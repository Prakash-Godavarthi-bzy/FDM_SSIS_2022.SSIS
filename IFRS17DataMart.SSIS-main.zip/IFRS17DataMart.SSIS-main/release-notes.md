Sprint
- Add QA Channel

- DataType changed from DT_WTSTR to DT_DECIMAL to the EarningPattern for the bug 17-3254


@[User::FinalResult]  =="FAILURE" || @[User::AssumptionSetIsEmpty]  =="FAILURE"


[AssumpDatasetId],[AssumpPercName],[Division],[FocusGroup],[RowID],[Trifocus],[TriFocusName]

- Updated two packages to merge the 3 new tables into fct tables i17-4013 4014 4015

Sprintdot1
- Extend ICE inputs / outputs extracts to include all ref data / param tables(I17-6920).
