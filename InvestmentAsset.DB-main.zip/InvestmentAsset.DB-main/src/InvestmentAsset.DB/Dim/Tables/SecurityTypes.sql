﻿CREATE TABLE [Dim].[SecurityTypes](
	[SecurityTypeID] [int] IDENTITY(1,1) NOT NULL,
	[SecurityType] [nvarchar](255) NULL,
	[Duration_Exclude_Futures] [nvarchar](5) NULL,
	[Filter_For_Index_Linked_Securities] [nvarchar](5) NULL,
	InsertDate DATETIME NULL,
	FileRunLogID BIGINT NULL,
 CONSTRAINT [PK_SecurityTypeID] PRIMARY KEY CLUSTERED 
(
	[SecurityTypeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO
