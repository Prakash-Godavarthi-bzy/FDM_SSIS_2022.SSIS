﻿CREATE TABLE [Dim].[SecurityDetails](
	[SecurityDetailsID] [int] IDENTITY(1,1) NOT NULL,
	[SecurityID] [int] NULL,
	[ISIN] [nvarchar](50) NULL,
	[Identifier] [nvarchar](50) NULL,
	[Detailed_Description] [nvarchar](500) NULL,
	[Final_Maturity] [date] NULL,
	[Coupon_Type] [nvarchar](50) NULL,
	[Coupon_Rate] [decimal](18, 3) NULL,
	[Ultimate_Parent_Description] [nvarchar](255) NULL,
	[InsertDate] [datetime] NULL,
	[FileRunLogID] [bigint] NULL,
 CONSTRAINT [PK_SecurityDetailsID] PRIMARY KEY CLUSTERED 
(
	[SecurityDetailsID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO

