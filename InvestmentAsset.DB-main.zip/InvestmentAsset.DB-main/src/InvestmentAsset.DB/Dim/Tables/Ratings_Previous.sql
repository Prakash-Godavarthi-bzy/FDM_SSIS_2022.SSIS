﻿CREATE TABLE [Dim].[Ratings_Previous](
	[RatingID] [int] IDENTITY(1,1) NOT NULL,
	[Rating_Including_Beazley_Provided] [nvarchar](255) NULL,
	[Rating_Group] [nvarchar](25) NULL,
	[Rating_Sort] [nvarchar](25) NULL,
	[Rating_Group_Sort] [nvarchar](10) NULL,
	InsertDate DATETIME,
	FileRunLogID BIGINT,
 CONSTRAINT [PK_RatingID] PRIMARY KEY CLUSTERED 
(
	[RatingID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO