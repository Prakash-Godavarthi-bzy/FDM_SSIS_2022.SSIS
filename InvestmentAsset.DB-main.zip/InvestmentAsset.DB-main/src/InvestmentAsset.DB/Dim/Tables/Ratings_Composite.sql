﻿CREATE TABLE [Dim].[Ratings_Composite] (
    [RatingID]               BIGINT         IDENTITY (0, 1) NOT NULL,
    [Composite_Rating]       NVARCHAR (255) NULL,
    [Composite_Rating_Group] NVARCHAR (10)  NULL,
    [Rating_Sort]            NVARCHAR (10)  NULL,
    [Rating_Group_Sort]      NVARCHAR (10)  NULL,
    [InsertDate]             DATETIME       NULL,
    [FileRunLogID]           BIGINT         NULL,
    CONSTRAINT [PK_Composite_RatingID] PRIMARY KEY CLUSTERED ([RatingID] ASC) WITH (FILLFACTOR = 90)
);


GO