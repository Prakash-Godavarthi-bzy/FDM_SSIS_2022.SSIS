﻿CREATE TABLE [Dim].[Calender](
	[DateKey] [int] NULL,
	[Date] [varchar](20) NULL,
	[Year] [int] NULL,
	[Quarter] [varchar](5) NULL,
	[Year_Quarter] [varchar](10) NULL,
	[Month_Name] [varchar](10) NULL,
	[Month_Sort_Key] [int] NULL,
	[Year_Month_Key] [varchar](10) NULL,
	[Year-Month] [varchar](10) NULL,
	[Week_of_Year] [int] NULL,
	[Day_Of_WeekID] [int] NULL,
	[Day_Of_Week] [nvarchar](30) NULL,
	[Week_Day_Flag] [varchar](5) NULL,
	[InsertDate] [datetime] NULL,
	[FileRunLogID] [int] NULL
) ON [PRIMARY]
GO
