﻿CREATE TABLE [Dim].[AssetType](
	[AssetTypeID] [int] IDENTITY(1,1) NOT NULL,
	[Beazley_Asset_Type] [nvarchar](255) NULL,
	[Fixed_Income_Report_Asset_Class] [nvarchar](255) NULL,
	[Asset_Class_Sort] [int] NULL,
	[InsertDate] [datetime] NULL,
	[FileRunLogID] [bigint] NULL,
 CONSTRAINT [PK_AssetTypeID] PRIMARY KEY CLUSTERED 
(
	[AssetTypeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO