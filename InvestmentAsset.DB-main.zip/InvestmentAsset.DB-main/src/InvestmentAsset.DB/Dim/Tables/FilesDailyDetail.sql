﻿CREATE TABLE [Dim].[FilesDailyDetail](
	[FileDate] [int] NULL,
	[File_Name_Daily_Detail] [nvarchar](500) NULL,
	[File_Folder] [nvarchar](500) NULL,
	[Date_Modified] [datetime] NULL,
	[Detail_File_Row_Count] [int] NULL
) ON [PRIMARY]
GO
