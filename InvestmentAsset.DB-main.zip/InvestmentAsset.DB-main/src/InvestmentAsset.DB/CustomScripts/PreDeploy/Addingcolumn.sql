﻿/*
 Pre-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be executed before the build script.	
 Use SQLCMD syntax to include a file in the pre-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the pre-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

/*------> Commenting due to deployment issues and they already added in the table level
--Adding the ABS column
IF NOT EXISTS (SELECT 1 
           FROM INFORMATION_SCHEMA.COLUMNS 
           WHERE TABLE_SCHEMA = 'Landing' 
           AND TABLE_NAME = 'CSReturns' 
           AND COLUMN_NAME = 'ABS')
BEGIN
    Alter table [Landing].[CSReturns] ADD [ABS] [bit] NULL;
END

IF NOT EXISTS (SELECT 1 
           FROM INFORMATION_SCHEMA.COLUMNS 
           WHERE TABLE_SCHEMA = 'Landing' 
           AND TABLE_NAME = 'CSReturns_Stage' 
           AND COLUMN_NAME = 'ABS')
BEGIN
    Alter table [Landing].[CSReturns_Stage] ADD [ABS] [bit] NULL;
END

IF NOT EXISTS (SELECT 1 
           FROM INFORMATION_SCHEMA.COLUMNS 
           WHERE TABLE_SCHEMA = 'Landing' 
           AND TABLE_NAME = 'IRReturns' 
           AND COLUMN_NAME = 'ABS')
BEGIN
    Alter table [Landing].[IRReturns] ADD [ABS] [bit] NULL;
END

IF NOT EXISTS (SELECT 1 
           FROM INFORMATION_SCHEMA.COLUMNS 
           WHERE TABLE_SCHEMA = 'Landing' 
           AND TABLE_NAME = 'IRReturns_Stage' 
           AND COLUMN_NAME = 'ABS')
BEGIN
    Alter table [Landing].[IRReturns_Stage] ADD [ABS] [bit] NULL;
END

IF NOT EXISTS (SELECT 1 
           FROM INFORMATION_SCHEMA.COLUMNS 
           WHERE TABLE_SCHEMA = 'Landing' 
           AND TABLE_NAME = 'DurationBuckets' 
           AND COLUMN_NAME = 'ABS')
BEGIN
    Alter table [Landing].[DurationBuckets] ADD [ABS] [bit] NULL;
END

*/
