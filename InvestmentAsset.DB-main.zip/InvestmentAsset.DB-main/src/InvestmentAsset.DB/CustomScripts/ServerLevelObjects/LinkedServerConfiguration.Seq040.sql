﻿----INCLUDE #{LinkedServer1_Pre_v4}



SET @LinkedServerName = N'InvestmentAsset'

SET @RemoteUser = NULL --'#{Credential_PXY_IFRS17DataMart_UserName}' -- For Windows / Kerberos set to null

SET @RemotePassword = NULL--'#{Credential_PXY_IFRS17DataMart_Password}' -- For Windows / Kerberos set to null

SET @DataSourceName = '#{investmentasset.ssis.instance}'--'#{ifrs17datamart.ssis.instance}' -- remote server-instance name/CNAME

SET @CatalogName = N'SSISDB'-- remote database name

--SET @ProviderName = N'SQLNCLI'



-- INCLUDE #{LinkedServer1_Mid_v4}



/*



Use this for most LinkedServers (uses "Other" data sources)

With this type, the linked server destination instance name can change for each environment and you can set the remote database name



Instructions:

=============

1. Set the @LinkedServerName

2. Create an Octopus variable for the @RemoteUser

If you are using Kerberos, set @RemoteUser to NULL

3. Create an Octopus variable for the @RemotePassword

If you are using Kerberos, set @RemotePassword to NULL

4. Create an Octopus variable for the @DataSourceName (remote instance or CNAME)

5. Set the @CatalogName (remote database name)

6. If the default @ProviderName is not 'SQLNCLI', then uncomment and set the @ProviderName

7. Set any non-standard config below, e.g.



*/

--EXEC master.dbo.sp_addlinkedserver @server = @LinkedServerName, @srvproduct=N'IFRS17DataMart', @provider=@ProviderName, @datasrc=@DataSourceName, @catalog=@CatalogName

--EXEC master.dbo.sp_serveroption @server=@LinkedServerName, @optname=N'collation compatible', @optvalue=N'false'

--INCLUDE #{LinkedServer_TEST}