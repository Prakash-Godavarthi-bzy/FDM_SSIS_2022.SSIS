﻿--USE MSDB;

--		UPDATE activity
--		SET activity.stop_execution_date =  GETDATE()
--        from msdb.dbo.sysjobs_view job  
--        inner join msdb.dbo.sysjobactivity activity on job.job_id = activity.job_id 
--        where  
--        activity.run_Requested_date is not null  
--        and activity.stop_execution_date is null  
--        and job.name = 'IR_ExternalFeed';
