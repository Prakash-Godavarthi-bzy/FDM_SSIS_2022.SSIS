﻿EXECUTE sp_addextendedproperty @name = N'previous database owner', @value = 'BFL\fleem';


GO
EXECUTE sp_addextendedproperty @name = N'previous database owner date recorded', @value = '2018-04-25';

