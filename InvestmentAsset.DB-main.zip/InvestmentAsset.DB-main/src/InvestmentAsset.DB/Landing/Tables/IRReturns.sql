﻿CREATE TABLE [Landing].[IRReturns](
	[Pk_IRReturns] [int] IDENTITY(-1,-1) NOT NULL,
	[Trial] [int] NOT NULL,
	[Timestep] [int] NOT NULL,
	[3m] [decimal](28, 10) NOT NULL,
	[6m] [decimal](28, 10) NOT NULL,
	[1y] [decimal](28, 10) NOT NULL,
	[2y] [decimal](28, 10) NOT NULL,
	[3y] [decimal](28, 10) NOT NULL,
	[4y] [decimal](28, 10) NOT NULL,
	[5y] [decimal](28, 10) NOT NULL,
	[6y] [decimal](28, 10) NOT NULL,
	[7y] [decimal](28, 10) NOT NULL,
	[10y] [decimal](28, 10) NOT NULL,
	[15y] [decimal](28, 10) NOT NULL,
	[20y] [decimal](28, 10) NOT NULL,
	[30y] [decimal](28, 10) NOT NULL,
	[Currency] [nvarchar](50) NOT NULL,
	[CalibrationDate] [nvarchar](50) NOT NULL,
	[IdxLnk] [bit] NULL,
	[Partition] [varchar](255) NULL,
	[InsertDate] [datetime] NOT NULL,
	[Version] [int] NOT NULL,
	[FileRunLogID] [int] NOT NULL,
	[ABS] [bit] NULL,
CONSTRAINT [Pk_IRReturns] PRIMARY KEY CLUSTERED 
(
	[Pk_IRReturns] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX  bzy_IX_IRReturns_CalibrationDate
ON  Landing.IRReturns([CalibrationDate] ASC)