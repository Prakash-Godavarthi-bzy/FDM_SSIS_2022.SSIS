﻿CREATE TABLE [Landing].[Returns](
	[Pk_Returns] [bigint] IDENTITY(-1,-1) NOT NULL,
	[Trial] [int] NULL,
	[TimeStep] [int] NULL,
	[Type] [varchar](200) NULL,
	[Value] [decimal](28, 10) NULL,
	[FileType] [varchar](100) NULL,
	[InsertDate] [datetime] NOT NULL,
	[Version] [int] NOT NULL,
	[FileRunLogID] [int] NULL,
	[CalibrationDate] [nvarchar](50) NULL
) ON [PRIMARY]
GO

