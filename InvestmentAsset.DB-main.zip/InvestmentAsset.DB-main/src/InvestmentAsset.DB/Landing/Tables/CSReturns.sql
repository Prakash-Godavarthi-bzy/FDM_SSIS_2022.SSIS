﻿CREATE TABLE [Landing].[CSReturns](
	[Pk_CSReturns] [int] IDENTITY(-1,-1) NOT NULL,
	[Trial] [int] NOT NULL,
	[Timestep] [int] NOT NULL,
	[Rating] [nvarchar](50) NOT NULL,
	[3m] [decimal](28, 10) NOT NULL,
	[6m] [decimal](28, 10) NOT NULL,
	[1y] [decimal](28, 10) NOT NULL,
	[2y] [decimal](28, 10) NOT NULL,
	[3y] [decimal](28, 10) NOT NULL,
	[4y] [decimal](28, 10) NOT NULL,
	[5y] [decimal](28, 10) NOT NULL,
	[6y] [decimal](28, 10) NOT NULL,
	[7y] [decimal](28, 10) NOT NULL,
	[10y] [decimal](28, 10) NOT NULL,
	[15y] [decimal](28, 10) NOT NULL,
	[20y] [decimal](28, 10) NOT NULL,
	[30y] [decimal](28, 10) NOT NULL,
	[Currency] [nvarchar](50) NOT NULL,
	[CalibrationDate] [nvarchar](50) NOT NULL,
	[GSAM] [bit] NULL,
	[TransitionFree] [bit] NULL,
	[Partition] [varchar](255) NULL,
	[InsertDate] [datetime] NULL,
	[Version] [int] NULL,
	[FileRunLogID] [int] NULL,
	[ABS] [bit] NULL,
CONSTRAINT [Pk_CSReturns] PRIMARY KEY CLUSTERED 
(
	[Pk_CSReturns] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX  bzy_IX_CSReturns_CalibrationDate
ON  Landing.CSReturns([CalibrationDate] ASC)