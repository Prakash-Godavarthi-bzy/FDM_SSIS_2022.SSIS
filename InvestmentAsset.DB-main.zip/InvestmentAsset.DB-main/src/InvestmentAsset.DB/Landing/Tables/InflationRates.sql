﻿CREATE TABLE [Landing].[InflationRates](
	[Pk_InflationRates] [int] IDENTITY(-1,-1) NOT NULL,
	[Trial] [int] NULL,
	[TimeStep] [int] NULL,
	[InflationRate] [decimal](28, 10) NULL,
	[Currency] [nvarchar](10) NULL,
	[Calibration_Date] [nvarchar](25) NULL,
	[InsertDate] [datetime] NULL,
	[Version] [int] NULL,
	[FileRunLogID] [bigint] NULL
) ON [PRIMARY]
GO
