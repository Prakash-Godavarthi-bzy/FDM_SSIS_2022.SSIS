﻿CREATE PROCEDURE [dbo].[usp_UpdateDateRangeLog] 
 (@LogID INT ,@Status VARCHAR(50),@ErrorMessage NVARCHAR(500))
AS
BEGIN

DECLARE @EndTime DATETIME = GETDATE();

UPDATE InvestmentAsset.Audit.RPADateRangeLog 
SET EndDate= @EndTime,Status= @Status,ErrorMessage= @ErrorMessage
WHERE Pk_LogID= @LogID

END