﻿CREATE PROCEDURE [dbo].[usp_InsertDateRangeLog] 
		(@DateRange NVARCHAR(255),@ErrorMessage NVARCHAR(500),@UserID VARCHAR(50), @userEmail NVARCHAR(255))
AS
BEGIN

DECLARE @FileType VARCHAR(50) = 'RPA';
DECLARE @StartTime DateTime = GETDATE();
DECLARE @EndTime DATETIME = NULL;
DECLARE @Status VARCHAR(50) = 'Processing';

Insert Into InvestmentAsset.Audit.RPADateRangeLog(FileType,DateRange,StartDate,EndDate,Status,ErrorMessage,UserID,UserEmail) 
VALUES(@FileType,@DateRange,@StartTime, @EndTime,@Status,@ErrorMessage,@UserID,@userEmail)

SELECT  @@IDENTITY AS RequestID

END