﻿

CREATE VIEW [dbo].[VW_PortFolioAssets2] 
AS 
SELECT 
	 DM.[PortFolio_Date] AS Portfolio_Date
	,FK_SecurityID AS Security_ID
	,DA.Account
	,Beginning_Base_Market_Value_Accured AS Beginning_Base_Market_Value_Accrued
	,Ending_Base_Market_Value_Accured AS Ending_Base_Market_Value_Accrued
	,DSD.ISIN
	,Performance_Affecting_Total_Numerator
	,DSD.Identifier
	,DSD.Detailed_Description
	,DC.Currency
	,DSD.Final_Maturity
	,DSD.Coupon_Type
	,DST.SecurityType AS Security_Type
	,BSG.BeazleyStrategy AS Beazley_Strategy
	,DAC.AssetClass AS Asset_Class
	,DAT.Beazley_Asset_Type
	,DRC.Composite_Rating AS BZLY_Composite_Rating
	,DRP.Rating_Including_Beazley_Provided AS Rating_including_Beazley_provided
	,Yield_To_Maturity AS Yield_to_Maturity
	,Asset_Return
	,Perf_Affecting_Numerator_Assest_Return_in_USD_Terms AS Perf_Affecting_Numerator_Asset_Return_in_USD_terms
	,DVO1_inc_Beazley AS DV01_inc_Beazley
	,[weight] AS [Weight]
	,Asset_Contribution
	,Duration_Inc_Beazley AS Duration_inc_Beazley
	,Credit_Spread_Duration_Inc_Beazley AS Credit_Spread_Duration_inc_Beazley
	,DE.Entity
	,Base_Net_Income
	,Base_Net_Transfers_In_Out
	,Syndicate
	,DDG.DurationGroup AS Duration_Group
	,Credit_Beta
	,DIS.IndustrySector AS Industry_Sector
	,CSO1_Inc_Beazley AS CS01_inc_Beazley
	,Option_Adjusted_Spread_Inc_Beazley AS Option_Adjusted_Spread_inc_Beazley
	,Yield_Inc_Beazley AS Yield_inc_Beazley
	,Coupon_Rate
	,Ultimate_Parent_Description
	,Ending_Current_Units
	,Market_Price
	,Risk_Model_index AS Risk_Model_Index
	,DM.FileRunLogID
FROM Fact.DetailMeasure DM
INNER JOIN Dim.SecurityDetails DSD	ON DM.FK_SecurityID= DSD.SecurityID
INNER JOIN Dim.Account DA ON DM.FK_AccountID = DA.AccountID
INNER JOIN Dim.Currency DC ON DM.FK_CurrencyID = DC.CurrencyID
INNER JOIN Dim.SecurityTypes DST ON DM.FK_SecurityTypeID= DST.SecurityTypeID
INNER JOIN Dim.BeazleyStrategyGroups BSG ON DM.FK_BeazleyStrategyID = BSG.BeazleyStrategyID
INNER JOIN Dim.AssetClasses DAC ON DM.FK_AssetClassID= DAC.AssetClassID
INNER JOIN Dim.AssetType DAT ON DM.FK_AssetTypeID= DAT.AssetTypeID
INNER JOIN Dim.Ratings_Composite DRC ON DM.FK_CompositeRatingID = DRC.RatingID
INNER JOIN Dim.Ratings_Previous DRP ON DM.FK_RatingID = DRP.RatingID
INNER JOIN Dim.Entities DE ON DM.FK_EntityID = DE.EntityID
INNER JOIN Dim.DurationGroups DDG ON DM.FK_DurationID = DDG.DurationID
INNER JOIN Dim.IndustrySector DIS ON DM.FK_Industry = DIS.IndustrySectorID;