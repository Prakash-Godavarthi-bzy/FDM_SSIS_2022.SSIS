﻿CREATE View dbo.Vw_FileStatus AS
SELECT * FROM Audit.FileStatus