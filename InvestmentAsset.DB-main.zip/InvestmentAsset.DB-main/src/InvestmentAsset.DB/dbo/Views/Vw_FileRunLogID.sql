﻿CREATE View dbo.Vw_FileRunLogID AS
SELECT * FROM Audit.FileRunLog