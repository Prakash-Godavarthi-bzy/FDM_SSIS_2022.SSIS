initial Version of DB
