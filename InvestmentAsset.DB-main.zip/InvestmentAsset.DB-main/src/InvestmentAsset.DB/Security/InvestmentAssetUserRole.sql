﻿CREATE ROLE [InvestmentAssetUserRole]
    AUTHORIZATION [dbo];

