﻿CREATE USER [App.InvestmentAsset.Users.RW] FOR LOGIN [BFL\App.InvestmentAsset.Users.RW.TST];

