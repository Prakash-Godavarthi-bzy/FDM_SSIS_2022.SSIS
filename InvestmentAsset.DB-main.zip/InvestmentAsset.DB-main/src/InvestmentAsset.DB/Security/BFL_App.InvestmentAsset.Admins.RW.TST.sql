﻿CREATE LOGIN [BFL\App.InvestmentAsset.Admins.RW.TST]
    FROM WINDOWS WITH DEFAULT_LANGUAGE = [us_english];

