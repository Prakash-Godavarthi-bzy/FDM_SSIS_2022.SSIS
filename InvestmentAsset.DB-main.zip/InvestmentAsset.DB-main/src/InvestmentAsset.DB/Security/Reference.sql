﻿CREATE SCHEMA [Reference]
    AUTHORIZATION [dbo];

