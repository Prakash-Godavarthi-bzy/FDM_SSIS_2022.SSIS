﻿CREATE LOGIN [BFL\App.InvestmentAsset.Users.RW.TST]
    FROM WINDOWS WITH DEFAULT_LANGUAGE = [us_english];

