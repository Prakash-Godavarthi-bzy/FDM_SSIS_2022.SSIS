﻿ALTER ROLE [db_owner] ADD MEMBER [InvestmentAssetAdminRole];


GO
ALTER ROLE [db_owner] ADD MEMBER [App.InvestmentAsset.Admins.RW];


GO
ALTER ROLE [db_owner] ADD MEMBER [PXY_InvestReport];


GO
ALTER ROLE [db_owner] ADD MEMBER [BFL\FDM Developers];


GO
ALTER ROLE [db_datareader] ADD MEMBER [DBS.SQL.InvestmentAsset.RO];


GO
ALTER ROLE [db_owner] ADD MEMBER [BFL\kandy];

