﻿CREATE USER [App.InvestmentAsset.Admins.RW] FOR LOGIN [BFL\App.InvestmentAsset.Admins.RW.TST];

