﻿CREATE USER [BFL\kandy] FOR LOGIN [BFL\kandy];

