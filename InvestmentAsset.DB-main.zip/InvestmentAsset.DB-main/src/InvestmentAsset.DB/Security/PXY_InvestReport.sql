﻿CREATE USER [PXY_InvestReport] FOR LOGIN [BFL\PXY_InvestReport_Dev];



