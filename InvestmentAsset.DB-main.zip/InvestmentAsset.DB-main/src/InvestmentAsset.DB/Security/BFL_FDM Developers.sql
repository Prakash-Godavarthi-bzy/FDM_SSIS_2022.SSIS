﻿CREATE USER [BFL\FDM Developers] FOR LOGIN [BFL\FDM Developers];



