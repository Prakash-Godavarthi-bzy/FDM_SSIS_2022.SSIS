﻿CREATE SCHEMA [Fact]
    AUTHORIZATION [dbo];







