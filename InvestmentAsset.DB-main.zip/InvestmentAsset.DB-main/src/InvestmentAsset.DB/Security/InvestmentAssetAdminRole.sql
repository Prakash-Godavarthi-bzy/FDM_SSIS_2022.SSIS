﻿CREATE ROLE [InvestmentAssetAdminRole]
    AUTHORIZATION [dbo];

