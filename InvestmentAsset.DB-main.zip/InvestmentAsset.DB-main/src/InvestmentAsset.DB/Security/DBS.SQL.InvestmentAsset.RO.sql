﻿CREATE USER [DBS.SQL.InvestmentAsset.RO] FOR LOGIN [BFL\DBS.SQL.InvestmentAsset.RO.TST];





