﻿CREATE TABLE [Audit].[FileStatus] (
    [pk_FileID]         BIGINT        IDENTITY (1, 1) NOT NULL,
    [SourceFileName]    VARCHAR (250) NULL,
    [SourceFileType]    VARCHAR (100) NULL,
    [UserEmail]         VARCHAR (100) NULL,
    [UserID]            VARCHAR (10)  NULL,
    [SubmittedFileName] VARCHAR (100) NULL,
    [SubmissionStatus]  VARCHAR (100) NULL,
    [SubmittedDate]     DATETIME2 (7) DEFAULT (getdate()) NULL,
    PRIMARY KEY CLUSTERED ([pk_FileID] ASC) WITH (FILLFACTOR = 90)
);

