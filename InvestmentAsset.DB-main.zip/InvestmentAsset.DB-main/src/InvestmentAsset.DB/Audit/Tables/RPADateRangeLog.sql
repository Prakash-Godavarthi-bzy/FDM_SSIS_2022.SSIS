﻿CREATE TABLE [Audit].[RPADateRangeLog](
	[Pk_LogID] [int] IDENTITY(0,1) NOT NULL,
	[FileType] [varchar](100) NULL,
	[DateRange] [nvarchar](255) NULL,
	[StartDate] [datetime2](7) NULL,
	[EndDate] [datetime2](7) NULL,
	[Status] [varchar](100) NULL,
	[ErrorMessage] [nvarchar](500) NULL,
	[UserID] [varchar](100) NULL,
	[UserEmail] [nvarchar](255) NULL
) ON [PRIMARY]
GO
