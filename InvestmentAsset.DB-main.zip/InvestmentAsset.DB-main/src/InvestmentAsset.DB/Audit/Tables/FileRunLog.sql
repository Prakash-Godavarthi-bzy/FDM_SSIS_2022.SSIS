﻿CREATE TABLE [Audit].[FileRunLog] (
    [FileRunLogID]     INT            IDENTITY (1, 1) NOT NULL,
    [fk_FileRunConfig] INT            NOT NULL,
    [FileName]         NVARCHAR (255) NOT NULL,
    [FileType]         NVARCHAR (255) NOT NULL,
    [CreatedDate]      DATETIME       NOT NULL,
    [InitiatedUser]    NVARCHAR (150) NOT NULL,
	[UserEmail] [nvarchar](255) NULL,
    [StartTime]        DATETIME       NULL,
    [EndTime]          DATETIME       NULL,
    [Status]           NVARCHAR (150) NOT NULL,
    [RecordsInserted]  BIGINT         NULL,
    CONSTRAINT [pk_FileRunLog] PRIMARY KEY CLUSTERED ([FileRunLogID] ASC) WITH (FILLFACTOR = 90)
);

