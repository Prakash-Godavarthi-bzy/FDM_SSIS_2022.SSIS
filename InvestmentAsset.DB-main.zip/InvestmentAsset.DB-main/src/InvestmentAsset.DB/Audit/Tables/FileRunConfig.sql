﻿CREATE TABLE [Audit].[FileRunConfig] (
    [pk_FileConfig]  INT            IDENTITY (1, 1) NOT NULL,
    [FolderName]     NVARCHAR (255) NOT NULL,
    [FileType]       NVARCHAR (255) NOT NULL,
    [PackageName]    NVARCHAR (255) NOT NULL,
    [Stream]         INT            NOT NULL,
    [RunOrder]       INT            NOT NULL,
    [SSISFolderName] NVARCHAR (255) NOT NULL,
    CONSTRAINT [pk_FileConfig] PRIMARY KEY CLUSTERED ([pk_FileConfig] ASC) WITH (FILLFACTOR = 90)
);

