﻿CREATE TABLE [Reference].[Securities] (
    [Security ID]          FLOAT (53)     NULL,
    [ISIN]                 NVARCHAR (255) NULL,
    [Identifier]           NVARCHAR (255) NULL,
    [Detailed Description] NVARCHAR (255) NULL,
    [Security Type]        NVARCHAR (255) NULL,
    [Beazley Strategy]     NVARCHAR (255) NULL,
    [Coupon Type]          NVARCHAR (255) NULL,
    [Final Maturity]       DATETIME       NULL,
    [Currency]             NVARCHAR (255) NULL
);

