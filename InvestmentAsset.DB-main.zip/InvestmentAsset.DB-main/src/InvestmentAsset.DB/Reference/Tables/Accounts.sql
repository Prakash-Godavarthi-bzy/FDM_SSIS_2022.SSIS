﻿CREATE TABLE [Reference].[Accounts] (
    [Account ID] FLOAT (53)     NULL,
    [Account]    NVARCHAR (255) NULL
);

