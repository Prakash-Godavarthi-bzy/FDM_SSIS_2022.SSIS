﻿CREATE TABLE [Reference].[AggregateAccounts] (
    [Aggregate Account Name] NVARCHAR (255) NULL,
    [Account ID]             FLOAT (53)     NULL,
    [Effective Date]         DATETIME       NULL
);

