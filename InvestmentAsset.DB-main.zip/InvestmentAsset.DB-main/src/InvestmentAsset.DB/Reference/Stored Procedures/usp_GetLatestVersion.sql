﻿




CREATE PROCEDURE [Reference].[usp_GetLatestVersion] (
  @RaterIndicator NVARCHAR(255)
) AS
BEGIN
DECLARE @VersionId INT;

SELECT @VersionId = (
		SELECT MAX(VersionId)
		FROM Reference.[Version]
		WHERE RaterIndicator = @RaterIndicator
		)

SELECT *
FROM Reference.[Version]
WHERE VersionId = @VersionId

RETURN @VersionId;

END


