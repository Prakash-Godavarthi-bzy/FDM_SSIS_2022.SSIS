﻿




CREATE PROCEDURE [Reference].[DeactivateUserFromLatestVersion] (
    @UserName       NVARCHAR(255)
  ) AS

BEGIN

    DECLARE @VersionId AS INT
    DECLARE @SequenceId AS INT
    SELECT @VersionId = MAX(VersionID) FROM Reference.[Version]
    
    SELECT @SequenceId = te.SequenceId
    
    FROM Reference.TableEntry te
    INNER JOIN Reference.TableColumn tc
    ON te.TableColumnID = tc.TableColumnID
    INNER JOIN Reference.[Table] t
    ON tc.TableID = t.TableID

    WHERE t.VersionID = @VersionId
    AND   t.ExcelName = 'DB.Reference.CurrentUnderwriterTable'
    AND   te.Value = @UserName ;
    
    DELETE FROM Reference.TableEntry
    WHERE TableEntryID IN 
        (SELECT TableEntryID FROM 
         Reference.TableEntry te
         INNER JOIN Reference.TableColumn tc
         ON te.TableColumnID = tc.TableColumnID
         INNER JOIN Reference.[Table] t
         ON tc.TableID = t.TableID

         WHERE t.VersionID      = @VersionId
         AND   t.ExcelName      = 'DB.Reference.CurrentUnderwriterTable'
         AND   te.SequenceId    = @SequenceId)
    
    
    UPDATE te SET SequenceId = a.SequenceId
    FROM
        (SELECT TableEntryID,
        ROW_NUMBER() OVER (PARTITION BY te.TableColumnID ORDER BY te.SequenceId) AS SequenceId
     
        FROM Reference.TableEntry te
        INNER JOIN Reference.TableColumn tc
        ON te.TableColumnID = tc.TableColumnID
        INNER JOIN Reference.[Table] t
        ON tc.TableID = t.TableID

        WHERE t.VersionID = @VersionId
        AND   t.ExcelName = 'DB.Reference.CurrentUnderwriterTable') a
        INNER JOIN Reference.TableEntry te
        ON a.TableEntryID = te.TableEntryID
     
     
     UPDATE t SET [RowCount] = [RowCount] - 1
     FROM Reference.[Table] t
     WHERE VersionID = @VersionId
     AND ExcelName = 'DB.Reference.CurrentUnderwriterTable'
     
     
END

