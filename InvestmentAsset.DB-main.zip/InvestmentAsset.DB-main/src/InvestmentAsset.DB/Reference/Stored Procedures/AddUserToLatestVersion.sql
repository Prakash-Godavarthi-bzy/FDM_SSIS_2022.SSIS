﻿




CREATE PROCEDURE [Reference].[AddUserToLatestVersion] (
    @UserName       NVARCHAR(255),
    @UserLocation   NVARCHAR(255)
  ) AS

BEGIN

    DECLARE @VersionId AS INT
    DECLARE @SequenceId AS INT
    SELECT @VersionId = MAX(VersionID) FROM Reference.[Version]
    
    SELECT @SequenceId = MAX(te.SequenceId)+1
    
    FROM Reference.TableEntry te
    INNER JOIN Reference.TableColumn tc
    ON te.TableColumnID = tc.TableColumnID
    INNER JOIN Reference.[Table] t
    ON tc.TableID = t.TableID

    WHERE t.VersionID = @VersionId
    AND   t.ExcelName = 'DB.Reference.CurrentUnderwriterTable'
    
    INSERT INTO Reference.TableEntry
            ( TableColumnID ,
              SequenceId ,
              ExcelName ,
              Value
            )
   
   SELECT DISTINCT te.TableColumnID, @SequenceId, NULL, @UserName
   FROM Reference.TableEntry te
    INNER JOIN Reference.TableColumn tc
    ON te.TableColumnID = tc.TableColumnID
    INNER JOIN Reference.[Table] t
    ON tc.TableID = t.TableID
    WHERE t.VersionID = @VersionId
    AND   t.ExcelName = 'DB.Reference.CurrentUnderwriterTable'
    AND tc.header='Underwriter'
    
   UNION ALL
    
   SELECT DISTINCT te.TableColumnID, @SequenceId, NULL, @UserLocation
   FROM Reference.TableEntry te
    INNER JOIN Reference.TableColumn tc
    ON te.TableColumnID = tc.TableColumnID
    INNER JOIN Reference.[Table] t
    ON tc.TableID = t.TableID
    WHERE t.VersionID   = @VersionId
    AND   t.ExcelName = 'DB.Reference.CurrentUnderwriterTable'
    AND tc.header='UnderwriterLocation'
    
    UPDATE te
    SET te.SequenceId = newsequence.NewSequenceId

    FROM (SELECT  TableEntryID ,
            old.SequenceId ,
            NewSequenceId FROM    
        (SELECT te.TableEntryID, te.SequenceId FROM Reference.TableEntry te
        INNER JOIN Reference.TableColumn tc
        ON te.TableColumnID = tc.TableColumnID
        INNER JOIN Reference.[Table] t
        ON tc.TableID = t.TableID

        WHERE t.VersionID = @VersionId
        AND   t.ExcelName = 'DB.Reference.CurrentUnderwriterTable' 
        ) old
        
        INNER JOIN 
        (SELECT te.SequenceId,
        ROW_NUMBER() OVER (PARTITION BY te.TableColumnID ORDER BY te.Value) AS NewSequenceId
     
        FROM Reference.TableEntry te
        INNER JOIN Reference.TableColumn tc
        ON te.TableColumnID = tc.TableColumnID
        INNER JOIN Reference.[Table] t
        ON tc.TableID = t.TableID

        WHERE t.VersionID = @VersionId
        AND   t.ExcelName = 'DB.Reference.CurrentUnderwriterTable'
        AND   tc.Header='Underwriter'
        ) new
        ON old.SequenceId = new.SequenceId) newsequence
        INNER JOIN Reference.TableEntry te
        ON newsequence.TableEntryID = te.TableEntryID
        
          
     UPDATE t SET [RowCount] = [RowCount] + 1
     FROM Reference.[Table] t
     WHERE VersionID = @VersionId
     AND ExcelName = 'DB.Reference.CurrentUnderwriterTable'
     
     
     SELECT @SequenceId = MAX(te.SequenceId)+ 1
    
    FROM Reference.TableEntry te
    INNER JOIN Reference.TableColumn tc
    ON te.TableColumnID = tc.TableColumnID
    INNER JOIN Reference.[Table] t
    ON tc.TableID = t.TableID

    WHERE t.VersionID = @VersionId
    AND   t.ExcelName = 'DB.Reference.AllUnderwriterTable'
    
    INSERT INTO Reference.TableEntry
            ( TableColumnID ,
              SequenceId ,
              ExcelName ,
              Value
            )
   
   SELECT DISTINCT te.TableColumnID, @SequenceId, NULL, @UserName
   FROM Reference.TableEntry te
    INNER JOIN Reference.TableColumn tc
    ON te.TableColumnID = tc.TableColumnID
    INNER JOIN Reference.[Table] t
    ON tc.TableID = t.TableID
    WHERE t.VersionID = @Versionid
    AND   t.ExcelName = 'DB.Reference.AllUnderwriterTable'
    AND tc.header='Underwriter'
    
   UNION ALL
    
   SELECT DISTINCT te.TableColumnID, @SequenceId, NULL, @UserLocation
   FROM Reference.TableEntry te
    INNER JOIN Reference.TableColumn tc
    ON te.TableColumnID = tc.TableColumnID
    INNER JOIN Reference.[Table] t
    ON tc.TableID = t.TableID
    WHERE t.VersionID = @VersionId
    AND   t.ExcelName = 'DB.Reference.AllUnderwriterTable'
    AND tc.header='UnderwriterLocation'
    
    UPDATE te
    SET te.SequenceId = newsequence.NewSequenceId

    FROM (SELECT  TableEntryID ,
            old.SequenceId ,
            NewSequenceId FROM    
        (SELECT te.TableEntryID, te.SequenceId FROM Reference.TableEntry te
        INNER JOIN Reference.TableColumn tc
        ON te.TableColumnID = tc.TableColumnID
        INNER JOIN Reference.[Table] t
        ON tc.TableID = t.TableID

        WHERE t.VersionID = @VersionId
        AND   t.ExcelName = 'DB.Reference.AllUnderwriterTable' 
        ) old
        
        INNER JOIN 
        (SELECT te.SequenceId,
        ROW_NUMBER() OVER (PARTITION BY te.TableColumnID ORDER BY te.Value) AS NewSequenceId
     
        FROM Reference.TableEntry te
        INNER JOIN Reference.TableColumn tc
        ON te.TableColumnID = tc.TableColumnID
        INNER JOIN Reference.[Table] t
        ON tc.TableID = t.TableID

        WHERE t.VersionID   = @VersionId
        AND   t.ExcelName = 'DB.Reference.AllUnderwriterTable'
        AND   tc.Header='Underwriter'
        ) new
        ON old.SequenceId = new.SequenceId) newsequence
        INNER JOIN Reference.TableEntry te
        ON newsequence.TableEntryID = te.TableEntryID
        
          
     UPDATE t SET [RowCount] = [RowCount] + 1
     FROM Reference.[Table] t
     WHERE VersionID = @VersionId
     AND ExcelName = 'DB.Reference.AllUnderwriterTable'
     
     
     
END

