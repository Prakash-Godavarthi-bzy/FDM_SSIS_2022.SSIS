﻿


CREATE PROCEDURE [Reference].[usp_AppendVersion] (
  @RaterIndicator NVARCHAR(255)
  ,@VersionNotes NVARCHAR(MAX)
) AS
BEGIN
  DECLARE @VersionId INT;

  -- TODO: Checks (Version is non-trivial, relationships, etc.)

  -- Create new version
  INSERT INTO Reference.[Version] (RaterIndicator, VersionNotes)
  VALUES (@RaterIndicator, @VersionNotes);

  SELECT @VersionId = SCOPE_IDENTITY();

  UPDATE #ReferenceData SET VersionId = @VersionId;


  INSERT INTO Reference.[Table] (VersionID, SequenceId, ExcelName, ColumnCount, [RowCount])
  SELECT VersionId          AS VersionID, 
         TableNumber        AS SequenceId,
         TableName          AS ExcelName,
         MAX([Column])      AS  ColumnCount,
         MAX([Row])         AS [RowCount]
  FROM #ReferenceData
  GROUP BY TableNumber, TableName, VersionId;

  UPDATE #ReferenceData
  SET    TableId = t.TableID
  FROM #ReferenceData rd
  INNER JOIN Reference.[Table] t
  ON  rd.VersionId   = t.VersionID
  AND rd.TableNumber = t.SequenceId;


  INSERT INTO Reference.TableColumn (TableID, SequenceId, ExcelName, Header)
  select TableId            AS TableID, 
         [Column]           AS SequenceId, 
         ColumnName         AS ExcelName, 
         ColumnHeader       AS Header
  FROM #ReferenceData
  GROUP BY TableId, [Column], ColumnName, ColumnHeader;

  UPDATE #ReferenceData  
  SET TableColumnId = tc.TableColumnID
  FROM #ReferenceData rd
  INNER JOIN Reference.TableColumn tc
  ON  rd.TableId  = tc.TableID
  AND rd.[Column] = tc.SequenceId;


  INSERT INTO Reference.TableEntry (TableColumnID, SequenceId, ExcelName, Value)
  SELECT TableColumnId      AS TableColumnID,
         [Row]              AS SequenceId,
         CellName           AS ExcelName,
         Value              AS Value
  FROM #ReferenceData;

  UPDATE #ReferenceData
  SET TableEntryId = te.TableEntryID
  FROM #ReferenceData rd
  INNER JOIN Reference.TableEntry te
  ON  rd.TableColumnId  = te.TableColumnID
  AND rd.[Row]          = te.SequenceId;

  RETURN @VersionId;

END
