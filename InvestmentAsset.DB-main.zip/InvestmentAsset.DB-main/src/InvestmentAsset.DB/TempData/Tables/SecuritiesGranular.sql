﻿CREATE TABLE [TempData].[SecuritiesGranular] (
    [Security ID]                 FLOAT (53) NULL,
    [Account ID]                  FLOAT (53) NULL,
    [As At Date]                  DATETIME   NULL,
    [Base Market Value + Accrued] FLOAT (53) NULL,
    [DV01 (inc Beazley)]          FLOAT (53) NULL
);

