﻿DECLARE @FileRunConfig TABLE
( 
	[pk_FileConfig]  INT  IDENTITY (1, 1) NOT NULL,
    [FolderName]     NVARCHAR (255) NOT NULL,
    [FileType]       NVARCHAR (255) NOT NULL,
    [PackageName]    NVARCHAR (255) NOT NULL,
    [Stream]         INT            NOT NULL,
    [RunOrder]       INT            NOT NULL,
    [SSISFolderName] NVARCHAR (255) NOT NULL

)

INSERT INTO @FileRunConfig ([FolderName],[FileType],[PackageName],[Stream],[RunOrder],[SSISFolderName])
     VALUES
           ('Calibrations\AbsReturns','AbsReturns','GenericReturns.dtsx',1,1,'Investment_Reporting'),
		   ('Calibrations\CashReturns','CashReturns','GenericReturns.dtsx',1,2,'Investment_Reporting'),
		   ('Calibrations\EquityReturns','EquityReturns','GenericReturns.dtsx',1,3,'Investment_Reporting'),
		   ('Calibrations\HFReturns','HFReturns','GenericReturns.dtsx',1,4,'Investment_Reporting'),
		   ('Calibrations\StratCredReturns','StratCredReturns','GenericReturns.dtsx',1,5,'Investment_Reporting'),
		   ('Calibrations\CSReturns','CSReturns','CSReturn.dtsx',2,1,'Investment_Reporting'),
		   ('Calibrations\IRReturns','IRReturns','IRReturn.dtsx',2,2,'Investment_Reporting'),
		   ('Calibrations\EcoDriver','EcoDriver','EcoDriver.dtsx',2,3,'Investment_Reporting'),
		   ('Calibrations\FXRates','FXRates','FXRates.dtsx',2,4,'Investment_Reporting'),
		   ('Calibrations\InflationRates','InflationRates','InflationRates.dtsx',2,5,'Investment_Reporting'),
		   ('Calibrations\SwapRates','SwapRates','SwapRates.dtsx',2,6,'Investment_Reporting'),
		   ('Portfolio','Portfolio','PortFolioLanding.dtsx',3,1,'Investment_Reporting'),
		   ('Calibrations\DurationBuckets','DurationBuckets','DurationBuckets.dtsx',2,7,'Investment_Reporting'),
		   ('RPA','RPA','RPAFileStatus.dtsx',3,2,'Investment_Reporting')

MERGE InvestmentAsset.Audit.FileRunConfig AS TGT

USING @FileRunConfig AS SRC

ON (
		TGT.[pk_FileConfig]=SRC.[pk_FileConfig] AND
		TGT.[FolderName] = SRC.[FolderName] AND
		TGT.[FileType] = SRC.[FileType]

)

WHEN MATCHED AND

			   ISNULL(TGT.[PackageName],'') <> ISNULL(SRC.[PackageName],'') OR
			   ISNULL(TGT.[Stream],'') <> ISNULL(SRC.[Stream],'') OR 
			   ISNULL(TGT.[RunOrder],'') <> ISNULL(SRC.[RunOrder],'') OR
			   ISNULL(TGT.[SSISFolderName],'') <> ISNULL(SRC.[SSISFolderName],'')

THEN

      UPDATE SET TGT.[PackageName] = SRC.[PackageName],
				 TGT.[Stream] = SRC.[Stream],
				 TGT.[RunOrder] = SRC.[RunOrder],
				 TGT.[SSISFolderName] = SRC.[SSISFolderName]
				 
			 
				

WHEN NOT MATCHED BY TARGET THEN

      INSERT ([FolderName],[FileType],[PackageName],[Stream],[RunOrder],[SSISFolderName])

      VALUES ([FolderName],[FileType],[PackageName],[Stream],[RunOrder],[SSISFolderName])
	  ;