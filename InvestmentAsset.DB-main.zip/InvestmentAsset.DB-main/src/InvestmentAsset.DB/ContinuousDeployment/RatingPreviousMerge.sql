﻿DECLARE @DimRatingPrevious TABLE
( 
	[RatingID]							  INT IDENTITY (1, 1) NOT NULL,
    [Rating_Including_Beazley_Provided]   NVARCHAR (255) NULL,
    [Rating_Group]						  NVARCHAR (25) NULL,
    [Rating_Sort]						  NVARCHAR (25) NULL,
    [Rating_Group_Sort]					  NVARCHAR(10) NULL,
    [InsertDate]						  DATETIME NULL,
    [FileRunLogID]						  BIGINT  NULL

)
INSERT INTO @DimRatingPrevious ([Rating_Including_Beazley_Provided],[Rating_Group],[Rating_Sort], [Rating_Group_Sort],[InsertDate],[FileRunLogID])
     VALUES
           ('AAA','AAA','A1Y','A1',GETDATE(),NULL),
		   ('AA+','AA','A2X','A2',GETDATE(),NULL),
		   ('AA','AA','A2Y','A2',GETDATE(),NULL),
		   ('AA-','AA','A2Z','A2',GETDATE(),NULL),
		   ('A+','A','A3X','A3',GETDATE(),NULL),
		   ('A','A','A3Y','A3',GETDATE(),NULL),
		   ('A-','A','A3Z','A3',GETDATE(),NULL),
		   ('BBB+','BBB','B1X','B1',GETDATE(),NULL),
		   ('BBB','BBB','B1Y','B1',GETDATE(),NULL),
		   ('BBB-','BBB','B1Z','B1',GETDATE(),NULL),
		   ('BB+','BB','B2X','B2',GETDATE(),NULL),
		   ('BB','BB','B2Y','B2',GETDATE(),NULL),
		   ('BB-','BB','B2Z','B2',GETDATE(),NULL),
		   ('B+','B','B3X','B3',GETDATE(),NULL),
		   ('B','B','B3Y','B3',GETDATE(),NULL),
		   ('B-','B','B3Z','B3',GETDATE(),NULL),
		   ('CCC','C','C','C',GETDATE(),NULL),
		   ('NR','NR','NR','NR',GETDATE(),NULL),
		   ('---','Unknown','Unknown','Unknown',GETDATE(),NULL),
		   ('Unknown','Unknown','Unknown','Unknown',GETDATE(),NULL)


MERGE InvestmentAsset.[Dim].[Ratings_Previous] AS TGT

USING @DimRatingPrevious AS SRC

ON (
		TGT.[RatingID]=SRC.[RatingID] 

)

WHEN MATCHED AND

			   ISNULL(TGT.[Rating_Including_Beazley_Provided],'') <> ISNULL(SRC.[Rating_Including_Beazley_Provided],'') OR
			   ISNULL(TGT.[Rating_Group],'') <> ISNULL(SRC.[Rating_Group],'') OR 
			   ISNULL(TGT.[Rating_Sort],'') <> ISNULL(SRC.[Rating_Sort],'') OR
			   ISNULL(TGT.[Rating_Group_Sort],'') <> ISNULL(SRC.[Rating_Group_Sort],'')

THEN

      UPDATE SET TGT.[Rating_Including_Beazley_Provided] = SRC.[Rating_Including_Beazley_Provided],
				 TGT.[Rating_Group] = SRC.[Rating_Group],
				 TGT.[Rating_Sort] = SRC.[Rating_Sort],
				 TGT.[Rating_Group_Sort] = SRC.[Rating_Group_Sort]
				 
			 
				

WHEN NOT MATCHED BY TARGET THEN

      INSERT ([Rating_Including_Beazley_Provided],[Rating_Group],[Rating_Sort],[Rating_Group_Sort],[InsertDate],[FileRunLogID])

      VALUES ([Rating_Including_Beazley_Provided],[Rating_Group],[Rating_Sort],[Rating_Group_Sort],[InsertDate],[FileRunLogID])
	  ;
