﻿
--DECLARE @EmailAddress							NVARCHAR(2000) = '#{Parameter_EmailAddress}'
--DECLARE @ExternalFeedLocation					NVARCHAR(2000) = '#{Parameter_ExternalFeedLocation}'
--DECLARE @InvestmentReportingDatabase			NVARCHAR(2000) = '#{TargetDatabaseName}'
--DECLARE @InvestmentReportingServer				NVARCHAR(2000) = '#{TargetInstanceName}'
--DECLARE @RPALocation							NVARCHAR(2000) = '#{Parameter_RPALocation}'
--DECLARE @UserEmail								NVARCHAR(2000) = '#{Parameter_UserEmail}'
--DECLARE @SMTPServer								NVARCHAR(2000) = '#{Parameter_SMTPServer}'




--DECLARE @ReferenceID INT = 0
--WHILE EXISTS	(SELECT	* FROM	InvestmentAsset.ssisdb.catalog.environment_references r 
--				WHERE	r.environment_name = 'InvestmentReportingEnvironment' AND r.reference_id > @ReferenceID)
--BEGIN
--	SELECT	@ReferenceID = MIN(reference_id)
--	FROM	InvestmentAsset.ssisdb.catalog.environment_references r
--	WHERE	r.environment_name = 'InvestmentReportingEnvironment'
--		AND reference_id > @ReferenceID
	
--	EXEC InvestmentAsset.SSISDB.catalog.delete_environment_reference @ReferenceID
--END

--IF EXISTS (SELECT * FROM InvestmentAsset.SSISDB.catalog.environments WHERE Name = 'InvestmentReportingEnvironment')		
--	EXEC InvestmentAsset.[SSISDB].[catalog].[delete_environment] @folder_name = 'InvestmentReporting', @Environment_Name = 'InvestmentReportingEnvironment'

----Clean off any parameters incorrectly set by solidops SSIS deployment
--DECLARE @ObjectName VARCHAR(255), @ParameterName VARCHAR(255), @ObjectType INT
--WHILE EXISTS (SELECT * FROM	InvestmentAsset.ssisdb.catalog.object_parameters op WHERE	op.referenced_variable_name LIKE 'InvestmentReporting%')
--BEGIN
--	SELECT	TOP 1  
--			@ObjectName = op.object_name,
--			@ParameterName = op.parameter_name,
--			@ObjectType = op.object_type
--	FROM	InvestmentAsset.ssisdb.catalog.object_parameters op 
--	WHERE	op.referenced_variable_name LIKE 'InvestmentReporting%'
	
--	EXEC InvestmentAsset.SSISDB.catalog.clear_object_parameter_value @folder_name = N'InvestmentReporting'
--													,@project_name = N'InvestmentReporting'
--													,@object_type = @ObjectType
--													,@object_name = @ObjectName
--													,@parameter_name = @ParameterName
--END


--EXEC InvestmentAsset.[SSISDB].[catalog].[create_environment] @folder_name = 'InvestmentReporting', @Environment_Name = 'InvestmentReportingEnvironment'

--SET @ReferenceID = NULL
--EXEC InvestmentAsset.[SSISDB].[catalog].[create_environment_reference] @folder_name = N'InvestmentReporting', @project_name = N'InvestmentReporting', @environment_name = N'InvestmentReportingEnvironment', @Reference_type = 'R', @reference_id = @ReferenceID



--EXEC InvestmentAsset.[SSISDB].[catalog].[create_environment_variable] @environment_name=N'InvestmentReportingEnvironment',			@variable_name=N'EmailAddress',					@sensitive=False, @folder_name=N'InvestmentReporting',		@value=@EmailAddress,					@data_type=N'String'
--EXEC InvestmentAsset.[SSISDB].[catalog].[create_environment_variable] @environment_name=N'InvestmentReportingEnvironment',			@variable_name=N'ExternalFeedLocation',			@sensitive=False, @folder_name=N'InvestmentReporting',		@value=@ExternalFeedLocation,			@data_type=N'String'
--EXEC InvestmentAsset.[SSISDB].[catalog].[create_environment_variable] @environment_name=N'InvestmentReportingEnvironment',			@variable_name=N'InvestmentReportingDatabase',	@sensitive=False, @folder_name=N'InvestmentReporting',		@value=@InvestmentReportingDatabase,	@data_type=N'String'
--EXEC InvestmentAsset.[SSISDB].[catalog].[create_environment_variable] @environment_name=N'InvestmentReportingEnvironment',			@variable_name=N'InvestmentReportingServer',	@sensitive=False, @folder_name=N'InvestmentReporting',		@value=@InvestmentReportingServer,		@data_type=N'String'
--EXEC InvestmentAsset.[SSISDB].[catalog].[create_environment_variable] @environment_name=N'InvestmentReportingEnvironment',			@variable_name=N'RPALocation',					@sensitive=False, @folder_name=N'InvestmentReporting',		@value=@RPALocation,					@data_type=N'String'
--EXEC InvestmentAsset.[SSISDB].[catalog].[create_environment_variable] @environment_name=N'InvestmentReportingEnvironment',			@variable_name=N'UserEmail',					@sensitive=False, @folder_name=N'InvestmentReporting',		@value=@UserEmail,						@data_type=N'String'
--EXEC InvestmentAsset.[SSISDB].[catalog].[create_environment_variable] @environment_name=N'InvestmentReportingEnvironment',			@variable_name=N'SMTPServer',					@sensitive=False, @folder_name=N'InvestmentReporting',		@value=@SMTPServer,						@data_type=N'String'


--EXEC InvestmentAsset.[SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'EmailAddress',					@object_name=N'InvestmentReporting', @folder_name=N'InvestmentReporting', @project_name=N'InvestmentReporting', @value_type=R, @parameter_value=N'EmailAddress'
--EXEC InvestmentAsset.[SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ExternalFeedLocation',			@object_name=N'InvestmentReporting', @folder_name=N'InvestmentReporting', @project_name=N'InvestmentReporting', @value_type=R, @parameter_value=N'ExternalFeedLocation'
--EXEC InvestmentAsset.[SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'InvestmentReportingDatabase',	@object_name=N'InvestmentReporting', @folder_name=N'InvestmentReporting', @project_name=N'InvestmentReporting', @value_type=R, @parameter_value=N'InvestmentReportingDatabase'
--EXEC InvestmentAsset.[SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'InvestmentReportingServer',		@object_name=N'InvestmentReporting', @folder_name=N'InvestmentReporting', @project_name=N'InvestmentReporting', @value_type=R, @parameter_value=N'InvestmentReportingServer'
--EXEC InvestmentAsset.[SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'RPALocation',					@object_name=N'InvestmentReporting', @folder_name=N'InvestmentReporting', @project_name=N'InvestmentReporting', @value_type=R, @parameter_value=N'RPALocation'
--EXEC InvestmentAsset.[SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'UserEmail',						@object_name=N'InvestmentReporting', @folder_name=N'InvestmentReporting', @project_name=N'InvestmentReporting', @value_type=R, @parameter_value=N'UserEmail'
--EXEC InvestmentAsset.[SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'SMTPServer',					@object_name=N'InvestmentReporting', @folder_name=N'InvestmentReporting', @project_name=N'InvestmentReporting', @value_type=R, @parameter_value=N'SMTPServer'
