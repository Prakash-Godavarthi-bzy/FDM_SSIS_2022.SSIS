﻿CREATE VIEW [Reporting].[ValidTriFocus]
	AS 


SELECT 
	[Name] As Valid_TrifocusName,
	[TriFocusCode] AS Valid_TrifocusCode,
	[LastChgDateTime] AS LastModifiedDate,
	[Code] AS MDS_Code,
	[ID] AS MDS_Id
FROM 
	[MDS].[TriFocus]

GO

GRANT select ON [Reporting].[ValidTriFocus] TO [Reporting]
GO
