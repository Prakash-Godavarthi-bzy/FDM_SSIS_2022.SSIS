﻿CREATE TABLE [ADM_TP_Output].[Mapping](
	[PK_SequenceNumber] [int] IDENTITY(1,1) NOT NULL,
	[SubmissionIdentifier] [nvarchar](11) NOT NULL,
	[TriFocusCode] [nvarchar](100) NULL,
	[TriFocusName] [nvarchar](250) NULL,
	[ReportTriFocus] [nchar](1) NOT NULL,
	[ADM_Class] [nvarchar](50) NULL,
	[ReportingState] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_Mapping] PRIMARY KEY CLUSTERED 
(
	[PK_SequenceNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [ADM_TP_Output].[Mapping]  WITH CHECK ADD  CONSTRAINT [CK_Mapping] CHECK  (([ReportTriFocus]='N' OR [ReportTriFocus]='Y'))
GO

ALTER TABLE [ADM_TP_Output].[Mapping] CHECK CONSTRAINT [CK_Mapping]
GO


CREATE NONCLUSTERED INDEX [ix_SubmissionIdentifier] ON [ADM_TP_Output].[Mapping]
(
	[SubmissionIdentifier] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO


