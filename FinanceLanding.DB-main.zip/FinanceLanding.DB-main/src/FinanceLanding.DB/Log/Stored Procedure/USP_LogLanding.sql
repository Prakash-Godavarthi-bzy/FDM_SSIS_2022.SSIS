﻿
CREATE	PROCEDURE [log].[usp_LogLanding]	@Input log.utt_ActivityLog READONLY
AS
BEGIN

	/*
       =========================================================================================================
                                         Insert into Log table
       =========================================================================================================
*/

	INSERT	[Orchestram].[Log].[ActivityLog](	FK_ParentActivityLog, FK_ActivityLogTag, FK_ActivitySource, FK_ActivityType, FK_ActivityStatus, ActivityHost
													, ActivityDatabase, ActivityJobId, ActivitySSISExecutionId, ActivityName, ActivityDateTime, ActivityMessage, AffectedRows)
	SELECT	NULL
	,		NULL
	,		5
	,		1
	,		ActivityStatus
	,		@@SERVERNAME
	,		'FinanceLanding'
	,		NULL
	,		ActivitySSISExecutionId
	,		ISNULL(ActivityName, 'FinanceLanding Activity')
	,		GETDATE()
	,		ActivityMessage
	,		RowsAffected
	FROM	@Input


END;