﻿
CREATE TABLE [ADM_RES_DAT].[Control](
	[PK_SequenceNumber] [int] IDENTITY(1,1) NOT NULL,
	[SubmissionIdentifier]  AS ((((CONVERT([nchar](4),[SubmissionYear])+'-')+CONVERT([nchar](1),[SubmissionQuarter]))+'-v')+CONVERT([nvarchar](3),[SubmissionVersion])),
	[SubmissionYear] [int] NOT NULL,
	[SubmissionQuarter] [int] NOT NULL,
	[SubmissionVersion] [int] NOT NULL,
	[FileValidatedBy] [nvarchar](255) NOT NULL,
	[Notes] [nvarchar](255) NULL,
	[RowCreated] [datetime] NOT NULL,
	[FileName] [varchar](1000) NULL,
 CONSTRAINT [PK_Control] PRIMARY KEY CLUSTERED 
(
	[PK_SequenceNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY],
 CONSTRAINT [UQ_SubmissionIdentifier] UNIQUE NONCLUSTERED 
(
	[SubmissionIdentifier] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [ADM_RES_DAT].[Control] ADD  CONSTRAINT [DF_ADFMS_Control_RowCreated]  DEFAULT (getdate()) FOR [RowCreated]
GO


