﻿CREATE PROCEDURE [fdm].[usp_LoadtoRI_Percentage]
--DECLARE
             @p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL		
AS

-- =============================================

-- Modified by:			Samata.Putumbaka@beazley.com
-- Modification date:	25-03-2022
-- Changes:				Loads the table fdm.RIPercentage in FinanceLanding. 
-- Modified by:			charvitha.sadhu@beazley.com
-- Modification date:	24-08-2022
-- Changes:			    Modified to populate the data from view. Changes are done based on the JIRA https://beazley.atlassian.net/browse/I1B-2766.
-- =============================================	
			
BEGIN

		SET NOCOUNT ON;

		DECLARE @Trancount INT= @@Trancount;
		DECLARE @v_ErrorMessage NVARCHAR(4000);

		DECLARE @v_RC							INT;
		DECLARE @v_ActivityLogTag				BIGINT;
		DECLARE @v_ActivitySource				SMALLINT;
		DECLARE @v_ActivityType					SMALLINT;
		DECLARE @v_ActivityStatusStart			SMALLINT;
		DECLARE @v_ActivityStatusStop			SMALLINT;
		DECLARE @v_ActivityStatusFail			SMALLINT;
		DECLARE @v_ActivityHost					VARCHAR(100);
		DECLARE @v_ActivityDatabase				VARCHAR(100);
		DECLARE @v_ActivityName					VARCHAR(100);
		DECLARE @v_ActivityDateTime				DATETIME2(2);
		DECLARE @v_ActivityMessage				NVARCHAR(4000);
		DECLARE @v_ActivityErrorCode			NVARCHAR(50);
		DECLARE @v_ActivityLogIdIn				BIGINT;
		DECLARE @v_ActivityLogIdOut				BIGINT;
		DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId;
		DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
		DECLARE @v_AffectedRows					INT				= 0;
		DECLARE @v_DataSet						VARCHAR(50)	= 'RIPercentage'

		-- for debugging. set to 1 & the no records will be written to the inbound tables.
		declare @stop bit = 0


		SELECT @v_ActivityStatusStart = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'STARTED';

		SELECT @v_ActivityStatusStop = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'SUCCEEDED';

		SELECT @v_ActivityStatusFail = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'ERRORED';

		DECLARE @v_BatchId INT;
		SELECT @v_BatchId = SCOPE_IDENTITY();
		--DECLARE @v_BatchId_Extensions INT;
		
  
		/* Log the start of the insert */

		BEGIN TRY

				SELECT   
					 @v_ActivityLogTag		        = NULL
					,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
					,@v_ActivityType				= (SELECT PK_ActivityType	
														FROM Orchestram.Log.ActivityType	
														WHERE ActivityType = CASE 
																				WHEN @p_ParentActivityLogId IS NULL 
																					THEN 'Manual process' 
																					ELSE 'Automated process' 
																				END)
					,@v_ActivityHost				= @@SERVERNAME
					,@v_ActivityName				= 'Load data into fdm.RIPercentage'
					,@v_ActivityDatabase			= 'FinanceLanding'
					,@v_ActivityDateTime			= GETUTCDATE()
					,@v_ActivityMessage				= NULL
					,@v_ActivityErrorCode			= NULL;

				EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
							 @p_ParentActivityLogId
							,@v_ActivityLogTag
							,@v_ActivitySource
							,@v_ActivityType
							,@v_ActivityStatusStart
							,@v_ActivityHost
							,@v_ActivityDatabase
							,@v_ActivityJobId
							,@v_ActivitySSISExecutionId
							,@v_ActivityName
							,@v_ActivityDateTime
							,@v_ActivityMessage
							,@v_ActivityErrorCode
							,@v_AffectedRows
							,@v_ActivityLogIdIn OUTPUT;

				SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

				--------------------------------------------------
				DECLARE @AuditHost varchar(255)		= CAST(SERVERPROPERTY('MachineName') as varchar(255))
				---Truncate the landing table before every load
				TRUNCATE  TABLE [FinanceLanding].fdm.RIPercentage	

----Munich Prep
--;with cte_acc as
--(
--select distinct cast(AccountingPeriod as varchar) AccountingPeriod,
--left(AccountingPeriod, 4) + case when right(AccountingPeriod , 2) in ('01', '02', '03') then '03'
--	   when right(AccountingPeriod, 2) in ('04', '05', '06') then '06'
--	   when right(AccountingPeriod, 2) in ('07', '08', '09') then '09'
--	   when right(AccountingPeriod, 2) in ('10', '11', '12') then '12'
--			   else '12'
--end QuarterRef 
--from fdm.AccountingPeriod--[adm].[Reserving_data]
--where AccountingPeriod >= '201809'
--and AccountingPeriod <= left(convert(varchar, getdate(), 112), 6)
--),

--cte_mun
--as
--(
--select Trifocus,
--YOA,
--dateadd(quarter, 1, cast(QuarterRef + '01' as date)) DateOfFact,
--Entity,
--SettlementCCY,
--[value]
--from
--(
--select triangle_group as Trifocus,
--cast(t.yoa as varchar) as YOA,
--asat,
--QuarterRef,
--en.ConformedEntityMapping as Entity,
--ccy as SettlementCCY,
--sum([Value]) [value],
--row_number() over 
--(partition by triangle_group,
--t.yoa,
--QuarterRef,
--en.ConformedEntityMapping,
--ccy
--order by asat desc) rownum
--from FinanceLanding.adm.[Reserving_data] t
--join cte_acc cte on (cte.AccountingPeriod = t.asat)
--left join FinanceLanding.MDS.ConformedEntityMapping en on (en.Entity = cast(t.synd as varchar))
--where special = 'Munich'
--and datasetname = 'Team Premium'
--and synd <> '8022'
--group by triangle_group,
--t.yoa,
--asat,
--QuarterRef,
--en.ConformedEntityMapping,
--ccy
--) t
--where rownum = 1
--and QuarterRef >= '201809'
--and yoa >= left(QuarterRef, 4) - 2
--),

----SPA Prep
--cte_cede
--as
--(
--select 2018 as YOA, 0.75 as Cede
--union all
--select 2019 as YOA, 0.6475 as Cede
--union all
--select 2020 as YOA, 0.6475 as Cede
--union all
--select 2021 as YOA, 0.8475 as Cede
--)
--,

----BICI Prep
--cte_bicisl as
--(
--select 'SL Facultative spend' ProgrammeCode, 'RAD' ClaimSBasis union all
--select 'MUNICH - Surplus', 'RAD' union all
--select 'FIDOML QS', 'RAD' union all
--select 'US Small Risks XL', 'RAD' union all
--select 'Cyber QS', 'RAD' union all
--select 'Environmental QS', 'RAD' union all
--select 'A&E Lawyers QS', 'RAD' union all
--select 'SLCyEx QS2', 'RAD' union all
--select 'Cyber Cat', 'CMD' union all
--select 'CUNA QS', 'RAD' union all
--select 'SLCyEx QS1', 'RAD' union all
--select 'Professions', 'RAD' union all
--select 'Systemic cover - Clash', 'CMD' union all
--select 'BICI Risk & Agg XL', 'LOD' union all
--select 'SLCyEx QS1 - TRC', 'RAD' union all
--select 'MUNQQS', 'RAD'
--)
--,

--cte_bici as
--(
--select t.AccountingPeriod,
--t.TrifocusCode, 
--t.TrifocusName,
--en.ConformedEntityMapping as Entity,
--t.YOA,
--t.ProgrammeCode,
--rt.Confirmed_RIPolicyType RIPolicyType,
--t.SettlementCCY,
--t.PolicyNumber,
--t.InceptionDate,
--t.ExpiryDate,
--t.ClaimsBasis,
--sum(sum(Premium)) over (partition by t.TrifocusCode, 
--	t.TrifocusName,
--	en.ConformedEntityMapping,
--	t.YOA,
--	t.ProgrammeCode,
--	rt.Confirmed_RIPolicyType,
--	t.SettlementCCY,
--	t.PolicyNumber,
--	t.InceptionDate,
--	t.ExpiryDate,
--	t.ClaimsBasis
--	order by t.AccountingPeriod asc
--) Premium
--from
--(
--select left(convert(varchar, DateOfFact, 112), 6) AccountingPeriod,
--t.TrifocusCode,
--tf.TrifocusName,
--'USBICI' as Entity,
--t.yoa YOA,
--e.ProgrammeCode,
--e.RIPolicyType,
--t.SettlementCCY,
--t.PolicyNumber,
--isnull(pol.rpd_ri_pol_prd_from, cast(yoa+'0101' as date)) InceptionDate,
--isnull(pol.rpd_ri_pol_prd_to, cast(yoa+'1231' as date)) as ExpiryDate,
--isnull(pol.rpd_ri_claims_basis, sl.ClaimSBasis) ClaimsBasis,
--sum(t.[value]) Premium
--from FinanceDataContract.Outbound.[Transaction] t
--join FinanceLanding.fdm.DimTrifocus tf on (tf.TrifocusCode = t.TrifocusCode)
--join FinanceDataContract.[Outbound].[Transaction_ReInsurance_Extensions_Bridge] b
--on (b.RowHash_Transaction = t.RowHash)
--join FinanceDataContract.[Outbound].[Transaction_ReInsurance_Extensions] e
--on (e.RowHash_Transaction_ReInsurance_Extensions = b.RowHash_Transaction_ReInsurance_Extensions)
--left join Eurobase.reinsurance_pol_det pol on 
--(pol.rpd_policy_reference = t.PolicyNumber
--and t.PolicyNumber <> 'NOPOLICY') 
--left join cte_bicisl sl on 
--(sl.ProgrammeCode = e.ProgrammeCode
--and t.PolicyNumber = 'NOPOLICY')
--where t.Dataset = 'BICI_RI_Ultimate_Premium'
--group by left(convert(varchar, DateOfFact, 112), 6),
--t.TrifocusCode,
--tf.TrifocusName,
--t.yoa,
--e.ProgrammeCode,
--e.RIPolicyType,
--t.SettlementCCY,
--t.PolicyNumber,
--isnull(pol.rpd_ri_pol_prd_from, cast(yoa+'0101' as date)),
--isnull(pol.rpd_ri_pol_prd_to, cast(yoa+'1231' as date)),
--isnull(pol.rpd_ri_claims_basis, sl.ClaimSBasis)
--having sum(t.[value]) <> 0

--union all

--select d.AccountingPeriod,
--t.TrifocusCode,
--tf.TrifocusName,
--'USBICI' as Entity,
--t.yoa YOA,
--e.ProgrammeCode,
--e.RIPolicyType,
--t.SettlementCCY,
--t.PolicyNumber,
--isnull(pol.rpd_ri_pol_prd_from, cast(yoa+'0101' as date)) InceptionDate,
--isnull(pol.rpd_ri_pol_prd_to, cast(yoa+'1231' as date)) as ExpiryDate,
--isnull(pol.rpd_ri_claims_basis, sl.ClaimSBasis) ClaimsBasis,
--0 as Premium
--from FinanceDataContract.Outbound.[Transaction] t
--join FinanceLanding.fdm.DimTrifocus tf on (tf.TrifocusCode = t.TrifocusCode)
--join FinanceDataContract.[Outbound].[Transaction_ReInsurance_Extensions_Bridge] b
--on (b.RowHash_Transaction = t.RowHash)
--join FinanceDataContract.[Outbound].[Transaction_ReInsurance_Extensions] e
--on (e.RowHash_Transaction_ReInsurance_Extensions = b.RowHash_Transaction_ReInsurance_Extensions)
--left join Eurobase.reinsurance_pol_det pol on 
--(pol.rpd_policy_reference = t.PolicyNumber
--and t.PolicyNumber <> 'NOPOLICY') 
--left join cte_bicisl sl on 
--(sl.ProgrammeCode = e.ProgrammeCode
--and  t.PolicyNumber = 'NOPOLICY')
--join
--(
--SELECT AccountingPeriod
--FROM [FinanceLanding].[fdm].[AccountingPeriod]
--where AccountingPeriod between 201601 and convert(varchar(6), getdate(), 112)
--and substring(AccountingPeriod, 5, 2) in ('03', '06', '09', '12') 
--)
--d on (d.AccountingPeriod > left(convert(varchar, DateOfFact, 112), 6))
--where t.Dataset = 'BICI_RI_Ultimate_Premium'
--group by d.AccountingPeriod,
--t.TrifocusCode,
--tf.TrifocusName,
--t.yoa,
--e.ProgrammeCode,
--e.RIPolicyType,
--t.SettlementCCY,
--t.PolicyNumber,
--isnull(pol.rpd_ri_pol_prd_from, cast(yoa+'0101' as date)),
--isnull(pol.rpd_ri_pol_prd_to, cast(yoa+'1231' as date)),
--isnull(pol.rpd_ri_claims_basis, sl.ClaimSBasis)
--having sum(t.[value]) <> 0
--) t
--left join FinanceLanding.MDS.ConformedEntityMapping en on (en.Entity = t.Entity)
--left join FinanceLanding.[MDS].[RITypeMapping] rt on (rt.RIPolicyType = t.RIPolicyType)
--group by t.AccountingPeriod,
--t.TrifocusCode, 
--t.TrifocusName,
--en.ConformedEntityMapping,
--t.YOA,
--t.ProgrammeCode,
--rt.Confirmed_RIPolicyType,
--t.SettlementCCY,
--t.PolicyNumber,
--t.InceptionDate,
--t.ExpiryDate,
--t.ClaimSBasis
--),

----All RI Query
--cte_ri AS
--(
--select t_all.*
--from
--(
----Munich
--select left(convert(varchar, DateOfFact, 112), 6) AccountingPeriod,
--tf.TrifocusCode, 
--t.Trifocus TrifocusName,
--t.Entity Entity,
--t.yoa YOA,
--'MUNQQS' as RIProgramme,
--'QS' as RIType,
--t.SettlementCCY,
--'NOPOLICY' as RIPolicyNumber,
--cast(cast(t.YOA as varchar) + case when t.YOA = 1998 then '0401' else '0101' end as date) as InceptionDate,
--cast(cast(t.YOA as varchar) + '1231' as date) as ExpiryDate,
--'RAD' as ClaimsBasis,
--t.[value] Premium
--FROM cte_mun t
--join fdm.DimTrifocus tf on (tf.TrifocusName = t.Trifocus)
--where t.[value] <> 0

--union all

----BICI
--select *
--from cte_bici
--where yoa >= left(AccountingPeriod, 4) - 2

--union all

----RI Spend General
--select
--AccountingPeriod,
--TrifocusCode, 
--TrifocusName,  
--en.ConformedEntityMapping as Entity,
--YOA,
--RIProgramme,
--RIType,
--SettlementCCY,
--RIPolicyNumber,
--InceptionDate,
--ExpiryDate,
--ClaimsBasis,
--sum(Premium) over (partition by TrifocusCode, 
--								TrifocusName,
--								en.ConformedEntityMapping,
--								YOA,
--								SettlementCCY,
--								--RIProgramme,
--								--RIType,
--								RIPolicyNumber
--								order by AccountingPeriod ASC) Premium--,
--from
--(
--	select t.fk_AccountingPeriod AccountingPeriod,
--	tf.TrifocusCode, 
--	tf.TrifocusName,
--	en.EntityCode AS Entity,
--	t.fk_YOA YOA,
--	max(isnull(prg.ifrs17_programme_group, ri.RIProgramme)) RIProgramme,
--	max(isnull(ty.Confirmed_RIPolicyType, isnull(pdet.rpd_rein_policy_type, case when ri.RIPolicyNumber in ('COMBPTY', 'COMBTTY') then 'XL' else ri.RIType end))) RIType,
--	t.currency AS SettlementCCY,
--	ri.RIPolicyNumber,
--	min(isnull(pdet.rpd_ri_pol_prd_from, ri.InceptionDate)) InceptionDate,
--	max(isnull(pdet.rpd_ri_pol_prd_to, ri.ExpiryDate)) ExpiryDate,
--	max(isnull(rpd_ri_claims_basis, ri.RIBasis)) ClaimsBasis,
--	sum(t.cur_amount) Premium--,
--	--0 AS GrossUltimates
--	from fdm.vw_FactFDMExternal t--fdm.FactFDMExternal_History t
--	JOIN fdm.[DimAccount] acc on (acc.pk_Account = t.fk_Account)
--	JOIN fdm.[DimProcess] prc on (prc.pk_Process = t.fk_Process)
--	LEFT JOIN fdm.vw_DimRIPolicy ri on (ri.pk_RIPolicy = t.fk_RIPolicy)
--	LEFT JOIN fdm.DimTrifocus tf ON (tf.pk_Trifocus = t.fk_TriFocus)
--	LEFT JOIN fdm.DimEntity en ON (en.pk_Entity = t.fk_Entity)
--	left join Eurobase.reinsurance_pol_det pdet on (pdet.rpd_policy_reference = ri.RIPolicyNumber)
--	left join Eurobase.rein_program_sequence prg on (prg.rps_program_id = pdet.rpd_treaty_ri_code)
--	left join mds.RITypeMapping ty on (ty.RIPolicyType = isnull(pdet.rpd_rein_policy_type, ri.RIType))
--	WHERE 
--	(
--	acc.AccountCode = 'RISPD10'
--	and prc.ProcessCode = '2B'
--	)
--	or
--	(
--	acc.AccountCode = 'RISPD01'
--	and prc.ProcessCode = '2A'
--	)
--	group by t.fk_AccountingPeriod,
--	tf.TrifocusCode, 
--	tf.TrifocusName, 
--	en.EntityCode,
--	t.fk_YOA,
--	ri.RIPolicyNumber,
--	t.currency	
--) t_risp 
--left join FinanceLanding.MDS.ConformedEntityMapping en on (en.Entity = t_risp.Entity)
--where t_risp.AccountingPeriod <> '201912'
--and t_risp.RIProgramme <> 'MUNQQS' 

--union all

----Missing 19Q4 RI Spend data
--select left(convert(varchar, t.DateOfFact, 112), 6) AccountingPeriod,
--t.TrifocusCode, 
--t.Trifocus,  
--en.ConformedEntityMapping as Entity,
--t.YOA,
--t.ProgrammeCode,
--ty.Confirmed_RIPolicyType RIPolicyType,
--t.SettlementCCY,
--t.RIPolicyNumber,
--t.InceptionDate,
--t.ExpiryDate,
--case when ty.Confirmed_RIPolicyType = 'FAC' then 'RAD' else pol.rpd_ri_claims_basis end as ClaimsBasis,
--sum([Value])  Premium
----from Testing.fdm.Missing19Q4Data t
--from [BR1_DataIngest].Testing.fdm.Missing19Q4Data t
--left join FinanceLanding.MDS.ConformedEntityMapping en on (en.Entity = t.Entity)
--left join FinanceLanding.mds.RITypeMapping ty on (ty.RIPolicyType = t.RIPolicyType)
--left join FinanceLanding.Eurobase.reinsurance_pol_det pol on (pol.rpd_policy_reference = t.RIPolicyNumber)
--where t.ProgrammeCode <> 'MUNQQS'
--group by left(convert(varchar, t.DateOfFact, 112), 6),
--t.TrifocusCode,
--t.Trifocus,  
--en.ConformedEntityMapping,
--t.YOA,
--t.ProgrammeCode,
--ty.Confirmed_RIPolicyType,
--t.SettlementCCY,
--t.RIPolicyNumber,
--t.InceptionDate,
--t.ExpiryDate,
--case when ty.Confirmed_RIPolicyType = 'FAC' then 'RAD' else pol.rpd_ri_claims_basis end

--union all

----Unincepted Allocation (DB Link to DEV until FDM data landed)
--select AccountingPeriod,
--TrifocusCode, 
--TrifocusName,  
--Entity,
--YOA,
--ProgrammeCode,
--RIPolicyType,
--SettlementCCY,
--RIPolicyNumber,
--InceptionDate,
--ExpiryDate,
--ClaimsBasis,
--sum([Premium]) over(partition by TrifocusCode, 
--TrifocusName,  
--Entity,
--YOA,
--ProgrammeCode,
--RIPolicyType,
--SettlementCCY,
--RIPolicyNumber,
--InceptionDate,
--ExpiryDate,
--ClaimsBasis
--order by AccountingPeriod)
--from
--(
--select  t.fk_AccountingPeriod AccountingPeriod,
--tf.TrifocusCode, 
--tf.TrifocusName,  
--cen.ConformedEntityMapping as Entity,
--t.fk_YOA YOA,
--ri.RIProgramme ProgrammeCode,
--ty.Confirmed_RIPolicyType RIPolicyType,
--t.currency as SettlementCCY,
--ri.RIPolicyNumber,
--min(ri.InceptionDate) InceptionDate,
--max(ri.ExpiryDate) ExpiryDate,
--case when ri.RIType = 'FAC' then 'RAD' else pol.rpd_ri_claims_basis end as ClaimsBasis,
--sum(t.cur_amount)  Premium
--FROM fdm.vw_FactFDMExternal t
--JOIN fdm.[DimAccount] acc on (acc.pk_Account = t.fk_Account)
--JOIN fdm.[DimProcess] prc on (prc.pk_Process = t.fk_Process)
--LEFT JOIN fdm.vw_DimRIPolicy ri on (ri.pk_RIPolicy = t.fk_RIPolicy)
--LEFT JOIN fdm.DimTrifocus tf ON (tf.pk_Trifocus = t.fk_TriFocus)
--LEFT JOIN fdm.DimEntity en ON (en.pk_Entity = t.fk_Entity)
--left join FinanceLanding.MDS.ConformedEntityMapping cen on (cen.Entity = en.EntityCode)
--left join FinanceLanding.mds.RITypeMapping ty on (ty.RIPolicyType = ri.RIType)
--left join FinanceLanding.Eurobase.reinsurance_pol_det pol on (pol.rpd_policy_reference = ri.RIPolicyNumber)
--WHERE acc.AccountCode = 'RI00001' 
--and ri.RIAdjustment = 'RISPD'
--and left(convert(varchar, ri.InceptionDate, 112), 6) > t.fk_AccountingPeriod
--and t.fk_YOA <= left(t.fk_AccountingPeriod, 4)
--group by t.fk_AccountingPeriod,
--tf.TrifocusCode, 
--tf.TrifocusName,  
--cen.ConformedEntityMapping,
--t.fk_YOA,
--ri.RIProgramme,
--ty.Confirmed_RIPolicyType,
--t.currency,
--ri.RIPolicyNumber,
--case when ri.RIType = 'FAC' then 'RAD' else pol.rpd_ri_claims_basis end
--) t_unin

--union all

----SPA's
--select
--left(convert(varchar, dateadd(quarter, 1, cast(cast(AccountingPeriod as varchar) + '01' as date)), 112), 6) AccountingPeriod,
--t_spa.TrifocusCode, 
--TrifocusName,  
--en.ConformedEntityMapping as Entity,
--YOA,
--RIProgramme,
--RIType,
--SettlementCCY,
--'NOPOLICY' as RIPolicyNumber,
--cast(YOA + '0101' as date) as InceptionDate,
--cast(YOA + '1231' as date) as ExpiryDate,
--'RAD' as ClaimsBasis,
---sum(sum(Premium)) over (partition by t_spa.TrifocusCode, TrifocusName,
--										en.ConformedEntityMapping,
--										YOA,
--										SettlementCCY,
--										RIProgramme,
--										RIType
--										order by AccountingPeriod ASC) Premium--,
--from
--(
--	select fk_AccountingPeriod AccountingPeriod,
--	tf.TrifocusCode,
--	en.EntityCode Entity,
--	cast(t.fk_YOA as varchar) YOA,
--	t.currency as SettlementCCY,
--	t.cur_amount * cede.Cede Premium,
--	'QS' RIType,
--	'Cede 5623' as RIProgramme
--	FROM fdm.FactFDMExternal_History t
--	JOIN fdm.[DimAccount] acc on (acc.pk_Account = t.fk_Account)
--	JOIN fdm.[DimProcess] prc on (prc.pk_Process = t.fk_Process)
--	JOIN fdm.DimTrifocus tf ON (tf.pk_Trifocus = t.fk_TriFocus)
--	JOIN fdm.DimEntity en ON (en.pk_Entity = t.fk_Entity)
--	left join cte_cede cede on (cede.YOA = cast(t.fk_YOA as varchar) )
--	WHERE 1=1
--	and acc.AccountCode = 'PF00004' 
--	and tf.TrifocusName like 'Tracker%'
--	and tf.TrifocusName <> 'Tracker SL Fronted'
--	and en.EntityCode = '3623'
--	--and isnull(t.cur_amount, 0) <> 0

--	union all

--	select fk_AccountingPeriod AccountingPeriod,
--	tf.TrifocusCode,
--	sp.SyndSplitEntity Entity,
--	cast(t.fk_YOA as varchar) YOA,
--	t.currency as SettlementCCY,
--	t.cur_amount * sp.SyndSplitPercentage [Value],
--	'QS' RIPolicyType,
--	'Cede 6107' as ProgrammeCode
--	FROM fdm.FactFDMExternal_History t
--	JOIN fdm.[DimAccount] acc on (acc.pk_Account = t.fk_Account)
--	JOIN fdm.[DimProcess] prc on (prc.pk_Process = t.fk_Process)
--	JOIN fdm.DimTrifocus tf ON (tf.pk_Trifocus = t.fk_TriFocus)
--	JOIN fdm.DimEntity en ON (en.pk_Entity = t.fk_Entity)
--	join fdm.[SyndicateSplitsbyYOA] sp on (sp.SyndSplitYOA  = cast(t.fk_YOA as varchar))
--	WHERE 1=1
--	and acc.AccountCode = 'PF00004' 
--	and en.EntityCode = '6107'
--	and sp.SyndSplitSource = '2623'
--	--and isnull(t.cur_amount, 0) <> 0
--) t_spa
--join FinanceLanding.fdm.DimTrifocus tf on (tf.TrifocusCode = t_spa.TrifocusCode)
--left join FinanceLanding.MDS.ConformedEntityMapping en on (en.Entity = t_spa.Entity)
--group by AccountingPeriod,
--t_spa.TrifocusCode, 
--TrifocusName, 
--en.ConformedEntityMapping,
--YOA,
--RIProgramme,
--RIType,
--SettlementCCY
--) t_all
--where 1=1
--and AccountingPeriod >= '201812'
--and YOA >= 2016
--),

--cte_gnp as
--(
--select * from
--(
--select
--left(convert(varchar, dateadd(quarter, 1, cast(cast(AccountingPeriod as varchar) + '01' as date)), 112), 6) AccountingPeriod,
--TrifocusCode, 
--TrifocusName,  
--en.ConformedEntityMapping as Entity,
--YOA,
--RIProgramme,
--RIType,
--SettlementCCY,
--sum(sum(isnull(Premium, 0))) over (partition by TrifocusCode, 
--										TrifocusName,
--										en.ConformedEntityMapping,
--										YOA,
--										SettlementCCY,
--										RIProgramme,
--										RIType
--										order by AccountingPeriod ASC) Premium--,
--from
--(
--	select t.fk_AccountingPeriod AccountingPeriod,
--	tf.TrifocusCode, 
--	tf.TrifocusName, 
--	en.EntityCode AS Entity,
--	cast(t.fk_YOA as varchar) YOA,
--	'GROSS' as RIProgramme,
--	'GROSS' as RIType,
--	t.currency AS SettlementCCY,
--	SUM(t.cur_amount) Premium--,
--	--SUM(t.cur_amount) GrossUltimates
--	FROM fdm.FactFDMExternal_History t
--	JOIN fdm.[DimAccount] acc on (acc.pk_Account = t.fk_Account)
--	JOIN fdm.[DimProcess] prc on (prc.pk_Process = t.fk_Process)
--	LEFT JOIN fdm.vw_DimRIPolicy ri on (ri.pk_RIPolicy = t.fk_RIPolicy)
--	LEFT JOIN fdm.DimTrifocus tf ON (tf.pk_Trifocus = t.fk_TriFocus)
--	LEFT JOIN fdm.DimEntity en ON (en.pk_Entity = t.fk_Entity)
--	WHERE acc.AccountCode =  'PF00004' --'RISPD04'
--	--AND prc.ProcessCode = '2B'
--	and t.fk_YOA >= left(t.fk_AccountingPeriod, 4) - 2
--	GROUP BY t.fk_AccountingPeriod,
--	tf.TrifocusCode, 
--	tf.TrifocusName, 
--	en.EntityCode,
--	t.fk_YOA,
--	t.currency
--	having isnull(SUM(t.cur_amount), 0) <> 0

--	union all

--	SELECT d.AccountingPeriod,
--	tf.TrifocusCode, 
--	tf.TrifocusName, 
--	en.EntityCode AS Entity,
--	cast(t.fk_YOA as varchar) YOA,
--	'GROSS',
--	'GROSS',
--	t.currency AS SettlementCCY,
--	sum(0) 
--	FROM fdm.FactFDMExternal_History t
--	JOIN
--	(	
--		SELECT distinct  AccountingPeriod
--		FROM fdm.AccountingPeriod
--		where AccountingPeriod < convert(varchar(6), getdate(), 112)
--		and right(AccountingPeriod, 2) in ('03', '06', '09', '12')
--	)
--	d on (d.AccountingPeriod > t.fk_AccountingPeriod)
--	JOIN fdm.[DimAccount] acc on (acc.pk_Account = t.fk_Account)
--	JOIN fdm.[DimProcess] prc on (prc.pk_Process = t.fk_Process)
--	LEFT JOIN fdm.vw_DimRIPolicy ri on (ri.pk_RIPolicy = t.fk_RIPolicy)
--	LEFT JOIN fdm.DimTrifocus tf ON (tf.pk_Trifocus = t.fk_TriFocus)
--	LEFT JOIN fdm.DimEntity en ON (en.pk_Entity = t.fk_Entity)
--	WHERE acc.AccountCode =  'PF00004' --'RISPD04'
--	--AND prc.ProcessCode = '2B'
--	and t.fk_YOA >= left(t.fk_AccountingPeriod, 4) - 2
--	GROUP BY d.AccountingPeriod,
--	tf.TrifocusCode, 
--	tf.TrifocusName, 
--	en.EntityCode,
--	t.fk_YOA,
--	t.currency
--) t
--left join FinanceLanding.MDS.ConformedEntityMapping en on (en.Entity = t.Entity)
--group by AccountingPeriod,
--TrifocusCode, 
--TrifocusName, 
--en.ConformedEntityMapping,
--YOA,
--RIProgramme,
--RIType,
--SettlementCCY
--) t_all
--where t_all.AccountingPeriod >= '201812'
--and right(t_all.AccountingPeriod, 2) in ('03', '06', '09', '12')
--and t_all.YOA >= 2016
--),


--cte_fx as
--(
--select [fk_AccountingPeriod],
--[fk_TransactionCurrency],
--[FXRate]
--from [fdm].[FactFXRate]
--where fk_FXRate = 2
--and fk_RateScenario = 4
--and fk_ReportingCurrency = 2
--and fk_TransactionCurrency in ('GBP', 'EUR', 'USD', 'CAD')
--and fk_AccountingPeriod between '201812' and left(convert(varchar, getdate(), 112), 6)
--and right(fk_AccountingPeriod, 2) in ('03', '06', '09', '12')
--),

--cte_gnpfx as
--(
--select AccountingPeriod,
--TrifocusCode, 
--TrifocusName,  
--Entity,
--YOA,
--sum(Premium/ fx.FXRate) PremiumUSD
--from cte_gnp gnp
--left join cte_fx fx on 
--(
--fx.fk_AccountingPeriod = gnp.AccountingPeriod
--and fx.fk_TransactionCurrency = gnp.SettlementCCY
--)
--group by AccountingPeriod,
--TrifocusCode, 
--TrifocusName,  
--Entity,
--YOA
--)



				INSERT INTO FinanceLanding.fdm.[RIPercentage]
				(
					 [AccountingPeriod]
					,[TrifocusCode]
					,[TrifocusName]
					,[Entity]
					,[YOA]
					,[YOI]
					,[RIProgramme]
					,[RIType]
					,[SettlementCCY]
					,[RIPolicyNumber]
					,[InceptionDate]
					,[ExpiryDate]
					,[ClaimsBasis]
					,[RIPremium]
					,[GrossNetUltimates]
					,[RI%]
					,[Businesskey]
					,[AuditSourceBatchID]
				    ,[AuditCreateDateTime]
					,[AuditGenerateDateTime]
					,AuditUserCreate
					,AuditHost
				)

             SELECT  AccountingPeriod,
                     TrifocusCode, 
                     TrifocusName,  
                     Entity,
                     YOA,
                     YOI,
			         RIProgramme,
					 RIType,
                     SettlementCCY, 
					 RIPolicyNumber,
					 InceptionDate,
                     ExpiryDate,
					 ClaimsBasis,
					 [RIPremium],
					 [GrossNetUltimates],
					 [RI%],
				     BusinessKey,
					 @v_BatchId,
					 GETDATE(),
					 GETDATE(),
					 suser_sname(),
					 @AuditHost
            FROM    [fdm].[vw_RIPercentage]

				SELECT   @v_AffectedRows			= @@ROWCOUNT;



				SELECT @v_ActivityDateTime			= GETUTCDATE();

				EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
						 @p_ParentActivityLogId
						,@v_ActivityLogTag
						,@v_ActivitySource
						,@v_ActivityType
						,@v_ActivityStatusStop
						,@v_ActivityHost
						,@v_ActivityDatabase
						,@v_ActivityJobId
						,@v_ActivitySSISExecutionId
						,@v_ActivityName
						,@v_ActivityDateTime
						,@v_ActivityMessage
						,@v_ActivityErrorCode
						,@v_AffectedRows
						,@v_ActivityLogIdIn OUTPUT;

				IF @Trancount = 0 AND @@TRANCOUNT <> 0
					COMMIT;
					

			END TRY

			BEGIN CATCH

				-- CANCEL TRAN
				IF @Trancount = 0 AND @@TRANCOUNT <> 0
					ROLLBACK;
			
				-- LOG THE RESULT WITH ERROR

				SELECT   @v_ActivityDateTime				= GETUTCDATE()
						,@v_ActivityLogTag					= @v_ActivityLogIdIn
						,@v_ActivityMessage					= ERROR_MESSAGE()
						,@v_ActivityErrorCode				= ERROR_NUMBER();

				EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
						 @p_ParentActivityLogId
						,@v_ActivityLogTag
						,@v_ActivitySource
						,@v_ActivityType
						,@v_ActivityStatusFail
						,@v_ActivityHost
						,@v_ActivityDatabase
						,@v_ActivityJobId
						,@v_ActivitySSISExecutionId
						,@v_ActivityName
						,@v_ActivityDateTime
						,@v_ActivityMessage
						,@v_ActivityErrorCode
						,@v_AffectedRows
						,@v_ActivityLogIdIn OUTPUT;

				THROW;

			END CATCH;

END;