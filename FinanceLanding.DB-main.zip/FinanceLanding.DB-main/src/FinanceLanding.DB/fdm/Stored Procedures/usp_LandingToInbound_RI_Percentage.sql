﻿CREATE PROCEDURE [fdm].[usp_LandingToInbound_RI_Percentage]
--declare
             @p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL		
AS

-- =============================================

-- Modified by:			Samata.Putumbaka@beazley.com
-- Modification date:	24-03-2021
-- Changes:				Loads RI Percentage data from FinanceLanding to Inbound.RIPercentage
-- Modified by:			
-- Modification date:	
-- Changes:			

-- Modified by:			Nikil.Nallamothu@beazley.com
-- Modification date:	27-01-2023
-- Changes:				Modified the code to load the data from [fdm].[RIPercentage] to Inbound.RIPercentage directly. Done as part of ticket https://beazley.atlassian.net/browse/I1B-3629
-- Modified by:			
-- Modification date:	
-- Changes:	
-- =============================================	
			
BEGIN

		SET NOCOUNT ON;

		DECLARE @Trancount INT= @@Trancount;
		DECLARE @v_ErrorMessage NVARCHAR(4000);

		DECLARE @v_RC							INT;
		DECLARE @v_ActivityLogTag				BIGINT;
		DECLARE @v_ActivitySource				SMALLINT;
		DECLARE @v_ActivityType					SMALLINT;
		DECLARE @v_ActivityStatusStart			SMALLINT;
		DECLARE @v_ActivityStatusStop			SMALLINT;
		DECLARE @v_ActivityStatusFail			SMALLINT;
		DECLARE @v_ActivityHost					VARCHAR(100);
		DECLARE @v_ActivityDatabase				VARCHAR(100);
		DECLARE @v_ActivityName					VARCHAR(100);
		DECLARE @v_ActivityDateTime				DATETIME2(2);
		DECLARE @v_ActivityMessage				NVARCHAR(4000);
		DECLARE @v_ActivityErrorCode			NVARCHAR(50);
		DECLARE @v_ActivityLogIdIn				BIGINT;
		DECLARE @v_ActivityLogIdOut				BIGINT;
		DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId;
		DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
		DECLARE @v_AffectedRows					INT				= 0;
		DECLARE @v_DataSet						VARCHAR(50)	= 'RIPercentage'

		-- for debugging. set to 1 & the no records will be written to the inbound tables.
		declare @stop bit = 0


		SELECT @v_ActivityStatusStart = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'STARTED';

		SELECT @v_ActivityStatusStop = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'SUCCEEDED';

		SELECT @v_ActivityStatusFail = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'ERRORED';

		DECLARE @v_BatchId INT;
		--DECLARE @v_BatchId_Extensions INT;
		
  
		/* Log the start of the insert */

		BEGIN TRY

				SELECT   
					 @v_ActivityLogTag		        = NULL
					,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
					,@v_ActivityType				= (SELECT PK_ActivityType	
														FROM Orchestram.Log.ActivityType	
														WHERE ActivityType = CASE 
																				WHEN @p_ParentActivityLogId IS NULL 
																					THEN 'Manual process' 
																					ELSE 'Automated process' 
																				END)
					,@v_ActivityHost				= @@SERVERNAME
					,@v_ActivityName				= 'Load percentages for re-insurance data into Inbound.RIPercentage'
					,@v_ActivityDatabase			= 'FinanceLanding'
					,@v_ActivityDateTime			= GETUTCDATE()
					,@v_ActivityMessage				= NULL
					,@v_ActivityErrorCode			= NULL;

				EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
							 @p_ParentActivityLogId
							,@v_ActivityLogTag
							,@v_ActivitySource
							,@v_ActivityType
							,@v_ActivityStatusStart
							,@v_ActivityHost
							,@v_ActivityDatabase
							,@v_ActivityJobId
							,@v_ActivitySSISExecutionId
							,@v_ActivityName
							,@v_ActivityDateTime
							,@v_ActivityMessage
							,@v_ActivityErrorCode
							,@v_AffectedRows
							,@v_ActivityLogIdIn OUTPUT;

				SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

				--------------------------------------------------

				--------------------------------------------------------------------
				/*=============================================================================================
         				Commented out the code , Done as part of ticket https://beazley.atlassian.net/browse/I1B-3629
					==============================================================================================
				if object_id('tempdb..#Outbound') is not null drop table #Outbound
				select 
					t.*
				into 
					#Outbound
				from 
					FinanceDataContract.Outbound.RIPercentage t
				where
					t.RowIsLatest = 1 -- we're only interested in the latest to test for changes.


				if object_id('tempdb..#Inbound') is not null drop table #Inbound
				-- do the inserts then updates and then union with the deletes
				select 
					 s.[AccountingPeriod]
					,s.[TrifocusCode]
					,s.[TrifocusName]
					,s.[Entity]
					,s.[YOA]
					,s.[YOI]
					,s.[RIProgramme]
					,s.[RIType]
					,s.[SettlementCCY]
					,s.[RIPolicyNumber]
					,s.[InceptionDate]
					,s.[ExpiryDate]
					,s.[ClaimsBasis]
					,s.[RIPremium]
					,s.[GrossNetUltimates]
					,s.[RI%]
					,s.[Businesskey]
					,[AuditAction] = case when o.BusinessKey IS NULL then 'I' else 'U' end
					,s.RowHash	
					,[RowVersionNumber] = ISNULL(o.RowVersionNumber,0) + 1
				into
					#Inbound
				from
					(
						select 
							   [AccountingPeriod]
							  ,[TrifocusCode]
							  ,[TrifocusName]
							  ,[Entity]
							  ,[YOA]
							  ,[YOI]
							  ,[RIProgramme]
							  ,[RIType]
							  ,[SettlementCCY]
							  ,[RIPolicyNumber]
							  ,[InceptionDate]
							  ,[ExpiryDate]
							  ,[ClaimsBasis]
							  ,[RIPremium]
							  ,[GrossNetUltimates]
							  ,[RI%]
							  ,[BusinessKey]
													 
								,RowHash				= HASHBYTES('SHA2_512',
																CONCAT(	 ISNULL(CONVERT(VARCHAR(10),[AccountingPeriod]),'')  									,'§~§'
																		,ISNULL([TrifocusCode],'')  															,'§~§'
																		,ISNULL([TrifocusName],'')  															,'§~§'
																		,ISNULL([Entity],'')  																	,'§~§'
																		,ISNULL(CONVERT(VARCHAR(4),YOA),'')  													,'§~§'
																		,ISNULL(CONVERT(VARCHAR(4),YOI),'')  													,'§~§'
																		,ISNULL([RIProgramme],'') 																,'§~§'
																		,ISNULL([RIType],'')  																	,'§~§'
																		,ISNULL([SettlementCCY],'')  															,'§~§'
																		,ISNULL([RIPolicyNumber],'')  															,'§~§'
																		,ISNULL(CONVERT(VARCHAR(10),[InceptionDate],102),'')									,'§~§'
																		,ISNULL(CONVERT(VARCHAR(10),[ExpiryDate],102),'')										,'§~§'
																		,ISNULL([ClaimsBasis],'')																,'§~§'    
																		,ISNULL(CONVERT(VARCHAR(30),CONVERT(numeric(19,6),[RIPremium])),'')						,'§~§'
																		,ISNULL(CONVERT(VARCHAR(30),[GrossNetUltimates]),'')									,'§~§'
																		,ISNULL(CONVERT(VARCHAR(30),CONVERT(numeric(19,6),[RI%])),'')							,'§~§'
																		)
																	)
							from [fdm].[RIPercentage] ) s
						left join #Outbound o on o.BusinessKey = s.BusinessKey
				where
					o.BusinessKey is null
					or o.RowHash <> s.RowHash

				union all

				select 
					s.[AccountingPeriod]
				   ,s.[TrifocusCode]
				   ,s.[TrifocusName]
				   ,s.[Entity]
				   ,s.[YOA]
				   ,s.[YOI]
				   ,s.[RIProgramme]
				   ,s.[RIType]
				   ,s.[SettlementCCY]
				   ,s.[RIPolicyNumber]
				   ,s.[InceptionDate]
				   ,s.[ExpiryDate]
				   ,s.[ClaimsBasis]
				   ,s.[RIPremium]
				   ,s.[GrossNetUltimates]
				   ,s.[RI%]
				   ,s.[BusinessKey]
				   ,[AuditAction] = 'D' 
				   ,s.RowHash	
				   ,[RowVersionNumber] = s.RowVersionNumber + 1
				from 
					#Outbound s
					left join [fdm].[RIPercentage] o on o.BusinessKey = s.BusinessKey
				where
					s.AuditAction <> 'D'
					and o.BusinessKey is null


				--RETURN -- gets here in 

			*/

					-------------------------------------------------------------------------

				if @stop = 1 return

				------/* Delete the current lines from Inbound ... */

				truncate table [FinanceDataContract].[Inbound].RIPercentage					
				
				--If no new data, then log and exit
/*
				IF NOT EXISTS (SELECT TOP 1 1 FROM #Inbound)
				BEGIN

					SELECT	  @v_ActivityDateTime			= GETUTCDATE()
							, @v_AffectedRows				= 0;

					EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
								 @p_ParentActivityLogId
								,@v_ActivityLogTag
								,@v_ActivitySource
								,@v_ActivityType
								,@v_ActivityStatusStop
								,@v_ActivityHost
								,@v_ActivityDatabase
								,@v_ActivityJobId
								,@v_ActivitySSISExecutionId
								,@v_ActivityName
								,@v_ActivityDateTime
								,@v_ActivityMessage
								,@v_ActivityErrorCode
								,@v_AffectedRows
								,@v_ActivityLogIdIn OUTPUT;	

					RETURN;
				END;

*/

				IF @Trancount = 0
					BEGIN TRAN;

					-- select * from [dbo].[Batch]
				INSERT INTO [dbo].[Batch]
					([CreateDate],[DataSet],[LatestBusinesKey]) 
				VALUES  
					(GETDATE(),@v_DataSet, NULL);

				SELECT @v_BatchId = SCOPE_IDENTITY();

				/*Done as part of the ticket https://beazley.atlassian.net/browse/I1B-3629 */
				INSERT INTO [FinanceDataContract].[Inbound].[RIPercentage]
				(
					 [AccountingPeriod]
					,[TrifocusCode]
					,[TrifocusName]
					,[Entity]
					,[YOA]
					,[YOI]
					,[RIProgramme]
					,[RIType]
					,[SettlementCCY]
					,[RIPolicyNumber]
					,[InceptionDate]
					,[ExpiryDate]
					,[ClaimsBasis]
					,[RIPremium]
					,[GrossNetUltimates]
					,[RI%]
					,[Businesskey]
					,[AuditAction]
					,[RowHash]
					,[RowVersionNumber]
					,[FK_Batch]
				)
				Select 
							   [AccountingPeriod]
							  ,[TrifocusCode]
							  ,[TrifocusName]
							  ,[Entity]
							  ,[YOA]
							  ,[YOI]
							  ,[RIProgramme]
							  ,[RIType]
							  ,[SettlementCCY]
							  ,[RIPolicyNumber]
							  ,[InceptionDate]
							  ,[ExpiryDate]
							  ,[ClaimsBasis]							  							  
							  ,[RIPremium]
							  ,[GrossNetUltimates]
							  ,[RI%]
							  ,[BusinessKey]
							  ,[AuditAction]='I'				 
							  ,RowHash				= HASHBYTES('SHA2_512',
																CONCAT(	 ISNULL(CONVERT(VARCHAR(10),[AccountingPeriod]),'')  									,'§~§'
																		,ISNULL([TrifocusCode],'')  															,'§~§'
																		,ISNULL([TrifocusName],'')  															,'§~§'
																		,ISNULL([Entity],'')  																	,'§~§'
																		,ISNULL(CONVERT(VARCHAR(4),YOA),'')  													,'§~§'
																		,ISNULL(CONVERT(VARCHAR(4),YOI),'')  													,'§~§'
																		,ISNULL([RIProgramme],'') 																,'§~§'
																		,ISNULL([RIType],'')  																	,'§~§'
																		,ISNULL([SettlementCCY],'')  															,'§~§'
																		,ISNULL([RIPolicyNumber],'')  															,'§~§'
																		,ISNULL(CONVERT(VARCHAR(10),[InceptionDate],102),'')									,'§~§'
																		,ISNULL(CONVERT(VARCHAR(10),[ExpiryDate],102),'')										,'§~§'
																		,ISNULL([ClaimsBasis],'')																,'§~§'    
																		,ISNULL(CONVERT(VARCHAR(30),CONVERT(numeric(19,6),[RIPremium])),'')						,'§~§'
																		,ISNULL(CONVERT(VARCHAR(30),[GrossNetUltimates]),'')									,'§~§'
																		,ISNULL(CONVERT(VARCHAR(30),CONVERT(numeric(19,6),[RI%])),'')							,'§~§'
																		)
																	)
							,[RowVersionNumber]=1
							,[FK_Batch]=@v_BatchId
							from [fdm].[RIPercentage] 

				SELECT   @v_AffectedRows			= @@ROWCOUNT;



				--/* Add the batchs to the queue */
				---- select top 100 * from [FinanceDataContract].[Inbound].[BatchQueue]  order by 1 desc
				INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,RunDescription
								,[DataSet]
								,OriginalName
								,AuditSourceBatchID
								)
				VALUES
								( @v_BatchId
								 ,'InBound'
								 ,NULL
								 ,@v_DataSet
								 ,NULL
								 ,NULL
								)								

				-- LOG THE RESULT WITH SUCCESS

				SELECT @v_ActivityDateTime			= GETUTCDATE();

				EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
						 @p_ParentActivityLogId
						,@v_ActivityLogTag
						,@v_ActivitySource
						,@v_ActivityType
						,@v_ActivityStatusStop
						,@v_ActivityHost
						,@v_ActivityDatabase
						,@v_ActivityJobId
						,@v_ActivitySSISExecutionId
						,@v_ActivityName
						,@v_ActivityDateTime
						,@v_ActivityMessage
						,@v_ActivityErrorCode
						,@v_AffectedRows
						,@v_ActivityLogIdIn OUTPUT;

				IF @Trancount = 0 AND @@TRANCOUNT <> 0
					COMMIT;
					

			END TRY

			BEGIN CATCH

				-- CANCEL TRAN
				IF @Trancount = 0 AND @@TRANCOUNT <> 0
					ROLLBACK;
			
				-- LOG THE RESULT WITH ERROR

				SELECT   @v_ActivityDateTime				= GETUTCDATE()
						,@v_ActivityLogTag					= @v_ActivityLogIdIn
						,@v_ActivityMessage					= ERROR_MESSAGE()
						,@v_ActivityErrorCode				= ERROR_NUMBER();

				EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
						 @p_ParentActivityLogId
						,@v_ActivityLogTag
						,@v_ActivitySource
						,@v_ActivityType
						,@v_ActivityStatusFail
						,@v_ActivityHost
						,@v_ActivityDatabase
						,@v_ActivityJobId
						,@v_ActivitySSISExecutionId
						,@v_ActivityName
						,@v_ActivityDateTime
						,@v_ActivityMessage
						,@v_ActivityErrorCode
						,@v_AffectedRows
						,@v_ActivityLogIdIn OUTPUT;

				THROW;

			END CATCH;

END;
GO


