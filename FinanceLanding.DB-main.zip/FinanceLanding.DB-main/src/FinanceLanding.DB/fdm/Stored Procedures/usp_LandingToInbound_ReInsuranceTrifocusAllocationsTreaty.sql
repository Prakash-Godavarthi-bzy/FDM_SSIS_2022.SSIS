﻿CREATE PROCEDURE fdm.[usp_LandingToInbound_ReInsuranceTrifocusAllocationsTreaty]

             @p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL

AS
-- =============================================

-- LastModified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 09/08/2021
-- Description:	Original version. Loads the table [Inbound].[ReInsuranceTrifocusAllocationsTreaty] with the current values.
--				

-- =============================================		
BEGIN

		SET NOCOUNT ON

		DECLARE @v_ErrorMessage NVARCHAR(4000)
		DECLARE @Trancount	INT = @@Trancount
		DECLARE @v_RC							INT
		DECLARE @v_ActivityLogTag				BIGINT
		DECLARE @v_ActivitySource				SMALLINT
		DECLARE @v_ActivityType					SMALLINT
		DECLARE @v_ActivityStatusStart			SMALLINT
		DECLARE @v_ActivityStatusStop			SMALLINT
		DECLARE @v_ActivityStatusFail			SMALLINT
		DECLARE @v_ActivityHost					VARCHAR(100)
		DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'ReInsuranceTrifocusAllocationsTreaty'
		DECLARE @v_ActivityName					VARCHAR(100)
		DECLARE @v_ActivityDateTime				DATETIME2(2)
		DECLARE @v_ActivityMessage				NVARCHAR(4000)
		DECLARE @v_ActivityErrorCode			NVARCHAR(50)
		DECLARE @v_ActivityLogIdIn				BIGINT
		DECLARE @v_ActivityLogIdOut				BIGINT
		DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId
		DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL
		DECLARE @v_AffectedRows					INT             = 0
		DECLARE @v_BatchId                      INT             = NULL
		DECLARE @v_Asat                         INT             = NULL

		DECLARE @v_MaxAuditGenerateDate         DATETIME2       = NULL
		DECLARE @v_AuditConcat                  NVARCHAR(4000)
		declare @DataSet varchar(50) = @v_ActivityDatabase

		 
  BEGIN TRY	
		-- Set the login variables needed for logging

		SELECT   
		    @v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
		   ,@v_ActivityType				    = (SELECT PK_ActivityType	
											   FROM Orchestram.Log.ActivityType	
											   WHERE ActivityType = CASE 
																	WHEN @p_ParentActivityLogId IS NULL 
																		THEN 'Manual process' 
																		ELSE 'Automated process' 
																	END)
		   ,@v_ActivityHost				    = @@SERVERNAME
		   ,@v_ActivityName				    = 'Load data into Inbound.ReInsuranceTrifocusAllocationsTreaty'
		   ,@v_ActivityDateTime			    = GETUTCDATE()

		SELECT @v_ActivityStatusStart = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'STARTED'

		SELECT @v_ActivityStatusStop = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'SUCCEEDED'

		SELECT @v_ActivityStatusFail = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'ERRORED'



		if object_id('tempdb..#ReInsuranceTrifocusAllocationsTreaty') is not null drop table #ReInsuranceTrifocusAllocationsTreaty;
		SELECT 
			[EntityCode]
			,[EntityName]
			,[AccountCode]
			,[AccountingPeriod]
			,[RIPolicyNumber]
			,[YOA]
			,[RIType]
			,[RIProgramme]
			,[TrifocusCode]
			,[TrifocusName]
			,[SettlementCurrency]
			,[Amount]
			,[TotalAmount]
			,[Allocation]
		INTO
			#ReInsuranceTrifocusAllocationsTreaty
		FROM 
			FinanceLanding.fdm.vw_ReInsuranceAllocations


		/* Log the start of the insert */

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStart
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT

		SELECT @v_ActivityLogTag = @v_ActivityLogIdIn


		IF NOT EXISTS (SELECT 1 FROM #ReInsuranceTrifocusAllocationsTreaty)

		BEGIN
			
			select 'no data, will exit'

			-- LOGIN THE RESULT WITH SUCCESS
				SELECT @v_ActivityDateTime			= GETUTCDATE()

				EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
						@p_ParentActivityLogId
						,@v_ActivityLogTag
						,@v_ActivitySource
						,@v_ActivityType
						,@v_ActivityStatusStop
						,@v_ActivityHost
						,@v_ActivityDatabase
						,@v_ActivityJobId
						,@v_ActivitySSISExecutionId
						,@v_ActivityName
						,@v_ActivityDateTime
						,@v_ActivityMessage
						,@v_ActivityErrorCode
						,@v_AffectedRows
						,@v_ActivityLogIdIn OUTPUT

			RETURN
		END

		/* Insert a new batch for DFMS_all datasource table*/
		INSERT INTO [dbo].[Batch]
			([CreateDate],[DataSet]) 

		VALUES  
			(GETDATE(),@DataSet)
	
		SELECT @v_BatchId = SCOPE_IDENTITY()
		
		 
			IF @Trancount = 0 

				BEGIN TRAN;

				/* Delete the current lines from Inbound ... */

				truncate table FinanceDataContract.[Inbound].ReInsuranceTrifocusAllocationsTreaty

				INSERT INTO FinanceDataContract.[Inbound].[ReInsuranceTrifocusAllocationsTreaty] WITH(TABLOCK)
				(
					[EntityCode]
					,[EntityName]
					,[AccountCode]
					,[AccountingPeriod]
					,[RIPolicyNumber]
					,[YOA]
					,[RIType]
					,[RIProgramme]
					,[TrifocusCode]
					,[TrifocusName]
					,[SettlementCurrency]
					,[Amount]
					,[TotalAmount]
					,[Allocation]
					,[FK_Batch]
					,[DataSet]
				)

				SELECT   
					[EntityCode]
					,[EntityName]
					,[AccountCode]
					,[AccountingPeriod]
					,[RIPolicyNumber]
					,[YOA]
					,[RIType]
					,[RIProgramme]
					,[TrifocusCode]
					,[TrifocusName]
					,[SettlementCurrency]
					,[Amount]
					,[TotalAmount]
					,[Allocation]
					,[FK_Batch] = @v_BatchId
					,[DataSet] = @DataSet
				FROM    
					#ReInsuranceTrifocusAllocationsTreaty

				SELECT   @v_AffectedRows			= @@ROWCOUNT
	
				/* Add the batch to the queue */

				INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
							( Pk_Batch
							,[Status]
							,DataSet
							,RunDescription
							,OriginalName
							)
				VALUES
							(@v_BatchId
							,'InBound'
							,@DataSet
							,@DataSet
							,NULL
							);
      
				-- LOGIN THE RESULT WITH SUCCESS
				SELECT @v_ActivityDateTime			= GETUTCDATE()

				EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
						@p_ParentActivityLogId
						,@v_ActivityLogTag
						,@v_ActivitySource
						,@v_ActivityType
						,@v_ActivityStatusStop
						,@v_ActivityHost
						,@v_ActivityDatabase
						,@v_ActivityJobId
						,@v_ActivitySSISExecutionId
						,@v_ActivityName
						,@v_ActivityDateTime
						,@v_ActivityMessage
						,@v_ActivityErrorCode
						,@v_AffectedRows
						,@v_ActivityLogIdIn OUTPUT

            IF @Trancount = 0 

				COMMIT;

			END TRY

			BEGIN CATCH
	
		    -- CANCEL TRAN
			IF @Trancount = 0 AND @@TRANCOUNT <> 0
				ROLLBACK;
			        
				-- LOGIN THE RESULT WITH ERROR

				SELECT   @v_ActivityDateTime				= GETUTCDATE()
						,@v_ActivityLogTag					= @v_ActivityLogIdIn
						,@v_ActivityMessage					= ERROR_MESSAGE()
						,@v_ActivityErrorCode				= ERROR_NUMBER()

				EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
						 @p_ParentActivityLogId
						,@v_ActivityLogTag
						,@v_ActivitySource
						,@v_ActivityType
						,@v_ActivityStatusFail
						,@v_ActivityHost
						,@v_ActivityDatabase
						,@v_ActivityJobId
						,@v_ActivitySSISExecutionId
						,@v_ActivityName
						,@v_ActivityDateTime
						,@v_ActivityMessage
						,@v_ActivityErrorCode
						,@v_AffectedRows
						,@v_ActivityLogIdIn OUTPUT;

            THROW;

			END CATCH

					
END

