﻿CREATE PROCEDURE [fdm].[usp_LandingToInbound_RI_Reinstatement_Premium_Earned]
			@p_AccountingPeriod			INT
			,@p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL

AS
-- =============================================

-- LastModified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 21/07/2021
-- Description:	Original version. Gets Earned_RIP_RISpend and pushes it into Inbound.Transaction.
--				
-- LastModified by Author:		Siddharth Atla <siddharth.atla@beazley.com>
-- Modified date: 12/10/2021
-- Description:	Added the paramter @p_AccountingPeriod so it is called by another procedure to cycle through all the periods/quarters and catch up or do all available periods in the case of day one.
--				Removed DateOfFact from the business key so the outbound process can use the rowhash column to detect changes and make adjustments accordingly.
--				
-- LastModified by Author:		Siddharth Atla <siddharth.atla@beazley.com>
-- Modified date: 12/10/2021
-- Description:	Modified to do reversals correctly & use dbo.fn_RowHashForTransactions for the RowHash
--				
-- LastModified by Author:		Shah Nawaz Ahmed <shahnawaz.ahmed@beazley.com>
-- Modified date: 06/06/2024
-- Description:	I1B-5448 -Added union all to fetch data from landing table cededre.RISpendBESI_EarnedRIPs(from file for BESI Trifocus)

-- LastModified by Author:		Shah Nawaz Ahmed <shahnawaz.ahmed@beazley.com>
-- Modified date: 24/07/2024
-- Description:	https://beazley.atlassian.net/browse/I1B-5692 RI Spend Programme Conforming, created a left join to get ProgrammeCode.

-- LastModified by Author:		Shah Nawaz Ahmed <shahnawaz.ahmed@beazley.com>
-- Modified date: 24/07/2024
-- Description:	https://beazley.atlassian.net/browse/I1B-5735 replaced [fdm].[DimRIPolicy] with [fdm].[vw_DimRIPolicy]

-- =============================================	
BEGIN

	SET NOCOUNT ON;
	
	
	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'Earned_RIP_RISpend';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	DECLARE @ContractType					CHAR(3)			= 'RIP'

	DECLARE @v_Dataset varchar(50)=@v_ActivityDatabase
	DECLARE @v_BatchId                   INT             = NULL;
	DECLARE @v_BatchId_Extensions INT;

BEGIN TRY

	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';


	/* Insert a new batch for Earned_RIP_RISpend datasource table*/
	INSERT INTO [dbo].[Batch]([CreateDate],[DataSet],[LatestBusinesKey]) 
	VALUES  (GETDATE(),@v_Dataset,@p_AccountingPeriod);

	SELECT @v_BatchId = SCOPE_IDENTITY();

	/* Log the start of the insert */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'Load data into Inbound.Transaction'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'Load data into Inbound.Transaction for Re-Insurance Earned_RIP_RISpend'
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;


	-- constants for constant values.
	declare 
		@Scenario char(1)				='A'
		,@Basis char(1)					= 'E'
		,@DefaultDate date				= CAST('01-01-1980' as date)
		,@TypeOfBusiness char(1)		= '-'
		,@Location char(1)				= '-'
		,@IsToDate char(1)				= 'Y'
		,@BusinessProcessCode char(2)	= 'T1'
		,@AuditHost varchar(255)		= CAST(SERVERPROPERTY('MachineName') as varchar(255))
		,@StatsCode varchar(25)			= null
		,@DateOfFact date				= DATEADD(QUARTER,1,convert(date,convert(char(8),@p_AccountingPeriod * 100 + 1),112))


	--temporary table for the insert (willbe used to calculate RowHash values before pushing data in the IDC transaction table

	DROP TABLE IF EXISTS #TempInboundTransaction;

    /* Insert the new records from ADM sources in the temp table */
	SELECT 
		DateOfFact,
		Account,
		BusinessKey,
		PolicyNumber ,
		InceptionDate,
		ExpiryDate ,
		TrifocusCode ,
		Entity,
		YOA,
		SettlementCCY,
		fk_AccountingPeriod,
		RIPolicyType,
		ProgrammeCode,
		[Value] = sum([Value]),
		RowHash = dbo.fn_RowHashForTransactions
		(
			'T'							-- <@RowHashType, char(1),>
			,@Scenario					--,<@Scenario, nvarchar(2000),>
			,[Account]					--,<@Account, nvarchar(2000),>
			,@v_Dataset					--,<@DataSet, nvarchar(2000),>
			,[BusinessKey]				--,<@BusinessKey, nvarchar(2000),>
			,[PolicyNumber]				--,<@PolicyNumber, nvarchar(2000),>
			,[InceptionDate]			--,<@InceptionDate, date,>
			,[ExpiryDate]				--,<@ExpiryDate, date,>
			,@DefaultDate				--,<@BindDate, date,>
			,@DefaultDate				--,<@DueDate, date,>
			,[TrifocusCode]				--,<@TrifocusCode, nvarchar(2000),>
			,[Entity]					--,<@Entity, nvarchar(2000),>
			,[YOA]						--,<@YOA, nvarchar(2000),>
			,@TypeOfBusiness			--,<@TypeOfBusiness, nvarchar(2000),>
			,@StatsCode					--,<@StatsCode, nvarchar(2000),>
			,[SettlementCCY]			--,<@SettlementCCY, nvarchar(2000),>
			,[SettlementCCY]			--,<@OriginalCCY, nvarchar(2000),>
			,@IsToDate					--,<@IsToDate, nvarchar(2000),>
			,@Basis						--,<@Basis, nvarchar(2000),>
			,@Location					--,<@Location, nvarchar(2000),>
			,@BusinessProcessCode		--,<@BusinessProcessCode, nvarchar(2000),>
			,null						--,<@BoundDate, date,>
			,CONCAT
			(
				 case when RIPolicyType is null then '' else (RIPolicyType + '§~§') end
				,case when ProgrammeCode is null then '' else (ProgrammeCode + '§~§') end
			)
		)
	INTO 
		#TempInboundTransaction
	FROM
	(
		SELECT 
			DATEADD(QUARTER,1,t.DateOfFact) AS DateOfFact,
			t.Account,
			BusinessKey = 
				rtrim(ltrim(ISNULL(t.Account, '')				)) + '|' + 
				rtrim(ltrim(ISNULL(t.ProgrammeCode, '')		)) + '|' + 
				rtrim(ltrim(ISNULL(t.RIPolicyType, '')		)) + '|' + 
				rtrim(ltrim(ISNULL(t.Entity, '')				)) + '|' +
				rtrim(ltrim(ISNULL(CAST(t.YOA AS VARCHAR(50)), '')	)) + '|' +
				rtrim(ltrim(ISNULL(t.SettlementCCY, '')			)) + '|' +
				rtrim(ltrim(ISNULL(t.Trifocus, '')				)) ,
			PolicyNumber = t.RIPolicyNumber,
			InceptionDate = min( t.RIInceptionDate ),
			ExpiryDate = max(t.RIExpiryDate),
			TrifocusCode = t.TriFocus,
			t.Entity,
			t.YOA,
			t.SettlementCCY,
			t.fk_AccountingPeriod,
			t.RIPolicyType,
			t.ProgrammeCode,
			t.RIAdjustment,
			[Value] = CASE 
						WHEN Entity = '8044' THEN SUM(t.Value)
						ELSE
						SUM(SUM(t.[Value])) 
						OVER
						(
							PARTITION BY 
								Account,
							--	RIPolicyNumber,
							--RIInceptionDate,
							--RIExpiryDate,
								TriFocus,
								RIPolicyType,
								ProgrammeCode,
								Entity,
								YOA,
								SettlementCCY
							ORDER BY 
								fk_AccountingPeriod ASC
						)
					END
		FROM
		(
			SELECT DISTINCT
			    DateOfFact = convert (DATE, concat (case when fk_AccountingPeriod <= 201809 then 201809 else fk_AccountingPeriod end,'01'), 102),
				Account = 'RP-ULT-R-' + CASE WHEN ri.RIType = 'FAC' THEN 'FAC' ELSE 'TTY' END ,
				RIPolicyNumber = rtrim(ri.RIPolicyNumber),
				RIInceptionDate = ri.InceptionDate , 
				RIExpiryDate = ri.ExpiryDate , 
				TriFocus = tf.TrifocusCode , 
				TriFocusName = tf.TrifocusName ,
				ProgrammeCode = ri.RIProgramme ,
				Entity = en.EntityCode ,
				YOA = t.fk_YOA ,
				SettlementCCY = t.currency ,
				[Value] = t.cur_amount ,
				case when fk_AccountingPeriod <= 201809 then 201809 else fk_AccountingPeriod end as FK_AccountingPeriod,
				ri.RIType AS RIPolicyType,
			    ri.RIAdjustment
			FROM 
				[fdm].[vw_FactFDMExternal] t
				JOIN (SELECT DISTINCT * FROM [fdm].[DimAccount]) acc on acc.pk_Account = t.fk_Account
				LEFT JOIN [fdm].[vw_DimRIPolicy] ri on ri.pk_RIPolicy = t.fk_RIPolicy		
				LEFT JOIN [fdm].[DimTrifocus] tf on tf.pk_Trifocus = t.fk_TriFocus
				LEFT JOIN [fdm].[DimEntity] en on en.pk_Entity = t.fk_Entity
			WHERE
				acc.AccountCode = 'RI00001'
				and  ri.RIAdjustment = 'Reinsts' 

				UNION ALL
				
				SELECT DateOfFact = convert (DATE, concat (t.AccountingPeriod,'01'), 102),
				Account = 'RP-ULT-R-' + CASE WHEN rt.Confirmed_RIPolicyType = 'FAC' THEN 'FAC' ELSE 'TTY' END ,
				RIPolicyNumber = rtrim(t.RIRef),
				RIInceptionDate = t.InceptionDate ,
				RIExpiryDate = t.ExpiryDate ,
				TriFocus = tf.TrifocusCode ,
				TriFocusName = tf.TrifocusName ,
				ProgrammeCode   = isnull(tty.ProgrammeCode, LTRIM(RTRIM(isnull(prg.ConformedProgrammeMapping, t.Programme)))) , --ProgrammeCode = t.Programme ,
				Entity = '8044' ,
				YOA,
				SettlementCCY = t.CCY ,
				[Value],
				t.AccountingPeriod ,
				rt.Confirmed_RIPolicyType AS RIPolicyType,
			    'Reinsts' as RIAdjustment
				from [cededre].[RISpendBESI_EarnedRIPs] t
				left join fdm.DimTrifocus tf on (tf.TrifocusName = t.Trifocus)
				left join Eurobase.vw_ReInsuranceTreatyContractAttributes tty on (tty.RI_Section_Reference = t.RIRef)
				left join [mds].[RITypeMapping] rt on (rt.RIPolicyType = t.Type2)
				left join [MDS].[ConformedProgrammeMapping] prg  ON	(prg.ProgrammeCode = t.Programme)
		) t	
		GROUP BY 
			t.Account,
			t.RIPolicyNumber,
			t.TriFocus,
			t.ProgrammeCode,
			t.RIPolicyType,
			t.Entity,
			t.YOA,
			t.SettlementCCY,
			t.FK_AccountingPeriod,
			t.DateOfFact,
			t.RIAdjustment
	) src1
	WHERE
		src1.fk_AccountingPeriod = @p_AccountingPeriod
		-- debug code
		--and src1.BusinessKey = 'P-RP-P-TTY|CLASHBUDGET|2019|USD|2623|697'
	GROUP BY 
		Account,
		BusinessKey,
		PolicyNumber ,
		InceptionDate  ,
		ExpiryDate  ,
		TrifocusCode ,
		Entity,
		YOA,
		SettlementCCY,
		fk_AccountingPeriod,
		RIPolicyType,
		ProgrammeCode,
		DateOfFact


	SELECT   @v_AffectedRows			= @@ROWCOUNT;
	print convert(varchar,@v_AffectedRows) + ' records in #TempInboundTransaction for ' + convert(varchar,@p_AccountingPeriod)

	if object_id('tempdb..#Outbound') is not null drop table #Outbound
				select 
					t.*
					-- extensions
					,e.ProgrammeCode
					,e.RIPolicyType
				into 
					#Outbound
				from 
					FinanceDataContract.Outbound.[Transaction] t
					join FinanceDataContract.Outbound.Transaction_Reinsurance_Extensions_Bridge b on b.RowHash_Transaction = t.RowHash
					join FinanceDataContract.Outbound.Transaction_Reinsurance_Extensions e on e.RowHash_Transaction_Reinsurance_Extensions = b.RowHash_Transaction_Reinsurance_Extensions
				where 
					t.DataSet = @v_DataSet


	-- now I need to do the Reversals.
	-- I get the data from the outbound grouped by the rowhash & check to see that we don't have a related inbound record. These are missing and need to be zero'ed for the current period.
	DROP TABLE IF EXISTS #TempOutboundTransaction;

	SELECT 
		 tot.Account             
		,tot.BusinessKey        
		,tot.PolicyNumber
		,tot.InceptionDate 
		,tot.ExpiryDate 
		,tot.TrifocusCode        
		,tot.Entity              
		,tot.YOA                 
		,tot.SettlementCCY       
		,[FK_Batch]          = MAX(tot.[FK_Batch])
		,tot.RowHash
		,tot.RIPolicyType
		,tot.ProgrammeCode
	INTO 
		#TempOutboundTransaction 
	FROM        
		#Outbound tot
		left join #TempInboundTransaction tite on tot.RowHash = tite.RowHash
	WHERE
		tite.RowHash is null
		and tot.Dataset = @v_Dataset
		and exists(select top 1 1 from #TempInboundTransaction) -- if we have nothing for this period, we don't want to reverse all the data out. This is not likely to happen in production - but in dev & test.
	GROUP BY  
		 tot.Account             
		,tot.BusinessKey        
		,tot.PolicyNumber
		,tot.InceptionDate 
		,tot.ExpiryDate 
		,tot.TrifocusCode        
		,tot.Entity              
		,tot.YOA                 
		,tot.SettlementCCY       
		,tot.RowHash
		,tot.RIPolicyType
		,tot.ProgrammeCode
	HAVING
		SUM(tot.[Value]) <> 0

	SELECT   @v_AffectedRows			= @@ROWCOUNT;
	print convert(varchar,@v_AffectedRows) + ' records in #TempOutboundTransaction for ' + convert(varchar,@p_AccountingPeriod)

		
	---DROP TABLE #transactions_final_agg_cs

	if object_id('tempdb..#transactions_final_agg_cs') is not null drop table #transactions_final_agg_cs

				--return -- gets here in 
				-- create the rowhash for the extensions.
				select DISTINCT
				    t.DateOfFact,
					t.Account,
					t.BusinessKey,
					t.PolicyNumber ,
					t.InceptionDate,
					t.ExpiryDate ,
					t.TrifocusCode ,
					t.Entity,
					t.YOA,
					t.SettlementCCY,
					[Value] = t.[Value],
					t.RIPolicyType,
					ProgrammeCode = t.ProgrammeCode,
					t.RowHash,
					[RowHash_Transaction_ReInsurance_Extensions] = dbo.fn_RowHashForTransactions
		(
			'E' /* @RowHashType */
			,@Scenario,t.Account,@v_Dataset,t.BusinessKey,t.PolicyNumber,t.InceptionDate,t.ExpiryDate,@DefaultDate,@DefaultDate,t.TrifocusCode,t.Entity,t.YOA,@TypeOfBusiness,@StatsCode,t.SettlementCCY,t.SettlementCCY,@IsToDate,@Basis,@Location
			,null /* @BusinessProcessCode */
			,null /* @BoundDate */
			-- extended columns
			,CONCAT
			(
				 case when t.ProgrammeCode is null then '' else (t.ProgrammeCode + '§~§') end
				,case when t.RIPolicyType is null then '' else (t.RIPolicyType + '§~§') end
			)
		)	
		-- I've introduced [DeltaType] here to over-ride the default behaviour in [Inbound].[usp_InboundOutboundWorkflow]
		-- We could have multiple new records and we only want to mark the first one as new, 
		-- the rest need to be marked as adjustments.
					,[DeltaType] = case 
									when o.RowHash is null and t.DateOfFact = tm.DateOfFact then 'New'
									else 'Adjustment' 
									end

				into
					#transactions_final_agg_cs 
					FROM
					#TempInboundTransaction t
					-- to determine what the DeltaType is. It can be either New or Adjustment.
					-- if we've already got data in the outbound, then DeltaType=Adjustment
					left join #Outbound o on o.RowHash = t.RowHash
					-- get the first movement from the #transactions_final_agg - this will be our [DeltaType]=New record.
					join
					(
						select 
							RowHash
							,[DateOfFact] = min([DateOfFact])
						from	
							#TempInboundTransaction
						group by
							RowHash
					) tm
						on tm.RowHash = t.RowHash

		---drop table #TempInboundTransaction
			------/* Delete the current lines from Inbound ... */

				DELETE 				
				FROM    [FinanceDataContract].[Inbound].[Transaction]					
				WHERE   [DataSet] = @v_DataSet

				DELETE [FinanceDataContract].[Inbound].[Transaction_Reinsurance_Extensions_Bridge]
				WHERE [ContractType] = @ContractType

				DELETE [FinanceDataContract].[Inbound].[Transaction_Reinsurance_Extensions]
				WHERE [ContractType] = @ContractType


	if not exists(select top 1 1 from #TempInboundTransaction)
	begin

		print 'No data in #TempInboundTransaction, exiting as there is nothing to do.'

		-- LOG THE RESULT WITH SUCCESS
		SELECT @v_ActivityDateTime			= GETUTCDATE();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStop
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

		return

	end


		---IF @Trancount = 0 
			--IF @Trancount = 0 
			BEGIN TRAN;

				-- select * from [dbo].[Batch]
				INSERT INTO [dbo].[Batch]
					([CreateDate],[DataSet],[LatestBusinesKey]) 
				VALUES  
					(GETDATE(),@v_DataSet, NULL);


				SELECT @v_BatchId = SCOPE_IDENTITY();

				INSERT INTO [dbo].[Batch]
					([CreateDate],[DataSet],[LatestBusinesKey]) 
				VALUES  
					(GETDATE(),'ReinsuranceExtensions', NULL);
				

				SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();
				

			/* We insert the rows from temp table in the system */

			
				INSERT INTO  [FinanceDataContract].[Inbound].Transaction_Reinsurance_Extensions_Bridge WITH(TABLOCK)
				(
					 [RowHash_Transaction]
					,[RowHash_Transaction_Reinsurance_Extensions]
					,[ContractType]
					,[FK_Batch]
				)
				SELECT DISTINCT
					 [RowHash]
					,[RowHash_Transaction_Reinsurance_Extensions]
					,@ContractType
					,@v_BatchId_Extensions
				FROM 
					#transactions_final_agg_cs
			
			
				INSERT INTO  [FinanceDataContract].[Inbound].Transaction_Reinsurance_Extensions WITH(TABLOCK)
				(
					[RowHash_Transaction_Reinsurance_Extensions]
					,[RIPolicyType]
					,[ProgrammeCode]
					,[IsLargeLoss]
					,[ContractType]
					,[FK_Batch]
				)
				SELECT DISTINCT
					 [RowHash_Transaction_Reinsurance_Extensions]
					,[RIPolicyType]
					,[ProgrammeCode]
					,0
					,@ContractType
					,@v_BatchId_Extensions
				FROM 
					#transactions_final_agg_cs
	

			/* We insert the rows from temp table in the system */

			INSERT INTO [FinanceDataContract].[Inbound].[Transaction] WITH(TABLOCK)
			(
				 [Scenario]
				,[Basis]
				,[Account]
				,[DataSet]
				,[DateOfFact]
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]
				,[DueDate]
				,[TrifocusCode]
				,[Entity]
				,[Location]
				,[YOA]
				,[TypeOfBusiness]
				,[SettlementCCY]
				,[OriginalCCY]
				,[IsToDate]
				,[Value]
				,[ValueOrig]
				,[RowHash]
				,[BusinessProcessCode]
				,[AuditSourceBatchID]
				,[AuditGenerateDateTime]
				,[StatsCode]
				,[FK_Batch]
				,[DeltaType]
			)		
			SELECT  
				 [Scenario]					= @Scenario
				,[Basis]					= @Basis
				,[Account]
				,[DataSet]					= @v_Dataset
				,[DateOfFact]				
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]					= @DefaultDate
				,[DueDate]					= @DefaultDate
				,[TrifocusCode]
				,[Entity]
				,[Location]					= @Location
				,[YOA]
				,[TypeOfBusiness]			= @TypeOfBusiness
				,[SettlementCCY]
				,[OriginalCCY]				= [SettlementCCY]
				,[IsToDate]					= @IsToDate
				,[Value]
				,[ValueOrig]				= [Value]
				,[RowHash] 
				,[BusinessProcessCode]		= @BusinessProcessCode
				,[AuditSourceBatchID]		= CAST(@v_BatchId AS VARCHAR (50))                                                 
				,[AuditGenerateDateTime]	= GETUTCDATE()
				,[StatsCode]				= @StatsCode
				,[FK_Batch]					= @v_BatchId
				,[DeltaType]				
			FROM    
				#transactions_final_agg_cs

			UNION ALL

			SELECT  
				 [Scenario]					= @Scenario
				,[Basis]					= @Basis
				,[Account]
				,[DataSet]					= @v_Dataset
				,[DateOfFact]				= @DateofFact				
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]					= @DefaultDate
				,[DueDate]					= @DefaultDate
				,[TrifocusCode]
				,[Entity]
				,[Location]					= @Location
				,[YOA]
				,[TypeOfBusiness]			= @TypeOfBusiness
				,[SettlementCCY]
				,[OriginalCCY]				= [SettlementCCY]
				,[IsToDate]					= @IsToDate
				,[Value]					= 0 
				,[ValueOrig]				= 0
				,[RowHash] 
				,[BusinessProcessCode]		= @BusinessProcessCode
				,[AuditSourceBatchID]		= CAST(@v_BatchId AS VARCHAR (50))                                                 
				,[AuditGenerateDateTime]	= GETUTCDATE()
				,[StatsCode]				= @StatsCode
				,[FK_Batch]				
				,DeltaType					= 'Reversal'
			FROM    
				#TempOutboundTransaction


			SELECT   @v_AffectedRows			= @@ROWCOUNT;

	
			/* Add the batch to the queue */
				INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,RunDescription
								,[DataSet]
								,OriginalName
								,AuditSourceBatchID
								,AsAt
								)
				VALUES
								( @v_BatchId
								 ,'InBound'
								 ,NULL
								 ,@v_DataSet
								 ,NULL
								 ,NULL
								,@p_AccountingPeriod	
								)								
				,
								( @v_BatchId_Extensions
								 ,'InBound'
								 ,'ReinsuranceExtensions, the additional attributes to extend functionality of the transaction table.'
								 ,'ReinsuranceExtensions'
								 ,NULL
								 ,NULL
								 ,@p_AccountingPeriod
								);
	
			-- LOG THE RESULT WITH SUCCESS
			SELECT @v_ActivityDateTime			= GETUTCDATE();

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStop
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

			IF @Trancount = 0 
				COMMIT;

		END TRY

		BEGIN CATCH
	
			-- CANCEL TRAN
			IF @Trancount = 0 AND @@TRANCOUNT <> 0 
				ROLLBACK;
			        
			-- LOG THE RESULT WITH ERROR

			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

		    THROW;

		END CATCH;

					
END