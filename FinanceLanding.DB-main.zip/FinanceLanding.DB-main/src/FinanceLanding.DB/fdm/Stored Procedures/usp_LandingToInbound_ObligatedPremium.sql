﻿CREATE PROCEDURE [fdm].[usp_LandingToInbound_ObligatedPremium]
			@p_AccountingPeriod			INT
			,@p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL

AS
-- =============================================
-- LastModified by Author:		Shah Nawaz Ahmed <shahnawaz.ahmed@beazley.com>
-- Modified date: 24/07/2024
-- Description:	https://beazley.atlassian.net/browse/I1B-5692 RI Spend Programme Conforming, created a left join to get ProgrammeCode.

-- LastModified by Author:		Nikil Chowdary Nallamothu <Nikil.Nallamothu@beazley.com>
-- Modified date: 24/04/2024
-- Description:	I1B-5084 -Added union all to fetch data from landing table cededre.RISpendBESITabs(from file for BESI Trifocus)


-- LastModified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 21/07/2021
-- Description:	Original version. Gets ObligatedPremium_RISpend and pushes it into Inbound.Transaction.
--				
-- LastModified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 02/09/2021
-- Description:	Added the paramter @p_AccountingPeriod so it is called by another procedure to cycle through all the periods/quarters and catch up or do all available periods in the case of day one.
--				Removed DateOfFact from the business key so the outbound process can use the rowhash column to detect changes and make adjustments accordingly.
--				
-- LastModified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 15/09/2021
-- Description:	Modified to do reversals correctly & use dbo.fn_RowHashForTransactions for the RowHash
--		

-- LastModified by Author:		Nikil Chowdary Nallamothu <Nikil.Nallamothu@beazley.com>
-- Modified date: 13/06/2022
-- Description:	Modified the DateOfFact variable to forward the accounting period.

-- LastModified by Author:		CharvithaSadhu <Charvitha.Sadhu@beazley.com>
-- Modified date: 22/09/2022
-- Description:	Removed the filter of exluding the programe MunichQQS. This changes are done as part of JIRA https://beazley.atlassian.net/browse/I1B-3309
-- =============================================	
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @YOA int = 2016-- we only get data >= this variable
	--DECLARE @ProcessAccountCodes table(ProcessCode char(2) not null, AccountCode char(7) not null)
	--INSERT INTO @ProcessAccountCodes(ProcessCode,AccountCode) 
	--VALUES('2A','RISPD01'),('2B','RISPD10')-- we're only interested in this combination

	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'ObligatedPremium_RISpend';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	DECLARE @ContractType					CHAR(3)			= 'OBP'

	DECLARE @v_Dataset varchar(50)=@v_ActivityDatabase
	DECLARE @v_BatchId                   INT             = NULL;
	DECLARE @v_BatchId_Extensions INT;

BEGIN TRY

	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';


	/* Insert a new batch for ObligatedPremium_RISpend datasource table*/
	INSERT INTO [dbo].[Batch]([CreateDate],[DataSet],[LatestBusinesKey]) 
	VALUES  (GETDATE(),@v_Dataset,@p_AccountingPeriod);

	SELECT @v_BatchId = SCOPE_IDENTITY();

	/* Log the start of the insert */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'Load data into Inbound.Transaction'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'Load data into Inbound.Transaction for Re-Insurance ObligatedPremium_RISpend'
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;


	-- constants for constant values.
	declare 
		 @Scenario char(1)				='A'
		,@Basis char(1)					= 'B'
		,@DefaultDate date				= CAST('01-01-1980' as date)
		,@TypeOfBusiness char(1)		= '-'
		,@Location char(1)				= '-'
		,@IsToDate char(1)				= 'Y'
		,@BusinessProcessCode char(2)	= 'T1'
		,@AuditHost varchar(255)		= CAST(SERVERPROPERTY('MachineName') as varchar(255))
		,@StatsCode varchar(25)			= null
		,@DateOfFact date				=DATEADD(QUARTER,1,convert(date,convert(char(8),@p_AccountingPeriod * 100 + 1),112))


	--temporary table for the insert (willbe used to calculate RowHash values before pushing data in the IDC transaction table

	DROP TABLE IF EXISTS #TempInboundTransaction;

    /* Insert the new records from ADM sources in the temp table */
	SELECT 
		DateOfFact,
		Account,
		BusinessKey,
		PolicyNumber ,
		InceptionDate,
		ExpiryDate ,
		TrifocusCode ,
		Entity,
		YOA,
		SettlementCCY,
		fk_AccountingPeriod,
		RIPolicyType,
		ProgrammeCode,
		[Value] = sum([Value]),
		RowHash = dbo.fn_RowHashForTransactions
		(
			'T'							-- <@RowHashType, char(1),>
			,@Scenario					--,<@Scenario, nvarchar(2000),>
			,[Account]					--,<@Account, nvarchar(2000),>
			,@v_Dataset					--,<@DataSet, nvarchar(2000),>
			,[BusinessKey]				--,<@BusinessKey, nvarchar(2000),>
			,[PolicyNumber]				--,<@PolicyNumber, nvarchar(2000),>
			,[InceptionDate]			--,<@InceptionDate, date,>
			,[ExpiryDate]				--,<@ExpiryDate, date,>
			,@DefaultDate				--,<@BindDate, date,>
			,@DefaultDate				--,<@DueDate, date,>
			,[TrifocusCode]				--,<@TrifocusCode, nvarchar(2000),>
			,[Entity]					--,<@Entity, nvarchar(2000),>
			,[YOA]						--,<@YOA, nvarchar(2000),>
			,@TypeOfBusiness			--,<@TypeOfBusiness, nvarchar(2000),>
			,@StatsCode					--,<@StatsCode, nvarchar(2000),>
			,[SettlementCCY]			--,<@SettlementCCY, nvarchar(2000),>
			,[SettlementCCY]			--,<@OriginalCCY, nvarchar(2000),>
			,@IsToDate					--,<@IsToDate, nvarchar(2000),>
			,@Basis						--,<@Basis, nvarchar(2000),>
			,@Location					--,<@Location, nvarchar(2000),>
			,@BusinessProcessCode		--,<@BusinessProcessCode, nvarchar(2000),>
			,null						--,<@BoundDate, date,>
			,CONCAT
			(
				 case when RIPolicyType is null then '' else (RIPolicyType + '§~§') end
				,case when ProgrammeCode is null then '' else (ProgrammeCode + '§~§') end
			)
		)
	INTO 
		#TempInboundTransaction
	FROM
	(
		SELECT
		     
           t.DateOfFact,
			t.Account,
			BusinessKey = 
				rtrim(ltrim(ISNULL(t.Account, '')				)) + '|' + 
				rtrim(ltrim(ISNULL(t.RIPolicyNumber, '')		)) + '|' + 
				rtrim(ltrim(ISNULL(CAST(t.YOA AS VARCHAR), '')	)) + '|' +
				rtrim(ltrim(ISNULL(t.SettlementCCY, '')			)) + '|' +
				rtrim(ltrim(ISNULL(t.Entity, '')				)) + '|' +
				rtrim(ltrim(ISNULL(t.Trifocus, '')				)) ,
			PolicyNumber = t.RIPolicyNumber,
			InceptionDate = max( t.RIInceptionDate ),
			ExpiryDate = max(t.RIExpiryDate),
			TrifocusCode = t.TriFocus,
			t.Entity,
			t.YOA,
			t.SettlementCCY,
			t.fk_AccountingPeriod,
			t.RIPolicyType,
			t.ProgrammeCode,
			[Value] = 
				SUM(SUM(t.[Value])) 
				OVER
				(
					PARTITION BY 
						Account,
						RIPolicyNumber,
						RIInceptionDate,
						RIExpiryDate,
						TriFocus,
						RIPolicyType,
						ProgrammeCode,
						Entity,
						YOA,
						SettlementCCY
					ORDER BY 
						fk_AccountingPeriod ASC
				)
		FROM
		(
			SELECT 
			    DateOfFact = @DateOfFact,
				Account = 'P-RP-P-' + CASE WHEN ri.RIType = 'FAC' THEN 'FAC' ELSE 'TTY' END ,
				RIPolicyNumber = rtrim(ri.RIPolicyNumber),
				RIInceptionDate = ri.InceptionDate , 
				RIExpiryDate = ri.ExpiryDate , 
				TriFocus = tf.TrifocusCode , 
				TriFocusName = tf.TrifocusName ,
				ProgrammeCode = LTRIM(RTRIM(ri.RIProgramme)) ,
				Entity = en.EntityCode ,
				YOA = t.fk_YOA ,
				SettlementCCY = t.currency ,
				[Value] = t.cur_amount ,
				t.fk_AccountingPeriod,
				RIPolicyType = LTRIM(RTRIM(ri.RIType))
			FROM 
				[fdm].[vw_FactFDMExternal] t
				JOIN [fdm].[DimAccount] acc on acc.pk_Account = t.fk_Account
				JOIN [fdm].[DimProcess] dp on  dp.pk_Process = t.fk_Process		
				INNER JOIN [fdm].[vw_DimRIPolicy] ri on ri.pk_RIPolicy = t.fk_RIPolicy	
				LEFT JOIN [fdm].[DimTrifocus] tf on tf.pk_Trifocus = t.fk_TriFocus
				LEFT JOIN [fdm].[DimEntity] en on en.pk_Entity = t.fk_Entity
			WHERE
			    acc.AccountCode = 'RI00001' 
                and ri.RIAdjustment in ('RISPD', 'Reinsts')
				and t.fk_YOA >= @YOA
				--and ri.RIProgramme<>'MUNQQS'
			 --Removed the below filter
				---AND fk_AccountingPeriod <> 201912 --Excluded as the data from FDM is not right for this period for 2A & 2B. I1B-2295
		) t
		GROUP BY 
			t.Account,
			t.RIPolicyNumber,
			t.TriFocus,
			t.ProgrammeCode,
			t.RIPolicyType,
			t.Entity,
			t.YOA,
			t.SettlementCCY,
			t.fk_AccountingPeriod,
			t.RIInceptionDate,
			t.RIExpiryDate,
			t.DateOfFact
UNION ALL
/*Obligated Premium RI Spend for BESI https://beazley.atlassian.net/browse/I1B-5084 */
	SELECT
	       t.DateOfFact																																																																									   ,
	       t.Account																																																																									   ,
	       BusinessKey   = rtrim(ltrim(ISNULL(t.Account, '') )) + '|' +
						   rtrim(ltrim(ISNULL(t.RIPolicyNumber, '') )) + '|' + 
						   rtrim(ltrim(ISNULL(CAST(t.YOA AS VARCHAR), '') )) + '|' +
						   rtrim(ltrim(ISNULL(t.SettlementCCY, '') )) + '|' + 
						   rtrim(ltrim(ISNULL(t.Entity, '') )) + '|' + 
						   rtrim(ltrim(ISNULL(t.Trifocus, '') )) ,
	       PolicyNumber  = t.RIPolicyNumber                                                                                                                                                                                                                                                                                ,
	       InceptionDate = max( t.RIInceptionDate )                                                                                                                                                                                                                                                                        ,
	       ExpiryDate    = max(t.RIExpiryDate)                                                                                                                                                                                                                                                                             ,
	       TrifocusCode  = t.TriFocus                                                                                                                                                                                                                                                                                      ,
	       t.Entity                                                                                                                                                                                                                                                                                                        ,
	       t.YOA                                                                                                                                                                                                                                                                                                           ,
	       t.SettlementCCY                                                                                                                                                                                                                                                                                                 ,
	       t.AccountingPeriod                                                                                                                                                                                                                                                                                              ,
	       t.RIPolicyType                                                                                                                                                                                                                                                                                                  ,
	       t.ProgrammeCode                                                                                                                                                                                                                                                                                                 ,
	       [Value] = SUM(t.[Value])
	FROM
	       (
	                 SELECT
	                        dateadd(quarter, 1, t.DateOfFact) DateOfFact,
	                        Account = 'P-RP-P-' +
	                        CASE
	                        WHEN
	                                  t.Type = 'FAC'
	                        THEN
	                                  'FAC'
	                        ELSE
	                                  'TTY'
	                        END                                                                    ,
	                        RIPolicyNumber  = rtrim(t.[RIRef])                                     ,
	                        RIInceptionDate = isnull(tty.Inception_Date, t.[InceptionDate])        ,
	                        RIExpiryDate    = isnull(tty.Expiry_Date, t.[ExpiryDate])              ,
	                        TriFocus        = tf.TrifocusCode                                      ,
	                        TriFocusName    = t.Trifocus                                           ,
	                        ProgrammeCode   = isnull(tty.ProgrammeCode, LTRIM(RTRIM(isnull(prg.ConformedProgrammeMapping, t.Programme)))) ,-- ProgrammeCode   = isnull(tty.ProgrammeCode, LTRIM(RTRIM(t.Programme))) ,
	                        Entity          = '8044'                                               ,
	                        YOA             = t.YOA                                                ,
	                        SettlementCCY   = 'USD'                                                ,
	                        [Value]         = t.[Value]                                            ,
	                        left(convert(varchar, t.DateOfFact, 112), 6) AccountingPeriod          ,
	                        RIPolicyType = isnull(tty.RI_Policy_Type, LTRIM(RTRIM(t.Type)))
	                 FROM
	                        cededre.RISpendBESITabs t
	                 LEFT JOIN
	                        Eurobase.vw_ReInsuranceTreatyContractAttributes tty
	                 ON
	                        (
	                                  tty.RI_Section_Reference = t.[RIRef])
	                 LEFT JOIN
	                        [fdm].[DimTrifocus] tf
	                 ON
	                        tf.TrifocusName = t.Trifocus
					LEFT JOIN
							MDS.ConformedProgrammeMapping prg
					ON		
							(prg.ProgrammeCode = t.Programme)) t
	GROUP BY
	       t.Account         ,
	       t.RIPolicyNumber  ,
	       t.TriFocus        ,
	       t.ProgrammeCode   ,
	       t.RIPolicyType    ,
	       t.Entity          ,
	       t.YOA             ,
	       t.SettlementCCY   ,
	       t.AccountingPeriod,
	       t.RIInceptionDate ,
	       t.RIExpiryDate    ,
	       t.DateOfFact
	) src1
	WHERE
		src1.fk_AccountingPeriod = @p_AccountingPeriod
		-- debug code
		--and src1.BusinessKey = 'P-RP-P-TTY|CLASHBUDGET|2019|USD|2623|697'
	GROUP BY 
		Account,
		BusinessKey,
		PolicyNumber ,
		InceptionDate  ,
		ExpiryDate  ,
		TrifocusCode ,
		Entity,
		YOA,
		SettlementCCY,
		fk_AccountingPeriod,
		RIPolicyType,
		ProgrammeCode,
		DateOfFact


	SELECT   @v_AffectedRows			= @@ROWCOUNT;
	print convert(varchar,@v_AffectedRows) + ' records in #TempInboundTransaction for ' + convert(varchar,@p_AccountingPeriod)

	if object_id('tempdb..#Outbound') is not null drop table #Outbound
				select 
					t.*
					-- extensions
					,e.ProgrammeCode
					,e.RIPolicyType
				into 
					#Outbound
				from 
					FinanceDataContract.Outbound.[Transaction] t
					join FinanceDataContract.Outbound.Transaction_Reinsurance_Extensions_Bridge b on b.RowHash_Transaction = t.RowHash
					join FinanceDataContract.Outbound.Transaction_Reinsurance_Extensions e on e.RowHash_Transaction_Reinsurance_Extensions = b.RowHash_Transaction_Reinsurance_Extensions
				where 
					t.DataSet = @v_DataSet


	-- now I need to do the Reversals.
	-- I get the data from the outbound grouped by the rowhash & check to see that we don't have a related inbound record. These are missing and need to be zero'ed for the current period.
	DROP TABLE IF EXISTS #TempOutboundTransaction;

	SELECT 
		 tot.Account             
		,tot.BusinessKey        
		,tot.PolicyNumber
		,tot.InceptionDate 
		,tot.ExpiryDate 
		,tot.TrifocusCode        
		,tot.Entity              
		,tot.YOA                 
		,tot.SettlementCCY       
		,[FK_Batch]          = MAX(tot.[FK_Batch])
		,tot.RowHash
		,tot.RIPolicyType
		,tot.ProgrammeCode
	INTO 
		#TempOutboundTransaction 
	FROM        
		#Outbound tot
		left join #TempInboundTransaction tite on tot.RowHash = tite.RowHash
	WHERE
		tite.RowHash is null
		and tot.Dataset = @v_Dataset
		and exists(select top 1 1 from #TempInboundTransaction) -- if we have nothing for this period, we don't want to reverse all the data out. This is not likely to happen in production - but in dev & test.
	GROUP BY  
		 tot.Account             
		,tot.BusinessKey        
		,tot.PolicyNumber
		,tot.InceptionDate 
		,tot.ExpiryDate 
		,tot.TrifocusCode        
		,tot.Entity              
		,tot.YOA                 
		,tot.SettlementCCY       
		,tot.RowHash
		,tot.RIPolicyType
		,tot.ProgrammeCode
	HAVING
		SUM(tot.[Value]) <> 0

	SELECT   @v_AffectedRows			= @@ROWCOUNT;
	print convert(varchar,@v_AffectedRows) + ' records in #TempOutboundTransaction for ' + convert(varchar,@p_AccountingPeriod)

		
	---DROP TABLE #transactions_final_agg_cs

	if object_id('tempdb..#transactions_final_agg_cs') is not null drop table #transactions_final_agg_cs

				--return -- gets here in 
				-- create the rowhash for the extensions.
				select DISTINCT
					t.Account,
					t.BusinessKey,
					t.PolicyNumber ,
					t.InceptionDate,
					t.ExpiryDate ,
					t.TrifocusCode ,
					t.Entity,
					t.YOA,
					t.SettlementCCY,
					[Value] = t.[Value],
					t.RIPolicyType,
					ProgrammeCode = t.ProgrammeCode,
					t.RowHash,
					[RowHash_Transaction_ReInsurance_Extensions] = dbo.fn_RowHashForTransactions
		(
			'E' /* @RowHashType */
			,@Scenario,t.Account,@v_Dataset,t.BusinessKey,t.PolicyNumber,t.InceptionDate,t.ExpiryDate,@DefaultDate,@DefaultDate,t.TrifocusCode,t.Entity,t.YOA,@TypeOfBusiness,@StatsCode,t.SettlementCCY,t.SettlementCCY,@IsToDate,@Basis,@Location
			,null /* @BusinessProcessCode */
			,null /* @BoundDate */
			-- extended columns
			,CONCAT
			(
				 case when t.ProgrammeCode is null then '' else (t.ProgrammeCode + '§~§') end
				,case when t.RIPolicyType is null then '' else (t.RIPolicyType + '§~§') end
			)
		)	
		-- I've introduced [DeltaType] here to over-ride the default behaviour in [Inbound].[usp_InboundOutboundWorkflow]
		-- We could have multiple new records and we only want to mark the first one as new, 
		-- the rest need to be marked as adjustments.
					,[DeltaType] = case 
									when o.RowHash is null and t.DateOfFact = tm.DateOfFact then 'New'
									else 'Adjustment' 
									end

				into
					#transactions_final_agg_cs 
					FROM
					#TempInboundTransaction t
					-- to determine what the DeltaType is. It can be either New or Adjustment.
					-- if we've already got data in the outbound, then DeltaType=Adjustment
					left join #Outbound o on o.RowHash = t.RowHash
					-- get the first movement from the #transactions_final_agg - this will be our [DeltaType]=New record.
					join
					(
						select 
							RowHash
							,[DateOfFact] = min([DateOfFact])
						from	
							#TempInboundTransaction
						group by
							RowHash
					) tm
						on tm.RowHash = t.RowHash

		---drop table #TempInboundTransaction
			------/* Delete the current lines from Inbound ... */

				DELETE 				
				FROM    [FinanceDataContract].[Inbound].[Transaction]					
				WHERE   [DataSet] = @v_DataSet

				DELETE [FinanceDataContract].[Inbound].[Transaction_Reinsurance_Extensions_Bridge]
				WHERE [ContractType] = @ContractType

				DELETE [FinanceDataContract].[Inbound].[Transaction_Reinsurance_Extensions]
				WHERE [ContractType] = @ContractType


	if not exists(select top 1 1 from #TempInboundTransaction)
	begin

		print 'No data in #TempInboundTransaction, exiting as there is nothing to do.'

		-- LOG THE RESULT WITH SUCCESS
		SELECT @v_ActivityDateTime			= GETUTCDATE();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStop
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

		return

	end


		---IF @Trancount = 0 
			--IF @Trancount = 0 
			BEGIN TRAN;

				-- select * from [dbo].[Batch]
				INSERT INTO [dbo].[Batch]
					([CreateDate],[DataSet],[LatestBusinesKey]) 
				VALUES  
					(GETDATE(),@v_DataSet, NULL);


				SELECT @v_BatchId = SCOPE_IDENTITY();

				INSERT INTO [dbo].[Batch]
					([CreateDate],[DataSet],[LatestBusinesKey]) 
				VALUES  
					(GETDATE(),'ReinsuranceExtensions', NULL);
				

				SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();
				

			/* We insert the rows from temp table in the system */

			
				INSERT INTO  [FinanceDataContract].[Inbound].Transaction_Reinsurance_Extensions_Bridge WITH(TABLOCK)
				(
					 [RowHash_Transaction]
					,[RowHash_Transaction_Reinsurance_Extensions]
					,[ContractType]
					,[FK_Batch]
				)
				SELECT DISTINCT
					 [RowHash]
					,[RowHash_Transaction_Reinsurance_Extensions]
					,@ContractType
					,@v_BatchId_Extensions
				FROM 
					#transactions_final_agg_cs
			
			
				INSERT INTO  [FinanceDataContract].[Inbound].Transaction_Reinsurance_Extensions WITH(TABLOCK)
				(
					[RowHash_Transaction_Reinsurance_Extensions]
					,[RIPolicyType]
					,[ProgrammeCode]
					,[IsLargeLoss]
					,[ContractType]
					,[FK_Batch]
				)
				SELECT DISTINCT
					 [RowHash_Transaction_Reinsurance_Extensions]
					,[RIPolicyType]
					,[ProgrammeCode]
					,0
					,@ContractType
					,@v_BatchId_Extensions
				FROM 
					#transactions_final_agg_cs
	

			/* We insert the rows from temp table in the system */

			INSERT INTO [FinanceDataContract].[Inbound].[Transaction] WITH(TABLOCK)
			(
				 [Scenario]
				,[Basis]
				,[Account]
				,[DataSet]
				,[DateOfFact]
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]
				,[DueDate]
				,[TrifocusCode]
				,[Entity]
				,[Location]
				,[YOA]
				,[TypeOfBusiness]
				,[SettlementCCY]
				,[OriginalCCY]
				,[IsToDate]
				,[Value]
				,[ValueOrig]
				,[RowHash]
				,[BusinessProcessCode]
				,[AuditSourceBatchID]
				,[AuditGenerateDateTime]
				,[StatsCode]
				,[FK_Batch]
				,[DeltaType]
			)		
			SELECT  
				 [Scenario]					= @Scenario
				,[Basis]					= @Basis
				,[Account]
				,[DataSet]					= @v_Dataset
				,[DateOfFact]				= @DateOfFact
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]					= @DefaultDate
				,[DueDate]					= @DefaultDate
				,[TrifocusCode]
				,[Entity]
				,[Location]					= @Location
				,[YOA]
				,[TypeOfBusiness]			= @TypeOfBusiness
				,[SettlementCCY]
				,[OriginalCCY]				= [SettlementCCY]
				,[IsToDate]					= @IsToDate
				,[Value]
				,[ValueOrig]				= [Value]
				,[RowHash] 
				,[BusinessProcessCode]		= @BusinessProcessCode
				,[AuditSourceBatchID]		= CAST(@v_BatchId AS VARCHAR (50))                                                 
				,[AuditGenerateDateTime]	= GETUTCDATE()
				,[StatsCode]				= @StatsCode
				,[FK_Batch]					= @v_BatchId
				,[DeltaType]				
			FROM    
				#transactions_final_agg_cs

			UNION ALL

			SELECT  
				 [Scenario]					= @Scenario
				,[Basis]					= @Basis
				,[Account]
				,[DataSet]					= @v_Dataset
				,[DateOfFact]				= @DateOfFact
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]					= @DefaultDate
				,[DueDate]					= @DefaultDate
				,[TrifocusCode]
				,[Entity]
				,[Location]					= @Location
				,[YOA]
				,[TypeOfBusiness]			= @TypeOfBusiness
				,[SettlementCCY]
				,[OriginalCCY]				= [SettlementCCY]
				,[IsToDate]					= @IsToDate
				,[Value]					= 0 
				,[ValueOrig]				= 0
				,[RowHash] 
				,[BusinessProcessCode]		= @BusinessProcessCode
				,[AuditSourceBatchID]		= CAST(@v_BatchId AS VARCHAR (50))                                                 
				,[AuditGenerateDateTime]	= GETUTCDATE()
				,[StatsCode]				= @StatsCode
				,[FK_Batch]				
				,DeltaType					= 'Reversal'
			FROM    
				#TempOutboundTransaction


			SELECT   @v_AffectedRows			= @@ROWCOUNT;

	
			/* Add the batch to the queue */
				INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,RunDescription
								,[DataSet]
								,OriginalName
								,AsAT
								,AuditSourceBatchID
								)
				VALUES
								( @v_BatchId
								 ,'InBound'
								 ,NULL
								 ,@v_DataSet
								 ,NULL
								,@p_AccountingPeriod
								 ,NULL
								)								
				,
								( @v_BatchId_Extensions
								 ,'InBound'
								 ,'ReinsuranceExtensions, the additional attributes to extend functionality of the transaction table.'
								 ,'ReinsuranceExtensions'
								 ,NULL
								 ,@p_AccountingPeriod
								 ,NULL
								);
			-- LOG THE RESULT WITH SUCCESS
			SELECT @v_ActivityDateTime			= GETUTCDATE();

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStop
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

			IF @Trancount = 0 
				COMMIT;

		END TRY

		BEGIN CATCH
	
			-- CANCEL TRAN
			IF @Trancount = 0 AND @@TRANCOUNT <> 0 
				ROLLBACK;
			        
			-- LOG THE RESULT WITH ERROR

			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

		    THROW;

		END CATCH;

					
END