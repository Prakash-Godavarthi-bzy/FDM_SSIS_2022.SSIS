﻿CREATE TABLE [fdm].[CHE] (
    [TrifocusCode]    NVARCHAR (255)  NULL,
    [YOAName]         NVARCHAR (255)  NULL,
    [InceptionDate]   DATE            NULL,
    [ExpiryDate]      DATE            NULL,
    [currency]        NVARCHAR (25)   NULL,
    [Entity]          NVARCHAR (255)  NULL,
    [PolicyReference] NVARCHAR (255)  NULL,
    [AccountCode]     VARCHAR (6)     NULL,
    [LocationDesc]    NVARCHAR (255)  NULL,
    [Value]           NUMERIC (18, 4) NULL,
    [Scenario]        VARCHAR (1)     NULL,
    [Basis]           VARCHAR (1)     NULL,
    [DateOFFact]      VARCHAR (52)    NULL,
    [BindDate]        VARCHAR (10)    NULL,
    [DueDate]         VARCHAR (10)    NULL,
    [TypeofBusiness]  VARCHAR (1)     NULL,
    [IsToDate]        VARCHAR (1)     NULL
);

