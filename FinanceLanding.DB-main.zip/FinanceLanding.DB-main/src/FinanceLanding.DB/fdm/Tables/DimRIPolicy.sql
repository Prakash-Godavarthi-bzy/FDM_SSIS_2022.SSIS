﻿
CREATE TABLE [fdm].[DimRIPolicy](
	[pk_RIPolicy] [bigint] NOT NULL,
	[RIPolicyNumber] [nvarchar](255) NULL,
	[InceptionDate] [date] NULL,
	[ExpiryDate] [date] NULL,
	[RIProgramme] [nvarchar](255) NULL,
	[RIType] [nvarchar](50) NULL,
	[RIAdjustment] [nvarchar](50) NULL,
	[RIBASis] [nvarchar](50) NULL
)