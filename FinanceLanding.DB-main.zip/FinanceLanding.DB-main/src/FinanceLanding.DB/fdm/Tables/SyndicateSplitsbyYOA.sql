﻿

CREATE TABLE [fdm].[SyndicateSplitsbyYOA](
	[pk_SyndSplit] [bigint] IDENTITY(1,1) NOT NULL,
	[SyndSplitSource] [nvarchar](10) NOT NULL,
	[SyndSplitYOA] [nvarchar](5) NOT NULL,
	[SyndSplitEntity] [nvarchar](25) NOT NULL,
	[SyndSplitPercentage] [numeric](4,4) NULL,
	[AuditSourceServer] [nvarchar](55)  NULL,
	[AuditSourceTable] [nvarchar](55)  NULL,
	[AuditGenerateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](55) NOT NULL,
	[AuditHost] [nvarchar](55) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [fdm].[SyndicateSplitsbyYOA] ADD  DEFAULT (getutcdate()) FOR [AuditGenerateDateTime]
GO

ALTER TABLE [fdm].[SyndicateSplitsbyYOA] ADD  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [fdm].[SyndicateSplitsbyYOA] ADD  DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO
