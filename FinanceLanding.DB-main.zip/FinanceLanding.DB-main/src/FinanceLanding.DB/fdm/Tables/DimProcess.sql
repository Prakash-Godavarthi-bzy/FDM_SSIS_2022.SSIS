﻿
CREATE TABLE [fdm].[DimProcess](
	[pk_Process] [int] NOT NULL,
	[ProcessCode] [nvarchar](255) NULL
)