﻿
CREATE TABLE [fdm].[DimEntity](
	[pk_Entity] [int] NOT NULL,
	[EntityCode] [nvarchar](255) NULL,
	[EntityName] [nvarchar](255) NULL
) ON [PRIMARY]