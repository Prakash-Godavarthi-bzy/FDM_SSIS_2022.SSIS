﻿CREATE TABLE [fdm].[AccountingPeriod](
	[pk_AccountingPeriod] [int] NOT NULL,
	[AccountingPeriod] [nvarchar](255) NULL,
	[AccountingYear] [int] NULL,
	[AccountingYearName] [nvarchar](255) NULL,
	[AccountingMonth] [int] NULL,
	[AccountingMonthName] [nvarchar](255) NULL,
 CONSTRAINT [PK__DimAccou__25CC01ECDC361639] PRIMARY KEY CLUSTERED 
(
	[pk_AccountingPeriod] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO

