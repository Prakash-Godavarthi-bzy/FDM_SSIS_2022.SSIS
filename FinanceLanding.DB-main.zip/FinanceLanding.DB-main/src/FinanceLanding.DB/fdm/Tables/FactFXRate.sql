﻿
CREATE TABLE [fdm].[FactFXRate](
	[fk_AccountingPeriod] [int] NOT NULL,
	[fk_FXRate] [int] NOT NULL,
	[fk_TransactionCurrency] [nvarchar](25) NOT NULL,
	[fk_ReportingCurrency] [int] NOT NULL,
	[FXRate] [numeric](28, 8) NULL,
	[fk_RateScenario] [int] NOT NULL,
	[InsertDate] [datetime2](7) NULL,
 CONSTRAINT [PK_FactFXRate] PRIMARY KEY CLUSTERED 
(
	[fk_AccountingPeriod] ASC,
	[fk_FXRate] ASC,
	[fk_TransactionCurrency] ASC,
	[fk_ReportingCurrency] ASC,
	[fk_RateScenario] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO
