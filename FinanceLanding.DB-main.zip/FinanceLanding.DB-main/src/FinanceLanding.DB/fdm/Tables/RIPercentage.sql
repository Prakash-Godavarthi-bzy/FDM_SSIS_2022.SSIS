﻿CREATE TABLE [fdm].[RIPercentage](
	[AccountingPeriod] [varchar](25) NULL,
	[TrifocusCode] [nvarchar](50) NULL,
	[TrifocusName] [nvarchar](255) NULL,
	[Entity] [varchar](50) NULL,
	[YOA] [int] NULL,
	[YOI] [int] NULL,
	[RIProgramme] [varchar](255) NULL,
	[RIType] [varchar](50) NULL,
	[SettlementCCY] [varchar](25) NULL,
	[RIPolicyNumber] [varchar](255) NULL,
	[InceptionDate] [datetime] NULL,
	[ExpiryDate] [datetime] NULL,
	[ClaimsBasis] [varchar](10) NULL,
	[RIPremium] [numeric](19, 6) NULL,	
	[GrossNetUltimates] [numeric](19, 6) NULL,
	[RI%] [numeric](19, 6) NULL,
	[Businesskey] [varchar](500) NOT NULL,
	[AuditSourceBatchID] [varchar](255) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditGenerateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL,
	[AuditHost] [nvarchar](255) NOT NULL,
) ON [PRIMARY]
GO
ALTER TABLE [fdm].[RIPercentage] ADD  CONSTRAINT [DF_RIPercentage_AuditCreateDateTime]  DEFAULT (getdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [fdm].[RIPercentage] ADD  CONSTRAINT [DF_RIPercentage_AuditGenerateDateTime]  DEFAULT (getdate()) FOR [AuditGenerateDateTime]
GO

ALTER TABLE [fdm].[RIPercentage] ADD  CONSTRAINT [DF_RIPercentage_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [fdm].[RIPercentage] ADD  CONSTRAINT [DF_RIPercentage_AuditHost]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO



