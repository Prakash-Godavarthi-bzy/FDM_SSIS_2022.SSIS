﻿CREATE TABLE [fdm].[RISpendMunichCedePercentage](
	[RISpendMunichCedePercentagesId] [int] NOT NULL,
	[YOA] [int] NULL,
	[Entity] [nvarchar](25) NULL,
	[TrifocusCode] [nvarchar](255) NULL,
	[TrifocusName] [nvarchar](255) NULL,
	[Percentage] NUMERIC(19,5) NULL,
	[ORCPercentage] NUMERIC(19,5) NULL,
	[AuditGenerateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](55) NOT NULL,
	[AuditHost] [nvarchar](55) NOT NULL
) ON [PRIMARY]
GO


ALTER TABLE [fdm].[RISpendMunichCedePercentage] ADD  DEFAULT (getutcdate()) FOR [AuditGenerateDateTime]
GO

ALTER TABLE [fdm].[RISpendMunichCedePercentage] ADD  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [fdm].[RISpendMunichCedePercentage] ADD  DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO