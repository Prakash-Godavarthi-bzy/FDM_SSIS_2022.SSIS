﻿
CREATE TABLE [fdm].[FactFDMExternal_History](
	[fk_AccountingPeriod] [int] NOT NULL,
	[fk_YOA] [int] NOT NULL,
	[currency] [nvarchar](25) NULL,
	[cur_amount] [decimal](28, 3) NULL,
	[fk_Account] [int] NOT NULL,
	[fk_Process] [int] NOT NULL,
	[fk_RIPolicy] [bigint] NOT NULL,
	[fk_TriFocus] [int] NOT NULL,
	[fk_Entity] [int] NOT NULL
) 