﻿
CREATE TABLE [fdm].[DimAccount](
	[pk_Account] [int] NOT NULL,
	[AccountCode] [nvarchar](255) NULL
) ON [PRIMARY]
