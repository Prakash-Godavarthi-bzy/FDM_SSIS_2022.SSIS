﻿
CREATE TABLE [fdm].[DimTrifocus](
	[pk_Trifocus] [int] NOT NULL,
	[TrifocusCode] [nvarchar](255) NULL,
	[TrifocusName] [nvarchar](255) NULL
) 