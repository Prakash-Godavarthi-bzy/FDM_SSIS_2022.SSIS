﻿CREATE   view [fdm].[vw_ReInsuranceAllocations]
as
with cte_rispend
as
(
select 
       EntityCode,
       EntityName,
       AccountCode,
       left(convert(varchar, dateadd(quarter, 1, cast(cast(AccountingPeriod as varchar) + '01' as date)), 112), 6) as AccountingPeriod,
       RIPolicyNumber,
      YOA,
       RIType,
       RIProgramme,
       TrifocusCode,
       TrifocusName,
       SettlementCurrency,
       Amount,
       TotalAmount,
       Allocation = case when TotalAmount <> 0 then Amount/TotalAmount else 0 end
from   
       (
              select 
                     EntityCode,
                     EntityName,
                     AccountCode,
                     AccountingPeriod,
                     RIPolicyNumber,
                     YOA,
                     RIType,
                     RIProgramme,
                     TrifocusCode,
                     TrifocusName,
                     SettlementCurrency,
                     Amount,
                     TotalAmount = sum(Amount) over
                     (
                           partition by 
                                  EntityCode,
                                  AccountCode,
                                  RIPolicyNumber,
                                  YOA,
                                  SettlementCurrency,
                                  AccountingPeriod
                     ) 
              from 
              (
                     select 
                           EntityCode,
                           EntityName,
                           AccountCode,
                           AccountingPeriod,
                           RIPolicyNumber,
                           YOA,
                           RIType,
                           RIProgramme,
                           TrifocusCode,
                           TrifocusName,
                           SettlementCurrency,
                           Amount = 
                                  sum(Amount) over 
                                  (
                                         partition by 
                                                EntityCode,
                                                AccountCode,
                                                RIPolicyNumber,
                                                YOA,
                                                TrifocusCode,
                                                SettlementCurrency
                                         order by 
                                                AccountingPeriod asc
                                   ) 
                     from
                     (
                           select 
                                  EntityCode = case when ent.EntityCode in ('BIFR', 'BIGE', 'BISP', 'BISW', 'BIUK') then '8033' else ent.EntityCode end,
                                  EntityName = max(case when ent.EntityCode in ('BIFR', 'BIGE', 'BISP', 'BISW', 'BIUK') then 'Beazley Insurance dac France' else ent.EntityName end),
                                  acc.AccountCode,
                                  AccountingPeriod = t.fk_AccountingPeriod ,
                                  ri.RIPolicyNumber,
                                  YOA = t.fk_YOA ,
                                  ri.RIType,
                                  RIProgramme = min(ri.RIProgramme),
                                  tf.TrifocusCode,
                                  tf.TrifocusName,
                                  SettlementCurrency = t.currency ,
                                  Amount = sum(t.cur_amount) 
                           from 
                                  [fdm].[vw_FactFDMExternal] t
                                  join fdm.[DimAccount] acc on (acc.pk_Account = t.fk_Account)
                                  join fdm.[DimProcess] prc on (prc.pk_Process = t.fk_Process)
                                  join fdm.[DimEntity] ent on (ent.pk_Entity = t.fk_Entity)
                                  left join fdm.vw_DimRIPolicy ri on (ri.pk_RIPolicy = t.fk_RIPolicy)
                                  join fdm.DimTrifocus tf on (tf.pk_Trifocus = t.fk_TriFocus) 
                           where 
                                  (
                                         acc.AccountCode = 'RI00001' 
                                         and ri.RIAdjustment in ('RISPD', 'Reinsts')
                                  )
                                                               
                                  --and t.fk_YOA >= 2016
                           group by 
                                  case when ent.EntityCode in ('BIFR', 'BIGE', 'BISP', 'BISW', 'BIUK') then '8033' else ent.EntityCode end,
                                  --ent.EntityName,
                                  acc.AccountCode,
                                  [fk_AccountingPeriod],
                                  ri.RIPolicyNumber,
                                  t.fk_YOA,
                                  ri.RIType,
                                  tf.TrifocusCode,
                                  tf.TrifocusName,
                                  t.currency
                     ) t
              )cte
       ) r

       ),
         ceded as (
          SELECT proc_period
,ritype
,cla_year_of_account
,isnull(cast(s.SyndSplitEntity as int), t.synd) synd
,cpl_pol_policy_reference
,COALESCE(t.DummyProgramme,prg.ifrs17_programme_group, t.programname) as programname
,clo_claim_currency
,trifocus
,sum(case when s.SyndSplitSource is not null then t.premium * s.SyndSplitPercentage else t.premium end) premium
,sum(case when s.SyndSplitSource is not null then t.overrider * s.SyndSplitPercentage else t.overrider end) overrider
FROM CededRe.VW_CededReAccessDB t
left join Eurobase.rein_program_sequence prg on (prg.rps_program_id = t.programname)
left join fdm.SyndicateSplitsbyYOA s
on (s.SyndSplitSource = cast(t.synd as varchar)
and s.SyndSplitYOA = t.cla_year_of_account
and cast(t.synd as varchar) in ('623', '2623', '1174'))
where (isnull(t.premium, 0) <> 0 or isnull(t.overrider, 0) <> 0)
group by proc_period
,ritype
,cla_year_of_account
,isnull(cast(s.SyndSplitEntity as int), t.synd)
,cpl_pol_policy_reference
,COALESCE(t.DummyProgramme,prg.ifrs17_programme_group, t.programname)
,clo_claim_currency
,trifocus
          ),

cte_cededre as
(
select cast(synd as varchar) as [EntityCode],
null as EntityName,
null as [AccountCode],
convert(varchar(6), proc_period, 112) as [AccountingPeriod],
cpl_pol_policy_reference as [RIPolicyNumber],
cla_year_of_account [YOA],
ritype [RIType],
programname [RIProgramme],
ISNULL(tri.TrifocusCode,'Unknown') as [TrifocusCode],
trifocus as [TrifocusName],
clo_claim_currency as [SettlementCurrency],
sum(isnull(premium, 0) + isnull(overrider, 0)) as Amount,
sum(sum(isnull(premium, 0) + isnull(overrider, 0))) over(partition by
synd,
proc_period,
cpl_pol_policy_reference,
cla_year_of_account,
ritype,
programname,
clo_claim_currency
) as TotalAmount
from 
ceded as t 
left join fdm.DimTrifocus as tri ON CASE WHEN t.trifocus = 'Covers' THEN 'Covers US'
                                                                     WHEN t.trifocus = 'Intl Specialty(PT)' THEN 'Intl Specialty (PT)'
                                                                     WHEN t.trifocus = 'BBR Services Int(Exc PE)' THEN 'BBR Services Int (Exc PE)'
                                                                     ELSE t.trifocus
                                                              END = tri.TrifocusName
where 
--cla_year_of_account <= 2015
ritype <> 'FAC'
group by synd,
--[AccountCode],
proc_period,
cpl_pol_policy_reference,
cla_year_of_account,
ritype,
programname,
ISNULL(tri.TrifocusCode,'Unknown'),
trifocus,
clo_claim_currency
having abs(sum(isnull(premium, 0) + isnull(overrider, 0))) > 1
)

select * from cte_rispend
where TotalAmount <> 0
and YOA >= cast(AccountingPeriod/ 100 as int) - 2  

union all

select *, Amount/ TotalAmount as Allocation
from cte_cededre
where TotalAmount <> 0
and YOA < cast(AccountingPeriod/ 100 as int) - 2
GO
