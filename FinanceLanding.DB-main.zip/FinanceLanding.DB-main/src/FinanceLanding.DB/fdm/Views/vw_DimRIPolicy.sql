﻿/* ===========================================================================================================
	Created By:		-
	Modified By : Venkat.Yerravati@beazley.com
	Created date:	-
	Modified Date : 19/01.2024
	Description:	Static Script is created to prevent the possibility of unconformed Programmes being introduced through RI Spend for Historical Data which is happening in the view vw_DimRIPolicy.
					--https://beazley.atlassian.net/browse/I1B-5059
=================================================================================================================== */


CREATE VIEW [fdm].[vw_DimRIPolicy]
AS
with cte_latest as
(
SELECT [pk_RIPolicy]
,case when t.RIPolicyNumber like 'R0925%' then 'KRE20' + substring(t.RIPolicyNumber, 7, 2)
else t.RIPolicyNumber
end [RIPolicyNumber]
,[InceptionDate]
,[ExpiryDate]
,isnull(dm.Programme, isnull(tty.ProgrammeCode, [RIProgramme])) RIProgramme
,[RIType]
,[RIAdjustment]
,[RIBASis]
FROM [fdm].[DimRIPolicy] t
left join [Eurobase].[vw_ReInsuranceTreatyContractAttributes] tty on
(tty.RI_Section_Reference = case when t.RIPolicyNumber like 'R0925%' then 'KRE20' + substring(t.RIPolicyNumber, 7, 2)
else t.RIPolicyNumber
end)
left join [MDS].[DummyProgrammes_CededRe] dm on (dm.DummyPolicy = case when t.RIPolicyNumber like 'R0925%' then 'KRE20' + substring(t.RIPolicyNumber, 7, 2)
else t.RIPolicyNumber
end)
)

select [pk_RIPolicy]
,[RIPolicyNumber]
,[InceptionDate]
,[ExpiryDate]
,isnull(cast(map.[ConformedProgrammeMapping] as varchar(100)), t.RIProgramme) RIProgramme
,[RIType]
,[RIAdjustment]
,[RIBASis] --into #test
from cte_latest t
left join [MDS].[ConformedProgrammeMapping] map on (map.[ProgrammeCode] = t.RIProgramme)
GO


