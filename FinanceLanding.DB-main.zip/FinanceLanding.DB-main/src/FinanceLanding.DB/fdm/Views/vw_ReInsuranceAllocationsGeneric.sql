﻿
CREATE VIEW [fdm].[vw_ReInsuranceAllocationsGeneric]
AS
/*
-- ====================================================================================================================================================================================
-- Modified by:			ShahNawaz.Ahmed@beazley.com
-- Modification date:	      14-05-2024
-- Changes:				Changed from EntityCode to add 8044 and change source https://beazley.atlassian.net/browse/I1B-5447
-- ====================================================================================================================================================================================	

Modified by:			venkat.yerravati@beazley.com
Modification date:	      26-06-2024
Changes:	RI LPSO TTY Trifocus Splitting View Hot Fix for BIUSPE/ BERE https://beazley.atlassian.net/browse/I1B-5645		

*/
-- FX
WITH cte_fx AS
(
SELECT [fk_AccountingPeriod],
[fk_TransactionCurrency],
[FXRate]
FROM [fdm].[FactFXRate]
WHERE fk_FXRate = 2
and fk_RateScenario = 4
and fk_ReportingCurrency = 2
and fk_TransactionCurrency in ('GBP', 'EUR', 'USD', 'CAD')
and fk_AccountingPeriod between '201601' and left(convert(varchar, getdate(), 112), 6)
and right(fk_AccountingPeriod, 2) in ('03', '06', '09', '12')
),

-- RI Spend
cte_rispend_prep AS
(
SELECT EntityCode,
AccountingPeriod,
YOA,
RIProgramme,
TrifocusCode,
TrifocusName,
SettlementCurrency,
sum(sum(Amount)) OVER (PARTITION BY EntityCode,
										 RIProgramme,
										 YOA,
										 TrifocusCode,
										 SettlementCurrency
							ORDER BY AccountingPeriod ASC) Amount 
FROM
  (
      select 
      case when cen.Entity in ('BIFR', 'BIGE', 'BISP', 'BISW', 'BIUK', 'BIUSPE', 'BERE') then '8033' else ent.EntityCode end EntityCode,
      t.fk_AccountingPeriod AccountingPeriod,
      t.fk_YOA as YOA,
      isnull(prg.ifrs17_programme_group, ri.RIProgramme) as RIProgramme,
      tf.TrifocusCode,
      tf.TrifocusName,
	  t.currency SettlementCurrency,
      sum(t.cur_amount) as Amount
      from [fdm].[vw_FactFDMExternal] t
      join fdm.[DimAccount] acc on (acc.pk_Account = t.fk_Account)
      join fdm.[DimProcess] prc on (prc.pk_Process = t.fk_Process)
      join fdm.[DimEntity] ent on (ent.pk_Entity = t.fk_Entity)
      left join fdm.vw_DimRIPolicy ri on (ri.pk_RIPolicy = t.fk_RIPolicy)
      join fdm.DimTrifocus tf on (tf.pk_Trifocus = t.fk_TriFocus) 
	  left join mds.ConformedEntityMapping cen on (cen.Entity = ent.EntityCode)
	  left join mds.[RITypeMapping] tp on (tp.RIPolicyType = ri.RIType)
	  left join Eurobase.reinsurance_pol_det pol on (pol.rpd_policy_reference = ri.RIPolicyNumber)
	  left join Eurobase.rein_program_sequence prg on (prg.rps_program_id = pol.rpd_treaty_ri_code)
	  where acc.AccountCode = 'RI00001'
      and ri.RIAdjustment in ('RISPD', 'Reinsts')
	  and ri.RIProgramme <> 'MUNQQS'
      group by 
      case when cen.Entity in ('BIFR', 'BIGE', 'BISP', 'BISW', 'BIUK', 'BIUSPE', 'BERE') then '8033' else ent.EntityCode end,
	  isnull(prg.ifrs17_programme_group, ri.RIProgramme),
      t.fk_AccountingPeriod,
      t.fk_YOA,
      tf.TrifocusCode,
      tf.TrifocusName,
	  t.currency
	) t
group by
EntityCode,
AccountingPeriod,
YOA,
RIProgramme,
TrifocusCode,
TrifocusName,
SettlementCurrency

union all

select '8044' as EntityCode,
left(convert(varchar, DateOfFact, 112), 6) as AccountingPeriod,
t.YOA,
isnull(tty.ProgrammeCode, t.Programme) as RIProgramme,
tf.TrifocusCode,
tf.TrifocusName,
CCY as SettlementCurrency,
sum(Value)
from cededre.RISpendBESITabs t
left join Eurobase.vw_ReInsuranceTreatyContractAttributes tty
 on (tty.RI_Section_Reference = t.[RIRef])
left join fdm.DimTrifocus tf on (tf.TrifocusName = t.Trifocus)
group by left(convert(varchar, DateOfFact, 112), 6),
t.YOA,
isnull(tty.ProgrammeCode, t.Programme),
tf.TrifocusCode,
tf.TrifocusName,
CCY

)
,

cte_rispend
as
(
SELECT EntityCode,
left(convert(varchar, dateadd(quarter, 1, cast(cast(AccountingPeriod as varchar) + '01' as date)), 112), 6) as AccountingPeriod,
YOA,
RIProgramme,
TrifocusCode,
TrifocusName,
sum(Amount/ FX.FXRate) Amount
from cte_rispend_prep t
left join cte_fx fx on (fx.fk_AccountingPeriod = t.AccountingPeriod
							  and fx.fk_TransactionCurrency = t.SettlementCurrency)
group by EntityCode,
left(convert(varchar, dateadd(quarter, 1, cast(cast(AccountingPeriod as varchar) + '01' as date)), 112), 6),
YOA,
RIProgramme,
TrifocusCode,
TrifocusName
),


cte_mun_prep
as
(
select en.ConformedEntityMapping as EntityCode,
left(t.asat, 4) + 
case right(t.asat, 2) when '05' then '03'
					  when '11' then '09'
					  else right(t.asat, 2)

end AccountingPeriod,
cast(t.yoa as varchar) as YOA,
'MUNQQS' as RIProgramme,
tf.TrifocusCode,
t.triangle_group TrifocusName,
sum([Value]/ fx.FXRate) [Amount]
from adm.[Reserving_data] t
left join MDS.ConformedEntityMapping en on (en.Entity = cast(t.synd as varchar))
left join fdm.DimTrifocus tf on (tf.TrifocusName = t.triangle_group)
left join cte_fx fx on (fx.fk_AccountingPeriod = left(t.asat, 4) + case right(t.asat, 2) when '05' then '03'
																						 when '11' then '09'
																						 else right(t.asat, 2)

																	end 
						and fx.fk_TransactionCurrency = t.ccy)
where (right(t.asat, 2) in ('05', '06', '11', '12') or asat = '202003')
and special = 'Munich'
and datasetname = 'Team Premium'
and synd <> '8022'
group by en.ConformedEntityMapping,
left(t.asat, 4) + 
case right(t.asat, 2) when '05' then '03'
					  when '11' then '09'
					  else right(t.asat, 2)

end,
cast(t.yoa as varchar),
tf.TrifocusCode,
t.triangle_group
),

cte_mun
as
(
select EntityCode,
left(convert(varchar, dateadd(quarter, 1, cast(cast(AccountingPeriod as varchar) + '01' as date)), 112), 6) as AccountingPeriod,
YOA,
RIProgramme,
TrifocusCode,
TrifocusName,
[Amount]
from cte_mun_prep
where AccountingPeriod >= '201809'
and yoa >= left(AccountingPeriod, 4) - 2
and YOA <> 'NOYOA'
)
,


--SPA Prep

cte_spa
as
(
select EntityCode,
left(convert(varchar, dateadd(quarter, 1, cast(cast(AccountingPeriod as varchar) + '01' as date)), 112), 6) AccountingPeriod,
YOA,
RIProgramme,
TrifocusCode, 
TrifocusName,  
(Amount/FXRate) Amount
from
	(		

		select
		en.ConformedEntityMapping as EntityCode,
		AccountingPeriod,
		YOA,
		t.ProgrammeCode RIProgramme,
		t.TrifocusCode, 
		TrifocusName,  
		SettlementCCY,
		-sum(sum(Value)) over (partition by t.TrifocusCode, 
										TrifocusName,
										en.ConformedEntityMapping,
										YOA,
										t.ProgrammeCode,
										SettlementCCY
										order by AccountingPeriod asc) Amount
		
		 
		from spa.VW_SPA_5623FDM t
		join fdm.DimTrifocus tf on (tf.TrifocusCode = t.TrifocusCode)
		left join MDS.ConformedEntityMapping en on (en.Entity = t.Entity)
		group by AccountingPeriod,
		t.TrifocusCode, 
		TrifocusName, 
		en.ConformedEntityMapping,
		YOA,
		t.ProgrammeCode,
		SettlementCCY

		union all

		select
		en.ConformedEntityMapping as EntityCode,
		AccountingPeriod,
		YOA,
		t.ProgrammeCode RIProgramme,
		t.TrifocusCode, 
		TrifocusName,  
		SettlementCCY,
		sum(Value) Amount
		from spa.VW_SPA_5623PFT_22Q1 t
		join fdm.DimTrifocus tf on (tf.TrifocusCode = t.TrifocusCode)
		left join MDS.ConformedEntityMapping en on (en.Entity = t.Entity)
		group by AccountingPeriod,
		t.TrifocusCode, 
		TrifocusName, 
		en.ConformedEntityMapping,
		YOA,
		t.ProgrammeCode,
		SettlementCCY

		union all

		select
		en.ConformedEntityMapping as EntityCode,
		AccountingPeriod,
		YOA,
		t.ProgrammeCode RIProgramme,
		t.TrifocusCode, 
		TrifocusName,  
		SettlementCCY,
		sum(Value) Amount
		from spa.VW_SPA_6107PFT t
		join fdm.DimTrifocus tf on (tf.TrifocusCode = t.TrifocusCode)
		left join MDS.ConformedEntityMapping en on (en.Entity = t.Entity)
		group by AccountingPeriod,
		t.TrifocusCode, 
		TrifocusName, 
		en.ConformedEntityMapping,
		YOA,
		t.ProgrammeCode,
		SettlementCCY

	) t
left join cte_fx fx on (fx.fk_AccountingPeriod = t.AccountingPeriod
						and fx.fk_TransactionCurrency = t.SettlementCCY)
where t.YOA >= cast(AccountingPeriod/ 100 as int) -2
and cast(t.YOA as varchar) <> 'NOYOA'
),


--BICI
cte_bici
as
(
select en.ConformedEntityMapping as EntityCode,
left(convert(varchar, DateOfFact, 112), 6) AccountingPeriod,
t.YOA,
t.ProgrammeCode RIProgramme,
t.TrifocusCode, 
tf.TrifocusName,  
sum([Value]/ fx.FXRate) Amount
--from biciri.LandedTransformed_Ultimates t
from  [BICIRI].[vw_LandedTransformed_Ultimates] t
join fdm.DimTrifocus tf on (tf.TrifocusCode = t.TrifocusCode)
left join MDS.ConformedEntityMapping en on (en.Entity = t.Entity)
left join mds.[RITypeMapping] tp on (tp.RIPolicyType = t.RIPolicyType)
left join cte_fx fx on (fx.fk_AccountingPeriod = left(convert(varchar, t.DateOfFact, 112), 6)
						and fx.fk_TransactionCurrency = t.SettlementCCY)
where Dataset in 
('ObligatedPremium_SL/CyEx', 'ObligatedPremium_BICI_Historical', 'Munich_QQS')
and CAST (YOA AS VARCHAR(10)) >= CAST ( (Datepart(Year, DateOfFact) - 2) AS VARCHAR(10))
and YOA <> 'NOYOA'
group by en.ConformedEntityMapping,
left(convert(varchar, DateOfFact, 112), 6),
t.YOA,
t.ProgrammeCode,
t.TrifocusCode, 
tf.TrifocusName

union all

select en.ConformedEntityMapping as EntityCode,
left(convert(varchar, DateOfFact, 112), 6) AccountingPeriod,
t.YOA,
t.ProgrammeCode RIProgramme,
t.TrifocusCode, 
tf.TrifocusName,  
sum([Value]/ fx.FXRate) Amount
--from biciri.LandedTransformed_Ultimates t
from  [BICIRI].[vw_LandedTransformed_Ultimates] t
join fdm.DimTrifocus tf on (tf.TrifocusCode = t.TrifocusCode)
left join MDS.ConformedEntityMapping en on (en.Entity = t.Entity)
left join mds.[RITypeMapping] tp on (tp.RIPolicyType = t.RIPolicyType)
left join cte_fx fx on (fx.fk_AccountingPeriod = left(convert(varchar, t.DateOfFact, 112), 6)
						and fx.fk_TransactionCurrency = t.SettlementCCY)
where Dataset in 
('BICI_Earned_Agresso')
and CAST( YOA AS VARCHAR(10)) < CAST ( (Datepart(Year, DateOfFact) - 2) AS VARCHAR(10))
and YOA <> 'NOYOA'
group by en.ConformedEntityMapping,
left(convert(varchar, DateOfFact, 112), 6),
t.YOA,
t.ProgrammeCode,
t.TrifocusCode, 
tf.TrifocusName
),

--Ceded Re	  
ceded as 
(
select proc_period
,ritype
,cla_year_of_account
,isnull(cast(s.SyndSplitEntity as int), t.synd) synd
,cpl_pol_policy_reference
,COALESCE(t.DummyProgramme,prg.ifrs17_programme_group, t.programname) as programname
,clo_claim_currency
,trifocus
,t.masterriind
,sum(case when s.SyndSplitSource is not null then t.premium * s.SyndSplitPercentage else t.premium end) premium
,sum(case when s.SyndSplitSource is not null then t.overrider * s.SyndSplitPercentage else t.overrider end) overrider
FROM CededRe.vw_CededReAccessDB t
left join Eurobase.rein_program_sequence prg on (prg.rps_program_id = t.programname)
left join fdm.SyndicateSplitsbyYOA s
on (s.SyndSplitSource = cast(t.synd as varchar)
and s.SyndSplitYOA = t.cla_year_of_account
and cast(t.synd as varchar) in ('623', '2623', '1174'))
where (isnull(t.premium, 0) <> 0 or isnull(t.overrider, 0) <> 0)
group by proc_period
,ritype
,cla_year_of_account
,isnull(cast(s.SyndSplitEntity as int), t.synd)
,cpl_pol_policy_reference
,COALESCE(t.DummyProgramme,prg.ifrs17_programme_group, t.programname)
,clo_claim_currency
,trifocus,
t.masterriind
),

cte_cededre as
(
select cen.ConformedEntityMapping as [EntityCode],
convert(varchar(6), proc_period, 112) as [AccountingPeriod],
cla_year_of_account [YOA],
isnull(fpg.RIProgramme, programname) [RIProgramme],
ISNULL(tri.TrifocusCode,'Unknown') as [TrifocusCode],
trifocus as [TrifocusName],
-sum((isnull(premium, 0) + isnull(overrider, 0))/ fx.FXRate) as Amount -- 6017 Correction
from ceded as t 
left join fdm.DimTrifocus as tri ON CASE WHEN t.trifocus = 'Covers' THEN 'Covers US'
										 WHEN t.trifocus = 'Intl Specialty(PT)' THEN 'Intl Specialty (PT)'
										 WHEN t.trifocus = 'BBR Services Int(Exc PE)' THEN 'BBR Services Int (Exc PE)'
										 ELSE t.trifocus
									END = tri.TrifocusName
left join mds.FACPrgTrifocusMapping fpg on (fpg.TrifocusCode = tri.TrifocusCode and t.ritype = 'FAC')
left join cte_fx fx on (fx.fk_AccountingPeriod = left(convert(varchar, t.proc_period, 112), 6)
						and fx.fk_TransactionCurrency = t.clo_claim_currency)
left join mds.ConformedEntityMapping cen on (cen.Entity = cast(t.synd as varchar))
left join mds.[RITypeMapping] tp on (tp.RIPolicyType = t.ritype)
where 1=1
--ritype <> 'FAC'
group by cen.ConformedEntityMapping,
proc_period,
cla_year_of_account,
isnull(fpg.RIProgramme, programname),
ISNULL(tri.TrifocusCode,'Unknown'),
trifocus
having abs(sum(isnull(premium, 0) + isnull(overrider, 0))) > 1
),

--Master RI excl. BICI
cte_mstrri
as
(
select cast(t.synd as varchar) as EntityCode,
left(convert(varchar(6), t.proc_period, 112), 6) AccountingPeriod,
t.cla_year_of_account YOA, 
--prg.ifrs17_programme_group ProgrammeCode,
t.programname ProgrammeCode,
tf.TriFocusCode, 
t.trifocus TrifocusName, 
-sum((isnull(t.premium, 0) + isnull(t.overrider, 0))/ fx.FXRate) Amount,
-sum(sum((isnull(t.premium, 0) + isnull(t.overrider, 0))/ fx.FXRate)) over (partition by t.proc_period,
																						t.synd,
																						t.cla_year_of_account
																			) TotalAmount
from Ceded t --[CededRe].[vw_CededReAccessDB] t
--left join mds.Trifocus tf on (tf.[Name] = t.trifocus)
left join fdm.DimTrifocus as tf ON CASE WHEN t.trifocus = 'Covers' THEN 'Covers US'
										 WHEN t.trifocus = 'Intl Specialty(PT)' THEN 'Intl Specialty (PT)'
										 WHEN t.trifocus = 'BBR Services Int(Exc PE)' THEN 'BBR Services Int (Exc PE)'
										 ELSE t.trifocus
									END = tf.TrifocusName
--left join Eurobase.rein_program_sequence prg on (prg.rps_program_id = t.programname)
left join cte_fx fx on 
(
	fx.fk_AccountingPeriod = left(convert(varchar, t.proc_period, 112), 6)
	and fx.fk_TransactionCurrency = t.clo_claim_currency
)
where t.masterriind = 'Y'
group by t.proc_period,
t.programname,
--prg.ifrs17_programme_group, 
t.trifocus, 
tf.TriFocusCode, 
t.synd,
t.cla_year_of_account
having sum((isnull(t.premium, 0) + isnull(t.overrider, 0))/ fx.FXRate) <> 0
),

--Master RI BICI
cte_mstrri_bici
as
(
select  '8022' as EntityCode,
left(convert(varchar(6), t.DateOfFact, 112), 6) AccountingPeriod,
t.YOA,
t.ProgrammeCode,
t.TriFocusCode, 
tf.[Name] TrifocusName, 
sum([Value]) Amount,
sum(sum([Value])) over (partition by t.DateOfFact,
									 t.YOA) TotalAmount
--from [BICIRI].[LandedTransformed_Ultimates] t
from  [BICIRI].[vw_LandedTransformed_Ultimates] t
left join mds.Trifocus tf on (tf.TriFocusCode = t.TrifocusCode)
join
(
	select distinct DateOfFact, YOA, TrifocusCode 
	--from [BICIRI].[LandedTransformed_Ultimates]
	from  [BICIRI].[vw_LandedTransformed_Ultimates] 
	where Dataset = 'BICI_Earned_Agresso' 
	and ProgrammeCode = 'Master RI'
) tmstr on
(
	tmstr.TrifocusCode = t.TrifocusCode
	and tmstr.YOA = t.YOA
	and tmstr.DateOfFact = t.DateOfFact
)
where t.Dataset = 'BICI_Earned_Agresso'
and t.ProgrammeCode <> 'Master RI'
group by t.DateOfFact, 
t.TrifocusCode, 
tf.[Name],
t.YOA, 
ProgrammeCode
having sum([Value]) <> 0
),

cte_combined
as
(
select --source,
EntityCode,
AccountingPeriod,
YOA,
RIProgramme ProgrammeCode,
TrifocusCode,
TrifocusName,
sum(Amount) Amount,
sum(sum(Amount)) over (partition by EntityCode,
									AccountingPeriod,
									YOA,
									RIProgramme--,
									--source
									) TotalAmount,
'N' as MasterRIInd
from
	(
		select 'rispend' source, *
		from cte_rispend
		where isnull(Amount, 0) <> 0

		union all

		select 'munich', * 
		from cte_mun
		where isnull(Amount, 0) <> 0

		union all

		select 'spa', * 
		from cte_spa
		where isnull(Amount, 0) <> 0

		union all

		select 'bici', * 
		from cte_bici
		where isnull(Amount, 0) <> 0

		union all

		select 'cededre', *
		from cte_cededre
		--where YOA < cast(AccountingPeriod/ 100 as int) - 2
		where YOA < cast(left(AccountingPeriod, 4) as int) - case when right(AccountingPeriod, 2) = '03' then 3 else 2 end
		and isnull(Amount, 0) <> 0

	) t
where 1=1
--and AccountingPeriod >= '201812'
group by --source,
EntityCode,
AccountingPeriod,
YOA,
RIProgramme,
TrifocusCode,
TrifocusName

union all

select --source,
EntityCode,
AccountingPeriod,
YOA,
ProgrammeCode,
TrifocusCode,
TrifocusName,
Amount,
TotalAmount,
'Y' as MasterRIInd
from
	(
		select 'mstrri' as source, *
		from cte_mstrri
		where TotalAmount <> 0

		union all

		select 'mstrri_bici', *
		from cte_mstrri_bici
		where TotalAmount <> 0

	) t
--where 1=1
----AccountingPeriod >= '201812'
--group by EntityCode,
--AccountingPeriod,
--YOA,
--ProgrammeCode,
--TrifocusCode,
--TrifocusName
)

select --source,
EntityCode,
AccountingPeriod,
YOA,
ProgrammeCode,
TrifocusCode,
TrifocusName,
Amount, 
TotalAmount, 
MasterRIInd 

from cte_combined 
--where TotalAmount --is not NULL
GO


