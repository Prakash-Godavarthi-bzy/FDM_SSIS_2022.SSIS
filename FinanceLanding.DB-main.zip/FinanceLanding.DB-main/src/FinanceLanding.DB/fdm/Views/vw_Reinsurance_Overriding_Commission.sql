﻿CREATE VIEW [fdm].[vw_Reinsurance_Overriding_Commission]
	AS 
/* ===========================================================================================================
	Created By:		-
	Modified By : ShahNawaz.Ahmed@beazley.com
	Created date:	-
	Modified Date : 20/06/2024
	Description:	Used for ORC Dataset, Modified the where conditions to exclude BESI TF (https://beazley.atlassian.net/browse/I1B-5632)

	Modified By : lakshman.akasapu@beazley.com
	Modified Date : 24/06/2024
	Description:	Accounting Period pushed back for 1 quarter of the table fdm.AccountingPeriod.
	Jira : https://beazley.atlassian.net/browse/I1B-5614

=================================================================================================================== */
	SELECT 
			    DateOfFact = convert (DATE, concat (case when fk_AccountingPeriod <= 201809 then 201809 else fk_AccountingPeriod end,'01'), 102),
				Account = 'P-OR-P-' + CASE WHEN ri.RIType = 'FAC' THEN 'FAC' ELSE 'TTY' END ,
				RIPolicyNumber = rtrim(ri.RIPolicyNumber),
				TriFocus = tf.TrifocusCode , 
				TriFocusName = tf.TrifocusName ,
				ProgrammeCode = ri.RIProgramme ,
				Entity = en.EntityCode ,
				YOA = t.fk_YOA ,
				SettlementCCY = t.currency ,
				[Value] = t.cur_amount ,
				case when fk_AccountingPeriod <= 201809 then 201809 else fk_AccountingPeriod end as FK_AccountingPeriod,
				ri.RIType AS RIPolicyType,
			    ri.RIAdjustment
			FROM 
				[fdm].[vw_FactFDMExternal] t
				JOIN [fdm].[DimAccount] acc on acc.pk_Account = t.fk_Account and acc.AccountCode = 'RI00001'  
				JOIN [fdm].[DimProcess] dp on  dp.pk_Process = t.fk_Process
				LEFT JOIN [fdm].[vw_DimRIPolicy] ri on ri.pk_RIPolicy = t.fk_RIPolicy		
				LEFT JOIN [fdm].[DimTrifocus] tf on tf.pk_Trifocus = t.fk_TriFocus
				LEFT JOIN [fdm].[DimEntity] en on en.pk_Entity = t.fk_Entity
			WHERE
				1=1 and acc.AccountCode = 'RI00001'
				and dp.ProcessCode is null 
				and ri.RIAdjustment = 'ORC' 
				and t.cur_amount  <> 0 
				--and tf.TrifocusName not like 'BICI%'  ----I1B-3986
				and not
				(
				tf.TrifocusName like 'BICI%'  
				or
					(
						en.EntityCode <> 'BIUSPE' and tf.TrifocusName like 'BESI%'
					)
				) -- I1B-5632
				
				UNION ALL

				SELECT 
			    DateOfFact = d.dateofFact,
				Account = 'P-OR-P-' + CASE WHEN ri.RIType = 'FAC' THEN 'FAC' ELSE 'TTY' END ,
				RIPolicyNumber = rtrim(ri.RIPolicyNumber),
				TriFocus = tf.TrifocusCode , 
				TriFocusName = tf.TrifocusName ,
				ProgrammeCode = ri.RIProgramme ,
				Entity = en.EntityCode ,
				YOA = t.fk_YOA ,
				SettlementCCY = t.currency ,
				[Value] = 0 ,
				d.AccountingPeriod as FK_AccountingPeriod,
				ri.RIType AS RIPolicyType,
			    ri.RIAdjustment
			FROM 
				[fdm].[vw_FactFDMExternal] t  
				JOIN [fdm].[DimAccount] acc on acc.pk_Account = t.fk_Account and acc.AccountCode = 'RI00001' 
				JOIN [fdm].[DimProcess] dp on  dp.pk_Process = t.fk_Process		
				LEFT JOIN [fdm].[vw_DimRIPolicy] ri on ri.pk_RIPolicy = t.fk_RIPolicy		
				LEFT JOIN [fdm].[DimTrifocus] tf on tf.pk_Trifocus = t.fk_TriFocus
				LEFT JOIN [fdm].[DimEntity] en on en.pk_Entity = t.fk_Entity
				JOIN
				(
					SELECT distinct AccountingPeriod , LEFT(AccountingPeriod,4)+'-'+ RIGHT(AccountingPeriod,2)+'-01' AS  DateOfFact
					FROM fdm.AccountingPeriod
					WHERE AccountingPeriod between 201809 and convert(varchar(6), dateadd(quarter, -1, getdate()), 112)
					and right(AccountingPeriod,2) in ('03', '06', '09', '12')  
				) d ON d.AccountingPeriod > case when fk_AccountingPeriod <= 201809 then 201809 else fk_AccountingPeriod end
			WHERE
				1=1 and acc.AccountCode = 'RI00001' 
				and dp.ProcessCode is null 
				and ri.RIAdjustment = 'ORC' 
				and ISNULL(t.cur_amount,0)  <> 0 
				--and tf.TrifocusName not like 'BICI%' ----I1B-3986
				and not
						(
						tf.TrifocusName like 'BICI%'  
						or
							(
								en.EntityCode <> 'BIUSPE' and tf.TrifocusName like 'BESI%' 
							)
						) -- I1B-5632

GO