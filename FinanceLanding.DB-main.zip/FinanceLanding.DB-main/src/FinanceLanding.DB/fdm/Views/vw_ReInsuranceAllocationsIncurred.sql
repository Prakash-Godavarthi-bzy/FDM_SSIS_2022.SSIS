﻿
CREATE VIEW [fdm].[vw_ReInsuranceAllocationsIncurred]

/*=========================================================================================
Change Version	: 1.0
Sprint			: 24 Q3 COMMITTED
Author		    : ENTHA BHARGAV ENTHA.BHARGAV@Beazley.com || Pushpal Das
CREATE Date	    : 31/07/20204
Description		:  Allocations generating for Claim Cash Accounts https://beazley.atlassian.net/browse/I1B-5519
					Used in [Eurobase].[usp_LandingToInbound_TreatyReInsurance] RI LPSO TTY
===============================================================================================*/
AS

-- FX
WITH cte_fx
  AS (SELECT [fk_AccountingPeriod],
             [fk_TransactionCurrency],
             [FXRate]
        FROM [fdm].[FactFXRate]
       WHERE fk_FXRate            = 2
         and fk_RateScenario      = 4
         and fk_ReportingCurrency = 2
         and fk_TransactionCurrency in ( 'GBP', 'EUR', 'USD', 'CAD' )
         and fk_AccountingPeriod between '201601' and left(convert(varchar, getdate(), 112), 6)
         and right(fk_AccountingPeriod, 2) in ( '03', '06', '09', '12' )
		 ),
     --Ceded Re	  
     ceded
  as (select proc_period,
             ritype,
             cla_year_of_account,
             isnull(cast(s.SyndSplitEntity as int), t.synd) synd,
             cpl_pol_policy_reference,
             COALESCE(t.DummyProgramme, prg.ifrs17_programme_group, t.programname) as programname,
             clo_claim_currency,
             trifocus,
             t.masterriind,
             sum(case
                      when s.SyndSplitSource is not null then
                 (isnull([paidnetbd], 0) + isnull([facpaidaccrual], 0) + isnull([osaccrualsnetbd], 0))
                 * s.SyndSplitPercentage
                      else t.premium end) Incurred
        FROM CededRe.vw_CededReAccessDB t
        left join Eurobase.rein_program_sequence prg
          on (prg.rps_program_id   = t.programname)
        left join fdm.SyndicateSplitsbyYOA s
          on (   s.SyndSplitSource = cast(t.synd as varchar)
           and   s.SyndSplitYOA    = t.cla_year_of_account
           and   cast(t.synd as varchar) in ( '623', '2623', '1174' ))
       where (   isnull([paidnetbd], 0)       <> 0
            or   isnull([facpaidaccrual], 0)  <> 0
            or   isnull([osaccrualsnetbd], 0) <> 0)
         and t.synd                           <> 8022
       group by proc_period,
                ritype,
                cla_year_of_account,
                isnull(cast(s.SyndSplitEntity as int), t.synd),
                cpl_pol_policy_reference,
                COALESCE(t.DummyProgramme, prg.ifrs17_programme_group, t.programname),
                clo_claim_currency,
                trifocus,
                t.masterriind
		),
     cte_cededre
  as (select cen.ConformedEntityMapping as [EntityCode],
             convert(varchar(6), proc_period, 112) as [AccountingPeriod],
             cla_year_of_account [YOA],
             isnull(fpg.RIProgramme, programname) [RIProgramme],
             ISNULL(tri.TrifocusCode, 'Unknown') as [TrifocusCode],
             trifocus as [TrifocusName],
             -sum(t.Incurred / fx.FXRate) as Amount
        from ceded as t
        left join fdm.DimTrifocus as tri
          ON CASE
                  WHEN t.trifocus = 'Covers' THEN 'Covers US'
                  WHEN t.trifocus = 'Intl Specialty(PT)' THEN 'Intl Specialty (PT)'
                  WHEN t.trifocus = 'BBR Services Int(Exc PE)' THEN 'BBR Services Int (Exc PE)'
                  ELSE t.trifocus END      = tri.TrifocusName
        left join mds.FACPrgTrifocusMapping fpg
          on (   fpg.TrifocusCode          = tri.TrifocusCode
           and   t.ritype                  = 'FAC')
        left join cte_fx fx
          on (   fx.fk_AccountingPeriod    = left(convert(varchar, t.proc_period, 112), 6)
           and   fx.fk_TransactionCurrency = t.clo_claim_currency)
        left join mds.ConformedEntityMapping cen
          on (cen.Entity                   = cast(t.synd as varchar))
        left join mds.[RITypeMapping] tp
          on (tp.RIPolicyType              = t.ritype)
       where 1 = 1
       group by cen.ConformedEntityMapping,
                proc_period,
                cla_year_of_account,
                isnull(fpg.RIProgramme, programname),
                ISNULL(tri.TrifocusCode, 'Unknown'),
                trifocus
      having abs(sum(t.Incurred)) > 1
	  ),
     --BICI
     cte_bici
  as (select en.ConformedEntityMapping as EntityCode,
             left(convert(varchar, DateOfFact, 112), 6) AccountingPeriod,
             t.YOA,
             t.ProgrammeCode RIProgramme,
             t.TrifocusCode,
             tf.TrifocusName,
             sum([Value] / fx.FXRate) Amount
        from [BICIRI].[vw_LandedTransformed_Ultimates] t
        join fdm.DimTrifocus tf
          on (tf.TrifocusCode              = t.TrifocusCode)
        left join MDS.ConformedEntityMapping en
          on (en.Entity                    = t.Entity)
        left join mds.[RITypeMapping] tp
          on (tp.RIPolicyType              = t.RIPolicyType)
        left join cte_fx fx
          on (   fx.fk_AccountingPeriod    = left(convert(varchar, t.DateOfFact, 112), 6)
           and   fx.fk_TransactionCurrency = t.SettlementCCY)
       where Dataset in ( 'BICI_RI_Incurred' )
         --and CAST( YOA AS VARCHAR(10)) < CAST ( (Datepart(Year, DateOfFact) - 2) AS VARCHAR(10))
         and YOA <> 'NOYOA'
       group by en.ConformedEntityMapping,
                left(convert(varchar, DateOfFact, 112), 6),
                t.YOA,
                t.ProgrammeCode,
                t.TrifocusCode,
                tf.TrifocusName
		),
     --Master RI excl. BICI
     cte_mstrri
  as (select cast(t.synd as varchar) as EntityCode,
             left(convert(varchar(6), t.proc_period, 112), 6) AccountingPeriod,
             t.cla_year_of_account YOA,
             t.programname ProgrammeCode,
             tf.TriFocusCode,
             t.trifocus TrifocusName,
             -sum(t.Incurred / fx.FXRate) Amount,
             -sum(sum(t.Incurred / fx.FXRate)) over (partition by t.proc_period, t.synd, t.cla_year_of_account) TotalAmount
        from Ceded t
        left join fdm.DimTrifocus as tf
          ON CASE
                  WHEN t.trifocus = 'Covers' THEN 'Covers US'
                  WHEN t.trifocus = 'Intl Specialty(PT)' THEN 'Intl Specialty (PT)'
                  WHEN t.trifocus = 'BBR Services Int(Exc PE)' THEN 'BBR Services Int (Exc PE)'
                  ELSE t.trifocus END      = tf.TrifocusName
        left join cte_fx fx
          on (   fx.fk_AccountingPeriod    = left(convert(varchar, t.proc_period, 112), 6)
           and   fx.fk_TransactionCurrency = t.clo_claim_currency)
       where t.masterriind = 'Y'
       group by t.proc_period,
                t.programname,
                --prg.ifrs17_programme_group, 
                t.trifocus,
                tf.TriFocusCode,
                t.synd,
                t.cla_year_of_account
      having sum(t.Incurred / fx.FXRate) <> 0
	  ),
     --Master RI BICI
     cte_mstrri_bici
  as (select '8022' as EntityCode,
             left(convert(varchar(6), t.DateOfFact, 112), 6) AccountingPeriod,
             t.YOA,
             t.ProgrammeCode,
             t.TriFocusCode,
             tf.[Name] TrifocusName,
             sum([Value]) Amount,
             sum(sum([Value])) over (partition by t.DateOfFact, t.YOA) TotalAmount
        --from [BICIRI].[LandedTransformed_Ultimates] t
        from [BICIRI].[vw_LandedTransformed_Ultimates] t
        left join mds.Trifocus tf
          on (tf.TriFocusCode       = t.TrifocusCode)
        join (   select distinct DateOfFact,
                        YOA,
                        TrifocusCode
                   --from [BICIRI].[LandedTransformed_Ultimates]
                   from [BICIRI].[vw_LandedTransformed_Ultimates]
                  where Dataset       = 'BICI_RI_Incurred'
                    and ProgrammeCode = 'Master RI') tmstr
          on (   tmstr.TrifocusCode = t.TrifocusCode
           and   tmstr.YOA          = t.YOA
           and   tmstr.DateOfFact   = t.DateOfFact)
       where t.Dataset       = 'BICI_RI_Incurred'
         and t.ProgrammeCode <> 'Master RI'
       group by t.DateOfFact,
                t.TrifocusCode,
                tf.[Name],
                t.YOA,
                ProgrammeCode
      having sum([Value]) <> 0
	  ),
     cte_combined
  as (select --source,
             EntityCode,
             AccountingPeriod,
             YOA,
             RIProgramme ProgrammeCode,
             TrifocusCode,
             TrifocusName,
             sum(Amount) Amount,
             sum(sum(Amount)) over (partition by EntityCode,
                                                 AccountingPeriod,
                                                 YOA,
                                                 RIProgramme --,
             --source
             ) TotalAmount,
             'N' as MasterRIInd
        from (   select 'cededre' source,
                        *
                   from cte_cededre
                  --where YOA < cast(left(AccountingPeriod, 4) as int) - case when right(AccountingPeriod, 2) = '03' then 3 else 2 end
                  where isnull(Amount, 0) <> 0
                 union all
                 select 'bici',
                        *
                   from cte_bici
                  where isnull(Amount, 0) <> 0) t
       where 1 = 1
       group by --source,
          EntityCode,
          AccountingPeriod,
          YOA,
          RIProgramme,
          TrifocusCode,
          TrifocusName
      union all
      select --source,
             EntityCode,
             AccountingPeriod,
             YOA,
             ProgrammeCode,
             TrifocusCode,
             TrifocusName,
             Amount,
             TotalAmount,
             'Y' as MasterRIInd
        from (   select 'mstrri' as source,
                        *
                   from cte_mstrri
                  where TotalAmount <> 0
                 union all
                 select 'mstrri_bici',
                        *
                   from cte_mstrri_bici
                  where TotalAmount <> 0) t )
select --source,
       EntityCode,
       AccountingPeriod,
       YOA,
       ProgrammeCode,
       TrifocusCode,
       TrifocusName,
       Amount,
       TotalAmount,
       --cast(null as numeric) as Amount_Premium,
       --cast(null as numeric) as TotalAmount_Premium,
       MasterRIInd
  from cte_combined

/*
select --source,
EntityCode,
AccountingPeriod,
YOA,
ProgrammeCode,
TrifocusCode,
TrifocusName,
case when sum(Amount_Incurred) is not null then  Amount_Incurred, 
sum(TotalAmount_Incurred) TotalAmount_Incurred, 
sum(Amount_Premium) Amount_Premium,
sum(TotalAmount_Premium) TotalAmount_Premium,
MasterRIInd into #tmp --drop table #tmp
from
(
select --source,
EntityCode,
AccountingPeriod,
YOA,
ProgrammeCode,
TrifocusCode,
TrifocusName,
Amount Amount_Incurred, 
TotalAmount TotalAmount_Incurred, 
cast(null as numeric) as Amount_Premium,
cast(null as numeric) as TotalAmount_Premium,
MasterRIInd 
from cte_combined --Incurred

union all

select --source,
EntityCode,
AccountingPeriod,
YOA,
ProgrammeCode,
TrifocusCode,
TrifocusName,
cast(null as numeric),
cast(null as numeric),
Amount, 
TotalAmount, 
MasterRIInd 
from FinanceLanding.fdm.vw_ReInsuranceAllocationsGeneric
) t
group by EntityCode,
AccountingPeriod,
YOA,
ProgrammeCode,
TrifocusCode,
TrifocusName,
MasterRIInd 


GO

select *
from #tmp
*/

GO
