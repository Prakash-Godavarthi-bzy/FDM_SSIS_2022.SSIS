﻿
CREATE VIEW [fdm].[vw_RIPercentage]
AS
--Munich Prep
-- ====================================================================================================================================================================================
-- Modified by:			ShahNawaz.Ahmed@beazley.com
-- Modification date:	      14-05-2024
-- Changes:				Changed from EntityCode to add 8044	https://beazley.atlassian.net/browse/I1B-5447

-- Modified by:			Venkat.Yerravati@beazley.com
-- Modification date:	      29-01-2024
-- Changes:				Changed from EntityCode to ConformedEntityMapping https://beazley.atlassian.net/browse/I1B-5060
-- ====================================================================================================================================================================================	
WITH cte_mun
AS (
	SELECT Trifocus
		,YOA
		,dateadd(quarter, 1, cast(asat + '01' AS DATE)) DateOfFact
		,Entity
		,SettlementCCY
		,[value]
	FROM (
		SELECT triangle_group AS Trifocus
			,cast(t.yoa AS VARCHAR) AS YOA
			,left(t.asat, 4) + CASE right(t.asat, 2)
				WHEN '05'
					THEN '03'
				WHEN '11'
					THEN '09'
				ELSE right(t.asat, 2)
				END asat
			,en.ConformedEntityMapping AS Entity
			,ccy AS SettlementCCY
			,sum([Value]) [value]
		FROM adm.[Reserving_data] t
		LEFT JOIN MDS.ConformedEntityMapping en ON (en.Entity = cast(t.synd AS VARCHAR))
		WHERE (
				right(t.asat, 2) IN (
					'05'
					,'06'
					,'11'
					,'12'
					)
				OR asat = '202003'
				)
			AND special = 'Munich'
			AND datasetname = 'Team Premium'
			AND synd <> '8022'
		GROUP BY triangle_group
			,t.yoa
			,left(t.asat, 4) + CASE right(t.asat, 2)
				WHEN '05'
					THEN '03'
				WHEN '11'
					THEN '09'
				ELSE right(t.asat, 2)
				END
			,en.ConformedEntityMapping
			,ccy
		) t
	WHERE asat >= '201809'
		AND yoa >= left(asat, 4) - 2
	)
	,
	--SPA Prep
cte_cede
AS (
	SELECT DISTINCT cast(datepart(year, [Inception_Date]) AS INT) AS YOA
		,[Average_QS_%] / 100 AS Cede
	FROM [Eurobase].[vw_ReInsuranceTreatyContractAttributes]
	WHERE ProgrammeCode = 'Cede 5623'
	)
	,
	--BICI Prep
cte_bicisl
AS (
	SELECT 'SL Facultative spend' ProgrammeCode
		,'RAD' ClaimSBasis
	
	UNION ALL
	
	SELECT 'MUNICH - Surplus'
		,'RAD'
	
	UNION ALL
	
	SELECT 'FIDOML QS'
		,'RAD'
	
	UNION ALL
	
	SELECT 'US Small Risks XL'
		,'RAD'
	
	UNION ALL
	
	SELECT 'Cyber QS'
		,'RAD'
	
	UNION ALL
	
	SELECT 'Environmental QS'
		,'RAD'
	
	UNION ALL
	
	SELECT 'A&E Lawyers QS'
		,'RAD'
	
	UNION ALL
	
	SELECT 'SLCyEx QS2'
		,'RAD'
	
	UNION ALL
	
	SELECT 'Cyber Cat'
		,'CMD'
	
	UNION ALL
	
	SELECT 'CUNA QS'
		,'RAD'
	
	UNION ALL
	
	SELECT 'SLCyEx QS1'
		,'RAD'
	
	UNION ALL
	
	SELECT 'Professions'
		,'RAD'
	
	UNION ALL
	
	SELECT 'Systemic cover - Clash'
		,'CMD'
	
	UNION ALL
	
	SELECT 'BICI Risk & Agg XL'
		,'LOD'
	
	UNION ALL
	
	SELECT 'SLCyEx QS1 - TRC'
		,'RAD'
	
	UNION ALL
	
	SELECT 'MUNQQS'
		,'RAD'
	)
	,cte_bici
AS (
	SELECT left(convert(VARCHAR, DateOfFact, 112), 6) AccountingPeriod
		,t.TrifocusCode
		,tf.TrifocusName
		,'8022' AS Entity
		,t.yoa YOA
		,t.ProgrammeCode
		,t.RIPolicyType
		,isnull(nullif(t.SettlementCCY, ''), 'USD') SettlementCCY
		,t.PolicyNumber
		,isnull(pol.rpd_ri_pol_prd_from, cast(yoa + '0101' AS DATE)) InceptionDate
		,isnull(pol.rpd_ri_pol_prd_to, cast(yoa + '1231' AS DATE)) AS ExpiryDate
		,isnull(pol.rpd_ri_claims_basis, sl.ClaimSBasis) ClaimsBasis
		,sum(t.[value]) Premium
	FROM [BICIRI].[vw_LandedTransformed_Ultimates] t
	LEFT JOIN fdm.DimTrifocus tf ON (tf.TrifocusCode = t.TrifocusCode)
	LEFT JOIN Eurobase.reinsurance_pol_det pol ON (
			pol.rpd_policy_reference = t.PolicyNumber
			AND t.PolicyNumber <> 'NOPOLICY'
			)
	LEFT JOIN cte_bicisl sl ON (
			sl.ProgrammeCode = t.ProgrammeCode
			AND t.PolicyNumber = 'NOPOLICY'
			)
	WHERE t.Dataset IN (
			'ObligatedPremium_SL/CyEx'
			,'Munich_QQS'
			,'ObligatedPremium_BICI_Historical'
			)
	GROUP BY left(convert(VARCHAR, DateOfFact, 112), 6)
		,t.TrifocusCode
		,tf.TrifocusName
		,t.yoa
		,t.ProgrammeCode
		,t.RIPolicyType
		,t.SettlementCCY
		,t.PolicyNumber
		,isnull(pol.rpd_ri_pol_prd_from, cast(yoa + '0101' AS DATE))
		,isnull(pol.rpd_ri_pol_prd_to, cast(yoa + '1231' AS DATE))
		,isnull(pol.rpd_ri_claims_basis, sl.ClaimSBasis)
	)
	,
	--All RI Query
cte_ri
AS (
	SELECT t_all.*
	FROM (
		--Munich
		SELECT left(convert(VARCHAR, DateOfFact, 112), 6) AccountingPeriod
			,tf.TrifocusCode
			,t.Trifocus TrifocusName
			,t.Entity Entity
			,t.yoa YOA
			,'MUNQQS' AS RIProgramme
			,'QS' AS RIType
			,t.SettlementCCY
			,'NOPOLICY' AS RIPolicyNumber
			,cast(cast(t.YOA AS VARCHAR) + CASE 
					WHEN t.YOA = 1998
						THEN '0401'
					ELSE '0101'
					END AS DATE) AS InceptionDate
			,cast(cast(t.YOA AS VARCHAR) + '1231' AS DATE) AS ExpiryDate
			,'RAD' AS ClaimsBasis
			,t.[value] Premium --,
			--'NA' as RIFlag
		FROM cte_mun t
		JOIN fdm.DimTrifocus tf ON (tf.TrifocusName = t.Trifocus)
		WHERE t.[value] <> 0
		
		UNION ALL
		
		--BICI
		SELECT * --,'NA' as RIFlag
		FROM cte_bici
		WHERE yoa >= left(AccountingPeriod, 4) - 2
		
		UNION ALL
		
		--RI Spend General
		SELECT left(convert(VARCHAR, dateadd(quarter, 1, cast(cast(AccountingPeriod AS VARCHAR) + '01' AS DATE)), 112), 6) AccountingPeriod
			,TrifocusCode
			,TrifocusName
			,ConformedEntityMapping AS Entity
			,YOA
			,RIProgramme
			,RIType
			,SettlementCCY
			,RIPolicyNumber
			,InceptionDate
			,ExpiryDate
			,ClaimsBasis
			,sum(sum(Premium)) OVER (
				PARTITION BY TrifocusCode
				,TrifocusName
				,ConformedEntityMapping
				,YOA
				,SettlementCCY
				,
				--RIProgramme,
				--RIType,
				RIPolicyNumber ORDER BY AccountingPeriod ASC
				) Premium --,
			--'NA' as RIFlag
		FROM (
			SELECT t.fk_AccountingPeriod AccountingPeriod
				,tf.TrifocusCode
				,tf.TrifocusName
				,cen.ConformedEntityMapping
				,t.fk_YOA YOA
				,max(isnull(prg.ifrs17_programme_group, ri.RIProgramme)) RIProgramme
				,max(isnull(ty.Confirmed_RIPolicyType, isnull(pdet.rpd_rein_policy_type, CASE 
								WHEN ri.RIPolicyNumber IN (
										'COMBPTY'
										,'COMBTTY'
										)
									THEN 'XL'
								ELSE ri.RIType
								END))) RIType
				,t.currency AS SettlementCCY
				,ri.RIPolicyNumber
				,min(isnull(pdet.rpd_ri_pol_prd_from, ri.InceptionDate)) InceptionDate
				,max(isnull(pdet.rpd_ri_pol_prd_to, ri.ExpiryDate)) ExpiryDate
				,max(isnull(rpd_ri_claims_basis, ri.RIBasis)) ClaimsBasis
				,sum(t.cur_amount) Premium --,
				--0 AS GrossUltimates
			FROM fdm.vw_FactFDMExternal t --fdm.FactFDMExternal_History t
			JOIN fdm.[DimAccount] acc ON (acc.pk_Account = t.fk_Account)
			JOIN fdm.[DimProcess] prc ON (prc.pk_Process = t.fk_Process)
			LEFT JOIN fdm.vw_DimRIPolicy ri ON (ri.pk_RIPolicy = t.fk_RIPolicy)
			LEFT JOIN fdm.DimTrifocus tf ON (tf.pk_Trifocus = t.fk_TriFocus)
			LEFT JOIN fdm.DimEntity en ON (en.pk_Entity = t.fk_Entity)
			LEFT JOIN Eurobase.reinsurance_pol_det pdet ON (pdet.rpd_policy_reference = ri.RIPolicyNumber)
			LEFT JOIN Eurobase.rein_program_sequence prg ON (prg.rps_program_id = pdet.rpd_treaty_ri_code)
			LEFT JOIN mds.RITypeMapping ty ON (ty.RIPolicyType = isnull(pdet.rpd_rein_policy_type, ri.RIType))
			LEFT JOIN MDS.ConformedEntityMapping cen ON (cen.Entity = en.EntityCode)
			WHERE acc.AccountCode = 'RI00001'
				AND ri.RIAdjustment IN (
					'RISPD'
					,'Reinsts'
					)
			GROUP BY t.fk_AccountingPeriod
				,tf.TrifocusCode
				,tf.TrifocusName
				,cen.ConformedEntityMapping
				,t.fk_YOA
				,ri.RIPolicyNumber
				,t.currency
			) t_risp
		--where t_risp.RIProgramme <> 'MUNQQS'
		GROUP BY AccountingPeriod
			,TrifocusCode
			,TrifocusName
			,ConformedEntityMapping
			,YOA
			,RIProgramme
			,RIType
			,SettlementCCY
			,RIPolicyNumber
			,InceptionDate
			,ExpiryDate
			,ClaimsBasis
		
		UNION ALL

		--RI Spend BESI 5447
		select left(convert(varchar, dateadd(quarter, 1, DateOfFact), 112), 6) as AccountingPeriod,
		tf.TrifocusCode,
		tf.TrifocusName,
		'8044' as Entity,
		t.YOA,
		isnull(tty.ProgrammeCode, t.Programme) as RIProgramme,
		t.Type RIType,
		t.CCY as SettlementCurrency,
		t.[RIRef],
		t.InceptionDate,
		t.ExpiryDate,
		t.Basis,
		sum(Value)
		from cededre.RISpendBESITabs t
		left join Eurobase.vw_ReInsuranceTreatyContractAttributes tty
			on (tty.RI_Section_Reference = t.[RIRef])
		left join fdm.DimTrifocus tf on (tf.TrifocusName = t.Trifocus)
		group by left(convert(varchar, dateadd(quarter, 1, DateOfFact), 112), 6),
		tf.TrifocusCode,
		tf.TrifocusName,
		t.YOA,
		isnull(tty.ProgrammeCode, t.Programme),
		t.Type,
		t.CCY,
		t.[RIRef],
		t.InceptionDate,
		t.ExpiryDate,
		t.Basis
		
		union all

		--SPA's PF00004 account
		select left(convert(VARCHAR, dateadd(quarter, 1, cast(cast(AccountingPeriod AS VARCHAR) + '01' AS DATE)), 112), 6) AccountingPeriod
			,t.TrifocusCode
			,TrifocusName
			,en.ConformedEntityMapping AS Entity
			,t.YOA
			,t.ProgrammeCode RIProgramme
			,t.RIPolicyType RIType
			,SettlementCCY
			,'NOPOLICY' AS RIPolicyNumber
			,cast(cast(YOA as varchar) + '0101' AS DATE) AS InceptionDate
			,cast(cast(YOA as varchar) + '1231' AS DATE) AS ExpiryDate
			,'RAD' AS ClaimsBasis
			,- sum(sum([Value])) OVER (
				PARTITION BY t.TrifocusCode
				,TrifocusName
				,en.ConformedEntityMapping
				,YOA
				,SettlementCCY
				,t.ProgrammeCode
				,t.RIPolicyType ORDER BY AccountingPeriod ASC
				) Premium --,
		from spa.VW_SPA_5623FDM t --5447
		left join fdm.DimTrifocus tf ON (tf.TrifocusCode = t.TrifocusCode)
		left join MDS.ConformedEntityMapping en ON (en.Entity = t.Entity)
		GROUP BY AccountingPeriod
			,t.TrifocusCode
			,TrifocusName
			,en.ConformedEntityMapping
			,t.YOA
			,t.ProgrammeCode
			,t.RIPolicyType
			,SettlementCCY
		
		UNION ALL
		
		SELECT left(convert(VARCHAR, dateadd(quarter, 1, cast(cast(t.AccountingPeriod AS VARCHAR) + '01' AS DATE)), 112), 6) AccountingPeriod
			,t.[TriFocusCode]
			,tf.TrifocusName
			,t.[Entity]
			,t.[YOA]
			,t.ProgrammeCode
			,t.RIPolicyType
			,t.SettlementCCY
			,'NOPOLICY' AS RIPolicyNumber
			,cast(t.YOA + '0101' AS DATE) AS InceptionDate
			,cast(t.YOA + '1231' AS DATE) AS ExpiryDate
			,'RAD' AS ClaimsBasis
			,sum(t.[Value]) [Value]
		FROM spa.Vw_SPA_5623PFT_22Q1 t	--5447
		--JOIN cte_cede cede ON (cede.YOA = t.YOA)
		LEFT JOIN fdm.DimTrifocus tf ON (tf.TrifocusCode = t.TrifocusCode)
		GROUP BY left(convert(VARCHAR, dateadd(quarter, 1, cast(cast(t.AccountingPeriod AS VARCHAR) + '01' AS DATE)), 112), 6)
			,t.[TriFocusCode]
			,tf.TrifocusName
			,t.[Entity]
			,t.[YOA]
			,t.ProgrammeCode
			,t.RIPolicyType
			,t.SettlementCCY
		
		UNION ALL
		
		SELECT left(convert(VARCHAR, dateadd(quarter, 1, cast(cast(t.AccountingPeriod AS VARCHAR) + '01' AS DATE)), 112), 6) AccountingPeriod
			,t.[TriFocusCode]
			,tf.TrifocusName
			,t.[Entity]
			,t.[YOA]
			,t.ProgrammeCode
			,t.RIPolicyType
			,t.SettlementCCY
			,'NOPOLICY' AS RIPolicyNumber
			,cast(YOA + '0101' AS DATE) AS InceptionDate
			,cast(YOA + '1231' AS DATE) AS ExpiryDate
			,'RAD' AS ClaimsBasis
			,sum([Value]) [Value]
		FROM spa.VW_SPA_6107PFT t		--5447
		LEFT JOIN fdm.DimTrifocus tf ON (tf.TrifocusCode = t.TrifocusCode)
		GROUP BY left(convert(VARCHAR, dateadd(quarter, 1, cast(cast(t.AccountingPeriod AS VARCHAR) + '01' AS DATE)), 112), 6)
			,t.[TriFocusCode]
			,tf.TrifocusName
			,t.[Entity]
			,t.[YOA]
			,t.ProgrammeCode
			,t.RIPolicyType
			,t.SettlementCCY
		) t_all
	WHERE 1 = 1
		AND AccountingPeriod >= '201812'
		AND YOA >= 2016
	)
	,
	--select * from cte_ri
cte_gnp
AS (
	SELECT left(convert(VARCHAR, dateadd(quarter, 1, cast(cast(AccountingPeriod AS VARCHAR) + '01' AS DATE)), 112), 6) AccountingPeriod
		,TrifocusCode
		,TrifocusName
		,Entity
		,YOA
		,RIProgramme
		,RIType
		,SettlementCCY
		,sum(sum(isnull(Premium, 0))) OVER (
			PARTITION BY TrifocusCode
			,TrifocusName
			,Entity
			,YOA
			,SettlementCCY
			,RIProgramme
			,RIType
			,RIFlag ORDER BY AccountingPeriod ASC
			) Premium
		,RIFlag
	FROM (
		SELECT t.fk_AccountingPeriod AccountingPeriod
			,tf.TrifocusCode
			,tf.TrifocusName
			,cen.ConformedEntityMapping Entity
			,cast(t.fk_YOA AS VARCHAR) YOA
			,'GROSS' AS RIProgramme
			,'GROSS' AS RIType
			,t.currency AS SettlementCCY
			,SUM(t.cur_amount) Premium
			,'Gross Gross' AS RIFlag
		FROM fdm.FactFDMExternal_History t
		JOIN fdm.[DimAccount] acc ON (acc.pk_Account = t.fk_Account)
		JOIN fdm.[DimProcess] prc ON (prc.pk_Process = t.fk_Process)
		LEFT JOIN fdm.vw_DimRIPolicy ri ON (ri.pk_RIPolicy = t.fk_RIPolicy)
		LEFT JOIN fdm.DimTrifocus tf ON (tf.pk_Trifocus = t.fk_TriFocus)
		LEFT JOIN fdm.DimEntity en ON (en.pk_Entity = t.fk_Entity)
		LEFT JOIN mds.ConformedEntityMapping cen ON (cen.Entity = en.EntityCode)
		WHERE acc.AccountCode = 'PF00001'
			AND t.fk_YOA >= left(t.fk_AccountingPeriod, 4) - 2
		GROUP BY t.fk_AccountingPeriod
			,tf.TrifocusCode
			,tf.TrifocusName
			,cen.ConformedEntityMapping
			,t.fk_YOA
			,t.currency
		
		UNION ALL
		
		SELECT t.fk_AccountingPeriod AccountingPeriod
			,tf.TrifocusCode
			,tf.TrifocusName
			,cen.ConformedEntityMapping Entity
			,cast(t.fk_YOA AS VARCHAR) YOA
			,'GROSS' AS RIProgramme
			,'GROSS' AS RIType
			,t.currency AS SettlementCCY
			,SUM(t.cur_amount) Premium
			,'Gross Net' AS RIFlag
		FROM fdm.FactFDMExternal_History t
		JOIN fdm.[DimAccount] acc ON (acc.pk_Account = t.fk_Account)
		JOIN fdm.[DimProcess] prc ON (prc.pk_Process = t.fk_Process)
		LEFT JOIN fdm.vw_DimRIPolicy ri ON (ri.pk_RIPolicy = t.fk_RIPolicy)
		LEFT JOIN fdm.DimTrifocus tf ON (tf.pk_Trifocus = t.fk_TriFocus)
		LEFT JOIN fdm.DimEntity en ON (en.pk_Entity = t.fk_Entity)
		LEFT JOIN mds.ConformedEntityMapping cen ON (cen.Entity = en.EntityCode)
		WHERE acc.AccountCode = 'PF00004'
			AND t.fk_YOA >= left(t.fk_AccountingPeriod, 4) - 2
		GROUP BY t.fk_AccountingPeriod
			,tf.TrifocusCode
			,tf.TrifocusName
			,cen.ConformedEntityMapping
			,t.fk_YOA
			,t.currency
		) t_gen
	GROUP BY AccountingPeriod
		,TrifocusCode
		,TrifocusName
		,Entity
		,YOA
		,RIProgramme
		,RIType
		,SettlementCCY
		,RIFlag
	
	UNION ALL
	
	SELECT '202206' AS AccountingPeriod
		,t.[TriFocusCode]
		,tf.TrifocusName
		,cen.ConformedEntityMapping [Entity]
		,t.[YOA]
		,'GROSS' AS RIProgramme
		,'GROSS' AS RIType
		,[TranCurr] SettlementCCY
		,- sum([GGP]) Premium
		,'Gross Gross' AS RIFlag
	FROM [pft].[PFT_SYND_WITH_CEDE] t
	LEFT JOIN fdm.DimTrifocus tf ON (tf.TrifocusCode = t.TrifocusCode)
	LEFT JOIN mds.ConformedEntityMapping cen ON (cen.Entity = t.Entity)
	WHERE ReviewCycle = '2022Q1'
	GROUP BY t.[TriFocusCode]
		,tf.TrifocusName
		,cen.ConformedEntityMapping
		,t.[YOA]
		,[TranCurr]
	
	UNION ALL
	
	SELECT '202206' AS AccountingPeriod
		,t.[TriFocusCode]
		,tf.TrifocusName
		,cen.ConformedEntityMapping [Entity]
		,t.[YOA]
		,'GROSS' AS RIProgramme
		,'GROSS' AS RIType
		,[TranCurr] SettlementCCY
		,- sum([SyndPremiumGIC]) Premium
		,'Gross Net' AS RIFlag
	FROM [pft].[PFT_SYND_WITH_CEDE] t
	LEFT JOIN fdm.DimTrifocus tf ON (tf.TrifocusCode = t.TrifocusCode)
	LEFT JOIN mds.ConformedEntityMapping cen ON (cen.Entity = t.Entity)
	WHERE ReviewCycle = '2022Q1'
	GROUP BY t.[TriFocusCode]
		,tf.TrifocusName
		,cen.ConformedEntityMapping
		,t.[YOA]
		,[TranCurr]
	)
	,cte_fx
AS (
	SELECT [fk_AccountingPeriod]
		,[fk_TransactionCurrency]
		,[FXRate]
	FROM [fdm].[FactFXRate]
	WHERE fk_FXRate = 2
		AND fk_RateScenario = 4
		AND fk_ReportingCurrency = 2
		AND fk_TransactionCurrency IN (
			'GBP'
			,'EUR'
			,'USD'
			,'CAD'
			)
		AND fk_AccountingPeriod BETWEEN '201812'
			AND left(convert(VARCHAR, getdate(), 112), 6)
		AND right(fk_AccountingPeriod, 2) IN (
			'03'
			,'06'
			,'09'
			,'12'
			)
	)
	,cte_gnpfx
AS (
	SELECT AccountingPeriod
		,TrifocusCode
		,TrifocusName
		,Entity
		,YOA
		,RIFlag
		,sum(Premium / fx.FXRate) PremiumUSD
	FROM cte_gnp gnp
	LEFT JOIN cte_fx fx ON (
			fx.fk_AccountingPeriod = gnp.AccountingPeriod
			AND fx.fk_TransactionCurrency = gnp.SettlementCCY
			)
	GROUP BY AccountingPeriod
		,TrifocusCode
		,TrifocusName
		,Entity
		,YOA
		,RIFlag
	)
SELECT * --into #tmp
FROM (
	SELECT ri.AccountingPeriod
		,ri.TrifocusCode
		,ri.TrifocusName
		,ri.Entity
		,ri.YOA
		,datepart(year, ri.InceptionDate) YOI
		,ri.RIProgramme
		,ri.RIType
		,'USD' AS SettlementCCY
		,ri.RIPolicyNumber
		,ri.InceptionDate InceptionDate
		,ri.ExpiryDate ExpiryDate
		,ri.ClaimsBasis
		,sum(ri.Premium / fx.FXRate) RIPremium
		,isnull(max(grg.PremiumUSD), 0) GrossNetUltimates
		,-- GrossGrossUltimates, --temp
		CASE 
			WHEN isnull(max(grg.PremiumUSD), 0) <> 0
				THEN CAST(sum(ri.Premium / fx.FXRate) / max(grg.PremiumUSD) AS NUMERIC(19, 6))
			ELSE 0
			END [RI%]
		,
		--isnull(max(grn.PremiumUSD), 0) GrossNetUltimates, --temp
		--CASE WHEN isnull(max(grn.PremiumUSD), 0) <> 0 THEN CAST(sum(ri.Premium/ fx.FXRate)/ max(grn.PremiumUSD) as numeric(19,6))  ELSE 0 END [GN_RI%], --temp
		isnull(cast(ri.AccountingPeriod AS VARCHAR), '-') + '|' + isnull(ri.TrifocusCode, '-') + '|' + isnull(ri.Entity, '-') + '|' + isnull(cast(ri.YOA AS VARCHAR), '-') + '|' + isnull(ri.RIProgramme, '-') + '|' + isnull(ri.RIType, '-') + '|' + isnull(ri.RIPolicyNumber, '-') + '|' + isnull(convert(VARCHAR, ri.InceptionDate, 126), '-') + '|' + isnull(convert(VARCHAR, ri.ExpiryDate, 126), '-') + '|' + isnull(ri.ClaimsBasis, '-') AS BusinessKey
	FROM cte_ri ri
	LEFT JOIN cte_gnpfx grg ON (
			ri.AccountingPeriod = grg.AccountingPeriod
			AND ri.TrifocusCode = grg.TrifocusCode
			AND ri.Entity = grg.Entity
			AND ri.YOA = grg.YOA
			AND grg.RIFlag = 'Gross Gross'
			)
	/* --temp
left join cte_gnpfx grn on
(
ri.AccountingPeriod = grn.AccountingPeriod
and ri.TrifocusCode = grn.TrifocusCode
and ri.Entity = grn.Entity
and ri.YOA = grn.YOA
and grn.RIFlag = 'Gross Net'
)
*/
	LEFT JOIN cte_fx fx ON (
			fx.fk_AccountingPeriod = ri.AccountingPeriod
			AND fx.fk_TransactionCurrency = ri.SettlementCCY
			)
	WHERE isnull(ri.Premium, 0) <> 0
	GROUP BY ri.AccountingPeriod
		,ri.TrifocusCode
		,ri.TrifocusName
		,ri.Entity
		,ri.YOA
		,datepart(year, ri.InceptionDate)
		,ri.RIProgramme
		,ri.RIType
		,
		--RIFlag,
		--ri.SettlementCCY,
		ri.RIPolicyNumber
		,ri.InceptionDate
		,ri.ExpiryDate
		,ri.ClaimsBasis
	) T
GO


