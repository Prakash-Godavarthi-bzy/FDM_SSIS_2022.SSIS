﻿
create view [fdm].[vw_FactFDMExternal]

as

select 
	fk_AccountingPeriod
	,fk_YOA
	,currency
	,cur_amount
	,fk_Account
	,fk_Process
	,fk_RIPolicy
	,fk_TriFocus
	,fk_Entity
from	
	[fdm].[FactFDMExternal_History]

union all

select 
	fk_AccountingPeriod
	,fk_YOA
	,currency
	,cur_amount
	,fk_Account
	,fk_Process
	,fk_RIPolicy
	,fk_TriFocus
	,fk_Entity
from	
	[fdm].[FactFDMExternal_Current]
GO


