USE [FinanceLanding]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* ==== Landing Zone ==== */


-- Cleanup
DROP TABLE IF EXISTS [Test].[epi_reinstatement]
DROP TABLE IF EXISTS [Test].[epi_view]
DROP TABLE IF EXISTS [Test].[policy_cube]
DROP TABLE IF EXISTS [Test].[policy_premium]
GO


-- Create brand new tables
CREATE TABLE [Test].[epi_reinstatement](
	[pre_cpd_policy_ref] [char](12) NULL,
	[reinstatement_signed] [float] NULL,
	[test_case] [int] NULL
) ON [PRIMARY]
GO

CREATE TABLE [Test].[epi_view](
	[cpd_epi_ccy] [varchar](3) NULL,
	[cpd_policy_reference] [varchar](12) NULL,
	[test_case] [int] NULL
) ON [PRIMARY]
GO

CREATE TABLE [Test].[policy_cube](
	[datemodified] [datetime] NULL,
	[Expiry] [datetime] NULL,
	[focus_area] [varchar](25) NULL,
	[Inception] [datetime] NULL,
	[mop] [varchar](3) NULL,
	[Multiyear] [varchar](1) NULL,
	[policyref] [varchar](12) NULL,
	[stats] [varchar](3) NULL,
	[synd] [int] NULL,
	[tot] [datetime] NULL,
	[yoa] [int] NULL,
	[test_case] [int] NULL
) ON [PRIMARY]
GO

CREATE TABLE [Test].[policy_premium](
	[pre_amount] [float] NULL,
	[pre_currency_code] [char](3) NULL,
	[pre_prem_qual] [char](3) NULL,
	[pre_cpd_policy_ref] [varchar](12) NULL,
	[test_case] [int] NULL
) ON [PRIMARY]
GO

-------------------------------------------------

-- Populate new tables with the cases we want to test
INSERT INTO [Test].[epi_reinstatement]
           ([pre_cpd_policy_ref],[reinstatement_signed],[test_case])					
     VALUES
           ('POL0001',10300.08,1),									-- simple case, 1 policy + 1 reinstatement + syndicate to be split + 1 original currency
		   ('POL0002',9500.33,2),									-- simple case, 1 policy + 1 reinstatement + syndicate <> 623 + 1 original currency
		   ('POL0003',46554.00,3),									-- 1 policy + 1 reinstatement + syndicate to be split + 2 original currencies
		   ('POL0004',7500.14,4),									-- 1 policy + 1 reinstatement + syndicate to be split + 1 original currency
		   ('POL0005',127544.01,5);									-- 1 policy + 1 reinstatement + syndicate <> 623 + 2 original currencies

INSERT INTO [Test].[epi_view]
           ([cpd_epi_ccy],[cpd_policy_reference],[test_case])
     VALUES
           ('EUR','POL0001',1),
		   ('USD','POL0002',2),
		   ('USD','POL0003',3),
		   ('GBP','POL0004',4),
		   ('EUR','POL0005',5);

INSERT INTO [Test].[policy_cube]
           ([datemodified],[Expiry],[focus_area],[Inception],[mop],[Multiyear],[policyref],[stats],[synd],[tot],[yoa],[test_case])
     VALUES
           ('2019-07-15 00:00:00.000','2020-07-14 00:00:00.000','EPL','2019-07-15 00:00:00.000','Z','N','POL0001','00',623,'2019-09-13 00:00:00.000',2012,1),
           ('2019-11-19 00:00:00.000','2020-09-30 00:00:00.000','Financial Institutions','2019-10-01 00:00:00.000','G','N','POL0002','SR',8033,'2020-02-01 00:00:00.000',2019,2),
           ('2019-05-27 00:00:00.000','2020-03-31 00:00:00.000','Sports','2019-04-01 00:00:00.000','J','N','POL0003','00',623,'2019-09-30 00:00:00.000',2019,3),
           ('2014-10-23 00:00:00.000','2013-12-31 00:00:00.000','BICI A&H PA','2013-01-01 00:00:00.000','B','N','POL0004','02',623,'2012-08-30 00:00:00.000',2013,4),
           ('2020-01-13 00:00:00.000','2021-12-31 00:00:00.000','Tracker SAT','2020-01-01 00:00:00.000','Z','Y','POL0005','06',3623,'2020-02-29 00:00:00.000',2020,5);

INSERT INTO [Test].[policy_premium]
           ([pre_amount],[pre_currency_code],[pre_prem_qual],[pre_cpd_policy_ref],[test_case])
     VALUES
           (0.00,'CAD','','POL0001',1),
		   (6000.00,'CAD','REI','POL0001',1),
           (0.00,'CAD','','POL0002',2),
		   (5000.00,'USD','REI','POL0002',2),
           (0.00,'CAD','','POL0003',3),
		   (2000.00,'CAD','REI','POL0003',3),
		   (3000.00,'GBP','REI','POL0003',3),
           (0.00,'CAD','','POL0004',4),
		   (1500.00,'AUD','REI','POL0004',4),
           (0.00,'CAD','','POL0005',5),
		   (170000.00,'JPY','REI','POL0005',5),
		   (10000.00,'USD','REI','POL0005',5);

/* ==== Inbound Zone: Test results ==== */

-- Cleanup
DROP TABLE IF EXISTS [Test].[Transaction]

-- Expected result table
CREATE TABLE [Test].[Transaction](
	[PK_Transaction] [bigint] NOT NULL,
	[Scenario] [varchar](2) NOT NULL,
	[Account] [varchar](10) NOT NULL,
	[Dataset] [varchar](255) NOT NULL,
	[DateOfFact] [datetime] NOT NULL,
	[BusinessKey] [varchar](255) NOT NULL,
	[PolicyNumber] [varchar](255) NOT NULL,
	[InceptionDate] [datetime] NOT NULL,
	[ExpiryDate] [datetime] NOT NULL,
	[BindDate] [datetime] NOT NULL,
	[DueDate] [datetime] NOT NULL,
	[TrifocusCode] [varchar](25) NOT NULL,
	[Entity] [varchar](25) NOT NULL,
	[YOA] [varchar](5) NOT NULL,
	[TypeOfBusiness] [varchar](1) NOT NULL,
	[StatsCode] [varchar](25) NULL,
	[SettlementCCY] [varchar](3) NOT NULL,
	[OriginalCCY] [varchar](3) NOT NULL,
	[IsToDate] [varchar](1) NOT NULL,
	[Value] [numeric](19, 4) NOT NULL,
	[RowHash] [varbinary](255) NULL,
	[FK_Allocation] [int] NULL,
	[DeltaType] [varchar](50) NULL,
	[AuditSourceBatchID] [varchar](255) NOT NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditGenerateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL,
	[AuditHost] [nvarchar](255) NOT NULL,
	[Basis] [varchar](2) NOT NULL,
	[Location] [varchar](50) NOT NULL,
	[ValueOrig] [numeric](19, 4) NULL,
	[BusinessProcessCode] [varchar](255) NULL,
	[FK_Batch] [int] NULL,
	[test_case] [int] NULL
) ON [PRIMARY]
GO

-- Expected result table

INSERT [Test].[Transaction] 
		( [PK_Transaction], [Scenario], [Account], [Dataset], [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate], [ExpiryDate], [BindDate], [DueDate]
		, [TrifocusCode], [Entity], [YOA], [TypeOfBusiness], [StatsCode], [SettlementCCY], [OriginalCCY], [IsToDate], [Value], [RowHash], [FK_Allocation], [DeltaType], [AuditSourceBatchID]
		, [AuditCreateDateTime], [AuditGenerateDateTime], [AuditUserCreate], [AuditHost], [Basis], [Location], [ValueOrig], [BusinessProcessCode], [FK_Batch], [test_case]) 
VALUES 
		 (90136013, N'A', N'RP-G-P', N'EPI Reinstatement Eurobase', CAST(N'2019-07-15T00:00:00.000' AS DateTime), N'POL0001     ', N'POL0001     ', CAST(N'2019-07-15T00:00:00.000' AS DateTime), CAST(N'2020-07-14T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'2019-09-13T00:00:00.000' AS DateTime), N'EPL', N'2623', N'2012', N'-', N'00', N'EUR', N'CAD', N'Y', CAST(8446.0656 AS Numeric(19, 4)), 0x78BFD8ED1D5A1DFC67635AC9E1DF03CD5C6D8359A9E41396FDFF7AC6465AEF708D60823CC0C61A4F8ABDB2CDBA14D5695E5C73488DE69BD3E73DADE81389C0C6, NULL, N'New', N'421', CAST(N'2020-05-08T14:34:16.243' AS DateTime), CAST(N'2020-05-08T14:20:20.700' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'E', N'N', CAST(4920.0000 AS Numeric(19, 4)), N'T1', 421, 1)
		,(90136014, N'A', N'RP-G-P', N'EPI Reinstatement Eurobase', CAST(N'2019-07-15T00:00:00.000' AS DateTime), N'POL0001     ', N'POL0001     ', CAST(N'2019-07-15T00:00:00.000' AS DateTime), CAST(N'2020-07-14T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'2019-09-13T00:00:00.000' AS DateTime), N'EPL', N'623', N'2012', N'-', N'00', N'EUR', N'CAD', N'Y', CAST(1854.0144 AS Numeric(19, 4)), 0x699EF55F06093F9383EFE80AED4D5FFC08D998A1875584EEEE4C61BD7D22976E2C38486DC911E65F46299E0E57104125E8353FEDA3C394A0816F7C81A7A8ABA7, NULL, N'New', N'421', CAST(N'2020-05-08T14:34:16.243' AS DateTime), CAST(N'2020-05-08T14:20:20.700' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'E', N'N', CAST(1080.0000 AS Numeric(19, 4)), N'T1', 421, 1)
		,(90136015, N'A', N'RP-G-P', N'EPI Reinstatement Eurobase', CAST(N'2019-05-27T00:00:00.000' AS DateTime), N'POL0003     ', N'POL0003     ', CAST(N'2019-04-01T00:00:00.000' AS DateTime), CAST(N'2020-03-31T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'2019-09-30T00:00:00.000' AS DateTime), N'Sports', N'2623', N'2019', N'-', N'00', N'USD', N'USD', N'Y', CAST(38174.2800 AS Numeric(19, 4)), 0x8B421EB0AEE63215E3FE44EB50011957DC23514E88DFF95EE163A7AB3A0B58B2219676EE84CBF2172DB38BEF947A8A2B247997AA8CAFDAC0781FF73FFE3E143F, NULL, N'New', N'423', CAST(N'2020-05-08T14:38:28.017' AS DateTime), CAST(N'2020-05-08T14:38:27.953' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'E', N'N', CAST(4394.6796 AS Numeric(19, 4)), N'T1', 423, 3)
		,(90136016, N'A', N'RP-G-P', N'EPI Reinstatement Eurobase', CAST(N'2019-05-27T00:00:00.000' AS DateTime), N'POL0003     ', N'POL0003     ', CAST(N'2019-04-01T00:00:00.000' AS DateTime), CAST(N'2020-03-31T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'2019-09-30T00:00:00.000' AS DateTime), N'Sports', N'623', N'2019', N'-', N'00', N'USD', N'USD', N'Y', CAST(8379.7200 AS Numeric(19, 4)), 0xD81F8FBBA95AB27E28F7B4E19B784590870349A2A567D269200D84220988774DD2C8B068774644514195927607AB5561378001112B3B097CF3AAE9C9BCC4BA83, NULL, N'New', N'423', CAST(N'2020-05-08T14:38:28.017' AS DateTime), CAST(N'2020-05-08T14:38:27.953' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'E', N'N', CAST(964.6858 AS Numeric(19, 4)), N'T1', 423, 3)
		,(90136017, N'A', N'RP-G-B', N'EPI Reinstatement Eurobase', CAST(N'2014-10-23T00:00:00.000' AS DateTime), N'POL0004     ', N'POL0004     ', CAST(N'2013-01-01T00:00:00.000' AS DateTime), CAST(N'2013-12-31T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'2012-08-30T00:00:00.000' AS DateTime), N'BICI A&H PA', N'2623', N'2013', N'-', N'02', N'GBP', N'AUD', N'Y', CAST(6150.1148 AS Numeric(19, 4)), 0xCCDF10C5D625DCE0F779582F1FC8BF50627A416D6F38CB08F2755940020F0AB5EB961BAB18286761150BB942648DF66FCB1F8FB1BA578F880C22DA9EBE5DA49A, NULL, N'New', N'424', CAST(N'2020-05-08T14:41:36.100' AS DateTime), CAST(N'2020-05-08T14:41:36.037' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'E', N'N', CAST(1230.0000 AS Numeric(19, 4)), N'T1', 424, 4)
		,(90136018, N'A', N'RP-G-B', N'EPI Reinstatement Eurobase', CAST(N'2014-10-23T00:00:00.000' AS DateTime), N'POL0004     ', N'POL0004     ', CAST(N'2013-01-01T00:00:00.000' AS DateTime), CAST(N'2013-12-31T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'2012-08-30T00:00:00.000' AS DateTime), N'BICI A&H PA', N'623', N'2013', N'-', N'02', N'GBP', N'AUD', N'Y', CAST(1350.0252 AS Numeric(19, 4)), 0x8715B43A5C9E4BB517C2296EC5A1EA417268924882EF91F44D8ED82A8A8FC7E101E66A6DF6D2F55D4FD2B25252E5E37D35059BB719BB06035B6ED750417FF84A, NULL, N'New', N'424', CAST(N'2020-05-08T14:41:36.100' AS DateTime), CAST(N'2020-05-08T14:41:36.037' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'E', N'N', CAST(270.0000 AS Numeric(19, 4)), N'T1', 424, 4)
		,(90136019, N'A', N'RP-G-P', N'EPI Reinstatement Eurobase', CAST(N'2020-01-13T00:00:00.000' AS DateTime), N'POL0005     ', N'POL0005     ', CAST(N'2020-01-01T00:00:00.000' AS DateTime), CAST(N'2021-12-31T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'2020-02-29T00:00:00.000' AS DateTime), N'Tracker SAT', N'3623', N'2020', N'-', N'06', N'EUR', N'USD', N'Y', CAST(127544.0100 AS Numeric(19, 4)), 0x81AD799F353C257CE52D52F937302311E44BFCB09B12236508432F463B861314D8EA3FEC4CF0EE1B8BCC6F5904A8E7FB43EB3B91E40C3C48415F792D13EDA929, NULL, N'New', N'425', CAST(N'2020-05-08T14:46:45.150' AS DateTime), CAST(N'2020-05-08T14:46:45.087' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'E', N'Y', CAST(11554.9673 AS Numeric(19, 4)), N'T1', 425, 5)
		,(90136020, N'A', N'RP-G-P', N'EPI Reinstatement Eurobase', CAST(N'2019-11-19T00:00:00.000' AS DateTime), N'POL0002     ', N'POL0002     ', CAST(N'2019-10-01T00:00:00.000' AS DateTime), CAST(N'2020-09-30T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'2020-02-01T00:00:00.000' AS DateTime), N'Financial Institutions', N'8033', N'2019', N'-', N'SR', N'USD', N'USD', N'Y', CAST(9500.3300 AS Numeric(19, 4)), 0x3DD602535FB2DFD40196EA3B6F78E77105DF8599F7271F0968D3BFA87A5480DC36B8CFDDE0A766FFFB636BDECF6A3A9B258CBFA244C525BBAEC0BD2888EF22E2, NULL, N'New', N'426', CAST(N'2020-05-08T14:51:53.280' AS DateTime), CAST(N'2020-05-08T14:51:53.183' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'E', N'N', CAST(5000.0000 AS Numeric(19, 4)), N'T1', 426, 2)
	
GO