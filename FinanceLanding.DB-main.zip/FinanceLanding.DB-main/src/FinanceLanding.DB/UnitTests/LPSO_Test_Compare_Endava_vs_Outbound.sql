SELECT sourceDiff, count(*)
FROM [EndavaTesting].dbo.mc_lpso3_with_abs_on_claims  tr
group by sourceDiff


SELECT sourceDiff,
	 [Account], [BusinessKey], [DateOfFact], [PolicyNumber], [TrifocusCode], [Entity], [YOA], [Value], [BrokerageValue], [FinalPremiumValue],
	 ABS(ISNULL([Value],0.00)) - ABS(ISNULL([FinalPremiumValue],0.00)) AS [diff1],
	 ABS(ISNULL([Value],0.00)) - ABS(ISNULL([BrokerageValue],0.00)) AS [diff2]
	 --, t.tra_syndicate_net_amount, t.tra_total_discount_pcnt
-- SELECT DISTINCT sourceDiff
FROM [EndavaTesting].dbo.mc_lpso3_with_abs_on_claims  tr
--INNER JOIN FinanceLanding.Eurobase.transaction_01 t ON tr.[BusinessKey] = CAST(t.transaction_01_id AS VARCHAR(50))+ '|1'
WHERE sourceDiff = 'premium: Endava_mapping vs. outbound'
	AND ABS(ISNULL([Value],0.00)) - ABS(ISNULL([FinalPremiumValue],0.00)) <> 0.00
	--AND ABS(ISNULL([Value],0.00)) - ABS(ISNULL(ROUND([BrokerageValue],4),0.00)) <> 0.00
ORDER BY ACCOUNT, [diff] DESC


SELECT sourceDiff,
	 [Account], [BusinessKey], [DateOfFact], [PolicyNumber], [TrifocusCode], [Entity], [YOA], [Value], [BrokerageValue], [FinalPremiumValue],
	 ABS(ISNULL([Value],0.00)) - ABS(ISNULL([FinalPremiumValue],0.00)) AS [diff1],
	 ABS(ISNULL([Value],0.00)) - ABS(ISNULL([BrokerageValue],0.00)) AS [diff2]
	 --, t.tra_syndicate_net_amount, t.tra_total_discount_pcnt
-- SELECT DISTINCT ACCOUNT
FROM [EndavaTesting].dbo.mc_lpso3_with_abs_on_claims  tr
--INNER JOIN FinanceLanding.Eurobase.transaction_01 t ON tr.[BusinessKey] = CAST(t.transaction_01_id AS VARCHAR(50))+ '|1'
WHERE sourceDiff = 'claims: Endava_mapping vs. outbound'
	AND ABS(ISNULL([Value],0.00)) - ABS(ISNULL([FinalPremiumValue],0.00)) <> 0.00
	--AND ABS(ISNULL([Value],0.00)) - ABS(ISNULL(ROUND([BrokerageValue],4),0.00)) <> 0.00
ORDER BY ACCOUNT, [diff] DESC


SELECT sourceDiff,
	 [Account], [BusinessKey], [DateOfFact], [PolicyNumber], [TrifocusCode], [Entity], [YOA], [Value], [BrokerageValue], [FinalPremiumValue],
	 ABS(ISNULL([Value],0.00)) - ABS(ISNULL([FinalPremiumValue],0.00)) AS [diff1],
	 ABS(ISNULL([Value],0.00)) - ABS(ISNULL([BrokerageValue],0.00)) AS [diff2]
	 --, t.tra_syndicate_net_amount, t.tra_total_discount_pcnt
-- SELECT DISTINCT ACCOUNT
FROM [EndavaTesting].dbo.mc_lpso3_with_abs_on_claims  tr
--INNER JOIN FinanceLanding.Eurobase.transaction_01 t ON tr.[BusinessKey] = CAST(t.transaction_01_id AS VARCHAR(50))+ '|1'
WHERE sourceDiff = 'brokerage: Endava_mapping vs. outbound'
	--AND ABS(ISNULL([Value],0.00)) - ABS(ISNULL([FinalPremiumValue],0.00)) <> 0.00
	AND ABS(ISNULL([Value],0.00)) - ABS(ISNULL(ROUND([BrokerageValue],4),0.00)) <> 0.00
ORDER BY ACCOUNT, [diff] DESC

-------------------------------------------------------------------------------------------------

SELECT sourceDiff,
	 [Account], [BusinessKey], [DateOfFact], [PolicyNumber], [TrifocusCode], [Entity], [YOA], [Value], [BrokerageValue], [FinalPremiumValue],
	 ABS(ISNULL([Value],0.00)) - ABS(ISNULL([FinalPremiumValue],0.00)) AS [diff1],
	 ABS(ISNULL([Value],0.00)) - ABS(ISNULL([BrokerageValue],0.00)) AS [diff2]
FROM [EndavaTesting].dbo.mc_lpso3_with_abs_on_claims  tr
WHERE sourceDiff = 'premium: outbound - Endava_mapping'
	--AND ABS(ISNULL([Value],0.00)) - ABS(ISNULL([FinalPremiumValue],0.00)) <> 0.00
	--AND ABS(ISNULL([Value],0.00)) - ABS(ISNULL(ROUND([BrokerageValue],4),0.00)) <> 0.00
ORDER BY ACCOUNT, [diff] DESC

SELECT sourceDiff,
	 [Account], [BusinessKey], [DateOfFact], [PolicyNumber], [TrifocusCode], [Entity], [YOA], [Value], [BrokerageValue], [FinalPremiumValue],
	 ABS(ISNULL([Value],0.00)) - ABS(ISNULL([FinalPremiumValue],0.00)) AS [diff1],
	 ABS(ISNULL([Value],0.00)) - ABS(ISNULL([BrokerageValue],0.00)) AS [diff2]
FROM [EndavaTesting].dbo.mc_lpso3_with_abs_on_claims  tr
WHERE sourceDiff = 'premium: Endava_mapping - outbound'
	--AND ABS(ISNULL([Value],0.00)) - ABS(ISNULL([FinalPremiumValue],0.00)) <> 0.00
	--AND ABS(ISNULL([Value],0.00)) - ABS(ISNULL(ROUND([BrokerageValue],4),0.00)) <> 0.00
	--AND PolicyNumber = 'B5203H04ANFT'
ORDER BY Account 

SELECT * FROM FinanceDataContract.Outbound.[Transaction]  where BusinessKey = '772475|3'			/* 809099|0,794463|0,1122807|0,860841|0,896087|0,860840|0,896086|0,794462|0,794464|0,809100|0,1122806|0 */
select * from FinanceLanding.Eurobase.transaction_01 where transaction_01_id = 772475
select * from FinanceLanding.Eurobase.transaction_instalment ti
where ti.ins_pre_br_signing_date	= '2004-02-12 00:00:00.000' 
				AND		ti.ins_pre_br_signing_num	= 21412
				AND		ti.ins_pre_br_version_num	=1
				AND		ti.ins_syn_user_number		= 2623
				AND		ti.ins_pre_treaty_section	= 'AA'
select * from FinanceLanding.Eurobase.policy_details_01 where pol_cpd_policy_reference = 'T6533G04ANCC'
select * from FinanceLanding.Eurobase.common_policy_details_01 where cpd_policy_reference = 'T6533G04ANCC'
select * from FinanceLanding.Eurobase.cob_codes where cob_code like 'RG %'

SELECT * FROM FinanceDataContract.Outbound.[Transaction] where BusinessKey = '794465|0'			/* 809099|0,794463|0,1122807|0,860841|0,896087|0,860840|0,896086|0,794462|0,794464|0,809100|0,1122806|0 */
select * from FinanceLanding.Eurobase.transaction_01 where transaction_01_id = 794465
select * from FinanceLanding.Eurobase.policy_details_01 where pol_cpd_policy_reference = 'B5203H04ANFT'
select * from FinanceLanding.Eurobase.common_policy_details_01 where cpd_policy_reference = 'B5203H04ANFT'
select * from FinanceLanding.Eurobase.cob_codes where cob_code like 'RG %'

SELECT sourceDiff, [Account], [PolicyNumber], [TrifocusCode], SUM([Value]) AS OutboundValue
FROM [EndavaTesting].dbo.mc_lpso3_with_abs_on_1claims  tr
WHERE sourceDiff = 'premium: Endava_mapping - outbound'
	--AND ABS(ISNULL([Value],0.00)) - ABS(ISNULL([FinalPremiumValue],0.00)) <> 0.00
	--AND ABS(ISNULL([Value],0.00)) - ABS(ISNULL(ROUND([BrokerageValue],4),0.00)) <> 0.00
group by sourceDiff, [Account], [PolicyNumber], [TrifocusCode]


