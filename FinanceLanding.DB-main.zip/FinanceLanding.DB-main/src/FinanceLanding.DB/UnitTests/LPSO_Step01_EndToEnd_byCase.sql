﻿use FinanceLanding

/*
SELECT *
FROM DeltaGeneration.[Configuration].vw_CfgTables
WHERE SourceSystemName = 'Eurobase'

SELECT  TOP 10 tra_actual_payment_date, tra_bureau_signing_date, tra_bureau_signing_num, tra_bureau_version_num, tra_business_category, tra_entry_type, tra_lloyds_account_type, tra_lloyds_ca_qual_cat, tra_planned_sett_date, tra_policy_ref, tra_processing_period, tra_settlement_ccy_code, tra_settlement_date, tra_syn_user_number, tra_syndicate_net_amount, tra_treaty_section, tra_year_of_account, transaction_01_id, tra_claim_split_number FROM Eurobase.[transaction_01]
SELECT  TOP 10 cpd_expiry, cpd_inception, cpd_policy_reference, cpd_tri_focus FROM Eurobase.[common_policy_details_01] 
SELECT  TOP 10 ins_actual_payment_date, ins_instalment_amount, ins_instalment_due_date, ins_pre_br_signing_date, ins_pre_br_signing_num, ins_pre_br_version_num, ins_pre_treaty_section, ins_syn_user_number, ins_instalment_num FROM Eurobase.[transaction_instalment]
SELECT  TOP 10 pol_mop_code, pol_cpd_policy_reference, pol_syn_user_number FROM Eurobase.[policy_details_01] 
SELECT  TOP 10 ded_cpd_policy_ref, ded_sequence_no, ded_qual, ded_pcnt FROM Eurobase.policy_deductions 

DELETE FROM FinanceDataContract.Outbound.[Transaction] WHERE DataSet = 'LPSO'
*/

SET NOCOUNT ON;

DECLARE @Test_Case INT

SET @Test_Case = 0				-- IF 0, applies all of them, else set a number

-------------------------------------------------------------------

BEGIN TRAN

-- Do the cleanup
TRUNCATE TABLE Eurobase.transaction_01;
TRUNCATE TABLE Eurobase.common_policy_details_01;
TRUNCATE TABLE Eurobase.transaction_instalment;
TRUNCATE TABLE Eurobase.policy_details_01;
TRUNCATE TABLE Eurobase.policy_deductions;

--TRUNCATE TABLE FinanceDataContract.Inbound.[Transaction]

-- Bring unit test data
INSERT INTO Eurobase.transaction_01
		(tra_actual_payment_date, tra_bureau_signing_date, tra_bureau_signing_num, tra_bureau_version_num, tra_business_category, tra_entry_type, tra_lloyds_account_type, tra_lloyds_ca_qual_cat, tra_planned_sett_date, tra_policy_ref, 
		 tra_processing_period, tra_settlement_ccy_code, tra_settlement_date, tra_syn_user_number, tra_syndicate_net_amount, tra_treaty_section, tra_year_of_account, transaction_01_id, tra_claim_split_number, tra_lloyds_ca_cat_code,
		 tra_total_discount_pcnt, [tra_lloyds_risk_class]) 
SELECT tra_actual_payment_date, tra_bureau_signing_date, tra_bureau_signing_num, tra_bureau_version_num, tra_business_category, tra_entry_type, tra_lloyds_account_type, tra_lloyds_ca_qual_cat, tra_planned_sett_date, tra_policy_ref, 
		 tra_processing_period, tra_settlement_ccy_code, tra_settlement_date, tra_syn_user_number, tra_syndicate_net_amount, tra_treaty_section, tra_year_of_account, transaction_01_id, tra_claim_split_number, tra_lloyds_ca_cat_code, 
		 tra_total_discount_pcnt, [tra_lloyds_risk_class]
FROM Test.transaction_01
WHERE (@Test_Case = 0) OR (test_case = @Test_Case);

INSERT INTO Eurobase.common_policy_details_01
		(cpd_expiry, cpd_inception, cpd_policy_reference, cpd_tri_focus, [cpd_udt_initials])
SELECT cpd_expiry, cpd_inception, cpd_policy_reference, cpd_tri_focus, [cpd_udt_initials]
FROM Test.common_policy_details_01
WHERE (@Test_Case = 0) OR (test_case = @Test_Case);

INSERT INTO Eurobase.transaction_instalment
	(ins_actual_payment_date, ins_instalment_amount, ins_instalment_due_date, ins_pre_br_signing_date, ins_pre_br_signing_num, ins_pre_br_version_num, ins_pre_treaty_section, ins_syn_user_number, ins_instalment_num)
SELECT ins_actual_payment_date, ins_instalment_amount, ins_instalment_due_date, ins_pre_br_signing_date, ins_pre_br_signing_num, ins_pre_br_version_num, ins_pre_treaty_section, ins_syn_user_number, ins_instalment_num
FROM Test.transaction_instalment
WHERE (@Test_Case = 0) OR (test_case = @Test_Case);

INSERT INTO Eurobase.policy_details_01
		(pol_mop_code, pol_cpd_policy_reference, pol_syn_user_number, pol_cob_code, pol_stats_code)
SELECT pol_mop_code, pol_cpd_policy_reference, pol_syn_user_number, pol_cob_code, pol_stats_code
FROM Test.policy_details_01
WHERE (@Test_Case = 0) OR (test_case = @Test_Case);

INSERT INTO Eurobase.policy_deductions
		(ded_cpd_policy_ref, ded_sequence_no, ded_qual, ded_pcnt)
SELECT TOP 1
		ded_cpd_policy_ref, ded_sequence_no, ded_qual, ded_pcnt
FROM Test.policy_deductions
WHERE (@Test_Case = 0) OR (test_case = @Test_Case);

SELECT * FROM Eurobase.transaction_01
SELECT * FROM Eurobase.transaction_instalment
SELECT * FROM Eurobase.policy_details_01
SELECT * FROM Eurobase.common_policy_details_01
SELECT * FROM Eurobase.policy_deductions

-- Populate Inbound.Transaction and check the result
EXECUTE FinanceLanding.Eurobase.usp_LandingToInbound null, null;

--INSERT INTO Test.[Transaction]
SELECT *, @Test_Case
FROM FinanceDataContract.Inbound.[Transaction] 
WHERE DataSet = 'LPSO';
-- ROLLBACK;

-- Populate Outbound.Transaction and check the result
EXEC FinanceDataContract.Inbound.usp_InboundOutboundWorkflow;

SELECT * FROM FinanceDataContract.Outbound.[Transaction] WHERE DataSet = 'LPSO'

IF @Test_Case = 4	-- We simulate some changes in time
BEGIN
	/*
	-- Time 1 : tra_syndicate_net_amount changes

	UPDATE Eurobase.transaction_01 
	SET tra_syndicate_net_amount += 100.00,
		tra_actual_payment_date = CASE WHEN YEAR(tra_actual_payment_date) = 9999 THEN tra_actual_payment_date ELSE DATEADD(DAY,30,tra_actual_payment_date) END

	SELECT * FROM Eurobase.transaction_01

	-- Populate Inbound.Transaction and check the result
	EXECUTE FinanceLanding.Eurobase.usp_LandingToInbound null, null;

	SELECT *
	FROM FinanceDataContract.Inbound.[Transaction]
	WHERE DataSet = 'LPSO';

	-- Populate Outbound.Transaction and check the result
	EXEC FinanceDataContract.Inbound.usp_InboundOutboundWorkflow;

	SELECT * FROM FinanceDataContract.Outbound.[Transaction] WHERE DataSet = 'LPSO'
	*/
	-- Time 2 : policy_deductions changes

	--UPDATE Eurobase.transaction_01 
	--SET tra_total_discount_pcnt = 30
	--WHERE (Test_Case = 4);

	--SELECT * FROM Eurobase.transaction_01 

	---- Populate Inbound.Transaction and check the result
	--EXECUTE FinanceLanding.Eurobase.usp_LandingToInbound null, null;

	--SELECT *
	--FROM FinanceDataContract.Inbound.[Transaction]
	--WHERE DataSet = 'LPSO'
	--ORDER BY PolicyNumber, DateOfFact, Value, Account desc, Entity;

	---- Populate Outbound.Transaction and check the result
	--EXEC FinanceDataContract.Inbound.usp_InboundOutboundWorkflow;

	SELECT * FROM FinanceDataContract.Outbound.[Transaction] WHERE DataSet = 'LPSO'

END

GO

IF @@TRANCOUNT <> 0
	ROLLBACK;
