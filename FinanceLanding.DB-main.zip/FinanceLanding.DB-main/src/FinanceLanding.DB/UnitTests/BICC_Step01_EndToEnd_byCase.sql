use FinanceLanding

/*
DELETE 
--SELECT TOP 100 *
FROM FinanceDataContract.Outbound.[Transaction] WHERE DataSet = 'ClaimCenter'
*/

SET NOCOUNT ON;

DECLARE @Test_Case INT
	, @Detail_Level INT = 2		-- IF 0 all data set results are

SET @Test_Case = 8				-- IF 0, applies all of them, else set a number

-------------------------------------------------------------------

BEGIN TRAN

-- Do the cleanup
DELETE 
--SELECT TOP 100 *
FROM FinanceDataContract.Outbound.[Transaction] WHERE DataSet = 'ClaimCenter'

TRUNCATE TABLE [BICC].[ClaimExposureMovement]
TRUNCATE TABLE [BICC].[ClaimExposure]
TRUNCATE TABLE [BICC].[Claim]
TRUNCATE TABLE [BICC].[ClaimExposureExtension]
TRUNCATE TABLE [BICC].[ClaimExposureCatastrophe]
TRUNCATE TABLE [BICC].[ClaimMovementLine]

--TRUNCATE TABLE FinanceDataContract.Inbound.[Transaction]

-- Bring unit test data
INSERT INTO [BICC].[ClaimExposureMovement]
        ([SourceSystem],[ClaimSourceId],[ClaimExposureSourceId],[MovementReferenceSourceId],[OriginalCurrency],[SettlementCurrency]
        ,[MovementDate],[MovementType],[ToDateDefenseIncurredInReservingCCY],[ToDateFeesIncurredInReservingCCY],[ToDateIndemnityIncurredInReservingCCY]
        ,[ToDatePaidDefenceInReservingCCY],[ToDatePaidFeesInReservingCCY],[ToDatePaidIndemnityInReservingCCY],[IsActive]) 
SELECT [SourceSystem],[ClaimSourceId],[ClaimExposureSourceId],[MovementReferenceSourceId],[OriginalCurrency],[SettlementCurrency]
        ,[MovementDate],[MovementType],[ToDateDefenseIncurredInReservingCCY],[ToDateFeesIncurredInReservingCCY],[ToDateIndemnityIncurredInReservingCCY]
        ,[ToDatePaidDefenceInReservingCCY],[ToDatePaidFeesInReservingCCY],[ToDatePaidIndemnityInReservingCCY],[IsActive]
FROM [Test].[ClaimExposureMovement]
WHERE (@Test_Case = 0) OR (test_case = @Test_Case);

INSERT INTO [BICC].[ClaimExposure]
		([SourceSystem],[ClaimSourceId],[ClaimExposureSourceId],[ClaimExposureNatCatastropheSourceId]
        ,[PolicyExpire],[PolicyInception],[TrifocusCode],[YearOfAccount],[IsActive])
SELECT [SourceSystem],[ClaimSourceId],[ClaimExposureSourceId],[ClaimExposureNatCatastropheSourceId]
        ,[PolicyExpire],[PolicyInception],[TrifocusCode],[YearOfAccount],[IsActive]
FROM [Test].[ClaimExposure]
WHERE (@Test_Case = 0) OR (test_case = @Test_Case);

INSERT INTO [BICC].[Claim]
		([SourceSystem],[ClaimSourceId],[ClaimReference],[LocationOfLossCountry],[LocationOfLossState],[PolicyNumber],[IsActive])
SELECT [SourceSystem],[ClaimSourceId],[ClaimReference],[LocationOfLossCountry],[LocationOfLossState],[PolicyNumber],[IsActive]
FROM [Test].[Claim]
WHERE (@Test_Case = 0) OR (test_case = @Test_Case);

INSERT INTO [BICC].[ClaimExposureExtension]
		([SourceSystem],[ClaimSourceId],[ClaimExposureSourceId],[SCMReference],[IsActive])
SELECT [SourceSystem],[ClaimSourceId],[ClaimExposureSourceId],[SCMReference],[IsActive]
FROM [Test].[ClaimExposureExtension]
WHERE (@Test_Case = 0) OR (test_case = @Test_Case);

INSERT INTO [BICC].[ClaimExposureCatastrophe]
		([SourceSystem],[CatastropheSourceId],[BeazleyCatCode],[IsActive])
SELECT [SourceSystem],[CatastropheSourceId],[BeazleyCatCode],[IsActive]
FROM [Test].[ClaimExposureCatastrophe]
WHERE (@Test_Case = 0) OR (test_case = @Test_Case);

INSERT INTO [BICC].[ClaimMovementLine]
		([SourceSystem],[ClaimExposureSourceId],[MovementReferenceSourceId],[SyndicateNumber],[LineMultiplier],[IsActive])
SELECT [SourceSystem],[ClaimExposureSourceId],[MovementReferenceSourceId],[SyndicateNumber],[LineMultiplier],[IsActive]
FROM [Test].[ClaimMovementLine]
WHERE (@Test_Case = 0) OR (test_case = @Test_Case);

IF @Detail_Level = 0
BEGIN
	SELECT TOP 100 [SourceSystem],[ClaimSourceId],[ClaimExposureSourceId],[MovementReferenceSourceId],[OriginalCurrency],[SettlementCurrency]
			,[MovementDate],[MovementType],[ToDateDefenseIncurredInReservingCCY],[ToDateFeesIncurredInReservingCCY],[ToDateIndemnityIncurredInReservingCCY]
			,[ToDatePaidDefenceInReservingCCY],[ToDatePaidFeesInReservingCCY],[ToDatePaidIndemnityInReservingCCY],[IsActive] 
	FROM [BICC].[ClaimExposureMovement]

	SELECT TOP 100 [SourceSystem],[ClaimSourceId],[ClaimExposureSourceId],[ClaimExposureNatCatastropheSourceId]
			,[PolicyExpire],[PolicyInception],[TrifocusCode],[YearOfAccount],[IsActive] 
	FROM [BICC].[ClaimExposure]

	SELECT TOP 100 [SourceSystem],[ClaimSourceId],[ClaimReference],[LocationOfLossCountry],[LocationOfLossState],[PolicyNumber],[IsActive] 
	FROM [BICC].[Claim]

	SELECT TOP 100 [SourceSystem],[ClaimSourceId],[ClaimExposureSourceId],[SCMReference],[IsActive] 
	FROM [BICC].[ClaimExposureExtension]

	SELECT TOP 100 [SourceSystem],[CatastropheSourceId],[BeazleyCatCode],[IsActive]
	 FROM [BICC].[ClaimExposureCatastrophe]

	SELECT TOP 100 [SourceSystem],[ClaimExposureSourceId],[MovementReferenceSourceId],[SyndicateNumber],[LineMultiplier],[IsActive]
	FROM [BICC].[ClaimMovementLine]
END

-- Populate Inbound.Transaction and check the result
EXECUTE FinanceLanding.BICC.usp_LandingToInbound null, null;

IF @Detail_Level < 2
	--INSERT INTO Test.[Transaction]
	SELECT TOP 500 *, @Test_Case
	FROM FinanceDataContract.Inbound.[Transaction] 
	WHERE DataSet = 'ClaimCenter';
	-- ROLLBACK;

-- Populate Outbound.Transaction and check the result
EXEC FinanceDataContract.Inbound.usp_InboundOutboundWorkflow;

SELECT TOP 500 * FROM FinanceDataContract.Outbound.[Transaction] WHERE DataSet = 'ClaimCenter'

IF @Test_Case = 444	-- We simulate some changes in time
BEGIN
	/*
	-- Time 1 : tra_syndicate_net_amount changes

	UPDATE Eurobase.transaction_01 
	SET tra_syndicate_net_amount += 100.00,
		tra_actual_payment_date = CASE WHEN YEAR(tra_actual_payment_date) = 9999 THEN tra_actual_payment_date ELSE DATEADD(DAY,30,tra_actual_payment_date) END

	SELECT * FROM Eurobase.transaction_01

	-- Populate Inbound.Transaction and check the result
	EXECUTE FinanceLanding.Eurobase.usp_LandingToInbound null, null;

	SELECT *
	FROM FinanceDataContract.Inbound.[Transaction]
	WHERE DataSet = 'LPSO';

	-- Populate Outbound.Transaction and check the result
	EXEC FinanceDataContract.Inbound.usp_InboundOutboundWorkflow;

	SELECT * FROM FinanceDataContract.Outbound.[Transaction] WHERE DataSet = 'LPSO'
	*/
	-- Time 2 : policy_deductions changes

	--UPDATE Eurobase.transaction_01 
	--SET tra_total_discount_pcnt = 30
	--WHERE (Test_Case = 4);

	--SELECT * FROM Eurobase.transaction_01 

	---- Populate Inbound.Transaction and check the result
	--EXECUTE FinanceLanding.Eurobase.usp_LandingToInbound null, null;

	--SELECT *
	--FROM FinanceDataContract.Inbound.[Transaction]
	--WHERE DataSet = 'LPSO'
	--ORDER BY PolicyNumber, DateOfFact, Value, Account desc, Entity;

	---- Populate Outbound.Transaction and check the result
	--EXEC FinanceDataContract.Inbound.usp_InboundOutboundWorkflow;

	SELECT TOP 100 * FROM FinanceDataContract.Outbound.[Transaction] WHERE DataSet = 'ClaimCenter'

END

GO

IF @@TRANCOUNT <> 0
	ROLLBACK;
