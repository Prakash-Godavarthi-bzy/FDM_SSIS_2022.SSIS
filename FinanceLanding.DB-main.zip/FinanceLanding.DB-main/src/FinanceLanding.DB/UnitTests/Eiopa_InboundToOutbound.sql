﻿	use FinanceDataContract
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
	IF @Trancount = 0 BEGIN TRAN;
	--rollback
	--Clear outbound 
	delete from  FinanceDataContract.Outbound.[DiscountRates] where DataSet='EIOPA';
	delete from  FinanceDataContract.inbound.[DiscountRates] where DataSet='EIOPA';

	IF OBJECT_ID('tempdb..#StaticSrcValues ') IS NOT NULL

     DROP TABLE #StaticSrcValues;

	/*=====================================================================================================================
	Set up Data for Test
	 ======================================================================================================================*/
	----Batch1 set up and process
	WITH	src
	    ([AsAtDate],
	     [DiscountRateName],
	     [DiscountRateKey],
	     [DataSet],
	     [SettlementCCY],
	     [CumulativeDevelopmentPercentage],
	     [DevelopmentYear],
	     [FK_Batch],
	     [AuditSourceBatchID],
		 [AuditHost],
		 AuditGenerateDateTime
	     )

	AS	(
	select 
	   '20190331',  
	   'EIOPA - RFR_spot_no_VA',
	   'EIOPA',
	   'EIOPA',
	   'EUR',
	   -0.00330,
	   1,
	   0,
	   0,
	   CAST(SERVERPROPERTY('MachineName') AS [VARCHAR](255)),
	   GETUTCDATE()
	 )
			
	
	SELECT	       
	     [AsAtDate],
	     [DiscountRateName],
	     [DiscountRateKey],
	     [DataSet],
	     [SettlementCCY],
	     [CumulativeDevelopmentPercentage],
	     [DevelopmentYear],
	     [FK_Batch],
	     [AuditSourceBatchID]
	     [AuditHost],
		 AuditGenerateDateTime
	
	INTO	#StaticSrcValues 
	FROM	src

	select * from #StaticSrcValues

	INSERT Inbound.[DiscountRates] (
	     [AsAtDate],
	     [DiscountRateName],
	     [DiscountRateKey],
	     [DataSet],
	     [SettlementCCY],
	     [CumulativeDevelopmentPercentage],
	     [DevelopmentYear],
	     [FK_Batch],
	     [AuditSourceBatchID],
		 [AuditHost],
		 AuditGenerateDateTime)	
	OUTPUT	Inserted.AuditSourceBatchID, 'InBound', 'EIOPA','DiscountRates'
	INTO	Inbound.BatchQueue(PK_Batch, Status, DataSet, RunDescription)
	SELECT	        
	     [AsAtDate],
	     [DiscountRateName],
	     [DiscountRateKey],
	     [DataSet],
	     [SettlementCCY],
	     [CumulativeDevelopmentPercentage],
	     [DevelopmentYear],
	     v.AuditSourceBatchId,
		 v.AuditSourceBatchId,
		 [AuditHost],
		 AuditGenerateDateTime
	
	FROM	#StaticSrcValues  l
	CROSS JOIN	(SELECT	value = CAST(0.5 AS Numeric(19, 4)),AuditSourceBatchId = 0) v;

		select * from inbound.[DiscountRates] where DataSet='EIOPA';
      
	EXECUTE FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_DiscountRates


	select * from outbound.[DiscountRates] where DataSet='EIOPA';
/*=====================================================================================================================
            Run Test and Roll back dont commit test data to tables
 ======================================================================================================================*/
	WITH	Expected (fk_batch, Value)
	AS		(
				SELECT	(SELECT CAST(- 1 AS VARCHAR(20)) FROM #StaticSrcValues slv), -0.00330
			)
	SELECT	OutboundValue	= (ISNULL(Outbound.CumulativeDevelopmentPercentage, 0.0000))
			,ExpectedValue = e.Value
			,TestName		= 'New record'
			,TestResult		= IIF (Outbound.CumulativeDevelopmentPercentage <> e.Value, 'Fail', 'Pass')
	FROM	Expected e
	LEFT JOIN	Outbound.[DiscountRates]	AS Outbound ON e.fk_batch = Outbound.fk_batch
	ORDER BY Outbound.fk_batch ASC;

    IF @Trancount = 0 ROLLBACK; 
END TRY
BEGIN CATCH
    IF @Trancount = 0  ROLLBACK;
    THROW;
END CATCH;