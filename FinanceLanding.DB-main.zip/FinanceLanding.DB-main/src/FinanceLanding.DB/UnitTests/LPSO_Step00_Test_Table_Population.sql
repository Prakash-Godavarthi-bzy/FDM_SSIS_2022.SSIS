USE [FinanceLanding]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* ==== Landing Zone ==== */


-- Cleanup
DROP TABLE IF EXISTS [Test].[common_policy_details_01]
DROP TABLE IF EXISTS [Test].[policy_deductions]
DROP TABLE IF EXISTS [Test].[policy_details_01]
DROP TABLE IF EXISTS [Test].[transaction_01]
DROP TABLE IF EXISTS [Test].[transaction_instalment]
GO


-- Create brand new tables
CREATE TABLE [Test].[common_policy_details_01](
	[cpd_expiry] [datetime] NULL,
	[cpd_inception] [datetime] NULL,
	[cpd_policy_reference] [varchar](12) NOT NULL,
	[cpd_tri_focus] [char](25) NULL,
	[cpd_udt_initials] [varchar](3) NULL,
	[test_case] [int] NULL,
 CONSTRAINT [PK_common_policy_details_01] PRIMARY KEY CLUSTERED 
(
	[cpd_policy_reference] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO

CREATE TABLE [Test].[policy_deductions](
	[ded_cpd_policy_ref] [varchar](12) NULL,
	[ded_sequence_no] [int] NULL,
	[ded_qual] [varchar](1) NULL,
	[ded_pcnt] [real] NULL,
	[test_case] [int] NULL
) ON [PRIMARY]
GO

CREATE TABLE [Test].[policy_details_01](
	[pol_mop_code] [varchar](3) NULL,
	[pol_cpd_policy_reference] [varchar](12) NULL,
	[pol_syn_user_number] [int] NULL,
	[pol_cob_code] [varchar](3) NULL,
	[pol_stats_code] [varchar](3) NULL,
	[test_case] [int] NULL
) ON [PRIMARY]
GO

CREATE TABLE [Test].[transaction_01](
	[tra_actual_payment_date] [datetime] NULL,
	[tra_bureau_signing_date] [datetime] NULL,
	[tra_bureau_signing_num] [int] NULL,
	[tra_bureau_version_num] [int] NULL,
	[tra_business_category] [nchar](3) NULL,
	[tra_entry_type] [nchar](3) NULL,
	[tra_lloyds_account_type] [nchar](1) NULL,
	[tra_lloyds_ca_qual_cat] [nchar](1) NULL,
	[tra_planned_sett_date] [datetime] NULL,
	[tra_policy_ref] [nchar](12) NULL,
	[tra_processing_period] [datetime] NULL,
	[tra_settlement_ccy_code] [nchar](3) NULL,
	[tra_settlement_date] [datetime] NULL,
	[tra_syn_user_number] [int] NULL,
	[tra_syndicate_net_amount] [float] NULL,
	[tra_treaty_section] [nchar](2) NULL,
	[tra_year_of_account] [int] NULL,
	[transaction_01_id] [bigint] NOT NULL,
	[tra_claim_split_number] [int] NULL,
	[tra_lloyds_ca_cat_code] [nchar](1) NULL,
	[tra_total_discount_pcnt] [real] NULL,	
	[tra_lloyds_risk_class] [nchar](2) NULL,
	[test_case] [int] NULL,
 CONSTRAINT [PK_transaction_01] PRIMARY KEY CLUSTERED 
(
	[transaction_01_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO

CREATE TABLE [Test].[transaction_instalment](
	[ins_actual_payment_date] [datetime] NULL,
	[ins_instalment_amount] [float] NULL,
	[ins_instalment_due_date] [datetime] NULL,
	[ins_pre_br_signing_date] [datetime] NULL,
	[ins_pre_br_signing_num] [int] NULL,
	[ins_pre_br_version_num] [int] NULL,
	[ins_pre_treaty_section] [char](2) NULL,
	[ins_syn_user_number] [int] NULL,
	[ins_instalment_num] [int] NULL,
	[test_case] [int] NULL
) ON [PRIMARY]
GO

-------------------------------------------------

-- Populate new tables with the cases we want to test
INSERT INTO [Test].transaction_01
		--(tra_actual_payment_date, tra_bureau_signing_date, tra_bureau_signing_num, tra_bureau_version_num, tra_business_category, tra_entry_type, tra_lloyds_account_type, tra_lloyds_ca_qual_cat, tra_planned_sett_date, tra_policy_ref, 
		-- tra_processing_period, tra_settlement_ccy_code, tra_settlement_date, tra_syn_user_number, tra_syndicate_net_amount, tra_treaty_section, tra_year_of_account, transaction_01_id, tra_claim_split_number, tra_lloyds_ca_cat_code, tra_total_discount_pcnt, [tra_lloyds_risk_class], [test_case]) 
VALUES 
		('2010-08-14 00:00:00.000', '20100905', 1000, 1, 'PRM', 'CRP', 'A', 'H', GETDATE(), 'POL0001', '20140805', 'GBP', '20140805', 100, 1000, 'AA', 2010, 1000000, 0, 1, 10, 'BB', 1),			-- transaction without installments with valid tra_actual_payment_date, binder
		('2014-08-14 00:00:00.000', '20150102', 1001, 1, 'PRM', 'CRP', 'L', 'I', GETDATE(), 'POL0002', '20140805', 'GBP', '20140805', 101, 3000, 'AA', 2015, 1000001, 0, 1, 15, NULL, 2),			-- transaction with 3 installments with valid ins_actual_payment_date, premium
		('2014-08-14 00:00:00.000', '20140805', 1002, 1, 'PRM', 'NAP', 'A', 'A', GETDATE(), 'POL0003', '20140805', 'GBP', '20140805', 102, 7000, 'AA', 2005, 1000002, 0, 1, 10, 'E6', 3),			-- transaction before 2004 (will be rejected); then change YOA to 2005
		('9999-12-31 23:59:59.000', '20070707', 1000, 1, 'PRD', 'NPM', 'A', 'H', GETDATE(), 'POL0004', '20140805', 'EUR', '20140805', 100, 2000, 'AA', 2010, 1000003, 0, 2, 25, NULL, 4),			-- transaction without installments with tra_actual_payment_date = '9999-12-31', wrong mop code
		('9999-12-31 23:59:59.000', '20070717', 1001, 1, 'PRD', 'CAP', 'S', 'I', GETDATE(), 'POL0005', '20140805', 'GBP', '20140805', 101, 6000, 'AA', 2009, 1000004, 0, 3, 10, NULL, 5),			-- transaction with 2 installments with ins_actual_payment_date = tra_actual_payment_date = '9999-12-31', premium
		('2015-01-10 00:00:00.000', '20080717', 1003, 1, 'PRM', 'CAP', 'L', 'H', GETDATE(), 'POL0006', '20140805', 'EUR', '20140805', 104, 5000, 'AA', 2015, 1000005, 0, 1, 10, 'BB', 6);			-- transaction with 2 installments with ins_actual_payment_date = '9999-12-31', but valid tra_actual_payment_date, binder

INSERT INTO [Test].common_policy_details_01
		--(cpd_expiry, cpd_inception, cpd_policy_reference, cpd_tri_focus, [cpd_udt_initials], [test_case])
VALUES

		('1998-06-02 00:00:00.000', '1997-06-03 00:00:00.000', 'POL0001', NULL, 'JGR', 1),
		('1997-07-22 00:00:00.000', '1997-06-23 00:00:00.000', 'POL0002', NULL, NULL, 2),
		('1998-06-25 00:00:00.000', '1997-06-26 00:00:00.000', 'POL0003', NULL, 'AM8', 3),
		('1997-07-12 00:00:00.000', '1997-06-13 00:00:00.000', 'POL0004', NULL, NULL, 4),
		('1997-08-06 00:00:00.000', '1997-07-07 00:00:00.000', 'POL0005', NULL, NULL, 5),
		('1997-08-27 00:00:00.000', '1997-07-28 00:00:00.000', 'POL0006', NULL, 'JGR', 6);

INSERT INTO [Test].transaction_instalment
		--(ins_actual_payment_date, ins_instalment_amount, ins_instalment_due_date, ins_pre_br_signing_date, ins_pre_br_signing_num, ins_pre_br_version_num, ins_pre_treaty_section, ins_syn_user_number, ins_instalment_num, [test_case])
VALUES
		('2014-08-15 00:00:00.000', 1000.00, '2014-08-15 00:00:00.000', '20150102', 1001, 1, 'AA', 101, 1, 2),
		('2014-08-16 00:00:00.000', 1500.00, '2014-08-15 00:00:00.000', '20150102', 1001, 1, 'AA', 101, 2, 2),
		('2014-08-19 00:00:00.000', 0500.00, '2014-08-15 00:00:00.000', '20150102', 1001, 1, 'AA', 101, 3, 2),
		('9999-12-31 23:59:59.000', 3000.00, '2014-08-15 00:00:00.000', '20070717', 1001, 1, 'AA', 101, 1, 5),
		('9999-12-31 23:59:59.000', 3000.00, '2014-08-15 00:00:00.000', '20070717', 1001, 1, 'AA', 101, 2, 5),
		('9999-12-31 23:59:59.000', 3000.00, '2014-08-15 00:00:00.000', '20080717', 1003, 1, 'AA', 104, 1, 6),
		('9999-12-31 23:59:59.000', 2000.00, '2014-08-15 00:00:00.000', '20080717', 1003, 1, 'AA', 104, 2, 6);

INSERT INTO [Test].policy_details_01
		--(pol_mop_code, pol_cpd_policy_reference, pol_syn_user_number, pol_cob_code, pol_stats_code, [test_case])
VALUES
		('B','POL0001',100,'OC','00',1),
		('J','POL0002',101,'AE',NULL,2),
		('J','POL0003',102,'PA','IN',3),
		('Q','POL0004',100,'AE',NULL,4),
		('J','POL0005',101,'AE',NULL,5),
		('B','POL0006',104,'OC','00',6);

INSERT INTO [Test].policy_deductions
		--(ded_cpd_policy_ref, ded_sequence_no, ded_qual, ded_pcnt, [test_case])
VALUES
		('POL0001',1,'B',10,1),
		('POL0002',1,'B',15,2),
		('POL0003',1,'P',10,3),
		('POL0004',1,'B',25,4),
		('POL0005',1,'P',10,5),
		('POL0006',1,'B',10,6);


/* ==== Inbound Zone: Test results ==== */

-- Cleanup
DROP TABLE IF EXISTS [Test].[Transaction]

-- Expected result table
CREATE TABLE [Test].[Transaction](
	[PK_Transaction] [bigint] NOT NULL,
	[Scenario] [varchar](2) NOT NULL,
	[Account] [varchar](10) NOT NULL,
	[Dataset] [varchar](255) NOT NULL,
	[DateOfFact] [datetime] NOT NULL,
	[BusinessKey] [varchar](255) NOT NULL,
	[PolicyNumber] [varchar](255) NOT NULL,
	[InceptionDate] [datetime] NOT NULL,
	[ExpiryDate] [datetime] NOT NULL,
	[BindDate] [datetime] NOT NULL,
	[DueDate] [datetime] NOT NULL,
	[TrifocusCode] [varchar](25) NOT NULL,
	[Entity] [varchar](25) NOT NULL,
	[YOA] [varchar](5) NOT NULL,
	[TypeOfBusiness] [varchar](1) NOT NULL,
	[StatsCode] [varchar](25) NULL,
	[SettlementCCY] [varchar](3) NOT NULL,
	[OriginalCCY] [varchar](3) NOT NULL,
	[IsToDate] [varchar](1) NOT NULL,
	[Value] [numeric](19, 4) NOT NULL,
	[RowHash] [varbinary](255) NULL,
	[FK_Allocation] [int] NULL,
	[DeltaType] [varchar](50) NULL,
	[AuditSourceBatchID] [varchar](255) NOT NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditGenerateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL,
	[AuditHost] [nvarchar](255) NOT NULL,
	[Basis] [varchar](2) NOT NULL,
	[Location] [varchar](50) NOT NULL,
	[ValueOrig] [numeric](19, 4) NULL,
	[BusinessProcessCode] [varchar](255) NULL,
	[FK_Batch] [int] NULL,
	[test_case] [int] NULL
) ON [PRIMARY]
GO

-- Expected result table

INSERT [Test].[Transaction] 
		( [PK_Transaction], [Scenario], [Account], [Dataset], [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate], [ExpiryDate], [BindDate], [DueDate]
		, [TrifocusCode], [Entity], [YOA], [TypeOfBusiness], [StatsCode], [SettlementCCY], [OriginalCCY], [IsToDate], [Value], [RowHash], [FK_Allocation], [DeltaType], [AuditSourceBatchID]
		, [AuditCreateDateTime], [AuditGenerateDateTime], [AuditUserCreate], [AuditHost], [Basis], [Location], [ValueOrig], [BusinessProcessCode], [FK_Batch], [test_case]) 
VALUES 
		 (90132431, N'A', N'BC-LS-RT', N'LPSO', CAST(N'2010-08-14T00:00:00.000' AS DateTime), N'1000000|0', N'POL0001     ', CAST(N'1997-06-03T00:00:00.000' AS DateTime), CAST(N'1998-06-02T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), N'Contingency              ', N'100', N'2010', N'-', N'-', N'GBP', N'GBP', N'Y', CAST(111.1111 AS Numeric(19, 4)), 0x72EE7D194BEE07D8040F173D3E29EFCFF4801324DD7952CA198C586C9EE6DE86AD168F511F736F5D9B930D67D78F6F9EE868F5EFD5A3533D46C579B4A4B8A3DE, NULL, N'New', N'409', CAST(N'2020-05-07T13:59:54.030' AS DateTime), CAST(N'2020-05-07T13:56:36.763' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'B', N'-', CAST(111.1111 AS Numeric(19, 4)), N'T1', 409, 1)
		,(90132447, N'A', N'PC-LS-RT', N'LPSO', CAST(N'2010-08-14T00:00:00.000' AS DateTime), N'1000000|0', N'POL0001     ', CAST(N'1997-06-03T00:00:00.000' AS DateTime), CAST(N'1998-06-02T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), N'Contingency              ', N'100', N'2010', N'-', N'-', N'GBP', N'GBP', N'Y', CAST(1111.1111 AS Numeric(19, 4)), 0x54BB1B5D522EDC769B742482200459DEAD2EACD8E69B7D705FC17F1D2A5BE4EFAB0E3DDB94CE8FFB341CF33CAD8EBC404B7535B55300981C7C4196141995F28F, NULL, N'New', N'409', CAST(N'2020-05-07T13:59:54.030' AS DateTime), CAST(N'2020-05-07T13:56:36.763' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'B', N'-', CAST(1111.1111 AS Numeric(19, 4)), N'T1', 409, 1)
		,(90135993, N'A', N'BC-SD-PC', N'LPSO', CAST(N'2014-08-15T00:00:00.000' AS DateTime), N'1000001|1', N'POL0002     ', CAST(N'1997-06-23T00:00:00.000' AS DateTime), CAST(N'1997-07-22T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), N'Open Market', N'101', N'2015', N'-', N'-', N'GBP', N'GBP', N'Y', CAST(176.4706 AS Numeric(19, 4)), 0xB9B994D4271979CB0046757FD6323AB9D1A60D3300DBFBC186977D4C229AAD6E3F660F5E7A7B698B6E02567A5A5D2A5F16C63D92C5D330BE71FCCC134F13330E, NULL, N'New', N'410', CAST(N'2020-05-07T14:01:59.377' AS DateTime), CAST(N'2020-05-07T14:01:40.860' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'B', N'-', CAST(176.4706 AS Numeric(19, 4)), N'T1', 410, 2)
		,(90135994, N'A', N'BC-SD-PC', N'LPSO', CAST(N'2014-08-16T00:00:00.000' AS DateTime), N'1000001|2', N'POL0002     ', CAST(N'1997-06-23T00:00:00.000' AS DateTime), CAST(N'1997-07-22T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), N'Open Market', N'101', N'2015', N'-', N'-', N'GBP', N'GBP', N'Y', CAST(264.7059 AS Numeric(19, 4)), 0x1DA612E94DFD2D12ACCAD28B248CAF1A006C200F8965AC50E01344EDDC94A491FFC6AFBD155952456488557D5BA2060BD46E525B48E047E95BC624D012D6551F, NULL, N'New', N'410', CAST(N'2020-05-07T14:01:59.377' AS DateTime), CAST(N'2020-05-07T14:01:40.860' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'B', N'-', CAST(264.7059 AS Numeric(19, 4)), N'T1', 410, 2)
		,(90135995, N'A', N'BC-SD-PC', N'LPSO', CAST(N'2014-08-19T00:00:00.000' AS DateTime), N'1000001|3', N'POL0002     ', CAST(N'1997-06-23T00:00:00.000' AS DateTime), CAST(N'1997-07-22T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), N'Open Market', N'101', N'2015', N'-', N'-', N'GBP', N'GBP', N'Y', CAST(88.2353 AS Numeric(19, 4)), 0xD853B93F228F2C48EE1CA95A4AA31C956254746D6A8554E1846E093367D5A683211E5F52B5FC65FD028E316807365E3D00BE7497D2F0DFBF5B1830DF63687F33, NULL, N'New', N'410', CAST(N'2020-05-07T14:01:59.377' AS DateTime), CAST(N'2020-05-07T14:01:40.860' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'B', N'-', CAST(88.2353 AS Numeric(19, 4)), N'T1', 410, 2)
		,(90135996, N'A', N'PC-SD-PC', N'LPSO', CAST(N'2014-08-15T00:00:00.000' AS DateTime), N'1000001|1', N'POL0002     ', CAST(N'1997-06-23T00:00:00.000' AS DateTime), CAST(N'1997-07-22T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), N'Open Market', N'101', N'2015', N'-', N'-', N'GBP', N'GBP', N'Y', CAST(1176.4706 AS Numeric(19, 4)), 0x5950139BA7862730E4AA98DCF464CFC938C7B6B35D400A1DA2BBE7F3AE3CAFB3CDF9159A555FA71D1D5E2A22037C3E923769F76D1740566393EE88BC6F0C27D7, NULL, N'New', N'410', CAST(N'2020-05-07T14:01:59.377' AS DateTime), CAST(N'2020-05-07T14:01:40.860' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'B', N'-', CAST(1176.4706 AS Numeric(19, 4)), N'T1', 410, 2)
		,(90135997, N'A', N'PC-SD-PC', N'LPSO', CAST(N'2014-08-16T00:00:00.000' AS DateTime), N'1000001|2', N'POL0002     ', CAST(N'1997-06-23T00:00:00.000' AS DateTime), CAST(N'1997-07-22T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), N'Open Market', N'101', N'2015', N'-', N'-', N'GBP', N'GBP', N'Y', CAST(1764.7059 AS Numeric(19, 4)), 0x1DE52ABC4658F3F0E5F32C6CFD85660F33B49D6F909C14318956AC8E8C52DD9DF3B3BD95D8CFBFEE530B774C23A52FFD86B8B6E1CF2EDF4002608D3D99E7D4CD, NULL, N'New', N'410', CAST(N'2020-05-07T14:01:59.377' AS DateTime), CAST(N'2020-05-07T14:01:40.860' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'B', N'-', CAST(1764.7059 AS Numeric(19, 4)), N'T1', 410, 2)
		,(90135998, N'A', N'PC-SD-PC', N'LPSO', CAST(N'2014-08-19T00:00:00.000' AS DateTime), N'1000001|3', N'POL0002     ', CAST(N'1997-06-23T00:00:00.000' AS DateTime), CAST(N'1997-07-22T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), N'Open Market', N'101', N'2015', N'-', N'-', N'GBP', N'GBP', N'Y', CAST(588.2353 AS Numeric(19, 4)), 0x807480791E73E7120DB0FF3EB67D9E194715CB0F49B22BC4CF9E02B412EB0CFF1449443E3BB31F8CB387225C6AE08CF2B048A40EF0D102C1931DC1655CAE7344, NULL, N'New', N'410', CAST(N'2020-05-07T14:01:59.377' AS DateTime), CAST(N'2020-05-07T14:01:40.860' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'B', N'-', CAST(588.2353 AS Numeric(19, 4)), N'T1', 410, 2)
		,(90135999, N'A', N'BC-LS-RT', N'LPSO', CAST(N'2007-07-07T00:00:00.000' AS DateTime), N'1000003|0', N'POL0004     ', CAST(N'1997-06-13T00:00:00.000' AS DateTime), CAST(N'1997-07-12T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), N'Open Market', N'100', N'2010', N'-', N'-', N'EUR', N'EUR', N'Y', CAST(666.6667 AS Numeric(19, 4)), 0x11B5138590F623D46A6681EEB5BA15DD0F9A88A71EC599253318F1294E83A5446C12FB8CCFF95A0E6FE663D710BCF0E4F2F6770BD367D6EDA97E64C7F71CB611, NULL, N'New', N'411', CAST(N'2020-05-07T14:03:36.867' AS DateTime), CAST(N'2020-05-07T14:03:34.380' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'B', N'-', CAST(666.6667 AS Numeric(19, 4)), N'T1', 411, 4)
		,(90136000, N'A', N'PC-LS-RT', N'LPSO', CAST(N'2007-07-07T00:00:00.000' AS DateTime), N'1000003|0', N'POL0004     ', CAST(N'1997-06-13T00:00:00.000' AS DateTime), CAST(N'1997-07-12T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), N'Open Market', N'100', N'2010', N'-', N'-', N'EUR', N'EUR', N'Y', CAST(2666.6667 AS Numeric(19, 4)), 0xABF2F0E250A32A353A9DFC4701F109F73DBF6E1D60B7ECCE2FDE1A32613F90EFE65DBB147F8BA61887167B05FA4E80AA8DBC805829BD2057CE9F43657161BD50, NULL, N'New', N'411', CAST(N'2020-05-07T14:03:36.867' AS DateTime), CAST(N'2020-05-07T14:03:34.380' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'B', N'-', CAST(2666.6667 AS Numeric(19, 4)), N'T1', 411, 4)
		,(90136001, N'A', N'PC-SD-PC', N'LPSO', CAST(N'2007-07-17T00:00:00.000' AS DateTime), N'1000004|2', N'POL0005     ', CAST(N'1997-07-07T00:00:00.000' AS DateTime), CAST(N'1997-08-06T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), N'Open Market', N'101', N'2009', N'-', N'-', N'GBP', N'GBP', N'Y', CAST(3333.3333 AS Numeric(19, 4)), 0x98E0F7C3406F1AB37D0B5F27692D42474681F39B65DCBFE7561B6AC78DDA99E45588E179DFFE5F69D62599A8BD5237F8707F2691485E4848A0E44D2054717449, NULL, N'New', N'412', CAST(N'2020-05-07T14:03:59.220' AS DateTime), CAST(N'2020-05-07T14:03:57.300' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'B', N'-', CAST(3333.3333 AS Numeric(19, 4)), N'T1', 412, 5)
		,(90136002, N'A', N'BC-SD-PC', N'LPSO', CAST(N'2007-07-17T00:00:00.000' AS DateTime), N'1000004|1', N'POL0005     ', CAST(N'1997-07-07T00:00:00.000' AS DateTime), CAST(N'1997-08-06T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), N'Open Market', N'101', N'2009', N'-', N'-', N'GBP', N'GBP', N'Y', CAST(333.3333 AS Numeric(19, 4)), 0xDF2FBA6302241976190DD09168E2695821288563D47C44A4C15608F7A47D4C70ECC971A4895034786F5E5656F0AA32758BED024BDCE58F208CDF2A5A19E90D50, NULL, N'New', N'412', CAST(N'2020-05-07T14:03:59.220' AS DateTime), CAST(N'2020-05-07T14:03:57.300' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'B', N'-', CAST(333.3333 AS Numeric(19, 4)), N'T1', 412, 5)
		,(90136003, N'A', N'BC-SD-PC', N'LPSO', CAST(N'2007-07-17T00:00:00.000' AS DateTime), N'1000004|2', N'POL0005     ', CAST(N'1997-07-07T00:00:00.000' AS DateTime), CAST(N'1997-08-06T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), N'Open Market', N'101', N'2009', N'-', N'-', N'GBP', N'GBP', N'Y', CAST(333.3333 AS Numeric(19, 4)), 0x2DBD93008BB4BCCDFC7957F90F946424548BF44F443C15C39A225527D9B3526CA36560376E2E17EFC52673AE2FB4D4902C319B3216FB3379758EAD1899D1D2ED, NULL, N'New', N'412', CAST(N'2020-05-07T14:03:59.220' AS DateTime), CAST(N'2020-05-07T14:03:57.300' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'B', N'-', CAST(333.3333 AS Numeric(19, 4)), N'T1', 412, 5)
		,(90136004, N'A', N'PC-SD-PC', N'LPSO', CAST(N'2007-07-17T00:00:00.000' AS DateTime), N'1000004|1', N'POL0005     ', CAST(N'1997-07-07T00:00:00.000' AS DateTime), CAST(N'1997-08-06T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), N'Open Market', N'101', N'2009', N'-', N'-', N'GBP', N'GBP', N'Y', CAST(3333.3333 AS Numeric(19, 4)), 0xB85227688E9EE42FE3A183F6D925F6B04B0F2A8A6CD0782809C905EA519173AFCF8BCFFC2F9121FD008C0CC0C5C4CAF175C05BE1E613A301C50673ADA8BAA8F3, NULL, N'New', N'412', CAST(N'2020-05-07T14:03:59.220' AS DateTime), CAST(N'2020-05-07T14:03:57.300' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'B', N'-', CAST(3333.3333 AS Numeric(19, 4)), N'T1', 412, 5)
		,(90136005, N'A', N'BC-SD-RT', N'LPSO', CAST(N'2015-01-10T00:00:00.000' AS DateTime), N'1000005|2', N'POL0006     ', CAST(N'1997-07-28T00:00:00.000' AS DateTime), CAST(N'1997-08-27T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), N'Contingency              ', N'104', N'2015', N'-', N'-', N'EUR', N'EUR', N'Y', CAST(222.2222 AS Numeric(19, 4)), 0x03BBA5E06E5D5284C8B49F0D63719A70CE97EA18E7A361C83DDFE20AE3105C953E071CD871AFF590BAD8FE7F070A5E2CCA4ACDB21AC24E0097FC1A863F1F0525, NULL, N'New', N'413', CAST(N'2020-05-07T14:04:22.343' AS DateTime), CAST(N'2020-05-07T14:04:19.873' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'B', N'-', CAST(222.2222 AS Numeric(19, 4)), N'T1', 413, 6)
		,(90136006, N'A', N'PC-SD-RT', N'LPSO', CAST(N'2015-01-10T00:00:00.000' AS DateTime), N'1000005|1', N'POL0006     ', CAST(N'1997-07-28T00:00:00.000' AS DateTime), CAST(N'1997-08-27T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), N'Contingency              ', N'104', N'2015', N'-', N'-', N'EUR', N'EUR', N'Y', CAST(3333.3333 AS Numeric(19, 4)), 0xB86267AD030B9FB64691B95F8AF8D45C528F17A1C516E82B666FFEB48295353749FA99ED9F2571830E2190B24487BBA507F220B33757A668F16FB7AED016B975, NULL, N'New', N'413', CAST(N'2020-05-07T14:04:22.343' AS DateTime), CAST(N'2020-05-07T14:04:19.873' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'B', N'-', CAST(3333.3333 AS Numeric(19, 4)), N'T1', 413, 6)
		,(90136007, N'A', N'PC-SD-RT', N'LPSO', CAST(N'2015-01-10T00:00:00.000' AS DateTime), N'1000005|2', N'POL0006     ', CAST(N'1997-07-28T00:00:00.000' AS DateTime), CAST(N'1997-08-27T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), N'Contingency              ', N'104', N'2015', N'-', N'-', N'EUR', N'EUR', N'Y', CAST(2222.2222 AS Numeric(19, 4)), 0x5CFB02FC34DE07C5642C18FFDB1CDDFD49D1956AE298BFB7CEBBE40521D0F69B9BE847669F2360BCB110348513DDAF81C9FCA6B024C61496994B8BE3D2E2D546, NULL, N'New', N'413', CAST(N'2020-05-07T14:04:22.343' AS DateTime), CAST(N'2020-05-07T14:04:19.873' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'B', N'-', CAST(2222.2222 AS Numeric(19, 4)), N'T1', 413, 6)
		,(90136008, N'A', N'BC-SD-RT', N'LPSO', CAST(N'2015-01-10T00:00:00.000' AS DateTime), N'1000005|1', N'POL0006     ', CAST(N'1997-07-28T00:00:00.000' AS DateTime), CAST(N'1997-08-27T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), N'Contingency              ', N'104', N'2015', N'-', N'-', N'EUR', N'EUR', N'Y', CAST(333.3333 AS Numeric(19, 4)), 0xB844298176B119EBDFF7AB9E72D298B78148BCBAE0501A3126D1ACB434292FDDB371CE0DAE53B0460648B59003A20239331A0993109BBE12DC1049D6EC6ACB27, NULL, N'New', N'413', CAST(N'2020-05-07T14:04:22.343' AS DateTime), CAST(N'2020-05-07T14:04:19.873' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'B', N'-', CAST(333.3333 AS Numeric(19, 4)), N'T1', 413, 6)
		,(90136009, N'A', N'BC-LS-OT', N'LPSO', CAST(N'2014-08-14T00:00:00.000' AS DateTime), N'1000002|0', N'POL0003     ', CAST(N'1997-06-26T00:00:00.000' AS DateTime), CAST(N'1998-06-25T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), N'Intl PI A&E Small        ', N'102', N'2005', N'-', N'-', N'GBP', N'GBP', N'Y', CAST(777.7778 AS Numeric(19, 4)), 0x1E8FC494D4F4CA9E1CDD5E64EB4A48E34A94CEFF41A88737E24D547A526D10F95FE3E2340A2A0DBEABC5D0ED876067B2CC5FF0779C596107D72E7138F0258FA9, NULL, N'New', N'414', CAST(N'2020-05-07T14:05:13.230' AS DateTime), CAST(N'2020-05-07T14:05:10.963' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'B', N'-', CAST(777.7778 AS Numeric(19, 4)), N'T1', 414, 3)
		,(90136010, N'A', N'PC-LS-OT', N'LPSO', CAST(N'2014-08-14T00:00:00.000' AS DateTime), N'1000002|0', N'POL0003     ', CAST(N'1997-06-26T00:00:00.000' AS DateTime), CAST(N'1998-06-25T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), CAST(N'1980-01-01T00:00:00.000' AS DateTime), N'Intl PI A&E Small        ', N'102', N'2005', N'-', N'-', N'GBP', N'GBP', N'Y', CAST(7777.7778 AS Numeric(19, 4)), 0x0A75D0A1DD19E8F4E9BC80A9B685300EE14AC270A2AAC3F0E2D1412F05943B74B21A214939DF023F1BA89730B7AC0079DE1F904874514C0A124B73D64C6D77CB, NULL, N'New', N'414', CAST(N'2020-05-07T14:05:13.230' AS DateTime), CAST(N'2020-05-07T14:05:10.963' AS DateTime), N'BFL\mandc', N'UKDVDB149', N'B', N'-', CAST(7777.7778 AS Numeric(19, 4)), N'T1', 414, 3)
	
GO