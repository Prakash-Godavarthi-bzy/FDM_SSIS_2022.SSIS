﻿use FinanceLanding

         DECLARE @Trancount INT = @@Trancount
         BEGIN TRY
              IF @Trancount = 0 BEGIN TRAN;

					   delete from FinanceDataContract.outbound.Pattern where dataset='NatCatEarning'
					   delete from FinanceDataContract.inbound.Pattern where dataset='NatCatEarning'
					   delete from financelanding.xls.NatCatEarning;
					   --select * from  FinanceDataContract.Outbound.[Pattern] where DataSet='NatCatEarning';
	                   --select * from financelanding.xls.NatCatEarning;
/*
========================================================================================================================================================================
Inserting Data into Landing Tables and Loading data from Landing to InBound.Pattern
========================================================================================================================================================================
*/

                       INSERT INTO FinanceLanding.xls.NatCatEarning
					   ( [FileName],
                         [LoadDate],
                         [Quarter],
                         [Trifocus_Group],
                         [Pct_unearned],
						 [Department],
						 [YOA],
                         [Inception Year],
                         [Entity]
					   )
                       VALUES ('Copy of Cat Margin Importer_2019Q4.xlsb','2020-01-21 11:01:39.5140000',1,	'Cargo',0.03,'Marine','2016',2016,'623/2623')

					    INSERT INTO FinanceLanding.xls.NatCatEarning
					   ( [FileName],
                         [LoadDate],
                         [Quarter],
                         [Trifocus_Group],
                         [Pct_unearned],
						 [Department],
						 [YOA],
                         [Inception Year],
                         [Entity]
					   )
                       VALUES ('Copy of Cat Margin Importer_2019Q4.xlsb','2020-01-21 11:01:39.5140000',2,	'Cargo',0.02,'Marine','2016',2016,'623/2623')




INSERT INTO Batch(CreateDate,DataSet,latestbusineskey) VALUES (GETDATE(),'NatCatEarning','NatCatEarning')

EXECUTE FinanceLanding.[xls].[usp_NatCatEarningLandingToInbound_Pattern]

DECLARE       @BatchId INT;
SELECT        @BatchId= MAX([PK_Batch])
FROM          dbo.[Batch]
WHERE         [DataSet] ='NatCatEarning'

select  @BatchId
/*
=========================================================================================================================================================================
Expected Results Loading InTo Temp Table
=========================================================================================================================================================================
*/
       DROP TABLE IF EXISTS #Temp_Inbound_Pattern;

       CREATE TABLE #Temp_Inbound_Pattern
	(
	[PatternScenario] [varchar](10) NOT NULL,
	[PatternScenarioVersion] [int] NOT NULL,
	[PatternName] [varchar](10) NOT NULL,
	[DataSet] [varchar](50) NOT NULL,
	[TrifocusCode] [varchar](100) NOT NULL,
	[YOA] [varchar](5) NULL,
	[InceptionYear] [smallint] NULL,
	[SettlementCCY] [varchar](3) NULL,
	[DevelopmentPercentageIncrement] [numeric](19, 6) NOT NULL,
	[DevelopmentQuarter] [int] NOT NULL,
	[AuditSourceBatchID] [varchar](255) NOT NULL,
	[BusinessProcessCode] [varchar](255) NULL,
    )


       INSERT INTO #Temp_Inbound_Pattern    
	  (
	[PatternScenario],
	[PatternScenarioVersion],
	[PatternName],
	[DataSet],
	[TrifocusCode],
	[YOA],
	[InceptionYear],
	[SettlementCCY],
	[DevelopmentPercentageIncrement],
	[DevelopmentQuarter],
	[AuditSourceBatchID],
	[BusinessProcessCode]	
    )
       values   (
	   '2019Q4',  
	   1,
	   'C-GC-NE',
	   'NatCatEarning',
	   'TRI00003',
	   '2016',
	   2016,
	   'UNK',
	   0.97,
	   1,
	   @BatchId,
		'T1' )
  INSERT INTO #Temp_Inbound_Pattern    
	  (
	[PatternScenario],
	[PatternScenarioVersion],
	[PatternName],
	[DataSet],
	[TrifocusCode],
	[YOA],
	[InceptionYear],
	[SettlementCCY],
	[DevelopmentPercentageIncrement],
	[DevelopmentQuarter],
	[AuditSourceBatchID],
	[BusinessProcessCode]	
    )
       values   (
	   '2019Q4',  
	   1,
	   'C-GC-NE',
	   'NatCatEarning',
	   'TRI00003',
	   '2016',
	   2016,
	   'UNK',
	   0.01,
	   2,
	   @BatchId,
		'T1' )


select * from #Temp_Inbound_Pattern 
select * FROM [FinanceDataContract].[inbound].[Pattern]   WHERE [FK_Batch]=@BatchId    
	 
	        
/*
==========================================================================================================================================================================
Comparing Temp table with InBound.Pattern
==========================================================================================================================================================================
*/
SELECT   IIF(COUNT(*)>0,'FAIL','PASS') 
	FROM 
		(	
   SELECT
	[PatternScenario],
	[PatternScenarioVersion],
	[PatternName],
	[DataSet],
	[TrifocusCode],
	[YOA],
	[InceptionYear],
	[SettlementCCY],
	[DevelopmentPercentageIncrement],
	[DevelopmentQuarter],
	[AuditSourceBatchID],
	[BusinessProcessCode]
                                                              
	  FROM  #Temp_Inbound_Pattern  WHERE AuditSourceBatchID=@BatchId
       EXCEPT 
   SELECT
	[PatternScenario],
	[PatternScenarioVersion],
	[PatternName],
	[DataSet],
	[TrifocusCode],
	[YOA],
	[InceptionYear],
	[SettlementCCY],
	[DevelopmentPercentageIncrement],
	[DevelopmentQuarter],
	[AuditSourceBatchID],
	[BusinessProcessCode]
      FROM [FinanceDataContract].[Inbound].[Pattern]   WHERE AuditSourceBatchID=@BatchId 
                     
      )A
					
		 ROLLBACK; 
         END TRY
         BEGIN CATCH
               ROLLBACK;
              THROW;
         END CATCH