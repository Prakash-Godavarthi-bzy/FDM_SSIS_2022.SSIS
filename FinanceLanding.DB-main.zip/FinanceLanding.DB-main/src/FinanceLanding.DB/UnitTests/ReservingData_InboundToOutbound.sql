﻿	use FinanceDataContract
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
	IF @Trancount = 0 BEGIN TRAN;
	--rollback
	--Clear outbound 
	--select * from FinanceDataContract.Outbound.[Transaction] where BusinessKey='Specialty Lines|BUSA Specialty Surety|2015|Gross|USD|Pure Premium|Attritional|-|623|Pure Premium                                      |-  |'
	delete from  Outbound.[Transaction] where DataSet='ReservingData';
	delete from  Inbound.[Transaction] ;
	/*=====================================================================================================================
				Set up Data for Test
	 ======================================================================================================================*/
	----Batch1 set up and process
	WITH	src
					([Scenario]
					,[Basis]
					,[Account]
					,[DataSet]
					,[DateOfFact]
					,[BusinessKey]
					,[PolicyNumber]
					,[InceptionDate]
					,[ExpiryDate]
					,[BindDate]
					,[DueDate]
					,[TrifocusCode]
					,[Entity]
					,[Location]
					,[YOA]
					,[TypeOfBusiness]
					,[SettlementCCY]
					,[OriginalCCY]
					,[IsToDate]
					--,[ValueSett]
					--,[ValueOrig]
					,[RowHash]
					,[BusinessProcessCode]
					,[AuditSourceBatchID]
					,[AuditHost]
					,AuditGenerateDateTime
					,[StatsCode]
					,[FK_Batch])

	AS	(
	       select 'F'	
		          ,'E'
				  ,'GP-P-PR'
				  ,'ReservingData'	
				  ,CAST('2019-06-01T00:00:00' AS Date)
				  ,'Specialty Lines|BUSA Specialty Surety|2015|Gross|USD|Pure Premium|Attritional|-|623|Pure Premium                                      |-  |'
				  ,'NOPOLICY'
				  ,CAST('1980-01-01T00:00:00' AS Date)
				  ,CAST('1980-01-01T00:00:00' AS Date)
				  ,CAST('1980-01-01T00:00:00' AS Date)
				  ,CAST('1980-01-01T00:00:00' AS Date)
				  ,'746'
				  ,'623'
				  ,'-'
				  ,2015
				  ,'-'
				  ,'USD'
				  ,'USD'
				  ,'Y'
				  ,null--0x9B07D06E07CC72EFF5B57CA24EE35F804266EB2B0D2947663DB22E3BDF5E5FDB1CFC528DAFFFAC0A1FD44C74540E56F1987C664A5C824D9BCAC6C6C398686567
				  ,'T1'
				  ,0
				  ,CAST(SERVERPROPERTY('MachineName') AS [VARCHAR](255))
				  ,GETUTCDATE()
				  ,'New'	
				  ,201906
				  )
			
	
	SELECT	         [Scenario]
					,[Basis]
					,[Account]
					,[DataSet]
					,[DateOfFact]
					,[BusinessKey]
					,[PolicyNumber]
					,[InceptionDate]
					,[ExpiryDate]
					,[BindDate]
					,[DueDate]
					,[TrifocusCode]
					,[Entity]
					,[Location]
					,[YOA]
					,[TypeOfBusiness]
					,[SettlementCCY]
					,[OriginalCCY]
					,[IsToDate]
					--,[ValueSett]
					--,[ValueOrig]
					,[RowHash]=HASHBYTES('SHA2_512',
										CONCAT(
												 CAST(Scenario AS VARCHAR(2000))		,'§~§'
												,CAST(Basis AS VARCHAR(2000))			,'§~§'
												,CAST(Account AS VARCHAR(2000))			,'§~§'
												,CAST(DataSet AS VARCHAR(2000))	,'§~§'
												,CAST(BusinessKey AS VARCHAR(2000))		,'§~§'
												,CAST(PolicyNumber AS VARCHAR(2000))	,'§~§'
												,CONVERT(VARCHAR(10),InceptionDate,102)	,'§~§'
												,CONVERT(VARCHAR(10),ExpiryDate,102)	,'§~§'
												,CONVERT(VARCHAR(10),BindDate,102)		,'§~§'
												,CONVERT(VARCHAR(10),DueDate,102)		,'§~§'
												,CAST(TrifocusCode AS VARCHAR(2000))	,'§~§'
												,CAST(Entity AS VARCHAR(2000))			,'§~§'
												,CAST(Location AS VARCHAR(2000))		,'§~§'
												,CAST(YOA AS VARCHAR(2000))				,'§~§'
												,CAST(TypeOfBusiness AS VARCHAR(2000))	,'§~§'
												,CAST(StatsCode AS VARCHAR(2000))		,'§~§'
												,CAST(SettlementCCY AS VARCHAR(2000))	,'§~§'
												,CAST(OriginalCCY AS VARCHAR(2000))		,'§~§'
												,CAST(IsToDate AS VARCHAR(2000))		,'§~§'									 
											)
									)
					,[BusinessProcessCode]
					,[AuditSourceBatchID]
					,[AuditHost]
					,AuditGenerateDateTime
					,[StatsCode]
					,[FK_Batch]
	
	INTO	#StaticSrcValues 
	FROM	src

	--select * from #StaticSrcValues
	
	INSERT INTO Inbound.[Transaction] (
	                 [Scenario]
					,[Basis]
					,[Account]
					,[DataSet]
					,[DateOfFact]
					,[BusinessKey]
					,[PolicyNumber]
					,[InceptionDate]
					,[ExpiryDate]
					,[BindDate]
					,[DueDate]
					,[TrifocusCode]
					,[Entity]
					,[Location]
					,[YOA]
					,[TypeOfBusiness]
					,[SettlementCCY]
					,[OriginalCCY]
					,[IsToDate]
					,[Value]
					,[ValueOrig]
					,[RowHash]
					,[BusinessProcessCode]
					,[AuditSourceBatchID]
					,[AuditHost]
					,AuditGenerateDateTime
					,[StatsCode]
					,[FK_Batch])	
	OUTPUT	Inserted.AuditSourceBatchID, 'InBound', 'ReservingData',NULL,inserted.fk_batch
	INTO	Inbound.BatchQueue(PK_Batch, Status, DataSet, RunDescription,OriginalName)
	SELECT	         [Scenario]
					,[Basis]
					,[Account]
					,[DataSet]
					,[DateOfFact]
					,[BusinessKey]
					,[PolicyNumber]
					,[InceptionDate]
					,[ExpiryDate]
					,[BindDate]
					,[DueDate]
					,[TrifocusCode]
					,[Entity]
					,[Location]
					,[YOA]
					,[TypeOfBusiness]
					,[SettlementCCY]
					,[OriginalCCY]
					,[IsToDate]
					,v.value
					,v.value
					,[RowHash]
					,[BusinessProcessCode]
					,v.AuditSourceBatchId
					,[AuditHost]
					,AuditGenerateDateTime
					,[StatsCode]
					,[FK_Batch]
	
	FROM	#StaticSrcValues  
	CROSS JOIN	(SELECT	value = CAST(100.0000 AS Numeric(19, 4)),AuditSourceBatchId = -1) v;

	--select * from inbound.[transaction] where DataSet='ReservingData'
      
	EXECUTE FinanceDataContract.Inbound.usp_InboundOutboundWorkflow ;

	select * from outbound.[transaction] where DataSet='ReservingData'
	 -----Batch2 set up and process
	delete from 	inbound.[Transaction] where DataSet='ReservingData'

	INSERT INTO Inbound.[Transaction] (
	                 [Scenario]
					,[Basis]
					,[Account]
					,[DataSet]
					,[DateOfFact]
					,[BusinessKey]
					,[PolicyNumber]
					,[InceptionDate]
					,[ExpiryDate]
					,[BindDate]
					,[DueDate]
					,[TrifocusCode]
					,[Entity]
					,[Location]
					,[YOA]
					,[TypeOfBusiness]
					,[SettlementCCY]
					,[OriginalCCY]
					,[IsToDate]
					,[Value]
					,[ValueOrig]
					,[RowHash]
					,[BusinessProcessCode]
					,[AuditSourceBatchID]
					,[AuditHost]
					,AuditGenerateDateTime
					,[StatsCode]
					,[FK_Batch])	
	OUTPUT	inserted.[AuditSourceBatchID], 'Inbound', 'ReservingData',NULL,Inserted.fk_batch
	INTO	Inbound.BatchQueue(PK_Batch, [Status], DataSet, RunDescription,OriginalName)
	SELECT	[Scenario]
					,[Basis]
					,[Account]
					,[DataSet]
					,[DateOfFact]
					,[BusinessKey]
					,[PolicyNumber]
					,[InceptionDate]
					,[ExpiryDate]
					,[BindDate]
					,[DueDate]
					,[TrifocusCode]
					,[Entity]
					,[Location]
					,[YOA]
					,[TypeOfBusiness]
					,[SettlementCCY]
					,[OriginalCCY]
					,[IsToDate]
					,v.value
					,v.value
					,[RowHash]
					,[BusinessProcessCode]
					,v.AuditSourceBatchID
					,[AuditHost]
					,AuditGenerateDateTime
					,[StatsCode]
					,fk_batch
	
	FROM	#StaticSrcValues 
	CROSS JOIN	(SELECT	value = CAST(140.0000 AS Numeric(19, 4)), AuditSourceBatchID = -2) v;

	--select * from inbound.[transaction] where DataSet='ReservingData';

	EXECUTE FinanceDataContract.Inbound.usp_InboundOutboundWorkflow 

   select * from outbound.[transaction] where DataSet='ReservingData';

		 
/*=====================================================================================================================
            Run Test and Roll back dont commit test data to tables
 ======================================================================================================================*/
	WITH	Expected (AuditSourceBatchID, Value,TestName)
	AS		(
				SELECT CAST(- 1 AS VARCHAR(20)) , 100.0000,'New' UNION
				SELECT CAST( - 2 AS VARCHAR(20)) , 40.0000 ,'DeltaAddition'
			)
	SELECT	OutboundValue	= ISNULL(Outbound.ValueOrig, 0.0000)
			,ExpectedValue = e.Value
			,TestName		= e.TestName
			,TestResult		= IIF (Outbound.ValueOrig != e.Value, 'Fail', 'Pass')
			,Outbound.DeltaType
	FROM	Expected e
	LEFT JOIN	Outbound.[Transaction]	AS Outbound ON e.AuditSourceBatchID = Outbound.AuditSourceBatchID
	ORDER BY Outbound.AuditSourceBatchID ASC;

    IF @Trancount = 0 ROLLBACK; 
END TRY
BEGIN CATCH
    IF @Trancount = 0  ROLLBACK;
    THROW;
END CATCH;