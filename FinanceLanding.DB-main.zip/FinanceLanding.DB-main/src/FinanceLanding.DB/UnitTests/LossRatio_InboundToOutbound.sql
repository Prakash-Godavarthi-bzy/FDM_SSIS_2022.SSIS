﻿	use FinanceDataContract
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
	IF @Trancount = 0 BEGIN TRAN;
	--rollback
	--Clear outbound 
	delete from  FinanceDataContract.Outbound.[LossRatio] where DataSet='LossRatio';
	delete from  FinanceDataContract.inbound.[LossRatio] where DataSet='LossRatio';

	IF OBJECT_ID('tempdb..#StaticSrcValues ') IS NOT NULL

     DROP TABLE #StaticSrcValues;

	/*=====================================================================================================================
	Set up Data for Test
	 ======================================================================================================================*/
	----Batch1 set up and process
	WITH	src
	    ([DataSet],
	     [LossRatioPeriod],
	     [LossRatioAccount],
	     [TrifocusCode],
	     [TrifocusName],
	     [YOA],
	     [LossRatioPercentage],
		 [AuditHost],
		 AuditGenerateDateTime
	     )

	AS	(
	select 
	   'LossRatio',  
	   '2019Q3',
	   'LR-G-CM',
	   '737',
	   'BBR Services (exc PE)',
	   '2019',
	   0.217300,
	   CAST(SERVERPROPERTY('MachineName') AS [VARCHAR](255)),
	   GETUTCDATE()

	 )
			
	
	SELECT	       
	     [DataSet],
	     [LossRatioPeriod],
	     [LossRatioAccount],
	     [TrifocusCode],
	     [TrifocusName],
	     [YOA],
	     [LossRatioPercentage],
		 [AuditHost],
		 AuditGenerateDateTime
	
	INTO	#StaticSrcValues 
	FROM	src

	select * from #StaticSrcValues

	INSERT Inbound.[LossRatio] (
	     [DataSet],
	     [LossRatioPeriod],
	     [LossRatioAccount],
	     [TrifocusCode],
	     [TrifocusName],
	     [YOA],
	     [LossRatioPercentage],
	     [AuditSourceBatchID],
		 [AuditHost],
		 AuditGenerateDateTime
	)	
	OUTPUT	Inserted.AuditSourceBatchID, 'InBound', 'LossRatio','LossRatio'
	INTO	Inbound.BatchQueue(PK_Batch, Status, DataSet, RunDescription)
	SELECT	        
	     [DataSet],
	     [LossRatioPeriod],
	     [LossRatioAccount],
	     [TrifocusCode],
	     [TrifocusName],
	     [YOA],
	     [LossRatioPercentage],
	     v.fk_batch,
		 [AuditHost],
		 AuditGenerateDateTime
		
	
	FROM	#StaticSrcValues  l
	CROSS JOIN	(SELECT	fk_batch = -1) v;

		select * from inbound.[LossRatio] where DataSet='LossRatio';
      
	EXECUTE FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_LossRatio


	select * from outbound.[LossRatio] where DataSet='LossRatio';
/*=====================================================================================================================
            Run Test and Roll back dont commit test data to tables
 ======================================================================================================================*/
	WITH	Expected (AuditSourceBatchId, Value)
	AS		(
				SELECT	(SELECT CAST(- 1 AS VARCHAR(20)) FROM #StaticSrcValues slv), 0.217300
			)
	SELECT	OutboundValue	= (ISNULL(Outbound.LossRatioPercentage, 0.0000))
			,ExpectedValue = e.Value
			,TestName		= 'New record'
			,TestResult		= IIF (Outbound.LossRatioPercentage <> e.Value, 'Fail', 'Pass')
	FROM	Expected e
	LEFT JOIN	Outbound.[LossRatio]	AS Outbound ON e.AuditSourceBatchId = Outbound.AuditSourceBatchId
	ORDER BY Outbound.AuditSourceBatchID;

    IF @Trancount = 0 ROLLBACK; 
END TRY
BEGIN CATCH
    IF @Trancount = 0  ROLLBACK;
    THROW;
END CATCH;