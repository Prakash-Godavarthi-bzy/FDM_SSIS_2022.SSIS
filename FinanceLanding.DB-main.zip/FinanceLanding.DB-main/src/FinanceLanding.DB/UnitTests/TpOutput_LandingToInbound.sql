﻿use FinanceLanding

         DECLARE @Trancount INT = @@Trancount
         BEGIN TRY
              IF @Trancount = 0 BEGIN TRAN;

                       delete from FinanceLanding.ADM.TPOutput;
					   delete from FinanceLanding.ADM.Reserving_data;
					   delete from [FinanceDataContract].[Inbound].[Transaction] where DataSet='SIITP'
					   delete from [FinanceDataContract].[outbound].[Transaction] where DataSet='SIITP'
/*
========================================================================================================================================================================
Inserting Data into Landing Tables and Loading data from Landing to InBound.Transacton
========================================================================================================================================================================
*/

                       INSERT INTO FinanceLanding.ADM.TpOutput
					   ([AsAt],
	                   [AuditFlag],
	                   [Class],
	                   [currency],
	                   [Dataset_Type],
	                   [datasetname],
	                   [DateStamp],
	                   [department],
	                   [DISC_CCY],
	                   [DISC_GBP],
	                   [DISC_USD],
	                   [gross_net],
	                   [grouped_dataset],
	                   [id],
	                   [life_flag],
	                   [Provision],
	                   [RM_DISC_CCY],
	                   [RM_DISC_GBP],
	                   [RM_DISC_USD],
	                   [RM_UNDISC_CCY],
	                   [RM_UNDISC_GBP],
	                   [RM_UNDISC_USD],
	                   [SII_Class],
	                   [Synd],
	                   [UNDISC_CCY],
	                   [UNDISC_GBP],
	                   [UNDISC_USD],
	                   [yoa] 
					   )
                       VALUES (201906,1,'BUSA Political','USD','CP - Acq Costs EFP',	'Acquisition Costs','2019-08-14 20:24:30.827','PAC',5401,4153,5282,	'Gross','Acquisition Costs',1,'Non-life excluding health','Claims Provision',0,0,0,0,0,0,'Credit and suretyship insurance',623,100,100,100,2013)

					   
                       INSERT INTO FinanceLanding.ADM.TpOutput
					   ([AsAt],
	                   [AuditFlag],
	                   [Class],
	                   [currency],
	                   [Dataset_Type],
	                   [datasetname],
	                   [DateStamp],
	                   [department],
	                   [DISC_CCY],
	                   [DISC_GBP],
	                   [DISC_USD],
	                   [gross_net],
	                   [grouped_dataset],
	                   [id],
	                   [life_flag],
	                   [Provision],
	                   [RM_DISC_CCY],
	                   [RM_DISC_GBP],
	                   [RM_DISC_USD],
	                   [RM_UNDISC_CCY],
	                   [RM_UNDISC_GBP],
	                   [RM_UNDISC_USD],
	                   [SII_Class],
	                   [Synd],
	                   [UNDISC_CCY],
	                   [UNDISC_GBP],
	                   [UNDISC_USD],
	                   [yoa] 
					   )
                       VALUES (201906,1,'BUSA Political','USD','CP - Acq Costs EFP',	'Acquisition Costs','2019-08-14 20:24:30.827','PAC',5401,4153,5282,	'Gross','Acquisition Costs',2,'Non-life excluding health','Claims Provision',0,0,0,0,0,0,'Credit and suretyship insurance',623,200,200,200,2013)

INSERT INTO Batch(CreateDate,DataSet,latestbusineskey) VALUES (GETDATE(),'SIITP',201906)

--select * from FinanceLanding.ADM.TpOutput
EXECUTE FinanceLanding.[adm].[usp_LandingToInbound] null,null

DECLARE       @BatchId INT;
SELECT        @BatchId= MAX([PK_Batch])
FROM          dbo.[Batch]
WHERE         [DataSet] = 'SIITP'

select  @BatchId
/*
=========================================================================================================================================================================
Expected Results Loading InTo Temp Table
=========================================================================================================================================================================
*/
       DROP TABLE IF EXISTS #Temp_Inbound_Transaction;

       CREATE TABLE #Temp_Inbound_Transaction
	([Scenario] [varchar](2) NOT NULL,
	[Basis] [varchar](2) NOT NULL,
	[Account] [varchar](10) NOT NULL,
	[SourceSystem] [varchar](255) NOT NULL,
	[DateOfFact] [datetime] NOT NULL,
	[BusinessKey] [varchar](255) NOT NULL,
	[PolicyNumber] [varchar](255) NOT NULL,
	[InceptionDate] [datetime] NOT NULL,
	[ExpiryDate] [datetime] NOT NULL,
	[BindDate] [datetime] NOT NULL,
	[DueDate] [datetime] NOT NULL,
	[TrifocusCode] [varchar](25) NOT NULL,
	[Entity] [varchar](10) NOT NULL,
	[Location] [varchar](50) NOT NULL,
	[YOA] [varchar](5) NOT NULL,
	[TypeOfBusiness] [varchar](1) NOT NULL,
	[StatsCode] [varchar](25) NULL,
	[SettlementCCY] [varchar](3) NOT NULL,
	[OriginalCCY] [varchar](3) NOT NULL,
	[IsToDate] [varchar](1) NOT NULL,
	[ValueSett] [numeric](19, 4) NOT NULL,
	[ValueOrig] [numeric](19, 4) NOT NULL,
	[BusinessProcessCode] [varchar](255) NOT NULL,
	[FK_Batch] [int] NOT NULL,
	[AuditSourceBatchID] [varchar](255) NOT NULL,
	
    )


       INSERT INTO #Temp_Inbound_Transaction    
	  ([Scenario],
	  [Basis],
	  [Account],
	  [SourceSystem],
	  [DateOfFact],
	  [BusinessKey],
	  [PolicyNumber],
	  [InceptionDate],
	  [ExpiryDate],
	  [BindDate],
	  [DueDate],
	  [TrifocusCode],
	  [Entity],
	  [Location],
	  [YOA],
	  [TypeOfBusiness],
	  [StatsCode],
	  [SettlementCCY],
	  [OriginalCCY],
	  [IsToDate],
	  [ValueSett],
	  [ValueOrig],
	  [BusinessProcessCode],
	  [FK_Batch],
	  [AuditSourceBatchID]
	
    )
       values   (
	   'F',  
	   'E',
	   'TPC-G-AC',
	   'SIITP',
	   '2019-06-01 00:00:00.000',
	   'BUSA Political|2013|USD|623',
	   'NOPOLICY',
	   '1980-01-01 00:00:00.000',
	   '1980-01-01 00:00:00.000',
	   '1980-01-01 00:00:00.000',
	   '1980-01-01 00:00:00.000',
	   '724',
	   '623',
	    '-',
	    2013,
	    '-',
		null,
		'USD',
		'USD',
		'Y',
		300.00,
		300.00,
		'T1',
		'201906',
		@BatchId )


select * from #Temp_Inbound_Transaction 
select * FROM [FinanceDataContract].[Inbound].[Transaction]   WHERE AuditSourceBatchID=@BatchId    
	 
	        
/*
==========================================================================================================================================================================
Comparing Temp table with InBound.Transaction
==========================================================================================================================================================================
*/
SELECT   IIF(COUNT(*)>0,'FAIL','PASS') 
	FROM 
		(	
      SELECT
	  [Scenario], 
	  [Basis],
	  [Account],
	  [SourceSystem],
	  [DateOfFact],
	  [BusinessKey],
	  [PolicyNumber],
	  [InceptionDate],
	  [ExpiryDate],
	  [BindDate],
	  [DueDate],
	  [TrifocusCode],
	  [Entity],
	  [Location],
	  [YOA],
	  [TypeOfBusiness],
	  [StatsCode],
	  [SettlementCCY],
	  [OriginalCCY],
	  [IsToDate],
	  [ValueSett],
	  [ValueOrig],
	  [BusinessProcessCode],
	  [FK_Batch],
	  [AuditSourceBatchID]
                                                              
	  FROM  #Temp_Inbound_Transaction  WHERE AuditSourceBatchID=@BatchId
       EXCEPT 
      SELECT
	  [Scenario], 
	  [Basis],
	  [Account],
	  [DataSet],
	  [DateOfFact],
	  [BusinessKey],
	  [PolicyNumber],
	  [InceptionDate],
	  [ExpiryDate],
	  [BindDate],
	  [DueDate],
	  [TrifocusCode],
	  [Entity],
	  [Location],
	  [YOA],
	  [TypeOfBusiness],
	  [StatsCode],
	  [SettlementCCY],
	  [OriginalCCY],
	  [IsToDate],
	  [Value],
	  [ValueOrig],
	  [BusinessProcessCode],
	  [FK_Batch],
	  [AuditSourceBatchID]
      FROM [FinanceDataContract].[Inbound].[Transaction]   WHERE AuditSourceBatchID=@BatchId 
                     
      )A
					
		 ROLLBACK; 
         END TRY
         BEGIN CATCH
               ROLLBACK;
              THROW;
         END CATCH