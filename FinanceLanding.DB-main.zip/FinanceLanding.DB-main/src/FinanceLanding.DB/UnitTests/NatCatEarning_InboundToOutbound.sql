﻿	use FinanceDataContract
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
	IF @Trancount = 0 BEGIN TRAN;
	--rollback
	--Clear outbound 
	delete from  FinanceDataContract.Outbound.[Pattern] where DataSet='NatCatEarning';
	delete from  FinanceDataContract.inbound.[Pattern] ;

	IF OBJECT_ID('tempdb..#StaticSrcValues ') IS NOT NULL

     DROP TABLE #StaticSrcValues ;
	--select * from  FinanceDataContract.Outbound.[Pattern] where DataSet='NatCatEarning';
	--select * from financelanding.xls.NatCatEarning;
	/*=====================================================================================================================
				Set up Data for Test
	 ======================================================================================================================*/
	----Batch1 set up and process
	WITH	src
					([PatternScenario]
					,[PatternScenarioVersion]
					,[PatternName]
					,[DataSet]
					,[TrifocusCode]
					,[YOA]
					,[InceptionYear]
					,[SettlementCCY]
					--,DevelopmentPercentageIncrement
					,DevelopmentQuarter
					,BusinessProcessCode
					,[AuditSourceBatchID]
					,[AuditHost]
					,AuditGenerateDateTime
					)

	AS	(
	       select '2019Q4'	
		          ,1
				  ,'CM-G-EP'
				  ,'NatCatEarning'
				  ,'788'
				  ,'2016'
				  ,2016
				  ,'UNK'
				  ,1
				  ,'T1'	
				  ,0
				  ,CAST(SERVERPROPERTY('MachineName') AS [VARCHAR](255))
				  ,GETUTCDATE()

				  )
			
	
	SELECT	        [PatternScenario]
					,[PatternScenarioVersion]
					,[PatternName]
					,[DataSet]
					,[TrifocusCode]
					,[YOA]
					,[InceptionYear]
					,[SettlementCCY]
					--,DevelopmentPercentageIncrement
					,DevelopmentQuarter
					,BusinessProcessCode
					,[AuditSourceBatchID]
					,[AuditHost]
					,AuditGenerateDateTime

	
	INTO	#StaticSrcValues 
	FROM	src

	select * from #StaticSrcValues

	INSERT Inbound.[Pattern] (
	                 [PatternScenario]
	                ,[PatternScenarioVersion]
					,[PatternName]
					,[DataSet]
					,[TrifocusCode]
					,[YOA]
					,[InceptionYear]
					,[SettlementCCY]
					,DevelopmentPercentageIncrement
					,DevelopmentQuarter
					,BusinessProcessCode
					,[AuditSourceBatchID]
					,[AuditHost]
					,AuditGenerateDateTime
					,fk_batch
)	
	OUTPUT	Inserted.AuditSourceBatchID, 'InBound', 'NatCatEarning','Pattern'
	INTO	Inbound.BatchQueue(PK_Batch, Status, DataSet, RunDescription)
	SELECT	         [PatternScenario]
	                ,[PatternScenarioVersion]
					,[PatternName]
					,[DataSet]
					,[TrifocusCode]
					,[YOA]
					,[InceptionYear]
					,[SettlementCCY]
					,v.[value]
					,DevelopmentQuarter
					,BusinessProcessCode
					,v.AuditSourceBatchId
					,[AuditHost]
					,AuditGenerateDateTime
					,v.AuditSourceBatchId
	
	FROM	#StaticSrcValues  l
	CROSS JOIN	(SELECT	value = CAST(0.5 AS Numeric(19, 4)),AuditSourceBatchId = -1) v;

		select * from inbound.[pattern] where DataSet='NatCatEarning';
      
	EXECUTE FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_Pattern ;


	select * from outbound.[pattern] where DataSet='NatCatEarning';
/*=====================================================================================================================
            Run Test and Roll back dont commit test data to tables
 ======================================================================================================================*/
	WITH	Expected (AuditSourceBatchId, Value)
	AS		(
				SELECT	(SELECT CAST(- 1 AS VARCHAR(20)) FROM #StaticSrcValues slv), 0.5 
			)
	SELECT	OutboundValue	= (ISNULL(Outbound.DevelopmentPercentageIncrement, 0.0000))
			,ExpectedValue = e.Value
			,TestName		= 'New record'
			,TestResult		= IIF (Outbound.DevelopmentPercentageIncrement <> e.Value, 'Fail', 'Pass')
	FROM	Expected e
	LEFT JOIN	Outbound.[Pattern]	AS Outbound ON e.AuditSourceBatchId = Outbound.AuditSourceBatchId
	ORDER BY Outbound.AuditSourceBatchId ASC;

    IF @Trancount = 0 ROLLBACK; 
END TRY
BEGIN CATCH
    IF @Trancount = 0  ROLLBACK;
    THROW;
END CATCH;