use FinanceLanding

/*
DELETE FROM FinanceDataContract.Outbound.[Transaction] WHERE DataSet = 'EPI Reinstatement Eurobase'
*/

SET NOCOUNT ON;

DECLARE @Test_Case INT

SET @Test_Case = 1				-- IF 0, applies all of them, else set a number

-------------------------------------------------------------------

BEGIN TRAN

-- Do the cleanup
DELETE FROM FinanceDataContract.Outbound.[Transaction] WHERE DataSet = 'EPI Reinstatement Eurobase'

TRUNCATE TABLE Eurobase.[epi_reinstatement];
TRUNCATE TABLE Eurobase.[epi_view];
TRUNCATE TABLE Eurobase.[policy_cube];
TRUNCATE TABLE Eurobase.[policy_premium];

--TRUNCATE TABLE FinanceDataContract.Inbound.[Transaction]

-- Bring unit test data

INSERT INTO [Eurobase].[epi_reinstatement]
           ([pre_cpd_policy_ref],[reinstatement_signed])
SELECT [pre_cpd_policy_ref],[reinstatement_signed]
FROM [Test].[epi_reinstatement]
WHERE (@Test_Case = 0) OR (test_case = @Test_Case);

INSERT INTO [Eurobase].[epi_view]
           ([cpd_epi_ccy],[cpd_policy_reference])
SELECT [cpd_epi_ccy],[cpd_policy_reference]
FROM Test.[epi_view]
WHERE (@Test_Case = 0) OR (test_case = @Test_Case);

INSERT INTO [Eurobase].[policy_cube]
           ([datemodified],[Expiry],[focus_area],[Inception],[mop],[Multiyear],[policyref],[stats],[synd],[tot],[yoa])
SELECT [datemodified],[Expiry],[focus_area],[Inception],[mop],[Multiyear],[policyref],[stats],[synd],[tot],[yoa]
FROM Test.[policy_cube]
WHERE (@Test_Case = 0) OR (test_case = @Test_Case);

INSERT INTO [Eurobase].[policy_premium]
           ([pre_amount],[pre_currency_code],[pre_prem_qual],[pre_cpd_policy_ref])
SELECT [pre_amount],[pre_currency_code],[pre_prem_qual],[pre_cpd_policy_ref]
FROM Test.[policy_premium]
WHERE (@Test_Case = 0) OR (test_case = @Test_Case);

SELECT * FROM Eurobase.[epi_reinstatement]
SELECT * FROM Eurobase.[epi_view]
SELECT * FROM Eurobase.[policy_cube]
SELECT * FROM Eurobase.[policy_premium]

-- Populate Inbound.Transaction and check the result
EXECUTE FinanceLanding.Eurobase.usp_LandingToInbound_EPI null, null;

--INSERT INTO Test.[Transaction]
SELECT *, @Test_Case
FROM FinanceDataContract.Inbound.[Transaction] 
WHERE DataSet = 'EPI Reinstatement Eurobase';
-- ROLLBACK;

-- Populate Outbound.Transaction and check the result
EXEC FinanceDataContract.Inbound.usp_InboundOutboundWorkflow;

SELECT * FROM FinanceDataContract.Outbound.[Transaction] WHERE DataSet = 'EPI Reinstatement Eurobase'

IF @Test_Case = 444	-- We simulate some changes in time
BEGIN
	/*
	-- Time 1 : tra_syndicate_net_amount changes

	UPDATE Eurobase.transaction_01 
	SET tra_syndicate_net_amount += 100.00,
		tra_actual_payment_date = CASE WHEN YEAR(tra_actual_payment_date) = 9999 THEN tra_actual_payment_date ELSE DATEADD(DAY,30,tra_actual_payment_date) END

	SELECT * FROM Eurobase.transaction_01

	-- Populate Inbound.Transaction and check the result
	EXECUTE FinanceLanding.Eurobase.usp_LandingToInbound null, null;

	SELECT *
	FROM FinanceDataContract.Inbound.[Transaction]
	WHERE DataSet = 'LPSO';

	-- Populate Outbound.Transaction and check the result
	EXEC FinanceDataContract.Inbound.usp_InboundOutboundWorkflow;

	SELECT * FROM FinanceDataContract.Outbound.[Transaction] WHERE DataSet = 'LPSO'
	*/
	-- Time 2 : policy_deductions changes

	--UPDATE Eurobase.transaction_01 
	--SET tra_total_discount_pcnt = 30
	--WHERE (Test_Case = 4);

	--SELECT * FROM Eurobase.transaction_01 

	---- Populate Inbound.Transaction and check the result
	--EXECUTE FinanceLanding.Eurobase.usp_LandingToInbound null, null;

	--SELECT *
	--FROM FinanceDataContract.Inbound.[Transaction]
	--WHERE DataSet = 'EPI Reinstatement Eurobase'
	--ORDER BY PolicyNumber, DateOfFact, Value, Account desc, Entity;

	---- Populate Outbound.Transaction and check the result
	--EXEC FinanceDataContract.Inbound.usp_InboundOutboundWorkflow;

	SELECT * FROM FinanceDataContract.Outbound.[Transaction] WHERE DataSet = 'EPI Reinstatement Eurobase'

END

GO

IF @@TRANCOUNT <> 0
	ROLLBACK;
