﻿use FinanceLanding
--select * from FinanceDataContract.Outbound.[transaction] where dataset='ReservingData' and BusinessKey-- like 'Marine|Aviation Liab|2015|Gross|CAD|Team Attritional Claims|%'
--='Marine|Aviation Liab|2015|Gross|CAD|Team Attritional Claims|Attritional|-|623|Team Claims                                       |-  |'
 -- F	E	GC-T-AC	ReservingData	2015-09-01 00:00:00.000	Marine|Aviation Liab|2015|Gross|CAD|Team Attritional Claims|Attritional|-|623|Team Claims                                       |-  |	NOPOLICY	1980-01-01 00:00:00.000	1980-01-01 00:00:00.000	1980-01-01 00:00:00.000	1980-01-01 00:00:00.000	TRI00090	623	-	2015	-	NULL	CAD	CAD	Y	300.0000	300.0000		201509	290
         DECLARE @Trancount INT = @@Trancount
         BEGIN TRY
              IF @Trancount = 0 BEGIN TRAN;

                    delete from FinanceLanding.ADM.TPOutput;
					delete from FinanceLanding.ADM.Reserving_data;
					delete from [FinanceDataContract].[Inbound].[Transaction] where DataSet='ReservingData'
					delete from [FinanceDataContract].[outbound].[Transaction] where DataSet='ReservingData'
/*
========================================================================================================================================================================
Inserting Data into Landing Tables and Loading data from Landing to InBound.Transacton
========================================================================================================================================================================
*/
                       
                       INSERT INTO FinanceLanding.ADM.Reserving_data
					   ([AsAt],
	                   [att_cat],
	                   [ccy],
	                   [datasetgroup],
	                   [datasetname],
	                   [department],
	                   [gross_ri],
	                   [office_location],
	                   [special],
	                   [synd],
	                   [triangle_group],
	                   [value],
	                   [yoa],
	                   [id]	                  
					   )
                       VALUES 
					    (201509,'Attritional','CAD','Team Claims','Team Attritional Claims','Marine','Gross',	NULL,NULL,623,	'Aviation Liab',100,2015,723489)
                       ,(201509,'Attritional','CAD','Team Claims','Team Attritional Claims','Marine','Gross',	NULL,NULL,623,	'Aviation Liab',200,2015,723490)
					   ,(201509,'Attritional','CAD','Team Claims','Team Attritional Claims','Marine','RI',	NULL,NULL,623,	'Aviation Liab',200,2015,723491)

INSERT INTO Batch(CreateDate,DataSet,latestbusineskey) VALUES (GETDATE(),'ReservingData',201509)

select * from FinanceLanding.ADM.Reserving_data
EXECUTE FinanceLanding.[adm].[usp_LandingToInbound] null,null

DECLARE       @BatchId INT;
SELECT        @BatchId= MAX([PK_Batch])
FROM          dbo.[Batch]
WHERE         [DataSet] = 'ReservingData'

select  @BatchId
/*
=========================================================================================================================================================================
Expected Results Loading InTo Temp Table
=========================================================================================================================================================================
*/
       DROP TABLE IF EXISTS #Temp_Inbound_Transaction;

       CREATE TABLE #Temp_Inbound_Transaction
	([Scenario] [varchar](2) NOT NULL,
	[Basis] [varchar](2) NOT NULL,
	[Account] [varchar](10) NOT NULL,
	[DataSet] [varchar](255) NOT NULL,
	[DateOfFact] [datetime] NOT NULL,
	[BusinessKey] [varchar](255) NOT NULL,
	[PolicyNumber] [varchar](255) NOT NULL,
	[InceptionDate] [datetime] NOT NULL,
	[ExpiryDate] [datetime] NOT NULL,
	[BindDate] [datetime] NOT NULL,
	[DueDate] [datetime] NOT NULL,
	[TrifocusCode] [varchar](25) NOT NULL,
	[Entity] [varchar](10) NOT NULL,
	[Location] [varchar](50) NOT NULL,
	[YOA] [varchar](5) NOT NULL,
	[TypeOfBusiness] [varchar](1) NOT NULL,
	[StatsCode] [varchar](25) NULL,
	[SettlementCCY] [varchar](3) NOT NULL,
	[OriginalCCY] [varchar](3) NOT NULL,
	[IsToDate] [varchar](1) NOT NULL,
	[ValueSett] [numeric](19, 4) NOT NULL,
	[ValueOrig] [numeric](19, 4) NOT NULL,
	[BusinessProcessCode] [varchar](255) NOT NULL,
	[FK_Batch] [int] NOT NULL,
	[AuditSourceBatchID] [varchar](255) NOT NULL,
	
    )


       INSERT INTO #Temp_Inbound_Transaction    
	  ([Scenario],
	  [Basis],
	  [Account],
	  [DataSet],
	  [DateOfFact],
	  [BusinessKey],
	  [PolicyNumber],
	  [InceptionDate],
	  [ExpiryDate],
	  [BindDate],
	  [DueDate],
	  [TrifocusCode],
	  [Entity],
	  [Location],
	  [YOA],
	  [TypeOfBusiness],
	  [StatsCode],
	  [SettlementCCY],
	  [OriginalCCY],
	  [IsToDate],
	  [ValueSett],
	  [ValueOrig],
	  [BusinessProcessCode],
	  [FK_Batch],
	  [AuditSourceBatchID]
	
    )
       values   (
	   'F',  
	   'E',
	   'GC-T-AC',
	   'ReservingData',
	   '2015-09-01 00:00:00.000',
	   'Marine|Aviation Liab|2015|Gross|CAD|Team Attritional Claims|Attritional|-|623|Team Claims                                       |-  |',
	   'NOPOLICY',
	   '1980-01-01 00:00:00.000',
	   '1980-01-01 00:00:00.000',
	   '1980-01-01 00:00:00.000',
	   '1980-01-01 00:00:00.000',
	   'TRI00090',
	   '623',
	    '-',
	    2015,
	    '-',
		null,
		'CAD',
		'CAD',
		'Y',
		300.00,
		300.00,
		'T1',
		'201509',
		@BatchId ),

		 (
	   'F',  
	   'E',
	   'RC-T-AC',
	   'ReservingData',
	   '2015-09-01 00:00:00.000',
	   'Marine|Aviation Liab|2015|RI|CAD|Team Attritional Claims|Attritional|-|623|Team Claims                                       |-  |',
	   'NOPOLICY',
	   '1980-01-01 00:00:00.000',
	   '1980-01-01 00:00:00.000',
	   '1980-01-01 00:00:00.000',
	   '1980-01-01 00:00:00.000',
	   'TRI00090',
	   '623',
	    '-',
	    2015,
	    '-',
		null,
		'CAD',
		'CAD',
		'Y',
		200.00,
		200.00,
		'T1',
		'201509',
		@BatchId )
                                      

	        
/*
==========================================================================================================================================================================
Comparing Temp table with InBound.Transaction
==========================================================================================================================================================================
*/

select * from #Temp_Inbound_Transaction 
select * FROM [FinanceDataContract].[Inbound].[Transaction] 
SELECT   IIF(COUNT(*)>0,'FAIL','PASS') 
	FROM 
		(	
      SELECT
	  [Scenario], 
	  [Basis],
	  [Account],
	  [DataSet],
	  [DateOfFact],
	  [BusinessKey],
	  [PolicyNumber],
	  [InceptionDate],
	  [ExpiryDate],
	  [BindDate],
	  [DueDate],
	  [TrifocusCode],
	  [Entity],
	  [Location],
	  [YOA],
	  [TypeOfBusiness],
	  [StatsCode],
	  [SettlementCCY],
	  [OriginalCCY],
	  [IsToDate],
	  [ValueSett],
	  [ValueOrig],
	  [BusinessProcessCode],
	  [FK_Batch],
	  [AuditSourceBatchID]
                                                              
	  FROM  #Temp_Inbound_Transaction  WHERE [AuditSourceBatchID]=@BatchId
       EXCEPT 
      SELECT
	  [Scenario], 
	  [Basis],
	  [Account],
	  [DataSet],
	  [DateOfFact],
	  [BusinessKey],
	  [PolicyNumber],
	  [InceptionDate],
	  [ExpiryDate],
	  [BindDate],
	  [DueDate],
	  [TrifocusCode],
	  [Entity],
	  [Location],
	  [YOA],
	  [TypeOfBusiness],
	  [StatsCode],
	  [SettlementCCY],
	  [OriginalCCY],
	  [IsToDate],
	  [Value],
	  [ValueOrig],
	  [BusinessProcessCode],
	  [FK_Batch],
	  [AuditSourceBatchID]
      FROM [FinanceDataContract].[Inbound].[Transaction]   WHERE [AuditSourceBatchID]=@BatchId 
                     
     )A
					
		 ROLLBACK; 
         END TRY
         BEGIN CATCH
               ROLLBACK;
              THROW;
         END CATCH