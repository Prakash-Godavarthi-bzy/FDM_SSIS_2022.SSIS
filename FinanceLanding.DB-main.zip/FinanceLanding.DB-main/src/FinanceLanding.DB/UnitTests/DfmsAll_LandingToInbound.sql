﻿use FinanceLanding

         DECLARE @Trancount INT = @@Trancount
         BEGIN TRY
              IF @Trancount = 0 BEGIN TRAN;

                       delete from FinanceLanding.ADM.DFMS_ALL;
					   delete from FinanceDataContract.outbound.Pattern where dataset='ADM'
					   delete from FinanceDataContract.inbound.Pattern where dataset='ADM'

/*
========================================================================================================================================================================
Inserting Data into Landing Tables and Loading data from Landing to InBound.Pattern
========================================================================================================================================================================
*/

                       INSERT INTO FinanceLanding.ADM.DFMS_ALL
					   ( [DatasetName],
                         [DateStamp],
                         [DevelopmentPeriod],
                         [ProjectName],
                         [ReservingClass2],
						 [ReservingClass3],
						 [ReservingClass4],
                         [Value],
                         [ReservingClass1]
					   )
                       VALUES ('Pure DFM Paid','14/06/2019 17:05:21',1,	'19Q1','Korean Re','Gross','Attritional',0.000002,'Life, Accident & Health')
					         ,('Pure DFM Paid','14/06/2019 17:05:21',2,	'19Q1','Korean Re','Gross','Attritional',0.000003,'Life, Accident & Health')
							 ,('Pure DFM Premium','14/06/2019 17:05:21',1,	'19Q1','Korean Re','Gross','Attritional',0.000001,'Life, Accident & Health')

					   

INSERT INTO Batch(CreateDate,DataSet,latestbusineskey) VALUES (GETDATE(),'ADM','DFMS_all')

select * from FinanceLanding.ADM.DFMS_all
EXECUTE FinanceLanding.[adm].[usp_LandingToInbound_Pattern] null,null

DECLARE       @BatchId INT;
SELECT        @BatchId= MAX([PK_Batch])
FROM          dbo.[Batch]
WHERE         [DataSet] = 'ADM'

select  @BatchId
/*
=========================================================================================================================================================================
Expected Results Loading InTo Temp Table
=========================================================================================================================================================================
*/
       DROP TABLE IF EXISTS #Temp_Inbound_Pattern;

       CREATE TABLE #Temp_Inbound_Pattern
	(
	[PatternScenario] [varchar](10) NOT NULL,
	[PatternScenarioVersion] [int] NOT NULL,
	[PatternName] [varchar](10) NOT NULL,
	[DataSet] [varchar](50) NOT NULL,
	[TrifocusCode] [varchar](100) NOT NULL,
	[YOA] [varchar](5) NULL,
	[InceptionYear] [smallint] NULL,
	[SettlementCCY] [varchar](3) NULL,
	[DevelopmentPercentageIncrement] [numeric](19, 6) NOT NULL,
	[DevelopmentQuarter] [int] NOT NULL,
	[FK_Batch] [int] NOT NULL,
	[AuditSourceBatchID] [varchar](255) NOT NULL,
	[BusinessProcessCode] [varchar](255) NULL,
    )


       INSERT INTO #Temp_Inbound_Pattern    
	  (
	[PatternScenario],
	[PatternScenarioVersion],
	[PatternName],
	[DataSet],
	[TrifocusCode],
	[YOA],
	[InceptionYear],
	[SettlementCCY],
	[DevelopmentPercentageIncrement],
	[DevelopmentQuarter],
	[FK_Batch],
	[AuditSourceBatchID],
	[BusinessProcessCode]	
    )
       values   (
	   '19Q1',  
	   1,
	   'C-GC-PP',
	   'ADM',
	   '780',
	   'NOYOA',
	   0,
	   'UNK',
	   0.000002,
	   1,
	   @BatchId,
	   @BatchId,
		'T1' 
	    ),   
	   (
	   '19Q1',  
	   1,
	   'C-GC-PP',
	   'ADM',
	   '780',
	   'NOYOA',
	   0,
	   'UNK',
	   0.000001,
	   2,
	   @BatchId,
	   @BatchId,
		'T1' 
	   ),

	   (
	   '19Q1',  
	   1,
	   'P-GP-PP',
	   'ADM',
	   '780',
	   'NOYOA',
	   0,
	   'UNK',
	   0.000001,
	   1,
	   @BatchId,
	   @BatchId,
		'T1' 
		),

		(
	   '19Q1',  
	   1,
	   'P-GP-BP',
	   'ADM',
	   '780',
	   'NOYOA',
	   0,
	   'UNK',
	   0.000001,
	   1,
	   @BatchId,
	   @BatchId,
		'T1' 
		)

 
select * from #Temp_Inbound_Pattern 
select * FROM [FinanceDataContract].[inbound].[Pattern]   WHERE [AuditSourceBatchId]=@BatchId    
	 
	        
/*
==========================================================================================================================================================================
Comparing Temp table with InBound.Pattern
==========================================================================================================================================================================
*/
SELECT   IIF(COUNT(*)>0,'FAIL','PASS') 
	FROM 
		(	
   SELECT
	[PatternScenario],
	[PatternScenarioVersion],
	[PatternName],
	[DataSet],
	[TrifocusCode],
	[YOA],
	[InceptionYear],
	[SettlementCCY],
	[DevelopmentPercentageIncrement],
	[DevelopmentQuarter],
	[FK_Batch],
	[AuditSourceBatchID],
	[BusinessProcessCode]
                                                              
	  FROM  #Temp_Inbound_Pattern  WHERE [AuditSourceBatchID]=@BatchId
       EXCEPT 
   SELECT
	[PatternScenario],
	[PatternScenarioVersion],
	[PatternName],
	[DataSet],
	[TrifocusCode],
	[YOA],
	[InceptionYear],
	[SettlementCCY],
	[DevelopmentPercentageIncrement],
	[DevelopmentQuarter],
	[FK_Batch],
	[AuditSourceBatchID],
	[BusinessProcessCode]
      FROM [FinanceDataContract].[Inbound].[Pattern]   WHERE [AuditSourceBatchId]=@BatchId 
                     
      )A
					
		 ROLLBACK; 
         END TRY
         BEGIN CATCH
               ROLLBACK;
              THROW;
         END CATCH

		 GO