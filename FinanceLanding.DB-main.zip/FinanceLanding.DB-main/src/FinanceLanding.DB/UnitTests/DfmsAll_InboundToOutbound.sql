﻿	use FinanceDataContract
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
	IF @Trancount = 0 BEGIN TRAN;
	--rollback
	--Clear outbound 
	delete from  FinanceDataContract.Outbound.[Pattern] where DataSet='ADM';
	delete from  FinanceDataContract.Inbound.[Pattern] ;

	IF OBJECT_ID('tempdb..#StaticSrcValues ') IS NOT NULL

     DROP TABLE #StaticSrcValues ;
	--select * from  FinanceDataContract.Outbound.[Pattern] where DataSet='ADM';
	/*=====================================================================================================================
				Set up Data for Test
	 ======================================================================================================================*/
	----Batch1 set up and process
	WITH	src
					([PatternScenario]
					,[PatternScenarioVersion]
					,[PatternName]
					,[DataSet]
					,[TrifocusCode]
					,[YOA]
					,[InceptionYear]
					,[SettlementCCY]
					--,DevelopmentPercentageIncrement
					,DevelopmentQuarter
					,BusinessProcessCode
					,[AuditSourceBatchID]
					,[AuditHost]
					,AuditGenerateDateTime
					,[FK_Batch])

	AS	(
	       select '19Q1'	
		          ,1
				  ,'P-G-PP'
				  ,'ADM'
				  ,'797'
				  ,'NOYOA'
				  ,0
				  ,'UNK'
				  ,1
				  ,'T1'	
				  ,0
				  ,CAST(SERVERPROPERTY('MachineName') AS [VARCHAR](255))
				  ,GETUTCDATE()
				  ,0
		)
			
	
	SELECT	        [PatternScenario]
					,[PatternScenarioVersion]
					,[PatternName]
					,[DataSet]
					,[TrifocusCode]
					,[YOA]
					,[InceptionYear]
					,[SettlementCCY]
					--,DevelopmentPercentageIncrement
					,DevelopmentQuarter
					,BusinessProcessCode
					,[AuditSourceBatchID]
					,[AuditHost]
					,AuditGenerateDateTime
					,[FK_Batch]
	
	INTO	#StaticSrcValues 
	FROM	src

	select * from #StaticSrcValues

	INSERT Inbound.[Pattern] (
	                 [PatternScenario]
	                 ,[PatternScenarioVersion]
					,[PatternName]
					,[DataSet]
					,[TrifocusCode]
					,[YOA]
					,[InceptionYear]
					,[SettlementCCY]
					,DevelopmentPercentageIncrement
					,DevelopmentQuarter
					,BusinessProcessCode
					,[AuditSourceBatchID]
					,[AuditHost]
					,AuditGenerateDateTime
					,[FK_Batch])	
	OUTPUT	Inserted.AuditSourceBatchID, 'InBound', 'ADM','Pattern'
	INTO	Inbound.BatchQueue(PK_Batch, Status, DataSet, RunDescription)
	SELECT	         [PatternScenario]
	                ,[PatternScenarioVersion]
					,[PatternName]
					,[DataSet]
					,[TrifocusCode]
					,[YOA]
					,[InceptionYear]
					,[SettlementCCY]
					,v.[value]
					,DevelopmentQuarter
					,BusinessProcessCode
					,v.AuditSourceBatchID
					,[AuditHost]
					,AuditGenerateDateTime
					,v.AuditSourceBatchID
	
	FROM	#StaticSrcValues  l
	CROSS JOIN	(SELECT	value = CAST(0.5 AS Numeric(19, 4)),AuditSourceBatchID = -1) v;

      
	EXECUTE FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_Pattern ;


	select * from outbound.[pattern] where DataSet='ADM';
/*=====================================================================================================================
            Run Test and Roll back dont commit test data to tables
 ======================================================================================================================*/
	WITH	Expected (AuditSourceBatchID, [Value])
	AS		(
				SELECT	(SELECT CAST(- 1 AS VARCHAR(20)) FROM #StaticSrcValues slv), 0.5 
			)
	SELECT	OutboundValue	= (ISNULL(Outbound.DevelopmentPercentageIncrement, 0.0000))
			,ExpectedValue = e.[Value]
			,TestName		= 'New record'
			,TestResult		= IIF (Outbound.DevelopmentPercentageIncrement <> e.[Value], 'Fail', 'Pass')
	FROM	Expected e
	LEFT JOIN	Outbound.[Pattern]	AS Outbound ON e.AuditSourceBatchID = Outbound.AuditSourceBatchID
	ORDER BY Outbound.AuditSourceBatchID ASC;

    IF @Trancount = 0 ROLLBACK; 
END TRY
BEGIN CATCH
    IF @Trancount = 0  ROLLBACK;
    THROW;
END CATCH;