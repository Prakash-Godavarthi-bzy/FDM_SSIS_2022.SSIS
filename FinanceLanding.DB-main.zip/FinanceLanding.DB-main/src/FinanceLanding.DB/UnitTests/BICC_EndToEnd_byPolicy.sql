use FinanceLanding

/*
DELETE 
--SELECT TOP 100 *
FROM FinanceDataContract.Outbound.[Transaction] WHERE DataSet = 'ClaimCenter'
*/

SET NOCOUNT ON;

DECLARE		  @PolicyRef VARCHAR(50)
			, @Detail_Level INT = 2		-- IF 0 all data set results are

DECLARE @ClaimReference TABLE (ClaimReference VARCHAR(50))

SET @PolicyRef = 'B6712J14'

INSERT INTO @ClaimReference
SELECT DISTINCT [ClaimSourceId]
FROM [BICC].[Claim]
WHERE [PolicyNumber] = @PolicyRef;

SELECT [SourceSystem],[ClaimSourceId],[ClaimReference],[LocationOfLossCountry],[LocationOfLossState],[PolicyNumber],[IsActive]
INTO #tmpClaim
FROM [BICC].[Claim]
WHERE [PolicyNumber] = @PolicyRef;

-------------------------------------------------------------------

BEGIN TRAN

-- Do the cleanup
DELETE 
--SELECT TOP 100 *
FROM FinanceDataContract.Outbound.[Transaction] WHERE DataSet = 'ClaimCenter'

TRUNCATE TABLE [BICC].[Claim]

INSERT INTO [BICC].[Claim]
		([SourceSystem],[ClaimSourceId],[ClaimReference],[LocationOfLossCountry],[LocationOfLossState],[PolicyNumber],[IsActive])
SELECT [SourceSystem],[ClaimSourceId],[ClaimReference],[LocationOfLossCountry],[LocationOfLossState],[PolicyNumber],[IsActive]
FROM #tmpClaim;

-- Populate Inbound.Transaction and check the result
EXECUTE FinanceLanding.BICC.usp_LandingToInbound null, null;

IF @Detail_Level < 2
	--INSERT INTO Test.[Transaction]
	SELECT TOP 1000 *
	FROM FinanceDataContract.Inbound.[Transaction] 
	WHERE DataSet = 'ClaimCenter';
	-- ROLLBACK;

-- Populate Outbound.Transaction and check the result
EXEC FinanceDataContract.Inbound.usp_InboundOutboundWorkflow;

SELECT TOP 1000 * FROM FinanceDataContract.Outbound.[Transaction] WHERE DataSet = 'ClaimCenter'

IF @@TRANCOUNT <> 0
	ROLLBACK;
