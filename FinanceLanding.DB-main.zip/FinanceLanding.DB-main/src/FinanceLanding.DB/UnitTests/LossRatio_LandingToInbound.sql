﻿use FinanceLanding

         DECLARE @Trancount INT = @@Trancount
         BEGIN TRY
              IF @Trancount = 0 BEGIN TRAN;

                       delete from FinanceLanding.xls.LossRatio
					   delete from FinanceDataContract.outbound.LossRatio where dataset='LossRatio'
					   delete from FinanceDataContract.inbound.LossRatio where dataset='LossRatio'
		

			
/*
========================================================================================================================================================================
Inserting Data into Landing Tables and Loading data from Landing to InBound.LossRatio
========================================================================================================================================================================
*/

                       INSERT INTO FinanceLanding.xls.LossRatio
					   ( 
	                     [FileName],
	                     [LoadDate],
	                     [Division_BI],
	                     [TrifocusCode_BI],
	                     [Trifocus_BI],
	                     [ReservingClass2_EI],
	                     [ReservingClassMapped],
	                     [LatestBusinessPlan],
	                     [Comments],
	                     [2017],
	                     [2018],
	                     [2019],
	                     [2020]
					   )
                       VALUES ('Initial cat margin - 2019Q3 non-BID','2020-03-24 16:40:04.7310000','CyEx','737','BBR Services (exc PE)'	,NULL,'BBR Services MM','TMB Info Sec',NULL,'20.00%','20.59%','21.73%','20.00%')


INSERT INTO Batch(CreateDate,DataSet,latestbusineskey) VALUES (GETDATE(),'LossRatio','LossRatio')

EXECUTE FinanceLanding.[xls].[usp_LandingToInbound_LossRatio] null,null

DECLARE       @BatchId INT;
SELECT        @BatchId= MAX([PK_Batch])
FROM          dbo.[Batch]
WHERE         [DataSet] ='LossRatio'

select  @BatchId
/*
=========================================================================================================================================================================
Expected Results Loading InTo Temp Table
=========================================================================================================================================================================
*/
       DROP TABLE IF EXISTS #Temp_Inbound_LossRatio;

       CREATE TABLE #Temp_Inbound_LossRatio
	(
	[DataSet] [varchar](50) NOT NULL,
	[LossRatioPeriod] [varchar](10) NOT NULL,
	[LossRatioAccount] [varchar](50) NOT NULL,
	[TrifocusCode] [varchar](10) NOT NULL,
	[TrifocusName] [varchar](255) NOT NULL,
	[YOA] [varchar](5) NOT NULL,
	[LossRatioPercentage] [numeric](19, 6) NOT NULL,
	[AuditSourceBatchID] [varchar](255) NOT NULL,
    )


       INSERT INTO #Temp_Inbound_LossRatio   
	  (
	     [DataSet],
	     [LossRatioPeriod],
	     [LossRatioAccount],
	     [TrifocusCode],
	     [TrifocusName],
	     [YOA],
	     [LossRatioPercentage],
	     [AuditSourceBatchID]

    )
      values   
	   ('LossRatio',  
	   '2019Q3',
	   'LR-G-CM',
	   '737',
	   'BBR Services (exc PE)',
	   '2019',
	   0.217300,
	   @BatchId),
	   ('LossRatio',  
	   '2019Q3',
	   'LR-G-CM',
	   '737',
	   'BBR Services (exc PE)',
	   '2018',
	   0.205900,
	   @BatchId)
	   ,
	   ('LossRatio',  
	   '2019Q3',
	   'LR-G-CM',
	   '737',
	   'BBR Services (exc PE)',
	   '2017',
	   0.200000,
	   @BatchId)
	   ,
	   ('LossRatio',  
	   '2019Q3',
	   'LR-G-CM',
	   '737',
	   'BBR Services (exc PE)',
	   '2020',
	   0.200000,
	   @BatchId)
     


select * from #Temp_Inbound_LossRatio
select * FROM [FinanceDataContract].[inbound].[LossRatio]   WHERE AuditSourceBatchID=@BatchId    
	 
	        
/*
==========================================================================================================================================================================
Comparing Temp table with InBound.LOssRatio
==========================================================================================================================================================================
*/
SELECT   IIF(COUNT(*)>0,'FAIL','PASS') 
	FROM 
		(	
   SELECT
	     [DataSet],
	     [LossRatioPeriod],
	     [LossRatioAccount],
	     [TrifocusCode],
	     [TrifocusName],
	     [YOA],
	     [LossRatioPercentage],
	     [AuditSourceBatchID]
                                                              
	  FROM  #Temp_Inbound_LossRatio WHERE [AuditSourceBatchID]=@BatchId
       EXCEPT 
   SELECT
         [DataSet],
	     [LossRatioPeriod],
	     [LossRatioAccount],
	     [TrifocusCode],
	     [TrifocusName],
	     [YOA],
	     [LossRatioPercentage],
	     [AuditSourceBatchID]
      FROM [FinanceDataContract].[Inbound].[LossRatio]   WHERE [AuditSourceBatchID]=@BatchId 
                     
      )A
					
		 ROLLBACK; 
         END TRY
         BEGIN CATCH
               ROLLBACK;
              THROW;
         END CATCH