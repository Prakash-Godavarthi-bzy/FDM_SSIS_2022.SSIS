﻿use FinanceLanding

         DECLARE @Trancount INT = @@Trancount
         BEGIN TRY
              IF @Trancount = 0 BEGIN TRAN;

                       delete from FinanceLanding.[XLS].[EIOPA];
					   delete from FinanceDataContract.outbound.DiscountRates where dataset='EIOPA'
					   delete from FinanceDataContract.inbound.DiscountRates where dataset='EIOPA'
					   --select * from FinanceDataContract.outbound.Pattern

/*
========================================================================================================================================================================
Inserting Data into Landing Tables and Loading data from Landing to InBound.Pattern
========================================================================================================================================================================
*/

   INSERT INTO FinanceLanding.[XLS].[EIOPA]
   ([FileName],
    [LoadDate],
    [SheetName],
    [Main Menu],
	[Euro],
    [Austria],
	[Belgium],
	[Bulgaria],
	[Croatia],
	[Cyprus],
	[Czech Republic],
	[Denmark],
	[Estonia],
	[Finland],
	[France],
	[Germany],
	[Greece],
	[Hungary],
	[Iceland],
	[Ireland],
	[Italy],
	[Latvia],
	[Liechtenstein],
	[Lithuania],
	[Luxembourg],
	[Malta],
	[Netherlands],
	[Norway],
	[Poland],
	[Portugal],
	[Romania],
	[Russia],
	[Slovakia],
	[Slovenia],
	[Spain],
	[Sweden],
	[Switzerland],
	[United Kingdom],
	[Australia],
	[Brazil],
	[Canada],
	[Chile],
	[China],
	[Colombia],
	[Hong Kong],
	[India],
	[Japan],
	[Malaysia],
	[Mexico],
	[New Zealand],
	[Singapore],
	[South Africa],
	[South Korea],
	[Taiwan],
	[Thailand],
	[Turkey],
	[United States]
					   )
   VALUES ('EIOPA_RFR_20190331_Term_Structures','2020-02-20 15:05:26.8220000','RFR_spot_no_VA',1,'-0.330%','-0.330%','-0.330%','-0.380%',	'-0.033%',	'-0.330%',	'1.993%',	'-0.340%',	'-0.330%',	'-0.330%',	'-0.330%',	'-0.330%',	'-0.330%',	'0.288%',	'4.368%',	'-0.330%',	'-0.330%',	'-0.330%',	'-0.757%',	'-0.330%',	'-0.330%',	'-0.330%',	'-0.330%',	'1.404%',	'1.412%',	'-0.330%',	'3.019%',	'8.170%',	'-0.330%',	'-0.330%',	'-0.330%',	'-0.055%',	'-0.757%',	'0.839%',	'1.421%',	'6.262%',	'1.812%',	'2.881%',	'2.437%',	'4.181%',	'1.521%',	'6.284%',	'-0.115%',	'3.336%',	'8.278%',	'1.567%',	'1.800%',	'6.929%',	'1.680%',	'0.387%',	'1.606%',	'28.820%',	'2.387%')



INSERT INTO Batch(CreateDate,DataSet,latestbusineskey) VALUES (GETDATE(),'EIOPA','EIOPA')

select * from FinanceLanding.xls.EIOPA
EXECUTE FinanceLanding.xls.usp_EIOPALandingToInbound_DiscountRates null,null

DECLARE       @BatchId INT;
SELECT        @BatchId= MAX([PK_Batch])
FROM          dbo.[Batch]
WHERE         [DataSet] ='EIOPA'

select  @BatchId
/*
=========================================================================================================================================================================
Expected Results Loading InTo Temp Table
=========================================================================================================================================================================
*/
       DROP TABLE IF EXISTS #Temp_Inbound_DiscountRates;

       CREATE TABLE #Temp_Inbound_DiscountRates
	(
	[AsAtDate] [date] NOT NULL,
	[DiscountRateName] [varchar](255) NOT NULL,
	[DiscountRateKey] [varchar](50) NOT NULL,
	[DataSet] [varchar](50) NOT NULL,
	[SettlementCCY] [varchar](3) NOT NULL,
	[CumulativeDevelopmentPercentage] [numeric](19, 6) NOT NULL,
	[DevelopmentYear] [int] NOT NULL,
	[AuditSourceBatchID] [varchar](255) NOT NULL
    )



       INSERT INTO #Temp_Inbound_DiscountRates   
	  (
	[AsAtDate],
	[DiscountRateName],
	[DiscountRateKey],
	[DataSet],
	[SettlementCCY],
	[CumulativeDevelopmentPercentage],
	[DevelopmentYear],
	[AuditSourceBatchID]	
    )
       values   (
	   '20190331',  
	   'EIOPA - RFR_spot_no_VA',
	   'EIOPA',
	   'EIOPA',
	   'EUR',
	   '-0.00330',
	   1,
	   @BatchId
	 )
  

select * from #Temp_Inbound_DiscountRates 
select * FROM [FinanceDataContract].[inbound].[DiscountRates]   WHERE AuditSourceBatchID=@BatchId  and [SettlementCCY]='EUR'  
	 
	        
/*
==========================================================================================================================================================================
Comparing Temp table with InBound.Transaction
==========================================================================================================================================================================
*/
SELECT   IIF(COUNT(*)>0,'FAIL','PASS') 
	FROM 
		(	
   SELECT
	[AsAtDate],
	[DiscountRateName],
	[DiscountRateKey],
	[DataSet],
	[SettlementCCY],
	[CumulativeDevelopmentPercentage],
	[DevelopmentYear],
	[AuditSourceBatchID]	
                                                              
	  FROM  #Temp_Inbound_DiscountRates  WHERE AuditSourceBatchID=@BatchId
       EXCEPT 
   SELECT
	[AsAtDate],
	[DiscountRateName],
	[DiscountRateKey],
	[DataSet],
	[SettlementCCY],
	[CumulativeDevelopmentPercentage],
	[DevelopmentYear],
	[AuditSourceBatchID]	
      FROM [FinanceDataContract].[Inbound].[DiscountRates]   WHERE AuditSourceBatchID=@BatchId and [SettlementCCY]='EUR'
                     
      )A
					
		 ROLLBACK; 
         END TRY
         BEGIN CATCH
               ROLLBACK;
              THROW;
         END CATCH