﻿CREATE PROCEDURE [ReinsuranceMI].[usp_LandingToInbound_SignedProfitCommission]
	--declare
	@p_ParentActivityLogId BIGINT = NULL
	,@p_ActivityJobId VARCHAR(50) = NULL
	,@p_AccountingPeriod INT
AS

/* =============================================
-- Modified by:			Samata.Putumbaka@beazley.com
-- Modification date:	30-09-2021
-- Changes:				Loads Signed profit commission data from FinanceLanding to Inbound.Transaction
-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	23-07-2021
-- Changes:				For attribute only changes we using the current date for the date of fact.
-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	10-08-2021
-- Changes:				ProgrammeCode changed and needs to accomodate character length of 100.
-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	26-08-2021
-- Changes:				Code allocations were wrong. I needed to allocate to existing date of fact & just change the fk allocation.

	Altered by:			nithin.dumpeti@beazley.com
	Altered date:		05-02-2024
	Changes:			Auditing AccountingPeriod in inbound.batchqueue table in column AsAt for passing date as a parameter externally

-- =============================================	*/
BEGIN
	SET NOCOUNT ON;

	DECLARE @Trancount INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);
	DECLARE @v_RC INT;
	DECLARE @v_ActivityLogTag BIGINT;
	DECLARE @v_ActivitySource SMALLINT;
	DECLARE @v_ActivityType SMALLINT;
	DECLARE @v_ActivityStatusStart SMALLINT;
	DECLARE @v_ActivityStatusStop SMALLINT;
	DECLARE @v_ActivityStatusFail SMALLINT;
	DECLARE @v_ActivityHost VARCHAR(100);
	DECLARE @v_ActivityDatabase VARCHAR(100);
	DECLARE @v_ActivityName VARCHAR(100);
	DECLARE @v_ActivityDateTime DATETIME2(2);
	DECLARE @v_ActivityMessage NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn BIGINT;
	DECLARE @v_ActivityLogIdOut BIGINT;
	DECLARE @v_ActivityJobId VARCHAR(50) = @p_ActivityJobId;
	DECLARE @v_ActivitySSISExecutionId VARCHAR(50) = NULL;
	DECLARE @v_AffectedRows INT = 0;
	DECLARE @v_DataSet VARCHAR(255) = 'Signed Profit Commission'
	DECLARE @ContractType CHAR(3) = 'PC'
	DECLARE @v_AccountingPeriod INT = @p_AccountingPeriod
	DECLARE @v_AsAt VARCHAR(6);
	-- for debugging. set to 1 & then no records will be written to the inbound tables.
	DECLARE @stop BIT = 0

	SELECT @v_ActivityStatusStart = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'ERRORED';

	DECLARE @v_BatchId INT;
	DECLARE @v_BatchId_Extensions INT;

	/* Log the start of the insert */
	BEGIN TRY
		SELECT @v_ActivityLogTag = NULL
			,@v_ActivitySource = (
				SELECT PK_ActivitySource
				FROM Orchestram.Log.ActivitySource
				WHERE ActivitySource = 'IFRS17'
				)
			,@v_ActivityType = (
				SELECT PK_ActivityType
				FROM Orchestram.Log.ActivityType
				WHERE ActivityType = CASE 
						WHEN @p_ParentActivityLogId IS NULL
							THEN 'Manual process'
						ELSE 'Automated process'
						END
				)
			,@v_ActivityHost = @@SERVERNAME
			,@v_ActivityName = 'Load signed profit commission data into Inbound.Transaction'
			,@v_ActivityDatabase = 'FinanceLanding'
			,@v_ActivityDateTime = GETUTCDATE()
			,@v_ActivityMessage = NULL
			,@v_ActivityErrorCode = NULL;

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStart
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

		--------------------------------------------------
		--------------------------------------------------
		DECLARE @OpeningBalanceDate DATE = '31 December 2018' -- this is the date for the opening balance
		DECLARE @OpeningBalanceCutOffYear INT = year(@OpeningBalanceDate) --+ 1 --- 2019
		DECLARE @OpeningBalanceAllocationPeriod INT = year(@OpeningBalanceDate) * 100 + month(@OpeningBalanceDate) -- 201812
			--select @AllocationPeriodForAggregate

		-- Get all the Profit Commission data
		DROP TABLE

		IF EXISTS #ProfitCommission;
			SELECT Account
				,DateOfFact
				,BusinessKey
				,PolicyNumber
				,InceptionDate
				,ExpiryDate
				,Entity
				,YOA
				,SettlementCCY
				,OriginalCCY
				,[Value]
				,[ValueOrg]
				-- extended values
				,RIPolicyType
				,ProgrammeCode
				-- create an int, yyyymm 202105 for example - used later as a filter against the allocations data.
				,AccPeriod = (year(DateOfFact) * 100 + month(DateOfFact))
				,id = identity(INT, 1, 1) -- used to simplify the check that records have been allocated or not.
			INTO #ProfitCommission
			FROM (
				SELECT Account = CONVERT(VARCHAR(14), pc.Account)
					-- Change the date to a date - get rid of the time part and aggregate to the day.
					-- 2018Q4 -- i need to sum up to 2018Q4, so any dates before this become '31 December 2018'
					,DateOfFact = CASE 
						WHEN year(pc.DateOfFact) <= @OpeningBalanceCutOffYear
							THEN @OpeningBalanceDate
						ELSE CONVERT(DATE, pc.DateOfFact)
						END
					,BusinessKey = CONVERT(VARCHAR(255), pc.BusinessKey)
					,PolicyNumber = CONVERT(VARCHAR(255), pc.RIPolicyNumber)
					,InceptionDate = CONVERT(DATETIME, pc.RIInceptionDate)
					,ExpiryDate = CONVERT(DATETIME, pc.RIExpiryDate)
					,Entity = CONVERT(VARCHAR(25), pc.Entity)
					,YOA = ISNULL(CONVERT(VARCHAR(5), NULLIF(pc.YOA, 0)), 'NOYOA')
					,SettlementCCY = CONVERT(VARCHAR(3), pc.SettlementCCY)
					,OriginalCCY = CONVERT(VARCHAR(3), pc.OriginalCCY)
					,[Value] = CONVERT(NUMERIC(19, 4), pc.[Value])
					,[ValueOrg] = CONVERT(NUMERIC(19, 4), pc.[ValueOrg])
					-- extended values
					,RIPolicyType = ISNULL(cri.confirmed_RIPolicyType, PC.RIPolicyType)
					,ProgrammeCode = convert(VARCHAR(100), CASE 
							WHEN rtc.ProgrammeCode IS NULL
								AND pc.RIPolicyNumber LIKE 'R1139%'
								THEN 'MUNQQS'
							WHEN rtc.ProgrammeCode IS NULL
								AND pc.RIPolicyNumber LIKE 'R0766%'
								THEN 'TRALIA'
							ELSE rtc.ProgrammeCode
							END)
				FROM ReinsuranceMI.SignedProfitCommission AS pc
				LEFT JOIN [Eurobase].[vw_ReInsuranceTreatyContractAttributes] AS rtc ON pc.RIPolicyNumber = rtc.RI_Section_Reference
				LEFT JOIN mds.RITypeMapping cri ON PC.RIPolicyType = cri.RIPolicyType
				) r
			WHERE (year(DateOfFact) * 100 + month(DateOfFact)) <= @v_AccountingPeriod

		----------------------------
		-----Change Alloc - Start
		------------------------------
		DROP TABLE

		IF EXISTS #cte_alloc
			SELECT EntityCode
				,AccountingPeriod
				,
				-- AccountingPeriod=case when AccountingPeriod <= 201812 then 201812 else AccountingPeriod end ,
				YOA
				,ProgrammeCode
				,TrifocusCode
				,TrifocusName
				,Amount
				,TotalAmount
				,MasterRIInd
				,Allocation = convert(NUMERIC(38, 7), (Amount / TotalAmount))
			INTO #cte_alloc
			FROM FinanceLanding.fdm.[vw_ReInsuranceAllocationsGeneric]
			WHERE TotalAmount <> 0
				AND AccountingPeriod <= @v_AccountingPeriod

		DROP TABLE

		IF EXISTS #cte_alloc_pass2
			SELECT EntityCode
				,AccountingPeriod
				--,AccountingPeriod=case when AccountingPeriod <= 201812 then 201812 else AccountingPeriod end 
				,ProgrammeCode
				,TrifocusCode
				,TrifocusName
				,Amount
				,TotalAmount
				,MasterRIInd
				,convert(NUMERIC(38, 7), (Amount / TotalAmount)) Allocation
			INTO #cte_alloc_pass2 --19826 Count match with PD
			FROM (
				SELECT EntityCode
					,AccountingPeriod
					,ProgrammeCode
					,TrifocusCode
					,TrifocusName
					,SUM(Amount) Amount
					,SUM(SUM(Amount)) OVER (
						PARTITION BY EntityCode
						,AccountingPeriod
						,ProgrammeCode
						) TotalAmount
					,MasterRIInd
				FROM #cte_alloc
				WHERE MasterRIInd = 'N'
				GROUP BY EntityCode
					,AccountingPeriod
					,ProgrammeCode
					,TrifocusCode
					,TrifocusName
					,MasterRIInd
				
				UNION ALL
				
				SELECT EntityCode
					,AccountingPeriod
					,ProgrammeCode
					,TrifocusCode
					,TrifocusName
					,SUM(Amount) Amount
					,SUM(SUM(Amount)) OVER (
						PARTITION BY EntityCode
						,AccountingPeriod
						) TotalAmount
					,MasterRIInd
				FROM #cte_alloc
				WHERE MasterRIInd = 'Y'
				GROUP BY EntityCode
					,AccountingPeriod
					,ProgrammeCode
					,TrifocusCode
					,TrifocusName
					,MasterRIInd
				) t
			WHERE TotalAmount <> 0

		DROP TABLE

		IF EXISTS #cte_latestalloc --select * from #cte_latestalloc
			SELECT AccountingPeriod
				,t.EntityCode
				,t.ProgrammeCode
				,t.YOA
				,t.TrifocusCode
				,t.Amount
				,t.TotalAmount
				,t.Allocation
				,t.MasterRIInd
			INTO #cte_latestalloc
			FROM #cte_alloc t
			JOIN (
				SELECT t.ProgrammeCode
					,t.EntityCode
					,t.YOA
					,t.MasterRIInd
					,max(t.AccountingPeriod) MaxAccountingPeriod
				FROM #cte_alloc t
				WHERE MasterRIInd = 'N'
				GROUP BY t.ProgrammeCode
					,t.EntityCode
					,t.YOA
					,t.MasterRIInd
				) m ON (
					m.ProgrammeCode = t.ProgrammeCode
					AND m.EntityCode = t.EntityCode
					AND m.YOA = t.YOA
					AND m.MaxAccountingPeriod = t.AccountingPeriod
					AND m.MasterRIInd = t.MasterRIInd
					)
			WHERE 1 = 1
				--abs(TotalAmount)>10    -- Check with PD 
				AND t.MasterRIInd = 'N'
			
			UNION ALL
			
			SELECT AccountingPeriod
				,t.EntityCode
				,t.ProgrammeCode
				,t.YOA
				,t.TrifocusCode
				,t.Amount
				,t.TotalAmount
				,t.Allocation
				,t.MasterRIInd
			FROM #cte_alloc t
			JOIN (
				SELECT t.EntityCode
					,t.YOA
					,t.MasterRIInd
					,max(t.AccountingPeriod) MaxAccountingPeriod
				FROM #cte_alloc t
				WHERE t.MasterRIInd = 'Y'
				GROUP BY t.EntityCode
					,t.YOA
					,t.MasterRIInd
				) m ON (
					m.EntityCode = t.EntityCode
					AND m.YOA = t.YOA
					AND m.MaxAccountingPeriod = t.AccountingPeriod
					AND m.MasterRIInd = t.MasterRIInd
					)
			WHERE 1 = 1
				--abs(TotalAmount)>10
				AND t.MasterRIInd = 'Y'

		DROP TABLE

		IF EXISTS #cte_latestalloc_pass2 --select * from #cte_latestalloc
			SELECT AccountingPeriod
				,t.EntityCode
				,t.ProgrammeCode
				,t.TrifocusCode
				,t.Amount Amount
				,t.TotalAmount TotalAmount
				,t.Allocation Allocation
				,t.MasterRIInd
			INTO #cte_latestalloc_pass2
			FROM #cte_alloc_pass2 t
			JOIN (
				SELECT t.ProgrammeCode
					,t.EntityCode
					,t.MasterRIInd
					,max(t.AccountingPeriod) MaxAccountingPeriod
				FROM #cte_alloc t
				WHERE MasterRIInd = 'N'
				GROUP BY t.ProgrammeCode
					,t.EntityCode
					,t.MasterRIInd
				) m ON (
					m.ProgrammeCode = t.ProgrammeCode
					AND m.EntityCode = t.EntityCode
					AND m.MaxAccountingPeriod = t.AccountingPeriod
					AND m.MasterRIInd = t.MasterRIInd
					)
			WHERE 1 = 1
				--abs(TotalAmount)>10
				AND t.MasterRIInd = 'N' --See if can exlcude this filter
			
			UNION ALL
			
			SELECT AccountingPeriod
				,t.EntityCode
				,t.ProgrammeCode
				,t.TrifocusCode
				,t.Amount Amount
				,t.TotalAmount TotalAmount
				,t.Allocation Allocation
				,t.MasterRIInd
			FROM #cte_alloc_pass2 t
			JOIN (
				SELECT t.EntityCode
					,t.MasterRIInd
					,MAX(t.AccountingPeriod) MaxAccountingPeriod
				FROM #cte_alloc t
				WHERE t.MasterRIInd = 'Y'
				GROUP BY t.EntityCode
					,t.MasterRIInd
				) m ON (
					m.EntityCode = t.EntityCode
					AND m.MaxAccountingPeriod = t.AccountingPeriod
					AND m.MasterRIInd = t.MasterRIInd
					)
			WHERE 1 = 1
				--abs(TotalAmount)>10
				AND t.MasterRIInd = 'Y'

		----------------------------
		------Change Alloc - End----
		----------------------------
		
		DROP TABLE

		IF EXISTS #TempInboundTransactionInIt1
			SELECT t.Account
				,t.DateOfFact
				,t.BusinessKey
				,t.PolicyNumber
				,t.InceptionDate
				,t.ExpiryDate
				,ISNULL(v.TrifocusCode, 'UNKNOWN') TrifocusCode
				,en.ConformedEntityMapping Entity
				,t.YOA
				,t.SettlementCCY
				,t.OriginalCCY
				,AllocatedValue = (CONVERT(NUMERIC(19, 4), t.[Value] * isnull(v.Allocation, 1)))
				,CASE 
					WHEN t.ProgrammeCode = 'Master RI'
						THEN 'Y'
					ELSE 'N'
					END IsMasterRI
				,CONVERT(INT, v.[AccountingPeriod]) [FK_Allocation]
				,RIPolicyType
				,ISNULL(CASE 
						WHEN t.ProgrammeCode = 'Master RI'
							THEN coalesce(v.ProgrammeCode, t.ProgrammeCode)
						ELSE t.ProgrammeCode
						END, 'UNKNOWN') ProgrammeCode
			INTO #TempInboundTransactionInIt1
			FROM #ProfitCommission t
			LEFT JOIN FinanceLanding.mds.ConformedEntityMapping en ON (en.Entity = cast(t.Entity AS VARCHAR))
			LEFT JOIN #cte_latestalloc v ON (
					v.EntityCode = en.ConformedEntityMapping
					AND v.ProgrammeCode = CASE 
						WHEN v.MasterRIInd = 'Y'
							THEN v.ProgrammeCode
						ELSE t.ProgrammeCode
						END
					AND v.YOA = t.YOA
					AND v.AccountingPeriod >= cast(left(convert(VARCHAR, CASE 
									WHEN t.DateOfFact < '2018-12-31'
										THEN '2018-12-31'
									ELSE t.DateOfFact
									END, 112), 6) AS INT)
					AND (
						(
							v.MasterRIInd = 'N'
							AND t.ProgrammeCode <> 'Master RI'
							)
						OR (
							v.MasterRIInd = 'Y'
							AND t.ProgrammeCode = 'Master RI'
							)
						)
					)

		DROP TABLE

		IF EXISTS #TempInboundTransactionInIt2
			SELECT t.Account
				,t.DateOfFact
				,t.BusinessKey
				,t.PolicyNumber
				,t.InceptionDate
				,t.ExpiryDate
				,CASE 
					WHEN t.TrifocusCode = 'UNKNOWN'
						AND t.FK_Allocation IS NULL
						THEN isnull(v2.TrifocusCode, isnull(v3.TrifocusCode, 'UNKNOWN'))
					ELSE t.TrifocusCode
					END TrifocusCode
				,t.Entity
				,t.YOA
				,t.SettlementCCY
				,t.OriginalCCY
				,t.[AllocatedValue] * isnull(v2.Allocation, isnull(v3.Allocation, 1)) AllocatedValue
				,CASE 
					WHEN t.ProgrammeCode = 'Master RI'
						THEN 'Y'
					ELSE 'N'
					END IsMasterRI
				,CASE 
					WHEN t.TrifocusCode = 'UNKNOWN'
						AND t.FK_Allocation IS NULL
						THEN CONVERT(INT, isnull(v2.[AccountingPeriod], v3.[AccountingPeriod]))
					ELSE t.FK_Allocation
					END [FK_Allocation]
				,RIPolicyType
				,ISNULL(CASE 
						WHEN t.ProgrammeCode = 'Master RI'
							THEN coalesce(v3.ProgrammeCode, t.ProgrammeCode)
						ELSE t.ProgrammeCode
						END, 'UNKNOWN') ProgrammeCode
			INTO #TempInboundTransactionInIt2
			FROM #TempInboundTransactionInIt1 t
			LEFT JOIN #cte_latestalloc_pass2 v2 -- select * from #cte_latestalloc_pass2
				ON (
					t.TrifocusCode = 'UNKNOWN'
					AND t.ProgrammeCode <> 'Master RI'
					AND v2.MasterRIInd = 'N'
					AND v2.EntityCode = t.Entity
					AND v2.ProgrammeCode = CASE 
						WHEN t.ProgrammeCode = 'Property Cat XL'
							THEN 'Property Risk Excess'
						ELSE t.ProgrammeCode
						END
					AND v2.AccountingPeriod >= cast(left(convert(VARCHAR, t.DateOfFact, 112), 6) AS INT)
					)
			LEFT JOIN #cte_latestalloc_pass2 v3 ON (
					t.TrifocusCode = 'UNKNOWN'
					AND t.FK_Allocation IS NULL
					AND t.ProgrammeCode = 'Master RI'
					AND v3.MasterRIInd = 'Y'
					AND v3.EntityCode = t.Entity
					AND v3.AccountingPeriod >= cast(left(convert(VARCHAR, t.DateOfFact, 112), 6) AS INT)
					)

		DROP TABLE

		IF EXISTS #TempInboundTransactionInIt3
			SELECT t.Account
				,t.DateOfFact
				,t.BusinessKey AS BK2
				--,case when t.IsMasterRI='Y' then t.BusinessKey else t.BusinessKey +'|'+ISNULL(t.ProgrammeCode,'-') end as BK2
				,t.BusinessKey + '|' + isnull(ptsm.TrifocusCode, t.TrifocusCode) + '|' + ISNULL(t.ProgrammeCode, '-') AS BusinessKey
				,t.PolicyNumber
				,t.InceptionDate
				,t.ExpiryDate
				,isnull(ptsm.TrifocusCode, t.TrifocusCode) TrifocusCode
				,t.Entity
				,t.YOA
				,t.SettlementCCY
				,t.OriginalCCY
				,t.AllocatedValue [Value]
				,t.AllocatedValue [ValueOrig]
				,t.FK_Allocation
				,t.RIPolicyType
				,t.ProgrammeCode
			INTO #TempInboundTransactionInIt3
			FROM #TempInboundTransactionInIt2 t
			LEFT JOIN mds.ProgrammeTrifocusStaticMapping ptsm ON ptsm.Programme = t.ProgrammeCode		

				-- now i need to aggregate up the values as we could have the same claim with multiple values for the same day
		DROP TABLE

		IF EXISTS #TempInboundTransactionInitAgg;
			SELECT Account
				,DateOfFact
				,BusinessKey
				,BK2
				,PolicyNumber
				,InceptionDate
				,ExpiryDate
				,TrifocusCode
				,Entity
				,YOA
				,[Value] = sum([Value])
				,[ValueOrig] = sum([ValueOrig])
				-- extra column to help get back to the allocations source
				,[FK_Allocation]
				-- extended values
				,RIPolicyType
				,ProgrammeCode
				/*,BeazleyCatCode
						,TransactionDate		
						,IsLargeLoss*/
				-- add columns here to keep the rowhash function clean
				,BindDate = CONVERT(DATETIME, '19800101')
				,DueDate = CONVERT(DATETIME, '19800101')
				,[Location] = '-'
				,Scenario = CONVERT([VARCHAR](2), 'A')
				,Basis = CONVERT([VARCHAR](2), 'E')
				,DataSet = @v_DataSet
				,TypeOfBusiness = CONVERT([VARCHAR](1), '-')
				,IsToDate = CONVERT([VARCHAR](1), 'N')
				,StatsCode = CONVERT([VARCHAR](25), '-')
				,SettlementCCY = SettlementCCY
				,OriginalCCY = OriginalCCY
				,BusinessProcessCode = BK2
			INTO #TempInboundTransactionInitAgg
			FROM #TempInboundTransactionInit3
			GROUP BY Account
				,DateOfFact
				,BusinessKey
				,BK2
				,PolicyNumber
				,InceptionDate
				,ExpiryDate
				,TrifocusCode
				,Entity
				,YOA
				,SettlementCCY
				,OriginalCCY
				-- extra column to help get back to the allocations source
				,[FK_Allocation]
				-- extended values
				,RIPolicyType
				,ProgrammeCode

		DROP TABLE

		IF EXISTS #TempInboundTransactionInit1 -- no longer needed
			DROP TABLE

		IF EXISTS #TempInboundTransactionInIt2
			DROP TABLE

		IF EXISTS #TempInboundTransactionInIt3
			--SELECT '#TempInboundTransactionInitAgg',* FROM #TempInboundTransactionInitAgg 
			-----------------------------------------
			IF object_id('tempdb..#TempInboundTransaction') IS NOT NULL
				DROP TABLE #TempInboundTransaction

		SELECT tmp.Scenario
			,tmp.Basis
			,tmp.Account
			,tmp.DataSet
			,tmp.DateOfFact
			,tmp.BusinessKey
			,tmp.PolicyNumber
			,tmp.InceptionDate
			,tmp.ExpiryDate
			,tmp.BindDate
			,tmp.DueDate
			,tmp.TrifocusCode
			,tmp.Entity
			,tmp.[Location]
			,tmp.YOA
			,tmp.TypeOfBusiness
			,tmp.SettlementCCY
			,tmp.OriginalCCY
			,tmp.IsToDate
			,tmp.[Value]
			,tmp.ValueOrig
			-- extra column to help get back to the allocations source
			,tmp.[FK_Allocation]
			-- extended values
			,tmp.RIPolicyType
			,tmp.ProgrammeCode
			,RowHash = dbo.fn_RowHashForTransactions('T' -- <@RowHashType, char(1),>
				, tmp.[Scenario] --,<@Scenario, nvarchar(2000),>
				, tmp.[Account] --,<@Account, nvarchar(2000),>
				, tmp.[DataSet] --,<@DataSet, nvarchar(2000),>
				, tmp.[BusinessKey] --,<@BusinessKey, nvarchar(2000),>
				, tmp.[PolicyNumber] --,<@PolicyNumber, nvarchar(2000),>
				, tmp.[InceptionDate] --,<@InceptionDate, date,>
				, tmp.[ExpiryDate] --,<@ExpiryDate, date,>
				, tmp.[BindDate] --,<@BindDate, date,>
				, tmp.[DueDate] --,<@DueDate, date,>
				, tmp.[TrifocusCode] --,<@TrifocusCode, nvarchar(2000),>
				, tmp.[Entity] --,<@Entity, nvarchar(2000),>
				, tmp.[YOA] --,<@YOA, nvarchar(2000),>
				, tmp.[TypeOfBusiness] --,<@TypeOfBusiness, nvarchar(2000),>
				, tmp.StatsCode --,<@StatsCode, nvarchar(2000),>
				, tmp.[SettlementCCY] --,<@SettlementCCY, nvarchar(2000),>
				, tmp.[OriginalCCY] --,<@OriginalCCY, nvarchar(2000),>
				, tmp.[IsToDate] --,<@IsToDate, nvarchar(2000),>
				, tmp.[Basis] --,<@Basis, nvarchar(2000),>
				, tmp.[Location] --,<@Location, nvarchar(2000),>
				, tmp.[BusinessProcessCode] --,<@BusinessProcessCode, nvarchar(2000),>
				, NULL --,<@BoundDate, date,>
				---,null						--,<@extensions, nvarchar(max),>)
				, CONCAT (
					CASE 
						WHEN RIPolicyType IS NULL
							THEN ''
						ELSE (RIPolicyType + '§~§')
						END
					,CASE 
						WHEN ProgrammeCode IS NULL
							THEN ''
						ELSE (ProgrammeCode + '§~§')
						END
					))
			,[RowHash_Transaction_ReInsurance_Extensions] = dbo.fn_RowHashForTransactions('E' 
				, tmp.Scenario, tmp.Account, tmp.DataSet, tmp.BusinessKey, tmp.PolicyNumber, tmp.InceptionDate, tmp.ExpiryDate, tmp.BindDate, tmp.DueDate, tmp.TrifocusCode, tmp.Entity, tmp.YOA, tmp.TypeOfBusiness, tmp.StatsCode, tmp.SettlementCCY, tmp.OriginalCCY, tmp.IsToDate, tmp.Basis, tmp.[Location], NULL 
				, NULL 
				-- extended columns
				, CONCAT (
					CASE 
						WHEN tmp.ProgrammeCode IS NULL
							THEN ''
						ELSE (tmp.ProgrammeCode + '§~§')
						END
					,CASE 
						WHEN tmp.RIPolicyType IS NULL
							THEN ''
						ELSE (tmp.RIPolicyType + '§~§')
						END
					))
			,tmp.BusinessProcessCode
			,tmp.StatsCode
		INTO #TempInboundTransaction
		FROM #TempInboundTransactionInitAgg AS tmp

		DROP TABLE

		IF EXISTS #TempInboundTransactionInitAgg;-- no longer needed
			------/* Delete the current lines from Inbound ... */
			DELETE
			FROM [FinanceDataContract].[Inbound].[Transaction]
			WHERE [DataSet] = @v_DataSet

		DELETE [FinanceDataContract].[Inbound].[Transaction_Reinsurance_Extensions_Bridge]
		WHERE [ContractType] = @ContractType

		DELETE [FinanceDataContract].[Inbound].[Transaction_Reinsurance_Extensions]
		WHERE [ContractType] = @ContractType

		--If no new data, then log and exit
		IF NOT EXISTS (
				SELECT TOP 1 1
				FROM #TempInboundTransaction
				)
		BEGIN
			SELECT @v_ActivityDateTime = GETUTCDATE()
				,@v_AffectedRows = 0;

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStop
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

			RETURN;
		END;

		IF @Trancount = 0
			BEGIN TRAN;

		-- select * from [dbo].[Batch]
		INSERT INTO [dbo].[Batch] (
			[CreateDate]
			,[DataSet]
			,[LatestBusinesKey]
			)
		VALUES (
			GETDATE()
			,@v_DataSet
			,NULL
			);

		SELECT @v_BatchId = SCOPE_IDENTITY();

		INSERT INTO [dbo].[Batch] (
			[CreateDate]
			,[DataSet]
			,[LatestBusinesKey]
			)
		VALUES (
			GETDATE()
			,'ReinsuranceExtensions'
			,NULL
			);

		SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();

		--drop table #transactions_final_agg_cs
		--drop table #transactions_final_agg
		----/* ... and add the new ones  */
		INSERT INTO [FinanceDataContract].[Inbound].Transaction_Reinsurance_Extensions_Bridge
		WITH (TABLOCK) (
				[RowHash_Transaction]
				,[RowHash_Transaction_Reinsurance_Extensions]
				,[ContractType]
				,[FK_Batch]
				)
		SELECT DISTINCT [RowHash]
			,[RowHash_Transaction_Reinsurance_Extensions]
			,@ContractType
			,@v_BatchId_Extensions
		FROM #TempInboundTransaction
		WHERE @stop = 0

		INSERT INTO [FinanceDataContract].[Inbound].Transaction_Reinsurance_Extensions
		WITH (TABLOCK) (
				[RowHash_Transaction_Reinsurance_Extensions]
				,[RIPolicyType]
				,[ProgrammeCode]
				,[IsLargeLoss]
				,[ContractType]
				,[FK_Batch]
				)
		SELECT DISTINCT [RowHash_Transaction_Reinsurance_Extensions]
			,[RIPolicyType]
			,[ProgrammeCode]
			,NULL
			,@ContractType
			,@v_BatchId_Extensions
		FROM #TempInboundTransaction
		WHERE @stop = 0

		INSERT INTO [FinanceDataContract].[Inbound].[Transaction]
		WITH (TABLOCK) (
				[Scenario]
				,[Basis]
				,[Account]
				,[DataSet]
				,[DateOfFact]
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]
				,[DueDate]
				,[TrifocusCode]
				,[Entity]
				,[Location]
				,[YOA]
				,[TypeOfBusiness]
				,[StatsCode]
				,[SettlementCCY]
				,[OriginalCCY]
				,[IsToDate]
				,[Value]
				,[ValueOrig]
				,[RowHash]
				,[FK_Allocation]
				,[BusinessProcessCode]
				,[FK_Batch]
				,[AuditSourceBatchID]
				,[AuditHost]
				,[AuditGenerateDateTime]
				)
		--,[DeltaType]
		SELECT t.[Scenario]
			,t.[Basis]
			,t.[Account]
			,t.[DataSet]
			,t.[DateOfFact]
			,t.[BusinessKey]
			,t.[PolicyNumber]
			,t.[InceptionDate]
			,t.[ExpiryDate]
			,t.[BindDate]
			,t.[DueDate]
			,t.[TrifocusCode]
			,t.[Entity]
			,t.[Location]
			,t.[YOA]
			,t.[TypeOfBusiness]
			,t.[StatsCode]
			,t.[SettlementCCY]
			,t.[OriginalCCY]
			,t.[IsToDate]
			,t.[Value]
			,t.[ValueOrig]
			,t.[RowHash]
			,t.[FK_Allocation]
			,t.[BusinessProcessCode]
			,FK_Batch = @v_BatchId
			,AuditSourceBatchID = @v_BatchId
			,[AuditHost] = CONVERT([VARCHAR](255), (SERVERPROPERTY('MachineName')))
			,[AuditGenerateDateTime] = GETUTCDATE()
		--,DeltaType
		FROM #TempInboundTransaction t

		--where
		--	@stop = 0
		SELECT @v_AffectedRows = @@ROWCOUNT;

		SET @v_AsAt = left(convert(VARCHAR(10), @v_AccountingPeriod), 6) --AsAt will store passing date as parameter externally. if it is null then take default as getdate

		--/* Add the batchs to the queue */
		---- select top 100 * from [FinanceDataContract].[Inbound].[BatchQueue] order by 1 desc
		INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue] (
			Pk_Batch
			,[Status]
			,RunDescription
			,[DataSet]
			,OriginalName
			,AuditSourceBatchID
			,AsAt
			)
		VALUES (
			@v_BatchId
			,'InBound'
			,NULL
			,@v_DataSet
			,NULL
			,NULL
			,@v_AsAt
			)
			,(
			@v_BatchId_Extensions
			,'InBound'
			,'ReinsuranceExtensions, the additional attributes to extend functionality of the transaction table.'
			,'ReinsuranceExtensions'
			,NULL
			,NULL
			,@v_AsAt
			);

		-- LOG THE RESULT WITH SUCCESS
		SELECT @v_ActivityDateTime = GETUTCDATE();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStop
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		IF @Trancount = 0
			AND @@TRANCOUNT <> 0
			COMMIT;
	END TRY

	BEGIN CATCH
		-- CANCEL TRAN
		IF @Trancount = 0
			AND @@TRANCOUNT <> 0
			ROLLBACK;

		-- LOG THE RESULT WITH ERROR
		SELECT @v_ActivityDateTime = GETUTCDATE()
			,@v_ActivityLogTag = @v_ActivityLogIdIn
			,@v_ActivityMessage = ERROR_MESSAGE()
			,@v_ActivityErrorCode = ERROR_NUMBER();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusFail
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		THROW;
	END CATCH;
END;
