﻿CREATE TABLE [ReinsuranceMI].[DimCurrency]
(
	[PK_Currency] [int] NOT NULL,
	[PK_Elgar_Currency] [int] NOT NULL,
	[CurrencyCode] [varchar](50) NOT NULL,
	[CurrencyDescription] [varchar](100) NOT NULL,
	[GBPMultiplier] [float] NOT NULL
)
