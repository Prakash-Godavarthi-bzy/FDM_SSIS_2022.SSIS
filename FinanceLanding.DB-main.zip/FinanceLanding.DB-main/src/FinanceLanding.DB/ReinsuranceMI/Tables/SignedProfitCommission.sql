﻿CREATE TABLE [ReinsuranceMI].[SignedProfitCommission]
(
	[DateOfFact] [datetime] NULL,
	[BusinessKey] [bigint] NULL,
	[BindDate] [datetime] NULL,
	[DueDate] [datetime] NULL,
	[Entity] [varchar](25) NULL,
	[YOA] [varchar](25) NULL,
	[TypeOfBusiness] [varchar](25) NULL,
	[SettlementCCY] [varchar](25) NULL,
	[OriginalCCY] [varchar](25) NULL,
	[IsToDate] [varchar](1) NULL,
	[ValueOrg] [numeric](28, 3) NULL,
	[Scenario] [varchar](1) NULL,
	[Basis] [varchar](1) NULL,
	[RIPolicyType] [varchar](3) NULL,
	[Account] [varchar](12) NULL,
	[DataSet] [varchar](24) NULL,
	[RIPolicyNumber] [varchar](100) NULL,
	[RIInceptionDate] [datetime] NULL,
	[RIExpiryDate] [datetime] NULL,
	[TriFocus] [int] NULL,
	[ProgrammeCode] [int] NULL,
	[Location] [varchar](2) NULL,
	[StatsCode] [varchar](2) NULL,
	[Value] NUMERIC(28, 3) NULL
) ON [PRIMARY]
GO

EXEC sys.sp_addextendedproperty 
	@name=N'description', 
	@value=N'Loaded by the SSIS package IFRS17_BeazleyMIReinsuranceToLandingExtract.dtsx' , 
	@level0type=N'SCHEMA',
	@level0name=N'ReinsuranceMI', 
	@level1type=N'TABLE',
	@level1name=N'SignedProfitCommission'
GO
