﻿CREATE TABLE [ReinsuranceMI].[DimCreditNote]
(
	[PK_CreditNote] [int] NOT NULL,
	[PK_Elgar_CreditNote] [int] NOT NULL,
	[FK_CollectionNoteDetail] [int] NOT NULL,
	[CreditNoteName] [varchar](100) NOT NULL,
	[SigningNumber] [varchar](100) NOT NULL,
	[SigningDate] [datetime] NULL,
	[FK_SigningDate] [datetime] NOT NULL,
	[CreditNoteAmount] [float] NOT NULL,
	[CreditNoteAmountGBP] [float] NOT NULL,
	[DummyCreditNote] [bit] NOT NULL,
	[DaysToSettle] [int] NULL,
	[FK_DaysSettlementBand] [int] NOT NULL
)
