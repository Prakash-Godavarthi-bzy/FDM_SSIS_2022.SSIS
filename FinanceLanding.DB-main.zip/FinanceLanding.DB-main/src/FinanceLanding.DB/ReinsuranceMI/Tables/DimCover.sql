﻿CREATE TABLE [ReinsuranceMI].[DimCover]
(
	[PK_Cover] [int] NOT NULL,
	[PK_Elgar_Cover] [int] NOT NULL,
	[FK_Broker] [int] NOT NULL,
	[PolicyReferenceYear] [varchar](100) NOT NULL,
	[PolicyDescription] [varchar](100) NOT NULL,
	[InceptionDate] [datetime] NOT NULL,
	[FK_InceptionDate] [datetime] NOT NULL,
	[ExpiryDate] [datetime] NOT NULL,
	[FK_ExpiryDate] [datetime] NOT NULL,
	[PolicyType] [int] NOT NULL,
	[PolicyReference] [varchar](100) NOT NULL,
	[PolicyYear] [int] NOT NULL,
	[BrokerReference] [varchar](100) NOT NULL,
	[ProgramType] [int] NOT NULL,
	[ProgramTypeName] [varchar](100) NOT NULL,
	[Department] [varchar](255) NOT NULL,
	[Technician] [varchar](255) NOT NULL,
	[Tail] [varchar](255) NOT NULL
)
