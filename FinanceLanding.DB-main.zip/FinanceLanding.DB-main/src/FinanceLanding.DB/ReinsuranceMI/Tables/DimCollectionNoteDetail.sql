﻿CREATE TABLE [ReinsuranceMI].[DimCollectionNoteDetail]
(
	[PK_CollectionNoteDetail] [int] NOT NULL,
	[PK_Elgar_CollectionNoteDetail] [int] NOT NULL,
	[FK_CollectionNote] [int] NOT NULL,
	[FK_Currency] [int] NOT NULL,
	[FK_ClassOfBusiness] [int] NOT NULL,
	[CollectionNoteDetailName] [varchar](200) NULL,
	[SyndicateNumber] [varchar](50) NULL,
	[YOA] [int] NULL,
	[RiskCode] [varchar](50) NULL,
	[TrustFund] [varchar](50) NULL,
	[FILCode] [varchar](50) NULL,
	[FIL4Code] [varchar](50) NULL,
	[AccrualType] [varchar](50) NULL,
	[TransactionTypeName] [varchar](50) NOT NULL,
	[AmountRequested] [float] NOT NULL,
	[AmountRequestedGBP] [float]
)
