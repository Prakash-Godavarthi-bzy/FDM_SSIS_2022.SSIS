﻿CREATE TABLE [ReinsuranceMI].[DimCollectionNote]
(
	PK_CollectionNote INT NOT NULL,
	PK_Elgar_CollectionNote INT NOT NULL,
	FK_Cover INT NOT NULL,
	FK_Catastrophe INT NOT NULL,
	AdviceReference VARCHAR(100)NOT NULL,
	IssueDate DATETIME NOT NULL,
	FK_IssueDate DATETIME NOT NULL,
	ProcessingPeriod DATETIME NOT NULL,
	FK_ProcessingPeriod DATETIME NOT NULL,
	AdviceFlag INT NULL,
	DaysAge INT NULL,
	FK_DaysOutstandingBand INT NOT NULL,
	FK_DaysOutstandingBandPerContractTerms INT NOT NULL,
	FK_AmountRequestedBand INT NOT NULL,
	ProfitCommission VARCHAR(100) NOT NULL,
	MemoNotes VARCHAR(MAX) NULL,
	FACAfter2009Flag bit NOT NULL,
	TreatyAfter2005Flag bit NOT NULL,
	HasDummyCreditNote bit NOT NULL,
	BeforeAsAtDate bit NOT NULL	
)
