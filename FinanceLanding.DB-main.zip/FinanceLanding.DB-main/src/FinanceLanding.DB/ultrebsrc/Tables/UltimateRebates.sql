﻿CREATE TABLE [ultrebsrc].[UltimateRebates]
(
	[Programme] [varchar](50) NULL,
	[Entity] [varchar](50) NULL,
	[Value] [varchar](50) NULL,
	[YOA] [varchar](50) NULL,
	[DateOfFact] [date] NULL
)
