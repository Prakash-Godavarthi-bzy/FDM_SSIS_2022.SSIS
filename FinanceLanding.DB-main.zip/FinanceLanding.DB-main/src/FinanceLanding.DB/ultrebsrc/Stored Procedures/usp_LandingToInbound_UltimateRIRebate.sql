﻿CREATE PROCEDURE [ultrebsrc].[usp_LandingToInbound_UltimateRIRebate]
--declare
             @p_AccountingPeriod			INT 
			,@p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL 
AS
---exec [ultrebsrc].[usp_LandingToInbound_UltimateRIRebate] 202009
-- =============================================
-- Created by:			Srinivasa.Tummala@beazley.com
-- Modification date:	10-06-2021
-- Changes:				Initial version.

-- Created by:			charvitha.sadhu@beazley.com
-- Modification date:	16-08-2021
-- Changes:			     Added the code for push forwarding the accounting period except for 201812 accounting period. changes are done related to JIRA I1B-3228 ticket.

-- Modified by:			entha.bhargav@beazley.com
-- Modification date:	07-09-2022
-- Changes:	   removed "Missing 19Q4 Allocation (DB Link to DEV)" part to remove dependency of table missing19q4 data for https://beazley.atlassian.net/browse/I1B-3290


-- Modified by:			pavani.bandaru@beazley.com
-- Modification date:	21-08-2023
-- Changes:	   cdc  https://beazley.atlassian.net/browse/I1B-4079

-- =============================================	
	--SET ANSI_NULLS OFF
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @YOA int = YEAR(GETDATE())-3-- we only get data >= this variable
	/*DECLARE @ProcessAccountCodes table(ProcessCode char(2) not null, AccountCode char(7) not null)
	INSERT INTO @ProcessAccountCodes(ProcessCode,AccountCode) 
	VALUES('2A','RISPD01'),('2B','RISPD10')-- we're only interested in this combination
	*/
	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'ReinsuranceRebates_Ultimate';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	DECLARE @ContractType					CHAR(3)			= 'RRU'

	DECLARE @v_Dataset varchar(50)=@v_ActivityDatabase
	DECLARE @v_BatchId                   INT             = NULL;
	DECLARE @v_BatchId_Extensions INT;


BEGIN TRY

	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';

	/* Insert a new batch for ObligatedPremium_RISpend datasource table*/
	INSERT INTO [dbo].[Batch]([CreateDate],[DataSet],[LatestBusinesKey]) 
	VALUES  (GETDATE(),@v_Dataset,@p_AccountingPeriod);

	SELECT @v_BatchId = SCOPE_IDENTITY();

	/* Log the start of the insert */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'Load data into Inbound.Transaction'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'Load data into Inbound.Transaction for Reinsurance Ultimate Rebates'
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

	declare @OpeningBalanceDate date = '31 December 2018' -- this is the date for the opening balance
	declare @OpeningBalanceCutOffYear int = year(@OpeningBalanceDate) + 1 --- 2019
	declare @OpeningBalanceAllocationPeriod int = year(@OpeningBalanceDate) * 100 + month(@OpeningBalanceDate) -- 201812
	--SET @p_AccountingPeriod = @OpeningBalanceAllocationPeriod
		-- constants for constant values.
	declare 
		 @Scenario char(1)				= 'A' 
		,@Basis char(1)					= 'E'
		,@DefaultDate date				= CAST('01-01-1980' as date)
		,@TypeOfBusiness char(1)		= '-'
		,@Location char(1)				= '-'
		,@IsToDate char(1)				= 'Y'
		,@BusinessProcessCode char(2)	= 'T1'
		,@AuditHost varchar(255)		= CAST(SERVERPROPERTY('MachineName') as varchar(255))
		,@StatsCode varchar(25)			= null
		,@DateOfFact date				= convert(date,convert(char(8),@p_AccountingPeriod * 100 + 1),112)
		


	DROP TABLE IF EXISTS #ReInsuUltimate;

	select
    'EX-RB-RP-R' as Account,
    'ReinsuranceRebates_Ultimate' as Dataset,
    case when DateOfFact ='2018-12-01' then DateOfFact else dateadd(quarter, 1, DateOfFact) end AS DateOfFact,
    BusinessKey =
                'EX-RB-RP-R' + '|' +
                isnull(Programme, '-') + '|' +
                isnull(Entity, '-') + '|' +
                isnull(cast(t.YOA as varchar(50)), '-'),
    'NOPOLICY' as PolicyNumber,
    '1980-01-01' as InceptionDate,
    '1980-01-01' as ExpiryDate,
    '1980-01-01' as BindDate,
    '1980-01-01' as DuedDate,
    'Unknown' as TrifocusCode,
     case when Entity in ('BICI', 'USBICI') then '8022'
		  when Entity = 'BIDAC' then '8033'
		  else t.Entity
	 end Entity,
    YOA,
    null as StatsCode,
    'USD' as SettlementCCY,
    'USD' as OriginalCCY,
    Programme as ProgrammeCode,
    sum(CONVERT(NUMERIC(35,10),[Value])) as [Value],
    sum(CONVERT(DECIMAL(35,10),[Value])) as ValueOrig,
    left(convert(varchar, 
				 case when DateOfFact ='2018-12-01' then DateOfFact else dateadd(quarter, 1, DateOfFact) end, 
				 112), 6) AS AccountingPeriod
    into #ReInsuUltimate
	from [ultrebsrc].[UltimateRebates] AS t
	where left(convert(varchar, 
					   case when DateOfFact ='2018-12-01' then DateOfFact else dateadd(quarter, 1, DateOfFact) end, 
					   112), 6) = @p_AccountingPeriod
    group by
    case when DateOfFact = '2018-12-01' then DateOfFact else dateadd(quarter, 1, DateOfFact) end,
    Programme,
    case when Entity in ('BICI', 'USBICI') then '8022'
		 when Entity = 'BIDAC' then '8033'
		 else t.Entity
	 end,
     YOA,
	 'EX-RB-RP-R' + '|' +
                isnull(Programme, '-') + '|' +
                isnull(Entity, '-') + '|' +
                isnull(cast(t.YOA as varchar(50)), '-')
      
	  having sum(CONVERT(DECIMAL(28,3),[Value])) <> 0


----------------------------
-----Change Alloc - Start
------------------------------

DROP TABLE IF exists #cte_alloc

                SELECT   EntityCode,
						 AccountingPeriod,
						-- AccountingPeriod=case when AccountingPeriod <= 201812 then 201812 else AccountingPeriod end ,
						 YOA,
						 ProgrammeCode,
						 TrifocusCode,
						 TrifocusName,
						 Amount,
						 TotalAmount,
						 MasterRIInd,
						 Allocation= (Amount/ TotalAmount) 
                INTO	 #cte_alloc
                FROM	 FinanceLanding.fdm.[vw_ReInsuranceAllocationsGeneric]
				WHERE	 TotalAmount <> 0 and AccountingPeriod <=@p_AccountingPeriod


				DROP TABLE IF exists #cte_alloc_pass2

				SELECT		EntityCode
							,AccountingPeriod
							--,AccountingPeriod=case when AccountingPeriod <= 201812 then 201812 else AccountingPeriod end 
							,ProgrammeCode
							,TrifocusCode
							,TrifocusName
							,Amount
							,TotalAmount
							,MasterRIInd
							,(Amount/ TotalAmount) Allocation
				INTO		#cte_alloc_pass2   --19826 Count match with PD
				FROM 
						(
							SELECT		EntityCode,
										AccountingPeriod,
										ProgrammeCode,
										TrifocusCode,
										TrifocusName,
										SUM(Amount) Amount,
										SUM(SUM(Amount)) OVER(PARTITION BY EntityCode,
																		   AccountingPeriod,
																		   ProgrammeCode
																		   ) TotalAmount,   
										MasterRIInd
							FROM		#cte_alloc
							WHERE		MasterRIInd = 'N'			
									
							GROUP BY	EntityCode,
										AccountingPeriod,
										ProgrammeCode,
										TrifocusCode,
										TrifocusName,
										MasterRIInd
						
							UNION ALL
							
							SELECT		EntityCode,
										AccountingPeriod,
										ProgrammeCode,
										TrifocusCode,
										TrifocusName,
										SUM(Amount) Amount,
										SUM(SUM(Amount)) OVER(PARTITION BY EntityCode,
																		   AccountingPeriod  
															 ) TotalAmount,
										MasterRIInd
							FROM		#cte_alloc
							WHERE		MasterRIInd = 'Y'  
							
							GROUP BY	EntityCode,
										AccountingPeriod,
										ProgrammeCode,
										TrifocusCode,
										TrifocusName,
										MasterRIInd
						) t
				WHERE TotalAmount <> 0
					
				DROP TABLE IF exists #cte_latestalloc --select * from #cte_latestalloc

                SELECT			AccountingPeriod,
								t.EntityCode,
								t.ProgrammeCode,
								t.YOA,
								t.TrifocusCode,
								t.Amount,
								t.TotalAmount,
								t.Allocation,
								t.MasterRIInd

               INTO				#cte_latestalloc   
               
			   FROM				#cte_alloc t
               JOIN
	            (		
	                  SELECT	t.ProgrammeCode,
								t.EntityCode,
								t.YOA,
								t.MasterRIInd,
								max(t.AccountingPeriod) MaxAccountingPeriod
					  FROM		#cte_alloc t
					  WHERE		MasterRIInd='N'
					  GROUP BY	t.ProgrammeCode,
								t.EntityCode,
								t.YOA,
								t.MasterRIInd
	            ) m ON 
	                 (
	                 	m.ProgrammeCode = t.ProgrammeCode
		                and m.EntityCode = t.EntityCode
		                and m.YOA = t.YOA
		                and m.MaxAccountingPeriod = t.AccountingPeriod
		                and m.MasterRIInd = t.MasterRIInd
	                 )
			 WHERE		1=1
			 --abs(TotalAmount)>10    -- Check with PD 
						AND  t.MasterRIInd='N'

			UNION ALL

			SELECT 
						AccountingPeriod,
						t.EntityCode,
						t.ProgrammeCode,
						t.YOA,
						t.TrifocusCode,
						t.Amount,
						t.TotalAmount,
						t.Allocation,
						t.MasterRIInd
			FROM       #cte_alloc t
			JOIN
						(		
							SELECT		t.EntityCode,
										t.YOA,
										t.MasterRIInd,
										max(t.AccountingPeriod) MaxAccountingPeriod
							FROM 		#cte_alloc t
							WHERE		t.MasterRIInd = 'Y'
							GROUP BY   t.EntityCode,
										t.YOA,
										t.MasterRIInd
							
						) m 
						ON 
						(	
								m.EntityCode = t.EntityCode
								AND m.YOA = t.YOA
								AND m.MaxAccountingPeriod = t.AccountingPeriod
								AND m.MasterRIInd = t.MasterRIInd
						)
			WHERE  1=1
							--abs(TotalAmount)>10
				and t.MasterRIInd='Y'   


				DROP TABLE IF EXISTS  #cte_latestalloc_pass2 --select * from #cte_latestalloc

                SELECT 
								AccountingPeriod,
								t.EntityCode,
								t.ProgrammeCode,
								t.TrifocusCode,
								t.Amount Amount,
								t.TotalAmount TotalAmount,
								t.Allocation Allocation,
								t.MasterRIInd
				
				INTO			#cte_latestalloc_pass2    
				
				FROM			#cte_alloc_pass2 t
				JOIN
					(		
						SELECT		t.ProgrammeCode,
									t.EntityCode,
									t.MasterRIInd,
									max(t.AccountingPeriod) MaxAccountingPeriod
						FROM		#cte_alloc t
						WHERE		MasterRIInd='N'
						GROUP BY	t.ProgrammeCode,
									t.EntityCode,
									t.MasterRIInd
					) m ON 
						(
							m.ProgrammeCode = t.ProgrammeCode
							AND m.EntityCode = t.EntityCode
							AND m.MaxAccountingPeriod = t.AccountingPeriod
							AND m.MasterRIInd = t.MasterRIInd
						)
				WHERE 1=1
				--abs(TotalAmount)>10
				AND t.MasterRIInd='N'  --See if can exlcude this filter

				UNION ALL

				SELECT 
									AccountingPeriod,  
									t.EntityCode,
									t.ProgrammeCode,
									t.TrifocusCode,
									t.Amount Amount,
									t.TotalAmount TotalAmount,
									t.Allocation Allocation,
									t.MasterRIInd
				FROM				#cte_alloc_pass2 t
				JOIN
					(		
						SELECT		t.EntityCode,
									t.MasterRIInd,
									MAX(t.AccountingPeriod) MaxAccountingPeriod
						FROM		#cte_alloc t
						WHERE		t.MasterRIInd = 'Y'
						GROUP BY	t.EntityCode,
									t.MasterRIInd
						
					) m ON 
					(	
						m.EntityCode = t.EntityCode
						and m.MaxAccountingPeriod = t.AccountingPeriod
						and m.MasterRIInd = t.MasterRIInd
					)
				WHERE 1=1
				--abs(TotalAmount)>10
				and t.MasterRIInd = 'Y'  


----------------------------
------Change Alloc - End----
----------------------------




    DROP TABLE IF EXISTS #TempInboundTransactionInit1;

				SELECT t.Account					
					,t.DateOfFact
					,t.BusinessKey
					,t.PolicyNumber
					,t.InceptionDate
					,t.ExpiryDate
					,ISNULL(v.TrifocusCode, 'UNKNOWN') TrifocusCode			
					,en.ConformedEntityMapping Entity
					,t.YOA
					,t.SettlementCCY 
					,t.OriginalCCY
					,(CONVERT(NUMERIC(19, 4), t.[Value] * isnull(v.Allocation,1))) AllocatedValue	
					,CONVERT(INT,v.[AccountingPeriod]) [FK_Allocation]		
					--,RIPolicyType
					,ISNULL(CASE WHEN t.ProgrammeCode = 'Master RI'
									                                 THEN coalesce(v.ProgrammeCode, t.ProgrammeCode)
																	 ELSE t.ProgrammeCode END, 'UNKNOWN') ProgrammeCode
					,case when t.ProgrammeCode='Master RI' then 'Y' else 'N' end IsMasterRI									
				INTO 
					#TempInboundTransactionInit1 
				from #ReInsuUltimate t
				LEFT JOIN			FinanceLanding.mds.ConformedEntityMapping en 
								ON (en.Entity = cast(t.Entity as varchar))
				LEFT JOIN			#cte_latestalloc v
								ON 
									(
										v.EntityCode =  en.ConformedEntityMapping
										and v.ProgrammeCode = case when v.MasterRIInd = 'Y' then v.ProgrammeCode 
																   else t.ProgrammeCode
															  end
										and v.YOA = t.YOA
										and v.AccountingPeriod >= cast(left(convert(varchar, case when t.DateOfFact < '2018-12-31' then '2018-12-31' else t.DateOfFact end, 112), 6) as int)
										and (	(v.MasterRIInd = 'N' and t.ProgrammeCode <> 'Master RI') 
												 or 
												(v.MasterRIInd = 'Y' and t.ProgrammeCode = 'Master RI')
											 )

									)


				DROP TABLE IF EXISTS #TempInboundTransactionInIt2
		
SELECT 
					 t.Account					
					,t.DateOfFact
					,t.BusinessKey
					,t.PolicyNumber
					,t.InceptionDate
					,t.ExpiryDate
					,CASE WHEN t.TrifocusCode = 'UNKNOWN' 
										THEN isnull(v2.TrifocusCode, isnull(v3.TrifocusCode, 'UNKNOWN')) 
									ELSE t.TrifocusCode 
					 END TrifocusCode	
					,t.Entity
					,t.YOA
					,t.SettlementCCY
					,t.OriginalCCY
					,t.[AllocatedValue] * isnull(v2.Allocation, isnull(v3.Allocation, 1)) AllocatedValue
					,case when t.TrifocusCode = 'UNKNOWN' then
                                        CONVERT(INT,isnull(v2.[AccountingPeriod], v3.[AccountingPeriod]))
                                     else t.FK_Allocation
                     end [FK_Allocation]
					--,RIPolicyType
					,ISNULL(CASE WHEN t.ProgrammeCode = 'Master RI'	
												THEN coalesce(v3.ProgrammeCode, t.ProgrammeCode) 
											ELSE t.ProgrammeCode 
											END, 'UNKNOWN'
										) ProgrammeCode	
					,case when t.ProgrammeCode='Master RI' then 'Y' else 'N' end IsMasterRI
			into #TempInboundTransactionInIt2
			FROM			#TempInboundTransactionInIt1 t 
				LEFT JOIN		#cte_latestalloc_pass2 v2 -- select * from #cte_latestalloc_pass2
								ON 
								(
									t.TrifocusCode = 'UNKNOWN'
									and t.ProgrammeCode <> 'Master RI'
									and v2.MasterRIInd = 'N'
									and v2.EntityCode =  t.Entity
									and v2.ProgrammeCode = case when t.ProgrammeCode = 'Property Cat XL' then 'Property Risk Excess' 
																		 else t.ProgrammeCode 
														   end 
									and v2.AccountingPeriod >= cast(left(convert(varchar, t.DateOfFact, 112), 6) as int)
								)

				LEFT JOIN		#cte_latestalloc_pass2 v3 
								ON 
								(
									t.TrifocusCode = 'UNKNOWN'
									and t.ProgrammeCode = 'Master RI'
									and v3.MasterRIInd = 'Y'
									and v3.EntityCode =  t.Entity
									and v3.AccountingPeriod >= cast(left(convert(varchar, t.DateOfFact, 112), 6) as int)
								)

				DROP TABLE IF EXISTS #TempInboundTransactionInIt3

		
SELECT 
					 t.Account					
					,t.DateOfFact
					--,case when t.IsMasterRI='Y' then t.BusinessKey else t.BusinessKey +'|'+ISNULL(t.ProgrammeCode,'-') end as BK2
					,t.BusinessKey+'|'+isnull(ptsm.TrifocusCode, t.TrifocusCode)+'|'+ISNULL(t.ProgrammeCode,'-') as BusinessKey
					,t.PolicyNumber
					,t.InceptionDate
					,t.ExpiryDate
					,isnull(ptsm.TrifocusCode, t.TrifocusCode) TrifocusCode	
					,t.Entity
					,t.YOA
					,t.SettlementCCY
					,t.OriginalCCY
					,t.AllocatedValue [Value]
					,t.AllocatedValue [ValueOrig]
					,t.FK_Allocation
					--,t.RIPolicyType
					,t.ProgrammeCode		
			into #TempInboundTransactionInIt3
			FROM			#TempInboundTransactionInIt2 t 
			LEFT JOIN		mds.ProgrammeTrifocusStaticMapping ptsm on ptsm.Programme = t.ProgrammeCode


DROP TABLE IF EXISTS #TempInboundTransaction;

    /* Insert the new records from Ultimate RI Rebate Database sources in the temp table */
	SELECT 
		DateOfFact,
		Account,
		BusinessKey,
		PolicyNumber ,
		InceptionDate,
		ExpiryDate ,
		TrifocusCode ,
		Entity,
		YOA,
		SettlementCCY,
		--RIPolicyType,
		ProgrammeCode,
		--fk_AccountingPeriod,
		[Value] = sum([Value]),
		RowHash = dbo.fn_RowHashForTransactions
		(
			'T'							-- <@RowHashType, char(1),>
			,@Scenario					--,<@Scenario, nvarchar(2000),>
			,[Account]					--,<@Account, nvarchar(2000),>
			,@v_Dataset					--,<@DataSet, nvarchar(2000),>
			,[BusinessKey]				--,<@BusinessKey, nvarchar(2000),>
			,[PolicyNumber]				--,<@PolicyNumber, nvarchar(2000),>
			,[InceptionDate]			--,<@InceptionDate, date,>
			,[ExpiryDate]				--,<@ExpiryDate, date,>
			,@DefaultDate				--,<@BindDate, date,>
			,@DefaultDate				--,<@DueDate, date,>
			,[TrifocusCode]				--,<@TrifocusCode, nvarchar(2000),>
			,[Entity]					--,<@Entity, nvarchar(2000),>
			,[YOA]						--,<@YOA, nvarchar(2000),>
			,@TypeOfBusiness			--,<@TypeOfBusiness, nvarchar(2000),>
			,@StatsCode					--,<@StatsCode, nvarchar(2000),>
			,[SettlementCCY]			--,<@SettlementCCY, nvarchar(2000),>
			,[SettlementCCY]			--,<@OriginalCCY, nvarchar(2000),>
			,@IsToDate					--,<@IsToDate, nvarchar(2000),>
			,@Basis						--,<@Basis, nvarchar(2000),>
			,@Location					--,<@Location, nvarchar(2000),>
			,@BusinessProcessCode		--,<@BusinessProcessCode, nvarchar(2000),>
			,null						--,<@BoundDate, date,>
			,CONCAT
			(
				 --case when RIPolicyType is null then '' else (RIPolicyType + '§~§') end
				 '',
				case when ProgrammeCode is null then '' else (ProgrammeCode + '§~§') end
			)
		)
		,[RowHash_Transaction_ReInsurance_Extensions] = dbo.fn_RowHashForTransactions
		(
			'E' /* @RowHashType */
			,@Scenario,Account,@v_Dataset,BusinessKey,PolicyNumber,InceptionDate,ExpiryDate,@DefaultDate,@DefaultDate,TrifocusCode,Entity,YOA,@TypeOfBusiness,@StatsCode,SettlementCCY,SettlementCCY,@IsToDate,@Basis,@Location
			,null /* @BusinessProcessCode */
			,null /* @BoundDate */
			-- extended columns
			,CONCAT
			(
				 '',
				 case when ProgrammeCode is null then '' else (ProgrammeCode + '§~§') end
				--,case when t.RIPolicyType is null then '' else (t.RIPolicyType + '§~§') end
			)
		)
		INTO #TempInboundTransaction
FROM #TempInboundTransactionInit3
	
		-- debug code
		--and src1.BusinessKey = 'P-RP-P-TTY|CLASHBUDGET|2019|USD|2623|697'
	GROUP BY 
        DateOfFact,
		Account,
		BusinessKey,
		PolicyNumber ,
		InceptionDate  ,
		ExpiryDate  ,
		TrifocusCode ,
		Entity,
		YOA,
		SettlementCCY,
		--AccountingPeriod,
		--RIPolicyType,
		ProgrammeCode


	SELECT   @v_AffectedRows			= @@ROWCOUNT;
	print convert(varchar,@v_AffectedRows) + ' records in #TempInboundTransaction for ' + convert(varchar,@p_AccountingPeriod)
		
	
	
		---drop table #TempInboundTransaction
			------/* Delete the current lines from Inbound ... */

				DELETE 				
				FROM    [FinanceDataContract].[Inbound].[Transaction]					
				WHERE   [DataSet] = @v_DataSet

				DELETE [FinanceDataContract].[Inbound].[Transaction_Reinsurance_Extensions_Bridge]
				WHERE [ContractType] = @ContractType

				DELETE [FinanceDataContract].[Inbound].[Transaction_Reinsurance_Extensions]
				WHERE [ContractType] = @ContractType
			
		if not exists(select top 1 1 from #TempInboundTransaction)
	begin

		print 'No data in #TempInboundTransaction, exiting as there is nothing to do.'

		-- LOG THE RESULT WITH SUCCESS
		SELECT @v_ActivityDateTime			= GETUTCDATE();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStop
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

		return

	end

			--IF @Trancount = 0 
			BEGIN TRAN;

				-- select * from [dbo].[Batch]
				INSERT INTO [dbo].[Batch]
					([CreateDate],[DataSet],[LatestBusinesKey]) 
				VALUES  
					(GETDATE(),@v_DataSet, NULL);


				SELECT @v_BatchId = SCOPE_IDENTITY();

				INSERT INTO [dbo].[Batch]
					([CreateDate],[DataSet],[LatestBusinesKey]) 
				VALUES  
					(GETDATE(),'ReinsuranceExtensions', NULL);
				

				SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();
				

			/* We insert the rows from temp table in the system */

			
				INSERT INTO  [FinanceDataContract].[Inbound].Transaction_Reinsurance_Extensions_Bridge
				(
					 [RowHash_Transaction]
					,[RowHash_Transaction_Reinsurance_Extensions]
					,[ContractType]
					,[FK_Batch]
				)
				SELECT DISTINCT
					 [RowHash]
					,[RowHash_Transaction_Reinsurance_Extensions]
					,@ContractType
					,@v_BatchId_Extensions
				FROM 
					#TempInboundTransaction
			
			
				INSERT INTO  [FinanceDataContract].[Inbound].Transaction_Reinsurance_Extensions
				(
					[RowHash_Transaction_Reinsurance_Extensions]
					--,[RIPolicyType]
					,[ProgrammeCode]
					,[IsLargeLoss]
					,[ContractType]
					,[FK_Batch]
				)
				SELECT DISTINCT
					 [RowHash_Transaction_Reinsurance_Extensions]
					--,[RIPolicyType]
					,[ProgrammeCode]
					,0
					,@ContractType
					,@v_BatchId_Extensions
				FROM 
					#TempInboundTransaction
	
	
			INSERT INTO [FinanceDataContract].[Inbound].[Transaction]
			(
				 [Scenario]
				,[Basis]
				,[Account]
				,[DataSet]
				,[DateOfFact]
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]
				,[DueDate]
				,[TrifocusCode]
				,[Entity]
				,[Location]
				,[YOA]
				,[TypeOfBusiness]
				,[SettlementCCY]
				,[OriginalCCY]
				,[IsToDate]
				,[Value]
				,[ValueOrig]
				,[RowHash]
				,[BusinessProcessCode]
				,[AuditSourceBatchID]
				,[AuditGenerateDateTime]
				,[StatsCode]
				,[FK_Batch]
				--,[DeltaType]
			)		
			SELECT  
				 [Scenario]					= @Scenario
				,[Basis]					= @Basis
				,[Account]
				,[DataSet]					= @v_Dataset
				,[DateOfFact]				= @DateOfFact
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]					= @DefaultDate
				,[DueDate]					= @DefaultDate
				,[TrifocusCode]
				,[Entity]
				,[Location]					= @Location
				,[YOA]
				,[TypeOfBusiness]			= @TypeOfBusiness
				,[SettlementCCY]
				,[OriginalCCY]				= [SettlementCCY]
				,[IsToDate]					= @IsToDate
				,[Value]
				,[ValueOrig]				= [Value]
				,[RowHash] 
				,[BusinessProcessCode]		= @BusinessProcessCode
				,[AuditSourceBatchID]		= CAST(@v_BatchId AS VARCHAR (50))                                                 
				,[AuditGenerateDateTime]	= GETUTCDATE()
				,[StatsCode]				= @StatsCode
				,[FK_Batch]					= @v_BatchId
				--,[DeltaType]				
			FROM    
				#TempInboundTransaction


				--DROP TABLE #transactions_final_agg_cs
			SELECT   @v_AffectedRows			= @@ROWCOUNT;

	
			/* Add the batch to the queue */
				INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,RunDescription
								,[DataSet]
								,OriginalName
								,AuditSourceBatchID
								,AsAt
								)
				VALUES
								( @v_BatchId
								 ,'InBound'
								 ,NULL
								 ,@v_DataSet
								 ,NULL
								 ,NULL
								 ,@p_AccountingPeriod
								)								
				,
								( @v_BatchId_Extensions
								 ,'InBound'
								 ,'ReinsuranceExtensions, the additional attributes to extend functionality of the transaction table.'
								 ,'ReinsuranceExtensions'
								 ,NULL
								 ,NULL
								 ,@p_AccountingPeriod
								);
   	-- LOG THE RESULT WITH SUCCESS
			SELECT @v_ActivityDateTime			= GETUTCDATE();

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStop
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;
					
			IF @Trancount = 0 
				COMMIT;
				
		END TRY

		BEGIN CATCH
	
			-- CANCEL TRAN
			IF @Trancount = 0 AND @@TRANCOUNT <> 0 
				ROLLBACK;
			        
			-- LOG THE RESULT WITH ERROR

			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

		    THROW;

		END CATCH;

					
END