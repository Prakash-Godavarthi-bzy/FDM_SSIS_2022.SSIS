﻿/*

	1. Invoke the following procedure to generate your MERGE statements:
		Example: EXEC sp_generate_merge @schema = 'dbo', @table_name ='Table'

	2. Paste it to a new file in the StaticTables folder.

	3. Include it in the list below. Order of the tables in the list depends on your table relationships.
		Begin with the tables at the end of your relationship chain.

*/

	--:r .\StaticTables\StaticTableExample.sql
	--:r .\ServerLevelConfiguration\Credential_PXY_FDM.sql
	--:r .\ServerLevelConfiguration\Credential_FDMDevelopers.sql
	  :r .\ServerLevelConfiguration\EnvironmentVariables.sql
	--:r .\ServerLevelConfiguration\Credential_SSASService.sql
	

	--Static data
	:r .\StaticTables\MDS.AccountNames.sql
	:r .\StaticTables\MDS.Currency.sql
	:r .\StaticTables\MDS.RITypeMapping.sql
	:r .\StaticTables\MDS.FACPrgTrifocusMapping.sql
	:r .\StaticTables\MDS.Catcode_Eventdate.sql
	:r .\StaticTables\MDS.Dataset.sql
	:r .\StaticTables\MDS.InterCompany_Rules.sql
	:r .\StaticTables\MDS.DummyProgrammes_CededRe.sql
	:r .\StaticTables\MDS.ConformedEntityMapping.sql
	:r .\StaticTables\MDS.ConformedTrifocusMapping.sql
	:r .\StaticTables\MDS.ProgrammeTrifocusStaticMapping.sql
	:r .\StaticTables\MDS.ClashIBNR2022Prior.sql
	:r .\StaticTables\MDS.CRClosedYOASpecial.sql
	:r .\StaticTables\MDS.DQFix6107CreatedRI.sql
	:r .\StaticTables\MDS.InValidRDrecords.sql
	:r .\StaticTables\MDS.TreatyShareGenerationRules.sql
	:r .\StaticTables\MDS.ConformedProgrammeMapping.sql
	:r .\StaticTables\ADMRI.ClashPeriods.sql
	:r .\StaticTables\ADMRI.FinalReservingData.sql
	:r .\StaticTables\ADMRI.IncClaimsPeriods.sql
	:r .\StaticTables\ADMRI.LargeLossesPeriods.sql
	:r .\StaticTables\ADMRI.Quarters_IncClaims.sql
	:r .\StaticTables\ADMRI.Quarters_RIPremium.sql
	:r .\StaticTables\ADMRI.Quarters_YOAPremium.sql
	:r .\StaticTables\ADMRI.RCPACBalances.sql
	:r .\StaticTables\ADMRI.RIPremiumPeriods.sql
	:r .\StaticTables\ADMRI.YOAPremiumPeriods.sql


	--Day1Load
	--:r .\Day1Load\ADM_Day1Load.sql