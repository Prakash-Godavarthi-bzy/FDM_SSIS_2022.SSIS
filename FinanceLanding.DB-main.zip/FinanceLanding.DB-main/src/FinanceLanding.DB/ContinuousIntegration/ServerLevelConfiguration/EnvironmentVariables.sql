﻿/*		
version	   Modified by							Date								Description
---------------------------------------------------------------------------------------------------------------------------------------
 1.0     Lakshman.Akasapu@Beazley.com		30/05/2024				created new Environment Reference Variables IFRS17_MailFrom and IFRS17_MailTo 
																	regarding the ticket :https://beazley.atlassian.net/jira/software/c/projects/I1B/boards/735?search=5553&selectedIssue=I1B-5553&sprints=5993

---------------------------------------------------------------------------------------------------------------------------------------
*/

DECLARE @CurrentEnvironment						NVARCHAR(2000) = '$(CurrentEnvironment)'

DECLARE @ServerName_TechnicalHub				NVARCHAR(2000) = '$(TargetInstanceName)'
DECLARE @ServerName_FinanceDataContract			NVARCHAR(2000) = '$(TargetInstanceName)'
DECLARE @ServerName_FinanceLanding				NVARCHAR(2000) = '$(TargetInstanceName)'
DECLARE @ServerName_Orchestram					NVARCHAR(2000) = '$(TargetInstanceName)'
DECLARE @ServerName_SchedulingHub				NVARCHAR(2000) = '$(TargetInstanceName)'
DECLARE @ServerName_ExternalFeedLocation		NVARCHAR(2000) = '$(Parameter_ExternalFeedLocation)'
DECLARE @ServerName_FinanceDataMart				NVARCHAR(2000) = '$(Parameter_FinanceDataMart)'
--DECLARE @URL_FDMSharepoint						NVARCHAR(2000) = '$(Parameter_FDMSharepoint)'
DECLARE @ServerName_SMTP						NVARCHAR(2000) = '$(Parameter_SMTP)'
DECLARE @EurobaseLinkedServer					NVARCHAR(2000) = '$(Parameter_EurobaseLinkedServer)'
DECLARE @IFRS17_ServerName_Dst                  NVARCHAR(2000) = '$(TargetInstanceName)'
DECLARE @IFRS17_ServerName_Log                  NVARCHAR(2000) = '$(TargetInstanceName)'
DECLARE @ServerName_EBCDS						NVARCHAR(2000) = '$(Parameter_EBCDS)'

DECLARE @ServerName_BeazleyReinsuranceMI		NVARCHAR(2000) = '$(ServerName_BeazleyReinsuranceMI)' --'UKPRDB050\UKBI03'

-- parameters originally added for IFRS17 
DECLARE @ServerName_ActuarialDataMart			NVARCHAR(2000) = '$(Parameter_ServerName_ActuarialDataMart)'
DECLARE @ServerName_Agresso						NVARCHAR(2000) = '$(Parameter_ServerName_Agresso)'
DECLARE @ServerName_BI_ClaimCentre				NVARCHAR(2000) = '$(Parameter_ServerName_BI_ClaimCentre)'
DECLARE @ServerName_EurobaseCentralDataStore	NVARCHAR(2000) = '$(Parameter_ServerName_EurobaseCentralDataStore)'
DECLARE @ServerName_MasterDataServices			NVARCHAR(2000) = '$(Parameter_ServerName_MasterDataServices)'
DECLARE @IFRS17_EiopaRootDirectory              NVARCHAR(2000) = '$(Parameter_IFRS17_EiopaRootDirectory)'
DECLARE @IFRS17_NatCatEarningsRootDirectory		NVARCHAR(2000) = '$(Parameter_IFRS17_NatCatEarningsRootDirectory)'
DECLARE @IFRS17_NatCatEarningsEmailAddress		NVARCHAR(2000) = '$(Parameter_IFRS17_NatCatEarningsEmailAddress)'
--DECLARE @IFRS17_ServerName_BI_ODS				NVARCHAR(2000) = '$(Parameter_IFRS17_ServerName_BI_ODS)'
DECLARE @IFRS17_ServerName_Pyramid		NVARCHAR(2000) = '$(Parameter_ServerName_Pyramid)'

DECLARE @IFRS17_ADMDFMsPaymentPatternMappingRootDirectory		NVARCHAR(2000) = '$(Parameter_IFRS17_ADMDFMsPaymentPatternMappingRootDirectory)'
DECLARE @IFRS17_ADMResDatPPMapRootDir		NVARCHAR(2000) = '$(Parameter_IFRS17_ADMResDatPPMapRootDir)'
DECLARE @IFRS17_ADMS2TPOutputPPMapRootDir		NVARCHAR(2000) = '$(Parameter_IFRS17_ADMS2TPOutputPPMapRootDir)'

DECLARE @IFRS17_MailFrom		NVARCHAR(2000) = '$(Parameter_IFRS17_MailFrom)'
DECLARE @IFRS17_MailTo		    NVARCHAR(2000) = '$(Parameter_IFRS17_MailTo)'

--'IFRS17_EiopaRootDirectory'

DECLARE @ReferenceID INT = 0
WHILE EXISTS	(SELECT	* FROM	ssisdb.catalog.environment_references r WHERE	r.environment_name = 'FinanceLandingEnvironment' AND r.reference_id > @ReferenceID)
BEGIN
	SELECT	@ReferenceID = MIN(reference_id)
	FROM	ssisdb.catalog.environment_references r
	WHERE	r.environment_name = 'FinanceLandingEnvironment'
		AND reference_id > @ReferenceID
	
	EXEC SSISDB.catalog.delete_environment_reference @ReferenceID
END

IF EXISTS (SELECT * FROM SSISDB.catalog.environments WHERE Name = 'FinanceLandingEnvironment')		
	EXEC [SSISDB].[catalog].[delete_environment] @folder_name = 'FinanceLanding', @Environment_Name = 'FinanceLandingEnvironment'

EXEC [SSISDB].[catalog].[create_environment] @folder_name = 'FinanceLanding', @Environment_Name = 'FinanceLandingEnvironment'

SET @ReferenceID = NULL
EXEC [SSISDB].[catalog].[create_environment_reference] @folder_name = N'FinanceLanding', @project_name = N'FinanceLanding.SSIS', @environment_name = N'FinanceLandingEnvironment', @Reference_type = 'R', @reference_id = @ReferenceID


-- environment variables added to enable the IFRS17 project to use the environment
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'CurrentEnvironment'		,@value=@CurrentEnvironment,			@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'

EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'ServerName_MasterDataServices'		,@value=@ServerName_MasterDataServices,			@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'ServerName_EurobaseCentralDataStore'	,@value=@ServerName_EurobaseCentralDataStore,	@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'ServerName_BI_ClaimCentre'			,@value=@ServerName_BI_ClaimCentre,				@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'ServerName_Agresso'					,@value=@ServerName_Agresso,					@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'ServerName_ActuarialDataMart'		,@value=@ServerName_ActuarialDataMart,			@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'IFRS17_EiopaRootDirectory'			,@value=@IFRS17_EiopaRootDirectory,				@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'IFRS17_NatCatEarningsRootDirectory'	,@value=@IFRS17_NatCatEarningsRootDirectory,	@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'IFRS17_NatCatEarningsEmailAddress'	,@value=@IFRS17_NatCatEarningsEmailAddress,		@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'

EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'IFRS17_ADMDFMsPaymentPatternMappingRootDirectory',@value=@IFRS17_ADMDFMsPaymentPatternMappingRootDirectory,@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'IFRS17_ADMResDatPPMapRootDir',@value=@IFRS17_ADMResDatPPMapRootDir,@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'IFRS17_ADMS2TPOutputPPMapRootDir',@value=@IFRS17_ADMS2TPOutputPPMapRootDir,@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'ServerName_EBCDS',@value=@ServerName_EBCDS,@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'ServerName_Pyramid',@value=@IFRS17_ServerName_Pyramid,@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'


EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'CurrentEnvironment',					@parameter_value=N'CurrentEnvironment'		,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'IFRS17_ServerName_MDS',					@parameter_value=N'ServerName_MasterDataServices'		,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'IFRS17_ServerName_Eurobase',			@parameter_value=N'ServerName_EurobaseCentralDataStore'	,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'IFRS17_ServerName_BICC',				@parameter_value=N'ServerName_BI_ClaimCentre'			,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'IFRS17_ServerName_Agresso',				@parameter_value=N'ServerName_Agresso'					,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'IFRS17_ServerName_ADM',					@parameter_value=N'ServerName_ActuarialDataMart'		,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'IFRS17_EiopaRootDirectory',				@parameter_value=N'IFRS17_EiopaRootDirectory'			,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'IFRS17_NatCatEarningsRootDirectory',	@parameter_value=N'IFRS17_NatCatEarningsRootDirectory'	,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'IFRS17_NatCatEarningsEmailAddress',		@parameter_value=N'IFRS17_NatCatEarningsEmailAddress'	,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'IFRS17_ADMDFMsPaymentPatternMappingRootDirectory',				@parameter_value=N'IFRS17_ADMDFMsPaymentPatternMappingRootDirectory'			,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'IFRS17_ADMResDatPPMapRootDir',				@parameter_value=N'IFRS17_ADMResDatPPMapRootDir'			,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'IFRS17_ADMS2TPOutputPPMapRootDir',			@parameter_value=N'IFRS17_ADMS2TPOutputPPMapRootDir'			,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_EBCDS',							@parameter_value=N'ServerName_EBCDS'			,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'IFRS17_ServerName_Pyramid',							@parameter_value=N'ServerName_Pyramid'			,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R


EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'ServerName_EurobaseLinkedServer',@value=@EurobaseLinkedServer,			@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'ServerName_FinanceDataContract',	@value=@ServerName_FinanceDataContract,	@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'ServerName_FinanceDataMart',		@value=@ServerName_FinanceDataMart,		@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'ServerName_FinanceLanding',		@value=@ServerName_FinanceLanding,		@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'ServerName_Orchestram',			@value=@ServerName_Orchestram,			@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'ServerName_SMTP',				@value=@ServerName_SMTP,				@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'ServerName_TechnicalHub',		@value=@ServerName_TechnicalHub,		@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
--EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'URL_FDMSharepoint',				@value=@URL_FDMSharepoint,				@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'IFRS17_ServerName_Dst',			@value=@IFRS17_ServerName_Dst,			@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'IFRS17_ServerName_Log',			@value=@IFRS17_ServerName_Log,			@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'ServerName_SchedulingHub',		@value=@ServerName_SchedulingHub,		@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'ExternalFeedLocation',			@value=@ServerName_ExternalFeedLocation,@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'ServerName_BeazleyReinsuranceMI',@value=@ServerName_BeazleyReinsuranceMI,@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'


EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_FinanceDataContract',	@parameter_value=N'ServerName_FinanceDataContract'	,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_FinanceLanding',			@parameter_value=N'ServerName_FinanceLanding'		,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_Orchestram',				@parameter_value=N'ServerName_Orchestram'			,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_SMTP',					@parameter_value=N'ServerName_SMTP'					,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_FinanceDataMart',		@parameter_value=N'ServerName_FinanceDataMart'		,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_EurobaseLinkedServer',	@parameter_value=N'ServerName_EurobaseLinkedServer'	,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
--EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'FDMSharepoint',						@parameter_value=N'URL_FDMSharepoint'				,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_TechnicalHub',			@parameter_value=N'ServerName_TechnicalHub'			,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'IFRS17_ServerName_Dst',			    @parameter_value=N'IFRS17_ServerName_Dst'			,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'IFRS17_ServerName_Log',			    @parameter_value=N'IFRS17_ServerName_Log'			,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
--EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_SchedulingHub',			@parameter_value=N'ServerName_SchedulingHub'			,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ExternalFeedLocation',			    @parameter_value=N'ExternalFeedLocation'			,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_BeazleyReinsuranceMI',	@parameter_value=N'ServerName_BeazleyReinsuranceMI'	,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R

EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'IFRS17_MailFrom',@value=@IFRS17_MailFrom,@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceLandingEnvironment', @variable_name=N'IFRS17_MailTo',@value=@IFRS17_MailTo,@data_type=N'String', @sensitive=False, @folder_name=N'FinanceLanding'

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'IFRS17_MailFrom',	@parameter_value=N'IFRS17_MailFrom'	,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'IFRS17_MailTo',	@parameter_value=N'IFRS17_MailTo'	,@object_name=N'FinanceLanding.SSIS', @folder_name=N'FinanceLanding', @project_name=N'FinanceLanding.SSIS', @value_type=R
