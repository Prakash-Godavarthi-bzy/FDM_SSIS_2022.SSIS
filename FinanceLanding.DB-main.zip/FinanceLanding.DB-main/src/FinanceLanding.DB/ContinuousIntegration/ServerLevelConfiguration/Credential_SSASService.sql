﻿BEGIN TRY
	IF NOT EXISTS (SELECT * FROM msdb.sys.syslogins WHERE name = '$(SSASServiceAccount)')
		CREATE LOGIN [$(SSASServiceAccount)] FROM WINDOWS WITH DEFAULT_DATABASE=[master]

	IF EXISTS (SELECT * FROM sys.sysusers s WHERE name = '$(SSASServiceAccount)')
		DROP USER [$(SSASServiceAccount)]

	CREATE USER [$(SSASServiceAccount)] FOR LOGIN [$(SSASServiceAccount)] WITH DEFAULT_SCHEMA=[dbo]

	ALTER ROLE db_datareader ADD MEMBER [$(SSASServiceAccount)]
	ALTER ROLE db_datawriter ADD MEMBER [$(SSASServiceAccount)]
END TRY
BEGIN CATCH
	THROW;
END CATCH
