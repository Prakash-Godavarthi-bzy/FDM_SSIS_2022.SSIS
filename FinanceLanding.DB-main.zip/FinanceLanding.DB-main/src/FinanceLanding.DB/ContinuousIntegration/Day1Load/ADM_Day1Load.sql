﻿USE FinanceLanding

--DECLARE @v_Day1Load  BIT = 1;
--IF @v_Day1Load =1

IF 1=1 --NOT EXISTS( SELECT 1 FROM FinanceDataContract.Outbound.[Transaction] WHERE DataSet IN ('SIITP','ReservingData')) -- swap conditions to make it repeatable or not pending current requirement.

BEGIN
   --define period for processing
    DECLARE  @v_AsAt_Start                 INT            =  201901
    DECLARE  @v_AsAt_End                   INT            =  NULL


    DECLARE @v_ErrorMessage                 VARCHAR(4000) =''
	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'ADMDay1DataLoad';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ParentActivityLogId          BIGINT          = NULL;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= NULL;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
   
    DECLARE @v_ReferenceId                  INT = (SELECT reference_id FROM SSISDB.catalog.environment_references WHERE environment_name = 'FinanceLandingEnvironment')
    DECLARE @v_ExecutionId                  BIGINT
   
    DECLARE @i                              INT      = 1
    DECLARE @v_NoAsAt                       INT      = 0
    DECLARE @v_AsAt                         INT
	--DECLARE @v_MaxDateOfFact            DATE
	--DECLARE @v_MinDateOfFact            DATE

    BEGIN TRY

	    SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	    FROM Orchestram.Log.ActivityStatus	
	    WHERE ActivityStatus = 'STARTED';

	    SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	    FROM Orchestram.Log.ActivityStatus	
	    WHERE ActivityStatus = 'SUCCEEDED';

	    SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	    FROM Orchestram.Log.ActivityStatus	
	    WHERE ActivityStatus = 'ERRORED';


	   /* Log the start*/
	    SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										   FROM Orchestram.Log.ActivityType	
										   WHERE ActivityType =  'Manual process' )																
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'ADM - Day1 Data Load'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= NULL
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	    EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @v_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	    SELECT @v_ActivityLogTag = @v_ActivityLogIdIn,
		       @v_ParentActivityLogId = @v_ActivityLogIdIn

        -- execute SSIS package
		 SELECT @v_ActivityMessage			= 'ADM SSIS package execution START'
		       ,@v_ActivityDateTime			= GETUTCDATE();
		 EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @v_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

        EXEC	SSISDB.catalog.create_execution		@execution_id=@v_ExecutionId OUTPUT,
											        @package_name='IFRS17_ADMToLandingExtract.dtsx',
											        @folder_name='FinanceLanding',
											        @project_name='FinanceLanding.SSIS',
											        @use32bitruntime=0,
											        @reference_id=@v_ReferenceId

        EXEC	[SSISDB].[catalog].[start_execution] @v_ExecutionId


	    WHILE EXISTS	(
						 SELECT [Status] FROM [SSISDB].[catalog].[executions]
						 WHERE execution_id = @v_ExecutionId
						 AND [status] in (1,2,5)
					     )
	         WAITFOR DELAY '00:00:05'; 

	    --check for errors
	    IF EXISTS (SELECT * FROM SSISDB.catalog.executions WHERE execution_id = @v_ExecutionId AND status IN (3, 4, 6, 8))
	   
	    BEGIN
		  
		   SELECT	@v_ErrorMessage  = 
		   CAST(	
				(
					SELECT	Message AS "@Message"
					FROM	SSISDB.internal.operation_messages
					WHERE	Message_type = 120
						AND operation_id = @v_ExecutionId
					FOR		XML PATH ('Messages')
				) AS VARCHAR(MAX)
			   )	

		   RAISERROR (@v_ErrorMessage, 16, 0)

		 END

		 SELECT @v_ActivityMessage			 	= 'ADM SSIS package execution END'
		        ,@v_ActivityDateTime			= GETUTCDATE();
		 EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @v_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

        
		-- start loading the data from FinanceLanding to FinanceDataContract
		SELECT   @v_ActivityMessage			 	= 'ADM Load from FinanceLanding to financeDataContract START'
		        ,@v_ActivityDateTime			=  GETUTCDATE();
		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @v_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

		--temporary table to keep the AsAt values
	    IF OBJECT_ID('tempdb..#TempAllAsat') IS NOT NULL
	       DROP TABLE #TempAllAsat
	
         CREATE TABLE #TempAllAsat ( 
	                       PK_TempAllAsat  INT		IDENTITY(1,1)
						  ,AsAt            BIGINT
						  ,DateOfFact      DATE
                          )
	
        --get the list of AsAt values
       INSERT INTO #TempAllAsat(AsAt,DateOfFact)

       SELECT   AsAt
	          ,CAST(DateOfFact AS DATE)

       FROM
         (
           SELECT  AsAt = AsAt
		          ,DateOfFact = RIGHT(asat,2) + '-01-'+ LEFT(asat,4)

           FROM   ADM.Reserving_Data 

		   WHERE  AsAt IS NOT NULL AND AsAt>= @v_AsAt_Start AND AsAt <= ISNULL(@v_AsAt_End,999999)

           UNION 

           SELECT  AsAt = AsAt
		          ,DateOfFact = RIGHT(asat,2) + '-01-'+ LEFT(asat,4) 

           FROM   ADM.TpOutput 
		
		   WHERE  AsAt IS NOT NULL AND AsAt>= @v_AsAt_Start AND AsAt <= ISNULL(@v_AsAt_End,999999)
         ) a

	   WHERE ISDATE(DateOfFact) = 1

       ORDER BY AsAt

	  --select * from #TempAllAsat
	
	  SET @v_NoAsAt = SCOPE_IDENTITY();

	  --SELECT  @v_MaxDateOfFact = MAX(DateOfFact)
	  --       ,@v_MinDateOfFact = MIN(DateOfFact)

	  --FROM    #TempAllAsat
	   
	
	  DELETE 
	  FROM FinanceDataContract.Outbound.[Transaction] 
	  WHERE DataSet IN ('SIITP','ReservingData')
	
	  DELETE 
	  FROM FinanceDataContract.Inbound.[Transaction] 
	  WHERE DataSet IN ('SIITP','ReservingData')
	
	  --AND DateOfFact >= @v_MinDateOfFact 


	 WHILE (@i <= @v_NoAsAt)
      
	   BEGIN
	    
		   SELECT  @v_AsAt         = asat 

			FROM   #TempAllAsat
			  
			WHERE  PK_TempAllAsat = @i 

			EXEC [FinanceLanding].[ADM].[usp_LandingToInbound] @v_AsAt, @v_ParentActivityLogId, NULL

			EXEC [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow] 
	      
		    SET @i = @i + 1

	    END


		SELECT   @v_ActivityMessage			 	= 'ADM Load from FinanceLanding to financeDataContract END'
		        ,@v_ActivityDateTime			=  GETUTCDATE();
		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @v_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

		-- LOGIN THE RESULT WITH SUCCESS
		SELECT @v_ActivityDateTime			= GETUTCDATE();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @v_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStop
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;


	END TRY

	BEGIN CATCH
		        
			-- LOGIN THE RESULT WITH ERROR

			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @v_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

		    THROW;

	END CATCH;
END

