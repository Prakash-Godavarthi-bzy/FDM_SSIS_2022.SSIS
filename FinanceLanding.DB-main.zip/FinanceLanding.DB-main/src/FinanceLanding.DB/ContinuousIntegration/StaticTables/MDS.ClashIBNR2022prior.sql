MERGE into MDS.[ClashIBNR2022prior] as Target

Using (Values
(1, 'BBR Services (exc PE)', 2014, 'USD', 517.489500000000 , 201809, '737', 'Core', '201809|2014|737|USD|Core', 'XL', 'Systemic cover - Clash'),

(2, 'BBR Services (exc PE)', 2015, 'USD', 116.127000000000 , 201809, '737', 'Core', '201809|2015|737|USD|Core', 'XL', 'Systemic cover - Clash'),

(14, 'BUSA BBR Services MM', 2013, 'USD', 45.416250000000 , 201809, '732', 'Core', '201809|2013|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(15, 'BUSA BBR Services MM', 2014, 'USD', 411299.237250000000 , 201809, '732', 'Core', '201809|2014|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(16, 'BUSA BBR Services MM', 2015, 'USD', 1302.567750000000 , 201809, '732', 'Core', '201809|2015|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(17, 'BUSA BBR Services PE', 2014, 'USD', 921.954000000000 , 201809, '731', 'Core', '201809|2014|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(18, 'BUSA BBR Services PE', 2015, 'USD', 263.942250000000 , 201809, '731', 'Core', '201809|2015|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(19, 'BUSA EPL MM', 2007, 'USD', 11903.490999999922 , 201809, '681', 'Core', '201809|2007|681|USD|Core', 'XL', 'Systemic cover - Clash'),

(20, 'BUSA TMB PE US Info Sec', 2014, 'USD', 146.198250000000 , 201809, '723', 'Core', '201809|2014|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(21, 'BUSA TMB US E&O', 2014, 'USD', 700.565250000000 , 201809, '689', 'Core', '201809|2014|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(22, 'BUSA TMB US E&O', 2015, 'USD', 388.888500000000 , 201809, '689', 'Core', '201809|2015|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(23, 'BUSA TMB US Info Sec', 2014, 'USD', 1288158.811500000000 , 201809, '714', 'Core', '201809|2014|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(24, 'BUSA TMB US Info Sec', 2015, 'USD', 644.506500000000 , 201809, '714', 'Core', '201809|2015|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(25, 'D&O', 2003, 'USD', 28769.180999999866 , 201809, '6', 'Core', '201809|2003|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(26, 'D&O', 2007, 'USD', 42013.884000000544 , 201809, '6', 'Core', '201809|2007|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(27, 'D&O', 2008, 'USD', 251586.367000011730 , 201809, '6', 'Core', '201809|2008|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(28, 'D&O', 2009, 'USD', 2291.214000000065 , 201809, '6', 'Core', '201809|2009|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(29, 'D&O', 2010, 'USD', 623.954999999994 , 201809, '6', 'Core', '201809|2010|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(30, 'DIN US Lawyers', 2011, 'USD', 107.740000000000 , 201809, '7', 'Core', '201809|2011|7|USD|Core', 'XL', 'Systemic cover - Clash'),

(31, 'EPL', 2007, 'USD', 993.751000000004 , 201809, '8', 'Core', '201809|2007|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(32, 'EPL', 2008, 'USD', 993.840000000000 , 201809, '8', 'Core', '201809|2008|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(33, 'EPL', 2009, 'USD', 24.347500000000 , 201809, '8', 'Core', '201809|2009|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(34, 'Mid Market Lawyers', 2009, 'USD', 8027.857500000042 , 201809, '663', 'Core', '201809|2009|663|USD|Core', 'XL', 'Systemic cover - Clash'),

(35, 'PI-Ins Brokers exBLPT', 2008, 'USD', 1622.454000000000 , 201809, '14', 'Core', '201809|2008|14|USD|Core', 'XL', 'Systemic cover - Clash'),

(36, 'PI-Lawyers exBLPT', 2004, 'USD', 48595.673000000417 , 201809, '15', 'Core', '201809|2004|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(37, 'PI-Lawyers exBLPT', 2005, 'USD', 6.035000000000 , 201809, '15', 'Core', '201809|2005|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(38, 'PI-Lawyers exBLPT', 2006, 'USD', 725.447999999989 , 201809, '15', 'Core', '201809|2006|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(39, 'PI-Lawyers exBLPT', 2007, 'USD', 35167.701499999500 , 201809, '15', 'Core', '201809|2007|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(40, 'PI-Lawyers exBLPT', 2008, 'USD', 481304.988999999130 , 201809, '15', 'Core', '201809|2008|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(41, 'PI-Lawyers exBLPT', 2009, 'USD', 84358.228999999934 , 201809, '15', 'Core', '201809|2009|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(42, 'PI-Lawyers exBLPT', 2010, 'USD', 22506.924500000197 , 201809, '15', 'Core', '201809|2010|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(43, 'PI-Lawyers exBLPT', 2012, 'USD', 120.027500000000 , 201809, '15', 'Core', '201809|2012|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(44, 'PI-Other exBLPT', 2007, 'USD', 33.597000000000 , 201809, '18', 'Core', '201809|2007|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(45, 'PI-Other exBLPT', 2008, 'USD', 49.195000000000 , 201809, '18', 'Core', '201809|2008|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(46, 'PI-Other exBLPT', 2009, 'USD', 9689.206999999937 , 201809, '18', 'Core', '201809|2009|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(47, 'PI-Other exBLPT', 2010, 'USD', 10.434500000000 , 201809, '18', 'Core', '201809|2010|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(48, 'PI-Other exBLPT', 2011, 'USD', 1.017500000000 , 201809, '18', 'Core', '201809|2011|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(49, 'Specialty (PT)', 2006, 'USD', 129.088000000002 , 201809, '27', 'Core', '201809|2006|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(50, 'Specialty (PT)', 2007, 'USD', 936.540999999997 , 201809, '27', 'Core', '201809|2007|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(51, 'Specialty (PT)', 2008, 'USD', 1153053.826500000000 , 201809, '27', 'Core', '201809|2008|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(52, 'Specialty (PT)', 2009, 'USD', 111827.110000000220 , 201809, '27', 'Core', '201809|2009|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(53, 'Specialty (PT)', 2010, 'USD', 6404.548499999917 , 201809, '27', 'Core', '201809|2010|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(54, 'Specialty (PT)', 2011, 'USD', 55721.485500000184 , 201809, '27', 'Core', '201809|2011|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(55, 'TMB Large Risk Int', 2014, 'USD', 126.340500000000 , 201809, '712', 'Core', '201809|2014|712|USD|Core', 'XL', 'Systemic cover - Clash'),

(56, 'TMB UK Info Sec', 2014, 'USD', 232.872750000000 , 201809, '721', 'Core', '201809|2014|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(57, 'TMB UK Info Sec', 2015, 'USD', 1272884.233500000000 , 201809, '721', 'Core', '201809|2015|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(58, 'TMB UK Tech', 2006, 'USD', 54.536500000000 , 201809, '19', 'Core', '201809|2006|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(59, 'TMB UK Tech', 2007, 'USD', 157098.863999996330 , 201809, '19', 'Core', '201809|2007|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(60, 'TMB UK Tech', 2008, 'USD', 632148.695999999880 , 201809, '19', 'Core', '201809|2008|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(61, 'TMB UK Tech', 2010, 'USD', 63434.984999999986 , 201809, '19', 'Core', '201809|2010|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(62, 'TMB UK Tech', 2014, 'USD', 144.366750000000 , 201809, '19', 'Core', '201809|2014|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(63, 'UK', 2006, 'EUR', 9689.963999999920 , 201809, '24', 'Core', '201809|2006|24|EUR|Core', 'XL', 'Systemic cover - Clash'),

(64, 'UK', 2007, 'GBP', 337.794000000002 , 201809, '24', 'Core', '201809|2007|24|GBP|Core', 'XL', 'Systemic cover - Clash'),

(73, 'BUSA BBR Services MM', 2014, 'USD', 24.700499999686 , 201812, '732', 'Core', '201812|2014|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(74, 'BUSA EPL MM', 2007, 'USD', 10726.820500000147 , 201812, '681', 'Core', '201812|2007|681|USD|Core', 'XL', 'Systemic cover - Clash'),

(75, 'BUSA TMB US E&O', 2014, 'USD', 13.175250000000 , 201812, '689', 'Core', '201812|2014|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(76, 'BUSA TMB US Info Sec', 2014, 'USD', 78.251249999972 , 201812, '714', 'Core', '201812|2014|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(77, 'BUSA TMB US Info Sec', 2015, 'USD', 0.024750000000 , 201812, '714', 'Core', '201812|2015|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(78, 'D&O', 2003, 'USD', 25925.300000000279 , 201812, '6', 'Core', '201812|2003|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(79, 'D&O', 2007, 'USD', 37860.801000000443 , 201812, '6', 'Core', '201812|2007|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(80, 'D&O', 2008, 'USD', 118927.957500012590 , 201812, '6', 'Core', '201812|2008|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(81, 'D&O', 2009, 'USD', 2064.682499999995 , 201812, '6', 'Core', '201812|2009|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(82, 'D&O', 2010, 'USD', 561.831999999995 , 201812, '6', 'Core', '201812|2010|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(83, 'DIN US Lawyers', 2011, 'USD', 97.780000000000 , 201812, '7', 'Core', '201812|2011|7|USD|Core', 'XL', 'Systemic cover - Clash'),

(84, 'EPL', 2007, 'USD', 895.533500000005 , 201812, '8', 'Core', '201812|2007|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(85, 'EPL', 2009, 'USD', 21.938500000000 , 201812, '8', 'Core', '201812|2009|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(86, 'Mid Market Lawyers', 2009, 'USD', 7234.311999999918 , 201812, '663', 'Core', '201812|2009|663|USD|Core', 'XL', 'Systemic cover - Clash'),

(87, 'PI-Ins Brokers exBLPT', 2008, 'USD', 2549.142000000000 , 201812, '14', 'Core', '201812|2008|14|USD|Core', 'XL', 'Systemic cover - Clash'),

(88, 'PI-Lawyers exBLPT', 2004, 'USD', 43791.936999999918 , 201812, '15', 'Core', '201812|2004|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(89, 'PI-Lawyers exBLPT', 2005, 'USD', 5.427000000000 , 201812, '15', 'Core', '201812|2005|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(90, 'PI-Lawyers exBLPT', 2006, 'USD', 653.733999999997 , 201812, '15', 'Core', '201812|2006|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(91, 'PI-Lawyers exBLPT', 2007, 'USD', 31691.384499999229 , 201812, '15', 'Core', '201812|2007|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(92, 'PI-Lawyers exBLPT', 2010, 'USD', 20282.086000000127 , 201812, '15', 'Core', '201812|2010|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(93, 'PI-Lawyers exBLPT', 2012, 'USD', 108.163500000001 , 201812, '15', 'Core', '201812|2012|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(94, 'PI-Other exBLPT', 2007, 'USD', 30.263000000000 , 201812, '18', 'Core', '201812|2007|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(95, 'PI-Other exBLPT', 2008, 'USD', 29.029500000001 , 201812, '18', 'Core', '201812|2008|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(96, 'PI-Other exBLPT', 2009, 'USD', 8731.427999999840 , 201812, '18', 'Core', '201812|2009|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(97, 'PI-Other exBLPT', 2010, 'USD', 9.459000000000 , 201812, '18', 'Core', '201812|2010|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(98, 'PI-Other exBLPT', 2011, 'USD', 0.917500000000 , 201812, '18', 'Core', '201812|2011|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(99, 'Specialty (PT)', 2006, 'USD', 116.342999999999 , 201812, '27', 'Core', '201812|2006|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(100, 'Specialty (PT)', 2007, 'USD', 843.955000000002 , 201812, '27', 'Core', '201812|2007|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(101, 'Specialty (PT)', 2008, 'USD', 996448.802999999840 , 201812, '27', 'Core', '201812|2008|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(102, 'Specialty (PT)', 2009, 'USD', 110377.403000000170 , 201812, '27', 'Core', '201812|2009|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(103, 'Specialty (PT)', 2010, 'USD', 5771.449499999988 , 201812, '27', 'Core', '201812|2010|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(104, 'Specialty (PT)', 2011, 'USD', 55113.313500000106 , 201812, '27', 'Core', '201812|2011|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(105, 'TMB Large Risk Int', 2014, 'USD', 4.999500000000 , 201812, '712', 'Core', '201812|2014|712|USD|Core', 'XL', 'Systemic cover - Clash'),

(106, 'TMB UK Info Sec', 2014, 'USD', 5.494500000000 , 201812, '721', 'Core', '201812|2014|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(107, 'TMB UK Info Sec', 2015, 'USD', 77.360250000143 , 201812, '721', 'Core', '201812|2015|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(108, 'TMB UK Tech', 2006, 'USD', 49.161500000000 , 201812, '19', 'Core', '201812|2006|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(109, 'TMB UK Tech', 2007, 'USD', 141569.483499998230 , 201812, '19', 'Core', '201812|2007|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(110, 'TMB UK Tech', 2008, 'USD', 622102.038000000000 , 201812, '19', 'Core', '201812|2008|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(111, 'TMB UK Tech', 2010, 'USD', 62470.543000000005 , 201812, '19', 'Core', '201812|2010|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(112, 'UK', 2006, 'EUR', 8732.104999999981 , 201812, '24', 'Core', '201812|2006|24|EUR|Core', 'XL', 'Systemic cover - Clash'),

(113, 'UK', 2007, 'GBP', 304.428000000000 , 201812, '24', 'Core', '201812|2007|24|GBP|Core', 'XL', 'Systemic cover - Clash'),

(122, 'BUSA BBR Services MM', 2014, 'USD', 24.700499999686 , 201903, '732', 'Core', '201903|2014|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(123, 'BUSA EPL MM', 2007, 'USD', 10067.562000000151 , 201903, '681', 'Core', '201903|2007|681|USD|Core', 'XL', 'Systemic cover - Clash'),

(124, 'BUSA TMB US E&O', 2014, 'USD', 13.175250000000 , 201903, '689', 'Core', '201903|2014|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(125, 'BUSA TMB US Info Sec', 2014, 'USD', 78.251249999972 , 201903, '714', 'Core', '201903|2014|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(126, 'BUSA TMB US Info Sec', 2015, 'USD', 0.024750000000 , 201903, '714', 'Core', '201903|2015|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(127, 'D&O', 2003, 'USD', 24331.972500000149 , 201903, '6', 'Core', '201903|2003|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(128, 'D&O', 2007, 'USD', 35533.885500000790 , 201903, '6', 'Core', '201903|2007|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(129, 'D&O', 2008, 'USD', 339326.559500003230 , 201903, '6', 'Core', '201903|2008|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(130, 'D&O', 2009, 'USD', 1937.755499999999 , 201903, '6', 'Core', '201903|2009|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(131, 'D&O', 2010, 'USD', 527.042999999998 , 201903, '6', 'Core', '201903|2010|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(132, 'DIN US Lawyers', 2011, 'USD', 90.680000000000 , 201903, '7', 'Core', '201903|2011|7|USD|Core', 'XL', 'Systemic cover - Clash'),

(133, 'EPL', 2007, 'USD', 840.496499999994 , 201903, '8', 'Core', '201903|2007|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(134, 'EPL', 2008, 'USD', 2108.040000000000 , 201903, '8', 'Core', '201903|2008|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(135, 'EPL', 2009, 'USD', 20.585000000000 , 201903, '8', 'Core', '201903|2009|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(136, 'Mid Market Lawyers', 2009, 'USD', 6789.709000000032 , 201903, '663', 'Core', '201903|2009|663|USD|Core', 'XL', 'Systemic cover - Clash'),

(137, 'PI-Ins Brokers exBLPT', 2008, 'USD', 6630.192000000001 , 201903, '14', 'Core', '201903|2008|14|USD|Core', 'XL', 'Systemic cover - Clash'),

(138, 'PI-Lawyers exBLPT', 2004, 'USD', 41100.555999999866 , 201903, '15', 'Core', '201903|2004|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(139, 'PI-Lawyers exBLPT', 2005, 'USD', 5.093000000000 , 201903, '15', 'Core', '201903|2005|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(140, 'PI-Lawyers exBLPT', 2006, 'USD', 613.564499999993 , 201903, '15', 'Core', '201903|2006|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(141, 'PI-Lawyers exBLPT', 2007, 'USD', 29743.659000000916 , 201903, '15', 'Core', '201903|2007|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(142, 'PI-Lawyers exBLPT', 2008, 'USD', 1059231.495000001000 , 201903, '15', 'Core', '201903|2008|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(143, 'PI-Lawyers exBLPT', 2009, 'USD', 741736.004499999920 , 201903, '15', 'Core', '201903|2009|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(144, 'PI-Lawyers exBLPT', 2012, 'USD', 83.029000000000 , 201903, '15', 'Core', '201903|2012|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(145, 'PI-Other exBLPT', 2007, 'USD', 28.399500000000 , 201903, '18', 'Core', '201903|2007|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(146, 'PI-Other exBLPT', 2008, 'USD', 60.000500000000 , 201903, '18', 'Core', '201903|2008|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(147, 'PI-Other exBLPT', 2009, 'USD', 8195.288499999908 , 201903, '18', 'Core', '201903|2009|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(148, 'PI-Other exBLPT', 2010, 'USD', 8.820000000000 , 201903, '18', 'Core', '201903|2010|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(149, 'PI-Other exBLPT', 2011, 'USD', 0.868000000000 , 201903, '18', 'Core', '201903|2011|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(150, 'Specialty (PT)', 2006, 'USD', 109.196500000000 , 201903, '27', 'Core', '201903|2006|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(151, 'Specialty (PT)', 2007, 'USD', 792.110000000001 , 201903, '27', 'Core', '201903|2007|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(152, 'Specialty (PT)', 2008, 'USD', 995452.263499999880 , 201903, '27', 'Core', '201903|2008|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(153, 'Specialty (PT)', 2009, 'USD', 109584.300500000360 , 201903, '27', 'Core', '201903|2009|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(154, 'Specialty (PT)', 2010, 'USD', 5416.747499999940 , 201903, '27', 'Core', '201903|2010|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(155, 'Specialty (PT)', 2011, 'USD', 54774.905000000144 , 201903, '27', 'Core', '201903|2011|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(156, 'TMB Large Risk Int', 2014, 'USD', 4.999500000000 , 201903, '712', 'Core', '201903|2014|712|USD|Core', 'XL', 'Systemic cover - Clash'),

(157, 'TMB UK Info Sec', 2014, 'USD', 5.494500000000 , 201903, '721', 'Core', '201903|2014|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(158, 'TMB UK Info Sec', 2015, 'USD', 77.360250000143 , 201903, '721', 'Core', '201903|2015|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(159, 'TMB UK Tech', 2006, 'USD', 46.114500000000 , 201903, '19', 'Core', '201903|2006|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(160, 'TMB UK Tech', 2007, 'USD', 132868.837499998510 , 201903, '19', 'Core', '201903|2007|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(161, 'TMB UK Tech', 2008, 'USD', 727628.021999999880 , 201903, '19', 'Core', '201903|2008|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(162, 'TMB UK Tech', 2010, 'USD', 63043.223999999987 , 201903, '19', 'Core', '201903|2010|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(163, 'UK', 2006, 'EUR', 8195.442000000040 , 201903, '24', 'Core', '201903|2006|24|EUR|Core', 'XL', 'Systemic cover - Clash'),

(164, 'UK', 2007, 'GBP', 285.699000000001 , 201903, '24', 'Core', '201903|2007|24|GBP|Core', 'XL', 'Systemic cover - Clash'),

(173, 'BUSA BBR Services MM', 2014, 'USD', 24.700499999686 , 201906, '732', 'Core', '201906|2014|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(174, 'BUSA EPL MM', 2007, 'USD', 12216.558000000194 , 201906, '681', 'Core', '201906|2007|681|USD|Core', 'XL', 'Systemic cover - Clash'),

(175, 'BUSA TMB US E&O', 2014, 'USD', 13.175250000000 , 201906, '689', 'Core', '201906|2014|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(176, 'BUSA TMB US Info Sec', 2015, 'USD', 0.024750000000 , 201906, '714', 'Core', '201906|2015|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(177, 'BUSA TMB US Info Sec', 2014, 'USD', 78.251249999972 , 201906, '714', 'Core', '201906|2014|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(178, 'D&O', 2010, 'USD', 642.058000000012 , 201906, '6', 'Core', '201906|2010|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(179, 'D&O', 2007, 'USD', 43118.796500000171 , 201906, '6', 'Core', '201906|2007|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(180, 'D&O', 2003, 'USD', 29525.786500000395 , 201906, '6', 'Core', '201906|2003|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(181, 'D&O', 2008, 'USD', 719101.836999995630 , 201906, '6', 'Core', '201906|2008|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(182, 'D&O', 2009, 'USD', 2351.370499999990 , 201906, '6', 'Core', '201906|2009|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(183, 'DIN US Lawyers', 2011, 'USD', 120.470000000000 , 201906, '7', 'Core', '201906|2011|7|USD|Core', 'XL', 'Systemic cover - Clash'),

(184, 'EPL', 2007, 'USD', 1019.876999999993 , 201906, '8', 'Core', '201906|2007|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(185, 'EPL', 2009, 'USD', 24.975500000000 , 201906, '8', 'Core', '201906|2009|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(186, 'EPL', 2008, 'USD', 2118.900000000001 , 201906, '8', 'Core', '201906|2008|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(187, 'Mid Market Lawyers', 2009, 'USD', 8238.987499999930 , 201906, '663', 'Core', '201906|2009|663|USD|Core', 'XL', 'Systemic cover - Clash'),

(188, 'PI-Ins Brokers exBLPT', 2008, 'USD', 6555.222000000000 , 201906, '14', 'Core', '201906|2008|14|USD|Core', 'XL', 'Systemic cover - Clash'),

(189, 'PI-Lawyers exBLPT', 2010, 'USD', 22000.528000000166 , 201906, '15', 'Core', '201906|2010|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(190, 'PI-Lawyers exBLPT', 2008, 'USD', 1075195.971000000800 , 201906, '15', 'Core', '201906|2008|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(191, 'PI-Lawyers exBLPT', 2009, 'USD', 744011.229500000130 , 201906, '15', 'Core', '201906|2009|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(192, 'PI-Lawyers exBLPT', 2007, 'USD', 36092.610000000335 , 201906, '15', 'Core', '201906|2007|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(193, 'PI-Lawyers exBLPT', 2006, 'USD', 744.516000000003 , 201906, '15', 'Core', '201906|2006|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(194, 'PI-Lawyers exBLPT', 2005, 'USD', 6.193000000000 , 201906, '15', 'Core', '201906|2005|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(195, 'PI-Lawyers exBLPT', 2004, 'USD', 49873.724500000477 , 201906, '15', 'Core', '201906|2004|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(196, 'PI-Lawyers exBLPT', 2012, 'USD', 100.737999999999 , 201906, '15', 'Core', '201906|2012|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(197, 'PI-Other exBLPT', 2010, 'USD', 10.786500000000 , 201906, '18', 'Core', '201906|2010|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(198, 'PI-Other exBLPT', 2009, 'USD', 9944.591999999830 , 201906, '18', 'Core', '201906|2009|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(199, 'PI-Other exBLPT', 2011, 'USD', 1.027000000000 , 201906, '18', 'Core', '201906|2011|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(200, 'PI-Other exBLPT', 2008, 'USD', 66.410500000000 , 201906, '18', 'Core', '201906|2008|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(201, 'PI-Other exBLPT', 2007, 'USD', 34.460000000000 , 201906, '18', 'Core', '201906|2007|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(202, 'Specialty (PT)', 2006, 'USD', 132.494000000001 , 201906, '27', 'Core', '201906|2006|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(203, 'Specialty (PT)', 2011, 'USD', 55882.356500000227 , 201906, '27', 'Core', '201906|2011|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(204, 'Specialty (PT)', 2010, 'USD', 6573.011999999755 , 201906, '27', 'Core', '201906|2010|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(205, 'Specialty (PT)', 2007, 'USD', 961.167500000010 , 201906, '27', 'Core', '201906|2007|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(206, 'Specialty (PT)', 2008, 'USD', 980173.130500000090 , 201906, '27', 'Core', '201906|2008|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(207, 'Specialty (PT)', 2009, 'USD', 112336.077000000050 , 201906, '27', 'Core', '201906|2009|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(208, 'TMB Large Risk Int', 2014, 'USD', 4.999500000000 , 201906, '712', 'Core', '201906|2014|712|USD|Core', 'XL', 'Systemic cover - Clash'),

(209, 'TMB UK Info Sec', 2014, 'USD', 5.494500000000 , 201906, '721', 'Core', '201906|2014|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(210, 'TMB UK Info Sec', 2015, 'USD', 77.360250000143 , 201906, '721', 'Core', '201906|2015|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(211, 'TMB UK Tech', 2006, 'USD', 55.978500000000 , 201906, '19', 'Core', '201906|2006|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(212, 'TMB UK Tech', 2007, 'USD', 161230.547499993820 , 201906, '19', 'Core', '201906|2007|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(213, 'TMB UK Tech', 2010, 'USD', 39567.402499999967 , 201906, '19', 'Core', '201906|2010|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(214, 'TMB UK Tech', 2008, 'USD', 724111.056000000000 , 201906, '19', 'Core', '201906|2008|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(215, 'UK', 2006, 'EUR', 9944.831000000006 , 201906, '24', 'Core', '201906|2006|24|EUR|Core', 'XL', 'Systemic cover - Clash'),

(216, 'UK', 2007, 'GBP', 346.709500000001 , 201906, '24', 'Core', '201906|2007|24|GBP|Core', 'XL', 'Systemic cover - Clash'),

(224, 'BUSA EPL MM', 2007, 'USD', 12216.560000000056 , 201909, '681', 'Core', '201909|2007|681|USD|Core', 'XL', 'Systemic cover - Clash'),

(225, 'BUSA TMB US E&O', 2014, 'USD', 12.614250000000 , 201909, '689', 'Core', '201909|2014|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(226, 'D&O', 2007, 'USD', 43118.816500000190 , 201909, '6', 'Core', '201909|2007|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(227, 'D&O', 2010, 'USD', 642.068000000014 , 201909, '6', 'Core', '201909|2010|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(228, 'D&O', 2003, 'USD', 29525.788500000257 , 201909, '6', 'Core', '201909|2003|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(229, 'D&O', 2008, 'USD', 717168.280500011520 , 201909, '6', 'Core', '201909|2008|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(230, 'D&O', 2009, 'USD', 2399.978500000027 , 201909, '6', 'Core', '201909|2009|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(231, 'DIN US Lawyers', 2011, 'USD', 120.470000000000 , 201909, '7', 'Core', '201909|2011|7|USD|Core', 'XL', 'Systemic cover - Clash'),

(232, 'EPL', 2009, 'USD', 24.975500000000 , 201909, '8', 'Core', '201909|2009|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(233, 'EPL', 2007, 'USD', 1019.876999999993 , 201909, '8', 'Core', '201909|2007|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(234, 'EPL', 2008, 'USD', 2100.282000000000 , 201909, '8', 'Core', '201909|2008|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(235, 'Mid Market Lawyers', 2009, 'USD', 8239.007499999949 , 201909, '663', 'Core', '201909|2009|663|USD|Core', 'XL', 'Systemic cover - Clash'),

(236, 'PI-Ins Brokers exBLPT', 2008, 'USD', 6523.746000000000 , 201909, '14', 'Core', '201909|2008|14|USD|Core', 'XL', 'Systemic cover - Clash'),

(237, 'PI-Lawyers exBLPT', 2004, 'USD', 49873.690999999642 , 201909, '15', 'Core', '201909|2004|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(238, 'PI-Lawyers exBLPT', 2012, 'USD', 100.737999999999 , 201909, '15', 'Core', '201909|2012|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(239, 'PI-Lawyers exBLPT', 2007, 'USD', 36092.604499999434 , 201909, '15', 'Core', '201909|2007|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(240, 'PI-Lawyers exBLPT', 2005, 'USD', 6.193000000000 , 201909, '15', 'Core', '201909|2005|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(241, 'PI-Lawyers exBLPT', 2006, 'USD', 744.516000000003 , 201909, '15', 'Core', '201909|2006|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(242, 'PI-Lawyers exBLPT', 2010, 'USD', 22000.537999999942 , 201909, '15', 'Core', '201909|2010|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(243, 'PI-Lawyers exBLPT', 2008, 'USD', 1063586.009000000500 , 201909, '15', 'Core', '201909|2008|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(244, 'PI-Lawyers exBLPT', 2009, 'USD', 737510.282000000000 , 201909, '15', 'Core', '201909|2009|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(245, 'PI-Other exBLPT', 2009, 'USD', 9944.593999999925 , 201909, '18', 'Core', '201909|2009|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(246, 'PI-Other exBLPT', 2010, 'USD', 10.786500000000 , 201909, '18', 'Core', '201909|2010|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(247, 'PI-Other exBLPT', 2007, 'USD', 34.460000000000 , 201909, '18', 'Core', '201909|2007|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(248, 'PI-Other exBLPT', 2008, 'USD', 66.140500000000 , 201909, '18', 'Core', '201909|2008|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(249, 'PI-Other exBLPT', 2011, 'USD', 1.027000000000 , 201909, '18', 'Core', '201909|2011|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(250, 'Specialty (PT)', 2007, 'USD', 961.167500000010 , 201909, '27', 'Core', '201909|2007|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(251, 'Specialty (PT)', 2009, 'USD', 112336.076999999930 , 201909, '27', 'Core', '201909|2009|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(252, 'Specialty (PT)', 2006, 'USD', 132.494000000001 , 201909, '27', 'Core', '201909|2006|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(253, 'Specialty (PT)', 2008, 'USD', 980173.138000000000 , 201909, '27', 'Core', '201909|2008|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(254, 'Specialty (PT)', 2011, 'USD', 55882.356500000227 , 201909, '27', 'Core', '201909|2011|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(255, 'Specialty (PT)', 2010, 'USD', 6573.012000000337 , 201909, '27', 'Core', '201909|2010|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(256, 'TMB Large Risk Int', 2014, 'USD', 4.892250000000 , 201909, '712', 'Core', '201909|2014|712|USD|Core', 'XL', 'Systemic cover - Clash'),

(257, 'TMB UK Info Sec', 2014, 'USD', 5.304750000000 , 201909, '721', 'Core', '201909|2014|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(258, 'TMB UK Tech', 2006, 'USD', 55.978500000000 , 201909, '19', 'Core', '201909|2006|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(259, 'TMB UK Tech', 2008, 'USD', 723843.258000000000 , 201909, '19', 'Core', '201909|2008|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(260, 'TMB UK Tech', 2010, 'USD', 39560.486499999941 , 201909, '19', 'Core', '201909|2010|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(261, 'TMB UK Tech', 2007, 'USD', 161230.571000004190 , 201909, '19', 'Core', '201909|2007|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(262, 'UK', 2006, 'EUR', 9944.822999999858 , 201909, '24', 'Core', '201909|2006|24|EUR|Core', 'XL', 'Systemic cover - Clash'),

(263, 'UK', 2007, 'GBP', 346.709500000001 , 201909, '24', 'Core', '201909|2007|24|GBP|Core', 'XL', 'Systemic cover - Clash'),

(272, 'BUSA BBR Services MM', 2014, 'USD', 24.667499999749 , 201912, '732', 'Core', '201912|2014|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(273, 'BUSA EPL MM', 2007, 'USD', 11229.485500000184 , 201912, '681', 'Core', '201912|2007|681|USD|Core', 'XL', 'Systemic cover - Clash'),

(274, 'BUSA TMB US E&O', 2015, 'USD', 0.008250000000 , 201912, '689', 'Core', '201912|2015|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(275, 'BUSA TMB US E&O', 2014, 'USD', 13.183500000000 , 201912, '689', 'Core', '201912|2014|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(276, 'BUSA TMB US Info Sec', 2015, 'USD', 0.024750000000 , 201912, '714', 'Core', '201912|2015|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(277, 'BUSA TMB US Info Sec', 2014, 'USD', 78.284250000026 , 201912, '714', 'Core', '201912|2014|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(278, 'D&O', 2010, 'USD', 589.972500000003 , 201912, '6', 'Core', '201912|2010|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(279, 'D&O', 2007, 'USD', 39634.962000000291 , 201912, '6', 'Core', '201912|2007|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(280, 'D&O', 2009, 'USD', 2206.111000000004 , 201912, '6', 'Core', '201912|2009|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(281, 'D&O', 2003, 'USD', 27140.219500000589 , 201912, '6', 'Core', '201912|2003|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(282, 'D&O', 2008, 'USD', 703046.572500029580 , 201912, '6', 'Core', '201912|2008|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(283, 'DIN US Lawyers', 2011, 'USD', 109.820000000000 , 201912, '7', 'Core', '201912|2011|7|USD|Core', 'XL', 'Systemic cover - Clash'),

(284, 'EPL', 2008, 'USD', 2092.638000000000 , 201912, '8', 'Core', '201912|2008|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(285, 'EPL', 2007, 'USD', 937.488499999992 , 201912, '8', 'Core', '201912|2007|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(286, 'EPL', 2009, 'USD', 22.956500000000 , 201912, '8', 'Core', '201912|2009|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(287, 'Mid Market Lawyers', 2009, 'USD', 7573.313999999897 , 201912, '663', 'Core', '201912|2009|663|USD|Core', 'XL', 'Systemic cover - Clash'),

(288, 'PI-Ins Brokers exBLPT', 2008, 'USD', 6251.178000000000 , 201912, '14', 'Core', '201912|2008|14|USD|Core', 'XL', 'Systemic cover - Clash'),

(289, 'PI-Lawyers exBLPT', 2005, 'USD', 5.687500000000 , 201912, '15', 'Core', '201912|2005|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(290, 'PI-Lawyers exBLPT', 2004, 'USD', 45844.075500001200 , 201912, '15', 'Core', '201912|2004|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(291, 'PI-Lawyers exBLPT', 2012, 'USD', 92.607000000000 , 201912, '15', 'Core', '201912|2012|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(292, 'PI-Lawyers exBLPT', 2006, 'USD', 684.350500000000 , 201912, '15', 'Core', '201912|2006|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(293, 'PI-Lawyers exBLPT', 2010, 'USD', 20222.980499999830 , 201912, '15', 'Core', '201912|2010|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(294, 'PI-Lawyers exBLPT', 2008, 'USD', 1053579.867999998900 , 201912, '15', 'Core', '201912|2008|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(295, 'PI-Lawyers exBLPT', 2007, 'USD', 33176.435499999672 , 201912, '15', 'Core', '201912|2007|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(296, 'PI-Lawyers exBLPT', 2009, 'USD', 734393.056500000180 , 201912, '15', 'Core', '201912|2009|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(297, 'PI-Other exBLPT', 2008, 'USD', 63.197500000000 , 201912, '18', 'Core', '201912|2008|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(298, 'PI-Other exBLPT', 2009, 'USD', 9141.174999999930 , 201912, '18', 'Core', '201912|2009|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(299, 'PI-Other exBLPT', 2011, 'USD', 0.968500000000 , 201912, '18', 'Core', '201912|2011|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(300, 'PI-Other exBLPT', 2010, 'USD', 9.866500000000 , 201912, '18', 'Core', '201912|2010|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(301, 'PI-Other exBLPT', 2007, 'USD', 31.691500000000 , 201912, '18', 'Core', '201912|2007|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(302, 'Specialty (PT)', 2009, 'USD', 111284.500500000080 , 201912, '27', 'Core', '201912|2009|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(303, 'Specialty (PT)', 2010, 'USD', 6041.926999999909 , 201912, '27', 'Core', '201912|2010|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(304, 'Specialty (PT)', 2006, 'USD', 121.798499999999 , 201912, '27', 'Core', '201912|2006|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(305, 'Specialty (PT)', 2007, 'USD', 883.527000000002 , 201912, '27', 'Core', '201912|2007|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(306, 'Specialty (PT)', 2011, 'USD', 55392.365500000131 , 201912, '27', 'Core', '201912|2011|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(307, 'Specialty (PT)', 2008, 'USD', 851266.162999999830 , 201912, '27', 'Core', '201912|2008|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(308, 'TMB Large Risk Int', 2014, 'USD', 4.991250000000 , 201912, '712', 'Core', '201912|2014|712|USD|Core', 'XL', 'Systemic cover - Clash'),

(309, 'TMB UK Info Sec', 2014, 'USD', 5.494500000000 , 201912, '721', 'Core', '201912|2014|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(310, 'TMB UK Info Sec', 2015, 'USD', 77.327249999857 , 201912, '721', 'Core', '201912|2015|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(311, 'TMB UK Tech', 2006, 'USD', 51.460000000000 , 201912, '19', 'Core', '201912|2006|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(312, 'TMB UK Tech', 2008, 'USD', 723639.527999999930 , 201912, '19', 'Core', '201912|2008|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(313, 'TMB UK Tech', 2010, 'USD', 39088.494500000030 , 201912, '19', 'Core', '201912|2010|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(314, 'TMB UK Tech', 2007, 'USD', 148203.644999995830 , 201912, '19', 'Core', '201912|2007|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(315, 'UK', 2006, 'EUR', 9141.293499999913 , 201912, '24', 'Core', '201912|2006|24|EUR|Core', 'XL', 'Systemic cover - Clash'),

(316, 'UK', 2007, 'GBP', 318.665499999999 , 201912, '24', 'Core', '201912|2007|24|GBP|Core', 'XL', 'Systemic cover - Clash'),

(325, 'BUSA BBR Services MM', 2014, 'USD', 24.667499999749 , 202003, '732', 'Core', '202003|2014|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(326, 'BUSA EPL MM', 2007, 'USD', 11211.848999999929 , 202003, '681', 'Core', '202003|2007|681|USD|Core', 'XL', 'Systemic cover - Clash'),

(327, 'BUSA TMB US E&O', 2014, 'USD', 13.183500000000 , 202003, '689', 'Core', '202003|2014|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(328, 'BUSA TMB US E&O', 2015, 'USD', 0.008250000000 , 202003, '689', 'Core', '202003|2015|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(329, 'BUSA TMB US Info Sec', 2015, 'USD', 0.024750000000 , 202003, '714', 'Core', '202003|2015|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(330, 'BUSA TMB US Info Sec', 2014, 'USD', 78.292499999981 , 202003, '714', 'Core', '202003|2014|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(331, 'D&O', 2010, 'USD', 589.017500000009 , 202003, '6', 'Core', '202003|2010|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(332, 'D&O', 2008, 'USD', 703241.805000020190 , 202003, '6', 'Core', '202003|2008|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(333, 'D&O', 2007, 'USD', 39572.768000001088 , 202003, '6', 'Core', '202003|2007|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(334, 'D&O', 2009, 'USD', 2158.012000000017 , 202003, '6', 'Core', '202003|2009|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(335, 'D&O', 2003, 'USD', 27097.601999999955 , 202003, '6', 'Core', '202003|2003|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(336, 'DIN US Lawyers', 2011, 'USD', 109.640000000000 , 202003, '7', 'Core', '202003|2011|7|USD|Core', 'XL', 'Systemic cover - Clash'),

(337, 'EPL', 2007, 'USD', 936.020000000004 , 202003, '8', 'Core', '202003|2007|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(338, 'EPL', 2008, 'USD', 2096.208000000001 , 202003, '8', 'Core', '202003|2008|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(339, 'EPL', 2009, 'USD', 22.923500000000 , 202003, '8', 'Core', '202003|2009|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(340, 'Mid Market Lawyers', 2009, 'USD', 7561.437999999966 , 202003, '663', 'Core', '202003|2009|663|USD|Core', 'XL', 'Systemic cover - Clash'),

(341, 'PI-Ins Brokers exBLPT', 2008, 'USD', 6258.018000000000 , 202003, '14', 'Core', '202003|2008|14|USD|Core', 'XL', 'Systemic cover - Clash'),

(342, 'PI-Lawyers exBLPT', 2008, 'USD', 1055349.978500001100 , 202003, '15', 'Core', '202003|2008|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(343, 'PI-Lawyers exBLPT', 2004, 'USD', 45772.046999999322 , 202003, '15', 'Core', '202003|2004|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(344, 'PI-Lawyers exBLPT', 2010, 'USD', 20191.195499999914 , 202003, '15', 'Core', '202003|2010|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(345, 'PI-Lawyers exBLPT', 2007, 'USD', 33124.301500000060 , 202003, '15', 'Core', '202003|2007|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(346, 'PI-Lawyers exBLPT', 2009, 'USD', 736003.436500000300 , 202003, '15', 'Core', '202003|2009|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(347, 'PI-Lawyers exBLPT', 2012, 'USD', 92.471500000000 , 202003, '15', 'Core', '202003|2012|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(348, 'PI-Lawyers exBLPT', 2006, 'USD', 683.286000000007 , 202003, '15', 'Core', '202003|2006|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(349, 'PI-Lawyers exBLPT', 2005, 'USD', 5.675500000000 , 202003, '15', 'Core', '202003|2005|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(350, 'PI-Other exBLPT', 2007, 'USD', 31.634000000000 , 202003, '18', 'Core', '202003|2007|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(351, 'PI-Other exBLPT', 2008, 'USD', 63.179000000000 , 202003, '18', 'Core', '202003|2008|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(352, 'PI-Other exBLPT', 2009, 'USD', 9126.787499999977 , 202003, '18', 'Core', '202003|2009|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(353, 'PI-Other exBLPT', 2011, 'USD', 0.968500000000 , 202003, '18', 'Core', '202003|2011|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(354, 'PI-Other exBLPT', 2010, 'USD', 9.832500000000 , 202003, '18', 'Core', '202003|2010|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(355, 'Specialty (PT)', 2011, 'USD', 55384.315000000177 , 202003, '27', 'Core', '202003|2011|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(356, 'Specialty (PT)', 2008, 'USD', 850786.086999999820 , 202003, '27', 'Core', '202003|2008|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(357, 'Specialty (PT)', 2010, 'USD', 6032.413500000257 , 202003, '27', 'Core', '202003|2010|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(358, 'Specialty (PT)', 2009, 'USD', 109552.977500000390 , 202003, '27', 'Core', '202003|2009|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(359, 'Specialty (PT)', 2007, 'USD', 882.108500000002 , 202003, '27', 'Core', '202003|2007|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(360, 'Specialty (PT)', 2006, 'USD', 121.599999999999 , 202003, '27', 'Core', '202003|2006|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(361, 'TMB Large Risk Int', 2014, 'USD', 4.991250000000 , 202003, '712', 'Core', '202003|2014|712|USD|Core', 'XL', 'Systemic cover - Clash'),

(362, 'TMB UK Info Sec', 2015, 'USD', 77.335499999812 , 202003, '721', 'Core', '202003|2015|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(363, 'TMB UK Info Sec', 2014, 'USD', 5.494500000000 , 202003, '721', 'Core', '202003|2014|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(364, 'TMB UK Tech', 2008, 'USD', 723697.061999999920 , 202003, '19', 'Core', '202003|2008|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(365, 'TMB UK Tech', 2010, 'USD', 39080.324000000022 , 202003, '19', 'Core', '202003|2010|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(366, 'TMB UK Tech', 2006, 'USD', 51.368500000000 , 202003, '19', 'Core', '202003|2006|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(367, 'TMB UK Tech', 2007, 'USD', 147971.139500001450 , 202003, '19', 'Core', '202003|2007|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(368, 'UK', 2006, 'EUR', 9126.939999999944 , 202003, '24', 'Core', '202003|2006|24|EUR|Core', 'XL', 'Systemic cover - Clash'),

(369, 'UK', 2007, 'GBP', 318.169500000000 , 202003, '24', 'Core', '202003|2007|24|GBP|Core', 'XL', 'Systemic cover - Clash'),

(378, 'BUSA BBR Services MM', 2014, 'USD', 24.667499999749 , 202006, '732', 'Core', '202006|2014|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(379, 'BUSA EPL MM', 2007, 'USD', 8446.723499999847 , 202006, '681', 'Core', '202006|2007|681|USD|Core', 'XL', 'Systemic cover - Clash'),

(380, 'BUSA TMB US E&O', 2014, 'USD', 13.183500000000 , 202006, '689', 'Core', '202006|2014|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(381, 'BUSA TMB US E&O', 2015, 'USD', 0.008250000000 , 202006, '689', 'Core', '202006|2015|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(382, 'BUSA TMB US Info Sec', 2015, 'USD', 0.024750000000 , 202006, '714', 'Core', '202006|2015|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(383, 'BUSA TMB US Info Sec', 2014, 'USD', 78.465749999974 , 202006, '714', 'Core', '202006|2014|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(384, 'D&O', 2007, 'USD', 29813.158999999985 , 202006, '6', 'Core', '202006|2007|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(385, 'D&O', 2008, 'USD', 319346.268000034620 , 202006, '6', 'Core', '202006|2008|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(386, 'D&O', 2009, 'USD', 1625.793499999971 , 202006, '6', 'Core', '202006|2009|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(387, 'D&O', 2010, 'USD', 443.112000000001 , 202006, '6', 'Core', '202006|2010|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(388, 'D&O', 2003, 'USD', 20414.687499999534 , 202006, '6', 'Core', '202006|2003|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(389, 'DIN US Lawyers', 2011, 'USD', 79.840000000000 , 202006, '7', 'Core', '202006|2011|7|USD|Core', 'XL', 'Systemic cover - Clash'),

(390, 'EPL', 2008, 'USD', 2089.242000000000 , 202006, '8', 'Core', '202006|2008|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(391, 'EPL', 2007, 'USD', 705.169500000004 , 202006, '8', 'Core', '202006|2007|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(392, 'EPL', 2009, 'USD', 17.261000000000 , 202006, '8', 'Core', '202006|2009|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(393, 'Mid Market Lawyers', 2009, 'USD', 5696.605499999947 , 202006, '663', 'Core', '202006|2009|663|USD|Core', 'XL', 'Systemic cover - Clash'),

(394, 'PI-Ins Brokers exBLPT', 2008, 'USD', 6244.662000000000 , 202006, '14', 'Core', '202006|2008|14|USD|Core', 'XL', 'Systemic cover - Clash'),

(395, 'PI-Lawyers exBLPT', 2009, 'USD', 733520.529500000180 , 202006, '15', 'Core', '202006|2009|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(396, 'PI-Lawyers exBLPT', 2010, 'USD', 15211.561000000220 , 202006, '15', 'Core', '202006|2010|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(397, 'PI-Lawyers exBLPT', 2007, 'USD', 24955.054500000086 , 202006, '15', 'Core', '202006|2007|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(398, 'PI-Lawyers exBLPT', 2006, 'USD', 514.762499999997 , 202006, '15', 'Core', '202006|2006|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(399, 'PI-Lawyers exBLPT', 2008, 'USD', 1034730.894000001300 , 202006, '15', 'Core', '202006|2008|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(400, 'PI-Lawyers exBLPT', 2004, 'USD', 34483.575000000186 , 202006, '15', 'Core', '202006|2004|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(401, 'PI-Lawyers exBLPT', 2012, 'USD', 69.662000000000 , 202006, '15', 'Core', '202006|2012|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(402, 'PI-Lawyers exBLPT', 2005, 'USD', 4.269000000000 , 202006, '15', 'Core', '202006|2005|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(403, 'PI-Other exBLPT', 2010, 'USD', 7.381000000000 , 202006, '18', 'Core', '202006|2010|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(404, 'PI-Other exBLPT', 2008, 'USD', 55.022500000000 , 202006, '18', 'Core', '202006|2008|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(405, 'PI-Other exBLPT', 2009, 'USD', 6875.906499999925 , 202006, '18', 'Core', '202006|2009|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(406, 'PI-Other exBLPT', 2011, 'USD', 0.735000000000 , 202006, '18', 'Core', '202006|2011|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(407, 'PI-Other exBLPT', 2007, 'USD', 23.831500000000 , 202006, '18', 'Core', '202006|2007|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(408, 'Specialty (PT)', 2008, 'USD', 848909.002000000000 , 202006, '27', 'Core', '202006|2008|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(409, 'Specialty (PT)', 2011, 'USD', 54096.599500000186 , 202006, '27', 'Core', '202006|2011|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(410, 'Specialty (PT)', 2006, 'USD', 91.612999999999 , 202006, '27', 'Core', '202006|2006|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(411, 'Specialty (PT)', 2007, 'USD', 664.561000000002 , 202006, '27', 'Core', '202006|2007|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(412, 'Specialty (PT)', 2009, 'USD', 107293.216000000360 , 202006, '27', 'Core', '202006|2009|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(413, 'Specialty (PT)', 2010, 'USD', 4544.663499999559 , 202006, '27', 'Core', '202006|2010|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(414, 'TMB Large Risk Int', 2014, 'USD', 4.991250000000 , 202006, '712', 'Core', '202006|2014|712|USD|Core', 'XL', 'Systemic cover - Clash'),

(415, 'TMB UK Info Sec', 2015, 'USD', 77.335499999812 , 202006, '721', 'Core', '202006|2015|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(416, 'TMB UK Info Sec', 2014, 'USD', 5.494500000000 , 202006, '721', 'Core', '202006|2014|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(417, 'TMB UK Tech', 2008, 'USD', 722894.213999999920 , 202006, '19', 'Core', '202006|2008|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(418, 'TMB UK Tech', 2006, 'USD', 38.690500000001 , 202006, '19', 'Core', '202006|2006|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(419, 'TMB UK Tech', 2010, 'USD', 37633.341499999980 , 202006, '19', 'Core', '202006|2010|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(420, 'TMB UK Tech', 2007, 'USD', 111477.908500000830 , 202006, '19', 'Core', '202006|2007|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(421, 'UK', 2006, 'EUR', 6876.047499999986 , 202006, '24', 'Core', '202006|2006|24|EUR|Core', 'XL', 'Systemic cover - Clash'),

(422, 'UK', 2007, 'GBP', 239.718499999999 , 202006, '24', 'Core', '202006|2007|24|GBP|Core', 'XL', 'Systemic cover - Clash'),

(431, 'BUSA BBR Services MM', 2014, 'USD', 24.667499999865 , 202009, '732', 'Core', '202009|2014|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(432, 'BUSA EPL MM', 2007, 'USD', 8412.960499999812 , 202009, '681', 'Core', '202009|2007|681|USD|Core', 'XL', 'Systemic cover - Clash'),

(433, 'BUSA TMB US E&O', 2014, 'USD', 13.183500000000 , 202009, '689', 'Core', '202009|2014|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(434, 'BUSA TMB US E&O', 2015, 'USD', 0.008250000000 , 202009, '689', 'Core', '202009|2015|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(435, 'BUSA TMB US Info Sec', 2015, 'USD', 0.024750000000 , 202009, '714', 'Core', '202009|2015|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(436, 'BUSA TMB US Info Sec', 2014, 'USD', 78.465749999974 , 202009, '714', 'Core', '202009|2014|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(437, 'D&O', 2009, 'USD', 1619.240999999951 , 202009, '6', 'Core', '202009|2009|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(438, 'D&O', 2003, 'USD', 20333.067500000354 , 202009, '6', 'Core', '202009|2003|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(439, 'D&O', 2008, 'USD', 318919.648000035430 , 202009, '6', 'Core', '202009|2008|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(440, 'D&O', 2007, 'USD', 29694.012500000186 , 202009, '6', 'Core', '202009|2007|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(441, 'D&O', 2010, 'USD', 441.385499999997 , 202009, '6', 'Core', '202009|2010|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(442, 'DIN US Lawyers', 2011, 'USD', 79.760000000000 , 202009, '7', 'Core', '202009|2011|7|USD|Core', 'XL', 'Systemic cover - Clash'),

(443, 'EPL', 2007, 'USD', 702.356000000000 , 202009, '8', 'Core', '202009|2007|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(444, 'EPL', 2009, 'USD', 17.225500000000 , 202009, '8', 'Core', '202009|2009|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(445, 'EPL', 2008, 'USD', 2089.242000000000 , 202009, '8', 'Core', '202009|2008|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(446, 'Mid Market Lawyers', 2009, 'USD', 5673.823499999940 , 202009, '663', 'Core', '202009|2009|663|USD|Core', 'XL', 'Systemic cover - Clash'),

(447, 'PI-Ins Brokers exBLPT', 2008, 'USD', 6244.674000000000 , 202009, '14', 'Core', '202009|2008|14|USD|Core', 'XL', 'Systemic cover - Clash'),

(448, 'PI-Lawyers exBLPT', 2012, 'USD', 69.359000000000 , 202009, '15', 'Core', '202009|2012|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(449, 'PI-Lawyers exBLPT', 2005, 'USD', 4.258500000000 , 202009, '15', 'Core', '202009|2005|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(450, 'PI-Lawyers exBLPT', 2010, 'USD', 15150.760999999940 , 202009, '15', 'Core', '202009|2010|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(451, 'PI-Lawyers exBLPT', 2004, 'USD', 34345.751000000164 , 202009, '15', 'Core', '202009|2004|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(452, 'PI-Lawyers exBLPT', 2008, 'USD', 1034522.505000002700 , 202009, '15', 'Core', '202009|2008|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(453, 'PI-Lawyers exBLPT', 2009, 'USD', 733520.189000000000 , 202009, '15', 'Core', '202009|2009|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(454, 'PI-Lawyers exBLPT', 2006, 'USD', 512.699999999997 , 202009, '15', 'Core', '202009|2006|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(455, 'PI-Lawyers exBLPT', 2007, 'USD', 24855.257499999367 , 202009, '15', 'Core', '202009|2007|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(456, 'PI-Other exBLPT', 2009, 'USD', 6848.386499999906 , 202009, '18', 'Core', '202009|2009|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(457, 'PI-Other exBLPT', 2008, 'USD', 54.887500000000 , 202009, '18', 'Core', '202009|2008|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(458, 'PI-Other exBLPT', 2007, 'USD', 23.744500000000 , 202009, '18', 'Core', '202009|2007|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(459, 'PI-Other exBLPT', 2011, 'USD', 0.697000000000 , 202009, '18', 'Core', '202009|2011|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(460, 'PI-Other exBLPT', 2010, 'USD', 7.403500000000 , 202009, '18', 'Core', '202009|2010|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(461, 'Specialty (PT)', 2007, 'USD', 661.925999999992 , 202009, '27', 'Core', '202009|2007|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(462, 'Specialty (PT)', 2008, 'USD', 848896.031500000000 , 202009, '27', 'Core', '202009|2008|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(463, 'Specialty (PT)', 2011, 'USD', 54081.466000000248 , 202009, '27', 'Core', '202009|2011|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(464, 'Specialty (PT)', 2009, 'USD', 107841.842500000380 , 202009, '27', 'Core', '202009|2009|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(465, 'Specialty (PT)', 2010, 'USD', 4526.497499999707 , 202009, '27', 'Core', '202009|2010|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(466, 'Specialty (PT)', 2006, 'USD', 91.243999999999 , 202009, '27', 'Core', '202009|2006|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(467, 'TMB Large Risk Int', 2014, 'USD', 4.991250000000 , 202009, '712', 'Core', '202009|2014|712|USD|Core', 'XL', 'Systemic cover - Clash'),

(468, 'TMB UK Info Sec', 2015, 'USD', 77.335499999812 , 202009, '721', 'Core', '202009|2015|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(469, 'TMB UK Info Sec', 2014, 'USD', 5.494500000000 , 202009, '721', 'Core', '202009|2014|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(470, 'TMB UK Tech', 2006, 'USD', 38.555000000000 , 202009, '19', 'Core', '202009|2006|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(471, 'TMB UK Tech', 2007, 'USD', 111032.277499999850 , 202009, '19', 'Core', '202009|2007|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(472, 'TMB UK Tech', 2010, 'USD', 37617.997999999963 , 202009, '19', 'Core', '202009|2010|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(473, 'TMB UK Tech', 2008, 'USD', 722894.213999999920 , 202009, '19', 'Core', '202009|2008|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(474, 'UK', 2006, 'EUR', 6848.554999999935 , 202009, '24', 'Core', '202009|2006|24|EUR|Core', 'XL', 'Systemic cover - Clash'),

(475, 'UK', 2007, 'GBP', 238.771000000001 , 202009, '24', 'Core', '202009|2007|24|GBP|Core', 'XL', 'Systemic cover - Clash'),

(484, 'BUSA BBR Services MM', 2014, 'USD', 24.667499999865 , 202012, '732', 'Core', '202012|2014|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(485, 'BUSA EPL MM', 2007, 'USD', 8414.222000000067 , 202012, '681', 'Core', '202012|2007|681|USD|Core', 'XL', 'Systemic cover - Clash'),

(486, 'BUSA TMB US E&O', 2014, 'USD', 13.183500000000 , 202012, '689', 'Core', '202012|2014|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(487, 'BUSA TMB US E&O', 2015, 'USD', 0.008250000000 , 202012, '689', 'Core', '202012|2015|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(488, 'BUSA TMB US Info Sec', 2015, 'USD', 0.024750000000 , 202012, '714', 'Core', '202012|2015|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(489, 'BUSA TMB US Info Sec', 2014, 'USD', 78.465749999974 , 202012, '714', 'Core', '202012|2014|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(490, 'D&O', 2008, 'USD', 319192.859000034630 , 202012, '6', 'Core', '202012|2008|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(491, 'D&O', 2007, 'USD', 29698.421000000555 , 202012, '6', 'Core', '202012|2007|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(492, 'D&O', 2010, 'USD', 441.428500000002 , 202012, '6', 'Core', '202012|2010|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(493, 'D&O', 2009, 'USD', 1619.587499999994 , 202012, '6', 'Core', '202012|2009|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(494, 'D&O', 2003, 'USD', 20336.104999999981 , 202012, '6', 'Core', '202012|2003|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(495, 'DIN US Lawyers', 2011, 'USD', 79.760000000000 , 202012, '7', 'Core', '202012|2011|7|USD|Core', 'XL', 'Systemic cover - Clash'),

(496, 'EPL', 2008, 'USD', 2091.780000000000 , 202012, '8', 'Core', '202012|2008|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(497, 'EPL', 2007, 'USD', 702.462500000009 , 202012, '8', 'Core', '202012|2007|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(498, 'EPL', 2009, 'USD', 17.205500000000 , 202012, '8', 'Core', '202012|2009|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(499, 'Mid Market Lawyers', 2009, 'USD', 5674.670999999973 , 202012, '663', 'Core', '202012|2009|663|USD|Core', 'XL', 'Systemic cover - Clash'),

(500, 'PI-Ins Brokers exBLPT', 2008, 'USD', 6249.455999999999 , 202012, '14', 'Core', '202012|2008|14|USD|Core', 'XL', 'Systemic cover - Clash'),

(501, 'PI-Lawyers exBLPT', 2005, 'USD', 4.278500000000 , 202012, '15', 'Core', '202012|2005|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(502, 'PI-Lawyers exBLPT', 2012, 'USD', 69.379000000001 , 202012, '15', 'Core', '202012|2012|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(503, 'PI-Lawyers exBLPT', 2007, 'USD', 24858.933500000276 , 202012, '15', 'Core', '202012|2007|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(504, 'PI-Lawyers exBLPT', 2008, 'USD', 1036334.024499999400 , 202012, '15', 'Core', '202012|2008|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(505, 'PI-Lawyers exBLPT', 2010, 'USD', 15153.051499999827 , 202012, '15', 'Core', '202012|2010|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(506, 'PI-Lawyers exBLPT', 2004, 'USD', 34350.859999999404 , 202012, '15', 'Core', '202012|2004|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(507, 'PI-Lawyers exBLPT', 2006, 'USD', 512.787499999991 , 202012, '15', 'Core', '202012|2006|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(508, 'PI-Lawyers exBLPT', 2009, 'USD', 734410.836500000000 , 202012, '15', 'Core', '202012|2009|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(509, 'PI-Other exBLPT', 2010, 'USD', 7.375500000000 , 202012, '18', 'Core', '202012|2010|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(510, 'PI-Other exBLPT', 2007, 'USD', 23.726499999999 , 202012, '18', 'Core', '202012|2007|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(511, 'PI-Other exBLPT', 2008, 'USD', 54.953500000001 , 202012, '18', 'Core', '202012|2008|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(512, 'PI-Other exBLPT', 2009, 'USD', 6814.830499999807 , 202012, '18', 'Core', '202012|2009|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(513, 'PI-Other exBLPT', 2011, 'USD', 0.715000000000 , 202012, '18', 'Core', '202012|2011|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(514, 'Specialty (PT)', 2008, 'USD', 848870.775500000110 , 202012, '27', 'Core', '202012|2008|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(515, 'Specialty (PT)', 2007, 'USD', 662.002000000008 , 202012, '27', 'Core', '202012|2007|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(516, 'Specialty (PT)', 2006, 'USD', 91.260500000000 , 202012, '27', 'Core', '202012|2006|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(517, 'Specialty (PT)', 2011, 'USD', 54080.494500000088 , 202012, '27', 'Core', '202012|2011|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(518, 'Specialty (PT)', 2010, 'USD', 4527.183499999694 , 202012, '27', 'Core', '202012|2010|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(519, 'Specialty (PT)', 2009, 'USD', 107830.423500000150 , 202012, '27', 'Core', '202012|2009|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(520, 'TMB Large Risk Int', 2014, 'USD', 4.991250000000 , 202012, '712', 'Core', '202012|2014|712|USD|Core', 'XL', 'Systemic cover - Clash'),

(521, 'TMB UK Info Sec', 2014, 'USD', 5.494500000000 , 202012, '721', 'Core', '202012|2014|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(522, 'TMB UK Info Sec', 2015, 'USD', 77.335499999812 , 202012, '721', 'Core', '202012|2015|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(523, 'TMB UK Tech', 2006, 'USD', 38.555499999999 , 202012, '19', 'Core', '202012|2006|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(524, 'TMB UK Tech', 2008, 'USD', 722650.050000000000 , 202012, '19', 'Core', '202012|2008|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(525, 'TMB UK Tech', 2010, 'USD', 37621.958500000008 , 202012, '19', 'Core', '202012|2010|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(526, 'TMB UK Tech', 2007, 'USD', 111048.798499993980 , 202012, '19', 'Core', '202012|2007|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(527, 'UK', 2007, 'GBP', 238.789500000003 , 202012, '24', 'Core', '202012|2007|24|GBP|Core', 'XL', 'Systemic cover - Clash'),

(528, 'UK', 2006, 'EUR', 6849.536500000046 , 202012, '24', 'Core', '202012|2006|24|EUR|Core', 'XL', 'Systemic cover - Clash'),

(537, 'BUSA BBR Services MM', 2014, 'USD', 24.667499999749 , 202103, '732', 'Core', '202103|2014|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(538, 'BUSA EPL MM', 2007, 'USD', 8414.222000000067 , 202103, '681', 'Core', '202103|2007|681|USD|Core', 'XL', 'Systemic cover - Clash'),

(539, 'BUSA TMB US E&O', 2014, 'USD', 13.183500000000 , 202103, '689', 'Core', '202103|2014|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(540, 'BUSA TMB US E&O', 2015, 'USD', 0.008250000000 , 202103, '689', 'Core', '202103|2015|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(541, 'BUSA TMB US Info Sec', 2014, 'USD', 78.465749999974 , 202103, '714', 'Core', '202103|2014|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(542, 'BUSA TMB US Info Sec', 2015, 'USD', 0.024750000000 , 202103, '714', 'Core', '202103|2015|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(543, 'D&O', 2008, 'USD', 320099.526500038800 , 202103, '6', 'Core', '202103|2008|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(544, 'D&O', 2003, 'USD', 20336.109499999788 , 202103, '6', 'Core', '202103|2003|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(545, 'D&O', 2009, 'USD', 1619.605000000011 , 202103, '6', 'Core', '202103|2009|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(546, 'D&O', 2010, 'USD', 441.428500000002 , 202103, '6', 'Core', '202103|2010|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(547, 'D&O', 2007, 'USD', 29698.472999999765 , 202103, '6', 'Core', '202103|2007|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(548, 'DIN US Lawyers', 2011, 'USD', 79.760000000000 , 202103, '7', 'Core', '202103|2011|7|USD|Core', 'XL', 'Systemic cover - Clash'),

(549, 'EPL', 2007, 'USD', 702.454500000007 , 202103, '8', 'Core', '202103|2007|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(550, 'EPL', 2009, 'USD', 17.205500000000 , 202103, '8', 'Core', '202103|2009|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(551, 'EPL', 2008, 'USD', 2100.726000000000 , 202103, '8', 'Core', '202103|2008|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(552, 'Mid Market Lawyers', 2009, 'USD', 5674.672999999952 , 202103, '663', 'Core', '202103|2009|663|USD|Core', 'XL', 'Systemic cover - Clash'),

(553, 'PI-Ins Brokers exBLPT', 2008, 'USD', 4062.780000000000 , 202103, '14', 'Core', '202103|2008|14|USD|Core', 'XL', 'Systemic cover - Clash'),

(554, 'PI-Lawyers exBLPT', 2005, 'USD', 4.278500000000 , 202103, '15', 'Core', '202103|2005|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(555, 'PI-Lawyers exBLPT', 2006, 'USD', 512.807499999995 , 202103, '15', 'Core', '202103|2006|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(556, 'PI-Lawyers exBLPT', 2004, 'USD', 34350.879000001587 , 202103, '15', 'Core', '202103|2004|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(557, 'PI-Lawyers exBLPT', 2007, 'USD', 24858.965499999933 , 202103, '15', 'Core', '202103|2007|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(558, 'PI-Lawyers exBLPT', 2009, 'USD', 714051.953000000210 , 202103, '15', 'Core', '202103|2009|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(559, 'PI-Lawyers exBLPT', 2010, 'USD', 15152.998000000138 , 202103, '15', 'Core', '202103|2010|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(560, 'PI-Lawyers exBLPT', 2008, 'USD', 1040952.318999999200 , 202103, '15', 'Core', '202103|2008|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(561, 'PI-Lawyers exBLPT', 2012, 'USD', 69.378999999999 , 202103, '15', 'Core', '202103|2012|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(562, 'PI-Other exBLPT', 2009, 'USD', 6814.822500000009 , 202103, '18', 'Core', '202103|2009|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(563, 'PI-Other exBLPT', 2007, 'USD', 23.726500000000 , 202103, '18', 'Core', '202103|2007|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(564, 'PI-Other exBLPT', 2011, 'USD', 0.715000000000 , 202103, '18', 'Core', '202103|2011|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(565, 'PI-Other exBLPT', 2008, 'USD', 55.085500000000 , 202103, '18', 'Core', '202103|2008|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(566, 'PI-Other exBLPT', 2010, 'USD', 7.375500000000 , 202103, '18', 'Core', '202103|2010|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(567, 'Specialty (PT)', 2008, 'USD', 848870.771999999880 , 202103, '27', 'Core', '202103|2008|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(568, 'Specialty (PT)', 2010, 'USD', 4527.165999999619 , 202103, '27', 'Core', '202103|2010|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(569, 'Specialty (PT)', 2009, 'USD', 107830.471499999990 , 202103, '27', 'Core', '202103|2009|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(570, 'Specialty (PT)', 2011, 'USD', 54080.496500000125 , 202103, '27', 'Core', '202103|2011|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(571, 'Specialty (PT)', 2007, 'USD', 662.012000000002 , 202103, '27', 'Core', '202103|2007|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(572, 'Specialty (PT)', 2006, 'USD', 91.260500000000 , 202103, '27', 'Core', '202103|2006|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(573, 'TMB Large Risk Int', 2014, 'USD', 4.991250000000 , 202103, '712', 'Core', '202103|2014|712|USD|Core', 'XL', 'Systemic cover - Clash'),

(574, 'TMB UK Info Sec', 2014, 'USD', 5.494500000000 , 202103, '721', 'Core', '202103|2014|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(575, 'TMB UK Info Sec', 2015, 'USD', 77.335500000045 , 202103, '721', 'Core', '202103|2015|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(576, 'TMB UK Tech', 2006, 'USD', 38.555500000000 , 202103, '19', 'Core', '202103|2006|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(577, 'TMB UK Tech', 2008, 'USD', 704054.520000000000 , 202103, '19', 'Core', '202103|2008|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(578, 'TMB UK Tech', 2010, 'USD', 37617.822500000009 , 202103, '19', 'Core', '202103|2010|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(579, 'TMB UK Tech', 2007, 'USD', 111048.859999997540 , 202103, '19', 'Core', '202103|2007|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(580, 'UK', 2006, 'EUR', 6849.532499999972 , 202103, '24', 'Core', '202103|2006|24|EUR|Core', 'XL', 'Systemic cover - Clash'),

(581, 'UK', 2007, 'GBP', 238.789500000006 , 202103, '24', 'Core', '202103|2007|24|GBP|Core', 'XL', 'Systemic cover - Clash'),

(582, 'BBR Services (exc PE)', 2019, 'USD', 4523.209640740068 , 202106, '737', 'Core', '202106|2019|737|USD|Core', 'XL', 'Systemic cover - Clash'),

(583, 'BBR Services (exc PE)', 2018, 'USD', 195.523084580003 , 202106, '737', 'Core', '202106|2018|737|USD|Core', 'XL', 'Systemic cover - Clash'),

(584, 'BBR Services (exc PE)', 2020, 'USD', 488938.735445259600 , 202106, '737', 'Core', '202106|2020|737|USD|Core', 'XL', 'Systemic cover - Clash'),

(585, 'BBR Services Int (exc PE)', 2019, 'CAD', 21426.796571849984 , 202106, '742', 'Core', '202106|2019|742|CAD|Core', 'XL', 'Systemic cover - Clash'),

(586, 'BBR Services Int (exc PE)', 2018, 'EUR', 86864.048865540011 , 202106, '742', 'Core', '202106|2018|742|EUR|Core', 'XL', 'Systemic cover - Clash'),

(587, 'BBR Services Int (exc PE)', 2018, 'GBP', 1988.675840480020 , 202106, '742', 'Core', '202106|2018|742|GBP|Core', 'XL', 'Systemic cover - Clash'),

(588, 'BBR Services Int (exc PE)', 2020, 'GBP', 3813.913840050000 , 202106, '742', 'Core', '202106|2020|742|GBP|Core', 'XL', 'Systemic cover - Clash'),

(589, 'BBR Services Int (exc PE)', 2021, 'EUR', 636.976179450000 , 202106, '742', 'Core', '202106|2021|742|EUR|Core', 'XL', 'Systemic cover - Clash'),

(590, 'BBR Services Int (exc PE)', 2018, 'USD', 455.498045779997 , 202106, '742', 'Core', '202106|2018|742|USD|Core', 'XL', 'Systemic cover - Clash'),

(591, 'BBR Services Int (exc PE)', 2017, 'USD', 159.413317089991 , 202106, '742', 'Core', '202106|2017|742|USD|Core', 'XL', 'Systemic cover - Clash'),

(592, 'BBR Services PE', 2017, 'USD', 1532.233894110000 , 202106, '738', 'Core', '202106|2017|738|USD|Core', 'XL', 'Systemic cover - Clash'),

(593, 'BBR Services PE', 2018, 'USD', 6318.165464550004 , 202106, '738', 'Core', '202106|2018|738|USD|Core', 'XL', 'Systemic cover - Clash'),

(594, 'BBR Services PE', 2020, 'USD', 160.539173289995 , 202106, '738', 'Core', '202106|2020|738|USD|Core', 'XL', 'Systemic cover - Clash'),

(633, 'BUSA BBR Services MM', 2021, 'USD', 5159.501830059977 , 202106, '732', 'Core', '202106|2021|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(634, 'BUSA BBR Services MM', 2014, 'USD', 24.667499999749 , 202106, '732', 'Core', '202106|2014|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(635, 'BUSA BBR Services MM', 2019, 'USD', 37220.401338639200 , 202106, '732', 'Core', '202106|2019|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(636, 'BUSA BBR Services MM', 2020, 'USD', 106082.119864149950 , 202106, '732', 'Core', '202106|2020|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(637, 'BUSA BBR Services MM', 2018, 'USD', 13879.767034799792 , 202106, '732', 'Core', '202106|2018|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(638, 'BUSA BBR Services PE', 2019, 'USD', 167940.570247469940 , 202106, '731', 'Core', '202106|2019|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(639, 'BUSA BBR Services PE', 2021, 'USD', 8495.068817339994 , 202106, '731', 'Core', '202106|2021|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(640, 'BUSA BBR Services PE', 2020, 'USD', 50439.598904710000 , 202106, '731', 'Core', '202106|2020|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(641, 'BUSA BBR Services PE', 2018, 'USD', 38777.568515199979 , 202106, '731', 'Core', '202106|2018|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(642, 'BUSA EPL MM', 2007, 'USD', 8400.288499999791 , 202106, '681', 'Core', '202106|2007|681|USD|Core', 'XL', 'Systemic cover - Clash'),

(643, 'BUSA TMB PE', 2019, 'USD', 86393.577450440032 , 202106, '690', 'Core', '202106|2019|690|USD|Core', 'XL', 'Systemic cover - Clash'),

(644, 'BUSA TMB PE', 2018, 'USD', 24573.453797270078 , 202106, '690', 'Core', '202106|2018|690|USD|Core', 'XL', 'Systemic cover - Clash'),

(645, 'BUSA TMB PE', 2020, 'USD', 19620.736607250015 , 202106, '690', 'Core', '202106|2020|690|USD|Core', 'XL', 'Systemic cover - Clash'),

(646, 'BUSA TMB PE US Info Sec', 2019, 'USD', 291971.902573890290 , 202106, '723', 'Core', '202106|2019|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(647, 'BUSA TMB PE US Info Sec', 2018, 'USD', 117561.437318820100 , 202106, '723', 'Core', '202106|2018|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(648, 'BUSA TMB PE US Info Sec', 2020, 'USD', 85318.788665020082 , 202106, '723', 'Core', '202106|2020|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(649, 'BUSA TMB US E&O', 2019, 'USD', 569410.193360270930 , 202106, '689', 'Core', '202106|2019|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(650, 'BUSA TMB US E&O', 2014, 'USD', 13.183500000000 , 202106, '689', 'Core', '202106|2014|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(651, 'BUSA TMB US E&O', 2020, 'USD', 755650.069231320170 , 202106, '689', 'Core', '202106|2020|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(652, 'BUSA TMB US E&O', 2015, 'USD', 0.008250000000 , 202106, '689', 'Core', '202106|2015|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(653, 'BUSA TMB US Info Sec', 2020, 'USD', 16750.841448799998 , 202106, '714', 'Core', '202106|2020|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(654, 'BUSA TMB US Info Sec', 2019, 'USD', 3307421.577852499700 , 202106, '714', 'Core', '202106|2019|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(655, 'BUSA TMB US Info Sec', 2015, 'USD', 0.024750000000 , 202106, '714', 'Core', '202106|2015|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(656, 'BUSA TMB US Info Sec', 2014, 'USD', 78.465749999974 , 202106, '714', 'Core', '202106|2014|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(657, 'BUSA US InfoSec MM BBR', 2021, 'USD', 21547.407000870007 , 202106, '763', 'Core', '202106|2021|763|USD|Core', 'XL', 'Systemic cover - Clash'),

(658, 'BUSA US InfoSec MM BBR', 2018, 'USD', 466987.021711739710 , 202106, '763', 'Core', '202106|2018|763|USD|Core', 'XL', 'Systemic cover - Clash'),

(659, 'BUSA US InfoSec MM BBR', 2020, 'USD', 1994243.945419310600 , 202106, '763', 'Core', '202106|2020|763|USD|Core', 'XL', 'Systemic cover - Clash'),

(660, 'BUSA US InfoSec MM BBR', 2019, 'USD', 1654289.636207481900 , 202106, '763', 'Core', '202106|2019|763|USD|Core', 'XL', 'Systemic cover - Clash'),

(661, 'D&O', 2009, 'USD', 1616.882499999978 , 202106, '6', 'Core', '202106|2009|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(662, 'D&O', 2008, 'USD', 320525.336500030000 , 202106, '6', 'Core', '202106|2008|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(663, 'D&O', 2007, 'USD', 29649.254499999806 , 202106, '6', 'Core', '202106|2007|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(664, 'D&O', 2010, 'USD', 440.715500000006 , 202106, '6', 'Core', '202106|2010|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(665, 'D&O', 2003, 'USD', 20302.438999999780 , 202106, '6', 'Core', '202106|2003|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(666, 'DIN US Lawyers', 2011, 'USD', 79.619999999999 , 202106, '7', 'Core', '202106|2011|7|USD|Core', 'XL', 'Systemic cover - Clash'),

(667, 'EPL', 2009, 'USD', 17.179000000001 , 202106, '8', 'Core', '202106|2009|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(668, 'EPL', 2008, 'USD', 2116.944000000000 , 202106, '8', 'Core', '202106|2008|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(669, 'EPL', 2007, 'USD', 701.298999999999 , 202106, '8', 'Core', '202106|2007|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(670, 'International', 2020, 'CAD', 785.002014000000 , 202106, '10', 'Core', '202106|2020|10|CAD|Core', 'XL', 'Systemic cover - Clash'),

(671, 'Intl PE Regions', 2020, 'CAD', 750.363155550000 , 202106, '906', 'Core', '202106|2020|906|CAD|Core', 'XL', 'Systemic cover - Clash'),

(672, 'Mid Market Lawyers', 2009, 'USD', 5665.288499999791 , 202106, '663', 'Core', '202106|2009|663|USD|Core', 'XL', 'Systemic cover - Clash'),

(673, 'PE Media US', 2019, 'GBP', 766.140545700000 , 202106, '905', 'Core', '202106|2019|905|GBP|Core', 'XL', 'Systemic cover - Clash'),

(674, 'PI-Ins Brokers exBLPT', 2008, 'USD', 4153.002000000000 , 202106, '14', 'Core', '202106|2008|14|USD|Core', 'XL', 'Systemic cover - Clash'),

(675, 'PI-Lawyers exBLPT', 2004, 'USD', 34293.982499998994 , 202106, '15', 'Core', '202106|2004|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(676, 'PI-Lawyers exBLPT', 2010, 'USD', 15127.910499999533 , 202106, '15', 'Core', '202106|2010|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(677, 'PI-Lawyers exBLPT', 2005, 'USD', 4.266500000000 , 202106, '15', 'Core', '202106|2005|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(678, 'PI-Lawyers exBLPT', 2006, 'USD', 511.913499999995 , 202106, '15', 'Core', '202106|2006|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(679, 'PI-Lawyers exBLPT', 2008, 'USD', 1049407.071000000500 , 202106, '15', 'Core', '202106|2008|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(680, 'PI-Lawyers exBLPT', 2009, 'USD', 725904.063499999930 , 202106, '15', 'Core', '202106|2009|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(681, 'PI-Lawyers exBLPT', 2012, 'USD', 69.261999999999 , 202106, '15', 'Core', '202106|2012|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(682, 'PI-Lawyers exBLPT', 2007, 'USD', 24817.876499999315 , 202106, '15', 'Core', '202106|2007|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(683, 'PI-Other exBLPT', 2008, 'USD', 55.259499999999 , 202106, '18', 'Core', '202106|2008|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(684, 'PI-Other exBLPT', 2009, 'USD', 6803.565000000061 , 202106, '18', 'Core', '202106|2009|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(685, 'PI-Other exBLPT', 2011, 'USD', 0.725000000000 , 202106, '18', 'Core', '202106|2011|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(686, 'PI-Other exBLPT', 2010, 'USD', 7.345500000000 , 202106, '18', 'Core', '202106|2010|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(687, 'PI-Other exBLPT', 2007, 'USD', 23.711499999999 , 202106, '18', 'Core', '202106|2007|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(688, 'Specialty (PT)', 2006, 'USD', 91.101000000001 , 202106, '27', 'Core', '202106|2006|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(689, 'Specialty (PT)', 2007, 'USD', 660.935500000007 , 202106, '27', 'Core', '202106|2007|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(690, 'Specialty (PT)', 2011, 'USD', 54073.634000000136 , 202106, '27', 'Core', '202106|2011|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(691, 'Specialty (PT)', 2008, 'USD', 848081.715499999700 , 202106, '27', 'Core', '202106|2008|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(692, 'Specialty (PT)', 2010, 'USD', 4519.667999999714 , 202106, '27', 'Core', '202106|2010|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(693, 'Specialty (PT)', 2009, 'USD', 107816.101000000140 , 202106, '27', 'Core', '202106|2009|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(694, 'TMB INT InfoSec MM BBR', 2018, 'CAD', 2153.806914700021 , 202106, '769', 'Core', '202106|2018|769|CAD|Core', 'XL', 'Systemic cover - Clash'),

(695, 'TMB INT InfoSec MM BBR', 2020, 'GBP', 8087.870990250001 , 202106, '769', 'Core', '202106|2020|769|GBP|Core', 'XL', 'Systemic cover - Clash'),

(696, 'TMB INT InfoSec MM BBR', 2018, 'EUR', 3028.731358089950 , 202106, '769', 'Core', '202106|2018|769|EUR|Core', 'XL', 'Systemic cover - Clash'),

(697, 'TMB INT InfoSec MM BBR', 2020, 'USD', 19153.652475600007 , 202106, '769', 'Core', '202106|2020|769|USD|Core', 'XL', 'Systemic cover - Clash'),

(698, 'TMB INT InfoSec MM BBR', 2019, 'CAD', 154675.065489929870 , 202106, '769', 'Core', '202106|2019|769|CAD|Core', 'XL', 'Systemic cover - Clash'),

(699, 'TMB Large Risk Int', 2020, 'CAD', 57807.480229590088 , 202106, '712', 'Core', '202106|2020|712|CAD|Core', 'XL', 'Systemic cover - Clash'),

(700, 'TMB Large Risk Int', 2014, 'USD', 4.991250000000 , 202106, '712', 'Core', '202106|2014|712|USD|Core', 'XL', 'Systemic cover - Clash'),

(701, 'TMB Large Risk Int', 2020, 'USD', 1615.642129910062 , 202106, '712', 'Core', '202106|2020|712|USD|Core', 'XL', 'Systemic cover - Clash'),

(702, 'TMB LargeRisk Int InfoSec', 2020, 'EUR', 178308.328488300000 , 202106, '744', 'Core', '202106|2020|744|EUR|Core', 'XL', 'Systemic cover - Clash'),

(703, 'TMB LargeRisk Int InfoSec', 2019, 'GBP', 790344.008948299800 , 202106, '744', 'Core', '202106|2019|744|GBP|Core', 'XL', 'Systemic cover - Clash'),

(704, 'TMB LargeRisk Int InfoSec', 2020, 'USD', 345556.468481850050 , 202106, '744', 'Core', '202106|2020|744|USD|Core', 'XL', 'Systemic cover - Clash'),

(705, 'TMB UK Info Sec', 2014, 'USD', 5.494500000000 , 202106, '721', 'Core', '202106|2014|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(706, 'TMB UK Info Sec', 2020, 'USD', 1126459.131764260400 , 202106, '721', 'Core', '202106|2020|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(707, 'TMB UK Info Sec', 2019, 'USD', 388359.990274899870 , 202106, '721', 'Core', '202106|2019|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(708, 'TMB UK Info Sec', 2015, 'USD', 77.335500000045 , 202106, '721', 'Core', '202106|2015|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(709, 'TMB UK InfoSec MM BBR', 2020, 'USD', 1911362.992788390000 , 202106, '765', 'Core', '202106|2020|765|USD|Core', 'XL', 'Systemic cover - Clash'),

(710, 'TMB UK InfoSec MM BBR', 2018, 'USD', 91033.699980049860 , 202106, '765', 'Core', '202106|2018|765|USD|Core', 'XL', 'Systemic cover - Clash'),

(711, 'TMB UK InfoSec MM BBR', 2019, 'USD', 3395209.430303090300 , 202106, '765', 'Core', '202106|2019|765|USD|Core', 'XL', 'Systemic cover - Clash'),

(712, 'TMB UK Tech', 2007, 'USD', 110865.005999993530 , 202106, '19', 'Core', '202106|2007|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(713, 'TMB UK Tech', 2019, 'USD', 55.158539720001 , 202106, '19', 'Core', '202106|2019|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(714, 'TMB UK Tech', 2020, 'USD', 64.604335450002 , 202106, '19', 'Core', '202106|2020|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(715, 'TMB UK Tech', 2008, 'USD', 707800.200000000070 , 202106, '19', 'Core', '202106|2008|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(716, 'TMB UK Tech', 2006, 'USD', 38.478000000000 , 202106, '19', 'Core', '202106|2006|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(717, 'TMB UK Tech', 2018, 'USD', 15.374459710000 , 202106, '19', 'Core', '202106|2018|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(718, 'TMB UK Tech', 2010, 'USD', 37618.487999999954 , 202106, '19', 'Core', '202106|2010|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(719, 'UK', 2007, 'GBP', 238.396500000003 , 202106, '24', 'Core', '202106|2007|24|GBP|Core', 'XL', 'Systemic cover - Clash'),

(720, 'UK', 2006, 'EUR', 6838.207499999786 , 202106, '24', 'Core', '202106|2006|24|EUR|Core', 'XL', 'Systemic cover - Clash'),

(721, 'US PE Londo', 2020, 'USD', 35.435764200000 , 202106, '25', 'Core', '202106|2020|25|USD|Core', 'XL', 'Systemic cover - Clash'),

(722, 'US PE Londo', 2017, 'USD', 1267.533084009992 , 202106, '25', 'Core', '202106|2017|25|USD|Core', 'XL', 'Systemic cover - Clash'),

(723, 'US PE Londo', 2018, 'USD', 15269.717169899996 , 202106, '25', 'Core', '202106|2018|25|USD|Core', 'XL', 'Systemic cover - Clash'),

(724, 'BBR Services (exc PE)', 2020, 'USD', 31754.704967330443 , 202109, '737', 'Core', '202109|2020|737|USD|Core', 'XL', 'Systemic cover - Clash'),

(725, 'BBR Services (exc PE)', 2018, 'USD', 241.760745750005 , 202109, '737', 'Core', '202109|2018|737|USD|Core', 'XL', 'Systemic cover - Clash'),

(726, 'BBR Services (exc PE)', 2019, 'USD', 5543.652557709895 , 202109, '737', 'Core', '202109|2019|737|USD|Core', 'XL', 'Systemic cover - Clash'),

(727, 'BBR Services Int (exc PE)', 2018, 'EUR', 449.942809939988 , 202109, '742', 'Core', '202109|2018|742|EUR|Core', 'XL', 'Systemic cover - Clash'),

(728, 'BBR Services Int (exc PE)', 2019, 'CAD', 26606.173616999993 , 202109, '742', 'Core', '202109|2019|742|CAD|Core', 'XL', 'Systemic cover - Clash'),

(729, 'BBR Services Int (exc PE)', 2021, 'EUR', 10504.548678600000 , 202109, '742', 'Core', '202109|2021|742|EUR|Core', 'XL', 'Systemic cover - Clash'),

(730, 'BBR Services Int (exc PE)', 2018, 'GBP', 2458.781293279957 , 202109, '742', 'Core', '202109|2018|742|GBP|Core', 'XL', 'Systemic cover - Clash'),

(731, 'BBR Services Int (exc PE)', 2020, 'GBP', 4735.825123950001 , 202109, '742', 'Core', '202109|2020|742|GBP|Core', 'XL', 'Systemic cover - Clash'),

(732, 'BBR Services Int (exc PE)', 2020, 'USD', 544.319970800000 , 202109, '742', 'Core', '202109|2020|742|USD|Core', 'XL', 'Systemic cover - Clash'),

(733, 'BBR Services Int (exc PE)', 2018, 'USD', 563.180000350003 , 202109, '742', 'Core', '202109|2018|742|USD|Core', 'XL', 'Systemic cover - Clash'),

(734, 'BBR Services Int (exc PE)', 2017, 'USD', 197.107456600002 , 202109, '742', 'Core', '202109|2017|742|USD|Core', 'XL', 'Systemic cover - Clash'),

(735, 'BBR Services PE', 2017, 'USD', 1902.614488279999 , 202109, '738', 'Core', '202109|2017|738|USD|Core', 'XL', 'Systemic cover - Clash'),

(736, 'BBR Services PE', 2018, 'USD', 7845.408897749996 , 202109, '738', 'Core', '202109|2018|738|USD|Core', 'XL', 'Systemic cover - Clash'),

(737, 'BBR Services PE', 2020, 'USD', 6382.223983050004 , 202109, '738', 'Core', '202109|2020|738|USD|Core', 'XL', 'Systemic cover - Clash'),

(774, 'BUSA BBR Services MM', 2021, 'USD', 125173.102537990000 , 202109, '732', 'Core', '202109|2021|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(775, 'BUSA BBR Services MM', 2018, 'USD', 19638.359416819643 , 202109, '732', 'Core', '202109|2018|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(776, 'BUSA BBR Services MM', 2019, 'USD', 49710.988006590400 , 202109, '732', 'Core', '202109|2019|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(777, 'BUSA BBR Services MM', 2014, 'USD', 24.667499999749 , 202109, '732', 'Core', '202109|2014|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(778, 'BUSA BBR Services MM', 2020, 'USD', 1507711.244501390000 , 202109, '732', 'Core', '202109|2020|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(779, 'BUSA BBR Services PE', 2018, 'USD', 19018.911750090017 , 202109, '731', 'Core', '202109|2018|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(780, 'BUSA BBR Services PE', 2020, 'USD', 108722.629812289960 , 202109, '731', 'Core', '202109|2020|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(781, 'BUSA BBR Services PE', 2021, 'USD', 55644.846849090000 , 202109, '731', 'Core', '202109|2021|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(782, 'BUSA BBR Services PE', 2019, 'USD', 151079.685276029980 , 202109, '731', 'Core', '202109|2019|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(783, 'BUSA EPL MM', 2007, 'USD', 8404.004000000190 , 202109, '681', 'Core', '202109|2007|681|USD|Core', 'XL', 'Systemic cover - Clash'),

(784, 'BUSA TMB PE', 2019, 'USD', 93165.887613250059 , 202109, '690', 'Core', '202109|2019|690|USD|Core', 'XL', 'Systemic cover - Clash'),

(785, 'BUSA TMB PE', 2020, 'USD', 76899.207840750000 , 202109, '690', 'Core', '202109|2020|690|USD|Core', 'XL', 'Systemic cover - Clash'),

(786, 'BUSA TMB PE', 2018, 'USD', 30382.352081419434 , 202109, '690', 'Core', '202109|2018|690|USD|Core', 'XL', 'Systemic cover - Clash'),

(787, 'BUSA TMB PE US Info Sec', 2019, 'USD', 529402.837816680080 , 202109, '723', 'Core', '202109|2019|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(788, 'BUSA TMB PE US Info Sec', 2021, 'USD', 17225.399549700000 , 202109, '723', 'Core', '202109|2021|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(789, 'BUSA TMB PE US Info Sec', 2018, 'USD', 72641.367562409900 , 202109, '723', 'Core', '202109|2018|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(790, 'BUSA TMB PE US Info Sec', 2020, 'USD', 153529.672081990050 , 202109, '723', 'Core', '202109|2020|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(791, 'BUSA TMB US E&O', 2019, 'USD', 683493.009898020000 , 202109, '689', 'Core', '202109|2019|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(792, 'BUSA TMB US E&O', 2015, 'USD', 0.008250000000 , 202109, '689', 'Core', '202109|2015|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(793, 'BUSA TMB US E&O', 2020, 'USD', 602752.932826490140 , 202109, '689', 'Core', '202109|2020|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(794, 'BUSA TMB US E&O', 2014, 'USD', 13.183500000000 , 202109, '689', 'Core', '202109|2014|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(795, 'BUSA TMB US Info Sec', 2019, 'USD', 3506925.211922180400 , 202109, '714', 'Core', '202109|2019|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(796, 'BUSA TMB US Info Sec', 2020, 'USD', 235779.382198299980 , 202109, '714', 'Core', '202109|2020|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(797, 'BUSA TMB US Info Sec', 2015, 'USD', 0.024750000000 , 202109, '714', 'Core', '202109|2015|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(798, 'BUSA TMB US Info Sec', 2014, 'USD', 78.465749999974 , 202109, '714', 'Core', '202109|2014|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(799, 'BUSA TMB US Info Sec', 2018, 'USD', 3625.416376489971 , 202109, '714', 'Core', '202109|2018|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(800, 'BUSA US InfoSec MM BBR', 2018, 'USD', 240934.386094029060 , 202109, '763', 'Core', '202109|2018|763|USD|Core', 'XL', 'Systemic cover - Clash'),

(801, 'BUSA US InfoSec MM BBR', 2021, 'USD', 55888.202190279975 , 202109, '763', 'Core', '202109|2021|763|USD|Core', 'XL', 'Systemic cover - Clash'),

(802, 'BUSA US InfoSec MM BBR', 2019, 'USD', 3153442.978113200500 , 202109, '763', 'Core', '202109|2019|763|USD|Core', 'XL', 'Systemic cover - Clash'),

(803, 'BUSA US InfoSec MM BBR', 2020, 'USD', 2291488.179539940300 , 202109, '763', 'Core', '202109|2020|763|USD|Core', 'XL', 'Systemic cover - Clash'),

(804, 'D&O', 2003, 'USD', 20311.438499999700 , 202109, '6', 'Core', '202109|2003|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(805, 'D&O', 2008, 'USD', 321364.535500030960 , 202109, '6', 'Core', '202109|2008|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(806, 'D&O', 2007, 'USD', 29662.412499999627 , 202109, '6', 'Core', '202109|2007|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(807, 'D&O', 2009, 'USD', 1617.584499999997 , 202109, '6', 'Core', '202109|2009|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(808, 'D&O', 2010, 'USD', 440.887499999997 , 202109, '6', 'Core', '202109|2010|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(809, 'DIN US Lawyers', 2011, 'USD', 79.650000000000 , 202109, '7', 'Core', '202109|2011|7|USD|Core', 'XL', 'Systemic cover - Clash'),

(810, 'EPL', 2007, 'USD', 701.607000000018 , 202109, '8', 'Core', '202109|2007|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(811, 'EPL', 2009, 'USD', 17.189000000001 , 202109, '8', 'Core', '202109|2009|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(812, 'EPL', 2008, 'USD', 2125.782000000000 , 202109, '8', 'Core', '202109|2008|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(813, 'International', 2020, 'CAD', 1195.144741350003 , 202109, '10', 'Core', '202109|2020|10|CAD|Core', 'XL', 'Systemic cover - Clash'),

(814, 'Intl PE Regions', 2021, 'USD', 6481.214270149998 , 202109, '906', 'Core', '202109|2021|906|USD|Core', 'XL', 'Systemic cover - Clash'),

(815, 'Intl PE Regions', 2020, 'CAD', 5879.079534749995 , 202109, '906', 'Core', '202109|2020|906|CAD|Core', 'XL', 'Systemic cover - Clash'),

(816, 'Mid Market Lawyers', 2009, 'USD', 5667.800999999978 , 202109, '663', 'Core', '202109|2009|663|USD|Core', 'XL', 'Systemic cover - Clash'),

(817, 'PE Media US', 2019, 'GBP', 951.343901099999 , 202109, '905', 'Core', '202109|2019|905|GBP|Core', 'XL', 'Systemic cover - Clash'),

(818, 'PI-Ins Brokers exBLPT', 2008, 'USD', 4170.330000000000 , 202109, '14', 'Core', '202109|2008|14|USD|Core', 'XL', 'Systemic cover - Clash'),

(819, 'PI-Lawyers exBLPT', 2009, 'USD', 724130.379499999810 , 202109, '15', 'Core', '202109|2009|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(820, 'PI-Lawyers exBLPT', 2004, 'USD', 34309.193499999121 , 202109, '15', 'Core', '202109|2004|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(821, 'PI-Lawyers exBLPT', 2010, 'USD', 15134.629000000423 , 202109, '15', 'Core', '202109|2010|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(822, 'PI-Lawyers exBLPT', 2007, 'USD', 24828.865500000771 , 202109, '15', 'Core', '202109|2007|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(823, 'PI-Lawyers exBLPT', 2008, 'USD', 1054079.707499999600 , 202109, '15', 'Core', '202109|2008|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(824, 'PI-Lawyers exBLPT', 2012, 'USD', 69.300999999999 , 202109, '15', 'Core', '202109|2012|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(825, 'PI-Lawyers exBLPT', 2005, 'USD', 4.256500000000 , 202109, '15', 'Core', '202109|2005|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(826, 'PI-Lawyers exBLPT', 2006, 'USD', 512.175500000012 , 202109, '15', 'Core', '202109|2006|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(827, 'PI-Other exBLPT', 2010, 'USD', 7.383000000000 , 202109, '18', 'Core', '202109|2010|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(828, 'PI-Other exBLPT', 2011, 'USD', 0.707500000000 , 202109, '18', 'Core', '202109|2011|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(829, 'PI-Other exBLPT', 2008, 'USD', 55.416500000000 , 202109, '18', 'Core', '202109|2008|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(830, 'PI-Other exBLPT', 2007, 'USD', 23.716000000000 , 202109, '18', 'Core', '202109|2007|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(831, 'PI-Other exBLPT', 2009, 'USD', 6806.598500000080 , 202109, '18', 'Core', '202109|2009|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(832, 'Specialty (PT)', 2011, 'USD', 54070.757000000158 , 202109, '27', 'Core', '202109|2011|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(833, 'Specialty (PT)', 2009, 'USD', 107782.087000000060 , 202109, '27', 'Core', '202109|2009|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(834, 'Specialty (PT)', 2010, 'USD', 4521.693499999936 , 202109, '27', 'Core', '202109|2010|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(835, 'Specialty (PT)', 2006, 'USD', 91.133999999998 , 202109, '27', 'Core', '202109|2006|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(836, 'Specialty (PT)', 2007, 'USD', 661.211500000005 , 202109, '27', 'Core', '202109|2007|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(837, 'Specialty (PT)', 2008, 'USD', 848006.500999999810 , 202109, '27', 'Core', '202109|2008|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(838, 'TMB INT InfoSec MM BBR', 2019, 'GBP', 228857.931584940000 , 202109, '769', 'Core', '202109|2019|769|GBP|Core', 'XL', 'Systemic cover - Clash'),

(839, 'TMB INT InfoSec MM BBR', 2020, 'EUR', 32272.438343849997 , 202109, '769', 'Core', '202109|2020|769|EUR|Core', 'XL', 'Systemic cover - Clash'),

(840, 'TMB INT InfoSec MM BBR', 2021, 'USD', 7933.617499500002 , 202109, '769', 'Core', '202109|2021|769|USD|Core', 'XL', 'Systemic cover - Clash'),

(841, 'TMB INT InfoSec MM BBR', 2019, 'CAD', 186601.146022530270 , 202109, '769', 'Core', '202109|2019|769|CAD|Core', 'XL', 'Systemic cover - Clash'),

(842, 'TMB INT InfoSec MM BBR', 2020, 'USD', 23783.547944250000 , 202109, '769', 'Core', '202109|2020|769|USD|Core', 'XL', 'Systemic cover - Clash'),

(843, 'TMB INT InfoSec MM BBR', 2018, 'EUR', 78779.070091710077 , 202109, '769', 'Core', '202109|2018|769|EUR|Core', 'XL', 'Systemic cover - Clash'),

(844, 'TMB INT InfoSec MM BBR', 2020, 'GBP', 10466.716658849993 , 202109, '769', 'Core', '202109|2020|769|GBP|Core', 'XL', 'Systemic cover - Clash'),

(845, 'TMB INT InfoSec MM BBR', 2018, 'CAD', 2662.948801430059 , 202109, '769', 'Core', '202109|2018|769|CAD|Core', 'XL', 'Systemic cover - Clash'),

(846, 'TMB Large Risk Int', 2014, 'USD', 4.991250000000 , 202109, '712', 'Core', '202109|2014|712|USD|Core', 'XL', 'Systemic cover - Clash'),

(847, 'TMB Large Risk Int', 2020, 'USD', 1997.566773889994 , 202109, '712', 'Core', '202109|2020|712|USD|Core', 'XL', 'Systemic cover - Clash'),

(848, 'TMB Large Risk Int', 2020, 'CAD', 71222.159392922185 , 202109, '712', 'Core', '202109|2020|712|CAD|Core', 'XL', 'Systemic cover - Clash'),

(849, 'TMB LargeRisk Int InfoSec', 2018, 'GBP', 565.374175869991 , 202109, '744', 'Core', '202109|2018|744|GBP|Core', 'XL', 'Systemic cover - Clash'),

(850, 'TMB LargeRisk Int InfoSec', 2019, 'GBP', 778182.241251040000 , 202109, '744', 'Core', '202109|2019|744|GBP|Core', 'XL', 'Systemic cover - Clash'),

(851, 'TMB LargeRisk Int InfoSec', 2020, 'USD', 432682.995133799850 , 202109, '744', 'Core', '202109|2020|744|USD|Core', 'XL', 'Systemic cover - Clash'),

(852, 'TMB LargeRisk Int InfoSec', 2020, 'EUR', 248112.203004000000 , 202109, '744', 'Core', '202109|2020|744|EUR|Core', 'XL', 'Systemic cover - Clash'),

(853, 'TMB UK Info Sec', 2015, 'USD', 77.335500000045 , 202109, '721', 'Core', '202109|2015|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(854, 'TMB UK Info Sec', 2020, 'USD', 1334830.572995790300 , 202109, '721', 'Core', '202109|2020|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(855, 'TMB UK Info Sec', 2014, 'USD', 5.494500000000 , 202109, '721', 'Core', '202109|2014|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(856, 'TMB UK Info Sec', 2018, 'USD', 46488.774581070291 , 202109, '721', 'Core', '202109|2018|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(857, 'TMB UK Info Sec', 2019, 'USD', 269863.426720180080 , 202109, '721', 'Core', '202109|2019|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(858, 'TMB UK InfoSec MM BBR', 2019, 'USD', 2950446.490016098100 , 202109, '765', 'Core', '202109|2019|765|USD|Core', 'XL', 'Systemic cover - Clash'),

(859, 'TMB UK InfoSec MM BBR', 2020, 'USD', 4238204.601243261200 , 202109, '765', 'Core', '202109|2020|765|USD|Core', 'XL', 'Systemic cover - Clash'),

(860, 'TMB UK InfoSec MM BBR', 2018, 'USD', 93643.905258930055 , 202109, '765', 'Core', '202109|2018|765|USD|Core', 'XL', 'Systemic cover - Clash'),

(861, 'TMB UK Tech', 2019, 'USD', 68.194231699998 , 202109, '19', 'Core', '202109|2019|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(862, 'TMB UK Tech', 2008, 'USD', 704005.878000000000 , 202109, '19', 'Core', '202109|2008|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(863, 'TMB UK Tech', 2007, 'USD', 110914.025499992070 , 202109, '19', 'Core', '202109|2007|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(864, 'TMB UK Tech', 2018, 'USD', 19.013386040000 , 202109, '19', 'Core', '202109|2018|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(865, 'TMB UK Tech', 2006, 'USD', 38.510000000000 , 202109, '19', 'Core', '202109|2006|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(866, 'TMB UK Tech', 2010, 'USD', 37629.253499999992 , 202109, '19', 'Core', '202109|2010|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(867, 'UK', 2006, 'EUR', 6841.250499999966 , 202109, '24', 'Core', '202109|2006|24|EUR|Core', 'XL', 'Systemic cover - Clash'),

(868, 'UK', 2007, 'GBP', 238.502499999999 , 202109, '24', 'Core', '202109|2007|24|GBP|Core', 'XL', 'Systemic cover - Clash'),

(869, 'US PE Londo', 2017, 'USD', 1571.729303459993 , 202109, '25', 'Core', '202109|2017|25|USD|Core', 'XL', 'Systemic cover - Clash'),

(870, 'US PE Londo', 2019, 'USD', 451.812490650000 , 202109, '25', 'Core', '202109|2019|25|USD|Core', 'XL', 'Systemic cover - Clash'),

(871, 'US PE Londo', 2020, 'USD', 3544.456445030000 , 202109, '25', 'Core', '202109|2020|25|USD|Core', 'XL', 'Systemic cover - Clash'),

(872, 'US PE Londo', 2018, 'USD', 18961.071132600002 , 202109, '25', 'Core', '202109|2018|25|USD|Core', 'XL', 'Systemic cover - Clash'),

(873, 'BBR Services (exc PE)', 2019, 'USD', 4248255.391447400700 , 202112, '737', 'Core', '202112|2019|737|USD|Core', 'XL', 'Systemic cover - Clash'),

(874, 'BBR Services Int (exc PE)', 2021, 'EUR', 7514.986119750003 , 202112, '742', 'Core', '202112|2021|742|EUR|Core', 'XL', 'Systemic cover - Clash'),

(875, 'BBR Services Int (exc PE)', 2019, 'CAD', 15302.888364150000 , 202112, '742', 'Core', '202112|2019|742|CAD|Core', 'XL', 'Systemic cover - Clash'),

(876, 'BBR Services Int (exc PE)', 2020, 'GBP', 2713.681355849998 , 202112, '742', 'Core', '202112|2020|742|GBP|Core', 'XL', 'Systemic cover - Clash'),

(877, 'BBR Services Int PE', 2020, 'CAD', 2897.754213150001 , 202112, '741', 'Core', '202112|2020|741|CAD|Core', 'XL', 'Systemic cover - Clash'),

(878, 'BBR Services PE', 2017, 'USD', 1090.195775030000 , 202112, '738', 'Core', '202112|2017|738|USD|Core', 'XL', 'Systemic cover - Clash'),

(879, 'BBR Services PE', 2020, 'USD', 3752.093443950002 , 202112, '738', 'Core', '202112|2020|738|USD|Core', 'XL', 'Systemic cover - Clash'),

(880, 'BBR Services PE', 2018, 'USD', 4495.505027849995 , 202112, '738', 'Core', '202112|2018|738|USD|Core', 'XL', 'Systemic cover - Clash'),

(915, 'BUSA BBR Services MM', 2020, 'USD', 54684.426490899990 , 202112, '732', 'Core', '202112|2020|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(916, 'BUSA BBR Services MM', 2014, 'USD', 24.667499999749 , 202112, '732', 'Core', '202112|2014|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(917, 'BUSA BBR Services MM', 2021, 'USD', 30862.436687390029 , 202112, '732', 'Core', '202112|2021|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(918, 'BUSA BBR Services PE', 2018, 'USD', 7158.953548140009 , 202112, '731', 'Core', '202112|2018|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(919, 'BUSA BBR Services PE', 2021, 'USD', 9000.796190319998 , 202112, '731', 'Core', '202112|2021|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(920, 'BUSA BBR Services PE', 2020, 'USD', 75623.216434910020 , 202112, '731', 'Core', '202112|2020|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(921, 'BUSA BBR Services PE', 2019, 'USD', 72308.100310079870 , 202112, '731', 'Core', '202112|2019|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(922, 'BUSA EPL MM', 2007, 'USD', 8404.185499999905 , 202112, '681', 'Core', '202112|2007|681|USD|Core', 'XL', 'Systemic cover - Clash'),

(923, 'BUSA Healthcare MM', 2016, 'USD', 253843.065592000030 , 202112, '683', 'Core', '202112|2016|683|USD|Core', 'XL', 'Systemic cover - Clash'),

(924, 'BUSA Healthcare MM', 2018, 'USD', 11115.560512000000 , 202112, '683', 'Core', '202112|2018|683|USD|Core', 'XL', 'Systemic cover - Clash'),

(925, 'BUSA Healthcare MM', 2017, 'USD', 28444.512004000004 , 202112, '683', 'Core', '202112|2017|683|USD|Core', 'XL', 'Systemic cover - Clash'),

(926, 'BUSA Misc Med PE', 2019, 'USD', 5956.888420000000 , 202112, '716', 'Core', '202112|2019|716|USD|Core', 'XL', 'Systemic cover - Clash'),

(927, 'BUSA TMB PE', 2019, 'USD', 51310.764314499975 , 202112, '690', 'Core', '202112|2019|690|USD|Core', 'XL', 'Systemic cover - Clash'),

(928, 'BUSA TMB PE', 2020, 'USD', 26978.355408149990 , 202112, '690', 'Core', '202112|2020|690|USD|Core', 'XL', 'Systemic cover - Clash'),

(929, 'BUSA TMB PE US Info Sec', 2019, 'USD', 277522.095494100360 , 202112, '723', 'Core', '202112|2019|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(930, 'BUSA TMB PE US Info Sec', 2020, 'USD', 96366.909326950088 , 202112, '723', 'Core', '202112|2020|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(931, 'BUSA TMB PE US Info Sec', 2018, 'USD', 30268.912607810053 , 202112, '723', 'Core', '202112|2018|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(932, 'BUSA TMB PE US Info Sec', 2021, 'USD', 22127.404807840008 , 202112, '723', 'Core', '202112|2021|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(933, 'BUSA TMB US E&O', 2015, 'USD', 0.008250000000 , 202112, '689', 'Core', '202112|2015|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(934, 'BUSA TMB US E&O', 2014, 'USD', 13.183500000000 , 202112, '689', 'Core', '202112|2014|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(935, 'BUSA TMB US E&O', 2020, 'USD', 252952.579904778860 , 202112, '689', 'Core', '202112|2020|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(936, 'BUSA TMB US E&O', 2019, 'USD', 380985.864662969480 , 202112, '689', 'Core', '202112|2019|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(937, 'BUSA TMB US Info Sec', 2014, 'USD', 78.465749999974 , 202112, '714', 'Core', '202112|2014|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(938, 'BUSA TMB US Info Sec', 2019, 'USD', 1102370.370823019700 , 202112, '714', 'Core', '202112|2019|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(939, 'BUSA TMB US Info Sec', 2020, 'USD', 642910.841099638490 , 202112, '714', 'Core', '202112|2020|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(940, 'BUSA TMB US Info Sec', 2015, 'USD', 0.024750000000 , 202112, '714', 'Core', '202112|2015|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(941, 'BUSA US InfoSec MM BBR', 2021, 'USD', 28074.203703690000 , 202112, '763', 'Core', '202112|2021|763|USD|Core', 'XL', 'Systemic cover - Clash'),

(942, 'BUSA US InfoSec MM BBR', 2020, 'USD', 2927842.113523447900 , 202112, '763', 'Core', '202112|2020|763|USD|Core', 'XL', 'Systemic cover - Clash'),

(943, 'BUSA US InfoSec MM BBR', 2019, 'USD', 2266837.580725224700 , 202112, '763', 'Core', '202112|2019|763|USD|Core', 'XL', 'Systemic cover - Clash'),

(944, 'D&O', 2007, 'USD', 29662.994000000414 , 202112, '6', 'Core', '202112|2007|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(945, 'D&O', 2010, 'USD', 440.923000000003 , 202112, '6', 'Core', '202112|2010|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(946, 'D&O', 2009, 'USD', 1617.603000000032 , 202112, '6', 'Core', '202112|2009|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(947, 'D&O', 2020, 'USD', 81.646172000000 , 202112, '6', 'Core', '202112|2020|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(948, 'D&O', 2008, 'USD', 315303.136000033470 , 202112, '6', 'Core', '202112|2008|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(949, 'D&O', 2003, 'USD', 20311.877500000875 , 202112, '6', 'Core', '202112|2003|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(950, 'D&O', 2015, 'USD', 29784.460667999996 , 202112, '6', 'Core', '202112|2015|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(951, 'D&O', 2016, 'USD', 668161.563032000000 , 202112, '6', 'Core', '202112|2016|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(952, 'D&O', 2019, 'USD', 446.767836000000 , 202112, '6', 'Core', '202112|2019|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(953, 'DIN US Lawyers', 2011, 'USD', 79.660000000000 , 202112, '7', 'Core', '202112|2011|7|USD|Core', 'XL', 'Systemic cover - Clash'),

(954, 'EPL', 2007, 'USD', 701.618999999992 , 202112, '8', 'Core', '202112|2007|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(955, 'EPL', 2009, 'USD', 17.199000000000 , 202112, '8', 'Core', '202112|2009|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(956, 'EPL', 2008, 'USD', 2065.908000000000 , 202112, '8', 'Core', '202112|2008|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(957, 'Healthcare-Hospitals', 2016, 'USD', 655.854600000000 , 202112, '756', 'Core', '202112|2016|756|USD|Core', 'XL', 'Systemic cover - Clash'),

(958, 'Healthcare-Hospitals', 2015, 'USD', 1319.452148000000 , 202112, '756', 'Core', '202112|2015|756|USD|Core', 'XL', 'Systemic cover - Clash'),

(959, 'International', 2020, 'CAD', 2033.478499049999 , 202112, '10', 'Core', '202112|2020|10|CAD|Core', 'XL', 'Systemic cover - Clash'),

(960, 'International ML', 2020, 'GBP', 590.558224000000 , 202112, '762', 'Core', '202112|2020|762|GBP|Core', 'XL', 'Systemic cover - Clash'),

(961, 'International ML', 2019, 'CAD', 0.060688000000 , 202112, '762', 'Core', '202112|2019|762|CAD|Core', 'XL', 'Systemic cover - Clash'),

(962, 'Intl PE Regions', 2020, 'CAD', 113.439672339999 , 202112, '906', 'Core', '202112|2020|906|CAD|Core', 'XL', 'Systemic cover - Clash'),

(963, 'Intl US PE Londo', 2020, 'CAD', 172484.708619790040 , 202112, '784', 'Core', '202112|2020|784|CAD|Core', 'XL', 'Systemic cover - Clash'),

(964, 'Mid Market Lawyers', 2009, 'USD', 5667.898999999976 , 202112, '663', 'Core', '202112|2009|663|USD|Core', 'XL', 'Systemic cover - Clash'),

(965, 'PE Media US', 2019, 'GBP', 1231.191764100000 , 202112, '905', 'Core', '202112|2019|905|GBP|Core', 'XL', 'Systemic cover - Clash'),

(966, 'PI-Ins Brokers exBLPT', 2008, 'USD', 4052.862000000000 , 202112, '14', 'Core', '202112|2008|14|USD|Core', 'XL', 'Systemic cover - Clash'),

(967, 'PI-Lawyers exBLPT', 2007, 'USD', 24829.391999999527 , 202112, '15', 'Core', '202112|2007|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(968, 'PI-Lawyers exBLPT', 2004, 'USD', 34305.176500000060 , 202112, '15', 'Core', '202112|2004|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(969, 'PI-Lawyers exBLPT', 2010, 'USD', 15134.984499999788 , 202112, '15', 'Core', '202112|2010|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(970, 'PI-Lawyers exBLPT', 2009, 'USD', 703651.512000000100 , 202112, '15', 'Core', '202112|2009|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(971, 'PI-Lawyers exBLPT', 2006, 'USD', 512.182000000015 , 202112, '15', 'Core', '202112|2006|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(972, 'PI-Lawyers exBLPT', 2005, 'USD', 4.266500000000 , 202112, '15', 'Core', '202112|2005|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(973, 'PI-Lawyers exBLPT', 2008, 'USD', 1022584.282500000700 , 202112, '15', 'Core', '202112|2008|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(974, 'PI-Lawyers exBLPT', 2012, 'USD', 69.303000000000 , 202112, '15', 'Core', '202112|2012|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(975, 'PI-Other exBLPT', 2011, 'USD', 0.707500000000 , 202112, '18', 'Core', '202112|2011|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(976, 'PI-Other exBLPT', 2010, 'USD', 7.371000000000 , 202112, '18', 'Core', '202112|2010|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(977, 'PI-Other exBLPT', 2009, 'USD', 6806.691500000190 , 202112, '18', 'Core', '202112|2009|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(978, 'PI-Other exBLPT', 2007, 'USD', 23.731500000000 , 202112, '18', 'Core', '202112|2007|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(979, 'PI-Other exBLPT', 2008, 'USD', 54.546000000001 , 202112, '18', 'Core', '202112|2008|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(980, 'Specialty (PT)', 2006, 'USD', 91.141500000000 , 202112, '27', 'Core', '202112|2006|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(981, 'Specialty (PT)', 2009, 'USD', 107780.481500000230 , 202112, '27', 'Core', '202112|2009|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(982, 'Specialty (PT)', 2010, 'USD', 4521.776999999653 , 202112, '27', 'Core', '202112|2010|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(983, 'Specialty (PT)', 2008, 'USD', 848003.042499999860 , 202112, '27', 'Core', '202112|2008|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(984, 'Specialty (PT)', 2011, 'USD', 54070.629500000156 , 202112, '27', 'Core', '202112|2011|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(985, 'Specialty (PT)', 2007, 'USD', 661.241499999989 , 202112, '27', 'Core', '202112|2007|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(986, 'TMB INT InfoSec MM BBR', 2021, 'USD', 5625.517211999999 , 202112, '769', 'Core', '202112|2021|769|USD|Core', 'XL', 'Systemic cover - Clash'),

(987, 'TMB INT InfoSec MM BBR', 2019, 'USD', 352623.596748609970 , 202112, '769', 'Core', '202112|2019|769|USD|Core', 'XL', 'Systemic cover - Clash'),

(988, 'TMB INT InfoSec MM BBR', 2020, 'USD', 13628.233928700007 , 202112, '769', 'Core', '202112|2020|769|USD|Core', 'XL', 'Systemic cover - Clash'),

(989, 'TMB INT InfoSec MM BBR', 2020, 'GBP', 5997.540336750000 , 202112, '769', 'Core', '202112|2020|769|GBP|Core', 'XL', 'Systemic cover - Clash'),

(990, 'TMB INT InfoSec MM BBR', 2019, 'CAD', 51688.230711400043 , 202112, '769', 'Core', '202112|2019|769|CAD|Core', 'XL', 'Systemic cover - Clash'),

(991, 'TMB Large Risk Int', 2020, 'USD', 177694.978151150000 , 202112, '712', 'Core', '202112|2020|712|USD|Core', 'XL', 'Systemic cover - Clash'),

(992, 'TMB Large Risk Int', 2014, 'USD', 4.991250000000 , 202112, '712', 'Core', '202112|2014|712|USD|Core', 'XL', 'Systemic cover - Clash'),

(993, 'TMB LargeRisk Int InfoSec', 2020, 'EUR', 279136.283862600000 , 202112, '744', 'Core', '202112|2020|744|EUR|Core', 'XL', 'Systemic cover - Clash'),

(994, 'TMB LargeRisk Int InfoSec', 2020, 'USD', 273627.247621500000 , 202112, '744', 'Core', '202112|2020|744|USD|Core', 'XL', 'Systemic cover - Clash'),

(995, 'TMB LargeRisk Int InfoSec', 2019, 'GBP', 762450.358014110000 , 202112, '744', 'Core', '202112|2019|744|GBP|Core', 'XL', 'Systemic cover - Clash'),

(996, 'TMB UK Info Sec', 2014, 'USD', 5.494500000000 , 202112, '721', 'Core', '202112|2014|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(997, 'TMB UK Info Sec', 2020, 'USD', 1119228.987587070000 , 202112, '721', 'Core', '202112|2020|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(998, 'TMB UK Info Sec', 2015, 'USD', 77.335500000045 , 202112, '721', 'Core', '202112|2015|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(999, 'TMB UK InfoSec MM BBR', 2020, 'USD', 3091136.958106809300 , 202112, '765', 'Core', '202112|2020|765|USD|Core', 'XL', 'Systemic cover - Clash'),

(1000, 'TMB UK InfoSec MM BBR', 2018, 'USD', 24569.380575930000 , 202112, '765', 'Core', '202112|2018|765|USD|Core', 'XL', 'Systemic cover - Clash'),

(1001, 'TMB UK Tech', 2008, 'USD', 697486.410000000000 , 202112, '19', 'Core', '202112|2008|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1002, 'TMB UK Tech', 2016, 'USD', 940.759436000000 , 202112, '19', 'Core', '202112|2016|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1003, 'TMB UK Tech', 2006, 'USD', 38.520000000000 , 202112, '19', 'Core', '202112|2006|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1004, 'TMB UK Tech', 2007, 'USD', 110916.401499997820 , 202112, '19', 'Core', '202112|2007|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1005, 'TMB UK Tech', 2015, 'USD', 28115.820436000000 , 202112, '19', 'Core', '202112|2015|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1006, 'TMB UK Tech', 2018, 'USD', 848545.777589569920 , 202112, '19', 'Core', '202112|2018|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1007, 'TMB UK Tech', 2010, 'USD', 37607.425000000105 , 202112, '19', 'Core', '202112|2010|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1008, 'TMB UK Tech', 2017, 'USD', 5878.908448000000 , 202112, '19', 'Core', '202112|2017|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1009, 'UK', 2006, 'EUR', 6841.394999999902 , 202112, '24', 'Core', '202112|2006|24|EUR|Core', 'XL', 'Systemic cover - Clash'),

(1010, 'UK', 2007, 'GBP', 238.514499999998 , 202112, '24', 'Core', '202112|2007|24|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1011, 'US PE Londo', 2020, 'USD', 5901.904986289999 , 202112, '25', 'Core', '202112|2020|25|USD|Core', 'XL', 'Systemic cover - Clash'),

(1012, 'US PE Londo', 2018, 'USD', 10865.028822749991 , 202112, '25', 'Core', '202112|2018|25|USD|Core', 'XL', 'Systemic cover - Clash'),

(1013, 'BBR Services Int (exc PE)', 2019, 'CAD', 16290.963536849988 , 202203, '742', 'Core', '202203|2019|742|CAD|Core', 'XL', 'Systemic cover - Clash'),

(1014, 'BBR Services Int (exc PE)', 2020, 'USD', 58350.284133910005 , 202203, '742', 'Core', '202203|2020|742|USD|Core', 'XL', 'Systemic cover - Clash'),

(1015, 'BBR Services Int (exc PE)', 2020, 'GBP', 2863.244271150003 , 202203, '742', 'Core', '202203|2020|742|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1016, 'BBR Services Int (exc PE)', 2021, 'EUR', 6537.829178700002 , 202203, '742', 'Core', '202203|2021|742|EUR|Core', 'XL', 'Systemic cover - Clash'),

(1017, 'BBR Services Int PE', 2020, 'CAD', 3057.471778049996 , 202203, '741', 'Core', '202203|2020|741|CAD|Core', 'XL', 'Systemic cover - Clash'),

(1018, 'BBR Services PE', 2018, 'USD', 4743.272528099999 , 202203, '738', 'Core', '202203|2018|738|USD|Core', 'XL', 'Systemic cover - Clash'),

(1019, 'BBR Services PE', 2017, 'USD', 1150.280757380001 , 202203, '738', 'Core', '202203|2017|738|USD|Core', 'XL', 'Systemic cover - Clash'),

(1049, 'BUSA BBR Services MM', 2014, 'USD', 24.667499999807 , 202203, '732', 'Core', '202203|2014|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(1050, 'BUSA BBR Services MM', 2020, 'USD', 37137.086642800132 , 202203, '732', 'Core', '202203|2020|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(1051, 'BUSA BBR Services MM', 2021, 'USD', 28259.943024630047 , 202203, '732', 'Core', '202203|2021|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(1052, 'BUSA BBR Services PE', 2018, 'USD', 4175.318449920014 , 202203, '731', 'Core', '202203|2018|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(1053, 'BUSA BBR Services PE', 2021, 'USD', 51571.581140760000 , 202203, '731', 'Core', '202203|2021|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(1054, 'BUSA BBR Services PE', 2019, 'USD', 60997.183203399996 , 202203, '731', 'Core', '202203|2019|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(1055, 'BUSA BBR Services PE', 2020, 'USD', 44111.311400620063 , 202203, '731', 'Core', '202203|2020|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(1056, 'BUSA EPL MM', 2007, 'USD', 8404.185499999905 , 202203, '681', 'Core', '202203|2007|681|USD|Core', 'XL', 'Systemic cover - Clash'),

(1057, 'BUSA Healthcare MM', 2017, 'USD', 4720.509636000000 , 202203, '683', 'Core', '202203|2017|683|USD|Core', 'XL', 'Systemic cover - Clash'),

(1058, 'BUSA Healthcare MM', 2016, 'USD', 41934.889675999992 , 202203, '683', 'Core', '202203|2016|683|USD|Core', 'XL', 'Systemic cover - Clash'),

(1059, 'BUSA Healthcare MM', 2018, 'USD', 1836.292272000000 , 202203, '683', 'Core', '202203|2018|683|USD|Core', 'XL', 'Systemic cover - Clash'),

(1060, 'BUSA Misc Med PE', 2019, 'USD', 1006.738312000000 , 202203, '716', 'Core', '202203|2019|716|USD|Core', 'XL', 'Systemic cover - Clash'),

(1061, 'BUSA TMB PE', 2020, 'USD', 16566.428240549983 , 202203, '690', 'Core', '202203|2020|690|USD|Core', 'XL', 'Systemic cover - Clash'),

(1062, 'BUSA TMB PE', 2019, 'USD', 26847.446456769947 , 202203, '690', 'Core', '202203|2019|690|USD|Core', 'XL', 'Systemic cover - Clash'),

(1063, 'BUSA TMB PE US Info Sec', 2020, 'USD', 72185.388103439938 , 202203, '723', 'Core', '202203|2020|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(1064, 'BUSA TMB PE US Info Sec', 2019, 'USD', 266639.325952439100 , 202203, '723', 'Core', '202203|2019|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(1065, 'BUSA TMB PE US Info Sec', 2018, 'USD', 23164.514135079866 , 202203, '723', 'Core', '202203|2018|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(1066, 'BUSA TMB PE US Info Sec', 2021, 'USD', 14777.583107529979 , 202203, '723', 'Core', '202203|2021|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(1067, 'BUSA TMB US E&O', 2015, 'USD', 0.008250000000 , 202203, '689', 'Core', '202203|2015|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(1068, 'BUSA TMB US E&O', 2019, 'USD', 347594.437012639360 , 202203, '689', 'Core', '202203|2019|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(1069, 'BUSA TMB US E&O', 2014, 'USD', 13.183500000000 , 202203, '689', 'Core', '202203|2014|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(1070, 'BUSA TMB US Info Sec', 2020, 'USD', 1338484.547851068900 , 202203, '714', 'Core', '202203|2020|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(1071, 'BUSA TMB US Info Sec', 2015, 'USD', 0.024750000000 , 202203, '714', 'Core', '202203|2015|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(1072, 'BUSA TMB US Info Sec', 2014, 'USD', 78.465749999974 , 202203, '714', 'Core', '202203|2014|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(1073, 'BUSA US InfoSec MM BBR', 2020, 'USD', 1167270.801922119200 , 202203, '763', 'Core', '202203|2020|763|USD|Core', 'XL', 'Systemic cover - Clash'),

(1074, 'BUSA US InfoSec MM BBR', 2021, 'USD', 29844.459844200028 , 202203, '763', 'Core', '202203|2021|763|USD|Core', 'XL', 'Systemic cover - Clash'),

(1075, 'BUSA US InfoSec MM BBR', 2019, 'USD', 2199106.370494881600 , 202203, '763', 'Core', '202203|2019|763|USD|Core', 'XL', 'Systemic cover - Clash'),

(1076, 'D&O', 2020, 'USD', 13.489592000000 , 202203, '6', 'Core', '202203|2020|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1077, 'D&O', 2009, 'USD', 1617.603000000032 , 202203, '6', 'Core', '202203|2009|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1078, 'D&O', 2019, 'USD', 75.086112000000 , 202203, '6', 'Core', '202203|2019|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1079, 'D&O', 2007, 'USD', 29662.994000000879 , 202203, '6', 'Core', '202203|2007|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1080, 'D&O', 2010, 'USD', 440.923000000003 , 202203, '6', 'Core', '202203|2010|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1081, 'D&O', 2015, 'USD', 4920.396479999999 , 202203, '6', 'Core', '202203|2015|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1082, 'D&O', 2008, 'USD', 315303.136000033470 , 202203, '6', 'Core', '202203|2008|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1083, 'D&O', 2016, 'USD', 111207.703524000000 , 202203, '6', 'Core', '202203|2016|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1084, 'D&O', 2003, 'USD', 20311.877500000875 , 202203, '6', 'Core', '202203|2003|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1085, 'DIN US Lawyers', 2011, 'USD', 79.660000000000 , 202203, '7', 'Core', '202203|2011|7|USD|Core', 'XL', 'Systemic cover - Clash'),

(1086, 'EPL', 2007, 'USD', 701.618999999992 , 202203, '8', 'Core', '202203|2007|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(1087, 'EPL', 2009, 'USD', 17.199000000000 , 202203, '8', 'Core', '202203|2009|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(1088, 'EPL', 2008, 'USD', 2065.908000000000 , 202203, '8', 'Core', '202203|2008|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(1089, 'Healthcare-Hospitals', 2015, 'USD', 217.976112000000 , 202203, '756', 'Core', '202203|2015|756|USD|Core', 'XL', 'Systemic cover - Clash'),

(1090, 'Healthcare-Hospitals', 2016, 'USD', 108.350248000000 , 202203, '756', 'Core', '202203|2016|756|USD|Core', 'XL', 'Systemic cover - Clash'),

(1091, 'International', 2020, 'CAD', 2145.556477349999 , 202203, '10', 'Core', '202203|2020|10|CAD|Core', 'XL', 'Systemic cover - Clash'),

(1092, 'International ML', 2019, 'CAD', 0.014268000000 , 202203, '762', 'Core', '202203|2019|762|CAD|Core', 'XL', 'Systemic cover - Clash'),

(1093, 'International ML', 2021, 'GBP', 35.238576000000 , 202203, '762', 'Core', '202203|2021|762|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1094, 'International ML', 2020, 'GBP', 105.961020000000 , 202203, '762', 'Core', '202203|2020|762|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1095, 'Mid Market Lawyers', 2009, 'USD', 5667.898999999976 , 202203, '663', 'Core', '202203|2009|663|USD|Core', 'XL', 'Systemic cover - Clash'),

(1096, 'PE Media US', 2019, 'GBP', 696.327329700000 , 202203, '905', 'Core', '202203|2019|905|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1097, 'PI-Ins Brokers exBLPT', 2008, 'USD', 4052.862000000000 , 202203, '14', 'Core', '202203|2008|14|USD|Core', 'XL', 'Systemic cover - Clash'),

(1098, 'PI-Lawyers exBLPT', 2005, 'USD', 4.266500000000 , 202203, '15', 'Core', '202203|2005|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1099, 'PI-Lawyers exBLPT', 2008, 'USD', 1022584.282500000700 , 202203, '15', 'Core', '202203|2008|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1100, 'PI-Lawyers exBLPT', 2007, 'USD', 24829.391999999527 , 202203, '15', 'Core', '202203|2007|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1101, 'PI-Lawyers exBLPT', 2010, 'USD', 15134.984499999788 , 202203, '15', 'Core', '202203|2010|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1102, 'PI-Lawyers exBLPT', 2009, 'USD', 703651.512000000100 , 202203, '15', 'Core', '202203|2009|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1103, 'PI-Lawyers exBLPT', 2012, 'USD', 69.303000000000 , 202203, '15', 'Core', '202203|2012|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1104, 'PI-Lawyers exBLPT', 2004, 'USD', 34305.176500000060 , 202203, '15', 'Core', '202203|2004|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1105, 'PI-Lawyers exBLPT', 2006, 'USD', 512.182000000015 , 202203, '15', 'Core', '202203|2006|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1106, 'PI-Other exBLPT', 2010, 'USD', 7.371000000000 , 202203, '18', 'Core', '202203|2010|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(1107, 'PI-Other exBLPT', 2011, 'USD', 0.707500000000 , 202203, '18', 'Core', '202203|2011|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(1108, 'PI-Other exBLPT', 2009, 'USD', 6806.691500000190 , 202203, '18', 'Core', '202203|2009|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(1109, 'PI-Other exBLPT', 2008, 'USD', 54.546000000001 , 202203, '18', 'Core', '202203|2008|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(1110, 'PI-Other exBLPT', 2007, 'USD', 23.731500000000 , 202203, '18', 'Core', '202203|2007|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(1111, 'Specialty (PT)', 2011, 'USD', 54070.629500000156 , 202203, '27', 'Core', '202203|2011|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1112, 'Specialty (PT)', 2006, 'USD', 91.141500000000 , 202203, '27', 'Core', '202203|2006|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1113, 'Specialty (PT)', 2010, 'USD', 4521.776999999653 , 202203, '27', 'Core', '202203|2010|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1114, 'Specialty (PT)', 2008, 'USD', 848003.042499999860 , 202203, '27', 'Core', '202203|2008|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1115, 'Specialty (PT)', 2007, 'USD', 661.241499999989 , 202203, '27', 'Core', '202203|2007|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1116, 'Specialty (PT)', 2009, 'USD', 107780.481500000000 , 202203, '27', 'Core', '202203|2009|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1117, 'TMB INT InfoSec MM BBR', 2021, 'USD', 3717.851251500000 , 202203, '769', 'Core', '202203|2021|769|USD|Core', 'XL', 'Systemic cover - Clash'),

(1118, 'TMB INT InfoSec MM BBR', 2019, 'CAD', 35050.921154930023 , 202203, '769', 'Core', '202203|2019|769|CAD|Core', 'XL', 'Systemic cover - Clash'),

(1119, 'TMB INT InfoSec MM BBR', 2019, 'USD', 330703.103392669930 , 202203, '769', 'Core', '202203|2019|769|USD|Core', 'XL', 'Systemic cover - Clash'),

(1120, 'TMB INT InfoSec MM BBR', 2020, 'GBP', 6328.121781149996 , 202203, '769', 'Core', '202203|2020|769|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1121, 'TMB INT InfoSec MM BBR', 2020, 'USD', 14379.400332899997 , 202203, '769', 'Core', '202203|2020|769|USD|Core', 'XL', 'Systemic cover - Clash'),

(1122, 'TMB Large Risk Int', 2014, 'USD', 4.991250000000 , 202203, '712', 'Core', '202203|2014|712|USD|Core', 'XL', 'Systemic cover - Clash'),

(1123, 'TMB LargeRisk Int InfoSec', 2020, 'USD', 280938.466417050000 , 202203, '744', 'Core', '202203|2020|744|USD|Core', 'XL', 'Systemic cover - Clash'),

(1124, 'TMB LargeRisk Int InfoSec', 2019, 'GBP', 730903.622733330240 , 202203, '744', 'Core', '202203|2019|744|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1125, 'TMB LargeRisk Int InfoSec', 2020, 'EUR', 285422.220214650000 , 202203, '744', 'Core', '202203|2020|744|EUR|Core', 'XL', 'Systemic cover - Clash'),

(1126, 'TMB UK Info Sec', 2014, 'USD', 5.494500000000 , 202203, '721', 'Core', '202203|2014|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(1127, 'TMB UK Info Sec', 2020, 'USD', 389714.840873099860 , 202203, '721', 'Core', '202203|2020|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(1128, 'TMB UK Info Sec', 2015, 'USD', 77.335500000045 , 202203, '721', 'Core', '202203|2015|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(1129, 'TMB UK InfoSec MM BBR', 2018, 'USD', 99336.473842900014 , 202203, '765', 'Core', '202203|2018|765|USD|Core', 'XL', 'Systemic cover - Clash'),

(1130, 'TMB UK InfoSec MM BBR', 2020, 'USD', 1809479.993425930400 , 202203, '765', 'Core', '202203|2020|765|USD|Core', 'XL', 'Systemic cover - Clash'),

(1131, 'TMB UK Tech', 2010, 'USD', 37607.425000000105 , 202203, '19', 'Core', '202203|2010|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1132, 'TMB UK Tech', 2015, 'USD', 4816.388288000000 , 202203, '19', 'Core', '202203|2015|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1133, 'TMB UK Tech', 2006, 'USD', 38.520000000000 , 202203, '19', 'Core', '202203|2006|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1134, 'TMB UK Tech', 2007, 'USD', 110916.401499994100 , 202203, '19', 'Core', '202203|2007|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1135, 'TMB UK Tech', 2018, 'USD', 122837.220808229990 , 202203, '19', 'Core', '202203|2018|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1136, 'TMB UK Tech', 2017, 'USD', 971.191500000000 , 202203, '19', 'Core', '202203|2017|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1137, 'TMB UK Tech', 2008, 'USD', 697486.410000000000 , 202203, '19', 'Core', '202203|2008|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1138, 'TMB UK Tech', 2016, 'USD', 155.411612000000 , 202203, '19', 'Core', '202203|2016|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1139, 'UK', 2006, 'EUR', 6841.395000000019 , 202203, '24', 'Core', '202203|2006|24|EUR|Core', 'XL', 'Systemic cover - Clash'),

(1140, 'UK', 2007, 'GBP', 238.514499999998 , 202203, '24', 'Core', '202203|2007|24|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1141, 'US PE Londo', 2020, 'USD', 4770.578150989997 , 202203, '25', 'Core', '202203|2020|25|USD|Core', 'XL', 'Systemic cover - Clash'),

(1142, 'US PE Londo', 2018, 'USD', 11408.590159199994 , 202203, '25', 'Core', '202203|2018|25|USD|Core', 'XL', 'Systemic cover - Clash'),

(1143, 'BBR Services Int (exc PE)', 2021, 'EUR', 4658.029004699994 , 202206, '742', 'Core', '202206|2021|742|EUR|Core', 'XL', 'Systemic cover - Clash'),

(1144, 'BBR Services Int (exc PE)', 2020, 'GBP', 2039.993738100000 , 202206, '742', 'Core', '202206|2020|742|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1145, 'BBR Services Int (exc PE)', 2019, 'CAD', 10285.886546099995 , 202206, '742', 'Core', '202206|2019|742|CAD|Core', 'XL', 'Systemic cover - Clash'),

(1146, 'BBR Services Int PE', 2020, 'CAD', 2178.360755550002 , 202206, '741', 'Core', '202206|2020|741|CAD|Core', 'XL', 'Systemic cover - Clash'),

(1147, 'BBR Services Int PE', 2021, 'CAD', 85689.657451920000 , 202206, '741', 'Core', '202206|2021|741|CAD|Core', 'XL', 'Systemic cover - Clash'),

(1148, 'BBR Services PE', 2017, 'USD', 819.540646580000 , 202206, '738', 'Core', '202206|2017|738|USD|Core', 'XL', 'Systemic cover - Clash'),

(1149, 'BBR Services PE', 2020, 'USD', 394.630539580001 , 202206, '738', 'Core', '202206|2020|738|USD|Core', 'XL', 'Systemic cover - Clash'),

(1150, 'BBR Services PE', 2018, 'USD', 3379.455486899995 , 202206, '738', 'Core', '202206|2018|738|USD|Core', 'XL', 'Systemic cover - Clash'),

(1180, 'BUSA BBR Services MM', 2020, 'USD', 2896.085353240138 , 202206, '732', 'Core', '202206|2020|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(1181, 'BUSA BBR Services MM', 2014, 'USD', 24.667499999807 , 202206, '732', 'Core', '202206|2014|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(1182, 'BUSA BBR Services MM', 2021, 'USD', 17826.378961540002 , 202206, '732', 'Core', '202206|2021|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(1183, 'BUSA BBR Services PE', 2019, 'USD', 33192.450653989916 , 202206, '731', 'Core', '202206|2019|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(1184, 'BUSA BBR Services PE', 2020, 'USD', 29998.171617169952 , 202206, '731', 'Core', '202206|2020|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(1185, 'BUSA EPL MM', 2007, 'USD', 8404.192999999970 , 202206, '681', 'Core', '202206|2007|681|USD|Core', 'XL', 'Systemic cover - Clash'),

(1186, 'BUSA Healthcare MM', 2016, 'USD', 34578.774308000000 , 202206, '683', 'Core', '202206|2016|683|USD|Core', 'XL', 'Systemic cover - Clash'),

(1187, 'BUSA Healthcare MM', 2018, 'USD', 1514.171604000000 , 202206, '683', 'Core', '202206|2018|683|USD|Core', 'XL', 'Systemic cover - Clash'),

(1188, 'BUSA Healthcare MM', 2017, 'USD', 3831.796884000000 , 202206, '683', 'Core', '202206|2017|683|USD|Core', 'XL', 'Systemic cover - Clash'),

(1189, 'BUSA Misc Med PE', 2019, 'USD', 749.228312000000 , 202206, '716', 'Core', '202206|2019|716|USD|Core', 'XL', 'Systemic cover - Clash'),

(1190, 'BUSA TMB PE', 2020, 'USD', 12291.489342000015 , 202206, '690', 'Core', '202206|2020|690|USD|Core', 'XL', 'Systemic cover - Clash'),

(1191, 'BUSA TMB PE US Info Sec', 2019, 'USD', 83724.611309930449 , 202206, '723', 'Core', '202206|2019|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(1192, 'BUSA TMB PE US Info Sec', 2020, 'USD', 46765.605268579908 , 202206, '723', 'Core', '202206|2020|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(1193, 'BUSA TMB PE US Info Sec', 2018, 'USD', 5201.147526340094 , 202206, '723', 'Core', '202206|2018|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(1194, 'BUSA TMB US E&O', 2019, 'USD', 196186.789204400500 , 202206, '689', 'Core', '202206|2019|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(1195, 'BUSA TMB US E&O', 2015, 'USD', 0.008250000000 , 202206, '689', 'Core', '202206|2015|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(1196, 'BUSA TMB US E&O', 2014, 'USD', 13.183500000000 , 202206, '689', 'Core', '202206|2014|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(1197, 'BUSA TMB US Info Sec', 2014, 'USD', 78.465749999974 , 202206, '714', 'Core', '202206|2014|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(1198, 'BUSA TMB US Info Sec', 2020, 'USD', 1119762.157919310000 , 202206, '714', 'Core', '202206|2020|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(1199, 'BUSA TMB US Info Sec', 2015, 'USD', 0.024750000000 , 202206, '714', 'Core', '202206|2015|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(1200, 'BUSA US InfoSec MM BBR', 2019, 'USD', 2184980.113992936900 , 202206, '763', 'Core', '202206|2019|763|USD|Core', 'XL', 'Systemic cover - Clash'),

(1201, 'BUSA US InfoSec MM BBR', 2021, 'USD', 16320.397398720015 , 202206, '763', 'Core', '202206|2021|763|USD|Core', 'XL', 'Systemic cover - Clash'),

(1202, 'BUSA US InfoSec MM BBR', 2020, 'USD', 277081.375803260130 , 202206, '763', 'Core', '202206|2020|763|USD|Core', 'XL', 'Systemic cover - Clash'),

(1203, 'D&O', 2019, 'USD', 60.857520000000 , 202206, '6', 'Core', '202206|2019|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1204, 'D&O', 2016, 'USD', 91869.106028000000 , 202206, '6', 'Core', '202206|2016|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1205, 'D&O', 2003, 'USD', 20311.842499999329 , 202206, '6', 'Core', '202206|2003|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1206, 'D&O', 2010, 'USD', 440.915499999996 , 202206, '6', 'Core', '202206|2010|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1207, 'D&O', 2009, 'USD', 1617.603000000032 , 202206, '6', 'Core', '202206|2009|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1208, 'D&O', 2007, 'USD', 29663.022000000346 , 202206, '6', 'Core', '202206|2007|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1209, 'D&O', 2020, 'USD', 11.124412000000 , 202206, '6', 'Core', '202206|2020|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1210, 'D&O', 2015, 'USD', 4057.270840000000 , 202206, '6', 'Core', '202206|2015|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1211, 'D&O', 2008, 'USD', 298046.640000032260 , 202206, '6', 'Core', '202206|2008|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1212, 'DIN US Lawyers', 2011, 'USD', 79.660000000000 , 202206, '7', 'Core', '202206|2011|7|USD|Core', 'XL', 'Systemic cover - Clash'),

(1213, 'EPL', 2009, 'USD', 17.199000000000 , 202206, '8', 'Core', '202206|2009|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(1214, 'EPL', 2008, 'USD', 1895.502000000000 , 202206, '8', 'Core', '202206|2008|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(1215, 'EPL', 2007, 'USD', 701.608999999997 , 202206, '8', 'Core', '202206|2007|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(1216, 'Healthcare-Hospitals', 2015, 'USD', 136.028340000000 , 202206, '756', 'Core', '202206|2015|756|USD|Core', 'XL', 'Systemic cover - Clash'),

(1217, 'Healthcare-Hospitals', 2016, 'USD', 89.338020000000 , 202206, '756', 'Core', '202206|2016|756|USD|Core', 'XL', 'Systemic cover - Clash'),

(1218, 'International', 2020, 'CAD', 1528.651597500000 , 202206, '10', 'Core', '202206|2020|10|CAD|Core', 'XL', 'Systemic cover - Clash'),

(1219, 'International ML', 2020, 'GBP', 89.528292000000 , 202206, '762', 'Core', '202206|2020|762|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1220, 'International ML', 2019, 'CAD', 0.004984000000 , 202206, '762', 'Core', '202206|2019|762|CAD|Core', 'XL', 'Systemic cover - Clash'),

(1221, 'International ML', 2021, 'GBP', 29.774584000000 , 202206, '762', 'Core', '202206|2021|762|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1222, 'Mid Market Lawyers', 2009, 'USD', 5667.908999999869 , 202206, '663', 'Core', '202206|2009|663|USD|Core', 'XL', 'Systemic cover - Clash'),

(1223, 'PE Media US', 2019, 'GBP', 496.120082850000 , 202206, '905', 'Core', '202206|2019|905|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1224, 'PI-Ins Brokers exBLPT', 2008, 'USD', 3718.566000000000 , 202206, '14', 'Core', '202206|2008|14|USD|Core', 'XL', 'Systemic cover - Clash'),

(1225, 'PI-Lawyers exBLPT', 2005, 'USD', 4.266500000000 , 202206, '15', 'Core', '202206|2005|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1226, 'PI-Lawyers exBLPT', 2004, 'USD', 34305.140999999829 , 202206, '15', 'Core', '202206|2004|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1227, 'PI-Lawyers exBLPT', 2008, 'USD', 932881.909000000920 , 202206, '15', 'Core', '202206|2008|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1228, 'PI-Lawyers exBLPT', 2009, 'USD', 645317.958000000100 , 202206, '15', 'Core', '202206|2009|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1229, 'PI-Lawyers exBLPT', 2020, 'USD', 42.407588000000 , 202206, '15', 'Core', '202206|2020|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1230, 'PI-Lawyers exBLPT', 2012, 'USD', 69.303000000000 , 202206, '15', 'Core', '202206|2012|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1231, 'PI-Lawyers exBLPT', 2006, 'USD', 512.182000000001 , 202206, '15', 'Core', '202206|2006|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1232, 'PI-Lawyers exBLPT', 2010, 'USD', 15134.954999999842 , 202206, '15', 'Core', '202206|2010|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1233, 'PI-Lawyers exBLPT', 2007, 'USD', 24829.372000000440 , 202206, '15', 'Core', '202206|2007|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1234, 'PI-Other exBLPT', 2008, 'USD', 52.062000000001 , 202206, '18', 'Core', '202206|2008|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(1235, 'PI-Other exBLPT', 2009, 'USD', 6806.689000000246 , 202206, '18', 'Core', '202206|2009|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(1236, 'PI-Other exBLPT', 2010, 'USD', 7.371000000000 , 202206, '18', 'Core', '202206|2010|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(1237, 'PI-Other exBLPT', 2011, 'USD', 0.707500000000 , 202206, '18', 'Core', '202206|2011|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(1238, 'PI-Other exBLPT', 2007, 'USD', 23.731500000000 , 202206, '18', 'Core', '202206|2007|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(1239, 'Specialty (PT)', 2006, 'USD', 91.141500000000 , 202206, '27', 'Core', '202206|2006|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1240, 'Specialty (PT)', 2007, 'USD', 661.231499999994 , 202206, '27', 'Core', '202206|2007|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1241, 'Specialty (PT)', 2011, 'USD', 54070.611500000174 , 202206, '27', 'Core', '202206|2011|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1242, 'Specialty (PT)', 2008, 'USD', 848003.014499999700 , 202206, '27', 'Core', '202206|2008|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1243, 'Specialty (PT)', 2010, 'USD', 4521.774499999592 , 202206, '27', 'Core', '202206|2010|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1244, 'Specialty (PT)', 2009, 'USD', 107780.482000000080 , 202206, '27', 'Core', '202206|2009|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1245, 'TMB INT InfoSec MM BBR', 2021, 'USD', 1748.711977650000 , 202206, '769', 'Core', '202206|2021|769|USD|Core', 'XL', 'Systemic cover - Clash'),

(1246, 'TMB INT InfoSec MM BBR', 2020, 'GBP', 85231.187087400000 , 202206, '769', 'Core', '202206|2020|769|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1247, 'TMB Large Risk Int', 2014, 'USD', 4.991250000000 , 202206, '712', 'Core', '202206|2014|712|USD|Core', 'XL', 'Systemic cover - Clash'),

(1248, 'TMB LargeRisk Int InfoSec', 2020, 'USD', 252350.876713500000 , 202206, '744', 'Core', '202206|2020|744|USD|Core', 'XL', 'Systemic cover - Clash'),

(1249, 'TMB LargeRisk Int InfoSec', 2020, 'EUR', 288838.119390300000 , 202206, '744', 'Core', '202206|2020|744|EUR|Core', 'XL', 'Systemic cover - Clash'),

(1250, 'TMB LargeRisk Int InfoSec', 2019, 'GBP', 722784.444884070000 , 202206, '744', 'Core', '202206|2019|744|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1251, 'TMB UK Info Sec', 2014, 'USD', 5.494500000000 , 202206, '721', 'Core', '202206|2014|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(1252, 'TMB UK Info Sec', 2020, 'USD', 365228.196926020090 , 202206, '721', 'Core', '202206|2020|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(1253, 'TMB UK Info Sec', 2015, 'USD', 77.335500000045 , 202206, '721', 'Core', '202206|2015|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(1254, 'TMB UK InfoSec MM BBR', 2018, 'USD', 96115.622106590000 , 202206, '765', 'Core', '202206|2018|765|USD|Core', 'XL', 'Systemic cover - Clash'),

(1255, 'TMB UK Tech', 2017, 'USD', 800.836288000000 , 202206, '19', 'Core', '202206|2017|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1256, 'TMB UK Tech', 2010, 'USD', 37529.850999999966 , 202206, '19', 'Core', '202206|2010|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1257, 'TMB UK Tech', 2016, 'USD', 128.151256000000 , 202206, '19', 'Core', '202206|2016|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1258, 'TMB UK Tech', 2008, 'USD', 598235.322000000000 , 202206, '19', 'Core', '202206|2008|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1259, 'TMB UK Tech', 2007, 'USD', 110916.423499997710 , 202206, '19', 'Core', '202206|2007|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1260, 'TMB UK Tech', 2006, 'USD', 38.520000000000 , 202206, '19', 'Core', '202206|2006|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1261, 'TMB UK Tech', 2015, 'USD', 3829.966188000000 , 202206, '19', 'Core', '202206|2015|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1262, 'TMB UK Tech', 2018, 'USD', 101199.313720430000 , 202206, '19', 'Core', '202206|2018|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1263, 'UK', 2006, 'EUR', 6841.434499999974 , 202206, '24', 'Core', '202206|2006|24|EUR|Core', 'XL', 'Systemic cover - Clash'),

(1264, 'UK', 2007, 'GBP', 238.504499999999 , 202206, '24', 'Core', '202206|2007|24|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1265, 'US PE Londo', 2020, 'USD', 19.377578169995 , 202206, '25', 'Core', '202206|2020|25|USD|Core', 'XL', 'Systemic cover - Clash'),

(1266, 'US PE Londo', 2018, 'USD', 8128.311088949995 , 202206, '25', 'Core', '202206|2018|25|USD|Core', 'XL', 'Systemic cover - Clash'),

(1267, 'BBR Services Int PE', 2021, 'CAD', 86259.950948050013 , 202209, '741', 'Core', '202209|2021|741|CAD|Core', 'XL', 'Systemic cover - Clash'),

(1283, 'BUSA BBR Services MM', 2014, 'USD', 24.667499999749 , 202209, '732', 'Core', '202209|2014|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(1284, 'BUSA EPL MM', 2007, 'USD', 8404.182999999960 , 202209, '681', 'Core', '202209|2007|681|USD|Core', 'XL', 'Systemic cover - Clash'),

(1285, 'BUSA Healthcare MM', 2018, 'USD', 60340.020924000004 , 202209, '683', 'Core', '202209|2018|683|USD|Core', 'XL', 'Systemic cover - Clash'),

(1286, 'BUSA Healthcare MM', 2017, 'USD', 134685.345388000000 , 202209, '683', 'Core', '202209|2017|683|USD|Core', 'XL', 'Systemic cover - Clash'),

(1287, 'BUSA Healthcare MM', 2016, 'USD', 1215165.338824000000 , 202209, '683', 'Core', '202209|2016|683|USD|Core', 'XL', 'Systemic cover - Clash'),

(1288, 'BUSA Misc Med PE', 2019, 'USD', 26329.428488000005 , 202209, '716', 'Core', '202209|2019|716|USD|Core', 'XL', 'Systemic cover - Clash'),

(1289, 'BUSA TMB US E&O', 2014, 'USD', 13.183500000000 , 202209, '689', 'Core', '202209|2014|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(1290, 'BUSA TMB US E&O', 2015, 'USD', 0.008250000000 , 202209, '689', 'Core', '202209|2015|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(1291, 'BUSA TMB US Info Sec', 2015, 'USD', 0.024750000000 , 202209, '714', 'Core', '202209|2015|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(1292, 'BUSA TMB US Info Sec', 2020, 'USD', 1361793.229919069500 , 202209, '714', 'Core', '202209|2020|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(1293, 'BUSA TMB US Info Sec', 2014, 'USD', 78.465749999974 , 202209, '714', 'Core', '202209|2014|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(1294, 'BUSA US InfoSec MM BBR', 2021, 'USD', 208068.146179890090 , 202209, '763', 'Core', '202209|2021|763|USD|Core', 'XL', 'Systemic cover - Clash'),

(1295, 'BUSA US InfoSec MM BBR', 2020, 'USD', 293042.223013548180 , 202209, '763', 'Core', '202209|2020|763|USD|Core', 'XL', 'Systemic cover - Clash'),

(1296, 'D&O', 2007, 'USD', 29663.007500000298 , 202209, '6', 'Core', '202209|2007|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1297, 'D&O', 2010, 'USD', 440.915499999996 , 202209, '6', 'Core', '202209|2010|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1298, 'D&O', 2015, 'USD', 142580.392104000000 , 202209, '6', 'Core', '202209|2015|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1299, 'D&O', 2009, 'USD', 1617.610999999975 , 202209, '6', 'Core', '202209|2009|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1300, 'D&O', 2018, 'USD', 906.984472000000 , 202209, '6', 'Core', '202209|2018|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1301, 'D&O', 2019, 'USD', 2140.384720000000 , 202209, '6', 'Core', '202209|2019|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1302, 'D&O', 2020, 'USD', 390.841620000000 , 202209, '6', 'Core', '202209|2020|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1303, 'D&O', 2008, 'USD', 298046.559500020000 , 202209, '6', 'Core', '202209|2008|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1304, 'D&O', 2003, 'USD', 20311.838000000454 , 202209, '6', 'Core', '202209|2003|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1305, 'D&O', 2016, 'USD', 3194883.553939999500 , 202209, '6', 'Core', '202209|2016|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1306, 'DIN US Lawyers', 2011, 'USD', 79.660000000000 , 202209, '7', 'Core', '202209|2011|7|USD|Core', 'XL', 'Systemic cover - Clash'),

(1307, 'EPL', 2009, 'USD', 17.199000000000 , 202209, '8', 'Core', '202209|2009|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(1308, 'EPL', 2008, 'USD', 1895.502000000000 , 202209, '8', 'Core', '202209|2008|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(1309, 'EPL', 2007, 'USD', 701.608999999997 , 202209, '8', 'Core', '202209|2007|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(1310, 'Healthcare-Hospitals', 2015, 'USD', 4780.183064000000 , 202209, '756', 'Core', '202209|2015|756|USD|Core', 'XL', 'Systemic cover - Clash'),

(1311, 'Healthcare-Hospitals', 2016, 'USD', 3139.620324000000 , 202209, '756', 'Core', '202209|2016|756|USD|Core', 'XL', 'Systemic cover - Clash'),

(1312, 'International ML', 2021, 'GBP', 1055.453308000000 , 202209, '762', 'Core', '202209|2021|762|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1313, 'International ML', 2019, 'CAD', 0.283504000000 , 202209, '762', 'Core', '202209|2019|762|CAD|Core', 'XL', 'Systemic cover - Clash'),

(1314, 'International ML', 2020, 'GBP', 3173.494824000000 , 202209, '762', 'Core', '202209|2020|762|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1315, 'Mid Market Lawyers', 2009, 'USD', 5667.908999999869 , 202209, '663', 'Core', '202209|2009|663|USD|Core', 'XL', 'Systemic cover - Clash'),

(1316, 'PI-Ins Brokers exBLPT', 2008, 'USD', 3718.566000000000 , 202209, '14', 'Core', '202209|2008|14|USD|Core', 'XL', 'Systemic cover - Clash'),

(1317, 'PI-Lawyers exBLPT', 2004, 'USD', 34305.126500000246 , 202209, '15', 'Core', '202209|2004|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1318, 'PI-Lawyers exBLPT', 2005, 'USD', 4.266500000000 , 202209, '15', 'Core', '202209|2005|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1319, 'PI-Lawyers exBLPT', 2008, 'USD', 932881.881999999280 , 202209, '15', 'Core', '202209|2008|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1320, 'PI-Lawyers exBLPT', 2007, 'USD', 24829.369999999180 , 202209, '15', 'Core', '202209|2007|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1321, 'PI-Lawyers exBLPT', 2006, 'USD', 512.182000000001 , 202209, '15', 'Core', '202209|2006|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1322, 'PI-Lawyers exBLPT', 2010, 'USD', 15134.934999999823 , 202209, '15', 'Core', '202209|2010|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1323, 'PI-Lawyers exBLPT', 2020, 'USD', 857097.009076000000 , 202209, '15', 'Core', '202209|2020|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1324, 'PI-Lawyers exBLPT', 2009, 'USD', 645317.496500000120 , 202209, '15', 'Core', '202209|2009|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1325, 'PI-Lawyers exBLPT', 2012, 'USD', 69.303000000000 , 202209, '15', 'Core', '202209|2012|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1326, 'PI-Other exBLPT', 2009, 'USD', 6806.697000000044 , 202209, '18', 'Core', '202209|2009|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(1327, 'PI-Other exBLPT', 2010, 'USD', 7.371000000000 , 202209, '18', 'Core', '202209|2010|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(1328, 'PI-Other exBLPT', 2011, 'USD', 0.707500000000 , 202209, '18', 'Core', '202209|2011|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(1329, 'PI-Other exBLPT', 2008, 'USD', 52.062000000000 , 202209, '18', 'Core', '202209|2008|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(1330, 'PI-Other exBLPT', 2007, 'USD', 23.731500000000 , 202209, '18', 'Core', '202209|2007|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(1331, 'Specialty (PT)', 2010, 'USD', 4521.774499999941 , 202209, '27', 'Core', '202209|2010|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1332, 'Specialty (PT)', 2009, 'USD', 107780.489499999910 , 202209, '27', 'Core', '202209|2009|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1333, 'Specialty (PT)', 2007, 'USD', 661.241499999989 , 202209, '27', 'Core', '202209|2007|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1334, 'Specialty (PT)', 2006, 'USD', 91.141500000000 , 202209, '27', 'Core', '202209|2006|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1335, 'Specialty (PT)', 2011, 'USD', 54070.601500000106 , 202209, '27', 'Core', '202209|2011|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1336, 'Specialty (PT)', 2008, 'USD', 848003.004499999690 , 202209, '27', 'Core', '202209|2008|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1337, 'TMB INT InfoSec MM BBR', 2021, 'USD', 13974.850596149998 , 202209, '769', 'Core', '202209|2021|769|USD|Core', 'XL', 'Systemic cover - Clash'),

(1338, 'TMB Large Risk Int', 2014, 'USD', 4.991250000000 , 202209, '712', 'Core', '202209|2014|712|USD|Core', 'XL', 'Systemic cover - Clash'),

(1339, 'TMB LargeRisk Int InfoSec', 2019, 'GBP', 737252.327238109890 , 202209, '744', 'Core', '202209|2019|744|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1340, 'TMB LargeRisk Int InfoSec', 2020, 'EUR', 280980.374179950000 , 202209, '744', 'Core', '202209|2020|744|EUR|Core', 'XL', 'Systemic cover - Clash'),

(1341, 'TMB UK Info Sec', 2014, 'USD', 5.494500000000 , 202209, '721', 'Core', '202209|2014|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(1342, 'TMB UK Info Sec', 2015, 'USD', 77.335500000045 , 202209, '721', 'Core', '202209|2015|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(1343, 'TMB UK Info Sec', 2020, 'USD', 367555.961370790140 , 202209, '721', 'Core', '202209|2020|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(1344, 'TMB UK InfoSec MM BBR', 2018, 'USD', 96104.855074080000 , 202209, '765', 'Core', '202209|2018|765|USD|Core', 'XL', 'Systemic cover - Clash'),

(1345, 'TMB UK Tech', 2010, 'USD', 37529.860999999975 , 202209, '19', 'Core', '202209|2010|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1346, 'TMB UK Tech', 2007, 'USD', 110916.360500006000 , 202209, '19', 'Core', '202209|2007|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1347, 'TMB UK Tech', 2017, 'USD', 28142.776327999996 , 202209, '19', 'Core', '202209|2017|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1348, 'TMB UK Tech', 2008, 'USD', 598235.322000000000 , 202209, '19', 'Core', '202209|2008|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1349, 'TMB UK Tech', 2018, 'USD', 3564372.569875680000 , 202209, '19', 'Core', '202209|2018|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1350, 'TMB UK Tech', 2015, 'USD', 134817.707571999990 , 202209, '19', 'Core', '202209|2015|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1351, 'TMB UK Tech', 2006, 'USD', 38.520000000000 , 202209, '19', 'Core', '202209|2006|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1352, 'TMB UK Tech', 2016, 'USD', 4503.474340000001 , 202209, '19', 'Core', '202209|2016|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1353, 'UK', 2007, 'GBP', 238.504499999999 , 202209, '24', 'Core', '202209|2007|24|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1354, 'UK', 2006, 'EUR', 6841.432499999879 , 202209, '24', 'Core', '202209|2006|24|EUR|Core', 'XL', 'Systemic cover - Clash'),

(1355, 'BBR Services (exc PE)', 2014, 'USD', 347.894250000000 , 202212, '737', 'Core', '202212|2014|737|USD|Core', 'XL', 'Systemic cover - Clash'),

(1356, 'BBR Services (exc PE)', 2015, 'USD', 78.045000000000 , 202212, '737', 'Core', '202212|2015|737|USD|Core', 'XL', 'Systemic cover - Clash'),

(1357, 'BBR Services Int (exc PE)', 2019, 'CAD', 5265.879136074764 , 202212, '742', 'Core', '202212|2019|742|CAD|Core', 'XL', 'Systemic cover - Clash'),

(1358, 'BBR Services Int (exc PE)', 2021, 'EUR', 5176.473515489444 , 202212, '742', 'Core', '202212|2021|742|EUR|Core', 'XL', 'Systemic cover - Clash'),

(1359, 'BBR Services Int (exc PE)', 2020, 'GBP', 1158.235577216647 , 202212, '742', 'Core', '202212|2020|742|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1360, 'BBR Services Int PE', 2020, 'CAD', 1236.796640274148 , 202212, '741', 'Core', '202212|2020|741|CAD|Core', 'XL', 'Systemic cover - Clash'),

(1361, 'BBR Services PE', 2018, 'USD', 1918.742934193600 , 202212, '738', 'Core', '202212|2018|738|USD|Core', 'XL', 'Systemic cover - Clash'),

(1362, 'BBR Services PE', 2017, 'USD', 465.297583741179 , 202212, '738', 'Core', '202212|2017|738|USD|Core', 'XL', 'Systemic cover - Clash'),

(1398, 'BUSA BBR Services MM', 2014, 'USD', 346.384499999753 , 202212, '732', 'Core', '202212|2014|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(1399, 'BUSA BBR Services MM', 2021, 'USD', 10765.809720835270 , 202212, '732', 'Core', '202212|2021|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(1400, 'BUSA BBR Services MM', 2020, 'USD', 23787.818679223768 , 202212, '732', 'Core', '202212|2020|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(1401, 'BUSA BBR Services MM', 2015, 'USD', 0.990000000000 , 202212, '732', 'Core', '202212|2015|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(1402, 'BUSA BBR Services MM', 2013, 'USD', 0.033000000000 , 202212, '732', 'Core', '202212|2013|732|USD|Core', 'XL', 'Systemic cover - Clash'),

(1403, 'BUSA BBR Services PE', 2019, 'USD', 26387.586362410162 , 202212, '731', 'Core', '202212|2019|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(1404, 'BUSA BBR Services PE', 2015, 'USD', 0.173250000000 , 202212, '731', 'Core', '202212|2015|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(1405, 'BUSA BBR Services PE', 2014, 'USD', 0.594000000000 , 202212, '731', 'Core', '202212|2014|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(1406, 'BUSA BBR Services PE', 2020, 'USD', 18452.640865380468 , 202212, '731', 'Core', '202212|2020|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(1407, 'BUSA BBR Services PE', 2021, 'USD', 578.915289403529 , 202212, '731', 'Core', '202212|2021|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(1408, 'BUSA BBR Services PE', 2018, 'USD', 2415.288086766086 , 202212, '731', 'Core', '202212|2018|731|USD|Core', 'XL', 'Systemic cover - Clash'),

(1409, 'BUSA EPL MM', 2007, 'USD', 7753.591000000015 , 202212, '681', 'Core', '202212|2007|681|USD|Core', 'XL', 'Systemic cover - Clash'),

(1410, 'BUSA Healthcare MM', 2018, 'USD', 49945.845932000000 , 202212, '683', 'Core', '202212|2018|683|USD|Core', 'XL', 'Systemic cover - Clash'),

(1411, 'BUSA Healthcare MM', 2017, 'USD', 111538.465084000010 , 202212, '683', 'Core', '202212|2017|683|USD|Core', 'XL', 'Systemic cover - Clash'),

(1412, 'BUSA Healthcare MM', 2016, 'USD', 1005840.732387999900 , 202212, '683', 'Core', '202212|2016|683|USD|Core', 'XL', 'Systemic cover - Clash'),

(1413, 'BUSA Misc Med PE', 2019, 'USD', 21793.921648000000 , 202212, '716', 'Core', '202212|2019|716|USD|Core', 'XL', 'Systemic cover - Clash'),

(1414, 'BUSA TMB PE', 2019, 'USD', 8668.934688596113 , 202212, '690', 'Core', '202212|2019|690|USD|Core', 'XL', 'Systemic cover - Clash'),

(1415, 'BUSA TMB PE', 2020, 'USD', 6762.612241142073 , 202212, '690', 'Core', '202212|2020|690|USD|Core', 'XL', 'Systemic cover - Clash'),

(1416, 'BUSA TMB PE US Info Sec', 2019, 'USD', 68073.436678672675 , 202212, '723', 'Core', '202212|2019|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(1417, 'BUSA TMB PE US Info Sec', 2020, 'USD', 33942.858142077865 , 202212, '723', 'Core', '202212|2020|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(1418, 'BUSA TMB PE US Info Sec', 2014, 'USD', 0.115500000000 , 202212, '723', 'Core', '202212|2014|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(1419, 'BUSA TMB PE US Info Sec', 2018, 'USD', 11256.634242445754 , 202212, '723', 'Core', '202212|2018|723|USD|Core', 'XL', 'Systemic cover - Clash'),

(1420, 'BUSA TMB US E&O', 2014, 'USD', 13.736250000000 , 202212, '689', 'Core', '202212|2014|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(1421, 'BUSA TMB US E&O', 2019, 'USD', 151714.181143137860 , 202212, '689', 'Core', '202212|2019|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(1422, 'BUSA TMB US E&O', 2015, 'USD', 0.313500000000 , 202212, '689', 'Core', '202212|2015|689|USD|Core', 'XL', 'Systemic cover - Clash'),

(1423, 'BUSA TMB US Info Sec', 2015, 'USD', 0.528000000000 , 202212, '714', 'Core', '202212|2015|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(1424, 'BUSA TMB US Info Sec', 2014, 'USD', 1088.876250000205 , 202212, '714', 'Core', '202212|2014|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(1425, 'BUSA TMB US Info Sec', 2020, 'USD', 22310.823548616841 , 202212, '714', 'Core', '202212|2020|714|USD|Core', 'XL', 'Systemic cover - Clash'),

(1426, 'BUSA US InfoSec MM BBR', 2021, 'USD', 170003.979516443800 , 202212, '763', 'Core', '202212|2021|763|USD|Core', 'XL', 'Systemic cover - Clash'),

(1427, 'BUSA US InfoSec MM BBR', 2019, 'USD', 87878.020440433174 , 202212, '763', 'Core', '202212|2019|763|USD|Core', 'XL', 'Systemic cover - Clash'),

(1428, 'D&O', 2020, 'USD', 323.511132000000 , 202212, '6', 'Core', '202212|2020|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1429, 'D&O', 2016, 'USD', 2644701.255084000000 , 202212, '6', 'Core', '202212|2016|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1430, 'D&O', 2008, 'USD', 305195.259000012650 , 202212, '6', 'Core', '202212|2008|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1431, 'D&O', 2003, 'USD', 18739.424000000115 , 202212, '6', 'Core', '202212|2003|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1432, 'D&O', 2007, 'USD', 27366.671000000089 , 202212, '6', 'Core', '202212|2007|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1433, 'D&O', 2018, 'USD', 1158.974064000000 , 202212, '6', 'Core', '202212|2018|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1434, 'D&O', 2019, 'USD', 1774.899284000000 , 202212, '6', 'Core', '202212|2019|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1435, 'D&O', 2015, 'USD', 117969.256327999990 , 202212, '6', 'Core', '202212|2015|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1436, 'D&O', 2010, 'USD', 406.745999999999 , 202212, '6', 'Core', '202212|2010|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1437, 'D&O', 2009, 'USD', 1492.419000000053 , 202212, '6', 'Core', '202212|2009|6|USD|Core', 'XL', 'Systemic cover - Clash'),

(1438, 'DIN US Lawyers', 2011, 'USD', 73.370000000000 , 202212, '7', 'Core', '202212|2011|7|USD|Core', 'XL', 'Systemic cover - Clash'),

(1439, 'EPL', 2009, 'USD', 15.854000000000 , 202212, '8', 'Core', '202212|2009|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(1440, 'EPL', 2007, 'USD', 647.289999999994 , 202212, '8', 'Core', '202212|2007|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(1441, 'EPL', 2008, 'USD', 1895.502000000000 , 202212, '8', 'Core', '202212|2008|8|USD|Core', 'XL', 'Systemic cover - Clash'),

(1442, 'Healthcare-Hospitals', 2016, 'USD', 2598.787644000000 , 202212, '756', 'Core', '202212|2016|756|USD|Core', 'XL', 'Systemic cover - Clash'),

(1443, 'Healthcare-Hospitals', 2015, 'USD', 3956.747428000000 , 202212, '756', 'Core', '202212|2015|756|USD|Core', 'XL', 'Systemic cover - Clash'),

(1444, 'International', 2020, 'CAD', 867.911684732862 , 202212, '10', 'Core', '202212|2020|10|CAD|Core', 'XL', 'Systemic cover - Clash'),

(1445, 'International ML', 2021, 'GBP', 903.575456000000 , 202212, '762', 'Core', '202212|2021|762|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1446, 'International ML', 2020, 'GBP', 2716.845696000000 , 202212, '762', 'Core', '202212|2020|762|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1447, 'International ML', 2019, 'CAD', 0.237084000000 , 202212, '762', 'Core', '202212|2019|762|CAD|Core', 'XL', 'Systemic cover - Clash'),

(1448, 'Mid Market Lawyers', 2009, 'USD', 5229.114499999792 , 202212, '663', 'Core', '202212|2009|663|USD|Core', 'XL', 'Systemic cover - Clash'),

(1449, 'PE Media US', 2019, 'GBP', 281.675163064148 , 202212, '905', 'Core', '202212|2019|905|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1450, 'PI-Ins Brokers exBLPT', 2008, 'USD', 3718.566000000000 , 202212, '14', 'Core', '202212|2008|14|USD|Core', 'XL', 'Systemic cover - Clash'),

(1451, 'PI-Lawyers exBLPT', 2005, 'USD', 3.934500000000 , 202212, '15', 'Core', '202212|2005|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1452, 'PI-Lawyers exBLPT', 2004, 'USD', 31649.470500000753 , 202212, '15', 'Core', '202212|2004|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1453, 'PI-Lawyers exBLPT', 2007, 'USD', 22907.194000000134 , 202212, '15', 'Core', '202212|2007|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1454, 'PI-Lawyers exBLPT', 2010, 'USD', 13963.278500000481 , 202212, '15', 'Core', '202212|2010|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1455, 'PI-Lawyers exBLPT', 2009, 'USD', 645253.990999999920 , 202212, '15', 'Core', '202212|2009|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1456, 'PI-Lawyers exBLPT', 2012, 'USD', 63.932500000001 , 202212, '15', 'Core', '202212|2012|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1457, 'PI-Lawyers exBLPT', 2008, 'USD', 927206.540499999190 , 202212, '15', 'Core', '202212|2008|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1458, 'PI-Lawyers exBLPT', 2006, 'USD', 472.527499999982 , 202212, '15', 'Core', '202212|2006|15|USD|Core', 'XL', 'Systemic cover - Clash'),

(1459, 'PI-Other exBLPT', 2011, 'USD', 0.662500000000 , 202212, '18', 'Core', '202212|2011|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(1460, 'PI-Other exBLPT', 2010, 'USD', 6.810000000000 , 202212, '18', 'Core', '202212|2010|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(1461, 'PI-Other exBLPT', 2007, 'USD', 21.904000000001 , 202212, '18', 'Core', '202212|2007|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(1462, 'PI-Other exBLPT', 2008, 'USD', 50.140000000001 , 202212, '18', 'Core', '202212|2008|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(1463, 'PI-Other exBLPT', 2009, 'USD', 6279.769999999786 , 202212, '18', 'Core', '202212|2009|18|USD|Core', 'XL', 'Systemic cover - Clash'),

(1464, 'Specialty (PT)', 2008, 'USD', 848736.325999999770 , 202212, '27', 'Core', '202212|2008|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1465, 'Specialty (PT)', 2006, 'USD', 84.088499999998 , 202212, '27', 'Core', '202212|2006|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1466, 'Specialty (PT)', 2010, 'USD', 4171.715499999933 , 202212, '27', 'Core', '202212|2010|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1467, 'Specialty (PT)', 2011, 'USD', 54491.487000000139 , 202212, '27', 'Core', '202212|2011|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1468, 'Specialty (PT)', 2009, 'USD', 113043.536000000080 , 202212, '27', 'Core', '202212|2009|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1469, 'Specialty (PT)', 2007, 'USD', 610.052499999991 , 202212, '27', 'Core', '202212|2007|27|USD|Core', 'XL', 'Systemic cover - Clash'),

(1470, 'TMB INT InfoSec MM BBR', 2019, 'CAD', 9941.738907279912 , 202212, '769', 'Core', '202212|2019|769|CAD|Core', 'XL', 'Systemic cover - Clash'),

(1471, 'TMB INT InfoSec MM BBR', 2020, 'GBP', 8224.651262100146 , 202212, '769', 'Core', '202212|2020|769|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1472, 'TMB INT InfoSec MM BBR', 2021, 'USD', 10609.228504469407 , 202212, '769', 'Core', '202212|2021|769|USD|Core', 'XL', 'Systemic cover - Clash'),

(1473, 'TMB INT InfoSec MM BBR', 2021, 'EUR', 4357.372964606475 , 202212, '769', 'Core', '202212|2021|769|EUR|Core', 'XL', 'Systemic cover - Clash'),

(1474, 'TMB Large Risk Int', 2014, 'USD', 5.090250000000 , 202212, '712', 'Core', '202212|2014|712|USD|Core', 'XL', 'Systemic cover - Clash'),

(1475, 'TMB LargeRisk Int InfoSec', 2019, 'GBP', 575721.691636102510 , 202212, '744', 'Core', '202212|2019|744|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1476, 'TMB LargeRisk Int InfoSec', 2020, 'USD', 357914.152063878720 , 202212, '744', 'Core', '202212|2020|744|USD|Core', 'XL', 'Systemic cover - Clash'),

(1477, 'TMB LargeRisk Int InfoSec', 2020, 'EUR', 14219.941995813428 , 202212, '744', 'Core', '202212|2020|744|EUR|Core', 'XL', 'Systemic cover - Clash'),

(1478, 'TMB UK Info Sec', 2014, 'USD', 5.676000000000 , 202212, '721', 'Core', '202212|2014|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(1479, 'TMB UK Info Sec', 2015, 'USD', 1072.986749999691 , 202212, '721', 'Core', '202212|2015|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(1480, 'TMB UK Info Sec', 2020, 'USD', 340901.003824671030 , 202212, '721', 'Core', '202212|2020|721|USD|Core', 'XL', 'Systemic cover - Clash'),

(1481, 'TMB UK InfoSec MM BBR', 2018, 'USD', 77138.938566273762 , 202212, '765', 'Core', '202212|2018|765|USD|Core', 'XL', 'Systemic cover - Clash'),

(1482, 'TMB UK Tech', 2015, 'USD', 112025.900420000000 , 202212, '19', 'Core', '202212|2015|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1483, 'TMB UK Tech', 2010, 'USD', 36080.592999999993 , 202212, '19', 'Core', '202212|2010|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1484, 'TMB UK Tech', 2007, 'USD', 102329.806499995290 , 202212, '19', 'Core', '202212|2007|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1485, 'TMB UK Tech', 2018, 'USD', 2950435.011517792500 , 202212, '19', 'Core', '202212|2018|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1486, 'TMB UK Tech', 2016, 'USD', 3727.705488000000 , 202212, '19', 'Core', '202212|2016|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1487, 'TMB UK Tech', 2017, 'USD', 23294.887472000002 , 202212, '19', 'Core', '202212|2017|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1488, 'TMB UK Tech', 2006, 'USD', 35.511500000001 , 202212, '19', 'Core', '202212|2006|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1489, 'TMB UK Tech', 2008, 'USD', 598235.322000000000 , 202212, '19', 'Core', '202212|2008|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1490, 'TMB UK Tech', 2014, 'USD', 0.107250000000 , 202212, '19', 'Core', '202212|2014|19|USD|Core', 'XL', 'Systemic cover - Clash'),

(1491, 'UK', 2006, 'EUR', 6311.732499999809 , 202212, '24', 'Core', '202212|2006|24|EUR|Core', 'XL', 'Systemic cover - Clash'),

(1492, 'UK', 2007, 'GBP', 220.054500000006 , 202212, '24', 'Core', '202212|2007|24|GBP|Core', 'XL', 'Systemic cover - Clash'),

(1493, 'US PE Londo', 2018, 'USD', 4614.979018278376 , 202212, '25', 'Core', '202212|2018|25|USD|Core', 'XL', 'Systemic cover - Clash')                                 

) as Source ([id],[TriFocusName], [YOA], [CCY], [ClashIBNR], [Period], [TrifocusCode], [EntitySet], [ClashKey], [RIPolicyType], [ProgrammeCode]) 
on Target.[Id]=Source.[Id]

WHEN MATCHED 
		and [Target].[TriFocusName]         != Source.[TriFocusName]
		or  [Target].[YOA]      != Source.[YOA]
		or  [Target].[CCY]   != Source.[CCY]
		or  [Target].[ClashIBNR]   != Source.[ClashIBNR]
		or  [Target].[Period]   != Source.[Period]
		or  [Target].[TrifocusCode]   != Source.[TrifocusCode]
		or  [Target].[EntitySet]   != Source.[EntitySet]
		or  [Target].[ClashKey]   != Source.[ClashKey]
		or  [Target].[RIPolicyType]   != Source.[RIPolicyType]
		or  [Target].[ProgrammeCode]   != Source.[ProgrammeCode]
THEN 
UPDATE SET  [Target].[TriFocusName]         = Source.[TriFocusName]
			,[Target].[YOA]      = Source.[YOA]
			,[Target].[CCY]   = Source.[CCY]
			,[Target].[ClashIBNR]   = Source.[ClashIBNR]
			,[Target].[Period]   = Source.[Period]
			,[Target].[TrifocusCode]   = Source.[TrifocusCode]
			,[Target].[EntitySet]   = Source.[EntitySet]
			,[Target].[ClashKey]   = Source.[ClashKey]
			,[Target].[RIPolicyType]   = Source.[RIPolicyType]
			,[Target].[ProgrammeCode]   = Source.[ProgrammeCode]    
		   
WHEN NOT MATCHED BY TARGET THEN

INSERT ([id],[TriFocusName], [YOA], [CCY], [ClashIBNR], [Period], [TrifocusCode], [EntitySet], [ClashKey], [RIPolicyType], [ProgrammeCode])
VALUES (Source.[id],Source.[TriFocusName], Source.[YOA], Source.[CCY], Source.[ClashIBNR], Source.[Period], Source.[TrifocusCode], Source.[EntitySet], Source.[ClashKey], Source.[RIPolicyType], Source.[ProgrammeCode])
		   
WHEN NOT MATCHED BY SOURCE THEN DELETE;

GO                                                                                                                                                                                                       
DECLARE @mergeError int                                                                                                                                                                                  
       ,@mergeCount int                                                                                                                                                                                       
SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT                                                                                                                                                   
IF @mergeError != 0                                                                                                                                                                                      
 BEGIN                                                                                                                                                                                                   
 PRINT 'ERROR OCCURRED IN MERGE FOR [MDS].[AccountNames]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); -- SQL should always return zero rows affected                           
 END                                                                                                                                                                                                     
ELSE                                                                                                                                                                                                     
 BEGIN                                                                                                                                                                                                   
 PRINT '[MDS].[AccountNames] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));                                                                                              
 END                                                                                                                                                                                                     
GO                                                                                                                                                                                                       
          