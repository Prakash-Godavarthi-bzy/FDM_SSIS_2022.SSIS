﻿USE FinanceLanding
GO
----Static table Scripts---
TRUNCATE TABLE [mds].[ProgrammeTrifocusStaticMapping]

INSERT INTO [mds].[ProgrammeTrifocusStaticMapping] (Programme,TrifocusCode,TrifocusName) 
VALUES ('HVH fac', 'TRI00002', 'BUSA Homeowners') ,
('Enviro Swiss Re Facility', '705', 'BUSA Environmental Occ') ,
('Breckenridge', 'TRI00007', 'Covers US') 

