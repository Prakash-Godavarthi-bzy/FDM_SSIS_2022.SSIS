﻿Merge into [ADMRI].[PERIODS_CLASH] as Target
Using (Values
(1, 201811, 201809, 'StaticScript'),
(2, 201812, 201812, 'StaticScript'),
(3, 201905, 201903, 'StaticScript'),
(4, 201906, 201906, 'StaticScript'),
(5, 201911, 201909, 'StaticScript'),
(6, 201912, 201912, 'StaticScript'),
(7, 202003, 202003, 'StaticScript'),
(8, 202006, 202006, 'StaticScript'),
(9, 202011, 202009, 'StaticScript'),
(10, 202012, 202012, 'StaticScript'),
(11, 202105, 202103, 'StaticScript'),
(12, 202106, 202106, 'StaticScript'),
(13, 202111, 202109, 'StaticScript'),
(14, 202112, 202112, 'StaticScript'),
(15, 202205, 202203, 'StaticScript'),
(16, 202206, 202206, 'StaticScript'),
(17, 202211, 202209, 'StaticScript'),
(18, 202212, 202212, 'StaticScript'),
(19, 202305, 202303, 'StaticScript'),
(20, 202306, 202306, 'StaticScript'),
(21, 202311, 202309, 'StaticScript'),
(22, 202312, 202312, 'StaticScript'),
(23, 202405, 202403, 'StaticScript')

) as Source (Id,RDPeriod, ClashPeriod, AuditSource)
on Target.[Id]=Source.[Id]

WHEN MATCHED 
		and Target.ClashPeriod !=Source.ClashPeriod
		or  [Target].RDPeriod      != Source.RDPeriod
		or  [Target].[AuditSource]      != Source.[AuditSource]
		
THEN 
UPDATE SET  Target.ClashPeriod=Source.ClashPeriod,
		  [Target].RDPeriod      = Source.RDPeriod,
		  [Target].[AuditSource]      = Source.[AuditSource],
		  [Target].[AuditGenerateDatetime] = getdate()
		   
WHEN NOT MATCHED BY TARGET THEN

INSERT (ClashPeriod,RDPeriod,[AuditSource])
VALUES (Source.ClashPeriod, Source.RDPeriod,Source.[AuditSource])
		   
WHEN NOT MATCHED BY SOURCE THEN DELETE;

GO                                                                                                                                                                                                       
DECLARE @mergeError int                                                                                                                                                                                  
       ,@mergeCount int                                                                                                                                                                                       
SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT                                                                                                                                                   
IF @mergeError != 0                                                                                                                                                                                      
 BEGIN                                                                                                                                                                                                   
 PRINT 'ERROR OCCURRED IN MERGE FOR [MDS].[AccountNames]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); -- SQL should always return zero rows affected                           
 END                                                                                                                                                                                                     
ELSE                                                                                                                                                                                                     
 BEGIN                                                                                                                                                                                                   
 PRINT '[MDS].[AccountNames] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));                                                                                              
 END                                                                                                                                                                                                     
GO  
