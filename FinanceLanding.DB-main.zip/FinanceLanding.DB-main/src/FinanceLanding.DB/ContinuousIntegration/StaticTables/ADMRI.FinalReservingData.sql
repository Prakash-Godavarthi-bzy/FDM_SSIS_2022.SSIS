﻿Merge into [ADMRI].[PERIODS_FINALRESERVINGDATA] as Target
Using (Values
 (201811, '201809','StaticScript')
,(201812, '201812','StaticScript')
,(201905, '201903','StaticScript')
,(201906, '201906','StaticScript')
,(201911, '201909','StaticScript')
,(201912, '201912','StaticScript')
,(202003, '202003','StaticScript')
,(202006, '202006','StaticScript')
,(202011, '202009','StaticScript')
,(202012, '202012','StaticScript')
,(202105, '202103','StaticScript')
,(202106, '202106','StaticScript')
,(202111, '202109','StaticScript')
,(202112, '202112','StaticScript')
,(202205, '202203','StaticScript')
,(202206, '202206','StaticScript')
,(202211, '202209','StaticScript')
,(202212, '202212','StaticScript')
,(202305, '202303','StaticScript')
,(202306, '202306','StaticScript')
,(202311, '202309','StaticScript')
,(202312, '202312','StaticScript')
,(202405, '202403','StaticScript')
) as Source (AsAt,Dateoffact,AuditSource)
on Target.[AsAt]=Source.[AsAt]

WHEN MATCHED 
		and Target.[AsAt] !=Source.[AsAt]
		or  [Target].[Dateoffact]      != Source.[Dateoffact]
		or  [Target].[AuditSource]      != Source.[AuditSource]
		
THEN 
UPDATE SET  Target.[AsAt]=Source.[AsAt],
		  [Target].[Dateoffact]      = Source.[Dateoffact],
		  [Target].[AuditSource]      = Source.[AuditSource],
		  [Target].[AuditGenerateDatetime] = getdate()
		   
WHEN NOT MATCHED BY TARGET THEN

INSERT ([AsAt],[Dateoffact],[AuditSource])
VALUES (Source.[AsAt], Source.[Dateoffact],Source.[AuditSource])
		   
WHEN NOT MATCHED BY SOURCE THEN DELETE;

GO                                                                                                                                                                                                       
DECLARE @mergeError int                                                                                                                                                                                  
       ,@mergeCount int                                                                                                                                                                                       
SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT                                                                                                                                                   
IF @mergeError != 0                                                                                                                                                                                      
 BEGIN                                                                                                                                                                                                   
 PRINT 'ERROR OCCURRED IN MERGE FOR [MDS].[AccountNames]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); -- SQL should always return zero rows affected                           
 END                                                                                                                                                                                                     
ELSE                                                                                                                                                                                                     
 BEGIN                                                                                                                                                                                                   
 PRINT '[MDS].[AccountNames] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));                                                                                              
 END                                                                                                                                                                                                     
GO  
