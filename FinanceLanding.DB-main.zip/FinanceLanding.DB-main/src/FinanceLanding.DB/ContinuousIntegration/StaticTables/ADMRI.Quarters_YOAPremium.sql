﻿Merge into ADMRI.Quarters_YOAPremium as Target
Using (Values
(1, '2018-12-01', 'Include', 'StaticScript'),
(2, '2019-03-01', 'Include', 'StaticScript'),
(3, '2019-06-01', 'Include', 'StaticScript'),
(4, '2019-09-01', 'Include', 'StaticScript'),
(5, '2019-12-01', 'Include', 'StaticScript'),
(6, '2020-03-01', 'Include', 'StaticScript'),
(7, '2020-06-01', 'Include', 'StaticScript'),
(8, '2020-09-01', 'Include', 'StaticScript'),
(9, '2020-12-01', 'Include', 'StaticScript'),
(10, '2021-03-01', 'Include', 'StaticScript'),
(11, '2021-06-01', 'Include', 'StaticScript'),
(12, '2021-09-01', 'Include', 'StaticScript'),
(13, '2021-12-01', 'Include', 'StaticScript'),
(14, '2022-03-01', 'Include', 'StaticScript'),
(15, '2022-06-01', 'Include', 'StaticScript'),
(16, '2022-09-01', 'Include', 'StaticScript'),
(17, '2022-12-01', 'Include', 'StaticScript'),
(18, '2023-03-01', 'Include', 'StaticScript'),
(19, '2023-06-01', 'Include', 'StaticScript'),
(20, '2023-09-01', 'Include', 'StaticScript'),
(21, '2023-12-01', 'Include', 'StaticScript'),
(22, '2024-03-01', 'Include', 'StaticScript'),
(23, '2024-06-01', 'Include', 'StaticScript')


) as Source (Id,Quarter, Dummy, AuditSource)
on Target.[Id]=Source.[Id]

WHEN MATCHED 
		and Target.[Quarter] !=Source.[Quarter]
		or  [Target].[Dummy]      != Source.[Dummy]
		or  [Target].[AuditSource]      != Source.[AuditSource]
		
THEN 
UPDATE SET  Target.[Quarter]=Source.[Quarter],
		  [Target].[Dummy]      = Source.[Dummy],
		  [Target].[AuditSource]      = Source.[AuditSource],
		  [Target].[AuditGenerateDatetime] = getdate()
		   
WHEN NOT MATCHED BY TARGET THEN

INSERT ([Quarter],[Dummy],[AuditSource])
VALUES (Source.Quarter, Source.Dummy,Source.[AuditSource])
		   
WHEN NOT MATCHED BY SOURCE THEN DELETE;

GO                                                                                                                                                                                                       
DECLARE @mergeError int                                                                                                                                                                                  
       ,@mergeCount int                                                                                                                                                                                       
SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT                                                                                                                                                   
IF @mergeError != 0                                                                                                                                                                                      
 BEGIN                                                                                                                                                                                                   
 PRINT 'ERROR OCCURRED IN MERGE FOR [MDS].[AccountNames]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); -- SQL should always return zero rows affected                           
 END                                                                                                                                                                                                     
ELSE                                                                                                                                                                                                     
 BEGIN                                                                                                                                                                                                   
 PRINT '[MDS].[AccountNames] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));                                                                                              
 END                                                                                                                                                                                                     
GO  
