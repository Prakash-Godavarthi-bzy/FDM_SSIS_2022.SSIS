Merge into [MDS].[InvalidRDrecords] as Target
Using (Values
(38423592, 202006, '202006|2018|668|USD', 2018, 'BICI A&E MM', 'BICI A&E MM2018', 0),

(38423599, 202006, '202006|2019|668|USD', 2019, 'BICI A&E MM', 'BICI A&E MM2019', 0),

(38423606, 202006, '202006|2020|668|USD', 2020, 'BICI A&E MM', 'BICI A&E MM2020', 0),

(38412140, 202006, '202006|2018|736|USD', 2018, 'BICI BBR Services MM', 'BICI BBR Services MM2018', 0),

(38412147, 202006, '202006|2019|736|USD', 2019, 'BICI BBR Services MM', 'BICI BBR Services MM2019', 0),

(38412154, 202006, '202006|2020|736|USD', 2020, 'BICI BBR Services MM', 'BICI BBR Services MM2020', 0),

(38423667, 202006, '202006|2018|735|USD', 2018, 'BICI BBR Services PE', 'BICI BBR Services PE2018', 0),

(38423674, 202006, '202006|2019|735|USD', 2019, 'BICI BBR Services PE', 'BICI BBR Services PE2019', 0),

(38423681, 202006, '202006|2020|735|USD', 2020, 'BICI BBR Services PE', 'BICI BBR Services PE2020', 0),

(38412191, 202006, '202006|2018|699|USD', 2018, 'BICI CommercialCrime', 'BICI CommercialCrime2018', 0),

(38412198, 202006, '202006|2019|699|USD', 2019, 'BICI CommercialCrime', 'BICI CommercialCrime2019', 0),

(38412205, 202006, '202006|2020|699|USD', 2020, 'BICI CommercialCrime', 'BICI CommercialCrime2020', 0),

(38412274, 202006, '202006|2018|671|USD', 2018, 'BICI D&O MM', 'BICI D&O MM2018', 0),

(38412282, 202006, '202006|2019|671|USD', 2019, 'BICI D&O MM', 'BICI D&O MM2019', 0),

(38412289, 202006, '202006|2020|671|USD', 2020, 'BICI D&O MM', 'BICI D&O MM2020', 0),

(38423708, 202006, '202006|2018|700|USD', 2018, 'BICI Environmental FS', 'BICI Environmental FS2018', 0),

(38423714, 202006, '202006|2019|700|USD', 2019, 'BICI Environmental FS', 'BICI Environmental FS2019', 0),

(38423720, 202006, '202006|2020|700|USD', 2020, 'BICI Environmental FS', 'BICI Environmental FS2020', 0),

(38412353, 202006, '202006|2018|672|USD', 2018, 'BICI EPL MM', 'BICI EPL MM2018', 0),

(38412361, 202006, '202006|2019|672|USD', 2019, 'BICI EPL MM', 'BICI EPL MM2019', 0),

(38412368, 202006, '202006|2020|672|USD', 2020, 'BICI EPL MM', 'BICI EPL MM2020', 0),

(38412422, 202006, '202006|2018|673|USD', 2018, 'BICI EPL PE', 'BICI EPL PE2018', 0),

(38412429, 202006, '202006|2019|673|USD', 2019, 'BICI EPL PE', 'BICI EPL PE2019', 0),

(38412436, 202006, '202006|2020|673|USD', 2020, 'BICI EPL PE', 'BICI EPL PE2020', 0),

(38412467, 202006, '202006|2018|719|USD', 2018, 'BICI Financial Crime', 'BICI Financial Crime2018', 0),

(38412474, 202006, '202006|2019|719|USD', 2019, 'BICI Financial Crime', 'BICI Financial Crime2019', 0),

(38412481, 202006, '202006|2020|719|USD', 2020, 'BICI Financial Crime', 'BICI Financial Crime2020', 0),

(38423809, 202006, '202006|2018|696|USD', 2018, 'BICI Healthcare ML', 'BICI Healthcare ML2018', 0),

(38423816, 202006, '202006|2019|696|USD', 2019, 'BICI Healthcare ML', 'BICI Healthcare ML2019', 0),

(38423823, 202006, '202006|2020|696|USD', 2020, 'BICI Healthcare ML', 'BICI Healthcare ML2020', 0),

(38423747, 202006, '202006|2018|674|USD', 2018, 'BICI HEALTHCARE MM', 'BICI HEALTHCARE MM2018', 0),

(38423754, 202006, '202006|2019|674|USD', 2019, 'BICI HEALTHCARE MM', 'BICI HEALTHCARE MM2019', 0),

(38423761, 202006, '202006|2020|674|USD', 2020, 'BICI HEALTHCARE MM', 'BICI HEALTHCARE MM2020', 0),

(38423883, 202006, '202006|2019|715|USD', 2019, 'BICI Misc Med PE', 'BICI Misc Med PE2019', 0),

(38423890, 202006, '202006|2020|715|USD', 2020, 'BICI Misc Med PE', 'BICI Misc Med PE2020', 0),

(38423856, 202006, '202006|2020|747|USD', 2020, 'BICI MM Health Occurrence', 'BICI MM Health Occurrence2020', 0),

(38423917, 202006, '202006|2019|739|USD', 2019, 'BICI Specialty Embedded', 'BICI Specialty Embedded2019', 0),

(38423923, 202006, '202006|2020|739|USD', 2020, 'BICI Specialty Embedded', 'BICI Specialty Embedded2020', 0),

(38423984, 202006, '202006|2018|687|USD', 2018, 'BICI TMB PE', 'BICI TMB PE2018', 0),

(38423991, 202006, '202006|2019|687|USD', 2019, 'BICI TMB PE', 'BICI TMB PE2019', 0),

(38423998, 202006, '202006|2020|687|USD', 2020, 'BICI TMB PE', 'BICI TMB PE2020', 0),

(38424028, 202006, '202006|2018|722|USD', 2018, 'BICI TMB PE US Info Sec', 'BICI TMB PE US Info Sec2018', 0),

(38424035, 202006, '202006|2019|722|USD', 2019, 'BICI TMB PE US Info Sec', 'BICI TMB PE US Info Sec2019', 0),

(38424042, 202006, '202006|2020|722|USD', 2020, 'BICI TMB PE US Info Sec', 'BICI TMB PE US Info Sec2020', 0),

(38412546, 202006, '202006|2018|686|USD', 2018, 'BICI TMB US E&O', 'BICI TMB US E&O2018', 0),

(38412553, 202006, '202006|2019|686|USD', 2019, 'BICI TMB US E&O', 'BICI TMB US E&O2019', 0),

(38412560, 202006, '202006|2020|686|USD', 2020, 'BICI TMB US E&O', 'BICI TMB US E&O2020', 0),

(38412595, 202006, '202006|2018|713|USD', 2018, 'BICI TMB US Info Sec', 'BICI TMB US Info Sec2018', 0),

(38412602, 202006, '202006|2019|713|USD', 2019, 'BICI TMB US Info Sec', 'BICI TMB US Info Sec2019', 0),

(38412609, 202006, '202006|2020|713|USD', 2020, 'BICI TMB US Info Sec', 'BICI TMB US Info Sec2020', 0),

(38412624, 202006, '202006|2018|764|USD', 2018, 'BICI US InfoSec MM BBR', 'BICI US InfoSec MM BBR2018', 0),

(38412631, 202006, '202006|2019|764|USD', 2019, 'BICI US InfoSec MM BBR', 'BICI US InfoSec MM BBR2019', 0),

(38412638, 202006, '202006|2020|764|USD', 2020, 'BICI US InfoSec MM BBR', 'BICI US InfoSec MM BBR2020', 0),

(38424077, 202006, '202006|2018|688|USD', 2018, 'BICI US PROGRAMMES', 'BICI US PROGRAMMES2018', 0),

(38424084, 202006, '202006|2019|688|USD', 2019, 'BICI US PROGRAMMES', 'BICI US PROGRAMMES2019', 0),

(38424091, 202006, '202006|2020|688|USD', 2020, 'BICI US PROGRAMMES', 'BICI US PROGRAMMES2020', 0),

(38425820, 202006, '202006|2019|9|USD', 2019, 'Healthcare', 'Healthcare2019', 0),

(38425819, 202006, '202006|2019|9|USD', 2019, 'Healthcare', 'Healthcare2019', 0)

) as Source ([id], [asat], [RDKey], [yoa], [triangle_group], [Lookup], [Periods])
on Target.[Id]=Source.[Id]

WHEN MATCHED 
		and [Target].[id]         != Source.[id]
		or  [Target].[asat]      != Source.[asat]
		or  [Target].[RDKey]   != Source.[RDKey]
		or  [Target].[yoa]   != Source.[yoa]
		or  [Target].[TriangleGroup]   != Source.[triangle_group]
		or  [Target].[Lookup]   != Source.[Lookup]
		or  [Target].[Periods]   != Source.[Periods]

THEN 
UPDATE SET  [Target].[id]         = Source.[id]
		,[Target].[asat]      = Source.[asat]
		,[Target].[RDKey]   = Source.[RDKey]
		,[Target].[yoa]   = Source.[yoa]
		,[Target].[TriangleGroup]   = Source.[triangle_group]
		,[Target].[Lookup]   = Source.[Lookup]
		,[Target].[Periods]   = Source.[Periods]
		   
WHEN NOT MATCHED BY TARGET THEN

INSERT ([id], [asat], [RDKey], [yoa], [TriangleGroup], [Lookup], [Periods])
VALUES (Source.[id], Source.[asat], Source.[RDKey], Source.[yoa], Source.[triangle_group], Source.[Lookup], Source.[Periods])
		   
WHEN NOT MATCHED BY SOURCE THEN DELETE;

GO                                                                                                                                                                                                       
DECLARE @mergeError int                                                                                                                                                                                  
       ,@mergeCount int                                                                                                                                                                                       
SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT                                                                                                                                                   
IF @mergeError != 0                                                                                                                                                                                      
 BEGIN                                                                                                                                                                                                   
 PRINT 'ERROR OCCURRED IN MERGE FOR [MDS].[AccountNames]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); -- SQL should always return zero rows affected                           
 END                                                                                                                                                                                                     
ELSE                                                                                                                                                                                                     
 BEGIN                                                                                                                                                                                                   
 PRINT '[MDS].[AccountNames] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));                                                                                              
 END                                                                                                                                                                                                     
GO  
