﻿USE FinanceLanding
GO
TRUNCATE TABLE MDS.RITypeMapping
INSERT INTO MDS.RITypeMapping
SELECT *
FROM
(
SELECT 'CLASH' AS RIPolicyType,'XL' AS Confirmed_RIPolicyType UNION 
SELECT 'FAC' AS RIPolicyType,'FAC' AS Confirmed_RIPolicyType UNION 
SELECT 'PPNL' AS RIPolicyType,'QS' AS Confirmed_RIPolicyType UNION 
SELECT 'PROFS' AS RIPolicyType,'XL' AS Confirmed_RIPolicyType UNION 
SELECT 'QQ' AS RIPolicyType,'QS' AS Confirmed_RIPolicyType UNION 
SELECT 'QS' AS RIPolicyType,'QS' AS Confirmed_RIPolicyType UNION 
SELECT 'RE' AS RIPolicyType,'XL' AS Confirmed_RIPolicyType UNION 
SELECT 'RPP' AS RIPolicyType,'XL' AS Confirmed_RIPolicyType UNION 
SELECT 'SL' AS RIPolicyType,'XL' AS Confirmed_RIPolicyType UNION 
SELECT 'Surplus' AS RIPolicyType,'QS' AS Confirmed_RIPolicyType UNION 
SELECT'XL' AS RIPolicyType,'XL' AS Confirmed_RIPolicyType  UNION
SELECT 'IR' AS RIPolicyType,'XL' AS Confirmed_RIPolicyType UNION
SELECT'UCT' AS RIPolicyType,'QS' AS Confirmed_RIPolicyType
) as t
