/* ===========================================================================================================
	Created By:		Venkat.Yerravati@beazley.com
	Created date:	19/01/2024
	Description:	Static Script is created to prevent the possibility of unconformed Programmes being introduced through RI Spend for Historical Data which is happening in the view vw_DimRIPolicy. 
					--https://beazley.atlassian.net/browse/I1B-5059
=================================================================================================================== 
Created By:		ShahNawaz.Ahmed@beazley.com
	Created date:	05/11/2024
	Description:	Added new record to resolve Unallocated TF of RI LPSO TTY Signings for Cyber Catastrophe. 
					--https://beazley.atlassian.net/browse/I1B-5905
===================================================================================================================
Created By:		ShahNawaz.Ahmed@beazley.com
	Created date:	03/12/2024
	Description:	Added new record for RI Spend Programmes. 
					--https://beazley.atlassian.net/browse/I1B-6015
===================================================================================================================*/



USE [FinanceLanding]
GO
SET NOCOUNT ON 
GO

MERGE INTO [MDS].[ConformedProgrammeMapping] AS Target

USING (VALUES
('WESTFIELD QS reinst','WESTFIELD QS','Static Script'),
('UNITED FIRE & CASUALTY QS reinst','UNITED FIRE & CASUALTY QS','Static Script'),
('DOVE QS reinst','DOVE QS','Static Script'),
('CC PROP FAC','Creechurch Property Facility','Static Script'),
('Occurrence QS Contingency','Occurrence QS','Static Script'),
('Occurrence QS PTY','Occurrence QS','Static Script'),
('AMERICAN AGRICULTURE QS reinst','AMERICAN AGRICULTURE QS','Static Script'),
('Combined Cat - PTY','Combined Cat - TTY','Static Script'),
('Open Market QS','Open Market QS US','Static Script'),
('RSUI QS reinst','RSUI QS','Static Script'),
('Open Market QS UK','Open Market QS - Swiss Re','Static Script'),
('MARGEN Terror','MARGEN','Static Script'),
('ERIE QS reinst','ERIE QS','Static Script'),
('BUPL (AIP)','BUPL (AIP) FAC account','Static Script'),
('Korean Re',	'KOREAN RE COMMON AC RI','Static Script'),
('MUNICH - Quota Share Occurrence','MUNQQS','Static Script'),
('PROPERTY CAT','Property Cat XL','Static Script'),
('US Event Liab','CONFAC','Static Script'),
('Contingent QS TRC','Contingent QS','Static Script'),
('COW QS reinst','COW QS','Static Script'),
--('ACCIDENT FUND INSURANCE CO OF AMERICA QS reinst','ACCIDENT FUND INSURANCE CO OF AMERICA QS','Static Script'), -- https://beazley.atlassian.net/browse/I1B-6015
('Product Recall','Product Recall XL','Static Script'),
('Cyber XOL','Cyber Catastrophe Excess of Loss Reinsurance','Static Script'),
('ACCIDENT FUND INSURANCE CO OF AMERICA Q','ACCIDENT FUND TREATY QS','Static Script'),
('ACCIDENT FUND INSURANCE CO OF AMERICA QS reinst','ACCIDENT FUND TREATY QS','Static Script'),
('ACCIDENT FUND TREATY QS reinst','ACCIDENT FUND TREATY QS','Static Script'),
('Aviation War and AVN52 XOL','MARINE AVIATION WAR EXCESS OF LOSS','Static Script'),
('Hospital QS','HOSPITALS QS','Static Script'),
('Tracker Cat XOL RI','TRACKER CAT XL','Static Script')


       )AS Source ([ProgrammeCode],[ConformedProgrammeMapping],[AuditSource])
			
ON (Target.[ProgrammeCode] = Source.[ProgrammeCode])

WHEN MATCHED 
		and [Target].[ProgrammeCode]				  != Source.[ProgrammeCode]
		or  [Target].[ConformedProgrammeMapping]      != Source.[ConformedProgrammeMapping]
		or  [Target].[AuditSource]					  != Source.[AuditSource]
THEN 
UPDATE SET  [ProgrammeCode]					 = Source.[ProgrammeCode]
           ,[ConformedProgrammeMapping]      = Source.[ConformedProgrammeMapping]
		   ,[AuditSource]					 = Source.[AuditSource]
		   
WHEN NOT MATCHED BY TARGET THEN

INSERT ([ProgrammeCode], [ConformedProgrammeMapping],[AuditSource])
VALUES (Source.[ProgrammeCode], Source.[ConformedProgrammeMapping],Source.[AuditSource])
		   
WHEN NOT MATCHED BY SOURCE THEN DELETE;

GO                                                                                                                                                                                                       
DECLARE @mergeError int                                                                                                                                                                                  
       ,@mergeCount int                                                                                                                                                                                       
SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT                                                                                                                                                   
IF @mergeError != 0                                                                                                                                                                                      
 BEGIN                                                                                                                                                                                                   
 PRINT 'ERROR OCCURRED IN MERGE FOR [MDS].[ConformedProgrammeMapping]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); -- SQL should always return zero rows affected                           
 END                                                                                                                                                                                                     
ELSE                                                                                                                                                                                                     
 BEGIN                                                                                                                                                                                                   
 PRINT '[MDS].[ConformedProgrammeMapping] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));                                                                                              
 END                                                                                                                                                                                                     
GO                                                                                                                                                                                                       
                                                                                                                                                                                                         
SET NOCOUNT OFF                                                                                                                                                                                          
GO     

