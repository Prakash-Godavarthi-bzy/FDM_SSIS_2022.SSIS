﻿Merge into [ADMRI].[PERIODS_RIPREMIUM] as Target
Using (Values
(1, 201812, 201811, 'StaticScript'),
(2, 201903, 201812, 'StaticScript'),
(3, 201906, 201905, 'StaticScript'),
(4, 201909, 201906, 'StaticScript'),
(5, 201912, 201911, 'StaticScript'),
(6, 202003, 201912, 'StaticScript'),
(7, 202006, 202003, 'StaticScript'),
(8, 202009, 202006, 'StaticScript'),
(9, 202012, 202011, 'StaticScript'),
(10, 202103, 202012, 'StaticScript'),
(11, 202106, 202105, 'StaticScript'),
(12, 202109, 202106, 'StaticScript'),
(13, 202112, 202111, 'StaticScript'),
(14, 202203, 202112, 'StaticScript'),
(15, 202206, 202205, 'StaticScript'),
(16, 202209, 202206, 'StaticScript'),
(17, 202212, 202211, 'StaticScript'),
(18, 202303, 202212, 'StaticScript'),
(19, 202306, 202305, 'StaticScript'),
(20, 202309, 202306, 'StaticScript'),
(21, 202312, 202311, 'StaticScript'),
(22, 202403, 202312, 'StaticScript'),
(23, 202406, 202405, 'StaticScript')


) as Source (Id,CRPeriod, RDPeriod, AuditSource)
on Target.[Id]=Source.[Id]

WHEN MATCHED 
		and Target.CRPeriod !=Source.CRPeriod
		or  [Target].RDPeriod      != Source.RDPeriod
		or  [Target].[AuditSource]      != Source.[AuditSource]
		
THEN 
UPDATE SET  Target.CRPeriod=Source.CRPeriod,
		  [Target].RDPeriod      = Source.RDPeriod,
		  [Target].[AuditSource]      = Source.[AuditSource],
		  [Target].[AuditGenerateDatetime] = getdate()
		   
WHEN NOT MATCHED BY TARGET THEN

INSERT (CRPeriod,RDPeriod,[AuditSource])
VALUES (Source.CRPeriod, Source.RDPeriod,Source.[AuditSource])
		   
WHEN NOT MATCHED BY SOURCE THEN DELETE;

GO                                                                                                                                                                                                       
DECLARE @mergeError int                                                                                                                                                                                  
       ,@mergeCount int                                                                                                                                                                                       
SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT                                                                                                                                                   
IF @mergeError != 0                                                                                                                                                                                      
 BEGIN                                                                                                                                                                                                   
 PRINT 'ERROR OCCURRED IN MERGE FOR [MDS].[AccountNames]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); -- SQL should always return zero rows affected                           
 END                                                                                                                                                                                                     
ELSE                                                                                                                                                                                                     
 BEGIN                                                                                                                                                                                                   
 PRINT '[MDS].[AccountNames] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));                                                                                              
 END                                                                                                                                                                                                     
GO  
