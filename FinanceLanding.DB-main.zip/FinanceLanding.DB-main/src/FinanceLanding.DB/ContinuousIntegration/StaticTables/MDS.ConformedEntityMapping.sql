﻿TRUNCATE TABLE  [MDS].[ConformedEntityMapping]
GO
INSERT INTO [MDS].[ConformedEntityMapping](Entity,ConformedEntityMapping )
SELECT * FROM(
SELECT '1174'As Entity,	'1174' As ConformedEntity UNION
SELECT '2623'As  Entity,	'2623' As ConformedEntity UNION
SELECT'3033'As  Entity,	'3033' As ConformedEntity UNION
SELECT '3622'As  Entity,	'3622' As ConformedEntity UNION
SELECT '3623'As  Entity,	'3623' As ConformedEntity UNION
SELECT '5623'As  Entity,	'5623' As ConformedEntity UNION
SELECT '6050'As  Entity,	'6050' As ConformedEntity UNION
SELECT '6107'As  Entity,	'6107' As ConformedEntity UNION
SELECT '623'As  Entity,	'623' As ConformedEntity UNION
SELECT '8022'As  Entity,'8022' As ConformedEntity UNION
SELECT '8033'As  Entity,'8033' As ConformedEntity UNION
SELECT 'BIARFR'As  Entity,'8033' As ConformedEntity UNION
SELECT 'BIARGE'As  Entity,'8033' As ConformedEntity UNION
SELECT 'BIARSP'As  Entity,'8033' As ConformedEntity UNION
SELECT 'BIARSW'As  Entity,'8033' As ConformedEntity UNION
SELECT 'BIARUK'As  Entity,'8033' As ConformedEntity UNION
SELECT 'BICI'As  Entity,'8022' As ConformedEntity UNION
SELECT 'BIDAC'As  Entity,'8033' As ConformedEntity UNION
SELECT 'BIFR'As  Entity,'8033' As ConformedEntity UNION
SELECT 'BIGE'As  Entity,'8033' As ConformedEntity UNION
SELECT 'BISP'As  Entity,'8033' As ConformedEntity UNION
SELECT 'BISW'As  Entity,'8033' As ConformedEntity UNION
SELECT 'BIUK'As  Entity,'8033' As ConformedEntity UNION
SELECT 'No Entity' As  Entity,'No Entity' As ConformedEntity UNION
SELECT 'USBAIC' As  Entity,'USBAIC' As ConformedEntity UNION
SELECT 'USBICI' As  Entity,'8022' As ConformedEntity UNION
SELECT 'USBUSA' As  Entity,'USBUSA' As ConformedEntity UNION
SELECT 'USSYND'As  Entity,'USSYND' As ConformedEntity UNION
SELECT 'USUKCONSOL'As  Entity,'USUKCONSOL' As ConformedEntity UNION
SELECT 'BESI'As  Entity,'8044' As ConformedEntity UNION
SELECT 'USBESI'As  Entity,'8044' As ConformedEntity UNION
SELECT '8044'As  Entity,'8044' As ConformedEntity UNION
SELECT 'BERE'As  Entity,'8033' As ConformedEntity UNION
SELECT 'BIUSPE'As  Entity,'8033' As ConformedEntity
)C
