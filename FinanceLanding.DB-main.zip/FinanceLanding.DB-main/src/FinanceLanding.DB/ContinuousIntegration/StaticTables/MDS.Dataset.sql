﻿TRUNCATE TABLE [MDS].[DataSet]
GO
INSERT INTO   [MDS].[DataSet] (PK_DataSet,BK_DataSet,GrossRI) 
SELECT * FROM( 

SELECT-2 AS PK_DataSet, 'NA' AS BK_DataSet,	'NA' AS GrossRI UNION
SELECT-1 AS PK_DataSet, 'Unknown'AS BK_DataSet,'NA' AS GrossRI UNION
SELECT 1 AS PK_DataSet, 'ADM' AS BK_DataSet,'Not in Use' AS GrossRI UNION
SELECT 2 AS PK_DataSet, 'ADM-DFMs'AS BK_DataSet,'Pattern'  AS GrossRI UNION
SELECT 3 AS PK_DataSet, 'Agresso'AS BK_DataSet,'Not in Use'  AS GrossRI UNION
SELECT 4 AS PK_DataSet, 'BI' AS BK_DataSet,	'Not in Use'  AS GrossRI UNION
SELECT 5 AS PK_DataSet, 'Claims_BI_ODS'AS BK_DataSet,'Gross'  AS GrossRI UNION
SELECT 6 AS PK_DataSet, 'EIOPA'AS BK_DataSet,'Not in Use'  AS GrossRI UNION
SELECT 7 AS PK_DataSet, 'EPI Reinstatement Eurobase'AS BK_DataSet,'Gross'  AS GrossRI UNION
SELECT 8 AS PK_DataSet, 'Eurobase'AS BK_DataSet,'Gross'  AS GrossRI UNION
SELECT 9 AS PK_DataSet, 'LPSO'AS BK_DataSet,'Gross'  AS GrossRI UNION
SELECT 10 AS PK_DataSet, 'NatCatEarning'AS BK_DataSet,'Pattern'  AS GrossRI UNION
SELECT 11 AS PK_DataSet, 'ObligatedPremium_RISpend'AS BK_DataSet,'RI'  AS GrossRI UNION
SELECT 12 AS PK_DataSet, 'PFT'AS BK_DataSet,'Gross'  AS GrossRI UNION
SELECT 13 AS PK_DataSet, 'ReservingData'AS BK_DataSet,'Both'  AS GrossRI UNION
SELECT 14 AS PK_DataSet, 'RI LPSO FAC'AS BK_DataSet,'RI'  AS GrossRI UNION
SELECT 15 AS PK_DataSet, 'RI LPSO TTY'AS BK_DataSet,'RI'  AS GrossRI UNION
SELECT 16 AS PK_DataSet, 'SIITP'AS BK_DataSet,'Not in Use'  AS GrossRI UNION
SELECT 17 AS PK_DataSet, 'USPremium'AS BK_DataSet,'Gross'  AS GrossRI UNION
SELECT 18 AS PK_DataSet, 'Interim_Ceded_Re_Closed_YOA'AS BK_DataSet,'RI'  AS GrossRI UNION
SELECT 19 AS PK_DataSet, 'Interim_USPremium'AS BK_DataSet,'Gross'  AS GrossRI UNION
SELECT 20 AS PK_DataSet, 'BICI'AS BK_DataSet,'Gross'  AS GrossRI UNION
SELECT 21 AS PK_DataSet, 'BIDAC'AS BK_DataSet,'Gross'  AS GrossRI UNION
SELECT 22 AS PK_DataSet, 'USBAIC'AS BK_DataSet,'Gross'  AS GrossRI UNION
SELECT 23 AS PK_DataSet, 'USSYND'AS BK_DataSet,'Gross'  AS GrossRI UNION
SELECT 24 AS PK_DataSet, 'ReinsuranceRebates_Ultimate'AS BK_DataSet,'RI'  AS GrossRI UNION
SELECT 25 AS PK_DataSet, 'Signed Profit Commission'AS BK_DataSet,'RI'  AS GrossRI UNION
SELECT 26 AS PK_DataSet, 'ReinsuranceRebates_Paid'AS BK_DataSet,'RI'  AS GrossRI UNION
SELECT 27 AS PK_DataSet, 'Ceded_Re_Claims_Incurred'AS BK_DataSet,'RI'  AS GrossRI UNION
SELECT 28 AS PK_DataSet, 'Ceded_Re_Closed_YOA'AS BK_DataSet,'RI'  AS GrossRI UNION
SELECT 29 AS PK_DataSet, 'Ceded_Re_ORC'AS BK_DataSet,'RI'  AS GrossRI UNION
SELECT 30 AS PK_DataSet, 'RI_SpecialArrangements'AS BK_DataSet,'RI'  AS GrossRI UNION
SELECT 31 AS PK_DataSet, 'Earned_RIP_RISpend'AS BK_DataSet,'RI'  AS GrossRI UNION
SELECT 32 AS PK_DataSet, 'Ultimate Profit Commission'AS BK_DataSet,'RI'  AS GrossRI UNION
SELECT 33 AS PK_DataSet, 'AgressoARBIDAC'AS BK_DataSet,'Gross'  AS GrossRI UNION
SELECT 34 AS PK_DataSet, 'AgressoARUS'AS BK_DataSet,'Gross'  AS GrossRI UNION
SELECT 35 AS PK_DataSet, 'BusinessPlan'AS BK_DataSet,'Gross'  AS GrossRI UNION
SELECT 36 AS PK_DataSet, 'Reinsurance_Overriding_Commission'AS BK_DataSet,'	RI'  AS GrossRI UNION
SELECT 37 AS PK_DataSet, 'BusinessPlanRI'AS BK_DataSet,'RI'  AS GrossRI UNION
SELECT 38 AS PK_DataSet, 'RIPsEventAlloc'AS BK_DataSet,'Gross'  AS GrossRI UNION
SELECT 39 AS PK_DataSet, 'ResDataEventAlloc'AS BK_DataSet,'Gross'  AS GrossRI UNION
SELECT 40 AS PK_DataSet, 'BICI_RI_Incurred'AS BK_DataSet,'RI'  AS GrossRI UNION
SELECT 41 AS PK_DataSet, 'BICI_RI_Paid'AS BK_DataSet,'RI'  AS GrossRI UNION
SELECT 42 AS PK_DataSet, 'BICI RI Ultimate Claim'AS BK_DataSet,'RI'  AS GrossRI UNION
SELECT 43 AS PK_DataSet, 'BICI TDM'AS BK_DataSet,'Gross'  AS GrossRI 

)C
