﻿TRUNCATE TABLE  [MDS].[DummyProgrammes_CededRe]
GO
INSERT INTO   [MDS].[DummyProgrammes_CededRe] (DummyPolicy,Programme) 
SELECT * FROM( 
SELECT 'X5555X94' AS [DummyPolicy],'Treaty XL' AS [Programme] UNION
SELECT 'X5555X95' AS [DummyPolicy],'Treaty XL' AS [Programme] UNION
SELECT 'R0025N94G' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'R0025N94R' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'R0025N95G' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'R0025N95R' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'R0025N96G' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'R0025N96R' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'R0025N97H' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'R0025N97R' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'R0025N98H' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'R0025N98R' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'R0025N99H' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'R0025N99R' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'X7777X97' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'X8888X93' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'X8888X94' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'X8888X95' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'X8888X96' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'X8888X97' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'X9999X93' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'X9999X94' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'X9999X95' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'X9999X96' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'X9999X97' AS [DummyPolicy],'SL Risk XoL' AS [Programme] UNION
SELECT 'R0360A03A' AS [DummyPolicy],'PRXS  ' AS [Programme] UNION
SELECT 'R0361A03A' AS [DummyPolicy],'PRXS  ' AS [Programme] UNION
SELECT 'X0042X97' AS [DummyPolicy],'PRXS  ' AS [Programme] UNION
SELECT 'X0043X97' AS [DummyPolicy],'PRXS  ' AS [Programme] UNION
SELECT 'X5555X96' AS [DummyPolicy],'Property XL' AS [Programme] UNION
SELECT 'X5555X97' AS [DummyPolicy],'Property XL' AS [Programme] UNION
SELECT 'X6666X93' AS [DummyPolicy],'Property XL' AS [Programme] UNION
SELECT 'R0070B97R' AS [DummyPolicy],'Property Risk Excess' AS [Programme] UNION
SELECT 'R0070B98R' AS [DummyPolicy],'Property Risk Excess' AS [Programme] UNION
SELECT 'X5555X93' AS [DummyPolicy],'Property Risk Excess' AS [Programme] UNION
SELECT 'X6666X94' AS [DummyPolicy],'Property Risk Excess' AS [Programme] UNION
SELECT 'X6666X95' AS [DummyPolicy],'Property Risk Excess' AS [Programme] UNION
SELECT 'R0237A01A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0352A02A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0352A03A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0352A04A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0353A02A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0354A02A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0354A03A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0355A02A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0356A03A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0357A03A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0357A04A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0358A03A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0358A04A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0359A03A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0363A03A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0365A03A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0366A03A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0366A04A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0368A02A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0380A02A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0429A03A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0430A03A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R0432A03A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R1352A03A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R1366A03A' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9352A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9352B05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9353A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9353B05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9354A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9355A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9356A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9357A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9358A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9359A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9363A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9365A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9365B05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9365C05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9366A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9366B05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9367A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9367B05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9367C05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9368A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9370A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9371A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9371B05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9372A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9379A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9420A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9429A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9430A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9431A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9432A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9433A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9554A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9559A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9560A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9561A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9562A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9563A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9564A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9565A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9566A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9567A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9567B06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9568A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9572A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9573A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9574A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9577A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9578A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9579A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9580A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9582A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9583A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9588A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9589A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9590A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9591A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9592A06' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9611A05' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9611A07' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9611B07' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9612A07' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9613A07' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9613B07' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9613C07' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9614A07' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9615A07' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9615B07' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9615C07' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9616A07' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9617A07' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9617B07' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9619A07' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9647B08' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9647C08' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9651A08' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9651B08' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9651C08' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9652A08' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9653A08' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9653B08' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9653C08' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9654A08' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9654B08' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9654C08' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9655A08' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9656A08' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9657A08' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9657B08' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9657C08' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9657D08' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9658A08' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9658B08' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9703A09' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9703B09' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9704A09' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9704B09' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'RXCOMPRX' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'RXCOMVER' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0001X93' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0001X94' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0002X93' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0003X93' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0003X94' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0003X95' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0003X96' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0003X97' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0003X98' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0004X92' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0004X94' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0004X95' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0004X96' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0004X97' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0004X98' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0005X94' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0005X95' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0006X93' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0006X94' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0006X95' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0006X96' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0006X97' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0007X93' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0007X94' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0008X93' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0008X94' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0008X95' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0008X96' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0008X97' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0010X94' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0010X96' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0010X97' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0010X98' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0022X94' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0022X95' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0022X96' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0022X97' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0022X98' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0024X93' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0027X97' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0029X93' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0029X94' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0033X96' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0033X97' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0034X94' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0034X95' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0034X96' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0034X97' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0035X95' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0036X95' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0037X95' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0037X96' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0038X95' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0038X96' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0038X97' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0038X98' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0039X95' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0039X96' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0040X97' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0040X98' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0044X97' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0137X98' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0153A98' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0153B98' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0200X93' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0200X94' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0200X95' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0200X96' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0200X97' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0207A99' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0210X93' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0210X94' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X0210X95' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X1022X95' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X1139X98' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X1139X99' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X2222X93' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X2222X94' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X3333X97' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'X7777X94' AS [DummyPolicy],'PI QS' AS [Programme] UNION
SELECT 'X7777X95' AS [DummyPolicy],'PI QS' AS [Programme] UNION
SELECT 'X7777X96' AS [DummyPolicy],'PI QS' AS [Programme] UNION
SELECT 'R1239A00' AS [DummyPolicy],'Old PA account' AS [Programme] UNION
SELECT 'R0185A99' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R1242A99' AS [DummyPolicy],'GEN RE QQS' AS [Programme] UNION
SELECT 'R1243A00' AS [DummyPolicy],'GEN RE QQS' AS [Programme] UNION
SELECT 'R9647A08' AS [DummyPolicy],'Property Cat XL' AS [Programme] UNION
SELECT 'R9620A07' AS [DummyPolicy],'MUNQQS' AS [Programme] UNION
SELECT 'R9626A07' AS [DummyPolicy],'MUNQQS' AS [Programme] UNION
SELECT 'R7652A08' AS [DummyPolicy],'MARGEN' AS [Programme] UNION
SELECT 'X6666X96' AS [DummyPolicy],'Kidnap and Ransom XL  ' AS [Programme] UNION
SELECT 'X6666X97' AS [DummyPolicy],'Kidnap and Ransom XL  ' AS [Programme] UNION
SELECT 'R0001H94R' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0001H97R' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0001H98R' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0001H99R' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0332A03A' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0339A03A' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0340A03A' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0348A02A' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0349A03A' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0351A03A' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0362A03A' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0362A04A' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0362A04B' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0364A03A' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0374A04A' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0375A04A' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0376A03A' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0376A04A' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0376A04B' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0377A03A' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0421A03A' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0421A04A' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0422A04A' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0422A04B' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0423A04A' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0424A03A' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0425A03A' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'R0505A04A' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X0022X93' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X0024X94' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X0024X95' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X0024X96' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X0027X93' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X0027X94' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X0027X95' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X0027X96' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X0030X94' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X0032X94' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X0032X96' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X0032X97' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X0033X94' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X0040X96' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X0041X97' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X0042X95' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X0042X96' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X2222X95' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X2222X96' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X2222X97' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X3333X93' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X3333X94' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X3333X95' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X3333X96' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X9999X98' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'XRRRRX99' AS [DummyPolicy],'GEN (Whole Account)' AS [Programme] UNION
SELECT 'X4444X93' AS [DummyPolicy],'Critical Asset Protection XL' AS [Programme] UNION
SELECT 'X7777X93' AS [DummyPolicy],'Casualty XL' AS [Programme] UNION
SELECT 'R0242A99' AS [DummyPolicy],'GEN RE QQS' AS [Programme] UNION
SELECT 'R0243A00' AS [DummyPolicy],'GEN RE QQS' AS [Programme] UNION
--SELECT 'R0059D99A' AS [DummyPolicy], 'PTRX' AS [Programme] UNION
--SELECT 'R0359A04A' AS [DummyPolicy],'SSHOP' AS [Programme] UNION
--SELECT 'R0374A04B' AS [DummyPolicy],'GEN' AS [Programme] UNION
--SELECT 'R0375A04B'AS [DummyPolicy],'GEN' AS  [Programme] UNION
--SELECT 'R0421A04B'AS [DummyPolicy],'GEN' AS  [Programme] UNION
--SELECT 'R0423A03A'AS [DummyPolicy],'GEN' AS  [Programme] UNION
--SELECT 'R0423A04B'AS [DummyPolicy],'GEN' AS  [Programme] UNION
--SELECT 'R0505A04B'AS [DummyPolicy],'GEN' AS  [Programme] UNION
--SELECT 'REAC'AS [DummyPolicy],'CARX' AS  [Programme] UNION
--SELECT 'RN887A14'AS [DummyPolicy],'SSHOP' AS  [Programme] UNION
--SELECT 'RN887A15'AS [DummyPolicy],'SSHOP' AS  [Programme] UNION
--SELECT 'RN887B15'AS [DummyPolicy],'SSHOP' AS  [Programme] UNiON
SELECT 'R0059D99A'AS DummyPolicy,'Property Risk Excess'AS Programme UNION
SELECT 'R0359A04A' AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0374A04B'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0423A03A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0423A04B'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'RN887A14'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'RN887A15'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0375A04B'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0421A04B'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0505A04B'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'REAC'AS DummyPolicy,'SL Risk XoL'AS Programme UNION
SELECT 'RN887B15'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0229A00A'AS DummyPolicy,'Casualty XL'AS Programme UNION
SELECT 'R0002V00A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0003E99A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0141B00A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0145G00A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0146G00A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0146G99A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0147G00A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0148G01A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0205A00A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0205A99A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0206A01A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0206A99A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R1141B99A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R2141B01A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0001H00A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0001H99A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0002V99A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0003E00A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0008F00A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0008F99A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0141B01A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0141B99A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0145G99A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0146G01A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0147G99A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0148G00A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0148G99A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0188A99A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0206A00A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0284A01A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0288A01A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R1141B00A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R1141B01A'AS DummyPolicy,'GEN (Whole Account)'AS Programme UNION
SELECT 'R0051X00A'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0051X99A'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0189A99A'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0231A01A'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0232A00A'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0234A00A'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0237A00A'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0287A01A'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0292A01A'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0293A01A'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0051X01A 'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0087E00A'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0087E01A'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0087E99A'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0231A00A'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0232A01A'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0233A00A'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0233A01A'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0236A00A'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0289A01A 'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0290A01A'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0294A01A'AS DummyPolicy,'Property Cat XL'AS Programme UNION
SELECT 'R0067N00A'AS DummyPolicy,'Property Risk Excess'AS Programme UNION
SELECT 'R0067N99A'AS DummyPolicy,'Property Risk Excess'AS Programme UNION
SELECT 'R0070B00A'AS DummyPolicy,'Property Risk Excess'AS Programme UNION
SELECT 'R0190A99A'AS DummyPolicy,'Property Risk Excess'AS Programme UNION
SELECT 'R1059D99A'AS DummyPolicy,'Property Risk Excess'AS Programme UNION
SELECT 'R0236A01A'AS DummyPolicy,'Property XL'AS Programme UNION
SELECT 'R0128K99A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0158A99A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0161A01A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0161A99A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0163A99A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0204A00A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0128K00A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0128K01A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0158A00A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0159A00A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0159A01A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0159A99A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0160A00A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0160A99A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0161A00A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0162A00A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0162A99A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0163A00A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0163A01A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0204A01A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0204A99A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0266A01A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R1159A01A'AS DummyPolicy,'PRXS'AS Programme UNION
SELECT 'R0150A99A'AS DummyPolicy,'Reinstatement Premium Protection'AS Programme UNION
SELECT 'R1243A99' AS DummyPolicy,'GEN RE QQS' AS Programme UNION
SELECT 'R0059D99A' AS DummyPolicy,'Property Risk Excess' AS Programme UNION
SELECT 'R0359A04A' AS DummyPolicy,'Property Cat XL' AS Programme
)C

