﻿
TRUNCATE TABLE [MDS].[TreatyShareGenerationRules]
GO
/* ===========================================================================================================
	Created By:		Entha.Bhargav@beazley.com
	Created date:	08/01/2024
	Description:	Static Script is created to use this Rules while Bulding data at Box3-4 Procedure Objects inorder to apply these rules and create additional records post Syndicate Split and InterCompany Rules
					[fct].[usp_LoadTechnicalResult]
					[fct].[usp_LoadTechnicalResult_BICI_BIDAC_BAIC]
					[fct].[usp_LoadTechnicalResult_Eurobase]
					[fct].[usp_LoadTechnicalResult_PFT]
					[fct].[usp_LoadTechnicalResult_USPremium]
	
					--These Rules were generate part of EBG changes from 2024 YOA Onwards
					--Changes cover part of JIRA https://beazley.atlassian.net/browse/I1B-5083
					-- In Future their is a scope these should populate from MDS source
	

=================================================================================================================== */

;WITH YOASet (YOA) as
(
		SELECT 2024						-- as this set to 2024, TreatyShareRules aggred effective from 2024 YOA only.
		
		UNION ALL
		
		SELECT YOA+1 
		FROM YOASet
		WHERE YOA<= year(GETDATE())+3   --Rules generate for Future 3 Years only
)
--SELECT	*
--FROM	YOA

INSERT INTO [MDS].[TreatyShareGenerationRules] (DataSet,YOA,TriFocusCode,FromEntity,ToEntity,TreatyName,CedePercentage,AuditSource)


SELECT DataSet,Y.YOA AS YOA,TriFocusCode,FromEntity,ToEntity,TreatyName,CedePercentage,AuditSource
FROM 
(
--PFT
SELECT 'PFT' DataSet,'2024' YOAFrom,'9999' YOATo,'TRI00004' TriFocusCode,'623' FromEntity,'8033' ToEntity,'CoreTreaty' TreatyName,0.30 as CedePercentage,'StaticScript' as AuditSource  --CAT TriFocus Group
UNION 
SELECT 'PFT' DataSet,'2024' YOAFrom,'9999' YOATo,'TRI00012' TriFocusCode,'623' FromEntity,'8033' ToEntity,'CoreTreaty' TreatyName,0.30 as CedePercentage,'StaticScript' as AuditSource  --Excat TriFocusGroup

--ReservingData
UNION
SELECT 'ReservingData' DataSet,'2024' YOAFrom,'9999' YOATo,'TRI00004' TriFocusCode,'623' FromEntity,'8033' ToEntity,'CoreTreaty' TreatyName,0.30 as CedePercentage,'StaticScript' as AuditSource  --CAT 
UNION 
SELECT 'ReservingData' DataSet,'2024' YOAFrom,'9999' YOATo,'TRI00012' TriFocusCode,'623' FromEntity,'8033' ToEntity,'CoreTreaty' TreatyName,0.30 as CedePercentage,'StaticScript' as AuditSource  --Excat 

--Eurobase
UNION
SELECT 'Eurobase' DataSet,'2024' YOAFrom,'9999' YOATo,'TRI00004' TriFocusCode,'623' FromEntity,'8033' ToEntity,'CoreTreaty' TreatyName,0.30 as CedePercentage,'StaticScript' as AuditSource  --CAT TriFocus 
UNION 
SELECT 'Eurobase' DataSet,'2024' YOAFrom,'9999' YOATo,'TRI00012' TriFocusCode,'623' FromEntity,'8033' ToEntity,'CoreTreaty' TreatyName,0.30 as CedePercentage,'StaticScript' as AuditSource  --Excat 

--LPSO
UNION
SELECT 'LPSO' DataSet,'2024' YOAFrom,'9999' YOATo,'TRI00004' TriFocusCode,'623' FromEntity,'8033' ToEntity,'CoreTreaty' TreatyName,0.30 as CedePercentage,'StaticScript' as AuditSource  --CAT TriFocus Group
UNION 
SELECT 'LPSO' DataSet,'2024' YOAFrom,'9999' YOATo,'TRI00012' TriFocusCode,'623' FromEntity,'8033' ToEntity,'CoreTreaty' TreatyName,0.30 as CedePercentage,'StaticScript' as AuditSource  --Excat 

--Claims_BI_ODS
UNION
SELECT 'Claims_BI_ODS' DataSet,'2024' YOAFrom,'9999' YOATo,'TRI00004' TriFocusCode,'623' FromEntity,'8033' ToEntity,'CoreTreaty' TreatyName,0.30 as CedePercentage,'StaticScript' as AuditSource  --CAT 
UNION 
SELECT 'Claims_BI_ODS' DataSet,'2024' YOAFrom,'9999' YOATo,'TRI00012' TriFocusCode,'623' FromEntity,'8033' ToEntity,'CoreTreaty' TreatyName,0.30 as CedePercentage,'StaticScript' as AuditSource  --Excat 

--EPI Reinstatement Eurobase
UNION
SELECT 'EPI Reinstatement Eurobase' DataSet,'2024' YOAFrom,'9999' YOATo,'TRI00004' TriFocusCode,'623' FromEntity,'8033' ToEntity,'CoreTreaty' TreatyName,0.30 as CedePercentage,'StaticScript' as AuditSource  
UNION 
SELECT 'EPI Reinstatement Eurobase' DataSet,'2024' YOAFrom,'9999' YOATo,'TRI00012' TriFocusCode,'623' FromEntity,'8033' ToEntity,'CoreTreaty' TreatyName,0.30 as CedePercentage,'StaticScript' as AuditSource



) as		Rules
INNER JOIN	YOASet Y
				ON  Y.YOA between Rules.YOAFrom and Rules.YOATo