﻿TRUNCATE TABLE [MDS].[Catcode_Eventdate]
GO
INSERT INTO [MDS].[Catcode_Eventdate] 
SELECT * FROM(
SELECT 'WTC' AS Event,'2001' AS EventYear,'09/11/2001' AS EventDate UNION
SELECT 'Hurricane Charley' AS Event,'2004' AS EventYear,'08/09/2004' AS EventDate UNION
SELECT 'Hurricane Frances' AS Event,'2004' AS EventYear,'08/24/2004' AS EventDate UNION
SELECT 'Hurricane Ivan' AS Event,'2004' AS EventYear,'09/02/2004' AS EventDate UNION
SELECT 'Hurricane Jeanne' AS Event,'2004' AS EventYear,'09/13/2004' AS EventDate UNION
SELECT 'Indian Ocean Tsunami' AS Event,'2004' AS EventYear,'12/26/2004' AS EventDate UNION
SELECT 'TYPHOON SONGDA' AS Event,'2004' AS EventYear,'08/26/2004' AS EventDate UNION
SELECT 'Hurricane Katrina' AS Event,'2005' AS EventYear,'08/23/2005' AS EventDate UNION
SELECT 'Hurricane Rita' AS Event,'2005' AS EventYear,'09/18/2005' AS EventDate UNION
SELECT 'Hurricane Wilma' AS Event,'2005' AS EventYear,'10/15/2005' AS EventDate UNION
SELECT 'Hurricane Gustav' AS Event,'2008' AS EventYear,'08/25/2008' AS EventDate UNION
SELECT 'Hurricane Ike' AS Event,'2008' AS EventYear,'09/01/2008' AS EventDate UNION
SELECT 'Australia Floods 2010' AS Event,'2010' AS EventYear,'11/26/2010' AS EventDate UNION
SELECT 'Chilean Earthquake' AS Event,'2010' AS EventYear,'02/27/2010' AS EventDate UNION
SELECT 'European Storm Xynthia' AS Event,'2010' AS EventYear,'02/27/2010' AS EventDate UNION
SELECT 'New Zealand Earthquake 2010' AS Event,'2010' AS EventYear,'09/04/2010' AS EventDate UNION
SELECT 'Australia Floods 2011' AS Event,'2011' AS EventYear,'01/10/2011' AS EventDate UNION
SELECT 'Hurricane Irene' AS Event,'2011' AS EventYear,'08/21/2011' AS EventDate UNION
SELECT 'Japanese Earthquake' AS Event,'2011' AS EventYear,'03/11/2011' AS EventDate UNION
SELECT 'New Zealand Earthquake 2011' AS Event,'2011' AS EventYear,'02/22/2011' AS EventDate UNION
SELECT 'Thailand Floods' AS Event,'2011' AS EventYear,'07/31/2011' AS EventDate UNION
SELECT 'US Tornados 11F' AS Event,'2011' AS EventYear,'04/14/2011' AS EventDate UNION
SELECT 'US Tornados 11G' AS Event,'2011' AS EventYear,'04/24/2011' AS EventDate UNION
SELECT 'US Tornados 11H' AS Event,'2011' AS EventYear,'05/20/2011' AS EventDate UNION
SELECT 'Hurricane Isaac' AS Event,'2012' AS EventYear,'08/21/2012' AS EventDate UNION
SELECT 'Hurricane Sandy' AS Event,'2012' AS EventYear,'10/22/2012' AS EventDate UNION
SELECT 'Alberta Floods' AS Event,'2013' AS EventYear,'06/19/2013' AS EventDate UNION
SELECT 'Central Euro Floods' AS Event,'2013' AS EventYear,'05/30/2013' AS EventDate UNION
SELECT 'German Hail' AS Event,'2013' AS EventYear,'07/27/2013' AS EventDate UNION
SELECT 'Hurricane Ingrid' AS Event,'2013' AS EventYear,'09/12/2013' AS EventDate UNION
SELECT 'Hurricane Manuel' AS Event,'2013' AS EventYear,'09/13/2013' AS EventDate UNION
SELECT 'Hurricane Odile' AS Event,'2014' AS EventYear,'09/10/2014' AS EventDate UNION
SELECT 'Port of Tianjin' AS Event,'2015' AS EventYear,'08/12/2015' AS EventDate UNION
SELECT 'Fort McMurray Wildfire' AS Event,'2016' AS EventYear,'05/01/2016' AS EventDate UNION
SELECT 'Hurricane Matthew' AS Event,'2016' AS EventYear,'09/28/2016' AS EventDate UNION
SELECT 'California Wildfires' AS Event,'2017' AS EventYear,'04/20/2017' AS EventDate UNION
SELECT 'Hurricane Harvey' AS Event,'2017' AS EventYear,'08/17/2017' AS EventDate UNION
SELECT 'Hurricane Irma' AS Event,'2017' AS EventYear,'08/30/2017' AS EventDate UNION
SELECT 'Hurricane Maria' AS Event,'2017' AS EventYear,'09/16/2017' AS EventDate UNION
SELECT 'HURRICANE NATE' AS Event,'2017' AS EventYear,'10/04/2017' AS EventDate UNION
SELECT 'Mexico Earthquake I' AS Event,'2017' AS EventYear,'09/07/2017' AS EventDate UNION
SELECT 'Mexico Earthquake II' AS Event,'2017' AS EventYear,'09/19/2017' AS EventDate UNION
SELECT 'CAMP WILDFIRE' AS Event,'2018' AS EventYear,'11/08/2018' AS EventDate UNION
SELECT 'HURRICANE FLORENCE' AS Event,'2018' AS EventYear,'08/31/2018' AS EventDate UNION
SELECT 'HURRICANE MICHAEL' AS Event,'2018' AS EventYear,'10/07/2018' AS EventDate UNION
SELECT 'TYPHOON JEBI' AS Event,'2018' AS EventYear,'08/26/2018' AS EventDate UNION
SELECT 'WOOLSEY WILDFIRE' AS Event,'2018' AS EventYear,'11/08/2018' AS EventDate UNION
SELECT 'Storm Dorian' AS Event,'2019' AS EventYear,'09/01/2019' AS EventDate UNION
SELECT 'TYPHOON FAXAI' AS Event,'2019' AS EventYear,'08/29/2019' AS EventDate UNION
SELECT 'TYPHOON HAGIBIS' AS Event,'2019' AS EventYear,'10/04/2019' AS EventDate UNION
SELECT 'CORONAVIRUS' AS Event,'2020' AS EventYear,'03/11/2020' AS EventDate UNION
SELECT 'Derecho Weather' AS Event,'2020' AS EventYear,'08/10/2020' AS EventDate UNION
SELECT 'Hurricane Delta' AS Event,'2020' AS EventYear,'10/04/2020' AS EventDate UNION
SELECT 'Hurricane Isaias' AS Event,'2020' AS EventYear,'06/30/2020' AS EventDate UNION
SELECT 'HURRICANE LAURA' AS Event,'2020' AS EventYear,'08/20/2020' AS EventDate UNION
SELECT 'HURRICANE SALLY' AS Event,'2020' AS EventYear,'09/11/2020' AS EventDate UNION
SELECT 'Hurricane Zeta' AS Event,'2020' AS EventYear,'10/24/2020' AS EventDate UNION
SELECT 'Storm Uri' AS Event,'2021' AS EventYear,'02/13/2021' AS EventDate 
)C
