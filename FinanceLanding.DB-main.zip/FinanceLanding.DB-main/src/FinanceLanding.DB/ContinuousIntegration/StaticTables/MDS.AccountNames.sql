﻿
USE [FinanceLanding]
GO
SET NOCOUNT ON 
GO

MERGE INTO [MDS].[AccountNames] AS Target

USING (VALUES
               (1,'ReservingData','GC-P-AC','Gross Claims Pure Claims Pure Attritional Claims',1)
              ,(2,'ReservingData','GC-P-CM','Gross Claims Pure Claims Pure Cat Margin',1)
              ,(3,'ReservingData','GC-P-LL','Gross Claims Pure Claims Pure Large Losses',1)
              ,(4,'ReservingData','GC-T-AC','Gross Claims Team Claims Team Attritional Claims',1)
              ,(5,'ReservingData','GC-T-CM','Gross Claims Team Claims Team Cat Margin',1)
              ,(6,'ReservingData','GC-T-LL','Gross Claims Team Claims Team Large Losses',1)
              ,(7,'ReservingData','GP-P-PR','Gross Premium Pure Premium Pure Premium',1)
              ,(8,'ReservingData','GP-T-PR','Gross Premium Team Premium Team Premium',1)
              ,(9,'SIITP','TPC-G-AC','TP Claims Provision Gross Acquisition Costs',1)
              ,(10,'SIITP','TPC-N-AC','TP Claims Provision Net Acquisition Costs',1)
              ,(11,'SIITP','TPC-G-CL','TP Claims Provision Gross Att Claims',1)
              ,(12,'SIITP','TPC-N-CL','TP Claims Provision Net Att Claims',1)
              ,(13,'SIITP','TPC-G-BD','TP Claims Provision Gross Bad Debt',1)
              ,(14,'SIITP','TPC-N-BD','TP Claims Provision Net Bad Debt',1)
              ,(15,'SIITP','TPC-G-EN','TP Claims Provision Gross ENIDs ',1)
              ,(16,'SIITP','TPC-N-EN','TP Claims Provision Net ENIDs ',1)
              ,(17,'SIITP','TPC-G-EX','TP Claims Provision Gross Expenses non ULAE ',1)
              ,(18,'SIITP','TPC-N-EX','TP Claims Provision Net Expenses non ULAE ',1)
              ,(19,'SIITP','TPC-G-EU','TP Claims Provision Gross Expenses ULAE ',1)
              ,(20,'SIITP','TPC-N-EU','TP Claims Provision Net Expenses ULAE ',1)
              ,(21,'SIITP','TPC-G-LL','TP Claims Provision Gross Large Losses',1)
              ,(22,'SIITP','TPC-N-LL','TP Claims Provision Net Large Losses ',1)
              ,(23,'SIITP','TPC-G-PR','TP Claims Provision Gross Premium ',-1)
              ,(24,'SIITP','TPC-N-PR','TP Claims Provision Net Premium ',-1)
              ,(25,'SIITP','TPI-G-AC','TP Premium Provision Incepted Gross Acquisition Costs ',1)
              ,(26,'SIITP','TPI-N-AC','TP Premium Provision Incepted Net Acquisition Costs ',1)
              ,(27,'SIITP','TPI-G-CL','TP Premium Provision Incepted Gross Att Claims ',1)
              ,(28,'SIITP','TPI-N-CL','TP Premium Provision Incepted Net Att Claims ',1)
              ,(29,'SIITP','TPI-G-BD','TP Premium Provision Incepted Gross Bad Debt ',1)
              ,(30,'SIITP','TPI-N-BD','TP Premium Provision Incepted Net Bad Debt ',1)
              ,(31,'SIITP','TPI-G-CM','TP Premium Provision Incepted Gross Cat Margin',1)
              ,(32,'SIITP','TPI-N-CM','TP Premium Provision Incepted Net Cat Margin ',1)
              ,(33,'SIITP','TPI-G-EN','TP Premium Provision Incepted Gross ENIDs ',1)
              ,(34,'SIITP','TPI-N-EN','TP Premium Provision Incepted Net ENIDs ',1)
              ,(35,'SIITP','TPI-G-EX','TP Premium Provision Incepted Gross Expenses non ULAE ',1)
              ,(36,'SIITP','TPI-N-EX','TP Premium Provision Incepted Net Expenses non ULAE',1)
              ,(37,'SIITP','TPI-G-EU','TP Premium Provision Incepted Gross Expenses ULAE',1)
              ,(38,'SIITP','TPI-N-EU','TP Premium Provision Incepted Net Expenses ULAE ',1)
              ,(39,'SIITP','TPI-G-PR','TP Premium Provision Incepted Gross Premium ',-1)
              ,(40,'SIITP','TPI-N-PR','TP Premium Provision Incepted Net Premium ',-1)
              ,(41,'SIITP','TPU-G-AC','TP Premium Provision Unincepted Gross Acquisition Costs ',1)
              ,(42,'SIITP','TPU-N-AC','TP Premium Provision Unincepted Net Acquisition Costs ',1)
              ,(43,'SIITP','TPU-G-CL','TP Premium Provision Unincepted Gross Att Claims ',1)
              ,(44,'SIITP','TPU-N-CL','TP Premium Provision Unincepted Net Att Claims ',1)
              ,(45,'SIITP','TPU-G-BD','TP Premium Provision Unincepted Gross Bad Debt ',1)
              ,(46,'SIITP','TPU-N-BD','TP Premium Provision Unincepted Net Bad Debt ',1)
              ,(47,'SIITP','TPU-G-CM','TP Premium Provision Unincepted Gross Cat Margin ',1)
              ,(48,'SIITP','TPU-N-CM','TP Premium Provision Unincepted Net Cat Margin ',1)
              ,(49,'SIITP','TPU-G-EN','TP Premium Provision Unincepted Gross ENIDs',1)
              ,(50,'SIITP','TPU-N-EN','TP Premium Provision Unincepted Net ENIDs ',1)
              ,(51,'SIITP','TPU-G-EX','TP Premium Provision Unincepted Gross Expenses non ULAE ',1)
              ,(52,'SIITP','TPU-N-EX','TP Premium Provision Unincepted Net Expenses non ULAE',1)
              ,(53,'SIITP','TPU-G-EU','TP Premium Provision Unincepted Gross Expenses ULAE',1)
              ,(54,'SIITP','TPU-N-EU','TP Premium Provision Unincepted Net Expenses ULAE ',1)
              ,(55,'SIITP','TPU-G-PR','TP Premium Provision Unincepted Gross Premium ',-1)
              ,(56,'SIITP','TPU-N-PR','TP Premium Provision Unincepted Net Premium ',-1) 
			  ,(57,'ReservingData','RC-P-AC','RI Claims Pure Claims Pure Attritional Claims',1)
              ,(58,'ReservingData','RC-P-CM','RI Claims Pure Claims Pure Cat Margin',1)
              ,(59,'ReservingData','RC-P-LL','RI Claims Pure Claims Pure Large Losses',1)
              ,(60,'ReservingData','RC-T-AC','RI Claims Team Claims Team Attritional Claims',1)
              ,(61,'ReservingData','RC-T-CM','RI Claims Team Claims Team Cat Margin',1)
              ,(62,'ReservingData','RC-T-LL','RI Claims Team Claims Team Large Losses',1)
              ,(63,'ReservingData','RP-P-PR','RI Premium Pure Premium Pure Premium',1)
              ,(64,'ReservingData','RP-T-PR','RI Premium Team Premium Team Premium',1)              
			 ,(100,'LPSO','PC-LS-RT','Premium Cash Gross of Brokerage - Lloyd`s Settled - Reinstatement',1)
			 ,(101,'LPSO','BC-LS-RT','Brokerage Cash - Lloyd`s Settled - Reinstatement',1)
			 ,(102,'LPSO','PC-SD-RT','Premium Cash Gross of Brokerage - Settled Direct - Reinstatement',1)
			 ,(103,'LPSO','BC-SD-RT','Brokerage Cash - Settled Direct - Reinstatement',1)
			 ,(104,'LPSO','PC-OS-RT','Premium Cash Gross of Brokerage - Other Settled - Reinstatement',1)
			 ,(105,'LPSO','BC-OS-RT','Brokerage Cash - Other Settled - Reinstatement',1)
			 ,(106,'LPSO','PC-LS-PC','Premium Cash Gross of Brokerage - Lloyd`s Settled - Profit Commission',-1)
			 ,(107,'LPSO','BC-LS-PC','Brokerage Cash - Lloyd`s Settled - Profit Commission',-1)
			 ,(108,'LPSO','PC-SD-PC','Premium Cash Gross of Brokerage - Settled Direct - Profit Commission',-1)
			 ,(109,'LPSO','BC-SD-PC','Brokerage Cash - Settled Direct - Profit Commission',-1)
			 ,(110,'LPSO','PC-OS-PC','Premium Cash Gross of Brokerage - Other Settled - Profit Commission',-1)
			 ,(111,'LPSO','BC-OS-PC','Brokerage Cash - Other Settled - Profit Commission',-1)
			 ,(112,'LPSO','PC-LS-OT','Premium Cash Gross of Brokerage - Lloyd`s Settled - Other',1)
			 ,(113,'LPSO','BC-LS-OT','Brokerage Cash - Lloyd`s Settled - Other',1)
			 ,(114,'LPSO','PC-SD-OT','Premium Cash Gross of Brokerage - Settled Direct - Other',1)
			 ,(115,'LPSO','BC-SD-OT','Brokerage Cash - Settled Direct - Other',1)
			 ,(116,'LPSO','PC-OS-OT','Premium Cash Gross of Brokerage - Other Settled- Other',1)
			 ,(117,'LPSO','BC-OS-OT','Brokerage Cash - Other Settled - Other',1)

			 ,(118,'LPSO','CC-LS-CLM','Claim Cash - Lloyd`s Settled - Claim',-1)
			 ,(119,'LPSO','CC-SD-CLM','Claim Cash - Settled Direct - Claim',-1)
			 ,(120,'LPSO','CC-OS-CLM','Claim Cash - Other Settled - Claim',-1)
			 ,(121,'LPSO','CC-LS-TTY','Claim Cash - Lloyd`s Settled - Proportional Treaty Statement',-1)
			 ,(122,'LPSO','CC-SD-TTY','Claim Cash - Settled Direct - Proportional Treaty Statement',-1)
			 ,(123,'LPSO','CC-OS-TTY','Claim Cash - Other Settled - Proportional Treaty Statement',-1)
			 ,(124,'LPSO','CC-LS-OTH','Claim Cash - Lloyd`s Settled - Other',-1)
			 ,(125,'LPSO','CC-SD-OTH','Claim Cash - Settled Direct - Other',-1)
			 ,(126,'LPSO','CC-OS-OTH','Claim Cash - Other Settled - Other',-1)

			 ,(130,'EPI Reinstatement Eurobase','GPE-RP-B','Reinstatement Premium - Gross - Binder',1)
			 ,(131,'EPI Reinstatement Eurobase','GPE-RP-P','Reinstatement Premium - Gross - Policy',1)

			 ,(132,'ClaimCenter','C-DI-LL','Claim Defence Incurred Large Loss',1)
			 ,(133,'ClaimCenter','C-FI-LL','Claim Fees Incurred Large Loss',1)
			 ,(134,'ClaimCenter','C-II-LL','Claim Indemnity Incurred Large Loss',1)
			 ,(135,'ClaimCenter','C-DP-LL','Claim Defence Paid Large Loss',1)
			 ,(136,'ClaimCenter','C-FP-LL','Claim Fees Paid Large Loss',1)
			 ,(137,'ClaimCenter','C-IP-LL','Claim Indemnity Paid Large Loss',1)
			 ,(138,'ClaimCenter','C-DO-LL','Claim Defence Outstanding Large Loss',1)
			 ,(139,'ClaimCenter','C-FO-LL','Claim Fees Outstanding Large Loss',1)
			 ,(140,'ClaimCenter','C-IO-LL','Claim Indemnity Outstanding Large Loss',1)
			 ,(141,'ClaimCenter','C-DI-ATT','Claim Defence Incurred Attritional',1)
			 ,(142,'ClaimCenter','C-FI-ATT','Claim Fees Incurred Attritional',1)
			 ,(143,'ClaimCenter','C-II-ATT','Claim Indemnity Incurred Attritional',1)
			 ,(144,'ClaimCenter','C-DP-ATT','Claim Defence Paid Attritional',1)
			 ,(145,'ClaimCenter','C-FP-ATT','Claim Fees Paid Attritional',1)
			 ,(146,'ClaimCenter','C-IP-ATT','Claim Indemnity Paid Attritional',1)
			 ,(147,'ClaimCenter','C-DO-ATT','Claim Defence Outstanding Attritional',1)
			 ,(148,'ClaimCenter','C-FO-ATT','Claim Fees Outstanding Attritional',1)
			 ,(149,'ClaimCenter','C-IO-ATT','Claim Indemnity Outstanding Attritional',1)

			 ,(150,'LPSO','CC-OS-OT','Gross Claims Cash Other Settled Claims',1)
			 ,(151,'LPSO','CC-SD-OT','Gross Claims Cash Settled Direct Claims',1)

       )AS Source ([PK_AccountNames], [DataSet], [AccountKey], [AccountNames], [AccountSignage])
			
ON (Target.[PK_AccountNames] = Source.[PK_AccountNames])

WHEN MATCHED 
		and [Target].[DataSet]         != Source.[DataSet]
		or  [Target].[AccountKey]      != Source.[AccountKey]
		or  [Target].[AccountNames]    != Source.[AccountNames]
		or  [Target].[AccountSignage]  != Source.[AccountSignage]
THEN 
UPDATE SET  [DataSet]         = Source.[DataSet]
           ,[AccountKey]      = Source.[AccountKey]
		   ,[AccountNames]    = Source.[AccountNames]
		   ,[AccountSignage]  = Source.[AccountSignage]
		   
WHEN NOT MATCHED BY TARGET THEN

INSERT ([PK_AccountNames], [DataSet], [AccountKey], [AccountNames], [AccountSignage])
VALUES (Source.[PK_AccountNames], Source.[DataSet], Source.[AccountKey], Source.[AccountNames], Source.[AccountSignage])
		   
WHEN NOT MATCHED BY SOURCE THEN DELETE;

GO                                                                                                                                                                                                       
DECLARE @mergeError int                                                                                                                                                                                  
       ,@mergeCount int                                                                                                                                                                                       
SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT                                                                                                                                                   
IF @mergeError != 0                                                                                                                                                                                      
 BEGIN                                                                                                                                                                                                   
 PRINT 'ERROR OCCURRED IN MERGE FOR [MDS].[AccountNames]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); -- SQL should always return zero rows affected                           
 END                                                                                                                                                                                                     
ELSE                                                                                                                                                                                                     
 BEGIN                                                                                                                                                                                                   
 PRINT '[MDS].[AccountNames] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));                                                                                              
 END                                                                                                                                                                                                     
GO                                                                                                                                                                                                       
                                                                                                                                                                                                         
SET NOCOUNT OFF                                                                                                                                                                                          
GO     

