﻿TRUNCATE TABLE  [MDS].[ConformedTrifocusMapping]
GO
INSERT INTO [MDS].[ConformedTrifocusMapping](TrifocusCode,ConformedTrifocusMapping )
SELECT * FROM(
Select '1' AS  TrifocusCode ,'Unknown' AS  ConformedTrifocus  UNION 
Select '16' AS  TrifocusCode ,'15' AS  ConformedTrifocus  UNION 
Select '733' AS  TrifocusCode ,'737' AS  ConformedTrifocus  UNION 
Select '9A' AS  TrifocusCode ,'758' AS  ConformedTrifocus  UNION 
Select 'BUSASL' AS  TrifocusCode ,'664' AS  ConformedTrifocus  UNION 
Select 'CPCC' AS  TrifocusCode ,'TRI00045' AS  ConformedTrifocus  UNION 
Select 'CPCE' AS  TrifocusCode ,'TRI00045' AS  ConformedTrifocus  UNION 
Select 'CPEA' AS  TrifocusCode ,'TRI00045' AS  ConformedTrifocus  UNION 
Select 'CPSCE' AS  TrifocusCode ,'TRI00045' AS  ConformedTrifocus  UNION 
Select 'CPSEA' AS  TrifocusCode ,'TRI00045' AS  ConformedTrifocus  UNION 
Select 'CPSWE' AS  TrifocusCode ,'TRI00045' AS  ConformedTrifocus  UNION 
Select 'CPWE' AS  TrifocusCode ,'TRI00045' AS  ConformedTrifocus  UNION 
Select 'FSAR' AS  TrifocusCode ,'796' AS  ConformedTrifocus  UNION 
Select 'FSBR' AS  TrifocusCode ,'796' AS  ConformedTrifocus  UNION 
Select 'FSCR' AS  TrifocusCode ,'796' AS  ConformedTrifocus  UNION 
Select 'FSHR' AS  TrifocusCode ,'796' AS  ConformedTrifocus  UNION 
Select 'FSLR' AS  TrifocusCode ,'796' AS  ConformedTrifocus  UNION 
Select 'FSNR' AS  TrifocusCode ,'796' AS  ConformedTrifocus  UNION 
Select 'FSSR' AS  TrifocusCode ,'796' AS  ConformedTrifocus  UNION 
Select 'FSMAR' AS  TrifocusCode ,'796' AS  ConformedTrifocus  UNION 
Select 'FSMBR' AS  TrifocusCode ,'796' AS  ConformedTrifocus  UNION 
Select 'FSMCR' AS  TrifocusCode ,'796' AS  ConformedTrifocus  UNION 
Select 'FSMHR' AS  TrifocusCode ,'796' AS  ConformedTrifocus  UNION 
Select 'FSMLR' AS  TrifocusCode ,'796' AS  ConformedTrifocus  UNION 
Select 'FSMNR' AS  TrifocusCode ,'796' AS  ConformedTrifocus  UNION 
Select 'FSROAR' AS  TrifocusCode ,'796' AS  ConformedTrifocus  UNION 
Select 'FSROBR' AS  TrifocusCode ,'796' AS  ConformedTrifocus  UNION 
Select 'FSROCR' AS  TrifocusCode ,'796' AS  ConformedTrifocus  UNION 
Select 'FSROLR' AS  TrifocusCode ,'796' AS  ConformedTrifocus  UNION 
Select 'FSRONR' AS  TrifocusCode ,'796' AS  ConformedTrifocus  UNION 
Select 'FSROSR' AS  TrifocusCode ,'796' AS  ConformedTrifocus  UNION 
Select 'No Trifocus' AS  TrifocusCode ,'Unknown' AS  ConformedTrifocus  UNION 
Select 'NOTRIFOC' AS  TrifocusCode ,'Unknown' AS  ConformedTrifocus  UNION 
Select 'S120' AS  TrifocusCode ,'Unknown' AS  ConformedTrifocus  UNION 
Select 'TRI00017' AS  TrifocusCode ,'TRI00016' AS  ConformedTrifocus  UNION 
Select 'TRI00024' AS  TrifocusCode ,'TRI00024' AS  ConformedTrifocus  UNION 
Select 'TRI00028' AS  TrifocusCode ,'724' AS  ConformedTrifocus  UNION 
Select 'TRI00043' AS  TrifocusCode ,'TRI00049' AS  ConformedTrifocus  UNION 
Select 'TRI00044' AS  TrifocusCode ,'TRI00049' AS  ConformedTrifocus  UNION 
Select '929' AS  TrifocusCode ,'TRI00047' AS  ConformedTrifocus  UNION 
Select '942' AS  TrifocusCode ,'TRI00052' AS  ConformedTrifocus  UNION 
Select '931' AS  TrifocusCode ,'TRI00054' AS  ConformedTrifocus  UNION 
Select '939' AS  TrifocusCode ,'TRI00055' AS  ConformedTrifocus  UNION 
Select '932' AS  TrifocusCode ,'TRI00056' AS  ConformedTrifocus  UNION 
Select '940' AS  TrifocusCode ,'TRI00057' AS  ConformedTrifocus  UNION 
Select '938' AS  TrifocusCode ,'TRI00059' AS  ConformedTrifocus  UNION 
Select '933' AS  TrifocusCode ,'TRI00060' AS  ConformedTrifocus  UNION 
Select '937' AS  TrifocusCode ,'TRI00069' AS  ConformedTrifocus  UNION 
Select '934' AS  TrifocusCode ,'TRI00070' AS  ConformedTrifocus  UNION 
Select '941' AS  TrifocusCode ,'TRI00071' AS  ConformedTrifocus  UNION 
Select '936' AS  TrifocusCode ,'TRI00073' AS  ConformedTrifocus  UNION 
Select '930' AS  TrifocusCode ,'TRI00074' AS  ConformedTrifocus  UNION 
Select '943' AS  TrifocusCode ,'TRI00076' AS  ConformedTrifocus  UNION 
Select '935' AS  TrifocusCode ,'TRI00077' AS  ConformedTrifocus  UNION 
Select 'Z140' AS  TrifocusCode ,'Unknown' AS  ConformedTrifocus  UNION 
Select 'Z148' AS  TrifocusCode ,'Unknown' AS  ConformedTrifocus  UNION
Select '504' AS  TrifocusCode ,'504' AS  ConformedTrifocus UNION
Select '2' AS  TrifocusCode ,'664' AS  ConformedTrifocus UNION
Select '3' AS  TrifocusCode ,'664' AS  ConformedTrifocus UNION
Select '4' AS  TrifocusCode ,'664' AS  ConformedTrifocus 
)CT
