CREATE TABLE [ADMRI].[RIIBNRToAlloc](
	[Id] [int] NOT NULL,
	[Asat] [int] NULL,
	[RDKEy] [nvarchar](255) NULL,
	[YOA] [int] NULL,
	[Triangle_Group] [nvarchar](255) NULL,
	[Department] [nvarchar](255) NULL,
	[ccy] [nvarchar](3) NULL,
	[Synd] [int] NULL,
	[special] [nvarchar](255) NULL,
	[Office_Location] [nvarchar](50) NULL,
	[TrifocusCode] [nvarchar](255) NULL,
	[EntitySet] [nvarchar](50) NULL,
	[RI_IBNR_ToAlloc] [numeric](38, 12) NULL,
	[Open/Closed] [nvarchar](50) NULL,
	[InAttritional] [nvarchar](50) NULL,
	[InClosed YOA] [nvarchar](50) NULL,
	[InRIPremium] [nvarchar](50) NULL,
	[InClosedYOASpecial] [nvarchar](50) NULL,
	[InAttritional_Clash_Profs] [nvarchar](50) NULL,
	[InClosedYOA_Clash_Profs] [nvarchar](50) NULL,
	[InRIPremium_Clash_Profs] [nvarchar](50) NULL,
	[InData] [nvarchar](50) NULL,
	[Rule_Closed_Attritional] [nvarchar](50) NULL,
	[Rule_Closed_ClosedYOA] [nvarchar](50) NULL,
	[Rule_Closed_RIPremium] [nvarchar](50) NULL,
	[Rule_Closed_Attritional_CP] [nvarchar](50) NULL,
	[Rule_Closed_ClosedYOA_CP] [nvarchar](50) NULL,
	[Rule_Closed_RIPremium_CP] [nvarchar](50) NULL,
	[Rule_Open_RIPremium] [nvarchar](50) NULL,
	[Rule_Open_ClosedYOA] [nvarchar](50) NULL,
	[Rule_Open_Attritional] [nvarchar](50) NULL,
	[Rule_Open_ClosedYOASpecial] [nvarchar](50) NULL,
	[Rule_Open_RIPremium_CP] [nvarchar](50) NULL,
	[Rule_Open_ClosedYOA_CP] [nvarchar](50) NULL,
	[Rule_Open_Attritional_CP] [nvarchar](50) NULL,
	[Unallocated] [nvarchar](50) NULL,
	[KeyForUnallocated] [nvarchar](255) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [ADMRI].[RIIBNRToAlloc] ADD  CONSTRAINT [DF_RIIBNRToAlloc_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [ADMRI].[RIIBNRToAlloc] ADD  CONSTRAINT [DF_RIIBNRToAlloc_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO