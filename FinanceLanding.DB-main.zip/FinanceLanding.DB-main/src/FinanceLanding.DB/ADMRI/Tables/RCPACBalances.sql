CREATE TABLE [ADMRI].[PERIODS_RCPACBALANCES](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[AsAt] [int] NOT NULL,
	[Dateoffact] [varchar](15) NOT NULL,
	[AuditSource] [char](15) NULL,
	[AuditGenerateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](55) NOT NULL,
	[AuditHost] [nvarchar](55) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [ADMRI].[PERIODS_RCPACBALANCES] ADD  DEFAULT (getutcdate()) FOR [AuditGenerateDateTime]
GO

ALTER TABLE [ADMRI].[PERIODS_RCPACBALANCES] ADD  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [ADMRI].[PERIODS_RCPACBALANCES] ADD  DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO