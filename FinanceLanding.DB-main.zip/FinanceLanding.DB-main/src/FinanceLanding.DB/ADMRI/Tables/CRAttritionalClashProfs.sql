CREATE TABLE [ADMRI].[CRAttritionalClashProfs](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[RDId] [int] NULL,
	[RDPeriod] [int] NULL,
	[RDKey] [nvarchar](255) NULL,
	[RDSynd] [int] NULL,
	[RDOffice] [nvarchar](25) NULL,
	[RIPolicyType] [nvarchar](255) NULL,
	[ProgramCode] [nvarchar](255) NULL,
	[InRDUltimates] [nvarchar](25) NOT NULL,
	[Value] [numeric](38, 12) NULL,
	[Split] [numeric](38, 12) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [ADMRI].[CRAttritionalClashProfs] ADD  CONSTRAINT [DF_CRAttritionalClashProfs_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [ADMRI].[CRAttritionalClashProfs] ADD  CONSTRAINT [DF_CRAttritionalClashProfs_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO