CREATE TABLE [ADMRI].[RIProgrammeCatData](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Key-1] [nvarchar](255) NULL,
	[Proc_Period] [datetime] NULL,
	[Dept] [nvarchar](255) NULL,
	[Spe_Description] [nvarchar](255) NULL,
	[Trifocus] [nvarchar](255) NULL,
	[Cla_Year_of_Account] [int] NULL,
	[Ritype] [nvarchar](255) NULL,
	[ProgramName] [nvarchar](255) NULL,
	[Clo_Claim_Currency] [nvarchar](255) NULL,
	[Fac] [numeric](38, 12) NULL,
	[Paid] [numeric](38, 12) NULL,
	[Outstanding] [numeric](38, 12) NULL,
	[Total Incurred] [numeric](38, 12) NULL,
	[programname Trim] [nvarchar](255) NULL,
	[Ifrs17_Programme_Group] [nvarchar](255) NULL,
	[Synd] [varchar](10) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [ADMRI].[RIProgrammeCatData] ADD  CONSTRAINT [DF_RIProgrammeCatData_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [ADMRI].[RIProgrammeCatData] ADD  CONSTRAINT [DF_RIProgrammeCatData_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO
