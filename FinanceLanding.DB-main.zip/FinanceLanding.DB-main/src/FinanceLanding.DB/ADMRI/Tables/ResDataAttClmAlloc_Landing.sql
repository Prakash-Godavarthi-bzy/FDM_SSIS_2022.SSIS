CREATE TABLE [ADMRI].[ResDataAttClmAlloc_Landing](
	[PK_Transaction] [int] IDENTITY(1,1) NOT NULL,
	[DOF] [datetime] NULL,
	[ASAT] [int] NULL,
	[Scenario] [nvarchar](25) NOT NULL,
	[Account] [nvarchar](25) NOT NULL,
	[DataSet] [nvarchar](25) NOT NULL,
	[BusinessKey] [nvarchar](255) NOT NULL,
	[PolicyNumber] [nvarchar](25) NOT NULL,
	[InceptionDate] [datetime] NULL,
	[ExpiryDate] [datetime] NULL,
	[BindDate] [datetime] NULL,
	[DueDate] [datetime] NULL,
	[TriFocusCode] [nvarchar](255) NULL,
	[Entity] [nvarchar](25) NULL,
	[YOA] [nvarchar](5) NULL,
	[TypeOfBusiness] [nvarchar](1) NOT NULL,
	[StatsCode] [nvarchar](50) NULL,
	[SettlementCCY] [nvarchar](7) NULL,
	[OriginalCCY] [nvarchar](7) NULL,
	[IsToDate] [nvarchar](1) NOT NULL,
	[value] [numeric](38, 12) NULL,
	[RowHash] [nvarchar](255) NULL,
	[Fk_Allocation] [int] NULL,
	[AuditSourceBatchID] [int] NULL,
	[AuditHost] [int] NULL,
	[Basis] [nvarchar](25) NOT NULL,
	[Location] [nvarchar](25) NULL,
	[BusinessProcessCode] [nvarchar](25) NOT NULL,
	[Fk_Batch] [int] NULL,
	[BoundDate] [datetime] NULL,
	[RIPolicyType] [nvarchar](255) NULL,
	[ProgrammeCode] [nvarchar](255) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [ADMRI].[ResDataAttClmAlloc_Landing] ADD  CONSTRAINT [DF_OutboundReservingData_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [ADMRI].[ResDataAttClmAlloc_Landing] ADD  CONSTRAINT [DF_OutboundReservingData_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO
