CREATE TABLE [ADMRI].[CRRIPremiumClashProfs](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[RDId] [int] NULL,
	[RDPeriod] [int] NULL,
	[RDKEY] [nvarchar](255) NULL,
	[RDSynd] [int] NULL,
	[RDOFFICE] [nvarchar](25) NULL,
	[InRDUltimates] [nvarchar](25) NULL,
	[ProgrammeCode] [nvarchar](255) NULL,
	[value] [numeric](38, 12) NULL,
	[Split] [numeric](38, 12) NULL,
	[RIPolicyType] [nvarchar](25) NULL,
	[KeyForUnallocated] [nvarchar](255) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [ADMRI].[CRRIPremiumClashProfs] ADD  CONSTRAINT [DF_CRRIPremiumClashProfs_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [ADMRI].[CRRIPremiumClashProfs] ADD  CONSTRAINT [DF_CRRIPremiumClashProfs_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO