CREATE TABLE [ADMRI].[RIIBNRUnallocated](
	[Id] [int] NULL,
	[asat] [int] NULL,
	[RDKEy] [nvarchar](255) NULL,
	[YOA] [int] NULL,
	[Triangle_Group] [nvarchar](255) NULL,
	[Department] [nvarchar](255) NULL,
	[ccy] [nvarchar](3) NULL,
	[Synd] [int] NULL,
	[special] [nvarchar](255) NULL,
	[Office_Location] [nvarchar](50) NULL,
	[TrifocusCode] [nvarchar](255) NULL,
	[EntitySet] [nvarchar](255) NULL,
	[RI_IBNR_ToAlloc] [numeric](38, 12) NULL,
	[Open/Closed] [nvarchar](50) NULL,
	[LookupForOverride] [nvarchar](255) NULL,
	[TrifocusOverride] [nvarchar](255) NULL,
	[asatOverride] [numeric](38, 12) NULL,
	[RDKeyOverride] [nvarchar](255) NULL,
	[KeyForUnallocated] [nvarchar](255) NULL,
	[In Attritional] [nvarchar](50) NULL,
	[In Attritional_NoSynd] [nvarchar](50) NULL,
	[In ClosedYOA] [nvarchar](50) NULL,
	[In ClosedYOA_NoSynd] [nvarchar](50) NULL,
	[In RIPremium] [nvarchar](50) NULL,
	[In RIPremium_NoSynd] [nvarchar](50) NULL,
	[In ManualSource] [nvarchar](50) NULL,
	[In closedYOASpecial] [nvarchar](50) NULL,
	[In RIPremiumCP] [nvarchar](50) NULL,
	[In ClosedYOACP] [nvarchar](50) NULL,
	[In data] [nvarchar](50) NULL,
	[InValid_RD_Record] [nvarchar](50) NULL,
	[Rule_Unalloc_ClosedYOA] [nvarchar](255) NULL,
	[Rule_Unalloc_ClosedYOA_NoSynd] [nvarchar](255) NULL,
	[Rule_Unalloc_RIPremium] [nvarchar](255) NULL,
	[Rule_Unalloc_RIPremium_NoSynd] [nvarchar](255) NULL,
	[Rule_Unalloc_Attritional] [nvarchar](50) NULL,
	[Rule_Unalloc_ManualSource] [nvarchar](50) NULL,
	[Rule_Unalloc_ClosedYOASpecial] [nvarchar](255) NULL,
	[Rule_Unalloc_RIPremiumCP] [nvarchar](255) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [ADMRI].[RIIBNRUnallocated] ADD  CONSTRAINT [DF_RIIBNRUnallocated_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [ADMRI].[RIIBNRUnallocated] ADD  CONSTRAINT [DF_RIIBNRUnallocated_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO