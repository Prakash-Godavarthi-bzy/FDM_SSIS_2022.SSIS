CREATE TABLE [ADMRI].[CRClosedYOAAlloc](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[RDId] [int] NULL,
	[RDPeriod] [int] NULL,
	[RDKEY] [nvarchar](255) NULL,
	[RDSynd] [int] NULL,
	[RDOFFICE] [char](3) NULL,
	[RIPolicyType] [nvarchar](255) NULL,
	[ProgrammeCode] [nvarchar](255) NULL,
	[InRDUltimates] [nvarchar](25) NULL,
	[value] [numeric](38, 12) NULL,
	[SPLIT] [numeric](38, 12) NOT NULL,
	[KeyForUnallocated] [nvarchar](255) NULL,
	[RDKeySplit] [numeric](38, 12) NOT NULL,
	[KeyForUnallocatedSplit] [numeric](38, 12) NOT NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [ADMRI].[CRClosedYOAAlloc] ADD  CONSTRAINT [DF_CRClosedYOAAlloc_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [ADMRI].[CRClosedYOAAlloc] ADD  CONSTRAINT [DF_CRClosedYOAAlloc_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO