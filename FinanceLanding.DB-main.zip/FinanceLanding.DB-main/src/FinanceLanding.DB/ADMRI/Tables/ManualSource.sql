CREATE TABLE [ADMRI].[ManualSource](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[RDid] [int] NULL,
	[RDPeriod] [int] NULL,
	[RDKey] [nvarchar](255) NULL,
	[RDSynd] [int] NULL,
	[RIPolicyType] [nvarchar](255) NULL,
	[ProgrammeCode] [nvarchar](255) NULL,
	[InRDUltimates] [nvarchar](255) NULL,
	[Value] [numeric](38, 12) NULL,
	[Split] [numeric](38, 12) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [ADMRI].[ManualSource] ADD  CONSTRAINT [DF_ManualSource_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [ADMRI].[ManualSource] ADD  CONSTRAINT [DF_ManualSource_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO