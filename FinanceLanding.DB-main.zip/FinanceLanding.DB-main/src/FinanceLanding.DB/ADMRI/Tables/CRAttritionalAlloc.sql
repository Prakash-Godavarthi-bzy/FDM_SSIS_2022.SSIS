CREATE TABLE [ADMRI].[CRAttritionalAlloc](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[RDId] [int] NULL,
	[RDPeriod] [int] NULL,
	[RDKey] [varchar](255) NULL,
	[RDSynd] [int] NULL,
	[RDOffice] [char](3) NULL,
	[RIPolicyType] [varchar](255) NULL,
	[ProgramCode] [varchar](255) NULL,
	[InRDUltimates] [varchar](25) NOT NULL,
	[Value] [numeric](38, 12) NULL,
	[SPLIT] [numeric](38, 12) NULL,
	[KeyForUnallocated] [varchar](255) NULL,
	[RDKeySplit] [numeric](38, 12) NULL,
	[KeyForUnallocatedSplit] [numeric](38, 12) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [ADMRI].[CRAttritionalAlloc] ADD  CONSTRAINT [DF_CRAttritionalAlloc_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [ADMRI].[CRAttritionalAlloc] ADD  CONSTRAINT [DF_CRAttritionalAlloc_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO