CREATE TABLE [ADMRI].[SlUltimatesCurrentQuarter](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[TriFocusName] [nvarchar](255) NULL,
	[YOA] [int] NULL,
	[CCY] [nvarchar](255) NULL,
	[ClashOnlyActual] [numeric](38, 12) NULL,
	[ClashOnlyML] [numeric](38, 12) NULL,
	[ClashIBNR] [numeric](38, 12) NULL,
	[Period] [int] NULL,
	[Synd] [varchar](10) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [ADMRI].[SlUltimatesCurrentQuarter] ADD  CONSTRAINT [DF_SlUltimatesCurrentQuarter_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [ADMRI].[SlUltimatesCurrentQuarter] ADD  CONSTRAINT [DF_SlUltimatesCurrentQuarter_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO