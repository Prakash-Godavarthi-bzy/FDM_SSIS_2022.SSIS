CREATE TABLE [ADMRI].[AllocOverrides](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Lookup] [nvarchar](255) NULL,
	[AsAt] [int] NULL,
	[YOA] [int] NULL,
	[TrifocusCode] [nvarchar](255) NULL,
	[FromName] [nvarchar](255) NULL,
	[TrifocusCodeOverride] [nvarchar](255) NULL,
	[ToName] [nvarchar](255) NULL,
	[AsAtOverride] [int] NULL,
	[InUnallocated] [nvarchar](255) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [ADMRI].[AllocOverrides] ADD  CONSTRAINT [DF_AllocOverrides_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [ADMRI].[AllocOverrides] ADD  CONSTRAINT [DF_AllocOverrides_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO


