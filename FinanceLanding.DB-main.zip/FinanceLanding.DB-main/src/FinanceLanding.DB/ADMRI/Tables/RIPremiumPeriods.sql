CREATE TABLE [ADMRI].[PERIODS_RIPREMIUM](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CRPeriod] [int] NOT NULL,
	[RDPeriod] [int] NOT NULL,
	[AuditSource] [char](15) NULL,
	[AuditGenerateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](55) NOT NULL,
	[AuditHost] [nvarchar](55) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [ADMRI].[PERIODS_RIPREMIUM] ADD  DEFAULT (getutcdate()) FOR [AuditGenerateDateTime]
GO

ALTER TABLE [ADMRI].[PERIODS_RIPREMIUM] ADD  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [ADMRI].[PERIODS_RIPREMIUM] ADD  DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO