CREATE TABLE [ADMRI].[CRRIPremiumAlloc](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[RDId] [int] NULL,
	[RDPeriod] [int] NULL,
	[RDKEY] [nvarchar](255) NULL,
	[RDSynd] [int] NULL,
	[RDOFFICE] [nvarchar](25) NULL,
	[RIPolicyType] [nvarchar](255) NULL,
	[ProgrammeCode] [nvarchar](255) NULL,
	[InRDUltimates] [nvarchar](255) NOT NULL,
	[value] [numeric](38, 12) NULL,
	[SPLIT] [numeric](38, 12) NOT NULL,
	[KeyForUnallocated] [nvarchar](255) NULL,
	[RDKeySplit] [numeric](38, 12) NOT NULL,
	[KeyForUnallocatedSplit] [numeric](38, 12) NOT NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [ADMRI].[CRRIPremiumAlloc] ADD  CONSTRAINT [DF_CRRIPremiumAlloc_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [ADMRI].[CRRIPremiumAlloc] ADD  CONSTRAINT [DF_CRRIPremiumAlloc_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO