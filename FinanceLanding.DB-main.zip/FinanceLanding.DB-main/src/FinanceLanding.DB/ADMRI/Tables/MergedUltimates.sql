CREATE TABLE [ADMRI].[MergedUltimates](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[RDId] [int] NULL,
	[RIPolicyType] [varchar](50) NULL,
	[ProgrammeCode] [varchar](50) NULL,
	[Value] [numeric](38, 12) NULL,
	[Source] nvarchar(50) null,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [ADMRI].[MergedUltimates] ADD  CONSTRAINT [DF_MergedUltimates_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [ADMRI].[MergedUltimates] ADD  CONSTRAINT [DF_MergedUltimates_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO