CREATE proc [ADMRI].[ResDataAttClmAllocLandingPhase2] as 
begin
/*
 LastModified by Author:		Venkat Yerravati <Venkat.yerravati@beazley.com>
 Modified date: 22-05-2024
 Description:	Added three specials to map it with ProgrammeCode
 https://beazley.atlassian.net/browse/I1B-5504

  LastModified by :		Venkat Yerravati <Venkat.yerravati@beazley.com>
 Modified date: 01-08-2024
 Description:	Removed the period mappings tables and implemented their pattern in the code.
https://beazley.atlassian.net/browse/I1B-5637
*/


drop table if exists #EntitySet

CREATE TABLE #EntitySet (Entity varchar(25), EntitySet varchar(10))

INSERT into #Entityset (Entity, EntitySet)
 select '623' as Entity,	'Core' as EntitySet
union ALL
select '2623' as Entity,'Core' as EntitySet
union ALL
select '1174' as Entity,'Core' as EntitySet
union ALL
select '6050' as Entity,'6050' as EntitySet
union ALL
select '3623' as Entity,'3623' as EntitySet
union ALL
select '3622' as Entity,'3622' as EntitySet
union ALL
select '8022' as Entity,'8022' as EntitySet
union ALL
select '6107' as Entity,'6107' as EntitySet
union ALL
select '8033' as Entity,'BIDAC' as EntitySet
union ALL
select 'BIARFR' as Entity,'BIDAC' as EntitySet
union ALL
select 'BIARGE' as Entity,'BIDAC' as EntitySet
union ALL
select 'BIARSP' as Entity,'BIDAC' as EntitySet
union ALL
select 'BIARSW' as Entity,'BIDAC' as EntitySet
union ALL
select 'BIARUK' as Entity,'BIDAC' as EntitySet
union ALL
select 'BIDAC' as Entity,'BIDAC' as EntitySet
union ALL
select 'BIFR' as Entity,'BIDAC' as EntitySet
union ALL
select 'BIGE' as Entity,'BIDAC' as EntitySet
union ALL
select 'BISP' as Entity,'BIDAC' as EntitySet
union ALL
select 'BISW' as Entity,'BIDAC' as EntitySet
union ALL
select 'BIUK' as Entity,'BIDAC' as EntitySet
union ALL
select '5623' as Entity,'5623' as EntitySet
union all
select '8044' as Entity, '8044' as EntitySet--change
Union All
select 'BESI' as Entity,'8044' as EntitySet
Union All
Select 'USBESI' as Entity,'8044' as EntitySet
union ALL
select 'No Entity' as Entity,	'No Entity' as EntitySet


drop table if exists #Final_ReservingData 

select rd.[asat], [ccy], [datasetgroup], [datasetname], [gross_ri], [special], [Synd], [triangle_group],  cast(Value as decimal(38,8)) as Value, [yoa], rd.[id], [department], [att_Cat], [Office_Location]
,isnull(e.EntitySet,rd.Synd) as EntitySet
,[To Add Back]  = case  when synd In ('6050','6107','8022') then null   --Special to ProgrammeCode mapping           
		  						when Special IS null then null--'Unknown'         
		  						when Special in ('Berkshire','Berkshire AFIC','Berkshire Munich') then 'Berkshire Hathaway'                     
		  						when Special in ('Cede 6050','Cede 6050 Munich') then 'Cede 6050'                      
		  						when Special='Gen Re' then 'GEN RE QQS'            
		  						when Special='Munich' then 'MUNQQS'            
		  						when Special='Profs' then 'Professions'            
		  						when Special='WHOLE AC S/LOSS' then 'Whole Account Stop Loss'            
		  						when Special='Cede 5623' then 'Cede 5623'            
		  						when Special='Cede 6107' then 'Cede 6107'            
		  						when Special='Cede to 5623' then 'Cede 5623'            
		  						when Special='Cede 3623' then null         
		  						when Special='Consol Adj' then null 
								when special='ConsolAdjBID' then 'Consol Adj'
								when special='Cede BID' then 'BESIQS'
								when special='Cede BID Treaty' then 'TTYBDC'
		  						--Else    special  
		  					End    
,Case when Special In ('Berkshire','Berkshire AFIC','Berkshire Munich','Cede 3623','Cede 6050',              
'Cede 6050 Munich','Consol Adj','Gen Re','Munich','Profs','WHOLE AC S/LOSS','Cede 5623','Cede 6107','Cede to 5623','ConsolAdjBID','Cede BID','Cede BID Treaty') OR Synd in('6050','6107','8022')              
then 'Exclude' Else 'Include'              
end as [Include]                           
--,case when a.DateOfFact is null then 'Exclude' else a.DateOfFact end as DOF
,case when asat=202003 then cast(asat as varchar(10))
when right(asat,2) in (11,05) then cast(asat-2  as varchar(10))
when RIGHT(asat,2) in (12,06) then cast(asat  as varchar(10))
else 'exclude' end as DOF
,Case when triangle_group In ('Covers') then 'Covers Us'
when triangle_group In ('BICI A&E OPPI') then 'BICI A&E OPPI (closed)'
when triangle_group In ('BICI Marine') then 'BICI Falvey Marine'
when triangle_group In ('Swiss') then 'Private Clients'
when triangle_group In ('VaultRiskCryptoasset') then 'Vault Risk Cryptoassets'
else triangle_group
End as triangle_group_TF

into #Final_ReservingData 

from FinanceLanding.adm.Reserving_data rd  
--left join AsAtDOF a on rd.asat=a.AsAt
--left join [ADMRI].[PERIODS_FINALRESERVINGDATA] a on rd.asat=a.AsAt
left join #Entityset e on cast(rd.Synd as varchar(50))=e.Entity
where rd.asat>=201809 and rd.asat<>201813 and att_cat='Attritional'               
and datasetgroup='Pure Claims'    
and value <> 0 
and round(Value ,8)<>0 and gross_ri='ri'    


CREATE CLUSTERED INDEX [CIX_Final_ReservingData_DOF_include] ON #Final_ReservingData (DOF, [Include]) 



DROP TABLE IF EXISTS #Reserving_data

/* Added RDKey as computed column*/
CREATE TABLE #Reserving_data (
id int NOT NULL,
department	nvarchar(30) NULL,
datasetname	nvarchar(100) NULL,
triangle_group	nvarchar(50) NULL,
yoa	int NULL,
gross_ri nvarchar(5) NULL,
ccy	nvarchar(7) NULL,
Value money NULL,
att_Cat	nvarchar(11) NULL,
special	nvarchar(50) NULL,
Synd int NULL,
asat int NULL,
datasetgroup char(50) NULL,
Office_Location	char(3) NULL,
Include	varchar(7) NOT NULL,
DOF	varchar(7)  NULL,
[6107QS_Adjustment] DECIMAL(38,8) NOT NULL,	
AdjustedValue	DECIMAL(38,8) NULL,
TrifocusCode	nvarchar (260) NULL,
EntitySet	varchar(25) NULL,
RDKEy 	 AS concat(
                 coalesce(cast(asat as varchar(10)) + '|', ''),
                 coalesce(cast(yoa as varchar(10)) + '|', ''),
                 coalesce(TrifocusCode + '|', ''),
                 coalesce(ccy + '|', ''),
                 coalesce(EntitySet, '')
             ) PERSISTED NOT NULL ,
RDPercent	decimal(38,8) NULL
)

;with reservingdatari as (

select src.id,
       src.department,
       SRC.datasetname,
       src.triangle_group,
       src.yoa,
       src.gross_ri,
       src.ccy,
       src.value as Value,
       src.att_Cat,
       src.special,
       src.Synd,
       src.asat,
       src.datasetgroup,
       src.Office_Location,
       src.Include,
       src.DOF, --src.*
       ISNULL(cast(dest.[QS_Adjustment] as decimal(38,8)), 0) as [6107QS_Adjustment],
       cast(src.value - (ISNULL(dest.[QS_Adjustment], 0)) as decimal(38,8)) as AdjustedValue,
       TC.TrifocusCode,
       Case
           when cast(Synd as varchar(25)) in ( '623', '2623', '1174' ) THEN 'Core'
           when cast(Synd as varchar(25)) in ( '8033', 'BIARFR', 'BIARGE', 'BIARSP', 'BIARSW', 'BIARUK', 'BIFR','BIGE', 'BISP', 'BISW', 'BIUK') THEN 'BIDAC'
           ELSE
               cast(Synd as varchar(25))
       END AS [EntitySet],

      case
           when ([Value] - (ISNULL( CONVERT(DECIMAL(38,8),dest.[QS_Adjustment]), 0))) = 0 then
               0
           when (sum([Value] - (ISNULL(CONVERT(DECIMAL(38,8),dest.[QS_Adjustment]), 0))) over (partition by (cast(src.asat as varchar(10))
                                                                                      + '|'
                                                                                      + cast(src.yoa as varchar(10))
                                                                                      + '|' + TC.TrifocusCode + '|'
                                                                                      + src.ccy + '|' + src.EntitySet
                                                                                     )
                                                                       )
                ) = 0 then
               0
           else
       ([Value] - (ISNULL(CONVERT(DECIMAL(38,8),dest.[QS_Adjustment]), 0)))
       / (sum([Value] - (ISNULL(CONVERT(DECIMAL(38,8),dest.[QS_Adjustment]), 0))) over (partition by (cast(src.asat as varchar(10)) + '|'
                                                                               + cast(src.yoa as varchar(10)) + '|'
                                                                               + TC.TrifocusCode + '|' + src.ccy + '|'
                                                                               + src.EntitySet
                                                                              )
                                                                )
         )
       end as RDPercent

from #Final_ReservingData src

    Left Join FinanceLanding.fdm.DimTrifocus TC
        ON src.triangle_group_TF = TC.TrifocusName
    Left join MDS.[DQFix6107CreatedRI] dest 
        on src.[id] = dest.[id]
where [DOF] <> 'Exclude'
      and Include = 'Include')

INSERT INTO #Reserving_data (id,
department,
datasetname,
triangle_group,
yoa,
gross_ri,
ccy,
Value,
att_Cat,
special,
Synd,
asat,
datasetgroup,
Office_Location,
Include,
DOF,
[6107QS_Adjustment],
AdjustedValue,
TrifocusCode,
EntitySet,
RDPercent)

select id=min(id),
department,
datasetname,
triangle_group,
yoa,
gross_ri,
ccy,
sum(Value) as value,
att_cat,
special,
Synd,
asat,
datasetgroup,
office_location,
Include,
DOF,
[6107QS_Adjustment],
AdjustedValue=sum(AdjustedValue),
TrifocusCode,
EntitySet,
sum(RDPercent) RDPercent
from reservingdatari
group by 
department,
datasetname,
triangle_group,
yoa,
gross_ri,
ccy,
att_cat,
special,
Synd,
asat,
datasetgroup,
office_location,
Include,
DOF,
[6107QS_Adjustment],
--AdjustedValue,
TrifocusCode,
EntitySet
--RDPercent

OPTION (USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'))

--select QS_Adjustment, CONVERT(DECIMAL(38,4), QS_Adjustment) ,
--QS_Adjustment- (CONVERT(DECIMAL(38,4), QS_Adjustment) )
--from MDS.[DQFix6107CreatedRI]
-----------------------------------------Ceded_Re_Claims--------------------------------------------------------------------




Drop table if exists #Ceded_Re_Incurred_deltas



select DateOfFact, TrifocusCode, Entity, cast(YOA as int) YOA, SettlementCCY, 
case when ProgrammeCode='IRIEQS' then 'ERIE QS' Else ProgrammeCode end as ProgrammeCode  ,E.RIPolicyType, 

CONVERT(DECIMAL(38,8),sum(Value)) as value,
case when Entity In ('6050','6107','8022') then 'Exclude'
     when RIPolicyType='QQ' then 'Exclude'
     when ProgrammeCode In('Berkshire Hathaway',
'Exclude','Cede 6050','Exclude','GEN RE QQS','MUNQQS','Professions','Whole Account Stop Loss','Cede 5623','Cede 6107', 'BESIQS', 'TTYBDC') then 'Exclude'
Else 'Include'
End as [Include]

into #Ceded_Re_Incurred_deltas
from FinanceDataContract.Outbound.[Transaction] T
left join FinanceDataContract.Outbound.Transaction_ReInsurance_Extensions_Bridge B ON T.RowHash=B.RowHash_Transaction
left join FinanceDataContract.Outbound.Transaction_ReInsurance_Extensions E ON B.RowHash_Transaction_ReInsurance_Extensions=E.RowHash_Transaction_ReInsurance_Extensions
where Dataset='Ceded_Re_Claims_Incurred' 
group by 
DateOfFact, TrifocusCode, Entity, YOA, SettlementCCY, 
case when E.ProgrammeCode='IRIEQS' then 'ERIE QS' Else E.ProgrammeCode end  ,E.RIPolicyType,
case when Entity In ('6050','6107','8022') then 'Exclude'
     when RIPolicyType='QQ' then 'Exclude'
     when ProgrammeCode In('Berkshire Hathaway',
'Exclude','Cede 6050','Exclude','GEN RE QQS','MUNQQS','Professions','Whole Account Stop Loss','Cede 5623','Cede 6107', 'BESIQS', 'TTYBDC') then 'Exclude'
Else 'Include'
End


CREATE CLUSTERED  INDEX [CIX_Ceded_Re_Incurred_deltas_Include] ON #Ceded_Re_Incurred_deltas ([Include]) 

CREATE CLUSTERED INDEX [IX_EntitySet_Entity] ON #EntitySet (Entity)




DROP TABLE IF EXISTS #CR_Incurred_Balances 

-- Define the start date and the current date
DECLARE @StartDate DATE = '2018-12-01';
DECLARE @EndDate DATE = GETDATE();

WITH Numbers AS (
    SELECT TOP (DATEDIFF(MONTH, @StartDate, @EndDate) / 3 + 1)
        ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 AS N
    FROM master..spt_values -- This is a system table with a large number of rows
)
,Quarters_IncClaims as (
SELECT
    DATEADD(MONTH, N * 3, @StartDate) AS Quarter,'include' as Dummy
FROM
    Numbers
WHERE
    DATEADD(MONTH, N * 3, @StartDate) <= EOMONTH(@EndDate, DATEDIFF(MONTH, 0, @EndDate) % 3)
    AND DATEADD(MONTH, N * 3, @StartDate) <> '2023-03-01'
)



select Quarter,
       b.Entity,
       ProgrammeCode,
       RIPolicyType,
       SettlementCCY,
       TrifocusCode,
       YOA,
       sum(value) as Balance,
       YEAR(a.Quarter) * 100 + MONTH(a.Quarter) as Period,
       isnull(es.EntitySet, b.Entity) as EntitySet,
       cast((YEAR(a.Quarter) * 100 + MONTH(a.Quarter)) as varchar(50)) + '|' + isnull(cast(YOA as varchar(50)) + '|', '') + isnull(TrifocusCode + '|', '') + isnull(SettlementCCY + '|', '')
       + isnull(ISNULL(es.EntitySet, b.Entity), '') IncurredKey

INTO #CR_Incurred_Balances 
from #Ceded_Re_Incurred_deltas b
 
--left join #Quarters_Inclaims a
left join Quarters_IncClaims a
        on a.Dummy = b.Include
left join #Entityset es
        on b.Entity = es.Entity
where [Include] = 'Include'
      and b.DateOfFact <= [Quarter]
group by Quarter,
         b.Entity,
         ProgrammeCode,
         RIPolicyType,
         SettlementCCY,
         TrifocusCode,
         YOA,
         YEAR(a.Quarter) * 100 + MONTH(a.Quarter),
         isnull(es.EntitySet, b.Entity)
/* ##RE_ADDED - This is to get a better row estimate from #ceded_re_incurred_deltas and avoid tempdb spills).  */
OPTION (USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'),NO_PERFORMANCE_SPOOL)


CREATE CLUSTERED INDEX [CIX_CR_Incurred_Balances_TrifocusCode] ON #CR_Incurred_Balances (TrifocusCode)

DROP TABLE IF EXISTS #CR_Incurred_No_entity

select [period],
       YOA,
       ib.TrifocusCode,
       ProgrammeCode,
       RIPolicyType,
       SettlementCCY,
       EntitySet,
       IncurredKey,
       sum(Balance) as Balance,
       case
           when ProgrammeCode = 'FAC'
                or RIPolicyType = 'FAC' then
               isnull(RIProgramme, ProgrammeCode)
           else
               ProgrammeCode
       end as TrimProgramCode

INTO  #CR_Incurred_No_entity
from #CR_Incurred_Balances ib
    left join FinanceLanding.mds.FACPrgTrifocusMapping tm
        on ib.TrifocusCode = tm.TrifocusCode
group by [period],
         YOA,
         ib.TrifocusCode,
         ProgrammeCode,
         RIPolicyType,
         SettlementCCY,
         EntitySet,
         IncurredKey,
         case
             when ProgrammeCode = 'FAC'
                  or RIPolicyType = 'FAC' then
                 isnull(RIProgramme, ProgrammeCode)
             else
                 ProgrammeCode
         end

CREATE CLUSTERED INDEX [CIX_CR_Incurred_No_entity_Period] ON #CR_Incurred_No_entity (Period) 


Drop table if exists #CR_Incurred_Periods

select e.[period],
       e.YOA,
       e.TrifocusCode,
       e.ProgrammeCode,
       e.RIPolicyType,
       e.SettlementCCY,
       e.EntitySet,
       e.IncurredKey,
	   e.Balance,
	   e.TrimProgramCode,
       e.RDPeriod,
       cast(RDPeriod as varchar(500)) + '|' + cast(YOA as varchar(50)) + '|' + TrifocusCode + '|' + SettlementCCY + '|' + EntitySet as RDKey
	   into #CR_Incurred_Periods
		from (
		select *,
		case when Period=201812 then 201811 end as RDPeriod
		
		from #CR_Incurred_No_entity e
		where Period=201812
		union 
		select *
		,case when period=201812 then 201812
		when Period=202003 then 202003
		when right(Period,2) in (03,09) and left(Period,4) <2023 then Period+2
		when right(Period,2) in (06,12) and left(Period,4) <2023 then Period
		
		when right(Period,2) in (06,12) and left(Period,4) >=2023 then Period-1
		when right(Period,2) in (09) then Period-3
		when right(Period,2) in (03) and left(Period,4) >2023 
			then cast((left(Period,4)-1) as varchar(10))+'12'
		end as RDperiod
		
		from #CR_Incurred_No_entity) e


drop table if exists #RD_RI_Split
select id as RDId,Synd as RDSynd,Office_Location as RDOffice,RDKEy,RDPercent 
into #RD_RI_Split
from #Reserving_data


where round(RDPercent,8)<>0  


CREATE CLUSTERED INDEX [CIX_RD_RI_Split_RDKey] ON #RD_RI_Split (RDKey)
CREATE CLUSTERED INDEX [CIX_CR_Incurred_Periods_RDKey] ON #CR_Incurred_Periods (RDKey)


drop table if exists #CR_Incurred_Split
select Period,
       YOA,
       TrifocusCode,
       SettlementCCY,
       RIPolicyType,
       TrimProgramCode as ProgramCode,
       IncurredKey,
       ips.RDKey,
       RDPeriod,
       Balance,
       RDId,
       RDSynd,
       RDOffice,
       RDPercent,
       case
           when ips.RDKey = rs.RDKEy then
               'In RD Ultimates'
           else
               'Not in RD Ultimates'
       end as InRDUltimates,
		   CONVERT(DECIMAL(38,8),sum(   case
                  when (case
                            when ips.RDKey = rs.RDKEy then
                                'In RD Ultimates'
                            else
                                'Not in RD Ultimates'
                        end
                       ) = 'In RD Ultimates' then
                      RDPercent * Balance
                  else
                      Balance
              end
          )) as Value


into #CR_Incurred_Split
from #CR_Incurred_Periods ips
    left join #RD_RI_Split rs
        on ips.RDKey = rs.RDKEy

group by Period,
         YOA,
         TrifocusCode,
         SettlementCCY,
         RIPolicyType,
         TrimProgramCode,
         IncurredKey,
         ips.RDKey,
         RDPeriod,
         Balance,
         RDId,
         RDSynd,
         RDOffice,
         RDPercent,
         case
             when ips.RDKey = rs.RDKEy then
                 'In RD Ultimates'
             else
                 'Not in RD Ultimates'
         end
OPTION (USE HINT ('ENABLE_PARALLEL_PLAN_PREFERENCE'))



---------CededReClargeLosses----------------------------

drop table if exists #Large_Losses;

   with  RI_Programme_Cat_Data
as (select proc_period,
           dept,
           spe_description,
           trifocus,
           cla_year_of_account,
           ritype,
           programname,
           clo_claim_currency,
           [Total Incurred],
           ifrs17_programme_group,
           case
               when ritype = 'QQ' then
                   'Exclude'
               when spe_description in ( 'UK FLOODS', 'XYNTHIA' ) then
                   'Exclude'
               when ifrs17_programme_group NOT IN ( 'Berkshire Hathaway', 'Exclude', 'Cede 6050', 'GEN RE QQS',
                                                    'MUNQQS', 'Professions', 'Whole Account Stop Loss', 'Cede 5623',
                                                    'Cede 6107', 'BESIQS', 'TTYBDC'
                                                  ) then
                   'Include'
               when ifrs17_programme_group = 'MUNQQS' then
                   'Include'
               Else
                   'Exclude'
           End as [Include],
           YEAR(proc_period) * 100 + MONTH(proc_period) as Period,
           cla_year_of_account as YOA,
           TrifocusCode,
           ifrs17_programme_group as Programme_Code,
           case
               when ritype is not null then
                   ritype
               when ifrs17_programme_group in ( 'Commercial Facultative spend', 'Engineering Facultative spend',
                                                'Retail Facultative spend', 'Treaty Facultative spend'
                                              ) then
                   'FAC'
               when ritype in ( 'GEN (Whole Account)', 'MORTAR - Engineering Risk Xs', 'Property Cat XL',
                                'Property Risk Excess', 'Property XL', 'PRXS', 'Reinstatement Premium Protection'
                              ) then
                   'XL'
               else
                   'QS'
           end as RIPolicyType,
           clo_claim_currency as SettlementCCY,
		   isnull(e.EntitySet,cd.Synd) as EntitySet,--change
           cast((YEAR(proc_period) * 100 + MONTH(proc_period)) as varchar(50)) + '|'
           + isnull(cast(cla_year_of_account as varchar) + '|', '') + isnull(TrifocusCode + '|', '')
           + isnull(clo_claim_currency + '|', '')
           + isnull(e.EntitySet,cd.Synd)--change
			 as IncurredKey
    from FinanceLanding.ADMRI.RIProgrammeCatData cd--join with #entityset
        left join FinanceLanding.fdm.DimTrifocus dt
            on cd.trifocus = dt.TrifocusName
			left join #EntitySet e on cd.Synd=e.Entity
   ),
     Large_Losses_RDPeriod_1
as (select cd.*,
           --isnull(RDPeriod, Period) as RDPeriod
		   case when Period=202003 then 202003
   when right(Period,2) in (03,09) then Period+2
   else Period end as RDperiod
    from RI_Programme_Cat_Data cd
        --left join CR_RD_Periods_LLS ll
		--left join [ADMRI].[PERIODS_LARGELOSSES] ll
  --          on cd.Period = ll.CRPeriod
    where Include = 'Include'
   ),
     Large_Losses_RDPeriod
as (select *,
           isnull(cast(RDPeriod as varchar) + '|', '') + isnull(cast(YOA as varchar) + '|', '')
           + isnull(TrifocusCode + '|', '') + isnull(SettlementCCY + '|', '') + isnull(EntitySet, '') as RDKey
    from Large_Losses_RDPeriod_1
   ),
     Large_Losses_Included_Split
as (select rp.*,
           RDId,
           RDSynd,
           RDPercent,
           case
               when Rp.RDKey = rs.RDKEy then
                   'In RD Ultimates'
               else
                   'Not in RD Ultimates'
           end as InRDUltimates,
           case
               when (case
                         when Rp.RDKey = rs.RDKEy then
                             'In RD Ultimates'
                         else
                             'Not in RD Ultimates'
                     end
                    ) = 'In RD Ultimates' then
                   RDPercent * [Total Incurred]
               else
                   [Total Incurred]
           end as Value
    from Large_Losses_RDPeriod rp
        left join #RD_RI_Split rs
            on rp.RDKey = rs.RDKEy
   )

select Period,
       YOA,
       TrifocusCode,
       SettlementCCY,
       RIPolicyType,
       Programme_Code,
       IncurredKey,
       RDPeriod,
       RDKey,
       RDId,
       RDSynd,
       InRDUltimates,
	   CONVERT(DECIMAL(38,8),sum(value)) as Value

into #Large_Losses


from Large_Losses_Included_Split
group by Period,
         YOA,
         TrifocusCode,
         SettlementCCY,
         RIPolicyType,
         Programme_Code,
         IncurredKey,
         RDPeriod,
         RDKey,
         RDId,
         RDSynd,
         InRDUltimates

----------------------------------------------------Ceded re incurred Attritional Claims


drop table if exists #Large_Losses2
select RDId,
       RDPeriod,
       Period,
       YOA,
       TrifocusCode,
       SettlementCCY,
       RIPolicyType,
       Programme_Code,
       IncurredKey,
       RDKey,
       RDSynd,
       InRDUltimates,
       Value,
       isnull(rdkey + '|', '') + isnull(cast(rdid as varchar) + '|', '') + isnull(ripolicytype + '|', '') + isnull(Programme_Code, '') as IncurredLookUp
into #Large_Losses2
from #Large_Losses

drop table if exists #CR_incurred2

CREATE TABLE #CR_incurred2 (
	   RDId int NULL,
       RDPeriod int NOT NULL,
       Period int NULL,
       YOA int NULL,
       TrifocusCode varchar(25) NOT NULL,
       SettlementCCY varchar(3),
       RIPolicyType varchar(50),
       ProgramCode varchar(100),
       IncurredKey varchar(142),
       RDKey varchar(592),
       RDSynd int NULL,
       RDOffice char(3) NULL,
       InRDUltimates varchar(19),
	   Value DECIMAL(38,4),
	   IncurredLookUp nvarchar(1000))

INSERT INTO #CR_incurred2 (RDId,RDPeriod,Period,YOA,TrifocusCode,SettlementCCY,RIPolicyType,ProgramCode,IncurredKey,RDKey,RDSynd,RDOffice,InRDUltimates,Value,IncurredLookUp)
select RDId,
       RDPeriod,
       Period,
       YOA,
       TrifocusCode,
       SettlementCCY,
       RIPolicyType,
       ProgramCode,
       IncurredKey,
       RDKey,
       RDSynd,
       RDOffice,
       InRDUltimates,
       Value,
        isnull(rdkey + '|', '') + isnull(cast(rdid as varchar) + '|', '') + isnull(ripolicytype + '|', '') + isnull(ProgramCode, '') as IncurredLookUp
from #CR_Incurred_Split

CREATE CLUSTERED INDEX [CIX_CR_incurred2_IncurredLookup] ON #CR_incurred2 (IncurredLookup) 
CREATE CLUSTERED INDEX [CIX_Large_Losses2_IncurredLookup] ON #Large_Losses2 (IncurredLookup) 

DROP TABLE  IF EXISTS #Large_Losses1

select ls.RDId,
       ls.RDPeriod,
       ls.Period,
       ls.YOA,
       ls.TrifocusCode,
       ls.SettlementCCY,
       ls.RIPolicyType,
       ls.Programme_Code,
       ls.IncurredKey,
       ls.RDKey,
       ls.RDSynd,
       ls.InRDUltimates,
       ls.Value,
       ls.IncurredLookup,
       case
           when ls.IncurredLookUp = ci.IncurredLookup then
               'InIncurred'
           else
               'Not in Incurred'
       end as InIcurred,
       count(*) as CountIncurredLookup
into #Large_Losses1
from #Large_Losses2 ls
    left join #CR_incurred2 ci
        on ls.IncurredLookUp = ci.IncurredLookup
group by ls.RDId,
         ls.RDPeriod,
         ls.Period,
         ls.YOA,
         ls.TrifocusCode,
         ls.SettlementCCY,
         ls.RIPolicyType,
         ls.Programme_Code,
         ls.IncurredKey,
         ls.RDKey,
         ls.RDSynd,
         ls.InRDUltimates,
         ls.Value,
         ls.IncurredLookup,
         case
             when ls.IncurredLookUp = ci.IncurredLookup then
                 'InIncurred'
             else
                 'Not in Incurred'
         end

CREATE INDEX [IX_Large_Losses1_IncurredLookup] ON #Large_Losses1 (IncurredLookup)

Drop table if exists #CR_Attritional_Prog

select ci.RDId,
       ci.RDPeriod,
       ci.Period,
       ci.YOA,
       ci.TrifocusCode,
       ci.SettlementCCY,
       ci.RIPolicyType,
       ci.ProgramCode,
       ci.IncurredKey,
       ci.RDKey,
       ci.RDSynd,
       ci.RDOffice,
       ci.InRDUltimates,
       round(   (Ci.Value - (case
                                 when ls.IncurredLookUp = ci.IncurredLookup then
                                     ls.Value
                                 else
                                     0
                             end
                            )
                ),
                8
            ) as Value,
       case
           when ProgramCode IN ( 'Berkshire Hathaway', 'Exclude', 'Cede 6050', 'GEN RE QQS', 'MUNQQS',
                                     'Professions', 'Whole Account Stop Loss', 'Cede 5623', 'Cede 6107', 'BESIQS', 'TTYBDC'
                                   ) then
               'Special'
           else
               'Not Special'
       end as Special
into #CR_Attritional_Prog
from #CR_incurred2 ci
    left join #Large_Losses1 ls
        on ci.IncurredLookup = ls.IncurredLookUp



CREATE CLUSTERED INDEX [CIX_CR_Attritional_Prog_RDId_RDPeriod_RDKey] ON #CR_Attritional_Prog (RDId,
             RDPeriod,
             RDKey,
             RDSynd,
             RDOffice,
             RIPolicyType,
             ProgramCode,
             InRDUltimates) 

Drop table if exists #CR_Attritional_Clash_Profs
select RDId,
       RDPeriod,
       RDKey,
       RDSynd,
       RDOffice,
       RIPolicyType,
       ProgramCode,
       InRDUltimates,
	   CONVERT(DECIMAL (38,8),sum(Value)) as Value,
       100.00 as Split
into #CR_Attritional_Clash_Profs
from #CR_Attritional_Prog
where InRDUltimates = 'In RD Ultimates'
      and ProgramCode = 'Systemic cover - Clash'
      and (
              Value >= 0.0001
              or Value <= -0.0001
          )
group by RDId,
         RDPeriod,
         RDKey,
         RDSynd,
         RIPolicyType,
         RDOffice,
         ProgramCode,
         InRDUltimates


DROP TABLE IF EXISTS #CR_Attritional_for_Alloc_1;

CREATE TABLE #CR_Attritional_for_Alloc_1 (
		   RDId int NULL,
           RDPeriod int NOT NULL,
           RDKey varchar(1000) NULL,
           RDSynd int NULL,
           RDOffice char(3) NULL,
           RIPolicyType varchar(50) NULL,
           ProgramCode varchar(100) NULL,
           InRDUltimates varchar(19) NULL,
		   Value DECIMAL(38,4) NULL
		   )

INSERT INTO #CR_Attritional_for_Alloc_1 (RDId,
           RDPeriod,
           RDKey,
           RDSynd,
           RDOffice,
           RIPolicyType,
           ProgramCode,
           InRDUltimates,
           Value)

select	   RDId,
           RDPeriod,
           RDKey,
           RDSynd,
           RDOffice,
           RIPolicyType,
           ProgramCode,
           InRDUltimates,
           sum(Value) as Value
    from #CR_Attritional_Prog
    where (ProgramCode <> 'Systemic cover - Clash' or ProgramCode is null)
          and Value <> 0
          and Special = 'Not Special'
    group by RDId,
             RDPeriod,
             RDKey,
             RDSynd,
             RDOffice,
             RIPolicyType,
             ProgramCode,
             InRDUltimates
   

CREATE CLUSTERED INDEX [CIX_CR_Attritional_for_Alloc_1_RDId_RDPeriod_RDKey] ON #CR_Attritional_for_Alloc_1  (RDId,
             RDPeriod,
			 RDKey,
             RDSynd,
             RDOffice,
             RIPolicyType,
             ProgramCode,
             InRDUltimates) 


CREATE INDEX [IX_CR_Attritional_for_Alloc_1_InRDUltimates] ON #CR_Attritional_for_Alloc_1 (InRDUltimates)

DROP TABLE IF EXISTS #CR_Attritional_for_Alloc;
SELECT *,
	   
	     CONVERT(DECIMAL(38,8),case
           when InRDUltimates = 'In RD Ultimates' then
               ISNULL((Value / NULLIF(SUM(VALUE) OVER (PARTITION BY RDId ORDER BY RDID), 0)), 0) * 100
           ELSE
               0
       END) AS SPLIT,

       cast(RDKey as varchar) + '|' + isnull(cast(RDSynd as varchar), '') as KeyForUnallocated,
	   CONVERT(DECIMAL(38,8),ISNULL(Value / NULLIF(SUM(VALUE) OVER (PARTITION BY RDkey), 0), 0) * 100) as RDKeySplit,
	   CONVERT(DECIMAL(38,8),ISNULL(Value / NULLIF(SUM(VALUE) OVER (PARTITION BY (RDKey + '|' + cast(RDSynd as varchar))), 0), 0) * 100) as KeyForUnallocatedSplit



INTO #CR_Attritional_for_Alloc
FROM #CR_Attritional_for_Alloc_1


-----------------------------------------------------clash------------------
CREATE CLUSTERED INDEX [CIX_Reserving_data_RDkey] ON #Reserving_data (RDKey)



DROP TABLE IF EXISTS #Clash_IBNR_all

select TriFocusName,YOA,CCY, 
CONVERT(DECIMAL(38,8),[ClashIBNR]) as ClashIBNR,
Period,TrifocusCode,EntitySet ,
cast(Period as varchar)+'|'+cast(yoa as varchar)+'|'+TrifocusCode+'|'+CCY+'|'+EntitySet as ClashKey,'XL' as RIPolicyType,'Systemic cover - Clash' as ProgrammeCode 

INTO #Clash_IBNR_all
from 

(
select TriFocusName,YOA,CCY,[ClashIBNR],Period,TrifocusCode,EntitySet
from MDS.[ClashIBNR2022prior] 

union
select sl.TriFocusName,YOA,CCY,[ClashIBNR],Period,TrifocusCode,isnull(EntitySet,sl.Synd) as EntitySet--change

from ADMRI.SlUltimatesCurrentQuarter sl join FinanceLanding.fdm.DimTrifocus df on sl.TriFocusName=df.TrifocusName
left join #EntitySet e on sl.Synd=e.Entity
) a 
where a.[ClashIBNR] >= 0.001 or a.[ClashIBNR] <= -0.001--Change

CREATE INDEX [IX_Clash_IBNR_all_Period] ON #Clash_IBNR_all (Period)


DROP TABLE IF EXISTS #Clash_IBNR_RDPeriod_1

select Period, YOA,TrifocusCode,CCY,TriFocusName,RIPolicyType,ProgrammeCode,ClashKey,[ClashIBNR],EntitySet
--,isnull(RDPeriod,Period) as RDPeriod
,case when Period=202003 then 202003
   when right(Period,2) in (03,09) then Period+2
   else Period end as RDperiod
INTO #Clash_IBNR_RDPeriod_1

from #Clash_IBNR_all CI 
--left join #CR_RD_Periods_Clash rcp 
--left join [ADMRI].[PERIODS_CLASH] rcp
--on ci.Period=rcp.ClashPeriod

DROP TABLE IF EXISTS #clash_RD_RI_Split 

select RDKEy,id as RDid,Synd as RDSynd,Office_Location as RDOffice,RDPercent
INTO #clash_RD_RI_Split 
from #Reserving_data

CREATE CLUSTERED INDEX [CIX_clash_RD_RI_Split_RDKey] ON #clash_RD_RI_Split (rdkey)

DROP TABLE IF EXISTS #Clash_IBNR_RDPeriod

select *,isnull(cast(RDPeriod as varchar)+'|','')+isnull(cast(YOA as varchar)+'|','')+isnull(TrifocusCode+'|','')+isnull(ccy+'|','')+isnull(EntitySet,'') as RDKey
,case when (isnull(cast(RDPeriod as varchar)+'|','')+isnull(cast(YOA as varchar)+'|','')+isnull(TrifocusCode+'|','')+isnull(ccy+'|','')+isnull(EntitySet,'')) 
			in (select distinct rdkey from #clash_RD_RI_Split) then 'In RDUltimates' else 'Not in RDUltimates' end as InRDUltimates
INTO #Clash_IBNR_RDPeriod
from #Clash_IBNR_RDPeriod_1

CREATE CLUSTERED INDEX [CIX_Clash_IBNR_RDPeriod_RDKey] ON #Clash_IBNR_RDPeriod (rdkey)


-----------------------------Calculated RI Attritional IBNR----------------------

DROP TABLE IF EXISTS #Clash_IBNR
select RDid, case when RDPercent is null then [ClashIBNR] else [ClashIBNR]*RDPercent end as Value
INTO #Clash_IBNR
from #Clash_IBNR_RDPeriod cir left join #clash_RD_RI_Split crrs on cir.RDKey=crrs.RDKEy
WHERE InRDUltimates= 'In RDUltimates'


CREATE CLUSTERED INDEX [CIX_Clash_IBNR_RDID] ON #Clash_IBNR (RDID)

DROP TABLE IF EXISTS #Reserving_data_RI

;with CR_Incurred_Attritional_Summary as(
select RDId,sum(value) as Value
from #CR_Attritional_Prog
where InRDUltimates= 'In RD Ultimates' and Special='Not Special'
group by RDId)

SELECT id,
       asat,
       RDKEy,
       yoa,
       triangle_group,
       department,
       ccy,
       Synd,
       special,
       Office_Location,
       TrifocusCode,
       EntitySet,
       rd.value as UltimateValue,
       [6107QS_Adjustment],
       AdjustedValue,
       Include,
       gross_ri,
       case
           when Ias.RDId is not null then
               'In Incurred'
           else
               'Not in Incurred'
       end as [In Incurred],
       case
           when (case
                     when Ias.RDId is not null then
                         'In Incurred'
                     else
                         'Not in Incurred'
                 end
                ) = 'In Incurred' then
               ias.Value
           else
               0
       end as IncurredValue,
       AdjustedValue - (case
                            when (case
                                      when Ias.RDId is not null then
                                          'In Incurred'
                                      else
                                          'Not in Incurred'
                                  end
                                 ) = 'In Incurred' then
                                ias.Value
                            else
                                0
                        end
                       ) as [RI IBNR(Adj-Incurred)],
       case
           when cib.RDid is not null then
               'In Clash'
           else
               'Not in Clash'
       end as InClash,
       case
           when (case
                     when cib.RDid is not null then
                         'In Clash'
                     else
                         'Not in Clash'
                 end
                ) = 'In Clash' then
               cib.Value
           else
               0
       end as ClashValue,
       (AdjustedValue - (case
                             when (case
                                       when Ias.RDId is not null then
                                           'In Incurred'
                                       else
                                           'Not in Incurred'
                                   end
                                  ) = 'In Incurred' then
                                 ias.Value
                             else
                                 0
                         end
                        )
       ) - (case
                when (case
                          when cib.RDid is not null then
                              'In Clash'
                          else
                              'Not in Clash'
                      end
                     ) = 'In Clash' then
                    cib.Value
                else
                    0
            end
           ) RI_IBNR_NoClash,
       (AdjustedValue - (case
                             when (case
                                       when Ias.RDId is not null then
                                           'In Incurred'
                                       else
                                           'Not in Incurred'
                                   end
                                  ) = 'In Incurred' then
                                 ias.Value
                             else
                                 0
                         end
                        )
       ) - (case
                when (case
                          when cib.RDid is not null then
                              'In Clash'
                          else
                              'Not in Clash'
                      end
                     ) = 'In Clash' then
                    cib.Value
                else
                    0
            end
           ) as RI_IBNR_ToAlloc
INTO #Reserving_data_RI
FROM #Reserving_data rd
    left join CR_Incurred_Attritional_Summary Ias
        on rd.id = Ias.rdid
    left join #Clash_IBNR cib
        on rd.id = cib.RDid
where AdjustedValue <> 0


Drop table if exists #RI_IBNR_Unallocated;
DROP TABLE IF EXISTS #RI_IBNR_Unallocated_1

select id,asat,RDKEy,yoa,triangle_group,department,ccy,Synd,special,Office_Location,TrifocusCode,EntitySet,RI_IBNR_ToAlloc,[Open/Closed]
 ,cast(asat as varchar(100))+cast(yoa as varchar(100))+TrifocusCode as LookupForOverride
 INTO #RI_IBNR_Unallocated_1
 from admri.RIIBNRToAlloc
 where Unallocated='Unallocated'
 
 ;WITH RI_IBNR_Unallocated_2 as(
 select riu.*
 ,isnull(AO.TrifocusCodeOverride,RIU.TrifocusCode) as TrifocusOverride
 ,isnull(Ao.asatOverride,riu.asat) as asatOverride
 from #RI_IBNR_Unallocated_1 RIU 
 left join ADMRI.AllocOverrides AO on riu.LookupForOverride=AO.Lookup)
 
 ,RI_IBNR_Unallocated_3 as(
		 select *
		 ,isnull(cast(asatOverride as varchar)+'|','')+isnull(cast(yoa as varchar)+'|','')+isnull(TrifocusOverride+'|','')+isnull(ccy+'|','')+isnull(EntitySet,'') as RDKeyOverride
		 ,isnull(cast(asatOverride as varchar)+'|','')+isnull(cast(yoa as varchar)+'|','')+isnull(TrifocusOverride+'|','')+isnull(ccy+'|','')+isnull(EntitySet+'|','')+isnull(cast(Synd as varchar),'') as KeyForUnallocated
		 from RI_IBNR_Unallocated_2)
 ,RI_IBNR_Unallocated_4 as(
 select ri3.*
 ,case when KeyForUnallocated in (select   KeyForUnallocated from admri.CRAttritionalAlloc) then 'In attritional' else 'Not in Attritional' end as [In Attritional] 
 ,case when RDKeyOverride in (select  RDKey from admri.CRAttritionalAlloc) then 'In attritional' else 'Not in Attritional' end as [In Attritional_NoSynd] 
 ,case when KeyForUnallocated in (select  KeyForUnallocated from admri.CRClosedYOAAlloc) then 'In ClosedYOA' else 'Not in ClosedYOA' end as [In ClosedYOA] 
  ,case when RDKeyOverride in (select  RDKey from admri.CRClosedYOAAlloc) then 'In ClosedYOA' else 'Not in ClosedYOA' end as [In ClosedYOA_NoSynd] 
  ,case when KeyForUnallocated in (select  KeyForUnallocated from admri.CRRIPremiumAlloc) then 'In RIPremium' else 'Not in RIPremium' end as [In RIPremium] 
  ,case when RDKeyOverride in (select  RDKey from ADMRI.CRRIPremiumAlloc) then 'In RIPremium' else 'Not in RIPremium' end as [In RIPremium_NoSynd] 
  ,case when id in (select RDid from ADMRI.ManualSource) then 'In ManualSource' else 'Not in ManualSource' end as [In ManualSource] 
  ,case when KeyForUnallocated in (select KeyForUnallocated from MDS.CRClosedYOASpecial) then 'In ClosedYOASpecial' else 'Not in ClosedYOASpecial' end as [In closedYOASpecial] 
  ,case when KeyForUnallocated in (select  KeyForUnallocated from admri.CRRIPremiumClashProfs) then 'In RIPremiumCP' else 'Not in RIPremiumCP' end as [In RIPremiumCP]
   ,case when KeyForUnallocated in (select keyforunallocated from admri.CRRIPremiumClashProfs) then 'In InClosedYOACP' else 'Not in InClosedYOACP' end as [In ClosedYOACP] 
 
 from RI_IBNR_Unallocated_3 RI3
 )

 ,RI_IBNR_Unallocated_5 as(
 select ri4.*  
 ,case when [In Attritional]='In Attritional' or [In Attritional_NoSynd] = 'In Attritional' or [In ClosedYOA]='In closedYOA' or [In ClosedYOA_NoSynd]='In ClosedYOA' or [In RIPremium]='In RIPremium'
 or [In RIPremium_NoSynd]='In RIPremium' or [In ManualSource]='In ManualSource' or [In closedYOASpecial]='In ClosedYOASpecial' or [In RIPremiumCP]='In RIPremiumCP' or [In ClosedYOACP]='In ClosedYOACP' then 'TRUE' else 'FALSE' 
 end as [In data]
 ,case when ir.id is not null then 'Invalid RD Record' else 'Valid' end as InValid_RD_Record 
 ,case when [In ClosedYOA] = 'In ClosedYOA' then KeyForUnallocated else 'Not Allocated' end as Rule_Unalloc_ClosedYOA
 from RI_IBNR_Unallocated_4 RI4 left join [MDS].[InvalidRDrecords] IR on ri4.id=ir.id)

 ,RI_IBNR_Unallocated_6 as(
 select *
 ,case when Rule_Unalloc_ClosedYOA='Not Allocated' then case when [In ClosedYOA_NoSynd]='In ClosedYOA' then RDKeyOverride else 'Not Allocated' end else 'Allocated' end as Rule_Unalloc_ClosedYOA_NoSynd
 from RI_IBNR_Unallocated_5)

 ,RI_IBNR_Unallocated_7 as(
 select *
 ,case when Rule_Unalloc_ClosedYOA_NoSynd='Not Allocated' then case when [In RIPremium]='In RIPremium' then KeyForUnallocated else 'Not Allocated' end else 'Allocated' end as Rule_Unalloc_RIPremium
 from RI_IBNR_Unallocated_6)

 ,RI_IBNR_Unallocated_8 as(
 select *
 ,case when Rule_Unalloc_RIPremium = 'Not Allocated' then case when [In RIPremium_NoSynd]='In RIPremium' then RDKeyOverride else 'Not Allocated' end else 'Allocated' end as Rule_Unalloc_RIPremium_NoSynd
 from RI_IBNR_Unallocated_7)

 ,RI_IBNR_Unallocated_9 as(
 select *
 ,case when Rule_Unalloc_RIPremium_NoSynd='Not Allocated' then case when [In Attritional]='In Attritional' then cast(id as varchar) else 'Not Allocated' end else 'Allocated' end as Rule_Unalloc_Attritional
 from RI_IBNR_Unallocated_8)

 ,RI_IBNR_Unallocated_10 as(
 select *
 ,case when Rule_Unalloc_Attritional='Not Allocated' then case when [In ManualSource]='In ManualSource' then cast(id as varchar) else 'Not Allocated' end else 'Allocated' end as Rule_Unalloc_ManualSource
 from RI_IBNR_Unallocated_9)

 ,RI_IBNR_Unallocated_11 as(
 select *
 ,case when Rule_Unalloc_ManualSource='Not Allocated' then case when [In closedYOASpecial]='In closedYOASpecial' then KeyForUnallocated else 'Not Allocated' end else 'Allocated' end as Rule_Unalloc_ClosedYOASpecial
 from RI_IBNR_Unallocated_10)

 select *
 ,case when Rule_Unalloc_ClosedYOASpecial='Not Allocated' then case when [In RIPremiumCP]='In RIPremiumCP' then KeyForUnallocated else 'Not Allocated' end else 'Allocated' end as Rule_Unalloc_RIPremiumCP
 into #RI_IBNR_Unallocated
 from RI_IBNR_Unallocated_11


 drop table if exists #Rule_Closed_Attritional;

 select 
	TA.id
	,asat
	,ta.RDKey
	,yoa
	,triangle_group
	,department
	,ccy
	,Synd,special
	,Office_Location
	,TrifocusCode
	,RI_IBNR_ToAlloc
	,RIPolicyType
	,ProgramCode
	,SPLIT
	,Allocatedvalue = RI_IBNR_ToAlloc*(SPLIT/100)  
 into #Rule_Closed_Attritional
 from [ADMRI].RIIBNRToAlloc ta 
 join [ADMRI].CRAttritionalAlloc fa on ta.Rule_Closed_Attritional=cast(fa.RDId as varchar) ----------------------------------------------
 where Rule_Closed_Attritional NOT IN ('Not Allocated','Allocated')
 

 drop table if exists #Rule_Closed_ClosedYOA;

 select 
	TA.id
	,asat
	,ta.RDKey
	,yoa
	,triangle_group
	,department
	,ccy
	,Synd
	,special
	,Office_Location
	,TrifocusCode
	,RI_IBNR_ToAlloc
	,RIPolicyType
	,ProgrammeCode
	,SPLIT
	,Allocatedvalue = RI_IBNR_ToAlloc*(SPLIT/100)  
 into #Rule_Closed_ClosedYOA
 from [ADMRI].RIIBNRToAlloc ta 
 join [ADMRI].CRClosedYOAAlloc fa on ta.Rule_Closed_ClosedYOA=cast(fa.RDId as varchar) ----------------------------------------------
 where Rule_Closed_ClosedYOA NOT IN ('Not Allocated','Allocated')
 

 drop table if exists #Rule_Closed_RIPremium;

 select 
	TA.id
	,asat
	,ta.RDKey
	,yoa
	,triangle_group
	,department
	,ccy
	,Synd
	,special
	,Office_Location
	,TrifocusCode
	,RI_IBNR_ToAlloc
	,RIPolicyType
	,ProgrammeCode
	,SPLIT
	,Allocatedvalue = RI_IBNR_ToAlloc*(SPLIT/100)  
 into #Rule_Closed_RIPremium
 from [ADMRI].RIIBNRToAlloc ta 
 join [ADMRI].CRRIPremiumAlloc fa on ta.Rule_Closed_RIPremium=cast(fa.RDId as varchar) ----------------------------------------
 where Rule_Closed_RIPremium NOT IN ('Not Allocated','Allocated')
 

drop table if exists #Rule_Closed_Attritional_CP;

 select 
	TA.id
	,asat
	,ta.RDKey
	,yoa
	,triangle_group
	,department
	,ccy
	,Synd
	,special
	,Office_Location
	,TrifocusCode
	,RI_IBNR_ToAlloc
	,RIPolicyType
	,ProgramCode
	,SPLIT
	,Allocatedvalue = RI_IBNR_ToAlloc*(SPLIT/100)  
 into #Rule_Closed_Attritional_CP
 from [ADMRI].RIIBNRToAlloc ta 
 join [ADMRI].CRAttritionalClashProfs fa on ta.Rule_Closed_Attritional_CP=cast(fa.RDId as varchar) ----------------------------------
 where Rule_Closed_Attritional_CP NOT IN ('Not Allocated','Allocated')
 

drop table if exists #Rule_Closed_ClosedYOA_CP;

select 
	TA.id
	,asat
	,ta.RDKey
	,yoa
	,triangle_group
	,department
	,ccy
	,Synd
	,special
	,Office_Location
	,TrifocusCode
	,RI_IBNR_ToAlloc
	,RIPolicyType
	,ProgrammeCode
	,SPLIT
	,Allocatedvalue = RI_IBNR_ToAlloc*(SPLIT/100)  
 into #Rule_Closed_ClosedYOA_CP
 from [ADMRI].RIIBNRToAlloc ta 
 join [ADMRI].CRClosedYOAClashProfs fa on ta.Rule_Closed_ClosedYOA_CP=cast(fa.RDId as varchar)------------------------------------------
 where Rule_Closed_ClosedYOA_CP NOT IN ('Not Allocated','Allocated')


 drop table if exists #Rule_Closed_RIPremium_CP;

select 
	TA.id
	,asat
	,ta.RDKey
	,yoa
	,triangle_group
	,department
	,ccy
	,Synd
	,special
	,Office_Location
	,TrifocusCode
	,RI_IBNR_ToAlloc
	,RIPolicyType
	,ProgrammeCode
	,SPLIT
	,Allocatedvalue = RI_IBNR_ToAlloc*(SPLIT/100)  
 into #Rule_Closed_RIPremium_CP
 from [ADMRI].RIIBNRToAlloc ta 
 join [ADMRI].CRRIPremiumClashProfs fa on ta.Rule_Closed_RIPremium_CP=cast(fa.RDId as varchar)--------------------------------------------
 where Rule_Closed_RIPremium_CP NOT IN ('Not Allocated','Allocated')

 drop table if exists #Rule_Open_RIPremium;

select 
	TA.id
	,asat
	,ta.RDKey
	,yoa
	,triangle_group
	,department
	,ccy
	,Synd
	,special
	,Office_Location
	,TrifocusCode
	,RI_IBNR_ToAlloc
	,RIPolicyType
	,ProgrammeCode
	,SPLIT
	,Allocatedvalue = RI_IBNR_ToAlloc*(SPLIT/100)  
 into #Rule_Open_RIPremium
 from [ADMRI].RIIBNRToAlloc ta 
 join [ADMRI].CRRIPremiumAlloc fa on ta.Rule_Open_RIPremium=cast(fa.RDId as varchar)----------------------------------
 where Rule_Open_RIPremium NOT IN ('Not Allocated','Allocated')

 drop table if exists #Rule_Open_ClosedYOA;

select 
	TA.id
	,asat
	,ta.RDKey
	,yoa
	,triangle_group
	,department
	,ccy
	,Synd
	,special
	,Office_Location
	,TrifocusCode
	,RI_IBNR_ToAlloc
	,RIPolicyType
	,ProgrammeCode
	,SPLIT
	,Allocatedvalue = RI_IBNR_ToAlloc*(SPLIT/100)  
 into #Rule_Open_ClosedYOA
 from [ADMRI].RIIBNRToAlloc ta 
 join [ADMRI].CRClosedYOAAlloc fa on ta.Rule_Open_ClosedYOA=cast(fa.RDId as varchar)-----------------------------------
 where Rule_Open_ClosedYOA NOT IN ('Not Allocated','Allocated')

 drop table if exists #Rule_Open_Attritional;

select 
	TA.id
	,asat
	,ta.RDKey
	,yoa
	,triangle_group
	,department
	,ccy
	,Synd
	,special
	,Office_Location
	,TrifocusCode
	,RI_IBNR_ToAlloc
	,RIPolicyType
	,ProgramCode
	,SPLIT
	,Allocatedvalue = RI_IBNR_ToAlloc*(SPLIT/100)  
 into #Rule_Open_Attritional
 from [ADMRI].RIIBNRToAlloc ta 
 join [ADMRI].CRAttritionalAlloc fa on ta.Rule_Open_Attritional=cast(fa.RDId as varchar)-------------------------------
 where Rule_Open_Attritional NOT IN ('Not Allocated','Allocated')

 drop table if exists #Rule_Open_ClosedYOASpecial;

select 
	TA.id
	,asat
	,ta.RDKey
	,yoa
	,triangle_group
	,department
	,ccy
	,Synd
	,special
	,Office_Location
	,TrifocusCode
	,RI_IBNR_ToAlloc
	,RIPolicyType
	,ProgrammeCode
	,SPLIT
	,Allocatedvalue = RI_IBNR_ToAlloc*SPLIT  
 into #Rule_Open_ClosedYOASpecial
 from [ADMRI].RIIBNRToAlloc ta 
 join  MDS.CRClosedYOASpecial fa on ta.Rule_Open_ClosedYOASpecial=cast(fa.RDId as varchar)---------------------------------------------
 where Rule_Open_ClosedYOASpecial NOT IN ('Not Allocated','Allocated')

 drop table if exists #Rule_Open_RIPremium_CP;

select 
	TA.id
	,asat
	,ta.RDKey
	,yoa
	,triangle_group
	,department
	,ccy
	,Synd
	,special
	,Office_Location
	,TrifocusCode
	,RI_IBNR_ToAlloc
	,RIPolicyType
	,ProgrammeCode
	,SPLIT
	,Allocatedvalue = RI_IBNR_ToAlloc*(SPLIT/100)  
 into #Rule_Open_RIPremium_CP
 from [ADMRI].RIIBNRToAlloc ta 
 join [ADMRI].CRRIPremiumClashProfs fa on ta.Rule_Open_RIPremium_CP=cast(fa.RDId as varchar)--------------------------------------------------------
 where Rule_Open_RIPremium_CP NOT IN ('Not Allocated','Allocated')

 drop table if exists #Rule_Open_ClosedYOA_CP;

select 
	TA.id
	,asat
	,ta.RDKey
	,yoa
	,triangle_group
	,department
	,ccy
	,Synd
	,special
	,Office_Location
	,TrifocusCode
	,RI_IBNR_ToAlloc
	,RIPolicyType
	,ProgrammeCode
	,SPLIT
	,Allocatedvalue = RI_IBNR_ToAlloc*(SPLIT/100)  
 into #Rule_Open_ClosedYOA_CP
 from [ADMRI].RIIBNRToAlloc ta
 join [ADMRI].CRClosedYOAClashProfs fa on ta.Rule_Open_ClosedYOA_CP=cast(fa.RDId as varchar)----------------------------------------------------------
 where Rule_Open_ClosedYOA_CP NOT IN ('Not Allocated','Allocated')

 drop table if exists #Rule_Open_Attritional_CP;

select 
	TA.id
	,asat
	,ta.RDKey
	,yoa
	,triangle_group
	,department
	,ccy
	,Synd
	,special
	,Office_Location
	,TrifocusCode
	,RI_IBNR_ToAlloc
	,RIPolicyType
	,ProgramCode
	,SPLIT
	,Allocatedvalue = RI_IBNR_ToAlloc*(SPLIT/100)  
 into #Rule_Open_Attritional_CP
 from [ADMRI].RIIBNRToAlloc ta 
 join [ADMRI].CRAttritionalClashProfs fa on ta.Rule_Open_Attritional_CP=cast(fa.RDId as varchar)------------------------------------------------------------------
 where Rule_Open_Attritional_CP NOT IN ('Not Allocated','Allocated')

DROP TABLE IF EXISTS #Rule_All_clash_Profs ;

select * 
into #Rule_All_clash_Profs 
from (
	select *
	from #Rule_Closed_Attritional_CP
	union all
	select *
	from #Rule_Closed_ClosedYOA_CP
	union all
	select *
	from #Rule_Closed_RIPremium_CP
	union all
	select *
	from #Rule_Open_RIPremium_CP
	union all
	select *
	from #Rule_Open_ClosedYOA_CP
	union all
	select *
	from #Rule_Open_Attritional_CP
) a

 drop table if exists #Rule_Unalloc_ClosedYOA;

select 
	TA.id
	,asat
	,ta.RDKey
	,yoa
	,triangle_group
	,department
	,ccy
	,Synd,special
	,Office_Location
	,TrifocusCode
	,RI_IBNR_ToAlloc
	,cu.RIPolicyType
	,cu.ProgrammeCode
	,cu.KeyForUnallocatedSplit
	,Allocatedvalue = RI_IBNR_ToAlloc*(cu.KeyForUnallocatedSplit/100)  
 into #Rule_Unalloc_ClosedYOA
 from #RI_IBNR_Unallocated ta 
 JOIN [ADMRI].CRClosedYOAAlloc CU ON ta.Rule_Unalloc_ClosedYOA = CU.KeyForUnallocated
 where Rule_Unalloc_ClosedYOA NOT IN ('Not Allocated','Allocated')

 drop table if exists #Rule_Unalloc_ClosedYOA_NoSynd;

select 
	TA.id
	,asat
	,ta.RDKey
	,yoa
	,triangle_group
	,department
	,ccy
	,Synd
	,special
	,Office_Location
	,TrifocusCode
	,RI_IBNR_ToAlloc
	,RIPolicyType
	,ProgrammeCode
	,RDKeySplit
	,Allocatedvalue = RI_IBNR_ToAlloc*(RDKeySplit/100)  
 into #Rule_Unalloc_ClosedYOA_NoSynd
 from #RI_IBNR_Unallocated ta 
 join [ADMRI].CRClosedYOAAlloc fa on ta.Rule_Unalloc_ClosedYOA_NoSynd=fa.RDKEY
 where Rule_Unalloc_ClosedYOA_NoSynd NOT IN ('Not Allocated','Allocated')
 

 drop table if exists #Rule_Unalloc_RIPremium ;

select 
	TA.id
	,asat
	,ta.RDKey
	,yoa
	,triangle_group
	,department
	,ccy
	,Synd
	,special
	,Office_Location
	,TrifocusCode
	,RI_IBNR_ToAlloc
	,RIPolicyType
	,ProgrammeCode
	,RDKeySplit
	,Allocatedvalue = RI_IBNR_ToAlloc*(KeyForUnallocatedSplit/100)  
 into #Rule_Unalloc_RIPremium
 from #RI_IBNR_Unallocated ta 
 join [ADMRI].CRRIPremiumAlloc fa on ta.Rule_Unalloc_RIPremium=fa.KeyForUnallocated
 where Rule_Unalloc_RIPremium NOT IN ('Not Allocated','Allocated')
 
drop table if exists #Rule_Unalloc_RIPremium_NoSynd;

select 
	TA.id
	,asat
	,ta.RDKey
	,yoa
	,triangle_group
	,department
	,ccy
	,Synd
	,special
	,Office_Location
	,TrifocusCode
	,RI_IBNR_ToAlloc
	,RIPolicyType
	,ProgrammeCode
	,RDKeySplit
	,Allocatedvalue = RI_IBNR_ToAlloc*(RDKeySplit/100)  
 into #Rule_Unalloc_RIPremium_NoSynd
 from #RI_IBNR_Unallocated ta 
 join [ADMRI].CRRIPremiumAlloc fa on ta.RDKeyOverride=fa.RDKey
 where Rule_Unalloc_RIPremium_NoSynd NOT IN ('Not Allocated','Allocated')
 
 drop table if exists #Rule_Unalloc_Attritional;

select 
	TA.id
	,asat
	,ta.RDKey
	,yoa
	,triangle_group
	,department
	,ccy
	,Synd
	,special
	,Office_Location
	,TrifocusCode
	,RI_IBNR_ToAlloc
	,RIPolicyType
	,ProgramCode
	,RDKeySplit
	,Allocatedvalue = RI_IBNR_ToAlloc*(RDKeySplit/100)  
 into #Rule_Unalloc_Attritional
 from #RI_IBNR_Unallocated ta 
 join [ADMRI].CRAttritionalAlloc fa on ta.RDKeyOverride=fa.RDKey
 where Rule_Unalloc_Attritional NOT IN ('Not Allocated','Allocated')
 
 drop table if exists #Rule_Unalloc_ManualSource;

select 
	TA.id
	,asat
	,ta.RDKey
	,yoa
	,triangle_group
	,department
	,ccy
	,Synd
	,special
	,Office_Location
	,TrifocusCode
	,RI_IBNR_ToAlloc
	,RIPolicyType
	,ProgrammeCode
	,ms.Split
	,Allocatedvalue = RI_IBNR_ToAlloc*(Split)  
 into #Rule_Unalloc_ManualSource
 from #RI_IBNR_Unallocated ta 
 join [ADMRI].ManualSource ms on ta.Rule_Unalloc_ManualSource=cast(ms.RDId as varchar)---------------------------------
 where Rule_Unalloc_ManualSource NOT IN ('Not Allocated','Allocated')
 
 drop table if exists #Rule_Unalloc_ClosedYOASpecial;

select 
	TA.id
	,asat
	,ta.RDKey
	,yoa
	,triangle_group
	,department
	,ccy
	,Synd
	,special
	,Office_Location
	,TrifocusCode
	,RI_IBNR_ToAlloc
	,RIPolicyType
	,ProgrammeCode
	,Split
	,Allocatedvalue = RI_IBNR_ToAlloc*Split  
 into #Rule_Unalloc_ClosedYOASpecial
 from #RI_IBNR_Unallocated ta 
 join MDS.CRClosedYOASpecial fa on ta.Rule_Unalloc_ClosedYOASpecial=cast(fa.RDId as varchar)--------------------------------------------
 where Rule_Unalloc_ClosedYOASpecial NOT IN ('Not Allocated','Allocated')
 

 drop table if exists #Rule_Unalloc_RIPremiumCP;

 select 
	TA.id
	,asat
	,ta.RDKey
	,yoa
	,triangle_group
	,department
	,ccy
	,Synd
	,special
	,Office_Location
	,TrifocusCode
	,RI_IBNR_ToAlloc
	,RIPolicyType
	,ProgrammeCode
	,Split
	,Allocatedvalue = RI_IBNR_ToAlloc*(Split/100)  
 into #Rule_Unalloc_RIPremiumCP
 from #RI_IBNR_Unallocated ta 
 join [ADMRI].CRRIPremiumClashProfs fa on ta.Rule_Unalloc_RIPremiumCP=fa.KeyForUnallocated
 where Rule_Unalloc_RIPremiumCP NOT IN ('Not Allocated','Allocated')
 

 --------------Allocated IBNR and Addbacks-------------------------
----------------------------------------------------

Drop table if exists #Merged_Allocations;

select * 
into #Merged_Allocations 
from(
		select 
			id
			,RIPolicyType
			,ProgrammeCode = ProgramCode
			,[Value] = Allocatedvalue
			,[Source] = 'Closed Attritional'  
		from #Rule_Closed_Attritional
		union 
		select 
			id
			,RIPolicyType
			,ProgrammeCode
			,[Value] = Allocatedvalue
			,[Source] = 'Closed_closedYOA' 
		from #Rule_Closed_ClosedYOA
		union 
		select 
			id
			,RIPolicyType
			,ProgrammeCode
			,[Value] = Allocatedvalue
			,[Source] = 'Closed_RIPremium' 
		from #Rule_Closed_RIPremium
		union 
		select 
			id
			,RIPolicyType
			,ProgrammeCode
			,[Value] = Allocatedvalue
			,[Source] = 'open_RIPremium'  
		from #Rule_Open_RIPremium
		union 
		select 
			id
			,RIPolicyType
			,ProgrammeCode
			,[Value] = Allocatedvalue
			,[Source] = 'Open_ClosedYOA' 
		from #Rule_Open_ClosedYOA
		union 
		select 
			id
			,RIPolicyType
			,ProgrammeCode = ProgramCode
			,[Value] = Allocatedvalue
			,[Source] = 'Open_Attritional'
		from #Rule_Open_Attritional
		union all
		select 
			id
			,RIPolicyType
			,ProgrammeCode
			,[Value] = Allocatedvalue
			,[Source] = 'Open_ClosedYOASpecial'
		from #Rule_Open_ClosedYOASpecial
		union 
		select 
			id
			,RIPolicyType
			,ProgrammeCode = ProgramCode
			,[Value] = Allocatedvalue
			,[Source] = 'Rule_All_clash_Profs'
		from #Rule_All_clash_Profs
		union 
		select 
			id
			,RIPolicyType
			,ProgrammeCode
			,[Value] = Allocatedvalue
			,[Source] = 'Unalloc_ClosedYOA'
		from #Rule_Unalloc_ClosedYOA--FAC
		union 
		select 
			id
			,RIPolicyType
			,ProgrammeCode
			,[Value] = Allocatedvalue
			,[Source] = 'Unalloc_ClosedYOA_NoSynd'
		from #Rule_Unalloc_ClosedYOA_NoSynd--FAC
		union 
		select 
			id
			,RIPolicyType
			,ProgrammeCode
			,[Value] = Allocatedvalue
			,[Source] = 'Unalloc_RIPremium'
		from #Rule_Unalloc_RIPremium
		union 
		select 
			id
			,RIPolicyType
			,ProgrammeCode = ProgrammeCode
			,[Value] = Allocatedvalue
			,[Source] = 'Unalloc_RIPremium_NoSynd'
		from #Rule_Unalloc_RIPremium_NoSynd
		union 
		select 
			id
			,RIPolicyType
			,ProgrammeCode = ProgramCode
			,[Value] = Allocatedvalue
			,[Source] = 'Unalloc_Attritional' 
		from #Rule_Unalloc_Attritional
		union 
		select 
			id
			,RIPolicyType
			,ProgrammeCode
			,[Value] = Allocatedvalue
			,[Source] = 'Unalloc_ManualSource'
		from #Rule_Unalloc_ManualSource
		union 
		select 
			id
			,RIPolicyType
			,ProgrammeCode
			,[Value] = Allocatedvalue
			,[Source] = 'Unalloc_ClosedYOASpecial'
		from #Rule_Unalloc_ClosedYOASpecial
		union 
		select 
			id
			,RIPolicyType
			,ProgrammeCode
			,[Value] = Allocatedvalue
			,[Source] = 'Unalloc_RIPremiumCP'
		from #Rule_Unalloc_RIPremiumCP
) a



DROP TABLE IF EXISTS #Clash_to_addback;

select 
	id = RDid
	,RIPolicyType = 'XL'
	,ProgrammeCode = 'Systemic Cover - Clash'
	,[Value]
	,[Source] = 'Clash Add Back'
into #Clash_to_addback
from #Clash_IBNR


DROP TABLE IF EXISTS #Incurred_Attritional_to_addback;

SELECT
	ID = RDId 
	,RIPolicyType
	,ProgramCode
	,[Value] = Sum(value)
	,[Source] = 'Incurred Attritional' 
INTO #Incurred_Attritional_to_addback
FROM #CR_Attritional_Prog
WHERE RDId IS NOT NULL 
AND RDId <> '' 
AND Special='Not Special'
group by 
	RDId
	,RIPolicyType
	,ProgramCode


Drop table if Exists #DQFix_6107_to_addback;

select 
	id
	,RIPolicyType = 'QS'
	,ProgrammeCode = 'Cede 6107' 
	,[Value] = [6107QS_Adjustment]
	,[Source] = 'DQFix_6107 Add Back' 
into #DQFix_6107_to_addback
from #Reserving_data
where [6107QS_Adjustment]<>0

drop table if exists #Merged_Ultimates;

select 
	id
	,RIPolicyType
	,ProgrammeCode
	,[Value] = round([Value],4)
	,Source--CHANGE  
into #Merged_Ultimates 
from (
	select 
		id
		,RIPolicyType
		,ProgrammeCode
		,[Value],[Source]
	from #Merged_Allocations
	union all
	select 
		id
		,RIPolicyType
		,ProgrammeCode
		,[Value]
		,[Source]
	from #Clash_to_addback
	union all
	select 
		id
		,RIPolicyType
		,ProgramCode as ProgrammeCode
		,[Value]
		,[Source]
	from #Incurred_Attritional_to_addback
	union all
	select 
		id
		,RIPolicyType
		,ProgrammeCode
		,[Value]
		,[Source]
	from #DQFix_6107_to_addback
) a
where a.id is not null and a.id<>''

--Not much needed For SQL----------------------------------------------------------------------------------------------
drop table if exists #Reserving_data_RI_to_Alloc;

select 
	ri.id
	,ri.asat
	,ri.RDKEy
	,ri.yoa
	,ri.triangle_group
	,department
	,ccy
	,Synd
	,special
	,Office_Location
	,TrifocusCode
	,UltimateValue
	,[6107QS_Adjustment]
	,AdjustedValue
	,IncurredValue
	,ClashValue
	,RI_IBNR_ToAlloc
	,Allocated_IBNR = isnull(ma.[Value],0) 
	,Calculated_Ultimate = isnull(mu.[Value],0)  
	,[Difference] = UltimateValue-isnull(mu.[Value],0)  
	,[Status] = case when (UltimateValue-isnull(mu.[Value],0))<0.0001 then 'Identical'
					 when isnull(ma.[Value],0)=0 then 'Not Allocated' else 'Different' end  
	,InValid = case when ir.id is not null then 'Not Valid' else 'Valid' end 
into #Reserving_data_RI_to_Alloc
from #Reserving_data_RI ri 
left join (select id,sum([Value]) as [Value] from #Merged_Allocations group by id) ma on ri.id=ma.id
left join (select id,sum([Value]) as [Value] from #Merged_Ultimates group by id) mu on ri.id=mu.id
left join [MDS].[InvalidRDrecords] ir on ri.id=ir.id


----------------------------Combined Ultimates----------------------------------


Drop table if exists #Calculated_Ultimates_Included;

select 
	id
	,RIPolicyType
	,ProgrammeCode
	,sum([Value]) as [Value]
into #Calculated_Ultimates_Included
from #Merged_Ultimates
where Value>=0.0001 or value <= -0.0001
group by 
	id
	,RIPolicyType
	,ProgrammeCode;


DROP TABLE IF EXISTS #Reserving_data_RI_Included;

select 
	id
	,department
	,triangle_group
	,yoa
	,gross_ri
	,ccy
	,[Value]
	,datasetname
	,att_Cat
	,special
	,Synd
	,asat
	,datasetgroup
	,Office_Location
	,[Include]
	,TrifocusCode
INTO #Reserving_data_RI_Included
from #Reserving_data
where Include='Include'


DROP TABLE IF EXISTS #RD_RI_Included_with_Progs;
SELECT 
	RDI.ID
	,department
	,triangle_group
	,yoa
	,gross_ri
	,CCY
	,datasetname
	,RDI.[Value] AS RD_VALUE
	,att_Cat
	,special
	,Synd
	,asat
	,datasetgroup
	,Office_Location
	,TrifocusCode
	,RIPolicyType
	,ProgrammeCode
	,isnull(CUI.[Value],RDI.Value) as [Value]
INTO #RD_RI_Included_with_Progs
FROM #Reserving_data_RI_Included RDI 
LEFT JOIN #Calculated_Ultimates_Included CUI
ON RDI.id=CUI.id
ORDER BY RDI.id

drop table if exists #RD_RI_All_with_Programmes ;

;with Programme_to_Add_Back 
as (
	SELECT 
		id
		,department
		,triangle_group
		,yoa
		,gross_ri
		,ccy
		,[Value]
		,datasetname
		,att_Cat
		,special
		,Synd
		,ASAT
		,datasetgroup
		,Office_Location
		,[To Add Back] AS PROGRAMMECODE
		,RIPOLICYTYPE = CASE WHEN [To Add Back] IN ('Berkshire Hathaway','Cede 6050','GEN RE QQS','MUNQQS','Cede 6107','Cede 5623', 'BESIQS', 'TTYBDC') THEN 'QS' 
							 WHEN [To Add Back] IN ('Professions','Whole Account Stop Loss') THEN 'XL'
						ELSE NULL END  
		,isnull(tc.trifocuscode,'Unknown') Trifocuscode
	FROM #Final_ReservingData FD LEFT JOIN FinanceLanding.fdm.DimTrifocus  TC ON fd.triangle_group_TF=TC.TrifocusName
	WHERE [To Add Back] IS NOT NULL AND [To Add Back] <>'' AND DOF<>'EXCLUDE')

--drop table if exists #RD_RI_All_with_Programmes 
select * 
into #RD_RI_All_with_Programmes 
from (
	select 
		id
		,department
		,triangle_group
		,yoa
		,gross_ri
		,ccy
		,datasetname
		,att_Cat
		,special
		,Synd
		,asat
		,datasetgroup
		,Office_Location
		,TrifocusCode
		,RIPolicyType
		,ProgrammeCode
		,[Value]
	from #RD_RI_Included_with_Progs
	union
	select 
		id
		,department
		,triangle_group
		,yoa
		,gross_ri
		,ccy
		,datasetname
		,att_Cat
		,special
		,Synd
		,asat
		,datasetgroup
		,Office_Location
		,TrifocusCode
		,RIPolicyType
		,ProgrammeCode
		,[Value]
	from Programme_to_Add_Back
) a

------------------------------------------RC-P-AC balances-------------------------
DROP TABLE IF EXISTS #RD_RI_ALL_WITH_PROGRAMMES_1;
with RD_RI_All_with_Programmes_1 
as (
	select 
		id
		,department
		,triangle_group
		,yoa
		,gross_ri
		,ccy
		,datasetname
		,att_Cat
		,special
		,Synd
		,asat
		,datasetgroup
		,Office_Location
		,TrifocusCode
		,RIPolicyType
		,ProgrammeCode
		,[Value]
		,Allocated = case when ProgrammeCode is null then 'Not Allocated' else 'Allocated' end 
		,Account = 'RC-P-AC'
		,ConformerdRIPolicyType = case when (case when ProgrammeCode is null then 'Not Allocated' else 'Allocated' end) = 'Not Allocated' then null
										when (ProgrammeCode='Life Facultative Spend' and RIPolicyType='QS') or (ProgrammeCode='PA Facultative Spend' and RIPolicyType='QS') then 'FAC' 
										when RIPolicyType in ('CLASH','IR','PROFS','RE','RPP','SL','XL','LOD','RAD') then 'XL' 
										when RIPolicyType in ('PPNL','QQ','QS','Surplus','UCT','CR') then 'QS'
										when RIPolicyType in ('FAC') then 'FAC'
										else RIPolicyType
								  end  
	from #RD_RI_All_with_Programmes
)
,RD_RI_All_with_Programmes_2 
as (
	select 
		id
		,department
		,triangle_group
		,yoa
		,gross_ri
		,ccy
		,datasetname
		,att_Cat
		,special
		,Synd
		,asat
		,datasetgroup
		,Office_Location
		,rrp.TrifocusCode
		,RIPolicyType
		,ProgrammeCode
		,[Value]
		,Account
		,Allocated
		,ConformerdRIPolicyType
		,FACProgramme = case when Allocated='Allocated' and ConformerdRIPolicyType='FAC' then (case when ProgrammeCode='FAC' then isnull(RIProgramme,'FAC') 
						else LTRIM(RTRIM(ProgrammeCode)) end )
						end  
	from RD_RI_All_with_Programmes_1 rrp 
	left join FinanceLanding.mds.FACPrgTrifocusMapping tm on rrp.TrifocusCode=tm.TrifocusCode
)
,RD_RI_All_with_Programmes_3 
as (
	select 
		*------------------------------------------------
		,ConformedProgrammeCode = case when Allocated='Not Allocated' then null
									   when FACProgramme is not null then FACProgramme
								  else ISNULL(ifrs17_programme_group,LTRIM(RTRIM(ProgrammeCode))) end  
	from RD_RI_All_with_Programmes_2 RRA2 left join Eurobase.rein_program_sequence RPS on RRA2.ProgrammeCode=RPS.rps_program_id
)
select 
	*--------------------------------------------------------------
	,Businesskey = isnull(ltrim(rtrim(department))+'|','')+isnull(ltrim(rtrim(triangle_group))+'|','')+isnull(cast(ltrim(rtrim(yoa)) as varchar)+'|','')+isnull(ltrim(rtrim(gross_ri))+'|','')+isnull(ltrim(rtrim(ccy))+'|','')
					+isnull(ltrim(rtrim(datasetname))+'|','')
					+isnull(ltrim(rtrim(att_Cat))+'|','')+isnull(ltrim(rtrim(special))+'|','')+isnull(cast(ltrim(rtrim(Synd)) as varchar)+'|','')
					+isnull(ltrim(rtrim(datasetgroup))+'|','')+isnull(ltrim(rtrim(Office_Location))+'|','')+isnull(ltrim(rtrim(ConformerdRIPolicyType))+'|','')+isnull(ltrim(rtrim(ConformedProgrammeCode)),'') 
	 ,OriginalCCY = ccy  
	 ,[Location] = case when Office_Location is null then '-'
					else Office_Location end  
	 ,DOF = case when asat=202003 then 202003
			when right(asat,2) in ('11','05') then asat-2
			else asat end  
INTO #RD_RI_ALL_WITH_PROGRAMMES_1
from RD_RI_All_with_Programmes_3

DROP TABLE IF EXISTS #OutboundReservingData;

;With OutboundReservingData_1 
as (
	SELECT 
		YOA
		,CCY as SettlementCCY
		,SYND as Entity
		,ASAT
		,TrifocusCode
		,sum(Value) as Value
		,Allocated
		,Account
		,ConformerdRIPolicyType as RIPolicyType
		,ConformedProgrammeCode as ProgrammeCode
		,Businesskey
		,OriginalCCY
		,Location
		,DOF
		,Null as Pk_Transaction
		,'F' as Scenario
		,'ResDataRIAttClmAlloc' as DataSet
		,'NOPOLICY' as PolicyNumber
		,cast('01/01/1980' as date) as InceptionDate
		,cast('01/01/1980' as date) as ExpiryDate
		,cast('01/01/1980' as date) as BindDate
		,cast('01/01/1980' as date) as DueDate
		,'-' as TypeOfBusiness
		,Null as StatsCode
		,'Y' as IsToDate
		,Null as RowHash
		,Null as FK_Allocation
		,null as AuditSourceBatchID
		,Null as AuditCreateDateTime
		,Null as AuditGenerateDateTime
		,Null as AuditUserCreate
		,Null as AuditHost
		,'E' as Basis
		,'T1' as BusinessProcessCode
		,Null as FK_Batch
		,Null as BoundDate
	FROM #RD_RI_ALL_WITH_PROGRAMMES_1
	WHERE Allocated='ALLOCATED' 
	AND asat>=201811
	group by YOA
		,CCY 
		,SYND 
		,ASAT
		,TrifocusCode
		,Allocated
		,Account
		,ConformerdRIPolicyType 
		,ConformedProgrammeCode 
		,Businesskey
		,OriginalCCY
		,Location
		,DOF
)
select 
	Dof
	,asat
	,pk_transaction
	,Scenario
	,Account
	,DataSet
	,BusinessKey
	,PolicyNumber
	,InceptionDate
	,ExpiryDate
	,BindDate
	,DueDate
	,Trifocuscode
	,Entity
	,YOA
	,TypeOfBusiness
	,StatsCode
	,SettlementCCY
	,OriginalCCY
	,IsToDate
	,sum(Value) as value
	,RowHash
	,Fk_Allocation
	,AuditSourceBatchID
	,AuditCreateDatetime
	,AuditGenerateDatetime
	,AuditUserCreate
	,AuditHost
	,Basis
	,Location
	,BusinessProcessCode
	,Fk_Batch
	,BoundDate
	,RIPolicyType
	,ProgrammeCode
INTO #OutboundReservingData
from OutboundReservingData_1
where [Value] >= 0.0001 or [Value] <= -0.0001 or [Value]<>0
group  by 
	asat
	,PK_Transaction  
	,Scenario
	,Account 
	,Dataset
	,BusinessKey 
	,PolicyNumber
	,InceptionDate
	,ExpiryDate 
	,BindDate 
	,DueDate 
	,TrifocusCode 
	,Entity 
	,YOA 
	,TypeOfBusiness
	,StatsCode 
	,SettlementCCY
	,OriginalCCY 
	,IsToDate 
	,RowHash
	,FK_Allocation
	,AuditSourceBatchID 
	,AuditCreateDateTime 
	,AuditGenerateDateTime 
	,AuditUserCreate
	,AuditHost 
	,Basis 
	,Location 
	,BusinessProcessCode
	,FK_Batch 
	,BoundDate 
	,RIPolicyType 
	,ProgrammeCode
	,DOF

IF EXISTS(SELECT TOP 1 * FROM FINANCELANDING.[ADMRI].[MergedUltimates])
BEGIN
TRUNCATE TABLE FINANCELANDING.[ADMRI].[MergedUltimates]
END

Insert into [ADMRI].[MergedUltimates](RDId,RIPolicyType,ProgrammeCode,[value],[Source])
select Id,
RIPolicyType,
ProgrammeCode,
Value,
Source
from #Merged_Ultimates


IF EXISTS(SELECT TOP 1 * FROM FINANCELANDING.ADMRI.ResDataAttClmAlloc_Landing)
BEGIN
TRUNCATE TABLE FINANCELANDING.ADMRI.ResDataAttClmAlloc_Landing;
END

Insert into ADMRI.ResDataAttClmAlloc_Landing(
[Dof]						
	,[asat]						
	,[Scenario]					
	,[Account]					
	,[DataSet]					
	,[BusinessKey]				
	,[PolicyNumber]				
	,[InceptionDate]				
	,[ExpiryDate]				
	,[BindDate]					
	,[DueDate]					
	,[Trifocuscode]				
	,[Entity]					
	,[YOA]						
	,[TypeOfBusiness]			
	,[StatsCode]					
	,[SettlementCCY]				
	,[OriginalCCY]				
	,[IsToDate]					
	,[value]						
	,[RowHash]					
	,[Fk_Allocation]				
	,[AuditSourceBatchID]				
	,[AuditHost]					
	,[Basis]						
	,[Location]					
	,[BusinessProcessCode]		
	,[Fk_Batch]					
	,[BoundDate]					
	,[RIPolicyType]				
	,[ProgrammeCode]	
)
select 
CONVERT(DATETIME,CAST([Dof] AS VARCHAR(10))+'01',112)						
	,[asat]						
	,[Scenario]					
	,[Account]					
	,[DataSet]					
	,[BusinessKey]				
	,[PolicyNumber]				
	,[InceptionDate]				
	,[ExpiryDate]				
	,[BindDate]					
	,[DueDate]					
	,[Trifocuscode]				
	,CAST([Entity] AS nvarchar(25))
	,CAST([YOA]	AS nvarchar(25))					
	,[TypeOfBusiness]			
	,CAST([StatsCode] AS NVARCHAR(50))					
	,[SettlementCCY]				
	,[OriginalCCY]				
	,[IsToDate]					
	,[value]						
	,[RowHash]					
	,[Fk_Allocation]				
	,[AuditSourceBatchID]		
	--,[AuditCreateDatetime]		
	--,[AuditGenerateDatetime]		
	--,[AuditUserCreate]			
	,[AuditHost]					
	,[Basis]						
	,[Location]					
	,[BusinessProcessCode]		
	,[Fk_Batch]					
	,CONVERT(DATETIME,CAST([BoundDate] AS VARCHAR(10)),112)										
	,[RIPolicyType]				
	,[ProgrammeCode]	
from #OutboundReservingData 


end
