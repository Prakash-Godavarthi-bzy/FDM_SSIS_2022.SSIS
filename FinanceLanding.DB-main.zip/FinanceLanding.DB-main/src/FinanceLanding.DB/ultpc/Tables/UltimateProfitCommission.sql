﻿CREATE TABLE [ultpc].[UltimateProfitCommission](
[IFRS17_Programme Group] [varchar](255) NULL,
[Reinsurance policy reference] [varchar](50) NULL,
[Year] [bigint] NULL,
[Focus Area] [varchar](255) NULL,
[Currency] [varchar](50) NULL,
[Value] [numeric](19, 4) NULL,
[Date Of Fact] [datetime] NULL, 
[Entity] [varchar](25) NULL
) 