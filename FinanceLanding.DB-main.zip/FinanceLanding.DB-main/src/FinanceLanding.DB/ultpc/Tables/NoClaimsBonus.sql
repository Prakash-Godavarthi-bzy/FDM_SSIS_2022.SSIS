﻿CREATE TABLE [Ultpc].[NoClaimsBonus] (
    [Id]                         INT             IDENTITY (1, 1) NOT NULL,
    [Dept]                       VARCHAR (50)    NULL,
    [IFRS17ProgrammeGroup]       VARCHAR (255)   NULL,
    [ReinsurancePolicyReference] VARCHAR (50)    NULL,
    [Year]                       BIGINT          NULL,
    [FocusArea]                  VARCHAR (255)   NULL,
    [Currency]                   VARCHAR (50)    NULL,
    [Value]                      NUMERIC (19, 4) NULL,
    [DateOfFact]                 DATETIME        NULL,
    [Entity]                     VARCHAR (50)    NULL,
    [AuditSSISExecutionID]       INT             NULL,
    [AuditSSISPackageName]       VARCHAR (255)   NULL,
    [AuditCreateDateTime]        DATETIME        CONSTRAINT [DF_ultpc_NoClaimsBonus_AuditCreateDateTime] DEFAULT (getutcdate()) NOT NULL,
    [AuditUserCreate]            VARCHAR (255)   CONSTRAINT [DF_ultpc_NoClaimsBonus_AuditUserCreate] DEFAULT (suser_sname()) NOT NULL,
    [AuditHost]                  VARCHAR (255)   CONSTRAINT [DF_ultpc_NoClaimsBonus_AuditHost] DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) NOT NULL,
    [Description]                VARCHAR (255)   NULL
);



