﻿CREATE   PROC [dbo].[usp_GenerateBatchID] @DataSet varchar(50), @ExecutionID INT, @PK_Batch INT OUTPUT
AS 
BEGIN 
	INSERT	[dbo].[Batch]([CreateDate],[DataSet], ExecutionID) 
	VALUES  (GETDATE(),@DataSet, @ExecutionID)
	
	SELECT @PK_Batch = SCOPE_IDENTITY()
END