﻿CREATE TABLE [dbo].[Batch] (
    [PK_Batch]          INT           IDENTITY (1, 1)	NOT NULL,
    [CreateDate]        DATETIME2 (0)					NOT NULL,
    [DataSet]			VARCHAR (50)					NULL,
    [LatestBusinesKey]  VARCHAR (200)					NULL,
	ExecutionID			INT,
    CONSTRAINT [PK_Batch] PRIMARY KEY CLUSTERED ([PK_Batch] ASC, [CreateDate] ASC) WITH (FILLFACTOR = 90)
);

