﻿
-- =============================================
-- Author:		Mark Baekdal
-- Create date: 18/08/2021
-- Description:	Creates a rowhash for transactions.

	-- To see those procedures that reference/use this function, right click the object and see references.

-- Example:
/*
		,RowHash = dbo.fn_RowHashForTransactions
		(
			'T' /* @RowHashType */
			,Scenario,Account,DataSet,BusinessKey,PolicyNumber,InceptionDate,ExpiryDate,BindDate,DueDate,TrifocusCode,Entity,YOA,TypeOfBusiness,StatsCode,SettlementCCY,OriginalCCY,IsToDate,Basis,[Location]
			,null /* @BusinessProcessCode */
			,null /* @BoundDate */
			-- extended columns
			,CONCAT
			(
				 case when special is null then '' else (special + '§~§') end
				,case when datasetname is null then '' else (datasetname + '§~§') end
				,case when datasetgroup is null then '' else (datasetgroup + '§~§') end
				,case when att_Cat is null then '' else (att_Cat + '§~§') end
			)
		)

		,[RowHash_Transaction_Reserving_ReInsurance_Extensions] = dbo.fn_RowHashForTransactions
		(
			'E' /* @RowHashType */
			,Scenario,Account,DataSet,BusinessKey,PolicyNumber,InceptionDate,ExpiryDate,BindDate,DueDate,TrifocusCode,Entity,YOA,TypeOfBusiness,StatsCode,SettlementCCY,OriginalCCY,IsToDate,Basis,[Location]
			,null /* @BusinessProcessCode */
			,null /* @BoundDate */
			-- extended columns
			,CONCAT
			(
				 case when special is null then '' else (special + '§~§') end
				,case when datasetname is null then '' else (datasetname + '§~§') end
				,case when datasetgroup is null then '' else (datasetgroup + '§~§') end
				,case when att_Cat is null then '' else (att_Cat + '§~§') end
			)
		)

*/
-- =============================================

CREATE FUNCTION [dbo].[fn_RowHashForTransactions]
(
	-- @RowHashType can be T for Transaction or E for extended columns.
	-- T will return all the inputs hashed, E will only hash the extensions.
	 @RowHashType char(1) 

	 -- The following are columns that collate to the columns in the [FinanceDataContract].Inbound/Outbound.Transaction table.
	 -- The data types are larger and are unicode to cater for most any future changes.

	,@Scenario nvarchar(2000) 
	,@Account nvarchar(2000) 
	,@DataSet nvarchar(2000) 
	,@BusinessKey nvarchar(2000) 
	,@PolicyNumber nvarchar(2000) 
	,@InceptionDate date 
	,@ExpiryDate date 
	,@BindDate date 
	,@DueDate date 
	,@TrifocusCode nvarchar(2000) 
	,@Entity nvarchar(2000) 
	,@YOA nvarchar(2000) 
	,@TypeOfBusiness nvarchar(2000) 
	,@StatsCode nvarchar(2000) 
	,@SettlementCCY nvarchar(2000) 
	,@OriginalCCY nvarchar(2000) 
	,@IsToDate nvarchar(2000) 
	,@Basis nvarchar(2000) 
	,@Location nvarchar(2000) 
	,@BusinessProcessCode nvarchar(2000)
	,@BoundDate date

	-- extensions. These are a concatenated string combining all the extension columns which are variable in number, so this is a generic way of handling them.
	-- Set this to null if there are no extensions.
	,@extensions nvarchar(max) 
)
RETURNS varbinary(255)
AS
BEGIN

	declare @input nvarchar(max)

	if @RowHashType = 'T'
	begin
		set @input = CONCAT
		(
			 case when @Scenario is null then '' else (ltrim(rtrim(@Scenario)) + '§~§') end
			,case when @Account is null then '' else (ltrim(rtrim(@Account)) + '§~§') end
			,case when @DataSet is null then '' else (ltrim(rtrim(@DataSet)) + '§~§') end
			,case when @BusinessKey is null then '' else (ltrim(rtrim(@BusinessKey)) + '§~§') end
			,case when @PolicyNumber is null then '' else (ltrim(rtrim(@PolicyNumber)) + '§~§') end
			,case when @InceptionDate is null then '' else (CONVERT(VARCHAR(10),@InceptionDate,102) + '§~§') end
			,case when @ExpiryDate is null then '' else (CONVERT(VARCHAR(10),@ExpiryDate,102) + '§~§') end
			,case when @BindDate is null then '' else (CONVERT(VARCHAR(10),@BindDate,102) + '§~§') end
			,case when @DueDate is null then '' else (CONVERT(VARCHAR(10),@DueDate,102) + '§~§') end
			,case when @TrifocusCode is null then '' else (ltrim(rtrim(@TrifocusCode)) + '§~§') end
			,case when @Entity is null then '' else (ltrim(rtrim(@Entity)) + '§~§') end
			,case when @YOA is null then '' else (ltrim(rtrim(@YOA)) + '§~§') end
			,case when @TypeOfBusiness is null then '' else (ltrim(rtrim(@TypeOfBusiness)) + '§~§') end
			,case when @StatsCode is null then '' else (ltrim(rtrim(@StatsCode)) + '§~§') end
			,case when @SettlementCCY is null then '' else (ltrim(rtrim(@SettlementCCY)) + '§~§') end
			,case when @OriginalCCY is null then '' else (ltrim(rtrim(@OriginalCCY)) + '§~§') end
			,case when @IsToDate is null then '' else (ltrim(rtrim(@IsToDate)) + '§~§') end
			,case when @Basis is null then '' else (ltrim(rtrim(@Basis)) + '§~§') end
			,case when @Location is null then '' else (ltrim(rtrim(@Location)) + '§~§') end
			,case when @BusinessProcessCode is null then '' else (ltrim(rtrim(@BusinessProcessCode)) + '§~§') end
			,case when @BoundDate is null then '' else (CONVERT(VARCHAR(10),@BoundDate,102) + '§~§') end
			-- extensions
			,case when @extensions is null then '' else ltrim(rtrim(@extensions)) end
		)
	end

	if @RowHashType = 'E'
	begin
		set @input = ltrim(rtrim(@extensions))
	end

	-- Return the result of the function
	RETURN HASHBYTES('SHA2_512',@input)

END
GO


