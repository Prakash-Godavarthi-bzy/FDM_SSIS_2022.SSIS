﻿CREATE SCHEMA [pft]
    AUTHORIZATION [dbo];











