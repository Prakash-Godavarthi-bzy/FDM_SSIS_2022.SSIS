﻿CREATE SCHEMA [MDS]
    AUTHORIZATION [dbo];

























