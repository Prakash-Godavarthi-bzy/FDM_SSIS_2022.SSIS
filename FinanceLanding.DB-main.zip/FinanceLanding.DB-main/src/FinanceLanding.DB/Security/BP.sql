﻿CREATE SCHEMA [BP]
    AUTHORIZATION [dbo];













