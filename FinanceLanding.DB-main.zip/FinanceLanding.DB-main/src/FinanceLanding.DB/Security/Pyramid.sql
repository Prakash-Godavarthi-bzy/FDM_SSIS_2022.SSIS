﻿CREATE SCHEMA [Pyramid]
    AUTHORIZATION [dbo];





















