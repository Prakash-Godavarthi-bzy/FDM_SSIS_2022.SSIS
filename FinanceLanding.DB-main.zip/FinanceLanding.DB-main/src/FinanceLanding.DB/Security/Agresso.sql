﻿CREATE SCHEMA [Agresso]
    AUTHORIZATION [dbo];



