﻿CREATE SCHEMA [SPA]
    AUTHORIZATION [dbo];

























