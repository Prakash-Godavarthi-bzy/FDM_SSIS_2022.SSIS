﻿CREATE SCHEMA [SLCyEX]
    AUTHORIZATION [dbo];













