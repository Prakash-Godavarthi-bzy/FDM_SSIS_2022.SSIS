﻿CREATE SCHEMA [pdrebsrc]
    AUTHORIZATION [dbo];
