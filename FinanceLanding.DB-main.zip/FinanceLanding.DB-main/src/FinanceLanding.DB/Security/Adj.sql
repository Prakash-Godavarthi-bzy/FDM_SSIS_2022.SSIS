﻿CREATE SCHEMA [Adj]
    AUTHORIZATION [dbo];













