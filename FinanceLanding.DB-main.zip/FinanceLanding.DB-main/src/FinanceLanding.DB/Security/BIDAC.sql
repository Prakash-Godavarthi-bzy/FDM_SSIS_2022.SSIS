﻿CREATE SCHEMA [BIDAC]
    AUTHORIZATION [dbo];





















