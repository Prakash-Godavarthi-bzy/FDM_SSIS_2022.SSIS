﻿CREATE SCHEMA [Ultpc]
    AUTHORIZATION [dbo];













