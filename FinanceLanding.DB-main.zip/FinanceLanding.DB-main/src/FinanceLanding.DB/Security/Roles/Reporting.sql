﻿CREATE ROLE [Reporting]
GO
