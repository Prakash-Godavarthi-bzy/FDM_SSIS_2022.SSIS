﻿CREATE SCHEMA [Eurobase]
    AUTHORIZATION [dbo];























