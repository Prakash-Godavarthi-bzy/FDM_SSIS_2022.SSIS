﻿CREATE SCHEMA [ultrebsrc]
    AUTHORIZATION [dbo];