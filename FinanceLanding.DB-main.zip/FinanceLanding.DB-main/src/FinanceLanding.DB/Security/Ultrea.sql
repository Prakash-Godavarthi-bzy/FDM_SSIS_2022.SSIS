﻿CREATE SCHEMA [Ultrea]
    AUTHORIZATION [dbo];













