﻿CREATE SCHEMA [BICIRI]
    AUTHORIZATION [dbo];













