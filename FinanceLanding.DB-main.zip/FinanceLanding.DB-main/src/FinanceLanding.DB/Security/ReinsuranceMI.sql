﻿CREATE SCHEMA [ReinsuranceMI]
    AUTHORIZATION [dbo];



















