﻿CREATE PROCEDURE [pft].[usp_LandingInboundWorkflow] 
--declare
             --@p_AccountingPeriod			INT 
			@p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL
			,@p_ReviewCycle varchar(10) 
AS

-- =============================================
-- Created by:			Srinivasa.Tummala@beazley.com	
-- Modification date:	11-10-2021
-- Changes:				Initial version.

-- =============================================	
	
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @YOA int = YEAR(GETDATE())-3-- we only get data >= this variable	
	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'PFT';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	--DECLARE @ContractType					CHAR(3)			= 'RRU'

	DECLARE @v_Dataset varchar(50)=@v_ActivityDatabase
	DECLARE @v_BatchId                   INT             = NULL;
	DECLARE @v_BatchId_Extensions INT;

BEGIN TRY

	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';


	Declare @AP varchar(6)
	select @AP=CASE  WHEN RIGHT(@p_ReviewCycle,2)='Q1' THEN CAST(CONCAT(LEFT(@p_ReviewCycle,4),'03') as varchar(6))
					 WHEN RIGHT(@p_ReviewCycle,2)='Q2' THEN CAST(CONCAT(LEFT(@p_ReviewCycle,4),'06') as varchar(6))
					 WHEN RIGHT(@p_ReviewCycle,2)='Q3' THEN CAST(CONCAT(LEFT(@p_ReviewCycle,4),'09') as varchar(6))
					WHEN RIGHT(@p_ReviewCycle,2)='Q4' THEN CAST(CONCAT(LEFT(@p_ReviewCycle,4),'12') as varchar(6))
								
		  	END
	
	--select * from dbo.Batch
--	SELECT @v_BatchId = MAX(PK_Batch) from dbo.Batch where DataSet=@v_Dataset;

--/* Insert a new batch for PFT*/
	INSERT INTO [dbo].[Batch]([CreateDate],[DataSet],[LatestBusinesKey]) 
	VALUES  (GETDATE(),@v_Dataset,@AP);

	set  @v_BatchId=SCOPE_IDENTITY();


	/* Log the start of the insert */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'Load data into Inbound.Transaction'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'Load data into Inbound.Transaction for PFT'
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

	declare @OpeningBalanceDate date = '31 December 2018' -- this is the date for the opening balance
	declare @OpeningBalanceCutOffYear int = year(@OpeningBalanceDate) + 1 --- 2019
	declare @OpeningBalanceAllocationPeriod int = year(@OpeningBalanceDate) * 100 + month(@OpeningBalanceDate) -- 201812
	--SET @p_AccountingPeriod = @OpeningBalanceAllocationPeriod
	--DECLARE @AccountingPeriod INT = (SELECT (YEAR(MAX(DateOfFact)) * 100 + MONTH(MAX(DateOfFact))) 
	--								   FROM    [pft].[PFT_SYND_WITH_CEDE])
	
	

	-- constants for constant values.
	declare 
		 @Scenario char(1)				= 'F' 
		,@Basis char(1)					= '-'
		,@DefaultDate date				= CAST('01-01-1980' as date)
		,@TypeOfBusiness char(1)		= 'N'
		,@Location char(1)				= '-'
		,@IsToDate char(1)				= 'Y'
		,@BusinessProcessCode char(2)	= null
		,@AuditHost varchar(255)		= CAST(SERVERPROPERTY('MachineName') as varchar(255))
		,@StatsCode varchar(25)			= null
		--,@DateOfFact date				= convert(date,convert(char(8),@AccountingPeriod * 100 + 15),112)
		


	DROP TABLE IF EXISTS #PFT;

	SELECT *
	INTO #PFT
	FROM
	(
		SELECT ExtractDate,
                     LTRIM(RTRIM(PremiumMonth)) AS PremiumMonth,
                     LTRIM(RTRIM(ReviewCycle)) AS ReviewCycle,					 
                     LTRIM(RTRIM(MoP)) AS MoP,
                     LTRIM(RTRIM(TriFocusCode)) AS TriFocusCode,
                     LTRIM(RTRIM(YOA)) AS YOA,
                     LTRIM(RTRIM(TranCurr)) AS TranCurr,
                     LTRIM(RTRIM(Entity)) AS Entity,
                     SUM(SyndPremiumGIC) AS SyndPremiumGIC,
                     SUM(SyndPremiumNIC) AS SyndPremiumNIC,
                     SUM(GGP) AS GGP
  FROM [pft].[PFT_SYND_WITH_CEDE]
  Where ReviewCycle=@p_ReviewCycle
  --WHERE RIGHT(ReviewCycle,1)*3+3 = PremiumMonth
  --AND RIGHT(ReviewCycle,1) IN (0,1,2,3)   
  GROUP BY ExtractDate,PremiumMonth,ReviewCycle,MoP,TriFocusCode,YOA,TranCurr,Entity 
  HAVING sum(CONVERT(DECIMAL(28,3),[GGP])) <> 0
	) AS t
		
	--SELECT * FROM #PFT
	DROP TABLE IF EXISTS #TempPFT;

	SELECT * INTO #TempPFT
	  FROM	
	(

	SELECT	Scenario = @Scenario			
				,Account				= CASE WHEN MoP = 'Binder' THEN 'P-GP-B' WHEN MoP = 'Policy' THEN 'P-GP-P' END

				,DataSet				= 'PFT'
				--,DateOfFact				= CAST(CONCAT(CONCAT(YOA, '-', PremiumMonth), '-', 15) AS DATE)
				,DateOfFact				=	CASE  WHEN RIGHT(ReviewCycle,2)='Q1' THEN CAST(CONCAT(CONCAT(LEFT(ReviewCycle,4),'-',03),'-',15) as date)
													WHEN RIGHT(ReviewCycle,2)='Q2' THEN CAST(CONCAT(CONCAT(LEFT(ReviewCycle,4),'-',06),'-',15) as date)
													WHEN RIGHT(ReviewCycle,2)='Q3' THEN CAST(CONCAT(CONCAT(LEFT(ReviewCycle,4),'-',09),'-',15) as date)
													WHEN RIGHT(ReviewCycle,2)='Q4' THEN CAST(CONCAT(CONCAT(LEFT(ReviewCycle,4),'-',12),'-',15) as date)
													ELSE CAST(CONCAT(CONCAT(RIGHT(ReviewCycle,4),'-',00),'-',15) AS DATE) 
											END
				--,BusinessKey			= CASE WHEN MoP = 'Binder' THEN 'Pk_Policy_Binder' WHEN MoP = 'Policy' THEN 'Pk_Policy_Non-Binder' END
							
				,PolicyNumber			= CASE WHEN MoP = 'Binder' THEN 'Pk_Policy_Binder' WHEN MoP = 'Policy' THEN 'Pk_Policy_Non-Binder' END
				,InceptionDate			= CAST(CONCAT(CONCAT(YOA, '-', PremiumMonth), '-', 15) AS DATE)
				,ExpiryDate				= CAST(DATEADD(yy, 1, CONCAT(CONCAT(YOA, '-', PremiumMonth), '-', 15)) AS DATE)
				,BindDate				= CAST('01/01/1980' AS DATETIME2)
				,DueDate				= CAST('01/01/1980' AS DATETIME2)
				,TriFocusCode
				,Entity					= CASE WHEN Entity = 'BIDE' THEN 'BIGE' ELSE Entity END
				,YOA
				,TypeOfBusiness = @TypeOfBusiness			
				,SettlementCCY			= TranCurr
				,OriginalCCY			= TranCurr
				,IsToDate = @IsToDate				
				,Value					= GGP
				,FK_Allocation			= -1
				,AuditSourceBatchID		= CAST(@v_BatchId AS VARCHAR (50))
				,AuditGenerateDateTime	= ExtractDate
				,AuditHost				= HOST_NAME()
		FROM	#PFT
		UNION ALL
		SELECT	Scenario = @Scenario				
				,Account				= CASE WHEN MoP = 'Binder' THEN 'P-AC-B' WHEN MoP = 'Policy' THEN 'P-AC-P' END
				,DataSet				= 'PFT'
				--,DateOfFact				= CAST(CONCAT(CONCAT(YOA, '-', PremiumMonth), '-', 15) AS DATE)
				,DateOfFact				=	CASE  WHEN RIGHT(ReviewCycle,2)='Q1' THEN CAST(CONCAT(CONCAT(LEFT(ReviewCycle,4),'-',03),'-',15) as date)
													WHEN RIGHT(ReviewCycle,2)='Q2' THEN CAST(CONCAT(CONCAT(LEFT(ReviewCycle,4),'-',06),'-',15) as date)
													WHEN RIGHT(ReviewCycle,2)='Q3' THEN CAST(CONCAT(CONCAT(LEFT(ReviewCycle,4),'-',09),'-',15) as date)
													WHEN RIGHT(ReviewCycle,2)='Q4' THEN CAST(CONCAT(CONCAT(LEFT(ReviewCycle,4),'-',12),'-',15) as date)
													ELSE CAST(CONCAT(CONCAT(RIGHT(ReviewCycle,4),'-',00),'-',15) AS DATE) 
											END
				--,BusinessKey			= CASE WHEN MoP = 'Binder' THEN 'Pk_Policy_Binder' WHEN MoP = 'Policy' THEN 'Pk_Policy_Non-Binder' END
				,PolicyNumber			= CASE WHEN MoP = 'Binder' THEN 'Pk_Policy_Binder' WHEN MoP = 'Policy' THEN 'Pk_Policy_Non-Binder' END
				,InceptionDate			= CAST(CONCAT(CONCAT(YOA, '-', PremiumMonth), '-', 15) AS DATE)
				,ExpiryDate				= CAST(DATEADD(yy, 1, CONCAT(CONCAT(YOA, '-', PremiumMonth), '-', 15)) AS DATE)
				,BindDate				= CAST('01/01/1980' AS DATETIME2)
				,DueDate				= CAST('01/01/1980' AS DATETIME2)
				,TriFocusCode
				,Entity					= CASE WHEN Entity = 'BIDE' THEN 'BIGE' ELSE Entity END
				,YOA
				,TypeOfBusiness = @TypeOfBusiness			
				,SettlementCCY			= TranCurr
				,OriginalCCY			= TranCurr
				,IsToDate = @IsToDate
				,Value					= [GGP] - [SyndPremiumGIC]
				,FK_Allocation			= -1
				,AuditSourceBatchID		= CAST(@v_BatchId AS VARCHAR (50))
				,AuditGenerateDateTime	= ExtractDate
				,AuditHost				= HOST_NAME()
		FROM	#PFT	
		) AS T
	--temporary table for the insert (willbe used to calculate RowHash values before pushing data in the IDC transaction table

	DECLARE @AccountingPeriod INT = (SELECT (YEAR(MAX(DateOfFact)) * 100 + MONTH(MAX(DateOfFact))) 
									   FROM    #TempPFT)

	DECLARE @DateOfFact date				= convert(date,convert(char(8),@AccountingPeriod * 100 + 15),112)

	
	DROP TABLE IF EXISTS #TempInboundTransaction;

    /* Insert the new records from PFT Database sources in the temp table */
	SELECT 
		DateOfFact,
		Account,
		BusinessKey,
		PolicyNumber ,
		InceptionDate,
		ExpiryDate ,
		TrifocusCode ,
		Entity,
		YOA,
		SettlementCCY,	
		
		[Value] = sum([Value]),
		RowHash = dbo.fn_RowHashForTransactions
		(
			'T'							-- <@RowHashType, char(1),>
			,null--@Scenario					--,<@Scenario, nvarchar(2000),>
			,null--[Account]					--,<@Account, nvarchar(2000),>
			,@v_Dataset					--,<@DataSet, nvarchar(2000),>
			,[BusinessKey]				--,<@BusinessKey, nvarchar(2000),>
			,null--[PolicyNumber]				--,<@PolicyNumber, nvarchar(2000),>
			,null--[InceptionDate]			--,<@InceptionDate, date,>
			,null--[ExpiryDate]				--,<@ExpiryDate, date,>
			,null--@DefaultDate				--,<@BindDate, date,>
			,null--@DefaultDate				--,<@DueDate, date,>
			,null--[TrifocusCode]				--,<@TrifocusCode, nvarchar(2000),>
			,null--[Entity]					--,<@Entity, nvarchar(2000),>
			,null--[YOA]						--,<@YOA, nvarchar(2000),>
			,null--@TypeOfBusiness			--,<@TypeOfBusiness, nvarchar(2000),>
			,null--@StatsCode					--,<@StatsCode, nvarchar(2000),>
			,null--[SettlementCCY]			--,<@SettlementCCY, nvarchar(2000),>
			,null--[OriginalCCY]				--,<@OriginalCCY, nvarchar(2000),>
			,null--@IsToDate					--,<@IsToDate, nvarchar(2000),>
			,null--@Basis						--,<@Basis, nvarchar(2000),>
			,null--@Location					--,<@Location, nvarchar(2000),>
			,null --@BusinessProcessCode		--,<@BusinessProcessCode, nvarchar(2000),>
			,null						--,<@BoundDate, date,>
			,null
			
		)
		INTO #TempInboundTransaction
FROM
	(
		SELECT 
			t.DateOfFact,
			t.Account,
			BusinessKey = ISNULL(Account, '-') + '|' +
					ISNULL(PolicyNumber, '-') + '|' +
					CONVERT(CHAR(8),ISNULL(InceptionDate, CAST('01/01/1980' AS DATETIME2)) ) +'|' +					
					ISNULL(TrifocusCode,'-') +'|'+
					ISNULL(Entity,'-') + '|' +
					ISNULL(CAST(YOA AS VARCHAR(50)),'-') + '|' +
					ISNULL(SettlementCCY,'-'),				
			PolicyNumber = t.PolicyNumber,
			InceptionDate =  t.InceptionDate ,
			ExpiryDate = t.ExpiryDate,
			TriFocusCode,
			t.Entity,
			t.YOA,
			SettlementCCY,
			OriginalCCY,
			(year(DateOfFact) * 100 + month(DateOfFact)) AS AccountingPeriod,
			--t.AccountingPeriod,
			--t.ProgrmmeCode,
			--t.RIPolicyType,
			t.[Value] 
		FROM #TempPFT t
		) src1
	WHERE 1 = 1
		--AND src1.AccountingPeriod = @p_AccountingPeriod
		-- debug code
		--and src1.BusinessKey = 'P-RP-P-TTY|CLASHBUDGET|2019|USD|2623|697'
	GROUP BY 
        DateOfFact,
		Account,
		BusinessKey,
		PolicyNumber ,
		InceptionDate  ,
		ExpiryDate  ,
		TrifocusCode ,
		Entity,
		YOA,
		SettlementCCY
		--AccountingPeriod
		--RIPolicyType,
		--ProgrmmeCode
		HAVING sum([Value]) <> 0

	SELECT   @v_AffectedRows			= @@ROWCOUNT;
	print convert(varchar,@v_AffectedRows) + ' records in #TempInboundTransaction for ' + convert(varchar,@AccountingPeriod)
		
				if object_id('tempdb..#Outbound') is not null drop table #Outbound
				select 
					t.*					
				into 
					#Outbound
				from 
					FinanceDataContract.Outbound.[Transaction] t					
				where 
					t.DataSet = @v_DataSet
					--AND t.DateOfFact = @DateOfFact

	-- now I need to do the Reversals.
	-- I get the data from the outbound grouped by the rowhash & check to see that we don't have a related inbound record. These are missing and need to be zero'ed for the current period.
	DROP TABLE IF EXISTS #TempOutboundTransaction;

	SELECT 
		 tot.Account             
		,tot.BusinessKey        
		,tot.PolicyNumber
		,tot.InceptionDate 
		,tot.ExpiryDate 
		,tot.TrifocusCode        
		,tot.Entity              
		,tot.YOA                 
		,tot.SettlementCCY       
		,[FK_Batch]          = MAX(tot.[FK_Batch])
		,[Value] = SUM(tot.[Value])
		,tot.RowHash		
	INTO 
		#TempOutboundTransaction 
	FROM        
		#Outbound tot
		left join #TempInboundTransaction tite on tot.BusinessKey = tite.BusinessKey
		--AND CAST(tot.Dataset AS DATE) = CAST(tite.DateOfFact AS DATE)
	WHERE
		tite.RowHash is null
		and tot.Dataset = @v_Dataset
		and exists(select top 1 1 from #TempInboundTransaction) -- if we have nothing for this period, we don't want to reverse all the data out. This is not likely to happen in production - but in dev & test.
	GROUP BY  
		 tot.Account             
		,tot.BusinessKey        
		,tot.PolicyNumber
		,tot.InceptionDate 
		,tot.ExpiryDate 
		,tot.TrifocusCode        
		,tot.Entity              
		,tot.YOA                 
		,tot.SettlementCCY       
		,tot.RowHash		
	HAVING
		SUM(tot.[Value]) <> 0


	SELECT   @v_AffectedRows			= @@ROWCOUNT;
	print convert(varchar,@v_AffectedRows) + ' records in #TempOutboundTransaction for ' + convert(varchar,@AccountingPeriod)
	
	---DROP TABLE #transactions_final_agg_cs

	if object_id('tempdb..#transactions_final_agg_cs') is not null drop table #transactions_final_agg_cs

				--return -- gets here in 
				-- create the rowhash for the extensions.
				select distinct
					t.Account,
					t.BusinessKey,
					t.PolicyNumber ,
					t.InceptionDate,
					t.ExpiryDate ,
					t.TrifocusCode ,
					t.Entity,
					t.YOA,
					t.SettlementCCY,
					[Value] = t.[Value],
					--t.RIPolicyType,
					--ProgrammeCode = t.ProgrmmeCode,
					t.RowHash,
					t.DateOfFact
		-- I've introduced [DeltaType] here to over-ride the default behaviour in [Inbound].[usp_InboundOutboundWorkflow]
		-- We could have multiple new records and we only want to mark the first one as new, 
		-- the rest need to be marked as adjustments.
					,[DeltaType] = case 
									when o.RowHash is null and t.DateOfFact = tm.DateOfFact then 'New'
									else 'Adjustment' 
									end

				into
					#transactions_final_agg_cs 
					FROM
					#TempInboundTransaction t
					-- to determine what the DeltaType is. It can be either New or Adjustment.
					-- if we've already got data in the outbound, then DeltaType=Adjustment
					left join #Outbound o on o.BusinessKey = t.BusinessKey
					-- get the first movement from the #transactions_final_agg - this will be our [DeltaType]=New record.
					join
					(
						select 
							BusinessKey--RowHash
							,[DateOfFact] = min([DateOfFact])
						from	
							#TempInboundTransaction
						group by BusinessKey
							--RowHash
					) tm
						on tm.BusinessKey = t.BusinessKey--tm.RowHash = t.RowHash
						--AND tm.DateOfFact  = t.DateOfFact

		---drop table #TempInboundTransaction
			------/* Delete the current lines from Inbound ... */

				DELETE 				
				FROM    [FinanceDataContract].[Inbound].[Transaction]					
				WHERE   [DataSet] = @v_DataSet
				
			
		if not exists(select top 1 1 from #transactions_final_agg_cs)
	begin

		print 'No data in #TempInboundTransaction, exiting as there is nothing to do.'

		-- LOG THE RESULT WITH SUCCESS
		SELECT @v_ActivityDateTime			= GETUTCDATE();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStop
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

		return

	end

			--IF @Trancount = 0 
			BEGIN TRAN;

				-- select * from [dbo].[Batch]
				--INSERT INTO [dbo].[Batch]
				--	([CreateDate],[DataSet],[LatestBusinesKey]) 
				--VALUES  
				--	(GETDATE(),@v_DataSet, NULL);


				--SELECT @v_BatchId = SCOPE_IDENTITY();
											

			/* We insert the rows from temp table in the system */

			INSERT INTO [FinanceDataContract].[Inbound].[Transaction] WITH(TABLOCK)
			(
				 [Scenario]
				,[Basis]
				,[Account]
				,[DataSet]
				,[DateOfFact]
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]
				,[DueDate]
				,[TrifocusCode]
				,[Entity]
				,[Location]
				,[YOA]
				,[TypeOfBusiness]
				,[SettlementCCY]
				,[OriginalCCY]
				,[IsToDate]
				,[Value]
				,[ValueOrig]
				,[RowHash]
				,[BusinessProcessCode]
				,[AuditSourceBatchID]
				,[AuditGenerateDateTime]
				,[StatsCode]
				,[FK_Batch]
				,[DeltaType]
			)		
			SELECT  
				 [Scenario]					= @Scenario
				,[Basis]					= @Basis
				,[Account]
				,[DataSet]					= @v_Dataset
				,[DateOfFact]				--= @DateOfFact
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]					= @DefaultDate
				,[DueDate]					= @DefaultDate
				,[TrifocusCode]
				,[Entity]
				,[Location]					= @Location
				,[YOA]
				,[TypeOfBusiness]			= @TypeOfBusiness
				,[SettlementCCY]
				,[OriginalCCY]				= [SettlementCCY]
				,[IsToDate]					= @IsToDate
				,[Value]
				,[ValueOrig]				= [Value]
				,[RowHash] 
				,[BusinessProcessCode]		= @BusinessProcessCode
				,[AuditSourceBatchID]		= CAST(@v_BatchId AS VARCHAR (50))                                                 
				,[AuditGenerateDateTime]	= GETUTCDATE()
				,[StatsCode]				= @StatsCode
				,[FK_Batch]					= @v_BatchId
				,[DeltaType]				
			FROM    
				#transactions_final_agg_cs

			UNION ALL

			SELECT  
				 [Scenario]					= @Scenario
				,[Basis]					= @Basis
				,[Account]
				,[DataSet]					= @v_Dataset
				,[DateOfFact]				= @DateOfFact
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]					= @DefaultDate
				,[DueDate]					= @DefaultDate
				,[TrifocusCode]
				,[Entity]
				,[Location]					= @Location
				,[YOA]
				,[TypeOfBusiness]			= @TypeOfBusiness
				,[SettlementCCY]
				,[OriginalCCY]				= [SettlementCCY]
				,[IsToDate]					= @IsToDate
				,[Value]					= 0 
				,[ValueOrig]				= 0
				--,[Value]
				--,[ValueOrig]				= [Value]
				,[RowHash] 
				,[BusinessProcessCode]		= @BusinessProcessCode
				,[AuditSourceBatchID]		= CAST(@v_BatchId AS VARCHAR (50))                                                 
				,[AuditGenerateDateTime]	= GETUTCDATE()
				,[StatsCode]				= @StatsCode
				,[FK_Batch]											
				,DeltaType					= 'Reversal'
			FROM    
				#TempOutboundTransaction

				--DROP TABLE #transactions_final_agg_cs
			SELECT   @v_AffectedRows			= @@ROWCOUNT;

	
			/* Add the batch to the queue */
				INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,RunDescription
								,[DataSet]
								,OriginalName
								,AuditSourceBatchID
								,AsAt
								)
				VALUES
								( @v_BatchId
								 ,'InBound'
								 ,NULL
								 ,@v_DataSet
								 ,NULL
								 ,NULL
								 ,@AP
								);
   	-- LOG THE RESULT WITH SUCCESS
			SELECT @v_ActivityDateTime			= GETUTCDATE();

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStop
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;
					
			IF @Trancount = 0 
				COMMIT;
				
		END TRY

		BEGIN CATCH
	
			-- CANCEL TRAN
			IF @Trancount = 0 AND @@TRANCOUNT <> 0 
				ROLLBACK;
			        
			-- LOG THE RESULT WITH ERROR

			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

		    THROW;

		END CATCH;

					
END