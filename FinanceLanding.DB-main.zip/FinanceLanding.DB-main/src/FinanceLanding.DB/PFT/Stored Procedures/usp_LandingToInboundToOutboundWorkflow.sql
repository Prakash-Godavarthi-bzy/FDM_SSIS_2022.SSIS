﻿
Create PROCEDURE [pft].[usp_LandingToInboundToOutboundWorkflow] 
--declare
             --@p_AccountingPeriod			INT 
			@p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL
AS

-- =============================================
-- Created by:			Srinivasa.Tummala@beazley.com	
-- Modification date:	11-10-2021
-- Changes:				Initial version.

-- =============================================	
	
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @YOA int = YEAR(GETDATE())-3-- we only get data >= this variable	
	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'PFT';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	--DECLARE @ContractType					CHAR(3)			= 'RRU'

	DECLARE @v_Dataset varchar(50)=@v_ActivityDatabase
	DECLARE @v_BatchId                   INT             = NULL;
	DECLARE @v_BatchId_Extensions INT;


	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';




	
Drop table if exists #temp_Reviewcycle;
 Create table #temp_Reviewcycle (Rowid int Identity(1,1) , ReviewCycle varchar(10), YearName int , QuaterName char(2))
 Insert Into #temp_Reviewcycle(ReviewCycle,YearName,QuaterName)
	select distinct ReviewCycle, cast(LEFT(Reviewcycle,4) as int),RIGHT(Reviewcycle,2) as QuaterName  from FinanceLanding.pft.PFT_SYND_WITH_CEDE --where ReviewCycle>=@ReviewCycle
		order by cast(LEFT(Reviewcycle,4) as int) asc,RIGHT(Reviewcycle,2)  asc

		--select * from #temp_Reviewcycle

	Declare @DefaultReviewCyscle varchar(10)
	select @DefaultReviewCyscle= CONCAT(cast(YearName as varchar(4)),QuaterName)  from #temp_Reviewcycle where Rowid=1;
	set @DefaultReviewCyscle= case when RIGHT(@DefaultReviewCyscle,2)='Q1' then REPLACE(@DefaultReviewCyscle,RIGHT(@DefaultReviewCyscle,2),'03')
								when RIGHT(@DefaultReviewCyscle,2)='Q2' then REPLACE(@DefaultReviewCyscle,RIGHT(@DefaultReviewCyscle,2),'06')
								when RIGHT(@DefaultReviewCyscle,2)='Q3' then REPLACE(@DefaultReviewCyscle,RIGHT(@DefaultReviewCyscle,2),'09')
								when RIGHT(@DefaultReviewCyscle,2)='Q4' then REPLACE(@DefaultReviewCyscle,RIGHT(@DefaultReviewCyscle,2),'12')
	                          End
	
		select @DefaultReviewCyscle
	

	DECLARE @DOF_OB varchar(6)

	Select @DOF_OB=CONVERT(varchar(6), DateAdd(QQ,1, MAX(DateOfFact)),112)  from FinanceDataContract.Outbound.[Transaction] where Dataset='PFT'
	Select @DOF_OB=ISNULL(@DOF_OB,@DefaultReviewCyscle)
		
		--select @DOF_OB

		Declare @ReviewCycle varchar(10)
		set @ReviewCycle= case when  RIGHT(@DOF_OB,2)='03' Then CONCAT(Left(@DOF_OB,4) ,'Q1') 
		            when  RIGHT(@DOF_OB,2)='06' Then CONCAT(Left(@DOF_OB,4) ,'Q2') 
					when  RIGHT(@DOF_OB,2)='09' Then CONCAT(Left(@DOF_OB,4) ,'Q3')
					when  RIGHT(@DOF_OB,2)='12' Then CONCAT(Left(@DOF_OB,4) ,'Q4')
					End

		--select @ReviewCycle

		drop table if exists #temp_ReviewCyclesToBeProcessed
	Select * into #temp_ReviewCyclesToBeProcessed from #temp_Reviewcycle where  ReviewCycle>=@ReviewCycle

	--select * from #temp_ReviewCyclesToBeProcessed

	Declare @Rowid int 
	select @Rowid= MIN(RowId) from #temp_ReviewCyclesToBeProcessed ;
	--select @Rowid
	Declare @cnt int 
	Select @cnt=COUNT(*) from #temp_Reviewcycle
	While (@Rowid<=@cnt)

	Begin 

	
	declare @AP varchar(10)
	select @AP=ReviewCycle from #temp_ReviewCyclesToBeProcessed where Rowid=@Rowid;

		SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'Load data into Inbound & Outbound for '+@AP +' Period'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'Load data into Inbound & Outbound Transaction for PFT '+ @AP +' Period'
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;
	

     exec [FinanceLanding].pft.[usp_LandingInboundWorkflow] NULL, NULL, @AP

	 exec FinanceDataContract.[Inbound].[usp_InboundOutboundWorkflow]

	set @Rowid=@Rowid+1;
	
		SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'Loaded data into Inbound & Outbound for '+@AP +' Period'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'Loaded data into Inbound & Outbound Transaction for PFT '+ @AP +' Period'
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;
	


	End
				
				
		
					
END
