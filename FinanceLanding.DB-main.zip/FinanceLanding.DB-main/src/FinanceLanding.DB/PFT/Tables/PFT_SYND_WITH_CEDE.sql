﻿CREATE TABLE [pft].[PFT_SYND_WITH_CEDE](
	[ExtractDate] DATETIME NULL,
	[PremiumMonth] [int] NOT NULL,
	[ReviewCycle] [varchar](255) NOT NULL,
	[MoP] [varchar](255) NOT NULL,
	[TriFocusCode] [varchar](255) NOT NULL,
	[YOA] [varchar](255) NOT NULL,
	[TranCurr] [varchar](255) NOT NULL,
	[Entity] [varchar](255) NOT NULL,
	[OfficeChannel] [varchar](255) NOT NULL,
	[SyndPremiumGIC] [numeric](18, 4) NOT NULL,
	[SyndPremiumNIC] [numeric](18, 4) NOT NULL,
	[GGP] [numeric](18, 4) NOT NULL
	);