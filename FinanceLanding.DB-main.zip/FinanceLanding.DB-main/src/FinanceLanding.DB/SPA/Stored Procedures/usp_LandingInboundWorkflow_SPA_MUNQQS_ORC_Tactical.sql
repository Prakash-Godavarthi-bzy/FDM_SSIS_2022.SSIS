﻿CREATE PROCEDURE [SPA].[usp_LandingInboundWorkflow_SPA_MUNQQS_ORC_Tactical]  
			@p_AccountingPeriod			INT
			,@p_ActivityJobId           VARCHAR(50)     = NULL

/*----======================================================================================================================================================================================

1.0					DetailsOfChange: 07/08/2023 :  Jira Ticket - I1B-3622
Description:			The source table [SPA].[ObligatedPremium_SPA] used in the Stored procedure is replaced with the Source query. The query now loads the data from FDM and PFT tables. 
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
 1.1 Details of Change : 16-02-2024 : https://beazley.atlassian.net/browse/I1B-5065
 Description : Converting from Tactical to Strategic - This Dataset is about calculating Commissions for Premiums SPA and MUNQQS.
											
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Version:		 1.2				
Date Of Change:		18-04-2024				
Change done by:		Lakshman.Akasapu@beazley.com			
Description:		https://beazley.atlassian.net/browse/I1B-5065 
					Added a condition to Code line  No.563. This will restrict creating a Batchid if no data found in Inbound. 
					This will avoid creating Reversal Entries in Outbound.Transaction
----------------------------------------------------------------------------------------------------------------------------------------------------------------------
Version:		 1.3 Sprint 24Q2 CommittedVersion
Author		:  Bhargav Entha    <entha.bhargav@beazley.com>
Modify Date	:  01/05/2024 - Sprint Q2 Committed version
Description	:  https://beazley.atlassian.net/browse/I1B-5065
				https://beazley.atlassian.net/browse/I1B-5079

				New views created and used to Extract SPA data for this calculations.
				1. [SPA].[VW_SPA_6107PFT]			--NewView
				2.[SPA].[VW_SPA_5623FDM]			-- Replace by [SPA].[vw_SPA_not2022q1]
				3.[SPA].[Vw_SPA_5623PFT_22Q1]		-- Replace by[SPA].[vw_SPA_2022Q1]

				both datasets need to change together if one would have to change (ObligatedPremium_SPA and SPA_MUNQQS_ORC_TACTICAL)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------
Version:		 1.4 Sprint 24Q3 CommittedVersion
Author		:  Shah Nawaz Ahmed    <ShahNawaz.Ahmed@beazley.com>
Modify Date	:  25/06/2024 - Sprint Q3 Committed version
Description	:  https://beazley.atlassian.net/browse/I1B-5498
				Added MUNQQS BICI RI Premuim data with existing data.
-- ======================================================================================================================================================================================*/

AS
BEGIN

	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;

	/*======================================================Logging Starts==================================================*/
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'SPA_MUNQQS_ORC_TACTICAL';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= NULL;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	DECLARE @ContractType					CHAR(3)			= 'SOT';
	DECLARE	@p_ParentActivityLogId			BIGINT			= NULL

	DECLARE @v_Dataset						varchar(50)		= @v_ActivityDatabase
	DECLARE @v_BatchId						INT             = NULL;
	DECLARE @v_BatchId_Extensions			INT;
	DECLARE @AccountingPeriod				varchar(20)		= @p_AccountingPeriod;



	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';

	INSERT INTO [dbo].[Batch]([CreateDate],[DataSet]) 
	VALUES  (GETDATE(),@v_Dataset);

	SELECT @v_BatchId = SCOPE_IDENTITY();

	SET @v_ActivityJobId=@v_BatchId

	/* Log the start of the insert */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'SPA.usp_LandingInboundWorkflow_SPA_MUNQQS_ORC_Tactical'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'Load data into Inbound.Transaction for SPA_MUNQQS_ORC_Tactical'
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;
	
/*==================Logging End======================*/


	BEGIN TRY
		IF @Trancount = 0 
			BEGIN TRAN;

		/*
=============================================================================================
	Create BatchID In landing
==============================================================================================
*/

	declare 
		 @Scenario char(1)				= 'A' 
		,@Basis char(1)					= 'E'
		,@DefaultDate date				= CAST('01-01-1980' as date)
		,@TypeOfBusiness char(1)		= '-'
		,@Location char(1)				= '-'
		,@IsToDate char(1)				= 'Y'
		,@BusinessProcessCode char(2)	= 'T1'
		,@AuditHost varchar(255)		= CAST(SERVERPROPERTY('MachineName') as varchar(255))
		,@StatsCode varchar(25)			= null
		,@Account varchar(25)			= 'P-OR-P-TTY'
		,@PolicyNumber char(8)			= 'NOPOLICY'

		
	

	INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'LandingInboundWorkflow_SPA_MUNQQS_ORC_Tactical', ' '+CONVERT(VARCHAR,@v_BatchId)+' Batch Created';

	if object_id('tempdb..#LandingTempSPA') is not null drop table #LandingTempSPA;

WITH cte
AS (
	SELECT ProgrammeCode
		,YOA
		,Class
		,(Overrider / 100) AS Overrider
	FROM (
		SELECT 'MUNQQS' AS ProgrammeCode
			,isnull(t.YOA, attr.YOA) YOA
			,'All' AS Class
			,isnull(t.ORCPercentage, attr.Overrider) Overrider
		FROM (
			SELECT YOA
				,max(ORCPercentage * 100) ORCPercentage
			FROM FinanceLanding.[fdm].[RISpendMunichCedePercentage] --Get the Commission Percentage
			GROUP BY YOA
			) t
		FULL OUTER JOIN (
			SELECT ProgrammeCode
				,cast(year(Inception_Date) AS VARCHAR) YOA
				,'All' AS Class
				,max(Overrider) Overrider
			FROM [Eurobase].[vw_ReInsuranceTreatyContractAttributes]
			WHERE ProgrammeCode = 'MUNQQS'
				AND Inception_Date >= '2016-01-01'
				AND General_Description NOT LIKE '%BICI%'
			GROUP BY ProgrammeCode
				,cast(year(Inception_Date) AS VARCHAR)
			) attr ON (attr.YOA = t.YOA)
		
		UNION ALL
		
		SELECT ProgrammeCode
			,cast(year(Inception_Date) AS VARCHAR) YOA
			,CASE 
				WHEN General_Description LIKE 'TREATY%'
					THEN 'Treaty'
				ELSE 'Specialty Lines'
				END AS Class
			,max(Overrider) Overrider
		FROM [Eurobase].[vw_ReInsuranceTreatyContractAttributes]
		WHERE ProgrammeCode = 'Cede 6107'
			AND Inception_Date >= '2016-01-01'
		GROUP BY ProgrammeCode
			,cast(year(Inception_Date) AS VARCHAR)
			,CASE 
				WHEN General_Description LIKE 'TREATY%'
					THEN 'Treaty'
				ELSE 'Specialty Lines'
				END
		
		UNION ALL
		
		SELECT ProgrammeCode
			,cast(year(Inception_Date) AS VARCHAR) YOA
			,'All' AS Class
			,Overrider
		FROM [Eurobase].[vw_ReInsuranceTreatyContractAttributes]
		WHERE ProgrammeCode = 'Cede 5623'
			AND Inception_Date >= '2016-01-01'
		) t
	)
	,CTE_MUNQQS_BICI_ORCPre --/*Modify Date	:  25/06/2024: https://beazley.atlassian.net/browse/I1B-5498 */
	AS (
		select ProgrammeCode,
		cast(year(Inception_Date) as varchar) YOA,
		'All' as Class,
		max(Overrider / 100) Overrider
		from [Eurobase].[vw_ReInsuranceTreatyContractAttributes]
		where ProgrammeCode = 'MUNQQS'
		and Inception_Date >= '2016-01-01'
		and General_Description like '%BICI%'
		group by ProgrammeCode,
		cast(year(Inception_Date) as varchar) 
	)
	,
--------------------------------------------------------------------------MUNQQS Source
CTE_TempIBMunichQQS
AS (
	SELECT TrifocusCode = tf.TrifocusCode
		,YOA
		,DateOfFact = dateadd(month, 3, cast(asat + '01' AS DATE)) --cast(asat + '01' AS DATE)
		,Entity
		,SettlementCCY
		,BusinessKey = isnull(ltrim(rtrim(t.Entity)), '-') + '|' + isnull(ltrim(rtrim(tf.TrifocusCode)), '-') + '|' + isnull(cast(ltrim(rtrim(t.YOA)) AS VARCHAR), '-') + '|' + isnull(ltrim(rtrim(t.SettlementCCY)), '-')
		,InceptionDate = cast(cast(t.YOA AS VARCHAR) + CASE 
				WHEN t.YOA = 1998
					THEN '0401' -- Writing specific this for reason, But removal of this transformation won't be huge impact
				ELSE '0101'
				END AS DATE)
		,ExpiryDate = cast(cast(t.YOA AS VARCHAR) + '1231' AS DATE)
		,[value]
	FROM SPA.vw_MUNQQS t
	LEFT JOIN FinanceLanding.fdm.DimTrifocus tf ON (tf.TrifocusName = t.TriFocus)
	WHERE t.yoa >= left(t.asat, 4) - 2
		AND AsAt = @p_AccountingPeriod
		-- Intention is to take Open Year of Accounts as this is derived based on YOA,AccountingPeriod fields ( YOA in relation to AP )
	)
	,
--------------------------------------------------------------------------MUNQQS BICI RI Premuim Source
	CTE_TempIBMUNQQS_BICI --/*Modify Date	:  25/06/2024: https://beazley.atlassian.net/browse/I1B-5498 */
	AS
	(
		SELECT	TrifocusCode = tf.TrifocusCode
				,t.YOA
				,DateOfFact = DATEADD(MONTH,3,CAST(AsAt+'01' AS date))
				,t.Entity
				,t.SettlementCCY
				,BusinessKey = isnull(ltrim(rtrim(t.Entity)), '-') + '|' + isnull(ltrim(rtrim(tf.TrifocusCode)), '-') + '|' + isnull(cast(ltrim(rtrim(t.YOA)) AS VARCHAR), '-') + '|' + isnull(ltrim(rtrim(t.SettlementCCY)), '-')
				,[Value]
		FROM	[SPA].[vw_MUNQQS_BICI_RI] t
		LEFT JOIN FinanceLanding.fdm.DimTrifocus tf ON (tf.TrifocusName = t.TriFocus)
		WHERE	t.yoa >= left(t.asat, 4) - 2
		AND AsAt = @p_AccountingPeriod
	),
	-------------------------------------------------SPA Source
cte_SPA
AS (
	SELECT NULL AS PK_Transaction
		,dateadd(quarter, 1, cast(left(t.AccountingPeriod, 4) + right(t.AccountingPeriod, 2) + '01' AS DATE)) AS DateOfFact
		,t.AccountingPeriod AS AccountingPeriod
		,isnull(t.ProgrammeCode, '-') + '|' + isnull(t.Entity, '-') + '|' + isnull(t.TrifocusCode, '-') + '|' + isnull(cast(t.YOA AS VARCHAR), '-') + '|' + isnull(t.SettlementCCY, '-') AS BusinessKey
		,t.TrifocusCode AS TrifocusCode
		,t.Entity AS Entity
		,t.YOA AS YOA
		,t.SettlementCCY AS SettlementCCY
		,t.SettlementCCY AS OriginalCCY
		,- sum(sum(t.[Value])) OVER (
			PARTITION BY t.TrifocusCode
			,t.Entity
			,t.YOA
			,t.SettlementCCY
			,t.RIPolicyType
			,t.ProgrammeCode ORDER BY t.AccountingPeriod ASC
			) AS [Value]
		,- sum(sum(t.[Value])) OVER (
			PARTITION BY t.TrifocusCode
			,t.Entity
			,t.YOA
			,t.SettlementCCY
			,t.RIPolicyType
			,t.ProgrammeCode ORDER BY t.AccountingPeriod ASC
			) AS [ValueOrig]
		,t.RIPolicyType AS RIPolicyType
		,t.ProgrammeCode AS ProgrammeCode
	FROM [SPA].[VW_SPA_5623FDM] t	 --SPA.vw_SPA_not2022q1 t --
	WHERE 1 = 1
		AND AccountingPeriod <= @p_AccountingPeriod
	GROUP BY t.AccountingPeriod
		,t.TrifocusCode
		,t.Entity
		,t.YOA
		,t.SettlementCCY
		,t.RIPolicyType
		,t.ProgrammeCode
	
	UNION ALL
	
	SELECT NULL AS PK_Transaction
		,dateadd(quarter, 1, cast(left(t.AccountingPeriod, 4) + right(t.AccountingPeriod, 2) + '01' AS DATE)) AS DateOfFact
		,t.AccountingPeriod
		,isnull(t.ProgrammeCode, '-') + '|' + isnull(t.Entity, '-') + '|' + isnull(t.TrifocusCode, '-') + '|' + isnull(cast(t.YOA AS VARCHAR), '-') + '|' + isnull(t.SettlementCCY, '-') AS BusinessKey
		,t.TrifocusCode AS TrifocusCode
		,t.Entity AS Entity
		,t.YOA AS YOA
		,t.SettlementCCY AS SettlementCCY
		,t.SettlementCCY AS OriginalCCY
		,sum(t.[Value]) AS [Value]
		,sum(t.[Value]) AS [ValueOrig]
		,t.RIPolicyType AS RIPolicyType
		,t.ProgrammeCode AS ProgrammeCode
	FROM  [SPA].[Vw_SPA_5623PFT_22Q1] t --SPA.vw_SPA_2022Q1
	WHERE 1 = 1
		
	GROUP BY t.AccountingPeriod
		,t.TrifocusCode
		,t.Entity
		,t.YOA
		,t.SettlementCCY
		,t.RIPolicyType
		,t.ProgrammeCode
	
	UNION ALL

		SELECT NULL AS PK_Transaction
		,dateadd(quarter, 1, cast(left(t.AccountingPeriod, 4) + right(t.AccountingPeriod, 2) + '01' AS DATE)) AS DateOfFact
		,t.AccountingPeriod
		,isnull(t.ProgrammeCode, '-') + '|' + isnull(t.Entity, '-') + '|' + isnull(t.TrifocusCode, '-') + '|' + isnull(cast(t.YOA AS VARCHAR), '-') + '|' + isnull(t.SettlementCCY, '-') AS BusinessKey
		,t.TrifocusCode AS TrifocusCode
		,t.Entity AS Entity
		,t.YOA AS YOA
		,t.SettlementCCY AS SettlementCCY
		,t.SettlementCCY AS OriginalCCY
		,sum(t.[Value]) AS [Value]
		,sum(t.[Value]) AS [ValueOrig]
		,t.RIPolicyType AS RIPolicyType
		,t.ProgrammeCode AS ProgrammeCode
	FROM [SPA].[VW_SPA_6107PFT] t --New
	WHERE 1 = 1
	AND AccountingPeriod= @p_AccountingPeriod --New Filter
	GROUP BY t.AccountingPeriod
		,t.TrifocusCode
		,t.Entity
		,t.YOA
		,t.SettlementCCY
		,t.RIPolicyType
		,t.ProgrammeCode
	)
	--Combination of MUNQQS and SPA sources
	,Cte_Landing
AS (
	SELECT convert(VARCHAR(10), [DateOfFact], 126) AS DateOfFact
		,[BusinessKey] + '|ORC' AS BusinessKey
		,[TrifocusCode]
		,[Entity]
		,t.[YOA]
		,isnull([SettlementCCY], 'USD') AS SettlementCCY
		,isnull([SettlementCCY], 'USD') AS [OriginalCCY]
		,- [Value] * isnull(mun.Overrider, 0) [Value]
		,- [Value] * isnull(mun.Overrider, 0) [ValueOrig]
		,'QS' [RIPolicyType]
		,'MUNQQS' [ProgrammeCode]
	FROM CTE_TempIBMunichQQS t
	JOIN cte mun ON (
			mun.ProgrammeCode = 'MUNQQS'
			AND mun.YOA = t.YOA
			)
	WHERE t.Value <> 0

	UNION ALL
	--/*Modify Date	:  25/06/2024: https://beazley.atlassian.net/browse/I1B-5498 */
	SELECT convert(VARCHAR(10), [DateOfFact], 126) AS DateOfFact
		,[BusinessKey] + '|ORC' AS BusinessKey
		,[TrifocusCode]
		,[Entity]
		,t.[YOA]
		,isnull([SettlementCCY], 'USD') AS SettlementCCY
		,isnull([SettlementCCY], 'USD') AS [OriginalCCY]
		,- [Value] * isnull(mun.Overrider, 0) [Value]
		,- [Value] * isnull(mun.Overrider, 0) [ValueOrig]
		,'QS' [RIPolicyType]
		,'MUNQQS' [ProgrammeCode]
	FROM	CTE_TempIBMUNQQS_BICI t
	JOIN	CTE_MUNQQS_BICI_ORCPre mun ON (
			mun.ProgrammeCode = 'MUNQQS'
			AND mun.YOA = t.YOA
			)
	WHERE t.[Value] <> 0
			
	UNION ALL
	
	SELECT convert(VARCHAR(10), [DateOfFact], 126) AS DateOfFact
		,[BusinessKey] + '|ORC' AS BusinessKey
		,[TrifocusCode]
		,[Entity]
		,t.[YOA]
		,isnull([SettlementCCY], 'USD') AS SettlementCCY
		,isnull([SettlementCCY], 'USD') AS [OriginalCCY]
		,- [Value] * isnull(trk.Overrider, 0) [Value]
		,- [Value] * isnull(trk.Overrider, 0) [ValueOrig]
		,[RIPolicyType]
		,t.ProgrammeCode
	FROM cte_SPA t
	JOIN cte trk ON (
			trk.ProgrammeCode = t.ProgrammeCode
			AND trk.YOA = t.YOA
			)
	WHERE t.ProgrammeCode = 'Cede 5623'
		AND t.AccountingPeriod = @p_AccountingPeriod
		AND t.Value <> 0
	----------
	
	UNION ALL
	
	SELECT convert(VARCHAR(10), [DateOfFact], 126) AS DateOfFact
		,[BusinessKey] + '|ORC' AS BusinessKey
		,t.[TrifocusCode]
		,[Entity]
		,t.[YOA]
		,isnull([SettlementCCY], 'USD') AS SettlementCCY
		,isnull([SettlementCCY], 'USD') AS [OriginalCCY]
		,- [Value] * isnull(spa.Overrider, 0) [Value]
		,- [Value] * isnull(spa.Overrider, 0) [ValueOrig]
		,[RIPolicyType]
		,t.ProgrammeCode
	FROM cte_SPA t
	LEFT JOIN mds.TriFocus tf ON (tf.TriFocusCode = t.TrifocusCode)
	LEFT JOIN mds.ConformedTrifocusMapping ctf ON (ctf.TrifocusCode = t.TrifocusCode)
	LEFT JOIN mds.TriFocus dep ON (dep.TriFocusCode = ctf.ConformedTrifocusMapping)
	LEFT JOIN cte spa ON (
			spa.ProgrammeCode = spa.ProgrammeCode
			AND spa.YOA = t.YOA
			AND spa.Class = isnull(tf.DepartmentName_Name, dep.DepartmentName_Name)
			)
	WHERE t.ProgrammeCode = 'Cede 6107'
		AND t.AccountingPeriod = @p_AccountingPeriod
		AND t.Value <> 0
	)
SELECT Scenario = @Scenario
	,Basis = @Basis
	,[Account] = @Account
	,[Dataset] = @v_Dataset
	,[DateOfFact] = LTRIM(RTRIM([DateOfFact]))
	,[BusinessKey] = LTRIM(RTRIM([BusinessKey]))
	,[PolicyNumber] = @PolicyNumber
	,[InceptionDate] = @DefaultDate
	,[ExpiryDate] = @DefaultDate
	,[BindDate] = @DefaultDate
	,[DueDate] = @DefaultDate
	,[TrifocusCode] = LTRIM(RTRIM([TrifocusCode]))
	,[Entity] = LTRIM(RTRIM([Entity]))
	,[Location] = @Location
	,[YOA] = LTRIM(RTRIM([YOA]))
	,[TypeOfBusiness] = @TypeOfBusiness
	,[SettlementCCY] = LTRIM(RTRIM([SettlementCCY]))
	,[OriginalCCY] = LTRIM(RTRIM([OriginalCCY]))
	,[IsToDate] = @IsToDate
	,[Value]
	,[ValueOrig]
	,RowHash = dbo.fn_RowHashForTransactions('T' -- <@RowHashType, char(1),>
		, @Scenario --,<@Scenario, nvarchar(2000),>
		, @Account --,<@Account, nvarchar(2000),>
		, @v_Dataset --,<@DataSet, nvarchar(2000),>
		, [BusinessKey] --,<@BusinessKey, nvarchar(2000),>
		, @PolicyNumber --,<@PolicyNumber, nvarchar(2000),>
		, @DefaultDate --,<@InceptionDate, date,>
		, @DefaultDate --,<@ExpiryDate, date,>
		, @DefaultDate --,<@BindDate, date,>
		, @DefaultDate --,<@DueDate, date,>
		, [TrifocusCode] --,<@TrifocusCode, nvarchar(2000),>
		, [Entity] --,<@Entity, nvarchar(2000),>
		, [YOA] --,<@YOA, nvarchar(2000),>
		, @TypeOfBusiness --,<@TypeOfBusiness, nvarchar(2000),>
		, @StatsCode --,<@StatsCode, nvarchar(2000),>
		, [SettlementCCY] --,<@SettlementCCY, nvarchar(2000),>
		, [SettlementCCY] --,<@OriginalCCY, nvarchar(2000),>
		, @IsToDate --,<@IsToDate, nvarchar(2000),>
		, @Basis --,<@Basis, nvarchar(2000),>
		, @Location --,<@Location, nvarchar(2000),>
		, @BusinessProcessCode --,<@BusinessProcessCode, nvarchar(2000),>
		, NULL --,<@BoundDate, date,>
		, CONCAT (
			CASE 
				WHEN RIPolicyType IS NULL
					THEN ''
				ELSE (RIPolicyType + '§~§')
				END
			,CASE 
				WHEN ProgrammeCode IS NULL
					THEN ''
				ELSE (ProgrammeCode + '§~§')
				END
			))
	,[RowHash_Transaction_ReInsurance_Extensions] = dbo.fn_RowHashForTransactions('E' /* @RowHashType */
		, @Scenario, @Account, @v_Dataset, BusinessKey, @PolicyNumber, @DefaultDate, @DefaultDate, @DefaultDate, @DefaultDate, TrifocusCode, Entity, YOA, @TypeOfBusiness, @StatsCode, SettlementCCY, SettlementCCY, @IsToDate, @Basis, @Location, @BusinessProcessCode /* @BusinessProcessCode */
		, NULL /* @BoundDate */
		-- extended columns
		, CONCAT (
			CASE 
				WHEN RIPolicyType IS NULL
					THEN ''
				ELSE (RIPolicyType + '§~§')
				END
			,CASE 
				WHEN ProgrammeCode IS NULL
					THEN ''
				ELSE (ProgrammeCode + '§~§')
				END
			))
	,[BusinessProcessCode] = @BusinessProcessCode --ISNULL(nullif(LTRIM(RTRIM([BusinessProcessCode])),''),@BusinessProcessCode)
	,[AuditSourceBatchID] = CAST(@v_BatchId AS VARCHAR(50))
	,[AuditGenerateDateTime] = @DefaultDate
	,[StatsCode] = NULL --ISNULL(nullif(LTRIM(RTRIM([StatsCode])),''),null)	  
	,[FK_Batch] = @v_BatchId
	,[DeltaType] = NULL --LTRIM(RTRIM([DeltaType]))
	,[FK_Allocation] = NULL --LTRIM(RTRIM([FK_Allocation]))
	--,[AuditUserCreate]
	,[AuditCreateDateTime] = GETUTCDATE()
	,AuditHost = @AuditHost
	,[BoundDate] = @DefaultDate --ISNULL(nullif(LTRIM(RTRIM([BoundDate])),''),@DefaultDate)
	,RIPolicyType
	,ProgrammeCode
INTO #LandingTempSPA
FROM Cte_Landing t
WHERE 1 = 1
ORDER BY yoa


			------/* Delete the current lines from Inbound ... */

		DELETE
		FROM [FinanceDataContract].[Inbound].[Transaction]
		WHERE [DataSet] = @v_DataSet

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions_Bridge]
		WHERE [ContractType] = @ContractType

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions]
		WHERE [ContractType] = @ContractType


		INSERT INTO [dbo].[Batch]
			([CreateDate],[DataSet],[LatestBusinesKey]) 
		VALUES  
			(GETDATE(),'ReInsuranceExtensions', @AccountingPeriod);

		SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();

		INSERT INTO  [FinanceDataContract].[Inbound].Transaction_ReInsurance_Extensions_Bridge WITH(TABLOCK)
			(
				[RowHash_Transaction]
				,[RowHash_Transaction_ReInsurance_Extensions]
				,[ContractType]
				,[FK_Batch]
			)
			SELECT DISTINCT
				[RowHash]
				,[RowHash_Transaction_ReInsurance_Extensions]
				,@ContractType
				,@v_BatchId_Extensions
			FROM 
				#LandingTempSPA

			INSERT INTO  [FinanceDataContract].[Inbound].Transaction_ReInsurance_Extensions WITH(TABLOCK)
				(
					[RowHash_Transaction_ReInsurance_Extensions]
					,[RIPolicyType]
					,[ProgrammeCode]
					--,[BeazleyCatCode]
					--,[TransactionDate]		
					,[IsLargeLoss]			
					,[ContractType]
					,[FK_Batch]
				)
				SELECT DISTINCT
					[RowHash_Transaction_ReInsurance_Extensions]
					,[RIPolicyType]
					,[ProgrammeCode]
					--,[BeazleyCatCode]
					--,[TransactionDate]		
					, NULL AS [IsLargeLoss]			
					,@ContractType
					,@v_BatchId_Extensions
				FROM 
					#LandingTempSPA
				

/*============================================================================================================
			INSERT INTO  Inbound.Transaction FROM FinanceLanding.BP.LandingBusinessplan
===============================================================================================================*/
	INSERT INTO [FinanceDataContract].[Inbound].[Transaction] WITH(TABLOCK)
			( [Scenario],[Basis],[Account],[DataSet],[DateOfFact],[BusinessKey],[PolicyNumber],[InceptionDate],[ExpiryDate],[BindDate],[DueDate],[TrifocusCode]
				,[Entity],[Location],[YOA],[TypeOfBusiness],[SettlementCCY],[OriginalCCY],[IsToDate],[Value],[ValueOrig],[RowHash],[BusinessProcessCode]
				,[AuditSourceBatchID],[AuditGenerateDateTime],[StatsCode],[FK_Batch],[DeltaType],[FK_Allocation],[AuditCreateDateTime],AuditHost
			)

	SELECT [Scenario],[Basis],[Account],[DataSet],[DateOfFact],[BusinessKey],[PolicyNumber],[InceptionDate],[ExpiryDate],[BindDate],[DueDate],[TrifocusCode]
			,[Entity],[Location],[YOA],[TypeOfBusiness],[SettlementCCY],[OriginalCCY],[IsToDate],[Value],[ValueOrig],[RowHash],[BusinessProcessCode]
			,[AuditSourceBatchID],[AuditGenerateDateTime],[StatsCode],[FK_Batch],[DeltaType],[FK_Allocation],[AuditCreateDateTime],AuditHost
	  FROM #LandingTempSPA
	--WHERE DateOfFact='2020-12-15 00:00:00.000'

	

		SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'SPA.usp_LandingIBWF_SPA_MUNQQS_ORC', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into Inbound.Transaction table for: ' +convert(varchar,@AccountingPeriod);

	IF EXISTS (SELECT  1 FROM [FinanceDataContract].Inbound.[Transaction] WHERE DataSet = @v_DataSet)
	BEGIN
		INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,RunDescription
								,[DataSet]
								,OriginalName
								,AuditSourceBatchID
								,AsAt
								)
				VALUES
								( @v_BatchId
								 ,'InBound'
								 ,NULL
								 ,@v_DataSet
								 ,@AccountingPeriod
								 ,NULL
								 ,left(convert (varchar,dateadd(month, 3, cast( @AccountingPeriod+ '01' as date)) ,112),6)								
								
								)
								,

								( @v_BatchId_Extensions
								,'InBound'
								,'ReInsuranceExtensions, the additional attributes to extend functionality of the transaction table.'
								,'ReInsuranceExtensions'
								,@AccountingPeriod
								,NULL
								,left(convert (varchar,dateadd(month, 3, cast( @AccountingPeriod+ '01' as date)) ,112),6)
								);
	END
		-- LOG THE RESULT WITH SUCCESS
			SELECT @v_ActivityDateTime			= GETUTCDATE();

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStop
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

       

		IF @Trancount = 0 
		COMMIT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, 'SPA.usp_LandingIBWF_SPA_MUNQQS_ORC', 'SPA_MUNQQS_ORC LandingToInBound Succeeded';

		--Generate logging for success
		EXEC log.usp_LogLanding @Input = @Logging;

	END TRY

	BEGIN CATCH

		IF @Trancount = 0  
				ROLLBACK;
			
			-- LOG THE RESULT WITH ERROR--
				UPDATE [FinanceDataContract].[Inbound].[BatchQueue]
				SET Status='OutBoundFailed'
				WHERE PK_Batch=@v_BatchId AND [Status]='InBound' AND DataSet=@v_DataSet


			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

			

		    THROW;

		
	END CATCH;

END;