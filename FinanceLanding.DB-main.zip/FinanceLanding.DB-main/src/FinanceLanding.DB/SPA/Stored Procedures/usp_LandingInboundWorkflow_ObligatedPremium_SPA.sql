﻿CREATE PROCEDURE [SPA].[usp_LandingInboundWorkflow_ObligatedPremium_SPA]  
			@p_AccountingPeriod			INT
			--,@p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL
/*
----================================================================================
--DetailsOfChange: 07/08/2023 :  Jira Ticket - I1B-3622
-- Description: The source table [SPA].[ObligatedPremium_SPA] used in the Stored procedure is replaced with the Source query. The query now loads the data from FDM and PFT tables. 


Author		:  Bhargav     <entha.bhargav@beazley.com>
Change Date	: 23/04/2024 - Sprint Q2 Committed version
Description	: https://beazley.atlassian.net/browse/I1B-5079

				1. Change has been made to populate 6107 Cede is from Adaptive layer or PFT rather taking it from FDM
				2. For 6107 Cede Write BUSA trifocuses from 2024 onwards into 3623 Entity rather allocating to Syndicates(2623/623). 
					With this 3623 Entity populates for 2024 YOA onwards for 6107 Cede data
			
----------------------------------------------------------------------------------------------------------------------------------------------------------------------
Version:		Sprint 24Q2 CommittedVersion
Author		:  Bhargav Entha    <entha.bhargav@beazley.com>
Modify Date	:  01/05/2024 - Sprint Q2 Committed version
Description	:  https://beazley.atlassian.net/browse/I1B-5065
				https://beazley.atlassian.net/browse/I1B-5079

				New views created and used to Extract SPA data for this calculations.
				1. [SPA].[VW_SPA_6107PFT]			--NewView
				2.[SPA].[VW_SPA_5623FDM]			-- Replace by [SPA].[vw_SPA_not2022q1]
				3.[SPA].[Vw_SPA_5623PFT_22Q1]		-- Replace by[SPA].[vw_SPA_2022Q1]

				both datasets need to change together if one would have to change (ObligatedPremium_SPA and SPA_MUNQQS_ORC_TACTICAL)

----================================================================================================================

*/

AS
BEGIN

	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;

	/*======================================================Logging Starts==================================================*/
	--DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'ObligatedPremium_SPA';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= NULL;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	DECLARE @ContractType					CHAR(3)			= 'SUP';
	DECLARE	@p_ParentActivityLogId			BIGINT			= NULL

	DECLARE @v_Dataset						varchar(50)		= @v_ActivityDatabase
	DECLARE @v_BatchId						INT             = NULL;
	DECLARE @v_BatchId_Extensions			INT;
	DECLARE @AccountingPeriod				varchar(20)		= @p_AccountingPeriod;



	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';

	INSERT INTO [dbo].[Batch]([CreateDate],[DataSet]) 
	VALUES  (GETDATE(),@v_Dataset);

	SELECT @v_BatchId = SCOPE_IDENTITY();

	SET @v_ActivityJobId=@v_BatchId

	/* Log the start of the insert */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'SPA.usp_LandingIBWF_ObligatedPremium_SPA'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'Load data into Inbound.Transaction for ObligatedPremium_SPA Excel Direct Load'
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;
	
/*==================Logging End======================*/


	BEGIN TRY
		IF @Trancount = 0 
			BEGIN TRAN;

		/*
=============================================================================================
	Create BatchID In landing
==============================================================================================
*/

	declare 
		 @Scenario char(1)				= 'A' 
		,@Basis char(1)					= 'E'
		,@DefaultDate date				= CAST('01-01-1980' as date)
		,@TypeOfBusiness char(1)		= '-'
		,@Location char(1)				= '-'
		,@IsToDate char(1)				= 'Y'
		,@BusinessProcessCode char(2)	= 'T1'
		,@AuditHost varchar(255)		= CAST(SERVERPROPERTY('MachineName') as varchar(255))
		,@StatsCode varchar(25)			= null
		,@Account varchar(25)			= 'P-RP-P-TTY'
		,@PolicyNumber char(8)			= 'NOPOLICY'


	

	INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'SPA.usp_LandingIBWF_ObligatedPremium_SPA', ' '+CONVERT(VARCHAR,@v_BatchId)+' Batch Created';

	if object_id('tempdb..#LandingTempSPA') is not null drop table #LandingTempSPA
/*
	;with cte_cede
	as
	(
		select distinct cast(datepart(year, [Inception_Date]) as int) as YOA,
						[Average_QS_%]/100 as Cede
		from Eurobase.[vw_ReInsuranceTreatyContractAttributes]
		where ProgrammeCode = 'Cede 5623'
	)
	,
	cte_5623FDMdata   -- FDM is Incremental/AsAT data where we are paritioning below cte_asat at make LTD data
	as
	(
		select 
			fk_AccountingPeriod		 as AccountingPeriod,
			tf.TrifocusCode			 as TrifocusCode,
			en.EntityCode			 as Entity,
			t.fk_YOA				 as  YOA,
			t.currency				 as SettlementCCY,
			t.cur_amount * cede.Cede as [Value],
			'QS'					 as RIPolicyType,
			'Cede 5623'				 as ProgrammeCode
		FROM fdm.vw_FactFDMExternal t 
			JOIN fdm.[DimAccount] acc on (acc.pk_Account = t.fk_Account)
			JOIN fdm.[DimProcess] prc on (prc.pk_Process = t.fk_Process)
			JOIN fdm.DimTrifocus tf ON (tf.pk_Trifocus = t.fk_TriFocus)
			JOIN fdm.DimEntity en ON (en.pk_Entity = t.fk_Entity)
			join cte_cede cede on (cede.YOA = cast(t.fk_YOA as varchar) )
		WHERE 1=1
			and acc.AccountCode = 'PF00004' 
			and tf.TrifocusName like 'Tracker%'
			and tf.TrifocusName <> 'Tracker SL Fronted'
			and en.EntityCode = '3623'
			and cast(t.fk_AccountingPeriod as varchar) <> '202203'
			and t.fk_AccountingPeriod<= @AccountingPeriod	
	),
	cte_5623PFTdata_22Q1
	as
	(
		SELECT 
			'202203'						  as AccountingPeriod,
			t.[TriFocusCode]				  as TrifocusCode,
			[Entity]						  AS Entity,
			t.[YOA]							  AS YOA,
			[TranCurr]						  as SettlementCCY,
			sum([SyndPremiumGIC] * cede.Cede) as [Value],
			'QS'							  as RIPolicyType,
			'Cede 5623'						  as ProgrammeCode
		from [FinanceLanding].[pft].[PFT_SYND_WITH_CEDE] t
			join cte_cede cede on (cede.YOA = t.YOA)
			left join FinanceLanding.fdm.DimTrifocus tf on (tf.TrifocusCode = t.TrifocusCode)
		where tf.TrifocusName like 'Tracker%'
			and tf.TrifocusName <> 'Tracker SL Fronted'
			and ReviewCycle = '2022Q1'
			and t.Entity = '3623'
		group by [ReviewCycle],
				 t.[TriFocusCode],
				 [Entity],
				 t.[YOA],
				 [TranCurr]
	),
		
	cte_6107PFTdata -- PFT data is LTD data and don't require any partion by in below cte_asat
	as
	(
		select  
						--t.[ReviewCycle]						as AccountingPeriod,

						AccountingPeriod=(CASE  WHEN RIGHT(t.[ReviewCycle],2)='Q1' THEN CAST(CONCAT(LEFT(t.[ReviewCycle],4),'03') as varchar(6))
									 WHEN RIGHT(t.[ReviewCycle],2)='Q2' THEN CAST(CONCAT(LEFT(t.[ReviewCycle],4),'06') as varchar(6))
									 WHEN RIGHT(t.[ReviewCycle],2)='Q3' THEN CAST(CONCAT(LEFT(t.[ReviewCycle],4),'09') as varchar(6))
									WHEN RIGHT(t.[ReviewCycle],2)='Q4' THEN CAST(CONCAT(LEFT(t.[ReviewCycle],4),'12') as varchar(6))
												
						  			END),
						t.[TriFocusCode]		  					as TrifocusCode,
						isnull(sp.SyndSplitEntity, '3623')			as [Entity], 
						t.[YOA]										as YOA,
						t.[TranCurr]								as SettlementCCY,
						sum([SyndPremiumGIC] * isnull(cast(sp.SyndSplitPercentage as numeric(5, 4)), 1))  as [Value],
						'QS'										as RIPolicyType,
						'Cede 6107'									as ProgrammeCode
		from			[PFT].[PFT_SYND_WITH_CEDE] t
		left join		fdm.DimTrifocus tf on (tf.TrifocusCode = t.TrifocusCode)
		left join		fdm.SyndicateSplitsbyYOA sp on
														(sp.SyndSplitYOA = YOA
														 and not (tf.TrifocusName like 'BUSA%'
															      and t.YOA >= '2024')
														 and sp.SyndSplitSource = '2623')
		where 1=1
					and t.Entity = '6107'
		--and t.ReviewCycle = @AccountingPeriod

					AND (CASE  WHEN RIGHT(t.[ReviewCycle],2)='Q1' THEN CAST(CONCAT(LEFT(t.[ReviewCycle],4),'03') as varchar(6))
						   WHEN RIGHT(t.[ReviewCycle],2)='Q2' THEN CAST(CONCAT(LEFT(t.[ReviewCycle],4),'06') as varchar(6))
						   WHEN RIGHT(t.[ReviewCycle],2)='Q3' THEN CAST(CONCAT(LEFT(t.[ReviewCycle],4),'09') as varchar(6))
						   WHEN RIGHT(t.[ReviewCycle],2)='Q4' THEN CAST(CONCAT(LEFT(t.[ReviewCycle],4),'12') as varchar(6))
						   
						 END
						)	=	@AccountingPeriod
		group by	t.[ReviewCycle],
					t.[TriFocusCode],
					isnull(sp.SyndSplitEntity, '3623'),
					t.[YOA],
					t.[TranCurr]
	),
	*/
	
	;WITH cte_asat
	as
	(
	---- Doing parition as FDM data we get is Incremental, Inroder to make data in unique way as compare to PFT. We preparing as LTD data here. this is 5623 Cede data exlcuding 202209
		select 
				null						 as PK_Transaction,
				dateadd(quarter, 1,cast(left(t.AccountingPeriod, 4) + right(t.AccountingPeriod, 2) + '01' as date)) as DateOfFact,
				t.AccountingPeriod			 as AccountingPeriod , 
				isnull(t.ProgrammeCode, '-') + '|' + 
				isnull(t.Entity, '-') + '|' + 
				isnull(t.TrifocusCode, '-') + '|' +
				isnull(cast(t.YOA as varchar), '-') + '|' + 
				isnull(t.SettlementCCY, '-') as BusinessKey,
				'1980-01-01'				 as InceptionDate,
				'1980-01-01'				 as ExpiryDate,
				'1980-01-01'				 as BindDate,
				'1980-01-01'				 as DueDate,
				t.TrifocusCode				 as TrifocusCode,
				t.Entity					 as Entity,
				t.YOA						 as YOA,
				'-'							 as TypeOfBusiness,
				null						 as StatsCode,
				t.SettlementCCY				 as SettlementCCY,
				t.SettlementCCY				 as OriginalCCY,
				'Y'							 as [IsToDate],
				-sum(sum(t.[Value])) over(partition by t.TrifocusCode,
													  t.Entity,
													  t.YOA,
													  t.SettlementCCY,
													  t.RIPolicyType,
													  t.ProgrammeCode
													  order by t.AccountingPeriod asc) as [Value],
				null						 as Rowhash,
				null						 as FK_Allocation,
				null						 as DeltaType,
				null						 as AuditSourceBatchID,
				@DefaultDate				 as AuditCreateDateTime,
				@DefaultDate				 as AuditGenerateDateTime,
				--null as AuditUserCreate,
				@AuditHost					 as AuditHost,
				'E'							 as Basis,
				'-'							 as Location,
				-sum(sum(t.[Value])) over(partition by t.TrifocusCode,
													  t.Entity,
													  t.YOA,
													  t.SettlementCCY,
													  t.RIPolicyType,
													  t.ProgrammeCode
													   order by t.AccountingPeriod asc) as [ValueOrig],
				'T1'						 as BusinessProcessCode,
				null						 as FK_Batch,
				null						 as BoundDate,
				t.RIPolicyType				 as RIPolicyType,
				t.ProgrammeCode				 as ProgrammeCode
		--from cte_5623FDMdata t
		FROM [SPA].[VW_SPA_5623FDM] T
		where 1=1
		AND T.AccountingPeriod<= @AccountingPeriod	
		group by t.AccountingPeriod,
				 t.TrifocusCode,
				 t.Entity,
				 t.YOA,
				 t.SettlementCCY,
				 t.RIPolicyType,
				 t.ProgrammeCode
		
		union all
		--This is LTD data for Cede 5623 from PFT as their is wrong data in FDM for this period
		
		select 
				null						 as PK_Transaction,
				dateadd(quarter, 1,	cast(left(t.AccountingPeriod, 4) + right(t.AccountingPeriod, 2) + '01' as date)) as DateOfFact,
				t.AccountingPeriod,
				isnull(t.ProgrammeCode, '-') + '|' + 
				isnull(t.Entity, '-') + '|' + 
				isnull(t.TrifocusCode, '-') + '|' +
				isnull(cast(t.YOA as varchar), '-') + '|' + 
				isnull(t.SettlementCCY, '-') as BusinessKey,
				'1980-01-01'				 as InceptionDate,
				'1980-01-01'				 as ExpiryDate,
				'1980-01-01'				 as BindDate,
				'1980-01-01'				 as DueDate,
				t.TrifocusCode				 as TrifocusCode,
				t.Entity					 as Entity,
				t.YOA						 as YOA,
				'-'							 as TypeOfBusiness,
				null						 as StatsCode,
				t.SettlementCCY				 as SettlementCCY,
				t.SettlementCCY				 as OriginalCCY,
				'Y'							 as [IsToDate],
				sum(t.[Value])				 as [Value],
				null						 as Rowhash,
				null						 as FK_Allocation,
				null						 as DeltaType,
				null						 as AuditSourceBatchID,
				@DefaultDate				 as AuditCreateDateTime,
				@DefaultDate				 as AuditGenerateDateTime,
				--null as AuditUserCreate,
				@AuditHost					 as AuditHost,
				'E'							 as Basis,
				'-'							 as Location,
				sum(t.[Value])				 as [ValueOrig],
				'T1'						 as BusinessProcessCode,
				null						 as FK_Batch,
				null						 as BoundDate,
				t.RIPolicyType				 as RIPolicyType,
				t.ProgrammeCode				 as ProgrammeCode
		--from cte_5623PFTdata_22Q1 t
		FROM [SPA].[Vw_SPA_5623PFT_22Q1]	T

		where 1=1
		AND T.AccountingPeriod=@AccountingPeriod
		group by t.AccountingPeriod,
				 t.TrifocusCode,
				 t.Entity,
				 t.YOA,
				 t.SettlementCCY,
				 t.RIPolicyType,
				 t.ProgrammeCode

		union all

		--This is 6107 Cede LTD data from PFT
		select 
				null						 as PK_Transaction,
				dateadd(quarter, 1,	cast(left(t.AccountingPeriod, 4) + right(t.AccountingPeriod, 2) + '01' as date)) as DateOfFact,
				t.AccountingPeriod,
				isnull(t.ProgrammeCode, '-') + '|' + 
				isnull(t.Entity, '-') + '|' + 
				isnull(t.TrifocusCode, '-') + '|' +
				isnull(cast(t.YOA as varchar), '-') + '|' + 
				isnull(t.SettlementCCY, '-') as BusinessKey,
				'1980-01-01'				 as InceptionDate,
				'1980-01-01'				 as ExpiryDate,
				'1980-01-01'				 as BindDate,
				'1980-01-01'				 as DueDate,
				t.TrifocusCode				 as TrifocusCode,
				t.Entity					 as Entity,
				t.YOA						 as YOA,
				'-'							 as TypeOfBusiness,
				null						 as StatsCode,
				t.SettlementCCY				 as SettlementCCY,
				t.SettlementCCY				 as OriginalCCY,
				'Y'							 as [IsToDate],
				sum(t.[Value])				 as [Value],
				null						 as Rowhash,
				null						 as FK_Allocation,
				null						 as DeltaType,
				null						 as AuditSourceBatchID,
				@DefaultDate				 as AuditCreateDateTime,
				@DefaultDate				 as AuditGenerateDateTime,
				--null as AuditUserCreate,
				@AuditHost					 as AuditHost,
				'E'							 as Basis,
				'-'							 as Location,
				sum(t.[Value])				 as [ValueOrig],
				'T1'						 as BusinessProcessCode,
				null						 as FK_Batch,
				null						 as BoundDate,
				t.RIPolicyType				 as RIPolicyType,
				t.ProgrammeCode				 as ProgrammeCode
		--from cte_6107PFTdata t
		FROM [SPA].[VW_SPA_6107PFT]	T
		where 1=1
		AND AccountingPeriod=@AccountingPeriod
		group by t.AccountingPeriod,
				 t.TrifocusCode,
				 t.Entity,
				 t.YOA,
				 t.SettlementCCY,
				 t.RIPolicyType,
				 t.ProgrammeCode
)
	
SELECT	Scenario=@Scenario
		,Basis= ISNULL(nullif(LTRIM(RTRIM([Basis])),''),@Basis)			
        ,[Account]=@Account
        ,[Dataset]=@v_Dataset
        ,[DateOfFact]=LTRIM(RTRIM([DateOfFact]))
        ,[BusinessKey]=LTRIM(RTRIM([BusinessKey]))
        ,[PolicyNumber]=@PolicyNumber
        ,[InceptionDate]=ISNULL(LTRIM(RTRIM([InceptionDate])),@DefaultDate)
        ,[ExpiryDate]=ISNULL(LTRIM(RTRIM([ExpiryDate])),@DefaultDate)
        ,[BindDate]=ISNULL(LTRIM(RTRIM([BindDate])),@DefaultDate)
        ,[DueDate]=ISNULL(LTRIM(RTRIM([DueDate])),@DefaultDate)
        ,[TrifocusCode]=LTRIM(RTRIM([TrifocusCode]))
        ,[Entity]=LTRIM(RTRIM([Entity]))
	    ,[Location]=ISNULL(nullif(LTRIM(RTRIM([Location])),''),@Location)
        ,[YOA]=LTRIM(RTRIM([YOA]))
        ,[TypeOfBusiness]=ISNULL(nullif(LTRIM(RTRIM([TypeOfBusiness])),''),@TypeOfBusiness)
	    ,[SettlementCCY]=LTRIM(RTRIM([SettlementCCY]))
        ,[OriginalCCY]=LTRIM(RTRIM([OriginalCCY]))
	    ,[IsToDate]=ISNULL(LTRIM(RTRIM([IsToDate])),@IsToDate)
        ,[Value]
	    ,[ValueOrig]
	    ,RowHash = dbo.fn_RowHashForTransactions('T' -- <@RowHashType, char(1),>
															, @Scenario --,<@Scenario, nvarchar(2000),>
															, @Account --,<@Account, nvarchar(2000),>
															, @v_Dataset --,<@DataSet, nvarchar(2000),>
															, [BusinessKey] --,<@BusinessKey, nvarchar(2000),>
															, @PolicyNumber --,<@PolicyNumber, nvarchar(2000),>
															, [InceptionDate] --,<@InceptionDate, date,>
															, [ExpiryDate] --,<@ExpiryDate, date,>
															, @DefaultDate --,<@BindDate, date,>
															, @DefaultDate --,<@DueDate, date,>
															, [TrifocusCode] --,<@TrifocusCode, nvarchar(2000),>
															, [Entity] --,<@Entity, nvarchar(2000),>
															, [YOA] --,<@YOA, nvarchar(2000),>
															, @TypeOfBusiness --,<@TypeOfBusiness, nvarchar(2000),>
															, @StatsCode --,<@StatsCode, nvarchar(2000),>
															, [SettlementCCY] --,<@SettlementCCY, nvarchar(2000),>
															, [SettlementCCY] --,<@OriginalCCY, nvarchar(2000),>
															, @IsToDate --,<@IsToDate, nvarchar(2000),>
															, @Basis --,<@Basis, nvarchar(2000),>
															, @Location --,<@Location, nvarchar(2000),>
															, @BusinessProcessCode --,<@BusinessProcessCode, nvarchar(2000),>
															, NULL --,<@BoundDate, date,>
															, CONCAT (
																		CASE 
																			WHEN RIPolicyType IS NULL
																				THEN ''
																			ELSE (RIPolicyType + '§~§')
																			END
																		,CASE 
																			WHEN ProgrammeCode IS NULL
																				THEN ''
																			ELSE (ProgrammeCode + '§~§')
																			END
																	)
														)
		 ,[RowHash_Transaction_ReInsurance_Extensions] = dbo.fn_RowHashForTransactions('E' /* @RowHashType */
					, @Scenario, @Account, @v_Dataset, BusinessKey, @PolicyNumber, InceptionDate, ExpiryDate, @DefaultDate, @DefaultDate,
					TrifocusCode, Entity, YOA, @TypeOfBusiness, @StatsCode, SettlementCCY, SettlementCCY, @IsToDate, @Basis, @Location
					, @BusinessProcessCode /* @BusinessProcessCode */
					, NULL /* @BoundDate */
					-- extended columns
					, CONCAT (
						CASE 
							WHEN RIPolicyType IS NULL
								THEN ''
							ELSE (RIPolicyType + '§~§')
							END
						,CASE 
							WHEN ProgrammeCode IS NULL
								THEN ''
							ELSE (ProgrammeCode + '§~§')
							END
						))
		 ,[BusinessProcessCode]=ISNULL(nullif(LTRIM(RTRIM([BusinessProcessCode])),''),@BusinessProcessCode)
		 ,[AuditSourceBatchID]=CAST(@v_BatchId AS VARCHAR (50))
		 ,[AuditGenerateDateTime]
		 ,[StatsCode]= ISNULL(nullif(LTRIM(RTRIM([StatsCode])),''),null)	  
		 ,[FK_Batch]=@v_BatchId     
		 ,[DeltaType]=LTRIM(RTRIM([DeltaType]))
		 ,[FK_Allocation]=LTRIM(RTRIM([FK_Allocation]))
		 --,[AuditUserCreate]
		 ,[AuditCreateDateTime]=GETUTCDATE()
		 ,AuditHost=@AuditHost
		 ,[BoundDate]=ISNULL(nullif(LTRIM(RTRIM([BoundDate])),''),@DefaultDate)
		 ,RIPolicyType
		 ,ProgrammeCode

INTO #LandingTempSPA
from cte_asat t
where 1=1
and t.AccountingPeriod = @AccountingPeriod
and t.[Value] <> 0
order by yoa 

			------/* Delete the current lines from Inbound ... */

		DELETE
		FROM [FinanceDataContract].[Inbound].[Transaction]
		WHERE [DataSet] = @v_DataSet

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions_Bridge]
		WHERE [ContractType] = @ContractType

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions]
		WHERE [ContractType] = @ContractType


		INSERT INTO [dbo].[Batch]
			([CreateDate],[DataSet],[LatestBusinesKey]) 
		VALUES  
			(GETDATE(),'ReInsuranceExtensions', @AccountingPeriod);

		SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();

		INSERT INTO  [FinanceDataContract].[Inbound].Transaction_ReInsurance_Extensions_Bridge WITH(TABLOCK)
			(
				[RowHash_Transaction]
				,[RowHash_Transaction_ReInsurance_Extensions]
				,[ContractType]
				,[FK_Batch]
			)
			SELECT DISTINCT
				[RowHash]
				,[RowHash_Transaction_ReInsurance_Extensions]
				,@ContractType
				,@v_BatchId_Extensions
			FROM 
				#LandingTempSPA

			INSERT INTO  [FinanceDataContract].[Inbound].Transaction_ReInsurance_Extensions WITH(TABLOCK)
				(
					[RowHash_Transaction_ReInsurance_Extensions]
					,[RIPolicyType]
					,[ProgrammeCode]
					--,[BeazleyCatCode]
					--,[TransactionDate]		
					,[IsLargeLoss]			
					,[ContractType]
					,[FK_Batch]
				)
				SELECT DISTINCT
					[RowHash_Transaction_ReInsurance_Extensions]
					,[RIPolicyType]
					,[ProgrammeCode]
					--,[BeazleyCatCode]
					--,[TransactionDate]		
					, NULL AS [IsLargeLoss]			
					,@ContractType
					,@v_BatchId_Extensions
				FROM 
					#LandingTempSPA
				

/*============================================================================================================
			INSERT INTO  Inbound.Transaction FROM FinanceLanding.BP.LandingBusinessplan
===============================================================================================================*/
	INSERT INTO [FinanceDataContract].[Inbound].[Transaction] WITH(TABLOCK)
			( [Scenario],[Basis],[Account],[DataSet],[DateOfFact],[BusinessKey],[PolicyNumber],[InceptionDate],[ExpiryDate],[BindDate],[DueDate],[TrifocusCode]
				,[Entity],[Location],[YOA],[TypeOfBusiness],[SettlementCCY],[OriginalCCY],[IsToDate],[Value],[ValueOrig],[RowHash],[BusinessProcessCode]
				,[AuditSourceBatchID],[AuditGenerateDateTime],[StatsCode],[FK_Batch],[DeltaType],[FK_Allocation],[AuditCreateDateTime],AuditHost
			)

	SELECT [Scenario],[Basis],[Account],[DataSet],[DateOfFact],[BusinessKey],[PolicyNumber],[InceptionDate],[ExpiryDate],[BindDate],[DueDate],[TrifocusCode]
			,[Entity],[Location],[YOA],[TypeOfBusiness],[SettlementCCY],[OriginalCCY],[IsToDate],[Value],[ValueOrig],[RowHash],[BusinessProcessCode]
			,[AuditSourceBatchID],[AuditGenerateDateTime],[StatsCode],[FK_Batch],[DeltaType],[FK_Allocation],[AuditCreateDateTime],AuditHost
	  FROM #LandingTempSPA
	--WHERE DateOfFact='2020-12-15 00:00:00.000'

	

		SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'SPA.usp_LandingIBWF_ObligatedPremium_SPA', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into Inbound.Transaction table for: ' +convert(varchar,@AccountingPeriod);

IF EXISTS(SELECT 1 FROM [FinanceDataContract].Inbound.[Transaction] where DataSet = @v_DataSet)
BEGIN
		INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,RunDescription
								,[DataSet]
								,OriginalName
								,AuditSourceBatchID
								,AsAt
								)
				VALUES
								( @v_BatchId
								 ,'InBound'
								 ,NULL
								 ,@v_DataSet
								 ,@AccountingPeriod
								 ,NULL
								 ,left(convert (varchar,dateadd(month, 3, cast( @AccountingPeriod+ '01' as date)) ,112),6)								
								
								)
								,

								( @v_BatchId_Extensions
								,'InBound'
								,'ReInsuranceExtensions, the additional attributes to extend functionality of the transaction table.'
								,'ReInsuranceExtensions'
								,@AccountingPeriod
								,NULL
								,left(convert (varchar,dateadd(month, 3, cast( @AccountingPeriod+ '01' as date)) ,112),6)
								);
END
		-- LOG THE RESULT WITH SUCCESS
			SELECT @v_ActivityDateTime			= GETUTCDATE();

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStop
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

       

		IF @Trancount = 0 
		COMMIT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, 'SPA.usp_LandingIBWF_ObligatedPremium_SPA', 'SPA_Obligated_Premium LandingToInBound Succeeded';

		--Generate logging for success
		EXEC log.usp_LogLanding @Input = @Logging;

	END TRY

	BEGIN CATCH

		IF @Trancount = 0  
				ROLLBACK;
			
			-- LOG THE RESULT WITH ERROR--
				UPDATE [FinanceDataContract].[Inbound].[BatchQueue]
				SET Status='OutBoundFailed'
				WHERE PK_Batch=@v_BatchId AND [Status]='InBound' AND DataSet=@v_DataSet


			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

			

		    THROW;

		
	END CATCH;

END;
GO


