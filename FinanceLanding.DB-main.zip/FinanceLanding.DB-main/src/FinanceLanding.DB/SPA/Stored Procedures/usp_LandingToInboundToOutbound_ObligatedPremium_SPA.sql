﻿CREATE PROCEDURE [SPA].[usp_LandingToInboundToOutbound_ObligatedPremium_SPA] 
             @p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL

AS
/*
-- =====================================================================================================================================================================================
--DetailsOfChange: 07/08/2023 : Jira Ticket - I1B-3622
-- Description: The source table [SPA].[ObligatedPremium_SPA] used in the Stored procedure is replaced with the Source query. The query now loads the data from FDM and PFT tables. 

Author		:  Bhargav     <entha.bhargav@beazley.com>
Change Date	: 23/04/2024 - Sprint Q2 Committed version
Description	: https://beazley.atlassian.net/browse/I1B-5079 added filter accountcode PF00004 to restrict period to pass on/run for

Author		:  Bhargav     <entha.bhargav@beazley.com>
Change Date	: 26/04/2024 - Sprint Q2 Committed version
Description	: https://beazley.atlassian.net/browse/I1B-5079 
				Written CTE PushBackPeriods to change it to PFT from FDM periods as Going forward from 2025 onwards, we can't see 5623 Cede data coming from FDM. Hence, modifying it to take periods to run from PFT table.
				In CTE we have back dated a quarter from PFT(as PFT always a push forward), However we are pushing forward the period in respective L2I procedure. 
				This Back date a quarter/period is just to ensure we don't do big number of changes when we convert it from FDM to PFT.As FDM has it's own quarter needs Push Forward where PFT is already forwaded.

Author		:  Shah Nawaz Ahmed     <shahnawaz.ahmed@beazley.com>
Change Date	: 13/06/2024 - Sprint Q2 Committed version
Description	: https://beazley.atlassian.net/browse/I1B-5616 Removed Pushback logic from selecting the Accounting Period

-- ======================================================================================================================================================================================
*/
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'ObligatedPremium_SPA';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	DECLARE @v_DataSet VARCHAR(255)	= @v_ActivityDatabase

	DECLARE @v_AccountingPeriod                   INT             = NULL;
	DECLARE @v_AccountingPeriod_Default           INT             = 201809; -- this is our starting date

BEGIN TRY  

	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';



	/* Log the start of the process */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'Load data into Inbound.Transaction and Outbound.Transaction using [SPA].[usp_LandingToInboundToOutbound_ObligatedPremium_SPA]  '
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= ''
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;


	-- Get the last processed date for data from the outbound table. 
	-- We'll then process these, so we get all the records for the current month or the last month and process these.
	-- In the case that we're doing day one, we will have zero records in the outbound, so we need to get them all from our default starting date.



	--DECLARE @v_AccountingPeriod                   INT             = NULL;
	--DECLARE @v_AccountingPeriod_Default           INT             = 201809; -- this is our starting date
	--DECLARE @v_DataSet VARCHAR(255)	= 'ObligatedPremium_SPA'

	-- to get exact current DOF/Period/AsAt, Backing a quarter from Outbound for dateOffact as it has been push forward by a quarter in [OP].[usp_LandingInboundWorkflow_ObligatedPremium_Munich_QQS]

	select @v_AccountingPeriod = isnull(convert(int,convert(char(6),convert(date,dateadd(quarter,-1,max(DateOfFact))),112)),@v_AccountingPeriod_Default)
	from [FinanceDataContract].[Outbound].[Transaction]
	where Dataset = @v_DataSet

	--select @v_AccountingPeriod=201903
	
	
	
	declare @Dates table(Asat int, i int identity(1,1))
	

	;WITH PushBackPeriods AS
	(
		SELECT			DISTINCT  Periodss=CASE  WHEN  RIGHT(T.ReviewCycle,2)='Q1' THEN CONCAT(LEFT(T.ReviewCycle,4) ,'03') 
												 WHEN  RIGHT(T.ReviewCycle,2)='Q2' THEN CONCAT(LEFT(T.ReviewCycle,4),'06')
												 WHEN  RIGHT(T.ReviewCycle,2)='Q3' THEN CONCAT(LEFT(T.ReviewCycle,4),'09')
												 WHEN  RIGHT(T.ReviewCycle,2)='Q4' THEN CONCAT(LEFT(T.ReviewCycle,4),'12')
											END		 
							
		FROM			FinanceLanding.[PFT].[PFT_SYND_WITH_CEDE] t
		
		WHERE			 1=1
					AND   t.Entity = '6107'  -- Only Filter Cede 6107 Data available periods
		)
	
	insert into @Dates(Asat)
	
	SELECT  Periodss
	FROM	 PushBackPeriods ff

	WHERE	isdate(convert(varchar(30),(convert(varchar(30),ff.Periodss)+'01'),12))=1 -- filter out non dates.
			and ff.Periodss > @v_AccountingPeriod	
	ORDER BY Periodss ASC

	----select * from @Dates -- rollback
	----order by 1 asc
	--return
	

	declare @i int = 1

	while exists(select 1 from @Dates where i=@i)
	begin

		set @v_AccountingPeriod = (select Asat from @Dates where i=@i)

		select [@v_AccountingPeriod] = @v_AccountingPeriod 

		exec [SPA].[usp_LandingInboundWorkflow_ObligatedPremium_SPA]
			@p_AccountingPeriod	= @v_AccountingPeriod
   --         ,@p_ParentActivityLogId	= @p_ParentActivityLogId
			,@p_ActivityJobId       = @p_ActivityJobId    

		print 'EXEC [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow]'
		if exists(select 1 from [FinanceDataContract].Inbound.[Transaction] where DataSet = @v_DataSet)
		begin
			--select 'exists'
			exec [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_ReInsuranceExtensions]
			--exec [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow] @DoNonIFRS17_Tests = 0   -- Reversal Record DOF for this are not as expected

			exec [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_GAAP] @DoNonIFRS17_Tests = 1
		end
		
		set @i += 1

		-- debug code to do a limited number
		--if @i>1 set @i=1000000
	end


	-- LOG THE RESULT WITH SUCCESS
	SELECT @v_ActivityDateTime			= GETUTCDATE();

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
			 @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStop
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;


END TRY

BEGIN CATCH
			        
			-- LOG THE RESULT WITH ERROR

			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

		    THROW;

END CATCH;

					
END
GO

