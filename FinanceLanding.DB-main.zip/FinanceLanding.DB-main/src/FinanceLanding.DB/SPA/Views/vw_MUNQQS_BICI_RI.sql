﻿CREATE view [SPA].[vw_MUNQQS_BICI_RI]
AS
/* ===========================================================================================================
	Created By:		ShahNawaz.Ahmed@beazley.com
	Modified By : -
	Created date:	24-06-2024
	Modified Date : 
	Description:	Used for SPA_MUNQQS_ORC_Tactical Dataset to bring in MUNQQS premium for BICI RI (https://beazley.atlassian.net/browse/I1B-5498)
=================================================================================================================== */
SELECT
        triangle_group AS Trifocus,
        YOA,
		--cast(asat + '01' as date) DateOfFact,
        AsAt = cast ( CASE right(t.ASAT,2) when	'05' then t.ASAT-2
																when	'11' then  t.ASAT-2
																else t.ASAT
												end
											As VARCHAR(20)
										 ),
        CASE 
            WHEN t.yoa >= '2018'
                AND mtf.Division IN ('SL', 'CyEx')
                AND synd = '3623' THEN '8022'
            ELSE CAST(t.Synd AS VARCHAR)
        END AS Entity,
        ccy AS SettlementCCY,
        SUM([Value]) [Value]
    FROM 
        adm.[Reserving_data] t
    LEFT JOIN 
        fdm.dimTrifocus tf ON (tf.TrifocusName = 
            CASE 
                WHEN t.triangle_group = 'Covers' THEN 'Covers US'
                WHEN t.triangle_group = 'Swiss' THEN 'Private Clients'
                ELSE t.triangle_group 
            END)
    LEFT JOIN 
        mds.TriFocus mtf ON (mtf.[Name] = t.triangle_group)
    WHERE 
        (RIGHT(t.asat, 2) IN ('05', '06', '11', '12') 
				OR asat = '202003')
        AND special = 'Munich'
        AND datasetname = 'Team Premium'
		AND CASE 
            WHEN t.yoa >= '2018'
                AND mtf.Division IN ('SL', 'CyEx')
                AND synd = '3623' THEN '8022'
            ELSE CAST(t.Synd AS VARCHAR)
        END = '8022'
		and asat >= '201809'
		and cast(left(t.asat, 4) as int) - YOA <= 2
    GROUP BY 
        triangle_group,
        YOA,
        cast ( CASE right(t.ASAT,2) when	'05' then t.ASAT-2
																when	'11' then  t.ASAT-2
																else t.ASAT
												end
											As VARCHAR(20)
										 ),
        CASE 
            WHEN t.yoa >= '2018'
                AND mtf.Division IN ('SL', 'CyEx')
                AND synd = '3623' THEN '8022'
            ELSE CAST(t.Synd AS VARCHAR)
        END,
        ccy
    HAVING 
        SUM([Value]) <> 0