CREATE VIEW [SPA].[VW_SPA_5623FDM]  --This needs to be <= Ap and partitional data
AS


/*============================================================================================
Author		:  Bhargav Entha    <entha.bhargav@beazley.com>
Create Date	:  01/05/2024 - Sprint Q2 Committed version
Description	:  https://beazley.atlassian.net/browse/I1B-5065
				https://beazley.atlassian.net/browse/I1B-5079

				This view created to increase the reusability of this object for datasets ObligatedPremium_SPA and SPA_MUNQQS_ORC_TACTICAL
				View objects used within are follows:
				1.[SPA].[usp_LandingInboundWorkflow_SPA_MUNQQS_ORC_Tactical]  
				2.[SPA].[usp_LandingInboundWorkflow_ObligatedPremium_SPA]

=========================================================================================================	*/

WITH cte_cede
	as
	(
		SELECT DISTINCT cast(datepart(year, [Inception_Date]) as int) as YOA,
						[Average_QS_%]/100 as Cede
		FROM  Eurobase.[vw_ReInsuranceTreatyContractAttributes]
		WHERE ProgrammeCode = 'Cede 5623'
	)
	
		select 
			fk_AccountingPeriod		 as AccountingPeriod,
			tf.TrifocusCode			 as TrifocusCode,
			en.EntityCode			 as Entity,
			t.fk_YOA				 as  YOA,
			t.currency				 as SettlementCCY,
			t.cur_amount * cede.Cede as [Value],
			'QS'					 as RIPolicyType,
			'Cede 5623'				 as ProgrammeCode
		FROM fdm.vw_FactFDMExternal t 
			JOIN fdm.[DimAccount] acc on (acc.pk_Account = t.fk_Account)
			JOIN fdm.[DimProcess] prc on (prc.pk_Process = t.fk_Process)
			JOIN fdm.DimTrifocus tf ON (tf.pk_Trifocus = t.fk_TriFocus)
			JOIN fdm.DimEntity en ON (en.pk_Entity = t.fk_Entity)
			join cte_cede cede on (cede.YOA = cast(t.fk_YOA as varchar) )
		WHERE 1=1
			and acc.AccountCode = 'PF00004' 
			and tf.TrifocusName like 'Tracker%'
			and tf.TrifocusName <> 'Tracker SL Fronted'
			and en.EntityCode = '3623'
			and cast(t.fk_AccountingPeriod as varchar) <> '202203'
			--and t.fk_AccountingPeriod<= @AccountingPeriod	




GO


