CREATE VIEW [SPA].[Vw_SPA_5623PFT_22Q1]
AS
/*============================================================================================
Author		:  Bhargav Entha    <entha.bhargav@beazley.com>
Create Date	:  01/05/2024 - Sprint Q2 Committed version
Description	:  https://beazley.atlassian.net/browse/I1B-5065
				https://beazley.atlassian.net/browse/I1B-5079

				This view created to increase the reusability of this object for datasets ObligatedPremium_SPA and SPA_MUNQQS_ORC_TACTICAL
				View objects used within are follows:
				1.[SPA].[usp_LandingInboundWorkflow_SPA_MUNQQS_ORC_Tactical]  
				2.[SPA].[usp_LandingInboundWorkflow_ObligatedPremium_SPA]

=========================================================================================================	*/
with cte_cede
	as
	(
		select distinct cast(datepart(year, [Inception_Date]) as int) as YOA,
						[Average_QS_%]/100 as Cede
		from Eurobase.[vw_ReInsuranceTreatyContractAttributes]
		where ProgrammeCode = 'Cede 5623'
	)
	
		SELECT 
			'202203'						  as AccountingPeriod,
			t.[TriFocusCode]				  as TrifocusCode,
			[Entity]						  AS Entity,
			t.[YOA]							  AS YOA,
			[TranCurr]						  as SettlementCCY,
			sum([SyndPremiumGIC] * cede.Cede) as [Value],
			'QS'							  as RIPolicyType,
			'Cede 5623'						  as ProgrammeCode
		from [pft].[PFT_SYND_WITH_CEDE] t
			join cte_cede cede on (cede.YOA = t.YOA)
			left join fdm.DimTrifocus tf on (tf.TrifocusCode = t.TrifocusCode)
		where tf.TrifocusName like 'Tracker%'
			and tf.TrifocusName <> 'Tracker SL Fronted'
			and ReviewCycle = '2022Q1'
			and t.Entity = '3623'
		group by [ReviewCycle],
				 t.[TriFocusCode],
				 [Entity],
				 t.[YOA],
				 [TranCurr]
	

GO