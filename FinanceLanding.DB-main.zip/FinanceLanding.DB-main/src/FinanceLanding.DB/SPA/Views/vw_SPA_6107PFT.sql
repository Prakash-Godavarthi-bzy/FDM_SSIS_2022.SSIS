CREATE VIEW [SPA].[VW_SPA_6107PFT] 
AS	

/*============================================================================================
Author		:  Bhargav Entha    <entha.bhargav@beazley.com>
Create Date	:  01/05/2024 - Sprint Q2 Committed version
Description	:  https://beazley.atlassian.net/browse/I1B-5065
				https://beazley.atlassian.net/browse/I1B-5079

				This view created to increase the reusability of this object for datasets ObligatedPremium_SPA and SPA_MUNQQS_ORC_TACTICAL
				View objects used within are follows:
				1.[SPA].[usp_LandingInboundWorkflow_SPA_MUNQQS_ORC_Tactical]  
				2.[SPA].[usp_LandingInboundWorkflow_ObligatedPremium_SPA]


Change Version	: 1.0
Sprint			: 24 Q3 COMMITTED
Author		?   : Venkat.yerravati@Beazley.com || Pushpal Das
CREATE Date	?   : 08/08/20204
Description		: BCL Trifocus for SPA RI Premium & ORC to be assigned to 3623  https://beazley.atlassian.net/browse/I1B-5759
					Used for ObligatedPremium_SPA & SPA_MUNQQS_ORC_TACTICAL

=========================================================================================================	*/
		SELECT  
						

						AccountingPeriod							=(CASE  WHEN RIGHT(t.[ReviewCycle],2)='Q1' THEN CAST(CONCAT(LEFT(t.[ReviewCycle],4),'03') as varchar(6))
																			WHEN RIGHT(t.[ReviewCycle],2)='Q2' THEN CAST(CONCAT(LEFT(t.[ReviewCycle],4),'06') as varchar(6))
																			WHEN RIGHT(t.[ReviewCycle],2)='Q3' THEN CAST(CONCAT(LEFT(t.[ReviewCycle],4),'09') as varchar(6))
																			WHEN RIGHT(t.[ReviewCycle],2)='Q4' THEN CAST(CONCAT(LEFT(t.[ReviewCycle],4),'12') as varchar(6))
												
						  												END
																	   ),
						t.[TriFocusCode]		  					as TrifocusCode,
						isnull(sp.SyndSplitEntity, '3623')			as [Entity], 
						t.[YOA]										as YOA,
						t.[TranCurr]								as SettlementCCY,
						sum([SyndPremiumGIC] * isnull(cast(sp.SyndSplitPercentage as numeric(5, 4)), 1))  as [Value],
						'QS'										as RIPolicyType,
						'Cede 6107'									as ProgrammeCode
		FROM 			[PFT].[PFT_SYND_WITH_CEDE] t
		LEFT JOIN		fdm.DimTrifocus tf on (tf.TrifocusCode = t.TrifocusCode)
		LEFT JOIN		fdm.SyndicateSplitsbyYOA sp on
														(sp.SyndSplitYOA = YOA
														 and not (
														 (tf.TrifocusName like 'BUSA%'
														 or tf.TrifocusName like 'BCL%')
															      and t.YOA >= '2024')
														 and sp.SyndSplitSource = '2623')
		WHERE		 1=1
					and t.Entity = '6107'
		
		GROUP BY	t.[ReviewCycle],
					t.[TriFocusCode],
					isnull(sp.SyndSplitEntity, '3623'),
					t.[YOA],
					t.[TranCurr]
GO


