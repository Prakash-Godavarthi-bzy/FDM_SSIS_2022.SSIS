CREATE view [SPA].[vw_MUNQQS]
AS
/* ===========================================================================================================
	Created By:		Venkat.Yerravati@beazley.com
	Modified By : -
	Created date:	16-02-2024
	Modified Date : 
	Description:	Used for SPA_MUNQQS_ORC_Tactical Dataset
=================================================================================================================== */
SELECT		TriFocus	= RD.triangle_group
							,YOA		= CAST(RD.yoa AS VARCHAR(5))
							,AsAt = cast ( CASE right(RD.ASAT,2) when	'05' then RD.ASAT-2
																when	'11' then  RD.ASAT-2
													         
																else RD.ASAT
												end
											As VARCHAR(20)
										 )
									
							,Entity		= en.ConformedEntityMapping
							,SettlementCCY = RD.CCY
							,[Value]	= SUM([Value])
				--	into #temp
				FROM ADM.[Reserving_data] RD
				LEFT JOIN MDS.ConformedEntityMapping en ON (ISNULL(LTRIM(en.Entity), '') = CAST(ISNULL(LTRIM(RD.synd), '') AS VARCHAR(20)))
				
				WHERE	(right(RD.asat, 2) IN ('05','06','11','12')									-- 05,11 periods will get more completeness of 03,06 Periods
								OR RD.asat = '202003'												-- Specific reason to include 03 instead 05 is due Covid Their is no 05 in 2020
						)																					
						AND RD.special = 'Munich'
						AND RD.datasetname = 'Team Premium'											-- Except assumptionS they not using Pure Premium, Hence Team Premium used
						AND RD.synd <> '8022'
						--and rd.asat= cast( @Asat as int)											--201811 -- Debug mode 
																									-- As this is AsAT data hence we are taking from 201809/201811
						
				
				GROUP BY	RD.triangle_group
							,RD.yoa
							, cast ( case right(RD.ASAT,2) when '05' then RD.ASAT-2
															when '11' then  RD.ASAT-2
															else RD.ASAT
												end
									  as varchar(20)
									)
							
							,en.ConformedEntityMapping
							,RD.CCY
GO


