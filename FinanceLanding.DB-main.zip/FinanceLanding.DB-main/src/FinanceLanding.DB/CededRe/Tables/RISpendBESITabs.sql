﻿CREATE TABLE [CededRe].[RISpendBESITabs](
	[DateOfFact] [date] NULL,
	[YOA] [int] NULL,
	[Value] [numeric](19, 4) NULL,
	[Basis] [varchar](100) NULL,
	[InceptionYear] [int] NULL,
	[Dept] [varchar](100) NULL,
	[Programme] [nvarchar](100) NULL,
	[RIRef] [varchar](255) NULL,
	[Type] [varchar](50) NULL,
	[Type2] [varchar](50) NULL,
	[InceptionDate] [date] NULL,
	[ExpiryDate] [date] NULL,
	[CCY] [varchar](50) NULL,
	[Trifocus] [varchar](255) NULL,
	[AuditSSISExecutionID] [int] NULL,
	[AuditSSISPackageName] [varchar](255) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [varchar](255) NOT NULL,
	[AuditHost] [varchar](255) NOT NULL,
	[Description] [varchar](255) NULL
) ON [PRIMARY]
GO

ALTER TABLE [CededRe].[RISpendBESITabs] ADD  CONSTRAINT [DF_RISpendBESI_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [CededRe].[RISpendBESITabs] ADD  CONSTRAINT [DF_RISpendBESI_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [CededRe].[RISpendBESITabs] ADD  CONSTRAINT [DF_RISpendBESI_AuditHost]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO


