﻿CREATE TABLE [CededRe].[NonSynergyFACProgrammes] (
    [PK_FACProgrammes]     INT           IDENTITY (1, 1) NOT NULL,
    [ProgrammeCode]        VARCHAR (128) NOT NULL,
    [AuditSSISExecutionID] INT           NULL,
    [AuditSSISPackageName] VARCHAR (255) NULL,
    [AuditCreateDateTime]  DATETIME      CONSTRAINT [DF_CededRe_NonSynergyFACPrgogrammes_AuditCreateDateTime] DEFAULT (getutcdate()) NOT NULL,
    [AuditUserCreate]      VARCHAR (255) CONSTRAINT [DF_CededRe_NonSynergyFACPrgogrammes_AuditUserCreate] DEFAULT (suser_sname()) NOT NULL,
    [AuditHost]            VARCHAR (255) CONSTRAINT [DF_CededRe_NonSynergyFACPrgogrammes_AuditHost] DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) NOT NULL,
    [Description]          VARCHAR (255) NULL
);

