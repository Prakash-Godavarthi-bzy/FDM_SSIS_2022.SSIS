﻿CREATE TABLE [CededRe].[RISpendBESI_ORC](
	[InceptionYear] [int] NULL,
	[YOA] [varchar](10) NULL,
	[Dept] [varchar](50) NULL,
	[Programme] [varchar](255) NULL,
	[RIRef] [varchar](255) NULL,
	[Type] [varchar](255) NULL,
	[Type2] [varchar](255) NULL,
	[InceptionDate] [date] NULL,
	[ExpiryDate] [date] NULL,
	[Basis] [varchar](10) NULL,
	[CCY] [varchar](50) NULL,
	[Trifocus] [varchar](255) NULL,
	[Value] [numeric](38, 7) NULL,
	[AccountingPeriod] [varchar](50) NULL,
	[AuditSSISExecutionID] [int] NULL,
	[AuditSSISPackageName] [varchar](255) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [varchar](255) NOT NULL,
	[AuditHost] [varchar](255) NOT NULL,
	[Description] [varchar](255) NULL
) ON [PRIMARY]
GO

ALTER TABLE [CededRe].[RISpendBESI_ORC] ADD  CONSTRAINT [DF_RISpendBESI_ORC_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [CededRe].[RISpendBESI_ORC] ADD  CONSTRAINT [DF_RISpendBESI_ORC_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [CededRe].[RISpendBESI_ORC] ADD  CONSTRAINT [DF_RISpendBESI_ORC_AuditHost]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO
