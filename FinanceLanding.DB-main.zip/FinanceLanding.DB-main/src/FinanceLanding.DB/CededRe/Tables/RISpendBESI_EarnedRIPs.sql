﻿CREATE TABLE [CededRe].[RISpendBESI_EarnedRIPs] (
    [InceptionYear]        INT             NULL,
    [YOA]                  VARCHAR (10)    NULL,
    [Dept]                 VARCHAR (50)    NULL,
    [Programme]            VARCHAR (255)   NULL,
    [RIRef]                VARCHAR (255)   NULL,
    [Type2]                VARCHAR (255)   NULL,
    [InceptionDate]        DATE            NULL,
    [ExpiryDate]           DATE            NULL,
    [Basis]                VARCHAR (10)    NULL,
    [CCY]                  VARCHAR (10)    NULL,
    [Trifocus]             VARCHAR (255)   NULL,
    [Value]                NUMERIC (38, 7) NULL,
    [AccountingPeriod]     VARCHAR (50)    NULL,
    [AuditSSISExecutionID] INT             NULL,
    [AuditSSISPackageName] VARCHAR (255)   NULL,
    [AuditCreateDateTime]  DATETIME        CONSTRAINT [DF_RISpendBESI_EarnedRIPs_AuditCreateDateTime] DEFAULT (getutcdate()) NOT NULL,
    [AuditUserCreate]      VARCHAR (255)   CONSTRAINT [DF_RISpendBESI_EarnedRIPs_AuditUserCreate] DEFAULT (suser_sname()) NOT NULL,
    [AuditHost]            VARCHAR (255)   CONSTRAINT [DF_RISpendBESI_EarnedRIPs_AuditHost] DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) NOT NULL,
    [Description]          VARCHAR (255)   NULL
);

