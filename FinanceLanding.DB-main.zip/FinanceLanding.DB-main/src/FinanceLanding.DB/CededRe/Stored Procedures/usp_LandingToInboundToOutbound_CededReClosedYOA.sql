﻿CREATE PROCEDURE [CededRe].[usp_LandingToInboundToOutbound_CededReClosedYOA] 
             @p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL

AS
-- =============================================
-- Original Author:		Samata Putumbaka <@beazley.com>
-- Create date: 12/10/2021
-- Description:	Original version, used to run in all the periods from 201812 to the current available period. 
--				Will run and catch up if need be (in the case of some downtime when the schedule hasn't run) and will do everything in case of a clear down.

-- Author:		Samata Putumbaka <@beazley.com>
-- Change date: 12/10/2021
-- Description:	Modified to use @DoNonIFRS17_Tests = 0 in FinanceDataContract.Inbound.usp_InboundOutboundWorkflow for performance benefits.

-- =============================================	
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'Ceded_Re_Closed_YOA';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	declare @v_DataSet VARCHAR(255)	= @v_ActivityDatabase
	DECLARE @v_AffectedRows					INT

	DECLARE @v_AccountingPeriod                   INT             = NULL;
	DECLARE @v_AccountingPeriod_Default           INT             = 201809; -- this is our starting date

BEGIN TRY  

	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';



	/* Log the start of the process */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'Load data into Inbound.Transaction and Outbound.Transaction using [CededRe].[usp_LandingToInboundToOutbound_CededReClosedYOA]'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= ''
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;


	-- Get the last processed date for data from the outbound table. 
	-- We'll then process these, so we get all the records for the current month or the last month and process these.
	-- In the case that we're doing day one, we will have zero records in the outbound, so we need to get them all from our default starting date.

	select @v_AccountingPeriod = isnull(convert(int,convert(char(6),convert(date,max(DateOfFact)),112)),@v_AccountingPeriod_Default)
	from [FinanceDataContract].[Outbound].[Transaction]
	where Dataset = @v_DataSet
	
	declare @Dates table(AccountingPeriod int, i int identity(1,1))
	insert into @Dates(AccountingPeriod)
	select distinct convert(varchar(6),rd.proc_period,112) AS AccountingPeriod
	from FinanceLanding.CededRe.CededReAccessDB  rd
	where  
		--isdate(convert(varchar(30),(convert(varchar(30),rd.fk_AccountingPeriod)+'01'),12))=1 -- filter out non dates.
		 convert(varchar(6),rd.proc_period,112) > @v_AccountingPeriod
		-- debug code
		--and rd.fk_AccountingPeriod between 201909 and 202003
	order by AccountingPeriod asc

	--select * from @Dates -- rollback
	--return

	declare @i int = 1

	while exists(select 1 from @Dates where i=@i)
	begin

		set @v_AccountingPeriod = (select AccountingPeriod from @Dates where i=@i)

		select [@v_AccountingPeriod] = @v_AccountingPeriod 

		exec [CededRe].[usp_LandingToInbound_CededReClosedYOA]
			 @p_AccountingPeriod	= @v_AccountingPeriod
            ,@p_ParentActivityLogId	= @p_ParentActivityLogId
			,@p_ActivityJobId       = @p_ActivityJobId    

		print 'EXEC [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow]'
		-- check to see if we've got any inbound data and if so run the inbound to outbound procedures.
		if exists(select 1 from [FinanceDataContract].Inbound.[Transaction] where DataSet = @v_DataSet)
		begin
			--select 'exists'
			exec [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_ReInsuranceExtensions]
			exec [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow] @DoNonIFRS17_Tests = 0
		end
		
		set @i += 1

		-- debug code to do a limited number
		--if @i>1 set @i=1000000
	end


	-- LOG THE RESULT WITH SUCCESS
	SELECT @v_ActivityDateTime			= GETUTCDATE();

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
			 @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStop
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

END TRY

BEGIN CATCH
			        
			-- LOG THE RESULT WITH ERROR

			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

		    THROW;

END CATCH;

					
END

