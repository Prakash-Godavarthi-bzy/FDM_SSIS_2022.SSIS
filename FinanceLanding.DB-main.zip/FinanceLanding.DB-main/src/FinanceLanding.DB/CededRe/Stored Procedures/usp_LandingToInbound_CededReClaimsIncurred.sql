﻿CREATE PROCEDURE  [CededRe].[usp_LandingToInbound_CededReClaimsIncurred]
			 @p_AccountingPeriod			INT 
			,@p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL

AS
-- =============================================
-- LastModified by Author:		Samata Putumbaka <.com>
-- Modified date: 12/10/2021
-- Description:	Original version. Gets Ceded RI ClosedYOA and pushes it into Inbound.Transaction.
--				
--				
-- =============================================	
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @YOA int = YEAR(GETDATE())-3-- we only get data >= this variable
	/*DECLARE @ProcessAccountCodes table(ProcessCode char(2) not null, AccountCode char(7) not null)
	INSERT INTO @ProcessAccountCodes(ProcessCode,AccountCode) 
	VALUES('2A','RISPD01'),('2B','RISPD10')-- we're only interested in this combination
	*/
	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'Ceded_Re_Claims_Incurred';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	DECLARE @ContractType					CHAR(3)			= 'CCI'

	DECLARE @v_Dataset varchar(50)=@v_ActivityDatabase
	DECLARE @v_BatchId                   INT             = NULL;
	DECLARE @v_BatchId_Extensions INT;

BEGIN TRY

	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';

	/* Insert a new batch for ObligatedPremium_RISpend datasource table*/
	INSERT INTO [dbo].[Batch]([CreateDate],[DataSet],[LatestBusinesKey]) 
	VALUES  (GETDATE(),@v_Dataset,@p_AccountingPeriod);

	SELECT @v_BatchId = SCOPE_IDENTITY();

	/* Log the start of the insert */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'Load data into Inbound.Transaction'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'Load data into Inbound.Transaction for Ceded Re Claims Incurred'
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

	declare @OpeningBalanceDate date = '31 December 2018' -- this is the date for the opening balance
	declare @OpeningBalanceCutOffYear int = year(@OpeningBalanceDate) + 1 --- 2019
	declare @OpeningBalanceAllocationPeriod int = year(@OpeningBalanceDate) * 100 + month(@OpeningBalanceDate) -- 201812

		-- constants for constant values.
	declare 
		 @Scenario char(1)				= 'A' 
		,@Basis char(1)					= 'E'
		,@DefaultDate date				= CAST('01-01-1980' as date)
		,@TypeOfBusiness char(1)		= '-'
		,@Location char(1)				= '-'
		,@IsToDate char(1)				= 'Y'
		,@BusinessProcessCode char(2)	= 'T1'
		,@AuditHost varchar(255)		= CAST(SERVERPROPERTY('MachineName') as varchar(255))
		,@StatsCode varchar(25)			= null
		,@DateOfFact date				= convert(date,convert(char(8),@p_AccountingPeriod * 100 + 1),112)
		
--Inception & Expiry Dates
if object_id('tempdb..#dates') is not null drop table #dates

select ri.pfl_cpd_policy_reference PolicyNumber, 
min(rid.fac_period_from) InceptionDate,
max(rid.fac_period_to) ExpiryDate
into #dates
from FinanceLanding.Eurobase.policy_fac_ri ri
join FinanceLanding.Eurobase.policy_fac_ri_details rid 
		 on (rid.fac_number = ri.pfl_fac_number)
group by ri.pfl_cpd_policy_reference

union all

select [RI_Section_Reference],
[Inception_Date],
[Expiry_Date]
from FinanceDataContract.[Outbound].[ReInsuranceTreatyContractAttributes]
where [RowIsLatest] = 1

DROP TABLE IF EXISTS #CededReDB;

SELECT *
INTO #CededReDB
FROM

(
--RI Incurred Dataset
SELECT 
'Ceded_Re_Claims_Incurred' as Dataset,
'CI-LS-' + case ritype when 'FAC' then 'FAC' ELSE 'TTY' end + '-UN' as Account,
proc_period DateOfFact,
ritype RIPolicyType,
synd Entity,
cpl_pol_policy_reference PolicyNumber,
COALESCE(t.DummyProgramme,prg.ifrs17_programme_group, t.programname) ProgrmmeCode,
cla_year_of_account YOA,
clo_claim_currency SettlementCurrency, 
ISNULL(tri.TrifocusCode,'Unknown') Trifocus,
sum(isnull(paidnetbd,0) + isnull(facpaidaccrual,0) + isnull(osaccrualsnetbd,0)) [Value],
isnull(max(d.InceptionDate), '1980-01-01') InceptionDate,
isnull(max(d.ExpiryDate), '1980-01-01') ExpiryDate,
(year(proc_period) * 100 + month(proc_period)) AS AccountingPeriod
FROM CededRe.vw_CededReAccessDB as t
left join FinanceLanding.Eurobase.rein_program_sequence prg on (prg.rps_program_id = t.programname)
left join #dates d on (d.PolicyNumber = cpl_pol_policy_reference)
left join fdm.DimTrifocus as tri ON CASE WHEN t.trifocus ='Covers' THEN 'Covers US'
										 WHEN t.trifocus ='Intl Specialty(PT)' THEN 'Intl Specialty (PT)'
										 WHEN t.trifocus = 'BBR Services Int(Exc PE)' THEN 'BBR Services Int (Exc PE)'
										 ELSE t.trifocus
									END = tri.TrifocusName
where (
isnull(paidnetbd,0) <> 0
or isnull(facpaidaccrual,0) <> 0
or isnull(osaccrualsnetbd,0) <> 0
)
and (year(proc_period) * 100 + month(proc_period)) = @p_AccountingPeriod
--and cpl_pol_policy_reference = 'R0262A01'
group by proc_period,
ritype,
synd,
cpl_pol_policy_reference,
COALESCE(t.DummyProgramme,prg.ifrs17_programme_group, t.programname),
cla_year_of_account,
clo_claim_currency, 
tri.TrifocusCode
) t
	--temporary table for the insert (willbe used to calculate RowHash values before pushing data in the IDC transaction table

	DROP TABLE IF EXISTS #TempInboundTransaction;

    /* Insert the new records from Ceded RI Database sources in the temp table */
	SELECT 
		DateOfFact,
		Account,
		BusinessKey,
		PolicyNumber ,
		InceptionDate,
		ExpiryDate ,
		TrifocusCode ,
		Entity,
		YOA,
		SettlementCCY,
		RIPolicyType,
		ProgrmmeCode,
		--fk_AccountingPeriod,
		[Value] = sum([Value]),
		RowHash = dbo.fn_RowHashForTransactions
		(
			'T'							-- <@RowHashType, char(1),>
			,@Scenario					--,<@Scenario, nvarchar(2000),>
			,[Account]					--,<@Account, nvarchar(2000),>
			,@v_Dataset					--,<@DataSet, nvarchar(2000),>
			,[BusinessKey]				--,<@BusinessKey, nvarchar(2000),>
			,[PolicyNumber]				--,<@PolicyNumber, nvarchar(2000),>
			,[InceptionDate]			--,<@InceptionDate, date,>
			,[ExpiryDate]				--,<@ExpiryDate, date,>
			,@DefaultDate				--,<@BindDate, date,>
			,@DefaultDate				--,<@DueDate, date,>
			,[TrifocusCode]				--,<@TrifocusCode, nvarchar(2000),>
			,[Entity]					--,<@Entity, nvarchar(2000),>
			,[YOA]						--,<@YOA, nvarchar(2000),>
			,@TypeOfBusiness			--,<@TypeOfBusiness, nvarchar(2000),>
			,@StatsCode					--,<@StatsCode, nvarchar(2000),>
			,[SettlementCCY]			--,<@SettlementCCY, nvarchar(2000),>
			,[SettlementCCY]			--,<@OriginalCCY, nvarchar(2000),>
			,@IsToDate					--,<@IsToDate, nvarchar(2000),>
			,@Basis						--,<@Basis, nvarchar(2000),>
			,@Location					--,<@Location, nvarchar(2000),>
			,@BusinessProcessCode		--,<@BusinessProcessCode, nvarchar(2000),>
			,null						--,<@BoundDate, date,>
			,CONCAT
			(
				 case when RIPolicyType is null then '' else (RIPolicyType + '§~§') end
				,case when ProgrmmeCode is null then '' else (ProgrmmeCode + '§~§') end
			)
		)
		INTO #TempInboundTransaction
FROM
	(
		SELECT 
			t.DateOfFact,
			t.Account,
			BusinessKey = 
				rtrim(ltrim(ISNULL(t.Account, '')				)) + '|' + 
				rtrim(ltrim(ISNULL(t.PolicyNumber, '')		)) + '|' + 
				rtrim(ltrim(ISNULL(CAST(t.YOA AS VARCHAR), '')	)) + '|' +
				rtrim(ltrim(ISNULL(t.SettlementCurrency, '')			)) + '|' +
				rtrim(ltrim(ISNULL(t.Entity, '')				)) + '|' +
				rtrim(ltrim(ISNULL(t.Trifocus, '')				)) ,
			PolicyNumber = t.PolicyNumber,
			InceptionDate =  t.InceptionDate ,
			ExpiryDate = t.ExpiryDate,
			TrifocusCode = t.TriFocus,
			t.Entity,
			t.YOA,
			t.SettlementCurrency AS SettlementCCY,
			t.AccountingPeriod,
			t.ProgrmmeCode,
			t.RIPolicyType,
			t.Value 
		FROM #CededReDB t
		) src1
	WHERE
		src1.AccountingPeriod = @p_AccountingPeriod
		-- debug code
		--and src1.BusinessKey = 'P-RP-P-TTY|CLASHBUDGET|2019|USD|2623|697'
	GROUP BY 
        DateOfFact,
		Account,
		BusinessKey,
		PolicyNumber ,
		InceptionDate  ,
		ExpiryDate  ,
		TrifocusCode ,
		Entity,
		YOA,
		SettlementCCY,
		AccountingPeriod,
		RIPolicyType,
		ProgrmmeCode

	SELECT   @v_AffectedRows			= @@ROWCOUNT;
	print convert(varchar,@v_AffectedRows) + ' records in #TempInboundTransaction for ' + convert(varchar,@p_AccountingPeriod)
		
				if object_id('tempdb..#Outbound') is not null drop table #Outbound
				select 
					t.*
					-- extensions
					,e.ProgrammeCode
					,e.RIPolicyType
				into 
					#Outbound
				from 
					FinanceDataContract.Outbound.[Transaction] t
					join FinanceDataContract.Outbound.Transaction_Reinsurance_Extensions_Bridge b on b.RowHash_Transaction = t.RowHash
					join FinanceDataContract.Outbound.Transaction_Reinsurance_Extensions e on e.RowHash_Transaction_Reinsurance_Extensions = b.RowHash_Transaction_Reinsurance_Extensions
				where 
					t.DataSet = @v_DataSet

	-- now I need to do the Reversals.
	-- I get the data from the outbound grouped by the rowhash & check to see that we don't have a related inbound record. These are missing and need to be zero'ed for the current period.
	DROP TABLE IF EXISTS #TempOutboundTransaction;

	SELECT 
		 tot.Account             
		,tot.BusinessKey        
		,tot.PolicyNumber
		,tot.InceptionDate 
		,tot.ExpiryDate 
		,tot.TrifocusCode        
		,tot.Entity              
		,tot.YOA                 
		,tot.SettlementCCY       
		,[FK_Batch]          = MAX(tot.[FK_Batch])
		,tot.RowHash
		,tot.RIPolicyType
		,tot.ProgrammeCode
	INTO 
		#TempOutboundTransaction 
	FROM        
		#Outbound tot
		left join #TempInboundTransaction tite on tot.RowHash = tite.RowHash
	WHERE
		tite.RowHash is null
		and tot.Dataset = @v_Dataset
		and exists(select top 1 1 from #TempInboundTransaction) -- if we have nothing for this period, we don't want to reverse all the data out. This is not likely to happen in production - but in dev & test.
	GROUP BY  
		 tot.Account             
		,tot.BusinessKey        
		,tot.PolicyNumber
		,tot.InceptionDate 
		,tot.ExpiryDate 
		,tot.TrifocusCode        
		,tot.Entity              
		,tot.YOA                 
		,tot.SettlementCCY       
		,tot.RowHash
		,tot.RIPolicyType
		,tot.ProgrammeCode
	HAVING
		SUM(tot.[Value]) <> 0


	SELECT   @v_AffectedRows			= @@ROWCOUNT;
	print convert(varchar,@v_AffectedRows) + ' records in #TempOutboundTransaction for ' + convert(varchar,@p_AccountingPeriod)
	
	---DROP TABLE #transactions_final_agg_cs

	if object_id('tempdb..#transactions_final_agg_cs') is not null drop table #transactions_final_agg_cs

				--return -- gets here in 
				-- create the rowhash for the extensions.
				select distinct
					t.Account,
					t.BusinessKey,
					t.PolicyNumber ,
					t.InceptionDate,
					t.ExpiryDate ,
					t.TrifocusCode ,
					t.Entity,
					t.YOA,
					t.SettlementCCY,
					[Value] = t.[Value],
					t.RIPolicyType,
					ProgrammeCode = t.ProgrmmeCode,
					t.RowHash,
					[RowHash_Transaction_ReInsurance_Extensions] = dbo.fn_RowHashForTransactions
		(
			'E' /* @RowHashType */
			,@Scenario,t.Account,@v_Dataset,t.BusinessKey,t.PolicyNumber,t.InceptionDate,t.ExpiryDate,@DefaultDate,@DefaultDate,t.TrifocusCode,t.Entity,t.YOA,@TypeOfBusiness,@StatsCode,t.SettlementCCY,t.SettlementCCY,@IsToDate,@Basis,@Location
			,null /* @BusinessProcessCode */
			,null /* @BoundDate */
			-- extended columns
			,CONCAT
			(
				 case when t.RIPolicyType is null then '' else (t.RIPolicyType + '§~§') end
				,case when t.ProgrmmeCode is null then '' else (t.ProgrmmeCode + '§~§') end
			)
		)	
		-- I've introduced [DeltaType] here to over-ride the default behaviour in [Inbound].[usp_InboundOutboundWorkflow]
		-- We could have multiple new records and we only want to mark the first one as new, 
		-- the rest need to be marked as adjustments.
					,[DeltaType] = case 
									when o.RowHash is null and t.DateOfFact = tm.DateOfFact then 'New'
									else 'Adjustment' 
									end

				into
					#transactions_final_agg_cs 
					FROM
					#TempInboundTransaction t
					-- to determine what the DeltaType is. It can be either New or Adjustment.
					-- if we've already got data in the outbound, then DeltaType=Adjustment
					left join #Outbound o on o.RowHash = t.RowHash
					-- get the first movement from the #transactions_final_agg - this will be our [DeltaType]=New record.
					join
					(
						select 
							RowHash
							,[DateOfFact] = min([DateOfFact])
						from	
							#TempInboundTransaction
						group by
							RowHash
					) tm
						on tm.RowHash = t.RowHash

		---drop table #TempInboundTransaction
			------/* Delete the current lines from Inbound ... */

				DELETE 				
				FROM    [FinanceDataContract].[Inbound].[Transaction]					
				WHERE   [DataSet] = @v_DataSet

				DELETE [FinanceDataContract].[Inbound].[Transaction_Reinsurance_Extensions_Bridge]
				WHERE [ContractType] = @ContractType

				DELETE [FinanceDataContract].[Inbound].[Transaction_Reinsurance_Extensions]
				WHERE [ContractType] = @ContractType
			
		if not exists(select top 1 1 from #transactions_final_agg_cs)
	begin

		print 'No data in #TempInboundTransaction, exiting as there is nothing to do.'

		-- LOG THE RESULT WITH SUCCESS
		SELECT @v_ActivityDateTime			= GETUTCDATE();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStop
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

		return

	end

			--IF @Trancount = 0 
			BEGIN TRAN;

				-- select * from [dbo].[Batch]
				INSERT INTO [dbo].[Batch]
					([CreateDate],[DataSet],[LatestBusinesKey]) 
				VALUES  
					(GETDATE(),@v_DataSet, NULL);


				SELECT @v_BatchId = SCOPE_IDENTITY();

				INSERT INTO [dbo].[Batch]
					([CreateDate],[DataSet],[LatestBusinesKey]) 
				VALUES  
					(GETDATE(),'ReinsuranceExtensions', NULL);
				

				SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();
				

			/* We insert the rows from temp table in the system */

			
				INSERT INTO  [FinanceDataContract].[Inbound].Transaction_Reinsurance_Extensions_Bridge WITH(TABLOCK)
				(
					 [RowHash_Transaction]
					,[RowHash_Transaction_Reinsurance_Extensions]
					,[ContractType]
					,[FK_Batch]
				)
				SELECT DISTINCT
					 [RowHash]
					,[RowHash_Transaction_Reinsurance_Extensions]
					,@ContractType
					,@v_BatchId_Extensions
				FROM 
					#transactions_final_agg_cs
			
			
				INSERT INTO  [FinanceDataContract].[Inbound].Transaction_Reinsurance_Extensions WITH(TABLOCK)
				(
					[RowHash_Transaction_Reinsurance_Extensions]
					,[RIPolicyType]
					,[ProgrammeCode]
					,[IsLargeLoss]
					,[ContractType]
					,[FK_Batch]
				)
				SELECT DISTINCT
					 [RowHash_Transaction_Reinsurance_Extensions]
					,[RIPolicyType]
					,[ProgrammeCode]
					,NULL
					,@ContractType
					,@v_BatchId_Extensions
				FROM 
					#transactions_final_agg_cs
	
	
			INSERT INTO [FinanceDataContract].[Inbound].[Transaction]  WITH(TABLOCK)
			(
				 [Scenario]
				,[Basis]
				,[Account]
				,[DataSet]
				,[DateOfFact]
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]
				,[DueDate]
				,[TrifocusCode]
				,[Entity]
				,[Location]
				,[YOA]
				,[TypeOfBusiness]
				,[SettlementCCY]
				,[OriginalCCY]
				,[IsToDate]
				,[Value]
				,[ValueOrig]
				,[RowHash]
				,[BusinessProcessCode]
				,[AuditSourceBatchID]
				,[AuditGenerateDateTime]
				,[StatsCode]
				,[FK_Batch]
				,[DeltaType]
			)		
			SELECT  
				 [Scenario]					= @Scenario
				,[Basis]					= @Basis
				,[Account]
				,[DataSet]					= @v_Dataset
				,[DateOfFact]				= @DateOfFact
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]					= @DefaultDate
				,[DueDate]					= @DefaultDate
				,[TrifocusCode]
				,[Entity]
				,[Location]					= @Location
				,[YOA]
				,[TypeOfBusiness]			= @TypeOfBusiness
				,[SettlementCCY]
				,[OriginalCCY]				= [SettlementCCY]
				,[IsToDate]					= @IsToDate
				,[Value]
				,[ValueOrig]				= [Value]
				,[RowHash] 
				,[BusinessProcessCode]		= @BusinessProcessCode
				,[AuditSourceBatchID]		= CAST(@v_BatchId AS VARCHAR (50))                                                 
				,[AuditGenerateDateTime]	= GETUTCDATE()
				,[StatsCode]				= @StatsCode
				,[FK_Batch]					= @v_BatchId
				,[DeltaType]				
			FROM    
				#transactions_final_agg_cs

			UNION ALL

			SELECT  
				 [Scenario]					= @Scenario
				,[Basis]					= @Basis
				,[Account]
				,[DataSet]					= @v_Dataset
				,[DateOfFact]				= @DateOfFact
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]					= @DefaultDate
				,[DueDate]					= @DefaultDate
				,[TrifocusCode]
				,[Entity]
				,[Location]					= @Location
				,[YOA]
				,[TypeOfBusiness]			= @TypeOfBusiness
				,[SettlementCCY]
				,[OriginalCCY]				= [SettlementCCY]
				,[IsToDate]					= @IsToDate
				,[Value]					= 0 
				,[ValueOrig]				= 0
				,[RowHash] 
				,[BusinessProcessCode]		= @BusinessProcessCode
				,[AuditSourceBatchID]		= CAST(@v_BatchId AS VARCHAR (50))                                                 
				,[AuditGenerateDateTime]	= GETUTCDATE()
				,[StatsCode]				= @StatsCode
				,[FK_Batch]											
				,DeltaType					= 'Reversal'
			FROM    
				#TempOutboundTransaction

				--DROP TABLE #transactions_final_agg_cs
			SELECT   @v_AffectedRows			= @@ROWCOUNT;

	
			/* Add the batch to the queue */
				INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,RunDescription
								,[DataSet]
								,OriginalName
								,AuditSourceBatchID
								)
				VALUES
								( @v_BatchId
								 ,'InBound'
								 ,NULL
								 ,@v_DataSet
								 ,NULL
								 ,NULL
								)								
				,
								( @v_BatchId_Extensions
								 ,'InBound'
								 ,'ReinsuranceExtensions, the additional attributes to extend functionality of the transaction table.'
								 ,'ReinsuranceExtensions'
								 ,NULL
								 ,NULL
								);
   	-- LOG THE RESULT WITH SUCCESS
			SELECT @v_ActivityDateTime			= GETUTCDATE();

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStop
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;
					
			IF @Trancount = 0 
				COMMIT;
				
		END TRY

		BEGIN CATCH
	
			-- CANCEL TRAN
			IF @Trancount = 0 AND @@TRANCOUNT <> 0 
				ROLLBACK;
			        
			-- LOG THE RESULT WITH ERROR

			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

		    THROW;

		END CATCH;

					
END