﻿CREATE VIEW [CededRe].[vw_CededReAccessDB]
AS

SELECT [proc_period]
,c.[ritype]
,c.[synd]
,c.[cpl_pol_policy_reference]
,c.[masterriind]
,case when cpl_pol_policy_reference like 'P3040%' then 'KOREAN' else c.[programname] end programname
,c.[clo_fac_page_number]
,c.[cla_year_of_account]
,c.[clo_claim_currency]
,c.[dept]
,c.[trifocus]
,c.[trustfund]
,c.[osaccrualsnetbd]
,c.[facpaidaccrual]
,c.[osbd]
,c.[rsd_lors_code]
,c.[bpt_name]
,c.[paidnetbd]
,c.[paidbd]
,c.[premium]
,c.[overrider]
,c.[Auditcreateddatetime]
,c.[Auitusercreate]
,c.[Audithost]
,d.[Programme] AS DummyProgramme
FROM CededRe.CededReAccessDB C 
LEFT JOIN MDS.DummyProgrammes_CededRe D
ON C.cpl_pol_policy_reference=D.[DummyPolicy]
GO


