﻿CREATE VIEW [CededRe].[vw_CededReAccessDB]
AS
SELECT C.*,D.[Programme] AS DummyProgramme FROM
CededRe.CededReAccessDB C (nolock)
LEFT JOIN MDS.DummyProgrammes_CededRe D 
ON C.cpl_pol_policy_reference=D.[DummyPolicy] and C.programname like '%DUMMY%'

GO