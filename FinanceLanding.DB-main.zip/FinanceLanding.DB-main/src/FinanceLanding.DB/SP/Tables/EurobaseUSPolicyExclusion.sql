﻿CREATE TABLE [sp].[EurobaseUSPolicyExclusion] (
    [UsPolicyRef] NVARCHAR (400) NOT NULL
);

