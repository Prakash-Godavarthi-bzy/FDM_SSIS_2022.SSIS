﻿CREATE TABLE [sp].[TrifocusCode] (
    [PK_Trifocuscode]    INT            IDENTITY (1, 1) NOT NULL,
    [TrifocusCode]       NVARCHAR (255) NOT NULL,
    [IsUSTrifocus]       BIT            NULL,
    [IsKoreanReTrifocus] BIT            NULL,
    [IsSLInternational]  BIT            NULL,
    [TrifocusName]       NVARCHAR (255) NOT NULL,
    [SourceSystem]       NVARCHAR (255) NULL,
    CONSTRAINT [pk_TrifocusCode] PRIMARY KEY CLUSTERED ([TrifocusCode] ASC, [PK_Trifocuscode] ASC, [TrifocusName] ASC)
);



