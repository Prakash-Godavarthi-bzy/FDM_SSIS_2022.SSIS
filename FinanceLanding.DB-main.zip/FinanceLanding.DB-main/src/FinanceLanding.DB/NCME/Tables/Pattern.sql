﻿
CREATE TABLE [NCME].[Pattern](
	[PK_SequenceNumber] [int] IDENTITY(1,1) NOT NULL,
	[SubmissionIdentifier] [nvarchar](11) NOT NULL,
	[PatternQuarter] [int] NOT NULL,
	[ADM_TrifocusGroup] [nvarchar](255) NULL,
	[PercentUnearned] [numeric](29, 16) NULL,
	[Department] [nvarchar](255) NULL,
	[YOA] [int] NULL,
	[InceptionYear] [int] NULL,
	[Entity] [nvarchar](10) NULL,
 CONSTRAINT [PK_Pattern] PRIMARY KEY CLUSTERED 
(
	[PK_SequenceNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO


