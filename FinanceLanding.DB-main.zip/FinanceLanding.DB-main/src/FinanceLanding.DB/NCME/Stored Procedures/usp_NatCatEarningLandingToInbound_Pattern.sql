﻿
CREATE PROCEDURE [NCME].[usp_NatCatEarningLandingToInbound_Pattern]

             @p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL

AS

-- =============================================

-- Last Modified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 25/02/2020
-- Description:	Original version.

-- =============================================	

BEGIN

		SET NOCOUNT ON

		DECLARE @v_ErrorMessage NVARCHAR(4000)

		DECLARE @Trancount INT= @@Trancount;
		DECLARE @v_RC							INT
		DECLARE @v_ActivityLogTag				BIGINT
		DECLARE @v_ActivitySource				SMALLINT
		DECLARE @v_ActivityType					SMALLINT
		DECLARE @v_ActivityStatusStart			SMALLINT
		DECLARE @v_ActivityStatusStop			SMALLINT
		DECLARE @v_ActivityStatusFail			SMALLINT
		DECLARE @v_ActivityHost					VARCHAR(100)
		DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'NatCatEarning'
		DECLARE @v_ActivityName					VARCHAR(100)
		DECLARE @v_ActivityDateTime				DATETIME2(2)
		DECLARE @v_ActivityMessage				NVARCHAR(4000)
		DECLARE @v_ActivityErrorCode			NVARCHAR(50)
		DECLARE @v_ActivityLogIdIn				BIGINT
		DECLARE @v_ActivityLogIdOut				BIGINT
		DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId
		DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL
		DECLARE @v_AffectedRows					INT
		DECLARE @v_BatchId                      INT             = NULL
		DECLARE @v_Asat                         INT             = NULL

		--DECLARE @v_MaxPatternScenarioVersion    INT             = NULL
		DECLARE @v_AuditConcat                  NVARCHAR(4000)

		declare @DataSet varchar(50) = @v_ActivityDatabase

  BEGIN TRY

		SELECT @v_ActivityStatusStart = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'STARTED'

		SELECT @v_ActivityStatusStop = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'SUCCEEDED'

		SELECT @v_ActivityStatusFail = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'ERRORED'




		/* Log the start of the insert */
		SELECT   
			@v_ActivityLogTag		        = NULL
		   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
		   ,@v_ActivityType				    = (SELECT PK_ActivityType	
											   FROM Orchestram.Log.ActivityType	
											   WHERE ActivityType = CASE 
																	WHEN @p_ParentActivityLogId IS NULL 
																		THEN 'Manual process' 
																		ELSE 'Automated process' 
																	END)
		   ,@v_ActivityHost				    = @@SERVERNAME
		   ,@v_ActivityName				    = 'Load NatCatEarning data into Inbound.Pattern'
		   ,@v_ActivityDateTime			    = GETUTCDATE()
		   ,@v_ActivityMessage			 	= NULL
		   ,@v_ActivityErrorCode			= NULL
		   ,@v_AffectedRows				    = 0

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStart
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT

		SELECT @v_ActivityLogTag = @v_ActivityLogIdIn

		
		if object_id('tempdb..#Outbound_Pattern') is not null drop table #Outbound_Pattern
		select distinct PatternScenario,PatternScenarioVersion
		into #Outbound_Pattern
		from [FinanceDataContract].[Outbound].[Pattern] op
		where op.DataSet = @DataSet

		create unique clustered index ix on #Outbound_Pattern(PatternScenarioVersion,PatternScenario)


		DROP TABLE IF EXISTS #TempInboundPattern
		
		select 
			PatternScenario						= convert(char(2),RIGHT(c.SubmissionYear,2)) + 'Q' + convert(char(1),c.SubmissionQuarter)
			,PatternScenarioVersion				= c.SubmissionVersion
			,[DataSet]							= @DataSet
			,m.TriFocusCode
			,YOA								= ISNULL(CAST(p.YOA AS VARCHAR(5)),'NOYOA')
			,p.InceptionYear
			,DevelopmentPercentageIncrement		= -1 * 
												(
													p.PercentUnearned - LAG(p.PercentUnearned, 1, 1.00) OVER 
													(
														PARTITION BY  
															m.TriFocusCode
															,p.[YOA]
															,c.SubmissionIdentifier
															,p.InceptionYear
														ORDER BY     
															CAST(p.PatternQuarter AS INT)
													)
												)
			,DevelopmentQuarter					= p.PatternQuarter 
			,AuditGenerateDateTime              = c.RowCreated 
		into	
			#TempInboundPattern
		from	
			[NCME].[Control] c
			join [NCME].[Mapping] m on m.SubmissionIdentifier = c.SubmissionIdentifier
			join [NCME].[Pattern] p 
				on  p.SubmissionIdentifier = m.SubmissionIdentifier
				and p.ADM_TrifocusGroup = m.ADM_TrifocusGroup
		where
			m.ReportPattern = 'Y'
			-- check to see that we haven't run the data in for the version.
			and not exists
			(
				select 1
				from #Outbound_Pattern op
				where
					op.PatternScenario = convert(char(2),RIGHT(c.SubmissionYear,2)) + 'Q' + convert(char(1),c.SubmissionQuarter)
					and op.PatternScenarioVersion = c.SubmissionVersion
			)


		IF NOT EXISTS (SELECT 1 FROM #TempInboundPattern)

		BEGIN
			
			select 'no data, will exit'

			-- LOGIN THE RESULT WITH SUCCESS
			SELECT @v_ActivityDateTime			= GETUTCDATE()

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					@p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStop
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT

			RETURN
		END


		IF @Trancount = 0 
		BEGIN	TRAN

		/* Insert a new batch for NatCatEarning datasource table*/
		INSERT INTO [dbo].[Batch]([CreateDate],[DataSet],[LatestBusinesKey]) VALUES  (GETDATE(),@DataSet, NULL)	
		SELECT @v_BatchId = SCOPE_IDENTITY()


		/* Delete the current lines of the NatCatEarning source system from Inbound ... */
		DELETE 					
		FROM    FinanceDataContract.Inbound.[Pattern]					
		WHERE   [DataSet] = @DataSet


		INSERT INTO [FinanceDataContract].[Inbound].[Pattern] WITH(TABLOCK)
				([PatternScenario]             
				,[PatternScenarioVersion]      
				,[PatternKey]                    
				,[DataSet]                         
				,[TrifocusCode]  
				,[YOA]
				,[InceptionYear]
				,[SettlementCCY]
				,[DevelopmentPercentageIncrement]                   
				,[DevelopmentQuarter]        
				,[AuditSourceBatchID]
				,[AuditHost]
				,[AuditGenerateDateTime]
				,[FK_Batch]
				,BusinessProcessCode 
				)		
			  
		SELECT   [PatternScenario]             
				,[PatternScenarioVersion]      
				,[PatternKey]						= 'C-GC-NE'  
				,[DataSet]                        
				,[TrifocusCode] 
				,[YOA]
				,[InceptionYear]
				,[SettlementCCY]					= 'UNK'
				,[DevelopmentPercentageIncrement]                     
				,[DevelopmentQuarter]        
				,[AuditSourceBatchID]				= CAST(@v_BatchId AS VARCHAR (50))
				,[AuditHost]						= CAST(SERVERPROPERTY('MachineName') AS VARCHAR(255))
				,[AuditGenerateDateTime]
				,[FK_Batch]							= @v_BatchId
				,BusinessProcessCode				= 'T1'
						   
		FROM    #TempInboundPattern

		WHERE   DevelopmentPercentageIncrement <> 0

		SELECT   @v_AffectedRows			= @@ROWCOUNT
	
		/* Add the batch to the queue */
		IF @v_BatchId IS NOT NULL

			INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
						( Pk_Batch
						,[Status]
						,[DataSet]
						,RunDescription
						,OriginalName
						)
			VALUES
						(@v_BatchId
						,'InBound'
						,@DataSet
						,'Pattern'
						,NULL
						);
      

		-- LOGIN THE RESULT WITH SUCCESS
		SELECT @v_ActivityDateTime			= GETUTCDATE()

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				@p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStop
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT

		IF @Trancount = 0
        COMMIT;

	END TRY

	BEGIN CATCH
	
		-- CANCEL TRAN
		IF @Trancount = 0 AND @@TRANCOUNT <> 0 
			ROLLBACK;
			        
		-- LOGIN THE RESULT WITH ERROR

		SELECT   @v_ActivityDateTime				= GETUTCDATE()
				,@v_ActivityLogTag					= @v_ActivityLogIdIn
				,@v_ActivityMessage					= ERROR_MESSAGE()
				,@v_ActivityErrorCode				= ERROR_NUMBER()

		EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					@p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusFail
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT	;


		THROW;

	END CATCH

					
END
GO



--exec [NCME].[usp_NatCatEarningLandingToInbound_Pattern]
--GO

--exec [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_Pattern] 
--GO



-- rollback