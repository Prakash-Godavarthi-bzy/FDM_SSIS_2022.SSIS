﻿

CREATE PROCEDURE [NCME].[usp_Control_Insert]
			 @SubmissionYear nvarchar(100)
			,@SubmissionQuarter nvarchar(100)
			,@FileValidatedBy nvarchar(255)
			,@Notes nvarchar(255)
			,@FileName nvarchar(1000)
AS
-- =============================================


-- Modified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 25/02/2021
-- Description:	Original version. Inserts a row into [NCME].[Control] and takes care of the version logic. 
--				Returns a recordset with the [SubmissionIdentifier] as a single row and column used by SSIS.

-- Modified by:		Lakshman.Akasapu@beazley.com
-- Modified date: 07/06/2024
-- Description:	 Added AffectedRows,it returns a recordset [p_SubmissionIdentifier] along with [p_AffectedRows] as a single row and these two columns used by SSIS.

-- =============================================	
BEGIN

	SET NOCOUNT ON;
	
	declare @SubmissionVersion int = 1;
	declare @SubmissionIdentifier Varchar(50),@AffectedRows int;


	BEGIN TRY

		if exists
		(
			select 1 
			from 
				[NCME].[Control] 
			where 
				[SubmissionYear] = convert(int, @SubmissionYear)
				and [SubmissionQuarter] = convert(int, @SubmissionQuarter)
		)
		begin
			set @SubmissionVersion = 
			(
				select max(SubmissionVersion) + 1
				from 
					[NCME].[Control] 
				where 
					[SubmissionYear] = convert(int, @SubmissionYear)
					and [SubmissionQuarter] = convert(int, @SubmissionQuarter)
				group by 
					[SubmissionYear] 
					,[SubmissionQuarter]
			)
		end

		begin tran

		insert into [NCME].[Control]
		(
			[SubmissionYear]
			,[SubmissionQuarter]
			,[SubmissionVersion]
			,[FileValidatedBy]
			,[Notes]
			,[FileName]
		)
		values
		(
			@SubmissionYear
			,@SubmissionQuarter
			,@SubmissionVersion
			,@FileValidatedBy
			,@Notes
			,@FileName
		)

		select @AffectedRows = @@ROWCOUNT;

		declare @identity int = scope_identity()

		select  @SubmissionIdentifier = [SubmissionIdentifier]
		from [NCME].[Control]
		where [PK_SequenceNumber] = @identity

		select @SubmissionIdentifier as p_SubmissionIdentifier,@AffectedRows as p_AffectedRows

		commit

	END TRY

	BEGIN CATCH
		
		if @@TRANCOUNT<>0 rollback;
		THROW;

	END CATCH;
					
END

GO



