﻿CREATE TABLE [BICIRI].[LandingBICIRI_ORC_Tactical](
	[InceptionYear] [int] NULL,
	[YOA] [varchar](10) NULL,
	[Dept] [varchar](50) NULL,
	[Programme] [varchar](255) NULL,
	[RIRef] [varchar](255) NULL,
	[Type] [varchar](255) NULL,
	[Type2] [varchar](255) NULL,
	[InceptionDate] [date] NULL,
	[ExpiryDate] [date] NULL,
	[Basis] [varchar](10) NULL,
	[CCY] [varchar](10) NULL,
	[Trifocus] [varchar](255) NULL,
	[Value] [numeric](38, 7) NULL,
	[AccountingPeriod] [varchar](50) NULL
) ON [PRIMARY]
GO