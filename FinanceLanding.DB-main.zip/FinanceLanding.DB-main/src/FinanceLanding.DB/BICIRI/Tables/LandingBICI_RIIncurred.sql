﻿CREATE TABLE [BICIRI].[LandingBICI_RIIncurred](
	[PK_Transaction] [bigint] IDENTITY(1,1) NOT NULL,
	[Scenario] [varchar](1) NOT NULL,
	[Account] [varchar](14) NOT NULL,
	[Dataset] [varchar](50) NOT NULL,
	[DateOfFact] [datetime] NOT NULL,
	[BusinessKey] [varchar](255) NOT NULL,
	[PolicyNumber] [varchar](255) NOT NULL,
	[InceptionDate] [datetime] NOT NULL,
	[ExpiryDate] [datetime] NOT NULL,
	[BindDate] [datetime] NULL,
	[DueDate] [datetime] NULL,
	[TrifocusCode] [varchar](50) NULL,
	[Entity] [varchar](25) NOT NULL,
	[YOA] [varchar](5) NOT NULL,
	[TypeOfBusiness] [varchar](1) NULL,
	[StatsCode] [varchar](50) NULL,
	[SettlementCCY] [varchar](3) NULL,
	[OriginalCCY] [varchar](3) NULL,
	[IsToDate] [varchar](1) NOT NULL,
	[Value] [numeric](19, 4) NOT NULL,
	[RowHash] [varchar](255) NOT NULL,
	[FK_Allocation] [varchar](10) NULL,
	[DeltaType] [varchar](50) NULL,
	[AuditSourceBatchID] [varchar](255) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditGenerateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL,
	[AuditHost] [nvarchar](255) NOT NULL,
	[Basis] [varchar](2) NOT NULL,
	[Location] [varchar](100) NOT NULL,
	[ValueOrig] [numeric](19, 4) NOT NULL,
	[BusinessProcessCode] [varchar](255) NULL,
	[FK_Batch] [varchar](10) NULL,
	[BoundDate] [varchar](100) NULL,
	[RIPolicyType] [varchar](50) NULL,
	[ProgrammeCode] [varchar](100) NULL,
	[ExcelRowHash] [varchar](255) NOT NULL,
	[RunNumber] [varchar](20) NULL,
	[SourceFileName] [varchar](255) NULL
) ON [PRIMARY]
GO

ALTER TABLE [BICIRI].[LandingBICI_RIIncurred] ADD  CONSTRAINT [DF_BICI_RIIncurred_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [BICIRI].[LandingBICI_RIIncurred] ADD  CONSTRAINT [DF_BICI_RIIncurred_AuditGenerateDateTime]  DEFAULT (getdate()) FOR [AuditGenerateDateTime]
GO

ALTER TABLE [BICIRI].[LandingBICI_RIIncurred] ADD  CONSTRAINT [DF_BICI_RIIncurred_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [BICIRI].[LandingBICI_RIIncurred] ADD  CONSTRAINT [DF_BICI_RIIncurred_AuditHost]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO