﻿CREATE TABLE [biciri].[LandedTransformed_Ultimates](
	[PK_Transaction] [bigint] NULL,
	[Scenario] [varchar](2) NULL,
	[Account] [varchar](50) NULL,
	[Dataset] [varchar](255) NULL,
	[DateOfFact] [datetime] NULL,
	[BusinessKey] [varchar](255) NULL,
	[PolicyNumber] [varchar](255) NULL,
	[InceptionDate] [datetime] NULL,
	[ExpiryDate] [datetime] NULL,
	[BindDate] [datetime] NULL,
	[DueDate] [datetime] NULL,
	[TrifocusCode] [varchar](255) NULL,
	[Entity] [varchar](25) NULL,
	[YOA] [varchar](5) NULL,
	[TypeOfBusiness] [varchar](1) NULL,
	[StatsCode] [varchar](25) NULL,
	[SettlementCCY] [varchar](3) NULL,
	[OriginalCCY] [varchar](3) NULL,
	[IsToDate] [varchar](1) NULL,
	[Value] [numeric](19, 4) NULL,
	[RowHash] [varbinary](255) NULL,
	[FK_Allocation] [int] NULL,
	[DeltaType] [varchar](50) NULL,
	[AuditSourceBatchID] [varchar](255) NULL,
	[AuditCreateDateTime] [datetime] NULL,
	[AuditGenerateDateTime] [datetime] NULL,
	[AuditUserCreate] [varchar](255) NULL,
	[AuditHost] [varchar](255) NULL,
	[Basis] [varchar](2) NULL,
	[Location] [varchar](100) NULL,
	[ValueOrig] [numeric](19, 4) NULL,
	[BusinessProcessCode] [varchar](255) NULL,
	[FK_Batch] [int] NULL,
	[BoundDate] [datetime2](7) NULL,
	[RIPolicyType] [varchar](50) NULL,
	[ProgrammeCode] [varchar](255) NULL
) ON [PRIMARY]
GO
ALTER TABLE [BICIRI].[LandedTransformed_Ultimates] ADD  CONSTRAINT [DF_BICI_RI_Transformed_Ultimates_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [BICIRI].[LandedTransformed_Ultimates] ADD  CONSTRAINT [DF_BICI_RI_Transformed_Ultimates_AuditGenerateDateTime]  DEFAULT (getdate()) FOR [AuditGenerateDateTime]
GO

ALTER TABLE [BICIRI].[LandedTransformed_Ultimates] ADD  CONSTRAINT [DF_BICI_RI_Transformed_Ultimates_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [BICIRI].[LandedTransformed_Ultimates] ADD  CONSTRAINT [DF_BICI_RI_Transformed_Ultimates_AuditHost]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO
