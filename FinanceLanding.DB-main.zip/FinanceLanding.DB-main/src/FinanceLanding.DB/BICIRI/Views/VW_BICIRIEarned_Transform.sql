﻿CREATE VIEW [BICIRI].[VW_BICIRIEarned_Transform]
AS 


-- USed this as source in IFRS17_BICIRI_EarnedPremium.dtsx populate into [BICIRI].[EarnedPremium]
-- table [BICIRI].[EarnedPremium] utilised in view [BICIRI].[vw_LandedTransformed_Ultimates]
--Ultimately [BICIRI].[vw_LandedTransformed_Ultimates] used in different vw_/datasets directly/Indirectly
--More details please check it https://beazley.atlassian.net/browse/I1B-3623

--DECLARE 
--		 @Scenario char(1)				= 'F' 
--		,@Basis char(1)					= 'E'
--		,@PolicyNumber char(8)			= 'NOPOLICY'
--		,@DefaultDate date				= CAST('01-01-1980' as date)
--		,@TypeOfBusiness char(1)		= '-'
--		,@Location char(1)				= '-'
--		,@IsToDate char(1)				= 'Y'
--		,@BusinessProcessCode char(2)	= 'T1'
--		,@AuditHost varchar(255)		= CAST(SERVERPROPERTY('MachineName') as varchar(255))
--		,@StatsCode varchar(25)			= null
--		,@Entity varchar(25)			='USBICI'
--		DECLARE @v_Dataset						varchar(50)		='BICI_Earned_Agresso'
		
		
--		,@DefaultGetdate datetime		= CAST(GETUTCDATE() AS datetime)
--		,@v_BatchId						INT             = NULL;
--IF object_id(N'tempdb..#TempPolType') IS NOT NULL
--	DROP TABLE #TempPolType

WITH TempPolType_CTE1
as
(
SELECT DISTINCT PolicyNo
	,
	--PolicyDescription, 
	CASE 
		WHEN PolicyDescription LIKE '%xs%'
			THEN 'XL'
		WHEN PolicyDescription LIKE '%Excess%'
			THEN 'XL'
		WHEN PolicyDescription LIKE '%XOL%'
			THEN 'XL'
		WHEN PolicyDescription LIKE '%Stop Loss%'
			THEN 'XL'
		WHEN PolicyNo LIKE '%XL%'
			THEN 'XL'
		WHEN PolicyDescription LIKE '%Marine Group%'
			THEN 'XL'
		WHEN PolicyNo LIKE 'SPG__EPL%'
			THEN 'XL'
		WHEN PolicyNo LIKE 'CPG%'
			THEN 'XL'
		WHEN PolicyDescription LIKE '%Quota Share%'
			THEN 'QS'
		WHEN PolicyNo LIKE '%QS%'
			THEN 'QS'
		WHEN PolicyDescription LIKE '% QS %'
			THEN 'QS'
		WHEN PolicyDescription LIKE '%Surplus%'
			THEN 'QS'
		WHEN PolicyDescription LIKE '%Master RI%'
			THEN 'QS'
		WHEN PolicyDescription LIKE '%Master Reinsurance%'
			THEN 'QS'
		WHEN PolicyDescription LIKE '%BBR Services%'
			THEN 'QS'
		WHEN PolicyNo LIKE 'CPAFB%'
			THEN 'QS'
		WHEN PolicyNo LIKE 'ENGCTL%'
			THEN 'QS'
		WHEN PolicyNo LIKE 'ENGTAF%'
			THEN 'QS'
		WHEN PolicyNo LIKE 'RICPBM%'
			THEN 'QS'
		WHEN PolicyNo LIKE 'BNP%'
			THEN 'FAC'
		WHEN PolicyNo LIKE 'RIUNIR'
			THEN 'FAC'
		WHEN PolicyNo LIKE 'CDM%'
			THEN 'FAC'
		WHEN PolicyNo LIKE 'DEW%'
			THEN 'FAC'
		WHEN PolicyNo LIKE 'IBI%'
			THEN 'FAC'
		WHEN PolicyNo LIKE 'STANTEC%'
			THEN 'FAC'
		WHEN PolicyDescription LIKE 'Specialty FAC%'
			THEN 'FAC'
		WHEN PolicyDescription LIKE '% FAC %'
			THEN 'FAC'
		WHEN PolicyNo LIKE '%FAC%'
			THEN 'FAC'
		WHEN PolicyNo LIKE 'V%'
			THEN 'FAC'
		WHEN PolicyDescription LIKE '%Loss Portfolio Transfer Reinsurance Agreement%'
			THEN 'QS'
		WHEN PolicyDescription LIKE '%BICI/Globe Reinsurance Agreement%'
			THEN 'QS' --ASK
		ELSE NULL
		END AS RIPolicyType																	-- Transformations provided by Pushpal Das
	,CASE 
		WHEN PolicyNo LIKE 'AHG__XL%'
			THEN 'Life & Accident Cat'
		WHEN PolicyNo LIKE 'BICISLRXA%'
			THEN 'BICI Risk & Agg XL'
		WHEN PolicyNo LIKE 'BNP%'
			THEN 'SL Facultative spend'
		WHEN PolicyNo LIKE 'CDM%'
			THEN 'SL Facultative spend'
		WHEN PolicyNo LIKE 'CP_XOL%'
			THEN 'Property XL'
		WHEN PolicyNo LIKE 'CPXOL%'
			THEN 'Property XL' --
		WHEN PolicyNo LIKE 'CPAFB%'
			THEN 'BICCPF' --
		WHEN PolicyNo LIKE 'CPF%'
			THEN 'Property FAC'
		WHEN PolicyNo LIKE 'CPG%'
			AND PolicyNo LIKE '%PRX%'
			THEN 'PRXS' ----Changed 06/04
		WHEN PolicyNo LIKE 'CPG%'
			THEN 'Property Cat XL'
		WHEN PolicyNo LIKE 'CPQS%'
			AND PolicyDescription LIKE 'Commercial Property Quota Share Treaty%'
			THEN 'BFS QS' --
		WHEN PolicyNo LIKE 'DEW%'
			THEN 'SL Facultative spend'
		WHEN PolicyNo LIKE 'EMEPL%'
			THEN 'BICI Internal QS' --'EMBEDDED EPL BICI INTERNAL QS' --internal for BICI
		WHEN PolicyNo LIKE 'ENGF%'
			THEN 'Marine Facultative Spend'
		WHEN PolicyNo LIKE 'ENGG%'
			AND PolicyNo LIKE '%XL%'
			THEN 'MORTAR - Engineering Risk Xs'
		WHEN PolicyNo LIKE 'ENGTR%'
			AND PolicyNo LIKE '%QS%'
			THEN 'Engineering Terrorism QS'
		WHEN PolicyNo LIKE 'ENGCTL%'
			THEN 'Internal QS  - Engineering'
		WHEN PolicyNo LIKE 'ENGTAF%'
			THEN 'Internal QS  - Engineering'
		WHEN PolicyNo LIKE 'ENG%'
			AND PolicyNo LIKE '%QS%'
			AND PolicyDescription LIKE '%Internal%'
			THEN 'Internal QS  - Engineering'
		WHEN PolicyNo LIKE 'ENG%'
			AND PolicyNo LIKE '%QS%'
			THEN 'Engineering Quota Share'
		WHEN PolicyNo LIKE 'IBI%'
			THEN 'SL Facultative spend'
		WHEN PolicyNo LIKE 'INTFALQS%'
			THEN 'Internal QS - Marine Falvey'
		WHEN PolicyNo LIKE 'INTMARQS%'
			THEN 'Internal QS  - Marine Non Falvey'
		WHEN PolicyNo LIKE 'INTPOLQS%'
			THEN 'Internal QS  - Political Risks'
		WHEN PolicyNo LIKE 'MARFALQS%'
			THEN 'Internal QS - Marine Falvey'
		WHEN PolicyNo LIKE 'MARCHLQS%'
			THEN 'Internal QS  - Marine Non Falvey'
		WHEN PolicyNo LIKE 'MARG%'
			AND PolicyNo LIKE '%CGOA%'
			THEN 'MARGEN' --Changed 06/04
		WHEN PolicyNo LIKE 'MARG%'
			AND PolicyNo LIKE '%CGOB%'
			THEN 'MARGEN' --Changed 06/04
		WHEN PolicyNo LIKE 'MARG%'
			AND PolicyNo LIKE '%CGO%'
			THEN 'Marine XL' --Changed 06/04
		WHEN PolicyNo LIKE 'MARG%'
			AND PolicyNo LIKE '%GEN%'
			THEN 'MARGEN'
		WHEN PolicyNo LIKE 'MARG%'
			AND PolicyNo LIKE '%GEX%'
			THEN 'MARGEX'
		WHEN PolicyNo LIKE 'MARG%'
			AND PolicyNo LIKE '%RPP%'
			THEN 'MARRPP'
		WHEN PolicyNo LIKE 'MARG%'
			THEN 'Marine XL'
		WHEN PolicyNo LIKE 'MARQS%'
			THEN 'Internal QS  - Marine Non Falvey' --'Internal QS - Marine Falvey' Changed 06/04
		WHEN PolicyNo LIKE 'MAR__FAC%'
			THEN 'Internal QS' --'Marine Facultative Spend' Changed 06/04
		WHEN PolicyNo LIKE 'MSTRI%'
			THEN 'Master RI'
		WHEN PolicyNo LIKE 'PCGCPRQS%'
			THEN 'Internal QS  - Political Risks' --'MINIMU - Political Risks QS' --internal for BICI 
		WHEN PolicyNo LIKE 'PCGG__XLCPR%'
			THEN 'TALK - Political Risks XL'
		WHEN PolicyNo LIKE 'RICPBM%'
			THEN 'US Boiler & Machinery'
		WHEN PolicyNo LIKE 'RIUNIR'
			THEN 'SL Facultative spend' --
		WHEN PolicyNo LIKE 'SPAELAW%'
			AND PolicyNo LIKE '%QS%'
			THEN 'A&E Lawyers QS'
		WHEN PolicyNo LIKE 'SPCUNAQS%'
			THEN 'CUNA QS'
		WHEN PolicyNo LIKE 'SPCYB%QS%'
			THEN 'Cyber QS'
		WHEN PolicyNo LIKE 'SPEXTCYBER%'
			THEN 'Cyber QS'
		WHEN PolicyNo LIKE 'SPDOQS%'
			THEN 'SWORD D&O'
		WHEN PolicyNo LIKE 'SPEXT%'
			AND PolicyNo LIKE '%ENV%'
			THEN 'Environmental QS'
		WHEN PolicyNo LIKE 'SPEXT%'
			AND PolicyNo LIKE '%SUR%'
			THEN 'MUNICH - Surplus'
		WHEN PolicyNo LIKE 'SPEXT%'
			AND PolicyNo LIKE '%QS%'
			THEN 'MUNQQS'
		WHEN PolicyNo LIKE 'SPEXT%'
			AND PolicyNo LIKE '%BBR%'
			THEN 'MUNQQS'
		WHEN PolicyNo LIKE 'SPG__LAG%'
			THEN 'Lawyers Risk Excess'
		WHEN PolicyNo LIKE 'SPINTXOL%'
			THEN 'BICI Risk & Agg XL'
		WHEN PolicyNo LIKE 'SPLAWQS%'
			THEN 'Lawyers QS'
		WHEN PolicyNo LIKE 'SPG__CL%'
			THEN 'Systemic cover - Clash'
		WHEN PolicyNo LIKE 'SPG__PETMB%'
			THEN 'US Small Risks XL'
		WHEN PolicyNo LIKE 'SPG__PROF%'
			AND YOA < '2015'
			THEN 'Professions Agg XL'
		WHEN PolicyNo LIKE 'SPG__PROF%'
			AND YOA >= '2015'
			THEN 'Professions'
		WHEN PolicyNo LIKE 'SPG__EPL%'
			THEN 'EPL Risk Excess'
		WHEN PolicyNo LIKE 'SPG__CFE%'
			THEN 'COFFEE'
		WHEN PolicyNo LIKE 'SPOCCQS%'
			THEN 'Occurrence QS'
		WHEN PolicyNo LIKE 'SPQS%'
			THEN 'BICI Internal QS'
		WHEN PolicyNo LIKE 'SPSUR%'
			THEN 'BICI Internal QS'
		WHEN PolicyNo LIKE 'STANTEC%'
			THEN 'SL Facultative spend'
		WHEN PolicyNo LIKE 'TERG__SA%'
			THEN 'Terrorism XLs'
		WHEN PolicyNo LIKE 'WTHQS%'
			THEN 'BICI Internal QS' --'Weather Contingency QS & Surplus' --internal for BICI	 
		WHEN PolicyNo LIKE 'WTHSUR%'
			THEN 'BICI Internal QS' --'Weather Contingency QS & Surplus' --internal for BICI	 
		WHEN PolicyDescription LIKE '%Master RI%'
			THEN 'Master RI'
		WHEN PolicyDescription LIKE '%Loss Portfolio Transfer Reinsurance Agreement%'
			THEN 'PORTFOLIO TRANSFER BICI TO CAPTIVE RI'
		WHEN PolicyDescription LIKE '%BICI/Globe Reinsurance Agreement%'
			THEN 'GLOBE'
		WHEN PolicyDescription LIKE 'Specialty FAC%'
			THEN 'SL Facultative spend'
		WHEN PolicyDescription LIKE '% FAC %'
			THEN 'SL Facultative spend'
		WHEN PolicyNo LIKE '%FAC%'
			THEN 'SL Facultative spend' --
		WHEN PolicyNo LIKE 'V%'
			THEN 'SL Facultative spend'
		ELSE NULL
		END AS Programme
--INTO #TempPolType

FROM [Agresso].[BICIRI_EarnedPremium] t
LEFT JOIN Eurobase.reinsurance_pol_det pol ON (pol.rpd_policy_reference = t.PolicyNo)
WHERE pol.rpd_policy_reference IS NULL
	AND PolicyNo NOT IN (
		''
		,'NO POLICY'
		)
	
)
,
--IF object_id(N'tempdb..#TempBICICRIEarn') IS NOT NULL
--	DROP TABLE #TempBICICRIEarn

TempBICICRIEarn_CTE2
AS
(
SELECT cast(CASE 
			WHEN right(t.AccountingPeriod, 2) IN (
					'01'
					,'02'
					)
				THEN left(t.AccountingPeriod, 4) + '03'
			WHEN right(t.AccountingPeriod, 2) IN (
					'04'
					,'05'
					)
				THEN left(t.AccountingPeriod, 4) + '06'
			WHEN right(t.AccountingPeriod, 2) IN (
					'07'
					,'08'
					)
				THEN left(t.AccountingPeriod, 4) + '09'
			WHEN right(t.AccountingPeriod, 2) IN (
					'10'
					,'11'
					)
				THEN left(t.AccountingPeriod, 4) + '12'
			ELSE t.AccountingPeriod
			END + '01' AS DATE) AS DateOfFact
	,t.TrifocusCode As TrifocusCode
	,t.YOA as YOA
	,IsNUll(t.CCY,'USD') as CCY
	,sum(cast(Amount AS NUMERIC(30, 4))) AS [Value]
	,sum(cast(t.Amount AS NUMERIC(30, 4))) AS [ValueOrig]
	,CASE 
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			AND right(Account, 2) = '00'
			THEN 'BICI_HISTORICAL'
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			THEN 'BICI Internal QS'
		WHEN isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN')) NOT LIKE '%Internal%'
			AND isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN')) NOT IN (
				'BICI Risk & Agg XL'
				,'PORTFOLIO TRANSFER BICI TO CAPTIVE RI'
				)
			AND right(Account, 2) <> '00'
			THEN 'BICI Internal QS'
		ELSE isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN'))
		END AS ProgrammeCode
	,CASE 
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			THEN 'UNK'
		ELSE isnull(tmp.RIPolicyType, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'FAC'
						WHEN tty.[rpd_rein_policy_type] IN (
								'SL'
								,'RE'
								)
							THEN 'XL'
						ELSE tty.[rpd_rein_policy_type]
						END, 'UNKNOWN'))
		END AS RIPolicyType
	,t.UWProd as UWProd

--INTO #TempBICICRIEarn


FROM [Agresso].[BICIRI_EarnedPremium] t
LEFT JOIN Eurobase.reinsurance_pol_det tty ON (tty.rpd_policy_reference = t.PolicyNo)
LEFT JOIN Eurobase.rein_program_sequence prg ON (prg.rps_program_id = tty.rpd_treaty_ri_code)
--LEFT JOIN #TempPolType tmp ON (tmp.PolicyNo = t.PolicyNo)
LEFT JOIN TempPolType_CTE1 tmp ON (tmp.PolicyNo = t.PolicyNo)
GROUP BY cast(CASE 
			WHEN right(t.AccountingPeriod, 2) IN (
					'01'
					,'02'
					)
				THEN left(t.AccountingPeriod, 4) + '03'
			WHEN right(t.AccountingPeriod, 2) IN (
					'04'
					,'05'
					)
				THEN left(t.AccountingPeriod, 4) + '06'
			WHEN right(t.AccountingPeriod, 2) IN (
					'07'
					,'08'
					)
				THEN left(t.AccountingPeriod, 4) + '09'
			WHEN right(t.AccountingPeriod, 2) IN (
					'10'
					,'11'
					)
				THEN left(t.AccountingPeriod, 4) + '12'
			ELSE t.AccountingPeriod
			END + '01' AS DATE)
	,t.TrifocusCode
	,t.YOA
	,IsNUll(t.CCY,'USD')
	,UWProd
	,CASE 
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			AND right(Account, 2) = '00'
			THEN 'BICI_HISTORICAL'
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			THEN 'BICI Internal QS'
		WHEN isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN')) NOT LIKE '%Internal%'
			AND isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN')) NOT IN (
				'BICI Risk & Agg XL'
				,'PORTFOLIO TRANSFER BICI TO CAPTIVE RI'
				)
			AND right(Account, 2) <> '00'
			THEN 'BICI Internal QS'
		ELSE isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN'))
		END
	,CASE 
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			THEN 'UNK'
		ELSE isnull(tmp.RIPolicyType, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'FAC'
						WHEN tty.[rpd_rein_policy_type] IN (
								'SL'
								,'RE'
								)
							THEN 'XL'
						ELSE tty.[rpd_rein_policy_type]
						END, 'UNKNOWN'))
		END

UNION ALL

SELECT CASE WHEN ISDATE(CAST(d.AccountingPeriod+'01'AS varchar))=1 THEN cast(d.AccountingPeriod + '01' AS DATE) 
		ELSE NULL
		END
	,t.TrifocusCode
	,t.YOA
	,IsNUll(t.CCY,'USD')as CCY
	,0 AS [Value]
	,0 AS [ValueOrig]
	,CASE 
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			AND right(Account, 2) = '00'
			THEN 'BICI_HISTORICAL'
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			THEN 'BICI Internal QS'
		WHEN isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN')) NOT LIKE '%Internal%'
			AND isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN')) NOT IN (
				'BICI Risk & Agg XL'
				,'PORTFOLIO TRANSFER BICI TO CAPTIVE RI'
				)
			AND right(Account, 2) <> '00'
			THEN 'BICI Internal QS'
		ELSE isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN'))
		END AS ProgrammeCode
	,CASE 
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			THEN 'UNK'
		ELSE isnull(tmp.RIPolicyType, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'FAC'
						WHEN tty.[rpd_rein_policy_type] IN (
								'SL'
								,'RE'
								)
							THEN 'XL'
						ELSE tty.[rpd_rein_policy_type]
						END, 'UNKNOWN'))
		END AS RIPolicyType
	,t.UWProd

--from Testing.agresso.BICI_RI_Earned t
FROM [Agresso].[BICIRI_EarnedPremium] t
LEFT JOIN Eurobase.reinsurance_pol_det tty ON (tty.rpd_policy_reference = t.PolicyNo)
LEFT JOIN Eurobase.rein_program_sequence prg ON (prg.rps_program_id = tty.rpd_treaty_ri_code)
LEFT JOIN TempPolType_CTE1 tmp ON (tmp.PolicyNo = t.PolicyNo)
JOIN fdm.AccountingPeriod d ON (
		d.AccountingPeriod > t.AccountingPeriod
		AND d.AccountingPeriod <= left(convert(VARCHAR, getdate(), 112), 6)
		AND substring(d.AccountingPeriod, 5, 2) IN (
			'03'
			,'06'
			,'09'
			,'12'
			)
		)
--WHERE ISDATE(CAST(d.AccountingPeriod+'01'AS varchar))=1
 GROUP BY CASE WHEN ISDATE(CAST(d.AccountingPeriod+'01'AS varchar))=1 THEN cast(d.AccountingPeriod + '01' AS DATE) 
		ELSE NULL
		END
	,t.TrifocusCode
	,t.YOA
	,IsNUll(t.CCY,'USD')
	,UWProd
	,CASE 
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			AND right(Account, 2) = '00'
			THEN 'BICI_HISTORICAL'
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			THEN 'BICI Internal QS'
		WHEN isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN')) NOT LIKE '%Internal%'
			AND isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN')) NOT IN (
				'BICI Risk & Agg XL'
				,'PORTFOLIO TRANSFER BICI TO CAPTIVE RI'
				)
			AND right(Account, 2) <> '00'
			THEN 'BICI Internal QS'
		ELSE isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN'))
		END
	,CASE 
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			THEN 'UNK'
		ELSE isnull(tmp.RIPolicyType, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'FAC'
						WHEN tty.[rpd_rein_policy_type] IN (
								'SL'
								,'RE'
								)
							THEN 'XL'
						ELSE tty.[rpd_rein_policy_type]
						END, 'UNKNOWN'))
		END


)


	SELECT 
	    TrifocusCode
		,Entity
		,YOA
		,SettlementCCY
		,OriginalCCY
		,DateOfFact
		,Businesskey
		,Inceptiondate
		,ExpiryDate
		,RIPolicyType
		,ProgrammeCode
		,Scenario
		,Account
		,Dataset
		,PolicyNumber
		,BindDate
		,DueDate
		,TypeOfBusiness
		,StatsCode
		,IsToDate
	
		,Basis
		,[Location]
		,BusinessProcessCode
		,FK_Batch
		,BoundDate
		,Rowhash
		,FK_Allocation
		,DeltaType
		,AuditSourceBatchID
		,AuditCreateDateTime
		,AuditGenerateDateTime
		,AuditUserCreate
		,AuditHost
		
		,[Value]
		,[ValueOrig]
	--INTO #FinalTransforms
	FROM (
		SELECT		TrifocusCode		= t.TrifocusCode
					,Entity = 'USBICI'
					,YOA = cast(t.YOA AS VARCHAR(5))
					,SettlementCCY = t.CCY
					,OriginalCCY = t.CCY
					,DateOfFact = CONVERT(DATETIME, DateOfFact)
					,Businesskey = CONCAT (
											'BICI_Earned_Agresso'
											,'|'
											,ISNULL(ProgrammeCode, '-')
											,'|'
											,ISNULL(T.RIPolicyType, '-')
											,'|'
											,ISNULL(T.CCY, '-')
											,'|'
											,ISNULL(TrifocusCode, '-')
											,'|'
											,ISNULL(cast(t.YOA AS VARCHAR(5)), '-')
										)
					,Inceptiondate =  CAST('01-01-1980' as date)
					,ExpiryDate =  CAST('01-01-1980' as date)
					,RIPolicyType = RIPolicyType
					,ProgrammeCode = ProgrammeCode
					,Scenario = 'A'
					,Account = Cast('P-EP-P-' + CASE 
							WHEN RIPolicyType = 'FAC'
								THEN 'FAC'
							ELSE 'TTY'
							END AS VARCHAR(25))
					,Dataset = 'BICI_Earned_Agresso'
					,PolicyNumber = 'NOPOLICY'
					,BindDate = CAST('01-01-1980' as date)
					,DueDate = CAST('01-01-1980' as date)
					,TypeOfBusiness = '-'
					,StatsCode = null
					,[IsToDate] = 'Y'
					
					,Basis = 'E'
					,[Location] = '-'
					,BusinessProcessCode = 'T1'
					,NULL AS FK_Batch
					,NULL AS BoundDate
					,null as Rowhash
					,null as FK_Allocation
					,null as DeltaType
					,null as AuditSourceBatchID
					,null as AuditCreateDateTime
					,null as AuditGenerateDateTime
					,null as AuditUserCreate
					,null as AuditHost
					
					,[Value] = sum(sum([Value])) OVER (
						PARTITION BY TrifocusCode
						,YOA
						,
						--RIPolicyType,
						ProgrammeCode
						,CCY
						,RIPolicyType ORDER BY DateOfFact ASC
						)
					,[ValueOrig] = sum(sum([Value])) OVER (
						PARTITION BY TrifocusCode
						,YOA
						,
						--RIPolicyType,
						ProgrammeCode
						,CCY
						,RIPolicyType ORDER BY DateOfFact ASC
						)
		--INTO			#FinalTransforms
		FROM TempBICICRIEarn_CTE2 t
		--where DateOfFact = '2018-12-01'
		--where left(convert(varchar,DateOfFact,112),6)  >=201812  --=@Asat
		GROUP BY dateoffact
			,CONCAT (
				'BICI_Earned_Agresso'
				,'|'
				,ISNULL(ProgrammeCode, '-')
				,'|'
				,ISNULL(T.RIPolicyType, '-')
				,'|'
				,ISNULL(T.CCY, '-')
				,'|'
				,ISNULL(TrifocusCode, '-')
				,'|'
				,ISNULL(T.YOA, '-')
				)
			,TrifocusCode
			,YOA
			,CCY
			,RIPolicyType
			,ProgrammeCode
		) a
	WHERE left(convert(VARCHAR, DateOfFact, 112), 6) >= '201812' AND DateOfFact IS NOT NULL
GO


