﻿CREATE VIEW [Eurobase].[vw_ReInsuranceTreaty]
AS

WITH cte_restate
AS (
	SELECT a.tra_bureau_signing_date
		,a.tra_bureau_signing_num
		,a.tra_treaty_section
		,b.tra_bureau_version_num
		,b.tra_claim_split_number
		,a.tra_syn_user_number
		,a.BaseVal
		,b.NewVal
		,(b.NewVal / a.BaseVal) * (
			CASE 
				WHEN b.tra_bureau_version_num < 0
					THEN - 1
				ELSE 1
				END
			) AS ChangeFactor
	FROM (
		SELECT tra_bureau_signing_date
			,t.tra_bureau_signing_num
			,t.tra_treaty_section
			,t.tra_bureau_version_num
			,t.tra_claim_split_number
			,t.tra_syn_user_number
			,abs(t.tra_syndicate_net_amount) BaseVal
		FROM [Eurobase].[transaction_01] t
		WHERE t.tra_bureau_version_num = 1
			AND t.tra_lloyds_ca_cat_code IN (
				'6'
				,'7'
				)
			AND t.tra_year_of_account >= '1993'
		) a
	INNER JOIN (
		SELECT tra_bureau_signing_date
			,t.tra_bureau_signing_num
			,t.tra_treaty_section
			,t.tra_bureau_version_num
			,t.tra_claim_split_number
			,t.tra_syn_user_number
			,abs(t.tra_syndicate_net_amount) NewVal
		FROM [Eurobase].[transaction_01] t
		WHERE t.tra_bureau_version_num <> 1
			AND t.tra_lloyds_ca_cat_code IN (
				'6'
				,'7'
				)
			AND t.tra_year_of_account >= '1993'
		) b ON b.tra_bureau_signing_date = a.tra_bureau_signing_date
		AND b.tra_bureau_signing_num = a.tra_bureau_signing_num
		AND b.tra_treaty_section = a.tra_treaty_section
		AND b.tra_syn_user_number = a.tra_syn_user_number
	)

SELECT			 RIPolicyType		=		rpd.rpd_rein_policy_type
				,Account			=					CASE 
																WHEN t.tra_lloyds_ca_cat_code IN ('6','7')
																THEN 'PC'
																ELSE 'CC'
														END --AS AccountL1,
												+ '-' + CASE 
															WHEN t.tra_lloyds_account_type = 'A'
															THEN 'LS'
															WHEN t.tra_lloyds_account_type IN ('S','L') AND year(t.tra_actual_payment_date) = '9999'
															THEN 'SD'
															ELSE 'OS'
														END --AS AccountL2,
												+ '-' + CASE 
															WHEN t.tra_lloyds_ca_cat_code IN ('6','7')
															THEN CASE WHEN t.tra_lloyds_ca_qual_cat = 'H'
																		THEN 'RT'
																		ELSE 'RP'
																 END
															ELSE 'UN'
														END --AS AccountL3,
												+ '-' + 'TTY'-- as Account Level4
				,RIPolicyNumber		= t.tra_policy_ref
				,BusinessKey		= CONVERT([VARCHAR](255), CONCAT (
																	ISNULL(CONVERT(VARCHAR(8), t.[tra_bureau_signing_date], 112), '')
																	,'|'
																	,ISNULL(CONVERT(VARCHAR(30), t.[tra_bureau_signing_num]), '')
																	,'|'
																	,ISNULL(CONVERT(VARCHAR(2), t.[tra_treaty_section]), '')
																	,'|'
																	,ISNULL(CONVERT(VARCHAR(30), t.[tra_bureau_version_num]), '')
																	,'|'
																	,ISNULL(CONVERT(VARCHAR(30), t.[tra_claim_split_number]), '')
																	,'|'
																	,ISNULL(CONVERT(VARCHAR(30), t.[tra_syn_user_number]), '')
																	,'|'
																	,CONVERT(VARCHAR(50), ISNULL(ti.ins_instalment_num, 0))
																)
											)
				,DateOfFact			=		CASE 
												WHEN t.tra_processing_period > (
																				CASE 
																					WHEN ti.ins_actual_payment_date IS NOT NULL
																						THEN ti.ins_actual_payment_date
																					WHEN DATEPART(Year, t.tra_actual_payment_date) = '9999'
																						THEN t.tra_bureau_signing_date
																					ELSE t.tra_actual_payment_date
																				END
																				)
												THEN t.tra_processing_period
												ELSE (
														CASE 
															WHEN ti.ins_actual_payment_date IS NOT NULL
																THEN ti.ins_actual_payment_date
															WHEN DATEPART(Year, t.tra_actual_payment_date) = '9999'
																THEN t.tra_bureau_signing_date
															ELSE t.tra_actual_payment_date
														END
													)
											END
				,TransactionDate   =		CASE 
												WHEN ti.ins_actual_payment_date IS NOT NULL
													THEN ti.ins_actual_payment_date
												WHEN DATEPART(Year, t.tra_actual_payment_date) = '9999'
													THEN t.tra_bureau_signing_date
												ELSE t.tra_actual_payment_date
											END
				,RIInceptionDate		 = ISNULL(rpd.rpd_ri_pol_prd_from, '1980-01-01')
				,RIExpiryDate			 = ISNULL(rpd.rpd_ri_pol_prd_to, '1980-01-01')
				,ProgrammeCode			 = COALESCE(D.Programme, rps.ifrs17_programme_group, rpd.rpd_treaty_ri_code)
				,Entity					 = t.tra_syn_user_number
				,YOA					 = t.tra_year_of_account
				,SettlementCCY			 = t.tra_settlement_ccy_code
				,BeazleyCatCode			 = nullif(cd.cla_clg_group_code, '')
				
				-- Date fields to establish Timing differences when performing Validation
				,TransBureauSigndate     = t.tra_bureau_signing_date
				,TransActualPaymentdate  = t.tra_actual_payment_date
				,TransProcessingPeriod   = t.tra_processing_period
				,TransInstalmentDate     = ti.ins_instalment_due_date

				--[Value_Old] = ISNULL((case when t.tra_bureau_version_num < 0 then -1 else 1 end) * ti.ins_instalment_amount, t.tra_syndicate_net_amount), -- Commented part of I1B-3832
				,[Value]                 =CONVERT(NUMERIC(38,4), CASE 
																	WHEN ti.ins_pre_br_signing_num IS NULL
																		THEN t.tra_syndicate_net_amount --New Additions with Adjustments
																	WHEN ti.ins_pre_br_version_num = t.tra_bureau_version_num
																		THEN ti.ins_instalment_amount
																	ELSE ti.ins_instalment_amount * ISNULL(rs.ChangeFactor, 1)
																END 
												 )-- This is resulting as Float datatype as causing issues, hence convert to decimal. SHould be remove part of I1B-3084
		  --convert(numeric(38,4),Amount)

FROM		 [Eurobase].[transaction_01] t
LEFT JOIN	 [Eurobase].[claim_details_01] cd ON cd.cla_unified_claim_ref = t.tra_cla_uni_claim_ref
			  AND cd.cla_originating_bureau = t.tra_cla_orig_bureau
LEFT JOIN	 [Eurobase].transaction_instalment ti ON ti.ins_pre_br_signing_date = t.tra_bureau_signing_date
			  AND ti.ins_pre_br_signing_num = t.tra_bureau_signing_num
			  AND   (
					ti.ins_pre_br_version_num = t.tra_bureau_version_num
					OR ti.ins_pre_br_version_num = - t.tra_bureau_version_num
					OR ti.ins_pre_br_version_num = abs(t.tra_bureau_version_num) % 100
				  )
			  AND ti.ins_syn_user_number = t.tra_syn_user_number
			  AND ti.ins_pre_treaty_section = t.tra_treaty_section
INNER JOIN	 [Eurobase].[reinsurance_pol_det] rpd ON rpd.rpd_policy_reference = t.tra_policy_ref
LEFT JOIN	 [Eurobase].[rein_program_sequence] rps ON rps.rps_program_id = rpd.rpd_treaty_ri_code
LEFT JOIN	 MDS.DummyProgrammes_CededRe D ON D.DummyPolicy = rpd.rpd_policy_reference
LEFT JOIN	 CTE_ReState RS ON (
								rs.tra_bureau_signing_date = t.tra_bureau_signing_date
								AND rs.tra_bureau_signing_num = t.tra_bureau_signing_num
								AND rs.tra_bureau_version_num = t.tra_bureau_version_num
								AND rs.tra_claim_split_number = t.tra_claim_split_number
								AND rs.tra_syn_user_number = t.tra_syn_user_number
								AND rs.tra_treaty_section = t.tra_treaty_section
								)																				   -- This helps to write Adjustments
LEFT JOIN	Eurobase.vw_ReInsuranceTreatyContractAttributes TTYC ON (ttyc.RI_Section_Reference = t.tra_policy_ref) -- This Join gets the Treaty attributes

WHERE		t.tra_lloyds_ca_cat_code IN ('6','7','8','9')
			
			AND t.tra_year_of_account >= 1993




