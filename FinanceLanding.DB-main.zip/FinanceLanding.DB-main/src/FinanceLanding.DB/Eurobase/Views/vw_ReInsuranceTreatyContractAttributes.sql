﻿CREATE view [Eurobase].[vw_ReInsuranceTreatyContractAttributes]
as
SELECT 
	[RI_Section_Reference]					= rpd.rpd_policy_reference,
	[RI_Policy_Type]						= MAX(rpd.rpd_rein_policy_type),
	[RI_Code]								= MAX(rpd.rpd_treaty_ri_code),
	[ProgrammeCode]							= MAX(COALESCE(D.Programme,prg.ifrs17_programme_group, rpd.rpd_treaty_ri_code)),
	[Inception_Date]						= MAX(rpd.rpd_ri_pol_prd_from),
	[Expiry_Date]							= MAX(rpd.rpd_ri_pol_prd_to),
	[Number_of_Reinstatements]				= MAX(rpd.rpd_reinstatements),
	[Claim_Basis]							= MAX(rpd.rpd_ri_claims_basis),
	[Slip_Order_%]							= MAX(rpd.rpd_slip_order_pcnt),
	[General_Description]					= MAX(rpd.rpd_general_description),
	[Sum_Insured_Limit]						= MAX(rpd.rpd_sum_insured_limit),
	[Excess_Limit]							= MAX(rpd.rpd_excess_limit),
	[Sum_Insured_Currency]					= MAX(rpd.rpd_sum_insured_ccy),
	[Event_Limit]							= MAX(rpd.rpd_event_limit),
	[Event_Limit_Currency]					= MAX(rpd.rpd_event_limit_ccy),
	[Settlement_Limit]						= MAX(rpd.rpd_sp_sett_limit),
	[Settlement_Limit_Currency]				= MAX(rpd.rpd_sp_sett_limit_ccy),
	[Currency_Converter]					= MAX(rpd.rpd_slip_roe),
	[Profit_Commission]						= MAX(rpd.rpd_exp_profit_comm),
	[Profit_Commission_Management_Expenses] = MAX(rpd.rpd_profit_comm_mgt_exp),
	[Profit_Commission_Currency]			= MAX(rpd.rpd_exp_profit_comm_ccy),
	[Overrider]								= MAX(rpd.rpd_overrider),
	[Average_QS_%]							= AVG(rli.pri_proportion),
	[Number_of_QS_Policies]					= COUNT(rli.pri_cpd_policy_ref),
	[%_Ceded_to_QS]							= AVG(rli.pri_ceded_pcnt)                         
FROM 
	[Eurobase].reinsurance_pol_det rpd 
	LEFT JOIN [Eurobase].policy_reinsurance_link rli 
       ON  rli.pri_rpd_policy_ref = rpd.rpd_policy_reference 
	   AND rli.pri_policy_type = 'QS'
	LEFT JOIN [Eurobase].rein_program_sequence prg 
       ON prg.rps_program_id = rpd.rpd_treaty_ri_code
	 LEFT JOIN MDS.DummyProgrammes_CededRe D
	 ON D.DummyPolicy=rpd.rpd_policy_reference
GROUP BY 
	rpd.rpd_policy_reference

	
GO


