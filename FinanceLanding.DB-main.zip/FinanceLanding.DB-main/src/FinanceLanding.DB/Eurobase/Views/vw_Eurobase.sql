﻿CREATE VIEW [Eurobase].[vw_Eurobase]
AS

-- ===================================================

-- Original Author:		Pavani Bandaru <pavani.bandaru@beazley.com> | Nikil Nallamothu <nikil.nallamothu@beazley.com> | Shah Nawaz Ahmed <shahnawaz.ahmed@beazley.com> 
-- Create date: 18/04/2024
-- Description:	This view is designed to construct the bussiness key and missing columns in comparison to outbound table by combining source data from two distinct tables (BaseLoad & Normal load).

-- jira: https://beazley.atlassian.net/browse/I1B-3817
-- ====================================================

--drop table if exists #pd_mop_code
--drop table if exists #fl_mop_code
WITH pd_mop_code
AS (
	SELECT pol_cpd_policy_reference
		,max(pd.pol_mop_code) pd_mop_code
	--into #pd_mop_code
	FROM Eurobase.policy_details_01 pd
	GROUP BY pol_cpd_policy_reference
	)
	--select * from pd_mop_code
	,fl_mop_code
AS (
	SELECT [Policy Reference]
		,max(mop) mop
	--into #fl_mop_code
	FROM Eurobase.Eurobase_EPI
	GROUP BY [Policy Reference]
	)
	--drop table if exists #cte_cb
	,cte_cb
AS (
	SELECT pd.pol_cpd_policy_reference
		,max(CASE 
				WHEN cpd.cpd_claim_basis = ''
					THEN cmc.CmcLossBasis
				ELSE cpd.cpd_claim_basis
				END) AS ClaimBasis
	--into #cte_cb
	FROM Eurobase.policy_details_01 pd
	LEFT JOIN Eurobase.common_policy_details_01 cpd ON (cpd.cpd_policy_reference = pd.pol_cpd_policy_reference)
	LEFT JOIN Eb.CobMopCombination cmc ON (
			cmc.CmcCobCode = pd.pol_cob_code
			AND cmc.CmcMopCode = pd.pol_mop_code
			)
	GROUP BY pd.pol_cpd_policy_reference
	)
--Drop table if exists #temp_initTransaction	
--insert into Testing.[ebnld].[LandedTransformed_EPI]
--BaseLoad EPI
--Select * into #temp_initTransaction from 
--(
SELECT 'A' AS scenario
	,'-' AS Basis
	,'P-GP-' + CASE 
		WHEN pdmop.pd_mop_code IN (
				'B'
				,'L'
				)
			THEN 'B'
		ELSE 'P'
		END AS Account
	,'Eurobase' AS Dataset
	,'2018-11-01' AS DateOfFact
	,isnull(rtrim(ltrim('P-GP-' + CASE 
					WHEN pdmop.pd_mop_code IN (
							'B'
							,'L'
							)
						THEN 'B'
					ELSE 'P'
					END)), '-') + '|' + isnull(rtrim(ltrim(t.policyref)), '-') + '|' + isnull(rtrim(ltrim(isnull(s.yoa, isnull(p.yoa, t.YOA)))), '-') + '|' + isnull(rtrim(ltrim(t.EntityCode)), '-') + '|' + isnull(rtrim(ltrim(t.SettlementCCY)), '-') + '|' + isnull(rtrim(ltrim(t.TrifocusCode)), '-') AS BusinessKey
	,t.PolicyRef PolicyNumber
	,CASE CONVERT(VARCHAR(12), isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception])), 114)
		WHEN '23:00:00:000'
			THEN DATEADD(HOUR, 1, isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception])))
		ELSE isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception]))
		END InceptionDate
	,CASE CONVERT(VARCHAR(12), isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry])), 114)
		WHEN '23:00:00:000'
			THEN DATEADD(HOUR, 1, isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry])))
		ELSE isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry]))
		END ExpiryDate
	,'1980-01-01' AS BindDate
	,'1980-01-01' AS DueDate
	,t.TrifocusCode
	,t.EntityCode Entity
	,isnull(s.yoa, isnull(p.yoa, t.YOA)) YOA
	,'-' AS TypeOfBusiness
	,NULL AS StatsCode
	,t.SettlementCCY
	,t.SettlementCCY AS OriginalCCY
	,'Y' AS IsToDate
	,sum(t.[Premium]) [Value]
	,sum(t.[Premium]) [ValueOrig]
	,'-' AS [Location]
	,'GROSS' AS ProgrammeCode
	,NULL AS [RIPolicyType]
	,coalesce(cb.ClaimBasis, s.ClaimBasis, p.ClaimBasis) PolicyClaimBasis
	,coalesce(pdmop.pd_mop_code, s.MopCode, p.MopCode, fl.mop) PolicyMopCode
	,t.YOA YOA_Source
FROM Eurobase.AgressoUABaseLoad t
LEFT JOIN pd_mop_code pdmop ON (pdmop.pol_cpd_policy_reference = t.policyref)
LEFT JOIN MDS.ODSSection s ON (s.[SectionReference] = t.policyref)
LEFT JOIN MDS.[ODSPolicy] p ON (p.PolicyReference = substring(t.policyref, 1, 8))
LEFT JOIN fl_mop_code fl ON (fl.[Policy Reference] = t.policyref)
LEFT JOIN cte_cb cb ON (cb.pol_cpd_policy_reference = t.policyref)
WHERE t.AccountingPeriod <= '201812'
	AND left(convert(VARCHAR, Inception, 112), 6) <= '201811'
GROUP BY 'P-GP-' + CASE 
		WHEN pdmop.pd_mop_code IN (
				'B'
				,'L'
				)
			THEN 'B'
		ELSE 'P'
		END
	,t.AccountingPeriod
	,t.PolicyRef
	,CASE CONVERT(VARCHAR(12), isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception])), 114)
		WHEN '23:00:00:000'
			THEN DATEADD(HOUR, 1, isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception])))
		ELSE isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception]))
		END
	,CASE CONVERT(VARCHAR(12), isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry])), 114)
		WHEN '23:00:00:000'
			THEN DATEADD(HOUR, 1, isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry])))
		ELSE isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry]))
		END
	,t.TriFocusCode
	,t.EntityCode
	,isnull(s.yoa, isnull(p.yoa, t.YOA))
	,t.SettlementCCY
	,coalesce(pdmop.pd_mop_code, s.MopCode, p.MopCode, fl.mop)
	,coalesce(cb.ClaimBasis, s.ClaimBasis, p.ClaimBasis)
	,t.YOA
HAVING sum(t.Premium) <> 0
--select * from #temp_initTransaction

UNION ALL

--Baseload Acquisition
SELECT 'A' AS scenario
	,'-' AS Basis
	,'P-AC-' + CASE 
		WHEN pdmop.pd_mop_code IN (
				'B'
				,'L'
				)
			THEN 'B'
		ELSE 'P'
		END AS Account
	,'Eurobase' AS Dataset
	,'2018-11-01' AS DateOfFact
	,isnull(rtrim(ltrim('P-AC-' + CASE 
					WHEN pdmop.pd_mop_code IN (
							'B'
							,'L'
							)
						THEN 'B'
					ELSE 'P'
					END)), '-') + '|' + isnull(rtrim(ltrim(t.policyref)), '-') + '|' + isnull(rtrim(ltrim(isnull(s.yoa, isnull(p.yoa, t.YOA)))), '-') + '|' + isnull(rtrim(ltrim(t.EntityCode)), '-') + '|' + isnull(rtrim(ltrim(t.SettlementCCY)), '-') + '|' + isnull(rtrim(ltrim(t.TrifocusCode)), '-') AS BusinessKey
	,t.PolicyRef PolicyNumber
	,CASE CONVERT(VARCHAR(12), isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception])), 114)
		WHEN '23:00:00:000'
			THEN DATEADD(HOUR, 1, isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception])))
		ELSE isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception]))
		END InceptionDate
	,CASE CONVERT(VARCHAR(12), isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry])), 114)
		WHEN '23:00:00:000'
			THEN DATEADD(HOUR, 1, isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry])))
		ELSE isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry]))
		END ExpiryDate
	,'1980-01-01' AS BindDate
	,'1980-01-01' AS DueDate
	,t.TrifocusCode
	,t.EntityCode Entity
	,isnull(s.yoa, isnull(p.yoa, t.YOA)) YOA
	,'-' AS TypeOfBusiness
	,NULL AS StatsCode
	,t.SettlementCCY
	,t.SettlementCCY AS OriginalCCY
	,'Y' AS IsToDate
	,sum(t.[Deductions]) [Value]
	,sum(t.[Deductions]) [ValueOrig]
	,'-' AS [Location]
	,'GROSS' AS ProgrammeCode
	,NULL AS [RIPolicyType]
	,coalesce(cb.ClaimBasis, s.ClaimBasis, p.ClaimBasis) PolicyClaimBasis
	,coalesce(pdmop.pd_mop_code, s.MopCode, p.MopCode, fl.mop) PolicyMopCode
	,t.YOA YOA_Source
FROM Eurobase.AgressoUABaseLoad t
LEFT JOIN pd_mop_code pdmop ON (pdmop.pol_cpd_policy_reference = t.policyref)
LEFT JOIN MDS.ODSSection s ON (s.[SectionReference] = t.policyref)
LEFT JOIN MDS.[ODSPolicy] p ON (p.PolicyReference = substring(t.policyref, 1, 8))
LEFT JOIN fl_mop_code fl ON (fl.[Policy Reference] = t.policyref)
LEFT JOIN cte_cb cb ON (cb.pol_cpd_policy_reference = t.policyref)
WHERE t.AccountingPeriod <= '201811'
	AND left(convert(VARCHAR, Inception, 112), 6) <= '201811'
GROUP BY 'P-AC-' + CASE 
		WHEN pdmop.pd_mop_code IN (
				'B'
				,'L'
				)
			THEN 'B'
		ELSE 'P'
		END
	,t.AccountingPeriod
	,t.PolicyRef
	,CASE CONVERT(VARCHAR(12), isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception])), 114)
		WHEN '23:00:00:000'
			THEN DATEADD(HOUR, 1, isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception])))
		ELSE isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception]))
		END
	,CASE CONVERT(VARCHAR(12), isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry])), 114)
		WHEN '23:00:00:000'
			THEN DATEADD(HOUR, 1, isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry])))
		ELSE isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry]))
		END
	,t.TriFocusCode
	,t.EntityCode
	,isnull(s.yoa, isnull(p.yoa, t.YOA))
	,t.SettlementCCY
	,coalesce(pdmop.pd_mop_code, s.MopCode, p.MopCode, fl.mop)
	,coalesce(cb.ClaimBasis, s.ClaimBasis, p.ClaimBasis)
	,t.YOA
HAVING sum(t.Deductions) <> 0

UNION ALL

--EPI
SELECT 'A' AS scenario
	,'-' AS Basis
	,'P-GP-' + CASE 
		WHEN coalesce(t.MOP, pdmop.pd_mop_code, s.MopCode, p.MopCode) IN (
				'B'
				,'L'
				)
			THEN 'B'
		ELSE 'P'
		END Account
	,'Eurobase' AS Dataset
	,cast(left(convert(VARCHAR, dateadd(month, - 1, t.report_date), 112), 6) + '01' AS DATE) DateOfFact
	,isnull('P-GP-' + CASE 
			WHEN coalesce(t.MOP, pdmop.pd_mop_code, s.MopCode, p.MopCode) IN (
					'B'
					,'L'
					)
				THEN 'B'
			ELSE 'P'
			END, '-') + '|' + isnull(rtrim(ltrim(t.[Policy Reference])), '-') + '|' + isnull(rtrim(ltrim(isnull(s.yoa, isnull(p.yoa, t.[Policy YOA])))), '-') + '|' + isnull(rtrim(ltrim([Syndicate Number])), '-') + '|' + isnull(rtrim(ltrim([Policy Settlement Currency])), '-') + '|' + isnull(rtrim(ltrim(isnull(tf.TrifocusCode, 'Unknown'))), '-') AS BusinessKey
	,t.[Policy Reference] PolicyNumber
	,CASE CONVERT(VARCHAR(12), isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception Date])), 114)
		WHEN '23:00:00:000'
			THEN DATEADD(HOUR, 1, isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception Date])))
		ELSE isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception Date]))
		END InceptionDate
	,CASE CONVERT(VARCHAR(12), isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry Date])), 114)
		WHEN '23:00:00:000'
			THEN DATEADD(HOUR, 1, isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry Date])))
		ELSE isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry Date]))
		END ExpiryDate
	,'1980-01-01' AS BindDate
	,'1980-01-01' AS DueDate
	,isnull(tf.TrifocusCode, 'Unknown') TrifocusCode
	,[Syndicate Number] Entity
	,isnull(s.yoa, isnull(p.yoa, t.[Policy YOA])) YOA
	,'-' AS TypeOfBusiness
	,NULL AS StatsCode
	,[Policy Settlement Currency] SettlementCCY
	,[Policy Settlement Currency] AS OrginalCCY
	,'Y' AS IsToDate
	,isnull(sum([Estimated Premium Income]), 0) + isnull(sum([Total Acquisition Cost]), 0) [Value]
	,isnull(sum([Estimated Premium Income]), 0) + isnull(sum([Total Acquisition Cost]), 0) [ValueOrig]
	,'-' AS [Location]
	,'GROSS' AS ProgrammeCode
	,NULL AS [RIPolicyType]
	,coalesce(cb.ClaimBasis, s.ClaimBasis, p.ClaimBasis) PolicyClaimBasis
	,coalesce(pdmop.pd_mop_code, s.MopCode, p.MopCode, fl.mop) PolicyMopCode
	,t.[Policy YOA] AS YOA_Source
FROM Eurobase.[Eurobase_EPI] t
LEFT JOIN fdm.DimTrifocus tf ON (
		tf.TrifocusName = CASE 
			WHEN t.[TriFocus Group] = 'Covers'
				THEN 'Covers US'
			WHEN t.[TriFocus Group] = 'Swiss'
				THEN 'Private Clients'
			ELSE t.[TriFocus Group]
			END
		)
LEFT JOIN pd_mop_code pdmop ON (pdmop.pol_cpd_policy_reference = t.[Policy Reference])
LEFT JOIN MDS.ODSSection s ON (s.[SectionReference] = t.[Policy Reference])
LEFT JOIN MDS.[ODSPolicy] p ON (p.PolicyReference = substring(t.[Policy Reference], 1, 8))
LEFT JOIN fl_mop_code fl ON (fl.[Policy Reference] = t.[Policy Reference])
LEFT JOIN cte_cb cb ON (cb.pol_cpd_policy_reference = t.[Policy Reference])
WHERE t.[TriFocus Group] NOT LIKE 'BICI%'
	AND t.[TriFocus Group] NOT LIKE 'BUSA%'
	AND [Syndicate Number] <> '8033'
	AND t.report_date IS NOT NULL
	AND substring(t.[Policy Reference], 1, 6) NOT IN (
		'B7029B'
		,'B7139A'
		,'B9997A'
		,'B9998A'
		,'B9999A'
		,'P2926H'
		,'P3015V'
		,'B8114F'
		,'B7382X'
		)
	AND left(convert(VARCHAR, dateadd(month, - 1, t.report_date), 112), 6) >= left(convert(VARCHAR, [inception Date], 112), 6)
GROUP BY cast(left(convert(VARCHAR, dateadd(month, - 1, t.report_date), 112), 6) + '01' AS DATE)
	,t.[Policy Reference]
	,'P-GP-' + CASE 
		WHEN coalesce(t.MOP, pdmop.pd_mop_code, s.MopCode, p.MopCode) IN (
				'B'
				,'L'
				)
			THEN 'B'
		ELSE 'P'
		END
	,CASE CONVERT(VARCHAR(12), isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception Date])), 114)
		WHEN '23:00:00:000'
			THEN DATEADD(HOUR, 1, isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception Date])))
		ELSE isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception Date]))
		END
	,CASE CONVERT(VARCHAR(12), isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry Date])), 114)
		WHEN '23:00:00:000'
			THEN DATEADD(HOUR, 1, isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry Date])))
		ELSE isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry Date]))
		END
	,isnull(tf.TrifocusCode, 'Unknown')
	,isnull(s.yoa, isnull(p.yoa, t.[Policy YOA]))
	,[Syndicate Number]
	,[Policy Settlement Currency]
	,coalesce(cb.ClaimBasis, s.ClaimBasis, p.ClaimBasis)
	,coalesce(pdmop.pd_mop_code, s.MopCode, p.MopCode, fl.mop)
	,t.[Policy YOA]
HAVING abs(isnull(sum([Estimated Premium Income]), 0) + isnull(sum([Total Acquisition Cost]), 0)) > 1

UNION ALL

--Acquisition
SELECT 'A' AS scenario
	,'-' AS Basis
	,'P-AC-' + CASE 
		WHEN coalesce(t.MOP, pdmop.pd_mop_code, s.MopCode, p.MopCode) IN (
				'B'
				,'L'
				)
			THEN 'B'
		ELSE 'P'
		END Account
	,'Eurobase' AS Dataset
	,cast(left(convert(VARCHAR, dateadd(month, - 1, t.report_date), 112), 6) + '01' AS DATE) DateOfFact
	,isnull('P-AC-' + CASE 
			WHEN coalesce(t.MOP, pdmop.pd_mop_code, s.MopCode, p.MopCode) IN (
					'B'
					,'L'
					)
				THEN 'B'
			ELSE 'P'
			END, '-') + '|' + isnull(rtrim(ltrim(t.[Policy Reference])), '-') + '|' + isnull(rtrim(ltrim(isnull(s.yoa, isnull(p.yoa, t.[Policy YOA])))), '-') + '|' + isnull(rtrim(ltrim([Syndicate Number])), '-') + '|' + isnull(rtrim(ltrim([Policy Settlement Currency])), '-') + '|' + isnull(rtrim(ltrim(isnull(tf.TrifocusCode, 'Unknown'))), '-') AS BusinessKey
	,t.[Policy Reference] PolicyNumber
	,CASE CONVERT(VARCHAR(12), isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception Date])), 114)
		WHEN '23:00:00:000'
			THEN DATEADD(HOUR, 1, isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception Date])))
		ELSE isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception Date]))
		END InceptionDate
	,CASE CONVERT(VARCHAR(12), isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry Date])), 114)
		WHEN '23:00:00:000'
			THEN DATEADD(HOUR, 1, isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry Date])))
		ELSE isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry Date]))
		END ExpiryDate
	,'1980-01-01' AS BindDate
	,'1980-01-01' AS DueDate
	,isnull(tf.TrifocusCode, 'Unknown') TrifocusCode
	,[Syndicate Number] Entity
	,isnull(s.yoa, isnull(p.yoa, t.[Policy YOA])) YOA
	,'-' AS TypeOfBusiness
	,NULL AS StatsCode
	,[Policy Settlement Currency] SettlementCCY
	,[Policy Settlement Currency] AS OrginalCCY
	,'Y' AS IsToDate
	,sum(isnull([Total Acquisition Cost], 0) - isnull(t.[LBS Comm], 0)) [Value]
	,sum(isnull([Total Acquisition Cost], 0) - isnull(t.[LBS Comm], 0)) [ValueOrig]
	,'-' AS [Location]
	,'GROSS' AS ProgrammeCode
	,NULL AS [RIPolicyType]
	,coalesce(cb.ClaimBasis, s.ClaimBasis, p.ClaimBasis) PolicyClaimBasis
	,coalesce(pdmop.pd_mop_code, s.MopCode, p.MopCode, fl.mop) PolicyMopCode
	,t.[Policy YOA] AS YOA_Source
FROM Eurobase.[Eurobase_EPI] t
LEFT JOIN fdm.DimTrifocus tf ON (
		tf.TrifocusName = CASE 
			WHEN t.[TriFocus Group] = 'Covers'
				THEN 'Covers US'
			WHEN t.[TriFocus Group] = 'Swiss'
				THEN 'Private Clients'
			ELSE t.[TriFocus Group]
			END
		)
LEFT JOIN pd_mop_code pdmop ON (pdmop.pol_cpd_policy_reference = t.[Policy Reference])
LEFT JOIN MDS.ODSSection s ON (s.[SectionReference] = t.[Policy Reference])
LEFT JOIN MDS.[ODSPolicy] p ON (p.PolicyReference = substring(t.[Policy Reference], 1, 8))
LEFT JOIN fl_mop_code fl ON (fl.[Policy Reference] = t.[Policy Reference])
LEFT JOIN cte_cb cb ON (cb.pol_cpd_policy_reference = t.[Policy Reference])
WHERE t.[TriFocus Group] NOT LIKE 'BICI%'
	AND t.[TriFocus Group] NOT LIKE 'BUSA%'
	AND [Syndicate Number] <> '8033'
	AND t.report_date IS NOT NULL
	AND substring(t.[Policy Reference], 1, 6) NOT IN (
		'B7029B'
		,'B7139A'
		,'B9997A'
		,'B9998A'
		,'B9999A'
		,'P2926H'
		,'P3015V'
		,'B8114F'
		,'B7382X'
		)
	AND left(convert(VARCHAR, dateadd(month, - 1, t.report_date), 112), 6) >= left(convert(VARCHAR, [inception Date], 112), 6)
GROUP BY cast(left(convert(VARCHAR, dateadd(month, - 1, t.report_date), 112), 6) + '01' AS DATE)
	,t.[Policy Reference]
	,'P-AC-' + CASE 
		WHEN coalesce(t.MOP, pdmop.pd_mop_code, s.MopCode, p.MopCode) IN (
				'B'
				,'L'
				)
			THEN 'B'
		ELSE 'P'
		END
	,CASE CONVERT(VARCHAR(12), isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception Date])), 114)
		WHEN '23:00:00:000'
			THEN DATEADD(HOUR, 1, isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception Date])))
		ELSE isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception Date]))
		END
	,CASE CONVERT(VARCHAR(12), isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry Date])), 114)
		WHEN '23:00:00:000'
			THEN DATEADD(HOUR, 1, isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry Date])))
		ELSE isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry Date]))
		END
	,isnull(tf.TrifocusCode, 'Unknown')
	,isnull(s.yoa, isnull(p.yoa, t.[Policy YOA]))
	,[Syndicate Number]
	,[Policy Settlement Currency]
	,coalesce(cb.ClaimBasis, s.ClaimBasis, p.ClaimBasis)
	,coalesce(pdmop.pd_mop_code, s.MopCode, p.MopCode, fl.mop)
	,t.[Policy YOA]
HAVING abs(sum([Total Acquisition Cost])) > 1

UNION ALL

--LBS Commission
SELECT 'A' AS scenario
	,'-' AS Basis
	,'P-LB-' + CASE 
		WHEN coalesce(t.MOP, pdmop.pd_mop_code, s.MopCode, p.MopCode) IN (
				'B'
				,'L'
				)
			THEN 'B'
		ELSE 'P'
		END Account
	,'Eurobase' AS Dataset
	,cast(left(convert(VARCHAR, dateadd(month, - 1, t.report_date), 112), 6) + '01' AS DATE)
	,isnull('P-LB-' + CASE 
			WHEN coalesce(t.MOP, pdmop.pd_mop_code, s.MopCode, p.MopCode) IN (
					'B'
					,'L'
					)
				THEN 'B'
			ELSE 'P'
			END, '-') + '|' + isnull(rtrim(ltrim(t.[Policy Reference])), '-') + '|' + isnull(rtrim(ltrim(isnull(s.yoa, isnull(p.yoa, t.[Policy YOA])))), '-') + '|' + isnull(rtrim(ltrim([Syndicate Number])), '-') + '|' + isnull(rtrim(ltrim([Policy Settlement Currency])), '-') + '|' + isnull(rtrim(ltrim(isnull(tf.TrifocusCode, 'Unknown'))), '-') AS BusinessKey
	,t.[Policy Reference] PolicyNumber
	,CASE CONVERT(VARCHAR(12), isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception Date])), 114)
		WHEN '23:00:00:000'
			THEN DATEADD(HOUR, 1, isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception Date])))
		ELSE isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception Date]))
		END InceptionDate
	,CASE CONVERT(VARCHAR(12), isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry Date])), 114)
		WHEN '23:00:00:000'
			THEN DATEADD(HOUR, 1, isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry Date])))
		ELSE isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry Date]))
		END ExpiryDate
	,'1980-01-01' AS BindDate
	,'1980-01-01' AS DueDate
	,isnull(tf.TrifocusCode, 'Unknown') TrifocusCode
	,[Syndicate Number] Entity
	,isnull(s.yoa, isnull(p.yoa, t.[Policy YOA])) YOA
	,'-' AS TypeOfBusiness
	,NULL AS StatsCode
	,[Policy Settlement Currency] SettlementCCY
	,[Policy Settlement Currency] AS OrginalCCY
	,'Y' AS IsToDate
	,sum(isnull([LBS Comm], 0)) [Value]
	,sum(isnull([LBS Comm], 0)) [ValueOrig]
	,'-' AS [Location]
	,'GROSS' AS ProgrammeCode
	,NULL AS [RIPolicyType]
	,coalesce(cb.ClaimBasis, s.ClaimBasis, p.ClaimBasis) PolicyClaimBasis
	,coalesce(pdmop.pd_mop_code, s.MopCode, p.MopCode, fl.mop) PolicyMopCode
	,t.[Policy YOA]
FROM Eurobase.[Eurobase_EPI] t
LEFT JOIN fdm.DimTrifocus tf ON (
		tf.TrifocusName = CASE 
			WHEN t.[TriFocus Group] = 'Covers'
				THEN 'Covers US'
			WHEN t.[TriFocus Group] = 'Swiss'
				THEN 'Private Clients'
			ELSE t.[TriFocus Group]
			END
		)
LEFT JOIN pd_mop_code pdmop ON (pdmop.pol_cpd_policy_reference = t.[Policy Reference])
LEFT JOIN MDS.ODSSection s ON (s.[SectionReference] = t.[Policy Reference])
LEFT JOIN MDS.[ODSPolicy] p ON (p.PolicyReference = substring(t.[Policy Reference], 1, 8))
LEFT JOIN fl_mop_code fl ON (fl.[Policy Reference] = t.[Policy Reference])
LEFT JOIN cte_cb cb ON (cb.pol_cpd_policy_reference = t.[Policy Reference])
WHERE t.[TriFocus Group] NOT LIKE 'BICI%'
	AND t.[TriFocus Group] NOT LIKE 'BUSA%'
	AND [Syndicate Number] <> '8033'
	AND t.report_date IS NOT NULL
	AND substring(t.[Policy Reference], 1, 6) NOT IN (
		'B7029B'
		,'B7139A'
		,'B9997A'
		,'B9998A'
		,'B9999A'
		,'P2926H'
		,'P3015V'
		,'B8114F'
		,'B7382X'
		)
	AND left(convert(VARCHAR, dateadd(month, - 1, t.report_date), 112), 6) >= left(convert(VARCHAR, [inception Date], 112), 6)
GROUP BY cast(left(convert(VARCHAR, dateadd(month, - 1, t.report_date), 112), 6) + '01' AS DATE)
	,t.[Policy Reference]
	,'P-LB-' + CASE 
		WHEN coalesce(t.MOP, pdmop.pd_mop_code, s.MopCode, p.MopCode) IN (
				'B'
				,'L'
				)
			THEN 'B'
		ELSE 'P'
		END
	,CASE CONVERT(VARCHAR(12), isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception Date])), 114)
		WHEN '23:00:00:000'
			THEN DATEADD(HOUR, 1, isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception Date])))
		ELSE isnull(s.InceptionDate, isnull(p.InceptionDate, t.[inception Date]))
		END
	,CASE CONVERT(VARCHAR(12), isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry Date])), 114)
		WHEN '23:00:00:000'
			THEN DATEADD(HOUR, 1, isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry Date])))
		ELSE isnull(s.ExpiryDate, isnull(p.ExpiryDate, t.[Expiry Date]))
		END
	,isnull(tf.TrifocusCode, 'Unknown')
	,isnull(s.yoa, isnull(p.yoa, t.[Policy YOA]))
	,[Syndicate Number]
	,[Policy Settlement Currency]
	,coalesce(cb.ClaimBasis, s.ClaimBasis, p.ClaimBasis)
	,coalesce(pdmop.pd_mop_code, s.MopCode, p.MopCode, fl.mop)
	,t.[Policy YOA]
HAVING abs(sum([LBS Comm])) > 1
GO