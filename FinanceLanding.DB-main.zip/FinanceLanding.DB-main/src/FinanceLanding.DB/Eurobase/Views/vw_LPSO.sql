﻿
CREATE view [Eurobase].[vw_LPSO]
As 



--drop table if exists #cte_basever
With cte_basever 
As (

				select t.tra_bureau_signing_date,
				t.tra_bureau_signing_num,
				t.tra_treaty_section,
				t.tra_bureau_version_num,
				t.tra_claim_split_number,
				t.tra_syn_user_number,
				t.tra_syndicate_net_amount 
				--into #cte_basever
				from [Eurobase].[transaction_01] t
				join 
				(
				select t.tra_bureau_signing_date,
				t.tra_bureau_signing_num,
				t.tra_treaty_section,
				min(t.tra_bureau_version_num) tra_bureau_version_num,
				t.tra_claim_split_number,
				t.tra_syn_user_number
				from [Eurobase].[transaction_01] t
				where t.tra_bureau_version_num >= 0 
				and t.tra_lloyds_ca_cat_code IN ('1','2', '3')
				and t.tra_year_of_account >= '2004'
				and t.tra_syndicate_net_amount <> 0
				group by tra_bureau_signing_date,
				t.tra_bureau_signing_num,
				t.tra_treaty_section,
				t.tra_claim_split_number,
				t.tra_syn_user_number
				) b
				on 
				(
				b.tra_bureau_signing_date = t.tra_bureau_signing_date
				and b.tra_bureau_signing_num = t.tra_bureau_signing_num
				and b.tra_bureau_version_num = t.tra_bureau_version_num
				and b.tra_treaty_section = t.tra_treaty_section
				--and b.tra_claim_split_number = a.tra_claim_split_number
				and b.tra_syn_user_number = t.tra_syn_user_number)
				where t.tra_lloyds_ca_cat_code IN ('1','2', '3')
				and t.tra_year_of_account >= '2004'
				)
, cte_restate as(
--drop table if exists #cte_restate

				select a.tra_bureau_signing_date,
				a.tra_bureau_signing_num,
				a.tra_treaty_section,
				b.tra_bureau_version_num,
				b.tra_claim_split_number,
				a.tra_syn_user_number,
				abs(a.tra_syndicate_net_amount) BaseVal,
				abs(b.tra_syndicate_net_amount) NewVal,
				abs(b.tra_syndicate_net_amount) / abs(a.tra_syndicate_net_amount) 
					* (CASE WHEN b.tra_bureau_version_num < 0 THEN - 1 ELSE 1 END) AS ChangeFactor 
				--into #cte_restate
				from cte_basever a
				inner join [Eurobase].[transaction_01] b
				on (b.tra_bureau_signing_date = a.tra_bureau_signing_date
				and	b.tra_bureau_signing_num = a.tra_bureau_signing_num
				and b.tra_treaty_section = a.tra_treaty_section
				--and b.tra_claim_split_number = a.tra_claim_split_number
				and b.tra_syn_user_number = a.tra_syn_user_number
				and b.tra_bureau_version_num <> a.tra_bureau_version_num
				and b.tra_lloyds_ca_cat_code IN ('1','2', '3')
				and b.tra_year_of_account >= '2004'
				and b.tra_syndicate_net_amount <> 0)
				)
,cte_net as (
--drop table if exists #cte_net

				select 	CONVERT([VARCHAR](2),'A')  Scenario ,                                                  
				CONVERT([VARCHAR](2),'B') Basis,                                                        
				CONCAT(CASE ISNULL(t.tra_lloyds_ca_cat_code,'-')
							 WHEN '1' THEN 'PC-'
							 WHEN '2' THEN 'PC-'
							 WHEN '3' THEN 'PC-'
							 WHEN '4' THEN 'CC-'
							 WHEN '5' THEN 'CC-'
							 ELSE 'XX-' 
						 END,
						 CASE 
							 WHEN ISNULL(t.tra_lloyds_account_type,'-') = 'A' THEN 'LS-'
							 WHEN ISNULL(t.tra_lloyds_account_type,'-') in ('S','L') AND YEAR(tra_actual_payment_date) = '9999' THEN 'SD-'
							 ELSE 'OS-' 
						 END,
						 CASE 
							 WHEN t.tra_lloyds_ca_cat_code	IN ('4','5') THEN ISNULL(NULLIF(t.tra_business_category,''),'OT')
							 WHEN ISNULL(t.tra_lloyds_ca_qual_cat,'-')	IN ('H')		
								  AND cc.cob_tri_group IN ('Cat','Ex Cat','Treaty Misc','Clash')	THEN 'RT'  --Remove Non-Treaties from RIP's
							 WHEN ISNULL(t.tra_lloyds_ca_qual_cat,'-')	IN ('I') AND ISNULL(t.tra_entry_type,'-')    IN ('CRP','CAP')	THEN 'PC'
							 ELSE 'OT'
						 END
						) Account,
				'LPSO' as Dataset,
				t.tra_processing_period ,

				CASE WHEN t.tra_processing_period > ( CASE WHEN ti.ins_actual_payment_date IS NOT NULL THEN ti.ins_actual_payment_date
														   WHEN DATEPART(Year, t.tra_actual_payment_date) = '9999' THEN t.tra_bureau_signing_date
														   ELSE t.tra_actual_payment_date
													  END) THEN t.tra_processing_period
									 
					 ELSE ( CASE WHEN ti.ins_actual_payment_date IS NOT NULL THEN ti.ins_actual_payment_date
														   WHEN DATEPART(Year, t.tra_actual_payment_date) = '9999' THEN t.tra_bureau_signing_date
														   ELSE t.tra_actual_payment_date
							END)
				END DateOfFact,
				CONVERT([VARCHAR](255),
																	CONCAT
																	(
																		ISNULL(CONVERT(varchar(8),t.[tra_bureau_signing_date],112),''),'|',
																		ISNULL(CONVERT(varchar(30),t.[tra_bureau_signing_num]),'') ,'|',
																		ISNULL(CONVERT(varchar(2),t.[tra_treaty_section]),'') ,'|',
																		ISNULL(CONVERT(varchar(30),t.[tra_bureau_version_num]),'') ,'|',
																		ISNULL(CONVERT(varchar(30),t.[tra_claim_split_number]),'') ,'|',
																		ISNULL(CONVERT(varchar(30),t.[tra_syn_user_number]),''),'|',
																		CONVERT(VARCHAR(50),ISNULL(ti.ins_instalment_num,0)))
				) BusinessKey,
				CONVERT([VARCHAR](255),t.[tra_policy_ref]) PolicyNumber,
				CONVERT([DATETIME],ISNULL(cp.cpd_inception,'19800101')) InceptionDate,
				CONVERT([DATETIME],ISNULL(cp.cpd_expiry,'19800101')) ExpiryDate,
				CONVERT([DATETIME],'01/01/1980') BindDate,
				CONVERT([DATETIME],'01/01/1980') DueDate,
				CONVERT([VARCHAR](25),ISNULL(CASE WHEN cc.cob_dept = 'Specialty Lines' THEN f_tf.TriFocusCode ELSE cc_tf.TriFocusCode END,'UNKNOWN')) TrifocusCode,
				CONVERT([VARCHAR](10),t.[tra_syn_user_number]) Entity,
				CONVERT([VARCHAR](50),'-') [Location],
				CONVERT([VARCHAR](5),t.[tra_year_of_account]) Yoa,
				CONVERT([VARCHAR](1),'-') TypeOfBusiness,                                       
				CONVERT([VARCHAR](3),t.[tra_settlement_ccy_code]) SettlementCCY,
				CONVERT([VARCHAR](3),t.[tra_settlement_ccy_code]) OriginalCCY,
				CONVERT([VARCHAR](1),'N') IsToDate,
				convert (numeric(38,4),CASE 
																								WHEN ti.ins_pre_br_signing_num IS NULL
																									THEN t.tra_syndicate_net_amount
																								WHEN ti.ins_pre_br_version_num = t.tra_bureau_version_num
																									THEN ti.ins_instalment_amount
																								ELSE ti.ins_instalment_amount * isnull(rs.ChangeFactor, 1)
																								END
																				) [Value],
				CONVERT([DECIMAL](19, 4), CASE WHEN ti.[ins_instalment_amount] IS NOT NULL THEN ti.[ins_instalment_amount]
											   ELSE ISNULL(t.[tra_syndicate_net_amount],0.00) 
										  END) ValueOrig,
				CONVERT([VARCHAR](255),'T1') BusinessProcessCode,
				CONVERT([VARCHAR](255),'-')  AuditSourceBatchID,                                                
				CONVERT([VARCHAR](255),(SERVERPROPERTY('MachineName'))) AuditHost,    
				CONVERT([VARCHAR](25),'-') StatsCode,
				CONVERT([INT],NULL) FK_Batch
				--into #cte_net
				from		[Eurobase].[transaction_01]				 AS t 
	
				JOIN	[Eurobase].[policy_details_01] pd 
										ON		t.tra_policy_ref = pd.pol_cpd_policy_reference
										AND		t.tra_syn_user_number = pd.pol_syn_user_number

				JOIN	[Eurobase].cob_codes					AS cc					
										ON		pd.pol_cob_code = cc.cob_code 
				
				LEFT JOIN fdm.DimTrifocus cc_tf                
										ON cc_tf.TrifocusName = cc.cob_tri_group

				LEFT JOIN	[Eurobase].[common_policy_details_01] AS cp
										ON		cp.cpd_policy_reference = t.[tra_policy_ref]
								
				LEFT JOIN	[Eurobase].[transaction_instalment]	 AS ti
										ON		ti.ins_pre_br_signing_date	= t.tra_bureau_signing_date  
										AND		ti.ins_pre_br_signing_num	= t.tra_bureau_signing_num 
										AND		(
													ti.ins_pre_br_version_num = t.tra_bureau_version_num
													OR ti.ins_pre_br_version_num = - t.tra_bureau_version_num
													OR ti.ins_pre_br_version_num = abs(t.tra_bureau_version_num) % 100
												)
										AND		ti.ins_syn_user_number		= t.tra_syn_user_number 
										AND		ti.ins_pre_treaty_section	= t.tra_treaty_section
										and ti.ins_actual_payment_date is not null
										and ti.ins_pre_br_version_num >=0


				
				LEFT JOIN [Eurobase].focus_area_new	f			
										ON				f.foc_udt_initials = cp.cpd_udt_initials
										AND		f.foc_cob_code = pd.pol_cob_code
										AND		f.foc_mop_code = pd.pol_mop_code
										AND		f.foc_stats_code = pd.pol_stats_code
										AND		f.foc_risk_class = t.tra_lloyds_risk_class
		
				LEFT JOIN fdm.DimTrifocus f_tf            
										ON		f_tf.TrifocusName = f.foc_area

				--LEFT JOIN [Eurobase].[policy_deductions] pded 
				--						ON		pded.ded_cpd_policy_ref = t.tra_policy_ref

				
				LEFT JOIN Eurobase.[claim_details_01] cd 
										ON		cd.cla_unified_claim_ref=t.tra_cla_uni_claim_ref
										AND		cd.cla_originating_bureau=t.tra_cla_orig_bureau

				LEFT JOIN mds.vw_CatCode vcc 
										ON ISNULL(cd.cla_clg_group_code,'')=ISNULL(vcc.BeazleyCatCode,'')

				LEFT JOIN			cte_restate rs 
																ON (
																	rs.tra_bureau_signing_date = t.tra_bureau_signing_date
																	AND rs.tra_bureau_signing_num = t.tra_bureau_signing_num
																	AND rs.tra_bureau_version_num = t.tra_bureau_version_num
																	AND rs.tra_claim_split_number = t.tra_claim_split_number
																	AND rs.tra_syn_user_number = t.tra_syn_user_number
																	AND rs.tra_treaty_section = t.tra_treaty_section
																	)

				WHERE	t.tra_year_of_account >= '2004'
				
										AND		(	CASE WHEN ti.[ins_instalment_amount] IS NOT NULL THEN ti.[ins_instalment_amount]
														 ELSE ISNULL(t.[tra_syndicate_net_amount],0.00) 
													END) <> 0.00
						

				AND		[tra_policy_ref] <> '!!!!INVALID' 
						
				AND t.[tra_lloyds_ca_cat_code] in ('1', '2', '3','4','5')  

				and t.tra_syndicate_net_amount <> 0
			
				AND		(vcc.BeazleyCatCode  NOT LIKE '%LF' or vcc.BeazleyCatCode IS NULL)
				)
, cte_ded as(

--drop table if exists #cte_ded

					select ded_cpd_policy_ref, 
					ded_pcnt, DedType, 
					max(ded_pcnt) over (partition by ded_cpd_policy_ref) tot_ded
					--into #cte_ded --drop table #cte_ded
					from
					(
					select ded_cpd_policy_ref, sum([ded_pcnt]) ded_pcnt, 'BC' DedType
					from [Eurobase].[policy_deductions] pded
					where ded_qual <> 'X'
					and [ded_pcnt] <> 0
					group by ded_cpd_policy_ref	

					union all

					select ded_cpd_policy_ref, sum([ded_pcnt]) ded_pcnt, 'LBSC' DedType
					from [Eurobase].[policy_deductions] pded
					where ded_qual = 'X'
					and [ded_pcnt] <> 0
					group by ded_cpd_policy_ref

					union all

					select ded_cpd_policy_ref, sum([ded_pcnt]) ded_pcnt, 'Tot' DedType
					from [Eurobase].[policy_deductions] pded
					group by ded_cpd_policy_ref
					) t
					)

--drop table if exists #tmp

select Scenario,                                                  
Basis,         
tra_processing_period as ProcessingPeriod,
case when d.DedType = 'BC' then replace(Account, 'PC-', 'BC-')
	 when d.DedType = 'LBSC' then replace(Account, 'PC-', 'LBSC-')
	 else Account
end Account,
Dataset,
DateOfFact,
BusinessKey,
PolicyNumber,
InceptionDate,
ExpiryDate,
BindDate,
DueDate,
TrifocusCode,
Entity,
[Location],
Yoa,
TypeOfBusiness,                                       
SettlementCCY,
OriginalCCY,
IsToDate,
case when d.DedType = 'Tot' then [Value]/ (1 - isnull(d.ded_pcnt, 0)/100)
	 when d.DedType in ('BC', 'LBSC') then [Value] * (d.ded_pcnt/100) / (1 - isnull(d.tot_ded, 0)/100)
	 else [Value]
end * (case when (Account like '%-PC' or Account like 'CC%') then -1 else 1 end) [Value],
case when d.DedType = 'Tot' then [Value]/ (1 - d.ded_pcnt/100)
	 when d.DedType in ('BC', 'LBSC') then [Value] * (d.ded_pcnt/100) / (1 - isnull(d.tot_ded, 0)/100)
	 else [Value]
end * (case when (Account like '%-PC' or Account like 'CC%') then -1 else 1 end)[ValueOrig],
t.BusinessProcessCode,
AuditSourceBatchID,                                                
AuditHost,    
StatsCode,
FK_Batch --into #tmp
from cte_net t
left join cte_ded d 
	on (d.ded_cpd_policy_ref = t.PolicyNumber
	    and t.Account like 'PC-%'
		and t.Account not like '%-RT'
		and t.Account not like '%-PC')



GO