﻿CREATE VIEW [Eurobase].[vw_ReInsuranceFac]
AS
WITH cte_fac_rid
AS (
		SELECT		ri.pfl_cpd_policy_reference
					,MIN(rid.fac_period_from) fac_period_from
					,MAX(rid.fac_period_to) fac_period_to
		FROM		[Eurobase].policy_fac_ri ri
		LEFT JOIN	[Eurobase].policy_fac_ri_details rid 
					ON (rid.fac_number = ri.pfl_fac_number)
		GROUP BY ri.pfl_cpd_policy_reference
   )
   ,cte_restate
				AS (
						SELECT		a.tra_bureau_signing_date
									,a.tra_bureau_signing_num
									,a.tra_treaty_section
									,b.tra_bureau_version_num
									,b.tra_claim_split_number
									,a.tra_syn_user_number
									,a.BaseVal
									,b.NewVal
									,(b.NewVal / a.BaseVal) * (
																CASE WHEN b.tra_bureau_version_num < 0
																		THEN - 1
																	 ELSE 1
																END
															) AS ChangeFactor
						FROM (
									SELECT		tra_bureau_signing_date
												,t.tra_bureau_signing_num
												,t.tra_treaty_section
												,t.tra_bureau_version_num
												,t.tra_claim_split_number
												,t.tra_syn_user_number
												,abs(t.tra_syndicate_net_amount) BaseVal
									FROM		[Eurobase].[transaction_01] t
									WHERE		t.tra_bureau_version_num = 1
												AND t.tra_lloyds_ca_cat_code IN ('6','7')
												AND t.tra_year_of_account >= '1993'
							) a
						INNER JOIN 
							  (
									SELECT		tra_bureau_signing_date
												,t.tra_bureau_signing_num
												,t.tra_treaty_section
												,t.tra_bureau_version_num
												,t.tra_claim_split_number
												,t.tra_syn_user_number
												,abs(t.tra_syndicate_net_amount) NewVal
									FROM		[Eurobase].[transaction_01] t
									WHERE		t.tra_bureau_version_num <> 1
												AND t.tra_lloyds_ca_cat_code IN ('6','7')
												AND t.tra_year_of_account >= '1993'
								) b ON			b.tra_bureau_signing_date = a.tra_bureau_signing_date
									AND			b.tra_bureau_signing_num = a.tra_bureau_signing_num
									AND			b.tra_treaty_section = a.tra_treaty_section
									--and b.tra_claim_split_number = a.tra_claim_split_number
									AND			b.tra_syn_user_number = a.tra_syn_user_number
									--where isnull(RevVal, 0) <> 0
					)




					 

		SELECT				RIPolicyType	= 'FAC'-- not using ri.fac_policy_type, but the join ensures this is a FAC re-insurance policy
							,Account		= CASE 
													WHEN t.tra_lloyds_ca_cat_code IN (
															'6'
															,'7'
															)
														THEN 'PC'
													ELSE 'CC'
											  END --AS AccountL1,
												+ '-' + 
											  CASE 
													WHEN	t.tra_lloyds_account_type = 'A'
															THEN 'LS'
													WHEN	t.tra_lloyds_account_type IN ('S','L')
															AND year(t.tra_actual_payment_date) = '9999'
															THEN 'SD'
													ELSE 'OS'
											  END --AS AccountL2,
												+ '-' + 
											  CASE 
													WHEN t.tra_lloyds_ca_cat_code IN ('6','7')
															THEN  CASE WHEN t.tra_lloyds_ca_qual_cat = 'H'
																		THEN 'RT'
																		ELSE 'RP'
																   END
														-- 'UN'
													WHEN mkt.LargeLossIndicator = 1
															   THEN 'LL'
													ELSE 'ATT'
											 END
											  +'-'+
											 'FAC' ,-- LEVEL 4
							RIPolicyNumber	= t.tra_policy_ref
							,BusinessKey	= CONVERT([VARCHAR](255), CONCAT (
																			ISNULL(CONVERT(VARCHAR(8), t.[tra_bureau_signing_date], 112), '')
																			,'|'
																			,ISNULL(CONVERT(VARCHAR(30), t.[tra_bureau_signing_num]), '')
																			,'|'
																			,ISNULL(CONVERT(VARCHAR(2), t.[tra_treaty_section]), '')
																			,'|'
																			,ISNULL(CONVERT(VARCHAR(30), t.[tra_bureau_version_num]), '')
																			,'|'
																			,ISNULL(CONVERT(VARCHAR(30), t.[tra_claim_split_number]), '')
																			,'|'
																			,ISNULL(CONVERT(VARCHAR(30), t.[tra_syn_user_number]), '')
																			,'|'
																			,CONVERT(VARCHAR(50), ISNULL(ti.ins_instalment_num, 0))
																			)
													 )
							,DateOfFact		= CASE 
													WHEN t.tra_processing_period > (
															CASE 
																WHEN ti.ins_actual_payment_date IS NOT NULL
																	THEN ti.ins_actual_payment_date
																WHEN DATEPART(Year, t.tra_actual_payment_date) = '9999'
																	THEN t.tra_bureau_signing_date
																ELSE t.tra_actual_payment_date
																END
															)
														THEN t.tra_processing_period
													ELSE (
															CASE 
																WHEN ti.ins_actual_payment_date IS NOT NULL
																	THEN ti.ins_actual_payment_date
																WHEN DATEPART(Year, t.tra_actual_payment_date) = '9999'
																	THEN t.tra_bureau_signing_date
																ELSE t.tra_actual_payment_date
																END
															)
													END
							,TransactionDate = CASE 
													WHEN ti.ins_actual_payment_date IS NOT NULL
														THEN ti.ins_actual_payment_date
													WHEN DATEPART(Year, t.tra_actual_payment_date) = '9999'
														THEN t.tra_bureau_signing_date
													ELSE t.tra_actual_payment_date
												END
							,RIInceptionDate = ISNULL(rid.fac_period_from, '1980-01-01')
							,RIExpiryDate	 = ISNULL(rid.fac_period_to, '1980-01-01')
							,TriFocus		 = CASE 
													WHEN cob.cob_dept <> 'Specialty Lines'
														THEN cob.cob_tri_group
													ELSE foc.foc_area
												END
							,Entity			 = t.tra_syn_user_number
							,YOA			 = t.tra_year_of_account
							,SettlementCCY	 = t.tra_settlement_ccy_code
							,BeazleyCatCode  = NULLIF(cd.cla_clg_group_code, '')
							-- Date fields to establish Timing differences when performing Validation
							,TransBureauSigndate	= t.tra_bureau_signing_date
							,TransActualPaymentdate = t.tra_actual_payment_date
							,TransProcessingPeriod	= t.tra_processing_period
							,TransInstalmentDate	= ti.ins_instalment_due_date
							,IsLargeLoss			= CONVERT(BIT, CASE 
																		WHEN mkt.LargeLossIndicator = 1
																			THEN 1
																		ELSE 0
																	END
															  )
							,[Value]				= convert (numeric(38,4),CASE 
																				WHEN ti.ins_pre_br_signing_num IS NULL
																					THEN t.tra_syndicate_net_amount
																				WHEN ti.ins_pre_br_version_num = t.tra_bureau_version_num
																					THEN ti.ins_instalment_amount
																				ELSE ti.ins_instalment_amount * isnull(rs.ChangeFactor, 1)
																				END
																)   -- This is resulting as Float datatype as causing issues, hence convert to decimal. SHould be remove part of I1B-3084
																--convert(numeric(38,4),Amount)
							FROM				[Eurobase].transaction_01 t

							LEFT JOIN			[Eurobase].[claim_details_01] cd 
												ON cd.cla_unified_claim_ref		= t.tra_cla_uni_claim_ref
												AND cd.cla_originating_bureau	= t.tra_cla_orig_bureau

							LEFT JOIN			[Eurobase].transaction_instalment ti 
												ON ti.ins_pre_br_signing_date	= t.tra_bureau_signing_date
												AND ti.ins_pre_br_signing_num	= t.tra_bureau_signing_num
												AND (
													ti.ins_pre_br_version_num		= t.tra_bureau_version_num
													OR ti.ins_pre_br_version_num	= - t.tra_bureau_version_num
													OR ti.ins_pre_br_version_num	= abs(t.tra_bureau_version_num) % 100
													)
												AND ti.ins_syn_user_number = t.tra_syn_user_number
												AND ti.ins_pre_treaty_section = t.tra_treaty_section
							
							
							JOIN				(select distinct pfl_cpd_policy_reference from [Eurobase].policy_fac_ri) ri
												ON  ri.pfl_cpd_policy_reference = t.tra_policy_ref
							
							LEFT JOIN			cte_fac_rid rid 
												ON (rid.pfl_cpd_policy_reference = t.tra_policy_ref)   -- This Join Ensure the FAC policies are filtered
							
							LEFT JOIN			[Eurobase].policy_details_01 pdet 
												ON (
														pdet.pol_cpd_policy_reference = t.tra_policy_ref
														AND pdet.pol_syn_user_number = t.tra_syn_user_number
													)

							LEFT JOIN		    [Eurobase].common_policy_details_01 cpdet 
												ON (cpdet.cpd_policy_reference = t.tra_policy_ref)

							LEFT JOIN			[Eurobase].cob_codes cob ON (cob.cob_code = pdet.pol_cob_code)

							LEFT JOIN			[Eurobase].[focus_area_new] foc 
												ON (
													foc.foc_cob_code = pdet.pol_cob_code
													AND foc.foc_mop_code = pdet.pol_mop_code
													AND foc.foc_stats_code = pdet.pol_stats_code
													AND foc.foc_risk_class = t.tra_lloyds_risk_class
													AND foc.foc_udt_initials = cpdet.cpd_udt_initials
													)

							LEFT JOIN			MDS.vw_CatCode AS cc 
												ON cd.cla_clg_group_code = cc.BeazleyCatCode

							LEFT JOIN			MDS.vw_CatCode AS mkt 
												ON cc.MarketCatCode = mkt.BeazleyCatCode

							LEFT JOIN			cte_restate rs 
												ON (
													rs.tra_bureau_signing_date = t.tra_bureau_signing_date
													AND rs.tra_bureau_signing_num = t.tra_bureau_signing_num
													AND rs.tra_bureau_version_num = t.tra_bureau_version_num
													AND rs.tra_claim_split_number = t.tra_claim_split_number
													AND rs.tra_syn_user_number = t.tra_syn_user_number
													AND rs.tra_treaty_section = t.tra_treaty_section
													)

							WHERE				t.tra_lloyds_ca_cat_code IN ('6','7','8','9')
												AND t.tra_year_of_account >= 1993






