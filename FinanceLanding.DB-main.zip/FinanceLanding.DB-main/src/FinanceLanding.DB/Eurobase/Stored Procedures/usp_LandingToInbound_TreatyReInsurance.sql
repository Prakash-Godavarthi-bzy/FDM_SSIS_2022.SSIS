﻿CREATE PROCEDURE [Eurobase].[usp_LandingToInbound_TreatyReInsurance] (
	@p_ParentActivityLogId BIGINT = NULL
	,@p_ActivityJobId VARCHAR(50) = NULL
	,@p_AccountingPeriod INT
	)
AS
/* =============================================
-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	18-05-2021
-- Changes:				Loads Treaty ReInsurance data from FinanceLanding to Inbound.Transaction
-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	23-07-2021
-- Changes:				For attribute only changes we using the current date for the date of fact.
-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	10-08-2021
-- Changes:				ProgrammeCode changed and needs to accomodate character length of 100.
-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	26-08-2021
-- Changes:				Code allocations were wrong. I needed to allocate to existing date of fact & just change the fk allocation.
-- Modified by:			entha.bhargav@beazley.com
-- Modification date:	07-08-2022
-- Changes:				Removed read data from Linked server BR1 Data Ingest and replaced with [mds].[ProgrammeTrifocusStaticMapping]
-- Modified by:			entha.bhargav@beazley.com
-- Modification date:	18-05-2023
-- Changes:				https://beazley.atlassian.net/browse/I1B-3832
-- Modified by:			pavani.bandaru@beazley.com
-- Modification date:	26-06-2023
-- Changes:				https://beazley.atlassian.net/browse/I1B-2939

	Altered by:			nithin.dumpeti@beazley.com
	ALtered date:		05-02-2021
	Changes:			Auditing AccountingPeriod in inbound.batchqueue table in column AsAt for passing date as a parameter externally
--------------------------------------------------------------------------
Change Version	: 
Sprint			: 24 Q3 COMMITTED
Author		    : ENTHA BHARGAV ENTHA.BHARGAV@Beazley.com || Pushpal Das
Modify Date	    : 31/07/20204
Description		:  Allocations generating for Claim Cash Accounts https://beazley.atlassian.net/browse/I1B-5519
					Comment blocks Allocation based on Premium and Allocation Based On Incurred are added. Created and handover by PD

-- ======================================================================================================================================================
--------------------------------------------------------------------------
Change Version	: 
Sprint			: 24 Q4 COMMITTED
Author		    : Shah Nawaz Ahmed ShahNawaz.Ahmed@Beazley.com
Modify Date	    : 10/10/20204
Description		:  Unsplit RI LPSO TTY signings due to FAC accounts https://beazley.atlassian.net/browse/I1B-5826
					Added join to get Trifocus for BESI RI FAC, BICI FAC, BAIC FAC for programmes.

--------------------------------------------------------------- 
-- Modified by:			purushothaman.kannan@beazley.com
-- Modification date:	21-02-2025
-- Changes:				https://beazley.atlassian.net/browse/I1B-6031
====================================================================================================================================================== */
BEGIN
	SET NOCOUNT ON;

	DECLARE @Trancount INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);
	DECLARE @v_RC INT;
	DECLARE @v_ActivityLogTag BIGINT;
	DECLARE @v_ActivitySource SMALLINT;
	DECLARE @v_ActivityType SMALLINT;
	DECLARE @v_ActivityStatusStart SMALLINT;
	DECLARE @v_ActivityStatusStop SMALLINT;
	DECLARE @v_ActivityStatusFail SMALLINT;
	DECLARE @v_ActivityHost VARCHAR(100);
	DECLARE @v_ActivityDatabase VARCHAR(100);
	DECLARE @v_ActivityName VARCHAR(100);
	DECLARE @v_ActivityDateTime DATETIME2(2);
	DECLARE @v_ActivityMessage NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn BIGINT;
	DECLARE @v_ActivityLogIdOut BIGINT;
	DECLARE @v_ActivityJobId VARCHAR(50) = @p_ActivityJobId;
	DECLARE @v_ActivitySSISExecutionId VARCHAR(50) = NULL;
	DECLARE @v_AffectedRows INT = 0;
	DECLARE @v_DataSet VARCHAR(255) = 'RI LPSO TTY'
	DECLARE @ContractType CHAR(3) = 'TTY'
	DECLARE @AccountingPeriod INT = @p_AccountingPeriod;--assigning parameter value to loacal variable
	DECLARE @v_AsAt VARCHAR(6);
	-- for debugging. set to 1 & then no records will be written to the inbound tables.
	DECLARE @stop BIT = 0

	SELECT @v_ActivityStatusStart = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'ERRORED';

	DECLARE @v_BatchId INT;
	DECLARE @v_BatchId_Extensions INT;

	/* Log the start of the insert */
	BEGIN TRY
		SELECT @v_ActivityLogTag = NULL
			,@v_ActivitySource = (
				SELECT PK_ActivitySource
				FROM Orchestram.Log.ActivitySource
				WHERE ActivitySource = 'IFRS17'
				)
			,@v_ActivityType = (
				SELECT PK_ActivityType
				FROM Orchestram.Log.ActivityType
				WHERE ActivityType = CASE 
						WHEN @p_ParentActivityLogId IS NULL
							THEN 'Manual process'
						ELSE 'Automated process'
						END
				)
			,@v_ActivityHost = @@SERVERNAME
			,@v_ActivityName = 'Load treaty eurobase re-insurance data into Inbound.Transaction'
			,@v_ActivityDatabase = 'FinanceLanding'
			,@v_ActivityDateTime = GETUTCDATE()
			,@v_ActivityMessage = NULL
			,@v_ActivityErrorCode = NULL;

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStart
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

		--------------------------------------------------
		--------------------------------------------------
		DECLARE @OpeningBalanceDate DATE = '31 December 2018' -- this is the date for the opening balance
		DECLARE @OpeningBalanceCutOffYear INT = year(@OpeningBalanceDate)
		DECLARE @OpeningBalanceAllocationPeriod INT = year(@OpeningBalanceDate) * 100 + month(@OpeningBalanceDate) -- 201812

		SELECT @OpeningBalanceAllocationPeriod --201812

		-- Get all the ReInsurance Treaty data
		DROP TABLE

		IF EXISTS #ReInsuranceTreaty;--474884 match with PD after converting vw value to Decimal/Numeric
			SELECT Account
				,DateOfFact
				,BusinessKey
				,PolicyNumber
				,InceptionDate
				,ExpiryDate
				,Entity
				,YOA
				,CCY
				,[Value]
				-- extended values
				,RIPolicyType
				,ProgrammeCode
				,BeazleyCatCode
				,TransactionDate
				,NULL AS IsLargeLoss ---We cannot associate to claim so has no catcode and hence LargeLoss is NULL	
				-- create an int, yyyymm 202105 for example - used later as a filter against the allocations data.
				,AccPeriod = (year(DateOfFact) * 100 + month(DateOfFact))
				,id = identity(INT, 1, 1) -- used to simplify the check that records have been allocated or not.
			INTO #ReInsuranceTreaty
			FROM (
				SELECT Account = CONVERT(VARCHAR(25), rt.Account)
					-- Change the date to a date - get rid of the time part and aggregate to the day.
					-- 2018Q4 -- i need to sum up to 2018Q4, so any dates before this become '31 December 2018'
					,DateOfFact = CASE 
						WHEN year(rt.DateOfFact) <= @OpeningBalanceCutOffYear
							THEN @OpeningBalanceDate
						ELSE CONVERT(DATE, rt.DateOfFact)
						END
					,BusinessKey = CONVERT(VARCHAR(255), rt.BusinessKey) + '|' + ISNULL(s.SyndSplitEntity, '-')
					,PolicyNumber = CONVERT(VARCHAR(255), rt.RIPolicyNumber)
					,InceptionDate = CONVERT(DATETIME, rt.RIInceptionDate)
					,ExpiryDate = CONVERT(DATETIME, rt.RIExpiryDate)
					,Entity = isnull(s.SyndSplitEntity, cast(rt.Entity AS VARCHAR(25)))
					,YOA = ISNULL(CONVERT(VARCHAR(5), NULLIF(rt.YOA, 0)), 'NOYOA')
					,CCY = CONVERT(VARCHAR(3), rt.SettlementCCY)
					,[Value] = [Value] * isnull(cast(s.SyndSplitPercentage AS DECIMAL(5, 4)), 1.0000) --6031
					-- extended values
					,RIPolicyType = ISNULL(cri.Confirmed_RIPolicyType, rt.RIPolicyType)
					--,ProgrammeCode			= convert(VARCHAR(100),rt.ProgrammeCode) 
					,ProgrammeCode = CONVERT(VARCHAR(100), CASE 
							WHEN (
									rt.RIPolicyNumber LIKE 'Y%'
									OR rt.RIPolicyNumber LIKE 'X%'
									)
								AND rt.ProgrammeCode = 'Dummy - ignore'
								THEN 'GEN (Whole Account)'
							WHEN rt.ProgrammeCode = 'Syndicate 1174 General Excess of Loss'
								THEN 'GEN (Whole Account)'
							WHEN rt.ProgrammeCode = 'BICI FAC'
								THEN 'SL Facultative spend'
							ELSE rt.ProgrammeCode
							END)
					,BeazleyCatCode = convert(VARCHAR(12), rt.BeazleyCatCode)
					,TransactionDate = CONVERT(DATE, rt.TransactionDate)
				FROM [Eurobase].[vw_ReInsuranceTreaty] rt
				LEFT JOIN mds.RITypeMapping cri ON rt.RIPolicyType = cri.RIPolicyType
				LEFT JOIN FinanceLanding.fdm.SyndicateSplitsbyYOA s ON (
						s.SyndSplitSource = cast(rt.Entity AS VARCHAR)
						AND s.SyndSplitYOA = rt.YOA
						)
				) r
			WHERE (year(DateOfFact) * 100 + month(DateOfFact)) <= @AccountingPeriod

		--Combine Allocations 
		DROP TABLE

		IF EXISTS #cte_alloc
			SELECT EntityCode
				,AccountingPeriod
				,
				-- AccountingPeriod=case when AccountingPeriod <= 201812 then 201812 else AccountingPeriod end ,
				YOA
				,ProgrammeCode
				,TrifocusCode
				,TrifocusName
				,Amount
				,TotalAmount
				,MasterRIInd
				,Allocation = (Amount / TotalAmount)
			INTO #cte_alloc
			FROM FinanceLanding.fdm.[vw_ReInsuranceAllocationsGeneric]
			WHERE TotalAmount <> 0
				AND AccountingPeriod <= @AccountingPeriod

		DROP TABLE

		IF EXISTS #cte_alloc_pass2
			SELECT EntityCode
				,AccountingPeriod
				--,AccountingPeriod=case when AccountingPeriod <= 201812 then 201812 else AccountingPeriod end 
				,ProgrammeCode
				,TrifocusCode
				,TrifocusName
				,Amount
				,TotalAmount
				,MasterRIInd
				,(Amount / TotalAmount) Allocation
			INTO #cte_alloc_pass2 --19826 Count match with PD
			FROM (
				SELECT EntityCode
					,AccountingPeriod
					,ProgrammeCode
					,TrifocusCode
					,TrifocusName
					,SUM(Amount) Amount
					,SUM(SUM(Amount)) OVER (
						PARTITION BY EntityCode
						,AccountingPeriod
						,ProgrammeCode
						) TotalAmount
					,MasterRIInd
				FROM #cte_alloc
				WHERE MasterRIInd = 'N'
				GROUP BY EntityCode
					,AccountingPeriod
					,ProgrammeCode
					,TrifocusCode
					,TrifocusName
					,MasterRIInd
				
				UNION ALL
				
				SELECT EntityCode
					,AccountingPeriod
					,ProgrammeCode
					,TrifocusCode
					,TrifocusName
					,SUM(Amount) Amount
					,SUM(SUM(Amount)) OVER (
						PARTITION BY EntityCode
						,AccountingPeriod
						) TotalAmount
					,MasterRIInd
				FROM #cte_alloc
				WHERE MasterRIInd = 'Y'
				GROUP BY EntityCode
					,AccountingPeriod
					,ProgrammeCode
					,TrifocusCode
					,TrifocusName
					,MasterRIInd
				) t
			WHERE TotalAmount <> 0

		DROP TABLE

		IF EXISTS #cte_latestalloc --select * from #cte_latestalloc
			SELECT AccountingPeriod
				,t.EntityCode
				,t.ProgrammeCode
				,t.YOA
				,t.TrifocusCode
				,t.Amount
				,t.TotalAmount
				,t.Allocation
				,t.MasterRIInd
			INTO #cte_latestalloc
			FROM #cte_alloc t
			JOIN (
				SELECT t.ProgrammeCode
					,t.EntityCode
					,t.YOA
					,t.MasterRIInd
					,max(t.AccountingPeriod) MaxAccountingPeriod
				FROM #cte_alloc t
				WHERE MasterRIInd = 'N'
				GROUP BY t.ProgrammeCode
					,t.EntityCode
					,t.YOA
					,t.MasterRIInd
				) m ON (
					m.ProgrammeCode = t.ProgrammeCode
					AND m.EntityCode = t.EntityCode
					AND m.YOA = t.YOA
					AND m.MaxAccountingPeriod = t.AccountingPeriod
					AND m.MasterRIInd = t.MasterRIInd
					)
			WHERE 1 = 1
				--abs(TotalAmount)>10    -- Check with PD 
				AND t.MasterRIInd = 'N'
			
			UNION ALL
			
			SELECT AccountingPeriod
				,t.EntityCode
				,t.ProgrammeCode
				,t.YOA
				,t.TrifocusCode
				,t.Amount
				,t.TotalAmount
				,t.Allocation
				,t.MasterRIInd
			FROM #cte_alloc t
			JOIN (
				SELECT t.EntityCode
					,t.YOA
					,t.MasterRIInd
					,max(t.AccountingPeriod) MaxAccountingPeriod
				FROM #cte_alloc t
				WHERE t.MasterRIInd = 'Y'
				GROUP BY t.EntityCode
					,t.YOA
					,t.MasterRIInd
				) m ON (
					m.EntityCode = t.EntityCode
					AND m.YOA = t.YOA
					AND m.MaxAccountingPeriod = t.AccountingPeriod
					AND m.MasterRIInd = t.MasterRIInd
					)
			WHERE 1 = 1
				--abs(TotalAmount)>10
				AND t.MasterRIInd = 'Y'

		DROP TABLE

		IF EXISTS #cte_latestalloc_pass2 --select * from #cte_latestalloc
			SELECT AccountingPeriod
				,t.EntityCode
				,t.ProgrammeCode
				,t.TrifocusCode
				,t.Amount Amount
				,t.TotalAmount TotalAmount
				,t.Allocation Allocation
				,t.MasterRIInd
			INTO #cte_latestalloc_pass2
			FROM #cte_alloc_pass2 t
			JOIN (
				SELECT t.ProgrammeCode
					,t.EntityCode
					,t.MasterRIInd
					,max(t.AccountingPeriod) MaxAccountingPeriod
				FROM #cte_alloc t
				WHERE MasterRIInd = 'N'
				GROUP BY t.ProgrammeCode
					,t.EntityCode
					,t.MasterRIInd
				) m ON (
					m.ProgrammeCode = t.ProgrammeCode
					AND m.EntityCode = t.EntityCode
					AND m.MaxAccountingPeriod = t.AccountingPeriod
					AND m.MasterRIInd = t.MasterRIInd
					)
			WHERE 1 = 1
				--abs(TotalAmount)>10
				AND t.MasterRIInd = 'N' --See if can exlcude this filter
			
			UNION ALL
			
			SELECT AccountingPeriod
				,t.EntityCode
				,t.ProgrammeCode
				,t.TrifocusCode
				,t.Amount Amount
				,t.TotalAmount TotalAmount
				,t.Allocation Allocation
				,t.MasterRIInd
			FROM #cte_alloc_pass2 t
			JOIN (
				SELECT t.EntityCode
					,t.MasterRIInd
					,MAX(t.AccountingPeriod) MaxAccountingPeriod
				FROM #cte_alloc t
				WHERE t.MasterRIInd = 'Y'
				GROUP BY t.EntityCode
					,t.MasterRIInd
				) m ON (
					m.EntityCode = t.EntityCode
					AND m.MaxAccountingPeriod = t.AccountingPeriod
					AND m.MasterRIInd = t.MasterRIInd
					)
			WHERE 1 = 1
				--abs(TotalAmount)>10
				AND t.MasterRIInd = 'Y'

--Combine Allocations Incurred
		DROP TABLE

		IF EXISTS #cte_alloc_inc
			SELECT EntityCode
				,AccountingPeriod
				,
				-- AccountingPeriod=case when AccountingPeriod <= 201812 then 201812 else AccountingPeriod end ,
				YOA
				,ProgrammeCode
				,TrifocusCode
				,TrifocusName
				,Amount
				,TotalAmount
				,MasterRIInd
				,Allocation = (Amount / TotalAmount)
			INTO #cte_alloc_inc
			FROM FinanceLanding.[fdm].[vw_ReInsuranceAllocationsIncurred]
			WHERE TotalAmount <> 0
				AND AccountingPeriod <= @AccountingPeriod

		DROP TABLE

		IF EXISTS #cte_alloc_inc_pass2
			SELECT EntityCode
				,AccountingPeriod
				--,AccountingPeriod=case when AccountingPeriod <= 201812 then 201812 else AccountingPeriod end 
				,ProgrammeCode
				,TrifocusCode
				,TrifocusName
				,Amount
				,TotalAmount
				,MasterRIInd
				,(Amount / TotalAmount) Allocation
			INTO #cte_alloc_inc_pass2 --19826 Count match with PD
			FROM (
				SELECT EntityCode
					,AccountingPeriod
					,ProgrammeCode
					,TrifocusCode
					,TrifocusName
					,SUM(Amount) Amount
					,SUM(SUM(Amount)) OVER (
						PARTITION BY EntityCode
						,AccountingPeriod
						,ProgrammeCode
						) TotalAmount
					,MasterRIInd
				FROM #cte_alloc_inc
				WHERE MasterRIInd = 'N'
				GROUP BY EntityCode
					,AccountingPeriod
					,ProgrammeCode
					,TrifocusCode
					,TrifocusName
					,MasterRIInd
				
				UNION ALL
				
				SELECT EntityCode
					,AccountingPeriod
					,ProgrammeCode
					,TrifocusCode
					,TrifocusName
					,SUM(Amount) Amount
					,SUM(SUM(Amount)) OVER (
						PARTITION BY EntityCode
						,AccountingPeriod
						) TotalAmount
					,MasterRIInd
				FROM #cte_alloc_inc
				WHERE MasterRIInd = 'Y'
				GROUP BY EntityCode
					,AccountingPeriod
					,ProgrammeCode
					,TrifocusCode
					,TrifocusName
					,MasterRIInd
				) t
			WHERE TotalAmount <> 0

		DROP TABLE

		IF EXISTS #cte_latestalloc_inc --select * from #cte_latestalloc
			SELECT AccountingPeriod
				,t.EntityCode
				,t.ProgrammeCode
				,t.YOA
				,t.TrifocusCode
				,t.Amount
				,t.TotalAmount
				,t.Allocation
				,t.MasterRIInd
			INTO #cte_latestalloc_inc
			FROM #cte_alloc_inc t
			JOIN (
				SELECT t.ProgrammeCode
					,t.EntityCode
					,t.YOA
					,t.MasterRIInd
					,max(t.AccountingPeriod) MaxAccountingPeriod
				FROM #cte_alloc_inc t
				WHERE MasterRIInd = 'N'
				GROUP BY t.ProgrammeCode
					,t.EntityCode
					,t.YOA
					,t.MasterRIInd
				) m ON (
					m.ProgrammeCode = t.ProgrammeCode
					AND m.EntityCode = t.EntityCode
					AND m.YOA = t.YOA
					AND m.MaxAccountingPeriod = t.AccountingPeriod
					AND m.MasterRIInd = t.MasterRIInd
					)
			WHERE 1 = 1
				--abs(TotalAmount)>10    -- Check with PD 
				AND t.MasterRIInd = 'N'
			
			UNION ALL
			
			SELECT AccountingPeriod
				,t.EntityCode
				,t.ProgrammeCode
				,t.YOA
				,t.TrifocusCode
				,t.Amount
				,t.TotalAmount
				,t.Allocation
				,t.MasterRIInd
			FROM #cte_alloc_inc t
			JOIN (
				SELECT t.EntityCode
					,t.YOA
					,t.MasterRIInd
					,max(t.AccountingPeriod) MaxAccountingPeriod
				FROM #cte_alloc_inc t
				WHERE t.MasterRIInd = 'Y'
				GROUP BY t.EntityCode
					,t.YOA
					,t.MasterRIInd
				) m ON (
					m.EntityCode = t.EntityCode
					AND m.YOA = t.YOA
					AND m.MaxAccountingPeriod = t.AccountingPeriod
					AND m.MasterRIInd = t.MasterRIInd
					)
			WHERE 1 = 1
				--abs(TotalAmount)>10
				AND t.MasterRIInd = 'Y'

		DROP TABLE

		IF EXISTS #cte_latestalloc_inc_pass2 --select * from #cte_latestalloc
			SELECT AccountingPeriod
				,t.EntityCode
				,t.ProgrammeCode
				,t.TrifocusCode
				,t.Amount Amount
				,t.TotalAmount TotalAmount
				,t.Allocation Allocation
				,t.MasterRIInd
			INTO #cte_latestalloc_inc_pass2
			FROM #cte_alloc_inc_pass2 t
			JOIN (
				SELECT t.ProgrammeCode
					,t.EntityCode
					,t.MasterRIInd
					,max(t.AccountingPeriod) MaxAccountingPeriod
				FROM #cte_alloc_inc t
				WHERE MasterRIInd = 'N'
				GROUP BY t.ProgrammeCode
					,t.EntityCode
					,t.MasterRIInd
				) m ON (
					m.ProgrammeCode = t.ProgrammeCode
					AND m.EntityCode = t.EntityCode
					AND m.MaxAccountingPeriod = t.AccountingPeriod
					AND m.MasterRIInd = t.MasterRIInd
					)
			WHERE 1 = 1
				--abs(TotalAmount)>10
				AND t.MasterRIInd = 'N' --See if can exlcude this filter
			
			UNION ALL
			
			SELECT AccountingPeriod
				,t.EntityCode
				,t.ProgrammeCode
				,t.TrifocusCode
				,t.Amount Amount
				,t.TotalAmount TotalAmount
				,t.Allocation Allocation
				,t.MasterRIInd
			FROM #cte_alloc_inc_pass2 t
			JOIN (
				SELECT t.EntityCode
					,t.MasterRIInd
					,MAX(t.AccountingPeriod) MaxAccountingPeriod
				FROM #cte_alloc_inc t
				WHERE t.MasterRIInd = 'Y'
				GROUP BY t.EntityCode
					,t.MasterRIInd
				) m ON (
					m.EntityCode = t.EntityCode
					AND m.MaxAccountingPeriod = t.AccountingPeriod
					AND m.MasterRIInd = t.MasterRIInd
					)
			WHERE 1 = 1
				--abs(TotalAmount)>10
				AND t.MasterRIInd = 'Y'


--Allocation Based On Incurred
	DROP TABLE

		IF EXISTS #TempInboundTransactionInIt1_Inc --4695753
			SELECT t.Account
				,t.BusinessKey
				,--+'|'+isnull(v.TrifocusCode, 'UNKNOWN')  as BusinessKey,
				t.PolicyNumber
				,t.InceptionDate
				,t.ExpiryDate
				,[FK_Allocation] = CONVERT(INT, v.[AccountingPeriod])
				,t.BeazleyCatCode
				,t.TransactionDate
				,t.IsLargeLoss
				,t.accPeriod
				,t.RIPolicyType
				,IsMasterRI = CASE 
					WHEN t.ProgrammeCode = 'Master RI'
						THEN 'Y'
					ELSE 'N'
					END
				,ProgrammeCode = ISNULL(CASE 
						WHEN t.ProgrammeCode = 'Master RI'
							THEN coalesce(v.ProgrammeCode, t.ProgrammeCode)
						ELSE t.ProgrammeCode
						END, 'UNKNOWN')
				,en.ConformedEntityMapping Entity
				,(t.[Value]) AS [Value]
				,--can be commented/remove
				t.YOA
				,t.CCY
				,DateOfFact = CASE 
					WHEN t.DateOfFact <= '2018-12-31'
						THEN '2018-12-31'
					ELSE t.DateOfFact
					END
				,TrifocusCode = ISNULL(v.TrifocusCode, 'UNKNOWN')
				,AllocatedValue = (CONVERT(NUMERIC(19, 4), sum(t.[Value] * isnull(v.Allocation, 1)))) --sum([value] * isnull(v.Allocation, 1)) AllocatedValue  
			INTO #TempInboundTransactionInIt1_Inc --select * from #source_pass1
			FROM #ReInsuranceTreaty t
			LEFT JOIN FinanceLanding.mds.ConformedEntityMapping en ON (en.Entity = cast(t.Entity AS VARCHAR))
			LEFT JOIN #cte_latestalloc_inc v ON (
					t.Account like 'CC%'
					AND v.EntityCode = en.ConformedEntityMapping
					AND v.ProgrammeCode = CASE 
						WHEN v.MasterRIInd = 'Y'
							THEN v.ProgrammeCode
						ELSE t.ProgrammeCode
						END
					AND v.YOA = t.YOA
					AND v.AccountingPeriod >= cast(left(convert(VARCHAR, CASE 
									WHEN t.DateOfFact < '2018-12-31'
										THEN '2018-12-31'
									ELSE t.DateOfFact
									END, 112), 6) AS INT)
					AND (
						(
							v.MasterRIInd = 'N'
							AND t.ProgrammeCode <> 'Master RI'
							)
						OR (
							v.MasterRIInd = 'Y'
							AND t.ProgrammeCode = 'Master RI'
							)
						)
					)
			GROUP BY t.BusinessKey --+'|'+isnull(v.TrifocusCode, 'UNKNOWN') ,
				,ISNULL(CASE 
						WHEN t.ProgrammeCode = 'Master RI'
							THEN coalesce(v.ProgrammeCode, t.ProgrammeCode)
						ELSE t.ProgrammeCode
						END, 'UNKNOWN')
				,en.ConformedEntityMapping
				,t.[Value]
				,t.YOA
				,CASE 
					WHEN t.DateOfFact <= '2018-12-31'
						THEN '2018-12-31'
					ELSE t.DateOfFact
					END
				,t.CCY
				,isnull(v.TrifocusCode, 'UNKNOWN')
				,t.PolicyNumber
				,t.InceptionDate
				,t.ExpiryDate
				,CONVERT(INT, v.[AccountingPeriod])
				,t.BeazleyCatCode
				,t.TransactionDate
				,t.IsLargeLoss
				,t.accPeriod
				,t.RIPolicyType
				,t.Account
				,CASE 
					WHEN t.ProgrammeCode = 'Master RI'
						THEN 'Y'
					ELSE 'N'
					END


		DROP TABLE

		IF EXISTS #TempInboundTransactionInIt2_Inc
			SELECT t.Account
				,t.BusinessKey
				,t.PolicyNumber
				,t.InceptionDate
				,t.ExpiryDate
				,
				--t.[FK_Allocation],
				FK_Allocation = CASE 
					WHEN t.TrifocusCode = 'UNKNOWN'
						THEN CONVERT(INT, isnull(v2.[AccountingPeriod], v3.[AccountingPeriod]))
					ELSE t.FK_Allocation
					END
				,t.BeazleyCatCode
				,t.TransactionDate
				,t.IsLargeLoss
				,t.AccPeriod
				,t.RIPolicyType
				,IsMasterRI
				,ISNULL(CASE 
						WHEN t.ProgrammeCode = 'Master RI'
							THEN coalesce(v3.ProgrammeCode, t.ProgrammeCode)
						ELSE t.ProgrammeCode
						END, 'UNKNOWN') ProgrammeCode
				,t.Entity
				,t.[Value]
				,t.YOA
				,t.CCY
				,t.DateOfFact
				,CASE 
					WHEN t.TrifocusCode = 'UNKNOWN'
						THEN isnull(v2.TrifocusCode, isnull(v3.TrifocusCode, 'UNKNOWN'))
					ELSE t.TrifocusCode
					END TrifocusCode
				,sum(t.[AllocatedValue] * isnull(v2.Allocation, isnull(v3.Allocation, 1))) AllocatedValue
			INTO #TempInboundTransactionInIt2_inc
			FROM #TempInboundTransactionInIt1_Inc t
			LEFT JOIN #cte_latestalloc_inc_pass2 v2 -- select * from #cte_latestalloc_pass2
				ON (
					t.Account like 'CC%'
					AND t.TrifocusCode = 'UNKNOWN'
					AND t.ProgrammeCode <> 'Master RI'
					AND v2.MasterRIInd = 'N'
					AND v2.EntityCode = t.Entity
					AND v2.ProgrammeCode = CASE 
						WHEN t.ProgrammeCode = 'Property Cat XL'
							THEN 'Property Risk Excess'
						ELSE t.ProgrammeCode
						END
					AND v2.AccountingPeriod >= cast(left(convert(VARCHAR, t.DateOfFact, 112), 6) AS INT)
					)
			LEFT JOIN #cte_latestalloc_inc_pass2 v3 ON (
					t.Account like 'CC%'
					AND t.TrifocusCode = 'UNKNOWN'
					AND t.ProgrammeCode = 'Master RI'
					AND v3.MasterRIInd = 'Y'
					AND v3.EntityCode = t.Entity
					AND v3.AccountingPeriod >= cast(left(convert(VARCHAR, t.DateOfFact, 112), 6) AS INT)
					)
			GROUP BY t.BusinessKey
				,isnull(CASE 
						WHEN t.ProgrammeCode = 'Master RI'
							THEN coalesce(v3.ProgrammeCode, t.ProgrammeCode)
						ELSE t.ProgrammeCode
						END, 'UNKNOWN')
				,t.Entity
				,t.[Value]
				,t.YOA
				,t.DateOfFact
				,t.CCY
				,CASE 
					WHEN t.TrifocusCode = 'UNKNOWN'
						THEN isnull(v2.TrifocusCode, isnull(v3.TrifocusCode, 'UNKNOWN'))
					ELSE t.TrifocusCode
					END
				,t.PolicyNumber
				,t.InceptionDate
				,t.ExpiryDate
				,CASE 
					WHEN t.TrifocusCode = 'UNKNOWN'
						THEN CONVERT(INT, isnull(v2.[AccountingPeriod], v3.[AccountingPeriod]))
					ELSE t.FK_Allocation
					END
				,t.BeazleyCatCode
				,t.TransactionDate
				,t.IsLargeLoss
				,t.AccPeriod
				,t.RIPolicyType
				,t.Account
				,isnull(v2.[AccountingPeriod], v3.[AccountingPeriod])
				,IsMasterRI

		--		select BusinessKey, COUNT(*) from #TempInboundTransactionInIt2 group by BusinessKey having COUNT(*)>1
		--		select distinct ProgrammeCode from  #TempInboundTransactionInIt1 where BusinessKey='20150426|12405|AA|1|0|8022|0|-|TRI00046'
		
		/*
		DROP TABLE

		IF EXISTS #TempInboundTransactionInIt3_Inc
			SELECT t.Account
				,t.DateOfFact
				,CASE 
					WHEN t.IsMasterRI = 'Y'
						THEN t.BusinessKey
					ELSE t.BusinessKey + '|' + ISNULL(t.ProgrammeCode, '-')
					END AS BK2
				,t.BusinessKey + '|' + isnull(ptsm.TrifocusCode, t.TrifocusCode) + '|' + ISNULL(t.ProgrammeCode, '-') AS BusinessKey
				,t.PolicyNumber
				,t.InceptionDate
				,t.ExpiryDate
				,isnull(ptsm.TrifocusCode, t.TrifocusCode) TrifocusCode
				,t.Entity
				,t.YOA
				,t.AllocatedValue
				,t.FK_Allocation
				,t.RIPolicyType
				,t.ProgrammeCode
				,t.BeazleyCatCode
				,t.TransactionDate
				,t.IsLargeLoss
				,t.CCY
			INTO #TempInboundTransactionInIt3_Inc
			FROM #TempInboundTransactionInIt2_Inc t
			LEFT JOIN mds.ProgrammeTrifocusStaticMapping ptsm 
						ON (ptsm.Programme = t.ProgrammeCode
					   AND t.Account like 'CC%')
			
			*/

-- Allocation based on Premium

		DROP TABLE

		IF EXISTS #TempInboundTransactionInIt1 --4695753
			SELECT t.Account
				,t.BusinessKey
				,--+'|'+isnull(v.TrifocusCode, 'UNKNOWN')  as BusinessKey,
				t.PolicyNumber
				,t.InceptionDate
				,t.ExpiryDate
				,[FK_Allocation] = CASE 
					WHEN t.TrifocusCode = 'UNKNOWN'
						THEN CONVERT(INT, v.[AccountingPeriod])
					ELSE t.FK_Allocation
					END
				,t.BeazleyCatCode
				,t.TransactionDate
				,t.IsLargeLoss
				,t.accPeriod
				,t.RIPolicyType
				,IsMasterRI = CASE 
					WHEN t.ProgrammeCode = 'Master RI'
						THEN 'Y'
					ELSE 'N'
					END
				,ProgrammeCode = ISNULL(CASE 
						WHEN t.ProgrammeCode = 'Master RI'
							THEN coalesce(v.ProgrammeCode, t.ProgrammeCode)
						ELSE t.ProgrammeCode
						END, 'UNKNOWN')
				,en.ConformedEntityMapping Entity
				,(t.[Value]) AS [Value]
				,--can be commented/remove
				t.YOA
				,t.CCY
				,DateOfFact = CASE 
					WHEN t.DateOfFact <= '2018-12-31'
						THEN '2018-12-31'
					ELSE t.DateOfFact
					END
				,TrifocusCode = CASE 
					WHEN t.TrifocusCode = 'UNKNOWN'
						THEN isnull(v.TrifocusCode, 'UNKNOWN')
					ELSE t.TrifocusCode
					END
				,AllocatedValue = (CONVERT(NUMERIC(19, 4), sum(t.[AllocatedValue] * isnull(v.Allocation, 1)))) --sum([value] * isnull(v.Allocation, 1)) AllocatedValue  
			INTO #TempInboundTransactionInIt1 --select * from #source_pass1
			FROM #TempInboundTransactionInIt2_Inc t
			LEFT JOIN FinanceLanding.mds.ConformedEntityMapping en ON (en.Entity = cast(t.Entity AS VARCHAR))
			LEFT JOIN #cte_latestalloc v ON (
					v.EntityCode = en.ConformedEntityMapping
					AND t.TrifocusCode = 'UNKNOWN'
					AND v.ProgrammeCode = CASE 
						WHEN v.MasterRIInd = 'Y'
							THEN v.ProgrammeCode
						ELSE t.ProgrammeCode
						END
					AND v.YOA = t.YOA
					AND v.AccountingPeriod >= cast(left(convert(VARCHAR, CASE 
									WHEN t.DateOfFact < '2018-12-31'
										THEN '2018-12-31'
									ELSE t.DateOfFact
									END, 112), 6) AS INT)
					AND (
						(
							v.MasterRIInd = 'N'
							AND t.ProgrammeCode <> 'Master RI'
							)
						OR (
							v.MasterRIInd = 'Y'
							AND t.ProgrammeCode = 'Master RI'
							)
						)
					)
			GROUP BY t.BusinessKey --+'|'+isnull(v.TrifocusCode, 'UNKNOWN') ,
				,ISNULL(CASE 
						WHEN t.ProgrammeCode = 'Master RI'
							THEN coalesce(v.ProgrammeCode, t.ProgrammeCode)
						ELSE t.ProgrammeCode
						END, 'UNKNOWN')
				,en.ConformedEntityMapping
				,t.[Value]
				,t.YOA
				,CASE 
					WHEN t.DateOfFact <= '2018-12-31'
						THEN '2018-12-31'
					ELSE t.DateOfFact
					END
				,t.CCY
				,CASE 
					WHEN t.TrifocusCode = 'UNKNOWN'
						THEN isnull(v.TrifocusCode, 'UNKNOWN')
					ELSE t.TrifocusCode
					END
				,t.PolicyNumber
				,t.InceptionDate
				,t.ExpiryDate
				,CASE 
					WHEN t.TrifocusCode = 'UNKNOWN'
						THEN CONVERT(INT, v.[AccountingPeriod])
					ELSE t.FK_Allocation
					END
				,t.BeazleyCatCode
				,t.TransactionDate
				,t.IsLargeLoss
				,t.accPeriod
				,t.RIPolicyType
				,t.Account
				,CASE 
					WHEN t.ProgrammeCode = 'Master RI'
						THEN 'Y'
					ELSE 'N'
					END

		--		select BusinessKey, COUNT(*) from #TempInboundTransactionInIt1 group by BusinessKey having COUNT(*)>1
		--		select * from  #TempInboundTransactionInIt1 where BusinessKey='20150426|12405|AA|1|0|8022|0|-|TRI00046'
		DROP TABLE

		IF EXISTS #TempInboundTransactionInIt2
			SELECT t.Account
				,t.BusinessKey
				,t.PolicyNumber
				,t.InceptionDate
				,t.ExpiryDate
				,
				--t.[FK_Allocation],
				FK_Allocation = CASE 
					WHEN t.TrifocusCode = 'UNKNOWN'
						THEN CONVERT(INT, isnull(v2.[AccountingPeriod], v3.[AccountingPeriod]))
					ELSE t.FK_Allocation
					END
				,t.BeazleyCatCode
				,t.TransactionDate
				,t.IsLargeLoss
				,t.AccPeriod
				,t.RIPolicyType
				,IsMasterRI
				,ISNULL(CASE 
						WHEN t.ProgrammeCode = 'Master RI'
							THEN coalesce(v3.ProgrammeCode, t.ProgrammeCode)
						ELSE t.ProgrammeCode
						END, 'UNKNOWN') ProgrammeCode
				,t.Entity
				,t.[Value]
				,t.YOA
				,t.CCY
				,t.DateOfFact
				,CASE 
					WHEN t.TrifocusCode = 'UNKNOWN'
						THEN isnull(v2.TrifocusCode, isnull(v3.TrifocusCode, 'UNKNOWN'))
					ELSE t.TrifocusCode
					END TrifocusCode
				,sum(t.[AllocatedValue] * isnull(v2.Allocation, isnull(v3.Allocation, 1))) AllocatedValue
			INTO #TempInboundTransactionInIt2
			FROM #TempInboundTransactionInIt1 t
			LEFT JOIN #cte_latestalloc_pass2 v2 -- select * from #cte_latestalloc_pass2
				ON (
					t.TrifocusCode = 'UNKNOWN'
					AND t.ProgrammeCode <> 'Master RI'
					AND v2.MasterRIInd = 'N'
					AND v2.EntityCode = t.Entity
					AND v2.ProgrammeCode = CASE 
						WHEN t.ProgrammeCode = 'Property Cat XL'
							THEN 'Property Risk Excess'
						ELSE t.ProgrammeCode
						END
					AND v2.AccountingPeriod >= cast(left(convert(VARCHAR, t.DateOfFact, 112), 6) AS INT)
					)
			LEFT JOIN #cte_latestalloc_pass2 v3 ON (
					t.TrifocusCode = 'UNKNOWN'
					AND t.ProgrammeCode = 'Master RI'
					AND v3.MasterRIInd = 'Y'
					AND v3.EntityCode = t.Entity
					AND v3.AccountingPeriod >= cast(left(convert(VARCHAR, t.DateOfFact, 112), 6) AS INT)
					)
			GROUP BY t.BusinessKey
				,isnull(CASE 
						WHEN t.ProgrammeCode = 'Master RI'
							THEN coalesce(v3.ProgrammeCode, t.ProgrammeCode)
						ELSE t.ProgrammeCode
						END, 'UNKNOWN')
				,t.Entity
				,t.[Value]
				,t.YOA
				,t.DateOfFact
				,t.CCY
				,CASE 
					WHEN t.TrifocusCode = 'UNKNOWN'
						THEN isnull(v2.TrifocusCode, isnull(v3.TrifocusCode, 'UNKNOWN'))
					ELSE t.TrifocusCode
					END
				,t.PolicyNumber
				,t.InceptionDate
				,t.ExpiryDate
				,CASE 
					WHEN t.TrifocusCode = 'UNKNOWN'
						THEN CONVERT(INT, isnull(v2.[AccountingPeriod], v3.[AccountingPeriod]))
					ELSE t.FK_Allocation
					END
				,t.BeazleyCatCode
				,t.TransactionDate
				,t.IsLargeLoss
				,t.AccPeriod
				,t.RIPolicyType
				,t.Account
				,isnull(v2.[AccountingPeriod], v3.[AccountingPeriod])
				,IsMasterRI

		--		select BusinessKey, COUNT(*) from #TempInboundTransactionInIt2 group by BusinessKey having COUNT(*)>1
		--		select distinct ProgrammeCode from  #TempInboundTransactionInIt1 where BusinessKey='20150426|12405|AA|1|0|8022|0|-|TRI00046'
		DROP TABLE

			IF EXISTS #TempInboundTransactionInIt3
			SELECT t.Account
				,t.DateOfFact
				,CASE
					WHEN t.IsMasterRI = 'Y'
						THEN t.BusinessKey
					ELSE t.BusinessKey + '|' + ISNULL(t.ProgrammeCode, '-')
					END AS BK2
				,t.BusinessKey + '|' + isnull(isnull(ptsm.TrifocusCode, nsn.TrifocusCode), t.TrifocusCode) + '|' + ISNULL(t.ProgrammeCode, '-') AS BusinessKey
				,t.PolicyNumber
				,t.InceptionDate
				,t.ExpiryDate
				,isnull(isnull(ptsm.TrifocusCode, nsn.TrifocusCode), t.TrifocusCode) TrifocusCode
				,t.Entity
				,t.YOA
				,t.AllocatedValue
				,t.FK_Allocation
				,t.RIPolicyType
				,t.ProgrammeCode
				,t.BeazleyCatCode
				,t.TransactionDate
				,t.IsLargeLoss
				,t.CCY
			INTO #TempInboundTransactionInIt3
			FROM #TempInboundTransactionInIt2 t
			LEFT JOIN mds.ProgrammeTrifocusStaticMapping ptsm ON ptsm.Programme = t.ProgrammeCode
			LEFT JOIN Eurobase.rein_conditions con ON (con.[rpc_policy_reference] = t.PolicyNumber
													   and t.ProgrammeCode in ( SELECT	ProgrammeCode FROM	FinanceLanding.[CededRe].[NonSynergyFACProgrammes]))-- 'BICI FAC', 'BAIC FAC', 'BESI FAC RI'))
			LEFT JOIN fdm.DimTrifocus nsn ON (nsn.TrifocusName = con.[rpc_condition])

		--		select BusinessKey, COUNT(*) from #TempInboundTransactionInIt3 group by BusinessKey having COUNT(*)>1
		--		select * from  #TempInboundTransactionInitAgg where BusinessKey='20150426|12405|AA|1|0|8022|0|-|TRI00046'
		-- now i need to aggregate up the values as we could have the same claim with multiple values for the same day
		DROP TABLE

		IF EXISTS #TempInboundTransactionInitAgg;
			SELECT Account
				,DateOfFact
				,BK2
				,BusinessKey
				,PolicyNumber
				,InceptionDate
				,ExpiryDate
				,TrifocusCode
				,Entity
				,YOA
				,[Value] = sum([AllocatedValue])
				-- extra column to help get back to the allocations source
				,[FK_Allocation]
				-- extended values
				,RIPolicyType
				,ProgrammeCode
				,BeazleyCatCode
				,TransactionDate
				,IsLargeLoss
				-- add columns here to keep the rowhash function clean
				,BindDate = CONVERT(DATETIME, '19800101')
				,DueDate = CONVERT(DATETIME, '19800101')
				,[Location] = '-'
				,Scenario = CONVERT([VARCHAR](2), 'A')
				,Basis = CONVERT([VARCHAR](2), 'B')
				,DataSet = 'RI LPSO TTY' --@v_DataSet
				,TypeOfBusiness = CONVERT([VARCHAR](1), '-')
				,IsToDate = CONVERT([VARCHAR](1), 'N')
				,StatsCode = CONVERT([VARCHAR](25), '-')
				,ValueOrig = SUM([AllocatedValue])
				,SettlementCCY = CCY
				,OriginalCCY = CCY
				,BusinessProcessCode = BK2
			INTO #TempInboundTransactionInitAgg
			FROM #TempInboundTransactionInIt3
			GROUP BY Account
				,DateOfFact
				,BusinessKey
				,PolicyNumber
				,InceptionDate
				,ExpiryDate
				,TrifocusCode
				,Entity
				,YOA
				,CCY
				-- extra column to help get back to the allocations source
				,[FK_Allocation]
				-- extended values
				,RIPolicyType
				,ProgrammeCode
				,BeazleyCatCode
				,TransactionDate
				,IsLargeLoss
				,BK2

		DROP TABLE

		IF EXISTS #TempInboundTransactionInit2 -- no longer needed
			--SELECT '#TempInboundTransactionInitAgg',* FROM #TempInboundTransactionInitAgg 
			-----------------------------------------
			IF object_id('tempdb..#TempInboundTransaction') IS NOT NULL
				DROP TABLE #TempInboundTransaction

		SELECT tmp.Scenario
			,tmp.Basis
			,tmp.Account
			,tmp.DataSet
			,tmp.DateOfFact
			,tmp.BusinessKey
			,tmp.PolicyNumber
			,tmp.InceptionDate
			,tmp.ExpiryDate
			,tmp.BindDate
			,tmp.DueDate
			,tmp.TrifocusCode
			,tmp.Entity
			,tmp.[Location]
			,tmp.YOA
			,tmp.TypeOfBusiness
			,tmp.SettlementCCY
			,tmp.OriginalCCY
			,tmp.IsToDate
			,tmp.[Value]
			,tmp.ValueOrig
			-- extra column to help get back to the allocations source
			,tmp.[FK_Allocation]
			-- extended values
			,tmp.RIPolicyType
			,tmp.ProgrammeCode
			,tmp.BeazleyCatCode
			,tmp.TransactionDate
			,tmp.IsLargeLoss
			-- fortify with isnull so we don't have to worry if the column changes for whatever reason. 
			,RowHash = HASHBYTES('SHA2_512', CONCAT (
					ISNULL(tmp.Scenario, '')
					,'§~§'
					,ISNULL(tmp.Basis, '')
					,'§~§'
					,ISNULL(tmp.[Account], '')
					,'§~§'
					,ISNULL(tmp.DataSet, '')
					,'§~§'
					,ISNULL(tmp.[BusinessKey], '')
					,'§~§'
					,ISNULL(tmp.[PolicyNumber], '')
					,'§~§'
					,ISNULL(CONVERT(VARCHAR(10), tmp.InceptionDate, 102), '')
					,'§~§'
					,ISNULL(CONVERT(VARCHAR(10), tmp.ExpiryDate, 102), '')
					,'§~§'
					,ISNULL(CONVERT(VARCHAR(10), tmp.BindDate, 102), '')
					,'§~§'
					,ISNULL(CONVERT(VARCHAR(10), tmp.DueDate, 102), '')
					,'§~§'
					,ISNULL(tmp.[TrifocusCode], '')
					,'§~§'
					,ISNULL(tmp.Entity, '')
					,'§~§'
					,ISNULL(tmp.[Location], '')
					,'§~§'
					,ISNULL(tmp.[YOA], '')
					,'§~§'
					,ISNULL(tmp.TypeOfBusiness, '')
					,'§~§'
					,ISNULL(tmp.StatsCode, '')
					,'§~§'
					,ISNULL(tmp.SettlementCCY, '')
					,'§~§'
					,ISNULL(tmp.OriginalCCY, '')
					,'§~§'
					,ISNULL(tmp.IsToDate, '')
					,'§~§'
					,ISNULL(tmp.BusinessProcessCode, '')
					,'§~§'
					---- extra column to help get back to the allocations source
					--,ISNULL(CONVERT(VARCHAR(30),tmp.[FK_Allocation]),'')						,'§~§'
					-- extended values
					,ISNULL(tmp.RIPolicyType, '')
					,'§~§'
					,ISNULL(tmp.ProgrammeCode, '')
					,'§~§'
					,ISNULL(tmp.BeazleyCatCode, '')
					,'§~§'
					,ISNULL(CONVERT(VARCHAR(10), tmp.TransactionDate, 102), '')
					,'§~§'
					,ISNULL(CONVERT(CHAR(1), tmp.IsLargeLoss), '')
					,'§~§'
					))
			,[RowHash_Transaction_ReInsurance_Extensions] = HASHBYTES('SHA2_512', CONCAT (
					-- extra attributes
					ISNULL(tmp.[ProgrammeCode], '')
					,'§~§'
					,ISNULL(tmp.[RIPolicyType], '')
					,'§~§'
					,ISNULL(tmp.[BeazleyCatCode], '')
					,'§~§'
					,ISNULL(CONVERT(VARCHAR(10), tmp.TransactionDate, 102), '')
					,'§~§'
					,ISNULL(CONVERT(BIT, tmp.IsLargeLoss), '')
					,'§~§'
					))
			,tmp.BusinessProcessCode
			,tmp.StatsCode
		INTO #TempInboundTransaction
		FROM #TempInboundTransactionInitAgg AS tmp

		--	select * from #TempInboundTransaction
		DROP TABLE

		IF EXISTS #TempInboundTransactionInitAgg;-- no longer needed
			------/* Delete the current lines from Inbound ... */
			DELETE
			FROM [FinanceDataContract].[Inbound].[Transaction]
			WHERE [DataSet] = @v_DataSet

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions_Bridge]
		WHERE [ContractType] = @ContractType

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions]
		WHERE [ContractType] = @ContractType

		--If no new data, then log and exit
		IF NOT EXISTS (
				SELECT TOP 1 1
				FROM #TempInboundTransaction
				)
		BEGIN
			SELECT @v_ActivityDateTime = GETUTCDATE()
				,@v_AffectedRows = 0;

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStop
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

			RETURN;
		END;

		IF @Trancount = 0
			BEGIN TRAN;

		-- select * from [dbo].[Batch]
		INSERT INTO [dbo].[Batch] (
			[CreateDate]
			,[DataSet]
			,[LatestBusinesKey]
			)
		VALUES (
			GETDATE()
			,@v_DataSet
			,NULL
			);

		SELECT @v_BatchId = SCOPE_IDENTITY();

		INSERT INTO [dbo].[Batch] (
			[CreateDate]
			,[DataSet]
			,[LatestBusinesKey]
			)
		VALUES (
			GETDATE()
			,'ReInsuranceExtensions'
			,NULL
			);

		SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();

		----/* ... and add the new ones  */
		INSERT INTO [FinanceDataContract].[Inbound].Transaction_ReInsurance_Extensions_Bridge (
			[RowHash_Transaction]
			,[RowHash_Transaction_ReInsurance_Extensions]
			,[ContractType]
			,[FK_Batch]
			)
		SELECT DISTINCT [RowHash]
			,[RowHash_Transaction_ReInsurance_Extensions]
			,@ContractType
			,@v_BatchId_Extensions
		FROM #TempInboundTransaction

		INSERT INTO [FinanceDataContract].[Inbound].Transaction_ReInsurance_Extensions (
			[RowHash_Transaction_ReInsurance_Extensions]
			,[RIPolicyType]
			,[ProgrammeCode]
			,[BeazleyCatCode]
			,[TransactionDate]
			,[IsLargeLoss]
			,[ContractType]
			,[FK_Batch]
			)
		SELECT DISTINCT [RowHash_Transaction_ReInsurance_Extensions]
			,[RIPolicyType]
			,[ProgrammeCode]
			,NULL AS [BeazleyCatCode] ---Setting this to NULL AS RI LPSO TTY never has catcodes (JIRA - 1898)
			,[TransactionDate]
			,NULL AS [IsLargeLoss] ---Setting it to NULL as RI LPSO TTY never has catcodes and hence no largeloss (JIRA - 1898).		
			,@ContractType
			,@v_BatchId_Extensions
		FROM #TempInboundTransaction

		INSERT INTO [FinanceDataContract].[Inbound].[Transaction] (
			[Scenario]
			,[Basis]
			,[Account]
			,[DataSet]
			,[DateOfFact]
			,[BusinessKey]
			,[PolicyNumber]
			,[InceptionDate]
			,[ExpiryDate]
			,[BindDate]
			,[DueDate]
			,[TrifocusCode]
			,[Entity]
			,[Location]
			,[YOA]
			,[TypeOfBusiness]
			,[StatsCode]
			,[SettlementCCY]
			,[OriginalCCY]
			,[IsToDate]
			,[Value]
			,[ValueOrig]
			,[RowHash]
			,[FK_Allocation]
			,[BusinessProcessCode]
			,[FK_Batch]
			,[AuditSourceBatchID]
			,[AuditHost]
			,[AuditGenerateDateTime]
			)
		SELECT t.[Scenario]
			,t.[Basis]
			,t.[Account]
			,t.[DataSet]
			,t.[DateOfFact]
			,t.[BusinessKey]
			,t.[PolicyNumber]
			,t.[InceptionDate]
			,t.[ExpiryDate]
			,t.[BindDate]
			,t.[DueDate]
			,t.[TrifocusCode]
			,t.[Entity]
			,t.[Location]
			,t.[YOA]
			,t.[TypeOfBusiness]
			,t.[StatsCode]
			,t.[SettlementCCY]
			,t.[OriginalCCY]
			,t.[IsToDate]
			,t.[Value]
			,t.[ValueOrig]
			,t.[RowHash]
			,t.[FK_Allocation]
			,t.[BusinessProcessCode]
			,FK_Batch = @v_BatchId
			,AuditSourceBatchID = @v_BatchId
			,[AuditHost] = CONVERT([VARCHAR](255), (SERVERPROPERTY('MachineName')))
			,[AuditGenerateDateTime] = GETUTCDATE()
		FROM #TempInboundTransaction t

		SELECT @v_AffectedRows = @@ROWCOUNT;

		SET @v_AsAt = convert(VARCHAR(6), @AccountingPeriod) --AsAt will store passing date as parameter externally. if it is null then take default as getdate

		INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue] (
			Pk_Batch
			,[Status]
			,RunDescription
			,[DataSet]
			,OriginalName
			,AuditSourceBatchID
			,AsAt
			)
		VALUES (
			@v_BatchId
			,'InBound'
			,NULL
			,@v_DataSet
			,NULL
			,NULL
			,@v_AsAt
			)
			,(
			@v_BatchId_Extensions
			,'InBound'
			,'ReInsuranceExtensions, the additional attributes to extend functionality of the transaction table.'
			,'ReInsuranceExtensions'
			,NULL
			,NULL
			,@v_AsAt
			);

		-- LOG THE RESULT WITH SUCCESS
		SELECT @v_ActivityDateTime = GETUTCDATE();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStop
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		IF @Trancount = 0
			AND @@TRANCOUNT <> 0
			COMMIT;
	END TRY

	BEGIN CATCH
		-- CANCEL TRAN
		IF @Trancount = 0
			AND @@TRANCOUNT <> 0
			ROLLBACK;

		-- LOG THE RESULT WITH ERROR
		SELECT @v_ActivityDateTime = GETUTCDATE()
			,@v_ActivityLogTag = @v_ActivityLogIdIn
			,@v_ActivityMessage = ERROR_MESSAGE()
			,@v_ActivityErrorCode = ERROR_NUMBER();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusFail
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		THROW;
	END CATCH;
END;