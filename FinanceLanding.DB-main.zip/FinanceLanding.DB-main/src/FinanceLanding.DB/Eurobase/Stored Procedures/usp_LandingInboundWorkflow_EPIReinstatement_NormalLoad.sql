﻿Create PROCEDURE [Eurobase].[usp_LandingInboundWorkflow_EPIReinstatement_NormalLoad]

--rollback
AS
BEGIN


	    DECLARE @Trancount INT= @@Trancount;
		DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
     	DECLARE @Logging log.utt_ActivityLog;

		DECLARE @v_ErrorMessage NVARCHAR(4000);


		DECLARE @v_RC							INT;
		DECLARE @v_ActivityLogTag				BIGINT;
		DECLARE @v_ActivitySource				SMALLINT;
		DECLARE @v_ActivityType					SMALLINT;
		DECLARE @v_ActivityStatusStart			SMALLINT;
		DECLARE @v_ActivityStatusStop			SMALLINT;
		DECLARE @v_ActivityStatusFail			SMALLINT;
		DECLARE @v_ActivityHost					VARCHAR(100);
		DECLARE @v_ActivityDatabase				VARCHAR(100);
		DECLARE @v_ActivityName					VARCHAR(100);
		DECLARE @v_ActivityDateTime				DATETIME2(2);
		DECLARE @v_ActivityMessage				NVARCHAR(4000);
		DECLARE @v_ActivityErrorCode			NVARCHAR(50);
		DECLARE @v_ActivityLogIdIn				BIGINT;
		DECLARE @v_ActivityLogIdOut				BIGINT;
		DECLARE @v_ActivityJobId				VARCHAR(50)		= NULL;
		DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
		DECLARE @v_AffectedRows					INT				= 0;
		DECLARE		@p_ParentActivityLogId		BIGINT			= NULL


		DECLARE @v_BatchId INT;

		DECLARE @DataSet						VARCHAR(50) = 'EPI Reinstatement Eurobase'

	
	declare 
		 @Scenario char(1)				= 'A' 
		,@Basis char(1)					= 'B'
		,@DefaultDate date				= CAST('01-01-1980' as date)
		,@TypeOfBusiness char(1)		= '-'
		,@Location char(1)				= '-'
		,@IsToDate char(1)				= 'Y'
		,@BusinessProcessCode char(2)	= 'T1'
		,@AuditHost varchar(255)		= CAST(SERVERPROPERTY('MachineName') as varchar(255))
		,@StatsCode varchar(25)			= null
		--,@DateOfFact date				= convert(date,convert(char(8),@p_AccountingPeriod * 100 + 1),112)


	
	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';
	
		
	--INSERT INTO [dbo].[Batch]([CreateDate],[DataSet]) 
	--VALUES  (GETDATE(),@Dataset);

	SELECT @v_BatchId = MAX(Pk_batch) from FinanceLanding.dbo.Batch where DataSet=@DataSet
	
	SET @v_ActivityJobId=@v_BatchId

	Declare @Asat varchar(10)
	Select   @Asat=Asat from FinanceDataContract.Inbound.BatchQueue where Pk_Batch=@v_BatchId
	
	--left(convert(varchar, dateadd(month, -1, getdate()), 112), 6);
	------------------Log Start---------------------

	/* Log the start of the insert */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'Eurobase.usp_LandingInboundWorkflow_EPIReinstatement_NormalLoad'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'Load data into Inbound.Transaction for EPIReinstatement Normal Load'
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;
	

	
/*==================Logging End======================*/



	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

								   
	DROP TABLE IF EXISTS #Temp2;-----------------------------'GPE-RP-P|TK026V20APCW|2020|TRI00004|2623|USD'
	DROP TABLE IF EXISTS #TempInboundTransaction;
	
	/*Generate Business Key*/
			SELECT 
						 Scenario				= CONVERT([VARCHAR](2),'A')                                                        
						,Basis					= CONVERT([VARCHAR](2),'E')                                                          
						,Account				= ISNULL(CONVERT([VARCHAR](10),t.AccountKey), 'UNKNOWN')
						,DataSet				= CONVERT([VARCHAR](50),@DataSet)                                               
						,isnull( t.AccountKey, '-') + '|' +
								isnull(t.PolicyNumber, '-') + '|' +
								isnull(cast(ISNULL(S.SyndSplitYOA,t.YOA) as varchar), '-') + '|' +
								isnull(cast(t.TrifocusCode as varchar), '-') + '|' +
								isnull(cast(ISNULL(S.SyndSplitEntity,t.Entity) as varchar), '-') + '|' +
								isnull(cast(t.SettlementCCY as varchar), '-') as BusinessKey
					  
					  ,DateOfFact				= CONVERT([DATETIME],t.AccountingPeriod+'01')
					 --,BusinessKey			= CONVERT([VARCHAR](255),r.[pre_cpd_policy_ref])
						,PolicyNumber			= CONVERT([VARCHAR](255),t.PolicyNumber)
						,InceptionDate			=cast( CONVERT([DATETIME],t.[inception]) as date)
						,ExpiryDate				= cast(CONVERT([DATETIME],t.[expiry]) as date)
						,BindDate				= @DefaultDate--cast(CONVERT([DATETIME],'01/01/1980') as date)
						,DueDate				=@DefaultDate --CONVERT([DATETIME],t.[tot])
						,TrifocusCode			= CONVERT([VARCHAR](25),ISNULL(nullif(t.TrifocusCode,''),'UNKNOWN'))
						
						--,S.SyndSplitSource
						--,S.SyndSplitEntity
						,Entity					= CONVERT([VARCHAR](10),ISNULL(S.SyndSplitEntity,t.Entity))
						,[Location]				= @Location--CONVERT([VARCHAR](50),t.[Multiyear])
						,Yoa					= CONVERT([VARCHAR](5),t.[yoa])
						,TypeOfBusiness			= CONVERT([VARCHAR](1),'-')      
						
						/*I1B-3810 set Original CCY to Settlement CCY and ValueOrig to Value   */


						,SettlementCCY			= CONVERT([VARCHAR](3),t.SettlementCCY)
						,OriginalCCY			= CONVERT([VARCHAR](3),t.SettlementCCY)
						,IsToDate				= CONVERT([VARCHAR](1),'Y')
						,Value					=cast(t.[SignedValue] * isnull(cast(S.SyndSplitPercentage as numeric(19, 4)), 1.00) as numeric(19, 4)) 
						                      --= CONVERT([DECIMAL](19, 4),t.SignedValue)--,r.[reinstatement_signed] * isnull(s.[spl_percent],100.00) / 100.00 )
						,ValueOrig					=cast(t.[SignedValue] * isnull(cast(S.SyndSplitPercentage as numeric(19, 4)), 1.00) as numeric(19, 4)) 
						--,ValueOrig				= CONVERT([DECIMAL](19, 4),t.OrgininalValue)--COALESCE(cv.OriginalValue,pp.pre_amount,0.00) * ISNULL(v.signed_line,100.00) / 100.00 * isnull(s.[spl_percent],100.00) / 100.00 )
						,BusinessProcessCode	= CONVERT([VARCHAR](255),'T1')
						,AuditSourceBatchID		= CONVERT([VARCHAR](255),@v_BatchId)                                                 
						,AuditHost				= CONVERT([VARCHAR](255),(SERVERPROPERTY('MachineName')))      
						,StatsCode              = NULL--CONVERT([VARCHAR](25),t.statscode)
						,FK_Batch				= CONVERT([INT],NULL)
						,[BoundDate]=@DefaultDate
						
						
				INTO		#Temp2
				From  FinanceLanding.Eurobase.PeriodicEPIReinstatement t 
				left JOIN FinanceLanding.fdm.SyndicateSplitsbyYOA S ON S.SyndSplitSource= t.Entity and S.SyndSplitYOA=t.YOA
				LEFT JOIN FinanceLanding.[Eurobase].[policy_details_01] pd ON (pd.pol_cpd_policy_reference = t.PolicyNumber and pd.pol_syn_user_number = t.Entity)
				LEFT JOIN FinanceLanding.[Eurobase].[cob_codes] cc on (cc.cob_code = pd.pol_cob_code )
				--where PolicyNumber='T6467E08BNCR'
				where t.AccountingPeriod=@Asat 
				AND  cc.cob_tri_group in
				 (
				 'Cat',
				 'Ex Cat',
				 'Treaty Misc',
				 'Clash'
				 )

	/*==============================Generate Rowhash============================================================*/
				select * 
				,RowHash = FinanceLanding.dbo.fn_RowHashForTransactions
						(
						'T'							-- <@RowHashType, char(1),>
						,Scenario					--,<@Scenario, nvarchar(2000),>
						, Account					--,<@Account, nvarchar(2000),>
						,DataSet					--,<@DataSet, nvarchar(2000),>
						,[BusinessKey]				--,<@BusinessKey, nvarchar(2000),>
				     	,[PolicyNumber]				--,<@PolicyNumber, nvarchar(2000),>
						,[InceptionDate]			--,<@InceptionDate, date,>
						,[ExpiryDate]				--,<@ExpiryDate, date,>
						,BindDate	--,<@BindDate, date,>
						,DueDate	--,<@DueDate, date,>						
						,TrifocusCode			--,<@TrifocusCode, nvarchar(2000),>
						,[Entity]					--,<@Entity, nvarchar(2000),>
						,[YOA]						--,<@YOA, nvarchar(2000),>
						,TypeOfBusiness				--,<@TypeOfBusiness, nvarchar(2000),>
						,StatsCode					--,<@StatsCode, nvarchar(2000),>
						,[SettlementCCY]			--,<@SettlementCCY, nvarchar(2000),>
						,OriginalCCY			--,<@OriginalCCY, nvarchar(2000),>
						,'Y'							--,<@IsToDate, nvarchar(2000),>
						,Basis					--,<@Basis, nvarchar(2000),>
						,[Location]					--,<@Location, nvarchar(2000),>
						,BusinessProcessCode						--,<@BusinessProcessCode, nvarchar(2000),>
						,null						--,<@BoundDate, date,>
						,null
					)
				INTO #TempInboundTransaction
				FROM #Temp2
			
			
	--		select * from #TempInboundTransaction   where   BusinessKey='GPE-RP-P|TK026V20APCW|2020|TRI00004|623|USD'
	--where PolicyNumber='T0566V04ANCR' and BusinessKey='GPE-RP-P|T0566V04ANCR|2004|TRI00012|2623|USD'
			
			
/*====================== Delete the current lines from Inbound and Insert ... ==========================================*/

				DELETE 				
				FROM    [FinanceDataContract].[Inbound].[Transaction]					
				WHERE   [DataSet] = @DataSet


					INSERT	FinanceDataContract.Inbound.[Transaction] WITH(TABLOCK) 
					(Scenario, Account, dataset, DateOfFact, BusinessKey, PolicyNumber, InceptionDate
					,ExpiryDate, BindDate, DueDate, TrifocusCode, StatsCode, Entity, YOA
					,TypeOfBusiness, SettlementCCY, OriginalCCY, IsToDate, [Value],ValueOrig,
					AuditSourceBatchID,BusinessProcessCode,Basis,[Location]
					,AuditGenerateDateTime, RowHash,[BoundDate])

				SELECT  Scenario
					   ,Account
					   ,dataset
					   ,DateOfFact
					   ,BusinessKey
					   ,PolicyNumber
					   ,InceptionDate
					   ,ExpiryDate
					   ,BindDate
					   ,DueDate
					   ,trifocusCode
					   ,[StatsCode]
					   ,Entity
					   ,YOA
					   ,TypeofBusiness
					   ,SettlementCCY
					   ,ISNULL(OriginalCCY,SettlementCCY)
					   ,ISTODate
					   ,[Value]
					   ,ValueOrig
					   ,AuditSourceBatchID
					   ,BusinessProcessCode
					   ,Basis
					   ,[Location]
					   --,auditcreateddatetime
					   ,GETDATE()
					   --,auitusercreate
					   --,AuditHost 
					   ,RowHash
					   ,[BoundDate]

			   From #TempInboundTransaction
		--select * from #TempInboundTransaction

		  SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'Eurobase.usp_LandingInbound_Reinstatement', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into Inbound.Transaction table';

		-- LOG THE RESULT WITH SUCCESS--
			SELECT @v_ActivityDateTime			= GETUTCDATE();

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStop
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT; 
         
	
		----------------------------
		--select * from #TempInboundTransaction where BusinessKey='GPE-RP-P|TK026V20APCW|2020|TRI00004|623|USD'

		
	Update FinanceDataContract.Inbound.BatchQueue set [Status]='Inbound' Where pk_batch=@v_BatchId

	-- LOG THE RESULT WITH SUCCESS--
			SELECT @v_ActivityDateTime			= GETUTCDATE();

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStop
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT; 
         
	
		IF @Trancount = 0 
		COMMIT;

		--INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		--SELECT 2, 'Eurobase.usp_LandingInboundWorkflow_Reinstatement Normal Load', 'EPIReinstatement LandingToInBound Normal Load Succeeded';

		--Generate logging for success--
		EXEC log.usp_LogLanding @Input = @Logging;


	END TRY
	BEGIN CATCH
		
	
		IF @Trancount = 0  
				ROLLBACK;

			-- LOG THE RESULT WITH ERROR--
				UPDATE [FinanceDataContract].[Inbound].[BatchQueue]
				SET Status='OutBoundFailed'
				WHERE PK_Batch=@v_BatchId AND [Status]='InBound' AND DataSet=@DataSet
			
				SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;


		THROW;
	END CATCH;
END;