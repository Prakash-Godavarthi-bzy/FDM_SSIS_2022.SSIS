﻿CREATE PROCEDURE [Eurobase].[usp_LandingToInbound_FacReInsurance] (
	@p_ParentActivityLogId BIGINT = NULL
	,@p_ActivityJobId VARCHAR(50) = NULL
	,@p_AccountingDate DATE = NULL
	)
AS
/* ====================================================================================================================================================================================

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	18-05-2021
-- Changes:				Loads Fac ReInsurance data from FinanceLanding to Inbound.Transaction

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	26-05-2021
-- Changes:				Uses an @OpeningBalanceDate date = '31 December 2018', so all accounts are aggregated up to this DateOfFact and then the DateOfFact is used normally.

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	23-07-2021
-- Changes:				For attribute only changes we using the current date for the date of fact.

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	10-08-2021
-- Changes:				ProgrammeCode changed and needs to accomodate character length of 100.

	Altered by:			nithin.dumpeti@beazley.com
	Altered date:		05-02-2024
	Changes:			Auditing AccountingPeriod in inbound.batchqueue table in column AsAt for passing date as a parameter externally
-- ====================================================================================================================================================================================	*/
BEGIN
	SET NOCOUNT ON;

	DECLARE @Trancount INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);
	DECLARE @v_RC INT;
	DECLARE @v_ActivityLogTag BIGINT;
	DECLARE @v_ActivitySource SMALLINT;
	DECLARE @v_ActivityType SMALLINT;
	DECLARE @v_ActivityStatusStart SMALLINT;
	DECLARE @v_ActivityStatusStop SMALLINT;
	DECLARE @v_ActivityStatusFail SMALLINT;
	DECLARE @v_ActivityHost VARCHAR(100);
	DECLARE @v_ActivityDatabase VARCHAR(100);
	DECLARE @v_ActivityName VARCHAR(100);
	DECLARE @v_ActivityDateTime DATETIME2(2);
	DECLARE @v_ActivityMessage NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn BIGINT;
	DECLARE @v_ActivityLogIdOut BIGINT;
	DECLARE @v_ActivityJobId VARCHAR(50) = @p_ActivityJobId;
	DECLARE @v_ActivitySSISExecutionId VARCHAR(50) = NULL;
	DECLARE @v_AffectedRows INT = 0;
	DECLARE @v_DataSet VARCHAR(255) = 'RI LPSO FAC'
	DECLARE @ContractType CHAR(3) = 'FAC'
	DECLARE @v_AsAt VARCHAR(6);
	-- for debugging. set to 1 & the no records will be written to the inbound tables.
	DECLARE @stop BIT = 0

	SELECT @v_ActivityStatusStart = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'ERRORED';

	DECLARE @v_BatchId INT;
	DECLARE @v_BatchId_Extensions INT;

	/* Log the start of the insert */
	BEGIN TRY
		SELECT @v_ActivityLogTag = NULL
			,@v_ActivitySource = (
				SELECT PK_ActivitySource
				FROM Orchestram.Log.ActivitySource
				WHERE ActivitySource = 'IFRS17'
				)
			,@v_ActivityType = (
				SELECT PK_ActivityType
				FROM Orchestram.Log.ActivityType
				WHERE ActivityType = CASE 
						WHEN @p_ParentActivityLogId IS NULL
							THEN 'Manual process'
						ELSE 'Automated process'
						END
				)
			,@v_ActivityHost = @@SERVERNAME
			,@v_ActivityName = 'Load eurobase re-insurance data into Inbound.Transaction'
			,@v_ActivityDatabase = 'FinanceLanding'
			,@v_ActivityDateTime = GETUTCDATE()
			,@v_ActivityMessage = NULL
			,@v_ActivityErrorCode = NULL;

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStart
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

		--------------------------------------------------
		DECLARE @AccountingDate DATE

		SELECT @AccountingDate = @p_AccountingDate

		--------------------------------------------------
		DECLARE @OpeningBalanceDate DATE = '31 December 2018' -- this is the date for the opening balance
		DECLARE @OpeningBalanceCutOffYear INT = year(@OpeningBalanceDate) + 1 -- this will be 2019

		DROP TABLE

		IF EXISTS #TempInboundTransactionInit;
			SELECT Account = CONVERT(VARCHAR(14), rif.Account)
				-- Change the date to a date - get rid of the time part and aggregate to the day.
				,DateOfFact = CASE 
					WHEN year(rif.DateOfFact) < @OpeningBalanceCutOffYear
						THEN @OpeningBalanceDate
					ELSE CONVERT(DATE, rif.DateOfFact)
					END
				,BusinessKey = CONVERT(VARCHAR(255), rif.BusinessKey)
				,PolicyNumber = CONVERT(VARCHAR(255), rif.RIPolicyNumber)
				,InceptionDate = CONVERT(DATETIME, rif.RIInceptionDate)
				,ExpiryDate = CONVERT(DATETIME, rif.RIExpiryDate)
				,TrifocusCode = CONVERT(VARCHAR(25), isnull(tf.TriFocusCode, 'UNKNOWN'))
				,Entity = CONVERT(VARCHAR(25), rif.Entity)
				,YOA = ISNULL(CONVERT(VARCHAR(5), NULLIF(rif.YOA, 0)), 'NOYOA')
				,CCY = CONVERT(VARCHAR(3), rif.SettlementCCY)
				,[Value] = CONVERT(NUMERIC(19, 4), rif.[Value]) --  +1000000 -- test only!!!!!
				-- extended values
				,RIPolicyType = CONVERT(VARCHAR(3), rif.RIPolicyType)
				,BeazleyCatCode = CONVERT(VARCHAR(12), rif.BeazleyCatCode)
				,TransactionDate = CONVERT(DATE, rif.TransactionDate)
				,IsLargeLoss = CONVERT(BIT, rif.IsLargeLoss)
			INTO #TempInboundTransactionInit
			FROM [Eurobase].[vw_ReInsuranceFac] rif
			LEFT JOIN MDS.TriFocus tf ON tf.[Name] = rif.TriFocus
			LEFT JOIN FinanceLanding.MDS.vw_CatCode cc ON cc.BeazleyCatCode = rif.BeazleyCatCode
			--left join cte_hist_fix hf on (hf.BusinessKey = rif.BusinessKey)
			WHERE isnull(rif.[Value], 0) <> 0.00
				AND CONVERT(DATE, rif.DateOfFact) <= ISNULL(@AccountingDate, rif.DateOfFact)

		--select * from #TempInboundTransactionInit 
		--where TrifocusCode = 'UNKNOWN'
		-- now i need to aggregate up the values as we could have the same claim with multiple values for the same day
		DROP TABLE

		IF EXISTS #TempInboundTransactionInitAgg;;
			WITH cte_hist_fix
			AS (
				SELECT '19930404|56336|  |1|0|623|0' AS BusinessKey
					,'F7656F92CAFX' AS RIPolicyNumber
					,cast('20000101' AS DATE) AS RIInceptionDate
					,cast('20000101' AS DATE) AS RIExpiryDate
				
				UNION ALL
				
				SELECT '19931114|10081|  |1|0|623|0'
					,'F8212V93CAFX'
					,cast('20000101' AS DATE)
					,cast('20000101' AS DATE)
				
				UNION ALL
				
				SELECT '19931114|10082|  |1|0|623|0'
					,'F8210A93CAFX'
					,cast('20000101' AS DATE)
					,cast('20000101' AS DATE)
				
				UNION ALL
				
				SELECT '19931114|10442|  |1|0|623|0'
					,'F5100E93BBFF'
					,cast('20000101' AS DATE)
					,cast('20000101' AS DATE)
				
				UNION ALL
				
				SELECT '19940327|10027|  |1|0|623|0'
					,'L0689X93JBFT'
					,cast('20000101' AS DATE)
					,cast('20000101' AS DATE)
				
				UNION ALL
				
				SELECT '19940522|10029|  |1|0|623|0'
					,'L0689X93JBFT'
					,cast('20000101' AS DATE)
					,cast('20000101' AS DATE)
				
				UNION ALL
				
				SELECT '19940612|10022|  |1|0|623|0'
					,'F5100E94BBFF'
					,cast('20000101' AS DATE)
					,cast('20000101' AS DATE)
				
				UNION ALL
				
				SELECT '19941120|10007|  |1|0|623|0'
					,'L0689X94BBFK'
					,cast('20000101' AS DATE)
					,cast('20000101' AS DATE)
				
				UNION ALL
				
				SELECT '19950423|71300|  |1|0|623|0'
					,'F9159D93AXFF'
					,cast('19930701' AS DATE)
					,cast('19940630' AS DATE)
				
				UNION ALL
				
				SELECT '19950507|10042|  |1|0|623|0'
					,'L0689X94BBFK'
					,cast('20000101' AS DATE)
					,cast('20000101' AS DATE)
				
				UNION ALL
				
				SELECT '19950507|10049|  |1|0|623|0'
					,'H0292A95ECFX'
					,cast('20000101' AS DATE)
					,cast('20000101' AS DATE)
				
				UNION ALL
				
				SELECT '19950507|10050|  |1|0|623|0'
					,'H0292A95ECFX'
					,cast('20000101' AS DATE)
					,cast('20000101' AS DATE)
				
				UNION ALL
				
				SELECT '19950604|10018|  |1|0|623|0'
					,'F5100E95BBFF'
					,cast('20000101' AS DATE)
					,cast('20000101' AS DATE)
				
				UNION ALL
				
				SELECT '19950604|10072|  |1|0|623|0'
					,'F5100E95BBFF'
					,cast('20000101' AS DATE)
					,cast('20000101' AS DATE)
				
				UNION ALL
				
				SELECT '19950625|53219|  |1|0|623|0'
					,'F9159D93AXFF'
					,cast('19930701' AS DATE)
					,cast('19940630' AS DATE)
				
				UNION ALL
				
				SELECT '19960225|13425|  |1|0|623|0'
					,'H0147Z95ECFX'
					,cast('20000101' AS DATE)
					,cast('20000101' AS DATE)
				
				UNION ALL
				
				SELECT '19960526|56549|  |1|0|623|0'
					,'H4683J95EDFX'
					,cast('20000101' AS DATE)
					,cast('20000101' AS DATE)
				)
			SELECT Account
				,DateOfFact
				,t1.BusinessKey
				,PolicyNumber = isnull(hf.RIPolicyNumber, t1.PolicyNumber)
				,InceptionDate = isnull(hf.RIInceptionDate, t1.InceptionDate)
				,ExpiryDate = isnull(hf.RIExpiryDate, t1.ExpiryDate)
				,TrifocusCode
				,Entity
				,YOA
				,[Value] = sum([Value])
				-- extended values
				,RIPolicyType
				,ProgrammeCode = convert(VARCHAR(100), NULL) -- this is null for FAC but populated for Treaty
				,BeazleyCatCode
				,TransactionDate
				,IsLargeLoss
				-- add columns here to keep the rowhash function clean
				,BindDate = CONVERT(DATETIME, '19800101')
				,DueDate = CONVERT(DATETIME, '19800101')
				,[Location] = '-'
				,Scenario = CONVERT([VARCHAR](2), 'A')
				,Basis = CONVERT([VARCHAR](2), 'E')
				,DataSet = @v_DataSet
				,TypeOfBusiness = CONVERT([VARCHAR](1), '-')
				,IsToDate = CONVERT([VARCHAR](1), 'N')
				,StatsCode = CONVERT([VARCHAR](25), '-')
				,ValueOrig = SUM([Value])
				,SettlementCCY = CCY
				,OriginalCCY = CCY
				,BusinessProcessCode = CONVERT([VARCHAR](255), 'T1')
			INTO #TempInboundTransactionInitAgg
			FROM #TempInboundTransactionInit t1
			LEFT JOIN cte_hist_fix hf ON (hf.BusinessKey = t1.BusinessKey)
			GROUP BY Account
				,DateOfFact
				,t1.BusinessKey
				,isnull(hf.RIPolicyNumber, t1.PolicyNumber)
				,isnull(hf.RIInceptionDate, t1.InceptionDate)
				,isnull(hf.RIExpiryDate, t1.ExpiryDate)
				,TrifocusCode
				,Entity
				,YOA
				,CCY
				-- extended values
				,RIPolicyType
				,BeazleyCatCode
				,TransactionDate
				,IsLargeLoss
			HAVING sum([Value]) <> 0

		DROP TABLE

		IF EXISTS #TempInboundTransactionInit -- no longer needed
			--SELECT  businesskey , count(*) FROM #TempInboundTransactionInitAgg group by businesskey having count(*)>1
			-----------------------------------------
			IF object_id('tempdb..#TempInboundTransaction') IS NOT NULL
				DROP TABLE #TempInboundTransaction

		SELECT tmp.Scenario
			,tmp.Basis
			,tmp.Account
			,tmp.DataSet
			,tmp.DateOfFact
			,tmp.BusinessKey
			,tmp.PolicyNumber
			,tmp.InceptionDate
			,tmp.ExpiryDate
			,tmp.BindDate
			,tmp.DueDate
			,tmp.TrifocusCode
			,tmp.Entity
			,tmp.[Location]
			,tmp.YOA
			,tmp.TypeOfBusiness
			,tmp.SettlementCCY
			,tmp.OriginalCCY
			,tmp.IsToDate
			,tmp.[Value]
			,tmp.ValueOrig
			-- extended values
			,tmp.RIPolicyType
			,tmp.ProgrammeCode
			,tmp.BeazleyCatCode
			,tmp.TransactionDate
			,tmp.IsLargeLoss
			-- fortify with isnull so we don't have to worry if the column changes for whatever reason. 
			,RowHash = HASHBYTES('SHA2_512', CONCAT (
					ISNULL(tmp.Scenario, '')
					,'§~§'
					,ISNULL(tmp.Basis, '')
					,'§~§'
					,ISNULL(tmp.[Account], '')
					,'§~§'
					,ISNULL(tmp.DataSet, '')
					,'§~§'
					,ISNULL(tmp.[BusinessKey], '')
					,'§~§'
					,ISNULL(tmp.[PolicyNumber], '')
					,'§~§'
					,ISNULL(CONVERT(VARCHAR(10), tmp.InceptionDate, 102), '')
					,'§~§'
					,ISNULL(CONVERT(VARCHAR(10), tmp.ExpiryDate, 102), '')
					,'§~§'
					,ISNULL(CONVERT(VARCHAR(10), tmp.BindDate, 102), '')
					,'§~§'
					,ISNULL(CONVERT(VARCHAR(10), tmp.DueDate, 102), '')
					,'§~§'
					,ISNULL(tmp.[TrifocusCode], '')
					,'§~§'
					,ISNULL(tmp.Entity, '')
					,'§~§'
					,ISNULL(tmp.[Location], '')
					,'§~§'
					,ISNULL(tmp.[YOA], '')
					,'§~§'
					,ISNULL(tmp.TypeOfBusiness, '')
					,'§~§'
					,ISNULL(tmp.StatsCode, '')
					,'§~§'
					,ISNULL(tmp.SettlementCCY, '')
					,'§~§'
					,ISNULL(tmp.OriginalCCY, '')
					,'§~§'
					,ISNULL(tmp.IsToDate, '')
					,'§~§'
					,ISNULL(tmp.BusinessProcessCode, '')
					,'§~§'
					-- extended values
					,ISNULL(tmp.RIPolicyType, '')
					,'§~§'
					,ISNULL(tmp.ProgrammeCode, '')
					,'§~§'
					,ISNULL(tmp.BeazleyCatCode, '')
					,'§~§'
					,ISNULL(CONVERT(VARCHAR(10), tmp.TransactionDate, 102), '')
					,'§~§'
					,ISNULL(CONVERT(CHAR(1), tmp.IsLargeLoss), '')
					,'§~§'
					))
			,tmp.BusinessProcessCode
			,tmp.StatsCode
			,[RowHash_Transaction_ReInsurance_Extensions] = HASHBYTES('SHA2_512', CONCAT (
					-- extra attributes
					ISNULL(tmp.[ProgrammeCode], '')
					,'§~§'
					,ISNULL(tmp.[RIPolicyType], '')
					,'§~§'
					,ISNULL(tmp.[BeazleyCatCode], '')
					,'§~§'
					,ISNULL(CONVERT(VARCHAR(10), tmp.TransactionDate, 102), '')
					,'§~§'
					,ISNULL(CONVERT(CHAR(1), tmp.IsLargeLoss), '')
					,'§~§'
					))
		INTO #TempInboundTransaction
		FROM #TempInboundTransactionInitAgg AS tmp

		DROP TABLE

		IF EXISTS #TempInboundTransactionInitAgg;-- no longer needed
			--select * from #TempInboundTransaction
			--where MovementType='Reserve'
			--order by DateOfFact
			--------------------------------------------------------------------
			--RETURN -- gets here in 
			------/* Delete the current lines from Inbound ... */
			DELETE
			FROM [FinanceDataContract].[Inbound].[Transaction]
			WHERE [DataSet] = @v_DataSet

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions_Bridge]
		WHERE [ContractType] = @ContractType

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions]
		WHERE [ContractType] = @ContractType

		--If no new data, then log and exit
		IF NOT EXISTS (
				SELECT TOP 1 1
				FROM #TempInboundTransaction
				)
		BEGIN
			SELECT @v_ActivityDateTime = GETUTCDATE()
				,@v_AffectedRows = 0;

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStop
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

			RETURN;
		END;

		IF @Trancount = 0
			BEGIN TRAN;

		-- select * from [dbo].[Batch]
		INSERT INTO [dbo].[Batch] (
			[CreateDate]
			,[DataSet]
			,[LatestBusinesKey]
			)
		VALUES (
			GETDATE()
			,@v_DataSet
			,NULL
			);

		SELECT @v_BatchId = SCOPE_IDENTITY();

		INSERT INTO [dbo].[Batch] (
			[CreateDate]
			,[DataSet]
			,[LatestBusinesKey]
			)
		VALUES (
			GETDATE()
			,'ReInsuranceExtensions'
			,NULL
			);

		SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();

		----/* ... and add the new ones  */
		INSERT INTO [FinanceDataContract].[Inbound].Transaction_ReInsurance_Extensions_Bridge
		WITH (TABLOCK) (
				[RowHash_Transaction]
				,[RowHash_Transaction_ReInsurance_Extensions]
				,[ContractType]
				,[FK_Batch]
				)
		SELECT DISTINCT [RowHash]
			,[RowHash_Transaction_ReInsurance_Extensions]
			,@ContractType
			,@v_BatchId_Extensions
		FROM #TempInboundTransaction

		INSERT INTO [FinanceDataContract].[Inbound].Transaction_ReInsurance_Extensions
		WITH (TABLOCK) (
				[RowHash_Transaction_ReInsurance_Extensions]
				,[RIPolicyType]
				,[ProgrammeCode]
				,[BeazleyCatCode]
				,[TransactionDate]
				,[IsLargeLoss]
				,[ContractType]
				,[FK_Batch]
				)
		SELECT DISTINCT [RowHash_Transaction_ReInsurance_Extensions]
			,[RIPolicyType]
			,[ProgrammeCode]
			,[BeazleyCatCode]
			,[TransactionDate]
			,[IsLargeLoss]
			,@ContractType
			,@v_BatchId_Extensions
		FROM #TempInboundTransaction

		INSERT INTO [FinanceDataContract].[Inbound].[Transaction]
		WITH (TABLOCK) (
				[Scenario]
				,[Basis]
				,[Account]
				,[DataSet]
				,[DateOfFact]
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]
				,[DueDate]
				,[TrifocusCode]
				,[Entity]
				,[Location]
				,[YOA]
				,[TypeOfBusiness]
				,[StatsCode]
				,[SettlementCCY]
				,[OriginalCCY]
				,[IsToDate]
				,[Value]
				,[ValueOrig]
				,[RowHash]
				,[BusinessProcessCode]
				,[FK_Batch]
				,[AuditSourceBatchID]
				,[AuditHost]
				,[AuditGenerateDateTime]
				)
		SELECT t.[Scenario]
			,t.[Basis]
			,t.[Account]
			,t.[DataSet]
			,t.[DateOfFact]
			,t.[BusinessKey]
			,t.[PolicyNumber]
			,t.[InceptionDate]
			,t.[ExpiryDate]
			,t.[BindDate]
			,t.[DueDate]
			,t.[TrifocusCode]
			,t.[Entity]
			,t.[Location]
			,t.[YOA]
			,t.[TypeOfBusiness]
			,t.[StatsCode]
			,t.[SettlementCCY]
			,t.[OriginalCCY]
			,t.[IsToDate]
			,t.[Value]
			,t.[ValueOrig]
			,t.[RowHash]
			,t.[BusinessProcessCode]
			,FK_Batch = @v_BatchId
			,AuditSourceBatchID = @v_BatchId
			,[AuditHost] = CONVERT([VARCHAR](255), (SERVERPROPERTY('MachineName')))
			,[AuditGenerateDateTime] = GETUTCDATE()
		FROM #TempInboundTransaction t

		SELECT @v_AffectedRows = @@ROWCOUNT;

		SET @v_AsAt = left(convert(VARCHAR(10), ISNULL(@AccountingDate, GETDATE()), 112), 6) --AsAt will store passing date as parameter externally. if it is null then take default as getdate

		--/* Add the batchs to the queue */
		---- select top 100 * from [FinanceDataContract].[Inbound].[BatchQueue]  order by 1 desc
		INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue] (
			Pk_Batch
			,[Status]
			,RunDescription
			,[DataSet]
			,OriginalName
			,AuditSourceBatchID
			,AsAt
			)
		VALUES (
			@v_BatchId
			,'InBound'
			,NULL
			,@v_DataSet
			,NULL
			,NULL
			,@v_AsAt
			)
			,(
			@v_BatchId_Extensions
			,'InBound'
			,'ReInsuranceExtensions, the additional attributes to extend functionality of the transaction table.'
			,'ReInsuranceExtensions'
			,NULL
			,NULL
			,@v_AsAt
			);

		-- LOG THE RESULT WITH SUCCESS
		SELECT @v_ActivityDateTime = GETUTCDATE();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStop
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		IF @Trancount = 0
			AND @@TRANCOUNT <> 0
			COMMIT;
	END TRY

	BEGIN CATCH
		-- CANCEL TRAN
		IF @Trancount = 0
			AND @@TRANCOUNT <> 0
			ROLLBACK;

		-- LOG THE RESULT WITH ERROR
		SELECT @v_ActivityDateTime = GETUTCDATE()
			,@v_ActivityLogTag = @v_ActivityLogIdIn
			,@v_ActivityMessage = ERROR_MESSAGE()
			,@v_ActivityErrorCode = ERROR_NUMBER();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusFail
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		THROW;
	END CATCH;
END;
