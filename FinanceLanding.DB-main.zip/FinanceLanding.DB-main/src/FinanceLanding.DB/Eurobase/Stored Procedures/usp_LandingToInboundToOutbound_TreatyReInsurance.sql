﻿CREATE PROCEDURE [Eurobase].[usp_LandingToInboundToOutbound_TreatyReInsurance] (
	@p_ParentActivityLogId BIGINT = NULL
	,@p_ActivityJobId VARCHAR(50) = NULL
	)
AS
/* =============================================

-- Author:      		mark.baekdal@beazley.com
-- Modification date:	2021-06-04
-- Changes:				Loads the Eurobase Re-Insurance treaty data to Inbound and to Outbound. 
--						It will do all the periods from 201812 if the outbound table is empty. Manually delete the outbound tables for the dataset and this procedure will reload. 
--						If the outbound is not empty if will find the max AccountingPeriod in the outbound table and use this to determine what to load for. 
--						Example: max AccountingPeriod = 202012. The load will run for 202103 if an accounting period exists, otherwise it will run again for 202012.
--						It will run within the IFRS17 Orchestration.
--
--						This also runs the treaty contract attributes into Inbound and Outbound.
--
-- Author:      		mark.baekdal@beazley.com
-- Modification date:	2021-07-23
-- Changes:				Changed to use the view [Eurobase].[vw_ReInsuranceTreaty]
--
-- Change Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modification date:	14/09/2021
-- Description:			Now using the variable @DoNonIFRS17_Tests = 0


-- Modified by:			pavani.bandaru@beazley.com
-- Modification date:	26-06-2023
-- Changes:				https://beazley.atlassian.net/browse/I1B-2939

	Modified By:	nithin.dumpeti@beazley.com
	Modified date:	29/01/2024
	Description:	passing date as parameter externally to give more user control from schedulinghub.sch.controldataset table	
	JIRA Ticket:	https://beazley.atlassian.net/browse/I1B-3887	
-- =============================================	*/
BEGIN
	DECLARE @v_ErrorMessage NVARCHAR(4000);
	DECLARE @v_RC INT;
	DECLARE @v_ActivityLogTag BIGINT;
	DECLARE @v_ActivitySource SMALLINT;
	DECLARE @v_ActivityType SMALLINT;
	DECLARE @v_ActivityStatusStart SMALLINT;
	DECLARE @v_ActivityStatusStop SMALLINT;
	DECLARE @v_ActivityStatusFail SMALLINT;
	DECLARE @v_ActivityHost VARCHAR(100);
	DECLARE @v_ActivityDatabase VARCHAR(100);
	DECLARE @v_ActivityName VARCHAR(100);
	DECLARE @v_ActivityDateTime DATETIME2(2);
	DECLARE @v_ActivityMessage NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn BIGINT;
	DECLARE @v_ActivityLogIdOut BIGINT;
	DECLARE @v_ActivityJobId VARCHAR(50) = @p_ActivityJobId;
	DECLARE @v_ActivitySSISExecutionId VARCHAR(50) = NULL;
	DECLARE @v_AffectedRows INT = 0;
	DECLARE @p_AccountingDate DATE;
	DECLARE @v_Default_date DATE = '1900-01-01' -- this will work when doing full refresh which runs till date

	BEGIN TRY
		SET NOCOUNT ON

		SELECT @v_ActivityStatusStart = PK_ActivityStatus
		FROM Orchestram.Log.ActivityStatus
		WHERE ActivityStatus = 'STARTED';

		SELECT @v_ActivityStatusStop = PK_ActivityStatus
		FROM Orchestram.Log.ActivityStatus
		WHERE ActivityStatus = 'SUCCEEDED';

		SELECT @v_ActivityStatusFail = PK_ActivityStatus
		FROM Orchestram.Log.ActivityStatus
		WHERE ActivityStatus = 'ERRORED';

		SELECT @v_ActivityLogTag = NULL
			,@v_ActivitySource = (
				SELECT PK_ActivitySource
				FROM Orchestram.Log.ActivitySource
				WHERE ActivitySource = 'IFRS17'
				)
			,@v_ActivityType = (
				SELECT PK_ActivityType
				FROM Orchestram.Log.ActivityType
				WHERE ActivityType = CASE 
						WHEN @p_ParentActivityLogId IS NULL
							THEN 'Manual process'
						ELSE 'Automated process'
						END
				)
			,@v_ActivityHost = @@SERVERNAME
			,@v_ActivityName = 'Load eurobase re-insurance treaty data for each period into Inbound.Transaction and run into Outbound.Transaction'
			,@v_ActivityDatabase = 'FinanceLanding'
			,@v_ActivityDateTime = GETUTCDATE()
			,@v_ActivityMessage = NULL
			,@v_ActivityErrorCode = NULL;

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStart
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

		DECLARE @v_DataSet VARCHAR(255) = 'RI LPSO TTY'

		--Here date will assign to variable which will get from control datsaet table for respective dataset. 
		SELECT @p_AccountingDate = PassingDate
		FROM SchedulingHub.sch.ControlDataset
		WHERE Dataset = @v_DataSet

		/*This logic works for Day1 loads*/
		IF (@p_AccountingDate = @v_Default_date)
		BEGIN
			DECLARE @AccountingPeriod INT

			IF @AccountingPeriod IS NULL
				SET @AccountingPeriod = 201809 -- this will force the process to start from 201812 which is when the opening balance is created.

			IF OBJECT_ID('tempdb..#AccountingPeriods') IS NOT NULL
				DROP TABLE #AccountingPeriods

			SELECT DISTINCT AccountingPeriod
				,id = IDENTITY(INT, 1, 1)
			INTO #AccountingPeriods
			FROM FinanceLanding.fdm.AccountingPeriod
			WHERE AccountingPeriod >= 201812
				AND AccountingMonth IN (
					3
					,6
					,9
					,12
					)
				AND AccountingPeriod <= YEAR(getdate()) * 100 + MONTH(Getdate())
			ORDER BY 1 ASC

			--select * from #AccountingPeriods
			-- if there are no greater periods we repeat the last period
			IF NOT EXISTS (
					SELECT 1
					FROM #AccountingPeriods
					)
				INSERT INTO #AccountingPeriods (AccountingPeriod)
				VALUES (@AccountingPeriod)

			--select * from #AccountingPeriods
			DECLARE @i INT = 1

			WHILE EXISTS (
					SELECT 1
					FROM #AccountingPeriods
					WHERE id = @i
					)
			BEGIN
				SELECT @AccountingPeriod = AccountingPeriod
				FROM #AccountingPeriods
				WHERE id = @i

				SELECT @AccountingPeriod

				/*--now to call the landing to inbound procedure----*/
				EXEC [Eurobase].[usp_LandingToInbound_TreatyReInsurance] @p_ParentActivityLogId = @p_ParentActivityLogId
					,@p_ActivityJobId = @p_ActivityJobId
					,@p_AccountingPeriod = @AccountingPeriod

				DECLARE @p_txndate DATETIME

				SELECT @p_txndate = CONVERT(DATETIME, CAST(@AccountingPeriod AS VARCHAR(8)) + '01', 105)

				-- check to see if we've got any inbound data and if so run the inbound to outbound procedures.
				IF EXISTS (
						SELECT 1
						FROM [FinanceDataContract].Inbound.[Transaction]
						WHERE DataSet = @v_DataSet
						)
				BEGIN
					--select 'exists'
					EXEC [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_ReInsuranceExtensions]

					EXEC [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_TransactionalDatasetsWithSplits] 0
						,@p_txndate
				END

				-- run in the treaty contract attributes.
				EXEC [Eurobase].[usp_LandingToInbound_TreatyReInsurance_ContractAttributes] @p_ParentActivityLogId = @p_ParentActivityLogId
					,@p_ActivityJobId = @p_ActivityJobId

				EXEC [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTreatyContractAttributes]

				SET @i += 1
			END
		END
		ELSE
			/*This logic works for Day2 loads*/
		BEGIN
			DECLARE @p_txndatePass DATETIME

			SELECT @p_txndatePass = @p_AccountingDate

			DECLARE @p_txnperiodPass INT

			SELECT @p_txnperiodPass = CAST(CONVERT(VARCHAR(6), @p_txndatePass, 112) AS INT)

			/*--now to call the landing to inbound procedure----*/
			EXEC [Eurobase].[usp_LandingToInbound_TreatyReInsurance] @p_ParentActivityLogId = @p_ParentActivityLogId
				,@p_ActivityJobId = @p_ActivityJobId
				,@p_AccountingPeriod = @p_txnperiodPass

			-- check to see if we've got any inbound data and if so run the inbound to outbound procedures.
			IF EXISTS (
					SELECT 1
					FROM [FinanceDataContract].Inbound.[Transaction]
					WHERE DataSet = @v_DataSet
					)
			BEGIN
				--select 'exists'
				EXEC [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_ReInsuranceExtensions]

				EXEC [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_TransactionalDatasetsWithSplits] 0
					,@p_txndatePass
			END

			-- run in the treaty contract attributes.
			EXEC [Eurobase].[usp_LandingToInbound_TreatyReInsurance_ContractAttributes] @p_ParentActivityLogId = @p_ParentActivityLogId
				,@p_ActivityJobId = @p_ActivityJobId
		END

		-- LOG THE RESULT WITH SUCCESS
		SELECT @v_ActivityDateTime = GETUTCDATE();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStop
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;
	END TRY

	BEGIN CATCH
		SELECT @v_ActivityDateTime = GETUTCDATE()
			,@v_ActivityLogTag = @v_ActivityLogIdIn
			,@v_ActivityMessage = ERROR_MESSAGE()
			,@v_ActivityErrorCode = ERROR_NUMBER();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusFail
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		THROW;
	END CATCH
END
GO
