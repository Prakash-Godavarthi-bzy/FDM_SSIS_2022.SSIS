﻿CREATE PROCEDURE [Eurobase].[usp_LandingToInboundToOutbound_FacReInsurance]
AS
BEGIN
	/* =========================================================================

	Altered by:		nithin.dumpeti@beazley.com
	Altered date:	25-01-2024
	Changes:		added new logic which is pass date parameter from table schedulinghub.sch.control table to give more user control to laod the data
	JIRA Ticket:	https://beazley.atlassian.net/browse/I1B-3887

=========================================================================	*/
	SET NOCOUNT ON;

	DECLARE @Trancount INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);
	DECLARE @Logging log.utt_ActivityLog;
	DECLARE @v_RC INT;
	DECLARE @v_ActivityLogTag BIGINT;
	DECLARE @v_ActivitySource SMALLINT;
	DECLARE @v_ActivityType SMALLINT;
	DECLARE @v_ActivityStatusStart SMALLINT;
	DECLARE @v_ActivityStatusStop SMALLINT;
	DECLARE @v_ActivityStatusFail SMALLINT;
	DECLARE @v_ActivityHost VARCHAR(100);
	DECLARE @v_ActivityDatabase VARCHAR(100);
	DECLARE @v_ActivityName VARCHAR(100);
	DECLARE @v_ActivityDateTime DATETIME2(2);
	DECLARE @v_ActivityMessage NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn BIGINT;
	DECLARE @v_ActivityLogIdOut BIGINT;
	DECLARE @v_ActivityJobId VARCHAR(50) = NULL;
	DECLARE @v_ActivitySSISExecutionId VARCHAR(50) = NULL;
	DECLARE @v_AffectedRows INT = 0;
	DECLARE @v_DataSet VARCHAR(255) = 'RI LPSO FAC'
	DECLARE @ContractType CHAR(3) = 'FAC'
	DECLARE @p_ParentActivityLogId BIGINT = NULL
	DECLARE @p_AccountingDate DATE;
	DECLARE @v_AccountingDate DATE;
	DECLARE @v_Default_date DATE = '1900-01-01' -- this will work when doing full refresh which runs till date
		-- for debugging. set to 1 & the no records will be written to the inbound tables.
	DECLARE @stop BIT = 0

	SELECT @v_ActivityStatusStart = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'ERRORED';

	DECLARE @v_BatchId INT;
	DECLARE @v_BatchId_Extensions INT;

	/* Log the start of the insert */
	BEGIN TRY
		SELECT @v_ActivityLogTag = NULL
			,@v_ActivitySource = (
				SELECT PK_ActivitySource
				FROM Orchestram.Log.ActivitySource
				WHERE ActivitySource = 'IFRS17'
				)
			,@v_ActivityType = (
				SELECT PK_ActivityType
				FROM Orchestram.Log.ActivityType
				WHERE ActivityType = CASE 
						WHEN @p_ParentActivityLogId IS NULL
							THEN 'Manual process'
						ELSE 'Automated process'
						END
				)
			,@v_ActivityHost = @@SERVERNAME
			,@v_ActivityName = 'Load eurobase re-insurance data into Inbound and into outbbound.Transaction'
			,@v_ActivityDatabase = 'FinanceLanding'
			,@v_ActivityDateTime = GETUTCDATE()
			,@v_ActivityMessage = NULL
			,@v_ActivityErrorCode = NULL;

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStart
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

		--------------------------------------------------
		--Here date will assign to variable which will get from control datsaet table for respective dataset. 
		SELECT @p_AccountingDate = PassingDate
		FROM SchedulingHub.sch.ControlDataset
		WHERE Dataset = @v_DataSet

		SET @v_AccountingDate = IIF(@p_AccountingDate = @v_Default_date, NULL, @p_AccountingDate)

		INSERT @Logging (
			ActivityStatus
			,ActivityName
			,ActivityMessage
			)
		SELECT 2
			,'Eurobase.[usp_LandingToInbound_FacReInsurance]'
			,'LandingToInBound RI LPSO FAC Reinsurance  Load started';

		/*--now calling landing to inbound proc--*/
		EXEC [FinanceLanding].Eurobase.[usp_LandingToInbound_FacReInsurance] NULL
			,NULL
			,@v_AccountingDate

		INSERT @Logging (
			ActivityStatus
			,ActivityName
			,ActivityMessage
			)
		SELECT 2
			,'Eurobase.[usp_LandingToInbound_FacReInsurance]'
			,'LandingToInBound RI LPSO FAC Reinsurance  Load Succeeded ';

		INSERT @Logging (
			ActivityStatus
			,ActivityName
			,ActivityMessage
			)
		SELECT 2
			,'usp_InboundOutboundWorkflow_ReInsuranceExtensions'
			,'LandingToInBound RI LPSO FAC Reinsurance Extensions  Load started ';

		/*--now calling Extensions proc--*/
		EXEC FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_ReInsuranceExtensions

		INSERT @Logging (
			ActivityStatus
			,ActivityName
			,ActivityMessage
			)
		SELECT 2
			,'usp_InboundOutboundWorkflow_ReInsuranceExtensions'
			,'LandingToInBound RI LPSO FAC Reinsurance Extensions  Load Succeeded ';

		INSERT @Logging (
			ActivityStatus
			,ActivityName
			,ActivityMessage
			)
		SELECT 2
			,'usp_InboundOutboundWorkflow_TransactionalDatasets'
			,'usp_InboundOutboundWorkflow_TransactionalDatasets for RI LPSO FAC Load started';

		--	Declare @p_AccountingDate		    Varchar(10)     = NULL
		DECLARE @AccountingDate DATETIME

		SELECT @AccountingDate = IIF(@p_AccountingDate = @v_Default_date, getdate(), @p_AccountingDate)

		-- run in TransactionalDatasets
		EXEC FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_TransactionalDatasets 0
			,@AccountingDate

		INSERT @Logging (
			ActivityStatus
			,ActivityName
			,ActivityMessage
			)
		SELECT 2
			,'usp_InboundOutboundWorkflow_TransactionalDatasets'
			,'usp_InboundOutboundWorkflow_TransactionalDatasets for RI LPSO FAC Load Succeeded';
	END TRY

	BEGIN CATCH
		-- LOG THE RESULT WITH ERROR
		SELECT @v_ActivityDateTime = GETUTCDATE()
			,@v_ActivityLogTag = @v_ActivityLogIdIn
			,@v_ActivityMessage = ERROR_MESSAGE()
			,@v_ActivityErrorCode = ERROR_NUMBER();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusFail
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		THROW;
	END CATCH;
END;
