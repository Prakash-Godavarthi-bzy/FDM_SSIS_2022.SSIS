﻿
CREATE PROCEDURE [Eurobase].[usp_LandingToInbound_EPI]
             @p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL			
AS
	
-- =============================================

-- http://git.bfl.local/Finance/FinanceLanding.DB
-- Unit tested via script(\src\FinanceLanding.DB\UnitTests\EPI_Step00_Test_Table_Population.sql,EPI_Step01_EndToEnd_byCase.sql)

-- Original Author:		Ciprian Mandras <ciprian.mandras@beazley.com>
-- Create date: 2020-04-23 16:17:45.015
-- Description:	Loads Eurobase LPSO data from FinanceLanding to Inbound.Transaction.

-- Author:		Mark Baekdal <mark.baekdal@beazley.com>
-- Create date: 2021-01-13
-- Description:	Uses MDS to map [Eurobase].[policy_cube].[focus_area] to [MDS].[TriFocus].[Name] to get the tri-focus code. 
--				Fixes defect 236.
--				BR1-IT2 - GP - Eurobase (EPI Reinstatement) - Transactional balances in Production/Techub and Mapping to Trifocus Code

-- Modified by:		Mark Baekdal <mark.baekdal@beazley.com>
-- Modify date: 2021-05-26
-- Description:	Bug fix for Bug I1B-686 - TechHub & Cube - Trifocus code loaded as code. Now loads the TriFocusCode, using MDS, not the code.
--
-- Modified by:		Mark Baekdal <mark.baekdal@beazley.com>
-- Modify date: 2021-06-23
-- Description:	1B-532/I1B-770 Create a list of all account keys in the Outbound Data Contract.
--				As part of this the accounts ending with C or X to be excluded.
--

-- =============================================	
			
BEGIN

		SET NOCOUNT ON;

		DECLARE @Trancount INT= @@Trancount;
		DECLARE @v_ErrorMessage NVARCHAR(4000);

		DECLARE @v_RC							INT;
		DECLARE @v_ActivityLogTag				BIGINT;
		DECLARE @v_ActivitySource				SMALLINT;
		DECLARE @v_ActivityType					SMALLINT;
		DECLARE @v_ActivityStatusStart			SMALLINT;
		DECLARE @v_ActivityStatusStop			SMALLINT;
		DECLARE @v_ActivityStatusFail			SMALLINT;
		DECLARE @v_ActivityHost					VARCHAR(100);
		DECLARE @v_ActivityDatabase				VARCHAR(100);
		DECLARE @v_ActivityName					VARCHAR(100);
		DECLARE @v_ActivityDateTime				DATETIME2(2);
		DECLARE @v_ActivityMessage				NVARCHAR(4000);
		DECLARE @v_ActivityErrorCode			NVARCHAR(50);
		DECLARE @v_ActivityLogIdIn				BIGINT;
		DECLARE @v_ActivityLogIdOut				BIGINT;
		DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId;
		DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
		DECLARE @v_AffectedRows					INT				= 0;

		DECLARE @v_BatchId INT;

		DECLARE @DataSet						VARCHAR(50) = 'EPI Reinstatement Eurobase'

		BEGIN TRY

				SELECT @v_ActivityStatusStart = PK_ActivityStatus 
				FROM Orchestram.Log.ActivityStatus	
				WHERE ActivityStatus = 'STARTED';

				SELECT @v_ActivityStatusStop = PK_ActivityStatus 
				FROM Orchestram.Log.ActivityStatus	
				WHERE ActivityStatus = 'SUCCEEDED';

				SELECT @v_ActivityStatusFail = PK_ActivityStatus 
				FROM Orchestram.Log.ActivityStatus	
				WHERE ActivityStatus = 'ERRORED';
  
				/* Log the start of the insert */

				SELECT   
					 @v_ActivityLogTag		        = NULL
					,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
					,@v_ActivityType				= (SELECT PK_ActivityType	
														FROM Orchestram.Log.ActivityType	
														WHERE ActivityType = CASE 
																				WHEN @p_ParentActivityLogId IS NULL 
																					THEN 'Manual process' 
																					ELSE 'Automated process' 
																				END)
					,@v_ActivityHost				= @@SERVERNAME
					,@v_ActivityName				= 'Load data into Inbound.Transaction'
					,@v_ActivityDatabase			= 'FinanceLanding'
					,@v_ActivityDateTime			= GETUTCDATE()
					,@v_ActivityMessage				= NULL
					,@v_ActivityErrorCode			= NULL;

				EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
							 @p_ParentActivityLogId
							,@v_ActivityLogTag
							,@v_ActivitySource
							,@v_ActivityType
							,@v_ActivityStatusStart
							,@v_ActivityHost
							,@v_ActivityDatabase
							,@v_ActivityJobId
							,@v_ActivitySSISExecutionId
							,@v_ActivityName
							,@v_ActivityDateTime
							,@v_ActivityMessage
							,@v_ActivityErrorCode
							,@v_AffectedRows
							,@v_ActivityLogIdIn OUTPUT;

				SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

				-- populate account mapping for Eurobase.transaction_01

				INSERT INTO   [MDS].[AccountMapping]
							  (
								[table]
							   ,l1
							   ,l2
							   ,l3
							   ,AccountKey
							  )

				SELECT DISTINCT                     
							   'Eurobase.EPI'
							   ,'GPE - Reinstatement Premium' 
							   ,'G/RI'
							   ,CASE
									WHEN t.mop							IN ('B','L')			THEN 'B' 
									ELSE 'P'
								END
							   ,
							   'GPE-RP-' + 
							   CASE
									WHEN t.mop							IN ('B','L')			THEN 'B' 
									ELSE 'P'
								END
				-- SELECT *
				FROM           [FinanceLanding].[Eurobase].[policy_cube] t
	
				WHERE   
					ISNULL(t.mop,'A') NOT IN ('0','A','C') -- we don't want these - we only want B for brokerage and P for premium
					AND NOT EXISTS (SELECT 1 
										   FROM   [MDS].[AccountMapping] am
										   WHERE  am.l1 =	'GPE - Reinstatement Premium' 
										   AND    am.l2 =	'G/RI'
										   AND    am.l3 =	CASE
																WHEN t.mop							IN ('B','L')			THEN 'B' 
																ELSE 'P'
															END
										   AND	  am.[Table] = 'Eurobase.EPI'	
										  );

				-----------------------------------

				/* Conversion rate for original amount where a policy has more than one original currency */

				  SELECT policyref, ToCCY, SUM(CalculatedInUSD) As OriginalValue

				  INTO #tmpOrigValueConversion

				  FROM (
						  SELECT c.datemodified
								, ISNULL(X.crh_currency_code,'GBP') AS FromCCY
								, CONVERT(VARCHAR(3),'USD') AS ToCCY
								, ISNULL(y.crh_rate,1.00)/ISNULL(x.crh_rate,1.00) AS ConversionRate 
								, p.pre_amount/ISNULL(x.crh_rate,1.00) * ISNULL(y.crh_rate,1.00) AS CalculatedInUSD
								, c.policyref
				  
						  FROM Eurobase.policy_premium p
				  
						  INNER JOIN Eurobase.policy_cube c 
						  ON c.policyref = p.pre_cpd_policy_ref

						  OUTER APPLY ( SELECT TOP 1 
												crh_rate, crh_date, rx.crh_currency_code 
										FROM Eurobase.[currency_rates_hist] rx 
										WHERE	CAST(rx.crh_date AS DATE) >= CAST(c.datemodified AS DATE) 
										AND		rx.crh_currency_code = p.pre_currency_code 
										ORDER BY rx.crh_date) AS x
				  
				  
						  OUTER APPLY ( SELECT TOP 1 crh_rate, crh_date, ry.crh_currency_code 
										FROM Eurobase.[currency_rates_hist] ry 
										WHERE	CAST(ry.crh_date AS DATE) >= CAST(c.datemodified AS DATE) 
										AND		ry.crh_currency_code = 'USD' 
										ORDER BY ry.crh_date) AS y

						  WHERE p.pre_prem_qual = 'REI' AND
								p.pre_cpd_policy_ref in ( SELECT pre_cpd_policy_ref 
															  FROM Eurobase.policy_premium
															  WHERE pre_prem_qual = 'REI'
															  GROUP BY pre_cpd_policy_ref
															  HAVING count(*) > 1)

						) AS X

						GROUP BY X.policyref, X.ToCCY

				/* We prepare the table that will be deployed to Inbound schema */

				DROP TABLE IF EXISTS #TempInboundTransaction;

				SELECT 
						 Scenario				= CONVERT([VARCHAR](2),'A')                                                        
						,Basis					= CONVERT([VARCHAR](2),'E')                                                          
						,Account				= ISNULL(CONVERT([VARCHAR](10),am.AccountKey), 'UNKNOWN')
						,DataSet				= CONVERT([VARCHAR](50),@DataSet)                                               
						,DateOfFact				= CONVERT([DATETIME],pc.[datemodified])
						,BusinessKey			= CONVERT([VARCHAR](255),r.[pre_cpd_policy_ref])
						,PolicyNumber			= CONVERT([VARCHAR](255),r.[pre_cpd_policy_ref])
						,InceptionDate			= CONVERT([DATETIME],pc.[inception])
						,ExpiryDate				= CONVERT([DATETIME],pc.[expiry])
						,BindDate				= CONVERT([DATETIME],'01/01/1980')
						,DueDate				= CONVERT([DATETIME],pc.[tot])
						,TrifocusCode			= CONVERT([VARCHAR](25),ISNULL(nullif(tf.TrifocusCode,''),'UNKNOWN'))
						,Entity					= CONVERT([VARCHAR](10),ISNULL(s.[spl_syn_user_number],pc.[synd]))
						,[Location]				= CONVERT([VARCHAR](50),pc.[Multiyear])
						,Yoa					= CONVERT([VARCHAR](5),pc.[yoa])
						,TypeOfBusiness			= CONVERT([VARCHAR](1),'-')                                        
						,SettlementCCY			= CONVERT([VARCHAR](3),v.[cpd_epi_ccy])
						,OriginalCCY			= CONVERT([VARCHAR](3),COALESCE(cv.ToCCY,pp.pre_currency_code,v.[cpd_epi_ccy]))
						,IsToDate				= CONVERT([VARCHAR](1),'Y')
						,Value					= CONVERT([DECIMAL](19, 4),r.[reinstatement_signed] * isnull(s.[spl_percent],100.00) / 100.00 )
						,ValueOrig				= CONVERT([DECIMAL](19, 4),COALESCE(cv.OriginalValue,pp.pre_amount,0.00) * ISNULL(v.signed_line,100.00) / 100.00 * isnull(s.[spl_percent],100.00) / 100.00 )
						,BusinessProcessCode	= CONVERT([VARCHAR](255),'T1')
						,AuditSourceBatchID		= CONVERT([VARCHAR](255),'-')                                                 
						,AuditHost				= CONVERT([VARCHAR](255),(SERVERPROPERTY('MachineName')))      
						,StatsCode              = CONVERT([VARCHAR](25),pc.[stats])
						,FK_Batch				= CONVERT([INT],NULL)
						
				INTO		#TempInboundTransaction
				
				-- SELECT *
				FROM	[Eurobase].[epi_reinstatement]					AS r  
			
				INNER JOIN	[Eurobase].[policy_cube]					AS pc  
				ON		pc.[policyref] = r.[pre_cpd_policy_ref]

				LEFT JOIN [MDS].[TriFocus]					AS tf  
				ON		pc.[focus_area] = tf.[Name]

				INNER JOIN	[Eurobase].[epi_view]						AS v   
				ON		v.[cpd_policy_reference] = r.[pre_cpd_policy_ref]

				LEFT JOIN	[Eurobase].[syndicate_split]				AS s   
				ON		s.[spl_yoa] = pc.[yoa]
				AND		pc.[synd] = 623

				LEFT JOIN #tmpOrigValueConversion						AS cv 
				ON cv.policyref = r.[pre_cpd_policy_ref]

				LEFT JOIN  [Eurobase].[policy_premium]					AS pp   
				ON	pp.pre_cpd_policy_ref = pc.policyref 
				AND	pp.pre_prem_qual = 'REI' 
				AND cv.policyref IS NULL
							 
				LEFT JOIN  [MDS].[AccountMapping] am
				ON		am.l1 =	'GPE - Reinstatement Premium' 
				AND		am.l2 =	'G/RI'
				AND		am.l3 =	CASE
									WHEN pc.mop							IN ('B','L')			THEN 'B' 
									WHEN pc.mop							IN ('C')				THEN 'C' 
									WHEN ISNULL(pc.mop,'A')				IN ('0','A')			THEN 'X' 
									ELSE 'P'
								END
				AND		am.[Table] = 'Eurobase.EPI'



				--SELECT * FROM #TempInboundTransaction
				--RETURN
				----------------------------------------------------------------



				--RAISERROR ('Temp table is filled',0,1) WITH NOWAIT

				IF NOT EXISTS ( SELECT TOP 1 1
					
								FROM #TempInboundTransaction
								)
				BEGIN

					SELECT	  @v_ActivityDateTime			= GETUTCDATE()
							, @v_AffectedRows				= 0

					EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
								 @p_ParentActivityLogId
								,@v_ActivityLogTag
								,@v_ActivitySource
								,@v_ActivityType
								,@v_ActivityStatusStop
								,@v_ActivityHost
								,@v_ActivityDatabase
								,@v_ActivityJobId
								,@v_ActivitySSISExecutionId
								,@v_ActivityName
								,@v_ActivityDateTime
								,@v_ActivityMessage
								,@v_ActivityErrorCode
								,@v_AffectedRows
								,@v_ActivityLogIdIn OUTPUT;		

					RETURN;
				END

				IF @Trancount = 0
					BEGIN TRAN;

				INSERT INTO [dbo].[Batch]
					([CreateDate],[DataSet],[LatestBusinesKey]) 
				VALUES  
					(GETDATE(),@DataSet, NULL);
	
				SELECT @V_BatchId = SCOPE_IDENTITY();
				--RAISERROR ('Batch created',0,1) WITH NOWAIT

				/* Delete the current lines of the Eurobase source system from Inbound ... */

				--DROP INDEX IF EXISTS CIX_INBD_TRAN 
				--ON [Inbound].[Transaction]

				DELETE 
				
				FROM    FinanceDataContract.Inbound.[Transaction]
					
				WHERE   [DataSet] = @DataSet;

				/* ... and add the new ones  */

				INSERT INTO [FinanceDataContract].[Inbound].[Transaction] WITH(TABLOCK)
						([Scenario]
						,[Basis]
						,[Account]
						,[DataSet]
						,[DateOfFact]
						,[BusinessKey]
						,[PolicyNumber]
						,[InceptionDate]
						,[ExpiryDate]
						,[BindDate]
						,[DueDate]
						,[TrifocusCode]
						,[Entity]
						,[Location]
						,[YOA]
						,[TypeOfBusiness]
						,[StatsCode]
						,[SettlementCCY]
						,[OriginalCCY]
						,[IsToDate]
						,[Value]
						,[ValueOrig]
						,[RowHash]
						,[BusinessProcessCode]
						,[FK_Batch]
						,[AuditSourceBatchID]
						,[AuditHost]
						,[AuditGenerateDateTime])		
			  
				SELECT   [Scenario]
						,[Basis]
						,[Account]
						,tmp.[DataSet]
						,[DateOfFact]
						,[BusinessKey]
						,[PolicyNumber]
						,[InceptionDate]
						,[ExpiryDate]
						,[BindDate]
						,[DueDate]
						,[TrifocusCode]
						,[Entity]
						,[Location]
						,[YOA]
						,[TypeOfBusiness]
						,[StatsCode]
						,[SettlementCCY]
						,[OriginalCCY]
						,[IsToDate]
						,ISNULL(an.[AccountSignage],1.00) * [Value]
						,[ValueOrig]
						,HASHBYTES('SHA2_512',
										CONCAT
										(	 
											 Scenario								 		,'§~§'
											,Basis											,'§~§'
											,Account 										,'§~§'
											,tmp.DataSet									,'§~§'
											,BusinessKey 									,'§~§'
											,PolicyNumber 									,'§~§'
											,CONVERT(VARCHAR(10),InceptionDate,102)			,'§~§'
											,CONVERT(VARCHAR(10),ExpiryDate,102)			,'§~§'
											,CONVERT(VARCHAR(10),BindDate,102)				,'§~§'
											,CONVERT(VARCHAR(10),DueDate,102)				,'§~§'
											,TrifocusCode									,'§~§'
											,Entity											,'§~§'
											,Location										,'§~§'
											,YOA 											,'§~§'
											,TypeOfBusiness									,'§~§'
											,StatsCode										,'§~§'
											,SettlementCCY									,'§~§'
											,OriginalCCY									,'§~§'
											,IsToDate										,'§~§'									 
										)
									)
						,[BusinessProcessCode]
						,@v_BatchId
						,@v_BatchId
						,[AuditHost]
						,GETUTCDATE()
						   
				FROM    #TempInboundTransaction tmp

				LEFT JOIN MDS.AccountNames an 
				ON an.AccountKey = tmp.Account and an.DataSet = @DataSet;

				SELECT   @v_AffectedRows			= @@ROWCOUNT;

				--CREATE CLUSTERED COLUMNSTORE INDEX CIX_INBD_TRAN 
				--ON [Inbound].[Transaction]

				/* Add the batch to the queue */

				INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,RunDescription
								,[DataSet]
								,OriginalName
								)
				VALUES
								( @v_BatchId
								 ,'InBound'
								 ,NULL
								 ,@DataSet
								 ,NULL
								);

				-- LOGIN THE RESULT WITH SUCCESS

				SELECT @v_ActivityDateTime			= GETUTCDATE();

				EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
						 @p_ParentActivityLogId
						,@v_ActivityLogTag
						,@v_ActivitySource
						,@v_ActivityType
						,@v_ActivityStatusStop
						,@v_ActivityHost
						,@v_ActivityDatabase
						,@v_ActivityJobId
						,@v_ActivitySSISExecutionId
						,@v_ActivityName
						,@v_ActivityDateTime
						,@v_ActivityMessage
						,@v_ActivityErrorCode
						,@v_AffectedRows
						,@v_ActivityLogIdIn OUTPUT;

				IF @Trancount = 0
					COMMIT;

			END TRY

			BEGIN CATCH

				-- CANCEL TRAN
				IF @Trancount = 0 and @@TRANCOUNT <> 0
					ROLLBACK;
			
				-- LOGIN THE RESULT WITH ERROR

				SELECT   @v_ActivityDateTime				= GETUTCDATE()
						,@v_ActivityLogTag					= @v_ActivityLogIdIn
						,@v_ActivityMessage					= ERROR_MESSAGE()
						,@v_ActivityErrorCode				= ERROR_NUMBER();

				EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
						 @p_ParentActivityLogId
						,@v_ActivityLogTag
						,@v_ActivitySource
						,@v_ActivityType
						,@v_ActivityStatusFail
						,@v_ActivityHost
						,@v_ActivityDatabase
						,@v_ActivityJobId
						,@v_ActivitySSISExecutionId
						,@v_ActivityName
						,@v_ActivityDateTime
						,@v_ActivityMessage
						,@v_ActivityErrorCode
						,@v_AffectedRows
						,@v_ActivityLogIdIn OUTPUT;

				THROW;

			END CATCH;
					
END;
GO

--exec  [Eurobase].[usp_LandingToInbound_EPI]
