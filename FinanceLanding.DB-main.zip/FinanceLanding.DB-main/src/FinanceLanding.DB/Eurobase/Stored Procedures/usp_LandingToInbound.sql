﻿CREATE PROCEDURE [Eurobase].[usp_LandingToInbound] (
	@p_ParentActivityLogId BIGINT = NULL
	,@p_ActivityJobId VARCHAR(50) = NULL
	,@p_AccountingDate DATE = NULL
	)
AS
/* =============================================
-- http://git.bfl.local/Finance/FinanceLanding.DB
-- Unit tested via script(\src\FinanceLanding.DB\UnitTests\LPSO_Step00_Test_Table_Population.sql,LPSO_Step01_EndToEnd_byCase.sql)
-- Original Author:		Ciprian Mandras <ciprian.mandras@beazley.com>
-- Create date: 2019-08-14 10:27:21.157
-- Description:	Loads Eurobase LPSO data from FinanceLanding to Inbound.Transaction.
-- Modified by:		Ciprian Mandras <ciprian.mandras@beazley.com>
-- Modify date: 2020-04-03 17:27:17.870
-- Description:	Changed the Account type calculation (ver. 3) and brokerage calculation method; also reduced the selection pushed in Inbound.Transaction to Gross Premiums and Claims.
--				Added @LPSO_default_brokerage_percentage and @LPSO_loading_starting_year for default percentage when this is missing (not used anymore) and tha first year after which we load data
-- Modified by:		Ciprian Mandras <ciprian.mandras@beazley.com>
-- Modify date: 2020-05-24 14:21:11.220
-- Description:	Bug fix after testing (add a condition when build accounts and management of installment amout when this was 0,
--				the record should be ignored,but I used a case and when installment amount was 0 I choosed the signed net amount instead)
-- Modified by:		Mark Baekdal <mark.baekdal@beazley.com>
-- Modify date: 2020-11-17
-- Description:	Bug fix for the Business key to correctly identify the row in source under all/any conditions.
-- Modified by:		Mark Baekdal <mark.baekdal@beazley.com>
-- Modify date: 2021-01-12
-- Description:	Bug fix for Bug 238 - BR1-IT2 - TechHub & Cube - Trifocus code loaded as Trifocus Name. Now loads the code, using MDS, not the name.
--
-- Modified by:		Mark Baekdal <mark.baekdal@beazley.com>
-- Modify date: 2021-05-26
-- Description:	Bug fix for Bug I1B-686 - TechHub & Cube - Trifocus code loaded as code. Now loads the TriFocusCode, using MDS, not the code.
--
-- Modified by:		Mark Baekdal <mark.baekdal@beazley.com>
-- Modify date: 2021-06-23
-- Description:	1B-532/I1B-770 Create a list of all account keys in the Outbound Data Contract.
--				As part of this Re-Insurance accounts needed to be excluded.
-- Modified by:		Charvitha Sadhu <charvitha.sadhu@beazley.com>
-- Modify date: 2022-06-17
-- Description:  LPSO Claims data is needed again added the code to populate the value for claims Modified the changes as part of JIRA I1B-2975 ticket.
-- Modified by:		Charvitha Sadhu <charvitha.sadhu@beazley.com>
-- Modify date: 2022-06-28
-- Description:  Added the coede to populate premiums for accounts where ded_qual is null Modified the changes as part of JIRA I1B-3052 ticket.
-- Modified by:		Nikil Chowdary  Nallamothu <Nikil. Nallamothu@beazley.com>
-- Modify date: 2022-09-22
-- Description:  Modified the code to replace the unknown trifocus, replaced the MDS.Trifocus table with Fdm.dimtrifocus. Changes are done as part of JIRA 
--                I1B-3317 ticket.
-- Modified by:		Entha Bhargav <entha. bhargav@beazley.com>
-- Modify date: 2022-10-07
-- Description:  commenting [MDS].[AccountMapping] to remove account dups part of https://beazley.atlassian.net/browse/I1B-3349
-- Modified by:		Entha Bhargav <entha. bhargav@beazley.com>
-- Modify date: 2023-05-26
-- Description:   https://beazley.atlassian.net/browse/I1B-3771 , https://beazley.atlassian.net/browse/I1B-3773

	Altered by:			nithin.dumpeti@beazley.com
	Altered date:		05-02-2024
	Changes:			Auditing AccountingPeriod in inbound.batchqueue table in column AsAt for passing date as a parameter externally
-- ============================================= */
BEGIN
	SET NOCOUNT ON;

	DECLARE @Trancount INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);
	DECLARE @v_RC INT;
	DECLARE @v_ActivityLogTag BIGINT;
	DECLARE @v_ActivitySource SMALLINT;
	DECLARE @v_ActivityType SMALLINT;
	DECLARE @v_ActivityStatusStart SMALLINT;
	DECLARE @v_ActivityStatusStop SMALLINT;
	DECLARE @v_ActivityStatusFail SMALLINT;
	DECLARE @v_ActivityHost VARCHAR(100);
	DECLARE @v_ActivityDatabase VARCHAR(100);
	DECLARE @v_ActivityName VARCHAR(100);
	DECLARE @v_ActivityDateTime DATETIME2(2);
	DECLARE @v_ActivityMessage NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn BIGINT;
	DECLARE @v_ActivityLogIdOut BIGINT;
	DECLARE @v_ActivityJobId VARCHAR(50) = @p_ActivityJobId;
	DECLARE @v_ActivitySSISExecutionId VARCHAR(50) = NULL;
	DECLARE @v_AffectedRows INT = 0;
	DECLARE @v_BatchId INT;
	DECLARE @LPSO_default_brokerage_percentage DECIMAL(19, 4);
	DECLARE @LPSO_loading_starting_year DECIMAL(19, 4);
	DECLARE @DataSet CHAR(4) = 'LPSO'
	DECLARE @v_AsAt VARCHAR(6);

	BEGIN TRY
		SELECT TOP 1 @LPSO_default_brokerage_percentage = CAST(Answer AS DECIMAL(19, 4))
		FROM Orchestram.Util.[Configuration]
		WHERE Question = 'EurobaseDefaultBrokeragePercentage'
		ORDER BY ISNULL(AuditModifyDateTime, AuditCreateDateTime) DESC;

		SELECT TOP 1 @LPSO_loading_starting_year = CAST(Answer AS DECIMAL(19, 4))
		FROM Orchestram.Util.[Configuration]
		WHERE Question = 'EurobaseFirstYearToLoad'
		ORDER BY ISNULL(AuditModifyDateTime, AuditCreateDateTime) DESC;

		SELECT @v_ActivityStatusStart = PK_ActivityStatus
		FROM Orchestram.Log.ActivityStatus
		WHERE ActivityStatus = 'STARTED';

		SELECT @v_ActivityStatusStop = PK_ActivityStatus
		FROM Orchestram.Log.ActivityStatus
		WHERE ActivityStatus = 'SUCCEEDED';

		SELECT @v_ActivityStatusFail = PK_ActivityStatus
		FROM Orchestram.Log.ActivityStatus
		WHERE ActivityStatus = 'ERRORED';

		/* Log the start of the insert */
		SELECT @v_ActivityLogTag = NULL
			,@v_ActivitySource = (
				SELECT PK_ActivitySource
				FROM Orchestram.Log.ActivitySource
				WHERE ActivitySource = 'IFRS17'
				)
			,@v_ActivityType = (
				SELECT PK_ActivityType
				FROM Orchestram.Log.ActivityType
				WHERE ActivityType = CASE 
						WHEN @p_ParentActivityLogId IS NULL
							THEN 'Manual process'
						ELSE 'Automated process'
						END
				)
			,@v_ActivityHost = @@SERVERNAME
			,@v_ActivityName = 'Load data into Inbound.Transaction'
			,@v_ActivityDatabase = 'FinanceLanding'
			,@v_ActivityDateTime = GETUTCDATE()
			,@v_ActivityMessage = NULL
			,@v_ActivityErrorCode = NULL;

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStart
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

		--------------------------------------------------
		DECLARE @AccountingDate DATE

		SELECT @AccountingDate = @p_AccountingDate

		--------------------------------------------------
		/* We prepare the table that will be deployed to Inbound schema */
		--	DROP TABLE IF EXISTS #TempInboundTransaction;
		--SELECT 
		--		 Scenario				= CONVERT([VARCHAR](2),'A')                                                        
		--		,Basis					= CONVERT([VARCHAR](2),'B')                                                          
		--		,Account				= CONCAT( CASE ISNULL(t.tra_lloyds_ca_cat_code,'-')
		--					 	                   WHEN '1' THEN 'PC-'
		--										   WHEN '2' THEN 'PC-'
		--										   WHEN '3' THEN 'PC-'
		--						                   WHEN '4' THEN 'CC-'
		--						                   WHEN '5' THEN 'CC-'
		--						                   ELSE 'XX-' 
		--					                       END,
		--											CASE 
		--												WHEN ISNULL(t.tra_lloyds_account_type,'-') = 'A' THEN 'LS-'
		--												WHEN ISNULL(t.tra_lloyds_account_type,'-') in ('S','L') AND YEAR(tra_actual_payment_date) = '9999' THEN 'SD-'
		--												ELSE 'OS-' 
		--											END,
		--											CASE 
		--												WHEN t.tra_lloyds_ca_cat_code				IN ('4','5')		THEN ISNULL(NULLIF(t.tra_business_category,''),'OT')
		--												WHEN ISNULL(t.tra_lloyds_ca_qual_cat,'-')	IN ('H')		
		--														AND 	cc.cob_tri_group IN ('Cat','Ex Cat','Treaty Misc','Clash')		THEN 'RT'  --Remove Non-Treaties from RIP's
		--												WHEN ISNULL(t.tra_lloyds_ca_qual_cat,'-')	IN ('I') 
		--														AND ISNULL(t.tra_entry_type,'-')    IN ('CRP','CAP')	THEN 'PC'
		--												ELSE 'OT'
		--											END
		--										) 
		--		,DataSet				= CONVERT([VARCHAR](50),@dataset)                                               
		--		,DateOfFact				= CONVERT([DATETIME],	
		--											CASE 
		--											WHEN	ISNULL(YEAR(ti.[ins_actual_payment_date]),9999) <> 9999 THEN ti.[ins_actual_payment_date] 
		--											WHEN	ISNULL(YEAR(t.[tra_actual_payment_date]),9999)  <> 9999 THEN t.[tra_actual_payment_date]
		--											ELSE	t.[tra_bureau_signing_date]
		--											END)
		--		,BusinessKey			= CONVERT([VARCHAR](255),
		--									CONCAT
		--									(
		--										ISNULL(CONVERT(varchar(8),[tra_bureau_signing_date],112),''),'|',
		--										ISNULL(CONVERT(varchar(30),t.[tra_bureau_signing_num]),'') ,'|',
		--										ISNULL(CONVERT(varchar(2),t.[tra_treaty_section]),'') ,'|',
		--										ISNULL(CONVERT(varchar(30),t.[tra_bureau_version_num]),'') ,'|',
		--										ISNULL(CONVERT(varchar(30),t.[tra_claim_split_number]),'') ,'|',
		--										ISNULL(CONVERT(varchar(30),t.[tra_syn_user_number]),''),'|',
		--										CONVERT(VARCHAR(50),ISNULL(ti.ins_instalment_num,0)))
		--									)
		--		,PolicyNumber			= CONVERT([VARCHAR](255),t.[tra_policy_ref])
		--		,InceptionDate			= CONVERT([DATETIME],ISNULL(cp.cpd_inception,'19800101'))
		--		,ExpiryDate				= CONVERT([DATETIME],ISNULL(cp.cpd_expiry,'19800101'))
		--		,BindDate				= CONVERT([DATETIME],'01/01/1980')
		--		,DueDate				= CONVERT([DATETIME],'01/01/1980')
		--		,TrifocusCode			= CONVERT([VARCHAR](25),ISNULL(CASE WHEN cc.cob_dept = 'Specialty Lines' THEN f_tf.TriFocusCode ELSE cc_tf.TriFocusCode END,'UNKNOWN'))
		--		,Entity					= CONVERT([VARCHAR](10),t.[tra_syn_user_number])
		--		,[Location]				= CONVERT([VARCHAR](50),'-')
		--		,Yoa					= CONVERT([VARCHAR](5),t.[tra_year_of_account])
		--		,TypeOfBusiness			= CONVERT([VARCHAR](1),'-')                                        
		--		,SettlementCCY			= CONVERT([VARCHAR](3),t.[tra_settlement_ccy_code])
		--		,OriginalCCY			= CONVERT([VARCHAR](3),t.[tra_settlement_ccy_code])
		--		,IsToDate				= CONVERT([VARCHAR](1),'Y')
		--		,Value					= 
		--								  CONVERT([DECIMAL](19, 4),
		--									CASE 
		--									WHEN ti.[ins_instalment_amount] IS NOT NULL
		--									THEN ti.[ins_instalment_amount]
		--									ELSE ISNULL(t.[tra_syndicate_net_amount],0.00) 
		--									END)
		--		,ValueOrig				= 
		--								  CONVERT([DECIMAL](19, 4),	
		--									CASE 
		--									WHEN ti.[ins_instalment_amount] IS NOT NULL
		--									THEN ti.[ins_instalment_amount]
		--									ELSE ISNULL(t.[tra_syndicate_net_amount],0.00)
		--									END)
		--		,BusinessProcessCode	= CONVERT([VARCHAR](255),'T1' 
		--										--+	CASE 
		--										--		WHEN ISNULL(ti.[ins_instalment_amount],0.00) <> 0.00 THEN 'i' ELSE ''
		--										--	END
		--											)
		--		,AuditSourceBatchID		= CONVERT([VARCHAR](255),'-')                                                 
		--		,AuditHost				= CONVERT([VARCHAR](255),(SERVERPROPERTY('MachineName')))      
		--		,StatsCode              = CONVERT([VARCHAR](25),'-')
		--		,FK_Batch				= CONVERT([INT],NULL)
		--		,BK_Percentage			= 1.000000 - 
		--								  CASE WHEN t.tra_lloyds_ca_cat_code IN ('4','5') 
		--									THEN 0.00
		--									ELSE ISNULL(t.tra_total_discount_pcnt,0.00)/100.00
		--									END
		--		,tra_lloyds_ca_cat_code = t.tra_lloyds_ca_cat_code
		--		,ded_qual = pded.ded_qual
		--		,ded_pcnt = isnull(pded.ded_pcnt,0)
		--		--,[ins_instalment_amount]
		--		--,[ins_instalment_num]
		--INTO		#TempInboundTransaction
		--FROM		[Eurobase].[transaction_01]				 AS t 
		--JOIN	[Eurobase].[policy_details_01] pd 
		--		ON		t.tra_policy_ref = pd.pol_cpd_policy_reference
		--		AND		t.tra_syn_user_number = pd.pol_syn_user_number
		--JOIN	[Eurobase].cob_codes					AS cc					
		--		ON		pd.pol_cob_code = cc.cob_code 
		--LEFT JOIN fdm.DimTrifocus cc_tf                
		--		ON cc_tf.TrifocusName = cc.cob_tri_group
		--LEFT JOIN	[Eurobase].[common_policy_details_01] AS cp
		--		ON		cp.cpd_policy_reference = t.[tra_policy_ref]
		--LEFT JOIN	[Eurobase].[transaction_instalment]	 AS ti
		--		ON		ti.ins_pre_br_signing_date	= t.tra_bureau_signing_date  
		--		AND		ti.ins_pre_br_signing_num	= t.tra_bureau_signing_num 
		--		AND		ti.ins_pre_br_version_num	= t.tra_bureau_version_num 
		--		AND		ti.ins_syn_user_number		= t.tra_syn_user_number 
		--		AND		ti.ins_pre_treaty_section	= t.tra_treaty_section
		--LEFT JOIN [Eurobase].focus_area_new	f			
		--		ON				f.foc_udt_initials = cp.cpd_udt_initials
		--		AND		f.foc_cob_code = pd.pol_cob_code
		--		AND		f.foc_mop_code = pd.pol_mop_code
		--		AND		f.foc_stats_code = pd.pol_stats_code
		--		AND		f.foc_risk_class = t.tra_lloyds_risk_class
		--LEFT JOIN fdm.DimTrifocus f_tf            
		--		ON		f_tf.TrifocusName = f.foc_area
		--LEFT JOIN [Eurobase].[policy_deductions] pded 
		--		ON		pded.ded_cpd_policy_ref = t.tra_policy_ref
		--LEFT JOIN Eurobase.[claim_details_01] cd 
		--		ON		cd.cla_unified_claim_ref=t.tra_cla_uni_claim_ref
		--		AND		cd.cla_originating_bureau=t.tra_cla_orig_bureau
		--LEFT JOIN mds.vw_CatCode vcc 
		--		ON ISNULL(cd.cla_clg_group_code,'')=ISNULL(vcc.BeazleyCatCode,'')
		--WHERE	t.tra_year_of_account >= @LPSO_loading_starting_year
		--		AND		(	CASE 
		--						WHEN ti.[ins_instalment_amount] IS NOT NULL
		--							THEN ti.[ins_instalment_amount]
		--						ELSE ISNULL(t.[tra_syndicate_net_amount],0.00)
		--					END <> 0.00
		--				)
		--		AND		[tra_policy_ref] <> '!!!!INVALID' 
		--		AND t.[tra_lloyds_ca_cat_code] in ('1', '2', '3','4','5')  
		--		AND		(vcc.BeazleyCatCode  NOT LIKE '%LF' or vcc.BeazleyCatCode IS NULL)  -- Removing Loss Funds from Gross LPSO
		----------------------------------------------------------------
		--RAISERROR ('Temp table is filled',0,1) WITH NOWAIT
		--return
		--If @TotalDeductionPercent > 100% then this policy and all transactions relating to it should be rejected
		--SHOULD BE DONE IN THE FUTURE: the rejected transactions should be saved and an alert should be created for the rejected transactions				
		DROP TABLE

		IF EXISTS #TempInboundTransaction;
			SELECT Scenario
				,Basis
				,Account
				,Dataset
				,DateOfFact
				,BusinessKey + '|' + Left(Account, CHARINDEX('-', Account, 0) - 1) AS BusinessKey
				,PolicyNumber
				,InceptionDate
				,ExpiryDate
				,BindDate
				,DueDate
				,TrifocusCode
				,Entity
				,[Location]
				,Yoa
				,TypeOfBusiness
				,SettlementCCY
				,OriginalCCY
				,IsToDate
				,[Value]
				,ValueOrig
				,BusinessProcessCode
				,AuditSourceBatchID
				,AuditHost
				,StatsCode
				,FK_Batch
			INTO #TempInboundTransaction
			FROM Eurobase.vw_LPSO
			WHERE CONVERT(DATE, DateOfFact) <= ISNULL(@AccountingDate, DateOfFact)

		--DELETE FROM #TempInboundTransaction
		--WHERE BusinessKey in ( SELECT DISTINCT BusinessKey
		--					   FROM #TempInboundTransaction
		--					   GROUP BY BusinessKey,PolicyNumber
		--					   HAVING SUM(ded_pcnt) > 100)
		--	DROP TABLE IF EXISTS #TempCalculatedValues;
		--					CREATE TABLE #TempCalculatedValues( [BusinessKey] [varchar](255) NOT NULL,
		--														[PolicyNumber] [varchar](255) NOT NULL,
		--														[Percentage] NUMERIC(19,4),
		--														[TotalDeductionPercentage] NUMERIC(19,4),
		--														[Value] NUMERIC(19,4), 
		--														[CalculatedValue] NUMERIC(19,4),
		--														[Type] varchar(8))
		--		----------------populating the data for claims account------------------
		--					INSERT INTO #TempCalculatedValues
		--								(
		--								  [BusinessKey]
		--								 ,[PolicyNumber]
		--								 ,[Percentage]
		--								 ,[TotalDeductionPercentage]
		--								 ,[Value]
		--								 ,[CalculatedValue]
		--								 ,[Type]
		--								)
		--					SELECT			BusinessKey
		--								   ,PolicyNumber
		--								   ,[Percentage] =0  --ROUND(SUM(ded_pcnt),4)
		--								   ,[TotalDeductionPercentage] = 0
		--								   ,[Value] =[Value]
		--								   ,[CalculatedValue] =0
		--								   ,[Type] ='CC-'
		--					FROM #TempInboundTransaction
		--					WHERE  Account like 'CC-%'
		--					--GROUP BY BusinessKey,PolicyNumber
		----Brokerage Cash
		--					INSERT INTO #TempCalculatedValues
		--								(
		--								  [BusinessKey]
		--								 ,[PolicyNumber]
		--								 ,[Percentage]
		--								 ,[TotalDeductionPercentage]
		--								 ,[Value]
		--								 ,[CalculatedValue]
		--								 ,[Type]
		--								)
		--					SELECT		 BusinessKey
		--								   ,PolicyNumber
		--								   ,[Percentage] = ROUND(SUM(ded_pcnt),4) 
		--								   ,[TotalDeductionPercentage] = 0
		--								   ,[Value] = MAX([Value])
		--								   ,[CalculatedValue] = 0
		--								   ,[Type] = 'BC-'
		--					FROM #TempInboundTransaction
		--					WHERE  ded_qual <> 'X'
		--					GROUP BY BusinessKey,PolicyNumber
		----LBS Commission Cash
		--					UNION
		--					SELECT			BusinessKey
		--								   ,PolicyNumber
		--								   ,[Percentage] = ROUND(SUM(ded_pcnt),4) 
		--								   ,[TotalDeductionPercentage] = 0
		--								   ,[Value] = MAX([Value])
		--								   ,[CalculatedValue] = 0
		--								   ,[Type] = 'LBSC-'
		--					FROM #TempInboundTransaction
		--					WHERE  ded_qual = 'X'  or ded_qual is null
		--					GROUP BY BusinessKey,PolicyNumber
		----Insert premium cash for Reinstatements and Profit Commissions for accounts not requiring brokerage (Ticket:  I1B-701)
		--					INSERT INTO #TempCalculatedValues
		--								(
		--								  [BusinessKey]
		--								 ,[PolicyNumber]
		--								 ,[Percentage]
		--								 ,[TotalDeductionPercentage]
		--								 ,[Value]
		--								 ,[CalculatedValue]
		--								 ,[Type]
		--								)	
		--					SELECT			tbl.BusinessKey
		--								   ,tbl.PolicyNumber
		--								   ,[Percentage] = 0 
		--								   ,[TotalDeductionPercentage] = 0 
		--								   ,[Value] = tbl.[Value]
		--								   ,[CalculatedValue] = 0
		--								   ,[Type] = 'PC-'
		--					FROM (
		--							SELECT DISTINCT tcv.BusinessKey,tcv.PolicyNumber,tcv.[Value]
		--							FROM    #TempCalculatedValues tcv
		--							INNER JOIN #TempInboundTransaction tmp 
		--							ON tcv.BusinessKey = tmp.BusinessKey 
		--							AND tcv.PolicyNumber = tmp.PolicyNumber
		--							AND (CASE WHEN tmp.ded_qual = 'X' THEN 'LBSC-' 
		--									  ELSE 'BC-' END) = tcv.[Type] 									
		--							WHERE tcv.[Type] + SUBSTRING([Account],CHARINDEX('-',[Account],2)+1,10) in ('BC-LS-RT','BC-SD-RT','BC-OS-RT','BC-LS-PC','BC-SD-PC','BC-OS-PC') 
		--							EXCEPT
		--							SELECT DISTINCT tcv.BusinessKey,tcv.PolicyNumber,tcv.[Value]
		--							FROM    #TempCalculatedValues tcv
		--							INNER JOIN #TempInboundTransaction tmp 
		--							ON tcv.BusinessKey = tmp.BusinessKey 
		--							AND tcv.PolicyNumber = tmp.PolicyNumber
		--							AND (CASE WHEN tmp.ded_qual = 'X' THEN 'LBSC-' 
		--									  ELSE 'BC-' END) = tcv.[Type] 	
		--							WHERE ded_qual = 'X' 
		--							and tcv.[Type]!='CC-'										
		--						 ) tbl
		----Remove processing of Brokerage for Reinstatements and Profit Commissions for accounts not requiring this (Ticket:  I1B-701)
		--					DELETE tcv
		--					FROM    #TempCalculatedValues tcv
		--					INNER JOIN #TempInboundTransaction tmp 
		--					ON tcv.BusinessKey = tmp.BusinessKey 
		--					AND tcv.PolicyNumber = tmp.PolicyNumber
		--					AND (CASE WHEN tmp.ded_qual = 'X' THEN 'LBSC-' 
		--									  ELSE 'BC-' END) = tcv.[Type]
		--					WHERE tcv.[Type] + SUBSTRING([Account],CHARINDEX('-',[Account],2)+1,10) in ('BC-LS-RT','BC-SD-RT','BC-OS-RT','BC-LS-PC','BC-SD-PC','BC-OS-PC') 
		----Premium Cash
		--					INSERT INTO #TempCalculatedValues
		--								(
		--								  [BusinessKey]
		--								 ,[PolicyNumber]
		--								 ,[Percentage]
		--								 ,[TotalDeductionPercentage]
		--								 ,[Value]
		--								 ,[CalculatedValue]
		--								 ,[Type]
		--								)	
		--					SELECT		BusinessKey
		--								   ,PolicyNumber
		--								   ,[Percentage] = ROUND(SUM([Percentage]),4) 
		--								   ,[TotalDeductionPercentage] = ROUND(SUM([Percentage]),4) 
		--								   ,[Value] = MAX([Value])
		--								   ,[CalculatedValue] = 0
		--								   ,[Type] = 'PC-'
		--					FROM #TempCalculatedValues
		--					where [Type]!='CC-'								
		--					GROUP BY BusinessKey,PolicyNumber
		--					;WITH TotalDeductionPercentageValues
		--					AS 
		--					( 					
		--										SELECT	DISTINCT 	 BusinessKey
		--															,PolicyNumber
		--															,[TotalDeductionPercentage]
		--										FROM #TempCalculatedValues
		--										WHERE [Type] = 'PC-'
		--					)
		--					Update tcv
		--					set [TotalDeductionPercentage] = val.[TotalDeductionPercentage]
		--					FROM #TempCalculatedValues tcv
		--					INNER JOIN TotalDeductionPercentageValues val 
		--					ON tcv.BusinessKey = val.BusinessKey 
		--					AND tcv.PolicyNumber = val.PolicyNumber
		--					where [TYPE]!='CC-'              
		--					Update tcv
		--					set CalculatedValue = CASE 
		--												WHEN [Type] in ('BC-','LBSC-') AND [Percentage] = 0 THEN CONVERT(DECIMAL(36,19),0) 
		--												WHEN [Type] in ('BC-','LBSC-') AND [Percentage] = 100 THEN [Value]
		--												WHEN [Type] = 'PC-' AND [Percentage] = 100 THEN 0
		--												WHEN [Type] = 'PC-' AND [Percentage] < 100 THEN [Value] / (1 - ([TotalDeductionPercentage] / 100))
		--												ELSE  [Value] / (1 - ([TotalDeductionPercentage] / 100)) * ([Percentage] / 100)
		--												END
		--					FROM #TempCalculatedValues tcv
		--					where tcv.[type]!='CC-'				 
		IF NOT EXISTS (
				SELECT TOP 1 1
				FROM #TempInboundTransaction
				)
		BEGIN
			SELECT @v_ActivityDateTime = GETUTCDATE()
				,@v_AffectedRows = 0

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStop
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

			RETURN;
		END

		IF @Trancount = 0
			BEGIN TRAN;

		INSERT INTO [dbo].[Batch] (
			[CreateDate]
			,[DataSet]
			,[LatestBusinesKey]
			)
		VALUES (
			GETDATE()
			,@DataSet
			,NULL
			);

		SELECT @V_BatchId = SCOPE_IDENTITY();

		DELETE
		FROM FinanceDataContract.Inbound.[Transaction]
		WHERE [DataSet] = @DataSet;

		/* ... and add the new ones  */
		INSERT INTO [FinanceDataContract].[Inbound].[Transaction] (
			[Scenario]
			,[Basis]
			,[Account]
			,[DataSet]
			,[DateOfFact]
			,[BusinessKey]
			,[PolicyNumber]
			,[InceptionDate]
			,[ExpiryDate]
			,[BindDate]
			,[DueDate]
			,[TrifocusCode]
			,[Entity]
			,[Location]
			,[YOA]
			,[TypeOfBusiness]
			,[StatsCode]
			,[SettlementCCY]
			,[OriginalCCY]
			,[IsToDate]
			,[Value]
			,[ValueOrig]
			,[RowHash]
			,[BusinessProcessCode]
			,[FK_Batch]
			,[AuditSourceBatchID]
			,[AuditHost]
			,[AuditGenerateDateTime]
			)
		SELECT [Scenario]
			,[Basis]
			,[Account]
			,[DataSet]
			,[DateOfFact]
			,[BusinessKey]
			,[PolicyNumber]
			,[InceptionDate]
			,[ExpiryDate]
			,[BindDate]
			,[DueDate]
			,[TrifocusCode]
			,[Entity]
			,[Location]
			,[YOA]
			,[TypeOfBusiness]
			,[StatsCode]
			,[SettlementCCY]
			,[OriginalCCY]
			,[IsToDate]
			,[Value]
			,[ValueOrig]
			,HASHBYTES('SHA2_512', CONCAT (
					Scenario
					,'§~§'
					,Basis
					,'§~§'
					,Account
					,'§~§'
					,DataSet
					,'§~§'
					,BusinessKey
					,'§~§'
					,PolicyNumber
					,'§~§'
					,CONVERT(VARCHAR(10), InceptionDate, 102)
					,'§~§'
					,CONVERT(VARCHAR(10), ExpiryDate, 102)
					,'§~§'
					,CONVERT(VARCHAR(10), BindDate, 102)
					,'§~§'
					,CONVERT(VARCHAR(10), DueDate, 102)
					,'§~§'
					,TrifocusCode
					,'§~§'
					,Entity
					,'§~§'
					,Location
					,'§~§'
					,YOA
					,'§~§'
					,TypeOfBusiness
					,'§~§'
					,StatsCode
					,'§~§'
					,SettlementCCY
					,'§~§'
					,OriginalCCY
					,'§~§'
					,IsToDate
					,'§~§'
					))
			,[BusinessProcessCode]
			,@v_BatchId
			,@v_BatchId
			,[AuditHost]
			,GETUTCDATE()
		FROM #TempInboundTransaction -- ON tcv.BusinessKey = tmp.BusinessKey AND tcv.PolicyNumber = tmp.PolicyNumber

		SELECT @v_AffectedRows = @@ROWCOUNT;

		SET @v_AsAt = left(convert(VARCHAR(10), ISNULL(@AccountingDate, GETDATE()), 112), 6) --AsAt will store passing date as parameter externally. if it is null then take default as getdate

		/* Add the batch to the queue */
		INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue] (
			Pk_Batch
			,[Status]
			,RunDescription
			,[DataSet]
			,OriginalName
			,AsAt
			)
		VALUES (
			@v_BatchId
			,'InBound'
			,NULL
			,@DataSet
			,NULL
			,@v_AsAt
			);

		-- LOGIN THE RESULT WITH SUCCESS
		SELECT @v_ActivityDateTime = GETUTCDATE();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStop
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		IF @Trancount = 0
			COMMIT;
	END TRY

	BEGIN CATCH
		-- CANCEL TRAN
		IF @Trancount = 0
			AND @@TRANCOUNT <> 0
			ROLLBACK;

		-- LOGIN THE RESULT WITH ERROR
		SELECT @v_ActivityDateTime = GETUTCDATE()
			,@v_ActivityLogTag = @v_ActivityLogIdIn
			,@v_ActivityMessage = ERROR_MESSAGE()
			,@v_ActivityErrorCode = ERROR_NUMBER();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusFail
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		THROW;
	END CATCH;
END;
