﻿CREATE PROCEDURE [Eurobase].[usp_LandingInboundWorkflow_EPIReinstatement]
AS
BEGIN


	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;

	/*======================================================Logging Starts==================================================*/
	--DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'EPI Reinstatement Eurobase';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= NULL;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	DECLARE @ContractType					CHAR(3)			= 'EPI';
	DECLARE		@p_ParentActivityLogId		BIGINT			= NULL

	DECLARE @v_Dataset varchar(50)=@v_ActivityDatabase
	DECLARE @v_BatchId                   INT             = NULL;
	DECLARE @v_BatchId_Extensions INT;



	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';

	INSERT INTO [dbo].[Batch]([CreateDate],[DataSet]) 
	VALUES  (GETDATE(),@v_Dataset);

	SELECT @v_BatchId = SCOPE_IDENTITY();

	SET @v_ActivityJobId=@v_BatchId

	/* Log the start of the insert */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'Eurobase.usp_LandingInboundWorkflow_EPIReinstatement'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'Load data into Inbound.Transaction for EPIReinstatement Excel Direct Load'
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;
	
/*==================Logging End======================*/


	BEGIN TRY
		IF @Trancount = 0 
			BEGIN TRAN;

		/*
=============================================================================================
	Create BatchID In landing
==============================================================================================
*/

	declare 
		 @Scenario char(1)				= 'A' 
		,@Basis char(1)					= 'B'
		,@DefaultDate date				= CAST('01-01-1980' as date)
		,@TypeOfBusiness char(1)		= '-'
		,@Location char(1)				= '-'
		,@IsToDate char(1)				= 'Y'
		,@BusinessProcessCode char(2)	= 'T1'
		,@AuditHost varchar(255)		= CAST(SERVERPROPERTY('MachineName') as varchar(255))
		,@StatsCode varchar(25)			= null
		--,@DateOfFact date				= convert(date,convert(char(8),@p_AccountingPeriod * 100 + 1),112)


	
    /* Insert into logging table */

	INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'Eurobase.LIWF_Reinstatement', ' '+CONVERT(VARCHAR,@v_BatchId)+' Batch Created';

    /* Insert the new records from LandingEPIReinstatement sources in the temp table */
	
	if object_id('tempdb..#LandingTempEPIR') is not null drop table #LandingTempBRP
	
	SELECT 
	   Scenario=ISNULL(LTRIM(RTRIM(Scenario)),@Scenario)
		,Basis= ISNULL(nullif(LTRIM(RTRIM([Basis])),''),@Basis)			
      ,[Account]=LTRIM(RTRIM([Account]))
      ,[Dataset]=ISNULL(nullif(LTRIM(RTRIM([Dataset])),''),@v_Dataset)
      ,[DateOfFact]=LTRIM(RTRIM([DateOfFact]))
      ,[BusinessKey]=LTRIM(RTRIM([BusinessKey]))
      ,[PolicyNumber]=ISNULL(nullif(LTRIM(RTRIM([PolicyNumber])),''),'NOPOLICY')
      ,[InceptionDate]=ISNULL(LTRIM(RTRIM([InceptionDate])),@DefaultDate)
      ,[ExpiryDate]=ISNULL(LTRIM(RTRIM([ExpiryDate])),@DefaultDate)
      ,[BindDate]=ISNULL(LTRIM(RTRIM([BindDate])),@DefaultDate)
      ,[DueDate]=ISNULL(LTRIM(RTRIM([DueDate])),@DefaultDate)
      ,[TrifocusCode]=LTRIM(RTRIM([TrifocusCode]))
      ,[Entity]=LTRIM(RTRIM([Entity]))
	  ,[Location]=(LTRIM(RTRIM([Location])))
      ,[YOA]=LTRIM(RTRIM([YOA]))
      ,[TypeOfBusiness]=ISNULL(nullif(LTRIM(RTRIM([TypeOfBusiness])),''),@TypeOfBusiness)
	  ,[SettlementCCY]=LTRIM(RTRIM([SettlementCCY]))
      ,[OriginalCCY]=LTRIM(RTRIM([OriginalCCY]))
	  ,[IsToDate]=ISNULL(LTRIM(RTRIM([IsToDate])),@IsToDate)
      ,[Value]
	  ,[ValueOrig]
	  ,RowHash=HASHBYTES('SHA2_512',CONCAT([ExcelRowHash]				,'§~§'
											-- extended values
											,ISNULL(RIPolicyType,'')	,'§~§'
											,ISNULL(ProgrammeCode,'')	,'§~§'
											)
						)
		,[RowHash_Transaction_ReInsurance_Extensions]=HASHBYTES('SHA2_512',CONCAT(
											-- extended values
											ISNULL(RIPolicyType,'')		,'§~§'
											,ISNULL(ProgrammeCode,'')	,'§~§'
											)
						)
	  ,[BusinessProcessCode]=ISNULL(nullif(LTRIM(RTRIM([BusinessProcessCode])),''),@BusinessProcessCode)
	  ,[AuditSourceBatchID]=CAST(@v_BatchId AS VARCHAR (50))
	  ,[AuditGenerateDateTime]
      ,[StatsCode]= ISNULL(nullif(LTRIM(RTRIM([StatsCode])),''),null)	  
	  ,[FK_Batch]=@v_BatchId     
      ,[DeltaType]=LTRIM(RTRIM([DeltaType]))
      ,[FK_Allocation]=null
      ,[AuditUserCreate]
	  ,[AuditCreateDateTime]=GETUTCDATE()
      ,AuditHost=@AuditHost
      ,[BoundDate]=ISNULL(nullif(LTRIM(RTRIM([BoundDate])),''),@DefaultDate)
	  ,RIPolicyType
	  ,ProgrammeCode
	  INTO #LandingTempEPIR
	FROM [Eurobase].[LandingEPIReinstatement] 


     ------/* Delete the current lines from Inbound ... */

        DELETE
		FROM [FinanceDataContract].[Inbound].[Transaction]
		WHERE [DataSet] = @v_DataSet

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions_Bridge]
		WHERE [ContractType] = @ContractType

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions]
		WHERE [ContractType] = @ContractType


	 ----------/*Insert into batch table...*/----------------
		
		INSERT INTO [dbo].[Batch]
			([CreateDate],[DataSet],[LatestBusinesKey]) 
		VALUES  
			(GETDATE(),'ReInsuranceExtensions', NULL);

		SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();

	---------/*Insert data into inbound extensions table*/------------
	   
		INSERT INTO  [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions_Bridge] WITH(TABLOCK)
			(
				[RowHash_Transaction]
				,[RowHash_Transaction_ReInsurance_Extensions]
				,[ContractType]
				,[FK_Batch]
			)
			SELECT DISTINCT
				[RowHash]
				,[RowHash_Transaction_ReInsurance_Extensions]
				,@ContractType
				,@v_BatchId_Extensions
			FROM 
				#LandingTempEPIR

			INSERT INTO  [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions] WITH(TABLOCK)
				(
					[RowHash_Transaction_ReInsurance_Extensions]
					,[RIPolicyType]
					,[ProgrammeCode]
					--,[BeazleyCatCode]
					--,[TransactionDate]		
					,[IsLargeLoss]			
					,[ContractType]
					,[FK_Batch]
				)
				SELECT DISTINCT
					[RowHash_Transaction_ReInsurance_Extensions]
					,[RIPolicyType]
					,[ProgrammeCode]
					--,[BeazleyCatCode]
					--,[TransactionDate]		
					, NULL AS [IsLargeLoss]			
					,@ContractType
					,@v_BatchId_Extensions
				FROM 
					#LandingTempEPIR

/*============================================================================================================
			INSERT INTO  Inbound.Transaction FROM FinanceLanding.[Eurobase].[LandingEPIReinstatement]
===============================================================================================================*/
	INSERT INTO [FinanceDataContract].[Inbound].[Transaction] WITH(TABLOCK)
			( [Scenario],[Basis],[Account],[DataSet],[DateOfFact],[BusinessKey],[PolicyNumber],[InceptionDate],[ExpiryDate],[BindDate],[DueDate],[TrifocusCode]
				,[Entity],[Location],[YOA],[TypeOfBusiness],[SettlementCCY],[OriginalCCY],[IsToDate],[Value],[ValueOrig],[RowHash],[BusinessProcessCode]
				,[AuditSourceBatchID],[AuditGenerateDateTime],[StatsCode],[FK_Batch],[DeltaType],[FK_Allocation],[AuditUserCreate],[AuditCreateDateTime],AuditHost,[BoundDate]
			)

	SELECT [Scenario],[Basis],[Account],[DataSet],[DateOfFact],[BusinessKey],[PolicyNumber],[InceptionDate],[ExpiryDate],[BindDate],[DueDate],[TrifocusCode]
			,[Entity],[Location],[YOA],[TypeOfBusiness],[SettlementCCY],[OriginalCCY],[IsToDate],[Value],[ValueOrig],[RowHash],[BusinessProcessCode]
			,[AuditSourceBatchID],[AuditGenerateDateTime],[StatsCode],[FK_Batch],[DeltaType],[FK_Allocation],[AuditUserCreate],[AuditCreateDateTime],AuditHost,[BoundDate] 
	  FROM #LandingTempEPIR
	--WHERE DateOfFact='2020-12-15 00:00:00.000'

		
	    SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'Eurobase.usp_LandingInbound_Reinstatement', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into Inbound.Transaction table';

		INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,RunDescription
								,[DataSet]
								,OriginalName
								,AuditSourceBatchID
								)
				VALUES
								( @v_BatchId
								 ,'InBound'
								 ,'CSV files data as source'
								 ,@v_DataSet
								 ,NULL
								 ,NULL
								)
								,

								( @v_BatchId_Extensions
								,'InBound'
								,'ReInsuranceExtensions, the additional attributes to extend functionality of the transaction table.'
								,'ReInsuranceExtensions'
								,NULL
								,NULL
								);


            -- LOG THE RESULT WITH SUCCESS--
			SELECT @v_ActivityDateTime			= GETUTCDATE();

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStop
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT; 
         
		 -----Insert data into outbound Extensions table--------------

         if exists(select 1 from [FinanceDataContract].Inbound.[Transaction] where DataSet = @v_DataSet)
		begin
			--select 'exists'
			DELETE ex
            from FinanceDataContract.Outbound.[Transaction] t
            INNER JOIN FinanceDataContract.Outbound.Transaction_ReInsurance_Extensions_Bridge rb on t.RowHash = rb.RowHash_Transaction
            INNER JOIN FinanceDataContract.Outbound.Transaction_ReInsurance_Extensions ex on rb.RowHash_Transaction_ReInsurance_Extensions = ex.RowHash_Transaction_ReInsurance_Extensions
            WHERE t.Dataset =@v_Dataset

            DELETE rb
            from FinanceDataContract.Outbound.[Transaction] t
            INNER JOIN FinanceDataContract.Outbound.Transaction_ReInsurance_Extensions_Bridge rb on t.RowHash = rb.RowHash_Transaction
            WHERE t.Dataset = @v_Dataset

             exec [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_ReInsuranceExtensions]
		end
        
		IF @Trancount = 0 
		COMMIT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, 'Eurobase.usp_LandingInboundWorkflow_Reinstatement', 'EPIReinstatement LandingToInBound Succeeded';

		--Generate logging for success--
		EXEC log.usp_LogLanding @Input = @Logging;

	END TRY

	BEGIN CATCH

		IF @Trancount = 0  
				ROLLBACK;
			
			
			-- LOG THE RESULT WITH ERROR--
				UPDATE [FinanceDataContract].[Inbound].[BatchQueue]
				SET Status='OutBoundFailed'
				WHERE PK_Batch=@v_BatchId AND [Status]='InBound' AND DataSet=@v_DataSet
				
			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

			

		    THROW;

		
	END CATCH;

END;