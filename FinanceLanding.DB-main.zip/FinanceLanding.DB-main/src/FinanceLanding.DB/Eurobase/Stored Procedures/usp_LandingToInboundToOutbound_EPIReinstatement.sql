﻿Create PROCEDURE [Eurobase].[usp_LandingToInboundToOutbound_EPIReinstatement]
AS
BEGIN


--------------------------------


DECLARE @v_ErrorMessage NVARCHAR(4000);


	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;


	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'EPI Reinstatement Eurobase';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= NULL;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	DECLARE @ContractType					CHAR(3)			= 'EPI';
	DECLARE		@p_ParentActivityLogId		BIGINT			= NULL


	

	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';

	Select 
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'Eurobase.usp_LandingToInboundToOutbound_EPIReinstatement'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'Load data into outbound.Transaction via baseload or normal load'
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;


	   
	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

	

	BEGIN TRY

	
	IF Exists(Select * from FinanceDataContract.Inbound.BatchQueue where DataSet= @v_ActivityDatabase 	and [Status]='FinanceLanding')
		Begin 

		
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, 'Eurobase.usp_LandingToInboundToOutbound_EPIRIPS', 'EPIReinstatement LandingToInBound Normal Load started';

		Exec Eurobase.[usp_LandingInboundWorkflow_EPIReinstatement_NormalLoad]
		
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, 'Eurobase.usp_LandingToInboundToOutbound_EPIRIPS', 'EPIReinstatement LandingToInBound Normal Load Succeeded';

		
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, 'Eurobase.usp_LandingToInboundToOutbound_EPIRIPS', 'EPIReinstatement Inbound to Outbound Normal Load started';

		Exec [FinanceDataContract].Inbound.[usp_InboundOutboundWorkflow_GAAP]

		
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, 'Eurobase.usp_LandingToInboundToOutbound_EPIRIPS', 'EPIReinstatement Inbound to Outbound Normal Load Succeeded';

		End
		Else 
		Begin 
		
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, 'Eurobase.usp_LandingToInboundToOutbound_EPIRIPS', 'EPIReinstatement LandingToInBound Base Load started';

		Exec [Eurobase].[usp_LandingInboundWorkflow_EPIReinstatement_BaseLoad]

		
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, 'Eurobase.usp_LandingToInboundToOutbound_EPIRIPS', 'EPIReinstatement LandingToInBound Base Load Succeeded';

		
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, 'Eurobase.usp_LandingToInboundToOutbound_EPIRIPS', 'EPIReinstatement Inbound To Outbound Base Load started';

		Exec [FinanceDataContract].TL.[usp_InboundOutBoundWorkflow_TacticalLoads]

		
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, 'Eurobase.usp_LandingToInboundToOutbound_EPIRIPS', 'EPIReinstatement Inbound To Outbound Base Load Succeeded';
		End


		
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, 'Eurobase.usp_LandingToInboundToOutbound_EPIRIPS', 'EPIReinstatement LandingToOutbound via BAseload or Normalload Succeeded';

		--Generate logging for success--
		EXEC log.usp_LogLanding @Input = @Logging;


	END TRY

	BEGIN CATCH
	SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode		= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

			

		    THROW;

		
	END CATCH;

END;