﻿CREATE PROCEDURE [Eurobase].[usp_LandingToInbound_TreatyReInsurance_ContractAttributes]
--declare
             @p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL		
AS

-- =============================================

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	18-05-2021
-- Changes:				Loads Treaty ReInsurance contract data from FinanceLanding to Inbound.ReInsuranceTreatyContractAttributes

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	10-08-2021
-- Changes:				Removed the columns [RI_Code] & [RI_Programme_Description] and added the new column ProgrammeCode.

-- =============================================	
			
BEGIN

		SET NOCOUNT ON;

		DECLARE @Trancount INT= @@Trancount;
		DECLARE @v_ErrorMessage NVARCHAR(4000);

		DECLARE @v_RC							INT;
		DECLARE @v_ActivityLogTag				BIGINT;
		DECLARE @v_ActivitySource				SMALLINT;
		DECLARE @v_ActivityType					SMALLINT;
		DECLARE @v_ActivityStatusStart			SMALLINT;
		DECLARE @v_ActivityStatusStop			SMALLINT;
		DECLARE @v_ActivityStatusFail			SMALLINT;
		DECLARE @v_ActivityHost					VARCHAR(100);
		DECLARE @v_ActivityDatabase				VARCHAR(100);
		DECLARE @v_ActivityName					VARCHAR(100);
		DECLARE @v_ActivityDateTime				DATETIME2(2);
		DECLARE @v_ActivityMessage				NVARCHAR(4000);
		DECLARE @v_ActivityErrorCode			NVARCHAR(50);
		DECLARE @v_ActivityLogIdIn				BIGINT;
		DECLARE @v_ActivityLogIdOut				BIGINT;
		DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId;
		DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
		DECLARE @v_AffectedRows					INT				= 0;
		DECLARE @v_DataSet						VARCHAR(50)	= 'TreatyReInsurance_ContractAttributes'

		-- for debugging. set to 1 & the no records will be written to the inbound tables.
		declare @stop bit = 0


		SELECT @v_ActivityStatusStart = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'STARTED';

		SELECT @v_ActivityStatusStop = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'SUCCEEDED';

		SELECT @v_ActivityStatusFail = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'ERRORED';

		DECLARE @v_BatchId INT;
		--DECLARE @v_BatchId_Extensions INT;
		
  
		/* Log the start of the insert */

		BEGIN TRY

				SELECT   
					 @v_ActivityLogTag		        = NULL
					,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
					,@v_ActivityType				= (SELECT PK_ActivityType	
														FROM Orchestram.Log.ActivityType	
														WHERE ActivityType = CASE 
																				WHEN @p_ParentActivityLogId IS NULL 
																					THEN 'Manual process' 
																					ELSE 'Automated process' 
																				END)
					,@v_ActivityHost				= @@SERVERNAME
					,@v_ActivityName				= 'Load treaty contract attribute re-insurance data into Inbound.ReInsuranceTreatyContractAttributes'
					,@v_ActivityDatabase			= 'FinanceLanding'
					,@v_ActivityDateTime			= GETUTCDATE()
					,@v_ActivityMessage				= NULL
					,@v_ActivityErrorCode			= NULL;

				EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
							 @p_ParentActivityLogId
							,@v_ActivityLogTag
							,@v_ActivitySource
							,@v_ActivityType
							,@v_ActivityStatusStart
							,@v_ActivityHost
							,@v_ActivityDatabase
							,@v_ActivityJobId
							,@v_ActivitySSISExecutionId
							,@v_ActivityName
							,@v_ActivityDateTime
							,@v_ActivityMessage
							,@v_ActivityErrorCode
							,@v_AffectedRows
							,@v_ActivityLogIdIn OUTPUT;

				SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

				--------------------------------------------------


				--------------------------------------------------

				--------------------------------------------------------------------
				
				if object_id('tempdb..#Outbound') is not null drop table #Outbound
				select 
					t.*
				into 
					#Outbound
				from 
					FinanceDataContract.Outbound.ReInsuranceTreatyContractAttributes t
				where
					t.RowIsLatest = 1 -- we're only interested in the latest to test for changes.


				if object_id('tempdb..#Inbound') is not null drop table #Inbound
				-- do the inserts then updates and then union with the deletes
				select 
					 s.[RI_Section_Reference]
					,s.[RI_Policy_Type]
					,s.[ProgrammeCode]
					,s.[Inception_Date]
					,s.[Expiry_Date]
					,s.[Number_of_Reinstatements]
					,s.[Claim_Basis]
					,s.[Slip_Order_%]
					,s.[General_Description]
					,s.[Sum_Insured_Limit]
					,s.[Excess_Limit]
					,s.[Sum_Insured_Currency]
					,s.[Event_Limit]
					,s.[Event_Limit_Currency]
					,s.[Settlement_Limit]
					,s.[Settlement_Limit_Currency]
					,s.[Currency_Converter]
					,s.[Profit_Commission]
					,s.[Profit_Commission_Management_Expenses]
					,s.[Profit_Commission_Currency]
					,s.[Overrider]
					,s.[Average_QS_%]
					,s.[Number_of_QS_Policies]
					,s.[%_Ceded_to_QS]
					,[AuditAction] = case when o.RI_Section_Reference IS NULL then 'I' else 'U' end
					,s.RowHash	
					,[RowVersionNumber] = ISNULL(o.RowVersionNumber,0) + 1
				into
					#Inbound
				from
					(
						select 
							 [RI_Section_Reference]
							,[RI_Policy_Type]
							,[ProgrammeCode]
							,[Inception_Date]
							,[Expiry_Date]
							,[Number_of_Reinstatements]
							,[Claim_Basis]
							,[Slip_Order_%]
							,[General_Description]
							,[Sum_Insured_Limit]
							,[Excess_Limit]
							,[Sum_Insured_Currency]
							,[Event_Limit]
							,[Event_Limit_Currency]
							,[Settlement_Limit]
							,[Settlement_Limit_Currency]
							,[Currency_Converter]
							,[Profit_Commission]
							,[Profit_Commission_Management_Expenses]
							,[Profit_Commission_Currency]
							,[Overrider]
							,[Average_QS_%]
							,[Number_of_QS_Policies]
							,[%_Ceded_to_QS]
							,RowHash				= HASHBYTES('SHA2_512',
																CONCAT(	 ISNULL([RI_Policy_Type],'')  																	,'§~§'
																		,ISNULL([ProgrammeCode],'') 															,'§~§'
																		,ISNULL(CONVERT(VARCHAR(10),[Inception_Date],102),'')												,'§~§'
																		,ISNULL(CONVERT(VARCHAR(10),[Expiry_Date],102),'')												,'§~§'
																		,ISNULL(CONVERT(VARCHAR(30),[Number_of_Reinstatements]),'')										,'§~§'
																		,ISNULL([Claim_Basis],'')																			,'§~§'    
																		,ISNULL(CONVERT(VARCHAR(30),CONVERT(numeric(19,6),[Slip_Order_%])),'')							,'§~§'
																		,ISNULL([General_Description],'')																	,'§~§'
																		,ISNULL(CONVERT(VARCHAR(30),CONVERT(numeric(19,6),[Sum_Insured_Limit])),'')						,'§~§'
																		,ISNULL(CONVERT(VARCHAR(30),CONVERT(numeric(19,6),[Excess_Limit])),'')							,'§~§'
																		,ISNULL([Event_Limit_Currency],'') 																,'§~§'
																		,ISNULL(CONVERT(VARCHAR(30),CONVERT(numeric(19,6),[Settlement_Limit])),'')						,'§~§'
																		,ISNULL([Event_Limit_Currency],'') 																,'§~§'
																		,ISNULL(CONVERT(VARCHAR(30),CONVERT(numeric(19,6),[Currency_Converter])),'')						,'§~§'
																		,ISNULL(CONVERT(VARCHAR(30),CONVERT(numeric(19,6),[Profit_Commission])),'')						,'§~§'
																		,ISNULL(CONVERT(VARCHAR(30),CONVERT(numeric(19,6),[Profit_Commission_Management_Expenses])),'')	,'§~§'
																		,ISNULL([Profit_Commission_Currency],'') 															,'§~§'
																		,ISNULL(CONVERT(VARCHAR(30),CONVERT(numeric(19,6),[Overrider])),'')								,'§~§'
																		,ISNULL(CONVERT(VARCHAR(30),CONVERT(numeric(19,6),[Average_QS_%])),'')							,'§~§'
																		,ISNULL(CONVERT(VARCHAR(30),[Number_of_QS_Policies]),'')											,'§~§'
																		,ISNULL(CONVERT(VARCHAR(30),CONVERT(numeric(19,6),[%_Ceded_to_QS])),'')							,'§~§'
																		)
																	)
						from 
							[Eurobase].[vw_ReInsuranceTreatyContractAttributes] 
					) s
					left join #Outbound o on o.RI_Section_Reference = s.RI_Section_Reference
				where
					o.RI_Section_Reference is null
					or o.RowHash <> s.RowHash

				union all

				select 
					 s.[RI_Section_Reference]
					,s.[RI_Policy_Type]
					,s.[ProgrammeCode]
					,s.[Inception_Date]
					,s.[Expiry_Date]
					,s.[Number_of_Reinstatements]
					,s.[Claim_Basis]
					,s.[Slip_Order_%]
					,s.[General_Description]
					,s.[Sum_Insured_Limit]
					,s.[Excess_Limit]
					,s.[Sum_Insured_Currency]
					,s.[Event_Limit]
					,s.[Event_Limit_Currency]
					,s.[Settlement_Limit]
					,s.[Settlement_Limit_Currency]
					,s.[Currency_Converter]
					,s.[Profit_Commission]
					,s.[Profit_Commission_Management_Expenses]
					,s.[Profit_Commission_Currency]
					,s.[Overrider]
					,s.[Average_QS_%]
					,s.[Number_of_QS_Policies]
					,s.[%_Ceded_to_QS]
					,[AuditAction] = 'D' 
					,s.RowHash	
					,[RowVersionNumber] = s.RowVersionNumber + 1
				from 
					#Outbound s
					left join [Eurobase].[vw_ReInsuranceTreatyContractAttributes] o on o.RI_Section_Reference = s.RI_Section_Reference
				where
					s.AuditAction <> 'D'
					and o.RI_Section_Reference is null


				--RETURN -- gets here in 

					-------------------------------------------------------------------------

				if @stop = 1 return

				------/* Delete the current lines from Inbound ... */

				truncate table [FinanceDataContract].[Inbound].ReInsuranceTreatyContractAttributes					
				



				--If no new data, then log and exit

				IF NOT EXISTS (SELECT TOP 1 1 FROM #Inbound)
				BEGIN

					SELECT	  @v_ActivityDateTime			= GETUTCDATE()
							, @v_AffectedRows				= 0;

					EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
								 @p_ParentActivityLogId
								,@v_ActivityLogTag
								,@v_ActivitySource
								,@v_ActivityType
								,@v_ActivityStatusStop
								,@v_ActivityHost
								,@v_ActivityDatabase
								,@v_ActivityJobId
								,@v_ActivitySSISExecutionId
								,@v_ActivityName
								,@v_ActivityDateTime
								,@v_ActivityMessage
								,@v_ActivityErrorCode
								,@v_AffectedRows
								,@v_ActivityLogIdIn OUTPUT;	

					RETURN;
				END;



				IF @Trancount = 0
					BEGIN TRAN;

					-- select * from [dbo].[Batch]
				INSERT INTO [dbo].[Batch]
					([CreateDate],[DataSet],[LatestBusinesKey]) 
				VALUES  
					(GETDATE(),@v_DataSet, NULL);

				SELECT @v_BatchId = SCOPE_IDENTITY();


				INSERT INTO [FinanceDataContract].[Inbound].[ReInsuranceTreatyContractAttributes] WITH(TABLOCK)
				(
					 [RI_Section_Reference]
					,[RI_Policy_Type]
					,[ProgrammeCode]
					,[Inception_Date]
					,[Expiry_Date]
					,[Number_of_Reinstatements]
					,[Claim_Basis]
					,[Slip_Order_%]
					,[General_Description]
					,[Sum_Insured_Limit]
					,[Excess_Limit]
					,[Sum_Insured_Currency]
					,[Event_Limit]
					,[Event_Limit_Currency]
					,[Settlement_Limit]
					,[Settlement_Limit_Currency]
					,[Currency_Converter]
					,[Profit_Commission]
					,[Profit_Commission_Management_Expenses]
					,[Profit_Commission_Currency]
					,[Overrider]
					,[Average_QS_%]
					,[Number_of_QS_Policies]
					,[%_Ceded_to_QS]
					,[AuditAction]  
					,[RowHash]	
					,[RowVersionNumber] 
					,[FK_Batch]
				)
				select 
					 [RI_Section_Reference]
					,[RI_Policy_Type]
					,[ProgrammeCode]
					,[Inception_Date]
					,[Expiry_Date]
					,[Number_of_Reinstatements]
					,[Claim_Basis]
					,[Slip_Order_%]
					,[General_Description]
					,[Sum_Insured_Limit]
					,[Excess_Limit]
					,[Sum_Insured_Currency]
					,[Event_Limit]
					,[Event_Limit_Currency]
					,[Settlement_Limit]
					,[Settlement_Limit_Currency]
					,[Currency_Converter]
					,[Profit_Commission]
					,[Profit_Commission_Management_Expenses]
					,[Profit_Commission_Currency]
					,[Overrider]
					,[Average_QS_%]
					,[Number_of_QS_Policies]
					,[%_Ceded_to_QS]
					,[AuditAction]  
					,[RowHash]	
					,[RowVersionNumber] 
					,[FK_Batch] = @v_BatchId
				from 
					#Inbound

				SELECT   @v_AffectedRows			= @@ROWCOUNT;



				--/* Add the batchs to the queue */
				---- select top 100 * from [FinanceDataContract].[Inbound].[BatchQueue]  order by 1 desc
				INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,RunDescription
								,[DataSet]
								,OriginalName
								,AuditSourceBatchID
								)
				VALUES
								( @v_BatchId
								 ,'InBound'
								 ,NULL
								 ,@v_DataSet
								 ,NULL
								 ,NULL
								)								

				-- LOG THE RESULT WITH SUCCESS

				SELECT @v_ActivityDateTime			= GETUTCDATE();

				EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
						 @p_ParentActivityLogId
						,@v_ActivityLogTag
						,@v_ActivitySource
						,@v_ActivityType
						,@v_ActivityStatusStop
						,@v_ActivityHost
						,@v_ActivityDatabase
						,@v_ActivityJobId
						,@v_ActivitySSISExecutionId
						,@v_ActivityName
						,@v_ActivityDateTime
						,@v_ActivityMessage
						,@v_ActivityErrorCode
						,@v_AffectedRows
						,@v_ActivityLogIdIn OUTPUT;

				IF @Trancount = 0 AND @@TRANCOUNT <> 0
					COMMIT;
					

			END TRY

			BEGIN CATCH

				-- CANCEL TRAN
				IF @Trancount = 0 AND @@TRANCOUNT <> 0
					ROLLBACK;
			
				-- LOG THE RESULT WITH ERROR

				SELECT   @v_ActivityDateTime				= GETUTCDATE()
						,@v_ActivityLogTag					= @v_ActivityLogIdIn
						,@v_ActivityMessage					= ERROR_MESSAGE()
						,@v_ActivityErrorCode				= ERROR_NUMBER();

				EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
						 @p_ParentActivityLogId
						,@v_ActivityLogTag
						,@v_ActivitySource
						,@v_ActivityType
						,@v_ActivityStatusFail
						,@v_ActivityHost
						,@v_ActivityDatabase
						,@v_ActivityJobId
						,@v_ActivitySSISExecutionId
						,@v_ActivityName
						,@v_ActivityDateTime
						,@v_ActivityMessage
						,@v_ActivityErrorCode
						,@v_AffectedRows
						,@v_ActivityLogIdIn OUTPUT;

				THROW;

			END CATCH;

END;

GO


