﻿
CREATE TABLE [Eurobase].[claim_details_01](
	[cla_originating_bureau] [varchar](1) NULL,
	[cla_unified_claim_ref] [varchar](12) NULL,
	[cla_clg_group_code] [varchar](12) NULL,
)

GO

EXEC sys.sp_addextendedproperty 
	@name=N'description', 
	@value=N'Loaded by the SSIS package IFRS17_EurobaseToLandingExtract.dtsx' , 
	@level0type=N'SCHEMA',
	@level0name=N'Eurobase', 
	@level1type=N'TABLE',
	@level1name=N'claim_details_01'
GO

