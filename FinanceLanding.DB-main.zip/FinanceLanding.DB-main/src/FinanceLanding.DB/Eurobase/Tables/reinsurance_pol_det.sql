﻿
CREATE TABLE [Eurobase].[reinsurance_pol_det](
	[rpd_policy_reference] [varchar](12) NULL,
	[rpd_rein_policy_type] [varchar](3) NULL,
	[rpd_treaty_ri_code] [varchar](6) NULL,
	[rpd_ri_pol_prd_from] [datetime] NULL,
	[rpd_ri_pol_prd_to] [datetime] NULL,
	[rpd_ri_claims_basis] [varchar](3) NULL,
	[rpd_slip_order_pcnt] [float] NULL,
	[rpd_general_description] [varchar](240) NULL,
	[rpd_sum_insured_limit] [float] NULL,
	[rpd_excess_limit] [float] NULL,
	[rpd_sum_insured_ccy] [varchar](3) NULL,
	[rpd_event_limit] [float] NULL,
	[rpd_event_limit_ccy] [varchar](3) NULL,
	[rpd_sp_sett_limit_ccy] [varchar](3) NULL,
	[rpd_slip_roe] [float] NULL,
	[rpd_profit_comm] [float] NULL,
	[rpd_profit_comm_mgt_exp] [float] NULL,
	[rpd_overrider] [float] NULL,

	[rpd_reinstatements] int null,
	[rpd_sp_sett_limit] float null,
	[rpd_exp_profit_comm] float null,
	[rpd_exp_profit_comm_ccy] varchar(3) null,
)

GO

EXEC sys.sp_addextendedproperty 
	@name=N'description', 
	@value=N'Loaded by the SSIS package IFRS17_EurobaseToLandingExtract.dtsx' , 
	@level0type=N'SCHEMA',
	@level0name=N'Eurobase', 
	@level1type=N'TABLE',
	@level1name=N'reinsurance_pol_det'
GO
