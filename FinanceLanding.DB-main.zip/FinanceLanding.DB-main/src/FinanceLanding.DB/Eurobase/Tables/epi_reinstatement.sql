﻿CREATE TABLE [Eurobase].[epi_reinstatement] (
    [pre_cpd_policy_ref]   CHAR (12)  NULL,
    [reinstatement_signed] FLOAT (53) NULL
);

GO

EXEC sys.sp_addextendedproperty 
	@name=N'description', 
	@value=N'Loaded by the SSIS package IFRS17_EurobaseToLandingExtract.dtsx' , 
	@level0type=N'SCHEMA',
	@level0name=N'Eurobase', 
	@level1type=N'TABLE',
	@level1name=N'epi_reinstatement'
GO

