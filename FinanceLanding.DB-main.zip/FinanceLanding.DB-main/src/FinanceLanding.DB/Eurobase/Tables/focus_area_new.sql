﻿CREATE TABLE [Eurobase].[focus_area_new] (
    [foc_tri_group]    VARCHAR (20) NULL,
    [foc_udt_initials] CHAR (3)     NULL,
    [foc_cob_code]     CHAR (3)     NULL,
    [foc_mop_code]     CHAR (1)     NULL,
    [foc_stats_code]   CHAR (3)     NULL,
    [foc_risk_class]   CHAR (2)     NULL,
    [foc_area]         CHAR (25)    NULL,
    [INITIALISE]       INT          NULL
);


GO

EXEC sys.sp_addextendedproperty 
	@name=N'description', 
	@value=N'Loaded by the SSIS package IFRS17_EurobaseToLandingExtract.dtsx' , 
	@level0type=N'SCHEMA',
	@level0name=N'Eurobase', 
	@level1type=N'TABLE',
	@level1name=N'focus_area_new'
GO
