﻿CREATE TABLE [Eurobase].[transaction_instalment] (
    [ins_actual_payment_date] DATETIME   NULL,
    [ins_instalment_amount]   FLOAT (53) NULL,
    [ins_instalment_due_date] DATETIME   NULL,
    [ins_pre_br_signing_date] DATETIME   NULL,
    [ins_pre_br_signing_num]  INT        NULL,
    [ins_pre_br_version_num]  INT        NULL,
    [ins_pre_treaty_section]  CHAR (2)   NULL,
    [ins_syn_user_number]     INT        NULL,
    [ins_instalment_num]      INT        NULL
);


GO

EXEC sys.sp_addextendedproperty 
	@name=N'description', 
	@value=N'Loaded by the SSIS package IFRS17_EurobaseToLandingExtract.dtsx' , 
	@level0type=N'SCHEMA',
	@level0name=N'Eurobase', 
	@level1type=N'TABLE',
	@level1name=N'transaction_instalment'
GO
