﻿CREATE TABLE [Eurobase].[policy_cube] (
    [datemodified]  DATETIME     NULL,
    [Expiry]        DATETIME     NULL,
    [focus_area]    VARCHAR (25) NULL,
    [Inception]     DATETIME     NULL,
    [mop]           VARCHAR (3)  NULL,
    [Multiyear]     VARCHAR (1)  NULL,
    [policyref]     VARCHAR (12) NULL,
    [stats]         VARCHAR (3)  NULL,
    [synd]          INT          NULL,
    [tot]           DATETIME     NULL,
    [yoa]           INT          NULL
);

GO

EXEC sys.sp_addextendedproperty 
	@name=N'description', 
	@value=N'Loaded by the SSIS package IFRS17_EurobaseToLandingExtract.dtsx' , 
	@level0type=N'SCHEMA',
	@level0name=N'Eurobase', 
	@level1type=N'TABLE',
	@level1name=N'policy_cube'
GO

