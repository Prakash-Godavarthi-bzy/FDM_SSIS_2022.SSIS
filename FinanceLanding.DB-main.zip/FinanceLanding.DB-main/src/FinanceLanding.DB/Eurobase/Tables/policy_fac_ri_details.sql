﻿
CREATE TABLE [Eurobase].[policy_fac_ri_details](
	[fac_number] [int] NULL,
	[fac_period_from] [datetime] NULL,
	[fac_period_to] [datetime] NULL,
	[fac_policy_type] [char](3) NULL,
	[fac_limit_ccy] [char](3) NULL,
	[fac_order] [float] NULL,
	[fac_ceded] [float] NULL,
	[fac_no_of_rein] [int] NULL,
	[fac_claims_basis] [char](3) NULL
) 

GO

EXEC sys.sp_addextendedproperty 
	@name=N'description', 
	@value=N'Loaded by the SSIS package IFRS17_EurobaseToLandingExtract.dtsx' , 
	@level0type=N'SCHEMA',
	@level0name=N'Eurobase', 
	@level1type=N'TABLE',
	@level1name=N'policy_fac_ri_details'
GO

