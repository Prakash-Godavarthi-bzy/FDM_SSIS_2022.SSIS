﻿CREATE TABLE [Eurobase].[policy_premium] (
    [pre_amount]         FLOAT (53)   NULL,
    [pre_currency_code]  CHAR (3)     NULL,
    [pre_prem_qual]      CHAR (3)     NULL,
    [pre_cpd_policy_ref] VARCHAR (12) NULL
);


GO

EXEC sys.sp_addextendedproperty 
	@name=N'description', 
	@value=N'Loaded by the SSIS package IFRS17_EurobaseToLandingExtract.dtsx' , 
	@level0type=N'SCHEMA',
	@level0name=N'Eurobase', 
	@level1type=N'TABLE',
	@level1name=N'policy_premium'
GO
