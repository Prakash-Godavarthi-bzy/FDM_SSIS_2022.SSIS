﻿CREATE TABLE [Eurobase].[rein_conditions] (
    [rpc_policy_reference] CHAR (12)     NULL,
    [rpc_syn_processing]   INT           NULL,
    [rpc_condition]        VARCHAR (100) NULL,
    [INITIALISE]           INT           NULL,
    [AuditSSISExecutionID] INT           NULL,
    [AuditSSISPackageName] VARCHAR (255) NULL,
    [AuditCreateDateTime]  DATETIME      CONSTRAINT [DF_Eurobase_rein_conditions_AuditCreateDateTime] DEFAULT (getutcdate()) NOT NULL,
    [AuditUserCreate]      VARCHAR (255) CONSTRAINT [DF_Eurobase_rein_conditions_AuditUserCreate] DEFAULT (suser_sname()) NOT NULL,
    [AuditHost]            VARCHAR (255) CONSTRAINT [DF_Eurobase_rein_conditions_AuditHost] DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) NOT NULL,
    [Description]          VARCHAR (255) NULL
);

