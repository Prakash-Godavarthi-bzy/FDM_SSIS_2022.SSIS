﻿CREATE TABLE [Eurobase].[currency_rates_hist] (
    [crh_date]          DATETIME    NULL,
    [crh_rate]          FLOAT (53)  NULL,
    [crh_currency_code] VARCHAR (3) NULL
);


GO

EXEC sys.sp_addextendedproperty 
	@name=N'description', 
	@value=N'Loaded by the SSIS package IFRS17_EurobaseToLandingExtract.dtsx' , 
	@level0type=N'SCHEMA',
	@level0name=N'Eurobase', 
	@level1type=N'TABLE',
	@level1name=N'currency_rates_hist'
GO
