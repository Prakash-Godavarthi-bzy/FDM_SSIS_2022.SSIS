﻿CREATE TABLE [Eurobase].[policy_deductions] (
    [ded_cpd_policy_ref] VARCHAR (12) NULL,
    [ded_sequence_no]    INT          NULL,
    [ded_qual]           VARCHAR (1)  NULL,
    [ded_pcnt]           REAL         NULL
);

GO

EXEC sys.sp_addextendedproperty 
	@name=N'description', 
	@value=N'Loaded by the SSIS package IFRS17_EurobaseToLandingExtract.dtsx' , 
	@level0type=N'SCHEMA',
	@level0name=N'Eurobase', 
	@level1type=N'TABLE',
	@level1name=N'policy_deductions'
GO

