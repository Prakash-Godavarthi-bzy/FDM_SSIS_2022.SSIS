﻿CREATE TABLE [Eurobase].[transaction_01] (
    [tra_actual_payment_date]  DATETIME   NULL,
    [tra_bureau_signing_date]  DATETIME   NULL,
    [tra_bureau_signing_num]   INT        NULL,
    [tra_bureau_version_num]   INT        NULL,
    [tra_business_category]    NCHAR (3)  NULL,
    [tra_entry_type]           NCHAR (3)  NULL,
    [tra_lloyds_account_type]  NCHAR (1)  NULL,
    [tra_lloyds_ca_qual_cat]   NCHAR (1)  NULL,
    [tra_planned_sett_date]    DATETIME   NULL,
    [tra_policy_ref]           NCHAR (12) NULL,
    [tra_processing_period]    DATETIME   NULL,
    [tra_settlement_ccy_code]  NCHAR (3)  NULL,
    [tra_settlement_date]      DATETIME   NULL,
    [tra_syn_user_number]      INT        NULL,
    [tra_syndicate_net_amount] FLOAT (53) NULL,
    [tra_treaty_section]       NCHAR (2)  NULL,
    [tra_year_of_account]      INT        NULL,
    [transaction_01_id]        BIGINT     NOT NULL,
    [tra_claim_split_number]   INT        NULL,
    [tra_total_discount_pcnt]  REAL       NULL,
	tra_lloyds_ca_cat_code	   NCHAR (1)  NULL,	
    [tra_lloyds_risk_class]    NCHAR (2)  NULL,
    [tra_cla_uni_claim_ref]    NVARCHAR(12) NULL,
    [tra_cla_orig_bureau]      NCHAR(1)   NULL,
    [tra_fac_page_number]      INT        NULL,
    CONSTRAINT [PK_transaction_01] PRIMARY KEY CLUSTERED ([transaction_01_id] ASC) WITH (FILLFACTOR = 90)
);




GO

EXEC sys.sp_addextendedproperty 
	@name=N'description', 
	@value=N'Loaded by the SSIS package IFRS17_EurobaseToLandingExtract.dtsx' , 
	@level0type=N'SCHEMA',
	@level0name=N'Eurobase', 
	@level1type=N'TABLE',
	@level1name=N'transaction_01'
GO
