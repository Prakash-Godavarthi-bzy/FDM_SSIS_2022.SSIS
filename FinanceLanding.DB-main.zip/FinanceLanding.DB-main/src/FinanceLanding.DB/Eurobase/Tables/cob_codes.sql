﻿CREATE TABLE [Eurobase].[cob_codes] (
    [cob_code]           VARCHAR (3)  NULL,
    [cob_syn_processing] INT          NULL,
    [cob_description]    VARCHAR (64) NULL,
    [cob_dept]           VARCHAR (20) NULL,
    [cob_group]          VARCHAR (20) NULL,
    [cob_tri_group]      VARCHAR (20) NULL,
    [cob_tri_group2]     VARCHAR (20) NULL,
    [cob_ritc_group]     VARCHAR (20) NULL,
    [cob_tot]            INT          NULL,
    [Cob_Start_Date]     DATETIME     NULL,
    [Cob_End_Date]       DATETIME     NULL,
    [INITIALISE]         INT          NULL
);


GO

EXEC sys.sp_addextendedproperty 
	@name=N'description', 
	@value=N'Loaded by the SSIS package IFRS17_EurobaseToLandingExtract.dtsx' , 
	@level0type=N'SCHEMA',
	@level0name=N'Eurobase', 
	@level1type=N'TABLE',
	@level1name=N'cob_codes'
GO
