﻿
CREATE TABLE [Eurobase].[policy_reinsurance_link](
	[pri_rpd_policy_ref] [char](12) NULL,
	[pri_proportion] [real] NULL,
	[pri_policy_type] [char](2) NULL,
	[pri_cpd_policy_ref] char(12) null,
	[pri_ceded_pcnt] real null,
)

GO

EXEC sys.sp_addextendedproperty 
	@name=N'description', 
	@value=N'Loaded by the SSIS package IFRS17_EurobaseToLandingExtract.dtsx' , 
	@level0type=N'SCHEMA',
	@level0name=N'Eurobase', 
	@level1type=N'TABLE',
	@level1name=N'policy_reinsurance_link'
GO
