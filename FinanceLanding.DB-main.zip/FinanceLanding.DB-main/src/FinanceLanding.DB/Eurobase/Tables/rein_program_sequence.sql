﻿
-- drop TABLE [Eurobase].[rein_program_sequence]
CREATE TABLE [Eurobase].[rein_program_sequence](
	[rps_program_id] [char](6) NULL,
	[ifrs17_programme_group] varchar(100) null,
	[Retro_Reinsurance_Ind] char(1) null
) 

GO

EXEC sys.sp_addextendedproperty 
	@name=N'description', 
	@value=N'Loaded by the SSIS package IFRS17_EurobaseToLandingExtract.dtsx' , 
	@level0type=N'SCHEMA',
	@level0name=N'Eurobase', 
	@level1type=N'TABLE',
	@level1name=N'rein_program_sequence'
GO
