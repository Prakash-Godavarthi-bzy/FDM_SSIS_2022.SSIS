﻿CREATE TABLE [Eurobase].[policy_details_01] (
    [pol_mop_code]             VARCHAR (10)  NULL,
    [pol_cpd_policy_reference] VARCHAR (12) NULL,
    [pol_syn_user_number]      INT          NULL,
    [pol_cob_code]             VARCHAR (3)  NULL,
    [pol_stats_code]           VARCHAR (3)  NULL
);

GO

EXEC sys.sp_addextendedproperty 
	@name=N'description', 
	@value=N'Loaded by the SSIS package IFRS17_EurobaseToLandingExtract.dtsx' , 
	@level0type=N'SCHEMA',
	@level0name=N'Eurobase', 
	@level1type=N'TABLE',
	@level1name=N'policy_details_01'
GO
