﻿CREATE TABLE [Eurobase].[syndicate_split] (
    [spl_percent]         FLOAT (53) NULL,
    [spl_syn_user_number] INT        NULL,
    [spl_yoa]             INT        NULL
);


GO

EXEC sys.sp_addextendedproperty 
	@name=N'description', 
	@value=N'Loaded by the SSIS package IFRS17_EurobaseToLandingExtract.dtsx' , 
	@level0type=N'SCHEMA',
	@level0name=N'Eurobase', 
	@level1type=N'TABLE',
	@level1name=N'syndicate_split'
GO
