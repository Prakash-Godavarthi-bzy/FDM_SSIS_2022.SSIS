﻿CREATE TABLE [Eurobase].[policy_risk_class] (
    [prc_cpd_policy_ref]     VARCHAR (12)     NULL,
    [prc_sequence_no]        INT              NULL,
    [prc_risk_class]         VARCHAR (2)      NULL,
    [prc_risk_percn]         INT              NULL,
    [INITIALISE]             INT              NULL
);
