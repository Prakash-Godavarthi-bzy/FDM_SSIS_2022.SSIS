﻿
CREATE TABLE [Eurobase].[policy_fac_ri](
	[pfl_cpd_policy_reference] [char](12) NULL,
	[pfl_fac_number] [int] NULL,
	[pfl_fac_page_number]  [int] NULL,
	[fac_policy_type] char(3) null
) 

GO

EXEC sys.sp_addextendedproperty 
	@name=N'description', 
	@value=N'Loaded by the SSIS package IFRS17_EurobaseToLandingExtract.dtsx' , 
	@level0type=N'SCHEMA',
	@level0name=N'Eurobase', 
	@level1type=N'TABLE',
	@level1name=N'policy_fac_ri'
GO


