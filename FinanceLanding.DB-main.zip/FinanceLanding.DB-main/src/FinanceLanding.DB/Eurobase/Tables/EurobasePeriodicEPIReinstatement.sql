﻿CREATE TABLE [Eurobase].[PeriodicEPIReinstatement](
	[AccountingPeriod] [varchar](6) NULL,
	[PolicyNumber] [char](12) NULL,
	[yoa] [int] NULL,
	[focus_area] [varchar](25) NULL,
	[TrifocusCode] [nvarchar](255) NULL,
	[TrifocusName] [nvarchar](255) NULL,
	[Entity] [nvarchar](255) NULL,
	[SignedValue] [float] NULL,
	[SignedLinePercent] [float] NULL,
	[SettlementCCY] [varchar](3) NULL,
	[OrgininalValue] [float] NULL,
	[OriginalCCY] [char](3) NULL,
	[MC_OriginalValue] [float] NULL,
	[MC_OrgininalCCY] [varchar](3) NULL,
	[mop] [varchar](3) NULL,
	[tot] [datetime] NULL,
	[Multiyear] [varchar](1) NULL,
	[statscode] [varchar](3) NULL,
	[Inception] [datetime] NULL,
	[Expiry] [datetime] NULL,
	[AccountKey] [varchar](50) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditGenerateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL,
	[AuditHost] [nvarchar](255) NOT NULL
) ON [PRIMARY]
GO





ALTER TABLE [Eurobase].[PeriodicEPIReinstatement] ADD  CONSTRAINT [DF_EPIReinstatement_NL_AuditCreateDateTime]  DEFAULT (getdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [Eurobase].[PeriodicEPIReinstatement] ADD  CONSTRAINT [DF_EPIReinstatement_NL_AuditGenerateDateTime]  DEFAULT (getdate()) FOR [AuditGenerateDateTime]
GO

ALTER TABLE [Eurobase].[PeriodicEPIReinstatement] ADD  CONSTRAINT [DF_EPIReinstatement_NL_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [Eurobase].[PeriodicEPIReinstatement] ADD  CONSTRAINT [DF_EPIReinstatement_NL_AuditHost]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO