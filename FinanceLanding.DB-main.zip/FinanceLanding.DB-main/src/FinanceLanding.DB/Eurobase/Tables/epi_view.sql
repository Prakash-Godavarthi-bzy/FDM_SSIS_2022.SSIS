﻿CREATE TABLE [Eurobase].[epi_view] (
    [cpd_epi_ccy]          VARCHAR (3)  NULL,
    [cpd_policy_reference] VARCHAR (12) NULL,
    [signed_line]          FLOAT (53)   NULL
);


GO

EXEC sys.sp_addextendedproperty 
	@name=N'description', 
	@value=N'Loaded by the SSIS package IFRS17_EurobaseToLandingExtract.dtsx' , 
	@level0type=N'SCHEMA',
	@level0name=N'Eurobase', 
	@level1type=N'TABLE',
	@level1name=N'epi_view'
GO


