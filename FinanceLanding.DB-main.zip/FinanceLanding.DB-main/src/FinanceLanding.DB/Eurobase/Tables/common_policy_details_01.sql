﻿CREATE TABLE [Eurobase].[common_policy_details_01] (
    [cpd_expiry]           DATETIME     NULL,
    [cpd_inception]        DATETIME     NULL,
    [cpd_policy_reference] VARCHAR (12) NOT NULL,
    [cpd_tri_focus]        CHAR (25)    NULL,
    [cpd_udt_initials]     VARCHAR (3)  NULL,
	[cpd_claim_basis]	   VARCHAR (10)   NULL,
    CONSTRAINT [PK_common_policy_details_01] PRIMARY KEY CLUSTERED ([cpd_policy_reference] ASC) WITH (FILLFACTOR = 90)
);




GO

EXEC sys.sp_addextendedproperty 
	@name=N'description', 
	@value=N'Loaded by the SSIS package IFRS17_EurobaseToLandingExtract.dtsx' , 
	@level0type=N'SCHEMA',
	@level0name=N'Eurobase', 
	@level1type=N'TABLE',
	@level1name=N'common_policy_details_01'
GO
