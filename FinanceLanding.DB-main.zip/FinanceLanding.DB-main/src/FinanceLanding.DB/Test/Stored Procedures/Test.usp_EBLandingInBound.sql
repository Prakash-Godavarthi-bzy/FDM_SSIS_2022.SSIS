﻿CREATE PROC [Test].[usp_EBLandingInBound]
AS 

              DECLARE @Trancount INT = @@Trancount
         BEGIN TRY
              IF @Trancount = 0 BEGIN TRAN;

                       TRUNCATE TABLE [eb].[Epi_View_Bbr2]
                       TRUNCATE TABLE [eb].[Policy_Cube]
					   TRUNCATE  TABLE [Sp].[TrifocusCode]
/*
========================================================================================================================================================================
Inserting Data into Landing Tables and Loading data from Landing to InBound.Transacton
========================================================================================================================================================================
*/

                       INSERT INTO [eb].[Epi_View_Bbr2]
                       ([Policyref],[Inception],[Expiry],[Underwriter],[Dept],[Trifocus],[Yoa],[Stats],[Ccy],[Synd],[Deductions],[Epi],[Auditcreateddatetime],[Auitusercreate],[Audithost])
                       VALUES('ZP009F07ANPM','2007-03-01 00:00:00','2008-06-01 00:00:00','MATTHEW WAGHORN','Specialty Lines','US PE London',2006,'00' ,'USD',2623,1706.25,5118.75,'2019-07-30 13:58:16.3900000','BFL\bardm','UKDVDV267')

                       INSERT INTO [eb].[Policy_Cube]
                       ([Policyref],[Stats],[Area],[Cob],[Status],[Lpsodate],[Mop],[Origpolicyref])
                       VALUES('ZP009F07ANPM','00','UIL','PM','C','2007-04-19 00:00:00','Z','L3784F06ANPM')

					    INSERT INTO [Sp].[TrifocusCode] (	[TrifocusCode]
															,[IsUSTrifocus]
															,[IsKoreanReTrifocus]
															,[TrifocusName]
															,[SourceSystem])
						VALUES('25',0,0,'US PE London','Eurobase')


INSERT INTO Batch(CreateDate,[DataSet]) VALUES (GETDATE(),'Eurobase')

EXECUTE [eb].[usp_LandingInboundWorkflow]

DECLARE              @BatchId INT;
SELECT        @BatchId= MAX([PK_Batch])
FROM          dbo.[Batch]
WHERE         [DataSet] = 'Eurobase'
/*
=========================================================================================================================================================================
Expected Results Loading InTo Temp Table
=========================================================================================================================================================================
*/
       DROP TABLE IF EXISTS #Temp_Inbound_Transaction;
       CREATE TABLE #Temp_Inbound_Transaction(
                                                       [Scenario] [varchar](2)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [Account] [varchar](10)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [DataSet] [varchar](255)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [DateOfFact] [datetime] NOT NULL,
                                                       [BusinessKey] [varchar](255)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [PolicyNumber] [varchar](255)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [InceptionDate] [datetime] NOT NULL,
                                                       [ExpiryDate] [datetime] NOT NULL,
                                                       [BindDate] [datetime] NOT NULL,
                                                       [DueDate] [datetime] NOT NULL,
                                                       [TrifocusCode] [varchar](25)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [Entity] [varchar](10)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [YOA] [varchar](5)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [TypeOfBusiness] [varchar](1)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [SettlementCCY] [varchar](3)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [OriginalCCY] [varchar](3)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [IsToDate] [varchar](1)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [Value] [numeric](19, 4) NOT NULL,
                                                       [AuditSourceBatchID] INT NOT NULL
                                                       )


       INSERT INTO #Temp_Inbound_Transaction    ([Scenario],
                                                                           [Account],
                                                                           [DataSet],
                                                                           [DateOfFact],
                                                                           [BusinessKey],
                                                                           [PolicyNumber],
                                                                           [InceptionDate],
                                                                           [ExpiryDate],
                                                                           [BindDate],
                                                                           [DueDate],
                                                                           [TrifocusCode],
                                                                           [Entity],
                                                                           [YOA],
                                                                           [TypeOfBusiness],
                                                                           [SettlementCCY],
                                                                           [OriginalCCY],
                                                                           [IsToDate],
                                                                           [Value],
                                                                           [AuditSourceBatchID])
       values                                                        ('A',
                                                                           'P-AC-P',
                                                                           'Eurobase',
                                                                           '2007-03-01 00:00:00',
                                                                           'ZP009F07ANPM',
                                                                           'ZP009F07ANPM',
                                                                           '2007-03-01 00:00:00',
                                                                           '2008-06-01 00:00:00',
                                                                           '1980-01-01 00:00:00',
                                                                           '1980-01-01 00:00:00',
                                                                           '25',
                                                                           '2623',
                                                                           '2006',
                                                                           'R',
                                                                           'USD',
                                                                           'USD',
                                                                           'Y',
                                                                           1706.2500,
                                                                           @BatchId)

       
       INSERT INTO #Temp_Inbound_Transaction ([Scenario],
                                                                           [Account],
                                                                           [DataSet],
                                                                           [DateOfFact],
                                                                           [BusinessKey],
                                                                           [PolicyNumber],
                                                                           [InceptionDate],
                                                                           [ExpiryDate],
                                                                           [BindDate],
                                                                           [DueDate],
                                                                           [TrifocusCode],
                                                                           [Entity],
                                                                           [YOA],
                                                                           [TypeOfBusiness],
                                                                           [SettlementCCY],
                                                                           [OriginalCCY],
                                                                           [IsToDate],
                                                                           [Value],
                                                                           [AuditSourceBatchID])
       values                                                        ('A',
                                                                           'P-GP-P',
                                                                           'Eurobase',
                                                                           '2007-03-01 00:00:00',
                                                                           'ZP009F07ANPM',
                                                                           'ZP009F07ANPM',
                                                                           '2007-03-01 00:00:00',
                                                                           '2008-06-01 00:00:00',
                                                                           '1980-01-01 00:00:00',
                                                                           '1980-01-01 00:00:00',
                                                                           '25',
                                                                           '2623',
                                                                           '2006',
                                                                           'R',
                                                                           'USD',
                                                                           'USD',
                                                                           'Y',
                                                                           6825.0000,
                                                                           @BatchId)                      
       
/*
==========================================================================================================================================================================
Comparing Temp table with InBound.Transaction
==========================================================================================================================================================================
*/
SELECT   IIF(COUNT(*)>0,'FAIL','PASS') 
	FROM 
		(	
       SELECT [Scenario], 
                                                               [Account], 
                                                               [DataSet], 
                                                               [DateOfFact], 
                                                               [BusinessKey], 
                                                               [PolicyNumber], 
                                                               [InceptionDate], 
                                                               [ExpiryDate], 
                                                               [BindDate], 
                                                               [DueDate], 
                                                               [TrifocusCode], 
                                                               [Entity], 
                                                               [YOA], 
                                                               [TypeOfBusiness], 
                                                               [SettlementCCY], 
                                                               [OriginalCCY], 
                                                               [IsToDate], 
                                                               [Value],
                                                              [AuditSourceBatchID] 
                                                               FROM  #Temp_Inbound_Transaction  WHERE AuditSourceBatchID=@BatchId
                              EXCEPT 
                              SELECT [Scenario], 
                                                               [Account], 
                                                               Dataset, 
                                                               [DateOfFact], 
                                                               [BusinessKey], 
                                                               [PolicyNumber], 
                                                               [InceptionDate], 
                                                               [ExpiryDate], 
                                                               [BindDate], 
                                                               [DueDate], 
                                                               [TrifocusCode], 
                                                               [Entity], 
                                                               [YOA], 
                                                               [TypeOfBusiness], 
                                                               [SettlementCCY], 
                                                               [OriginalCCY], 
                                                               [IsToDate], 
                                                               [Value],
                                                              [AuditSourceBatchID]
                                                              FROM [FinanceDataContract].[Inbound].[Transaction]   WHERE AuditSourceBatchID=@BatchId 
                     
                    )A
					 ROLLBACK; 
         END TRY
         BEGIN CATCH
               ROLLBACK;
              THROW;
         END CATCH