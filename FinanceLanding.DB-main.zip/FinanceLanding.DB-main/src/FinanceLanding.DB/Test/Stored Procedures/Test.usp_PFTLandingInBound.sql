﻿CREATE PROC  [Test].[usp_PFTLandingInBound]
AS 

              DECLARE @Trancount INT = @@Trancount
         BEGIN TRY
              IF @Trancount = 0 BEGIN TRAN;

                       TRUNCATE TABLE   [pft].[PFT_SYND_WITH_CEDE] 

/*
========================================================================================================================================================================
Inserting Data into Landing Tables and Loading data from Landing to InBound.Transacton
========================================================================================================================================================================
*/

INSERT INTO [pft].[PFT_SYND_WITH_CEDE]([ExtractDate],
                                                                     [PremiumMonth],
                                                                     [ReviewCycle],
                                                                     [MoP],
                                                                     [TriFocusCode],
                                                                     [YOA],
                                                                     [TranCurr],
                                                                     [Entity],
                                                                     [OfficeChannel],
                                                                     [SyndPremiumGIC],
                                                                     [SyndPremiumNIC],
                                                                     [GGP])
VALUES                                                        ('2019-07-22 08:44:02',
                                                                     1,
                                                                     '2019Q2',
                                                                     'Binder',
                                                                     'TRI00090',
                                                                     '2019',
                                                                     'EUR',
                                                                     '2623',
                                                                     'LDN',
                                                                     43952.0000,
                                                                     43952.0000,
                                                                     56348.7179)

/*
=========================================================================================================================================================================
CREATING BATCH
=========================================================================================================================================================================
*/

INSERT INTO Batch(CreateDate,[DataSet]) VALUES (GETDATE(),'PFT')


                     EXECUTE [pft].[usp_LandingInboundWorkflow]

DECLARE              @BatchId INT;
SELECT        @BatchId= MAX([PK_Batch])
FROM          dbo.[Batch]
WHERE         [DataSet] = 'PFT'



/*
=========================================================================================================================================================================
Expected Results Loading InTo Temp Table
=========================================================================================================================================================================
*/
       DROP TABLE IF EXISTS #Temp_Inbound_Transaction;
       CREATE TABLE #Temp_Inbound_Transaction(
                                                       [Scenario] [varchar](2)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [Account] [varchar](10)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [DataSet] [varchar](255)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [DateOfFact] [datetime] NOT NULL,
                                                       [BusinessKey] [varchar](255)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [PolicyNumber] [varchar](255)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [InceptionDate] [datetime] NOT NULL,
                                                       [ExpiryDate] [datetime] NOT NULL,
                                                       [BindDate] [datetime] NOT NULL,
                                                       [DueDate] [datetime] NOT NULL,
                                                       [TrifocusCode] [varchar](25)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [Entity] [varchar](10)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [YOA] [varchar](5)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [TypeOfBusiness] [varchar](1)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [SettlementCCY] [varchar](3)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [OriginalCCY] [varchar](3)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [IsToDate] [varchar](1)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [Value] [numeric](19, 4) NOT NULL,
                                                       AuditSourceBatchID [INT] NOT NULL
                                                       )


INSERT INTO #Temp_Inbound_Transaction (  [Scenario],
                                                                     [Account],
                                                                     [DataSet],
                                                                     [DateOfFact],
                                                                     [BusinessKey],
                                                                     [PolicyNumber],
                                                                     [InceptionDate],
                                                                     [ExpiryDate],
                                                                     [BindDate],
                                                                     [DueDate],
                                                                     [TrifocusCode],
                                                                     [Entity],
                                                                     [YOA],
                                                                     [TypeOfBusiness],
                                                                     [SettlementCCY],
                                                                     [OriginalCCY],
                                                                     [IsToDate],
                                                                     [Value],
                                                                     AuditSourceBatchID )
                                                VALUES (      'F',
                                                                     'P-GP-B',
                                                                     'PFT',
                                                                     '2019-01-15 00:00:00',
                                                                     'Pk_Policy_Binder',
                                                                     'Pk_Policy_Binder',
                                                                     '2019-01-15 00:00:00',
                                                                     '2020-01-15 00:00:00',
                                                                     '1980-01-01 00:00:00',
                                                                     '1980-01-01 00:00:00',
                                                                     'TRI00090',
                                                                     '2623',
                                                                     '2019',
                                                                     'N',
                                                                     'EUR',
                                                                     'EUR',
                                                                     'Y',
                                                                     56348.7179,
                                                                     @BatchId)

INSERT INTO #Temp_Inbound_Transaction (  [Scenario],
                                                                     [Account],
                                                                     [DataSet],
                                                                     [DateOfFact],
                                                                     [BusinessKey],
                                                                     [PolicyNumber],
                                                                     [InceptionDate],
                                                                     [ExpiryDate],
                                                                     [BindDate],
                                                                     [DueDate],
                                                                     [TrifocusCode],
                                                                     [Entity],
                                                                     [YOA],
                                                                     [TypeOfBusiness],
                                                                     [SettlementCCY],
                                                                     [OriginalCCY],
                                                                     [IsToDate],
                                                                     [Value],
                                                                     AuditSourceBatchID)
                                                VALUES (      'F',
                                                                     'P-AC-B',
                                                                     'PFT',
                                                                     '2019-01-15 00:00:00',
                                                                     'Pk_Policy_Binder',
                                                                     'Pk_Policy_Binder',
                                                                     '2019-01-15 00:00:00',
                                                                     '2020-01-15 00:00:00',
                                                                     '1980-01-01 00:00:00',
                                                                     '1980-01-01 00:00:00',
                                                                     'TRI00090',
                                                                     '2623',
                                                                     '2019',
                                                                     'N',
                                                                     'EUR',
                                                                     'EUR',
                                                                     'Y',
                                                                     12396.7179,
                                                                     @BatchId)
       

/*
==========================================================================================================================================================================
Comparing Temp table with InBound.Transaction
==========================================================================================================================================================================
*/
	SELECT   IIF(COUNT(*)>0,'FAIL','PASS') 
	FROM 
		(	
       SELECT [Scenario], 
                                                               [Account], 
                                                               [DataSet], 
                                                               [DateOfFact], 
                                                               [BusinessKey], 
                                                               [PolicyNumber], 
                                                               [InceptionDate], 
                                                               [ExpiryDate], 
                                                               [BindDate], 
                                                               [DueDate], 
                                                               [TrifocusCode], 
                                                               [Entity], 
                                                               [YOA], 
                                                               [TypeOfBusiness], 
                                                               [SettlementCCY], 
                                                               [OriginalCCY], 
                                                               [IsToDate], 
                                                               [Value],
                                                              [AuditSourceBatchID] 
                                                               FROM  #Temp_Inbound_Transaction  WHERE AuditSourceBatchID=@BatchId
                              EXCEPT 
                              SELECT [Scenario], 
                                                               [Account], 
                                                               [DataSet], 
                                                               [DateOfFact], 
                                                               [BusinessKey], 
                                                               [PolicyNumber], 
                                                               [InceptionDate], 
                                                               [ExpiryDate], 
                                                               [BindDate], 
                                                               [DueDate], 
                                                               [TrifocusCode], 
                                                               [Entity], 
                                                               [YOA], 
                                                               [TypeOfBusiness], 
                                                               [SettlementCCY], 
                                                               [OriginalCCY], 
                                                               [IsToDate], 
                                                               [Value],
                                                              AuditSourceBatchID
                                                              FROM [FinanceDataContract].[Inbound].[Transaction]   WHERE AuditSourceBatchID=@BatchId 
                     
                     )A
					 ROLLBACK; 
         END TRY
         BEGIN CATCH
               ROLLBACK;
              THROW;
         END CATCH