﻿CREATE PROC [test].[usp_EBLandingInBound_LBSPercentageCheck]
AS 

              DECLARE @Trancount INT = @@Trancount
         BEGIN TRY
              IF @Trancount = 0 BEGIN TRAN;

                       TRUNCATE TABLE [eb].[Epi_View_Bbr2]
                       TRUNCATE TABLE [eb].[Policy_Cube]
					   TRUNCATE TABLE [eb].[Policy_Deductions]
					   TRUNCATE  TABLE [Sp].[TrifocusCode]
/*
========================================================================================================================================================================
Inserting Data into Landing Tables and Loading data from Landing to InBound.Transacton
========================================================================================================================================================================
*/
						INSERT INTO	[eb].[Policy_Deductions]
						(ded_cpd_policy_ref,ded_sequence_no,ded_qual,ded_pcnt) VALUES
						('B5346J19DNDM',4,'X',2.75)

                       INSERT INTO [eb].[Epi_View_Bbr2]
                       ([Policyref],[Inception],[Expiry],[Underwriter],[Dept],[Trifocus],[Yoa],[Stats],[Ccy],[Synd],[Deductions],[Epi],[Auditcreateddatetime],[Auitusercreate],[Audithost])
                       VALUES('B5346J19DNDM','2019-03-01 00:00:00.000','2020-02-29 00:00:00.000','MICHELA MURGIA','Specialty Lines','International',2019,00,'EUR','2623',94710.0000,151290.0000,'2019-10-18 07:38:31.6230000','BFL\lakkh','UKDVDV298')

                       INSERT INTO [eb].[Policy_Cube]
                       ([Policyref],[Stats],[Area],[Cob],[Status],[Lpsodate],[Mop],[Origpolicyref])
                       VALUES('B5346J19DNDM','00','EIT','DM','L','2019-08-20 00:00:00.000','B','B5346J19DNDM')	

					   INSERT INTO [Sp].[TrifocusCode] (	[TrifocusCode]
															,[IsUSTrifocus]
															,[IsKoreanReTrifocus]
															,IsSLInternational
															,[TrifocusName]
															,[SourceSystem])
						VALUES('10',0,0,1,'International','Eurobase')

INSERT INTO dbo.Batch(CreateDate,[DataSet]) VALUES (GETDATE(),'Eurobase')

EXECUTE [eb].[usp_LandingInboundWorkflow]

DECLARE              @BatchId INT;
SELECT        @BatchId= MAX([PK_Batch])
FROM          dbo.[Batch]
WHERE         [DataSet] = 'Eurobase'
/*
=========================================================================================================================================================================
Expected Results Loading InTo Temp Table
=========================================================================================================================================================================
*/
       DROP TABLE IF EXISTS #Temp_Inbound_Transaction;
       CREATE TABLE #Temp_Inbound_Transaction(
                                                       [Scenario] [nvarchar](2)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [Account] [nvarchar](10)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [DataSet] [nvarchar](255)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [DateOfFact] [datetime2](7) NOT NULL,
                                                       [BusinessKey] [nvarchar](255)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [PolicyNumber] [nvarchar](255)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [InceptionDate] [datetime2](7) NOT NULL,
                                                       [ExpiryDate] [datetime2](7) NOT NULL,
                                                       [BindDate] [datetime2](7) NOT NULL,
                                                       [DueDate] [datetime2](7) NOT NULL,
                                                       [TrifocusCode] [nvarchar](25)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [Entity] [nvarchar](10)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [YOA] [nvarchar](5)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [TypeOfBusiness] [nvarchar](1)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [SettlementCCY] [nvarchar](3)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [OriginalCCY] [nvarchar](3)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [IsToDate] [nvarchar](1)COLLATE DATABASE_DEFAULT NOT NULL,
                                                       [Value] [numeric](19, 4) NOT NULL,
                                                       [AuditSourceBatchID] INT NOT NULL
                                                       )


       INSERT INTO #Temp_Inbound_Transaction							  ([Scenario],
                                                                           [Account],
                                                                           [DataSet],
                                                                           [DateOfFact],
                                                                           [BusinessKey],
                                                                           [PolicyNumber],
                                                                           [InceptionDate],
                                                                           [ExpiryDate],
                                                                           [BindDate],
                                                                           [DueDate],
                                                                           [TrifocusCode],
                                                                           [Entity],
                                                                           [YOA],
                                                                           [TypeOfBusiness],
                                                                           [SettlementCCY],
                                                                           [OriginalCCY],
                                                                           [IsToDate],
                                                                           [Value],
                                                                           [AuditSourceBatchID])
       values															   ('A',
                                                                           'P-AC-B',
                                                                           'Eurobase',
                                                                           '2019-03-01 00:00:00.0000000',
                                                                           'B5346J19DNDM',
                                                                           'B5346J19DNDM',
                                                                           '2019-03-01 00:00:00.0000000',
                                                                           '2020-02-29 00:00:00.0000000',
                                                                           '1980-01-01 00:00:00.0000000',
                                                                           '1980-01-01 00:00:00.0000000',
                                                                           10,
                                                                           2623,
                                                                           2019,
                                                                           'N',
                                                                           'EUR',
                                                                           'EUR',
                                                                           'Y',
                                                                           94710.0000,
                                                                           @BatchId)

       
       INSERT INTO #Temp_Inbound_Transaction							   ([Scenario],
                                                                           [Account],
                                                                           [DataSet],
                                                                           [DateOfFact],
                                                                           [BusinessKey],
                                                                           [PolicyNumber],
                                                                           [InceptionDate],
                                                                           [ExpiryDate],
                                                                           [BindDate],
                                                                           [DueDate],
                                                                           [TrifocusCode],
                                                                           [Entity],
                                                                           [YOA],
                                                                           [TypeOfBusiness],
                                                                           [SettlementCCY],
                                                                           [OriginalCCY],
                                                                           [IsToDate],
                                                                           [Value],
                                                                           [AuditSourceBatchID])
       values															   ('A',
                                                                           'P-GP-B',
                                                                           'Eurobase',
                                                                           '2019-03-01 00:00:00.0000000',
                                                                           'B5346J19DNDM',
                                                                           'B5346J19DNDM',
                                                                           '2019-03-01 00:00:00.0000000',
                                                                           '2020-02-29 00:00:00.0000000',
                                                                           '1980-01-01 00:00:00.0000000',
                                                                           '1980-01-01 00:00:00.0000000',
                                                                           10,
                                                                           2623,
                                                                           2019,
                                                                           'N',
                                                                           'EUR',
                                                                           'EUR',
                                                                           'Y',
                                                                           246000.0000,
                                                                           @BatchId)  
																		   
           INSERT INTO #Temp_Inbound_Transaction							([Scenario],
                                                                           [Account],
                                                                           [DataSet],
                                                                           [DateOfFact],
                                                                           [BusinessKey],
                                                                           [PolicyNumber],
                                                                           [InceptionDate],
                                                                           [ExpiryDate],
                                                                           [BindDate],
                                                                           [DueDate],
                                                                           [TrifocusCode],
                                                                           [Entity],
                                                                           [YOA],
                                                                           [TypeOfBusiness],
                                                                           [SettlementCCY],
                                                                           [OriginalCCY],
                                                                           [IsToDate],
                                                                           [Value],
                                                                           [AuditSourceBatchID])
       values															   ('A',
                                                                           'P-LB-B',
                                                                           'Eurobase',
                                                                           '2019-03-01 00:00:00.0000000',
                                                                           'B5346J19DNDM',
                                                                           'B5346J19DNDM',
                                                                           '2019-03-01 00:00:00.0000000',
                                                                           '2020-02-29 00:00:00.0000000',
                                                                           '1980-01-01 00:00:00.0000000',
                                                                           '1980-01-01 00:00:00.0000000',
                                                                           10,
                                                                           2623,
                                                                           2019,
                                                                           'N',
                                                                           'EUR',
                                                                           'EUR',
                                                                           'Y',
                                                                           6765.000000,
                                                                           @BatchId)                      
       
/*
==========================================================================================================================================================================
Comparing Temp table with InBound.Transaction
==========================================================================================================================================================================
*/
	SELECT   IIF(COUNT(*)>0,'FAIL','PASS') 
	FROM 
		(	
		SELECT												   [Scenario], 
                                                               [Account], 
                                                               [DataSet], 
															   [DateOfFact], 
                                                               [BusinessKey], 
                                                               [PolicyNumber], 
                                                               [InceptionDate], 
                                                               [ExpiryDate], 
                                                               [BindDate], 
                                                               [DueDate], 
                                                               [TrifocusCode], 
                                                               [Entity], 
                                                               [YOA], 
                                                               [TypeOfBusiness], 
                                                               [SettlementCCY], 
                                                               [OriginalCCY], 
                                                               [IsToDate], 
                                                               [Value],
                                                              [AuditSourceBatchID] 
                                                               FROM  #Temp_Inbound_Transaction  WHERE AuditSourceBatchID=@BatchId
                              EXCEPT 
                              SELECT [Scenario], 
                                                               [Account], 
                                                               [DataSet], 
                                                               [DateOfFact], 
                                                               [BusinessKey], 
                                                               [PolicyNumber], 
                                                               [InceptionDate], 
                                                               [ExpiryDate], 
                                                               [BindDate], 
                                                               [DueDate], 
                                                               [TrifocusCode], 
                                                               [Entity], 
                                                               [YOA], 
                                                               [TypeOfBusiness], 
                                                               [SettlementCCY], 
                                                               [OriginalCCY], 
                                                               [IsToDate], 
                                                               [Value],
                                                              [AuditSourceBatchID]
                                                              FROM [FinanceDataContract].[Inbound].[Transaction]   WHERE AuditSourceBatchID=@BatchId
				) A
                     
		ROLLBACK; 
         END TRY
         BEGIN CATCH
               ROLLBACK;
              THROW;
         END CATCH
