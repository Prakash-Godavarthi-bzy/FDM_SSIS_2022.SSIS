﻿CREATE PROC [test].[usp_LogBatchAggregate] @Jobid INT
AS

/*
        =========================================================================================================
						Set logging parameters for inbound value test
		=========================================================================================================
*/

     DECLARE		 @ActivitySource_GP SMALLINT=1, --1 --IFRS17--2--DatatContracct
					 @ActivityStatus_GP SMALLINT=5, --1 started 2 succeded 3 stopped 4 errored 5 information 
					 @ActivityName_GP VARCHAR(50)='EbLanding.test.usp_LogBatchAggregate_Gross',
					 @ActivityMessage_GP NVARCHAR(4000)


			SELECT		 @ActivityMessage_GP=ISNULL(SUM(CAST(ROUND(Deductions-COALESCE(R.bkg,0.00),2) AS NUMERIC(19, 4)) + CAST(ROUND(EP.EPI, 2) AS NUMERIC(19, 4))),0)
			FROM		FinanceLanding.Eb.Epi_View_Bbr2 EP
			JOIN		FinanceLanding.Eb.Policy_Cube PC
			ON			EP.policyref = PC.policyref
			JOIN		FinanceLanding.[sp].[TrifocusCode] trf 
			ON			EP.trifocus = trf.[TrifocusName]
						AND trf.SourceSystem = 'Eurobase'
			LEFT JOIN   FinanceLanding.Eb.epi_reinstatement_bkg2  R	ON EP.policyref = R.pre_cpd_policy_ref
													AND EP.synd = R.spl_syn_user_number
			WHERE		(Epi + (Deductions-COALESCE(R.bkg,0.00)))> 0 
/*
		=========================================================================================================
						Log eurobase total value in Landing for testing inbound datacontract value
		=========================================================================================================
*/

     EXEC [dbo].[usp_LogLanding] 
          @v_ActivityMessage = @ActivityMessage_GP, 
          @v_ActivityStatus = @ActivityStatus_GP, 
          @v_ActivityName = @ActivityName_GP,
		  @V_JobId = @Jobid;

/*
        =========================================================================================================
						Set logging parameters for inbound value test Acquition Costs
		=========================================================================================================
*/

     DECLARE		 @ActivitySource_AC SMALLINT=1, --1 --IFRS17--2--DatatContracct
					 @ActivityStatus_AC SMALLINT=5, --1 started 2 succeded 3 stopped 4 errored 5 information 
					 @ActivityName_AC VARCHAR(50)='EbLanding.test.usp_LogBatchAggregate_AcquitionsCos',
					 @ActivityMessage_AC NVARCHAR(4000)

						
DECLARE @LB NUMERIC(19,4) = 
(
			SELECT		ISNULL(SUM(ROUND((CAST(ROUND(Deductions-COALESCE(R.bkg,0.00),2) AS NUMERIC(19, 4)) +  CAST(ROUND(EPI ,2) AS NUMERIC(19, 4)))* (pd.ded_pcnt/100),3)),0)
			FROM		FinanceLanding.Eb.Epi_View_Bbr2 EP
			JOIN		FinanceLanding.Eb.Policy_Cube PC
			ON			EP.policyref = PC.policyref
			JOIN		FinanceLanding.[sp].[TrifocusCode] trf 
			ON			EP.trifocus = trf.[TrifocusName]
						AND trf.SourceSystem = 'Eurobase'
			JOIN		FinanceLanding.eb.policy_deductions pd 
			ON			pd.ded_cpd_policy_ref = EP.policyref
			LEFT JOIN FinanceLanding.Eb.epi_reinstatement_bkg2  R	ON EP.policyref = R.pre_cpd_policy_ref
													AND EP.synd = R.spl_syn_user_number
			WHERE		(Epi + (Deductions-COALESCE(R.bkg,0.00)))> 0
			)

DECLARE @AC NUMERIC(19,4) = 
(
		SELECT		ISNULL(SUM(CASE WHEN  pd.ded_cpd_policy_ref IS NOT NULL AND (Epi + (Deductions-COALESCE(R.bkg,0.00))) > 0 
							THEN ROUND(CAST(ROUND(Deductions-COALESCE(R.bkg,0.00),2) AS NUMERIC(19, 4)) - ((CAST(ROUND(Deductions-COALESCE(R.bkg,0.00),2) AS NUMERIC(19, 4)) + 
																			CAST(ROUND(EPI ,2) AS NUMERIC(19, 4))) * (pd.ded_pcnt/100)),3) 
						ELSE CAST(ROUND(Deductions-COALESCE(R.bkg,0.00),2) AS NUMERIC(19, 4))
						END),0) AS [Value]
		FROM		FinanceLanding.Eb.Epi_View_Bbr2 EP
		JOIN		FinanceLanding.Eb.Policy_Cube PC
		ON			EP.policyref = PC.policyref
		JOIN		FinanceLanding.[sp].[TrifocusCode] trf 
		ON			EP.trifocus = trf.[TrifocusName]
					AND trf.SourceSystem = 'Eurobase'
		LEFT OUTER JOIN		FinanceLanding.eb.policy_deductions pd 
		ON			pd.ded_cpd_policy_ref = EP.policyref
		LEFT JOIN FinanceLanding.Eb.epi_reinstatement_bkg2  R	ON EP.policyref = R.pre_cpd_policy_ref
													AND EP.synd = R.spl_syn_user_number
		WHERE		(Deductions-COALESCE(R.bkg,0.00))> 0
)
					SELECT @ActivityMessage_AC = @AC + @LB

/*
		=========================================================================================================
						Log eurobase total value in Landing for testing inbound datacontract value
		=========================================================================================================
*/

     EXEC [dbo].[usp_LogLanding] 
          @v_ActivityMessage = @ActivityMessage_AC, 
          @v_ActivityStatus = @ActivityStatus_AC, 
          @v_ActivityName = @ActivityName_AC,
		  @V_JobId = @Jobid;