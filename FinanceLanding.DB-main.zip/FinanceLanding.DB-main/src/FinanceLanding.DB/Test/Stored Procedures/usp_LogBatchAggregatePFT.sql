﻿CREATE PROC [Test].[usp_LogBatchAggregatePFT] @Jobid INT
AS
/*
        =========================================================================================================
						Set logging parameters for inbound value test
		=========================================================================================================
*/

     DECLARE		 @ActivitySource SMALLINT=1, --1 --IFRS17--2--DatatContracct
					 @ActivityStatus SMALLINT=5, --1 started 2 succeded 3 stopped 4 errored 5 information 
					 @ActivityName VARCHAR(50)='PFTLanding.test.usp_LogBatchAggregatePFT',
					 @ActivityMessage NVARCHAR(4000)


	SELECT @ActivityMessage = SUM(ISNULL(GGP,0))+SUM(ISNULL(GGP,0)-ISNULL(SyndPremiumGIC,0)) 
	FROM [pft].[PFT_SYND_WITH_CEDE]
	--WHERE RIGHT(ReviewCycle,1)*3+3 = PremiumMonth
	--AND RIGHT(ReviewCycle,1) IN (0,1,2,3)


	/*
		=========================================================================================================
						Log eurobase total value in Landing for testing inbound datacontract value
		=========================================================================================================
*/

     EXEC [dbo].[usp_LogLanding] 
          @v_ActivityMessage = @ActivityMessage, 
          @v_ActivityStatus = @ActivityStatus, 
          @v_ActivityName = @ActivityName,
		  @V_JobId = @Jobid;