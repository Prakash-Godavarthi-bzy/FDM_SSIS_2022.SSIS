﻿CREATE PROC [test].[usp_LogBatchAggregateAggregateEB_Baseload] @Jobid INT
AS

/*
        =========================================================================================================
                                         Set logging parameters for inbound value test Gross
       =========================================================================================================
*/

     DECLARE         @ActivitySource SMALLINT=1, --1 --IFRS17--2--DatatContracct
                                  @ActivityStatus SMALLINT=5, --1 started 2 succeded 3 stopped 4 errored 5 information 
                                   @ActivityName VARCHAR(50)='EbLanding.test.usp_LogBatchAggregate_Gross',
                                  @ActivityMessage NVARCHAR(4000)


       SELECT	@ActivityMessage=SUM(Premium + Deductions) 
		FROM	FinanceLanding.EB.StageEPIBaseLoad
		WHERE	MOP IS NOT NULL




	
/*
       =========================================================================================================
                                         Log eurobase total value in Landing for testing inbound datacontract value Gross
       =========================================================================================================
*/

     EXEC [dbo].[usp_LogLanding] 
          @v_ActivityMessage = @ActivityMessage, 
          @v_ActivityStatus = @ActivityStatus, 
          @v_ActivityName = @ActivityName,
                @V_JobId = @Jobid;

/*
        ========================================================================================================
                                         Set logging parameters for inbound value test Acqutions Costs
       =========================================================================================================
*/


DECLARE						@ActivitySource_AC SMALLINT=1, --1 --IFRS17--2--DatatContracct
							@ActivityStatus_AC SMALLINT=5, --1 started 2 succeded 3 stopped 4 errored 5 information 
							@ActivityName_AC VARCHAR(100)='EbLanding.test.usp_LogBatchAggregate_AcquitionsCos',
							@ActivityMessage_AC NVARCHAR(4000)
						
DECLARE @LB NUMERIC(19,4) = 
(
		SELECT	SUM(ROUND(((Premium+ Deductions) * (PD.ded_pcnt/100)),03))
		FROM	FinanceLanding.EB.StageEPIBaseLoad BL
		JOIN	FinanceLanding.Eb.policy_deductions PD
		ON		BL.policyref = PD.ded_cpd_policy_ref
		WHERE	(Premium+Deductions) > 0  AND PD.ded_qual = 'x'
				AND MOP IS  NOT NULL 
)

DECLARE @AC NUMERIC(19,4) = 
(
		SELECT	SUM(CASE
					WHEN PD.ded_cpd_policy_ref IS NOT NULL AND (Premium + Deductions) > 0 AND PD.ded_qual = 'x'	THEN ROUND(Deductions-((Premium + Deductions) * (PD.ded_pcnt/100)),03)
					ELSE	ROUND(Deductions,3)
				END )
		FROM	FinanceLanding.EB.StageEPIBaseLoad BL
		LEFT OUTER JOIN	FinanceLanding.Eb.policy_deductions PD
		ON		BL.policyref = PD.ded_cpd_policy_ref
		WHERE	 MOP IS  NOT NULL 
)
					SELECT @ActivityMessage_AC = @AC + @LB
	
/*
       =========================================================================================================
                                         Log eurobase total value in Landing for testing inbound datacontract value Acqutions Costs
       =========================================================================================================
*/
					EXEC [dbo].[usp_LogLanding] 
					@v_ActivityMessage = @ActivityMessage_AC, 
					@v_ActivityStatus = @ActivityStatus_AC, 
					@v_ActivityName = @ActivityName_AC,
					@V_JobId = @Jobid;