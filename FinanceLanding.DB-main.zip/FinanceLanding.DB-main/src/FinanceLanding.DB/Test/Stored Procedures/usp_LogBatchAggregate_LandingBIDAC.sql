﻿CREATE PROC [Test].[usp_LogBatchAggregate_LandingBIDAC] @Jobid INT
AS
BEGIN
/*
        =========================================================================================================
                        Set logging parameters for inbound value test
        =========================================================================================================
*/

 

     DECLARE         @ActivitySource SMALLINT=1, --1 --IFRS17--2--DatatContracct
                     @ActivityStatus SMALLINT=5, --1 started 2 succeded 3 stopped 4 errored 5 information 
                     @ActivityName VARCHAR(50)='Landing.test.usp_LogBatchAggregate_BIDAC',
                     @ActivityMessage NVARCHAR(4000)

 

    SELECT    @ActivityMessage=ISNULL(SUM(ISNULL(
            CASE    WHEN       CAST([Account] AS NVARCHAR)=10100 THEN [CurAmount]/(-1) 
                    WHEN       CAST([Account] AS NVARCHAR)=30100 THEN [CurAmount]/1
                    ELSE       [CurAmount]
            END,0)),0)                
    FROM [FinanceLanding].[BIDAC].[BIDStageLanding]
    

 

    /*
        =========================================================================================================
                        Log FDM total value in Landing for testing inbound datacontract value
        =========================================================================================================
*/

  EXEC [dbo].[usp_LogLanding] 
          @v_ActivityMessage = @ActivityMessage, 
          @v_ActivityStatus = @ActivityStatus, 
          @v_ActivityName = @ActivityName,
          @V_JobId = @Jobid;

END;
