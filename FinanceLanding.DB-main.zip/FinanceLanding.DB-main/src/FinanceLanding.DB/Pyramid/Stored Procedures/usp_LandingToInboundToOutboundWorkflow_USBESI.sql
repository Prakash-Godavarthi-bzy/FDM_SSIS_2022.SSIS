﻿
CREATE PROCEDURE [Pyramid].[usp_LandingToInboundToOutboundWorkflow_USBESI] 
             @p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL

AS
-- =====================================================================================================================================================================================
-- Details:
--Version				DateOfModification		UpdatedBY									Description
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- 1.0					26-02-2024				Entha.Bhargav@beazley.com			https://beazley.atlassian.net/browse/I1B-5080 [EBG][Q1] BESI Written Premium & Brokerage --Intital Version 


-- ======================================================================================================================================================================================

BEGIN

	SET NOCOUNT ON;
	
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'USBESI';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	DECLARE @v_DataSet						VARCHAR(255)	= @v_ActivityDatabase

	DECLARE @v_AccountingPeriod                   INT       = NULL;
	DECLARE @v_AccountingPeriod_Default           INT       = 201812; -- this is our starting date

BEGIN TRY  

	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';



	/* Log the start of the process */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										   FROM Orchestram.Log.ActivityType	
										   WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL THEN 'Manual process' 
																ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'Load data into Inbound.Transaction and Outbound.Transaction using [Pyramid].[usp_LandingToInboundToOutboundWorkflow_USBESI]'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= ''
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

	

	SELECT @v_AccountingPeriod = ISNULL(CONVERT(INT,CONVERT(CHAR(6),CONVERT(DATE,MAX(dateoffact)),112)),@v_AccountingPeriod_Default)
	FROM [FinanceDataContract].[Outbound].[Transaction]
	WHERE Dataset = @v_DataSet

	--SELECT @v_AccountingPeriod=201903
	
	DECLARE @Dates TABLE(Asat INT, i INT IDENTITY(1,1))
	INSERT INTO @Dates(Asat)
	
	SELECT DISTINCT left(convert(varchar, dateadd(month, -1, ProcessingPeriod), 112), 6) as Accountingperiod
		--,ProcessingPeriod
	FROM FinanceLanding.[Pyramid].[Landing_TriangleFactData]
	WHERE 
			ISDATE(ProcessingPeriod)=1
			AND LEFT(convert(varchar, dateadd(month, -1, ProcessingPeriod), 112), 6)>= @v_AccountingPeriod
		--left(convert(varchar, dateadd(month, -1, ProcessingPeriod), 112), 6)='202406'
	ORDER BY 1 ASC

	DECLARE @i int = 1

	WHILE EXISTS(SELECT 1 FROM @Dates WHERE i=@i)
	BEGIN

		SET @v_AccountingPeriod = (SELECT Asat FROM @Dates WHERE i=@i)

		SELECT [@v_AccountingPeriod] = @v_AccountingPeriod 

		EXEC [Pyramid].[usp_LandingInboundWorkflow_USBESI]
						@p_AccountingPeriod	= @v_AccountingPeriod  

		PRINT '[Pyramid].[usp_LandingToInboundToOutboundWorkflow_USBESI]'
		IF EXISTS(SELECT 1 FROM [FinanceDataContract].Inbound.[Transaction] WHERE DataSet = @v_DataSet)
		BEGIN
			--SELECT 'exists'
			--EXEC [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_ReInsuranceExtensions]
			--exec [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow] @DoNonIFRS17_Tests = 0   -- Reversal Record DOF for this are not as expected

			EXEC [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_GAAP] @DoNonIFRS17_Tests = 1
		END
		
		SET @i += 1

		-- debug code to do a limited number
		--if @i>1 set @i=1000000
	END


	-- LOG THE RESULT WITH SUCCESS
	SELECT @v_ActivityDateTime			= GETUTCDATE();

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
			 @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStop
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;


END TRY

BEGIN CATCH
			        
			-- LOG THE RESULT WITH ERROR

			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

		    THROW;

END CATCH;

					
END