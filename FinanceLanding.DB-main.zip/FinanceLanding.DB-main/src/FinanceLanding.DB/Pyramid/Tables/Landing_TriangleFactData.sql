﻿CREATE TABLE [Pyramid].[Landing_TriangleFactData](
	[PK_ID] [bigint] IDENTITY(1,1) NOT NULL,
	[FK_Run] INT NOT NULL,
	[ProcessingPeriod] [datetime] NOT NULL,
	[TriFocusname] [varchar](100) NULL,
	[TrifocusCode] [varchar](50) NULL,
	[Entity] [varchar](25) NOT NULL,
	[YOAName] [varchar](5) NOT NULL,
	[SettlementCurrency] [varchar](3) NULL,
	[DataSetType]  [Varchar] (50) NULL,
	[DataSetSubType] [Varchar] (100) NULL,
	[PolicyReference] [Varchar] (20) NOT NULL,
	[InceptionDate] [datetime] NOT NULL,
	[ExpiryDate] [datetime] NOT NULL,

	[Value] [numeric](38, 4) NULL,
	[Value_GBPPIM] [numeric](38, 4) NULL,
	[Value_GBPSPOT] [numeric](38, 4) NULL,
	[Value_USDPIM] [numeric](38, 4) NULL,
	[Value_USDSPOT] [numeric](38, 4) NULL,

	[AuditSSISExecutionID] [varchar](255) NULL,
	[AuditSSISPackageName] [varchar](255) NULL,
	[AuditSource] [varchar](255) NULL,
	[AuditGenerateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL,
	[AuditHost] [nvarchar](255) NOT NULL,
	
	
) ON [PRIMARY]

GO

ALTER TABLE [Pyramid].[Landing_TriangleFactData] ADD  CONSTRAINT [DF_Landing_TriangleFactData_AuditGenerateDateTime]  DEFAULT (getdate()) FOR [AuditGenerateDateTime]

GO
ALTER TABLE [Pyramid].[Landing_TriangleFactData] ADD  CONSTRAINT [DF_Landing_TriangleFactData_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]

GO
ALTER TABLE [Pyramid].[Landing_TriangleFactData] ADD  CONSTRAINT [DF_Landing_TriangleFactData_AuditHost]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]

GO
EXEC sys.sp_addextendedproperty 
@name=N'description', 
@value=N'The table is maintained by USBESI procedures. You need to view the procedures to see how this is done. View dependancies in the object explorer to see the names of the procedures.' , 
@level0type=N'SCHEMA',
@level0name=N'Pyramid', 
@level1type=N'TABLE',
@level1name=N'Landing_TrianglefactData'
GO
