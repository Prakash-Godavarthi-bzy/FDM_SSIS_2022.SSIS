﻿CREATE PROCEDURE [BIDAC].[usp_LandingInboundWorkflow]
AS
BEGIN

-- =============================================

-- created by:			entha.bhargav@beazley.com
-- Do:				Perform Aggregates and Transformations to the fields and move all the landing BIDAC Data into Inbound.Transaction table


-- Modified by:			entha.bhargav@beazley.com
-- Modification date:	2021-29-12
-- Changes:				Added rules to avoid Multiple Inception,Expiry dates for single policy. Rules applied from BI ODS Instance. Done changes part of JIRA
--https://beazley.atlassian.net/browse/I1B-1926
--https://beazley.atlassian.net/browse/I1B-1703


-- Modified by:			Nikil.Nallamothu@beazley.com
-- Modification date:	2022-13-07
-- Changes:				Performed joins inorder to extract the claims and mopcode columns from source tables and loaded into extensions tables. Done changes part of JIRA
--https://beazley.atlassian.net/browse/I1B-1863(RAD Policies)

-- Modified by:			Nikil.Nallamothu@beazley.com
-- Modification date:	2022-04-08
-- Changes:				Applied the BI Rules inorder to replace the Null values for ClaimBasis,MopCode,PolicyNumber and Cobcode fields by using Fallback scenario.Done changes part of JIRA
						--https://beazley.atlassian.net/browse/I1B-3172 

-- =============================================	
	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_AffectedRows					INT;
	DECLARE @v_DataSet varchar(255)='BIDAC';
	DECLARE @ContractType					CHAR(3)			= 'BID';
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;

	INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
	SELECT 1, '[bidac].[usp_LandingInboundWorkflow]', 'BIDAC  Started';

	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
		SELECT @@TRANCOUNT;
		/*
=============================================================================================
       Create BatchID In landing
==============================================================================================
*/		DECLARE @v_BatchId_Extensions INT;
		DECLARE @Basis char(1)	= '-';
		DECLARE @Location char(1) = '-';

		DECLARE @BatchId INT;
		SELECT	@BatchId	= MAX([PK_Batch])
		FROM	dbo.[Batch]
		WHERE	[DataSet] = @v_DataSet;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, '[bidac].[usp_LandingInboundWorkflow]', 'Batch Created';

		
		Declare @AsAt varchar(10)
		Select @AsAt =Asat from FinanceDataContract.Inbound.BatchQueue where Pk_Batch=@BatchId;

		DROP TABLE IF EXISTS #Temp_BIDACLand;

		SELECT	Scenario				=CASE WHEN CAST([SCENARIO] AS NVARCHAR) = 'Actual' THEN 'A' ELSE CAST([SCENARIO] AS NVARCHAR)END
					,Account			= CASE WHEN CAST([Account] AS NVARCHAR) = 10100 THEN 'P-GP-P'
													WHEN CAST([Account] AS NVARCHAR) = 30100 THEN 'P-AC-P'													
													ELSE CAST([Account] AS NVARCHAR)
												END
					,DataSet				= @v_DataSet
					--,DateOfFact				= CAST(case when convert(varchar(6), t.Inception, 112) < cast(AccountingPeriod as varchar) 
					--									then eomonth(convert(date, cast(AccountingPeriod as varchar) + '01'))
					--									else t.Inception
					--								END AS DATETIME2
					--								)
					
					,[BusinessKey]			= CAST(t.[Policyref] AS NVARCHAR)
												
					,PolicyNumber			= CAST(t.[Policyref] AS NVARCHAR)
												
					,InceptionDate			= CAST(isnull(s.InceptionDate,
															isnull(p.InceptionDate,
																	isnull(psub.InceptionDate,
																		isnull(pwwb.InceptionDate,
																			isnull(pwwv.InceptionDate,
																				isnull(pwwq.InceptionDate,
																					isnull(pwwz.InceptionDate,
																						isnull(pwwg.InceptionDate,isnull(bl.inception,t.inception))))))))
														) AS DATETIME2)
					,ExpiryDate				= CAST(isnull(s.ExpiryDate,
																		isnull(p.ExpiryDate, 
																		isnull(psub.ExpiryDate,
																		isnull(pwwb.ExpiryDate,
																		isnull(pwwv.ExpiryDate,
																		isnull(pwwq.ExpiryDate,
																		isnull(pwwz.ExpiryDate,
																		isnull(pwwg.ExpiryDate,isnull(bl.expiry,t.expiry))))))))
															) AS DATETIME2)
												
					--,InceptionDate= CAST(T.inception AS DATETIME2)
					--,ExpiryDate= CAST (T.expiry AS datetime2)							
					,BindDate				= CAST('01/01/1980' AS DATETIME2)
					,DueDate				= CAST('01/01/1980' AS DATETIME2)
					,TrifocusCode			= CAST([TrifocusCode] AS NVARCHAR)
					,Entity					= CAST([EntityCode] AS NVARCHAR)
					,YOA					= CAST( LTRIM(RTRIM(isnull(pwwz.YOA, isnull(pwwg.yoa,isnull(bl.yoa,t.[YOA]))))) AS NVARCHAR)
					,TypeofBusiness			= 'N'
					,SettlementCCY			= CAST([SettlementCCY] AS NVARCHAR)
					,OriginalCCY			= CAST([SettlementCCY] AS NVARCHAR)
					,ISTODate				= 'Y'
					,Value					=[CurAmount] * CASE WHEN CAST([Account] AS NVARCHAR) IN (10100) THEN -1 ELSE 1 END
					,fk_Allocation			= 1
					,AuditSourceBatchID		= @BatchId
					--,[AuditGenerateDateTime] =CAST(GETDATE() AS DATETIME2)
					--,AuditHost				= HOST_NAME()
					--,cpd_claim_basis	=	ISNULL(pol.Claim_Basis,'Unknown') 
					--,pol_mop_code	    =	ISNULL(pol.pol_mop_code,'Unknown')
					,cpd_claim_basis	=	coalesce(pol.ClaimBasis,s.ClaimBasis,p.ClaimBasis,pp.ClaimBasis,psub.ClaimBasis,pwwb.ClaimBasis,pwwv.ClaimBasis,pwwq.ClaimBasis,pwwz.ClaimBasis,pwwg.ClaimBasis,'Unknown')
					,pol_mop_code	    =	coalesce(pol.pol_mop_code,s.MopCode,p.MopCode,pp.MopCode,psub.MopCode,pwwb.MopCode,pwwv.MopCode,pwwq.MopCode,pwwz.MopCode,pwwg.MopCode,T.MopCode,'Unknown')
					,CobCode			=   coalesce(pol.CmcCobCode,s.CobCode,p.CobCode,pp.CobCode,psub.CobCode,pwwb.CobCode,pwwv.CobCode,pwwq.CobCode,pwwz.CobCode,pwwg.CobCode,'Unknown')
					--,tra_policy_ref	    =	ISNULL(tra.tra_policy_ref,'Unknown')
					,tra_policy_ref	    = coalesce(cpd_policy_reference,s.[SectionReference],p.PolicyReference,pp.PolicyReference,psub.PolicyReference,pwwb.PolicyReference,pwwv.PolicyReference,pwwq.PolicyReference,pwwz.PolicyReference,pwwg.PolicyReference,'Unknown') 

			INTO #Temp_BIDACLand

			FROM      FinanceLanding.[BIDAC].[BIDStageLanding] T 
			LEFT JOIN FinanceLanding.[MDS].[ODSSection]  s 
					on (s.[SectionReference] = t.policyref)
			LEFT JOIN FinanceLanding.[MDS].[ODSPolicy] p 
					on (p.PolicyReference = t.policyref)
			LEFT JOIN FinanceLanding.[MDS].[ODSPolicy] pp	
					on (pp.PolicyReference = substring(t.policyref, 1, 8)) 
			LEFT JOIN FinanceLanding.[MDS].[ODSPolicy] psub 
					on (psub.PolicyReference = substring(t.policyref, 1, case when charindex('', t.policyref ) > 1 then charindex('', t.policyref )-1 else len(t.policyref) end))
			LEFT JOIN FinanceLanding.[MDS].[ODSPolicy] pwwb 
					on (replace(pwwb.PolicyReference, 'WB 0', 'WWB') = t.policyref)
			LEFT JOIN FinanceLanding.[MDS].[ODSPolicy] pwwv 
					on (replace(pwwv.PolicyReference, 'WV 0', 'WWV') = t.policyref)
			LEFT JOIN FinanceLanding.[MDS].[ODSPolicy] pwwq 
					on (replace(pwwq.PolicyReference, 'WQ 0', 'WWQ') = t.policyref)
			LEFT JOIN FinanceLanding.[MDS].[ODSPolicy]pwwz 
					on (replace(pwwz.PolicyReference, 'WZ 0', 'WWZ') = t.policyref)
			LEFT JOIN FinanceLanding.[MDS].[ODSPolicy] pwwg 
					on (replace(pwwg.PolicyReference, 'WG 0', 'WWG') = t.policyref)
			LEFT JOIN (SELECT policyref,MIN(inception) Inception,MAX(expiry) Expiry,min(yoa) yoa
						FROM FinanceLanding.[BIDAC].[BIDStageLanding]  
						GROUP BY policyref) bl 
					ON BL.policyref=T.PolicyRef
			LEFT JOIN	(SELECT DISTINCT
                                pol_cpd_policy_reference,cpd_policy_reference,pol_mop_code,pol_syn_user_number
                                ,CASE WHEN cpd_claim_basis='' THEN CmcLossBasis
                                        ELSE cpd_claim_basis
                                 END AS ClaimBasis
                                ,cpd_claim_basis,CmcCobCode,CmcLossBasis
                                FROM FinanceLanding.Eurobase.policy_details_01 a
                                LEFT JOIN FinanceLanding.Eurobase.common_policy_details_01 b
                                ON b.cpd_policy_reference=a.pol_cpd_policy_reference
                                LEFT JOIN   FinanceLanding.eb.CobMopCombination c
                                ON c.CmcCobCode=a.pol_cob_code
                                AND c.CmcMopCode=a.pol_mop_code)pol 
						ON T.Policyref=pol.pol_cpd_policy_reference
			--LEFT JOIN	 FinanceLanding.Eurobase.transaction_01 tra
			--		    ON T.Policyref=tra.tra_policy_ref;



				SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, '[bidac].[usp_LandingInboundWorkflow]', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into TempBIDACLand table';
		/*
=========================================================================================================
Insert from Landing to Inbound.Transaction Table 
=========================================================================================================
*/
	DROP TABLE IF EXISTS #Inbound_BIDAC;
	WITH LANDING AS (
		SELECT	Scenario
				,Account
				,DataSet
				--,DateOfFact
				,BusinessKey =	isnull(cast(Account as varchar), '-') + '|' +
								isnull(PolicyNumber, '-') + '|' +
								isnull(YOA, '-') + '|' +
								isnull(Entity, '-') + '|' +
								isnull(OriginalCCY, '-') + '|' +
								isnull(TrifocusCode, '-')  
				,PolicyNumber
				,InceptionDate
				,ExpiryDate
				,BindDate
				,DueDate
				,TrifocusCode
				,Entity
				,YOA
				,TypeofBusiness
				,SettlementCCY
				,OriginalCCY
				,ISTODate
				,sum([Value]) as [value]
				,fk_Allocation
				,AuditSourceBatchID
				,[AuditGenerateDateTime] =CAST(GETDATE() AS DATETIME2)
				,AuditHost				= HOST_NAME()
				,cpd_claim_basis
				,pol_mop_code	 
				,tra_policy_ref	 
				,CobCode
				--into #BIDACCTE
		FROM #Temp_BIDACLand
		--WHERE PolicyNumber IN ('C1B6D6200501-01')
		GROUP BY Scenario
				,Account
				,DataSet
				--,DateOfFact
				,BusinessKey
				,PolicyNumber
				,InceptionDate
				,ExpiryDate
				,BindDate
				,DueDate
				,TrifocusCode
				,Entity
				,YOA
				,TypeofBusiness
				,SettlementCCY
				,OriginalCCY
				,ISTODate,fk_Allocation
				,AuditSourceBatchID
				--,CAST(GETDATE() AS DATETIME2)
				--,HOST_NAME()
				,cpd_claim_basis
				,pol_mop_code	 
				,tra_policy_ref	
				,CobCode
		)

		SELECT	DISTINCT Landing.Scenario
				,Landing.Account
				,Landing.DataSet
				--,Landing.DateOfFact
				,DateOfFact =CAST(@AsAt+'01' as date)
				--,DateOfFact				= CAST(case when convert(varchar(6), B.Inception, 112) < cast(B.AccountingPeriod as varchar) 
				--										then eomonth(convert(date, cast(B.AccountingPeriod as varchar) + '01'))
				--										else B.Inception
				--									END 
				--									AS DATETIME2
				--						)
				,Landing.BusinessKey
				,Landing.PolicyNumber
				,Landing.InceptionDate
				,Landing.ExpiryDate
				,Landing.BindDate
				,Landing.DueDate
				,Landing.TrifocusCode
				,Landing.Entity
				,Landing.YOA
				,Landing.TypeofBusiness
				,Landing.SettlementCCY
				,Landing.OriginalCCY
				,Landing.ISTODate
				,Landing.[Value]
				,Landing.fk_Allocation
				,Landing.AuditSourceBatchID
				,Landing.AuditGenerateDateTime
				,Landing.AuditHost
				,Landing.cpd_claim_basis
				,Landing.pol_mop_code	 
				,Landing.tra_policy_ref	 
				,Landing.CobCode
				,RowHash = dbo.fn_RowHashForTransactions
						(
						'T'							-- <@RowHashType, char(1),>
						,Scenario					--,<@Scenario, nvarchar(2000),>
						,[Account]					--,<@Account, nvarchar(2000),>
						,@v_DataSet					--,<@DataSet, nvarchar(2000),>
						,[BusinessKey]				--,<@BusinessKey, nvarchar(2000),>
						,[PolicyNumber]				--,<@PolicyNumber, nvarchar(2000),>
						,[InceptionDate]			--,<@InceptionDate, date,>
						,[ExpiryDate]				--,<@ExpiryDate, date,>
						,BindDate					--,<@BindDate, date,>
						,DueDate					--,<@DueDate, date,>
						,[TrifocusCode]				--,<@TrifocusCode, nvarchar(2000),>
						,[Entity]					--,<@Entity, nvarchar(2000),>
						,[YOA]						--,<@YOA, nvarchar(2000),>
						,TypeOfBusiness				--,<@TypeOfBusiness, nvarchar(2000),>
						,null						--,<@StatsCode, nvarchar(2000),>
						,[SettlementCCY]			--,<@SettlementCCY, nvarchar(2000),>
						,[SettlementCCY]			--,<@OriginalCCY, nvarchar(2000),>
						,IsToDate					--,<@IsToDate, nvarchar(2000),>
						,@Basis						--,<@Basis, nvarchar(2000),>
						,@Location					--,<@Location, nvarchar(2000),>
						,null						--,<@BusinessProcessCode, nvarchar(2000),>
						,null						--,<@BoundDate, date,>
						,CONCAT
						(
							 case when cpd_claim_basis is null	then '' else (cpd_claim_basis + '§~§') end
							,case when pol_mop_code	   is null	then '' else (pol_mop_code + '§~§')	   end
							,case when tra_policy_ref  is null	then '' else (tra_policy_ref + '§~§')  end
							,case when CobCode  is null	then '' else (CobCode + '§~§')  end
						)
					)
														
		INTO #Inbound_BIDAC
		FROM	Landing Landing
		--JOIN (SELECT DISTINCT S.[Policyref] PolicyRef
		--					,Max(S.inception) Inception
		--					,Max(S.AccountingPeriod)  AccountingPeriod 
		--		FROM FinanceLanding.[BIDAC].[BIDStageLanding] S
		--		GROUP BY S.[Policyref] 
												
		--	) B ON Landing.PolicyNumber=B.policyref
		--where PolicyNumber IN ('C1B6D6200501-01')--,'C1B6D6200501-02','C1B6D6200501-03') 
		;

		SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, '[bidac].[usp_LandingInboundWorkflow]', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into InboundBIDAC table';

		DROP TABLE IF EXISTS #Final_Inbound_BIDAC 

						SELECT 
						 t.Scenario									
						,t.Account	
						,t.DataSet				                                
						,t.DateOfFact				
						,t.BusinessKey
						,t.PolicyNumber			
						,t.InceptionDate			
						,t.ExpiryDate				
						,t.BindDate				
						,t.DueDate				
						,t.TrifocusCode	
						,t.Entity				
						,t.YOA					
						,t.TypeOfBusiness
						,t.SettlementCCY			
						,t.OriginalCCY			
						,t.IsToDate				
						,t.[Value]	
						,T.fk_Allocation
						,t.AuditSourceBatchID
					    ,t.AuditGenerateDateTime
					    ,t.AuditHost 
					    ,t.cpd_claim_basis 
					    ,t.pol_mop_code
					    ,t.tra_policy_ref
					    ,t.RowHash
						,t.CobCode
						,[RowHash_Transaction_Premium_Extensions] = dbo.fn_RowHashForTransactions
								(
								'E'							-- <@RowHashType, char(1),>
								,Scenario					--,<@Scenario, nvarchar(2000),>
								,[Account]					--,<@Account, nvarchar(2000),>
								,@v_DataSet					--,<@DataSet, nvarchar(2000),>
								,[BusinessKey]				--,<@BusinessKey, nvarchar(2000),>
								,[PolicyNumber]				--,<@PolicyNumber, nvarchar(2000),>
								,[InceptionDate]			--,<@InceptionDate, date,>
								,[ExpiryDate]				--,<@ExpiryDate, date,>
								,BindDate					--,<@BindDate, date,>
								,DueDate					--,<@DueDate, date,>
								,[TrifocusCode]				--,<@TrifocusCode, nvarchar(2000),>
								,[Entity]					--,<@Entity, nvarchar(2000),>
								,[YOA]						--,<@YOA, nvarchar(2000),>
								,TypeOfBusiness				--,<@TypeOfBusiness, nvarchar(2000),>
								,null						--,<@StatsCode, nvarchar(2000),>
								,[SettlementCCY]			--,<@SettlementCCY, nvarchar(2000),>
								,[SettlementCCY]			--,<@OriginalCCY, nvarchar(2000),>
								,IsToDate					--,<@IsToDate, nvarchar(2000),>
								,@Basis						--,<@Basis, nvarchar(2000),>
								,@Location					--,<@Location, nvarchar(2000),>
								,null						--,<@BusinessProcessCode, nvarchar(2000),>
								,null						--,<@BoundDate, date,>
								,CONCAT
								(
									 case when cpd_claim_basis is null	then '' else (cpd_claim_basis + '§~§') end
									,case when pol_mop_code	   is null	then '' else (pol_mop_code + '§~§')	   end
									,case when tra_policy_ref  is null	then '' else (tra_policy_ref + '§~§')  end
									,case when CobCode  is null	then '' else (CobCode + '§~§')  end
								)
							)
						into 
							#Final_Inbound_BIDAC
						From  
							#Inbound_BIDAC t

		SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, '[bidac].[usp_LandingInboundWorkflow]', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into FinalInboundBIDAC table';


/* Delete the current lines from Inbound ... */

				DELETE 				
				FROM    [FinanceDataContract].[Inbound].[Transaction]					
				WHERE   [DataSet] = @v_DataSet

				DELETE [FinanceDataContract].[Inbound].[Premium_Extensions_Bridge]
				WHERE [ContractType] = @ContractType

				DELETE [FinanceDataContract].[Inbound].[Premium_Extensions]
				WHERE [ContractType] = @ContractType

				INSERT INTO [dbo].[Batch]
					([CreateDate],[DataSet],[LatestBusinesKey]) 
				VALUES  
					(GETDATE(),'PremiumExtensions', NULL);
				
				SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();


				INSERT INTO  [FinanceDataContract].[Inbound].Premium_Extensions_Bridge WITH(TABLOCK)
				(
					[RowHash_Transaction]
					,[RowHash_Transaction_Premium_Extensions]
					,[ContractType]
					,[FK_Batch]
				)
				SELECT DISTINCT
					c.[RowHash]
					,c.[RowHash_Transaction_Premium_Extensions]
					,@ContractType
					,@v_BatchId_Extensions
				FROM 
					#Final_Inbound_BIDAC c

				INSERT INTO  [FinanceDataContract].[Inbound].Premium_Extensions WITH(TABLOCK)
				(
					 [RowHash_Transaction_Premium_Extensions]
					,[PolicyClaimBasis]
					,[PolicyMOPCode]
					,[PolicyCobCode]
					,[PolicyNumber]
					,[ContractType]
					,[FK_Batch]
				)
				SELECT DISTINCT
					[RowHash_Transaction_Premium_Extensions]
					,cpd_claim_basis 
					,pol_mop_code
					,CobCode
					,tra_policy_ref
					,@ContractType
					,@v_BatchId_Extensions
				FROM 
					#Final_Inbound_BIDAC
			
			INSERT	[FinanceDataContract].[Inbound].[Transaction] WITH(TABLOCK)([Scenario], [Account], DataSet, [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate]
																				,[ExpiryDate], [BindDate], [DueDate], [TrifocusCode], [Entity], [YOA], [TypeOfBusiness]
																				,[SettlementCCY], [OriginalCCY], [IsToDate], [Value], [FK_Allocation], [AuditSourceBatchID]
																				,[AuditGenerateDateTime], [AuditHost], RowHash)
			SELECT		Scenario
					   ,Account
					   ,dataset
					   ,DateOfFact
					   ,BusinessKey
					   ,PolicyNumber
					   ,InceptionDate
					   ,ExpiryDate
					   ,BindDate
					   ,DueDate
					   ,trifocusCode
					   ,Entity
					   ,YOA
					   ,TypeofBusiness
					   ,SettlementCCY
					   ,OriginalCCY
					   ,ISTODate
					   ,[Value]
					   ,fk_Allocation
					   ,AuditSourceBatchID
					   ,AuditGenerateDateTime
					   ,AuditHost 
					   ,RowHash
			   FROM #Final_Inbound_BIDAC

			   INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,RunDescription
								,[DataSet]
								,OriginalName
								,AuditSourceBatchID
								)
				VALUES

								( @v_BatchId_Extensions
								 ,'InBound'
								 ,'PremiumExtensions, the additional attributes to extend functionality of the transaction table.'
								 ,'PremiumExtensions'
								 ,NULL
								 ,NULL
								);


		

		SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, '[bidac].[usp_LandingInboundWorkflow]', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into Inbound.Transaction table, Batch: '+cast (@BatchId as varchar);


		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT	5
				,	'[bidac].[usp_LandingInboundWorkflow]'
				,'Insert from Landing to Inbound.Transaction Table ';

/*
=============================================================================================
	LogInbound Aggregate Value
==============================================================================================
*/

		EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_InboundBIDAC] @BatchId;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, '[bidac].[usp_LandingInboundWorkflow]', 'LogInbound Aggregate Value';

			/*
================================================================================================
		Load extensions data from Inbound to Outnound
================================================================================================
*/
			EXEC [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_PremiumExtensions]

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, '[bidac].[usp_LandingInboundWorkflow]', 'Insert from Inbound to Outbound Extensions Tables';

/*
=============================================================================================
       QueueBatchID in DataContract
==============================================================================================
*/

		UPDATE	[FinanceDataContract].[Inbound].[BatchQueue]
		SET		Status = 'InBound'
		WHERE	Status = 'FinanceLanding'
			AND DataSet = 'BIDAC'
			AND Pk_Batch = @BatchId;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, '[bidac].[usp_LandingInboundWorkflow]', ' QueueBatchID in DataContract';

		IF @Trancount = 0 COMMIT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, '[bidac].[usp_LandingInboundWorkflow]', 'BIDAC succeeded for Batch: '+cast (@BatchId as varchar);

		--Generate logging for success
		EXEC log.usp_LogLanding @Input = @Logging;

	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;

		--Generate logging for error (outside tran)
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 4, '[bidac].[usp_LandingInboundWorkflow]', ERROR_MESSAGE();
		EXEC log.usp_LogLanding @Input = @Logging;

		THROW;
	END CATCH;
END;