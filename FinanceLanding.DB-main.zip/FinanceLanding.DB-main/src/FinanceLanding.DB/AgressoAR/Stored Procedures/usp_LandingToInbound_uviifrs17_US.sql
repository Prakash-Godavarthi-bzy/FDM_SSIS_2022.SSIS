﻿CREATE PROCEDURE [AgressoAR].[usp_LandingToInbound_uviifrs17_US]
              @p_AccountingPeriod			INT
			 ,@p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL

AS
 --=============================================

--LastModified by Author: Charvitha Sadhu <charvitha.sadhu@beazley.com>
--Modified date:          05/07/2022
--Description  :	      Changes are Modified for Account field taking the accounts PC-AS-RE and BC-AS-RE to align with EurobaseLPSO accounts and for Business Keyfield to populate from the fields
--		                  GL Account, GLMCTRansNo and GLInvoiceNo. 
--                        Ticket numbers are https://beazley.atlassian.net/browse/I1B-2944 and https://beazley.atlassian.net/browse/I1B-2790
--LastModified by Author: Akshay Vachavai <Akshay.Vachavai@beazley.com>
--Modified date:          10/10/2022
--Description  :	      Changes are modified to populate the data from [AgressoAR].[uviifrs17_BP] table.
--                        Ticket numbers are https://beazley.atlassian.net/browse/I1B-3333


 --=============================================	
BEGIN

		SET NOCOUNT ON;

		DECLARE @Trancount INT= @@Trancount;
		DECLARE @v_ErrorMessage NVARCHAR(4000);

		DECLARE @v_RC							INT;
		DECLARE @v_ActivityLogTag				BIGINT;
		DECLARE @v_ActivitySource				SMALLINT;
		DECLARE @v_ActivityType					SMALLINT;
		DECLARE @v_ActivityStatusStart			SMALLINT;
		DECLARE @v_ActivityStatusStop			SMALLINT;
		DECLARE @v_ActivityStatusFail			SMALLINT;
		DECLARE @v_ActivityHost					VARCHAR(100);
		DECLARE @v_ActivityDatabase				VARCHAR(100);
		DECLARE @v_ActivityName					VARCHAR(100);
		DECLARE @v_ActivityDateTime				DATETIME2(2);
		DECLARE @v_ActivityMessage				NVARCHAR(4000);
		DECLARE @v_ActivityErrorCode			NVARCHAR(50);
		DECLARE @v_ActivityLogIdIn				BIGINT;
		DECLARE @v_ActivityLogIdOut				BIGINT;
		DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId;
		DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
		DECLARE @v_AffectedRows					INT				= 0;
		DECLARE @v_DataSet						VARCHAR(255)	= 'AgressoARUS'
		DECLARE @ContractType					CHAR(3)			= 'ARU'

		-- for debugging. set to 1 & the no records will be written to the inbound tables.
		declare @stop bit = 0


		SELECT @v_ActivityStatusStart = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'STARTED';

		SELECT @v_ActivityStatusStop = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'SUCCEEDED';

		SELECT @v_ActivityStatusFail = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'ERRORED';

		DECLARE @v_BatchId INT;
		DECLARE @v_BatchId_Extensions INT;

		/* Log the start of the insert */

		BEGIN TRY

				SELECT   
					 @v_ActivityLogTag		        = NULL
					,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
					,@v_ActivityType				= (SELECT PK_ActivityType	
														FROM Orchestram.Log.ActivityType	
														WHERE ActivityType = CASE 
																				WHEN @p_ParentActivityLogId IS NULL 
																					THEN 'Manual process' 
																					ELSE 'Automated process' 
																				END)
					,@v_ActivityHost				= @@SERVERNAME
					,@v_ActivityName				= 'Load AgressoAR data into Inbound.Transaction'
					,@v_ActivityDatabase			= 'FinanceLanding'
					,@v_ActivityDateTime			= GETUTCDATE()
					,@v_ActivityMessage				= NULL
					,@v_ActivityErrorCode			= NULL;

				EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
							 @p_ParentActivityLogId
							,@v_ActivityLogTag
							,@v_ActivitySource
							,@v_ActivityType
							,@v_ActivityStatusStart
							,@v_ActivityHost
							,@v_ActivityDatabase
							,@v_ActivityJobId
							,@v_ActivitySSISExecutionId
							,@v_ActivityName
							,@v_ActivityDateTime
							,@v_ActivityMessage
							,@v_ActivityErrorCode
							,@v_AffectedRows
							,@v_ActivityLogIdIn OUTPUT;

				SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;
                --------------------------------------------------------------


				--------------------------------------------------------------
				declare @OpeningBalanceDate date = '31 December 2018' -- this is the date for the opening balance
				declare @OpeningBalanceCutOffYear int = year(@OpeningBalanceDate) + 1 -- this will be 2019


				DROP TABLE IF EXISTS #TempInboundTransaction;

		     SELECT *
			 INTO #TempInboundTransaction
			 FROM
			 (
             SELECT 
					 Scenario            = 'A'                   
					,Basis               = 'B'  
					,Account = 
				    CASE
						WHEN rd.GLAccount IN ('10100','10260')  THEN 'PC-SD-OT'
						WHEN rd.GLAccount IN ('30100','30120')  THEN 'BC-SD-OT'
					END
					,GLAccountDesc       = CAST(ISNULL(rd.GLAccountDesc,'') AS VARCHAR(255))
					,DataSet			 = 'AgressoARUS'
					,DateOfFact          = CAST(CASE WHEN rd.DateOfFact<='2018-12-31' THEN '2018-12-31' ELSE rd.DateOfFact END AS DATETIME)
					,BusinessKey         =  ISNULL(rd.GLAccount,'NOGLAccount')+'|'+
							                ISNULL(CAST(GLMCTransNo as varchar(50)), '-') +'|'+
							                ISNULL(GLInvoiceNo,'-') 
					,GLBusinessKey       =CAST(ISNULL(rd.GLBusinessKey,'') AS VARCHAR(255))
					,PolicyNumber        = CAST(ISNULL(rd.GLPolicyNumber,'NOPOLICY') AS VARCHAR(255))
					,InceptionDate       = CAST(ISNULL(rd.InceptionDate,'01-01-1980') AS DATETIME)
					,ExpiryDate          = CAST(ISNULL(rd.ExpiryDate,'01-01-1980') AS DATETIME)
					,BindDate            = CAST(ISNULL(rd.BindDate,'01-01-1980') AS DATETIME)
					,DueDate             = CAST(ISNULL(rd.DueDate,'01-01-1980') AS DATETIME)
					,TrifocusCode        = CAST(ISNULL(rd.TrifocusCode,'UNKNOWN') AS VARCHAR(25))
					,Entity              = CAST(ISNULL(rd.Entity,'NOENTITY') AS VARCHAR(10))
					,SyndicateSplitPercentage =CAST(1.00 as numeric(3,2) )
					,[Location]          = CAST('NOLOCATION' AS VARCHAR(50))
					,YOA                 = CAST(ISNULL(rd.YOA, 'NOYOA') AS VARCHAR(5))
					,TypeOfBusiness      = '-'
					,GLTransactionType   = CAST(ISNULL(rd.GLTransactionType,'-') AS VARCHAR(2))
					,GLSupplierCust      = CAST(ISNULL(rd.GLSupplierCust,'') AS VARCHAR(255))
					,SettlementCCY       = CAST(rd.SettlementCCY AS VARCHAR(3))
					,OriginalCCY         = CAST(rd.OriginalCCY   AS VARCHAR(3))
					,IsToDate            = 'N'
					,[Value]             = CAST(SUM(ISNULL(rd.SettlementValue,0.0000)) AS DECIMAL (19, 4))
					,[ValueOrig]         = CAST(SUM(ISNULL(rd.OriginalValue,0.0000)) AS DECIMAL (19, 4))
					,RowHash             = NULL
					,[RowHash_Transaction_AgressoAR_Extensions]= NULL
					,BusinessProcessCode = 'T1'
					,AuditSourceBatchID  = CAST('-' AS VARCHAR (255))                                                 
					,AuditHost           = CAST(SERVERPROPERTY('MachineName') AS [VARCHAR](255))
					,[StatsCode]         = CAST('-' AS VARCHAR(25))
					,[FK_Batch]          = NULL

			FROM       [AgressoAR].[uviifrs17_US] rd 
			WHERE  CASE WHEN (year(DateOfFact) * 100 + month(DateOfFact))<=201812 
						THEN 201812 
						ELSE (year(DateOfFact) * 100 + month(DateOfFact))
					END =@p_AccountingPeriod 

			AND   rd.entity in ('USBICI','USSYND','USBAIC','623','2623') 
			AND   rd.GLAccount IS NOT NULL
			AND   rd.GLAccount in ('10100','10260','30100','30120')

			GROUP BY rd.GlAccount, rd.DateOfFact, rd.YOA, rd.GLInvoiceNo, rd.GLMCTransNo, rd.Entity, rd.TrifocusCode, rd.GLPolicyNumber, rd.InceptionDate,
			         rd.SettlementCCY, rd.OriginalCCY, rd.ExpiryDate, rd.BindDate, rd.DueDate, rd.GLAccount, GLSupplierCust,GLBusinessKey, rd.GLTransactionType,rd.GLAccountDesc
	 			
	UNION ALL

			SELECT 
					 Scenario            = 'A'                   
					,Basis               = 'B'  
					,Account = 
				    CASE
						WHEN rd.GLAccount IN ('10100','10260')  THEN 'PC-SD-OT'
						WHEN rd.GLAccount IN ('30100','30120')  THEN 'BC-SD-OT'
					END
					,GLAccountDesc       = CAST(ISNULL(rd.GLAccountDesc,'') AS VARCHAR(255))
					,DataSet			 = 'AgressoARUS'
					,DateOfFact          = rd.DateOfFact
					,BusinessKey         =  ISNULL(rd.GLAccount,'NOGLAccount')+'|'+
							                ISNULL(CAST(GLMCTransNo as varchar(50)), '-') +'|'+
							                ISNULL(GLInvoiceNo,'-') 
					,GLBusinessKey       =CAST(ISNULL(rd.GLBusinessKey,'') AS VARCHAR(255))
					,PolicyNumber        = CAST(ISNULL(rd.GLPolicyNumber,'NOPOLICY') AS VARCHAR(255))
					,InceptionDate       = CAST(ISNULL(rd.InceptionDate,'01-01-1980') AS DATETIME)
					,ExpiryDate          = CAST(ISNULL(rd.ExpiryDate,'01-01-1980') AS DATETIME)
					,BindDate            = CAST(ISNULL(rd.BindDate,'01-01-1980') AS DATETIME)
					,DueDate             = CAST(ISNULL(rd.DueDate,'01-01-1980') AS DATETIME)
					,TrifocusCode        = CAST(ISNULL(rd.TrifocusCode,'UNKNOWN') AS VARCHAR(25))
					,Entity              = CAST(ISNULL(rd.Entity,'NOENTITY') AS VARCHAR(10))
					,SyndicateSplitPercentage =CAST(1.00 as numeric(3,2) )
					,[Location]          = CAST('NOLOCATION' AS VARCHAR(50))
					,YOA                 = CAST(ISNULL(rd.YOA, 'NOYOA') AS VARCHAR(5))
					,TypeOfBusiness      = '-'
					,GLTransactionType   = CAST(ISNULL(rd.GLTransactionType,'-') AS VARCHAR(2))
					,GLSupplierCust      = CAST(ISNULL(rd.GLSupplierCust,'') AS VARCHAR(255))
					,SettlementCCY       = CAST(rd.SettlementCCY AS VARCHAR(3))
					,OriginalCCY         = CAST(rd.OriginalCCY   AS VARCHAR(3))
					,IsToDate            = 'N'
					,[Value]             = CAST(SUM(ISNULL(rd.SettlementValue,0.0000)) AS DECIMAL (19, 4))
					,[ValueOrig]         = CAST(SUM(ISNULL(rd.OriginalValue,0.0000)) AS DECIMAL (19, 4))
					,RowHash             = NULL
					,[RowHash_Transaction_AgressoAR_Extensions]= NULL
					,BusinessProcessCode = 'T1'
					,AuditSourceBatchID  = CAST('-' AS VARCHAR (255))                                                 
					,AuditHost           = CAST(SERVERPROPERTY('MachineName') AS [VARCHAR](255))
					,[StatsCode]         = CAST('-' AS VARCHAR(25))
					,[FK_Batch]          = NULL

			FROM       [AgressoAR].[uviifrs17_BP] rd 
			WHERE  @p_AccountingPeriod <=201812
            AND   rd.entity in ('USBICI','USSYND','USBAIC','623','2623') 
			AND   rd.GLAccount IS NOT NULL
			AND   rd.GLAccount in ('10100','10260','30100','30120')

			GROUP BY rd.GlAccount, rd.DateOfFact, rd.YOA, rd.GLInvoiceNo, rd.GLMCTransNo, rd.Entity, rd.TrifocusCode, rd.GLPolicyNumber, rd.InceptionDate,
			         rd.SettlementCCY, rd.OriginalCCY, rd.ExpiryDate, rd.BindDate, rd.DueDate, rd.GLAccount, GLSupplierCust,GLBusinessKey, rd.GLTransactionType,rd.GLAccountDesc
	 	)t	
				-------------------------------------------------------------------
				              ------/*SyndSplitByYOA*/------
				-------------------------------------------------------------------

				IF object_id('tempdb..#TempInboundTransactionSplit') is not null drop table #TempInboundTransactionSplit



				SELECT 
						 t.Scenario				
						,t.Basis					
						,t.Account
						,t.GLAccountDesc
						,t.DataSet				                                
						,t.DateOfFact				
						,t.BusinessKey
						,t.GLBusinessKey
						,t.PolicyNumber			
						,t.InceptionDate			
						,t.ExpiryDate				
						,t.BindDate				
						,t.DueDate				
						,t.TrifocusCode			
						,s.SyndSplitEntity as Entity
						,SyndicateSplitPercentage= s.SyndSplitPercentage
						,t.[Location]				
						,t.YOA					
						,t.TypeOfBusiness
						,t.GLTransactionType
						,t.GLSupplierCust
						,t.SettlementCCY			
						,t.OriginalCCY			
						,t.IsToDate				
						,t.[Value] *s.SyndSplitPercentage as [Value]
						, t.ValueOrig *s.SyndSplitPercentage as [ValueOrig]
						,t.BusinessProcessCode								
						-- fortify with isnull so we don't have to worry if the column changes for whatever reason. 
						,RowHash
						,t.[RowHash_Transaction_AgressoAR_Extensions]
						,t.StatsCode  

						INTO  #TempInboundTransactionSplit 
						From  #TempInboundTransaction  t
						Left Join fdm.SyndicateSplitsbyYOA s on t.YOA=S.SyndSplitYOA and t.Entity=s.SyndSplitSource
						Where Entity IN ('USSYND')

						----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

						IF object_id('tempdb..#transactions_UnionSplit') is not null drop table #transactions_UnionSplit --tempdb..#transactions_final_agg_cs
						SELECT 
						 *
						into #transactions_UnionSplit From  (
						SELECT 
						 t.Scenario				
						,t.Basis					
						,t.Account
						,t.GLAccountDesc
						,t.DataSet				                                
						,t.DateOfFact				
						,t.BusinessKey
						,t.GLBusinessKey
						,t.PolicyNumber			
						,t.InceptionDate			
						,t.ExpiryDate				
						,t.BindDate				
						,t.DueDate				
						,t.TrifocusCode			
						,t.Entity
						,t.SyndicateSplitPercentage
						,t.[Location]				
						,t.YOA					
						,t.TypeOfBusiness
						,t.GLTransactionType
						,t.GLSupplierCust
						,t.SettlementCCY			
						,t.OriginalCCY			
						,t.IsToDate				
						,t.[Value]			
						,t.ValueOrig as ValueOrig						 
						,t.RowHash
						,t.[RowHash_Transaction_AgressoAR_Extensions]
						,t.StatsCode  
						,t.BusinessProcessCode

						From  #TempInboundTransactionsplit t
						union all

						SELECT 
						 t.Scenario				
						,t.Basis					
						,t.Account
						,t.GLAccountDesc
						,t.DataSet				                                
						,t.DateOfFact				
						,t.BusinessKey
						,t.GLBusinessKey
						,t.PolicyNumber			
						,t.InceptionDate			
						,t.ExpiryDate				
						,t.BindDate				
						,t.DueDate				
						,t.TrifocusCode			
						,t.Entity
						,t.SyndicateSplitPercentage
						,t.[Location]				
						,t.YOA					
						,t.TypeOfBusiness
						,t.GLTransactionType
						,t.GLSupplierCust
						,t.SettlementCCY			
						,t.OriginalCCY			
						,t.IsToDate				
						,t.[Value]			
						,t.ValueOrig as ValueOrig							 
						,t.RowHash
						,t.[RowHash_Transaction_AgressoAR_Extensions]
						,t.StatsCode
						,t.BusinessProcessCode

						From   #TempInboundTransaction t where Entity NOT IN ('USSYND')
						) as tmp

						
						--------------------------------------------------------------------
						  -----------------------------------------------------------	
	                  /*RowHash*/
	   -----------------------------------------------------------

				IF object_id('tempdb..#TempInboundTransactionInit') is not null drop table #TempInboundTransactionInit 

				SELECT 
						 tmp.Scenario				
						,tmp.Basis					
						,tmp.Account
						,tmp.GLAccountDesc
						,tmp.DataSet				                                
						,tmp.DateOfFact				
						,tmp.BusinessKey
						,tmp.GLBusinessKey
						,tmp.PolicyNumber			
						,tmp.InceptionDate			
						,tmp.ExpiryDate				
						,tmp.BindDate				
						,tmp.DueDate				
						,tmp.TrifocusCode			
						,tmp.Entity	
						,tmp.SyndicateSplitPercentage
						,tmp.[Location]				
						,tmp.YOA					
						,tmp.TypeOfBusiness
						,tmp.GLTransactionType
						,tmp.GLSupplierCust
						,tmp.SettlementCCY			
						,tmp.OriginalCCY			
						,tmp.IsToDate				
						,[Value]= CASE 
						  WHEN tmp.Account = 'PC-SD-OT' 
						  THEN tmp.[Value] *-1
						  WHEN tmp.Account= 'BC-SD-OT'
						  THEN tmp.[Value] 
						  end
						,[ValueOrig]= CASE 
						  WHEN tmp.Account = 'PC-SD-OT' 
						  THEN tmp.ValueOrig *-1
						  WHEN tmp.Account= 'BC-SD-OT'
						  THEN tmp.ValueOrig
						  end			

						-- fortify with isnull so we don't have to worry if the column changes for whatever reason. 
						,RowHash				= HASHBYTES('SHA2_512',
															CONCAT(	 ISNULL(tmp.Scenario,'')  													,'§~§'
																	,ISNULL(tmp.[Account],'') 													,'§~§'
																	,ISNULL(tmp.DataSet,'')  													,'§~§'
																	,ISNULL(tmp.[BusinessKey],'') 												,'§~§'
																	,ISNULL(tmp.[PolicyNumber],'') 												,'§~§'
																	,ISNULL(CONVERT(VARCHAR(10),tmp.InceptionDate,102),'')						,'§~§'
																	,ISNULL(CONVERT(VARCHAR(10),tmp.ExpiryDate,102),'')							,'§~§'
																	,ISNULL(CONVERT(VARCHAR(10),tmp.BindDate,102),'')							,'§~§'
																	,ISNULL(CONVERT(VARCHAR(10),tmp.DueDate,102),'')							,'§~§'
																	,ISNULL(tmp.[TrifocusCode],'')												,'§~§'    
																	,ISNULL(tmp.Entity,'')														,'§~§'
																	,ISNULL(tmp.[YOA],'') 														,'§~§'
																	,ISNULL(tmp.TypeOfBusiness,'') 												,'§~§'
																	,ISNULL(tmp.StatsCode,'')													,'§~§'
																	,ISNULL(tmp.SettlementCCY,'')												,'§~§'
																	,ISNULL(tmp.OriginalCCY,'')													,'§~§'
																	,ISNULL(tmp.IsToDate,'')													,'§~§'
																	,ISNULL(tmp.Basis,'')													    ,'§~§'
																	,ISNULL(tmp.[Location],'')													,'§~§'
																	,ISNULL(tmp.[BusinessProcessCode],'')										,'§~§'
																	,ISNULL(tmp.GLBusinessKey,'')										        ,'§~§'
																	,ISNULL(tmp.GLSupplierCust,'')                                              ,'§~§'
																	,ISNULL(CONVERT(VARCHAR(10),tmp.SyndicateSplitPercentage),'')               ,'§~§'
																	,ISNULL(tmp.GLTransactionType,'')                                           ,'§~§'
					

																	)
																)
						,tmp.BusinessProcessCode	
						,tmp.StatsCode              

				INTO #TempInboundTransactionInit

				FROM #transactions_UnionSplit AS tmp 

				if object_id('tempdb..#transactions_final_agg_cs') is not null drop table #transactions_final_agg_cs

						SELECT 
						 t.Scenario				
						,t.Basis					
						,t.Account
						,t.GLAccountDesc
						,t.DataSet				                                
						,t.DateOfFact				
						,t.BusinessKey
						,t.GLBusinessKey
						,t.PolicyNumber			
						,t.InceptionDate			
						,t.ExpiryDate				
						,t.BindDate				
						,t.DueDate				
						,t.TrifocusCode			
						,t.Entity
						,t.SyndicateSplitPercentage
						,t.[Location]				
						,t.YOA					
						,t.TypeOfBusiness
						,t.GLTransactionType
						,t.GLSupplierCust
						,t.SettlementCCY			
						,t.OriginalCCY			
						,t.IsToDate				
						,t.[Value]			
						,t.ValueOrig as ValueOrig							 
						,t.RowHash
						,t.StatsCode
						,t.BusinessProcessCode
						,[RowHash_Transaction_AgressoAR_Extensions] = HASHBYTES('SHA2_512',CONCAT
					(	 
						-- extra attributes
						ISNULL(t.GLBusinessKey,'')										    ,'§~§'
						,ISNULL(t.PolicyNumber,'')										    ,'§~§'
						,ISNULL(t.GLSupplierCust,'')                                        ,'§~§'
						,ISNULL(CONVERT(VARCHAR(10),t.SyndicateSplitPercentage),'')         ,'§~§'
						,ISNULL(t.GLTransactionType,'')                                     ,'§~§'
						)
					)
						into
					#transactions_final_agg_cs
						From  #TempInboundTransactionInit t--#TempInboundTransactionUnion  t



				------/* Delete the current lines from Inbound ... */
				if @stop = 1 return

				------/* Delete the current lines from Inbound ... */

				DELETE 				
				FROM    [FinanceDataContract].[Inbound].[Transaction]					
				WHERE   [DataSet] =@v_DataSet

				DELETE [FinanceDataContract].[Inbound].[Transaction_AgressoAR_Extensions_Bridge]
				WHERE [ContractType] = @ContractType

				DELETE [FinanceDataContract].[Inbound].[Transaction_AgressoAR_Extensions]
				WHERE [ContractType] =  @ContractType


				--If no new data, then log and exit

				IF NOT EXISTS (SELECT TOP 1 1 FROM #transactions_final_agg_cs)
				BEGIN

					SELECT	  @v_ActivityDateTime			= GETUTCDATE()
							, @v_AffectedRows				= 0;

					EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
								 @p_ParentActivityLogId
								,@v_ActivityLogTag
								,@v_ActivitySource
								,@v_ActivityType
								,@v_ActivityStatusStop
								,@v_ActivityHost
								,@v_ActivityDatabase
								,@v_ActivityJobId
								,@v_ActivitySSISExecutionId
								,@v_ActivityName
								,@v_ActivityDateTime
								,@v_ActivityMessage
								,@v_ActivityErrorCode
								,@v_AffectedRows
								,@v_ActivityLogIdIn OUTPUT;	

					RETURN;
				END;



				IF @Trancount = 0
					BEGIN TRAN;

				INSERT INTO [dbo].[Batch]
					([CreateDate],[DataSet],[LatestBusinesKey]) 
				VALUES  
					(GETDATE(),@v_DataSet, NULL);

				SELECT @v_BatchId = SCOPE_IDENTITY();

				INSERT INTO [dbo].[Batch]
					([CreateDate],[DataSet],[LatestBusinesKey]) 
				VALUES  
					(GETDATE(),'AgressoARExtensions', NULL);

				SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();
								
				------/* ... and add the new ones  */

				INSERT INTO  [FinanceDataContract].[Inbound].Transaction_AgressoAR_Extensions_Bridge WITH(TABLOCK)
				(
					[RowHash_Transaction]
					,[RowHash_Transaction_AgressoAR_Extensions]
					,[ContractType]
					,[FK_Batch]
				)
				SELECT DISTINCT
					c.[RowHash]
					,c.[RowHash_Transaction_AgressoAR_Extensions]
					,@ContractType
					,@v_BatchId_Extensions
				FROM 
					#transactions_final_agg_cs c
				where
					@stop = 0


				INSERT INTO  [FinanceDataContract].[Inbound].Transaction_AgressoAR_Extensions WITH(TABLOCK)
				(
					[RowHash_Transaction_AgressoAR_Extensions]
					,[GLBusinessKey]
					,[GLPolicyNumber]
					,[GLTransactionType]
					,[GLSupplierCust]
					,[SyndicateSplitPercentage]
					,[ContractType]
					,[FK_Batch]
				)
				SELECT DISTINCT
					[RowHash_Transaction_AgressoAR_Extensions]
					,GLBusinessKey
					,PolicyNumber
					,GLTransactionType
					,GLSupplierCust
					,SyndicateSplitPercentage
					,@ContractType
					,@v_BatchId_Extensions
				FROM 
					#transactions_final_agg_cs
				where
					@stop = 0	


		INSERT INTO [FinanceDataContract].[Inbound].[Transaction] WITH(TABLOCK)
					([Scenario]
					,[Basis]
					,[Account]
					,[DataSet]
					,[DateOfFact]
					,[BusinessKey]
					,[PolicyNumber]
					,[InceptionDate]
					,[ExpiryDate]
					,[BindDate]
					,[DueDate]
					,[TrifocusCode]
					,[Entity]
					,[Location]
					,[YOA]
					,[TypeOfBusiness]
					,[StatsCode]
					,[SettlementCCY]
					,[OriginalCCY]
					,[IsToDate]
					,[Value]
					,[ValueOrig]
					,[RowHash]
					,[BusinessProcessCode]
					,[FK_Batch]
					,[AuditSourceBatchID]
					,[AuditHost]
					,[AuditGenerateDateTime])		
				select
					t.[Scenario]
					,t.[Basis]
					,t.[Account]
					,t.[DataSet]
					,t.[DateOfFact]
					,t.[BusinessKey]
					,t.[PolicyNumber]
					,t.[InceptionDate]
					,t.[ExpiryDate]
					,t.[BindDate]
					,t.[DueDate]
					,t.[TrifocusCode]
					,t.[Entity]
					,t.[Location]
					,t.[YOA]
					,t.[TypeOfBusiness]
					,t.[StatsCode]
					,t.[SettlementCCY]
					,t.[OriginalCCY]
					,t.[IsToDate]
					,t.[Value]
					,t.[ValueOrig]
					,t.[RowHash]
					,t.[BusinessProcessCode]
					,FK_Batch = @v_BatchId
					,AuditSourceBatchID = @v_BatchId
					,[AuditHost] = CONVERT([VARCHAR](255),(SERVERPROPERTY('MachineName')))
					,[AuditGenerateDateTime] = GETUTCDATE()					   
				from
					#transactions_final_agg_cs t
				where
					@stop = 0
	

				SELECT   @v_AffectedRows			= @@ROWCOUNT;



				--/* Add the batchs to the queue */
				---- select top 100 * from [FinanceDataContract].[Inbound].[BatchQueue]  order by 1 desc
				INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,RunDescription
								,[DataSet]
								,OriginalName
								,AuditSourceBatchID
								)
				VALUES
								( @v_BatchId
								 ,'InBound'
								 ,NULL
								 ,@v_DataSet
								 ,NULL
								 ,NULL
								)
								,

								( @v_BatchId_Extensions
								 ,'InBound'
								 ,'AgressoARExtensions, the additional attributes to extend functionality of the transaction table.'
								 ,'AgressoARExtensions'
								 ,NULL
								 ,NULL
								);
				-- LOG THE RESULT WITH SUCCESS

				SELECT @v_ActivityDateTime			= GETUTCDATE();

				EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
						 @p_ParentActivityLogId
						,@v_ActivityLogTag
						,@v_ActivitySource
						,@v_ActivityType
						,@v_ActivityStatusStop
						,@v_ActivityHost
						,@v_ActivityDatabase
						,@v_ActivityJobId
						,@v_ActivitySSISExecutionId
						,@v_ActivityName
						,@v_ActivityDateTime
						,@v_ActivityMessage
						,@v_ActivityErrorCode
						,@v_AffectedRows
						,@v_ActivityLogIdIn OUTPUT;

				IF @Trancount = 0 AND @@TRANCOUNT <> 0
					COMMIT;
					

			END TRY

			BEGIN CATCH

				-- CANCEL TRAN
				IF @Trancount = 0 AND @@TRANCOUNT <> 0
					ROLLBACK;
			
				-- LOG THE RESULT WITH ERROR

				SELECT   @v_ActivityDateTime				= GETUTCDATE()
						,@v_ActivityLogTag					= @v_ActivityLogIdIn
						,@v_ActivityMessage					= ERROR_MESSAGE()
						,@v_ActivityErrorCode				= ERROR_NUMBER();

				EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
						 @p_ParentActivityLogId
						,@v_ActivityLogTag
						,@v_ActivitySource
						,@v_ActivityType
						,@v_ActivityStatusFail
						,@v_ActivityHost
						,@v_ActivityDatabase
						,@v_ActivityJobId
						,@v_ActivitySSISExecutionId
						,@v_ActivityName
						,@v_ActivityDateTime
						,@v_ActivityMessage
						,@v_ActivityErrorCode
						,@v_AffectedRows
						,@v_ActivityLogIdIn OUTPUT;

				THROW;

			END CATCH;

END;