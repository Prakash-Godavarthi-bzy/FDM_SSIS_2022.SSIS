﻿CREATE TABLE [AgressoAR].[uviifrs17_BIDAC](
	[PK_BIDAC] [bigint] IDENTITY(1,1) NOT NULL,
	[GLAccount] [varchar](14) NOT NULL,
	[GLAccountDesc] [varchar](255) NOT NULL,
	[Source] [varchar](50) NOT NULL,
	[DateOfFact] [datetime] NOT NULL,
	[GLBusinessKey] [varchar](255) NOT NULL,
	[GLPolicyNumber] [varchar](255) NOT NULL,
	[GLMCTransNo] [varchar](25) NOT NULL,
	[InceptionDate] [datetime] NOT NULL,
	[ExpiryDate] [datetime] NOT NULL,
	[BindDate] [datetime] NULL,
	[DueDate] [datetime] NULL,
	[TrifocusCode] [varchar](25) NOT NULL,
	[Entity] [varchar](25) NOT NULL,
	[YOA] [varchar](5) NOT NULL,
	[GLTransactionType] [varchar](2) NULL,
	[GLSupplierCust] [varchar](25) NOT NULL,
	[GLInvoiceNo] [varchar](100) NOT NULL,
	[SettlementCCY] [varchar](3) NOT NULL,
	[OriginalCCY] [varchar](3) NOT NULL,
	[IsToDate] [varchar](1) NOT NULL,
	[SettlementValue] [numeric](19, 4) NOT NULL,
	[OriginalValue] [numeric](19, 4) NULL,
	[GLAccountingPeriod] [varchar](10) NOT NULL,
	[AuditSourceServer] [varchar](255) NULL,
	[AuditSourceTable] [varchar](255) NOT NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [varchar](255) NOT NULL,
	[AuditHost] [varchar](255) NULL
) ON [PRIMARY]
GO

ALTER TABLE [AgressoAR].[uviifrs17_BIDAC] ADD  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [AgressoAR].[uviifrs17_BIDAC] ADD  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [AgressoAR].[uviifrs17_BIDAC] ADD  DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO
