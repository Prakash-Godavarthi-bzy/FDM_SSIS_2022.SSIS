﻿
CREATE TABLE [Claims_BI_ODS].PolicySectionReference(
	[PolicyReference] [varchar](255) NOT NULL,
	[SectionReference] [varchar](255) NOT NULL, 
    CONSTRAINT [PK_PolicySectionReference] PRIMARY KEY ([SectionReference], [PolicyReference]),
	) 