﻿CREATE PROCEDURE [Claims_BI_ODS].[usp_LandingToInbound] (
	@p_ParentActivityLogId BIGINT = NULL
	,@p_ActivityJobId VARCHAR(50) = NULL
	,@AP DATETIME = NULL
	)
AS
/* =============================================

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	2021-02-08
-- Changes:				Loads Claim Center BI ODS data from FinanceLanding to Inbound.Transaction

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	2021-05-07
-- Changes:				Loads Claim Center BI ODS data from FinanceLanding to Inbound.Transaction. Second draft.

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	2021-05-26
-- Changes:				Removed the section reference from the extensions table and aggregated to 2018Q4 for the opening balance.

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	2021-09-08
-- Changes:				With the additional data that we now have by including External claims I needed to address performance issues as this procedure was taking 35 minutes to execute on the development platform.
--						I removed the process that aggregates the claims data from the outbound.transaction table and moved it to the SSIS package IFRS17_BICCToLandingExtract.dtsx where it can be done at the same time as the claims 
--						are sourced. This along with other improvements brought the execution time down to 16 minutes in the development environment.
--						I also added functionality to include the DeltaType in the inbound.transaction table, so I can sort out what is New and what are Adjustments.
--						This mainly effected day one data, as all of it would show as new - but can also effect data afterwards especially when long periods have past
--						before data is loaded. This happens in the testing and UAT environments.

	Altered by:			nithin.dumpeti@beazley.com
	Altered date:		05-02-2024
	Changes:			Auditing AccountingPeriod in inbound.batchqueue table in column AsAt for passing date as a parameter externally

-- =============================================	*/
BEGIN
	SET NOCOUNT ON;

	DECLARE @Trancount INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);
	DECLARE @v_RC INT;
	DECLARE @v_ActivityLogTag BIGINT;
	DECLARE @v_ActivitySource SMALLINT;
	DECLARE @v_ActivityType SMALLINT;
	DECLARE @v_ActivityStatusStart SMALLINT;
	DECLARE @v_ActivityStatusStop SMALLINT;
	DECLARE @v_ActivityStatusFail SMALLINT;
	DECLARE @v_ActivityHost VARCHAR(100);
	DECLARE @v_ActivityDatabase VARCHAR(100);
	DECLARE @v_ActivityName VARCHAR(100);
	DECLARE @v_ActivityDateTime DATETIME2(2);
	DECLARE @v_ActivityMessage NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn BIGINT;
	DECLARE @v_ActivityLogIdOut BIGINT;
	DECLARE @v_ActivityJobId VARCHAR(50) = @p_ActivityJobId;
	DECLARE @v_ActivitySSISExecutionId VARCHAR(50) = NULL;
	DECLARE @v_AffectedRows INT = 0;
	DECLARE @v_AsAt VARCHAR(6);
	-- for debugging. set to 1 & the no records will be written to the inbound tables.
	DECLARE @stop BIT = 0

	SELECT @v_ActivityStatusStart = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'ERRORED';

	DECLARE @v_BatchId INT;
	DECLARE @v_BatchId_Extensions INT;

	/* Log the start of the insert */
	BEGIN TRY
		SELECT @v_ActivityLogTag = NULL
			,@v_ActivitySource = (
				SELECT PK_ActivitySource
				FROM Orchestram.Log.ActivitySource
				WHERE ActivitySource = 'IFRS17'
				)
			,@v_ActivityType = (
				SELECT PK_ActivityType
				FROM Orchestram.Log.ActivityType
				WHERE ActivityType = CASE 
						WHEN @p_ParentActivityLogId IS NULL
							THEN 'Manual process'
						ELSE 'Automated process'
						END
				)
			,@v_ActivityHost = @@SERVERNAME
			,@v_ActivityName = 'Load data into Inbound.Transaction'
			,@v_ActivityDatabase = 'FinanceLanding'
			,@v_ActivityDateTime = GETUTCDATE()
			,@v_ActivityMessage = NULL
			,@v_ActivityErrorCode = NULL;

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStart
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

		--------------------------------------------------
		PRINT 'Starting the process of getting the data: ' + convert(VARCHAR, getdate())

		--------------------------------------------------
		---- variable used to re-state records when attributes change and we don't have a movement/transaction for the row.
		---- We use the newest movement date in the data set as this will give us the last time something changed in the system. 
		--declare @AttributeChangeDate date = CONVERT(DATE,(select MAX(MovementDate) from [Claims_BI_ODS].[ClaimMovements])) ---2023-04-17 09:43:51.610
		----select @AttributeChangeDate
		---- Where are we in the outbound table? Are we up to date? If we get the max MovementDate from the Outbound aggregated table, and compare it to the date above - we can determine if we need to run this process or not.
		--declare @ClaimMovementsInOutbound_MovementDate date = (select MAX(MovementDate) from [Claims_BI_ODS].[ClaimMovementsInOutbound]) 
		--select [@AttributeChangeDate]=@AttributeChangeDate, [@ClaimMovementsInOutbound_MovementDate]=@ClaimMovementsInOutbound_MovementDate
		--	declare @OpeningBalanceDate date = '31 December 2018' -- this is the date for the opening balance
		--declare @OpeningBalanceCutOffYear int = year(@OpeningBalanceDate) + 1 -- this will be 2019
		DECLARE @AsAt DATETIME

		SET @AsAt = @AP

		DROP TABLE

		IF EXISTS #TempInboundTransactionInit;
			/*  account */
			;
			WITH CTE_AccountMap
			AS (
				SELECT 'MovementIncurredFees' AS BICCField
					,'C-FI-' AS BICCAccount
				
				UNION
				
				SELECT 'MovementIncurredIndemnity' AS BICCField
					,'C-II-' AS BICCAccount
				
				UNION
				
				SELECT 'MovementIncurredDefence' AS BICCField
					,'C-DI-' AS BICCAccount
				
				UNION
				
				SELECT 'MovementPaidIndemnity' AS BICCField
					,'C-IP-' AS BICCAccount
				
				UNION
				
				SELECT 'MovementPaidFees' AS BICCField
					,'C-FP-' AS BICCAccount
				
				UNION
				
				SELECT 'MovementPaidDefence' AS BICCField
					,'C-DP-' AS BICCAccount
					--UNION
					--SELECT
					--'MovementOutstandingDefence' AS BICCField, 'C-DO-' as BICCAccount
					--UNION
					--SELECT
					--'MovementOutstandingFees' AS BICCField, 'C-FO-' as BICCAccount
					--UNION
					--SELECT
					--'MovementOutstandingIndemnity' AS BICCField, 'C-IO-' as BICCAccount
				)
			--	select * from CTE_AccountMap
			SELECT [Value]
				,TransactionType
				--,DateOfFact				= case when year(cem.FK_Date) < @OpeningBalanceCutOffYear then @OpeningBalanceDate
				--			                               else CONVERT(DATE,cem.FK_Date) 
				,DateOfFact = CASE 
					WHEN year(unpvt.FK_Date) <= '2018'
						THEN '2018-12-01'
					ELSE convert(DATE, unpvt.FK_Date)
					END
				,BusinessKey = BusinessKey + '|' + coalesce(Left(AM.BICCAccount, 4), '-')
				,AM.BICCAccount + CASE 
					WHEN ll.LargeLossIndicator = 1
						THEN 'LL'
					ELSE 'ATT'
					END Account
				--	,SequenceNumber			= CONVERT(VARCHAR(4),unpvt.SequenceNumber)
				,PolicyNumber = CONVERT(VARCHAR(255), unpvt.SectionReference)
				,InceptionDate = CONVERT(DATETIME, COALESCE(unpvt.InceptionDate, '19800101'))
				,ExpiryDate = CONVERT(DATETIME, COALESCE(unpvt.ExpiryDate, '19800101'))
				,TrifocusCode = CONVERT(VARCHAR(25), unpvt.TriFocusCode)
				,Entity = CONVERT(VARCHAR(25), unpvt.SyndicateNumber)
				,[Location] = CONVERT(VARCHAR(100), LEFT(ISNULL(unpvt.LocationOfLossCountry, 'NOCOUNTRY') + '|' + ISNULL(unpvt.LocationOfLossState, 'NOSTATE'), 100))
				,YOA = ISNULL(CONVERT(VARCHAR(5), NULLIF(unpvt.FK_YOA, 0)), 'NOYOA')
				,CCY = CONVERT(VARCHAR(3), unpvt.CurrencyCode)
				,DateOfLoss = CONVERT(DATE, unpvt.LossFromDate)
				,SourceSystem = unpvt.ClaimSource
				,PolicySourceSystem = unpvt.PolicySourceSystem
				,UnderwritingPlatformCode = unpvt.UnderwritingPlatformCode
				,UnderwritingPlatformName = unpvt.UnderwritingPlatformName
				,UWOfficeLocation = unpvt.BeazleyOfficeLocation
				,MovementType = unpvt.MovementType
				--	,TransactionTrackingStatus	= unpvt.TransactionTrackingStatus
				,InsuredState = unpvt.InsuredState
				,InsuredCountry = unpvt.InsuredCountry
				,BeazleyCatCode = unpvt.BeazleyCatCode
				,IsLargeLossClaim = CONVERT(BIT, ll.LargeLossIndicator)
				,MovementDate = CONVERT(DATE, unpvt.MovementDate)
				,ExposureReference = unpvt.ExposureReference
				,SCMReference = unpvt.SCMReference
				,ClaimReference = unpvt.ClaimReference
				,Scenario = CONVERT([VARCHAR](2), 'A')
				,Basis = CONVERT([VARCHAR](2), 'B')
				,DataSet = CONVERT([VARCHAR](255), 'Claims_BI_ODS')
				,BindDate = CONVERT(DATETIME, '19800101')
				,DueDate = CONVERT(DATETIME, '19800101')
				,TypeOfBusiness = CONVERT([VARCHAR](1), '-')
				,SettlementCCY = CONVERT(VARCHAR(3), unpvt.CurrencyCode)
				,OriginalCCY = CONVERT(VARCHAR(3), unpvt.CurrencyCode)
				,IsToDate = CONVERT([VARCHAR](1), 'N')
				,ValueOrig = unpvt.[Value]
				,StatsCode = CONVERT([VARCHAR](25), '-')
				,BusinessProcessCode = CONVERT([VARCHAR](255), 'T1')
			INTO #TempInboundTransactionInit
			FROM (
				SELECT [PolicyReference]
					,[PolicySourceSystem]
					,[ClaimReference]
					,[ClaimSource]
					,[SectionReference]
					,[InceptionDate]
					,[ExpiryDate]
					,
					--  [TransactionTrackingStatus], 
					[MovementType]
					,[SyndicateNumber]
					,[UnderwritingPlatformName]
					,[UnderwritingPlatformCode]
					,[BeazleyOfficeLocation]
					,[InsuredState]
					,[InsuredCountry]
					,[LossFromDate]
					,[LocationOfLossCountry]
					,[LocationOfLossState]
					,[TriFocusCode]
					,[CurrencyCode]
					,[BeazleyCatCode]
					,cast([MovementDate] AS DATE) AS [MovementDate]
					,sum([MovementIncurredIndemnity]) AS [MovementIncurredIndemnity]
					,sum([MovementOutstandingIndemnity]) AS [MovementOutstandingIndemnity]
					,sum([MovementPaidIndemnity]) AS [MovementPaidIndemnity]
					,sum([MovementIncurredFees]) AS [MovementIncurredFees]
					,sum([MovementOutstandingFees]) AS [MovementOutstandingFees]
					,sum([MovementPaidFees]) AS [MovementPaidFees]
					,sum([MovementIncurredDefence]) AS [MovementIncurredDefence]
					,sum([MovementOutstandingDefence]) AS [MovementOutstandingDefence]
					,sum([MovementPaidDefence]) AS [MovementPaidDefence]
					,[ExposureReference]
					,[SCMReference]
					,[MovementReference]
					,[SequenceNumber]
					,[BusinessKey]
					,FK_date
					,FK_YOA
				FROM [FinanceLanding].Claims_BI_ODS.[ClaimMovements]
				WHERE FK_Date <= @AsAt
					AND (
						MovementIncurredDefence <> 0
						OR MovementIncurredFees <> 0
						OR MovementIncurredIndemnity <> 0
						OR MovementPaidDefence <> 0
						OR MovementPaidIndemnity <> 0
						OR MovementPaidFees <> 0
						)
				--	and  BusinessKey='ClaimCenter|BEAZL100005210609-01|Payment|1|USD|USD|623|2023-04-23'
				GROUP BY [PolicyReference]
					,[PolicySourceSystem]
					,[ClaimReference]
					,[ClaimSource]
					,[SectionReference]
					,[InceptionDate]
					,[ExpiryDate]
					,
					-- [TransactionTrackingStatus],
					[MovementType]
					,[SyndicateNumber]
					,[UnderwritingPlatformName]
					,[UnderwritingPlatformCode]
					,[BeazleyOfficeLocation]
					,[InsuredState]
					,[InsuredCountry]
					,[LossFromDate]
					,[LocationOfLossCountry]
					,[LocationOfLossState]
					,[TriFocusCode]
					,[CurrencyCode]
					,[BeazleyCatCode]
					,cast([MovementDate] AS DATE)
					,[ExposureReference]
					,[SCMReference]
					,[MovementReference]
					,[SequenceNumber]
					,[BusinessKey]
					,FK_date
					,FK_YOA
				) cem
			unpivot([Value] FOR TransactionType IN (
						[MovementIncurredIndemnity]
						,[MovementPaidIndemnity]
						,[MovementIncurredFees]
						,[MovementPaidFees]
						,[MovementIncurredDefence]
						,[MovementPaidDefence]
						-- ,[MovementOutstandingDefence]
						-- ,[MovementOutstandingFees]
						-- ,[MovementOutstandingIndemnity]
						)) AS unpvt
			LEFT JOIN [FinanceLanding].MDS.vw_CatCode ll ON unpvt.BeazleyCatCode = ll.BeazleyCatCode
			JOIN CTE_AccountMap AM ON unpvt.TransactionType = AM.BICCField
			WHERE unpvt.[Value] <> 0

		PRINT 'Created #TempInboundTransactionInit table: ' + convert(VARCHAR, getdate())

		SELECT *
			,RowHash = HASHBYTES('SHA2_512', CONCAT (
					ISNULL(tmp.Scenario, '')
					,'§~§'
					,ISNULL(tmp.Basis, '')
					,'§~§'
					,ISNULL(tmp.[Account], '')
					,'§~§'
					,ISNULL(tmp.DataSet, '')
					,'§~§'
					,ISNULL(tmp.[BusinessKey], '')
					,'§~§'
					,ISNULL(tmp.[PolicyNumber], '')
					,'§~§'
					,ISNULL(CONVERT(VARCHAR(10), tmp.InceptionDate, 102), '')
					,'§~§'
					,ISNULL(CONVERT(VARCHAR(10), tmp.ExpiryDate, 102), '')
					,'§~§'
					,ISNULL(CONVERT(VARCHAR(10), tmp.BindDate, 102), '')
					,'§~§'
					,ISNULL(CONVERT(VARCHAR(10), tmp.DueDate, 102), '')
					,'§~§'
					,ISNULL(tmp.[TrifocusCode], '')
					,'§~§'
					,ISNULL(tmp.Entity, '')
					,'§~§'
					,ISNULL(tmp.[Location], '')
					,'§~§'
					,ISNULL(tmp.[YOA], '')
					,'§~§'
					,ISNULL(tmp.TypeOfBusiness, '')
					,'§~§'
					,ISNULL(tmp.StatsCode, '')
					,'§~§'
					,ISNULL(tmp.SettlementCCY, '')
					,'§~§'
					,ISNULL(tmp.OriginalCCY, '')
					,'§~§'
					,ISNULL(tmp.IsToDate, '')
					,'§~§'
					,ISNULL(tmp.BusinessProcessCode, '')
					,'§~§'
					-- extra attributes
					,ISNULL(CONVERT(VARCHAR(10), tmp.DateOfLoss, 102), '')
					,'§~§'
					,ISNULL(tmp.SourceSystem, '')
					,'§~§'
					,ISNULL(tmp.PolicySourceSystem, '')
					,'§~§'
					,ISNULL(tmp.UnderwritingPlatformCode, '')
					,'§~§'
					,ISNULL(tmp.UnderwritingPlatformName, '')
					,'§~§'
					,ISNULL(tmp.UWOfficeLocation, '')
					,'§~§'
					,ISNULL(tmp.MovementType, '')
					,'§~§'
					--	,ISNULL(tmp.TransactionTrackingStatus,'')									,'§~§'
					,ISNULL(tmp.InsuredState, '')
					,'§~§'
					,ISNULL(tmp.InsuredCountry, '')
					,'§~§'
					,ISNULL(tmp.BeazleyCatCode, '')
					,'§~§'
					,ISNULL(CONVERT(CHAR(1), tmp.IsLargeLossClaim), '')
					,'§~§'
					,ISNULL(CONVERT(VARCHAR(10), tmp.MovementDate, 102), '')
					,'§~§'
					,ISNULL(tmp.ExposureReference, '')
					,'§~§'
					,ISNULL(tmp.SCMReference, '')
					,'§~§'
					,ISNULL(tmp.ClaimReference, '')
					,'§~§'
					))
			,RowHash_Transaction_Claim_Extensions = HASHBYTES('SHA2_512', CONCAT (
					-- extra attributes
					ISNULL(CONVERT(VARCHAR(10), tmp.DateOfLoss, 102), '')
					,'§~§'
					,ISNULL(tmp.SourceSystem, '')
					,'§~§'
					,ISNULL(tmp.PolicySourceSystem, '')
					,'§~§'
					,ISNULL(tmp.UnderwritingPlatformCode, '')
					,'§~§'
					,ISNULL(tmp.UnderwritingPlatformName, '')
					,'§~§'
					,ISNULL(tmp.UWOfficeLocation, '')
					,'§~§'
					,ISNULL(tmp.MovementType, '')
					,'§~§'
					--	,ISNULL(tmp.TransactionTrackingStatus,'')									,'§~§'
					,ISNULL(tmp.InsuredState, '')
					,'§~§'
					,ISNULL(tmp.InsuredCountry, '')
					,'§~§'
					,ISNULL(tmp.BeazleyCatCode, '')
					,'§~§'
					,ISNULL(CONVERT(CHAR(1), tmp.IsLargeLossClaim), '')
					,'§~§'
					,ISNULL(CONVERT(VARCHAR(10), tmp.MovementDate, 102), '')
					,'§~§'
					,ISNULL(tmp.ExposureReference, '')
					,'§~§'
					,ISNULL(tmp.SCMReference, '')
					,'§~§'
					,ISNULL(tmp.ClaimReference, '')
					,'§~§'
					))
		INTO #TempInboundTransaction
		FROM #TempInboundTransactionInit tmp

		--------------------------------------------------------------------
		------/* Delete the current lines of the BI Claim Center source system from Inbound ... */
		DELETE
		FROM [FinanceDataContract].[Inbound].[Transaction]
		WHERE [DataSet] = 'Claims_BI_ODS';

		TRUNCATE TABLE [FinanceDataContract].[Inbound].[Transaction_Claim_Extensions_Bridge]

		TRUNCATE TABLE [FinanceDataContract].[Inbound].[Transaction_Claim_Extensions]

		PRINT 'deleted inbound data: ' + convert(VARCHAR, getdate())

		--select * from #transactions_final_agg_cs
		--return 
		--If no new data, then log and exit
		IF NOT EXISTS (
				SELECT TOP 1 1
				FROM #TempInboundTransaction
				)
		BEGIN
			PRINT 'No data to go into the inbound table'

			SELECT @v_ActivityDateTime = GETUTCDATE()
				,@v_AffectedRows = 0;

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStop
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

			RETURN;
		END;

		IF @Trancount = 0
			BEGIN TRAN;

		PRINT 'beginning transaction: ' + convert(VARCHAR, getdate())

		-- select * from [dbo].[Batch]
		INSERT INTO [dbo].[Batch] (
			[CreateDate]
			,[DataSet]
			,[LatestBusinesKey]
			)
		VALUES (
			GETDATE()
			,'Claims_BI_ODS'
			,NULL
			);

		SELECT @v_BatchId = SCOPE_IDENTITY();

		INSERT INTO [dbo].[Batch] (
			[CreateDate]
			,[DataSet]
			,[LatestBusinesKey]
			)
		VALUES (
			GETDATE()
			,'ClaimCentreExtensions'
			,NULL
			);

		SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();

		------/* ... and add the new ones  */
		INSERT INTO [FinanceDataContract].[Inbound].[Transaction_Claim_Extensions_Bridge]
		WITH (TABLOCK) (
				[RowHash_Transaction]
				,[RowHash_Transaction_Claim_Extensions]
				,[FK_Batch]
				)
		SELECT DISTINCT [RowHash]
			,[RowHash_Transaction_Claim_Extensions]
			,@v_BatchId_Extensions
		FROM #TempInboundTransaction

		INSERT INTO [FinanceDataContract].[Inbound].[Transaction_Claim_Extensions]
		WITH (TABLOCK) (
				[RowHash_Transaction_Claim_Extensions]
				,[DateOfLoss]
				,[SourceSystem]
				,[PolicySourceSystem]
				,[UnderwritingPlatformCode]
				,[UnderwritingPlatformName]
				,[UWOfficeLocation]
				,[MovementType]
				--	,[TransactionTrackingStatus]
				,[InsuredState]
				,[InsuredCountry]
				,[BeazleyCatCode]
				,[IsLargeLossClaim]
				,[FK_Batch]
				,[MovementDate]
				,[ExposureReference]
				,[SCMReference]
				,[ClaimReference]
				)
		SELECT DISTINCT [RowHash_Transaction_Claim_Extensions]
			,[DateOfLoss]
			,[SourceSystem]
			,[PolicySourceSystem]
			,[UnderwritingPlatformCode]
			,[UnderwritingPlatformName]
			,[UWOfficeLocation]
			,[MovementType]
			--,[TransactionTrackingStatus]
			,[InsuredState]
			,[InsuredCountry]
			,[BeazleyCatCode]
			,[IsLargeLossClaim]
			,@v_BatchId_Extensions
			,[MovementDate]
			,[ExposureReference]
			,[SCMReference]
			,[ClaimReference]
		FROM #TempInboundTransaction

		INSERT INTO [FinanceDataContract].[Inbound].[Transaction]
		WITH (TABLOCK) (
				[Scenario]
				,[Basis]
				,[Account]
				,[DataSet]
				,[DateOfFact]
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]
				,[DueDate]
				,[TrifocusCode]
				,[Entity]
				,[Location]
				,[YOA]
				,[TypeOfBusiness]
				,[StatsCode]
				,[SettlementCCY]
				,[OriginalCCY]
				,[IsToDate]
				,[Value]
				,[ValueOrig]
				,[RowHash]
				,[BusinessProcessCode]
				,[FK_Batch]
				,[AuditSourceBatchID]
				,[AuditHost]
				,[AuditGenerateDateTime]
				)
		SELECT t.[Scenario]
			,t.[Basis]
			,t.[Account]
			,t.[DataSet]
			,t.[DateOfFact]
			,t.[BusinessKey]
			,t.[PolicyNumber]
			,t.[InceptionDate]
			,t.[ExpiryDate]
			,t.[BindDate]
			,t.[DueDate]
			,t.[TrifocusCode]
			,t.[Entity]
			,t.[Location]
			,t.[YOA]
			,t.[TypeOfBusiness]
			,t.[StatsCode]
			,t.[SettlementCCY]
			,t.[OriginalCCY]
			,t.[IsToDate]
			,t.[Value]
			,t.[ValueOrig]
			,t.[RowHash]
			,t.[BusinessProcessCode]
			,FK_Batch = @v_BatchId
			,AuditSourceBatchID = @v_BatchId
			,[AuditHost] = CONVERT([VARCHAR](255), (SERVERPROPERTY('MachineName')))
			,[AuditGenerateDateTime] = GETUTCDATE()
		FROM #TempInboundTransaction t

		--where
		--SELECT   @v_AffectedRows			= @@ROWCOUNT;
		PRINT 'inserted into inbound transaction record count: ' + convert(VARCHAR, @v_AffectedRows)

		SET @v_AsAt = left(convert(VARCHAR(10), ISNULL(@AsAt, GETDATE()), 112), 6) --AsAt will store passing date as parameter externally. if it is null then take default as getdate

		--/* Add the batchs to the queue */
		---- select top 100 * from [FinanceDataContract].[Inbound].[BatchQueue]  order by 1 desc
		INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue] (
			Pk_Batch
			,[Status]
			,RunDescription
			,[DataSet]
			,OriginalName
			,AuditSourceBatchID
			,AsAt
			)
		VALUES (
			@v_BatchId
			,'InBound'
			,NULL
			,'Claims_BI_ODS'
			,NULL
			,NULL
			,@v_AsAt
			)
			,(
			@v_BatchId_Extensions
			,'InBound'
			,'ClaimCentreExtensions, the additional claim attributes to extend functionality of the transaction table.'
			,'ClaimCentreExtensions'
			,NULL
			,NULL
			,@v_AsAt
			);

		-- LOG THE RESULT WITH SUCCESS
		SELECT @v_ActivityDateTime = GETUTCDATE();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStop
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		IF @Trancount = 0
			AND @@TRANCOUNT <> 0
			COMMIT;

		PRINT 'committed transaction: ' + convert(VARCHAR, getdate())
	END TRY

	BEGIN CATCH
		-- CANCEL TRAN
		IF @Trancount = 0
			AND @@TRANCOUNT <> 0
			ROLLBACK;

		-- LOG THE RESULT WITH ERROR
		SELECT @v_ActivityDateTime = GETUTCDATE()
			,@v_ActivityLogTag = @v_ActivityLogIdIn
			,@v_ActivityMessage = ERROR_MESSAGE()
			,@v_ActivityErrorCode = ERROR_NUMBER();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusFail
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		THROW;
	END CATCH;
END;
