﻿CREATE PROCEDURE [Claims_BI_ODS].[usp_LandingToInboundToOutbound]
AS
BEGIN
	/*
===========================================================================================================
	Modified By:	nithin.dumpeti@beazley.com
	Modified date:	25/01/2024
	Description:	passing date as parameter from schedulinghub.sch.controldataset table
	JIRA Ticket:	https://beazley.atlassian.net/browse/I1B-3887	
===========================================================================================================
*/
	DECLARE @v_ErrorMessage NVARCHAR(4000);
	DECLARE @Trancount INT = @@Trancount;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;
	DECLARE @v_RC INT;
	DECLARE @v_ActivityLogTag BIGINT;
	DECLARE @v_ActivitySource SMALLINT;
	DECLARE @v_ActivityType SMALLINT;
	DECLARE @v_ActivityStatusStart SMALLINT;
	DECLARE @v_ActivityStatusStop SMALLINT;
	DECLARE @v_ActivityStatusFail SMALLINT;
	DECLARE @v_ActivityHost VARCHAR(100);
	DECLARE @v_ActivityDatabase VARCHAR(100) = 'Claims_BI_ODS';
	DECLARE @v_ActivityName VARCHAR(100);
	DECLARE @v_ActivityDateTime DATETIME2(2);
	DECLARE @v_ActivityMessage NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn BIGINT;
	DECLARE @v_ActivityLogIdOut BIGINT;
	DECLARE @v_ActivityJobId VARCHAR(50) = NULL;
	DECLARE @v_ActivitySSISExecutionId VARCHAR(50) = NULL;
	DECLARE @v_AffectedRows INT
	DECLARE @p_ParentActivityLogId BIGINT = NULL
	DECLARE @p_AccountingDate DATE;
	DECLARE @v_Default_date DATE = '1900-01-01' -- this will work when doing full refresh which runs till date

	SELECT @v_ActivityStatusStart = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'ERRORED';

	SELECT @v_ActivityLogTag = NULL
		,@v_ActivitySource = (
			SELECT PK_ActivitySource
			FROM Orchestram.Log.ActivitySource
			WHERE ActivitySource = 'IFRS17'
			)
		,@v_ActivityType = (
			SELECT PK_ActivityType
			FROM Orchestram.Log.ActivityType
			WHERE ActivityType = CASE 
					WHEN @p_ParentActivityLogId IS NULL
						THEN 'Manual process'
					ELSE 'Automated process'
					END
			)
		,@v_ActivityHost = @@SERVERNAME
		,@v_ActivityName = 'usp_LandingToInboundToOutbound_Claims_BI_ODS'
		,@v_ActivityDateTime = GETUTCDATE()
		,@v_ActivityMessage = 'Load claims_bi_ods data into Inbound.Transaction'
		,@v_ActivityErrorCode = NULL
		,@v_AffectedRows = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
		,@v_ActivityLogTag
		,@v_ActivitySource
		,@v_ActivityType
		,@v_ActivityStatusStart
		,@v_ActivityHost
		,@v_ActivityDatabase
		,@v_ActivityJobId
		,@v_ActivitySSISExecutionId
		,@v_ActivityName
		,@v_ActivityDateTime
		,@v_ActivityMessage
		,@v_ActivityErrorCode
		,@v_AffectedRows
		,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

	SELECT @p_AccountingDate = PassingDate
	FROM SchedulingHub.sch.ControlDataset
	WHERE Dataset = @v_ActivityDatabase

	DECLARE @AccountingDate DATE

	SELECT @AccountingDate = IIF(@p_AccountingDate = @v_Default_date, GETDATE(), @p_AccountingDate)

	SELECT @v_ActivityLogTag = NULL
		,@v_ActivitySource = (
			SELECT PK_ActivitySource
			FROM Orchestram.Log.ActivitySource
			WHERE ActivitySource = 'IFRS17'
			)
		,@v_ActivityType = (
			SELECT PK_ActivityType
			FROM Orchestram.Log.ActivityType
			WHERE ActivityType = CASE 
					WHEN @p_ParentActivityLogId IS NULL
						THEN 'Manual process'
					ELSE 'Automated process'
					END
			)
		,@v_ActivityHost = @@SERVERNAME
		,@v_ActivityName = 'Load claims_bi_ods  data into Inbound & Outbound for ' + CAST(@p_AccountingDate AS VARCHAR(10)) + ' Period'
		,@v_ActivityDateTime = GETUTCDATE()
		,@v_ActivityMessage = 'Load data into Inbound & Outbound Transaction for Claims_BI_ODS ' + CAST(@p_AccountingDate AS VARCHAR(10)) + ' Period'
		,@v_ActivityErrorCode = NULL
		,@v_AffectedRows = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
		,@v_ActivityLogTag
		,@v_ActivitySource
		,@v_ActivityType
		,@v_ActivityStatusStart
		,@v_ActivityHost
		,@v_ActivityDatabase
		,@v_ActivityJobId
		,@v_ActivitySSISExecutionId
		,@v_ActivityName
		,@v_ActivityDateTime
		,@v_ActivityMessage
		,@v_ActivityErrorCode
		,@v_AffectedRows
		,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

	/*--now to call the landing to inbound procedure----*/
	EXEC [FinanceLanding].Claims_BI_ODS.[usp_LandingToInbound] NULL
		,NULL
		,@AccountingDate

	EXEC FinanceDataContract.[Inbound].[usp_InboundOutboundWorkflow_ClaimExtensions]

	EXEC FinanceDataContract.[Inbound].[usp_InboundOutboundWorkflow_TransactionalDatasets] 0
		,@AccountingDate

	--set @Rowid=@Rowid+1;
	SELECT @v_ActivityLogTag = NULL
		,@v_ActivitySource = (
			SELECT PK_ActivitySource
			FROM Orchestram.Log.ActivitySource
			WHERE ActivitySource = 'IFRS17'
			)
		,@v_ActivityType = (
			SELECT PK_ActivityType
			FROM Orchestram.Log.ActivityType
			WHERE ActivityType = CASE 
					WHEN @p_ParentActivityLogId IS NULL
						THEN 'Manual process'
					ELSE 'Automated process'
					END
			)
		,@v_ActivityHost = @@SERVERNAME
		,@v_ActivityName = 'Loaded claims_BI_ODS data into Inbound & Outbound for ' + CAST(@p_AccountingDate AS VARCHAR(10)) + ' Period'
		,@v_ActivityDateTime = GETUTCDATE()
		,@v_ActivityMessage = 'Loaded data into Inbound & Outbound Transaction for Claims_BI_ODS ' + CAST(@p_AccountingDate AS VARCHAR(10)) + ' Period'
		,@v_ActivityErrorCode = NULL
		,@v_AffectedRows = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
		,@v_ActivityLogTag
		,@v_ActivitySource
		,@v_ActivityType
		,@v_ActivityStatusStart
		,@v_ActivityHost
		,@v_ActivityDatabase
		,@v_ActivityJobId
		,@v_ActivitySSISExecutionId
		,@v_ActivityName
		,@v_ActivityDateTime
		,@v_ActivityMessage
		,@v_ActivityErrorCode
		,@v_AffectedRows
		,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;
END
