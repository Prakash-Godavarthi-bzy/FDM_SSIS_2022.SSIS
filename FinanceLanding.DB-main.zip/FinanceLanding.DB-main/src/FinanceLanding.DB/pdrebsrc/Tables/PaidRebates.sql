﻿CREATE TABLE [pdrebsrc].[PaidRebates]
(
	[PolicyRef] [varchar](50) NULL,
	[Entity] [varchar](50) NULL,
	[Value] [numeric](19, 4) NULL,
	[Trifocus] [varchar](50) NULL,
	[CCY] [varchar](50) NULL,
	[YOA] [int] NULL,
	[DateOfFact] [date] NULL,
	[SourceFile] [varchar](255) NULL
)
