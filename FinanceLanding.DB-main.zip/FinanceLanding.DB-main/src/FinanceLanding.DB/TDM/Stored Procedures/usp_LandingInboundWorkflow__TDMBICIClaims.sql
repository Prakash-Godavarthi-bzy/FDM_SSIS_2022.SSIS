﻿CREATE PROCEDURE [TDM].[usp_LandingInboundWorkflow_BICIClaims]
AS
BEGIN


	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;

	/*======================================================Logging Starts==================================================*/
	--DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'BICI TDM';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= NULL;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	DECLARE @ContractType					CHAR(3)			= NULL;
	DECLARE		@p_ParentActivityLogId		BIGINT			= NULL

	DECLARE @v_Dataset varchar(50)=@v_ActivityDatabase
	DECLARE @v_BatchId                   INT             = NULL;
	DECLARE @v_BatchId_Extensions INT;



	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';

	INSERT INTO [dbo].[Batch]([CreateDate],[DataSet]) 
	VALUES  (GETDATE(),@v_Dataset);

	SELECT @v_BatchId = SCOPE_IDENTITY();

	SET @v_ActivityJobId=@v_BatchId

	/* Log the start of the insert */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = '[TDM].[usp_LandingInboundWorkflow_BICIClaims]'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'Load data into Inbound.Transaction for TDM Claims Excel Direct Load'
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;
	
/*==================Logging End======================*/


	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		/*
=============================================================================================
	Create BatchID In landing
==============================================================================================
*/

	declare 
		 @Scenario char(1)				= 'A' 
		,@Basis char(1)					= '-'
		,@DefaultDate date				= CAST('01-01-1980' as date)
		,@TypeOfBusiness char(1)		= '-'
		,@Location char(1)				= '-'
		,@IsToDate char(1)				= 'Y'
		,@BusinessProcessCode char(2)	= 'T1'
		,@AuditHost varchar(255)		= CAST(SERVERPROPERTY('MachineName') as varchar(255))
		,@StatsCode varchar(25)			= null
		--,@DateOfFact date				= convert(date,convert(char(8),@p_AccountingPeriod * 100 + 1),112)


	

	INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, '[TDM].[usp_LandingInboundWorkflow_BICIClaims]', ' '+CONVERT(VARCHAR,@v_BatchId)+' Batch Created';

/*============================================================================================================
			INSERT INTO  Inbound.Transaction FROM FinanceLanding.BICI.TDMClaims
===============================================================================================================*/
	INSERT INTO [FinanceDataContract].[Inbound].[Transaction] WITH(TABLOCK)
			( [Scenario],[Basis],[Account],[DataSet],[DateOfFact],[BusinessKey],[PolicyNumber],[InceptionDate],[ExpiryDate],[BindDate],[DueDate],[TrifocusCode]
				,[Entity],[Location],[YOA],[TypeOfBusiness],[SettlementCCY],[OriginalCCY],[IsToDate],[Value],[ValueOrig],[RowHash],[BusinessProcessCode]
				,[AuditSourceBatchID],[AuditGenerateDateTime],[StatsCode],[FK_Batch],[DeltaType],[FK_Allocation],[AuditUserCreate],[AuditCreateDateTime],AuditHost,[BoundDate]
			)			
	SELECT 
	   Scenario=ISNULL(LTRIM(RTRIM(Scenario)),@Scenario)
	  ,Basis= ISNULL(nullif(LTRIM(RTRIM([Basis])),''),@Basis)
	  ,[Account]=LTRIM(RTRIM([Account]))
      ,[Dataset]=ISNULL(nullif(LTRIM(RTRIM([Dataset])),''),@v_Dataset)
      ,[DateOfFact]=LTRIM(RTRIM([DateOfFact]))
      ,[BusinessKey]=LTRIM(RTRIM([BusinessKey]))
      ,[PolicyNumber]=ISNULL(nullif(LTRIM(RTRIM([PolicyNumber])),''),'NOPOLICY')
      ,[InceptionDate]=ISNULL(LTRIM(RTRIM([InceptionDate])),@DefaultDate)
      ,[ExpiryDate]=ISNULL(LTRIM(RTRIM([ExpiryDate])),@DefaultDate)
      ,[BindDate]=ISNULL(LTRIM(RTRIM([BindDate])),@DefaultDate)
      ,[DueDate]=ISNULL(LTRIM(RTRIM([DueDate])),@DefaultDate)
      ,[TrifocusCode]=LTRIM(RTRIM([TrifocusCode]))
      ,CASE When Entity='US BICI' Then  'USBICI'
	      else rtrim(ltrim(Entity)) End as Entity
	  ,[Location]=ISNULL(nullif(LTRIM(RTRIM([Location])),''),@Location)
      ,[YOA]=LTRIM(RTRIM([YOA]))
      ,[TypeOfBusiness]=ISNULL(nullif(LTRIM(RTRIM([TypeOfBusiness])),''),@TypeOfBusiness)
	  ,[SettlementCCY]=LTRIM(RTRIM([SettlementCCY]))
      ,[OriginalCCY]=LTRIM(RTRIM([OriginalCCY]))
	  ,[IsToDate]=ISNULL(LTRIM(RTRIM([IsToDate])),@IsToDate)
      ,[Value]
	  ,[ValueOrig]
	  ,RowHash=HASHBYTES('SHA2_512',[ExcelRowHash])
	  ,[BusinessProcessCode]=ISNULL(nullif(LTRIM(RTRIM([BusinessProcessCode])),''),@BusinessProcessCode)
	  ,[AuditSourceBatchID]=CAST(@v_BatchId AS VARCHAR (50))
	  ,[AuditGenerateDateTime]
      ,[StatsCode]=@StatsCode 
	  ,[FK_Batch]=@v_BatchId     
      ,[DeltaType]=LTRIM(RTRIM([DeltaType]))
      ,[FK_Allocation]=null
      ,[AuditUserCreate]
	  ,[AuditCreateDateTime]=GETUTCDATE()
      ,AuditHost=@AuditHost
      ,[BoundDate]=ISNULL(nullif(LTRIM(RTRIM([BoundDate])),''),@DefaultDate)
	  
	FROM [FinanceLanding].[TDM].[BICIClaims] 
	

	--WHERE DateOfFact='2020-12-15 00:00:00.000'

		SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, '[TDM].[usp_LandingInboundWorkflow_BICIClaims]', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into Inbound.Transaction table';

		INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,RunDescription
								,[DataSet]
								,OriginalName
								,AuditSourceBatchID
								)
				VALUES
								( @v_BatchId
								 ,'InBound'
								 ,'CSV files data as source'
								 ,@v_DataSet
								 ,NULL
								 ,NULL
								)	

		-- LOG THE RESULT WITH SUCCESS
			SELECT @v_ActivityDateTime			= GETUTCDATE();

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStop
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

		IF @Trancount = 0 
		COMMIT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, '[TDM].[usp_LandingInboundWorkflow_BICIClaims]', 'TDM Claims LandingToInBound Succeeded';

		--Generate logging for success
		EXEC log.usp_LogLanding @Input = @Logging;

	END TRY

	BEGIN CATCH

		IF @Trancount = 0  
				ROLLBACK;
			
			
			-- LOG THE RESULT WITH ERROR
				UPDATE [FinanceDataContract].[Inbound].[BatchQueue]
				SET Status='OutBoundFailed'
				WHERE PK_Batch=@v_BatchId AND [Status]='InBound' AND DataSet=@v_DataSet
				
			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

			

		    THROW;

		
	END CATCH;

END;

