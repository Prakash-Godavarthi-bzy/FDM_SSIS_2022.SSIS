﻿
CREATE PROCEDURE [OP].[usp_LandingInboundWorkflow_ObligatedPremium_MunichQQS]
			@p_AccountingPeriod			INT
			--,@p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL

AS

/* =====================================================================================================================================================================================

-- Original Author:		ENTHA BHARGAV <Entha.Bhargav@beazley.com>
-- Create date: 02/08/2023
-- Description:	Original version, used to run in all the periods from 201811 to the current available period. 
--		Will run and catch up if need be (in the case of some downtime when the schedule hasn't run) and will do everything in case of a clear down.
--  Tactical to Strategic Migration under JIRA https://beazley.atlassian.net/browse/I1B-3621

--  Tables used in this Proc
--	FinanceLanding.ADM.[Reserving_data]  table Populates from FL.SSIS		FinanceLanding.SSIS\src\FinanceLanding.SSIS\IFRS17_ADMToLandingExtract.dtsx
--	FinanceLanding.MDS.ConformedEntityMapping table populates from FL.DB	FinanceLanding.DB\src\FinanceLanding.DB\ContinuousIntegration\StaticTables\MDS.ConformedEntityMapping.sql
--	FinanceLanding.fdm.DimTrifocus table Populates from FL.SSIS				FDMToLandingExtract.Dtsx

--	This will be refreshed Quarter in Arrears


-- Input periods are as 05,06,11,12 below derivations gives more detail

		 --	202005 change as 202003 and again Push forward by a Quarter becomes 202006
		 --	202006 Push forward Quarter becomes 202009
		 --	202011 as 202009 and pushh forward by Quarter becomes as 202012
		 --	202012 push forward quarter as 202103

--Version1: ENTHA BHARGAV
--Modify date: 16/11/2023
--Change Description: Scenario changed from F to A https://beazley.atlassian.net/browse/I1B-4323


Modified By:	Entha.Bhargav@beazley.com
Modified Date:		23/10/2024
Description:	 Get BID entities using office locations instead of allocating to 803. These BID entities used at Box4 in FK_SourceEntity
					https://beazley.atlassian.net/browse/I1B-5870

-- ======================================================================================================================================================================================*/
BEGIN

	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;

	/*======================================================Logging Starts==================================================*/
	--DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'ObligatedPremium_MunichQQS';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= NULL;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	DECLARE @ContractType					CHAR(3)			= 'QQS'
	DECLARE		@p_ParentActivityLogId		BIGINT			= NULL;

	DECLARE @v_Dataset						varchar(50)		=@v_ActivityDatabase
	DECLARE @v_BatchId						INT             = NULL;
	DECLARE @v_BatchId_Extensions			INT
	DECLARE @Asat			 varchar(20)			= @p_AccountingPeriod;



	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';

	INSERT INTO [dbo].[Batch]([CreateDate],[DataSet],LatestBusinesKey) 
	VALUES  (GETDATE(),@v_Dataset,cast(@Asat as VARCHAR));

	SELECT @v_BatchId = SCOPE_IDENTITY();

	SET @v_ActivityJobId=@v_BatchId

	/* Log the start of the insert */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'OP.usp_LandingIBWF_ObligatedPremium_MunichQQS'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'Load data into Inbound.Transaction for ObligatedPremium_MunichQQS'
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;
	
/*==================Logging End======================*/


	BEGIN TRY
		IF @Trancount = 0 
			BEGIN TRAN;

		/*
=============================================================================================
	Create BatchID In landing
==============================================================================================
*/

	DECLARE 
		 @Scenario char(1)				= 'A' 
		,@Basis char(1)					= 'E'
		,@PolicyNumber char(8)			= 'NOPOLICY'
		,@DefaultDate date				= CAST('01-01-1980' as date)
		,@TypeOfBusiness char(1)		= '-'
		,@Location char(1)				= '-'
		,@IsToDate char(1)				= 'Y'
		,@BusinessProcessCode char(2)	= 'T1'
		,@AuditHost varchar(255)		= CAST(SERVERPROPERTY('MachineName') as varchar(255))
		,@StatsCode varchar(25)			= null
		,@Account varchar(25)			= 'P-RP-P-TTY'
		
		
		,@DefaultGetdate datetime		= CAST(GETUTCDATE() AS datetime) 
		,@RIPolicyType varchar(15)		= 'QS'
		,@ProgrammeCode Varchar(20)		= 'MUNQQS'
		
		--,@Asat			varchar(20)			= @p_AccountingPeriod
		--, @v_dataset				VARCHAR(100)    = 'ObligatedPremium_Munich_QQS'
		--,@v_BatchId varchar(50)= NULL;
		--,@DateOfFact date				= convert(date,convert(varchar(30),(convert(varchar(30),@v_asat_RS)+'01'),12))

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'OP.usp_LandingIBWF_ObligatedPremium_MunichQQS', ' '+CONVERT(VARCHAR,@v_BatchId)+' Batch Created';
		
		if object_id('tempdb..#LandingTempQQS') is not null drop table #LandingTempQQS
	
;
WITH CTE_TempIBMunichQQS
AS (
	SELECT		TrifocusCode = tf.TrifocusCode
				,YOA
				,DateOfFact = cast(asat + '01' AS DATE)
				,Entity
				,SettlementCCY
				,BusinessKey =	isnull(ltrim(rtrim(t.Entity)), '-') + '|' + 
								isnull(ltrim(rtrim(tf.TrifocusCode)), '-') + '|' + 
								isnull(cast(ltrim(rtrim(t.YOA)) AS VARCHAR), '-') + '|' + 
								isnull(ltrim(rtrim(t.SettlementCCY)), '-')
				,InceptionDate =cast(cast(t.YOA AS VARCHAR) + CASE 
						WHEN t.YOA = 1998   
							THEN '0401'  -- Writing specific this for reason, But removal of this transformation won't be huge impact
						ELSE '0101'
						END AS DATE)  
				,ExpiryDate =cast(cast(t.YOA AS VARCHAR) + '1231' AS DATE) 
				,[value]
					--into #cte_data
					/*
					select  distinct asat
					from #cte_data
					order by asat

					drop table if exists #cte_data
					*/
	FROM (

			
				SELECT		TriFocus	= RD.triangle_group
							,YOA		= CAST(RD.yoa AS VARCHAR(5))
							,AsAt = cast ( CASE right(RD.ASAT,2) when	'05' then RD.ASAT-2
																when	'11' then  RD.ASAT-2
													         
																else RD.ASAT
												end
											As VARCHAR(20)
										 )
									
							,Entity		= case when cast(RD.synd as varchar) = '8033' 
																		then
																			 case office_location when 'PAR' then 'BIFR'
																								  when 'MUN' then 'BIGE'
																								  when 'BAR' then 'BISP'
																								  when 'ZUR' then 'BISW'
																								  when 'FAR' then 'BIUSPE'
																								  when 'LON' then 'BIUK'
																			 else 'BIUK'
																			 end
											else	en.ConformedEntityMapping
											end 
							,SettlementCCY = RD.CCY
							,[Value]	= SUM([Value])
				--	into #temp
				FROM FinanceLanding.ADM.[Reserving_data] RD
				LEFT JOIN FinanceLanding.MDS.ConformedEntityMapping en ON (  ISNULL(LTRIM(en.Entity), '') = CAST(ISNULL(LTRIM(RD.synd), '') AS VARCHAR(20))
																			 AND  cast(RD.synd as varchar) <> '8033'
																		)
				
				WHERE	(right(RD.asat, 2) IN ('05','06','11','12')									-- 05,11 periods will get more completeness of 03,06 Periods
								OR RD.asat = '202003'												-- Specific reason to include 03 instead 05 is due Covid Their is no 05 in 2020
						)																					
						AND RD.special = 'Munich'
						AND RD.datasetname = 'Team Premium'											-- Except assumptionS they not using Pure Premium, Hence Team Premium used
						AND RD.synd <> '8022'
						and rd.asat= cast( @Asat as int)											--201811 -- Debug mode 
																									-- As this is AsAT data hence we are taking from 201809/201811
						
				
				GROUP BY	RD.triangle_group
							,RD.yoa
							, cast ( case right(RD.ASAT,2) when '05' then RD.ASAT-2
															when '11' then  RD.ASAT-2
															else RD.ASAT
												end
									  as varchar(20)
									)
							
							,case when cast(RD.synd as varchar) = '8033' 
																		then
																			 case office_location when 'PAR' then 'BIFR'
																								  when 'MUN' then 'BIGE'
																								  when 'BAR' then 'BISP'
																								  when 'ZUR' then 'BISW'
																								  when 'FAR' then 'BIUSPE'
																								  when 'LON' then 'BIUK'
																			 else 'BIUK'
																			 end
											else	en.ConformedEntityMapping
											end
							,RD.CCY
							 
								
									

							/*
								select  distinct asat
								from #temp
								order by asat

								drop table if exists #temp
							*/
		) t
	LEFT JOIN FinanceLanding.fdm.DimTrifocus tf ON (tf.TrifocusName = t.TriFocus)
	
	WHERE 
		
		t.yoa >= left(t.asat, 4) - 2	-- Intention is to take Open Year of Accounts as this is derived based on YOA,AccountingPeriod fields ( YOA in relation to AP )
	) 
	
	--Debug mode
	--select*
	--into #cte_data
	--from CTE_TempIBMunichQQS
	--ORDER BY 1 DESC
	


 SELECT			TrifocusCode=t.TrifocusCode
				,Entity= t.Entity
				,YOA	= t.YOA
				,SettlementCCY=t.SettlementCCY
				,OriginalCCY=t.SettlementCCY 
				,DateOfFact= dateadd(month, 3, t.DateOfFact) 
				,BusinessKey
				,InceptionDate
				,ExpiryDate
				,RIPolicyType=@RIPolicyType 
				,ProgrammeCode=@ProgrammeCode 
				,Scenario= @Scenario
				,Account= @Account  
				,Dataset=@v_Dataset  
				,PolicyNumber= @PolicyNumber  
				,BindDate=@DefaultDate  
				,DueDate=@DefaultDate  
				,TypeOfBusiness=@TypeOfBusiness
				,StatsCode=@StatsCode 
				,[IsToDate]=@IsToDate  
				,AuditGenerateDateTime=@DefaultGetdate 
				,AuditHost=@AuditHost  
				,Basis= @Basis  
				,[Location]=@Location  
				,BusinessProcessCode= @BusinessProcessCode  
				,AuditCreateDateTime=@DefaultGetdate  
				
				,RowHash = dbo.fn_RowHashForTransactions('T' -- <@RowHashType, char(1),>
															, @Scenario --,<@Scenario, nvarchar(2000),>
															, @Account --,<@Account, nvarchar(2000),>
															, @v_Dataset --,<@DataSet, nvarchar(2000),>
															, [BusinessKey] --,<@BusinessKey, nvarchar(2000),>
															, @PolicyNumber --,<@PolicyNumber, nvarchar(2000),>
															, [InceptionDate] --,<@InceptionDate, date,>
															, [ExpiryDate] --,<@ExpiryDate, date,>
															, @DefaultDate --,<@BindDate, date,>
															, @DefaultDate --,<@DueDate, date,>
															, [TrifocusCode] --,<@TrifocusCode, nvarchar(2000),>
															, [Entity] --,<@Entity, nvarchar(2000),>
															, [YOA] --,<@YOA, nvarchar(2000),>
															, @TypeOfBusiness --,<@TypeOfBusiness, nvarchar(2000),>
															, @StatsCode --,<@StatsCode, nvarchar(2000),>
															, [SettlementCCY] --,<@SettlementCCY, nvarchar(2000),>
															, [SettlementCCY] --,<@OriginalCCY, nvarchar(2000),>
															, @IsToDate --,<@IsToDate, nvarchar(2000),>
															, @Basis --,<@Basis, nvarchar(2000),>
															, @Location --,<@Location, nvarchar(2000),>
															, @BusinessProcessCode --,<@BusinessProcessCode, nvarchar(2000),>
															, NULL --,<@BoundDate, date,>
															, CONCAT (
																		CASE 
																			WHEN @RIPolicyType IS NULL
																				THEN ''
																			ELSE (@RIPolicyType + '§~§')
																			END
																		,CASE 
																			WHEN @ProgrammeCode IS NULL
																				THEN ''
																			ELSE (@ProgrammeCode + '§~§')
																			END
																	)
														)
				,[RowHash_Transaction_ReInsurance_Extensions] = dbo.fn_RowHashForTransactions('E' /* @RowHashType */
					, @Scenario, @Account, @v_Dataset, BusinessKey, @PolicyNumber, InceptionDate, ExpiryDate, @DefaultDate, @DefaultDate,
					TrifocusCode, Entity, YOA, @TypeOfBusiness, @StatsCode, SettlementCCY, SettlementCCY, @IsToDate, @Basis, @Location
					, @BusinessProcessCode /* @BusinessProcessCode */
					, NULL /* @BoundDate */
					-- extended columns
					, CONCAT (
						CASE 
							WHEN @RIPolicyType IS NULL
								THEN ''
							ELSE (@RIPolicyType + '§~§')
							END
						,CASE 
							WHEN @ProgrammeCode IS NULL
								THEN ''
							ELSE (@ProgrammeCode + '§~§')
							END
						))
				,NULL AS FK_Allocation
				,NULL AS DeltaType
				--,NULL AS BoundDate
				,@v_BatchId AS AuditSourceBatchID
				, @v_BatchId AS FK_Batch
				,t.[Value]
				,t.[Value] AS ValueOrig

INTO			#LandingTempQQS


FROM			CTE_TempIBMunichQQS t
--left join FinanceLanding.fdm.DimTrifocus tf on (tf.TrifocusName = t.TriFocus)

WHERE			t.[value] <> 0


		SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'OP.usp_LandingIBWF_ObligatedPremium_MunichQQS', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into LandingTempQQS table for: ' +convert(varchar,@Asat);


	-- Debug mode
	--select distinct DateOfFact
	--from #LandingTempQQS
	--order by 1 desc

	 ------/* Delete the current lines from Inbound ... */
	 --DECLARE @ContractType					CHAR(3)			= 'QQS'
	 --, @v_dataset				VARCHAR(100)    = 'ObligatedPremium_Munich_QQS';

		DELETE
		FROM [FinanceDataContract].[Inbound].[Transaction]
		WHERE [DataSet] = @v_DataSet

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions_Bridge]
		WHERE [ContractType] = @ContractType

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions]
		WHERE [ContractType] = @ContractType


		INSERT INTO [dbo].[Batch]
			([CreateDate],[DataSet],[LatestBusinesKey]) 
		VALUES  
			(GETDATE(),'ReInsuranceExtensions', @Asat);

		SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();

		INSERT INTO  [FinanceDataContract].[Inbound].Transaction_ReInsurance_Extensions_Bridge
			(
				[RowHash_Transaction]
				,[RowHash_Transaction_ReInsurance_Extensions]
				,[ContractType]
				,[FK_Batch]
			)
			SELECT DISTINCT
				[RowHash]
				,[RowHash_Transaction_ReInsurance_Extensions]
				,@ContractType
				,@v_BatchId_Extensions
			FROM 
				#LandingTempQQS

			INSERT INTO  [FinanceDataContract].[Inbound].Transaction_ReInsurance_Extensions
				(
					[RowHash_Transaction_ReInsurance_Extensions]
					,[RIPolicyType]
					,[ProgrammeCode]
					--,[BeazleyCatCode]
					--,[TransactionDate]		
					,[IsLargeLoss]			
					,[ContractType]
					,[FK_Batch]
				)
				SELECT DISTINCT
					[RowHash_Transaction_ReInsurance_Extensions]
					,[RIPolicyType]
					,[ProgrammeCode]
					--,[BeazleyCatCode]
					--,[TransactionDate]		
					, NULL AS [IsLargeLoss]			
					,@ContractType
					,@v_BatchId_Extensions
				FROM 
					#LandingTempQQS
				

/*============================================================================================================
			INSERT INTO  Inbound.Transaction FROM FinanceLanding.OP.LandingObligatedPremium_Munich_QQS
===============================================================================================================*/
	INSERT INTO [FinanceDataContract].[Inbound].[Transaction] WITH(TABLOCK)
			( [Scenario],[Basis],[Account],[DataSet],[DateOfFact],[BusinessKey],[PolicyNumber],[InceptionDate],[ExpiryDate],[BindDate],[DueDate],[TrifocusCode]
				,[Entity],[Location],[YOA],[TypeOfBusiness],[SettlementCCY],[OriginalCCY],[IsToDate],[Value],[ValueOrig],[RowHash],[BusinessProcessCode]
				,[AuditSourceBatchID],[AuditGenerateDateTime],[StatsCode],[FK_Batch],[DeltaType],[FK_Allocation]
				,[AuditCreateDateTime],AuditHost
				
			)

	SELECT	 [Scenario],[Basis],[Account],[DataSet],[DateOfFact],[BusinessKey],[PolicyNumber],[InceptionDate],[ExpiryDate],[BindDate],[DueDate],[TrifocusCode]
			,[Entity],[Location],[YOA],[TypeOfBusiness],[SettlementCCY],[OriginalCCY],[IsToDate],[Value],[ValueOrig],[RowHash],[BusinessProcessCode]
			,[AuditSourceBatchID],[AuditGenerateDateTime],[StatsCode],[FK_Batch],[DeltaType],[FK_Allocation]
			,[AuditCreateDateTime],AuditHost
			 
	  FROM #LandingTempQQS
	--WHERE DateOfFact='2020-12-15 00:00:00.000'

	

		SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'OP.usp_LandingIBWF_ObligatedPremium_MunichQQS', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into Inbound.Transaction table for: ' +convert(varchar,@Asat);

		INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,RunDescription
								,[DataSet]
								--,OriginalName
								,AuditSourceBatchID
								,OriginalName
								,AsAt
								)
				VALUES
								( @v_BatchId
								 ,'InBound'
								 --,'CSV files data as source'
								 ,NULL
								 ,@v_DataSet
								-- ,NULL
								 ,NULL
								 ,@Asat
								 ,case right(@Asat,2) when '05' then @Asat+1																				-- PushForward the dates convert 05 to 03 then add a quarter to it
			                                          when '11' then  @Asat+1																				
			                                 
									else left(convert (varchar,dateadd(month, 3, cast( @asat+ '01' as date)) ,112),6)
									end
									
								)
								,

								( @v_BatchId_Extensions
								,'InBound'
								,'ReInsuranceExtensions, the additional attributes to extend functionality of the transaction table.'
								,'ReInsuranceExtensions'
								--,NULL
								,NULL
								,@Asat
								,case right(@Asat,2) when '05' then @Asat+1
			                                          when '11' then  @Asat+1
			                                 
									else left(convert (varchar,dateadd(month, 3, cast( @asat+ '01' as date)) ,112),6)
									end
								);

		-- LOG THE RESULT WITH SUCCESS
			SELECT @v_ActivityDateTime			= GETUTCDATE();

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStop
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

		IF @Trancount = 0 
		COMMIT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, 'OP.usp_LandingIBWF_ObligatedPremium_MunichQQS', 'Push forward Quarter For'+convert(varchar,@Asat)+':OP_ObligatedPremium_MunichQQS LandingToInBound Succeeded';

		--Generate logging for success
		EXEC log.usp_LogLanding @Input = @Logging;

	END TRY

	BEGIN CATCH

		IF @Trancount = 0  
				ROLLBACK;
			
			-- LOG THE RESULT WITH ERROR--
				UPDATE [FinanceDataContract].[Inbound].[BatchQueue]
				SET Status='OutBoundFailed'
				WHERE PK_Batch=@v_BatchId AND [Status]='InBound' AND DataSet=@v_DataSet


			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

			

		    THROW;

		
	END CATCH;

END;