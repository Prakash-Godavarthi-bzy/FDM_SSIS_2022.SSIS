﻿CREATE TABLE [ADM].[Reserving_data] (
    [asat]            INT            NULL,
    [att_cat]         NVARCHAR (11)  NULL,
    [ccy]             NVARCHAR (7)   NULL,
    [datasetgroup]    CHAR (50)      NULL,
    [datasetname]     NVARCHAR (100) NULL,
    [department]      NVARCHAR (30)  NULL,
    [gross_ri]        NVARCHAR (5)   NULL,
    [office_location] CHAR (3)       NULL,
    [special]         NVARCHAR (50)  NULL,
    [Synd]            INT            NULL,
    [triangle_group]  NVARCHAR (50)  NULL,
    [value]           MONEY          NULL,
    [yoa]             INT            NULL,
    [id]              INT            NOT NULL,
	[IFRS17_mapping] nvarchar(255)   NULL
    CONSTRAINT [PK_Reserving_data] PRIMARY KEY CLUSTERED ([id] ASC) WITH (FILLFACTOR = 90)
);

