﻿CREATE TABLE [ADM].[ReservingDataEventAlloc](
	[PK_Transaction] [int] IDENTITY(1,1) NOT NULL,
	[DOF] [datetime] NULL,
	[asat] [int] NULL,
	[Scenario] [varchar](50) NULL,
	[Account] [varchar](50) NULL,
	[Dataset] [varchar](50) NULL,
	[BusinessKey] [varchar](255) NULL,
	[PolicyNumber] [varchar](50) NULL,
	[InceptionDate] [datetime] NULL,
	[ExpiryDate] [datetime] NULL,
	[BindDate] [datetime] NULL,
	[DueDate] [datetime] NULL,
	[TrifocusCode] [varchar](50) NULL,
	[Entity] [varchar](50) NULL,
	[YOA] [int] NULL,
	[TypeOfBusiness] [varchar](50) NULL,
	[StatsCode] [varchar](50) NULL,
	[SettlementCCY] [varchar](50) NULL,
	[OriginalCCY] [varchar](50) NULL,
	[IsToDate] [varchar](1) NULL,
	[Value] [numeric](38, 12) NULL,
	[RowHash] [varchar](255) NULL,
	[FK_Allocation] [int] NULL,
	[Basis] [varchar](50) NULL,
	[Location] [varchar](50) NULL,
	[BusinessProcessCode] [varchar](50) NULL,
	[FK_Batch] [int] NULL,
	[BoundDate] [datetime] NULL,
	[BeazleyCatCode] [varchar](50) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [varchar](255) NOT NULL,
	[AuditHost] [varchar](255) NOT NULL,
) ON [PRIMARY]
GO

ALTER TABLE [ADM].[ReservingDataEventAlloc] ADD  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [ADM].[ReservingDataEventAlloc] ADD  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [ADM].[ReservingDataEventAlloc] ADD  DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO
