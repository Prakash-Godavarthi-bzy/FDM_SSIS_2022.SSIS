﻿
CREATE TABLE [ADM].[GroupActuaries_IFRS17_Mappings](
	[Special] [nvarchar](255) NOT NULL,
	[IFRS17_mapping] [nvarchar](255) NOT NULL
) ON [PRIMARY]