﻿CREATE TABLE [ADM].[DFMS_all] (
    [DatasetName]       TEXT            NULL,
    [DateStamp]         TEXT            NULL,
    [DevelopmentPeriod] INT             NULL,
    [ProjectName]       TEXT            NULL,
    [ReservingClass2]   TEXT            NULL,
    [ReservingClass3]   TEXT            NULL,
    [ReservingClass4]   TEXT            NULL,
    [Value]             DECIMAL (10, 6) NULL,
    [ReservingClass1]   TEXT            NULL
);

