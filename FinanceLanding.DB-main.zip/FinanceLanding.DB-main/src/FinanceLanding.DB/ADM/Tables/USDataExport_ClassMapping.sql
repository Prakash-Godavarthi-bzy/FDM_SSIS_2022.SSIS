﻿CREATE TABLE [ADM].[USDataExport_ClassMapping] (
    [ClassNumber]    SMALLINT       NULL,
    [Dept]           NVARCHAR (255) NULL,
    [Reserving_Name] NVARCHAR (255) NULL,
    [ResQUSSLTriGrp] NVARCHAR (255) NULL,
    [RI_Name]        NVARCHAR (255) NULL,
    [USTriGrp]       NVARCHAR (255) NOT NULL,
    [WiziDept]       VARCHAR (59)   NULL,
    [WiziName]       NVARCHAR (255) NULL,
    CONSTRAINT [PK_USDataExport_ClassMapping] PRIMARY KEY CLUSTERED ([USTriGrp] ASC) WITH (FILLFACTOR = 90)
);

