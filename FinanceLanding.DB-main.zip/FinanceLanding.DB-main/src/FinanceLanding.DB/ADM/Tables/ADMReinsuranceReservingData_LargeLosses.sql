﻿CREATE TABLE [ADM].[ADMReinsuranceReservingData_LargeLosses] (
    [PK_Transaction]        INT              IDENTITY (1, 1) NOT NULL,
    [DOF]                   DATETIME         NULL,
    [asat]                  INT              NULL,
    [Scenario]              VARCHAR (50)     NULL,
    [Account]               VARCHAR (50)     NULL,
    [Dataset]               VARCHAR (50)     NULL,
    [BusinessKey]           VARCHAR (255)    NULL,
    [PolicyNumber]          VARCHAR (255)    NULL,
    [InceptionDate]         DATETIME         NULL,
    [ExpiryDate]            DATETIME         NULL,
    [BindDate]              DATETIME         NULL,
    [DueDate]               DATETIME         NULL,
    [TrifocusCode]          VARCHAR (50)     NULL,
    [Entity]                VARCHAR (50)     NULL,
    [YOA]                   INT              NULL,
    [TypeOfBusiness]        VARCHAR (50)     NULL,
    [StatsCode]             VARCHAR (50)     NULL,
    [SettlementCCY]         VARCHAR (50)     NULL,
    [OriginalCCY]           VARCHAR (50)     NULL,
    [IsToDate]              VARCHAR (1)      NULL,
    [Value]                 NUMERIC (38, 12) NULL,
    [RowHash]               VARCHAR (255)    NULL,
    [FK_Allocation]         INT              NULL,
    [Basis]                 VARCHAR (50)     NULL,
    [Location]              VARCHAR (50)     NULL,
    [BusinessProcessCode]   VARCHAR (255)    NULL,
    [FK_Batch]              INT              NULL,
    [BoundDate]             DATETIME         NULL,
    [BeazleyCatCode]        VARCHAR (50)     NULL,
    [AuditCreateDateTime]   DATETIME         CONSTRAINT [DF_ADMReinsuranceReservingData_LargeLosses_ADM_AuditCreateDateTime] DEFAULT (getutcdate()) NOT NULL,
    [AuditGenerateDateTime] DATETIME         CONSTRAINT [DF_ADMReinsuranceReservingData_LargeLosses_ADM_AuditGenerateDateTime] DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]       VARCHAR (255)    CONSTRAINT [DF_ADMReinsuranceReservingData_LargeLosses_ADM_AuditUserCreate] DEFAULT (suser_sname()) NOT NULL,
    [AuditHost]             VARCHAR (255)    CONSTRAINT [DF_ADMReinsuranceReservingData_LargeLosses_ADM_AuditHost] DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))) NOT NULL,
    [RIPolicyType]          VARCHAR (50)     NULL,
    [ProgrammeCode]         VARCHAR (100)    NULL
);


GO


GO


GO


GO


GO



