﻿
CREATE PROCEDURE [ADM].[usp_LandingToInboundToOutbound_ReinsuranceReservingDataLargeLosses_ADM] 
             @p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL

/*
Modified By:	ShahNawaz.Ahmed@beazley.com
Modified Date:		23/10/2024
Description:	 Created this proc to convert ResDataRILargeLossAlloc Tactical to Strategic (partial), by passing balances through GAAP proc to generate deltas
					https://beazley.atlassian.net/browse/I1B-5410
-- ======================================================================================================================================================================================*/

AS

BEGIN

	SET NOCOUNT ON;
	
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'ResDataRILargeLossAlloc';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	DECLARE @v_DataSet VARCHAR(255)	= @v_ActivityDatabase

	DECLARE @v_AccountingPeriod                   INT             = NULL;
	DECLARE @v_AccountingPeriod_Default           INT             = 201806; -- this is our starting date

BEGIN TRY  

	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';



	/* Log the start of the process */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	
	
	,@v_ActivityName				    = 'Load data into Inbound.Transaction and Outbound.Transaction using [ADM].[usp_LandingToInboundToOutbound_ReinsuranceReservingDataLargeLosses_ADM]  '
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= ''
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

	-- Get the last processed date for data from the outbound table. 
	-- We'll then process these, so we get all the records for the current month or the last month and process these.
	-- In the case that we're doing day one, we will have zero records in the outbound, so we need to get them all from our default starting date.

	select @v_AccountingPeriod = isnull(cast(convert(varchar(6),max(DateOfFact),112)  as int),@v_AccountingPeriod_Default)
	from [FinanceDataContract].[Outbound].[Transaction]
	where Dataset = @v_DataSet

	--select @v_AccountingPeriod=201903
	
	declare @Dates table(Asat int, i int identity(1,1))
	insert into @Dates(Asat)
	
	select distinct cast(convert(varchar(6),dof,112)  as int)
	from    [ADM].[ADMReinsuranceReservingData_LargeLosses] rd
	where cast(convert(varchar(6),dof,112)  as int) > @v_AccountingPeriod
	order by 1

	declare @i int = 1

	while exists(select 1 from @Dates where i=@i)
	begin

		set @v_AccountingPeriod = (select Asat from @Dates where i=@i)

		select [@v_AccountingPeriod] = @v_AccountingPeriod 

		exec FinanceLanding.[ADM].[usp_LandingInboundWorkflow_ReinsuranceReservingDataLargeLosses_ADM]
			@p_AccountingPeriod	= @v_AccountingPeriod
    

		print 'EXEC [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_GAAP'
		if exists(select 1 from [FinanceDataContract].Inbound.[Transaction] where DataSet = @v_DataSet)
		begin
			exec [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_ReInsuranceExtensions]
			exec [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_GAAP] @DoNonIFRS17_Tests = 0
		end
		
		set @i += 1

	end


	-- LOG THE RESULT WITH SUCCESS
	SELECT @v_ActivityDateTime			= GETUTCDATE();

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
			 @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStop
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;


END TRY

BEGIN CATCH
			        
			-- LOG THE RESULT WITH ERROR

			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

		    THROW;

END CATCH;

					
END