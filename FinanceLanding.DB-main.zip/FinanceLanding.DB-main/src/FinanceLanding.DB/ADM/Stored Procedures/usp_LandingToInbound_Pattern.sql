﻿

CREATE PROCEDURE [ADM].[usp_LandingToInbound_Pattern]

             @p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL

AS
-- =============================================

-- http://git.bfl.local/Finance/FinanceLanding.DB
-- Unit tested via script(\src\FinanceLanding.DB\UnitTests\DfmsAll_LandingToInbound.sql )

-- Original Author:		Ionela Ciornei <Ionela-Minodora.Ciornei@beazley.com>
-- Create date: 11/02/2020
-- Description:	Loads ADM data from FinanceLanding to Inbound.Pattern

-- Last Modified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 18/02/2020
-- Description:	Coded review changes, comments inline.

-- Last Modified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 08/01/2021
-- Description:	The calculation for DevelopmentPercentageIncrement is partitioning without using the TriFocusCode, 
--				so the output can become zero which is then filtered out of the end result. 

-- Last Modified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 24/02/2021
-- Description:	Now using the [ADM_DFMS].[Mapping] table to map [ReservingClass2] to [TriFocusCode]

-- LastModified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 06/04/2021
-- Description:	Changed the business key to include the SubmissionIdentifier.
--				

-- LastModified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 23/06/2021
-- Description:	Removed the pattern mapping code as the table isn't used.
--				

-- =============================================		
BEGIN

		SET NOCOUNT ON

		DECLARE @v_ErrorMessage NVARCHAR(4000)
		DECLARE @Trancount	INT = @@Trancount
		DECLARE @v_RC							INT
		DECLARE @v_ActivityLogTag				BIGINT
		DECLARE @v_ActivitySource				SMALLINT
		DECLARE @v_ActivityType					SMALLINT
		DECLARE @v_ActivityStatusStart			SMALLINT
		DECLARE @v_ActivityStatusStop			SMALLINT
		DECLARE @v_ActivityStatusFail			SMALLINT
		DECLARE @v_ActivityHost					VARCHAR(100)
		DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'ADM-DFMs'
		DECLARE @v_ActivityName					VARCHAR(100)
		DECLARE @v_ActivityDateTime				DATETIME2(2)
		DECLARE @v_ActivityMessage				NVARCHAR(4000)
		DECLARE @v_ActivityErrorCode			NVARCHAR(50)
		DECLARE @v_ActivityLogIdIn				BIGINT
		DECLARE @v_ActivityLogIdOut				BIGINT
		DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId
		DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL
		DECLARE @v_AffectedRows					INT             = 0
		DECLARE @v_BatchId                      INT             = NULL
		DECLARE @v_Asat                         INT             = NULL

		DECLARE @v_MaxAuditGenerateDate         DATETIME2       = NULL
		DECLARE @v_AuditConcat                  NVARCHAR(4000)
		declare @DataSet varchar(50) = @v_ActivityDatabase

		 
  BEGIN TRY	
		-- Set the login variables needed for logging

		SELECT   
		    @v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
		   ,@v_ActivityType				    = (SELECT PK_ActivityType	
											   FROM Orchestram.Log.ActivityType	
											   WHERE ActivityType = CASE 
																	WHEN @p_ParentActivityLogId IS NULL 
																		THEN 'Manual process' 
																		ELSE 'Automated process' 
																	END)
		   ,@v_ActivityHost				    = @@SERVERNAME
		   ,@v_ActivityName				    = 'Load data into Inbound.Pattern'
		   ,@v_ActivityDateTime			    = GETUTCDATE()

		SELECT @v_ActivityStatusStart = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'STARTED'

		SELECT @v_ActivityStatusStop = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'SUCCEEDED'

		SELECT @v_ActivityStatusFail = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'ERRORED'


		if object_id('tempdb..#Outbound_Pattern') is not null drop table #Outbound_Pattern
		select distinct PatternScenario,PatternScenarioVersion
		into #Outbound_Pattern
		from [FinanceDataContract].[Outbound].[Pattern] op
		where op.DataSet = @DataSet

		create unique clustered index ix on #Outbound_Pattern(PatternScenarioVersion,PatternScenario)


		if object_id('tempdb..#DFMS_all') is not null drop table #DFMS_all
		select
			[PatternScenarioVersion] = s.SubmissionVersion
			,m.TriFocusCode
			,s.SubmissionIdentifier
			,df.*
		into
			#DFMS_all
		from	
			(
				SELECT 
					[ReservingClass1]		= CONVERT(VARCHAR(255), [ReservingClass1])
					,[ReservingClass2]		= CONVERT(VARCHAR(255), [ReservingClass2])
					,[ReservingClass3]		= CONVERT(VARCHAR(255), [ReservingClass3])
					,[ReservingClass4]		= CONVERT(VARCHAR(255), [ReservingClass4]) 
					,[DatasetName]			= CONVERT(VARCHAR(255), [DatasetName])
					,[PatternScenario]		= CONVERT(VARCHAR(255), [ProjectName])
					,[SubmissionYear]		= convert(int, '20' + left(CONVERT(VARCHAR(255), [ProjectName]),2))
					,[SubmissionQuarter]	= convert(int,RIGHT(CONVERT(VARCHAR(255), [ProjectName]),1))
					,[DevelopmentPeriod]	= [DevelopmentPeriod]
					,[Value]				= ISNULL([Value],0.00)
					,[DateStamp]			= CONVERT(DATETIME2, CONVERT(VARCHAR(255), [DateStamp]), 103)
				FROM 
					[ADM].[DFMS_all]
				where
					CONVERT(VARCHAR(255), [ReservingClass3]) <> 'Net'
					--AND CONVERT(VARCHAR(255), [ProjectName]) >= '19Q1'
					AND 'Department Total' != CONVERT(VARCHAR(255), [ReservingClass2]) -- this is a hard-coded work around as department total maps to every tri-focus which would double account values.
			) df
			join [ADM_DFMS].[Control] s
				on  s.SubmissionYear = df.SubmissionYear
				and s.SubmissionQuarter = df.SubmissionQuarter		
			join [ADM_DFMS].[Mapping] m 
				on  m.SubmissionIdentifier = s.SubmissionIdentifier
				and m.ADM_ReservingClass2 = df.ReservingClass2
		where
			m.ReportPattern = 'Y'
			-- check to see that we haven't run the data in for the version.
			and not exists
			(
				select 1
				from #Outbound_Pattern op
				where
					op.PatternScenario = df.PatternScenario
					and op.PatternScenarioVersion = s.SubmissionVersion
			)


		/* Log the start of the insert */

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStart
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT

		SELECT @v_ActivityLogTag = @v_ActivityLogIdIn


		--select * from #DFMS_all
		--select * from #Outbound_Pattern
		--return


		IF NOT EXISTS (SELECT 1 FROM #DFMS_all)

		BEGIN
			
			select 'no data, will exit'

			-- LOGIN THE RESULT WITH SUCCESS
				SELECT @v_ActivityDateTime			= GETUTCDATE()

				EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
						@p_ParentActivityLogId
						,@v_ActivityLogTag
						,@v_ActivitySource
						,@v_ActivityType
						,@v_ActivityStatusStop
						,@v_ActivityHost
						,@v_ActivityDatabase
						,@v_ActivityJobId
						,@v_ActivitySSISExecutionId
						,@v_ActivityName
						,@v_ActivityDateTime
						,@v_ActivityMessage
						,@v_ActivityErrorCode
						,@v_AffectedRows
						,@v_ActivityLogIdIn OUTPUT

			RETURN
		END

		/* Insert a new batch for DFMS_all datasource table*/
		INSERT INTO [dbo].[Batch]
			([CreateDate],[DataSEt],[LatestBusinesKey]) 

		VALUES  
			(GETDATE(),@DataSet, 'DFMS_all')
	
		SELECT @v_BatchId = SCOPE_IDENTITY()


		
		---------------------------------------------------------------------------------
		-- Start of Pattern Mapping
		---------------------------------------------------------------------------------

		select *
		into #PatternMapping
		from
		(
			SELECT DISTINCT             
					L1 = rd.DatasetName
					,L2 = rd.ReservingClass3
					,L3 = 'PP'
					,PatternKey = CASE
								  WHEN rd.DatasetName LIKE 'Pure%Premium' THEN 'P-'
								  WHEN rd.DatasetName LIKE 'Pure%Paid' THEN 'C-'
								  END +
								  CASE
								  WHEN rd.ReservingClass3 = 'Gross' THEN 'G'
								  WHEN rd.ReservingClass3 = 'RI' THEN 'R'
								  END +
								  CASE
								  WHEN rd.DatasetName LIKE 'Pure%Premium' THEN 'P-'
								  WHEN rd.DatasetName LIKE 'Pure%Paid' THEN 'C-'
								  END +
								  'PP'

	 		 FROM    #DFMS_all rd

			 UNION ALL

			 SELECT DISTINCT             
					L1 = rd.DatasetName
					,L2 = rd.ReservingClass3
					,L3 = 'BP'
					,PatternKey = CASE
								  WHEN rd.DatasetName LIKE 'Pure%Premium' THEN 'P-'
								  END +
								  CASE
								  WHEN rd.ReservingClass3 = 'Gross' THEN 'G'
								  END +
								  CASE
								  WHEN rd.DatasetName LIKE 'Pure%Premium' THEN 'P-'
								  END +
								  'BP'

	 		 FROM    #DFMS_all rd

	     ) s

		-------------------------------------------------------------------------------
		-- End of Account Mapping
		-------------------------------------------------------------------------------

		-- temp table to be populated

		DROP TABLE IF EXISTS #TempInboundPattern

             SELECT * 

			 INTO #TempInboundPattern

			 FROM
				(SELECT 
						 PatternScenario                   = CAST(rd.PatternScenario AS VARCHAR(10))                 
						,PatternScenarioVersion            = CAST(rd.PatternScenarioVersion AS INT)
						,PatternKey                        = CAST(ISNULL(am.PatternKey,'X-XX-XX') AS VARCHAR(10))
						,DataSet                           = @DataSet --'ADM'
						,TrifocusCode                      = CAST(ISNULL(rd.TriFocusCode,'UNKNOWN') AS VARCHAR(100))
						,[YOA]                             = 'NOYOA'
			            ,InceptionYear                     = 0
			            ,[SettlementCCY]                   ='UNK'
						,DevelopmentPercentageIncrement    = CAST((rd.[Value]-LAG(rd.[Value], 1, 0.00) OVER (PARTITION BY  rd.ReservingClass1
                                                                                                                    ,rd.ReservingClass2
                                                                                                                    ,rd.ReservingClass3
                                                                                                                    ,rd.ReservingClass4
                                                                                                                    ,rd.DatasetName
                                                                                                                    ,rd.PatternScenario
																													,rd.TriFocusCode
																													,rd.PatternScenarioVersion
  			                                                                                           ORDER BY      rd.DevelopmentPeriod,rd.TriFocusCode,rd.PatternScenarioVersion
																									   ) ) AS NUMERIC (19,6) )
						,DevelopmentQuarter                = CAST(rd.DevelopmentPeriod AS INT)
						,AuditSourceBatchID                = CAST(@v_BatchId AS VARCHAR(50))
						,AuditHost                         = CAST(SERVERPROPERTY('MachineName') AS VARCHAR(255))
						,AuditGenerateDateTime             = rd.DateStamp
						,FK_Batch                          = @v_BatchId
						,BusinessProcessCode               = 'T1'
						,BusinessKey                       = CONCAT
															(
																rd.DatasetName,'-',rd.ReservingClass1,'-',rd.ReservingClass2,'-',rd.ReservingClass3, '-'
																,rd.ReservingClass4, '-',rd.PatternScenario,'-',rd.SubmissionIdentifier
															)
           

				FROM    #DFMS_all rd

				LEFT JOIN   #PatternMapping am
				ON          am.l1 = rd.DatasetName
				AND         am.l2 = rd.ReservingClass3
				AND         am.l3 = 'PP'

                WHERE       rd.ReservingClass2 NOT LIKE 'BID %'  -- remove BID classes from this release, they need special handling
				AND         rd.ReservingClass3 <>'RI'
         
		 UNION ALL

				SELECT 
						 PatternScenario                   = CAST(rd.PatternScenario AS VARCHAR(10))                 
						,PatternScenarioVersion            = CAST(rd.PatternScenarioVersion AS INT)
						,PatternName                       = CAST(ISNULL(am.PatternKey,'X-XX-XX') AS VARCHAR(10))
						,DataSet                           = @DataSet --'ADM'
						,TrifocusCode                      = CAST(ISNULL(rd.TriFocusCode,'UNKNOWN') AS VARCHAR(100))
						,[YOA]                             = 'NOYOA'
			            ,InceptionYear                     = 0
			            ,[SettlementCCY]                   ='UNK'
						,DevelopmentPercentageIncrement    = CAST((rd.[Value]-LAG(rd.[Value], 1, 0.00) OVER (PARTITION BY  rd.ReservingClass1
                                                                                                                    ,rd.ReservingClass2
                                                                                                                    ,rd.ReservingClass3
                                                                                                                    ,rd.ReservingClass4
                                                                                                                    ,rd.DatasetName
                                                                                                                    ,rd.PatternScenario
																													,rd.TriFocusCode 
																													,rd.PatternScenarioVersion
  			                                                                                           ORDER BY      rd.DevelopmentPeriod,rd.TriFocusCode,rd.PatternScenarioVersion
																									   ) ) AS NUMERIC (19,6) )
						,DevelopmentQuarter                = CAST(rd.DevelopmentPeriod AS INT)
						,AuditSourceBatchID                = CAST(@v_BatchId AS VARCHAR(50))
						,AuditHost                         = CAST(SERVERPROPERTY('MachineName') AS VARCHAR(255))
						,AuditGenerateDateTime             = rd.DateStamp
						,FK_Batch                          = @v_BatchId
						,BusinessProcessCode               = 'T1'
						,BusinessKey                       = CONCAT
															(
																rd.DatasetName,'-',rd.ReservingClass1,'-',rd.ReservingClass2,'-',rd.ReservingClass3, '-'
																,rd.ReservingClass4, '-',rd.PatternScenario,'-',rd.SubmissionIdentifier
															)

				FROM    #DFMS_all rd

				LEFT JOIN   #PatternMapping am
				ON          am.l1 = rd.DatasetName
				AND         am.l2 = rd.ReservingClass3
				AND         am.l3 = 'BP'

                WHERE       rd.ReservingClass2 NOT LIKE 'BID %'  -- remove BID classes from this release, they need special handling
				AND         rd.ReservingClass3 <>'RI'
				AND         rd.DatasetName LIKE 'Pure%Premium' 
				AND         rd.ReservingClass3 = 'Gross'
				) a
				  

		 
			IF @Trancount = 0 

				BEGIN TRAN;

				/* Delete the current lines of the ADM source system from Inbound ... */

				DELETE 
					
				FROM    FinanceDataContract.Inbound.[Pattern]
					
				WHERE   DataSet = @DataSet
						

				INSERT INTO [FinanceDataContract].[Inbound].[Pattern] WITH(TABLOCK)
						([PatternScenario]             
						,[PatternScenarioVersion]      
						,[PatternKey]                    
						,[DataSet]                         
						,[TrifocusCode] 
						,[YOA]
			            ,InceptionYear 
			            ,[SettlementCCY]                      
						,[DevelopmentPercentageIncrement]                   
						,[DevelopmentQuarter]        
						,[AuditSourceBatchID]
						,[AuditHost]
						,[AuditGenerateDateTime]
						,[FK_Batch]
						,BusinessProcessCode 
						,BusinessKey
						)		
			  
				SELECT   [PatternScenario]             
						,[PatternScenarioVersion]      
						,[PatternKey]                    
						,[DataSet]                        
						,[TrifocusCode] 
						,[YOA]
			            ,InceptionYear 
			            ,[SettlementCCY]                  
						,[DevelopmentPercentageIncrement]                     
						,[DevelopmentQuarter]        
						,[AuditSourceBatchID]
						,[AuditHost]
						,[AuditGenerateDateTime]
						,[FK_Batch]
						,BusinessProcessCode 
                        ,BusinessKey
						   
				FROM    #TempInboundPattern

			    WHERE   DevelopmentPercentageIncrement <> 0


				SELECT   @v_AffectedRows			= @@ROWCOUNT
	
				/* Add the batch to the queue */

				INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
							( Pk_Batch
							,[Status]
							,DataSet
							,RunDescription
							,OriginalName
							)
				VALUES
							(@v_BatchId
							,'InBound'
							,@DataSet
							,'Pattern'
							,NULL
							);
      
				-- LOGIN THE RESULT WITH SUCCESS
				SELECT @v_ActivityDateTime			= GETUTCDATE()

				EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
						@p_ParentActivityLogId
						,@v_ActivityLogTag
						,@v_ActivitySource
						,@v_ActivityType
						,@v_ActivityStatusStop
						,@v_ActivityHost
						,@v_ActivityDatabase
						,@v_ActivityJobId
						,@v_ActivitySSISExecutionId
						,@v_ActivityName
						,@v_ActivityDateTime
						,@v_ActivityMessage
						,@v_ActivityErrorCode
						,@v_AffectedRows
						,@v_ActivityLogIdIn OUTPUT

            IF @Trancount = 0 

				COMMIT;

			END TRY

			BEGIN CATCH
	
		    -- CANCEL TRAN
			IF @Trancount = 0 AND @@TRANCOUNT <> 0
				ROLLBACK;
			        
				-- LOGIN THE RESULT WITH ERROR

				SELECT   @v_ActivityDateTime				= GETUTCDATE()
						,@v_ActivityLogTag					= @v_ActivityLogIdIn
						,@v_ActivityMessage					= ERROR_MESSAGE()
						,@v_ActivityErrorCode				= ERROR_NUMBER()

				EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
						 @p_ParentActivityLogId
						,@v_ActivityLogTag
						,@v_ActivitySource
						,@v_ActivityType
						,@v_ActivityStatusFail
						,@v_ActivityHost
						,@v_ActivityDatabase
						,@v_ActivityJobId
						,@v_ActivitySSISExecutionId
						,@v_ActivityName
						,@v_ActivityDateTime
						,@v_ActivityMessage
						,@v_ActivityErrorCode
						,@v_AffectedRows
						,@v_ActivityLogIdIn OUTPUT;

            THROW;

			END CATCH

					
END

GO



--exec [ADM].[usp_LandingToInbound_Pattern]

--GO

--exec [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_Pattern] 
--GO

-- rollback