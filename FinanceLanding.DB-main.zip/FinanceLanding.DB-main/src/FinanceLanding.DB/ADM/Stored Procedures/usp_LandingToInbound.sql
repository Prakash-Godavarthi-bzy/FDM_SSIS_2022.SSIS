﻿CREATE PROCEDURE [ADM].[usp_LandingToInbound]
			 @p_Asat_RS int
			,@p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL

AS
-- =============================================

-- Description:	Loads ADM reserving data from FinanceLanding to Inbound.Transaction
-- Loads the following datasets: 'ReservingData' to Inbound.Transaction 
-- & 'Reserving_ReInsuranceExtensions' to Inbound.Transaction_Reserving_ReInsurance_Extensions & Inbound.Transaction_Reserving_ReInsurance_Extensions_Bridge.


-- http://git.bfl.local/Finance/FinanceLanding.DB
-- Unit tested via script(\src\FinanceLanding.DB\UnitTests\ReservingData_LandingToInbound.sql & \src\FinanceLanding.DB\UnitTests\TpOutput_LandingToInbound.sql)
-- unit test obsolete as of 19/08/2021; needs to be upgraded

-- Original Author:		Ionela Ciornei <Ionela-Minodora.Ciornei@beazley.com>
-- Create date: 11/02/2020
-- Description:	Loads ADM reserving data from FinanceLanding to Inbound.Transaction

-- 	loads the following datasets: 'ReservingData' to Inbound.Transaction & 'Reserving_ReInsuranceExtensions' to Inbound.Transaction_Reserving_ReInsurance_Extensions.


-- Modified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 18/02/2020
-- Description:	Coded review changes, comments inline.

-- LastModified by Author:		Ionela Ciornei <Ionela-Minodora.Ciornei@beazley.com>
-- Modified date: 14/05/2020
-- Description:	Add RI data for ReservingData

-- LastModified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 13/08/2020
-- Description:	Functionality added for signage.

-- LastModified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 25/08/2020
-- Description:	The business key had a char datatype in it which needed to be rtrim()'ed to match requirements for the key and the RowHash.

-- LastModified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 21/01/2021
-- Description:	The procedure needed to change so it is called by a handling procedure as this handling procedure will input the two dates for reserverving and technical outputs.
--				The handling procedure - [ADM].[usp_LandingToInboundToOutbound] - also calls the inbound to outbound procedure as it can handle a catch up and day one scenarios.

-- LastModified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 26/02/2021
-- Description:	Changed to get the tri-focus from [ADM_RES_DAT].[Mapping] table for reserving data & [ADM_TP_Output].[Mapping] for technical provisions.
--				
-- LastModified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 06/04/2021
-- Description:	Changed the business key to include the SubmissionIdentifier.
--				
--				
-- LastModified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 11/05/2021
-- Description:	Changed the business key to include the AsAt column.
--				Removed the Technical Outputs code as this is no longer required.
--				Changed the join to get the tri-focus to get from the MDS table, the mapping tables are no longer required.
--				
-- LastModified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 11/08/2021
-- Description:	Added Extensions.
--				
-- LastModified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 02/09/2021
-- Description:	Removed the AsAt column from the business key so that the outbound process can detect changes using the row hash and make adjustments accordingly.
--				Added the datasetgroup to the business key as it was missing.
--				Added the new column trianglegroup to the extensions table.
--				
-- LastModified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 14/09/2021
-- Description:	Modified code to do reversals, so that we add a record to the inbound for the current period with a zero value when a combination is missing. 
--				Without this the [Inbound].[usp_InboundOutboundWorkflow] would create a reversal but use the existing DateOfFact which would be wrong.
-- LastModified by Author:	Charvitha Sadhu <Charvitha.Sadhu@beazley.com>
-- Modified date: 14/09/2022
-- Description:	 Modified the code to populate data for assat Period 5 → Review Cycle Q1, Asat Period 6 → Review Cycle Q2 Asat Period 11 → Review Cycle Q3
--               Asat Period 12 → Review Cycle Q4 and added the ASAT field for BatchQueue table. These changes are done based on 
--               https://beazley.atlassian.net/browse/I1B-3089	
--	
-- LastModified by Author:		Nikil chowdary Nallamothu <Nikil.Nallamothu@beazley.com>
-- Modified date: 15/11/2022
-- Description:	Replaced the Mds.Trifocus table with fdm.DimTrifocus table by looking up against the ADM.Reserving_data table done as part of the ticket I1B-3434.
-- =============================================	
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'ADM';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT

	DECLARE @v_BatchId_RS                   INT             = NULL;
	DECLARE @v_BatchId_Ext                  INT             = NULL;
	DECLARE @v_Asat_RS                      INT             = @p_Asat_RS;

BEGIN TRY

	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';

	declare @dataset_ReservingData varchar(50) = 'ReservingData'
	declare @dataset_Reserving_ReInsuranceExtensions varchar(50) = 'Reserving_ReInsuranceExtensions'

	/* Insert a new batch for Reserving_date datasource table*/
	IF @v_Asat_RS IS NOT NULL
	   BEGIN

			INSERT INTO [dbo].[Batch]([CreateDate],[DataSet],[LatestBusinesKey]) VALUES  (GETDATE(),@dataset_Reserving_ReInsuranceExtensions, @v_Asat_RS);	
			SELECT @v_BatchId_Ext = SCOPE_IDENTITY();
			--SELECT @v_BatchId_Ext

			INSERT INTO [dbo].[Batch]([CreateDate],[DataSet],[LatestBusinesKey]) VALUES  (GETDATE(),@dataset_ReservingData, @v_Asat_RS);	
			SELECT @v_BatchId_RS = SCOPE_IDENTITY();

	   END

	/* Log the start of the insert */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'Load data into Inbound.Transaction'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'AsAt ReservingData:' + ISNULL(CAST(@v_Asat_RS AS VARCHAR(50)),'0')
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

	-- populate account mapping for ADM.Reserving_data 

	MERGE INTO   [MDS].[AccountMapping] AS Target

	USING

	(SELECT DISTINCT                     
				   [table] = 'ReservingData'
				   ,L1     = rd.gross_ri
				   ,L2     = rd.datasetgroup
				   ,L3     = rd.datasetname
				   ,AccountKey = 
				    CASE
						WHEN rd.gross_ri = 'Gross' THEN 'G'
						WHEN rd.gross_ri = 'RI'    THEN 'R'
									
					END +
					CASE
						WHEN rd.datasetgroup LIKE '%Claims' THEN 'C-'
						WHEN rd.datasetgroup LIKE '%Premium' THEN 'P-'

					END +
					CASE
						WHEN rd.datasetgroup LIKE 'Pure%' THEN 'P-'
						WHEN rd.datasetgroup LIKE 'Team%' THEN 'T-'

					END +	
					CASE
						WHEN rd.datasetname LIKE '%Cat Margin' THEN 'CM'
						WHEN rd.datasetname LIKE '%Large Losses' THEN 'LL'
						WHEN rd.datasetname LIKE '%Attritional Claims' THEN 'AC'
						WHEN rd.datasetname LIKE '%Premium' THEN 'PR'

					END

	FROM           [FinanceLanding].[ADM].[Reserving_data] rd

	WHERE          rd.gross_ri <> 'Net'

    AND            rd.datasetgroup  in ('Pure Claims','Team Claims','Pure Premium','Team Premium')

	AND            rd.datasetname NOT LIKE '%IC' 

   ) AS Source ([table],L1,L2,L3,AccountKey)

   ON (Target.[table] = Source.[table] AND Target.L1 = Source.L1 AND Target.L2 = Source.L2 AND Target.L3 = Source.L3 AND  Source.AccountKey IS NOT NULL)

   WHEN MATCHED AND Target.AccountKey <> Source.AccountKey

   THEN UPDATE SET Target.AccountKey = Source.AccountKey

   WHEN NOT MATCHED BY TARGET AND Source.AccountKey IS NOT NULL

   THEN INSERT([table],L1,L2,L3,AccountKey) VALUES(Source.[table],Source.L1,Source.L2,Source.L3,Source.AccountKey);
 

	--populate FK_AccountKey when AccountKey is matching
	UPDATE		
		am
	SET        
		FK_AccountKey = an.PK_AccountNames
	FROM       
		MDS.AccountMapping am
		JOIN MDS.AccountNames an ON am.AccountKey = an.AccountKey
	WHERE      
		am.[Table] = @dataset_ReservingData
		and isnull(FK_AccountKey, -an.PK_AccountNames) != an.PK_AccountNames


	-- constants for constant values.
	declare 
		 @Scenario char(1)				= 'F' 
		,@Basis char(1)					= 'E'
		,@PolicyNumber char(8)			= 'NOPOLICY'
		,@DefaultDate date				= CAST('01-01-1980' as date)
		,@TypeOfBusiness char(1)		= '-'
		,@IsToDate char(1)				= 'Y'
		,@BusinessProcessCode char(2)	= 'T1'
		,@AuditHost varchar(255)		= CAST(SERVERPROPERTY('MachineName') as varchar(255))
		,@StatsCode varchar(25)			= null
		,@DateOfFact date				= convert(date,convert(varchar(30),(convert(varchar(30),@v_asat_RS)+'01'),12))


	--temporary table for the insert (willbe used to calculate RowHash values before pushing data in the IDC transaction table

	DROP TABLE IF EXISTS #TempInboundTransaction;

    /* Insert the new records from ADM sources */
    SELECT * 

    INTO #TempInboundTransaction

    FROM

	           (SELECT 
					Account             
					,BusinessKey         
					,TrifocusCode        
					,Entity              
					,[Location]          
					,YOA                 
					,SettlementCCY       
					,[Value]             = SUM([value])

					-- extra columns to go into the extensions table
					,[special]			
					,[datasetname]		
					,[datasetgroup]		
					,[att_cat]			
					,[triangle_group]	

			FROM        
			(
				SELECT 
					Account             = CAST(ISNULL(am.AccountKey,'XX-XX-XX') AS VARCHAR(10))
					,TrifocusCode        = CAST(ISNULL(tf.TriFocusCode,'UNKNOWN') AS [VARCHAR](25))
					,Entity              = ISNULL(CAST(synd AS [VARCHAR](10)),'NOENTITY')
					,[Location]          = CAST(ISNULL(office_location,'-') AS [VARCHAR](50))
					,YOA                 = ISNULL(CAST(yoa AS VARCHAR(5)),'NOYOA') 
					,SettlementCCY       = CAST(ccy AS VARCHAR(3))
					,[Value]             = CAST((ISNULL([value],0.0000)) AS DECIMAL (19, 4))

					,BusinessKey         = CAST
											(
												CONCAT
												(
													 rtrim(ltrim(ISNULL(rd.[department],'-')))		,'|'
													,rtrim(ltrim(ISNULL(rd.[triangle_group],'-')))	,'|'
													,ISNULL(CAST(rd.YOA AS VARCHAR(10)),'-')		,'|'
													,rtrim(ltrim(ISNULL(rd.[gross_ri],'-')))		,'|'
													,rtrim(ltrim(ISNULL(rd.ccy,'-')))				,'|'
													,rtrim(ltrim(ISNULL(rd.[datasetname],'-')))		,'|'
													,rtrim(ltrim(ISNULL(rd.[att_cat],'-')))			,'|'
													,rtrim(ltrim(ISNULL(rd.[special],'-')))			,'|'
													,ISNULL(CAST(rd.Synd AS VARCHAR(30)),'-')		,'|'
													,rtrim(ltrim(ISNULL(rd.[datasetgroup],'-')))	,'|'
													,rtrim(ltrim(ISNULL(rd.office_location,'-')))	
												) AS VARCHAR(255)
											)

					-- extra columns to go into the extensions table
					,[special]			= convert(nvarchar(100), case when rd.[gross_ri] = 'RI' then rd.[IFRS17_mapping] 
					                                                  when rd.[gross_ri] = 'Gross' and isnull(rd.IFRS17_mapping,'')!='Consol Adj' then 'GROSS'
																	  when rd.[gross_ri] = 'Gross' and rd.[IFRS17_mapping]='Consol Adj' then 'Consol Adj'
					                              end)
					,[datasetname]		= convert(nvarchar(200), case when rd.[gross_ri] = 'RI' then rd.[datasetname] else null end)
					,[datasetgroup]		= convert(varchar(100), case when rd.[gross_ri] = 'RI' then rd.[datasetgroup] else null end)
					,[att_cat]			= convert(nvarchar(30), case when rd.[gross_ri] = 'RI' then rd.[att_cat] else null end)
					,[triangle_group]	= convert(nvarchar(50), case when rd.[gross_ri] = 'RI' then rd.[triangle_group] else null end)

				FROM        
					ADM.Reserving_data rd 

					--LEFT JOIN fdm.DimTrifocus tf  on tf.TrifocusName = rd.triangle_group I1B-3434 Bug reverting by EB 25/11/2022
					LEFT JOIN MDS.TriFocus tf  on tf.[Name] = rd.triangle_group

					LEFT JOIN   MDS.AccountMapping am  
						ON          rd.gross_ri     = am.l1
						AND         rd.datasetgroup = am.l2 
						AND         rd.datasetname  = am.l3
						AND         am.[Table]      = @dataset_ReservingData

				WHERE 
					rd.asat = @v_asat_RS
					AND   rd.gross_ri <> 'Net'
					AND   rd.datasetgroup  in ('Pure Claims','Team Claims','Pure Premium','Team Premium')
					AND   rd.datasetname NOT LIKE '%IC' 
					AND   am.AccountKey IS NOT NULL
					AND   isdate(convert(varchar(30),(convert(varchar(30),rd.asat)+'01'),12))=1 -- filter out non dates.
			) r

			-- dev/test code to run for a single row per period.
			--where
			--	YOA=2019
			--	and Entity='2623'
			--	and SettlementCCY='CAD'
			--	and Account='GP-P-PR'
			--	and TrifocusCode='20'


			GROUP BY  
				BusinessKey
				,triangle_group
				,YOA
				,SettlementCCY
				,datasetname
				,att_cat
				,triangle_group
				,special
				,Entity				
				,datasetgroup
				,[Location]
				,TriFocusCode
				,Account
		        			
            ) src ;

	
	-- sort out the rowhashes for the transaction table and the extensions table
	SELECT  
		[Account]
		,[BusinessKey]
		,[TrifocusCode]
		,[Entity]
		,[Location]
		,[YOA]
		,[SettlementCCY]
		,[Value]
		,RowHash = dbo.fn_RowHashForTransactions
		(
			'T' /* @RowHashType */
			,@Scenario,Account,@dataset_ReservingData,BusinessKey,@PolicyNumber,@DefaultDate,@DefaultDate,@DefaultDate,@DefaultDate,TrifocusCode,Entity,YOA,@TypeOfBusiness,@StatsCode,SettlementCCY,SettlementCCY,@IsToDate,@Basis,[Location]
			,null  --[BusinessProcessCode]
			,null /* @BoundDate */
			-- extended columns
			,CONCAT
			(
				 case when special is null			then '' else (rtrim(ltrim(special)) + '§~§') end
				,case when datasetname is null		then '' else (rtrim(ltrim(datasetname)) + '§~§') end
				,case when datasetgroup is null		then '' else (rtrim(ltrim(datasetgroup)) + '§~§') end
				,case when triangle_group is null	then '' else (rtrim(ltrim(triangle_group)) + '§~§') end
				,case when att_cat is null			then '' else (rtrim(ltrim(att_cat)) + '§~§') end
			)
		)
		-- extra columns to go into the extensions table
		,[special]			
		,[datasetname]		
		,[datasetgroup]		
		,[att_cat]
		,[triangle_group]			
		,[RowHash_Transaction_Reserving_ReInsurance_Extensions] = dbo.fn_RowHashForTransactions
		(
			'E' /* @RowHashType */
			,@Scenario,Account,@dataset_ReservingData,BusinessKey,@PolicyNumber,@DefaultDate,@DefaultDate,@DefaultDate,@DefaultDate,TrifocusCode,Entity,YOA,@TypeOfBusiness,@StatsCode,SettlementCCY,SettlementCCY,@IsToDate,@Basis,[Location]
			,null  --[BusinessProcessCode]
			,null /* @BoundDate */
			-- extended columns
			,CONCAT
			(
				 case when special is null			then '' else (rtrim(ltrim(special)) + '§~§') end
				,case when datasetname is null		then '' else (rtrim(ltrim(datasetname)) + '§~§') end
				,case when datasetgroup is null		then '' else (rtrim(ltrim(datasetgroup)) + '§~§') end
				,case when triangle_group is null	then '' else (rtrim(ltrim(triangle_group)) + '§~§') end
				,case when att_cat is null			then '' else (rtrim(ltrim(att_cat)) + '§~§') end
			)
		)
	INTO    
		#TempInboundTransactionExtended
	FROM    
		#TempInboundTransaction;

	SELECT   @v_AffectedRows			= @@ROWCOUNT;
	print convert(varchar,@v_AffectedRows) + ' records in #TempInboundTransactionExtended for ' + convert(varchar,@v_Asat_RS)

	DROP TABLE IF EXISTS #TempInboundTransaction; -- no longer required


	-- create the extensions.
	DROP TABLE IF EXISTS #Transaction_Reserving_ReInsurance_Extensions;
	SELECT
		 [special]			
		,[datasetname]		
		,[datasetgroup]		
		,[att_cat]
		,[triangle_group]			
		,[RowHash_Transaction_Reserving_ReInsurance_Extensions] 
	INTO
		#Transaction_Reserving_ReInsurance_Extensions
	FROM    
		#TempInboundTransactionExtended
	GROUP BY
		 [special]			
		,[datasetname]		
		,[datasetgroup]		
		,[att_cat]
		,[triangle_group]			
		,[RowHash_Transaction_Reserving_ReInsurance_Extensions] 
	

	-- create the extensions bridge
	DROP TABLE IF EXISTS #Transaction_Reserving_ReInsurance_Extensions_Bridge;
	SELECT
		[RowHash]
		,[RowHash_Transaction_Reserving_ReInsurance_Extensions] 
	INTO
		#Transaction_Reserving_ReInsurance_Extensions_Bridge
	FROM    
		#TempInboundTransactionExtended
	GROUP BY
		[RowHash]
		,[RowHash_Transaction_Reserving_ReInsurance_Extensions] 
	

	-- now I need to do the Reversals.
	-- I get the data from the outbound grouped by the rowhash & check to see that we don't have a related inbound record. These are missing and need to be zero for the current period.
	DROP TABLE IF EXISTS #TempOutboundTransaction;

	SELECT 
		 tot.Account             
		,tot.BusinessKey        
		,tot.TrifocusCode        
		,tot.Entity              
		,tot.[Location]          
		,tot.YOA                 
		,tot.SettlementCCY       
		,[FK_Batch]          = MAX(tot.[FK_Batch])
		,tot.RowHash
	INTO 
		#TempOutboundTransaction 
	FROM        
		FinanceDataContract.Outbound.[Transaction] tot
		left join #TempInboundTransactionExtended tite on tot.RowHash = tite.RowHash
	WHERE
		tite.RowHash is null
		and tot.Dataset = @dataset_ReservingData
	GROUP BY  
		 tot.Account             
		,tot.BusinessKey        
		,tot.TrifocusCode        
		,tot.Entity              
		,tot.[Location]          
		,tot.YOA                 
		,tot.SettlementCCY       
		,tot.RowHash
	HAVING
		SUM(tot.[Value]) <> 0

	SELECT   @v_AffectedRows			= @@ROWCOUNT;
	print convert(varchar,@v_AffectedRows) + ' records in #TempOutboundTransaction for ' + convert(varchar,@v_Asat_RS)


		IF @Trancount = 0 

			BEGIN TRAN;

			/* Delete the Inbound extensions tables ... */
			truncate table [FinanceDataContract].[Inbound].[Transaction_Reserving_ReInsurance_Extensions]
			truncate table [FinanceDataContract].[Inbound].[Transaction_Reserving_ReInsurance_Extensions_Bridge]

			/* We insert the rows from temp table in the extension tables */
			INSERT INTO [FinanceDataContract].[Inbound].[Transaction_Reserving_ReInsurance_Extensions] WITH(TABLOCK)
			(
				[RowHash_Transaction_Reserving_ReInsurance_Extensions]
				,[special]
				,[datasetname]
				,[datasetgroup]
				,[att_cat]
				,[trianglegroup]
				,[FK_Batch] 
			)
			SELECT 
				[RowHash_Transaction_Reserving_ReInsurance_Extensions] 
				,[special]			
				,[datasetname]		
				,[datasetgroup]		
				,[att_cat]
				,[triangle_group]			
				,[FK_Batch] = @v_BatchId_Ext
			FROM    
				#Transaction_Reserving_ReInsurance_Extensions


			INSERT INTO [FinanceDataContract].[Inbound].[Transaction_Reserving_ReInsurance_Extensions_Bridge] WITH(TABLOCK)
			(
				[RowHash_Transaction]
				,[RowHash_Transaction_Reserving_ReInsurance_Extensions]
				,[FK_Batch] 
			)
			SELECT 
				[RowHash]
				,[RowHash_Transaction_Reserving_ReInsurance_Extensions] 
				,[FK_Batch] = @v_BatchId_Ext
			FROM
				#Transaction_Reserving_ReInsurance_Extensions_Bridge
		

			/* Delete the current lines of the ADM source system from Inbound ... */

			DELETE 
			FROM    FinanceDataContract.Inbound.[Transaction]
			WHERE   [DataSet] = @dataset_ReservingData

			/* We insert the rows from temp table in the system */

			INSERT INTO [FinanceDataContract].[Inbound].[Transaction] WITH(TABLOCK)
			(
				 [Scenario]
				,[Basis]
				,[Account]
				,[DataSet]
				,[DateOfFact]
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]
				,[DueDate]
				,[TrifocusCode]
				,[Entity]
				,[Location]
				,[YOA]
				,[TypeOfBusiness]
				,[SettlementCCY]
				,[OriginalCCY]
				,[IsToDate]
				,[Value]
				,[ValueOrig]
				,[RowHash]
				,[BusinessProcessCode]
				,[AuditSourceBatchID]
				,[AuditHost]
				,[AuditGenerateDateTime]
				,[StatsCode]
				,[FK_Batch]
				,[DeltaType]
			)		
			SELECT  
				 Scenario					= @Scenario                   
				,Basis						= @Basis  
				,[Account]
				,DataSet					= @dataset_ReservingData
				,[DateOfFact]				= case month(@DateOfFact) when '5' then  dateadd(mm,-2,@DateOfFact)
                                                                      when '11' then dateadd(mm,-2,@DateOfFact)
                                              else @DateOfFact
		                                      end
				,[BusinessKey]
				,PolicyNumber				= @PolicyNumber
				,InceptionDate				= @DefaultDate
				,ExpiryDate					= @DefaultDate
				,BindDate					= @DefaultDate
				,DueDate					= @DefaultDate
				,[TrifocusCode]
				,[Entity]
				,[Location]
				,[YOA]
				,TypeOfBusiness				= @TypeOfBusiness                                         
				,[SettlementCCY]
				,OriginalCCY				= SettlementCCY
				,IsToDate					= @IsToDate
				,[Value]
				,[ValueOrig]				= [Value]
				,RowHash
				,BusinessProcessCode		= @BusinessProcessCode
				,AuditSourceBatchID			= CAST(@v_BatchId_RS AS VARCHAR (50))                                                 
				,AuditHost					= @AuditHost
				,[AuditGenerateDateTime]	= GETUTCDATE()
				,[StatsCode]				= @StatsCode
				,[FK_Batch]					= @v_BatchId_RS
				,[DeltaType]				= CONVERT(varchar,null)
			FROM    
				#TempInboundTransactionExtended

			UNION ALL

			SELECT  
				 Scenario					= @Scenario                   
				,Basis						= @Basis  
				,[Account]
				,DataSet					= @dataset_ReservingData
				,DateOfFact					= case month(@DateOfFact) when '5' then  dateadd(mm,-2,@DateOfFact)
                                                                      when '11' then dateadd(mm,-2,@DateOfFact)
                                              else @DateOfFact
		                                      end
				,[BusinessKey]
				,PolicyNumber				= @PolicyNumber
				,InceptionDate				= @DefaultDate
				,ExpiryDate					= @DefaultDate
				,BindDate					= @DefaultDate
				,DueDate					= @DefaultDate
				,[TrifocusCode]
				,[Entity]
				,[Location]
				,[YOA]
				,TypeOfBusiness				= @TypeOfBusiness                                         
				,[SettlementCCY]
				,OriginalCCY				= SettlementCCY
				,IsToDate					= @IsToDate
				,[Value]					= 0
				,[ValueOrig]				= 0
				,RowHash
				,BusinessProcessCode		= @BusinessProcessCode
				,AuditSourceBatchID			= CAST(@v_BatchId_RS AS VARCHAR (50))                                                 
				,AuditHost					= @AuditHost
				,[AuditGenerateDateTime]	= GETUTCDATE()
				,[StatsCode]				= @StatsCode
				,[FK_Batch]
				,DeltaType					= 'Reversal'
			FROM    
				#TempOutboundTransaction

			SELECT   @v_AffectedRows			= @@ROWCOUNT;
	
			/* Add the batch to the queue */
			IF @v_BatchId_RS IS NOT NULL
			BEGIN

			   INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
							( Pk_Batch
							,[Status]
							,[DataSet]
							,RunDescription
							,OriginalName
							)
			   VALUES
							(@v_BatchId_Ext
							,'InBound'
							,@dataset_Reserving_ReInsuranceExtensions
							,NULL
							,@v_asat_RS
							);
			
			   INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
							( Pk_Batch
							,[Status]
							,[DataSet]
							,RunDescription
							,OriginalName
							,asat
							)
			   VALUES
							(@v_BatchId_RS
							,'InBound'
							,@dataset_ReservingData
							,NULL
							,@v_asat_RS
							,case right(@v_Asat_RS,2) when '05' then @v_Asat_RS-2
			                                          when '11' then  @v_Asat_RS-2
			                                 
                             else @v_Asat_RS
							 end
							);
			
			END

			-- LOG THE RESULT WITH SUCCESS
			SELECT @v_ActivityDateTime			= GETUTCDATE();

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStop
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

			IF @Trancount = 0 COMMIT;

		END TRY

		BEGIN CATCH
	
			-- CANCEL TRAN
			IF @Trancount = 0 AND @@TRANCOUNT <> 0 
				ROLLBACK;
			        
			-- LOG THE RESULT WITH ERROR

			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

		    THROW;

		END CATCH;

					
END