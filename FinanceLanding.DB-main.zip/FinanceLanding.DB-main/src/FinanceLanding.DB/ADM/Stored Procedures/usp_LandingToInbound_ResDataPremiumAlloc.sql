﻿CREATE PROCEDURE [ADM].[usp_LandingInboundWorkflow_ReservingDataPremiumAlloc] 
(
@p_AccountingPeriod int 
)
AS
BEGIN

/* =====================================================================================================================================================================================
--> Details:

  Version				DateOfModification		UpdatedBY
  ----------------------------------------------------------------------------
	1.0					29-04-2024				Lakshman.Akasapu@beazley.com
	
  Description
  ----------------------------------------------------------------------------------------------------------
  Added a condition to Code line No.919. This will restrict creating a Batchid if no data found in Inbound.				
  This will avoid creating Reversal Entries in Outbound.Transaction.
  https://beazley.atlassian.net/browse/I1B-5451


    Version				DateOfModification		UpdatedBY
  ----------------------------------------------------------------------------
	1.1					08-05-2024				Lakshman.Akasapu@beazley.com
	
  Description
  ----------------------------------------------------------------------------------------------------------
  1. Added a COALESCE function [at line 233 ] to the trifocuscode  so that if source having any unknown trifocus name, instead of NULL entry it converts NULL value to 'Unknown' while loading into the [FinanceDataContract].Inbound.[Transaction]
  2. Added a CASE to the code [at line 255 ] ,as for the table FinanceLanding.adm.[Reserving_data] triangle_group column value 'Vault Risk Cryptoassets' has spaces where as 
									  for the table FinanceLanding.fdm.dimTrifocus TrifocusName column value 'VaultRiskCryptoasset' has no spaces. This case avoids NULL entry while loading.
  https://beazley.atlassian.net/jira/software/c/projects/I1B/boards/735?selectedIssue=I1B-5510&sprints=5779

  ====================================================================================================================================================================================== */

	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;

	/*======================================================Logging Starts==================================================*/
	--DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'ReservingDataPremiumAlloc';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= NULL;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	DECLARE @ContractType					CHAR(3)			= 'RDP';
	DECLARE	@p_ParentActivityLogId		    BIGINT			= NULL

	DECLARE @v_Dataset varchar(50)=@v_ActivityDatabase
	DECLARE @v_BatchId                   INT             = NULL;
	DECLARE @v_BatchId_Extensions INT;



	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';

	INSERT INTO [dbo].[Batch]([CreateDate],[DataSet]) 
	VALUES  (GETDATE(),@v_Dataset);

	SELECT @v_BatchId = SCOPE_IDENTITY();

	SET @v_ActivityJobId=@v_BatchId

	/* Log the start of the insert */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'ADM.usp_LandingInboundWorkflow_ResDataPremiumAlloc'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'Load data into Inbound.Transaction for ReservingData Excel Direct Load'
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;
	
/*==================Logging End======================*/


	BEGIN TRY
		IF @Trancount = 0 
			BEGIN TRAN;

		/*
=============================================================================================
	Create BatchID In landing
==============================================================================================
*/

	declare 
		 @Scenario char(1)				= 'F' 
		,@Basis char(1)					= 'E'
		,@DefaultDate date				= CAST('01-01-1980' as date)
		,@TypeOfBusiness char(1)		= '-'
		,@Location char(1)				= '-'
		,@IsToDate char(1)				= 'Y'
		,@BusinessProcessCode char(2)	= 'T1'
		,@AuditHost varchar(255)		= CAST(SERVERPROPERTY('MachineName') as varchar(255))
		,@StatsCode varchar(25)			= null
		--,@DateOfFact date				= convert(date,convert(char(8),@p_AccountingPeriod * 100 + 1),112)


	
    /* Insert into logging table */

	INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'ADM.usp_LandingInboundWorkflow_ResDataPremiumAlloc', ' '+CONVERT(VARCHAR,@v_BatchId)+' Batch Created';

drop table if exists #temp_InboundTransactions_init;
drop table if exists #alloc_view;
drop table if exists #ProgrammeCode

SELECT DISTINCT ifrs17_programme_group into #ProgrammeCode from
[Eurobase].rein_program_sequence prg

select * 
into #alloc_view from fdm.vw_ReInsuranceAllocationsGeneric---cte_tmp --
where MasterRIInd = 'N';



--Combine Allocations
WITH
cte_alloc
as
(
select * , 
Amount/ TotalAmount as Allocation 
from
(
select AccountingPeriod,
	case when EntityCode in ('BIFR', 'BIGE', 'BISP', 'BISW', 'BIUK') then '8033' else EntityCode end EntityCode,
	ProgrammeCode RIProgramme,
	YOA,
	TrifocusCode,
	sum(Amount) Amount,
	sum(sum(Amount)) over (partition by TrifocusCode,
								case when EntityCode in ('BIFR', 'BIGE', 'BISP', 'BISW', 'BIUK') then '8033' else EntityCode end,
								YOA,
								AccountingPeriod) TotalAmount
	from #alloc_view t
	left join 
		(
			select distinct IFRS17_mapping 
			from adm.GroupActuaries_IFRS17_Mappings 
			where IFRS17_mapping <>'Unknown' 
			and IFRS17_mapping not in ('Professions', 'Whole Account Stop Loss')
		) a
		 on (t.ProgrammeCode = a.IFRS17_mapping)
	where a.IFRS17_mapping is null
	group by
	AccountingPeriod,
	case when EntityCode in ('BIFR', 'BIGE', 'BISP', 'BISW', 'BIUK') then '8033' else EntityCode end,
	ProgrammeCode,
	YOA,
	TrifocusCode
) t
where TotalAmount <> 0
),


--ADM Data Preparation

cte_adm_prep 
as
(
select datasetname,
t.datasetgroup,
TrifocusCode,
TrifocusName,
YOA,
asat as AccountingPeriod,
Entity,
SettlementCCY,
ProgrammeCode,
office_location,
special,
[value] 
--into #cte_adm_prep --drop table #cte_adm
from
(
	select t.datasetname,
	t.datasetgroup,
	COALESCE(tf.TrifocusCode,'Unknown') TrifocusCode,
	t.triangle_group TrifocusName,
	t.YOA,
	left(t.asat, 4) + case right(t.asat, 2) when '05' then '03'
											when '11' then '09'
											else right(t.asat, 2)
					  end asat,
	--t.asat,
	case when t.yoa >= '2018' 
			  and mtf.Division in ('SL', 'CyEx') 
			  and synd = '3623' then '8022' 
		 else cast(t.Synd as varchar) 
	end as Entity,
	t.ccy as SettlementCCY,
	isnull(t.IFRS17_mapping, 'Unknown') ProgrammeCode,
	t.office_location,
	t.special,
	sum(t.[Value]) [Value]
	from FinanceLanding.adm.[Reserving_data] t 
	left join FinanceLanding.fdm.dimTrifocus tf 
		on (tf.TrifocusName = case when t.triangle_group = 'Covers' then 'Covers US' 
								   when t.triangle_group = 'Swiss' then 'Private Clients'
								   when t.triangle_group = 'Vault Risk Cryptoassets' then 'VaultRiskCryptoasset'
								   else t.triangle_group end)
	left join mds.TriFocus mtf on (mtf.[Name] = t.triangle_group)
	where (right(t.asat, 2) in ('05', '06', '11', '12') or asat = '202003')
	and datasetname = 'Team Premium'
	and gross_ri = 'RI'
	--and Synd <> '8022'
	group by t.datasetname,
	t.datasetgroup,
	tf.TrifocusCode,
	t.triangle_group,
	t.YOA,
	left(t.asat, 4) + case right(t.asat, 2) when '05' then '03'
											when '11' then '09'
											else right(t.asat, 2)
					  end,
	--t.asat,
	case when t.yoa >= '2018' 
			  and mtf.Division in ('SL', 'CyEx') 
			  and synd = '3623' then '8022' 
		 else cast(t.Synd as varchar) 
	end,
	ccy,
	isnull(t.IFRS17_mapping, 'Unknown'),
	t.office_location,
	t.special
) t
where  asat =@p_AccountingPeriod-->= '201809'
and [value] <> 0
--and ProgrammeCode = 'Berkshire Hathaway'
),


--Fix Cede 6107 Issue

_6107_Gross_CyEx 
as
(
select * from 
(
select t.datasetgroup,
t.datasetname,
left(t.asat, 4) + case right(t.asat, 2) when '05' then '03'
											when '11' then '09'
											else right(t.asat, 2)
					  end AccountingPeriod, 
YOA, 
tf.TriFocusCode, 
[Name] TrifocusName, 
t.CCY SettlementCCY, 
ss.SyndSplitEntity Entity,
sum([value] * isnull(cast(ss.SyndSplitPercentage as decimal(3, 2)) ,1)) GrossAmount_6107
--into #6107_Gross_CyEx --drop table #t1
from FinanceLanding.adm.Reserving_data t 
left join mds.TriFocus tf on (tf.Name = t.triangle_group)
left join [fdm].[SyndicateSplitsbyYOA] ss on (ss.[SyndSplitSource] = '2623'
											  and ss.SyndSplitYOA = t.yoa)
where t.Synd = '6107'
and tf.Division = 'CyEx'
and (right(t.asat, 2) in ('05', '06', '11', '12') or asat = '202003')
and t.datasetname = 'Team Premium'
and t.gross_ri = 'Gross'
--and t.asat>= '201811'
group by t.datasetgroup,
t.datasetname,
left(t.asat, 4) + case right(t.asat, 2) when '05' then '03'
											when '11' then '09'
											else right(t.asat, 2)
					  end, 
t.YOA, 
tf.TriFocusCode, 
tf.[Name], 
t.CCY,
ss.SyndSplitEntity
) as qry where AccountingPeriod=@p_AccountingPeriod
),

Syndicate_RI_Cyex
as
(
select * from 
(
select t.datasetgroup,
t.datasetname,
left(t.asat, 4) + case right(t.asat, 2) when '05' then '03'
											when '11' then '09'
											else right(t.asat, 2)
					  end AccountingPeriod, 
--t.asat AccountingPeriod,
t.YOA, 
tf.TriFocusCode, 
tf.[Name]  TrifocusName, 
t.CCY SettlementCCY, 
t.Synd Entity,
t.IFRS17_mapping ProgrammeCode,
sum(t.[value]) RIAmount 
--into #Syndicate_RI_Cyex --drop table #t2
from FinanceLanding.adm.Reserving_data t
left join mds.TriFocus tf on (tf.Name = t.triangle_group)
where Synd in ('2623', '623')
and tf.Division = 'CyEx'
and (right(t.asat, 2) in ('05', '06', '11', '12') or asat = '202003')
and t.datasetname = 'Team Premium'
and t.gross_ri = 'RI'
--and t.asat >= '201811'
group by t.datasetgroup,
t.datasetname,
left(t.asat, 4) + case right(t.asat, 2) when '05' then '03'
											when '11' then '09'
											else right(t.asat, 2)
					  end, 
--t.asat,
t.YOA, 
tf.TriFocusCode, 
tf.[Name], 
t.CCY, 
t.Synd,
t.IFRS17_mapping
) as q2 where AccountingPeriod=@p_AccountingPeriod
),


--drop table if exists #6107_corrections
_6107_corrections
as
(
select t1.datasetgroup,
t1.datasetname,
t1.AccountingPeriod, 
t1.yoa,
t1.TriFocusCode,
t1.TrifocusName,
t1.SettlementCCY,
t1.Entity,
t1.GrossAmount_6107,
t2.RIAmount RIAmountCede6107, 
t3.RIAmount  RIAmountUnknown
--into #6107_corrections
from _6107_Gross_CyEx t1
left join Syndicate_RI_Cyex t2 on (t2.datasetgroup = t1.datasetgroup
					 and t2.datasetname = t1.datasetname
					 and t2.AccountingPeriod = t1.AccountingPeriod
					 and t2.TrifocusCode = t1.TrifocusCode
					 and t2.yoa = t1.yoa
					 and t2.SettlementCCY = t1.SettlementCCY
					 and t2.Entity = t1.Entity
					 and t2.ProgrammeCode = 'Cede 6107')
left join Syndicate_RI_Cyex t3 on (t3.datasetgroup = t1.datasetgroup
					 and t3.datasetname = t1.datasetname
				     and t3.AccountingPeriod = t1.AccountingPeriod
					 and t3.TrifocusCode = t1.TrifocusCode
					 and t3.yoa = t1.yoa
					 and t3.SettlementCCY = t1.SettlementCCY
					 and t3.Entity = t1.Entity
					 and isnull(t3.ProgrammeCode, 'Unknown') = 'Unknown')
											  
where t2.RIAmount is null
),


--Combine ADM Data with 6107 fix

cte_adm 
as
(
select
t.datasetname,
t.datasetgroup,
t.TrifocusCode,
t.TrifocusName,
t.YOA,
left(convert(varchar, dateadd(quarter, 1, cast(cast(AccountingPeriod as varchar) + '01' as date)), 112), 6) as AccountingPeriod,
Entity,
SettlementCCY,
ProgrammeCode,
office_location,
special,
sum([Value]) [Value]
--into #cte_adm 
from
(
select t.datasetname,
t.datasetgroup,
t.TrifocusCode,
t.TrifocusName,
t.YOA,
t.AccountingPeriod,
Entity,
SettlementCCY,
ProgrammeCode,
office_location,
special,
[value]
from cte_adm_prep t

union all

select t.datasetname,
t.datasetgroup,
t.TrifocusCode,
t.TrifocusName,
t.YOA,
t.AccountingPeriod,
Entity,
SettlementCCY,
'Cede 6107' ProgrammeCode,
'LON' as office_location,
'Cede 6107' as special,
GrossAmount_6107
from _6107_corrections t

union all

select t.datasetname,
t.datasetgroup,
t.TrifocusCode,
t.TrifocusName,
t.YOA,
t.AccountingPeriod,
Entity,
SettlementCCY,
'Unknown' ProgrammeCode,
'LON' as office_location,
null as special,
-GrossAmount_6107
from _6107_corrections t
where RIAmountUnknown is not null
) t
group by t.datasetname,
t.datasetgroup,
t.TrifocusCode,
t.TrifocusName,
t.YOA,
t.AccountingPeriod,
left(convert(varchar, dateadd(quarter, 1, cast(cast(AccountingPeriod as varchar) + '01' as date)), 112), 6),
t.Entity,
t.SettlementCCY,
t.ProgrammeCode,
t.office_location,
t.special
),


--Splitting logic

cte_adm_period
as
(
select
t.datasetname,
t.datasetgroup,
t.TrifocusCode,
t.TrifocusName,
t.YOA,
t.AccountingPeriod,
t.Entity,
t.SettlementCCY,
t.ProgrammeCode,
t.office_location,
t.special,
t.[value],
isnull(max(minAccountingPeriod), max(maxAccountingPeriod)) as AllocAccountingPeriod
from
(
	select t.datasetname,
	t.datasetgroup,
	t.TrifocusCode,
	t.TrifocusName,
	t.YOA,
	t.AccountingPeriod,
	t.Entity,
	t.SettlementCCY,
	t.ProgrammeCode,
	t.office_location,
	t.special,
	t.[value],
	min(a.AccountingPeriod) minAccountingPeriod,
	null as maxAccountingPeriod
	from cte_adm t
	left join mds.TriFocus tf on (tf.TriFocusCode = t.TrifocusCode)
	left join cte_alloc a on
	(
		a.TrifocusCode = case when t.YOA between 2005 and 2008 and tf.DepartmentName_Name = 'Specialty Lines' and left(t.TrifocusName, 4) in ('BICI', 'BUSA') then
							  case when t.Entity = '8022' then '28' --BICI Specialty
								   else '664' --BUSA SL
							  end
							  when t.Entity in ('623', '2623') and t.TrifocusCode = '798' then 'TRI00046' -- BICI Falvey -> BICI Falvey Marine
							  when t.YOA = 2011 and t.TrifocusCode = '693' then '703' -- BUSA Environmental -> BUSA Environmental FS
							  when t.YOA in (2009, 2010 ) and t.TrifocusCode = '696' then '670' --BICI Healthcare ML -> BICI BEAZLEY HEALTHCARE
							  else t.TrifocusCode
						 end
		and a.AccountingPeriod >= t.AccountingPeriod
		and a.YOA = t.yoa
		and a.EntityCode = t.Entity
		and t.ProgrammeCode = 'Unknown'
	)
	group by t.datasetname,
	t.datasetgroup,
	t.TrifocusCode,
	t.TrifocusName,
	t.YOA,
	t.AccountingPeriod,
	t.Entity,
	t.SettlementCCY,
	t.ProgrammeCode,
	t.office_location,
	t.special,
	t.[value]

	union all

	select t.datasetname,
	t.datasetgroup,
	t.TrifocusCode,
	t.TrifocusName,
	t.YOA,
	t.AccountingPeriod,
	t.Entity,
	t.SettlementCCY,
	t.ProgrammeCode,
	t.office_location,
	t.special,
	t.[value],
	null as minAccountingPeriod,
	max(a.AccountingPeriod) maxAccountingPeriod
	from cte_adm t
	left join mds.TriFocus tf on (tf.TriFocusCode = t.TrifocusCode)
	left join cte_alloc a on
	(
		a.TrifocusCode = case when t.YOA between 2005 and 2008 and tf.DepartmentName_Name = 'Specialty Lines' and left(t.TrifocusName, 4) in ('BICI', 'BUSA') then
							  case when t.Entity = '8022' then '28' --BICI Specialty
								   else '664' --BUSA SL
							  end
							  when t.Entity in ('623', '2623') and t.TrifocusCode = '798' then 'TRI00046' -- BICI Falvey -> BICI Falvey Marine
							  when t.YOA = 2011 and t.TrifocusCode = '693' then '703' -- BUSA Environmental -> BUSA Environmental FS
							  when t.YOA in (2009, 2010 ) and t.TrifocusCode = '696' then '670' --BICI Healthcare ML -> BICI BEAZLEY HEALTHCARE
							  else t.TrifocusCode
						 end
		and a.AccountingPeriod < t.AccountingPeriod
		and a.YOA = t.yoa
		and a.EntityCode = t.Entity
		--and t.ProgrammeCode = 'Unknown'
	)
	where t.ProgrammeCode = 'Unknown'
	group by t.datasetname,
	t.datasetgroup,
	t.TrifocusCode,
	t.TrifocusName,
	t.YOA,
	t.AccountingPeriod,
	t.Entity,
	t.SettlementCCY,
	t.ProgrammeCode,
	t.office_location,
	t.special,
	t.[value]
) t
group by t.datasetname,
t.datasetgroup,
t.TrifocusCode,
t.TrifocusName,
t.YOA,
t.AccountingPeriod,
t.Entity,
t.SettlementCCY,
t.ProgrammeCode,
t.office_location,
t.special,
t.[value]
),

cte_adm_allocated as 
(
select t.datasetgroup,
t.datasetname,
left(convert(varchar, dateadd(quarter, -1, cast(cast(t.AccountingPeriod as varchar) + '01' as date)), 112), 6) as AccountingPeriod,
--t.AccountingPeriod,
t.TrifocusCode,
t.TrifocusName,
t.YOA,
t.Entity,
t.office_location [Location],
t.SettlementCCY,
t.special,
t.[value] as Amount,
isnull(a.Allocation, 1) Allocation,
case when t.TrifocusCode = '780' then 'KOREAN RE COMMON AC RI' -- Korean Re
	 else isnull(a.RIProgramme, t.ProgrammeCode) 
end RIProgramme,
t.[value] * isnull(a.Allocation, 1) as AmountProgramme
--into #adm_allocated
from cte_adm_period t -- #cte_adm_period t
left join mds.TriFocus tf on (tf.TriFocusCode = t.TrifocusCode)
left join cte_alloc a on --#cte_alloc a on 
(
a.TrifocusCode = case when t.YOA between 2005 and 2008 and tf.DepartmentName_Name = 'Specialty Lines' then
					  case when t.Entity = '8022' then '28' --BICI Specialty
						   else '664' --BUSA SL
					  end
					  --when t.YOA = 2015 and t.TrifocusCode = '798' then '788' -- BICI Falvey -> BICI Cargo
					  when t.Entity in ('623', '2623') and t.TrifocusCode = '798' then 'TRI00046' -- BICI Falvey -> BICI Falvey Marine
					  when t.YOA = 2011 and t.TrifocusCode = '693' then '705' -- BUSA Environmental -> BUSA Environmental Occ
					  else t.TrifocusCode
				 end
and a.AccountingPeriod = t.AllocAccountingPeriod
and a.YOA = t.yoa
and a.EntityCode = t.Entity /*case when tf.TrifocusCode = '798' and t.Entity in ('623', '2623') then '3623'
						else t.Entity
				   end*/
and t.ProgrammeCode = 'Unknown' --is null
)
)


SELECT 
null as [PK_Transaction],
'F' as Scenario,
case when t.datasetname = 'Team Premium' then 'RP-T-PR' else 'RP-P-PR' end Account,
'ReservingDataPremiumAlloc' as Dataset,
cast(t.AccountingPeriod + '01' as date) DateOfFact,
cast(
		rtrim(ltrim(ISNULL(t.[datasetgroup],'-'))) + '|' +
		rtrim(ltrim(ISNULL(t.[datasetname],'-'))) + '|' +
		rtrim(ltrim(ISNULL(t.[TrifocusCode],'-'))) + '|' +
		isnull(CAST(t.YOA AS VARCHAR(10)),'-') + '|' +
		rtrim(ltrim(ISNULL(t.Entity,'-'))) + '|' +
		rtrim(ltrim(ISNULL(t.[Location],'-'))) + '|' +
		rtrim(ltrim(ISNULL(t.SettlementCCY,'-'))) + '|' +
		rtrim(ltrim(ISNULL(t.[special],'-'))) + '|' +
		rtrim(ltrim(ISNULL(ISNULL(prg.ifrs17_programme_group,t.RIProgramme),'-')))
		as varchar(255)
	)  as BusinessKey,
'NOPOLICY' as PolicyNumber,
'1980-01-01' as InceptionDate,
'1980-01-01' as ExpiryDate,
'1980-01-01' as BindDate,
'1980-01-01' as DueDate,
t.TrifocusCode,
t.Entity,
t.YOA,
'-' as TypeOfBusiness,
null as StatsCode,
t.SettlementCCY,
t.SettlementCCY as OriginalCCY,
'Y' as IsToDate,
AmountProgramme as [Value],
null as Rowhash,
null as FK_Allocation,
null as DeltaType, 
AuditSourceBatchID=@v_BatchId,
AuditCreateDateTime=GETUTCDATE(),
AuditGenerateDateTime=GETUTCDATE(),
null as AuditUserCreate,
null as AuditHost,
'E' as Basis,
ISNULL(t.[Location],@Location) as [Location],
AmountProgramme as [ValueOrig],
'T1' as BusinessProcessCode,
null as FK_Batch,
'1980-01-01' as BoundDate,
null as RIPolicyType,
special,
ISNULL(prg.ifrs17_programme_group,t.RIProgramme) as ProgrammeCode 
into #temp_InboundTransactions_init --drop table #tmp
from cte_adm_allocated t
LEFT JOIN #ProgrammeCode prg on t.RIProgramme=prg.ifrs17_programme_group
order by t.datasetgroup,
t.datasetname,
t.AccountingPeriod,
t.TrifocusCode,
t.TrifocusName,
t.YOA,
t.Entity,
ISNULL(t.[Location],@Location),
t.SettlementCCY,
t.special,
ISNULL(prg.ifrs17_programme_group,t.RIProgramme)


    /* Insert the new records from Landing ReservingDataPremiumAlloc sources in the temp table */
	
	if object_id('tempdb..#LandingTempRDPA') is not null drop table #LandingTempRDPA

	SELECT 
	   Scenario
	  ,Basis			
      ,[Account]=LTRIM(RTRIM([Account]))
      ,[Dataset]
      ,[DateOfFact]=LTRIM(RTRIM([DateOfFact]))
      ,[BusinessKey]=LTRIM(RTRIM([BusinessKey]))
      ,[PolicyNumber]
      ,[InceptionDate]
      ,[ExpiryDate]
      ,[BindDate]
      ,[DueDate]
      ,[TrifocusCode]=LTRIM(RTRIM([TrifocusCode]))
      ,[Entity]=LTRIM(RTRIM([Entity]))
	  ,[Location]
      ,[YOA]=LTRIM(RTRIM([YOA]))
      ,[TypeOfBusiness]
	  ,[SettlementCCY]=LTRIM(RTRIM([SettlementCCY]))
      ,[OriginalCCY]=LTRIM(RTRIM([OriginalCCY]))
	  ,[IsToDate]
      ,[Value]
	  ,[ValueOrig]
	 ,RowHash = dbo.fn_RowHashForTransactions('T' -- <@RowHashType, char(1),>
															, Scenario --,<@Scenario, nvarchar(2000),>
															, Account --,<@Account, nvarchar(2000),>
															, Dataset --,<@DataSet, nvarchar(2000),>
															, [BusinessKey] --,<@BusinessKey, nvarchar(2000),>
															, PolicyNumber --,<@PolicyNumber, nvarchar(2000),>
															, [InceptionDate] --,<@InceptionDate, date,>
															, [ExpiryDate] --,<@ExpiryDate, date,>
															, BindDate --,<@BindDate, date,>
															, DueDate --,<@DueDate, date,>
															, [TrifocusCode] --,<@TrifocusCode, nvarchar(2000),>
															, [Entity] --,<@Entity, nvarchar(2000),>
															, [YOA] --,<@YOA, nvarchar(2000),>
															, TypeOfBusiness --,<@TypeOfBusiness, nvarchar(2000),>
															, StatsCode --,<@StatsCode, nvarchar(2000),>
															, [SettlementCCY] --,<@SettlementCCY, nvarchar(2000),>
															, OriginalCCY --,<@OriginalCCY, nvarchar(2000),>
															, IsToDate --,<@IsToDate, nvarchar(2000),>
															, Basis --,<@Basis, nvarchar(2000),>
															, [Location] --,<@Location, nvarchar(2000),>
															, BusinessProcessCode --,<@BusinessProcessCode, nvarchar(2000),>
															, BoundDate --,<@BoundDate, date,>
															, CONCAT (
																		CASE 
																			WHEN RIPolicyType IS NULL
																				THEN ''
																			ELSE (RIPolicyType + '§~§')
																			END
																		,CASE 
																			WHEN ProgrammeCode IS NULL
																				THEN ''
																			ELSE (ProgrammeCode + '§~§')
																			END
																	)
														)
		 ,[RowHash_Transaction_ReInsurance_Extensions] = dbo.fn_RowHashForTransactions('E' 
		 	                                                 ,Scenario --,<@Scenario, nvarchar(2000),>
															, Account --,<@Account, nvarchar(2000),>
															, Dataset --,<@DataSet, nvarchar(2000),>
															, [BusinessKey] --,<@BusinessKey, nvarchar(2000),>
															, PolicyNumber --,<@PolicyNumber, nvarchar(2000),>
															, [InceptionDate] --,<@InceptionDate, date,>
															, [ExpiryDate] --,<@ExpiryDate, date,>
															, BindDate --,<@BindDate, date,>
															, DueDate --,<@DueDate, date,>
															, [TrifocusCode] --,<@TrifocusCode, nvarchar(2000),>
															, [Entity] --,<@Entity, nvarchar(2000),>
															, [YOA] --,<@YOA, nvarchar(2000),>
															, TypeOfBusiness --,<@TypeOfBusiness, nvarchar(2000),>
															, StatsCode --,<@StatsCode, nvarchar(2000),>
															, [SettlementCCY] --,<@SettlementCCY, nvarchar(2000),>
															, OriginalCCY --,<@OriginalCCY, nvarchar(2000),>
															, IsToDate --,<@IsToDate, nvarchar(2000),>
															, Basis --,<@Basis, nvarchar(2000),>
															, [Location] --,<@Location, nvarchar(2000),>
															, BusinessProcessCode --,<@BusinessProcessCode, nvarchar(2000),>
															, BoundDate --,<@BoundDate, date,>
															, CONCAT (
																		CASE 
																			WHEN RIPolicyType IS NULL
																				THEN ''
																			ELSE (RIPolicyType + '§~§')
																			END
																		,CASE 
																			WHEN ProgrammeCode IS NULL
																				THEN ''
																			ELSE (ProgrammeCode + '§~§')
																			END
																	)
														)
	  ,[BusinessProcessCode]
	  ,[AuditSourceBatchID]=CAST(@v_BatchId AS VARCHAR (50))
	  ,[AuditGenerateDateTime]
      ,[StatsCode]	  
	  ,[FK_Batch]=@v_BatchId     
      ,[DeltaType]=LTRIM(RTRIM([DeltaType]))
      ,[FK_Allocation]
      ,[AuditUserCreate]=suser_sname()
	  ,[AuditCreateDateTime]=GETUTCDATE()
      ,AuditHost=@AuditHost
      ,[BoundDate]
	  ,RIPolicyType
	  ,ProgrammeCode
	  INTO #LandingTempRDPA
	FROM #temp_InboundTransactions_init 

    ------/* Delete the current lines from Inbound ... */

        DELETE
		FROM [FinanceDataContract].[Inbound].[Transaction]
		WHERE [DataSet] = @v_DataSet

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions_Bridge]
		WHERE [ContractType] = @ContractType

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions]
		WHERE [ContractType] = @ContractType


	----------/*Insert into batch table...*/----------------
		
		INSERT INTO [dbo].[Batch]
			([CreateDate],[DataSet],[LatestBusinesKey]) 
		VALUES  
			(GETDATE(),'ReInsuranceExtensions', NULL);

		SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();

			----------/*Insert data into inbound extensions table...*/---------------
	   
		INSERT INTO  [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions_Bridge]
			(
				[RowHash_Transaction]
				,[RowHash_Transaction_ReInsurance_Extensions]
				,[ContractType]
				,[FK_Batch]
			)
			SELECT DISTINCT
				[RowHash]
				,[RowHash_Transaction_ReInsurance_Extensions]
				,@ContractType
				,@v_BatchId_Extensions
			FROM 
				#LandingTempRDPA

			INSERT INTO  [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions]
				(
					[RowHash_Transaction_ReInsurance_Extensions]
					,[RIPolicyType]
					,[ProgrammeCode]
					--,[BeazleyCatCode]
					--,[TransactionDate]		
					,[IsLargeLoss]			
					,[ContractType]
					,[FK_Batch]
				)
				SELECT DISTINCT
					[RowHash_Transaction_ReInsurance_Extensions]
					,RIPolicyType
					,ProgrammeCode
					--,[BeazleyCatCode]
					--,[TransactionDate]		
					, NULL AS [IsLargeLoss]			
					,@ContractType
					,@v_BatchId_Extensions
				FROM 
					#LandingTempRDPA



/*============================================================================================================
			INSERT INTO  Inbound.Transaction FROM FinanceLanding.[ADM].[ReservingDataPremiumAlloc]  
===============================================================================================================*/
	INSERT INTO [FinanceDataContract].[Inbound].[Transaction] WITH(TABLOCK)
			( [Scenario],[Basis],[Account],[DataSet],[DateOfFact],[BusinessKey],[PolicyNumber],[InceptionDate],[ExpiryDate],[BindDate],[DueDate],[TrifocusCode]
				,[Entity],[Location],[YOA],[TypeOfBusiness],[SettlementCCY],[OriginalCCY],[IsToDate],[Value],[ValueOrig],[RowHash],[BusinessProcessCode]
				,[AuditSourceBatchID],[AuditGenerateDateTime],[StatsCode],[FK_Batch],[DeltaType],[FK_Allocation],[AuditUserCreate],[AuditCreateDateTime],AuditHost,[BoundDate]
			)

	SELECT [Scenario],[Basis],[Account],[DataSet],[DateOfFact],[BusinessKey],[PolicyNumber],[InceptionDate],[ExpiryDate],[BindDate],[DueDate],[TrifocusCode]
			,[Entity],[Location],[YOA],[TypeOfBusiness],[SettlementCCY],[OriginalCCY],[IsToDate],[Value],[ValueOrig],[RowHash],[BusinessProcessCode]
			,[AuditSourceBatchID],[AuditGenerateDateTime],[StatsCode],[FK_Batch],[DeltaType],[FK_Allocation],[AuditUserCreate],[AuditCreateDateTime],AuditHost,[BoundDate] 
	  FROM #LandingTempRDPA
	--WHERE DateOfFact='2020-12-15 00:00:00.000'

		
	    SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'ADM.ReservingDataPremiumAlloc', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into Inbound.Transaction table';

	IF EXISTS(SELECT 1 FROM [FinanceDataContract].Inbound.[Transaction] WHERE DataSet = @v_DataSet)
	BEGIN

		INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,RunDescription
								,[DataSet]
								,OriginalName
								,AuditSourceBatchID
								,AsAt
								)
				VALUES
								( @v_BatchId
								 ,'InBound'
								 ,NULL
								 ,@v_DataSet
								 ,NULL
								 ,NULL
								 ,@p_AccountingPeriod
								)
								,

								( @v_BatchId_Extensions
								,'InBound'
								,'ReInsuranceExtensions, the additional attributes to extend functionality of the transaction table.'
								,'ReInsuranceExtensions'
								,NULL
								,NULL
								,NULL
								);
		END

            -- LOG THE RESULT WITH SUCCESS
			SELECT @v_ActivityDateTime			= GETUTCDATE();

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStop
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT; 
         
		
        
		IF @Trancount = 0 
		COMMIT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, 'ADM.ReservingDataPremiumAlloc', 'ReservingDataPremiumAlloc LandingToInBound Succeeded';

		--Generate logging for success
		EXEC log.usp_LogLanding @Input = @Logging;

	END TRY

	BEGIN CATCH

		IF @Trancount = 0  
				ROLLBACK;
			
			
			-- LOG THE RESULT WITH ERROR--
				UPDATE [FinanceDataContract].[Inbound].[BatchQueue]
				SET Status='OutBoundFailed'
				WHERE PK_Batch=@v_BatchId AND [Status]='InBound' AND DataSet=@v_DataSet
				
			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

			

		    THROW;

		
	END CATCH;

END;