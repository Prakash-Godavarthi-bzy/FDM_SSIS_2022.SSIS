﻿CREATE TABLE [MDS].[ConformedTrifocusMapping](
	[TrifocusCode] [varchar](50) NOT NULL,
	[ConformedTrifocusMapping] [varchar](50) NULL,
	[AuditSourceBatchID] [varchar](255) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [varchar](255) NOT NULL,
	[AuditHost] [varchar](255) NULL
) ON [PRIMARY]
GO

ALTER TABLE [MDS].[ConformedTrifocusMapping] ADD  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [MDS].[ConformedTrifocusMapping] ADD  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [MDS].[ConformedTrifocusMapping] ADD  DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO