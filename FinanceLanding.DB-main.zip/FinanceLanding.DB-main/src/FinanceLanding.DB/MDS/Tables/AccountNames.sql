﻿CREATE TABLE [MDS].[AccountNames] (
    [PK_AccountNames] INT NOT NULL,
    [DataSet]         VARCHAR (200) NOT NULL,
    [AccountKey]      VARCHAR (255) NOT NULL,
    [AccountNames]    VARCHAR (200) NOT NULL,
	[AccountSignage]  INT			DEFAULT (1) NOT NULL,
    PRIMARY KEY CLUSTERED ([PK_AccountNames] ASC) WITH (FILLFACTOR = 90)
);
GO

EXEC sys.sp_addextendedproperty 
@name=N'description', 
@value=N'This table is loaded by a static data script: ...\FinanceLanding.DB\ContinuousIntegration\StaticTables\MDS.AccountNames.sql.
It needs to be in FinanceLanding as it is used by the load to determine signage.' , 
@level0type=N'SCHEMA',
@level0name=N'MDS', 
@level1type=N'TABLE',
@level1name=N'AccountNames'
GO


ALTER TABLE [MDS].[AccountNames] ADD  CONSTRAINT [IX_AccountKey] UNIQUE NONCLUSTERED 
(
	[AccountKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'the account key must be unique' , @level0type=N'SCHEMA',@level0name=N'MDS', @level1type=N'TABLE',@level1name=N'AccountNames', @level2type=N'CONSTRAINT',@level2name=N'IX_AccountKey'
GO

ALTER TABLE [MDS].[AccountNames] ADD  CONSTRAINT [IX_AccountNames] UNIQUE NONCLUSTERED 
(
	[AccountNames] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'the account name must be unique' , @level0type=N'SCHEMA',@level0name=N'MDS', @level1type=N'TABLE',@level1name=N'AccountNames', @level2type=N'CONSTRAINT',@level2name=N'IX_AccountNames'
GO

