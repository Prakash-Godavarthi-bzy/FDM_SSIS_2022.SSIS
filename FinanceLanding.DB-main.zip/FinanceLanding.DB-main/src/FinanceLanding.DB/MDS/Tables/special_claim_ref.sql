﻿CREATE TABLE [MDS].[special_claim_ref] (
    [spe_claim_ref_group_code] CHAR (12) NULL,
    [spe_description]          CHAR (15) NULL,
    [spe_include]              CHAR (1)  NULL,
    [INITIALISE]               INT       NULL
);

