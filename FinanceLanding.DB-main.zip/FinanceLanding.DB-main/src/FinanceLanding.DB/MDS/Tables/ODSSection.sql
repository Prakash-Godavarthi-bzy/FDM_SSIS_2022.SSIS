﻿CREATE TABLE [MDS].[ODSSection](
	[PK_Section] [int] IDENTITY(1,1) NOT NULL,
	[SectionReference] [varchar](255) NULL,
	[InceptionDate] [datetime] NULL,
	[ExpiryDate] [datetime] NULL,
	[YOA] [varchar](10) NULL,
	[ClaimBasis] [varchar](10) NULL,
	[MopCode] [varchar](10) NULL,
	[CobCode] [Varchar] (10) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [varchar](255) NOT NULL,
	[AuditHost] [varchar](255) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [MDS].[ODSSection] ADD  CONSTRAINT [DF_ODSSection_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [MDS].[ODSSection] ADD  CONSTRAINT [DF_ODSSection_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [MDS].[ODSSection] ADD  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO

EXEC sys.sp_addextendedproperty @name=N'description', @value=N'This table is loaded by a dtsx.
It needs to be in FinanceLanding as it is used by the load to determine signage.' , @level0type=N'SCHEMA',@level0name=N'MDS', @level1type=N'TABLE',@level1name=N'ODSSection'
GO