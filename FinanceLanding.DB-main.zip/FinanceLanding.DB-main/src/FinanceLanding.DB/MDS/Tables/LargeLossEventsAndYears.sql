﻿CREATE TABLE [MDS].[LargeLossEventsAndYears] (
    [Event_EurobaseName] VARCHAR (100) NULL,
    [EventYear]          INT           NULL,
    [Event_BeazleyName]  VARCHAR (100) NULL,
    [Include_In_Reports] BIT           NULL
);

