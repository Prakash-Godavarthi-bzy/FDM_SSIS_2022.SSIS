﻿CREATE TABLE [MDS].[claim_group_codes] (
    [clg_claim_group_code]   VARCHAR (12)  NULL,
    [clg_cla_syn_processing] INT           NULL,
    [clg_short_description]  VARCHAR (30)  NULL,
    [clg_group_description]  VARCHAR (240) NULL,
    [clg_loss_date_from]     DATETIME      NULL,
    [clg_loss_date_to]       DATETIME      NULL,
    [clg_xl_date]            DATETIME      NULL,
    [clg_market_cat_code]    VARCHAR (12)  NULL,
    [clg_war_indicator]      VARCHAR (1)   NULL,
    [clg_pcs_code]           VARCHAR (4)   NULL,
    [clg_market_indicator]   VARCHAR (1)   NULL,
    [INITIALISE]             INT           NULL
);

