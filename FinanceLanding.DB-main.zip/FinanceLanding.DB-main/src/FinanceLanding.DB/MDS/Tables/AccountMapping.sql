﻿CREATE TABLE [MDS].[AccountMapping] (
    [PK_AccountMapping] INT           IDENTITY (1, 1) NOT NULL,
    [Table]             VARCHAR (200) NULL,
    [FK_AccountKey]     INT           NULL,
    [L1]                VARCHAR (500) NULL,
    [L2]                VARCHAR (500) NULL,
    [L3]                VARCHAR (500) NULL,
    [AccountKey]        VARCHAR (20)  NULL,
    PRIMARY KEY CLUSTERED ([PK_AccountMapping] ASC) WITH (FILLFACTOR = 90)
);
GO


EXEC sys.sp_addextendedproperty 
@name=N'description', 
@value=N'The table is maintained by various procedures. You need to view the procedures to see how this is done. View dependancies in the object explorer to see the names of the procedures.' , 
@level0type=N'SCHEMA',
@level0name=N'MDS', 
@level1type=N'TABLE',
@level1name=N'AccountMapping'
GO
