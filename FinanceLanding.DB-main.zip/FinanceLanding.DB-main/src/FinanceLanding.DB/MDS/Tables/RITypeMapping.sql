﻿CREATE TABLE [MDS].[RITypeMapping](
	[RIPolicyType] [varchar](50) NULL,
	[Confirmed_RIPolicyType] [varchar](50) NULL
) ON [PRIMARY]
GO
EXEC sys.sp_addextendedproperty 
@name=N'description', 
@value=N'The table is maintained by various procedures. You need to view the procedures to see how this is done. View dependancies in the object explorer to see the names of the procedures.' , 
@level0type=N'SCHEMA',
@level0name=N'MDS', 
@level1type=N'TABLE',
@level1name=N'RITypeMapping'
GO
