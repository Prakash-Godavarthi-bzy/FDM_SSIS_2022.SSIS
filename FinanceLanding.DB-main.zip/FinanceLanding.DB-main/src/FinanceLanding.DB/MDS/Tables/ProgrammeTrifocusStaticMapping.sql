﻿CREATE TABLE [mds].[ProgrammeTrifocusStaticMapping](
	[Programme] [varchar](255) NOT NULL,
	[TrifocusCode] [varchar](100) NOT NULL,
	[TrifocusName] [varchar](255) NOT NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [varchar](255) NOT NULL,
	[AuditHost] [varchar](255) NULL
) ON [PRIMARY]
GO

ALTER TABLE [mds].[ProgrammeTrifocusStaticMapping] ADD  DEFAULT (getdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [mds].[ProgrammeTrifocusStaticMapping] ADD  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [mds].[ProgrammeTrifocusStaticMapping] ADD  DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO

