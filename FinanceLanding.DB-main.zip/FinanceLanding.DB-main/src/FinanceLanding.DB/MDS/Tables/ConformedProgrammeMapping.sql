﻿CREATE TABLE [MDS].[ConformedProgrammeMapping](
	[PK_ProgrammeMapping] [int] IDENTITY(1,1) NOT NULL,
	[ProgrammeCode] [varchar](50) NOT NULL,
	[ConformedProgrammeMapping] [varchar](50) NULL,
	[AuditSource] [varchar](255) NULL,
	[AuditGenerateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [varchar](255) NOT NULL
	) ON [PRIMARY]
GO

ALTER TABLE [MDS].[ConformedProgrammeMapping] ADD  DEFAULT (getutcdate()) FOR [AuditGenerateDateTime]
GO

ALTER TABLE [MDS].[ConformedProgrammeMapping] ADD  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO
