CREATE TABLE [MDS].[DQFix6107CreatedRI](
	[ID] [int] NULL,
	[QS_Adjustment] [numeric](38, 12) NULL,
	[ProgrammeCode] [nvarchar](255) NULL,
	[RIPolicyType] [nvarchar](255) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [MDS].[DQFix6107CreatedRI] ADD  CONSTRAINT [DF_ReservingData_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [MDS].[DQFix6107CreatedRI] ADD  CONSTRAINT [DF_ReservingData_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO