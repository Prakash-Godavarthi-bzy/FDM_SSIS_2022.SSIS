﻿CREATE TABLE [MDS].[ADMReservingClassMapping] (
    [ChangeTrackingMask]       INT              NULL,
    [Code]                     NVARCHAR (250)   NULL,
    [DepartmentName]           NVARCHAR (255)   NULL,
    [EnterDateTime]            DATETIME2 (7)    NULL,
    [EnterUserName]            NVARCHAR (100)   NULL,
    [EnterVersionNumber]       INT              NULL,
    [ID]                       INT              NULL,
    [LastChgDateTime]          DATETIME2 (7)    NULL,
    [LastChgUserName]          NVARCHAR (100)   NULL,
    [LastChgVersionNumber]     INT              NULL,
    [MUID]                     UNIQUEIDENTIFIER NULL,
    [Name]                     NVARCHAR (250)   NULL,
    [ReservingClassName]       NVARCHAR (255)   NULL,
    [ReservingClassNameMapped] NVARCHAR (255)   NULL,
    [ValidationStatus]         NVARCHAR (250)   NULL,
    [VersionFlag]              NVARCHAR (50)    NULL,
    [VersionName]              NVARCHAR (50)    NULL,
    [VersionNumber]            INT              NULL
);

