CREATE TABLE [MDS].[ClashIBNR2022prior](
	[ID] [int] NULL,
	[TriFocusName] [nvarchar](255) NULL,
	[YOA] [int] NULL,
	[CCY] [char](3) NULL,
	[ClashIBNR] [numeric](38, 12) NULL,
	[Period] [int] NULL,
	[TrifocusCode] [nvarchar](255) NULL,
	[EntitySet] [nvarchar](255) NULL,
	[ClashKey] [nvarchar](255) NULL,
	[RIPolicyType] [nvarchar](255) NULL,
	[ProgrammeCode] [nvarchar](255) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [MDS].[ClashIBNR2022prior] ADD  CONSTRAINT [DF_ClashIBNR_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [MDS].[ClashIBNR2022prior] ADD  CONSTRAINT [DF_ClashIBNR_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO
