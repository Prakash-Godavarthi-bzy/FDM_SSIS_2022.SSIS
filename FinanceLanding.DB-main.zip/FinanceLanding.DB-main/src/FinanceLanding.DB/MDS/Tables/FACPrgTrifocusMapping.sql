﻿CREATE TABLE [MDS].[FACPrgTrifocusMapping]
(
	[TrifocusCode] VARCHAR(25) NOT NULL, 
    [TrifocusName] VARCHAR(50) NOT NULL,
	[RIProgramme] VARCHAR(100) NOT NULL
)
