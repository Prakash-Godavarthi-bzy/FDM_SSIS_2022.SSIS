﻿
CREATE TABLE [MDS].[Catcode_Eventdate](
	[Event] [varchar](200) NULL,
	[Eventyear] [varchar](500) NULL,
	[EventDate] [datetime] NULL
) 

