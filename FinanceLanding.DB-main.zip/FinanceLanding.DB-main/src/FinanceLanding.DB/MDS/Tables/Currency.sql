﻿CREATE TABLE [MDS].[Currency] (
    [PK_Currency]     INT           IDENTITY (1, 1) NOT NULL,
    [CountryName]     VARCHAR (100) NULL,
    [CurrencyName]    VARCHAR (100) NULL,
    [CurrencyCode]    VARCHAR (100) NULL,
    [CurrencyCodeNum] INT           NULL,
    PRIMARY KEY CLUSTERED ([PK_Currency] ASC) WITH (FILLFACTOR = 90)
);

