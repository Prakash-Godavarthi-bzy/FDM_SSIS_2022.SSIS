﻿CREATE TABLE [MDS].[Intercompany_Rules](
	[Dataset] [varchar](25) NOT NULL,
	[GrossRI] [varchar](3) NOT NULL,
	[YOA] [varchar](10) NOT NULL,
	[Entity] [varchar](10) NOT NULL,
	[Trifocus] [varchar](25) NOT NULL,
	[Programme] [varchar](100) NOT NULL,
	[Percentage] [float] NOT NULL,
	[Flag] [varchar](20) NOT NULL,
	[PrioritySequence] [int] NOT NULL,
	[FromDOF] [date] NULL,
	[ToDOF] [date] NULL
)