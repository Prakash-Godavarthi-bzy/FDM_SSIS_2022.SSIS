﻿CREATE TABLE [MDS].[TreatyShareGenerationRules]
		(
				Pk_ShareID				INT IDENTITY(1,1)		NOT NULL,
				Dataset					VARCHAR(255)			NOT NULL,
				YOA						VARCHAR(5)				NOT NULL,
				TriFocusCode			VARCHAR(25)				NOT NULL,
				FromEntity				VARCHAR(25)				NOT NULL,
				ToEntity				VARCHAR(25 )			NOT NULL,
				TreatyName				VARCHAR(50)				NULL,
				CedePercentage			NUMERIC(4,4)			NULL,
				AuditSource				VARCHAR(50)				NULL,
				AuditGenerateDateTime	datetime				NOT NULL,
				AuditUserCreate			VARCHAR(55)				NOT NULL,
		)  ON [PRIMARY]
GO

ALTER TABLE [MDS].[TreatyShareGenerationRules] ADD  CONSTRAINT [DF_TreatyShareGenRules_AuditGenerateDatetime]  DEFAULT (getutcdate()) FOR [AuditGenerateDateTime]
GO

ALTER TABLE [MDS].[TreatyShareGenerationRules] ADD  CONSTRAINT [DF_TreatyShareGenRules_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO


EXEC sys.sp_addextendedproperty @name=N'description', @value=N'This table is loaded by a static script.
It needs to be in FinanceLanding as it is used by the load to determine rules using at Box3-4.' , @level0type=N'SCHEMA',@level0name=N'MDS', @level1type=N'TABLE',@level1name=N'TreatyShareGenerationRules'
GO
