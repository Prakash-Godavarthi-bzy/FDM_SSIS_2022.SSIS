CREATE TABLE [MDS].[InvalidRDrecords](
	[ID] [int] NULL,
	[ASAT] [int] NULL,
	[RDKey] [nvarchar](255) NULL,
	[YOA] [int] NULL,
	[TriangleGroup] [nvarchar](255) NULL,
	[Lookup] [nvarchar](255) NULL,
	[Periods] [int] NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [MDS].[InvalidRDrecords] ADD  CONSTRAINT [DF_InvalidRDrecords_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [MDS].[InvalidRDrecords] ADD  CONSTRAINT [DF_InvalidRDrecords_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO


