﻿CREATE PROCEDURE [MDS].[usp_LandingToInbound]
             @p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL		
AS

-- =============================================

-- http://git.bfl.local/Finance/FinanceLanding.DB
-- Unit tested via script(\src\FinanceLanding.DB\UnitTests\MDS_LandingToInbound.sql)

-- Original Author:		Ciprian Mandras <ciprian.mandras@beazley.com>
-- Create date: 2020-04-10 10:56:31.217
-- Description:	Loads MDS data from FinanceLanding : claim_group_codes (Eurobase), special_claim_ref (Eurobase) and LargeLossEventsAndYears (ADM) to Inbound.LargeLossCatCode

-- Change Author:		Mark Baekdal <mark.baekdal@beazley.com>
-- Change date: 2021-05-27 
-- Description:	The table Inbound.LargeLossCatCode has been changed to Inbound.CatCode & the code now gets all the BeazleyCatCodes, not just the large loss cat codes.

-- =============================================	
			
BEGIN

		SET NOCOUNT ON;

		DECLARE @Trancount INT= @@Trancount;
		DECLARE @v_ErrorMessage NVARCHAR(4000);

		DECLARE @v_RC							INT;
		DECLARE @v_ActivityLogTag				BIGINT;
		DECLARE @v_ActivitySource				SMALLINT;
		DECLARE @v_ActivityType					SMALLINT;
		DECLARE @v_ActivityStatusStart			SMALLINT;
		DECLARE @v_ActivityStatusStop			SMALLINT;
		DECLARE @v_ActivityStatusFail			SMALLINT;
		DECLARE @v_ActivityHost					VARCHAR(100);
		DECLARE @v_ActivityDatabase				VARCHAR(100);
		DECLARE @v_ActivityName					VARCHAR(100);
		DECLARE @v_ActivityDateTime				DATETIME2(2);
		DECLARE @v_ActivityMessage				NVARCHAR(4000);
		DECLARE @v_ActivityErrorCode			NVARCHAR(50);
		DECLARE @v_ActivityLogIdIn				BIGINT;
		DECLARE @v_ActivityLogIdOut				BIGINT;
		DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId;
		DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
		DECLARE @v_AffectedRows					INT				= 0;

		SELECT @v_ActivityStatusStart = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'STARTED';

		SELECT @v_ActivityStatusStop = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'SUCCEEDED';

		SELECT @v_ActivityStatusFail = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'ERRORED';

		DECLARE @v_BatchId INT;
  
		/* Log the start of the insert */

		BEGIN TRY

				SELECT   
					 @v_ActivityLogTag		        = NULL
					,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
					,@v_ActivityType				= (SELECT PK_ActivityType	
														FROM Orchestram.Log.ActivityType	
														WHERE ActivityType = CASE 
																				WHEN @p_ParentActivityLogId IS NULL 
																					THEN 'Manual process' 
																					ELSE 'Automated process' 
																				END)
					,@v_ActivityHost				= @@SERVERNAME
					,@v_ActivityName				= 'Load data into Inbound.CatCode, Inbound.AccountName'
					,@v_ActivityDatabase			= 'FinanceLanding'
					,@v_ActivityDateTime			= GETUTCDATE()
					,@v_ActivityMessage				= NULL
					,@v_ActivityErrorCode			= NULL;

				EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
							 @p_ParentActivityLogId
							,@v_ActivityLogTag
							,@v_ActivitySource
							,@v_ActivityType
							,@v_ActivityStatusStart
							,@v_ActivityHost
							,@v_ActivityDatabase
							,@v_ActivityJobId
							,@v_ActivitySSISExecutionId
							,@v_ActivityName
							,@v_ActivityDateTime
							,@v_ActivityMessage
							,@v_ActivityErrorCode
							,@v_AffectedRows
							,@v_ActivityLogIdIn OUTPUT;

				SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

				-- mapping 

				IF @Trancount = 0
					BEGIN TRAN;

				------------------------------------------------

				INSERT INTO [dbo].[Batch]
					([CreateDate],[DataSet],[LatestBusinesKey]) 
				VALUES  
					(GETDATE(),'CatCode', NULL);
				
				SELECT @v_BatchId = SCOPE_IDENTITY();


				declare @v_BatchId_Account int

				INSERT INTO [dbo].[Batch]
					([CreateDate],[DataSet],[LatestBusinesKey]) 
				VALUES  
					(GETDATE(),'AccountName', NULL);
				
				SELECT @v_BatchId_Account = SCOPE_IDENTITY();


				truncate table FinanceDataContract.Inbound.CatCode
				truncate table FinanceDataContract.Inbound.AccountName
				/*
--request I1B-677, modifications are commented and marked by request name
--NOTE:  (a) Old approach of MDS tables in FL and outbound.AccountName in FDC are no longer being used.  
--dim.Account is an inferred dimension on the TDH, and therefore we have been requested to create a 
--separate ticket for direct update following addition of accounts to the dim.Account via inferred update. 
--[LINK TICKET].  This code has now been temporaily commented out.  (b) A Master Data ticket will also be 
--created to improve Account management across all sources consistently [LINK TICKET].  (c) Account signage 
--has also been adjusted due to point (a) above, and is now driven through code directly

				DROP TABLE IF EXISTS #temp_AccountNames;

				CREATE TABLE #temp_AccountNames(
					[AccountKey] [varchar](255)  NULL,
					[AccountNames] [varchar](200)  NULL)

				insert into #temp_AccountNames values
				 ('PC-LS-OT','Gross Premium Cash - Lloyd''s Settled - Received')
				,('BC-LS-OT','Brokerage Cash - Lloyd''s Settled - Received')
				,('PC-SD-OT','Gross Premium Cash - Settled Direct - Received')
				,('BC-SD-OT','Brokerage Cash - Settled Direct - Received')
				,('PC-OS-OT','Gross Premium Cash - Other Settled - Received')
				,('BC-OS-OT','Brokerage Cash - Other Settled - Received')
				,('PC-LS-RT','Net Premium Cash - Lloyd''s Settled - Reinstatement')
				,('PC-SD-RT','Net Premium Cash - Settled Direct - Reinstatement')
				,('PC-OS-RT','Net Premium Cash - Other Settled - Reinstatement')
				,('PC-LS-PC','Net Premium Cash - Lloyd''s Settled - Profit Commission')
				,('PC-SD-PC','Net Premium Cash - Settled Direct  - Profit Commission')
				,('PC-OS-PC','Net Premium Cash - Other Settled - Profit Commission')
				*/
				insert into FinanceDataContract.Inbound.AccountName
				(
					[AccountKey]
					,[AccountNames]
					,[FK_Batch]
				)
				select 
					 r.AccountKey
					,r.AccountNames--,isnull(temp.AccountNames,r.AccountNames) --request I1B-677
					,@v_BatchId_Account
				from
				(
					select 
						an.AccountKey
						,an.AccountNames
					from	
						[FinanceLanding].[MDS].[AccountNames] an

					union

					select 
						am.AccountKey
						,an.AccountNames
					from	
						[FinanceLanding].[MDS].[AccountMapping] am
						left join [FinanceLanding].[MDS].[AccountNames] an on an.AccountKey = am.AccountKey
				)r
				--left join #temp_AccountNames temp on r.AccountKey = temp.AccountKey --request I1B-677

				/* --request I1B-677
				delete from FinanceDataContract.Inbound.AccountName
				where AccountKey in 
				('BC-LS-RT','BC-SD-RT','BC-OS-RT','BC-LS-PC','BC-SD-PC','BC-OS-PC')

				insert into FinanceDataContract.Inbound.AccountName values
				('LBSC-LS-OT','LBS Commission Cash - Lloyd''s Settled - Received',@v_BatchId_Account)
				,('LBSC-SD-OT','LBS Commission Cash - Settled Direct - Received',@v_BatchId_Account)
				,('LBSC-OS-OT','LBS Commission Cash - Other Settled - Received',@v_BatchId_Account)
				,('LBSC-LS-RT','LBS Commission Cash - Lloyd''s Settled - Reinstatement',@v_BatchId_Account)
				,('LBSC-SD-RT','LBS Commission Cash - Settled Direct - Reinstatement',@v_BatchId_Account)
				,('LBSC-OS-RT','LBS Commission Cash - Other Settled - Reinstatement',@v_BatchId_Account)
				,('LBSC-LS-PC','LBS Commission Cash - Lloyd''s Settled - Profit Commission',@v_BatchId_Account)
				,('LBSC-SD-PC','LBS Commission Cash - Settled Direct - Profit Commission',@v_BatchId_Account)
				,('LBSC-OS-PC','LBS Commission Cash - Other Settled - Profit Commission',@v_BatchId_Account)
				*/


				insert into FinanceDataContract.Inbound.CatCode
				(
					 MarketCatCode			
					,BeazleyCatCode			
					,BeazleyCatDesription	
					,BeazleySpecial			
					,EventYear				
					,BeazleyEventName		
					,LargeLossIndicator	
					,FK_Batch
				)
				SELECT 
					 MarketCatCode			=		cgc.clg_market_cat_code
					,BeazleyCatCode			=		RTRIM(LTRIM(cgc.clg_claim_group_code))
					,BeazleyCatDesription	=		cgc.clg_short_description
					,BeazleySpecial			=		scr.spe_description
					,EventYear				=		YEAR(cgc.clg_loss_date_from)
					,BeazleyEventName		=		lle.Event_BeazleyName
					,LargeLossIndicator		=		case when lle.Event_BeazleyName is null then 0 else 1 end
					,FK_Batch				=		@v_BatchId
				FROM 
					MDS.claim_group_codes cgc

					LEFT JOIN MDS.special_claim_ref scr 
						ON RTRIM(LTRIM(cgc.clg_claim_group_code)) = RTRIM(LTRIM(scr.spe_claim_ref_group_code))

					LEFT JOIN MDS.LargeLossEventsAndYears lle
						ON  lle.Event_EurobaseName	= cgc.clg_short_description
						AND lle.Include_In_Reports = 1
				WHERE
					cgc.clg_claim_group_code IS NOT NULL

				SELECT @v_AffectedRows = @@ROWCOUNT


				INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,[DataSet]
								,RunDescription
								)
				VALUES
								( @v_BatchId_Account
								 ,'InBound'
								 ,'AccountName'
								 ,'Loaded from MDS source via [MDS].[usp_LandingToInbound].'
								)
								,
								( @v_BatchId
								 ,'InBound'
								 ,'CatCode'
								 ,'Loaded from MDS source via [MDS].[usp_LandingToInbound].'
								)

				-------------------------------------------------------------------
		
				-- LOG THE RESULT WITH SUCCESS

				SELECT @v_ActivityDateTime			= GETUTCDATE();

				EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
						 @p_ParentActivityLogId
						,@v_ActivityLogTag
						,@v_ActivitySource
						,@v_ActivityType
						,@v_ActivityStatusStop
						,@v_ActivityHost
						,@v_ActivityDatabase
						,@v_ActivityJobId
						,@v_ActivitySSISExecutionId
						,@v_ActivityName
						,@v_ActivityDateTime
						,@v_ActivityMessage
						,@v_ActivityErrorCode
						,@v_AffectedRows
						,@v_ActivityLogIdIn OUTPUT;

				IF @Trancount = 0
					COMMIT;

			END TRY

			BEGIN CATCH

				-- CANCEL TRAN
				IF @Trancount = 0 AND @@TRANCOUNT <> 0
					ROLLBACK;
			
				-- LOGIN THE RESULT WITH ERROR

				SELECT   @v_ActivityDateTime				= GETUTCDATE()
						,@v_ActivityLogTag					= @v_ActivityLogIdIn
						,@v_ActivityMessage					= ERROR_MESSAGE()
						,@v_ActivityErrorCode				= ERROR_NUMBER();

				EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
						 @p_ParentActivityLogId
						,@v_ActivityLogTag
						,@v_ActivitySource
						,@v_ActivityType
						,@v_ActivityStatusFail
						,@v_ActivityHost
						,@v_ActivityDatabase
						,@v_ActivityJobId
						,@v_ActivitySSISExecutionId
						,@v_ActivityName
						,@v_ActivityDateTime
						,@v_ActivityMessage
						,@v_ActivityErrorCode
						,@v_AffectedRows
						,@v_ActivityLogIdIn OUTPUT;

				THROW;

			END CATCH;


					
END;
