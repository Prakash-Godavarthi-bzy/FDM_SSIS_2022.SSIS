﻿Create view [MDS].[vw_CatCode]
as
SELECT 
					 MarketCatCode			=		cgc.clg_market_cat_code
					,BeazleyCatCode			=		RTRIM(LTRIM(cgc.clg_claim_group_code))
					,BeazleyCatDesription	=		cgc.clg_short_description
					,BeazleySpecial			=		scr.spe_description
					,EventYear				=		YEAR(cgc.clg_loss_date_from)
					,BeazleyEventName		=		lle.Event_BeazleyName
					,LargeLossIndicator		=		case when lle.Event_BeazleyName is null then 0 else 1 end
					--,FK_Batch				=		@v_BatchId
				FROM 
					MDS.claim_group_codes cgc

					LEFT JOIN MDS.special_claim_ref scr 
						ON RTRIM(LTRIM(cgc.clg_claim_group_code)) = RTRIM(LTRIM(scr.spe_claim_ref_group_code))

					LEFT JOIN MDS.LargeLossEventsAndYears lle
						ON  lle.Event_EurobaseName	= cgc.clg_short_description
						AND lle.Include_In_Reports = 1
				WHERE
					cgc.clg_claim_group_code IS NOT NULL



