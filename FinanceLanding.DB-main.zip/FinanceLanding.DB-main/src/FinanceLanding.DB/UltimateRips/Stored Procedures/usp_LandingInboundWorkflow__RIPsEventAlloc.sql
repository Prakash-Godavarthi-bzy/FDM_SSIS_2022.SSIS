﻿CREATE PROCEDURE [Ultrea].[usp_LandingInboundWorkflow_RIPsEventAlloc] @DOF INT
AS

/*
Modified by : venkat.yerravati@beazley.com
Modified Date : 23/10/2024
Description : Partial tactical to Strategic(gets the balances file from Katie) https://beazley.atlassian.net/browse/I1B-5409
			  It is being used in [Ultrea].[usp_LandingToInboundToOutbound_RIPsEventAlloc] 
*/

BEGIN


	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;

	/*======================================================Logging Starts==================================================*/
	--DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'RIPsEventAlloc';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= NULL;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	--DECLARE @ContractType					CHAR(3)			= 'RDEA';
	DECLARE		@p_ParentActivityLogId		BIGINT			= NULL

	DECLARE @v_Dataset varchar(50)=@v_ActivityDatabase
	DECLARE @v_BatchId                   INT             = NULL;
	DECLARE @v_BatchId_Extensions INT;



	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';

	INSERT INTO [dbo].[Batch]([CreateDate],[DataSet]) 
	VALUES  (GETDATE(),@v_Dataset);

	SELECT @v_BatchId = SCOPE_IDENTITY();

	SET @v_ActivityJobId=@v_BatchId

	/* Log the start of the insert */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'Ultrea.usp_LandingInboundWorkflow_RIPsEventAlloc'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'Load data into Inbound.Transaction for RIPsEventAlloc Excel Direct Load'
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;
	
/*==================Logging End======================*/


	BEGIN TRY
		IF @Trancount = 0 
			BEGIN TRAN;

		/*
=============================================================================================
	Create BatchID In landing
==============================================================================================
*/

	declare 
		 @Scenario char(1)				= 'F' 
		,@Basis char(1)					= 'E'
		,@DefaultDate date				= CAST('01-01-1980' as date)
		,@TypeOfBusiness char(1)		= '-'
		--,@Location char(1)				= '-'
		,@IsToDate char(1)				= 'Y'
		,@BusinessProcessCode char(2)	= 'T1'
		,@AuditHost varchar(255)		= CAST(SERVERPROPERTY('MachineName') as varchar(255))
		,@StatsCode varchar(25)			= null
		--,@DateOfFact date				= convert(date,convert(char(8),@p_AccountingPeriod * 100 + 1),112)


	

	INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'Ultrea.usp_LandingInboundWorkflow_RIPsEventAlloc', ' '+CONVERT(VARCHAR,@v_BatchId)+' Batch Created';

	
	if object_id('tempdb..#LandingTempRipsEvent') is not null drop table #LandingTempRipsEvent

	SELECT 
	   Scenario=ISNULL(LTRIM(RTRIM(Scenario)),@Scenario)
		,Basis= ISNULL(nullif(LTRIM(RTRIM([Basis])),''),@Basis)			
      ,[Account]=LTRIM(RTRIM([Account]))
      ,[Dataset]=ISNULL(nullif(LTRIM(RTRIM([Dataset])),''),@v_Dataset)
      ,[DateOfFact]=LTRIM(RTRIM(DOF))
      ,[BusinessKey]=LTRIM(RTRIM([BusinessKey]))
      ,[PolicyNumber]=ISNULL(nullif(LTRIM(RTRIM([PolicyNumber])),''),'NOPOLICY')
      ,[InceptionDate]=ISNULL(LTRIM(RTRIM([InceptionDate])),@DefaultDate)
      ,[ExpiryDate]=ISNULL(LTRIM(RTRIM([ExpiryDate])),@DefaultDate)
      ,[BindDate]=ISNULL(LTRIM(RTRIM([BindDate])),@DefaultDate)
      ,[DueDate]=ISNULL(LTRIM(RTRIM([DueDate])),@DefaultDate)
      ,[TrifocusCode]=LTRIM(RTRIM([TrifocusCode]))
      ,[Entity]=LTRIM(RTRIM([Entity]))
	  ,[Location]=(LTRIM(RTRIM([Location])))
      ,[YOA]=LTRIM(RTRIM([YOA]))
      ,[TypeOfBusiness]=ISNULL(nullif(LTRIM(RTRIM([TypeOfBusiness])),''),@TypeOfBusiness)
	  ,[SettlementCCY]=LTRIM(RTRIM([SettlementCCY]))
      ,[OriginalCCY]=LTRIM(RTRIM([OriginalCCY]))
	  ,[IsToDate]=ISNULL(LTRIM(RTRIM([IsToDate])),@IsToDate)
      ,[Value]
	  ,[Value] [ValueOrig]
	 -- ,RowHash=HASHBYTES('SHA2_512',CONCAT(BusinessKey				,'§~§',ISNULL(TrifocusCode,'')
		--									-- extended values
		--									,ISNULL(BeazleyCatCode,'')	,'§~§'
		--									--,ISNULL(ProgrammeCode,'')	,'§~§'
		--									)
		--				)
		--,[RowHash_Transaction_Reserving_ReInsurance_Extensions]=HASHBYTES('SHA2_512',CONCAT(
		--									-- extended values
		--									ISNULL(BeazleyCatCode,'')		,'§~§'
		--									--,ISNULL(ProgrammeCode,'')	,'§~§'
		--									)
		--				)
	,RowHash = dbo.fn_RowHashForTransactions('T' -- <@RowHashType, char(1),>
															, @Scenario --,<@Scenario, nvarchar(2000),>
															, Account --,<@Account, nvarchar(2000),>
															, 'RIPsEventAlloc' --,<@DataSet, nvarchar(2000),>
															, [BusinessKey] --,<@BusinessKey, nvarchar(2000),>
															, PolicyNumber --,<@PolicyNumber, nvarchar(2000),>
															, [InceptionDate] --,<@InceptionDate, date,>
															, [ExpiryDate] --,<@ExpiryDate, date,>
															, @DefaultDate --,<@BindDate, date,>
															, @DefaultDate --,<@DueDate, date,>
															, [TrifocusCode] --,<@TrifocusCode, nvarchar(2000),>
															, [Entity] --,<@Entity, nvarchar(2000),>
															, [YOA] --,<@YOA, nvarchar(2000),>
															, @TypeOfBusiness --,<@TypeOfBusiness, nvarchar(2000),>
															, @StatsCode --,<@StatsCode, nvarchar(2000),>
															, [SettlementCCY] --,<@SettlementCCY, nvarchar(2000),>
															, [SettlementCCY] --,<@OriginalCCY, nvarchar(2000),>
															, @IsToDate --,<@IsToDate, nvarchar(2000),>
															, @Basis --,<@Basis, nvarchar(2000),>
															, [Location] --,<@Location, nvarchar(2000),>
															, @BusinessProcessCode --,<@BusinessProcessCode, nvarchar(2000),>
															, NULL --,<@BoundDate, date,>
															, NULL)
		,[RowHash_Transaction_Reserving_ReInsurance_Extensions]=HASHBYTES('SHA2_512',CONCAT(
											-- extended values
											ISNULL(BeazleyCatCode,'')		,'§~§'
											--,ISNULL(ProgrammeCode,'')	,'§~§'
											)
						)
	  ,[BusinessProcessCode]=ISNULL(nullif(LTRIM(RTRIM([BusinessProcessCode])),''),@BusinessProcessCode)
	  ,[AuditSourceBatchID]=CAST(@v_BatchId AS VARCHAR (50))
	  ,[AuditGenerateDateTime]=GETUTCDATE()
      ,[StatsCode]= ISNULL(nullif(LTRIM(RTRIM([StatsCode])),''),null)	  
	  ,[FK_Batch]=@v_BatchId     
      ,[DeltaType]=NULL
      ,[FK_Allocation]=null
      ,[AuditUserCreate]
	  ,[AuditCreateDateTime]=GETUTCDATE()
      ,AuditHost=@AuditHost
      ,[BoundDate]=ISNULL(nullif(LTRIM(RTRIM([BoundDate])),''),@DefaultDate)
	  ,BeazleyCatCode=LTRIM(RTRIM([BeazleyCatCode]))
	  INTO #LandingTempRipsEvent
	FROM [FinanceLanding].[Ultrea].[UltimateRIPsEventAlloc]
	WHERE DOF=CONVERT(DATETIME,CAST(@DOF AS VARCHAR(10))+'01',112)
    ------/* Delete the current lines from Inbound ... */

	DELETE
	FROM [FinanceDataContract].[Inbound].[Transaction]
	WHERE [DataSet] = @v_DataSet

	DELETE  RB from [FinanceDataContract].[Inbound].[Transaction_Reserving_ReInsurance_Extensions_Bridge] RB
	JOin [FinanceDataContract].[Inbound].[Transaction_Reserving_ReInsurance_Extensions] RE
    on RB.RowHash_Transaction_Reserving_ReInsurance_Extensions=RE.RowHash_Transaction_Reserving_ReInsurance_Extensions
	Where RE.[datasetname]='RIPsEventAlloc'

	DELETE [FinanceDataContract].[Inbound].[Transaction_Reserving_ReInsurance_Extensions]
	WHERE  DataSetname='RIPsEventAlloc'

	----------/*Insert into batch table...*/----------------
		INSERT INTO [dbo].[Batch]
			([CreateDate],[DataSet],[LatestBusinesKey]) 
		VALUES  
			(GETDATE(),'Reserving_ReInsuranceExtensions', NULL);

		SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();

		INSERT INTO  [FinanceDataContract].[Inbound].[Transaction_Reserving_ReInsurance_Extensions_Bridge] WITH(TABLOCK)
			(
				[RowHash_Transaction]
				,[RowHash_Transaction_Reserving_ReInsurance_Extensions]
				,[FK_Batch]
			)
			SELECT DISTINCT
				[RowHash]
				,[RowHash_Transaction_Reserving_ReInsurance_Extensions]
				,@v_BatchId_Extensions
			FROM 
				#LandingTempRipsEvent

			INSERT INTO  [FinanceDataContract].[Inbound].[Transaction_Reserving_ReInsurance_Extensions] WITH(TABLOCK)
				(
					[RowHash_Transaction_Reserving_ReInsurance_Extensions]
					,[Special]
					,[datasetname]
					,[datasetgroup]
					,[att_cat]
					,[trianglegroup]
					,[FK_Batch]
					,[BeazleyCatCode]
				)
				SELECT DISTINCT
					[RowHash_Transaction_Reserving_ReInsurance_Extensions]
					,Null AS [Special]
					,Dataset
					,Null as [datasetGroup]
					,NUll as [att_Cat]		
					,NULL AS [TriangleGroup]			
					,@v_BatchId_Extensions
					,BeazleyCatCode
				FROM 
					#LandingTempRipsEvent
				

/*============================================================================================================
			INSERT INTO  Inbound.Transaction FROM FinanceLanding.[ADM].[ReservingDataEventAlloc] 
===============================================================================================================*/
	INSERT INTO [FinanceDataContract].[Inbound].[Transaction] WITH(TABLOCK)
			( [Scenario],[Basis],[Account],[DataSet],[DateOfFact],[BusinessKey],[PolicyNumber],[InceptionDate],[ExpiryDate],[BindDate],[DueDate],[TrifocusCode]
				,[Entity],[Location],[YOA],[TypeOfBusiness],[SettlementCCY],[OriginalCCY],[IsToDate],[Value],[ValueOrig],[RowHash],[BusinessProcessCode]
				,[AuditSourceBatchID],[AuditGenerateDateTime],[StatsCode],[FK_Batch],[DeltaType],[FK_Allocation],[AuditUserCreate],[AuditCreateDateTime],AuditHost,[BoundDate]
			)

	SELECT [Scenario],[Basis],[Account],[DataSet],[DateOfFact],[BusinessKey],[PolicyNumber],[InceptionDate],[ExpiryDate],[BindDate],[DueDate],[TrifocusCode]
			,[Entity],[Location],[YOA],[TypeOfBusiness],[SettlementCCY],[OriginalCCY],[IsToDate],[Value],[ValueOrig],[RowHash],[BusinessProcessCode]
			,[AuditSourceBatchID],[AuditGenerateDateTime],[StatsCode],[FK_Batch],[DeltaType],[FK_Allocation],[AuditUserCreate],[AuditCreateDateTime],AuditHost,[BoundDate] 
	  FROM #LandingTempRipsEvent
	--WHERE DateOfFact='2020-12-15 00:00:00.000'

             SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'Ultrea.usp_LandingInboundWorkflow_RIPsEventAlloc', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into Inbound.Transaction table';

		INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,RunDescription
								,[DataSet]
								,OriginalName
								,AuditSourceBatchID
								,AsAt
								)
				VALUES
								( @v_BatchId
								 ,'InBound'
								 ,null
								 ,@v_DataSet
								 ,NULL
								 ,NULL
								 ,@DOF
								)
								,

								( @v_BatchId_Extensions
								,'InBound'
								,'ReservingReInsuranceExtensions, the additional attributes to extend functionality of the transaction table.'
								,'Reserving_ReInsuranceExtensions'
								,NULL
								,NULL
								,@DOF
								);


            -- LOG THE RESULT WITH SUCCESS
			SELECT @v_ActivityDateTime			= GETUTCDATE();

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStop
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;
        		
	 --   if exists(select 1 from [FinanceDataContract].Inbound.[Transaction] where DataSet = @v_DataSet)
		--begin
		--	--select 'exists'
		--	Delete RB from
		--	FinanceDataContract.Outbound.[Transaction] t
		--	left join [FinanceDataContract].[outbound].[Transaction_Reserving_ReInsurance_Extensions_Bridge] RB on t.RowHash = rb.RowHash_Transaction
		--	left JOIN [FinanceDataContract].[outbound].[Transaction_Reserving_ReInsurance_Extensions] EX
		--	on RB.RowHash_Transaction_Reserving_ReInsurance_Extensions=EX.RowHash_Transaction_Reserving_ReInsurance_Extensions
		--	Where EX.[datasetname]='RIPsEventAlloc'

		--	DELETE [FinanceDataContract].[Outbound].[Transaction_Reserving_ReInsurance_Extensions]
		--	WHERE DataSetname='RIPsEventAlloc'

		--	exec [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_Reserving_ReInsuranceExtensions]
		--end

		IF @Trancount = 0 
		COMMIT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, 'Ultrea.usp_LandingInboundWorkflow_RIPsEventAlloc', 'RipsDataEventAlloc LandingToInBound Succeeded';

		--Generate logging for success
		EXEC log.usp_LogLanding @Input = @Logging;

	END TRY

	BEGIN CATCH

		IF @Trancount = 0  
				ROLLBACK;
			
			
			-- LOG THE RESULT WITH ERROR--
				UPDATE [FinanceDataContract].[Inbound].[BatchQueue]
				SET Status='OutBoundFailed'
				WHERE PK_Batch=@v_BatchId AND [Status]='InBound' AND DataSet=@v_DataSet
				
			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

			

		    THROW;

		
	END CATCH;

END;