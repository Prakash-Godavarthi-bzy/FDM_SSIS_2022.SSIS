﻿CREATE TABLE [XLS].[LossRatio] (
    [FileName]             NVARCHAR (255) NULL,
    [LoadDate]             DATETIME2 (7)  NULL,
    [Division_BI]          NVARCHAR (255) NULL,
    [TrifocusCode_BI]      NVARCHAR (255) NULL,
    [Trifocus_BI]          NVARCHAR (255) NULL,
    [ReservingClass2_EI]   NVARCHAR (255) NULL,
    [ReservingClassMapped] NVARCHAR (255) NULL,
    [LatestBusinessPlan]   NVARCHAR (255) NULL,
    [Comments]             NVARCHAR (255) NULL,
    [2017]                 NVARCHAR (100) NULL,
    [2018]                 NVARCHAR (100) NULL,
    [2019]                 NVARCHAR (100) NULL,
    [2020]                 NVARCHAR (100) NULL
);

