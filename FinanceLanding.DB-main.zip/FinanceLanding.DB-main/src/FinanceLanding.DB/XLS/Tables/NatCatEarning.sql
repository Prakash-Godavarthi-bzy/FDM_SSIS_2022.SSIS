﻿CREATE TABLE [XLS].[NatCatEarning] (
    [FileName]       NVARCHAR (255)   NULL,
    [LoadDate]       DATETIME2 (7)    NULL,
    [Quarter]        NVARCHAR (50)    NULL,
    [Trifocus_Group] NVARCHAR (255)   NULL,
    [Pct_unearned]   NUMERIC (29, 16) NULL,
    [Department]     NVARCHAR (255)   NULL,
    [YOA]            NVARCHAR (50)    NULL,
    [Inception Year] NVARCHAR (50)    NULL,
    [Entity]         NVARCHAR (255)   NULL, 
    [ValidationFailed] BIT NOT NULL DEFAULT 0
);

