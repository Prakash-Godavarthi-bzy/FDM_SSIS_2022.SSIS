﻿create view [XLS].[InboundPattern_NatCatEarning_Validation_Duplicates]
as


select 
	[filename]
	,Trifocus_Group
	,[YOA]
	,[Inception Year]
	,[Quarter]
	,rows_submitted = count(*)
from
	XLS.InboundPattern_NatCatEarning
group by
	[filename]
	,Trifocus_Group
	,[YOA]
	,[Inception Year]
	,[Quarter]
having
	count(*)<>1
GO


