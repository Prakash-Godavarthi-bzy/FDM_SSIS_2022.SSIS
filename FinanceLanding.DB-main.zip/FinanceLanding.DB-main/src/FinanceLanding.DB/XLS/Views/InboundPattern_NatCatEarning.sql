﻿

CREATE view XLS.InboundPattern_NatCatEarning

as

	SELECT           
		nce.[filename]
		,tf.TrifocusCode            
		,nce.Trifocus_Group          
		,nce.[YOA]                             
		,nce.[Inception Year]                     
		,DevelopmentPercentageIncrement = -1 * 
										(
											nce.pct_unearned - LAG(nce.pct_unearned, 1, 1.00) OVER 
											(
												PARTITION BY  
													[Trifocus_Group]
													,[YOA]
													,[FileName]
													,[Inception Year]
												ORDER BY     
													CAST([Quarter] AS INT)
											)
										)
		,nce.pct_unearned
		,nce.[Quarter]
		,nce.LoadDate
		,nce.[ValidationFailed]
	FROM    
		[XLS].[NatCatEarning] nce
		LEFT JOIN [MDS].[TriFocus] tf ON tf.[name] = nce.Trifocus_Group
GO


