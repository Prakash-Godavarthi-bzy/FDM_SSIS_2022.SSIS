﻿

CREATE view [XLS].[InboundPattern_NatCatEarning_Validation_UnmatchedTrifocus]

as

SELECT distinct
	[filename]
	,[Trifocus_Group]
  FROM [XLS].[InboundPattern_NatCatEarning]
  where
	[TrifocusCode] is null


GO


