﻿

CREATE view [XLS].[InboundPattern_NatCatEarning_Validation_DevelopmentPercentageIncrement]
as


 --Get the data set if one of the increments is greater than one.
select 
	 s.[filename]
	,s.Trifocus_Group
	,s.[YOA]
	,s.[Inception Year]
	,s.DevelopmentPercentageIncrement 
	,s.[pct_unearned]
	,s.[Quarter]
from
	XLS.InboundPattern_NatCatEarning s
	join
	(
		select 
			[filename]
			,Trifocus_Group
			,[YOA]
			,[Inception Year]
			,DevelopmentPercentageIncrement 
			,[pct_unearned]
		from
			XLS.InboundPattern_NatCatEarning
		where
			[pct_unearned] > 1
			or
			[pct_unearned] < 0
	) t
		on  t.[filename] = s.[filename]
		and t.Trifocus_Group = s.Trifocus_Group
		and t.[YOA] = s.[YOA]
		and t.[Inception Year] = s.[Inception Year]
