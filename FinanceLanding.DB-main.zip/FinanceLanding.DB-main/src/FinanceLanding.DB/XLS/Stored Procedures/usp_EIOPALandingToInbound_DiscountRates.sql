﻿




CREATE PROCEDURE [XLS].[usp_EIOPALandingToInbound_DiscountRates]

             @p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL

AS
-- =============================================

-- http://git.bfl.local/Finance/FinanceLanding.DB
-- Unit tested via script(\src\FinanceLanding.DB\UnitTests\NatCatEarning_LandingToInbound.sql)

-- Original Author:		Ionela Ciornei <Ionela-Minodora.Ciornei@beazley.com>
-- Create date: 11/02/2020
-- Description:	Loads EIOPA data from FinanceLanding to Inbound.DiscountRates

-- Last Modified by Author:		Mark Baekdal <Mark.Baekdal@beazley.com>
-- Modified date: 18/02/2020
-- Description:	Coded review changes, comments inline.

-- =============================================			
BEGIN

		SET NOCOUNT ON

		DECLARE @v_ErrorMessage NVARCHAR(4000)

		DECLARE @Trancount INT= @@Trancount;
		DECLARE @v_RC							INT
		DECLARE @v_ActivityLogTag				BIGINT
		DECLARE @v_ActivitySource				SMALLINT
		DECLARE @v_ActivityType					SMALLINT
		DECLARE @v_ActivityStatusStart			SMALLINT
		DECLARE @v_ActivityStatusStop			SMALLINT
		DECLARE @v_ActivityStatusFail			SMALLINT
		DECLARE @v_ActivityHost					VARCHAR(100)
		DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'EIOPA'
		DECLARE @v_ActivityName					VARCHAR(100)
		DECLARE @v_ActivityDateTime				DATETIME2(2)
		DECLARE @v_ActivityMessage				NVARCHAR(4000)
		DECLARE @v_ActivityErrorCode			NVARCHAR(50)
		DECLARE @v_ActivityLogIdIn				BIGINT
		DECLARE @v_ActivityLogIdOut				BIGINT
		DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId
		DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL
		DECLARE @v_AffectedRows					INT
		DECLARE @v_BatchId                      INT             = NULL
		DECLARE @v_Asat                         INT             = NULL

 BEGIN TRY

		SELECT @v_ActivityStatusStart = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'STARTED'

		SELECT @v_ActivityStatusStop = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'SUCCEEDED'

		SELECT @v_ActivityStatusFail = PK_ActivityStatus 
		FROM Orchestram.Log.ActivityStatus	
		WHERE ActivityStatus = 'ERRORED'


		/* Insert a new batch for EIOPA datasource table*/
		INSERT INTO [dbo].[Batch]([CreateDate],[DataSet],[LatestBusinesKey]) VALUES  (GETDATE(),'EIOPA', NULL)
	
		SELECT @v_BatchId = SCOPE_IDENTITY()


		/* Log the start of the insert */
		SELECT   
			@v_ActivityLogTag		        = NULL
		   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
		   ,@v_ActivityType				    = (SELECT PK_ActivityType	
											   FROM Orchestram.Log.ActivityType	
											   WHERE ActivityType = CASE 
																	WHEN @p_ParentActivityLogId IS NULL 
																		THEN 'Manual process' 
																		ELSE 'Automated process' 
																	END)
		   ,@v_ActivityHost				    = @@SERVERNAME
		   ,@v_ActivityName				    = 'Load EIOPA data into Inbound.DiscountRates'
		   ,@v_ActivityDateTime			    = GETUTCDATE()
		   ,@v_ActivityMessage			 	= NULL
		   ,@v_ActivityErrorCode			= NULL
		   ,@v_AffectedRows				    = 0

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStart
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT

		SELECT @v_ActivityLogTag = @v_ActivityLogIdIn

		
		DROP TABLE IF EXISTS #TempInboundDiscountRates

 
		;WITH eiopa AS

			         (SELECT [FileName]
					        ,LoadDate
							,SheetName
					        ,[Main Menu]
							,[Country]
							,[Value]

                      FROM 

                          (SELECT * 

	                       FROM   [xls].[EIOPA] 

	                       WHERE  ISNUMERIC([Main menu]) = 1
						   --AND [FileName] NOT IN (SELECT DISTINCT AuditSourceBatchID FROM FinanceDataContract.Outbound. [DiscountRates])
	                      ) src

                          UNPIVOT
                                  ([Value] FOR [Country] IN (
	                                                          Euro
                                                             ,Austria
                                                             ,Belgium
                                                             ,Bulgaria
                                                             ,Croatia
                                                             ,Cyprus
                                                             ,[Czech Republic]
                                                             ,Denmark
                                                             ,Estonia
                                                             ,Finland
                                                             ,France
                                                             ,Germany
                                                             ,Greece
                                                             ,Hungary
                                                             ,Iceland
                                                             ,Ireland
                                                             ,Italy
                                                             ,Latvia
                                                             ,Liechtenstein
                                                             ,Lithuania
                                                             ,Luxembourg
                                                             ,Malta
                                                             ,Netherlands
                                                             ,Norway
                                                             ,Poland
                                                             ,Portugal
                                                             ,Romania
                                                             ,Russia
                                                             ,Slovakia
                                                             ,Slovenia
                                                             ,Spain
                                                             ,Sweden
                                                             ,Switzerland
                                                             ,[United Kingdom]
                                                             ,Australia
                                                             ,Brazil
                                                             ,Canada
                                                             ,Chile
                                                             ,China
                                                             ,Colombia
                                                             ,[Hong Kong]
                                                             ,India
                                                             ,Japan
                                                             ,Malaysia
                                                             ,Mexico
                                                             ,[New Zealand]
                                                             ,Singapore
                                                             ,[South Africa]
                                                             ,[South Korea]
                                                             ,Taiwan
                                                             ,Thailand
                                                             ,Turkey
                                                             ,[United States]
								                            )
	     
	                             )AS unpvt

			         ),

                eiopa_final AS

				     (SELECT DISTINCT 
					          ep.[FileName]
					         ,ISNULL((SELECT [value]

							          FROM   STRING_SPLIT(ep.[FileName],'_')

							          WHERE  ISDATE([value]) = 1),GETUTCDATE()
									 ) FileDate
					         ,ep.LoadDate
							 ,ep.SheetName
					         ,CAST(ep.[Main Menu] as INT)  [DevelopmentQuarter]
							 ,(CASE WHEN ep.Country = 'Euro' THEN 'EUR'
							        ELSE cry.CurrencyCode
							  END) CurrencyCode
							 ,ISNULL(CAST(REPLACE(ep.[Value],'%','') AS NUMERIC(19,6)),0.00) [Value]

					  FROM   eiopa ep

					  LEFT JOIN (SELECT DISTINCT 
					                    (CASE WHEN CountryName = 'KOREA (THE REPUBLIC OF)'         THEN 'South Korea'  
							                  WHEN CountryName = 'UNITED STATES OF AMERICA (THE)'  THEN 'United States' 
								              WHEN CountryName = 'TAIWAN (PROVINCE OF CHINA)'      THEN 'Taiwan'      
								              WHEN CountryName = 'UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN IRELAND (THE)'  THEN 'United Kingdom' 
								              WHEN CountryName = 'RUSSIAN FEDERATION (THE)'        THEN 'Russia'     
											  ELSE CountryName
										END )CountryName
					                   ,CurrencyCode

					             FROM   [MDS].[Currency]
								 ) cry 
					  ON ep.Country = cry.CountryName OR ep.Country +' (THE)' = cry.CountryName

                   )

				 
				SELECT 
					     [AsAtDate]                        = CAST(FileDate AS DATE)
			            ,[DiscountRateName]                = 'EIOPA - ' + SheetName
			            ,[DiscountRateKey]                 = 'EIOPA'
			            ,[DataSet]						   = 'EIOPA'
			            ,[SettlementCCY]                   = CAST(CurrencyCode AS VARCHAR  (3))
			            ,[CumulativeDevelopmentPercentage] = [value]/100
			            ,[DevelopmentYear]                 = [DevelopmentQuarter]
			            ,AuditSourceBatchID                = CAST(@v_BatchId AS VARCHAR (50))
						                                    --[FileName]                                             
						,AuditHost                         = CAST(SERVERPROPERTY('MachineName') AS VARCHAR(255))
						,AuditGenerateDateTime             = LoadDate
						,FK_Batch                          = @v_BatchId 

				INTO   #TempInboundDiscountRates

				FROM   eiopa_final		

		    IF @Trancount = 0 	
	          BEGIN TRAN
	            
		       /* Delete the current lines of the EIOPA source system from Inbound ... */

				DELETE 
					
				FROM    FinanceDataContract.Inbound.[DiscountRates]
					
				WHERE   [DataSet] = 'EIOPA'

				INSERT INTO [FinanceDataContract].[Inbound].[DiscountRates] WITH(TABLOCK)
						([AsAtDate] 
			            ,[DiscountRateName] 
			            ,[DiscountRateKey] 
			            ,[DataSet] 
			            ,[SettlementCCY] 
			            ,[CumulativeDevelopmentPercentage] 
			            ,[DevelopmentYear] 
			            ,[AuditSourceBatchID] 
			            ,[AuditGenerateDateTime] 
			            ,[AuditHost]
			            ,[FK_Batch] 
						)		
			  
				SELECT   [AsAtDate] 
			            ,[DiscountRateName] 
			            ,[DiscountRateKey] 
			            ,[DataSet] 
			            ,[SettlementCCY] 
			            ,[CumulativeDevelopmentPercentage] 
			            ,[DevelopmentYear] 
			            ,[AuditSourceBatchID] 
			            ,[AuditGenerateDateTime] 
			            ,[AuditHost]
			            ,[FK_Batch] 
						   
				FROM    #TempInboundDiscountRates

				WHERE AsAtDate  NOT IN (SELECT DISTINCT AsAtDate FROM FinanceDataContract.Outbound.[DiscountRates])

				SELECT   @v_AffectedRows			= @@ROWCOUNT
	

		
				/* Add the batch to the queue */
				IF @v_BatchId IS NOT NULL

				   INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,[DataSet]
								,RunDescription
								,OriginalName
								)
				   VALUES
								(@v_BatchId
								,'InBound'
								,'EIOPA'
								,'DiscountRates'
								,NULL
								);
      
				-- LOGIN THE RESULT WITH SUCCESS
				SELECT @v_ActivityDateTime			= GETUTCDATE()

				EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
						@p_ParentActivityLogId
						,@v_ActivityLogTag
						,@v_ActivitySource
						,@v_ActivityType
						,@v_ActivityStatusStop
						,@v_ActivityHost
						,@v_ActivityDatabase
						,@v_ActivityJobId
						,@v_ActivitySSISExecutionId
						,@v_ActivityName
						,@v_ActivityDateTime
						,@v_ActivityMessage
						,@v_ActivityErrorCode
						,@v_AffectedRows
						,@v_ActivityLogIdIn OUTPUT;

				IF @Trancount = 0
                COMMIT;

	END TRY

	BEGIN CATCH
	
				-- CANCEL TRAN
				IF @Trancount = 0 AND @@TRANCOUNT <> 0 
				   ROLLBACK;
			        
				-- LOGIN THE RESULT WITH ERROR

				SELECT   @v_ActivityDateTime				= GETUTCDATE()
						,@v_ActivityLogTag					= @v_ActivityLogIdIn
						,@v_ActivityMessage					= ERROR_MESSAGE()
						,@v_ActivityErrorCode				= ERROR_NUMBER()

				EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
						 @p_ParentActivityLogId
						,@v_ActivityLogTag
						,@v_ActivitySource
						,@v_ActivityType
						,@v_ActivityStatusFail
						,@v_ActivityHost
						,@v_ActivityDatabase
						,@v_ActivityJobId
						,@v_ActivitySSISExecutionId
						,@v_ActivityName
						,@v_ActivityDateTime
						,@v_ActivityMessage
						,@v_ActivityErrorCode
						,@v_AffectedRows
						,@v_ActivityLogIdIn OUTPUT	;

				THROW;

	END CATCH


					
END