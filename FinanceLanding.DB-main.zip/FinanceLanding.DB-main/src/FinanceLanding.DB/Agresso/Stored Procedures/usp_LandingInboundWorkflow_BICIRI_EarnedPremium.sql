﻿CREATE PROCEDURE [Agresso].[usp_LandingInboundWorkflow_BICIRI_EarnedPremium] --201812
		--	Declare	
			@p_AccountingPeriod			INT  --=201812
			--,@p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL

AS
/*
-- =====================================================================================================================================================================================

-- Original Author:		ENTHA BHARGAV <Entha.Bhargav@beazley.com>
-- Create date: 30/08/2023
-- Description:	Original version, used to run in all the periods from 201811 to the current available period. 
--	Will run and catch up if need be (in the case of some downtime when the schedule hasn't run) and will do everything in case of a clear down.

--	This is executed under Procedure object   [Agresso].[usp_LandingToInboundToOutboundWorkflow_BICIRI_EarnedPremium]


--  Tables used in this Proc
--	FinanceLanding.[Agresso].[BICIRI_EarnedPremium]  table Populates from FL.SSIS		FinanceLanding.SSIS\src\FinanceLanding.SSIS\IFRS17_BICIRI_EarnedPremium.dtsx

--	FinanceLanding.Eurobase.reinsurance_pol_det table populates from FL.SSIS			FinanceLanding.SSIS\src\FinanceLanding.SSIS\IFRS17_EurobaseToLandingExtract.dtsx
--	FinanceLanding.Eurobase.rein_program_sequence										FinanceLanding.SSIS\src\FinanceLanding.SSIS\IFRS17_EurobaseToLandingExtract.dtsx
--	FinanceLanding.fdm.AccountingPeriod													FinanceLanding.SSIS\src\FinanceLanding.SSIS\IFRS17_FDMToLandingExtract.dtsx


--	This will be refreshed Quarter in Arrears 03,06,09,12
--	The Primary source data is extracted into Landing from		Agresso			which is Transactional data, However we converted into AsAt, feed it to AsAt Delta proc.
--	Transformations applied for ProgrammeCode, RIPolicyType as Agresso doesn't hold this information (#TempPolType).
--	Pushpal Das Business Data Analyst Provide the huge number of static transformations and needs to modify/change in future additions if any
--  Temporary tables used are  #TempPolType , #TempBICICRIEarn , #FinalTransforms

DateOfModification		UpdatedBY									Description
--------------------------------------------------------------------------------------------------------------------------------------------
28-06-2024				venkat.yerravati@beazley.com				BICI Earned, Incurred and Paid - Unknown PG(I1B-5664)


-- ======================================================================================================================================================================================
*/
BEGIN

	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;

		

	/*======================================================Logging Starts==================================================*/
	--DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'BICI_Earned_Agresso';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= NULL;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	DECLARE @ContractType					CHAR(3)			= 'BEA'
	DECLARE		@p_ParentActivityLogId		BIGINT			= NULL;

	DECLARE @v_Dataset						varchar(50)		=@v_ActivityDatabase
	DECLARE @v_BatchId						INT             = NULL;
	DECLARE @v_BatchId_Extensions			INT
	DECLARE @Asat			 varchar(20)			= @p_AccountingPeriod;



	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';

	INSERT INTO [dbo].[Batch]([CreateDate],[DataSet],LatestBusinesKey) 
	VALUES  (GETDATE(),@v_Dataset,cast(@Asat as VARCHAR));

	SELECT @v_BatchId = SCOPE_IDENTITY();

	SET @v_ActivityJobId=@v_BatchId

	/* Log the start of the insert */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'usp_LandingInboundWorkflow_AgressoExpensesActual'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'Load data into Inbound.Transaction for Expenses Actual started'
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;
	
/*==================Logging End======================*/


	BEGIN TRY
		IF @Trancount = 0 
			BEGIN TRAN;

		/*
=============================================================================================
	Create BatchID In landing
==============================================================================================
*/

	DECLARE 
		 @Scenario char(1)				= 'F' 
		,@Basis char(1)					= 'E'
		,@PolicyNumber char(8)			= 'NOPOLICY'
		,@DefaultDate date				= CAST('01-01-1980' as date)
		,@TypeOfBusiness char(1)		= '-'
		,@Location char(1)				= '-'
		,@IsToDate char(1)				= 'Y'
		,@BusinessProcessCode char(2)	= 'T1'
		,@AuditHost varchar(255)		= CAST(SERVERPROPERTY('MachineName') as varchar(255))
		,@StatsCode varchar(25)			= null
		,@Entity varchar(25)			='USBICI'
		
		
		,@DefaultGetdate datetime		= CAST(GETUTCDATE() AS datetime) 
		
		
		
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, @v_ActivityName,'At LandToInbound_BICIRI_EarnedPremium'+ CONVERT(VARCHAR,@v_BatchId)+' Batch Created';
		

IF object_id(N'tempdb..#TempPolType') IS NOT NULL
	DROP TABLE #TempPolType

SELECT DISTINCT PolicyNo
	,
	--PolicyDescription, 
	CASE 
		WHEN PolicyDescription LIKE '%xs%'
			THEN 'XL'
		WHEN PolicyDescription LIKE '%Excess%'
			THEN 'XL'
		WHEN PolicyDescription LIKE '%XOL%'
			THEN 'XL'
		WHEN PolicyDescription LIKE '%Stop Loss%'
			THEN 'XL'
		WHEN PolicyNo LIKE '%XL%'
			THEN 'XL'
		WHEN PolicyDescription LIKE '%Marine Group%'
			THEN 'XL'
		WHEN PolicyNo LIKE 'SPG__EPL%'
			THEN 'XL'
		WHEN PolicyNo LIKE 'CPG%'
			THEN 'XL'
		WHEN PolicyDescription LIKE '%Quota Share%'
			THEN 'QS'
		WHEN PolicyNo LIKE '%QS%'
			THEN 'QS'
		WHEN PolicyDescription LIKE '% QS %'
			THEN 'QS'
		WHEN PolicyDescription LIKE '%Surplus%'
			THEN 'QS'
		WHEN PolicyDescription LIKE '%Master RI%'
			THEN 'QS'
		WHEN PolicyDescription LIKE '%Master Reinsurance%'
			THEN 'QS'
		WHEN PolicyDescription LIKE '%BBR Services%'
			THEN 'QS'
		WHEN PolicyNo LIKE 'CPAFB%'
			THEN 'QS'
		WHEN PolicyNo LIKE 'ENGCTL%'
			THEN 'QS'
		WHEN PolicyNo LIKE 'ENGTAF%'
			THEN 'QS'
		WHEN PolicyNo LIKE 'RICPBM%'
			THEN 'QS'
		WHEN PolicyNo LIKE 'BNP%'
			THEN 'FAC'
		WHEN PolicyNo LIKE 'RIUNIR'
			THEN 'FAC'
		WHEN PolicyNo LIKE 'CDM%'
			THEN 'FAC'
		WHEN PolicyNo LIKE 'DEW%'
			THEN 'FAC'
		WHEN PolicyNo LIKE 'IBI%'
			THEN 'FAC'
		WHEN PolicyNo LIKE 'STANTEC%'
			THEN 'FAC'
		WHEN PolicyDescription LIKE 'Specialty FAC%'
			THEN 'FAC'
		WHEN PolicyDescription LIKE '% FAC %'
			THEN 'FAC'
		WHEN PolicyNo LIKE '%FAC%'
			THEN 'FAC'
		WHEN PolicyNo LIKE 'V%'
			THEN 'FAC'
		WHEN PolicyDescription LIKE '%Loss Portfolio Transfer Reinsurance Agreement%'
			THEN 'QS'
		WHEN PolicyDescription LIKE '%BICI/Globe Reinsurance Agreement%'
			THEN 'QS' --ASK
		ELSE NULL
		END AS RIPolicyType																	-- Transformations provided by Pushpal Das
	,CASE 
		WHEN PolicyNo LIKE 'AHG__XL%'
			THEN 'Life & Accident Cat'
		WHEN PolicyNo LIKE 'BICISLRXA%'
			THEN 'BICI Risk & Agg XL'
		WHEN PolicyNo LIKE 'BNP%'
			THEN 'SL Facultative spend'
		WHEN PolicyNo LIKE 'CDM%'
			THEN 'SL Facultative spend'
		WHEN PolicyNo LIKE 'CP_XOL%'
			THEN 'Property XL'
		WHEN PolicyNo LIKE 'CPXOL%'
			THEN 'Property XL' --
		WHEN PolicyNo LIKE 'CPAFB%'
			THEN 'BICCPF' --
		WHEN PolicyNo LIKE 'CPF%'
			THEN 'Property FAC'
		WHEN PolicyNo LIKE 'CPG%'
			AND PolicyNo LIKE '%PRX%'
			THEN 'PRXS' ----Changed 06/04
		WHEN PolicyNo LIKE 'CPG%'
			THEN 'Property Cat XL'
		WHEN PolicyNo LIKE 'CPQS%'
			AND PolicyDescription LIKE 'Commercial Property Quota Share Treaty%'
			THEN 'BFS QS' --
		WHEN PolicyNo LIKE 'DEW%'
			THEN 'SL Facultative spend'
		WHEN PolicyNo LIKE 'EMEPL%'
			THEN 'BICI Internal QS' --'EMBEDDED EPL BICI INTERNAL QS' --internal for BICI
		WHEN PolicyNo LIKE 'ENGF%'
			THEN 'Marine Facultative Spend'
		WHEN PolicyNo LIKE 'ENGG%'
			AND PolicyNo LIKE '%XL%'
			THEN 'MORTAR - Engineering Risk Xs'
		WHEN PolicyNo LIKE 'ENGTR%'
			AND PolicyNo LIKE '%QS%'
			THEN 'Engineering Terrorism QS'
		WHEN PolicyNo LIKE 'ENGCTL%'
			THEN 'Internal QS  - Engineering'
		WHEN PolicyNo LIKE 'ENGTAF%'
			THEN 'Internal QS  - Engineering'
		WHEN PolicyNo LIKE 'ENG%'
			AND PolicyNo LIKE '%QS%'
			AND PolicyDescription LIKE '%Internal%'
			THEN 'Internal QS  - Engineering'
		WHEN PolicyNo LIKE 'ENG%'
			AND PolicyNo LIKE '%QS%'
			THEN 'Engineering Quota Share'
		WHEN PolicyNo LIKE 'IBI%'
			THEN 'SL Facultative spend'
		WHEN PolicyNo LIKE 'INTFALQS%'
			THEN 'Internal QS - Marine Falvey'
		WHEN PolicyNo LIKE 'INTMARQS%'
			THEN 'Internal QS  - Marine Non Falvey'
		WHEN PolicyNo LIKE 'INTPOLQS%'
			THEN 'Internal QS  - Political Risks'
		WHEN PolicyNo LIKE 'MARFALQS%'
			THEN 'Internal QS - Marine Falvey'
		WHEN PolicyNo LIKE 'MARCHLQS%'
			THEN 'Internal QS  - Marine Non Falvey'
		WHEN PolicyNo LIKE 'MARG%'
			AND PolicyNo LIKE '%CGOA%'
			THEN 'MARGEN' --Changed 06/04
		WHEN PolicyNo LIKE 'MARG%'
			AND PolicyNo LIKE '%CGOB%'
			THEN 'MARGEN' --Changed 06/04
		WHEN PolicyNo LIKE 'MARG%'
			AND PolicyNo LIKE '%CGO%'
			THEN 'Marine XL' --Changed 06/04
		WHEN PolicyNo LIKE 'MARG%'
			AND PolicyNo LIKE '%GEN%'
			THEN 'MARGEN'
		WHEN PolicyNo LIKE 'MARG%'
			AND PolicyNo LIKE '%GEX%'
			THEN 'MARGEX'
		WHEN PolicyNo LIKE 'MARG%'
			AND PolicyNo LIKE '%RPP%'
			THEN 'MARRPP'
		WHEN PolicyNo LIKE 'MARG%'
			THEN 'Marine XL'
		WHEN PolicyNo LIKE 'MARQS%'
			THEN 'Internal QS  - Marine Non Falvey' --'Internal QS - Marine Falvey' Changed 06/04
		WHEN PolicyNo LIKE 'MAR__FAC%'
			THEN 'Internal QS' --'Marine Facultative Spend' Changed 06/04
		WHEN PolicyNo LIKE 'MSTRI%'
			THEN 'Master RI'
		WHEN PolicyNo LIKE 'PCGCPRQS%'
			THEN 'Internal QS  - Political Risks' --'MINIMU - Political Risks QS' --internal for BICI 
		WHEN PolicyNo LIKE 'PCGG__XLCPR%'
			THEN 'TALK - Political Risks XL'
		WHEN PolicyNo LIKE 'RICPBM%'
			THEN 'US Boiler & Machinery'
		WHEN PolicyNo LIKE 'RIUNIR'
			THEN 'SL Facultative spend' --
		WHEN PolicyNo LIKE 'SPAELAW%'
			AND PolicyNo LIKE '%QS%'
			THEN 'A&E Lawyers QS'
		WHEN PolicyNo LIKE 'SPCUNAQS%'
			THEN 'CUNA QS'
		WHEN PolicyNo LIKE 'SPCYB%QS%'
			THEN 'Cyber QS'
		WHEN PolicyNo LIKE 'SPEXTCYBER%'
			THEN 'Cyber QS'
		WHEN PolicyNo LIKE 'SPDOQS%'
			THEN 'SWORD D&O'
		WHEN PolicyNo LIKE 'SPEXT%'
			AND PolicyNo LIKE '%ENV%'
			THEN 'Environmental QS'
		WHEN PolicyNo LIKE 'SPEXT%'
			AND PolicyNo LIKE '%SUR%'
			THEN 'MUNICH - Surplus'
		WHEN PolicyNo LIKE 'SPEXT%'
			AND PolicyNo LIKE '%QS%'
			THEN 'MUNQQS'
		WHEN PolicyNo LIKE 'SPEXT%'
			AND PolicyNo LIKE '%BBR%'
			THEN 'MUNQQS'
		WHEN PolicyNo LIKE 'SPG__LAG%'
			THEN 'Lawyers Risk Excess'
		WHEN PolicyNo LIKE 'SPINTXOL%'
			THEN 'BICI Risk & Agg XL'
		WHEN PolicyNo LIKE 'SPLAWQS%'
			THEN 'Lawyers QS'
		WHEN PolicyNo LIKE 'SPG__CL%'
			THEN 'Systemic cover - Clash'
		WHEN PolicyNo LIKE 'SPG__PETMB%'
			THEN 'US Small Risks XL'
		WHEN PolicyNo LIKE 'SPG__PROF%'
			AND YOA < '2015'
			THEN 'Professions Agg XL'
		WHEN PolicyNo LIKE 'SPG__PROF%'
			AND YOA >= '2015'
			THEN 'Professions'
		WHEN PolicyNo LIKE 'SPG__EPL%'
			THEN 'EPL Risk Excess'
		WHEN PolicyNo LIKE 'SPG__CFE%'
			THEN 'COFFEE'
		WHEN PolicyNo LIKE 'SPOCCQS%'
			THEN 'Occurrence QS'
		WHEN PolicyNo LIKE 'SPQS%'
			THEN 'BICI Internal QS'
		WHEN PolicyNo LIKE 'SPSUR%'
			THEN 'BICI Internal QS'
		WHEN PolicyNo LIKE 'STANTEC%'
			THEN 'SL Facultative spend'
		WHEN PolicyNo LIKE 'TERG__SA%'
			THEN 'Terrorism XLs'
		WHEN PolicyNo LIKE 'WTHQS%'
			THEN 'BICI Internal QS' --'Weather Contingency QS & Surplus' --internal for BICI	 
		WHEN PolicyNo LIKE 'WTHSUR%'
			THEN 'BICI Internal QS' --'Weather Contingency QS & Surplus' --internal for BICI	 
		WHEN PolicyDescription LIKE '%Master RI%'
			THEN 'Master RI'
		WHEN PolicyDescription LIKE '%Loss Portfolio Transfer Reinsurance Agreement%'
			THEN 'PORTFOLIO TRANSFER BICI TO CAPTIVE RI'
		WHEN PolicyDescription LIKE '%BICI/Globe Reinsurance Agreement%'
			THEN 'GLOBE'
		WHEN PolicyDescription LIKE 'Specialty FAC%'
			THEN 'SL Facultative spend'
		WHEN PolicyDescription LIKE '% FAC %'
			THEN 'SL Facultative spend'
		WHEN PolicyNo LIKE '%FAC%'
			THEN 'SL Facultative spend' --
		WHEN PolicyNo LIKE 'V%'
			THEN 'SL Facultative spend'
		WHEN PolicyNo LIKE 'R1139%'
			THEN 'MUNQQS'
		ELSE NULL
		END AS Programme
INTO #TempPolType

FROM FinanceLanding.[Agresso].[BICIRI_EarnedPremium] t
LEFT JOIN Eurobase.reinsurance_pol_det pol ON (pol.rpd_policy_reference = t.PolicyNo)
WHERE pol.rpd_policy_reference IS NULL
	AND PolicyNo NOT IN (
		''
		,'NO POLICY'
		)
	


IF object_id(N'tempdb..#TempBICICRIEarn') IS NOT NULL
	DROP TABLE #TempBICICRIEarn

SELECT cast(CASE 
			WHEN right(t.AccountingPeriod, 2) IN (
					'01'
					,'02'
					)
				THEN left(t.AccountingPeriod, 4) + '03'
			WHEN right(t.AccountingPeriod, 2) IN (
					'04'
					,'05'
					)
				THEN left(t.AccountingPeriod, 4) + '06'
			WHEN right(t.AccountingPeriod, 2) IN (
					'07'
					,'08'
					)
				THEN left(t.AccountingPeriod, 4) + '09'
			WHEN right(t.AccountingPeriod, 2) IN (
					'10'
					,'11'
					)
				THEN left(t.AccountingPeriod, 4) + '12'
			ELSE t.AccountingPeriod
			END + '01' AS DATE) AS DateOfFact
	,t.TrifocusCode
	,t.YOA
	,IsNUll(t.CCY,'USD') AS CCY
	,sum(cast(Amount AS NUMERIC(30, 4))) AS [Value]
	,sum(cast(t.Amount AS NUMERIC(30, 4))) AS [ValueOrig]
	,CASE 
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			AND right(Account, 2) = '00'
			THEN 'BICI_HISTORICAL'
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			THEN 'BICI Internal QS'
		WHEN isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN')) NOT LIKE '%Internal%'
			AND isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN')) NOT IN (
				'BICI Risk & Agg XL'
				,'PORTFOLIO TRANSFER BICI TO CAPTIVE RI'
				)
			AND right(Account, 2) <> '00'
			THEN 'BICI Internal QS'
		ELSE isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN'))
		END AS ProgrammeCode
	,CASE 
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			THEN 'UNK'
		ELSE isnull(tmp.RIPolicyType, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'FAC'
						WHEN RTRIM(LTRIM(tty.[rpd_rein_policy_type])) IN (
								'SL'
								,'RE'
								)
							THEN 'XL'
						ELSE RTRIM(LTRIM(tty.[rpd_rein_policy_type]))
						END, 'UNKNOWN'))
		END AS RIPolicyType
	,t.UWProd

INTO #TempBICICRIEarn


FROM FinanceLanding.[Agresso].[BICIRI_EarnedPremium] t
LEFT JOIN FinanceLanding.Eurobase.reinsurance_pol_det tty ON (tty.rpd_policy_reference = t.PolicyNo)
LEFT JOIN FinanceLanding.Eurobase.rein_program_sequence prg ON (prg.rps_program_id = tty.rpd_treaty_ri_code)
LEFT JOIN #TempPolType tmp ON (tmp.PolicyNo = t.PolicyNo)
GROUP BY cast(CASE 
			WHEN right(t.AccountingPeriod, 2) IN (
					'01'
					,'02'
					)
				THEN left(t.AccountingPeriod, 4) + '03'
			WHEN right(t.AccountingPeriod, 2) IN (
					'04'
					,'05'
					)
				THEN left(t.AccountingPeriod, 4) + '06'
			WHEN right(t.AccountingPeriod, 2) IN (
					'07'
					,'08'
					)
				THEN left(t.AccountingPeriod, 4) + '09'
			WHEN right(t.AccountingPeriod, 2) IN (
					'10'
					,'11'
					)
				THEN left(t.AccountingPeriod, 4) + '12'
			ELSE t.AccountingPeriod
			END + '01' AS DATE)
	,t.TrifocusCode
	,t.YOA
	,IsNUll(t.CCY,'USD')
	,UWProd
	,CASE 
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			AND right(Account, 2) = '00'
			THEN 'BICI_HISTORICAL'
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			THEN 'BICI Internal QS'
		WHEN isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN')) NOT LIKE '%Internal%'
			AND isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN')) NOT IN (
				'BICI Risk & Agg XL'
				,'PORTFOLIO TRANSFER BICI TO CAPTIVE RI'
				)
			AND right(Account, 2) <> '00'
			THEN 'BICI Internal QS'
		ELSE isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN'))
		END
	,CASE 
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			THEN 'UNK'
		ELSE isnull(tmp.RIPolicyType, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'FAC'
						WHEN RTRIM(LTRIM(tty.[rpd_rein_policy_type])) IN (
								'SL'
								,'RE'
								)
							THEN 'XL'
						ELSE RTRIM(LTRIM(tty.[rpd_rein_policy_type]))
						END, 'UNKNOWN'))
		END

UNION ALL

SELECT cast(d.AccountingPeriod + '01' AS DATE) AS DateOfFact
	,t.TrifocusCode
	,t.YOA
	,IsNUll(t.CCY,'USD') AS CCY
	,0 AS [Value]
	,0 AS [ValueOrig]
	,CASE 
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			AND right(Account, 2) = '00'
			THEN 'BICI_HISTORICAL'
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			THEN 'BICI Internal QS'
		WHEN isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN')) NOT LIKE '%Internal%'
			AND isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN')) NOT IN (
				'BICI Risk & Agg XL'
				,'PORTFOLIO TRANSFER BICI TO CAPTIVE RI'
				)
			AND right(Account, 2) <> '00'
			THEN 'BICI Internal QS'
		ELSE isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN'))
		END AS ProgrammeCode
	,CASE 
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			THEN 'UNK'
		ELSE isnull(tmp.RIPolicyType, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'FAC'
						WHEN RTRIM(LTRIM(tty.[rpd_rein_policy_type])) IN (
								'SL'
								,'RE'
								)
							THEN 'XL'
						ELSE RTRIM(LTRIM(tty.[rpd_rein_policy_type]))
						END, 'UNKNOWN'))
		END AS RIPolicyType
	,t.UWProd

--from Testing.agresso.BICI_RI_Earned t
FROM FinanceLanding.[Agresso].[BICIRI_EarnedPremium] t
LEFT JOIN FinanceLanding.Eurobase.reinsurance_pol_det tty ON (tty.rpd_policy_reference = t.PolicyNo)
LEFT JOIN FinanceLanding.Eurobase.rein_program_sequence prg ON (prg.rps_program_id = tty.rpd_treaty_ri_code)
LEFT JOIN #TempPolType tmp ON (tmp.PolicyNo = t.PolicyNo)
JOIN fdm.AccountingPeriod d ON (
		d.AccountingPeriod > t.AccountingPeriod
		AND d.AccountingPeriod <= left(convert(VARCHAR, getdate(), 112), 6)
		AND substring(d.AccountingPeriod, 5, 2) IN (
			'03'
			,'06'
			,'09'
			,'12'
			)
		)
GROUP BY cast(d.AccountingPeriod + '01' AS DATE)
	,t.TrifocusCode
	,t.YOA
	,IsNUll(t.CCY,'USD')
	,UWProd
	,CASE 
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			AND right(Account, 2) = '00'
			THEN 'BICI_HISTORICAL'
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			THEN 'BICI Internal QS'
		WHEN isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN')) NOT LIKE '%Internal%'
			AND isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN')) NOT IN (
				'BICI Risk & Agg XL'
				,'PORTFOLIO TRANSFER BICI TO CAPTIVE RI'
				)
			AND right(Account, 2) <> '00'
			THEN 'BICI Internal QS'
		ELSE isnull(tmp.Programme, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'SL Facultative spend'
						ELSE prg.ifrs17_programme_group
						END, 'UNKNOWN'))
		END
	,CASE 
		WHEN t.PolicyNo IN (
				''
				,'NO POLICY'
				)
			THEN 'UNK'
		ELSE isnull(tmp.RIPolicyType, isnull(CASE 
						WHEN prg.ifrs17_programme_group = 'BICI FAC'
							THEN 'FAC'
						WHEN RTRIM(LTRIM(tty.[rpd_rein_policy_type])) IN (
								'SL'
								,'RE'
								)
							THEN 'XL'
						ELSE RTRIM(LTRIM(tty.[rpd_rein_policy_type]))
						END, 'UNKNOWN'))
		END




--DECLARE 
--		 @Scenario char(1)				= 'F' 
--		,@Basis char(1)					= 'E'
--		,@PolicyNumber char(8)			= 'NOPOLICY'
--		,@DefaultDate date				= CAST('01-01-1980' as date)
--		,@TypeOfBusiness char(1)		= '-'
--		,@Location char(1)				= '-'
--		,@IsToDate char(1)				= 'Y'
--		,@BusinessProcessCode char(2)	= 'T1'
--		,@AuditHost varchar(255)		= CAST(SERVERPROPERTY('MachineName') as varchar(255))
--		,@StatsCode varchar(25)			= null
--		,@Entity varchar(25)			='USBICI'
--		DECLARE @v_Dataset						varchar(50)		='BICI_Earned_Agresso'
		
		
--		,@DefaultGetdate datetime		= CAST(GETUTCDATE() AS datetime)
--		,@v_BatchId						INT             = NULL;
DROP TABLE

IF EXISTS #FinalTransforms
	SELECT TrifocusCode
		,Entity
		,YOA
		,SettlementCCY
		,OriginalCCY
		,DateOfFact
		,Businesskey
		,Inceptiondate
		,ExpiryDate
		,RIPolicyType
		,ProgrammeCode
		,Scenario
		,Account
		,Dataset
		,PolicyNumber
		,BindDate
		,DueDate
		,TypeOfBusiness
		,StatsCode
		,IsToDate
		,AuditGenerateDateTime
		,AuditHost
		,Basis
		,[Location]
		,BusinessProcessCode
		,AuditCreateDateTime
		,RowHash
		,RowHash_Transaction_ReInsurance_Extensions
		,FK_Allocation
		,DeltaType
		,AuditSourceBatchID
		,FK_Batch
		,[Value]
		,[ValueOrig]
	INTO #FinalTransforms
	FROM (
		SELECT		 TrifocusCode		= t.TrifocusCode
					,Entity = @Entity
					,YOA = cast(t.YOA AS VARCHAR(5))
					,SettlementCCY = t.CCY
					,OriginalCCY = t.CCY
					,DateOfFact = CONVERT(DATETIME, DateOfFact)
					,Businesskey = CONCAT (
											@v_Dataset
											,'|'
											,ISNULL(ProgrammeCode, '-')
											,'|'
											,ISNULL(T.RIPolicyType, '-')
											,'|'
											,ISNULL(T.CCY, '-')
											,'|'
											,ISNULL(TrifocusCode, '-')
											,'|'
											,ISNULL(cast(t.YOA AS VARCHAR(5)), '-')
										)
					,Inceptiondate = @DefaultDate
					,ExpiryDate = @DefaultDate
					,RIPolicyType = RIPolicyType
					,ProgrammeCode = ProgrammeCode
					,Scenario = @Scenario
					,Account = Cast('P-EP-P-' + CASE 
							WHEN RIPolicyType = 'FAC'
								THEN 'FAC'
							ELSE 'TTY'
							END AS VARCHAR(25))
					,Dataset = @v_Dataset
					,PolicyNumber = @PolicyNumber
					,BindDate = @DefaultDate
					,DueDate = @DefaultDate
					,TypeOfBusiness = @TypeOfBusiness
					,StatsCode = @StatsCode
					,[IsToDate] = @IsToDate
					,AuditGenerateDateTime = @DefaultGetdate
					,AuditHost = @AuditHost
					,Basis = @Basis
					,[Location] = @Location
					,BusinessProcessCode = @BusinessProcessCode
					,AuditCreateDateTime = @DefaultGetdate
					,RowHash = dbo.fn_RowHashForTransactions('T' -- <@RowHashType, char(1),>
						, @Scenario --,<@Scenario, nvarchar(2000),>
						, 'P-EP-P-' + CASE 
							WHEN RIPolicyType = 'FAC'
								THEN 'FAC'
							ELSE 'TTY'
							END --,<@Account, nvarchar(2000),>
						, @v_Dataset --,<@DataSet, nvarchar(2000),>
						, CONCAT (
							@v_Dataset
							,'|'
							,ISNULL(ProgrammeCode, '-')
							,'|'
							,ISNULL(T.RIPolicyType, '-')
							,'|'
							,ISNULL(T.CCY, '-')
							,'|'
							,ISNULL(TrifocusCode, '-')
							,'|'
							,ISNULL(cast(t.YOA AS VARCHAR(5)), '-')
							) --,<@BusinessKey, nvarchar(2000),>
						, @PolicyNumber --,<@PolicyNumber, nvarchar(2000),>
						, @DefaultDate --,<@InceptionDate, date,>
						, @DefaultDate --,<@ExpiryDate, date,>
						, @DefaultDate --,<@BindDate, date,>
						, @DefaultDate --,<@DueDate, date,>
						, [TrifocusCode] --,<@TrifocusCode, nvarchar(2000),>
						, @Entity --,<@Entity, nvarchar(2000),>
						, [YOA] --,<@YOA, nvarchar(2000),>
						, @TypeOfBusiness --,<@TypeOfBusiness, nvarchar(2000),>
						, @StatsCode --,<@StatsCode, nvarchar(2000),>
						, CCY --,<@SettlementCCY, nvarchar(2000),>
						, CCY --,<@OriginalCCY, nvarchar(2000),>
						, @IsToDate --,<@IsToDate, nvarchar(2000),>
						, @Basis --,<@Basis, nvarchar(2000),>
						, @Location --,<@Location, nvarchar(2000),>
						, @BusinessProcessCode --,<@BusinessProcessCode, nvarchar(2000),>
						, NULL --,<@BoundDate, date,>
						, CONCAT (
							CASE 
								WHEN RIPolicyType IS NULL
									THEN ''
								ELSE (RIPolicyType + '§~§')
								END
							,CASE 
								WHEN ProgrammeCode IS NULL
									THEN ''
								ELSE (ProgrammeCode + '§~§')
								END
							))
					,[RowHash_Transaction_ReInsurance_Extensions] = dbo.fn_RowHashForTransactions('E' /* @RowHashType */
						, @Scenario, 'P-EP-P-' + CASE 
							WHEN RIPolicyType = 'FAC'
								THEN 'FAC'
							ELSE 'TTY'
							END, @v_Dataset, CONCAT (
							@v_Dataset
							,'|'
							,ISNULL(ProgrammeCode, '-')
							,'|'
							,ISNULL(T.RIPolicyType, '-')
							,'|'
							,ISNULL(T.CCY, '-')
							,'|'
							,ISNULL(TrifocusCode, '-')
							,'|'
							,ISNULL(cast(t.YOA AS VARCHAR(5)), '-')
							), @PolicyNumber, @DefaultDate, @DefaultDate, @DefaultDate, @DefaultDate, TrifocusCode, @Entity, YOA, @TypeOfBusiness, @StatsCode, CCY, CCY, @IsToDate, @Basis, @Location, @BusinessProcessCode /* @BusinessProcessCode */
						, NULL /* @BoundDate */
						-- extended columns
						, CONCAT (
							CASE 
								WHEN RIPolicyType IS NULL
									THEN ''
								ELSE (RIPolicyType + '§~§')
								END
							,CASE 
								WHEN ProgrammeCode IS NULL
									THEN ''
								ELSE (ProgrammeCode + '§~§')
								END
							))
					,NULL AS FK_Allocation
					,NULL AS DeltaType
					,@v_BatchId AS AuditSourceBatchID
					,@v_BatchId AS FK_Batch
					,[Value] = sum(sum([Value])) OVER (
						PARTITION BY TrifocusCode
						,YOA
						,
						--RIPolicyType,
						ProgrammeCode
						,CCY
						,RIPolicyType ORDER BY DateOfFact ASC
						)
					,[ValueOrig] = sum(sum([Value])) OVER (
						PARTITION BY TrifocusCode
						,YOA
						,
						--RIPolicyType,
						ProgrammeCode
						,CCY
						,RIPolicyType ORDER BY DateOfFact ASC
						)
		--INTO			#FinalTransforms
		FROM #TempBICICRIEarn t
		--where DateOfFact = '2018-12-01'
		--where left(convert(varchar,DateOfFact,112),6)  >=201812  --=@Asat
		GROUP BY dateoffact
			,CONCAT (
				@v_Dataset
				,'|'
				,ISNULL(ProgrammeCode, '-')
				,'|'
				,ISNULL(T.RIPolicyType, '-')
				,'|'
				,ISNULL(T.CCY, '-')
				,'|'
				,ISNULL(TrifocusCode, '-')
				,'|'
				,ISNULL(T.YOA, '-')
				)
			,TrifocusCode
			,YOA
			,CCY
			,RIPolicyType
			,ProgrammeCode
		) a
	WHERE left(convert(VARCHAR, DateOfFact, 112), 6) = @Asat

--where DateOfFact='2019-03-01'
--and YOA='2011'
--and RIPolicyType='FAC'


		SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, @v_ActivityName, 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into LandingTempBICIRIEarn table for: ' +convert(varchar,@Asat);



	-- Debug mode
	--select distinct DateOfFact
	--from #TempBICICRIEarn
	--order by 1 desc

	 ------/* Delete the current lines from Inbound ... */
	 --DECLARE @ContractType					CHAR(3)			= 'AEA'
	 --, @v_dataset				VARCHAR(100)    = 'Expenses Actual';

		DELETE
		FROM [FinanceDataContract].[Inbound].[Transaction]
		WHERE [DataSet] = @v_DataSet

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions_Bridge]
		WHERE [ContractType] = @ContractType

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions]
		WHERE [ContractType] = @ContractType


		INSERT INTO [dbo].[Batch]
			([CreateDate],[DataSet],[LatestBusinesKey]) 
		VALUES  
			(GETDATE(),'ReInsuranceExtensions', @Asat);

		SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();

		INSERT INTO  [FinanceDataContract].[Inbound].Transaction_ReInsurance_Extensions_Bridge
			(
				[RowHash_Transaction]
				,[RowHash_Transaction_ReInsurance_Extensions]
				,[ContractType]
				,[FK_Batch]
			)
			SELECT DISTINCT
				[RowHash]
				,[RowHash_Transaction_ReInsurance_Extensions]
				,@ContractType
				,@v_BatchId_Extensions
			FROM 
				#FinalTransforms

			INSERT INTO  [FinanceDataContract].[Inbound].Transaction_ReInsurance_Extensions
				(
					[RowHash_Transaction_ReInsurance_Extensions]
					,[RIPolicyType]
					,[ProgrammeCode]
					--,[BeazleyCatCode]
					--,[TransactionDate]		
					,[IsLargeLoss]			
					,[ContractType]
					,[FK_Batch]
				)
				SELECT DISTINCT
					[RowHash_Transaction_ReInsurance_Extensions]
					,[RIPolicyType]
					,[ProgrammeCode]
					--,[BeazleyCatCode]
					--,[TransactionDate]		
					, NULL AS [IsLargeLoss]			
					,@ContractType
					,@v_BatchId_Extensions
				FROM 
					#FinalTransforms
				

/*============================================================================================================
			INSERT INTO  Inbound.Transaction FROM FinanceLanding.OP.LandingObligatedPremium_Munich_QQS
===============================================================================================================*/
	INSERT INTO [FinanceDataContract].[Inbound].[Transaction] WITH(TABLOCK)
			( [Scenario],[Basis],[Account],[DataSet],[DateOfFact],[BusinessKey],[PolicyNumber],[InceptionDate],[ExpiryDate],[BindDate],[DueDate],[TrifocusCode]
				,[Entity],[Location],[YOA],[TypeOfBusiness],[SettlementCCY],[OriginalCCY],[IsToDate],[Value],[ValueOrig],[RowHash],[BusinessProcessCode]
				,[AuditSourceBatchID],[AuditGenerateDateTime],[StatsCode],[FK_Batch],[DeltaType],[FK_Allocation]
				,[AuditCreateDateTime],AuditHost
				
			)

	SELECT	 [Scenario],[Basis],[Account],[DataSet],[DateOfFact],[BusinessKey],[PolicyNumber],[InceptionDate],[ExpiryDate],[BindDate],[DueDate],[TrifocusCode]
			,[Entity],[Location],[YOA],[TypeOfBusiness],[SettlementCCY],[OriginalCCY],[IsToDate],[Value],[ValueOrig],[RowHash],[BusinessProcessCode]
			,[AuditSourceBatchID],[AuditGenerateDateTime],[StatsCode],[FK_Batch],[DeltaType],[FK_Allocation]
			,[AuditCreateDateTime],AuditHost
			 
	  FROM #FinalTransforms
	

		SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, @v_ActivityName, 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into Inbound.Transaction table for: ' +convert(varchar,@Asat);

		INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,RunDescription
								,[DataSet]
								--,OriginalName
								,AuditSourceBatchID
								--,OriginalName
								,AsAt
								)
				VALUES
								( @v_BatchId
								 ,'InBound'
								 --,'CSV files data as source'
								 ,NULL
								 ,@v_DataSet
								-- ,NULL
								 ,NULL
								-- ,@Asat
								 ,@Asat
									
								)
								,

								( @v_BatchId_Extensions
								,'InBound'
								,'ReInsuranceExtensions, the additional attributes to extend functionality of the transaction table.'
								,'ReInsuranceExtensions'
								--,NULL
								,NULL
								--,@Asat
								,@Asat
								);

		-- LOG THE RESULT WITH SUCCESS
			SELECT @v_ActivityDateTime			= GETUTCDATE();

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStop
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

		IF @Trancount = 0 
		COMMIT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, @v_ActivityName, 'BICIRI_EarnedPremium Agresso LandingToInBound Succeeded';

		--Generate logging for success
		EXEC log.usp_LogLanding @Input = @Logging;

	END TRY

	BEGIN CATCH

		IF @Trancount = 0  
				ROLLBACK;
			
			-- LOG THE RESULT WITH ERROR--
				UPDATE [FinanceDataContract].[Inbound].[BatchQueue]
				SET Status='OutBoundFailed'
				WHERE PK_Batch=@v_BatchId AND [Status]='InBound' AND DataSet=@v_DataSet


			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

			

		    THROW;

		
	END CATCH;

END;