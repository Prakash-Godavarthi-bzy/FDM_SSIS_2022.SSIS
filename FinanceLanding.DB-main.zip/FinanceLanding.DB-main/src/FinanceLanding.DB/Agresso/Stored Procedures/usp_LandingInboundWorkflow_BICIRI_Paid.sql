﻿CREATE PROCEDURE [Agresso].[usp_LandingInboundWorkflow_BICIRI_Paid]
				@p_AccountingPeriod			INT	
AS
BEGIN
/*
-- =====================================================================================================================================================================================
-- Details:
--Version				DateOfModification		UpdatedBY									Description
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- 1.0					11-08-2023				Yasaswini.kandimalla@beazley.com			I1B-4108 Tactical to Strategic Load for BICI_RI Paid --Intital Version 


-- ======================================================================================================================================================================================
DateOfModification		UpdatedBY									Description
--------------------------------------------------------------------------------------------------------------------------------------------
28-06-2024				venkat.yerravati@beazley.com				BICI Earned, Incurred and Paid - Unknown PG(I1B-5664)
*/
	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;

	/*======================================================Logging Starts==================================================*/
	--DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'BICI_RI_Paid';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= NULL;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	DECLARE @ContractType					CHAR(3)			= 'BRP';
	DECLARE		@p_ParentActivityLogId		BIGINT			= NULL

	DECLARE @v_Dataset						varchar(50)		=@v_ActivityDatabase
	DECLARE @v_BatchId						INT             = NULL;
	DECLARE @v_BatchId_Extensions			INT;
	DECLARE @AccountingPeriod				varchar(20)		= @p_AccountingPeriod;


	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';

	INSERT INTO [dbo].[Batch]([CreateDate],[DataSet]) 
	VALUES  (GETDATE(),@v_Dataset);

	SELECT @v_BatchId = SCOPE_IDENTITY();

	SET @v_ActivityJobId=@v_BatchId

	/* Log the start of the insert */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'Agresso.usp_LandingInboundWorkflow_BICI_RI_Paid'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'Load data into Inbound.Transaction for BICI RI Paid Started'
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;
	
/*==================Logging End======================*/


	BEGIN TRY
		IF @Trancount = 0 
			BEGIN TRAN;

		/*
=============================================================================================
	Create BatchID In landing
==============================================================================================
*/

	declare 
		 @Scenario char(1)				= 'A' 
		,@Basis char(1)					= 'B'
		,@DefaultDate date				= CAST('01-01-1980' as date)
		,@TypeOfBusiness char(1)		= '-'
		,@Location char(1)				= '-'
		,@IsToDate char(1)				= 'Y'
		,@BusinessProcessCode char(2)	= 'T1'
		,@AuditHost varchar(255)		= CAST(SERVERPROPERTY('MachineName') as varchar(255))
		,@StatsCode varchar(25)			= null
		,@DateOfFact date				= DATEFROMPARTS(SUBSTRING(@AccountingPeriod,1,4),SUBSTRING(@AccountingPeriod,5,6),'01')


	
    /* Insert into logging table */

	INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'Agresso.usp_LandingInboundWorkflow_BICIRI_Paid', ' '+CONVERT(VARCHAR,@v_BatchId)+' Batch Created';

    /* Insert the new records from LandingBICI_RI_Paid sources in the temp table */

	if object_id('tempdb..#RIPaid') is not null drop table #RIPaid

;with RIAgresso AS
(
	SELECT 
		 [PolicyNo],
		 [AccountingPeriod],
		 [Entity],
		 [YOA] = CAST(	CASE WHEN [YOA] = 'NOYOA' AND RIGHT(PolicyNo, 4) IN ('QS07', 'QS08', 'QS09', 'QS10') THEN '20' + RIGHT(PolicyNo, 2)
		 				ELSE YOA
						END AS VARCHAR),
		 [TriFocusCode],
		 [UWProd],
		 [CCY],
		 [Amount],
		 [AmountPaid],
		 [PolicyDescription],
		 [Account]
	FROM FinanceLanding.[agresso].[BICIRI_Paid]
	
	UNION ALL
	
	SELECT 
		 [PolicyNo],
		 [AccountingPeriod],
		 [Entity],
		 [YOA], 
		 [TriFocusCode],
		 [UWProd],
		 [CCY],
		 [Amount] = - sum(Amount),
		 [AmountPaid] = 0,
		 [PolicyDescription],
		 [Account]
	FROM FinanceLanding.[agresso].[BICIRI_Paid]
	WHERE PolicyNo = 'RICPBM'
		  AND yoa in ('NOYOA', '2009', '2010')
		  AND Account in ('23100','23110','23150','23155') 
	GROUP BY 
		 [PolicyNo],
		 [AccountingPeriod],
		 [Entity],
		 [YOA], 
		 [TriFocusCode],
		 [UWProd],
		 [CCY],
		 [PolicyDescription],
		 [Account]
	HAVING abs(sum(Amount)) > 0
),
programme AS
(

	SELECT DISTINCT 
		   PolicyNo, 
		   RIPolicyType = CASE WHEN PolicyDescription		LIKE '%xs%'											   THEN 'XL'
							   WHEN PolicyDescription		LIKE '%Excess%'										   THEN 'XL'
							   WHEN PolicyDescription		LIKE '%XOL%'										   THEN 'XL'
							   WHEN PolicyDescription		LIKE '%Stop Loss%'									   THEN 'XL'
							   WHEN PolicyNo				LIKE '%XL%'											   THEN 'XL'
							   WHEN PolicyDescription		LIKE '%Marine Group%'								   THEN 'XL'
							   WHEN PolicyNo				LIKE 'SPG__EPL%'									   THEN 'XL'
							   WHEN PolicyNo				LIKE 'CPG%'											   THEN 'XL'
							   WHEN PolicyDescription		LIKE '%Quota Share%'								   THEN 'QS'
							   WHEN PolicyNo				LIKE '%QS%'											   THEN 'QS'
							   WHEN PolicyDescription		LIKE '% QS %'										   THEN 'QS'
							   WHEN PolicyDescription		LIKE '%Surplus%'									   THEN 'QS'
							   WHEN PolicyDescription		LIKE '%Master RI%'									   THEN 'QS'
							   WHEN PolicyDescription		LIKE '%Master Reinsurance%'							   THEN 'QS'
							   WHEN PolicyDescription		LIKE '%BBR Services%'								   THEN 'QS'
							   WHEN PolicyNo				LIKE 'CPAFB%'										   THEN 'QS'
							   WHEN PolicyNo				LIKE 'ENGCTL%'										   THEN 'QS'
							   WHEN PolicyNo				LIKE 'ENGTAF%'										   THEN 'QS'
							   WHEN PolicyNo				LIKE 'RICPBM%'										   THEN 'QS'
							   WHEN PolicyNo				LIKE 'BNP%'											   THEN 'FAC'
							   WHEN PolicyNo				LIKE 'RIUNIR'										   THEN 'FAC'
							   WHEN PolicyNo				LIKE 'CDM%'											   THEN 'FAC'
							   WHEN PolicyNo				LIKE 'DEW%'											   THEN 'FAC'
							   WHEN PolicyNo				LIKE 'IBI%'											   THEN 'FAC'
							   WHEN PolicyNo				LIKE 'STANTEC%'										   THEN 'FAC'
							   WHEN PolicyDescription		LIKE 'Specialty FAC%'								   THEN 'FAC'
							   WHEN PolicyDescription		LIKE '% FAC %'										   THEN 'FAC'
							   WHEN PolicyNo				LIKE '%FAC%'										   THEN 'FAC'
							   WHEN PolicyNo				LIKE 'V%'											   THEN 'FAC'
							   WHEN PolicyDescription		LIKE '%Loss Portfolio Transfer Reinsurance Agreement%' THEN 'QS'
							   WHEN PolicyDescription		LIKE '%BICI/Globe Reinsurance Agreement%'			   THEN 'QS'
						  ELSE NULL
						  END,
		   Programme	= CASE WHEN PolicyNo			  LIKE 'AHG__XL%'								 THEN 'Life & Accident Cat' 
							   WHEN PolicyNo			  LIKE 'BICISLRXA%'								 THEN 'BICI Risk & Agg XL' 
							   WHEN PolicyNo			  LIKE 'BNP%'									 THEN 'SL Facultative spend' 
							   WHEN PolicyNo			  LIKE 'CDM%'									 THEN 'SL Facultative spend'
							   WHEN PolicyNo			  LIKE 'CP_XOL%'								 THEN 'Property XL'
							   WHEN PolicyNo			  LIKE 'CPXOL%'									 THEN 'Property XL' 
							   WHEN PolicyNo			  LIKE 'CPAFB%'									 THEN 'BICCPF'
							   WHEN PolicyNo			  LIKE 'CPF%'									 THEN 'Property FAC'
							   WHEN PolicyNo			  LIKE 'CPG%'									 THEN 'Property Cat XL'
							   WHEN PolicyNo			  LIKE 'CPQS%' 
									and PolicyDescription LIKE 'Commercial Property Quota Share Treaty%' THEN 'BFS QS'
							   WHEN PolicyNo			  LIKE 'DEW%'									 THEN 'SL Facultative spend'
							   WHEN PolicyNo			  LIKE 'EMEPL%'									 THEN 'BICI Internal QS' --'EMBEDDED EPL BICI INTERNAL QS' --internal for BICI
							   WHEN PolicyNo			  LIKE 'ENGF%'									 THEN 'Marine Facultative Spend'
							   WHEN PolicyNo			  LIKE 'ENGG%' 
									and PolicyNo		  LIKE '%XL%'									 THEN 'MORTAR - Engineering Risk Xs'
							   WHEN PolicyNo			  LIKE 'ENGTR%' 
									and PolicyNo		  LIKE '%QS%'									 THEN 'Engineering Terrorism QS'
							   WHEN PolicyNo			  LIKE 'ENGCTL%'								 THEN 'Internal QS  - Engineering' 
							   WHEN PolicyNo			  LIKE 'ENGTAF%'								 THEN 'Internal QS  - Engineering' 
							   WHEN PolicyNo			  LIKE 'ENG%' 
									and PolicyNo		  LIKE '%QS%' 
									and PolicyDescription LIKE '%Internal%'								 THEN 'Internal QS  - Engineering'
							   WHEN PolicyNo			  LIKE 'ENG%' 
									and PolicyNo		  LIKE '%QS%'									 THEN 'Engineering Quota Share'
							   WHEN PolicyNo			  LIKE 'IBI%'									 THEN 'SL Facultative spend'
							   WHEN PolicyNo			  LIKE 'INTFALQS%'								 THEN 'Internal QS - Marine Falvey'
							   WHEN PolicyNo			  LIKE 'INTMARQS%'								 THEN 'Internal QS  - Marine Non Falvey'
							   WHEN PolicyNo			  LIKE 'INTPOLQS%'								 THEN 'Internal QS  - Political Risks'
							   WHEN PolicyNo			  LIKE 'MARFALQS%'								 THEN 'Internal QS - Marine Falvey'
							   WHEN PolicyNo			  LIKE 'MARCHLQS%'								 THEN 'Internal QS  - Marine Non Falvey'
							   WHEN PolicyNo			  LIKE 'MARG%'									 THEN 'Marine XL'
							   WHEN PolicyNo			  LIKE 'MARQS%'									 THEN 'Internal QS - Marine Falvey'
							   WHEN PolicyNo			  LIKE 'MAR__FAC%'								 THEN 'Marine Facultative Spend' 
							   WHEN PolicyNo			  LIKE 'MSTRI%'									 THEN 'Master RI'
							   WHEN PolicyNo			  LIKE 'PCGCPRQS%'								 THEN 'Internal QS  - Political Risks' --'MINIMU - Political Risks QS' --internal for BICI 
							   WHEN PolicyNo			  LIKE 'PCGG__XLCPR%'							 THEN 'TALK - Political Risks XL' 
							   WHEN PolicyNo			  LIKE 'RICPBM%'								 THEN 'US Boiler & Machinery' 
							   WHEN PolicyNo			  LIKE 'RIUNIR'									 THEN 'SL Facultative spend' 
							   WHEN PolicyNo			  LIKE 'SPAELAW%' 
									and PolicyNo		  LIKE '%QS%'									 THEN 'A&E Lawyers QS' 
							   WHEN PolicyNo			  LIKE 'SPCUNAQS%'								 THEN 'CUNA QS' 
							   WHEN PolicyNo			  LIKE 'SPCYB%QS%'								 THEN 'Cyber QS' 
							   WHEN PolicyNo			  LIKE 'SPEXTCYBER%'							 THEN 'Cyber QS' 
							   WHEN PolicyNo			  LIKE 'SPDOQS%'								 THEN 'SWORD D&O'
							   WHEN PolicyNo			  LIKE 'SPEXT%' 
									and PolicyNo		  LIKE '%ENV%'									 THEN 'Environmental QS'
							   WHEN PolicyNo			  LIKE 'SPEXT%'									  
									and PolicyNo		  LIKE '%SUR%'									 THEN 'MUNICH - Surplus'
							   WHEN PolicyNo			  LIKE 'SPEXT%' 
									and PolicyNo		  LIKE '%QS%'									 THEN 'MUNQQS'
							   WHEN PolicyNo			  LIKE 'SPEXT%' 								 
									and PolicyNo		  LIKE '%BBR%'									 THEN 'MUNQQS'
							   WHEN PolicyNo			  LIKE 'SPG__LAG%'								 THEN 'Lawyers Risk Excess' 
							   WHEN PolicyNo			  LIKE 'SPINTXOL%'								 THEN 'BICI Risk & Agg XL' 
							   WHEN PolicyNo			  LIKE 'SPLAWQS%'								 THEN 'Lawyers QS' 
							   WHEN PolicyNo			  LIKE 'SPG__CL%'								 THEN 'Systemic cover - Clash'
							   WHEN PolicyNo			  LIKE 'SPG__PETMB%'							 THEN 'US Small Risks XL'
							   WHEN PolicyNo			  LIKE 'SPG__PROF%'								 THEN 'Professions'
							   WHEN PolicyNo			  LIKE 'SPG__EPL%'								 THEN 'EPL Risk Excess' 
							   WHEN PolicyNo			  LIKE 'SPG__CFE%'								 THEN 'COFFEE' 
							   WHEN PolicyNo			  LIKE 'SPOCCQS%'								 THEN 'Occurrence QS' 
							   WHEN PolicyNo			  LIKE 'SPQS%'									 THEN 'BICI Internal QS'
							   WHEN PolicyNo			  LIKE 'SPSUR%'									 THEN 'BICI Internal QS'
							   WHEN PolicyNo			  LIKE 'STANTEC%'								 THEN 'SL Facultative spend'
							   WHEN PolicyNo			  LIKE 'TERG__SA%'								 THEN 'Terrorism XLs' 
							   WHEN PolicyNo			  LIKE 'WTHQS%'									 THEN 'BICI Internal QS'--'Weather Contingency QS & Surplus' --internal for BICI	 
							   WHEN PolicyNo			  LIKE 'WTHSUR%'								 THEN 'BICI Internal QS'--'Weather Contingency QS & Surplus' --internal for BICI	 
							   WHEN PolicyDescription	  LIKE '%Master RI%'							 THEN 'Master RI'
							   WHEN PolicyDescription	  LIKE '%Loss Portfolio Transfer Reinsurance Agreement%' THEN 'PORTFOLIO TRANSFER BICI TO CAPTIVE RI'
							   WHEN PolicyDescription	  LIKE '%BICI/Globe Reinsurance Agreement%'		 THEN 'GLOBE' 
							   WHEN PolicyDescription	  LIKE 'Specialty FAC%'							 THEN 'SL Facultative spend'
							   WHEN PolicyDescription	  LIKE '% FAC %'								 THEN 'SL Facultative spend'
							   WHEN PolicyNo			  LIKE '%FAC%'									 THEN 'SL Facultative spend' 
							   WHEN PolicyNo			  LIKE 'V%'										 THEN 'SL Facultative spend'
							   WHEN PolicyNo			  LIKE 'R1139%'									 THEN 'MUNQQS'
						ELSE NULL
						END
	FROM RIAgresso t
	LEFT JOIN FinanceLanding.Eurobase.reinsurance_pol_det pol ON (pol.rpd_policy_reference = t.PolicyNo)
	WHERE pol.rpd_policy_reference IS NULL
		AND PolicyNo NOT IN ('', 'NO POLICY')
),
FinalData AS
(
SELECT 
	 [DateOfFact]		  = CAST(
					  		CASE WHEN RIGHT(t.AccountingPeriod, 2) IN ('01', '02') THEN LEFT(t.AccountingPeriod, 4) + '03'
					  			 WHEN RIGHT(t.AccountingPeriod, 2) IN ('04', '05') THEN LEFT(t.AccountingPeriod, 4) + '06'
					  			 WHEN RIGHT(t.AccountingPeriod, 2) IN ('07', '08') THEN LEFT(t.AccountingPeriod, 4) + '09'
					  	 		 WHEN RIGHT(t.AccountingPeriod, 2) IN ('10', '11') THEN LEFT(t.AccountingPeriod, 4) + '12'
					  		ELSE t.AccountingPeriod
					  		END + '01' AS DATE),
	 [PolicyNumber]	      = t.PolicyNo,
	 [InceptionDate]	  = MAX(ISNULL(tty.rpd_ri_pol_prd_FROM, ISNULL(NULLIF(YOA,'NOYOA'), '1980')  + '0101')),
	 [ExpiryDate]		  = MAX(ISNULL(tty.rpd_ri_pol_prd_to, ISNULL(NULLIF(YOA,'NOYOA'), '1980')  + CASE WHEN YOA = 'NOYOA' THEN '0101' ELSE '1231' END)),
	 [TrifocusCode]		  = t.TrifocusCode,
	 [Entity]			  = t.Entity,
	 [YOA]				  = t.YOA,
	 [CCY]				  = t.CCY,
	 [value]			  = SUM(Amount) ,
	 [valuePaid]		  = SUM(AmountPaid) ,
	 [ProgrammeCode]	  = CASE WHEN t.PolicyNo IN ('', 'NO POLICY') 
									  AND RIGHT(Account, 2) IN ('00', '50')				THEN 'BICI_HISTORICAL' 
							     WHEN t.PolicyNo IN ('', 'NO POLICY')					THEN 'BICI Internal QS'
							     WHEN ISNULL(tmp.Programme, ISNULL( CASE WHEN prg.ifrs17_programme_group = 'BICI FAC' THEN 'SL Facultative spend' 
							   										ELSE prg.ifrs17_programme_group 
							   										END, 'UNKNOWN')
											) NOT LIKE '%Internal%' 
							   	     AND	   		 
									 ISNULL(tmp.Programme, ISNULL(CASE WHEN prg.ifrs17_programme_group = 'BICI FAC'   THEN 'SL Facultative spend' 
							   									  ELSE prg.ifrs17_programme_group 
							   									  END, 'UNKNOWN')
							   			   ) NOT IN ('BICI Risk & Agg XL', 'PORTFOLIO TRANSFER BICI TO CAPTIVE RI')
							   	     AND RIGHT(Account, 2) NOT IN ('00', '50') 
							   															THEN 'BICI Internal QS'
						    ELSE  ISNULL(tmp.Programme, ISNULL(CASE WHEN prg.ifrs17_programme_group = 'BICI FAC'     THEN 'SL Facultative spend' 
																ELSE prg.ifrs17_programme_group 
																END, 'UNKNOWN')
										 ) 
							END ,
	 [RIPolicyType]		 =  CASE WHEN t.PolicyNo IN ('', 'NO POLICY') 				THEN 'UNK'
						    ELSE	ISNULL(tmp.RIPolicyType, ISNULL(CASE WHEN prg.ifrs17_programme_group = 'BICI FAC'					THEN 'FAC' 
																		 WHEN RTRIM(LTRIM(tty.[rpd_rein_policy_type])) IN ('SL', 'RE') 	THEN 'XL'
																    ELSE RTRIM(LTRIM(tty.[rpd_rein_policy_type])) 
																    END, 'UNKNOWN')
									      ) 
						    END 
FROM RIAgresso t
LEFT JOIN FinanceLanding.Eurobase.reinsurance_pol_det tty	ON (tty.rpd_policy_reference = t.PolicyNo)
LEFT JOIN FinanceLanding.Eurobase.rein_program_sequence prg ON (prg.rps_program_id = tty.rpd_treaty_ri_code)
LEFT JOIN programme tmp										ON (tmp.PolicyNo = t.PolicyNo)
GROUP BY 
	CAST(CASE WHEN RIGHT(t.AccountingPeriod, 2) IN ('01', '02') THEN LEFT(t.AccountingPeriod, 4) + '03'
			  WHEN RIGHT(t.AccountingPeriod, 2) IN ('04', '05') THEN LEFT(t.AccountingPeriod, 4) + '06'
			  WHEN RIGHT(t.AccountingPeriod, 2) IN ('07', '08') THEN LEFT(t.AccountingPeriod, 4) + '09'
			  WHEN RIGHT(t.AccountingPeriod, 2) IN ('10', '11') THEN LEFT(t.AccountingPeriod, 4) + '12'
		 ELSE t.AccountingPeriod
	     END + '01' AS DATE),
	t.PolicyNo,
	t.TrifocusCode,
	t.Entity,
	t.YOA,
	t.CCY,
	CASE WHEN t.PolicyNo IN ('', 'NO POLICY') AND RIGHT(Account, 2) IN ('00', '50') 		THEN 'BICI_HISTORICAL' 
		 WHEN t.PolicyNo IN ('', 'NO POLICY')												THEN 'BICI Internal QS'
	     WHEN ISNULL(tmp.Programme,  ISNULL(CASE WHEN prg.ifrs17_programme_group = 'BICI FAC' 	THEN 'SL Facultative spend' 
											ELSE prg.ifrs17_programme_group 
											END, 'UNKNOWN')
				    ) NOT LIKE '%Internal%' 
			  AND
			  ISNULL(tmp.Programme, ISNULL(CASE WHEN prg.ifrs17_programme_group = 'BICI FAC' THEN 'SL Facultative spend' 
										   ELSE prg.ifrs17_programme_group 
										   END, 'UNKNOWN')
					) NOT IN ('BICI Risk & Agg XL', 'PORTFOLIO TRANSFER BICI TO CAPTIVE RI')
			  AND RIGHT(Account, 2) NOT IN ('00', '50')
																							THEN 'BICI Internal QS'
	ELSE   ISNULL(tmp.Programme, ISNULL(CASE WHEN prg.ifrs17_programme_group = 'BICI FAC' 	THEN 'SL Facultative spend' 
										ELSE prg.ifrs17_programme_group 
										END, 'UNKNOWN')
				 ) 
	END,
	CASE WHEN t.PolicyNo IN ('', 'NO POLICY') 		 THEN 'UNK'
	ELSE	ISNULL(tmp.RIPolicyType, ISNULL(CASE WHEN prg.ifrs17_programme_group = 'BICI FAC' 					THEN 'FAC' 
												 WHEN RTRIM(LTRIM(tty.[rpd_rein_policy_type])) IN ('SL', 'RE') 	THEN 'XL'
											ELSE RTRIM(LTRIM(tty.[rpd_rein_policy_type])) 
											END, 'UNKNOWN')
				  )
	END

UNION ALL

SELECT 
	 [DateOfFact]		= cast(d.AccountingPeriod + '01' as Date),
	 [PolicyNumber]		= t.PolicyNo,
	 [InceptionDate]	= max(ISNULL(tty.rpd_ri_pol_prd_FROM, ISNULL(nullif(YOA,'NOYOA'), '1980')  + '0101')),
	 [ExpiryDate]		= max(ISNULL(tty.rpd_ri_pol_prd_to, ISNULL(nullif(YOA,'NOYOA'), '1980')  + CASE WHEN YOA = 'NOYOA' THEN '0101' ELSE '1231' end)),
	 [TrifocusCode]		= t.TrifocusCode,
	 [Entity]			= t.Entity,
	 [YOA]				= t.YOA,
	 [CCY]				= t.CCY,
	 [value]			= 0,
	 [ValuePaid]		= 0,
	 [ProgrammeCode]	= CASE WHEN t.PolicyNo IN ('', 'NO POLICY') AND RIGHT(Account, 2) IN ('00', '50') 	THEN 'BICI_HISTORICAL' 
							   WHEN t.PolicyNo IN ('', 'NO POLICY')											THEN 'BICI Internal QS'
							   WHEN ISNULL(tmp.Programme, ISNULL(CASE WHEN prg.ifrs17_programme_group = 'BICI FAC' 	THEN 'SL Facultative spend' 
																 ELSE prg.ifrs17_programme_group 
																 END, 'UNKNOWN')
										  ) NOT LIKE '%Internal%' 
									AND
									ISNULL(tmp.Programme, ISNULL(CASE WHEN prg.ifrs17_programme_group = 'BICI FAC' THEN 'SL Facultative spend' 
																 ELSE prg.ifrs17_programme_group 
																 END, 'UNKNOWN')
										  ) NOT IN ('BICI Risk & Agg XL', 'PORTFOLIO TRANSFER BICI TO CAPTIVE RI')
									AND RIGHT(Account, 2) NOT IN ('00', '50')								THEN 'BICI Internal QS'
						  ELSE	ISNULL(tmp.Programme, ISNULL(CASE WHEN prg.ifrs17_programme_group = 'BICI FAC'		THEN 'SL Facultative spend' 
															 ELSE prg.ifrs17_programme_group 
															 END, 'UNKNOWN')
									  ) 
						  END,
	 [RIPolicyType]		= CASE WHEN t.PolicyNo IN ('', 'NO POLICY')	 THEN 'UNK'
						  ELSE	ISNULL(tmp.RIPolicyType, ISNULL(CASE WHEN prg.ifrs17_programme_group = 'BICI FAC' 	THEN 'FAC' 
																	 WHEN RTRIM(LTRIM(tty.[rpd_rein_policy_type])) IN ('SL', 'RE') 	THEN 'XL'
																	 ELSE RTRIM(LTRIM(tty.[rpd_rein_policy_type]))
																	 END, 'UNKNOWN')
									  ) 
						  END
FROM RIAgresso t
LEFT JOIN FinanceLanding.Eurobase.reinsurance_pol_det tty	ON (tty.rpd_policy_reference = t.PolicyNo)
LEFT JOIN FinanceLanding.Eurobase.rein_program_sequence prg ON (prg.rps_program_id = tty.rpd_treaty_ri_code)
LEFT JOIN programme tmp										ON (tmp.PolicyNo = t.PolicyNo)
JOIN FinanceLanding.fdm.AccountingPeriod d									ON (d.AccountingPeriod > t.AccountingPeriod 
															AND d.AccountingPeriod >= '201812'
															AND d.AccountingPeriod <= left(CONVERT(VARCHAR, GETDATE(), 112), 6)
															AND RIGHT(d.AccountingPeriod, 2) in ('03', '06', '09', '12')
)
GROUP BY 
	CAST(d.AccountingPeriod + '01' AS DATE),
	t.PolicyNo,
	t.TrifocusCode,
	t.Entity,
	t.YOA,
	t.CCY,
	CASE WHEN t.PolicyNo IN ('', 'NO POLICY') AND RIGHT(Account, 2) IN ('00', '50') THEN 'BICI_HISTORICAL' 
		 WHEN t.PolicyNo IN ('', 'NO POLICY')						    		    THEN 'BICI Internal QS'
		 WHEN ISNULL(tmp.Programme,ISNULL(CASE WHEN prg.ifrs17_programme_group = 'BICI FAC' THEN 'SL Facultative spend' 
										  ELSE prg.ifrs17_programme_group 
										  END, 'UNKNOWN')
					) NOT LIKE '%Internal%' 
			  AND
			  ISNULL(tmp.Programme, ISNULL(CASE WHEN prg.ifrs17_programme_group = 'BICI FAC' THEN 'SL Facultative spend' 
										   ELSE prg.ifrs17_programme_group 
									       END, 'UNKNOWN')
					) NOT IN ('BICI Risk & Agg XL', 'PORTFOLIO TRANSFER BICI TO CAPTIVE RI')
			 AND RIGHT(Account, 2) NOT IN ('00', '50')								THEN 'BICI Internal QS'
	ELSE	 ISNULL(tmp.Programme, ISNULL(CASE WHEN prg.ifrs17_programme_group = 'BICI FAC' THEN 'SL Facultative spend' 
										  ELSE prg.ifrs17_programme_group 
										  END, 'UNKNOWN')
				   ) 
			END,
	CASE WHEN t.PolicyNo IN ('', 'NO POLICY') 	THEN 'UNK'
	ELSE ISNULL(tmp.RIPolicyType, ISNULL(CASE WHEN prg.ifrs17_programme_group = 'BICI FAC'	THEN 'FAC' 
											  WHEN RTRIM(LTRIM(tty.[rpd_rein_policy_type])) IN ('SL', 'RE') THEN 'XL'
										 ELSE RTRIM(LTRIM(tty.[rpd_rein_policy_type])) 
										 END, 'UNKNOWN')
		)
	END
)

SELECT *
INTO #RIPaid
FROM
(
	SELECT 
		Account			='CC-LS-' +'UN-' +	CASE WHEN RIPolicyType in ('QS', 'XL')	THEN 'TTY' 
									ELSE RIPolicyType
									END ,
		DateOfFact,
		BusinessKey		= ISNULL(ProgrammeCode, '-') + '|' +ISNULL(RIPolicyType, '-') + '|' +ISNULL(PolicyNumber, '-') + '|' +ISNULL(TrifocusCode, '-') + '|' +ISNULL(YOA, '-'),
		PolicyNumber	= ISNULL(NULLIF(LTRIM(RTRIM([PolicyNumber])),''),'NOPOLICY'),
		InceptionDate,
		ExpiryDate,
		BindDate		= '1980-01-01',
		DueDate			= '1980-01-01',
		TrifocusCode,
		Entity			= 'USBICI',
		YOA,
		StatsCode		= NULL,
		SettlementCCY	= ISNULL(CCY,'USD'),
		OriginalCCY		= ISNULL(CCY,'USD'),
		[value]			= -SUM(SUM([valuePaid])) OVER (PARTITION BY PolicyNumber,Entity,YOA,TrifocusCode,CCY,ProgrammeCode,RIPolicyType ORDER BY DateOfFact),
		ValueOrig		= -SUM(SUM([valuePaid])) OVER (PARTITION BY PolicyNumber,Entity,YOA,TrifocusCode,CCY,ProgrammeCode,RIPolicyType ORDER BY DateOfFact),
		[Location]		= '-',
		ProgrammeCode,
		RIPolicyType,
		AuditGenerateDateTime	= NULL,
		AuditUserCreate			= NULL
	FROM FinalData
	GROUP BY
		DateOfFact,
		PolicyNumber,
		InceptionDate,
		ExpiryDate,
		TrifocusCode,
		Entity,
		YOA,
		CCY,
		ProgrammeCode,
		RIPolicyType
) t
WHERE DateOfFact >= '2018-12-01'
AND [value] <> 0

	
IF OBJECT_ID('tempdb..#LandingTempBRP') IS NOT NULL DROP TABLE #LandingTempBRP
	
SELECT 
	   Scenario			= @Scenario
	  ,Basis			= @Basis		
      ,[Account]		= LTRIM(RTRIM([Account]))
      ,[Dataset]		= @v_Dataset
      ,[DateOfFact]		= LTRIM(RTRIM([DateOfFact]))
      ,[BusinessKey]	= LTRIM(RTRIM([BusinessKey]))
      ,[PolicyNumber]
      ,[InceptionDate]	= ISNULL(LTRIM(RTRIM([InceptionDate])),@DefaultDate)
      ,[ExpiryDate]		= ISNULL(LTRIM(RTRIM([ExpiryDate])),@DefaultDate)
      ,[BindDate]		= ISNULL(LTRIM(RTRIM([BindDate])),@DefaultDate)
      ,[DueDate]		= ISNULL(LTRIM(RTRIM([DueDate])),@DefaultDate)
      ,[TrifocusCode]	= LTRIM(RTRIM([TrifocusCode]))
      ,[Entity]			= LTRIM(RTRIM([Entity]))
	  ,[Location]		= @Location
      ,[YOA]			= LTRIM(RTRIM([YOA]))
      ,[TypeOfBusiness]	= @TypeOfBusiness
	  ,[SettlementCCY]	= LTRIM(RTRIM([SettlementCCY]))
      ,[OriginalCCY]	= LTRIM(RTRIM([OriginalCCY]))
	  ,[IsToDate]		= @IsToDate
      ,[Value]
	  ,[ValueOrig]
	  ,RowHash			= dbo.fn_RowHashForTransactions('T' -- <@RowHashType, char(1),>
														, @Scenario 
														, LTRIM(RTRIM([Account]))
														, @v_Dataset 
														, LTRIM(RTRIM([BusinessKey]))
														, PolicyNumber 
														, ISNULL(LTRIM(RTRIM([InceptionDate])),@DefaultDate)
														, ISNULL(LTRIM(RTRIM([ExpiryDate])),@DefaultDate)
														, ISNULL(LTRIM(RTRIM([BindDate])),@DefaultDate)
														, ISNULL(LTRIM(RTRIM([DueDate])),@DefaultDate)
														, LTRIM(RTRIM([TrifocusCode]))
														, LTRIM(RTRIM([Entity]))
														, LTRIM(RTRIM([YOA]))
														, @TypeOfBusiness 
														,  ISNULL(nullif(LTRIM(RTRIM([StatsCode])),''),null) 
														, LTRIM(RTRIM([SettlementCCY]))
														, LTRIM(RTRIM([OriginalCCY]))
														, @IsToDate 
														, @Basis 
														, @Location 
														, @BusinessProcessCode 
														, @DefaultDate
														, CONCAT (
															CASE 
																WHEN RIPolicyType IS NULL	THEN ''
																ELSE (RIPolicyType + '§~§')
																END
															,CASE 
																WHEN ProgrammeCode IS NULL	THEN ''
																ELSE (ProgrammeCode + '§~§')
																END
															))
		,[RowHash_Transaction_ReInsurance_Extensions]= dbo.fn_RowHashForTransactions('E' /* @RowHashType */
																					, @Scenario
																					,LTRIM(RTRIM([Account]))
																					,@v_Dataset
																					, LTRIM(RTRIM([BusinessKey]))
																					, PolicyNumber
																					, ISNULL(LTRIM(RTRIM([InceptionDate])),@DefaultDate)
																					, ISNULL(LTRIM(RTRIM([ExpiryDate])),@DefaultDate)
																					, ISNULL(LTRIM(RTRIM([BindDate])),@DefaultDate)
																					, ISNULL(LTRIM(RTRIM([DueDate])),@DefaultDate)
																					, LTRIM(RTRIM([TrifocusCode]))
																					, LTRIM(RTRIM([Entity]))
																					, LTRIM(RTRIM([YOA]))
																					, @TypeOfBusiness 
																					,  ISNULL(nullif(LTRIM(RTRIM([StatsCode])),''),null) 
																					, LTRIM(RTRIM([SettlementCCY]))
																					, LTRIM(RTRIM([OriginalCCY])) 
																					, @IsToDate 
																					, @Basis 
																					, @Location 
																					, @BusinessProcessCode 
																					, @DefaultDate 
																					, CONCAT (
																						CASE 
																							WHEN RIPolicyType IS NULL	THEN ''
																							ELSE (RIPolicyType + '§~§')
																							END
																						,CASE 
																							WHEN ProgrammeCode IS NULL	THEN ''
																							ELSE (ProgrammeCode + '§~§')
																							END
																						))
	  ,[BusinessProcessCode]	= @BusinessProcessCode
	  ,[AuditSourceBatchID]		= CAST(@v_BatchId AS VARCHAR (50))
      ,[StatsCode]				= ISNULL(nullif(LTRIM(RTRIM([StatsCode])),''),null)	  
	  ,[FK_Batch]				= @v_BatchId     
      ,[DeltaType]				= NULL
      ,[FK_Allocation]			= NULL
	  ,[AuditCreateDateTime]	= GETUTCDATE()
	  ,[AuditGenerateDateTime]	= GETUTCDATE()
	  ,[AuditUserCreate]
      ,AuditHost				= @AuditHost
      ,[BoundDate]				= @DefaultDate
	  ,RIPolicyType
	  ,ProgrammeCode
	INTO #LandingTempBRP
	FROM #RIPaid
	WHERE [DateOfFact] = @DateOfFact;

	SELECT   @v_AffectedRows			= @@ROWCOUNT;

	INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
	SELECT 5, @v_ActivityName, 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into LandingTempBRP table for: ' +convert(varchar,@AccountingPeriod);

     ------/* Delete the current lines from Inbound ... */

        DELETE
		FROM [FinanceDataContract].[Inbound].[Transaction]
		WHERE [DataSet] = @v_DataSet

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions_Bridge]
		WHERE [ContractType] = @ContractType

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions]
		WHERE [ContractType] = @ContractType


	 ----------/*Insert into batch table...*/----------------
		
		INSERT INTO [dbo].[Batch]
			([CreateDate],[DataSet],[LatestBusinesKey]) 
		VALUES  
			(GETDATE(),'ReInsuranceExtensions', NULL);

		SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();

	---------/*Insert data into inbound extensions table*/------------
	   
		INSERT INTO  [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions_Bridge] WITH(TABLOCK)
			(
				[RowHash_Transaction]
				,[RowHash_Transaction_ReInsurance_Extensions]
				,[ContractType]
				,[FK_Batch]
			)
			SELECT DISTINCT
				[RowHash]
				,[RowHash_Transaction_ReInsurance_Extensions]
				,@ContractType
				,@v_BatchId_Extensions
			FROM 
				#LandingTempBRP

			INSERT INTO  [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions] WITH(TABLOCK)
				(
					[RowHash_Transaction_ReInsurance_Extensions]
					,[RIPolicyType]
					,[ProgrammeCode]
					--,[BeazleyCatCode]
					--,[TransactionDate]		
					,[IsLargeLoss]			
					,[ContractType]
					,[FK_Batch]
				)
				SELECT DISTINCT
					[RowHash_Transaction_ReInsurance_Extensions]
					,[RIPolicyType]
					,[ProgrammeCode]
					--,[BeazleyCatCode]
					--,[TransactionDate]		
					, NULL AS [IsLargeLoss]			
					,@ContractType
					,@v_BatchId_Extensions
				FROM 
					#LandingTempBRP

/*============================================================================================================
			INSERT INTO  Inbound.Transaction FROM FinanceLanding.[BICIRI].[LandingBICI_RI_Paid] 
===============================================================================================================*/

	INSERT INTO [FinanceDataContract].[Inbound].[Transaction] WITH(TABLOCK)
			( [Scenario],[Basis],[Account],[DataSet],[DateOfFact],[BusinessKey],[PolicyNumber],[InceptionDate],[ExpiryDate],[BindDate],[DueDate],[TrifocusCode]
				,[Entity],[Location],[YOA],[TypeOfBusiness],[SettlementCCY],[OriginalCCY],[IsToDate],[Value],[ValueOrig],[RowHash],[BusinessProcessCode]
				,[AuditSourceBatchID],[AuditGenerateDateTime],[StatsCode],[FK_Batch],[DeltaType],[FK_Allocation]
				,[AuditCreateDateTime],AuditHost
				
			)

	SELECT	 [Scenario],[Basis],[Account],[DataSet],[DateOfFact],[BusinessKey],[PolicyNumber],[InceptionDate],[ExpiryDate],[BindDate],[DueDate],[TrifocusCode]
			,[Entity],[Location],[YOA],[TypeOfBusiness],[SettlementCCY],[OriginalCCY],[IsToDate],[Value],[ValueOrig],[RowHash],[BusinessProcessCode]
			,[AuditSourceBatchID],[AuditGenerateDateTime],[StatsCode],[FK_Batch],[DeltaType],[FK_Allocation]
			,[AuditCreateDateTime],AuditHost
	  FROM #LandingTempBRP
	--WHERE DateOfFact='2020-12-15 00:00:00.000'

		
	    SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'Agresso.usp_LandingInboundWorkflow_BICIRI_Paid', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into Inbound.Transaction table';

		INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,RunDescription
								,[DataSet]
								,OriginalName
								,AuditSourceBatchID
								,AsAt
								)
				VALUES
								( @v_BatchId
								 ,'InBound'
								 ,NULL
								 ,@v_DataSet
								 ,NULL
								 ,NULL
								 ,@AccountingPeriod
								)
								,

								( @v_BatchId_Extensions
								,'InBound'
								,'ReInsuranceExtensions, the additional attributes to extend functionality of the transaction table.'
								,'ReInsuranceExtensions'
								,NULL
								,NULL
								,@AccountingPeriod
								);


            -- LOG THE RESULT WITH SUCCESS--
			SELECT @v_ActivityDateTime			= GETUTCDATE();

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStop
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT; 
         
        
		IF @Trancount = 0 
		COMMIT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, 'Agresso.usp_LandingInboundWorkflow_BICI_RI_Paid', 'BICIRIPaid LandingToInBound Succeeded';

		--Generate logging for success--
		EXEC log.usp_LogLanding @Input = @Logging;

	END TRY

	BEGIN CATCH

		IF @Trancount = 0  
				ROLLBACK;
			
			
			-- LOG THE RESULT WITH ERROR--
				UPDATE [FinanceDataContract].[Inbound].[BatchQueue]
				SET Status='OutBoundFailed'
				WHERE PK_Batch=@v_BatchId AND [Status]='InBound' AND DataSet=@v_DataSet
				
			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

			

		    THROW;

		
	END CATCH;

END;