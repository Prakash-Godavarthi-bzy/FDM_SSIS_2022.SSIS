﻿CREATE PROCEDURE [Agresso].[usp_LandingInboundWorkflow_AgressoExpensesActual]
			--Declare	
			@p_AccountingPeriod			INT
			--,@p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL

AS

-- =====================================================================================================================================================================================

-- Original Author:		ENTHA BHARGAV <Entha.Bhargav@beazley.com>
-- Create date: 21/08/2023
-- Description:	Original version, used to run in all the periods from 201811 to the current available period. 
--		Will run and catch up if need be (in the case of some downtime when the schedule hasn't run) and will do everything in case of a clear down.

--  Tables used in this Proc
--	FinanceLanding.[Agresso].[AExpensesActualConsol]  table Populates from FL.SSIS		FinanceLanding.SSIS\src\FinanceLanding.SSIS\IFRS17_AExpensesActualLanding.dtsx
--	FinanceLanding.[fdm].[SyndicateSplitsbyYOA] table populates from FL.SSIS			FinanceLanding.SSIS\src\FinanceLanding.SSIS\SyndicateSplit.dtsx

--	This will be refreshed Quarter in Arrears 03,06,09,12


-- ======================================================================================================================================================================================
BEGIN

	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;

		

	/*======================================================Logging Starts==================================================*/
	--DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'Expenses Actual';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= NULL;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	DECLARE @ContractType					CHAR(3)			= 'AEA'
	DECLARE		@p_ParentActivityLogId		BIGINT			= NULL;

	DECLARE @v_Dataset						varchar(50)		=@v_ActivityDatabase
	DECLARE @v_BatchId						INT             = NULL;
	DECLARE @v_BatchId_Extensions			INT
	DECLARE @Asat			 varchar(20)			= @p_AccountingPeriod;



	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';

	INSERT INTO [dbo].[Batch]([CreateDate],[DataSet],LatestBusinesKey) 
	VALUES  (GETDATE(),@v_Dataset,cast(@Asat as VARCHAR));

	SELECT @v_BatchId = SCOPE_IDENTITY();

	SET @v_ActivityJobId=@v_BatchId

	/* Log the start of the insert */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'usp_LandingInboundWorkflow_AgressoExpensesActual'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'Load data into Inbound.Transaction for Expenses Actual started'
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;
	
/*==================Logging End======================*/


	BEGIN TRY
		IF @Trancount = 0 
			BEGIN TRAN;

		/*
=============================================================================================
	Create BatchID In landing
==============================================================================================
*/

	DECLARE 
		 @Scenario char(1)				= 'F' 
		,@Basis char(1)					= 'E'
		,@PolicyNumber char(8)			= 'NOPOLICY'
		,@DefaultDate date				= CAST('01-01-1980' as date)
		,@TypeOfBusiness char(1)		= '-'
		,@Location char(1)				= '-'
		,@IsToDate char(1)				= 'Y'
		,@BusinessProcessCode char(2)	= 'T1'
		,@AuditHost varchar(255)		= CAST(SERVERPROPERTY('MachineName') as varchar(255))
		,@StatsCode varchar(25)			= null
	
		
		
		,@DefaultGetdate datetime		= CAST(GETUTCDATE() AS datetime) 
		,@RIPolicyType varchar(15)		=  NULL
		,@ProgrammeCode Varchar(20)		=  NULL
		
		
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, @v_ActivityName,'At tempLandingExpenses'+ CONVERT(VARCHAR,@v_BatchId)+' Batch Created';
		
		if object_id('tempdb..#LandingTempExpenses') is not null drop table #LandingTempExpenses
	



	--drop table if exists #cte
	--declare @Asat varchar(20)='201906'

;
WITH CTE_TempIBExpenses
AS
(
		SELECT	@Asat as asat,															--The period which we do AsAt, input from L2IO
				Entity,
				case when charindex(' ', Trifocuscode) > 0 then
						  substring(Trifocuscode, 1, charindex(' ', Trifocuscode) - 1)  
					 else Trifocuscode
				end TrifocusCode,
				CAST(YOA AS VARCHAR) AS YOA,
				Currency as SettlementCCY,
				case Measure when 'Total Acq By TF' then 'EX-AC-O' 
							 when 'Total Other By TF' then 'EX-AD-P'
							 when 'CHE TF' then 'EX-CH-O'
							 when 'Total RI By TF' then 'EX-RI-P'
							 else 'ERROR!'
				end as Account,
				sum(cast(isnull(Amount, 0) as numeric(19,4))) as [Value]
				
				--into #cte
		FROM FinanceLanding.[Agresso].[AExpensesActualConsol]
		WHERE 1=1
		
				and 
				(
					asat = @Asat
					or 
					(
						left(cast(asat as varchar), 4)  < left(cast(@Asat as varchar), 4)  
						and 
						right(cast(asat as varchar), 2) = '12'
				
					)
				)
		group by 
		Entity,
		case when charindex(' ', Trifocuscode) > 0 then
				  substring(Trifocuscode, 1, charindex(' ', Trifocuscode) - 1) 
			 else Trifocuscode
		end,
		
		
		YOA,
		Currency,
		Measure


)

--SELECT TOP 100 *
--FROM CTE_TempIBExpenses


 SELECT			TrifocusCode=t.TrifocusCode
				,Entity= t.Entity
				,YOA	= t.YOA
				,SettlementCCY=t.SettlementCCY
				,OriginalCCY=t.SettlementCCY 
				,DateOfFact= cast(left(cast(asat as varchar), 4) + '-' + right(cast(asat as varchar), 2) + '-' + '01' as Date)  -- sHOULD CHANGE, ADD DIRECTLY FROM ASAT OF cte
			--	,DateOfFact= CONVERT(datetime,concat(asat,01),1) 
				
				,Businesskey= CONCAT (ISNULL(Account,'-'),'|',ISNULL(T.Entity,'-'),'|',ISNULL(T.TrifocusCode,'-'),'|',ISNULL(YOA,'-'),'|',ISNULL(T.SettlementCCY,'-'))
				,Inceptiondate	=@DefaultDate
				,ExpiryDate		=@DefaultDate
				,RIPolicyType=@RIPolicyType 
				,ProgrammeCode=@ProgrammeCode 
				,Scenario= @Scenario
				,Account= Account  
				,Dataset=@v_Dataset  
				,PolicyNumber= @PolicyNumber  
				,BindDate=@DefaultDate  
				,DueDate=@DefaultDate  
				,TypeOfBusiness=@TypeOfBusiness
				,StatsCode=@StatsCode 
				,[IsToDate]=@IsToDate  
				,AuditGenerateDateTime=@DefaultGetdate 
				,AuditHost=@AuditHost  
				,Basis= @Basis  
				,[Location]=@Location  
				,BusinessProcessCode= @BusinessProcessCode  
				,AuditCreateDateTime=@DefaultGetdate  
				
				,RowHash = dbo.fn_RowHashForTransactions('T' -- <@RowHashType, char(1),>
															, @Scenario --,<@Scenario, nvarchar(2000),>
															, Account --,<@Account, nvarchar(2000),>
															, @v_Dataset --,<@DataSet, nvarchar(2000),>
															, CONCAT (ISNULL(Account,'-'),'|',ISNULL(T.Entity,'-'),'|',ISNULL(T.TrifocusCode,'-'),'|',ISNULL(YOA,'-'),'|',ISNULL(T.SettlementCCY,'-')) --,<@BusinessKey, nvarchar(2000),>
															, @PolicyNumber --,<@PolicyNumber, nvarchar(2000),>
															, @DefaultDate --,<@InceptionDate, date,>
															, @DefaultDate --,<@ExpiryDate, date,>
															, @DefaultDate --,<@BindDate, date,>
															, @DefaultDate --,<@DueDate, date,>
															, [TrifocusCode] --,<@TrifocusCode, nvarchar(2000),>
															, [Entity] --,<@Entity, nvarchar(2000),>
															, [YOA] --,<@YOA, nvarchar(2000),>
															, @TypeOfBusiness --,<@TypeOfBusiness, nvarchar(2000),>
															, @StatsCode --,<@StatsCode, nvarchar(2000),>
															, [SettlementCCY] --,<@SettlementCCY, nvarchar(2000),>
															, [SettlementCCY] --,<@OriginalCCY, nvarchar(2000),>
															, @IsToDate --,<@IsToDate, nvarchar(2000),>
															, @Basis --,<@Basis, nvarchar(2000),>
															, @Location --,<@Location, nvarchar(2000),>
															, @BusinessProcessCode --,<@BusinessProcessCode, nvarchar(2000),>
															, NULL --,<@BoundDate, date,>
															, CONCAT (
																		CASE 
																			WHEN @RIPolicyType IS NULL
																				THEN ''
																			ELSE (@RIPolicyType + '§~§')
																			END
																		,CASE 
																			WHEN @ProgrammeCode IS NULL
																				THEN ''
																			ELSE (@ProgrammeCode + '§~§')
																			END
																	)
														)
				,[RowHash_Transaction_ReInsurance_Extensions] = dbo.fn_RowHashForTransactions('E' /* @RowHashType */
					, @Scenario, Account, @v_Dataset,  CONCAT (ISNULL(Account,'-'),'|',ISNULL(T.Entity,'-'),'|',ISNULL(T.TrifocusCode,'-'),'|',ISNULL(YOA,'-'),'|',ISNULL(T.SettlementCCY,'-'))
					, @PolicyNumber, @DefaultDate, @DefaultDate, @DefaultDate, @DefaultDate,
					 TrifocusCode, Entity, YOA, @TypeOfBusiness, @StatsCode, SettlementCCY, SettlementCCY, @IsToDate, @Basis, @Location
					, @BusinessProcessCode /* @BusinessProcessCode */
					, NULL /* @BoundDate */
					-- extended columns
					, CONCAT (
						CASE 
							WHEN @RIPolicyType IS NULL
								THEN ''
							ELSE (@RIPolicyType + '§~§')
							END
						,CASE 
							WHEN @ProgrammeCode IS NULL
								THEN ''
							ELSE (@ProgrammeCode + '§~§')
							END
						))
				,NULL AS FK_Allocation
				,NULL AS DeltaType
				--,NULL AS BoundDate
				,@v_BatchId AS AuditSourceBatchID
				, @v_BatchId AS FK_Batch
				--,t.[Value]
				--,t.[Value] AS ValueOrig
				,t.[value]/ (case when ss.SyndSplitPercentage is null then 1 else ss.SyndSplitPercentage end) as [value]
               ,t.[value]/ (case when ss.SyndSplitPercentage is null then 1 else ss.SyndSplitPercentage end) as [ValueOrig]

INTO			#LandingTempExpenses


FROM			CTE_TempIBExpenses t
LEFT JOIN		FinanceLanding.[fdm].[SyndicateSplitsbyYOA] ss
													on 
													(
													t.Entity = '2623'
													and ss.SyndSplitSource = '2623'   --Why only 2623 cal's full expenses?
													and ss.SyndSplitEntity = '2623'
													and ss.SyndSplitYOA =  t.YOA
													)



		SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, @v_ActivityName, 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into LandingTempExpenses table for: ' +convert(varchar,@Asat);


	-- Debug mode
	--select distinct DateOfFact
	--from ##LandingTempExpenses
	--order by 1 desc

	 ------/* Delete the current lines from Inbound ... */
	 --DECLARE @ContractType					CHAR(3)			= 'AEA'
	 --, @v_dataset				VARCHAR(100)    = 'Expenses Actual';

		DELETE
		FROM [FinanceDataContract].[Inbound].[Transaction]
		WHERE [DataSet] = @v_DataSet

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions_Bridge]
		WHERE [ContractType] = @ContractType

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions]
		WHERE [ContractType] = @ContractType


		INSERT INTO [dbo].[Batch]
			([CreateDate],[DataSet],[LatestBusinesKey]) 
		VALUES  
			(GETDATE(),'ReInsuranceExtensions', @Asat);

		SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();

		INSERT INTO  [FinanceDataContract].[Inbound].Transaction_ReInsurance_Extensions_Bridge
			(
				[RowHash_Transaction]
				,[RowHash_Transaction_ReInsurance_Extensions]
				,[ContractType]
				,[FK_Batch]
			)
			SELECT DISTINCT
				[RowHash]
				,[RowHash_Transaction_ReInsurance_Extensions]
				,@ContractType
				,@v_BatchId_Extensions
			FROM 
				#LandingTempExpenses

			INSERT INTO  [FinanceDataContract].[Inbound].Transaction_ReInsurance_Extensions
				(
					[RowHash_Transaction_ReInsurance_Extensions]
					,[RIPolicyType]
					,[ProgrammeCode]
					--,[BeazleyCatCode]
					--,[TransactionDate]		
					,[IsLargeLoss]			
					,[ContractType]
					,[FK_Batch]
				)
				SELECT DISTINCT
					[RowHash_Transaction_ReInsurance_Extensions]
					,[RIPolicyType]
					,[ProgrammeCode]
					--,[BeazleyCatCode]
					--,[TransactionDate]		
					, NULL AS [IsLargeLoss]			
					,@ContractType
					,@v_BatchId_Extensions
				FROM 
					#LandingTempExpenses
				

/*============================================================================================================
			INSERT INTO  Inbound.Transaction FROM FinanceLanding.OP.LandingObligatedPremium_Munich_QQS
===============================================================================================================*/
	INSERT INTO [FinanceDataContract].[Inbound].[Transaction] WITH(TABLOCK)
			( [Scenario],[Basis],[Account],[DataSet],[DateOfFact],[BusinessKey],[PolicyNumber],[InceptionDate],[ExpiryDate],[BindDate],[DueDate],[TrifocusCode]
				,[Entity],[Location],[YOA],[TypeOfBusiness],[SettlementCCY],[OriginalCCY],[IsToDate],[Value],[ValueOrig],[RowHash],[BusinessProcessCode]
				,[AuditSourceBatchID],[AuditGenerateDateTime],[StatsCode],[FK_Batch],[DeltaType],[FK_Allocation]
				,[AuditCreateDateTime],AuditHost
				
			)

	SELECT	 [Scenario],[Basis],[Account],[DataSet],[DateOfFact],[BusinessKey],[PolicyNumber],[InceptionDate],[ExpiryDate],[BindDate],[DueDate],[TrifocusCode]
			,[Entity],[Location],[YOA],[TypeOfBusiness],[SettlementCCY],[OriginalCCY],[IsToDate],[Value],[ValueOrig],[RowHash],[BusinessProcessCode]
			,[AuditSourceBatchID],[AuditGenerateDateTime],[StatsCode],[FK_Batch],[DeltaType],[FK_Allocation]
			,[AuditCreateDateTime],AuditHost
			 
	  FROM #LandingTempExpenses
	--WHERE DateOfFact='2020-12-15 00:00:00.000'
	where TrifocusCode<>'903'

	

	/*
	

Drop table FinanceLanding.[Agresso].[AExpensesActualConsol]
use FinanceLanding
go
CREATE TABLE [Agresso].[AExpensesActualConsol](
	[PK_Expenses] [bigint] IDENTITY(1,1) NOT NULL,

	[AsAt]  [varchar](10) NOT NULL,
	[Scenario] [varchar](10) NOT NULL,
	[TrifocusCode] [varchar](50) NULL, --Should be Trifocus as for few ap it is TFName and other TFcode
	[Entity] [varchar](25) NOT NULL,
	[YOA] [varchar](5) NOT NULL,
	[Currency] [varchar](3) NULL,
	[Measure] [varchar] (50) NULL,
	
	[Amount] [numeric](38, 4) NULL,

	[AuditSSISExecutionID] [varchar](255) NULL,
	[AuditSSISPackageName] [varchar](255) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditGenerateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL,
	[AuditHost] [nvarchar](255) NOT NULL,
	[SourceFileName] [varchar](255) NULL,
	[Description]  [varchar] (255) NULL

) ON [PRIMARY]
GO

ALTER TABLE [Agresso].[AExpensesActualConsol] ADD  CONSTRAINT [DF_AExpensesActualConsol_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [Agresso].[AExpensesActualConsol] ADD  CONSTRAINT [DF_AExpensesActualConsol_AuditGenerateDateTime]  DEFAULT (getdate()) FOR [AuditGenerateDateTime]
GO

ALTER TABLE [Agresso].[AExpensesActualConsol] ADD  CONSTRAINT [DF_AExpensesActualConsol_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [Agresso].[AExpensesActualConsol] ADD  CONSTRAINT [DF_AExpensesActualConsol_AuditHost]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO


*/

		SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, @v_ActivityName, 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into Inbound.Transaction table for: ' +convert(varchar,@Asat);

		INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,RunDescription
								,[DataSet]
								--,OriginalName
								,AuditSourceBatchID
								--,OriginalName
								,AsAt
								)
				VALUES
								( @v_BatchId
								 ,'InBound'
								 --,'CSV files data as source'
								 ,NULL
								 ,@v_DataSet
								-- ,NULL
								 ,NULL
								-- ,@Asat
								 ,@Asat
									
								)
								,

								( @v_BatchId_Extensions
								,'InBound'
								,'ReInsuranceExtensions, the additional attributes to extend functionality of the transaction table.'
								,'ReInsuranceExtensions'
								--,NULL
								,NULL
								--,@Asat
								,@Asat
								);

		-- LOG THE RESULT WITH SUCCESS
			SELECT @v_ActivityDateTime			= GETUTCDATE();

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStop
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

		IF @Trancount = 0 
		COMMIT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, @v_ActivityName, 'Agresso Expenses Actual LandingToInBound Succeeded';

		--Generate logging for success
		EXEC log.usp_LogLanding @Input = @Logging;

	END TRY

	BEGIN CATCH

		IF @Trancount = 0  
				ROLLBACK;
			
			-- LOG THE RESULT WITH ERROR--
				UPDATE [FinanceDataContract].[Inbound].[BatchQueue]
				SET Status='OutBoundFailed'
				WHERE PK_Batch=@v_BatchId AND [Status]='InBound' AND DataSet=@v_DataSet


			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

			

		    THROW;

		
	END CATCH;

END;