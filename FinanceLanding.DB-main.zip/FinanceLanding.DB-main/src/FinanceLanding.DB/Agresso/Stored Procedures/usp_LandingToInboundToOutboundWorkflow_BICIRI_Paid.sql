﻿CREATE PROCEDURE [Agresso].[usp_LandingToInboundToOutboundWorkflow_BICIRI_Paid] 
             @p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL

AS
/*
-- =====================================================================================================================================================================================
-- Details:
-- Version				DateOfModification		UpdatedBY									Description
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- 1.0					07-09-2023				Yasaswini.kandimalla@beazley.com			I1B-4108 Tactical to Strategic Load for BICI_RI Paid --Intital Version 


-- ======================================================================================================================================================================================

DateOfModification		UpdatedBY									Description
--------------------------------------------------------------------------------------------------------------------------------------------
28-06-2024				venkat.yerravati@beazley.com				BICIRI Incremental Refresh issue's with DriveDate/passdate in Wrap up Procs(I1B-5662)

*/
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'BICI_RI_Paid';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	DECLARE @v_DataSet VARCHAR(255)	= @v_ActivityDatabase

	DECLARE @v_AccountingPeriod                   INT       = NULL;
	DECLARE @v_AccountingPeriod_Default           INT       = 201812; -- this is our starting date

BEGIN TRY  

	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';



	/* Log the start of the process */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										   FROM Orchestram.Log.ActivityType	
										   WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'Load data into Inbound.Transaction and Outbound.Transaction using [Agresso].[usp_LandingToInboundToOutbound_BICI_RI_Paid]  '
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= ''
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;


	-- Get the last processed date for data from the outbound table. 
	-- We'll then process these, so we get all the records for the current month or the last month and process these.
	-- In the case that we're doing day one, we will have zero records in the outbound, so we need to get them all from our default starting date.



	--DECLARE @v_AccountingPeriod                   INT             = NULL;
	--DECLARE @v_AccountingPeriod_Default           INT             = 201811; -- this is our starting date
	--DECLARE @v_DataSet VARCHAR(255)	= 'ObligatedPremium_Munich_QQS'

	-- to get exact current DOF/Period/AsAt, Backing a quarter from Outbound for dateOffact as it has been push forward by a quarter in [OP].[usp_LandingInboundWorkflow_ObligatedPremium_Munich_QQS]

	SELECT @v_AccountingPeriod = ISNULL(CONVERT(INT,CONVERT(CHAR(6),CONVERT(DATE,MAX(DateOfFact)),112)),@v_AccountingPeriod_Default)
	FROM [FinanceDataContract].[Outbound].[Transaction]
	WHERE Dataset = @v_DataSet

	--select @v_AccountingPeriod=201903
	
	DECLARE @Dates TABLE(Asat INT, i INT IDENTITY(1,1))
	INSERT INTO @Dates(Asat)
	
	SELECT DISTINCT ff.AccountingPeriod
	FROM  [Agresso].[BICIRI_Paid] ff 
	WHERE  
		ISDATE(CONVERT(VARCHAR(30),(CONVERT(VARCHAR(30),ff.AccountingPeriod)+'01'),12))=1 -- filter out non dates.
		AND ff.AccountingPeriod > @v_AccountingPeriod and (RIGHT(ff.AccountingPeriod,2) in('03', '06', '09', '12') )
	ORDER BY ff.AccountingPeriod ASC
	

	DECLARE @i int = 1

	WHILE EXISTS(SELECT 1 FROM @Dates WHERE i=@i)
	BEGIN

		SET @v_AccountingPeriod = (SELECT Asat FROM @Dates WHERE i=@i)

		SELECT [@v_AccountingPeriod] = @v_AccountingPeriod 

		EXEC [Agresso].[usp_LandingInboundWorkflow_BICIRI_Paid]
			@p_AccountingPeriod	= @v_AccountingPeriod  

		PRINT 'EXEC [Agresso].[usp_LandingToInboundToOutboundWorkflow_BICIRI_Paid] '
		IF EXISTS(SELECT 1 FROM [FinanceDataContract].Inbound.[Transaction] WHERE DataSet = @v_DataSet)
		BEGIN
			--SELECT 'EXISTS'
			exec [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_ReInsuranceExtensions]
			--exec [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow] @DoNonIFRS17_Tests = 0   -- Reversal Record DOF for this are not as expected

			exec [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_GAAP] @DoNonIFRS17_Tests = 1
		end
		
		set @i += 1

		-- debug code to do a limited number
		--if @i>1 set @i=1000000
	end


	-- LOG THE RESULT WITH SUCCESS
	SELECT @v_ActivityDateTime			= GETUTCDATE();

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
			 @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStop
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;


END TRY

BEGIN CATCH
			        
			-- LOG THE RESULT WITH ERROR

			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

		    THROW;

END CATCH;

					
END