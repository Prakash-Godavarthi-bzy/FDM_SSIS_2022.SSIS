﻿CREATE PROCEDURE [Agresso].[usp_LandingInboundWorkflow_BICIRI_Orc_Tactical] @p_AccountingPeriod INT
AS
BEGIN
	/* =====================================================================================================================================================================================
-- Details:
--Version				DateOfModification		UpdatedBY									Description
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- 1.0					20-11-2023				Yasaswini.kandimalla@beazley.com			I1B-3847 Tactical to Strategic Load for BICI_RI ORC Tactical --Intital Version 
	1.1					31-01-2024				nithin.dumpeti@beazley.com					adding 1 quarter to @DateOfFact to perfrom pushforward for open Yoa's.  
	1.2					19-04-2024				Lakshman.Akasapu@beazley.com				Added a condition to Code line No.1171. This will restrict creating a Batchid if no data found in Inbound. This will avoid creating Reversal Entries in Outbound.Transaction


----------------------------------------------------------------------------------------------------------------------------------------------------------------------
Change Version	:	1.3  
Sprint			: BR1 Q3 24 Committed
Author			: Bhargav Entha    <entha.bhargav@beazley.com>
Modify Date		:  11/07/2024 
Description		:  https://beazley.atlassian.net/browse/I1B-5667
					Add on a Old Policy to extract Valid ProgrammeCode and RIPolicyType. Inconsistency between Agresso and Eurobase data resulting Unknown PC's with the join failure.
				
 ====================================================================================================================================================================================== */
	DECLARE @Trancount INT = @@Trancount;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;
	/*======================================================Logging Starts==================================================*/
	--DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);
	DECLARE @v_RC INT;
	DECLARE @v_ActivityLogTag BIGINT;
	DECLARE @v_ActivitySource SMALLINT;
	DECLARE @v_ActivityType SMALLINT;
	DECLARE @v_ActivityStatusStart SMALLINT;
	DECLARE @v_ActivityStatusStop SMALLINT;
	DECLARE @v_ActivityStatusFail SMALLINT;
	DECLARE @v_ActivityHost VARCHAR(100);
	DECLARE @v_ActivityDatabase VARCHAR(100) = 'BICI_ORC_TACTICAL';
	DECLARE @v_ActivityName VARCHAR(100);
	DECLARE @v_ActivityDateTime DATETIME2(2);
	DECLARE @v_ActivityMessage NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn BIGINT;
	DECLARE @v_ActivityLogIdOut BIGINT;
	DECLARE @v_ActivityJobId VARCHAR(50) = NULL;
	DECLARE @v_ActivitySSISExecutionId VARCHAR(50) = NULL;
	DECLARE @v_AffectedRows INT
	DECLARE @ContractType CHAR(3) = 'BOT';
	DECLARE @p_ParentActivityLogId BIGINT = NULL
	DECLARE @v_Dataset VARCHAR(50) = @v_ActivityDatabase
	DECLARE @v_BatchId INT = NULL;
	DECLARE @v_BatchId_Extensions INT;
	DECLARE @AccountingPeriod VARCHAR(20) = @p_AccountingPeriod;
	DECLARE @AsAt VARCHAR(6)

	SELECT @v_ActivityStatusStart = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'ERRORED';

	INSERT INTO [dbo].[Batch] (
		[CreateDate]
		,[DataSet]
		)
	VALUES (
		GETDATE()
		,@v_Dataset
		);

	SELECT @v_BatchId = SCOPE_IDENTITY();

	SET @v_ActivityJobId = @v_BatchId

	/* Log the start of the insert */
	SELECT @v_ActivityLogTag = NULL
		,@v_ActivitySource = (
			SELECT PK_ActivitySource
			FROM Orchestram.Log.ActivitySource
			WHERE ActivitySource = 'IFRS17'
			)
		,@v_ActivityType = (
			SELECT PK_ActivityType
			FROM Orchestram.Log.ActivityType
			WHERE ActivityType = CASE 
					WHEN @p_ParentActivityLogId IS NULL
						THEN 'Manual process'
					ELSE 'Automated process'
					END
			)
		,@v_ActivityHost = @@SERVERNAME
		,@v_ActivityName = 'Agresso.usp_LandingIBWF_BICI_ORC_TACTICAL'
		,@v_ActivityDateTime = GETUTCDATE()
		,@v_ActivityMessage = 'Load data into Inbound.Transaction for BICIRI_ORC_TACTICAL Started'
		,@v_ActivityErrorCode = NULL
		,@v_AffectedRows = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
		,@v_ActivityLogTag
		,@v_ActivitySource
		,@v_ActivityType
		,@v_ActivityStatusStart
		,@v_ActivityHost
		,@v_ActivityDatabase
		,@v_ActivityJobId
		,@v_ActivitySSISExecutionId
		,@v_ActivityName
		,@v_ActivityDateTime
		,@v_ActivityMessage
		,@v_ActivityErrorCode
		,@v_AffectedRows
		,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

	/*==================Logging End======================*/
	BEGIN TRY
		IF @Trancount = 0
			BEGIN TRAN;

		/*
=============================================================================================
	Create BatchID In landing
==============================================================================================
*/
		DECLARE @Scenario CHAR(1) = 'F'
			,@Basis CHAR(1) = 'E'
			,@DefaultDate DATETIME2 = CAST('01-01-1980' AS DATETIME2)
			,@TypeOfBusiness CHAR(1) = '-'
			,@Location CHAR(1) = '-'
			,@IsToDate CHAR(1) = 'Y'
			,@BusinessProcessCode CHAR(2) = 'T1'
			,@AuditHost VARCHAR(255) = CAST(SERVERPROPERTY('MachineName') AS VARCHAR(255))
			,@StatsCode VARCHAR(25) = NULL
			,@DateOfFact DATE = DATEADD(QUARTER, 1, DATEFROMPARTS(SUBSTRING(@AccountingPeriod, 1, 4), SUBSTRING(@AccountingPeriod, 5, 6), '01')) -- Here @AccountingPeriod will be pushforward by 1 quarter (eg: default is 201809 and pushforward date is 201812 so, insert 201809 data with 201812 dateoffact in box3)			

		SET @AsAt = left(CONVERT(VARCHAR(10), @DateOfFact, 112), 6) --log the Pushforward AccountingPeriod in InBound.BatchQueue

		INSERT @Logging (
			ActivityStatus
			,ActivityName
			,ActivityMessage
			)
		SELECT 5
			,'Agresso.usp_LandingIBWF_BICIRI_ORC_TACTICAL'
			,' ' + CONVERT(VARCHAR, @v_BatchId) + ' Batch Created';

		IF object_id(N'tempdb..#programme') IS NOT NULL
			DROP TABLE #programme

		SELECT DISTINCT PolicyNo
			,RIPolicyType = CASE 
				WHEN PolicyDescription LIKE '%xs%'
					THEN 'XL'
				WHEN PolicyDescription LIKE '%Excess%'
					THEN 'XL'
				WHEN PolicyDescription LIKE '%XOL%'
					THEN 'XL'
				WHEN PolicyDescription LIKE '%Stop Loss%'
					THEN 'XL'
				WHEN PolicyNo LIKE '%XL%'
					THEN 'XL'
				WHEN PolicyDescription LIKE '%Marine Group%'
					THEN 'XL'
				WHEN PolicyNo LIKE 'SPG__EPL%'
					THEN 'XL'
				WHEN PolicyNo LIKE 'CPG%'
					THEN 'XL'
				WHEN PolicyDescription LIKE '%Quota Share%'
					THEN 'QS'
				WHEN PolicyNo LIKE '%QS%'
					THEN 'QS'
				WHEN PolicyDescription LIKE '% QS %'
					THEN 'QS'
				WHEN PolicyDescription LIKE '%Surplus%'
					THEN 'QS'
				WHEN PolicyDescription LIKE '%Master RI%'
					THEN 'QS'
				WHEN PolicyDescription LIKE '%Master Reinsurance%'
					THEN 'QS'
				WHEN PolicyDescription LIKE '%BBR Services%'
					THEN 'QS'
				WHEN PolicyNo LIKE 'CPAFB%'
					THEN 'QS'
				WHEN PolicyNo LIKE 'ENGCTL%'
					THEN 'QS'
				WHEN PolicyNo LIKE 'ENGTAF%'
					THEN 'QS'
				WHEN PolicyNo LIKE 'RICPBM%'
					THEN 'QS'
				WHEN PolicyNo LIKE 'BNP%'
					THEN 'FAC'
				WHEN PolicyNo LIKE 'RIUNIR'
					THEN 'FAC'
				WHEN PolicyNo LIKE 'CDM%'
					THEN 'FAC'
				WHEN PolicyNo LIKE 'DEW%'
					THEN 'FAC'
				WHEN PolicyNo LIKE 'IBI%'
					THEN 'FAC'
				WHEN PolicyNo LIKE 'STANTEC%'
					THEN 'FAC'
				WHEN PolicyDescription LIKE 'Specialty FAC%'
					THEN 'FAC'
				WHEN PolicyDescription LIKE '% FAC %'
					THEN 'FAC'
				WHEN PolicyNo LIKE '%FAC%'
					THEN 'FAC'
				WHEN PolicyNo LIKE 'V%'
					THEN 'FAC'
				WHEN PolicyDescription LIKE '%Loss Portfolio Transfer Reinsurance Agreement%'
					THEN 'QS'
				WHEN PolicyDescription LIKE '%BICI/Globe Reinsurance Agreement%'
					THEN 'QS'
				ELSE NULL
				END
			,Programme = CASE 
				WHEN PolicyNo LIKE 'AHG__XL%'
					THEN 'Life & Accident Cat'
				WHEN PolicyNo LIKE 'BICISLRXA%'
					THEN 'BICI Risk & Agg XL'
				WHEN PolicyNo LIKE 'BNP%'
					THEN 'SL Facultative spend'
				WHEN PolicyNo LIKE 'CDM%'
					THEN 'SL Facultative spend'
				WHEN PolicyNo LIKE 'CP_XOL%'
					THEN 'Property XL'
				WHEN PolicyNo LIKE 'CPXOL%'
					THEN 'Property XL' --
				WHEN PolicyNo LIKE 'CPAFB%'
					THEN 'BICCPF' --
				WHEN PolicyNo LIKE 'CPF%'
					THEN 'Property FAC'
				WHEN PolicyNo LIKE 'CPG%'
					AND PolicyNo LIKE '%PRX%'
					THEN 'PRXS'
				WHEN PolicyNo LIKE 'CPG%'
					THEN 'Property Cat XL'
				WHEN PolicyNo LIKE 'CPQS%'
					AND PolicyDescription LIKE 'Commercial Property Quota Share Treaty%'
					THEN 'BFS QS'
				WHEN PolicyNo LIKE 'DEW%'
					THEN 'SL Facultative spend'
				WHEN PolicyNo LIKE 'EMEPL%'
					THEN 'BICI Internal QS'
				WHEN PolicyNo LIKE 'ENGF%'
					THEN 'Marine Facultative Spend'
				WHEN PolicyNo LIKE 'ENGG%'
					AND PolicyNo LIKE '%XL%'
					THEN 'MORTAR - Engineering Risk Xs'
				WHEN PolicyNo LIKE 'ENGTR%'
					AND PolicyNo LIKE '%QS%'
					THEN 'Engineering Terrorism QS'
				WHEN PolicyNo LIKE 'ENGCTL%'
					THEN 'Internal QS  - Engineering'
				WHEN PolicyNo LIKE 'ENGTAF%'
					THEN 'Internal QS  - Engineering'
				WHEN PolicyNo LIKE 'ENG%'
					AND PolicyNo LIKE '%QS%'
					AND PolicyDescription LIKE '%Internal%'
					THEN 'Internal QS  - Engineering'
				WHEN PolicyNo LIKE 'ENG%'
					AND PolicyNo LIKE '%QS%'
					THEN 'Engineering Quota Share'
				WHEN PolicyNo LIKE 'IBI%'
					THEN 'SL Facultative spend'
				WHEN PolicyNo LIKE 'INTFALQS%'
					THEN 'Internal QS - Marine Falvey'
				WHEN PolicyNo LIKE 'INTMARQS%'
					THEN 'Internal QS  - Marine Non Falvey'
				WHEN PolicyNo LIKE 'INTPOLQS%'
					THEN 'Internal QS  - Political Risks'
				WHEN PolicyNo LIKE 'MARFALQS%'
					THEN 'Internal QS - Marine Falvey'
				WHEN PolicyNo LIKE 'MARCHLQS%'
					THEN 'Internal QS  - Marine Non Falvey'
				WHEN PolicyNo LIKE 'MARG%'
					AND PolicyNo LIKE '%CGOA%'
					THEN 'MARGEN'
				WHEN PolicyNo LIKE 'MARG%'
					AND PolicyNo LIKE '%CGOB%'
					THEN 'MARGEN'
				WHEN PolicyNo LIKE 'MARG%'
					AND PolicyNo LIKE '%CGO%'
					THEN 'Marine XL'
				WHEN PolicyNo LIKE 'MARG%'
					AND PolicyNo LIKE '%GEN%'
					THEN 'MARGEN'
				WHEN PolicyNo LIKE 'MARG%'
					AND PolicyNo LIKE '%GEX%'
					THEN 'MARGEX'
				WHEN PolicyNo LIKE 'MARG%'
					AND PolicyNo LIKE '%RPP%'
					THEN 'MARRPP'
				WHEN PolicyNo LIKE 'MARG%'
					THEN 'Marine XL'
				WHEN PolicyNo LIKE 'MARQS%'
					THEN 'Internal QS  - Marine Non Falvey'
				WHEN PolicyNo LIKE 'MAR__FAC%'
					THEN 'Internal QS'
				WHEN PolicyNo LIKE 'MSTRI%'
					THEN 'Master RI'
				WHEN PolicyNo LIKE 'PCGCPRQS%'
					THEN 'Internal QS  - Political Risks'
				WHEN PolicyNo LIKE 'PCGG__XLCPR%'
					THEN 'TALK - Political Risks XL'
				WHEN PolicyNo LIKE 'RICPBM%'
					THEN 'US Boiler & Machinery'
				WHEN PolicyNo LIKE 'RIUNIR'
					THEN 'SL Facultative spend'
				WHEN PolicyNo LIKE 'SPAELAW%'
					AND PolicyNo LIKE '%QS%'
					THEN 'A&E Lawyers QS'
				WHEN PolicyNo LIKE 'SPCUNAQS%'
					THEN 'CUNA QS'
				WHEN PolicyNo LIKE 'SPCYB%QS%'
					THEN 'Cyber QS'
				WHEN PolicyNo LIKE 'SPEXTCYBER%'
					THEN 'Cyber QS'
				WHEN PolicyNo LIKE 'SPDOQS%'
					THEN 'SWORD D&O'
				WHEN PolicyNo LIKE 'SPEXT%'
					AND PolicyNo LIKE '%ENV%'
					THEN 'Environmental QS'
				WHEN PolicyNo LIKE 'SPEXT%'
					AND PolicyNo LIKE '%SUR%'
					THEN 'MUNICH - Surplus'
				WHEN PolicyNo LIKE 'SPEXT%'
					AND PolicyNo LIKE '%QS%'
					THEN 'MUNQQS'
				WHEN PolicyNo LIKE 'SPEXT%'
					AND PolicyNo LIKE '%BBR%'
					THEN 'MUNQQS'
				WHEN PolicyNo LIKE 'SPG__LAG%'
					THEN 'Lawyers Risk Excess'
				WHEN PolicyNo LIKE 'SPINTXOL%'
					THEN 'BICI Risk & Agg XL'
				WHEN PolicyNo LIKE 'SPLAWQS%'
					THEN 'Lawyers QS'
				WHEN PolicyNo LIKE 'SPG__CL%'
					THEN 'Systemic cover - Clash'
				WHEN PolicyNo LIKE 'SPG__PETMB%'
					THEN 'US Small Risks XL'
				WHEN PolicyNo LIKE 'SPG__PROF%'
					AND YOA < '2015'
					THEN 'Professions Agg XL'
				WHEN PolicyNo LIKE 'SPG__PROF%'
					AND YOA >= '2015'
					THEN 'Professions'
				WHEN PolicyNo LIKE 'SPG__EPL%'
					THEN 'EPL Risk Excess'
				WHEN PolicyNo LIKE 'SPG__CFE%'
					THEN 'COFFEE'
				WHEN PolicyNo LIKE 'SPOCCQS%'
					THEN 'Occurrence QS'
				WHEN PolicyNo LIKE 'SPQS%'
					THEN 'BICI Internal QS'
				WHEN PolicyNo LIKE 'SPSUR%'
					THEN 'BICI Internal QS'
				WHEN PolicyNo LIKE 'STANTEC%'
					THEN 'SL Facultative spend'
				WHEN PolicyNo LIKE 'TERG__SA%'
					THEN 'Terrorism XLs'
				WHEN PolicyNo LIKE 'WTHQS%'
					THEN 'BICI Internal QS'
				WHEN PolicyNo LIKE 'WTHSUR%'
					THEN 'BICI Internal QS'
				WHEN PolicyDescription LIKE '%Master RI%'
					THEN 'Master RI'
				WHEN PolicyDescription LIKE '%Loss Portfolio Transfer Reinsurance Agreement%'
					THEN 'PORTFOLIO TRANSFER BICI TO CAPTIVE RI'
				WHEN PolicyDescription LIKE '%BICI/Globe Reinsurance Agreement%'
					THEN 'GLOBE'
				WHEN PolicyDescription LIKE 'Specialty FAC%'
					THEN 'SL Facultative spend'
				WHEN PolicyDescription LIKE '% FAC %'
					THEN 'SL Facultative spend'
				WHEN PolicyNo LIKE '%FAC%'
					THEN 'SL Facultative spend'
				WHEN PolicyNo LIKE 'V%'
					THEN 'SL Facultative spend'
				WHEN PolicyNo			  LIKE 'R1139%'									 
					THEN 'MUNQQS'
				ELSE NULL
				END
		INTO #programme
		FROM [Agresso].[BICIRI_ORC_Tactical] t
		LEFT JOIN FinanceLanding.Eurobase.reinsurance_pol_det pol ON (pol.rpd_policy_reference = t.PolicyNo)
		WHERE pol.rpd_policy_reference IS NULL
			AND PolicyNo NOT IN (
				''
				,'NO POLICY'
				)

		IF object_id(N'tempdb..#data') IS NOT NULL
			DROP TABLE #data

		SELECT DateOfFact = cast(CASE 
					WHEN right(t.AccountingPeriod, 2) IN (
							'01'
							,'02'
							)
						THEN left(t.AccountingPeriod, 4) + '03'
					WHEN right(t.AccountingPeriod, 2) IN (
							'04'
							,'05'
							)
						THEN left(t.AccountingPeriod, 4) + '06'
					WHEN right(t.AccountingPeriod, 2) IN (
							'07'
							,'08'
							)
						THEN left(t.AccountingPeriod, 4) + '09'
					WHEN right(t.AccountingPeriod, 2) IN (
							'10'
							,'11'
							)
						THEN left(t.AccountingPeriod, 4) + '12'
					ELSE t.AccountingPeriod
					END + '01' AS DATE)
			,TrifocusCode = t.TrifocusCode
			,YOA = t.YOA
			,CCY = t.CCY
			,[Value] = sum(cast(Amount AS NUMERIC(30, 4)))
			,[ValueOrig] = sum(cast(t.Amount AS NUMERIC(30, 4)))
			,ProgrammeCode = CASE 
				WHEN t.PolicyNo IN (
						''
						,'NO POLICY'
						)
					AND t.YOA <= '2010'
					AND t.UWProd = 'CPBM'
					THEN 'US Boiler & Machinery'
				WHEN t.PolicyNo IN (
						''
						,'NO POLICY'
						)
					AND t.YOA <= '2010'
					THEN 'BICI Internal QS'
				WHEN t.PolicyNo IN (
						''
						,'NO POLICY'
						)
					AND right(Account, 2) = '00'
					THEN 'BICI_HISTORICAL'
				WHEN t.PolicyNo IN (
						''
						,'NO POLICY'
						)
					THEN 'BICI Internal QS'
				WHEN isnull(tmp.Programme, isnull(CASE 
								WHEN prg.ifrs17_programme_group = 'BICI FAC'
									THEN 'SL Facultative spend'
								ELSE prg.ifrs17_programme_group
								END, 'UNKNOWN')) NOT LIKE '%Internal%'
					AND isnull(tmp.Programme, isnull(CASE 
								WHEN prg.ifrs17_programme_group = 'BICI FAC'
									THEN 'SL Facultative spend'
								ELSE prg.ifrs17_programme_group
								END, 'UNKNOWN')) NOT IN (
						'BICI Risk & Agg XL'
						,'PORTFOLIO TRANSFER BICI TO CAPTIVE RI'
						)
					AND right(Account, 2) <> '00'
					THEN 'BICI Internal QS'
				ELSE isnull(tmp.Programme, isnull(CASE 
								WHEN prg.ifrs17_programme_group = 'BICI FAC'
									THEN 'SL Facultative spend'
								ELSE prg.ifrs17_programme_group
								END, 'UNKNOWN'))
				END
			,RIPolicyType = CASE 
				WHEN t.PolicyNo IN (
						''
						,'NO POLICY'
						)
					THEN 'UNK'
				ELSE isnull(tmp.RIPolicyType, isnull(CASE 
								WHEN prg.ifrs17_programme_group = 'BICI FAC'
									THEN 'FAC'
								WHEN tty.[rpd_rein_policy_type] IN (
										'SL'
										,'RE'
										)
									THEN 'XL'
								ELSE tty.[rpd_rein_policy_type]
								END, 'UNKNOWN'))
				END
			,UWProd = t.UWProd
		INTO #data
		FROM FinanceLanding.Agresso.BICIRI_ORC_Tactical t
		LEFT JOIN FinanceLanding.Eurobase.reinsurance_pol_det tty ON (tty.rpd_policy_reference = t.PolicyNo)
		LEFT JOIN FinanceLanding.Eurobase.rein_program_sequence prg ON (prg.rps_program_id = tty.rpd_treaty_ri_code)
		LEFT JOIN #programme tmp ON (tmp.PolicyNo = t.PolicyNo)
		GROUP BY cast(CASE 
					WHEN right(t.AccountingPeriod, 2) IN (
							'01'
							,'02'
							)
						THEN left(t.AccountingPeriod, 4) + '03'
					WHEN right(t.AccountingPeriod, 2) IN (
							'04'
							,'05'
							)
						THEN left(t.AccountingPeriod, 4) + '06'
					WHEN right(t.AccountingPeriod, 2) IN (
							'07'
							,'08'
							)
						THEN left(t.AccountingPeriod, 4) + '09'
					WHEN right(t.AccountingPeriod, 2) IN (
							'10'
							,'11'
							)
						THEN left(t.AccountingPeriod, 4) + '12'
					ELSE t.AccountingPeriod
					END + '01' AS DATE)
			,t.TrifocusCode
			,t.YOA
			,CCY
			,UWProd
			,CASE 
				WHEN t.PolicyNo IN (
						''
						,'NO POLICY'
						)
					AND t.YOA <= '2010'
					AND t.UWProd = 'CPBM'
					THEN 'US Boiler & Machinery'
				WHEN t.PolicyNo IN (
						''
						,'NO POLICY'
						)
					AND t.YOA <= '2010'
					THEN 'BICI Internal QS'
				WHEN t.PolicyNo IN (
						''
						,'NO POLICY'
						)
					AND right(Account, 2) = '00'
					THEN 'BICI_HISTORICAL'
				WHEN t.PolicyNo IN (
						''
						,'NO POLICY'
						)
					THEN 'BICI Internal QS'
				WHEN isnull(tmp.Programme, isnull(CASE 
								WHEN prg.ifrs17_programme_group = 'BICI FAC'
									THEN 'SL Facultative spend'
								ELSE prg.ifrs17_programme_group
								END, 'UNKNOWN')) NOT LIKE '%Internal%'
					AND isnull(tmp.Programme, isnull(CASE 
								WHEN prg.ifrs17_programme_group = 'BICI FAC'
									THEN 'SL Facultative spend'
								ELSE prg.ifrs17_programme_group
								END, 'UNKNOWN')) NOT IN (
						'BICI Risk & Agg XL'
						,'PORTFOLIO TRANSFER BICI TO CAPTIVE RI'
						)
					AND right(Account, 2) <> '00'
					THEN 'BICI Internal QS'
				ELSE isnull(tmp.Programme, isnull(CASE 
								WHEN prg.ifrs17_programme_group = 'BICI FAC'
									THEN 'SL Facultative spend'
								ELSE prg.ifrs17_programme_group
								END, 'UNKNOWN'))
				END
			,CASE 
				WHEN t.PolicyNo IN (
						''
						,'NO POLICY'
						)
					THEN 'UNK'
				ELSE isnull(tmp.RIPolicyType, isnull(CASE 
								WHEN prg.ifrs17_programme_group = 'BICI FAC'
									THEN 'FAC'
								WHEN tty.[rpd_rein_policy_type] IN (
										'SL'
										,'RE'
										)
									THEN 'XL'
								ELSE tty.[rpd_rein_policy_type]
								END, 'UNKNOWN'))
				END
		
		UNION ALL
		
		SELECT DateOfFact = cast(d.AccountingPeriod + '01' AS DATE)
			,t.TrifocusCode
			,t.YOA
			,t.CCY
			,[Value] = 0
			,[ValueOrig] = 0
			,ProgrammeCode = CASE 
				WHEN t.PolicyNo IN (
						''
						,'NO POLICY'
						)
					AND t.YOA <= '2010'
					AND t.UWProd = 'CPBM'
					THEN 'US Boiler & Machinery'
				WHEN t.PolicyNo IN (
						''
						,'NO POLICY'
						)
					AND t.YOA <= '2010'
					THEN 'BICI Internal QS'
				WHEN t.PolicyNo IN (
						''
						,'NO POLICY'
						)
					AND right(Account, 2) = '00'
					THEN 'BICI_HISTORICAL'
				WHEN t.PolicyNo IN (
						''
						,'NO POLICY'
						)
					THEN 'BICI Internal QS'
				WHEN isnull(tmp.Programme, isnull(CASE 
								WHEN prg.ifrs17_programme_group = 'BICI FAC'
									THEN 'SL Facultative spend'
								ELSE prg.ifrs17_programme_group
								END, 'UNKNOWN')) NOT LIKE '%Internal%'
					AND isnull(tmp.Programme, isnull(CASE 
								WHEN prg.ifrs17_programme_group = 'BICI FAC'
									THEN 'SL Facultative spend'
								ELSE prg.ifrs17_programme_group
								END, 'UNKNOWN')) NOT IN (
						'BICI Risk & Agg XL'
						,'PORTFOLIO TRANSFER BICI TO CAPTIVE RI'
						)
					AND right(Account, 2) <> '00'
					THEN 'BICI Internal QS'
				ELSE isnull(tmp.Programme, isnull(CASE 
								WHEN prg.ifrs17_programme_group = 'BICI FAC'
									THEN 'SL Facultative spend'
								ELSE prg.ifrs17_programme_group
								END, 'UNKNOWN'))
				END
			,RIPolicyType = CASE 
				WHEN t.PolicyNo IN (
						''
						,'NO POLICY'
						)
					THEN 'UNK'
				ELSE isnull(tmp.RIPolicyType, isnull(CASE 
								WHEN prg.ifrs17_programme_group = 'BICI FAC'
									THEN 'FAC'
								WHEN tty.[rpd_rein_policy_type] IN (
										'SL'
										,'RE'
										)
									THEN 'XL'
								ELSE tty.[rpd_rein_policy_type]
								END, 'UNKNOWN'))
				END
			,t.UWProd
		FROM [Agresso].[BICIRI_ORC_Tactical] t
		LEFT JOIN FinanceLanding.Eurobase.reinsurance_pol_det tty ON (tty.rpd_policy_reference = t.PolicyNo)
		LEFT JOIN FinanceLanding.Eurobase.rein_program_sequence prg ON (prg.rps_program_id = tty.rpd_treaty_ri_code)
		LEFT JOIN #programme tmp ON (tmp.PolicyNo = t.PolicyNo)
		JOIN FinanceLanding.fdm.AccountingPeriod d ON (
				d.AccountingPeriod > t.AccountingPeriod
				AND d.AccountingPeriod <= left(convert(VARCHAR(10), getdate(), 112), 6)
				AND substring(d.AccountingPeriod, 5, 2) IN (
					'03'
					,'06'
					,'09'
					,'12'
					)
				)
		GROUP BY cast(d.AccountingPeriod + '01' AS DATE)
			,t.TrifocusCode
			,t.YOA
			,CCY
			,UWProd
			,CASE 
				WHEN t.PolicyNo IN (
						''
						,'NO POLICY'
						)
					AND t.YOA <= '2010'
					AND t.UWProd = 'CPBM'
					THEN 'US Boiler & Machinery'
				WHEN t.PolicyNo IN (
						''
						,'NO POLICY'
						)
					AND t.YOA <= '2010'
					THEN 'BICI Internal QS'
				WHEN t.PolicyNo IN (
						''
						,'NO POLICY'
						)
					AND right(Account, 2) = '00'
					THEN 'BICI_HISTORICAL'
				WHEN t.PolicyNo IN (
						''
						,'NO POLICY'
						)
					THEN 'BICI Internal QS'
				WHEN isnull(tmp.Programme, isnull(CASE 
								WHEN prg.ifrs17_programme_group = 'BICI FAC'
									THEN 'SL Facultative spend'
								ELSE prg.ifrs17_programme_group
								END, 'UNKNOWN')) NOT LIKE '%Internal%'
					AND isnull(tmp.Programme, isnull(CASE 
								WHEN prg.ifrs17_programme_group = 'BICI FAC'
									THEN 'SL Facultative spend'
								ELSE prg.ifrs17_programme_group
								END, 'UNKNOWN')) NOT IN (
						'BICI Risk & Agg XL'
						,'PORTFOLIO TRANSFER BICI TO CAPTIVE RI'
						)
					AND right(Account, 2) <> '00'
					THEN 'BICI Internal QS'
				ELSE isnull(tmp.Programme, isnull(CASE 
								WHEN prg.ifrs17_programme_group = 'BICI FAC'
									THEN 'SL Facultative spend'
								ELSE prg.ifrs17_programme_group
								END, 'UNKNOWN'))
				END
			,CASE 
				WHEN t.PolicyNo IN (
						''
						,'NO POLICY'
						)
					THEN 'UNK'
				ELSE isnull(tmp.RIPolicyType, isnull(CASE 
								WHEN prg.ifrs17_programme_group = 'BICI FAC'
									THEN 'FAC'
								WHEN tty.[rpd_rein_policy_type] IN (
										'SL'
										,'RE'
										)
									THEN 'XL'
								ELSE tty.[rpd_rein_policy_type]
								END, 'UNKNOWN'))
				END

		IF object_id(N'tempdb..#FinalData') IS NOT NULL
			DROP TABLE #FinalData

		SELECT *
		INTO #FinalData
		FROM (
			SELECT PK_Transaction
				,Scenario
				,Account
				,Dataset
				,DateOfFact
				,BusinessKey
				,PolicyNumber
				,InceptionDate
				,ExpiryDate
				,BindDate
				,DueDate
				,TrifocusCode
				,Entity
				,YOA
				,TypeOfBusiness
				,StatsCode
				,SettlementCCY
				,OriginalCCY
				,[IsToDate]
				,[Value]
				,Rowhash
				,FK_Allocation
				,DeltaType
				,AuditSourceBatchID
				,AuditCreateDateTime
				,AuditGenerateDateTime
				,AuditUserCreate
				,AuditHost
				,Basis
				,[Location]
				,ValueOrig
				,BusinessProcessCode
				,FK_Batch
				,BoundDate
				,RIPolicyType
				,ProgrammeCode
			FROM (
				SELECT PK_Transaction = NULL
					,Scenario = 'F'
					,Account = 'PC-LS-OR-' + CASE 
						WHEN RIPolicyType = 'FAC'
							THEN 'FAC'
						ELSE 'TTY'
						END
					,Dataset = 'BICI_ORC_TACTICAL'
					,DateOfFact
					,BusinessKey = 'PC-LS-OR-' + CASE 
						WHEN RIPolicyType = 'FAC'
							THEN 'FAC'
						ELSE 'TTY'
						END + '|' + isnull(ProgrammeCode, '-') + '|' + isnull(cast(YOA AS VARCHAR(10)), '-') + '|' + isnull(CCY, '-') + '|' + '8022' + '|' + isnull(TrifocusCode, '-')
					,PolicyNumber = 'NOPOLICY'
					,InceptionDate = cast('1980-01-01' AS DATE)
					,ExpiryDate = cast('1980-01-01' AS DATE)
					,BindDate = cast('1980-01-01' AS DATE)
					,DueDate = cast('1980-01-01' AS DATE)
					,TrifocusCode
					,Entity = 'USBICI'
					,YOA
					,TypeOfBusiness = '-'
					,StatsCode = NULL
					,SettlementCCY = CCY
					,OriginalCCY = CCY
					,[IsToDate] = 'Y'
					,[Value] = sum(sum([Value])) OVER (
						PARTITION BY TrifocusCode
						,YOA
						,ProgrammeCode
						,CCY
						,RIPolicyType
						,'PC-LS-OR-' + CASE 
							WHEN RIPolicyType = 'FAC'
								THEN 'FAC'
							ELSE 'TTY'
							END ORDER BY DateOfFact ASC
						)
					,Rowhash = NULL
					,FK_Allocation = NULL
					,DeltaType = NULL
					,AuditSourceBatchID = NULL
					,AuditCreateDateTime = NULL
					,AuditGenerateDateTime = NULL
					,AuditUserCreate = NULL
					,AuditHost = NULL
					,Basis = 'E'
					,[Location] = '-'
					,ValueOrig = sum(sum([Value])) OVER (
						PARTITION BY TrifocusCode
						,YOA
						,ProgrammeCode
						,CCY
						,RIPolicyType
						,'PC-LS-OR-' + CASE 
							WHEN RIPolicyType = 'FAC'
								THEN 'FAC'
							ELSE 'TTY'
							END ORDER BY DateOfFact ASC
						)
					,BusinessProcessCode = 'T1'
					,FK_Batch = NULL
					,BoundDate = @DefaultDate
					,RIPolicyType
					,ProgrammeCode
				FROM #data
				GROUP BY DateOfFact
					,'PC-LS-OR-' + CASE 
						WHEN RIPolicyType = 'FAC'
							THEN 'FAC'
						ELSE 'TTY'
						END
					,'PC-LS-OR-' + CASE 
						WHEN RIPolicyType = 'FAC'
							THEN 'FAC'
						ELSE 'TTY'
						END + '|' + isnull(ProgrammeCode, '-') + '|' + isnull(cast(YOA AS VARCHAR(10)), '-') + '|' + isnull(CCY, '-') + '|' + '8022' + '|' + isnull(TrifocusCode, '-')
					,TrifocusCode
					,YOA
					,CCY
					,RIPolicyType
					,ProgrammeCode
				) t
			WHERE YOA < year(DateOfFact) - CASE 
					WHEN month(DateOfFact) = 3
						THEN 3
					ELSE 2
					END
			
			UNION ALL
			
			SELECT PK_Transaction = NULL
				,Scenario = 'F'
				,Account = 'P-OR-P-' + CASE 
					WHEN [Type] = 'FAC'
						THEN 'FAC'
					ELSE 'TTY'
					END
				,Dataset = 'BICI_ORC_TACTICAL'
				,DateOfFact = dateadd(quarter, 1, cast(AccountingPeriod + '01' AS DATE))
				,BusinessKey = rtrim(ltrim(ISNULL('P-OR-P-' + CASE 
								WHEN t.[Type] = 'FAC'
									THEN 'FAC'
								ELSE 'TTY'
								END, ''))) + '|' + rtrim(ltrim(ISNULL(t.[RIRef], ''))) + '|' + rtrim(ltrim(ISNULL(t.Programme, ''))) + '|' + '8022' + '|' + rtrim(ltrim(ISNULL(CAST(t.YOA AS VARCHAR(50)), ''))) + '|' + 'USD' + '|' + rtrim(ltrim(ISNULL(tf.TrifocusCode, '')))
				,PolicyNumber = RIRef
				,InceptionDate = isnull(pol.InceptionDate, t.InceptionDate)
				,ExpiryDate = isnull(pol.ExpiryDate, t.ExpiryDate)
				,BindDate = cast('1980-01-01' AS DATE)
				,DueDate = cast('1980-01-01' AS DATE)
				,TrifocusCode
				,Entity = 'USBICI'
				,YOA
				,TypeOfBusiness = '-'
				,StatsCode = NULL
				,SettlementCCY = CCY
				,OriginalCCY = CCY
				,[IsToDate] = 'Y'
				,[Value] = sum([Value])
				,Rowhash = NULL
				,FK_Allocation = NULL
				,DeltaType = NULL
				,AuditSourceBatchID = NULL
				,AuditCreateDateTime = NULL
				,AuditGenerateDateTime = NULL
				,AuditUserCreate = NULL
				,AuditHost = NULL
				,Basis = 'E'
				,[Location] = '-'
				,ValueOrig = sum([Value])
				,BusinessProcessCode = 'T1'
				,FK_Batch = NULL
				,BoundDate = @DefaultDate
				,[Type]
				,Programme
			FROM [BICIRI].[LandingBICIRI_ORC_Tactical] t
			LEFT JOIN fdm.DimTrifocus tf ON (tf.TrifocusName = t.Trifocus)
			LEFT JOIN (
				SELECT *
				FROM (
					SELECT RIPolicyNumber
						,pk_RIPolicy
						,InceptionDate
						,ExpiryDate
						,pos = rank() OVER (
							PARTITION BY RIPolicyNumber ORDER BY pk_RIPolicy DESC
							)
					FROM [FinanceLanding].[fdm].[DimRIPolicy]
					) t
				WHERE pos = 1
				) pol ON (pol.RIPolicyNumber = t.RIRef)
			GROUP BY dateadd(quarter, 1, cast(AccountingPeriod + '01' AS DATE))
				,'P-OR-P-' + CASE 
					WHEN [Type] = 'FAC'
						THEN 'FAC'
					ELSE 'TTY'
					END
				,rtrim(ltrim(ISNULL('P-OR-P-' + CASE 
								WHEN t.[Type] = 'FAC'
									THEN 'FAC'
								ELSE 'TTY'
								END, ''))) + '|' + rtrim(ltrim(ISNULL(t.[RIRef], ''))) + '|' + rtrim(ltrim(ISNULL(t.Programme, ''))) + '|' + '8022' + '|' + rtrim(ltrim(ISNULL(CAST(t.YOA AS VARCHAR(50)), ''))) + '|' + 'USD' + '|' + rtrim(ltrim(ISNULL(tf.TrifocusCode, '')))
				,RIRef
				,isnull(pol.InceptionDate, t.InceptionDate)
				,isnull(pol.ExpiryDate, t.ExpiryDate)
				,tf.TrifocusCode
				,YOA
				,CCY
				,[Type]
				,Programme
			) t
		WHERE DateOfFact >= '2018-12-01'

		IF object_id('tempdb..#LandingTempBOT') IS NOT NULL
			DROP TABLE #LandingTempBOT

		SELECT Scenario = ISNULL(LTRIM(RTRIM(Scenario)), @Scenario)
			,Basis = ISNULL(nullif(LTRIM(RTRIM([Basis])), ''), @Basis)
			,[Account] = LTRIM(RTRIM([Account]))
			,[Dataset] = ISNULL(nullif(LTRIM(RTRIM([Dataset])), ''), @v_Dataset)
			,DateOfFact = CONVERT(DATETIME2, LTRIM(RTRIM(DateOfFact)))
			,[BusinessKey] = LTRIM(RTRIM([BusinessKey]))
			,[PolicyNumber] = ISNULL(nullif(LTRIM(RTRIM([PolicyNumber])), ''), 'NOPOLICY')
			,[InceptionDate] = ISNULL(CONVERT(DATETIME2, LTRIM(RTRIM(InceptionDate))), @DefaultDate)
			,[ExpiryDate] = ISNULL(CONVERT(DATETIME2, LTRIM(RTRIM([ExpiryDate]))), @DefaultDate)
			,[BindDate] = ISNULL(CONVERT(DATETIME2, LTRIM(RTRIM([BindDate]))), @DefaultDate)
			,[DueDate] = ISNULL(CONVERT(DATETIME2, LTRIM(RTRIM([DueDate]))), @DefaultDate)
			,[TrifocusCode] = LTRIM(RTRIM([TrifocusCode]))
			,[Entity] = LTRIM(RTRIM([Entity]))
			,[Location] = ISNULL(nullif(LTRIM(RTRIM([Location])), ''), @Location)
			,[YOA] = LTRIM(RTRIM([YOA]))
			,[TypeOfBusiness] = ISNULL(nullif(LTRIM(RTRIM([TypeOfBusiness])), ''), @TypeOfBusiness)
			,[SettlementCCY] = LTRIM(RTRIM([SettlementCCY]))
			,[OriginalCCY] = LTRIM(RTRIM([OriginalCCY]))
			,[IsToDate] = ISNULL(LTRIM(RTRIM([IsToDate])), @IsToDate)
			,[Value]
			,[ValueOrig]
			,RowHash = dbo.fn_RowHashForTransactions('T', ISNULL(LTRIM(RTRIM(Scenario)), @Scenario), LTRIM(RTRIM([Account])), ISNULL(nullif(LTRIM(RTRIM([Dataset])), ''), @v_Dataset), LTRIM(RTRIM([BusinessKey])), ISNULL(nullif(LTRIM(RTRIM([PolicyNumber])), ''), 'NOPOLICY'), ISNULL(CONVERT(DATETIME2, LTRIM(RTRIM(InceptionDate))), @DefaultDate), ISNULL(CONVERT(DATETIME2, LTRIM(RTRIM([ExpiryDate]))), @DefaultDate), ISNULL(CONVERT(DATETIME2, LTRIM(RTRIM([BindDate]))), @DefaultDate), ISNULL(CONVERT(DATETIME2, LTRIM(RTRIM([DueDate]))), @DefaultDate), LTRIM(RTRIM([TrifocusCode])), LTRIM(RTRIM([Entity])), LTRIM(RTRIM([YOA])), ISNULL(nullif(LTRIM(RTRIM([TypeOfBusiness])), ''), @TypeOfBusiness), ISNULL(nullif(LTRIM(RTRIM([StatsCode])), ''), NULL), LTRIM(RTRIM([SettlementCCY])), LTRIM(RTRIM([OriginalCCY])), ISNULL(LTRIM(RTRIM([IsToDate])), @IsToDate), ISNULL(nullif(LTRIM(RTRIM([Basis])), ''), @Basis), ISNULL(nullif(LTRIM(RTRIM([Location])), ''), @Location), ISNULL(nullif(LTRIM(RTRIM([BusinessProcessCode])), ''), @BusinessProcessCode), 
				@DefaultDate, CONCAT (
					CASE 
						WHEN RIPolicyType IS NULL
							THEN ''
						ELSE (RIPolicyType + '§~§')
						END
					,CASE 
						WHEN ProgrammeCode IS NULL
							THEN ''
						ELSE (ProgrammeCode + '§~§')
						END
					))
			,[RowHash_Transaction_ReInsurance_Extensions] = dbo.fn_RowHashForTransactions('E', ISNULL(LTRIM(RTRIM(Scenario)), @Scenario), LTRIM(RTRIM([Account])), ISNULL(nullif(LTRIM(RTRIM([Dataset])), ''), @v_Dataset), LTRIM(RTRIM([BusinessKey])), ISNULL(nullif(LTRIM(RTRIM([PolicyNumber])), ''), 'NOPOLICY'), ISNULL(CONVERT(DATETIME2, LTRIM(RTRIM(InceptionDate))), @DefaultDate), ISNULL(CONVERT(DATETIME2, LTRIM(RTRIM([ExpiryDate]))), @DefaultDate), ISNULL(CONVERT(DATETIME2, LTRIM(RTRIM([BindDate]))), @DefaultDate), ISNULL(CONVERT(DATETIME2, LTRIM(RTRIM([DueDate]))), @DefaultDate), LTRIM(RTRIM([TrifocusCode])), LTRIM(RTRIM([Entity])), LTRIM(RTRIM([YOA])), ISNULL(nullif(LTRIM(RTRIM([TypeOfBusiness])), ''), @TypeOfBusiness), ISNULL(nullif(LTRIM(RTRIM([StatsCode])), ''), NULL), LTRIM(RTRIM([SettlementCCY])), LTRIM(RTRIM([OriginalCCY])), ISNULL(LTRIM(RTRIM([IsToDate])), @IsToDate), ISNULL(nullif(LTRIM(RTRIM([Basis])), ''), @Basis), ISNULL(nullif(LTRIM(RTRIM([Location])), ''), @Location), ISNULL(nullif(LTRIM(RTRIM(
								[BusinessProcessCode])), ''), @BusinessProcessCode), @DefaultDate, CONCAT (
					CASE 
						WHEN RIPolicyType IS NULL
							THEN ''
						ELSE (RIPolicyType + '§~§')
						END
					,CASE 
						WHEN ProgrammeCode IS NULL
							THEN ''
						ELSE (ProgrammeCode + '§~§')
						END
					))
			,[BusinessProcessCode] = ISNULL(nullif(LTRIM(RTRIM([BusinessProcessCode])), ''), @BusinessProcessCode)
			,[AuditSourceBatchID] = CAST(@v_BatchId AS VARCHAR(50))
			,[AuditGenerateDateTime] = GETUTCDATE()
			,[StatsCode] = ISNULL(nullif(LTRIM(RTRIM([StatsCode])), ''), NULL)
			,[FK_Batch] = @v_BatchId
			,[DeltaType] = LTRIM(RTRIM([DeltaType]))
			,[FK_Allocation] = LTRIM(RTRIM([FK_Allocation]))
			,[AuditUserCreate]
			,[AuditCreateDateTime] = GETUTCDATE()
			,AuditHost = @AuditHost
			,[BoundDate]
			,RIPolicyType = LTRIM(RTRIM(RIPolicyType))
			,ProgrammeCode = LTRIM(RTRIM(ProgrammeCode))
		INTO #LandingTempBOT
		FROM #FinalData
		WHERE DateOfFact = @DateOfFact

		SELECT @v_AffectedRows = @@ROWCOUNT;

		INSERT @Logging (
			ActivityStatus
			,ActivityName
			,ActivityMessage
			)
		SELECT 5
			,@v_ActivityName
			,'Inserted ' + CONVERT(VARCHAR(10), @v_AffectedRows) + ' Rows into LandingTempBOT table for: ' + convert(VARCHAR(10), @AccountingPeriod);

		DELETE
		FROM [FinanceDataContract].[Inbound].[Transaction]
		WHERE [DataSet] = @v_DataSet

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions_Bridge]
		WHERE [ContractType] = @ContractType

		DELETE [FinanceDataContract].[Inbound].[Transaction_ReInsurance_Extensions]
		WHERE [ContractType] = @ContractType

		INSERT INTO [dbo].[Batch] (
			[CreateDate]
			,[DataSet]
			,[LatestBusinesKey]
			)
		VALUES (
			GETDATE()
			,'ReInsuranceExtensions'
			,NULL
			);

		SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();

		INSERT INTO [FinanceDataContract].[Inbound].Transaction_ReInsurance_Extensions_Bridge
		WITH (TABLOCK) (
				[RowHash_Transaction]
				,[RowHash_Transaction_ReInsurance_Extensions]
				,[ContractType]
				,[FK_Batch]
				)
		SELECT DISTINCT [RowHash]
			,[RowHash_Transaction_ReInsurance_Extensions]
			,@ContractType
			,@v_BatchId_Extensions
		FROM #LandingTempBOT

		INSERT INTO [FinanceDataContract].[Inbound].Transaction_ReInsurance_Extensions
		WITH (TABLOCK) (
				[RowHash_Transaction_ReInsurance_Extensions]
				,[RIPolicyType]
				,[ProgrammeCode]
				--,[BeazleyCatCode]
				--,[TransactionDate]		
				,[IsLargeLoss]
				,[ContractType]
				,[FK_Batch]
				)
		SELECT DISTINCT [RowHash_Transaction_ReInsurance_Extensions]
			,[RIPolicyType]
			,[ProgrammeCode]
			--,[BeazleyCatCode]
			--,[TransactionDate]		
			,NULL AS [IsLargeLoss]
			,@ContractType
			,@v_BatchId_Extensions
		FROM #LandingTempBOT

		/*============================================================================================================
			INSERT INTO  Inbound.Transaction FROM FinanceLanding.BP.LandingBusinessplan
===============================================================================================================*/
		INSERT INTO [FinanceDataContract].[Inbound].[Transaction]
		WITH (TABLOCK) (
				[Scenario]
				,[Basis]
				,[Account]
				,[DataSet]
				,[DateOfFact]
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]
				,[DueDate]
				,[TrifocusCode]
				,[Entity]
				,[Location]
				,[YOA]
				,[TypeOfBusiness]
				,[SettlementCCY]
				,[OriginalCCY]
				,[IsToDate]
				,[Value]
				,[ValueOrig]
				,[RowHash]
				,[BusinessProcessCode]
				,[AuditSourceBatchID]
				,[AuditGenerateDateTime]
				,[StatsCode]
				,[FK_Batch]
				,[DeltaType]
				,[FK_Allocation]
				,[AuditCreateDateTime]
				,AuditHost
				,[BoundDate]
				)
		SELECT [Scenario]
			,[Basis]
			,[Account]
			,[DataSet]
			,[DateOfFact]
			,[BusinessKey]
			,[PolicyNumber]
			,[InceptionDate]
			,[ExpiryDate]
			,[BindDate]
			,[DueDate]
			,[TrifocusCode]
			,[Entity]
			,[Location]
			,[YOA]
			,[TypeOfBusiness]
			,[SettlementCCY]
			,[OriginalCCY]
			,[IsToDate]
			,[Value]
			,[ValueOrig]
			,[RowHash]
			,[BusinessProcessCode]
			,[AuditSourceBatchID]
			,[AuditGenerateDateTime]
			,[StatsCode]
			,[FK_Batch]
			,[DeltaType]
			,[FK_Allocation]
			,[AuditCreateDateTime]
			,AuditHost
			,[BoundDate]
		FROM #LandingTempBOT

		--WHERE DateOfFact='2020-12-15 00:00:00.000'
		SELECT @v_AffectedRows = @@ROWCOUNT;

		INSERT @Logging (
			ActivityStatus
			,ActivityName
			,ActivityMessage
			)
		SELECT 5
			,'Agresso.usp_LandingIBWF_BICIRI_ORC_TACTICAL'
			,'Inserted ' + CONVERT(VARCHAR(10), @v_AffectedRows) + ' Rows into Inbound.Transaction table';


	IF EXISTS(SELECT 1 FROM [FinanceDataContract].Inbound.[Transaction] WHERE DataSet = @v_DataSet)
	BEGIN
		INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue] (
			Pk_Batch
			,[Status]
			,RunDescription
			,[DataSet]
			,OriginalName
			,AuditSourceBatchID
			,AsAt
			)
		VALUES (
			@v_BatchId
			,'InBound'
			,NULL
			,@v_DataSet
			,@AccountingPeriod
			,NULL
			,@AsAt
			)
			,(
			@v_BatchId_Extensions
			,'InBound'
			,'ReInsuranceExtensions, the additional attributes to extend functionality of the transaction table.'
			,'ReInsuranceExtensions'
			,@AccountingPeriod
			,NULL
			,@AsAt
			);
	END

		-- LOG THE RESULT WITH SUCCESS
		SELECT @v_ActivityDateTime = GETUTCDATE();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStop
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		IF @Trancount = 0
			COMMIT;

		INSERT @Logging (
			ActivityStatus
			,ActivityName
			,ActivityMessage
			)
		SELECT 2
			,'Agresso.usp_LandingIBWF_BICIRI_ORC_TACTICAL'
			,'BICI_ORC_TACTICAL LandingToInBound Succeeded';

		--Generate logging for success
		EXEC log.usp_LogLanding @Input = @Logging;
	END TRY

	BEGIN CATCH
		IF @Trancount = 0
			ROLLBACK;

		-- LOG THE RESULT WITH ERROR--
		UPDATE [FinanceDataContract].[Inbound].[BatchQueue]
		SET STATUS = 'OutBoundFailed'
		WHERE PK_Batch = @v_BatchId
			AND [Status] = 'InBound'
			AND DataSet = @v_DataSet

		SELECT @v_ActivityDateTime = GETUTCDATE()
			,@v_ActivityLogTag = @v_ActivityLogIdIn
			,@v_ActivityMessage = ERROR_MESSAGE()
			,@v_ActivityErrorCode = ERROR_NUMBER();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusFail
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		THROW;
	END CATCH;
END;
