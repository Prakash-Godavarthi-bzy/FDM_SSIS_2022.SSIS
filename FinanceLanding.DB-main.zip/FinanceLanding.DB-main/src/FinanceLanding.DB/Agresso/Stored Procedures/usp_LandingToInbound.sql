﻿

CREATE PROCEDURE [Agresso].[usp_LandingToInbound]
			 @p_ParentActivityLogId		BIGINT			= NULL
			,@p_ActivityJobId           VARCHAR(50)     = NULL

AS
-- =============================================

-- http://git.bfl.local/Finance/FinanceLanding.DB
-- Unit tests not done since development for Agresso was put on hold

-- Original Author:		Ionela Ciornei <Ionela-Minodora.Ciornei@beazley.com>
-- Create date: 08/05/2020
-- Description:	Loads Agresso data from FinanceLanding to Inbound.Transaction

-- =============================================	
BEGIN

	SET NOCOUNT ON;

	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'AgressoARCashUS';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= @p_ActivityJobId;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT

	DECLARE @v_BatchId                   INT             = NULL;


BEGIN TRY

	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';


	
	/* Log the start of the insert */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = 'Load data into Inbound.Transaction'
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= NULL
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

	-- populate account mapping for ADM.Reserving_data and ADM.TPOutput

	MERGE INTO   [MDS].[AccountMapping] AS Target

	USING

	(SELECT DISTINCT                     
				   [table] = 'AgressoARCashUS'
				   ,L1     = rd.GLAccount
				   ,L2     = rd.GLAccount
				   ,L3     = 'N/A'
				   ,AccountKey = 
				    CASE
						WHEN rd.GLAccount IN ('10100','10260')  THEN 'PC-'
						WHEN rd.GLAccount IN ('30100','30120')  THEN 'BC-'	
						ELSE 'OT-'
					END +
					rd.GLAccount

	FROM           [FinanceLanding].[Agresso].[uviifrs17] rd

	WHERE          rd.entity in ('USBICI','USSYND','USBUSA','USBAIC') 

   ) AS Source ([table],L1,L2,L3,AccountKey)

   ON (Target.[table] = Source.[table] AND Target.L1 = Source.L1 AND Target.L2 = Source.L2 AND Target.L3 = Source.L3 AND  Source.AccountKey IS NOT NULL)

   WHEN MATCHED AND Target.AccountKey <> Source.AccountKey

   THEN UPDATE SET Target.AccountKey = Source.AccountKey

   WHEN NOT MATCHED BY TARGET AND Source.AccountKey IS NOT NULL

   THEN INSERT([table],L1,L2,L3,AccountKey) VALUES(Source.[table],Source.L1,Source.L2,Source.L3,Source.AccountKey);

 

	--populate FK_AccountKey when AccountKey is matching
	UPDATE     am

	SET        FK_AccountKey = an.PK_AccountNames

	FROM       MDS.AccountMapping am

	INNER JOIN MDS.AccountNames   an
	ON         am.AccountKey = an.AccountKey

	WHERE      am.[Table] IN ('AgressoARCashUS')


	--temporary table for the insert (willbe used to calculate RowHash values before pushing data in the IDC transaction table

	DROP TABLE IF EXISTS #TempInboundTransaction;

    /* Insert the new records from ADM sources in the temp table */
             SELECT 
					 Scenario            = 'A'                   
					,Basis               = 'B'  
					,Account             = CAST(ISNULL(am.AccountKey,'XX-XX-XX') AS VARCHAR(10))
					,DataSet			 = 'AgressoARCashUS'
					,DateOfFact          = CAST(rd.DateOfFact AS DATETIME)
					,BusinessKey         = CAST(CONCAT(rd.InvoiceNo,'|' ,CAST(rd.MCTransNo AS VARCHAR(50)),'|',rd.TypeOfBusiness) AS VARCHAR(255))
					,PolicyNumber        = CAST(ISNULL(rd.PolicyNumber,'NOPOLICY') AS VARCHAR(255))
					,InceptionDate       = CAST(ISNULL(rd.InceptionDate,'01-01-1980') AS DATETIME)
					,ExpiryDate          = CAST(ISNULL(rd.ExpiryDate,'01-01-1980') AS DATETIME)
					,BindDate            = CAST(ISNULL(rd.BindDate,'01-01-1980') AS DATETIME)
					,DueDate             = CAST(ISNULL(rd.DueDate,'01-01-1980') AS DATETIME)
					,TrifocusCode        = CAST(ISNULL(rd.TrifocusCode,'UNKNOWN') AS VARCHAR(25))
					,Entity              = CAST(ISNULL(rd.Entity,'NOENTITY') AS VARCHAR(10))
					,[Location]          = CAST('-' AS VARCHAR(50))
					,YOA                 = CAST(ISNULL(rd.YOA, 'NOYOA') AS VARCHAR(5))
					,TypeOfBusiness      = '-'                                         
					,SettlementCCY       = CAST(rd.SettlementCCY AS VARCHAR(3))
					,OriginalCCY         = CAST(rd.OriginalCCY   AS VARCHAR(3))
					,IsToDate            = 'Y'
					,[Value]             = CAST(SUM(ISNULL(rd.ValueSett,0.0000)) AS DECIMAL (19, 4))
					,[ValueOrig]         = CAST(SUM(ISNULL(rd.ValueOrg,0.0000)) AS DECIMAL (19, 4))
					,RowHash             = NULL
					,BusinessProcessCode = 'T1'
					,AuditSourceBatchID  = CAST('-' AS VARCHAR (255))                                                 
					,AuditHost           = CAST(SERVERPROPERTY('MachineName') AS [VARCHAR](255))
					,[StatsCode]         = CAST('-' AS VARCHAR(25))
					,[FK_Batch]          = NULL

			INTO #TempInboundTransaction

			FROM       [Agresso].[uviifrs17] rd

			LEFT JOIN   MDS.AccountMapping am
			ON          rd.GLAccount     = am.l1

			WHERE rd.entity in ('USBICI','USSYND','USBUSA','USBAIC') 
			AND   am.AccountKey IS NOT NULL

			GROUP BY rd.GlAccount, rd.DateOfFact, rd.YOA, rd.InvoiceNo, rd.MCTransNo, rd.TypeOfBusiness, rd.Entity, rd.TrifocusCode, rd.PolicyNumber, rd.InceptionDate,
			         rd.SettlementCCY, rd.OriginalCCY, rd.ExpiryDate, rd.BindDate, rd.DueDate, am.AccountKey

		IF @Trancount = 0 

			BEGIN TRAN;

			INSERT INTO [dbo].[Batch]([CreateDate],[DataSet],[LatestBusinesKey]) 
			VALUES  (GETDATE(),'AgressoARCashUS', NULL);
	
			SELECT @v_BatchId = SCOPE_IDENTITY();

			/* Delete the current lines of the ADM source system from Inbound ... */

			DELETE 
					
			FROM    FinanceDataContract.Inbound.[Transaction]
					
			WHERE   [DataSet] = 'AgressoARCashUS';
			/* We insert the rows from temp table in the system */

			INSERT INTO [FinanceDataContract].[Inbound].[Transaction]
					([Scenario]
					,[Basis]
					,[Account]
					,[DataSet]
					,[DateOfFact]
					,[BusinessKey]
					,[PolicyNumber]
					,[InceptionDate]
					,[ExpiryDate]
					,[BindDate]
					,[DueDate]
					,[TrifocusCode]
					,[Entity]
					,[Location]
					,[YOA]
					,[TypeOfBusiness]
					,[SettlementCCY]
					,[OriginalCCY]
					,[IsToDate]
					,[Value]
					,[ValueOrig]
					,[RowHash]
					,[BusinessProcessCode]
					,[AuditSourceBatchID]
					,[AuditHost]
					,[AuditGenerateDateTime]
					,[StatsCode]
					,[FK_Batch])		
			  
			SELECT  [Scenario]
					,[Basis]
					,[Account]
					,[DataSet]
					,[DateOfFact]
					,[BusinessKey]
					,[PolicyNumber]
					,[InceptionDate]
					,[ExpiryDate]
					,[BindDate]
					,[DueDate]
					,[TrifocusCode]
					,[Entity]
					,[Location]
					,[YOA]
					,[TypeOfBusiness]
					,[SettlementCCY]
					,[OriginalCCY]
					,[IsToDate]
					,[Value]
					,[ValueOrig]
					,RowHash = HASHBYTES('SHA2_512',
										CONCAT(
												 CAST(Scenario AS VARCHAR(2000))		,'§~§'
												,CAST(Basis AS VARCHAR(2000))			,'§~§'
												,CAST(Account AS VARCHAR(2000))			,'§~§'
												,CAST(DataSet AS VARCHAR(2000))			,'§~§'
												,CAST(BusinessKey AS VARCHAR(2000))		,'§~§'
												,CAST(PolicyNumber AS VARCHAR(2000))	,'§~§'
												,CONVERT(VARCHAR(10),InceptionDate,102)	,'§~§'
												,CONVERT(VARCHAR(10),ExpiryDate,102)	,'§~§'
												,CONVERT(VARCHAR(10),BindDate,102)		,'§~§'
												,CONVERT(VARCHAR(10),DueDate,102)		,'§~§'
												,CAST(TrifocusCode AS VARCHAR(2000))	,'§~§'
												,CAST(Entity AS VARCHAR(2000))			,'§~§'
												,CAST(Location AS VARCHAR(2000))		,'§~§'
												,CAST(YOA AS VARCHAR(2000))				,'§~§'
												,CAST(TypeOfBusiness AS VARCHAR(2000))	,'§~§'
												,CAST(StatsCode AS VARCHAR(2000))		,'§~§'
												,CAST(SettlementCCY AS VARCHAR(2000))	,'§~§'
												,CAST(OriginalCCY AS VARCHAR(2000))		,'§~§'
												,CAST(IsToDate AS VARCHAR(2000))		,'§~§'									 
											)
									)
					,[BusinessProcessCode]
					,@v_BatchId 
					,[AuditHost]
					,GETUTCDATE()
					,[StatsCode]
					,@v_BatchId
						   
			FROM    #TempInboundTransaction;

			SELECT   @v_AffectedRows			= @@ROWCOUNT;
	
			/* Add the batch to the queue */
			
			   INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
							( Pk_Batch
							,[Status]
							,[DataSet]
							,RunDescription
							,OriginalName
							)
			   VALUES
							(@v_BatchId
							,'InBound'
							,'AgressoARCashUS'
							,NULL
							,NULL
							);
      
	
			-- LOGIN THE RESULT WITH SUCCESS
			SELECT @v_ActivityDateTime			= GETUTCDATE();

			EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusStop
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

			IF @Trancount = 0 

				COMMIT;

		END TRY

		BEGIN CATCH
	
			-- CANCEL TRAN
			IF @Trancount = 0 AND @@TRANCOUNT <> 0 
				ROLLBACK;
			        
			-- LOGIN THE RESULT WITH ERROR

			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

		    THROW;

		END CATCH;

					
END