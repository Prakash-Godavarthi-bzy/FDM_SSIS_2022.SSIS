﻿CREATE TABLE [Agresso].[AExpensesActualConsol](
	[PK_Expenses] [bigint] IDENTITY(1,1) NOT NULL,
	[AsAt]  [varchar](10) NOT NULL,
	[Scenario] [varchar](10) NOT NULL,
	[TrifocusCode] [varchar](50) NULL, 
	[Entity] [varchar](25) NOT NULL,
	[YOA] [varchar](5) NOT NULL,
	[Currency] [varchar](3) NULL,
	[Measure] [varchar] (50) NULL,
	[Amount] [numeric](38, 4) NULL,
	[AuditSSISExecutionID] [varchar](255) NULL,
	[AuditSSISPackageName] [varchar](255) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditGenerateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL,
	[AuditHost] [nvarchar](255) NOT NULL,
	[SourceFileName] [varchar](255) NULL,
	[Description]  [varchar] (255) NULL

) ON [PRIMARY]
GO

ALTER TABLE [Agresso].[AExpensesActualConsol] ADD  CONSTRAINT [DF_AExpensesActualConsol_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [Agresso].[AExpensesActualConsol] ADD  CONSTRAINT [DF_AExpensesActualConsol_AuditGenerateDateTime]  DEFAULT (getdate()) FOR [AuditGenerateDateTime]
GO

ALTER TABLE [Agresso].[AExpensesActualConsol] ADD  CONSTRAINT [DF_AExpensesActualConsol_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [Agresso].[AExpensesActualConsol] ADD  CONSTRAINT [DF_AExpensesActualConsol_AuditHost]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO