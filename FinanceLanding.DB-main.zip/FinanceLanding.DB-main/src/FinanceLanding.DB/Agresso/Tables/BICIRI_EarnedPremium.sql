﻿CREATE TABLE [Agresso].[BICIRI_EarnedPremium](
	[PK_RIEarnPremID] [bigint] IDENTITY(1,1) NOT NULL,
	[AccountingPeriod] [varchar](10) NOT NULL,
	[Account] [varchar](50) NULL,
	[CCY] [varchar](3) NOT NULL,
	[Entity] [varchar](25) NULL,
	[TriFocusCode] [varchar](25) NULL,
	[YOA] [varchar](5) NULL,
	[PolicyNo] [varchar](25) NULL,
	[PolicyDescription] [varchar](255) NULL,
	[UWProd] [varchar](25) NULL,
	[Amount] [numeric](38, 4) NULL,
	[Description] [varchar](255) NULL,
	[AuditSSISExecutionID] [int] NULL,
	[AuditSSISPackageName] [varchar](255) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL,
	[AuditHost] [nvarchar](255) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [Agresso].[BICIRI_EarnedPremium] ADD  CONSTRAINT [DF_BICIRIEarned_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [Agresso].[BICIRI_EarnedPremium] ADD  CONSTRAINT [DF_BICIRIEarned_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [Agresso].[BICIRI_EarnedPremium] ADD  CONSTRAINT [DF_BICIRIEarned_AuditHost]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO