﻿CREATE PROCEDURE [US].[usp_BICILandingToInboundWorkflow]
AS
BEGIN

-- =============================================

-- created by:			entha.bhargav@beazley.com
-- Do:				Perform Aggregates and Transformations to the fields and move all the landing BICI Data into Inbound.Transaction table


-- Modified by:			entha.bhargav@beazley.com
-- Modification date:	2021-29-12
-- Changes:				Added rules to avoid Multiple Inception,Expiry dates for single policy. Rules applied from BI ODS Instance. Done changes part of JIRA
--https://beazley.atlassian.net/browse/I1B-1926
--https://beazley.atlassian.net/browse/I1B-1703

-- Modified by:			Nikil.Nallamothu@beazley.com
-- Modification date:	2022-13-07
-- Changes:				Used the function to generated Rowhash.


-- =============================================	
	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_AffectedRows					INT;

	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;

	INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
	SELECT 1, '[US].[usp_BICILandingToInboundWorkflow]', 'USBICI  Started';

	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
		SELECT @@TRANCOUNT;
		/*
=============================================================================================
       Create BatchID In landing
==============================================================================================
*/		DECLARE @Basis char(1)	= '-';
		DECLARE @Location char(1) = '-';

		DECLARE @BatchId INT;
		SELECT	@BatchId	= MAX([PK_Batch])
		FROM	dbo.[Batch]
		WHERE	[DataSet] = 'BICI';

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, '[US].[usp_BICILandingToInboundWorkflow]', 'Batch Created , Batch: '+cast (@BatchId as varchar);

				Declare @AsAt varchar(10)
		Select @AsAt =Asat from FinanceDataContract.Inbound.BatchQueue where Pk_Batch=@BatchId;

		DROP TABLE IF EXISTS #Temp_BICILand;

		SELECT	Scenario				=CAST([Scenario] AS NVARCHAR)
					,Account				= CASE WHEN CAST([Account] AS NVARCHAR) IN (10100,10260) THEN 'P-GP-P'
													WHEN CAST([Account] AS NVARCHAR)  IN (30100,30120) THEN 'P-AC-P'
													ELSE CAST([Account] AS NVARCHAR)
												END
					,DataSet				= 'BICI'
					--,DateOfFact				= CAST(case when convert(varchar(6), t.Inception, 112) < cast(AccountingPeriod as varchar) 
					--									then eomonth(convert(date, cast(AccountingPeriod as varchar) + '01'))
					--									else t.Inception
					--								END AS DATETIME2
					--								)
					
					,[BusinessKey]			= CASE WHEN trifocusCode='TRI00081' THEN CAST(		T.[Policyref] + '_' + convert(varchar, T.Inception, 112) + '_' +
																								convert(varchar, case when T.[Expiry] < T.Inception then T.Inception else T.[Expiry] end, 112) 
																						AS NVARCHAR)
													ELSE CAST(t.[Policyref] AS NVARCHAR)
												END
					,PolicyNumber			= CASE WHEN trifocusCode='TRI00081' THEN CAST(T.[Policyref] + '_' + convert(varchar, T.Inception, 112) + '_' +
																						convert(varchar, case when T.[Expiry] < T.Inception then T.Inception else T.[Expiry] end, 112)  AS NVARCHAR)
													ELSE CAST(t.[Policyref] AS NVARCHAR)
												END
					,InceptionDate			= CAST(isnull(s.InceptionDate,
															isnull(p.InceptionDate,
																	isnull(psub.InceptionDate,
																		isnull(pwwb.InceptionDate,
																			isnull(pwwv.InceptionDate,
																				isnull(pwwq.InceptionDate,
																					isnull(pwwz.InceptionDate,
																						isnull(pwwg.InceptionDate,isnull(l.inception,t.inception))))))))
														) AS DATETIME2)
					,ExpiryDate				= CASE WHEN  trifocusCode='TRI00081' AND T.[Expiry] < T.Inception 
													THEN CAST(T.Inception AS DATETIME2)
													ELSE CAST(isnull(s.ExpiryDate,
																		isnull(p.ExpiryDate, 
																		isnull(psub.ExpiryDate,
																		isnull(pwwb.ExpiryDate,
																		isnull(pwwv.ExpiryDate,
																		isnull(pwwq.ExpiryDate,
																		isnull(pwwz.ExpiryDate,
																		isnull(pwwg.ExpiryDate,isnull(l.expiry,t.expiry))))))))
															) AS DATETIME2)
												END
					--,InceptionDate= CAST(T.inception AS DATETIME2)
					--,ExpiryDate= CAST (T.expiry AS datetime2)							
					,BindDate				= CAST('01/01/1980' AS DATETIME2)
					,DueDate				= CAST('01/01/1980' AS DATETIME2)
					,TrifocusCode			= CAST([TrifocusCode] AS NVARCHAR)
					,Entity					= CAST([EntityCode] AS NVARCHAR)
					,YOA					= CASE WHEN trifocusCode='TRI00081' THEN CAST(YEAR(T.inception) AS NVARCHAR)
													ELSE CAST( LTRIM(RTRIM(isnull(pwwz.YOA, isnull(pwwg.yoa,isnull(l.yoa,T.[YOA]))))) AS NVARCHAR)
												END
					,TypeofBusiness			= 'N'
					,SettlementCCY			= CAST([SettlementCCY] AS NVARCHAR)
					,OriginalCCY			= CAST([SettlementCCY] AS NVARCHAR)
					,ISTODate				= 'Y'
					,Value					=[CurAmount] * CASE WHEN CAST([Account] AS NVARCHAR) IN (10100,10260) THEN -1 ELSE 1 END
					,fk_Allocation			= 1
					,AuditSourceBatchID		= @BatchId
					--,[AuditGenerateDateTime] =CAST(GETDATE() AS DATETIME2)
					--,AuditHost				= HOST_NAME()
			
			INTO #Temp_BICILand

			FROM		FinanceLanding.[us].[BICIStageLanding] T 
			left join FinanceLanding.[MDS].[ODSSection]  s 
					on (s.[SectionReference] = t.policyref)
			left join FinanceLanding.[MDS].[ODSPolicy] p 
					on (p.PolicyReference = t.policyref)
			left join FinanceLanding.[MDS].[ODSPolicy] psub 
					on (psub.PolicyReference = substring(t.policyref, 1, case when charindex('', t.policyref ) > 1 then charindex('', t.policyref )-1 else len(t.policyref) end))
			left join FinanceLanding.[MDS].[ODSPolicy] pwwb 
					on (replace(pwwb.PolicyReference, 'WB 0', 'WWB') = t.policyref)
			left join FinanceLanding.[MDS].[ODSPolicy] pwwv 
					on (replace(pwwv.PolicyReference, 'WV 0', 'WWV') = t.policyref)
			left join FinanceLanding.[MDS].[ODSPolicy] pwwq 
					on (replace(pwwq.PolicyReference, 'WQ 0', 'WWQ') = t.policyref)
			left join FinanceLanding.[MDS].[ODSPolicy]pwwz 
					on (replace(pwwz.PolicyReference, 'WZ 0', 'WWZ') = t.policyref)
			left join FinanceLanding.[MDS].[ODSPolicy] pwwg 
					on (replace(pwwg.PolicyReference, 'WG 0', 'WWG') = t.policyref)
			left join (SELECT distinct CASE WHEN bi.trifocusCode='TRI00081' THEN CAST(BI.[Policyref] + '_' + convert(varchar, BI.Inception, 112) + '_' +
																						convert(varchar, case when BI.[Expiry] < BI.Inception then BI.Inception else BI.[Expiry] end, 112)  AS NVARCHAR)
													ELSE CAST(BI.[Policyref] AS NVARCHAR) 
												END PolicyRef
												,MIN(inception) AS Inception
												,MAX(expiry) AS Expiry
												,MIN(YOA) AS YOA
							FROM FinanceLanding.[us].[BICIStageLanding] bi 
							--where policyref like 'VBZ0008'
							GROUP BY CASE WHEN bi.trifocusCode='TRI00081' THEN CAST(BI.[Policyref] + '_' + convert(varchar, BI.Inception, 112) + '_' +
																						convert(varchar, case when BI.[Expiry] < BI.Inception then BI.Inception else BI.[Expiry] end, 112)  AS NVARCHAR)
													ELSE CAST(BI.[Policyref] AS NVARCHAR) 
												END) L 
						ON L.policyref= (CASE WHEN t.trifocusCode='TRI00081' THEN CAST(t.[Policyref] + '_' + convert(varchar, t.Inception, 112) + '_' +
																						convert(varchar, case when t.[Expiry] < t.Inception then t.Inception else t.[Expiry] end, 112)  AS NVARCHAR)
													ELSE CAST(t.[Policyref] AS NVARCHAR) 
												END) 
												;		

				SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, '[US].[usp_BICILandingToInboundWorkflow]', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into TempBICILand table';

		/*

=========================================================================================================
Insert from Landing to Inbound.Transaction Table 
=========================================================================================================
*/

--DROP TABLE IF EXISTS #BICICTE;
--DROP TABLE IF EXISTS #Inbound;

--select top 100 *
--from #Temp_BICILand
--where PolicyNumber='V2571A180101'

--select top 100 *
--from  #BICICTE
--where PolicyNumber='V2571A180101'


WITH LANDING AS (
		SELECT	Scenario
				,Account
				,DataSet
				--,DateOfFact
				,BusinessKey
				,PolicyNumber
				,InceptionDate
				,ExpiryDate
				--,InceptionDate
				--,ExpiryDate
				,BindDate
				,DueDate
				,TrifocusCode
				,Entity
				,YOA
				,TypeofBusiness
				,SettlementCCY
				,OriginalCCY
				,ISTODate
				,sum([Value]) as [value]
				,fk_Allocation
				,AuditSourceBatchID
				,[AuditGenerateDateTime] =CAST(GETDATE() AS DATETIME2)
				,AuditHost				= HOST_NAME()
			--	into #BICICTE
		FROM #Temp_BICILand tl
		--left join (SELECT distinct CASE WHEN bi.trifocusCode='TRI00081' THEN CAST(BI.[Policyref] + '_' + convert(varchar, BI.Inception, 112) + '_' +
		--																				convert(varchar, case when BI.[Expiry] < BI.Inception then BI.Inception else BI.[Expiry] end, 112)  AS NVARCHAR)
		--											ELSE CAST(BI.[Policyref] AS NVARCHAR) 
		--										END PolicyRef
		--										,MIN(inception) AS Inception
		--										,MAX(expiry) AS Expiry
		--					FROM FinanceLanding.[us].[BICIStageLanding] bi --where policyref like 'VBZ0008'
		--					GROUP BY CASE WHEN bi.trifocusCode='TRI00081' THEN CAST(BI.[Policyref] + '_' + convert(varchar, BI.Inception, 112) + '_' +
		--																				convert(varchar, case when BI.[Expiry] < BI.Inception then BI.Inception else BI.[Expiry] end, 112)  AS NVARCHAR)
		--											ELSE CAST(BI.[Policyref] AS NVARCHAR) 
		--										END) L ON L.policyref=		tl.PolicyNumber
			--WHERE PolicyNumber IN ('C1B6D6200501-01')
		GROUP BY Scenario
				,Account
				,DataSet
				--,DateOfFact
				,BusinessKey
				,PolicyNumber
				--,l.Inception 
				--,l.Expiry
				,InceptionDate
				,ExpiryDate
				,BindDate
				,DueDate
				,TrifocusCode
				,Entity
				,YOA
				,TypeofBusiness
				,SettlementCCY
				,OriginalCCY
				,ISTODate,fk_Allocation
				,AuditSourceBatchID
				--,CAST(GETDATE() AS DATETIME2)
				--,HOST_NAME()
		)
		INSERT	[FinanceDataContract].[Inbound].[Transaction] WITH(TABLOCK) ([Scenario], [Account], DataSet, [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate]
															,[ExpiryDate], [BindDate], [DueDate], [TrifocusCode], [Entity], [YOA], [TypeOfBusiness]
															,[SettlementCCY], [OriginalCCY], [IsToDate], [Value], [FK_Allocation], [AuditSourceBatchID]
															,[AuditGenerateDateTime], [AuditHost], RowHash)
		SELECT	DISTINCT Landing.Scenario
				,Landing.Account
				,Landing.DataSet
				--,Landing.DateOfFact
				,DateOfFact =CAST(@AsAt+'01' as date)
				--,DateOfFact				= CAST(case when convert(varchar(6), B.Inception, 112) < cast(B.AccountingPeriod as varchar) 
				--										then eomonth(convert(date, cast(B.AccountingPeriod as varchar) + '01'))
				--										else B.Inception
				--									END 
				--									AS DATETIME2
				--						)
				,isnull(cast(Landing.Account as varchar), '-') + '|' +
				isnull(Landing.PolicyNumber, '-') + '|' +
				isnull(Landing.YOA, '-') + '|' +
				isnull(Landing.Entity, '-') + '|' +
				isnull(Landing.OriginalCCY, '-') + '|' +
				isnull(Landing.TrifocusCode, '-') as BusinessKey
				,Landing.PolicyNumber
				,Landing.InceptionDate
				,Landing.ExpiryDate
				,Landing.BindDate
				,Landing.DueDate
				,Landing.TrifocusCode
				,Landing.Entity
				,Landing.YOA
				,Landing.TypeofBusiness
				,Landing.SettlementCCY
				,Landing.OriginalCCY
				,Landing.ISTODate
				,Landing.[Value]
				,Landing.fk_Allocation
				,Landing.AuditSourceBatchID
				,Landing.AuditGenerateDateTime
				,Landing.AuditHost
				,RowHash = dbo.fn_RowHashForTransactions
						(
						'T'							-- <@RowHashType, char(1),>
						,Scenario					--,<@Scenario, nvarchar(2000),>
						,[Account]					--,<@Account, nvarchar(2000),>
						,Dataset					--,<@DataSet, nvarchar(2000),>
						--,[BusinessKey]				--,<@BusinessKey, nvarchar(2000),>
						,isnull(cast(Landing.Account as varchar), '-') + '|' +
								isnull(Landing.PolicyNumber, '-') + '|' +
								isnull(Landing.YOA, '-') + '|' +
								isnull(Landing.Entity, '-') + '|' +
								isnull(Landing.OriginalCCY, '-') + '|' +
								isnull(Landing.TrifocusCode, '-')
						,[PolicyNumber]				--,<@PolicyNumber, nvarchar(2000),>
						,[InceptionDate]			--,<@InceptionDate, date,>
						,[ExpiryDate]				--,<@ExpiryDate, date,>
						,BindDate					--,<@BindDate, date,>
						,DueDate					--,<@DueDate, date,>
						,[TrifocusCode]				--,<@TrifocusCode, nvarchar(2000),>
						,[Entity]					--,<@Entity, nvarchar(2000),>
						,[YOA]						--,<@YOA, nvarchar(2000),>
						,TypeOfBusiness				--,<@TypeOfBusiness, nvarchar(2000),>
						,null						--,<@StatsCode, nvarchar(2000),>
						,[SettlementCCY]			--,<@SettlementCCY, nvarchar(2000),>
						,[SettlementCCY]			--,<@OriginalCCY, nvarchar(2000),>
						,IsToDate					--,<@IsToDate, nvarchar(2000),>
						,@Basis						--,<@Basis, nvarchar(2000),>
						,@Location					--,<@Location, nvarchar(2000),>
						,null						--,<@BusinessProcessCode, nvarchar(2000),>
						,null						--,<@BoundDate, date,>
						,null						--,<@extensions,nvarchar,>
					)
													--into	#Inbound
		FROM	Landing Landing
		--JOIN (SELECT DISTINCT CASE WHEN trifocusCode='TRI00081' THEN CAST(BICI.[Policyref] + '_' + convert(varchar, BICI.Inception, 112) + '_' +
		--																				convert(varchar, case when BICI.[Expiry] < BICI.Inception then BICI.Inception else BICI.[Expiry] end, 112)  AS NVARCHAR)
		--											ELSE CAST(BICI.[Policyref] AS NVARCHAR) 
		--										END PolicyRef
		--										,Max(bici.inception) Inception
		--										,Max(BICI.AccountingPeriod)  AccountingPeriod 
		--		FROM FinanceLanding.US.BICIStageLanding BICI
		--		GROUP BY CASE WHEN trifocusCode='TRI00081' THEN CAST(BICI.[Policyref] + '_' + convert(varchar, BICI.Inception, 112) + '_' +
		--																				convert(varchar, case when BICI.[Expiry] < BICI.Inception then BICI.Inception else BICI.[Expiry] end, 112)  AS NVARCHAR)
		--											ELSE CAST(BICI.[Policyref] AS NVARCHAR) 
		--										END
		--	) B ON Landing.PolicyNumber=B.policyref
		--where PolicyNumber IN ('C1B6D6200501-01')--,'C1B6D6200501-02','C1B6D6200501-03') 
		;
		

		SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, '[US].[usp_BICILandingToInboundWorkflow]', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into Inbound.Transaction table , Batch: '+cast (@BatchId as varchar);

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT	5
				,	'[US].[usp_BICILandingToInboundWorkflow]'
				,'Insert from BICIStageLanding to Inbound.Transaction Table ';

		/*
=============================================================================================
	LogInbound Aggregate Value
==============================================================================================
*/

		EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_InboundBICI] @BatchId;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'US.usp_BICILandingToInboundWorkflow', 'LogInbound Aggregate Value';

		/*
=============================================================================================
       QueueBatchID in DataContract
==============================================================================================
*/

		UPDATE	[FinanceDataContract].[Inbound].[BatchQueue]
		SET		Status = 'InBound'
		WHERE	Status = 'FinanceLanding'
			AND DataSet = 'BICI'
			AND Pk_Batch = @BatchId;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, '[US].[usp_BICILandingToInboundWorkflow]', ' QueueBatchID in DataContract';

		IF @Trancount = 0 COMMIT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, '[US].[usp_BICILandingToInboundWorkflow]', 'BICI Inbound Workflow succeeded for Batch: '+cast (@BatchId as varchar);

		--Generate logging for success
		EXEC log.usp_LogLanding @Input = @Logging;

	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;

		--Generate logging for error (outside tran)
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 4, '[US].[usp_BICILandingToInboundWorkflow]', ERROR_MESSAGE();
		EXEC log.usp_LogLanding @Input = @Logging;

		THROW;
	END CATCH;
END;