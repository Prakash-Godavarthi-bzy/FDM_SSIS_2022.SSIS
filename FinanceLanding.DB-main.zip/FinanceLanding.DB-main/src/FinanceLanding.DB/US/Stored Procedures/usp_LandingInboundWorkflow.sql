﻿CREATE PROCEDURE [US].[usp_LandingInboundWorkflow]
AS
BEGIN

-- =============================================

-- created by:		entha.bhargav@beazley.com
-- Do:				Perform Aggregates and Transformations to the fields and move all the landing Uspremium Data (FDM) into Inbound.Transaction table


-- Modified by:			entha.bhargav@beazley.com
-- Modification date:	2021-29-12
-- Changes:				Added rules to avoid Multiple Inception,Expiry dates and YOA for single policy. Rules applied from BI ODS Instance. Done changes part of JIRA
--https://beazley.atlassian.net/browse/I1B-1658
--https://beazley.atlassian.net/browse/I1B-1788

-- Modified by:			Nikil.Nallamothu@beazley.com
-- Modification date:	2022-13-07
-- Changes:				Used the function to generated Rowhash.

-- =============================================	
	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_AffectedRows					INT;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;

	INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
	SELECT 1, '[us].[usp_LandingInboundWorkflow]', 'USPremium  Started';

	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
		SELECT @@TRANCOUNT;
		/*
=============================================================================================
       Create BatchID In landing
==============================================================================================
*/		DECLARE @Basis char(1)	= '-';
		DECLARE @Location char(1) = '-';

		DECLARE @BatchId INT;
		SELECT	@BatchId	= MAX([PK_Batch])
		FROM	dbo.[Batch]
		WHERE	[DataSet] = 'USPremium';

		Declare @AsAt varchar(10)
        Select @AsAt =Asat from FinanceDataContract.Inbound.BatchQueue where Pk_Batch=@BatchId;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, '[us].[usp_LandingInboundWorkflow]', 'Batch Created';


		DROP TABLE IF EXISTS #Temp_UsPremiumLand;
		SELECT	Scenario				=CASE WHEN CAST([Scenario.Scenario.Scenario] AS NVARCHAR) = 'Actual' THEN 'A' ELSE CAST([Scenario.Scenario.Scenario] AS NVARCHAR)END
					,Account				= CASE WHEN CAST([Account.AccountCode.AccountCode] AS NVARCHAR) = 10100 THEN 'P-GP-P'
													WHEN CAST([Account.AccountCode.AccountCode] AS NVARCHAR) = 30100 THEN 'P-AC-P'
													WHEN       CAST([Account.AccountCode.AccountCode] AS NVARCHAR)=30512 THEN 'P-IC-P'
													ELSE CAST([Account.AccountCode.AccountCode] AS NVARCHAR)
												END
					,DataSet				= 'USPremium'
					--,DateOfFact				= CAST(case when convert(varchar(6), t.Inception, 112) < cast(AccountingPeriod as varchar) 
					--									then eomonth(convert(date, cast(AccountingPeriod as varchar) + '01'))
					--									else t.Inception
					--								END AS DATETIME2
					--								) --CAST([Earnings.InceptionDate.InceptionDate] AS DATETIME2)
					
					,[BusinessKey]			= LTRIM(RTRIM(CAST([PolicySection.SectionReference.SectionReference] AS NVARCHAR)))
					,PolicyNumber			= LTRIM(RTRIM(CAST([PolicySection.SectionReference.SectionReference] AS NVARCHAR)))
					,InceptionDate			= CAST(isnull(s.InceptionDate,
															isnull(p.InceptionDate,
																	isnull(psub.InceptionDate,
																		isnull(pwwb.InceptionDate,
																			isnull(pwwv.InceptionDate,
																				isnull(pwwq.InceptionDate,
																					isnull(pwwz.InceptionDate,
																						isnull(pwwg.InceptionDate,isnull(bl.inception,[Earnings.InceptionDate.InceptionDate]))))))))
														) AS DATETIME2)
					,ExpiryDate				= CAST(isnull(s.ExpiryDate,
																		isnull(p.ExpiryDate, 
																		isnull(psub.ExpiryDate,
																		isnull(pwwb.ExpiryDate,
																		isnull(pwwv.ExpiryDate,
																		isnull(pwwq.ExpiryDate,
																		isnull(pwwz.ExpiryDate,
																		isnull(pwwg.ExpiryDate,isnull(bl.expiry,[Earnings.ExpiryDate.ExpiryDate]))))))))
															) AS DATETIME2)
												
					,BindDate				= CAST('01/01/1980' AS DATETIME2)
					,DueDate				= CAST('01/01/1980' AS DATETIME2)
					,TrifocusCode			= LTRIM(RTRIM(CAST([TriFocus.TrifocusCode.TrifocusCode] AS NVARCHAR)))
					,Entity					= LTRIM(RTRIM(CAST([Entity.EntityCode.EntityCode] AS NVARCHAR)))
					,YOA					=  CAST( LTRIM(RTRIM(isnull(pwwz.YOA, isnull(pwwg.yoa,isnull(bl.yoa,T.[YOA.YOA.YOA]))))) AS NVARCHAR)
					,TypeofBusiness			= 'N'
					,SettlementCCY			= LTRIM(RTRIM(CAST([CurTransactionCurrency.TranCurr.TranCurr] AS NVARCHAR)))
					,OriginalCCY			= LTRIM(RTRIM(CAST([CurTransactionCurrency.TranCurr.TranCurr] AS NVARCHAR)))
					,ISTODate				= 'Y'
					,Value					=[Measures.CurAmount] * CASE WHEN CAST([Account.AccountCode.AccountCode] AS NVARCHAR) = 10100 THEN -1 ELSE 1 END
					,fk_Allocation			= 1
					,AuditSourceBatchID		= @BatchId
					
			INTO	#Temp_UsPremiumLand
			FROM	FinanceLanding.[us].[USPremium] T 
			left join FinanceLanding.[MDS].[ODSSection]  s 
					on (s.[SectionReference] = t.[PolicySection.SectionReference.SectionReference])
			left join FinanceLanding.[MDS].[ODSPolicy] p 
					on (p.PolicyReference = t.[PolicySection.SectionReference.SectionReference])
			left join FinanceLanding.[MDS].[ODSPolicy] psub 
					on (psub.PolicyReference = substring(t.[PolicySection.SectionReference.SectionReference], 1, case when charindex('', t.[PolicySection.SectionReference.SectionReference] ) > 1 then charindex('', t.[PolicySection.SectionReference.SectionReference] )-1 else len(t.[PolicySection.SectionReference.SectionReference]) end))
			left join FinanceLanding.[MDS].[ODSPolicy] pwwb 
					on (replace(pwwb.PolicyReference, 'WB 0', 'WWB') = t.[PolicySection.SectionReference.SectionReference])
			left join FinanceLanding.[MDS].[ODSPolicy] pwwv 
					on (replace(pwwv.PolicyReference, 'WV 0', 'WWV') = t.[PolicySection.SectionReference.SectionReference])
			left join FinanceLanding.[MDS].[ODSPolicy] pwwq 
					on (replace(pwwq.PolicyReference, 'WQ 0', 'WWQ') = t.[PolicySection.SectionReference.SectionReference])
			left join FinanceLanding.[MDS].[ODSPolicy]pwwz 
					on (replace(pwwz.PolicyReference, 'WZ 0', 'WWZ') = t.[PolicySection.SectionReference.SectionReference])
			left join FinanceLanding.[MDS].[ODSPolicy] pwwg 
					on (replace(pwwg.PolicyReference, 'WG 0', 'WWG') = t.[PolicySection.SectionReference.SectionReference])
			left join (SELECT distinct [PolicySection.SectionReference.SectionReference] Policyref,MIN([Earnings.InceptionDate.InceptionDate]) Inception,MAX([Earnings.ExpiryDate.ExpiryDate]) Expiry,min([YOA.YOA.YOA]) as yoa
						FROM FinanceLanding.[us].[USPremium]  
						GROUP BY [PolicySection.SectionReference.SectionReference]) bl 
					ON BL.policyref=T.[PolicySection.SectionReference.SectionReference];

		SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, '[us].[usp_LandingInboundWorkflow]', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into #Temp_UsPremiumLand table';

		/*

=========================================================================================================
Insert from Landing to Inbound.Transaction Table 
=========================================================================================================
*/

		WITH LANDING AS (
		SELECT	Scenario
				,Account
				,DataSet
				--,DateOfFact
				,BusinessKey
				,PolicyNumber
				,InceptionDate
				,ExpiryDate
				,BindDate
				,DueDate
				,TrifocusCode
				,Entity
				,YOA
				,TypeofBusiness
				,SettlementCCY
				,OriginalCCY
				,ISTODate
				,sum([Value]) as [value]
				,fk_Allocation
				,AuditSourceBatchID
				,[AuditGenerateDateTime] =CAST(GETDATE() AS DATETIME2)
				,AuditHost				= HOST_NAME()
				--into #CTELand
		FROM #Temp_UsPremiumLand
		--WHERE PolicyNumber IN ('C1B6D6200501-01')
		GROUP BY Scenario
				,Account
				,DataSet
				--,DateOfFact
				,BusinessKey
				,PolicyNumber
				,InceptionDate
				,ExpiryDate
				,BindDate
				,DueDate
				,TrifocusCode
				,Entity
				,YOA
				,TypeofBusiness
				,SettlementCCY
				,OriginalCCY
				,ISTODate,fk_Allocation
				,AuditSourceBatchID
				--,CAST(GETDATE() AS DATETIME2)
				--,HOST_NAME()
		)
		INSERT	[FinanceDataContract].[Inbound].[Transaction] WITH(TABLOCK) ([Scenario], [Account], DataSet, [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate]
															,[ExpiryDate], [BindDate], [DueDate], [TrifocusCode], [Entity], [YOA], [TypeOfBusiness]
															,[SettlementCCY], [OriginalCCY], [IsToDate], [Value], [FK_Allocation], [AuditSourceBatchID]
															,[AuditGenerateDateTime], [AuditHost], RowHash)
		SELECT	DISTINCT Landing.Scenario
				,Landing.Account
				,Landing.DataSet
				--,Landing.DateOfFact
				,DateOfFact =CAST(@AsAt+'01' as date)
								,isnull(cast(Landing.Account as varchar), '-') + '|' +
				isnull(Landing.PolicyNumber, '-') + '|' +
				isnull(Landing.YOA, '-') + '|' +
				isnull(Landing.Entity, '-') + '|' +
				isnull(Landing.OriginalCCY, '-') + '|' +
				isnull(Landing.TrifocusCode, '-') as BusinessKey
				,Landing.PolicyNumber
				,Landing.InceptionDate
				,Landing.ExpiryDate
				,Landing.BindDate
				,Landing.DueDate
				,Landing.TrifocusCode
				,Landing.Entity
				,Landing.YOA
				,Landing.TypeofBusiness
				,Landing.SettlementCCY
				,Landing.OriginalCCY
				,Landing.ISTODate
				,Landing.[Value]
				,Landing.fk_Allocation
				,Landing.AuditSourceBatchID
				,Landing.AuditGenerateDateTime
				,Landing.AuditHost
				,RowHash = dbo.fn_RowHashForTransactions
						(
						'T'							-- <@RowHashType, char(1),>
						,Scenario					--,<@Scenario, nvarchar(2000),>
						,[Account]					--,<@Account, nvarchar(2000),>
						,Dataset					--,<@DataSet, nvarchar(2000),>
						--,[BusinessKey]				--,<@BusinessKey, nvarchar(2000),>
						,isnull(cast(Landing.Account as varchar), '-') + '|' +
								isnull(Landing.PolicyNumber, '-') + '|' +
								isnull(Landing.YOA, '-') + '|' +
								isnull(Landing.Entity, '-') + '|' +
								isnull(Landing.OriginalCCY, '-') + '|' +
								isnull(Landing.TrifocusCode, '-')
						,[PolicyNumber]				--,<@PolicyNumber, nvarchar(2000),>
						,[InceptionDate]			--,<@InceptionDate, date,>
						,[ExpiryDate]				--,<@ExpiryDate, date,>
						,BindDate					--,<@BindDate, date,>
						,DueDate					--,<@DueDate, date,>
						,[TrifocusCode]				--,<@TrifocusCode, nvarchar(2000),>
						,[Entity]					--,<@Entity, nvarchar(2000),>
						,[YOA]						--,<@YOA, nvarchar(2000),>
						,TypeOfBusiness				--,<@TypeOfBusiness, nvarchar(2000),>
						,null					--,<@StatsCode, nvarchar(2000),>
						,[SettlementCCY]			--,<@SettlementCCY, nvarchar(2000),>
						,[SettlementCCY]			--,<@OriginalCCY, nvarchar(2000),>
						,IsToDate					--,<@IsToDate, nvarchar(2000),>
						,@Basis						--,<@Basis, nvarchar(2000),>
						,@Location					--,<@Location, nvarchar(2000),>
						,null						--,<@BusinessProcessCode, nvarchar(2000),>
						,null						--,<@BoundDate, date,>
						,null						--,<@extensions,nvarchar,>
					)
														--into #landigncte
		FROM	Landing Landing
		--JOIN (SELECT distinct [PolicySection.SectionReference.SectionReference] Policyref,Max([Earnings.InceptionDate.InceptionDate]) Inception
			--		,MAX([AccountingPeriod.AccountingPeriod.AccountingPeriod]) AccountingPeriod
			--			FROM FinanceLanding.[us].[USPremium]  
			--			GROUP BY [PolicySection.SectionReference.SectionReference]
			--) B ON Landing.PolicyNumber=B.policyref;


		SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, '[us].[usp_LandingInboundWorkflow]', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into Inbound.Transaction table';

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT	5
				,	'[us].[usp_LandingInboundWorkflow]'
				,'Insert from Landing to Inbound.Transaction Table ';

		/*
=============================================================================================
	LogInbound Aggregate Value
==============================================================================================
*/

		EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_InboundFDM] @BatchId;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, '[us].[usp_LandingInboundWorkflow]', 'LogInbound Aggregate Value';

		/*
=============================================================================================
       QueueBatchID in DataContract
==============================================================================================
*/

		UPDATE	[FinanceDataContract].[Inbound].[BatchQueue]
		SET		Status = 'InBound'
		WHERE	Status = 'FinanceLanding'
			AND DataSet = 'USPremium'
			AND Pk_Batch = @BatchId;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, '[us].[usp_LandingInboundWorkflow]', ' QueueBatchID in DataContract';

		IF @Trancount = 0 COMMIT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, '[us].[usp_LandingInboundWorkflow]', 'USPremium succeeded';

		--Generate logging for success
		EXEC log.usp_LogLanding @Input = @Logging;

	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;

		--Generate logging for error (outside tran)
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 4, '[us].[usp_LandingInboundWorkflow]', ERROR_MESSAGE();
		EXEC log.usp_LogLanding @Input = @Logging;

		THROW;
	END CATCH;
END;
