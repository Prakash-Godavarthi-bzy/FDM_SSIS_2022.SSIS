﻿CREATE TABLE [us].[USPremium](
       [AccountingPeriod.AccountingPeriod.AccountingPeriod] [varchar](50) NULL,
       [YOA.YOA.YOA] [varchar](50) NULL,
       [Location.LocationCode.LocationCode] [varchar](50) NULL,
       [Project.ProjectCode.ProjectCode] [varchar](50) NULL,
       [CurTransactionCurrency.TranCurr.TranCurr] [varchar](50) NULL,
       [TriFocus.TrifocusCode.TrifocusCode] [varchar](50) NULL,
       [Entity.EntityCode.EntityCode] [varchar](50) NULL,
       [Account.AccountCode.AccountCode] [varchar](50) NULL,
       [Process.ProcessCode.ProcessCode] [varchar](50) NULL,
       [Scenario.Scenario.Scenario] [varchar](250) NULL,
       [Client.Client.Client] [varchar](50) NULL,
       [Product.ProductCode.ProductCode] [varchar](50) NULL,
       [TargetEntity.TargetEntityCode.TargetEntityCode] [varchar](50) NULL,
       [TargetPeriod.TargetPeriod.TargetPeriod] [varchar](50) NULL,
       [Measures.CurAmount] NUMERIC(19,4) NULL,
       [Measures.Amount] VARCHAR(50) NULL,
       [Measures.Value2] VARCHAR(50) NULL,
       [Measures.Value3] VARCHAR(50) NULL,
       [Measures.ConvertedAmount] VARCHAR(50) NULL,
       [Module] [varchar](50) NULL,
       [OutputName] [varchar](50) NULL, 
    [PolicySection.SectionReference.SectionReference] VARCHAR(50) NULL, 
    [Earnings.InceptionDate.InceptionDate] VARCHAR(50) NULL, 
    [Earnings.ExpiryDate.ExpiryDate] VARCHAR(50) NULL ,
	[MOPCode] VARCHAR(5) NULL

) ;

   