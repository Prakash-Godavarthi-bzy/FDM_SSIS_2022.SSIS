﻿CREATE PROCEDURE [eb].[usp_LandingInboundWorkflow_BaseLoad]
AS
    BEGIN
        DECLARE @Trancount INT= @@Trancount;
        BEGIN TRY
            IF @Trancount = 0
            BEGIN TRAN;

/*
=============================================================================================
	Create BatchID In landing
==============================================================================================
*/

            DECLARE @BatchId INT;
             SELECT  @BatchId= MAX([PK_Batch])
             FROM dbo.[Batch]
             WHERE [DataSet] = 'Eurobase'
/*

=========================================================================================================
Insert from Landing to Inbound.Transaction Table 
=========================================================================================================
*/

            DROP TABLE IF EXISTS #temp;
            CREATE TABLE #temp
            ([policyref]             [VARCHAR](255) NOT NULL, 
             [inception]             [DATETIME2](7) NULL, 
             [expiry]                [DATETIME2](7) NULL,  
             [trifocusCode]          [NVARCHAR](255) NULL, 
             [yoa]                   [NVARCHAR](5) NULL, 
             [TypeofBusiness]        [VARCHAR](1) NOT NULL, 
             [stats]                 [VARCHAR](25) NULL, 
             [LEVEL3]                [VARCHAR](6) NOT NULL, 
             [Scenario]              [VARCHAR](2) NOT NULL, 
             [EntityCode]            [NVARCHAR](10) NULL, 
             [SettlementCCY]         [VARCHAR](3) NULL, 
             [AcquisitionCosts]      [NUMERIC](19, 4) NULL, 
             [Gross]                 [NUMERIC](19, 4) NULL, 
             [AuditSourceBatchID]    [INT] NOT NULL, 
             [auditcreateddatetime]  [DATETIME2](7) NULL, 
             [AuditGenerateDateTime] [DATETIME2](7) NULL, 
             [auitusercreate]        [NVARCHAR](255) NULL, 
             [AuditHost]             [NVARCHAR](255) NULL
            );
            INSERT INTO #temp
                   SELECT v.[policyref], 
                          v.inception, 
                          v.expiry,  
                          V.[trifocusCode], 
                          v.yoa,
                          CASE
                              WHEN ISNULL(V.[Originalpolicyref], '') = ''
                                   OR V.[Originalpolicyref] = V.[Originalpolicyref]
                              THEN 'N'
                              ELSE 'R'
                          END 'TypeofBusiness', 
                          v.[stats],
                          CASE
                              WHEN V.MOP IN('B', 'L')
                                   OR V.IsKoreanTrifocus = 1
                              THEN 'Binder'
                              ELSE 'Policy'
                          END 'LEVEL3', 
                          'A' Scenario, 
                          v.EntityCode AS EntityCode, 
                          v.SettlementCCY SettlementCCY, 
                       CAST(ROUND(Deductions,2) AS NUMERIC(19, 4)) AS 'AcquisitionCosts', 
                        CAST(ROUND(Deductions,2) AS NUMERIC(19, 4)) +  CAST(ROUND(Premium ,2) AS NUMERIC(19, 4)) 'Gross',
                          @BatchId AS AuditSourceBatchID, 
                          v.[auditcreateddatetime], 
                          v.[auditcreateddatetime] AS [AuditGenerateDateTime], 
                          v.[auitusercreate], 
                          v.[AuditHost]
                   FROM [eb].[StageEPIBaseLoad] V
				    WHERE MOP IS NOT NULL
					
/*
=========================================================================================================
load AcquisitionCosts from landing to DataContract
=========================================================================================================
*/

          INSERT INTO [FinanceDataContract].[Inbound].[Transaction]
            ([Scenario], 
             [Account], 
             DataSet, 
             [DateOfFact], 
             [BusinessKey], 
             [PolicyNumber], 
             [InceptionDate], 
             [ExpiryDate], 
             [BindDate], 
             [DueDate], 
             [TrifocusCode],
			 StatsCode, 
             [Entity], 
             [YOA], 
             [TypeOfBusiness], 
             [SettlementCCY], 
             [OriginalCCY], 
             [IsToDate], 
             [Value], 
             [AuditSourceBatchID], 
             [AuditCreateDateTime], 
             [AuditGenerateDateTime], 
             [AuditUserCreate], 
             [AuditHost]
            )
                   SELECT Scenario,
                          CASE
                              WHEN [LEVEL3] = 'Policy'
                              THEN 'P-AC-P'
                              WHEN [LEVEL3] = 'Binder'
                              THEN 'P-AC-B'
                          END AS Account, 
                          'Eurobase' AS DataSet, 
                          CAST(inception AS DATETIME2) AS DateOfFact, 
                          policyref AS BusinessKey, 
                          policyref AS PoliceyNumber, 
                          CAST(inception AS DATETIME2) AS InceptionDate, 
                          CAST(expiry AS DATETIME2) AS ExpiryDate, 
                          CAST('01/01/1980' AS DATETIME2) AS BindDate, 
                          CAST('01/01/1980' AS DATETIME2) AS DueDate, 
                          [TrifocusCode], 
						  [stats],
                          EntityCode AS Entity, 
                          yoa AS YOA, 
                          TypeofBusiness TypeofBusiness, 
                          [SettlementCCY] AS [SettlementCCY], 
                          [SettlementCCY] AS [OriginalCCY], 
                          'Y' ISTODate, 
                          AcquisitionCosts AS [Value], 
                          AuditSourceBatchID, 
                          [AuditCreatedDatetime], 
                          [AuditGenerateDateTime], 
                          [auitusercreate], 
                          [AuditHost]
                   FROM #temp
                 

/*
=========================================================================================================
load Gross from landing to DataContract
=========================================================================================================
*/

            INSERT INTO [FinanceDataContract].[Inbound].[Transaction]
            ([Scenario], 
             [Account], 
             DataSet, 
             [DateOfFact], 
             [BusinessKey], 
             [PolicyNumber], 
             [InceptionDate], 
             [ExpiryDate], 
             [BindDate], 
             [DueDate], 
             [TrifocusCode], 
			 StatsCode,
             [Entity], 
             [YOA], 
             [TypeOfBusiness], 
             [SettlementCCY], 
             [OriginalCCY], 
             [IsToDate], 
             [Value], 
             [AuditSourceBatchID], 
             [AuditCreateDateTime], 
             [AuditGenerateDateTime], 
             [AuditUserCreate], 
             [AuditHost]
            )
                   SELECT Scenario,
                          CASE
                              WHEN [LEVEL3] = 'Policy'
                              THEN 'P-GP-P'
                              WHEN [LEVEL3] = 'Binder'
                              THEN 'P-GP-B'
                          END AS ACCOUNT, 
                          'Eurobase' AS DataSet, 
                          CAST(GETDATE() AS DATETIME2) AS DateOfFact, 
                          policyref AS BusinessKey, 
                          policyref AS PoliceyNumber, 
                          CAST(inception AS DATETIME2) AS InceptionDate, 
                          CAST(expiry AS DATETIME2) AS ExpiryDate, 
                          CAST('01/01/1980' AS DATETIME2) AS BindDate, 
                          CAST('01/01/1980' AS DATETIME2) AS DueDate, 
                          [TrifocusCode], 
						  [stats],
                          EntityCode AS Entity, 
                          yoa AS YOA, 
                          TypeofBusiness, 
                          [SettlementCCY] AS [SettlementCCY], 
                          [SettlementCCY] AS [OriginalCCY], ---check with Dave,
                          'Y' ISTODate, 
                          Gross AS [Value], 
                          AuditSourceBatchID, 
                          [AuditCreateddatetime], 
                          [AuditGenerateDateTime], 
                          [auitusercreate], 
                          [AuditHost]
                   FROM #temp
                  

/*
=============================================================================================
	LogInbound Aggregate Value
==============================================================================================
*/
            --EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_Inbound] @BatchId



/*



=============================================================================================
	QueueBatchID in DataContract
==============================================================================================
*/
            INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
            ([Pk_Batch], 
             [Status],
			 DataSet
            )
            VALUES
            (@BatchId, 
             'Pending',
			 'Eurobase'
            );
            IF @Trancount = 0
                COMMIT;
        END TRY
        BEGIN CATCH
            IF @Trancount = 0
                ROLLBACK;
            THROW;
        END CATCH;
    END;