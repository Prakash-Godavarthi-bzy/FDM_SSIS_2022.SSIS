﻿CREATE PROCEDURE [Eb].[usp_LandingInboundWorkflow_Eurobase] --'2018-11-01'
	(
	--@p_AccountingPeriod			INT
	@nextprd DATE --='2018-11-01',
	)
AS
BEGIN
	----
-- =============================================

-- Original Author:		Pavani Bandaru <pavani.bandaru@beazley.com>  | Nikil Nallamothu <nikil.nallamothu@beazley.com> | Shah Nawaz Ahmed <shahnawaz.ahmed@beazley.com>
-- Create date: 18/04/2024
-- Description:	The purpose of this Stored Proc is,
--				Build up Inbound data LTD position from:
--				1. Base Load static data for 201811 - Both Open & Closed YOA
--				2. Open YOA data landed from file for current period
--				3. Closed YOA data landed from file for earlier periods (latest state for each BK)
----				
-- jira: https://beazley.atlassian.net/browse/I1B-3817
-- =============================================	
-- Author:		Shah Nawaz Ahmed <shahnawaz.ahmed@beazley.com>
-- Create date: 22/07/2024
-- Description:	For closed years Date of fact is @nextprd variable, So that change in BI will not effect unwanted new and reversals.
----				
-- jira: https://beazley.atlassian.net/browse/I1B-5672
-- =============================================

	DECLARE @Trancount INT = @@Trancount;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;
	/*======================================================Logging Starts==================================================*/
	--DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);
	DECLARE @v_RC INT;
	DECLARE @v_ActivityLogTag BIGINT;
	DECLARE @v_ActivitySource SMALLINT;
	DECLARE @v_ActivityType SMALLINT;
	DECLARE @v_ActivityStatusStart SMALLINT;
	DECLARE @v_ActivityStatusStop SMALLINT;
	DECLARE @v_ActivityStatusFail SMALLINT;
	DECLARE @v_ActivityHost VARCHAR(100);
	DECLARE @v_ActivityDatabase VARCHAR(100) = 'Eurobase';
	DECLARE @v_ActivityName VARCHAR(100);
	DECLARE @v_ActivityDateTime DATETIME2(2);
	DECLARE @v_ActivityMessage NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn BIGINT;
	DECLARE @v_ActivityLogIdOut BIGINT;
	DECLARE @v_ActivityJobId VARCHAR(50) = NULL;
	DECLARE @v_ActivitySSISExecutionId VARCHAR(50) = NULL;
	DECLARE @v_AffectedRows INT
	DECLARE @ContractType CHAR(3) = 'EUR';
	DECLARE @p_ParentActivityLogId BIGINT = NULL
	DECLARE @v_Dataset VARCHAR(50) = @v_ActivityDatabase
	DECLARE @v_BatchId INT = NULL;
	DECLARE @v_BatchId_Extensions INT;
	DECLARE @PolicyCobCode varchar(10)=NULL;

	--DECLARE @AccountingPeriod				varchar(20)		= @p_AccountingPeriod;
	SELECT @v_ActivityStatusStart = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus
	FROM Orchestram.Log.ActivityStatus
	WHERE ActivityStatus = 'ERRORED';

	INSERT INTO [dbo].[Batch] (
		[CreateDate]
		,[DataSet]
		)
	VALUES (
		GETDATE()
		,@v_Dataset
		);

	SELECT @v_BatchId = SCOPE_IDENTITY();

	SET @v_ActivityJobId = @v_BatchId

	INSERT INTO [dbo].[Batch] (
		[CreateDate]
		,[DataSet]
		)
	VALUES (
		GETDATE()
		,'Eurobase Extensions'
		);

	SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();

	/* Log the start of the insert */
	SELECT @v_ActivityLogTag = NULL
		,@v_ActivitySource = (
			SELECT PK_ActivitySource
			FROM Orchestram.Log.ActivitySource
			WHERE ActivitySource = 'IFRS17'
			)
		,@v_ActivityType = (
			SELECT PK_ActivityType
			FROM Orchestram.Log.ActivityType
			WHERE ActivityType = CASE 
					WHEN @p_ParentActivityLogId IS NULL
						THEN 'Manual process'
					ELSE 'Automated process'
					END
			)
		,@v_ActivityHost = @@SERVERNAME
		,@v_ActivityName = 'EB.usp_LandingInboundWorkflow_Eurobase'
		,@v_ActivityDateTime = GETUTCDATE()
		,@v_ActivityMessage = 'Load data into Inbound.Transaction for Eurobase'
		,@v_ActivityErrorCode = NULL
		,@v_AffectedRows = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
		,@v_ActivityLogTag
		,@v_ActivitySource
		,@v_ActivityType
		,@v_ActivityStatusStart
		,@v_ActivityHost
		,@v_ActivityDatabase
		,@v_ActivityJobId
		,@v_ActivitySSISExecutionId
		,@v_ActivityName
		,@v_ActivityDateTime
		,@v_ActivityMessage
		,@v_ActivityErrorCode
		,@v_AffectedRows
		,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

	/*==================Logging End======================*/
	BEGIN TRY
		IF @Trancount = 0
			BEGIN TRAN;

		/*
=============================================================================================
	Create BatchID In landing
==============================================================================================
*/
		DECLARE @Scenario CHAR(1) = 'A'
			,@Basis CHAR(1) = 'B'
			,@DefaultDate DATE = CAST('01-01-1980' AS DATE)
			,@TypeOfBusiness CHAR(1) = '-'
			,@Location CHAR(1) = '-'
			,@IsToDate CHAR(1) = 'Y'
			,@BusinessProcessCode CHAR(2) = 'T1'
			,@AuditHost VARCHAR(255) = CAST(SERVERPROPERTY('MachineName') AS VARCHAR(255))
			,@StatsCode VARCHAR(25) = NULL

		--,@DateOfFact date				= convert(date,convert(char(8),@p_AccountingPeriod * 100 + 1),112)
		INSERT @Logging (
			ActivityStatus
			,ActivityName
			,ActivityMessage
			)
		SELECT 5
			,'EB.usp_LandingInboundWorkflow_Eurobase'
			,' ' + CONVERT(VARCHAR, @v_BatchId) + ' Batch Created';

		----
		DECLARE
			--@dataset varchar(100) = 'Eurobase', 
			@msg VARCHAR(2000)
			,@Asat INT

		--@ContractType CHAR(3)	= 'EUR'
		--DECLARE @Basis char(1)	= '-'
		SELECT @Asat = cast(Left(REPLACE(Cast(@nextprd AS VARCHAR(10)), '-', ''), 6) AS INT) --cast(cast(YEAR(@nextprd) as varchar(4))+cast(MONTH(@nextprd)as varchar(2)) as int)

		SET @msg = 'Running Period  ' + cast(@nextprd AS VARCHAR) + '...'

		RAISERROR (
				@msg
				,10
				,1
				)
		WITH NOWAIT

		SELECT @v_BatchId
			,@v_BatchId_Extensions

		--Load next period into Inbound 
		DROP TABLE

		IF EXISTS #latestBkState;
			--Latest state of each BK
			SELECT BusinessKey
				,max(DateOfFact) DateOfFact
			INTO #latestBkState
			FROM Eurobase.vw_Eurobase
			WHERE [YOA_Source] < year(@nextprd) - 2
			GROUP BY BusinessKey

		--select * from #latestBkState
		DROP TABLE

		IF EXISTS #reversalbk;
			--Latest Reversals from Outbound - need to exclude if there is reversal in Outbound after last file position 
			SELECT BusinessKey
				,max(DateOfFact) DateOfFact
			INTO #reversalbk
			FROM FinanceDataContract.Outbound.[Transaction]
			WHERE dataset = @v_Dataset
				AND DeltaType = 'Reversal'
			GROUP BY BusinessKey

		--select * from #reversalbk
		--Current period data - to stop double counting just in case there is a bit of Closed YOA data in the current period
		DROP TABLE

		IF EXISTS #currentperiodbk
			SELECT DISTINCT BusinessKey
			INTO #currentperiodbk
			FROM Eurobase.vw_Eurobase
			WHERE DateOfFact = @nextprd
				--and [YOA_Source] >= year(@nextprd) - 2 
				AND dataset = @v_Dataset

		--select * from #currentperiodbk
		--Load latest period into Inbound temp table
		IF object_id('tempdb..#inbound') IS NOT NULL
			DROP TABLE #inbound

		--declare variables 
		SELECT [Scenario]
			,[Basis]
			,[Account]
			,[Dataset]
			,[DateOfFact]
			,[BusinessKey]
			,[PolicyNumber]
			,[InceptionDate]
			,[ExpiryDate]
			,[BindDate]
			,[DueDate]
			,[TrifocusCode]
			,[Entity]
			,[YOA]
			,[TypeOfBusiness]
			,[StatsCode]
			,[SettlementCCY]
			,[OriginalCCY]
			,[IsToDate]
			,sum([Value]) [Value]
			,sum([ValueOrig]) [ValueOrig]
			,[Location]
			,[ProgrammeCode]
			,[RIPolicyType]
			,[PolicyClaimBasis]
			,[PolicyMopCode]
		INTO #inbound
		FROM (
			--Base Load data
			SELECT [Scenario]
				,[Basis]
				,[Account]
				,[Dataset]
				,[DateOfFact]
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]
				,[DueDate]
				,[TrifocusCode]
				,[Entity]
				,[YOA]
				,[TypeOfBusiness]
				,[StatsCode]
				,[SettlementCCY]
				,[OriginalCCY]
				,[IsToDate]
				,[Value]
				,[ValueOrig]
				,[Location]
				,[ProgrammeCode]
				,[RIPolicyType]
				,[PolicyClaimBasis]
				,[PolicyMopCode]
			FROM Eurobase.vw_Eurobase
			WHERE DateOfFact = @nextprd
				AND @nextprd = '2018-11-01' /*open yoa*/
			--and [YOA_Source] >= year(@nextprd) - 2 --needed just for opening balance
			--and dataset = @dataset
			
			UNION ALL
			
			--Current Period data
			SELECT [Scenario]
				,[Basis]
				,[Account]
				,[Dataset]
				,[DateOfFact]
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]
				,[DueDate]
				,[TrifocusCode]
				,[Entity]
				,[YOA]
				,[TypeOfBusiness]
				,[StatsCode]
				,[SettlementCCY]
				,[OriginalCCY]
				,[IsToDate]
				,[Value]
				,[ValueOrig]
				,[Location]
				,[ProgrammeCode]
				,[RIPolicyType]
				,[PolicyClaimBasis]
				,[PolicyMopCode]
			FROM Eurobase.vw_Eurobase
			WHERE DateOfFact = @nextprd /*open Yoa*/
				--and [YOA_Source] >= year(@nextprd) - 2 --needed just for opening balance
				AND dataset = @v_ActivityDatabase
				AND @nextprd > '2018-11-01'
			
			UNION ALL
			
			--Closed YOA data 
			SELECT [Scenario]
				,[Basis]
				,[Account]
				,[Dataset]
				,@nextprd  AS [DateOfFact]--t.[DateOfFact]
				,t.[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]
				,[DueDate]
				,[TrifocusCode]
				,[Entity]
				,[YOA]
				,[TypeOfBusiness]
				,[StatsCode]
				,[SettlementCCY]
				,[OriginalCCY]
				,[IsToDate]
				,[Value]
				,[ValueOrig]
				,[Location]
				,[ProgrammeCode]
				,[RIPolicyType]
				,[PolicyClaimBasis]
				,[PolicyMopCode]
			FROM Eurobase.vw_Eurobase t
			JOIN #latestBkState mx --Latest state of each BK
				ON (
					mx.BusinessKey = t.BusinessKey
					AND mx.DateOfFact = t.DateOfFact
					)
			LEFT JOIN #reversalbk rv ON (
					rv.BusinessKey = t.BusinessKey
					AND rv.DateOfFact > t.DateOfFact
					)
			LEFT JOIN #currentperiodbk fl ON (fl.BusinessKey = t.BusinessKey)
			WHERE t.[YOA_Source] < year(@nextprd) - 2
				AND t.dataset = @v_ActivityDatabase
				AND rv.DateOfFact IS NULL
				AND fl.BusinessKey IS NULL
				AND @nextprd > '2018-11-01'
			) t
		GROUP BY [Scenario]
			,[Basis]
			,[Account]
			,[Dataset]
			,[DateOfFact]
			,[BusinessKey]
			,[PolicyNumber]
			,[InceptionDate]
			,[ExpiryDate]
			,[BindDate]
			,[DueDate]
			,[TrifocusCode]
			,[Entity]
			,[YOA]
			,[TypeOfBusiness]
			,[StatsCode]
			,[SettlementCCY]
			,[OriginalCCY]
			,[IsToDate]
			,[Location]
			,[ProgrammeCode]
			,[RIPolicyType]
			,[PolicyClaimBasis]
			,[PolicyMopCode]

		DROP TABLE IF EXISTS #temp_InboundTransaction;

			SELECT Scenario
				,Basis
				,[Account] = LTRIM(RTRIM([Account]))
				,[Dataset] = @v_Dataset
				,[DateOfFact] = LTRIM(RTRIM([DateOfFact]))
				,[BusinessKey] = LTRIM(RTRIM([BusinessKey]))
				,[PolicyNumber]
				,[InceptionDate] = ISNULL(LTRIM(RTRIM([InceptionDate])), @DefaultDate)
				,[ExpiryDate] = ISNULL(LTRIM(RTRIM([ExpiryDate])), @DefaultDate)
				,[BindDate] = ISNULL(LTRIM(RTRIM([BindDate])), @DefaultDate)
				,[DueDate] = ISNULL(LTRIM(RTRIM([DueDate])), @DefaultDate)
				,[TrifocusCode] = LTRIM(RTRIM([TrifocusCode]))
				,[Entity] = LTRIM(RTRIM([Entity]))
				,[Location] = @Location
				,[YOA] = LTRIM(RTRIM([YOA]))
				,[TypeOfBusiness] = @TypeOfBusiness
				,[SettlementCCY] = LTRIM(RTRIM([SettlementCCY]))
				,[OriginalCCY] = LTRIM(RTRIM([OriginalCCY]))
				,[IsToDate] = @IsToDate
				,[Value]
				,[ValueOrig]
				 ,[Rowhash] = dbo.fn_RowHashForTransactions
						(
						'T'							-- <@RowHashType, char(1),>
						,Scenario					--,<@Scenario, nvarchar(2000),>
						,[Account]					--,<@Account, nvarchar(2000),>
						,DataSet					--,<@DataSet, nvarchar(2000),>
						,[BusinessKey]				--,<@BusinessKey, nvarchar(2000),>
						,[PolicyNumber]				--,<@PolicyNumber, nvarchar(2000),>
						,[InceptionDate]			--,<@InceptionDate, date,>
						,[ExpiryDate]				--,<@ExpiryDate, date,>
						,BindDate					--,<@BindDate, date,>
						,DueDate					--,<@DueDate, date,>
						,[TrifocusCode]				--,<@TrifocusCode, nvarchar(2000),>
						,[Entity]					--,<@Entity, nvarchar(2000),>
						,[YOA]						--,<@YOA, nvarchar(2000),>
						,TypeOfBusiness				--,<@TypeOfBusiness, nvarchar(2000),>
						,[StatsCode]					--,<@StatsCode, nvarchar(2000),>
						,[SettlementCCY]			--,<@SettlementCCY, nvarchar(2000),>
						,[SettlementCCY]			--,<@OriginalCCY, nvarchar(2000),>
						,IsToDate					--,<@IsToDate, nvarchar(2000),>
						,Basis					--,<@Basis, nvarchar(2000),>
						,[Location]					--,<@Location, nvarchar(2000),>
						,null						--,<@BusinessProcessCode, nvarchar(2000),>
						,null						--,<@BoundDate, date,>
						,CONCAT
						(	
						      case when PolicyNumber is null	then '' else (PolicyNumber + '§~§') end
							 ,case when PolicyClaimBasis is null	then '' else (PolicyClaimBasis + '§~§') end
							 ,case when PolicyMopCode	   is null	then '' else (PolicyMopCode + '§~§')	end
							 ,case when @PolicyCobCode  is null	then '' else (@PolicyCobCode + '§~§')  end
						)
					)
	,[RowHash_Transaction_Premium_Extensions] = dbo.fn_RowHashForTransactions
								(
								'E'							-- <@RowHashType, char(1),>
								,Scenario					--,<@Scenario, nvarchar(2000),>
								,[Account]					--,<@Account, nvarchar(2000),>
								,DataSet					--,<@DataSet, nvarchar(2000),>
								,[BusinessKey]				--,<@BusinessKey, nvarchar(2000),>
								,[PolicyNumber]				--,<@PolicyNumber, nvarchar(2000),>
								,[InceptionDate]			--,<@InceptionDate, date,>
								,[ExpiryDate]				--,<@ExpiryDate, date,>
								,BindDate					--,<@BindDate, date,>
								,DueDate					--,<@DueDate, date,>
								,[TrifocusCode]				--,<@TrifocusCode, nvarchar(2000),>
								,[Entity]					--,<@Entity, nvarchar(2000),>
								,[YOA]						--,<@YOA, nvarchar(2000),>
								,TypeOfBusiness				--,<@TypeOfBusiness, nvarchar(2000),>
								,[StatsCode]					--,<@StatsCode, nvarchar(2000),>
								,[SettlementCCY]			--,<@SettlementCCY, nvarchar(2000),>
								,[SettlementCCY]			--,<@OriginalCCY, nvarchar(2000),>
								,IsToDate					--,<@IsToDate, nvarchar(2000),>
								,Basis						--,<@Basis, nvarchar(2000),>
								,Location					--,<@Location, nvarchar(2000),>
								,null						--,<@BusinessProcessCode, nvarchar(2000),>
								,null						--,<@BoundDate, date,>
								,CONCAT
								(
									 case when PolicyNumber is null	then '' else (PolicyNumber + '§~§') end
									,case when PolicyClaimBasis is null	then '' else (PolicyClaimBasis + '§~§') end
									,case when PolicyMopCode	   is null	then '' else (PolicyMopCode + '§~§')	end
									,case when @PolicyCobCode  is null	then '' else (@PolicyCobCode + '§~§')  end
								)
							)
				,[BusinessProcessCode] = @BusinessProcessCode
				,[AuditSourceBatchID] = CAST(@v_BatchId AS VARCHAR(50))
				,[StatsCode] = ISNULL(nullif(LTRIM(RTRIM([StatsCode])), ''), NULL)
				,[FK_Batch] = @v_BatchId
				,[DeltaType] = NULL
				,[FK_Allocation] = NULL
				,[AuditCreateDateTime] = GETUTCDATE()
				,[AuditGenerateDateTime] = GETUTCDATE()
				,[AuditUserCreate] = SUSER_NAME()
				,AuditHost = @AuditHost
				,[BoundDate] = @DefaultDate
				,RIPolicyType
				,ProgrammeCode
				,[PolicyClaimBasis]
				,[PolicyMOPCode]
			--,[PolicyCobCode]
			INTO #temp_InboundTransaction
			FROM #inbound

		DROP TABLE IF EXISTS #inbound;

			SELECT @v_AffectedRows = @@ROWCOUNT;

		INSERT @Logging (
			ActivityStatus
			,ActivityName
			,ActivityMessage
			)
		SELECT 5
			,@v_ActivityName
			,'Inserted ' + CONVERT(VARCHAR, @v_AffectedRows) + ' Rows into temp_InboundTransaction table for: ' + convert(VARCHAR, NULL);

		------/* Delete the current lines FROM Inbound ... */
		--  select *
		--  ,RowHash = dbo.fn_RowHashForTransactions
		--					(
		--					'T'							-- <@RowHashType, char(1),>
		--					,Scenario					--,<@Scenario, nvarchar(2000),>
		--					,[Account]					--,<@Account, nvarchar(2000),>
		--					,'Eurobase'--@dataSet					--,<@DataSet, nvarchar(2000),>
		--					,[BusinessKey]				--,<@BusinessKey, nvarchar(2000),>
		--				    ,[PolicyNumber]				--,<@PolicyNumber, nvarchar(2000),>
		--					,[InceptionDate]			--,<@InceptionDate, date,>
		--					,[ExpiryDate]				--,<@ExpiryDate, date,>
		--					,BindDate					--,<@BindDate, date,>
		--					,DueDate					--,<@DueDate, date,>
		--					,[TrifocusCode]				--,<@TrifocusCode, nvarchar(2000),>
		--					,[Entity]					--,<@Entity, nvarchar(2000),>
		--					,[YOA]						--,<@YOA, nvarchar(2000),>
		--					,TypeOfBusiness				--,<@TypeOfBusiness, nvarchar(2000),>
		--					,ISNULL([StatsCode],'')					--,<@StatsCode, nvarchar(2000),>
		--					,[SettlementCCY]			--,<@SettlementCCY, nvarchar(2000),>
		--					,[SettlementCCY]			--,<@OriginalCCY, nvarchar(2000),>
		--					,IsToDate					--,<@IsToDate, nvarchar(2000),>
		--					,Basis					--,<@Basis, nvarchar(2000),>
		--					,[Location]					--,<@Location, nvarchar(2000),>
		--					,null						--,<@BusinessProcessCode, nvarchar(2000),>
		--					,null						--,<@BoundDate, date,>
		--					,CONCAT
		--					(
		--						PolicyClaimBasis
		--						,PolicyMopCode
		--						,ProgrammeCode
		--						,ISNULL(RIPolicyTYpe,'')
		--					)
		--				)
		--		,RowHash_Extension = HASHBYTES('SHA2_512'
		--		                     ,CONCAT
		--								(	 
		--								-- extra attributes
		--								ISNULL(PolicyClaimBasis,'') ,'§~§'
		--								,ISNULL([RIPolicyType],''),'§~§'
		--								,ISNULL(ProgrammeCode,'') ,'§~§'
		--								,ISNULL(PolicyMopCode,'') ,'§~§'
		--								)
		--           					   )
		--into #temp_InboundTransaction
		--  from #inbound
		--select * from #temp_InboundTransaction
		DELETE
		FROM [FinanceDataContract].[Inbound].[Transaction]
		WHERE [DataSet] = @v_Dataset

		DELETE [FinanceDataContract].[Inbound].[Premium_Extensions_Bridge]
		WHERE [ContractType] = @ContractType

		DELETE [FinanceDataContract].[Inbound].[Premium_Extensions]
		WHERE [ContractType] = @ContractType

		INSERT INTO [FinanceDataContract].[Inbound].Premium_Extensions_Bridge
		WITH (TABLOCK) (
				[RowHash_Transaction]
				,[RowHash_Transaction_Premium_Extensions]
				,[ContractType]
				,[FK_Batch]
				)
		SELECT DISTINCT [RowHash]
			,[RowHash_Transaction_Premium_Extensions]
			,@ContractType
			,@v_BatchId_Extensions
		FROM #temp_InboundTransaction

		INSERT INTO [FinanceDataContract].[Inbound].Premium_Extensions
		WITH (TABLOCK) (
				[RowHash_Transaction_Premium_Extensions]
				,[PolicyClaimBasis]
				,[PolicyMOPCode]
				,[PolicyCobCode]
				,[PolicyNumber]
				,[ContractType]
				,[FK_Batch]
				)
		SELECT DISTINCT [RowHash_Transaction_Premium_Extensions]
			,PolicyClaimBasis
			,PolicyMopCode
			,@PolicyCobCode
			,PolicyNumber
			,@ContractType
			,@v_BatchId_Extensions
		FROM #temp_InboundTransaction

		--	INSERT	FinanceDataContract.Inbound.[Transaction] WITH(TABLOCK) (Scenario, Account, dataset, DateOfFact, BusinessKey, PolicyNumber, InceptionDate
		--																,ExpiryDate, BindDate, DueDate, TrifocusCode, StatsCode, Entity, YOA
		--																,TypeOfBusiness, SettlementCCY, OriginalCCY, IsToDate, [Value], AuditSourceBatchID
		--																,AuditCreateDateTime, AuditGenerateDateTime, AuditUserCreate, AuditHost, RowHash)
		--					SELECT  Scenario
		--					   ,Account
		--					   ,dataset
		--					   ,DateOfFact
		--				       ,BusinessKey
		--					   ,PolicyNumber
		--					   ,InceptionDate
		--					   ,ExpiryDate
		--					   ,BindDate
		--					   ,DueDate
		--					   ,trifocusCode
		--					   ,[StatsCode]
		--					   ,Entity
		--					   ,YOA
		--					   ,TypeofBusiness
		--					   ,SettlementCCY
		--					   ,OriginalCCY
		--					   ,ISTODate
		--					   ,[Value]
		--					   ,@v_BatchId
		--					   ,GETUTCDATE()
		--					   ,GETUTCDATE()
		--					   ,SUSER_NAME()
		--					   ,CONVERT([VARCHAR](255),(SERVERPROPERTY('MachineName'))) 
		--					   ,RowHash
		--			   FROM #temp_InboundTransaction
		--			   Update FinanceDataContract.Inbound.BatchQueue
		--			          set Status='Inbound' 
		--					  Where Pk_Batch in (@v_BatchId,@v_BatchId_Extensions)
		--End			   
		/*============================================================================================================
			INSERT INTO  Inbound.Transaction FROM FinanceLanding.[Eurobase].[LandingEPIReinstatement]
===============================================================================================================*/
		INSERT INTO [FinanceDataContract].[Inbound].[Transaction]
		WITH (TABLOCK) (
				[Scenario]
				,[Basis]
				,[Account]
				,[DataSet]
				,[DateOfFact]
				,[BusinessKey]
				,[PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[BindDate]
				,[DueDate]
				,[TrifocusCode]
				,[Entity]
				,[Location]
				,[YOA]
				,[TypeOfBusiness]
				,[SettlementCCY]
				,[OriginalCCY]
				,[IsToDate]
				,[Value]
				,[ValueOrig]
				,[RowHash]
				,[BusinessProcessCode]
				,[AuditSourceBatchID]
				,[AuditGenerateDateTime]
				,[StatsCode]
				,[FK_Batch]
				,[DeltaType]
				,[FK_Allocation]
				,[AuditUserCreate]
				,[AuditCreateDateTime]
				,AuditHost
				,[BoundDate]
				)
		SELECT [Scenario]
			,[Basis]
			,[Account]
			,[DataSet]
			,[DateOfFact]
			,[BusinessKey]
			,[PolicyNumber]
			,[InceptionDate]
			,[ExpiryDate]
			,[BindDate]
			,[DueDate]
			,[TrifocusCode]
			,[Entity]
			,[Location]
			,[YOA]
			,[TypeOfBusiness]
			,[SettlementCCY]
			,[OriginalCCY]
			,[IsToDate]
			,[Value]
			,[ValueOrig]
			,[RowHash]
			,[BusinessProcessCode]
			,[AuditSourceBatchID]
			,[AuditGenerateDateTime]
			,[StatsCode]
			,[FK_Batch]
			,[DeltaType]
			,[FK_Allocation]
			,[AuditUserCreate]
			,[AuditCreateDateTime]
			,AuditHost
			,[BoundDate]
		FROM #temp_InboundTransaction

		--WHERE DateOfFact='2020-12-15 00:00:00.000'
		SELECT @v_AffectedRows = @@ROWCOUNT;

		INSERT @Logging (
			ActivityStatus
			,ActivityName
			,ActivityMessage
			)
		SELECT 5
			,'Eb.usp_LandingInboundWorkflow_Eurobase'
			,'Inserted ' + CONVERT(VARCHAR, @v_AffectedRows) + ' Rows into Inbound.Transaction table';

		INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue] (
			Pk_Batch
			,[Status]
			,RunDescription
			,[DataSet]
			,OriginalName
			,AuditSourceBatchID
			,AsAt
			)
		VALUES (
			@v_BatchId
			,'InBound'
			,NULL
			,@v_DataSet
			,NULL
			,NULL
			,@Asat
			)
			,(
			@v_BatchId_Extensions
			,'InBound'
			,'PremiumExtensions, the additional attributes to extend functionality of the transaction table.'
			,'PremiumExtensions'
			,NULL
			,NULL
			,@Asat
			);

		-- LOG THE RESULT WITH SUCCESS--
		SELECT @v_ActivityDateTime = GETUTCDATE();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStop
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		-----Insert data into outbound Extensions table--------------
		--       if exists(select 1 from [FinanceDataContract].Inbound.[Transaction] where DataSet = @v_DataSet)
		--begin
		--	--select 'exists'
		--	DELETE ex
		--          from FinanceDataContract.Outbound.[Transaction] t
		--          INNER JOIN FinanceDataContract.Outbound.Transaction_ReInsurance_Extensions_Bridge rb on t.RowHash = rb.RowHash_Transaction
		--          INNER JOIN FinanceDataContract.Outbound.Transaction_ReInsurance_Extensions ex on rb.RowHash_Transaction_ReInsurance_Extensions = ex.RowHash_Transaction_ReInsurance_Extensions
		--          WHERE t.Dataset =@v_Dataset
		--          DELETE rb
		--          from FinanceDataContract.Outbound.[Transaction] t
		--          INNER JOIN FinanceDataContract.Outbound.Transaction_ReInsurance_Extensions_Bridge rb on t.RowHash = rb.RowHash_Transaction
		--          WHERE t.Dataset = @v_Dataset
		--           exec [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_ReInsuranceExtensions]
		--end
		IF @Trancount = 0
			COMMIT;

		INSERT @Logging (
			ActivityStatus
			,ActivityName
			,ActivityMessage
			)
		SELECT 2
			,'Eb.usp_LandingInboundWorkflow_Eurobase'
			,'Eurobase LandingToInBound Succeeded';

		--Generate logging for success--
		EXEC log.usp_LogLanding @Input = @Logging;
	END TRY

	BEGIN CATCH
		IF @Trancount = 0
			ROLLBACK;

		-- LOG THE RESULT WITH ERROR--
		UPDATE [FinanceDataContract].[Inbound].[BatchQueue]
		SET STATUS = 'OutBoundFailed'
		WHERE PK_Batch = @v_BatchId
			AND [Status] = 'InBound'
			AND DataSet = @v_DataSet

		SELECT @v_ActivityDateTime = GETUTCDATE()
			,@v_ActivityLogTag = @v_ActivityLogIdIn
			,@v_ActivityMessage = ERROR_MESSAGE()
			,@v_ActivityErrorCode = ERROR_NUMBER();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusFail
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		THROW;
	END CATCH;
END;
GO