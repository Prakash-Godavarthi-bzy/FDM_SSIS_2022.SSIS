﻿CREATE PROCEDURE [Eb].[usp_LandingInboundWorkflow_EurobaseTacticalLoad]
AS
BEGIN
/*======================================================Logging Starts==================================================*/
	
	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;
	DECLARE @v_AffectedRows					INT;
	DECLARE @v_DataSet varchar(255)='Eurobase'
	DECLARE @ContractType					CHAR(3)			= 'EUR'

	INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
	SELECT 1, 'Eb.usp_LandingInboundWorkflow_Tactical', 'Eurobase  Started';

	
/*==================Logging End======================*/


	BEGIN TRY
		IF @Trancount = 0 
			BEGIN TRAN;

		/*
=============================================================================================
	Create BatchID In landing
==============================================================================================
*/

		DECLARE @v_BatchId_Extensions INT;
		

		DECLARE @BatchId INT;
		SELECT	@BatchId	= MAX(PK_Batch)
		FROM	dbo.Batch
		WHERE	DataSet = @v_DataSet;

		DECLARE @PolicyCobCode varchar(10)=NULL

	
      INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'Eb.usp_LandingInboundWorkflow_Tactical', ' '+CONVERT(VARCHAR,@BatchId)+' Batch Created';

  		/*
			
=========================================================================================================
Insert from Landing to LandingTempEB table
=========================================================================================================
*/
	
if object_id('tempdb..#LandingTempEB') is not null drop table #LandingTempEB
SELECT [Scenario]
      ,[Basis]
      ,[Account]
      ,[Dataset]
      ,[DateOfFact]
      ,[BusinessKey]
      ,[PolicyNumber]
      ,[InceptionDate]
      ,[ExpiryDate]
      ,[BindDate]
      ,[DueDate]
      ,[TrifocusCode]
      ,[Entity]
      ,[YOA]
      ,[TypeOfBusiness]
      ,[StatsCode]
      ,[SettlementCCY]
      ,[OriginalCCY]
      ,[IsToDate]
      ,[Value]=ISNULL([Value],0)
      ,[ValueOrig]
      ,[Location]
      ,[ProgrammeCode]
      ,[DeltaType]
      ,[RIPolicyType]
      ,[PolicyClaimBasis]
      ,[PolicyMopCode]
	  ,[PolicyCobCode]=@PolicyCobCode
	  ,AuditSourceBatchID = @BatchId
	  ,[Auditcreateddatetime]
	  ,[AuditGenerateDateTime]=[Auditcreateddatetime]
      ,[Auditusercreate]
      ,[Audithost]
	  ,[Rowhash] = dbo.fn_RowHashForTransactions
						(
						'T'							-- <@RowHashType, char(1),>
						,Scenario					--,<@Scenario, nvarchar(2000),>
						,[Account]					--,<@Account, nvarchar(2000),>
						,DataSet					--,<@DataSet, nvarchar(2000),>
						,[BusinessKey]				--,<@BusinessKey, nvarchar(2000),>
						,[PolicyNumber]				--,<@PolicyNumber, nvarchar(2000),>
						,[InceptionDate]			--,<@InceptionDate, date,>
						,[ExpiryDate]				--,<@ExpiryDate, date,>
						,BindDate					--,<@BindDate, date,>
						,DueDate					--,<@DueDate, date,>
						,[TrifocusCode]				--,<@TrifocusCode, nvarchar(2000),>
						,[Entity]					--,<@Entity, nvarchar(2000),>
						,[YOA]						--,<@YOA, nvarchar(2000),>
						,TypeOfBusiness				--,<@TypeOfBusiness, nvarchar(2000),>
						,[StatsCode]					--,<@StatsCode, nvarchar(2000),>
						,[SettlementCCY]			--,<@SettlementCCY, nvarchar(2000),>
						,[SettlementCCY]			--,<@OriginalCCY, nvarchar(2000),>
						,IsToDate					--,<@IsToDate, nvarchar(2000),>
						,Basis					--,<@Basis, nvarchar(2000),>
						,[Location]					--,<@Location, nvarchar(2000),>
						,null						--,<@BusinessProcessCode, nvarchar(2000),>
						,null						--,<@BoundDate, date,>
						,CONCAT
						(	
						      case when PolicyNumber is null	then '' else (PolicyNumber + '§~§') end
							 ,case when PolicyClaimBasis is null	then '' else (PolicyClaimBasis + '§~§') end
							 ,case when PolicyMopCode	   is null	then '' else (PolicyMopCode + '§~§')	end
							 ,case when @PolicyCobCode  is null	then '' else (@PolicyCobCode + '§~§')  end
						)
					)
	,[RowHash_Transaction_Premium_Extensions] = dbo.fn_RowHashForTransactions
								(
								'E'							-- <@RowHashType, char(1),>
								,Scenario					--,<@Scenario, nvarchar(2000),>
								,[Account]					--,<@Account, nvarchar(2000),>
								,DataSet					--,<@DataSet, nvarchar(2000),>
								,[BusinessKey]				--,<@BusinessKey, nvarchar(2000),>
								,[PolicyNumber]				--,<@PolicyNumber, nvarchar(2000),>
								,[InceptionDate]			--,<@InceptionDate, date,>
								,[ExpiryDate]				--,<@ExpiryDate, date,>
								,BindDate					--,<@BindDate, date,>
								,DueDate					--,<@DueDate, date,>
								,[TrifocusCode]				--,<@TrifocusCode, nvarchar(2000),>
								,[Entity]					--,<@Entity, nvarchar(2000),>
								,[YOA]						--,<@YOA, nvarchar(2000),>
								,TypeOfBusiness				--,<@TypeOfBusiness, nvarchar(2000),>
								,[StatsCode]					--,<@StatsCode, nvarchar(2000),>
								,[SettlementCCY]			--,<@SettlementCCY, nvarchar(2000),>
								,[SettlementCCY]			--,<@OriginalCCY, nvarchar(2000),>
								,IsToDate					--,<@IsToDate, nvarchar(2000),>
								,Basis						--,<@Basis, nvarchar(2000),>
								,Location					--,<@Location, nvarchar(2000),>
								,null						--,<@BusinessProcessCode, nvarchar(2000),>
								,null						--,<@BoundDate, date,>
								,CONCAT
								(
									 case when PolicyNumber is null	then '' else (PolicyNumber + '§~§') end
									,case when PolicyClaimBasis is null	then '' else (PolicyClaimBasis + '§~§') end
									,case when PolicyMopCode	   is null	then '' else (PolicyMopCode + '§~§')	end
									,case when @PolicyCobCode  is null	then '' else (@PolicyCobCode + '§~§')  end
								)
							)
	INTO #LandingTempEB
    FROM [Eb].[TL_Outbound]

			SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'Eb.usp_LandingInboundWorkflow_Tactical', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into Temp_LandEB table, Batch: ' +cast (@BatchId as varchar);

     ------/* Delete the current lines from Inbound ... */

        DELETE
		FROM [FinanceDataContract].[Inbound].[Transaction]
		WHERE [DataSet] = @v_DataSet

		DELETE [FinanceDataContract].[Inbound].[Premium_Extensions_Bridge]
		WHERE [ContractType] = @ContractType

		DELETE [FinanceDataContract].[Inbound].[Premium_Extensions]
		WHERE [ContractType] = @ContractType


	 ----------/*Insert into batch table...*/----------------
		
		INSERT INTO [dbo].[Batch]
			([CreateDate],[DataSet],[LatestBusinesKey]) 
		VALUES  
			(GETDATE(),'PremiumExtensions', NULL);

		SELECT @v_BatchId_Extensions = SCOPE_IDENTITY();

	---------/*Insert data into inbound extensions table*/------------
	   
		INSERT INTO  [FinanceDataContract].[Inbound].[Premium_Extensions_Bridge] WITH(TABLOCK)
			(
				[RowHash_Transaction]
				,[RowHash_Transaction_Premium_Extensions]
				,[ContractType]
				,[FK_Batch]
			)
			SELECT DISTINCT
				[Rowhash]
				,[RowHash_Transaction_Premium_Extensions]
				,@ContractType
				,@v_BatchId_Extensions
			FROM 
				#LandingTempEB

				SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'Eb.usp_LandingInboundWorkflow_Eurobase', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into Inbound.Premium_Extensions_Bridge, Batch: ' +cast (@v_BatchId_Extensions as varchar);


		INSERT INTO  [FinanceDataContract].[Inbound].Premium_Extensions WITH(TABLOCK)
				(
					 [RowHash_Transaction_Premium_Extensions]
					,[PolicyClaimBasis]
					,[PolicyMOPCode]
					,[PolicyCobCode]
					,[PolicyNumber]
					,[ContractType]
					,[FK_Batch]
				)
				SELECT DISTINCT
					[RowHash_Transaction_Premium_Extensions]
					,PolicyClaimBasis 
					,PolicyMopCode
					,PolicyCobCode
					,PolicyNumber
					,@ContractType
					,@v_BatchId_Extensions
				FROM 
					#LandingTempEB

    
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'Eb.usp_LandingInboundWorkflow_Tactical', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into Inbound.Premium_Extensions, Batch: ' +cast (@v_BatchId_Extensions as varchar);

		

/*============================================================================================================
			INSERT INTO  Inbound.Transaction FROM FinanceLanding.[Ebnld].[Outbound] 
===============================================================================================================*/
	INSERT	FinanceDataContract.Inbound.[Transaction] WITH(TABLOCK) (Scenario, Account, dataset, DateOfFact, BusinessKey, PolicyNumber, InceptionDate
																,ExpiryDate, BindDate, DueDate, TrifocusCode, StatsCode, Entity, YOA
																,TypeOfBusiness, SettlementCCY, OriginalCCY, IsToDate, [Value], AuditSourceBatchID
																,AuditCreateDateTime, AuditGenerateDateTime, AuditUserCreate, AuditHost,DeltaType,RowHash)

				SELECT  Scenario
					   ,Account
					   ,dataset
					   ,DateOfFact
					   ,BusinessKey
					   ,PolicyNumber
					   ,InceptionDate
					   ,ExpiryDate
					   ,BindDate
					   ,DueDate
					   ,trifocusCode
					   ,[StatsCode]
					   ,Entity
					   ,YOA
					   ,TypeofBusiness
					   ,SettlementCCY
					   ,OriginalCCY
					   ,ISTODate
					   ,[Value]
					   ,AuditSourceBatchID
					   ,Auditcreateddatetime
					   ,AuditGenerateDateTime
					   ,Auditusercreate
					   ,AuditHost 
					   ,DeltaType
					   ,RowHash
			 FROM #LandingTempEB
	

		
	    SELECT   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'Eb.usp_LandingInboundWorkflow_Tactical', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into Inbound.Transaction table'+cast (@BatchId as varchar);

		INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
								( Pk_Batch
								,[Status]
								,RunDescription
								,[DataSet]
								,OriginalName
								,AuditSourceBatchID
								)
				VALUES

								( @v_BatchId_Extensions
								 ,'InBound'
								 ,'PremiumExtensions, the additional attributes to extend functionality of the transaction table.'
								 ,'PremiumExtensions'
								 ,NULL
								 ,NULL
								);
/*
================================================================================================
		Delete extensions data from Outbound
================================================================================================
*/
        IF EXISTS(SELECT  1 FROM [FinanceDataContract].Inbound.[Transaction] WHERE DataSet = @v_DataSet)
	 BEGIN
	        DELETE ex
			FROM FinanceDataContract.Outbound.[Transaction] t
			INNER JOIN FinanceDataContract.Outbound.Premium_Extensions_Bridge rb on t.RowHash = rb.RowHash_Transaction
			INNER JOIN FinanceDataContract.Outbound.Premium_Extensions ex on rb.RowHash_Transaction_Premium_Extensions=ex.RowHash_Transaction_Premium_Extensions
			WHERE t.Dataset=@v_Dataset


                   
			DELETE rb
			FROM FinanceDataContract.Outbound.[Transaction] t
			INNER JOIN FinanceDataContract.Outbound.Premium_Extensions_Bridge rb on t.RowHash = rb.RowHash_Transaction
			WHERE t.Dataset=@v_Dataset

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'Eb.usp_LandingInboundWorkflow_Tactical', 'Deleted extensions data from Outbound';
	END


/*
================================================================================================
		Load extensions data from Inbound to Outnound
================================================================================================
*/
			EXEC [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_PremiumExtensions]

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'Eb.usp_LandingInboundWorkflow_Tactical', 'Insert from Inbound to Outbound Extensions Tables';

		/*
=============================================================================================
	QueueBatchID in DataContract
==============================================================================================
*/
		UPDATE	FinanceDataContract.Inbound.BatchQueue
		SET		Status = 'InBound'
		WHERE	Status = 'FinanceLanding'
			AND DataSet = 'Eurobase'
			AND Pk_Batch = @BatchId;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 5, 'Eb.usp_LandingInboundWorkflow_Tactical', 'QueueBatchID in DataContract';
		IF @Trancount = 0 COMMIT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, 'Eb.usp_LandingInboundWorkflow_Tactical', 'Eurobase Succeeded for Batch: '+cast (@BatchId as varchar);

		--Generate logging for success
		EXEC log.usp_LogLanding @Input = @Logging;

	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		--Generate logging for error (outside tran)
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 4, 'Eb.usp_LandingInboundWorkflow_Tactical', ERROR_MESSAGE();
		EXEC log.usp_LogLanding @Input = @Logging;


		THROW;
	END CATCH;
END;