﻿CREATE PROCEDURE [eb].[usp_LandingInboundWorkflow]
AS
    BEGIN
        DECLARE @Trancount INT= @@Trancount;
        BEGIN TRY
            IF @Trancount = 0
            BEGIN TRAN;

/*
=============================================================================================
	Create BatchID In landing
==============================================================================================
*/

            DECLARE @BatchId INT;
             SELECT  @BatchId= MAX([PK_Batch])
             FROM dbo.[Batch]
             WHERE [DataSet] = 'Eurobase'
/*

=========================================================================================================
Insert from Landing to Inbound.Transaction Table 
=========================================================================================================
*/

            DROP TABLE IF EXISTS #temp;
            CREATE TABLE #temp
            ([policyref]             [VARCHAR](12) NOT NULL, 
             [inception]             [DATETIME2](7) NULL, 
             [expiry]                [DATETIME2](7) NULL, 
             [underwriter]           [VARCHAR](20) NULL, 
             [dept]                  [VARCHAR](20) NULL, 
             [trifocusCode]          [NVARCHAR](255) NULL, 
             [yoa]                   [INT] NULL, 
             [TypeofBusiness]        [VARCHAR](1) NOT NULL, 
             [stats]                 [VARCHAR](3) NULL, 
             [LEVEL3]                [VARCHAR](6) NOT NULL, 
             [Scenario]              [VARCHAR](1) NOT NULL, 
             [EntityCode]            [INT] NULL, 
             [SettlementCCY]         [VARCHAR](3) NULL, 
             [AcquisitionCosts]      [NUMERIC](38, 18) NULL, 
             [Gross]                 [NUMERIC](38, 18) NULL, 
             [AuditSourceBatchID]    [INT] NOT NULL, 
             [auditcreateddatetime]  [DATETIME2](7) NULL, 
             [AuditGenerateDateTime] [DATETIME2](7) NULL, 
             [auitusercreate]        [NVARCHAR](255) NULL, 
             [AuditHost]             [NVARCHAR](255) NULL
            );
            INSERT INTO #temp
                   SELECT v.[policyref], 
                          v.inception, 
                          v.expiry, 
                          v.underwriter, 
                          v.dept, 
                          trf.[trifocusCode], 
                          v.yoa,
                          CASE
                              WHEN ISNULL(C.[origpolicyref], '') = ''
                                   OR C.[origpolicyref] = C.[policyref]
                              THEN 'N'
                              ELSE 'R'
                          END 'TypeofBusiness', 
                          v.[stats],
                          CASE
                              WHEN c.MOP IN('B', 'L')
                                   OR trf.IsKoreanReTrifocus = 1
                              THEN 'Binder'
                              ELSE 'Policy'
                          END 'LEVEL3', 
                          'A' Scenario, 
                          v.[synd] AS EntityCode, 
                          v.[ccy] SettlementCCY, 
                        CAST(ROUND(Deductions,2) AS NUMERIC(19, 4)) AS 'AcquisitionCosts', 
                        CAST(ROUND(Deductions,2) AS NUMERIC(19, 4)) +  CAST(ROUND(V.EPI ,2) AS NUMERIC(19, 4)) 'Gross',
                          @BatchId AS AuditSourceBatchID, 
                          v.[auditcreateddatetime], 
                          v.[auditcreateddatetime] AS [AuditGenerateDateTime], 
                          v.[auitusercreate], 
                          v.[AuditHost]
                   FROM [eb].[policy_cube] c
                        INNER JOIN [eb].[epi_view_bbr2] v ON c.policyref = v.policyref
                        INNER JOIN [sp].[TrifocusCode] trf ON v.trifocus = trf.[TrifocusName]
                                                              AND trf.SourceSystem = 'Eurobase';

/*
=========================================================================================================
load AcquisitionCosts from landing to DataContract
=========================================================================================================
*/

          INSERT INTO [FinanceDataContract].[Inbound].[Transaction]
            ([Scenario], 
             [Account], 
             [SourceSystem], 
             [DateOfFact], 
             [BusinessKey], 
             [PolicyNumber], 
             [InceptionDate], 
             [ExpiryDate], 
             [BindDate], 
             [DueDate], 
             [TrifocusCode],
			 StatsCode, 
             [Entity], 
             [YOA], 
             [TypeOfBusiness], 
             [SettlementCCY], 
             [OriginalCCY], 
             [IsToDate], 
             [Value], 
             [AuditSourceBatchID], 
             [AuditCreateDateTime], 
             [AuditGenerateDateTime], 
             [AuditUserCreate], 
             [AuditHost]
            )
                   SELECT Scenario,
                          CASE
                              WHEN [LEVEL3] = 'Policy'
                              THEN 'P-AC-P'
                              WHEN [LEVEL3] = 'Binder'
                              THEN 'P-AC-B'
                          END AS Account, 
                          'Eurobase' AS SourceSystem, 
                          CAST(inception AS DATETIME2) AS DateOfFact, 
                          policyref AS BusinessKey, 
                          policyref AS PoliceyNumber, 
                          CAST(inception AS DATETIME2) AS InceptionDate, 
                          CAST(expiry AS DATETIME2) AS ExpiryDate, 
                          CAST('01/01/1980' AS DATETIME2) AS BindDate, 
                          CAST('01/01/1980' AS DATETIME2) AS DueDate, 
                          [TrifocusCode], 
						  [stats],
                          EntityCode AS Entity, 
                          yoa AS YOA, 
                          TypeofBusiness TypeofBusiness, 
                          [SettlementCCY] AS [SettlementCCY], 
                          [SettlementCCY] AS [OriginalCCY], 
                          'Y' ISTODate, 
                          AcquisitionCosts AS [Value], 
                          AuditSourceBatchID, 
                          [AuditCreatedDatetime], 
                          [AuditGenerateDateTime], 
                          [auitusercreate], 
                          [AuditHost]
                   FROM #temp
                   WHERE AcquisitionCosts > 0;

/*
=========================================================================================================
load Gross from landing to DataContract
=========================================================================================================
*/

            INSERT INTO [FinanceDataContract].[Inbound].[Transaction]
            ([Scenario], 
             [Account], 
             [SourceSystem], 
             [DateOfFact], 
             [BusinessKey], 
             [PolicyNumber], 
             [InceptionDate], 
             [ExpiryDate], 
             [BindDate], 
             [DueDate], 
             [TrifocusCode], 
			 StatsCode,
             [Entity], 
             [YOA], 
             [TypeOfBusiness], 
             [SettlementCCY], 
             [OriginalCCY], 
             [IsToDate], 
             [Value], 
             [AuditSourceBatchID], 
             [AuditCreateDateTime], 
             [AuditGenerateDateTime], 
             [AuditUserCreate], 
             [AuditHost]
            )
                   SELECT Scenario,
                          CASE
                              WHEN [LEVEL3] = 'Policy'
                              THEN 'P-GP-P'
                              WHEN [LEVEL3] = 'Binder'
                              THEN 'P-GP-B'
                          END AS ACCOUNT, 
                          'Eurobase' AS SourceSystem, 
                          CAST(GETDATE() AS DATETIME2) AS DateOfFact, 
                          policyref AS BusinessKey, 
                          policyref AS PoliceyNumber, 
                          CAST(inception AS DATETIME2) AS InceptionDate, 
                          CAST(expiry AS DATETIME2) AS ExpiryDate, 
                          CAST('01/01/1980' AS DATETIME2) AS BindDate, 
                          CAST('01/01/1980' AS DATETIME2) AS DueDate, 
                          [TrifocusCode], 
						  [stats],
                          EntityCode AS Entity, 
                          yoa AS YOA, 
                          TypeofBusiness, 
                          [SettlementCCY] AS [SettlementCCY], 
                          [SettlementCCY] AS [OriginalCCY], ---check with Dave,
                          'Y' ISTODate, 
                          Gross AS [Value], 
                          AuditSourceBatchID, 
                          [AuditCreateddatetime], 
                          [AuditGenerateDateTime], 
                          [auitusercreate], 
                          [AuditHost]
                   FROM #temp
                   WHERE Gross > 0;

/*
=============================================================================================
	LogInbound Aggregate Value
==============================================================================================
*/
            EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_Inbound] @BatchId



/*
=============================================================================================
	QueueBatchID in DataContract
==============================================================================================
*/
            INSERT INTO [FinanceDataContract].[Inbound].[BatchQueue]
            ([Pk_Batch], 
             [Status],
			 DataSet
            )
            VALUES
            (@BatchId, 
             'Pending',
			 'Eurobase'
            );
            IF @Trancount = 0
                COMMIT;
        END TRY
        BEGIN CATCH
            IF @Trancount = 0
                ROLLBACK;
            THROW;
        END CATCH;
    END;