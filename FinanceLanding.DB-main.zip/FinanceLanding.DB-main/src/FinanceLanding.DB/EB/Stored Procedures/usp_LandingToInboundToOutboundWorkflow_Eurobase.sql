﻿CREATE PROCEDURE [Eb].[usp_LandingToInboundToOutboundWorkflow_Eurobase] @p_ParentActivityLogId BIGINT = NULL
	,@p_ActivityJobId VARCHAR(50) = NULL
AS
BEGIN

-- =============================================

-- Original Author:		Pavani Bandaru <pavani.bandaru@beazley.com> | Nikil Nallamothu <nikil.nallamothu@beazley.com> | Shah Nawaz Ahmed <shahnawaz.ahmed@beazley.com>
-- Create date: 18/04/2024
-- Description:	This stored procedure calls usp_LandingInboundWorkflow_Eurobase and usp_InboundOutboundWorkflow_GAAP by iteratively going through the accounting periods one by one.

-- jira: https://beazley.atlassian.net/browse/I1B-3817
-- =============================================	

	SET NOCOUNT ON;

	DECLARE @v_ErrorMessage NVARCHAR(4000);
	DECLARE @v_RC INT;
	DECLARE @v_ActivityLogTag BIGINT;
	DECLARE @v_ActivitySource SMALLINT;
	DECLARE @v_ActivityType SMALLINT;
	DECLARE @v_ActivityStatusStart SMALLINT;
	DECLARE @v_ActivityStatusStop SMALLINT;
	DECLARE @v_ActivityStatusFail SMALLINT;
	DECLARE @v_ActivityHost VARCHAR(100);
	DECLARE @v_ActivityDatabase VARCHAR(100) = 'Eurobase';
	DECLARE @v_ActivityName VARCHAR(100);
	DECLARE @v_ActivityDateTime DATETIME2(2);
	DECLARE @v_ActivityMessage NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn BIGINT;
	DECLARE @v_ActivityLogIdOut BIGINT;
	DECLARE @v_ActivityJobId VARCHAR(50) = @p_ActivityJobId;
	DECLARE @v_ActivitySSISExecutionId VARCHAR(50) = NULL;
	DECLARE @v_AffectedRows INT
	DECLARE @v_DataSet VARCHAR(255) = @v_ActivityDatabase
	DECLARE @v_AccountingPeriod INT = NULL;
	DECLARE @v_AccountingPeriod_Default INT = 201812;-- this is our starting date

	BEGIN TRY
		SELECT @v_ActivityStatusStart = PK_ActivityStatus
		FROM Orchestram.Log.ActivityStatus
		WHERE ActivityStatus = 'STARTED';

		SELECT @v_ActivityStatusStop = PK_ActivityStatus
		FROM Orchestram.Log.ActivityStatus
		WHERE ActivityStatus = 'SUCCEEDED';

		SELECT @v_ActivityStatusFail = PK_ActivityStatus
		FROM Orchestram.Log.ActivityStatus
		WHERE ActivityStatus = 'ERRORED';

		/* Log the start of the process */
		SELECT @v_ActivityLogTag = NULL
			,@v_ActivitySource = (
				SELECT PK_ActivitySource
				FROM Orchestram.Log.ActivitySource
				WHERE ActivitySource = 'IFRS17'
				)
			,@v_ActivityType = (
				SELECT PK_ActivityType
				FROM Orchestram.Log.ActivityType
				WHERE ActivityType = CASE 
						WHEN @p_ParentActivityLogId IS NULL
							THEN 'Manual process'
						ELSE 'Automated process'
						END
				)
			,@v_ActivityHost = @@SERVERNAME
			,@v_ActivityName = 'Load data into Inbound.Transaction and Outbound.Transaction using [Eb].[usp_LandingToInboundToOutboundWorkflow_Eurobase]  '
			,@v_ActivityDateTime = GETUTCDATE()
			,@v_ActivityMessage = ''
			,@v_ActivityErrorCode = NULL
			,@v_AffectedRows = 0;

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStart
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

		DROP TABLE

		IF EXISTS #validDPF
			SELECT cast('2018-11-01' AS DATE) AS ValidDOF
			INTO #validDPF
			
			UNION ALL
			
			SELECT DISTINCT cast(left(convert(VARCHAR, dateadd(month, - 1, report_date), 112), 6) + '01' AS DATE) ValidDOF
			FROM Eurobase.Eurobase_EPI
			WHERE report_date IS NOT NULL
			ORDER BY 1

		DECLARE @maxoutprd DATE

		--Check max period available in Outbound table 
		SELECT @maxoutprd = isnull(max(DateOfFact), '1980-01-01')
		FROM FinanceDataContract.Outbound.[Transaction]
		WHERE dataset = 'Eurobase'

		DROP TABLE

		IF EXISTS #ValidPeriods;
			SELECT ROW_NUMBER() OVER (
					ORDER BY ValidDOF
					) AS RowId
				,ValidDOF
			INTO #ValidPeriods
			FROM #validDPF
			WHERE ValidDOF > @maxoutprd
				AND ValidDOF <= GETDATE()
			ORDER BY 1 ASC

		DECLARE @RowID INT
			,@cnt INT

		SELECT @cnt = COUNT(*)
		FROM #ValidPeriods

		SET @RowID = 1

		DECLARE @nextprd DATE
		DECLARE @DoNonIFRS17_Tests bit = 0
		----LOop while Outbound behind Source
		WHILE (@RowID <= @cnt)
		BEGIN
			--Pick the next period to run
			SELECT @nextprd = ValidDOF
			FROM #ValidPeriods
			WHERE RowId = @RowID

			--print  @nextprd --2018-11-01
			EXEC [Eb].[usp_LandingInboundWorkflow_Eurobase] @nextprd

			EXEC [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_PremiumExtensions]

			EXEC FinanceDataContract.[Inbound].[usp_InboundOutboundWorkflow_GAAP] @DoNonIFRS17_Tests

			SET @RowID = @RowID + 1;
		END

		-- LOG THE RESULT WITH SUCCESS
		SELECT @v_ActivityDateTime = GETUTCDATE();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusStop
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;
	END TRY

	BEGIN CATCH
		-- LOG THE RESULT WITH ERROR
		SELECT @v_ActivityDateTime = GETUTCDATE()
			,@v_ActivityLogTag = @v_ActivityLogIdIn
			,@v_ActivityMessage = ERROR_MESSAGE()
			,@v_ActivityErrorCode = ERROR_NUMBER();

		EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog @p_ParentActivityLogId
			,@v_ActivityLogTag
			,@v_ActivitySource
			,@v_ActivityType
			,@v_ActivityStatusFail
			,@v_ActivityHost
			,@v_ActivityDatabase
			,@v_ActivityJobId
			,@v_ActivitySSISExecutionId
			,@v_ActivityName
			,@v_ActivityDateTime
			,@v_ActivityMessage
			,@v_ActivityErrorCode
			,@v_AffectedRows
			,@v_ActivityLogIdIn OUTPUT;

		THROW;
	END CATCH;
END
GO