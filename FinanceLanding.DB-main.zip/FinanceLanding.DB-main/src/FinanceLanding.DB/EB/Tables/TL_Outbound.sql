﻿CREATE TABLE [Eb].[TL_Outbound](
	[Scenario] [varchar](2) NOT NULL,
	[Basis] [varchar](2) NOT NULL,
	[Account] [varchar](15) NOT NULL,
	[Dataset] [varchar](255) NOT NULL,
	[DateOfFact] [datetime] NULL,
	[BusinessKey] [varchar](255) NOT NULL,
	[PolicyNumber] [varchar](255) NULL,
	[InceptionDate] [datetime] NULL,
	[ExpiryDate] [datetime] NULL,
	[BindDate] [datetime] NOT NULL,
	[DueDate] [datetime] NOT NULL,
	[TrifocusCode] [varchar](25) NULL,
	[Entity] [varchar](25) NULL,
	[YOA] [varchar](5) NULL,
	[TypeOfBusiness] [varchar](1) NOT NULL,
	[StatsCode] [varchar](25) NULL,
	[SettlementCCY] [varchar](3) NOT NULL,
	[OriginalCCY] [varchar](3) NOT NULL,
	[IsToDate] [varchar](1) NOT NULL,
	[Value] [numeric](38, 4) NULL,
	[ValueOrig] [numeric](38, 4) NULL,
	[Location] [varchar](1) NOT NULL,
	[ProgrammeCode] [varchar](100) NULL,
	[DeltaType] [varchar](50) NULL,
	[RIPolicyType] [varchar](50) NULL,
	[PolicyClaimBasis] [varchar](255) NULL,
	[PolicyMopCode] [varchar](255) NULL,
	[Auditcreateddatetime] [datetime2](7) NULL,
	[Auditusercreate] [nvarchar](255) NULL,
	[Audithost] [nvarchar](255) NULL
) ON [PRIMARY]
GO

ALTER TABLE [Eb].[TL_Outbound] ADD  CONSTRAINT [Eb_TLOutbound_auditcreateddatetime]  DEFAULT (getdate()) FOR [Auditcreateddatetime]
GO

ALTER TABLE [Eb].[TL_Outbound] ADD  CONSTRAINT [Eb_TLOutbound_auditusercreate]  DEFAULT (suser_name()) FOR [Auditusercreate]
GO

ALTER TABLE [Eb].[TL_Outbound] ADD  CONSTRAINT [Eb_TLOutbound_audithost]  DEFAULT (host_name()) FOR [Audithost]
GO


