﻿CREATE TABLE [eb].[common_policy_details_01]
(
cpd_policyreference VARCHAR(12) NOT NULL,
cpd_syn_processing INT NULL,
cpd_written_date DATETIME NULL,
epi_CCY VARCHAR(3) NULL,
Orig_policyref VARCHAR(50) NULL,
Inception DATETIME NULL,
Expiry DATETIME NULL,
cpd_status VARCHAR(2) NULL,
Cpd_ClosedDate DATETIME NULL,
cpd_OrigCCY VARCHAR(3) NULL,
Brokerage_pcnt Numeric (16,4) NULL,
TotalDed_pcnt NUMERIC (16,4) NULL,
[Auditcreateddatetime] DATETIME2 (7)   CONSTRAINT [DF_common_policy_details_01_auditcreateddatetime] DEFAULT (getdate()) NULL,
[Auditusercreate]       NVARCHAR (255)  CONSTRAINT [DF_common_policy_details_01_auditusercreate] DEFAULT (suser_name()) NULL,
[Audithost]            NVARCHAR (255)  CONSTRAINT [DF_common_policy_details_01_audithost] DEFAULT (host_name()) NULL,
)
