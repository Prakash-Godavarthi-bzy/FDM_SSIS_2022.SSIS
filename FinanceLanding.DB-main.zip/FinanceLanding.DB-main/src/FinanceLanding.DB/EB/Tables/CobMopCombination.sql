﻿CREATE TABLE [Eb].[CobMopCombination](
	[CmcSynProcessing] [int] NULL,
	[CmcCobCode] [varchar](3) NULL,
	[CmcMopCode] [varchar](1) NULL,
	[CmcReassInd] [varchar](1) NULL,
	[CmcAssInd] [varchar](1) NULL,
	[CmcVesInd] [varchar](1) NULL,
	[CmcLossBasis] [varchar](3) NULL,
	[CmcZoneInd] [varchar](1) NULL,
	[CmcGpiLimitInd] [varchar](1) NULL,
	[CmcRolEstInd] [varchar](1) NULL,
	[CmcRolActInd] [varchar](1) NULL,
	[CmcDecInd] [varchar](1) NULL,
	[CmcFinInd] [varchar](1) NULL,
	[Cmc9999Ind] [varchar](1) NULL,
	[Initialise] [int] NULL,
	[Auditcreateddatetime] [datetime2](7) NULL,
	[Auditusercreate] [nvarchar](255) NULL,
	[Audithost] [nvarchar](255) NULL
) ON [PRIMARY]
GO

ALTER TABLE [Eb].[CobMopCombination] ADD  CONSTRAINT [DF_CobMopCombination_auditcreateddatetime]  DEFAULT (getdate()) FOR [Auditcreateddatetime]
GO

ALTER TABLE [Eb].[CobMopCombination] ADD  CONSTRAINT [DF_CobMopCombination_auditusercreate]  DEFAULT (suser_name()) FOR [Auditusercreate]
GO

ALTER TABLE [Eb].[CobMopCombination] ADD  CONSTRAINT [DF_CobMopCombination_audithost]  DEFAULT (host_name()) FOR [Audithost]
GO
