﻿CREATE TABLE eb.policy_deductions ( [ded_cpd_policy_ref] char(12) NOT NULL, 
									[ded_sequence_no] int, 
									[ded_qual] char(1), 
									[ded_pcnt] real, 
    CONSTRAINT [PK_policy_deductions] PRIMARY KEY ([ded_cpd_policy_ref]) );
    




