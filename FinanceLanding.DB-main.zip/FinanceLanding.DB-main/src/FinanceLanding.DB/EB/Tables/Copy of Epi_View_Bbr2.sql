﻿CREATE TABLE [eb].[Epi_View_Bbr2] (
    [PK_EpiView]           INT             IDENTITY (1, 1) NOT NULL,
    [Policyref]            VARCHAR (12)    NOT NULL,
    [Inception]            DATETIME		   NULL,
    [Expiry]               DATETIME		   NULL,
    [Underwriter]          VARCHAR (20)    NULL,
    [Dept]                 VARCHAR (20)    NULL,
    [Trifocus]             VARCHAR (25)    NULL,
    [Yoa]                  INT             NULL,
    [Stats]                VARCHAR (3)     NULL,
    [Ccy]                  VARCHAR (3)     NULL,
    [Synd]                 INT             NULL,
    [Deductions]           NUMERIC (19, 4) NULL,
    [Epi]                  NUMERIC (19, 4) NULL,
    [Auditcreateddatetime] DATETIME2 (7)   CONSTRAINT [DF_epi_view_bbr2_auditcreateddatetime] DEFAULT (getdate()) NULL,
    [Auitusercreate]       NVARCHAR (255)  CONSTRAINT [DF_epi_view_bbr2_auitusercreate] DEFAULT (suser_name()) NULL,
    [Audithost]            NVARCHAR (255)  CONSTRAINT [DF_epi_view_bbr2_audithost] DEFAULT (host_name()) NULL,
    CONSTRAINT [pk_id_policyref_product_epi_view] PRIMARY KEY CLUSTERED ([Policyref] ASC, [PK_EpiView] ASC)
);



