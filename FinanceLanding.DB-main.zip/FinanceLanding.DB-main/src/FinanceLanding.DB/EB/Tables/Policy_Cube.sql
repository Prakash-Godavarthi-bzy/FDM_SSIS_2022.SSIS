﻿CREATE TABLE [eb].[Policy_Cube] (
    [PK_PolicyCube] INT           IDENTITY (1, 1) NOT NULL,
    [Policyref]     VARCHAR (12)  NOT NULL,
    [Stats]         VARCHAR (3)   NULL,
    [Area]          VARCHAR (3)   NULL,
    [Cob]           VARCHAR (3)   NULL,
    [Status]        VARCHAR (1)   NULL,
    [Lpsodate]      DATETIME NULL,
    [Mop]           VARCHAR (3)   NULL,
	[Account]		VARCHAR(250) NULL,
    [Origpolicyref] VARCHAR (50)  NULL,
    [renewalfrom]	VARCHAR(50) NULL, 
    CONSTRAINT [pk_id_policyref_policy_cube] PRIMARY KEY CLUSTERED ([Policyref] ASC, [PK_PolicyCube] ASC)
);

