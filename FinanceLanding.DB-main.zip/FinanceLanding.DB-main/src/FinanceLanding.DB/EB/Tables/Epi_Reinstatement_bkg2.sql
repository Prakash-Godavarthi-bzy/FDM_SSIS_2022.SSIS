﻿CREATE TABLE eb.epi_reinstatement_bkg2(
[pre_cpd_policy_ref] Varchar(50) NOT NULL
,[spl_syn_user_number] INT NULL
,[bkg] NUMERIC(19,4)
,[rst] NUMERIC(19,4)
,[Auditcreatedatetime] datetime2
,[Auditusercreate] NVARCHAR(510)
,[Audithost] NVARCHAR(510)
)