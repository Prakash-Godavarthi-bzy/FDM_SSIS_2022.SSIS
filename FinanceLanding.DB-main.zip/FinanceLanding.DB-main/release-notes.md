Sprint 16    
-Added Period Mappings for ResDataRIAttClmAlloc Dataset(I1B-5289)        
-Conform entities BESI, USBESI -> 8044(I1B-5260)    
-I/C Rule to eliminate 8022 from Claims_BI_ODS and remove the fix from the View(I1B-5130)    
-Group share for 5623 to change in 2024(I1B-5116)    
-[EBG][Q1] BESI Written Premium & Brokerage(I1B-5080)    
-Pass date parameter to Transaction dataset runs(I1B-3887)    
Sprint 15<br/>
-Tactical to Strategic : BICI_RI_OverridingCommision (I1B-3847)<br/>
-RI% dataset RI Premium for BIDAC is not consistent with premium from Obligated RI Premium(I1B-5060)<br/>
-RI Spend Programme can be lower grain than Eurobase Programme(I1B-5059)<br/>
-[EBG][Q1] Core Treaty 623 Cede to BIDAC(I1B-5083)
