﻿/*
This will be executed during the pre-deployment phase.
Use it to apply scripts for all actions that cannot be easily and 
consistently done using just the database project.

Note that the pre-deployment scripts are just prepended to the
generated script.

!!!Make sure your scripts are idempotent(repeatable)!!!

Example invocation:
EXEC sp_execute_script @sql = 'UPDATE Table....', @author = 'Your Name'
*/
--=================================================================================================
--Change Version	: 1.0 
--Sprint			: BR1 Q3 24 committed
--Author			: lakshman.akasapu@beazley.com
--Modify Date	    : 2024-08-06 
--Description		: https://beazley.atlassian.net/browse/I1B-5328
--					  Drop tables and procedures scripts has written here
--=================================================================================================


DECLARE @SQL_RUN VARCHAR(8000)

SET @SQL_RUN = '
if exists(select 1 from sys.columns where [name]=''PatternName'' and [object_id] = OBJECT_ID(''[Outbound].[Pattern]''))
begin
	exec sp_rename ''[Outbound].[Pattern].[PatternName]'',''PatternKey'',''COLUMN''
end

if exists(select 1 from sys.columns where [name]=''PatternName'' and [object_id] = OBJECT_ID(''[Inbound].[Pattern]''))
begin
	exec sp_rename ''[Inbound].[Pattern].[PatternName]'',''PatternKey'',''COLUMN''
end
'
EXEC (@SQL_RUN)


IF Exists (SELECT * FROM FinanceDataContract.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'RIPercentage' and COLUMN_NAME IN ('GrossGrossUltimates','GN_RI%'))
BEGIN

Truncate table FinanceDataContract.Inbound.RIpercentage

ALTER TABLE FinanceDataContract.Inbound.RIpercentage
DROP COLUMN GrossGrossUltimates

ALTER TABLE FinanceDataContract.Inbound.RIpercentage
DROP COLUMN [GN_RI%]

Truncate table FinanceDataContract.Outbound.RIpercentage

ALTER TABLE FinanceDataContract.Outbound.RIpercentage
DROP COLUMN GrossGrossUltimates

ALTER TABLE FinanceDataContract.Outbound.RIpercentage
DROP COLUMN [GN_RI%]

END

/*  Drop BATCHID TABLE TYPE dependent obj and BATCHID TABLE TYPE*/

--IF NOT EXISTS(
--select c.name as COLUMN_NAME--, t.name as [TYPE_NAME], c.precision as [PRECISION], c.is_nullable as [NULLABLE], c.system_type_id, c.precision as [LENGTH]
--from sys.columns c, sys.types t
--where c.object_id = (select type_table_object_id from sys.table_types where name = 'BATCHID')
--and t.user_type_id = c.user_type_id and c.name='AsAt'
--)
--Begin

--IF (OBJECT_ID('Inbound.usp_InboundOutboundWorkflow_AccountNames', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Inbound.usp_InboundOutboundWorkflow_AccountNames;
--END;
--IF (OBJECT_ID('Inbound.usp_InboundOutboundWorkflow_AgressoARExtensions', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Inbound.usp_InboundOutboundWorkflow_AgressoARExtensions;
--END;
--IF (OBJECT_ID('Inbound.usp_InboundOutboundWorkflow_ClaimExtensions', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Inbound.usp_InboundOutboundWorkflow_ClaimExtensions;
--END;
--IF (OBJECT_ID('Inbound.usp_InboundOutboundWorkflow_DiscountRates', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Inbound.usp_InboundOutboundWorkflow_DiscountRates;
--END;
--IF (OBJECT_ID('Inbound.usp_InboundOutboundWorkflow_LossRatio', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Inbound.usp_InboundOutboundWorkflow_LossRatio;
--END;
--IF (OBJECT_ID('Inbound.usp_InboundOutboundWorkflow_PolicySectionReferences', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Inbound.usp_InboundOutboundWorkflow_PolicySectionReferences;
--END;
--IF (OBJECT_ID('Inbound.usp_InboundOutboundWorkflow_PremiumExtensions', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Inbound.usp_InboundOutboundWorkflow_PremiumExtensions;
--END;
--IF (OBJECT_ID('Inbound.usp_InboundOutboundWorkflow_ReInsuranceExtensions', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Inbound.usp_InboundOutboundWorkflow_ReInsuranceExtensions;
--END;
--IF (OBJECT_ID('Inbound.usp_InboundOutboundWorkflow_ReInsuranceQuotaSharePercentage', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Inbound.usp_InboundOutboundWorkflow_ReInsuranceQuotaSharePercentage;
--END;

--IF (OBJECT_ID('Inbound.usp_InboundOutboundWorkflow_ReInsuranceTreatyContractAttributes', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Inbound.usp_InboundOutboundWorkflow_ReInsuranceTreatyContractAttributes;
--END;

--IF (OBJECT_ID('Inbound.usp_InboundOutboundWorkflow_ReInsuranceTrifocusAllocationsTreaty', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Inbound.usp_InboundOutboundWorkflow_ReInsuranceTrifocusAllocationsTreaty;
--END;
--IF (OBJECT_ID('Inbound.usp_InboundOutboundWorkflow_Reserving_ReInsuranceExtensions', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Inbound.usp_InboundOutboundWorkflow_Reserving_ReInsuranceExtensions;
--END;
 
--IF (OBJECT_ID('Inbound.usp_InboundOutboundWorkflow', 'P') IS NOT NULL)BEGIN
--  DROP PROCEDURE Inbound.usp_InboundOutboundWorkflow;
--END;

--IF (OBJECT_ID('Inbound.usp_InboundOutboundWorkflow_Pattern', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Inbound.usp_InboundOutboundWorkflow_Pattern;
--END;

--IF (OBJECT_ID('Inbound.usp_InboundOutboundWorkflow_RIPercentage', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Inbound.usp_InboundOutboundWorkflow_RIPercentage;
--END;



--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ActualOutBoundBAIC', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ActualOutBoundBAIC;
--END;

--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ActualOutBoundBICI', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ActualOutBoundBICI;
--END;

--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ActualOutboundBIDAC', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ActualOutboundBIDAC;
--END;


--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ActualOutBoundUSSYND', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ActualOutBoundUSSYND;
--END;


--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ActualOutbound', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ActualOutbound;
--END;



--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ExpectedOutBoundBAIC', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ExpectedOutBoundBAIC;
--END;


--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ActualOutboundFDM', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ActualOutboundFDM;
--END;


--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ExpectedOutBoundBICI', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ExpectedOutBoundBICI;
--END;


--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ActualOutboundFDMCHE', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ActualOutboundFDMCHE;
--END;


--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ExpectedOutboundBIDAC', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ExpectedOutboundBIDAC;
--END;


--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ActualOutboundPFT', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ActualOutboundPFT;
--END;


--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ExpectedOutBoundUSSYND', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ExpectedOutBoundUSSYND;
--END;


--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ExpectedOutbound', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ExpectedOutbound;
--END;


--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ExpectedTechnicalHubBICI', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ExpectedTechnicalHubBICI;
--END;


--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ExpectedOutboundFDM', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ExpectedOutboundFDM;
--END;


--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ExpectedTechnicalHubBIDAC', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ExpectedTechnicalHubBIDAC;
--END;


--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ExpectedOutboundFDMCHE', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ExpectedOutboundFDMCHE;
--END;


--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ExpectedTechnicalHubUSBAIC', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ExpectedTechnicalHubUSBAIC;
--END;


--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ExpectedOutboundPFT', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ExpectedOutboundPFT;
--END;


--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ExpectedTechnicalHubUSSYND', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ExpectedTechnicalHubUSSYND;
--END;


--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ExpectedTechnicalHub', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ExpectedTechnicalHub;
--END;


--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ExpectedTechnicalHubFDM', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ExpectedTechnicalHubFDM;
--END;


--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ExpectedTechnicalHubFDMCHE', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ExpectedTechnicalHubFDMCHE;
--END;


--IF (OBJECT_ID('Test.usp_LogBatchAggregate_ExpectedTechnicalHubPFT', 'P') IS NOT NULL) BEGIN
--  DROP PROCEDURE Test.usp_LogBatchAggregate_ExpectedTechnicalHubPFT;
--END;
--	-------Drop table type-------------
	
--IF EXISTS(select type_table_object_id from sys.table_types where name = 'BATCHID') BEGIN

--DROP TYPE [dbo].[BatchID]

--END
	

--End


