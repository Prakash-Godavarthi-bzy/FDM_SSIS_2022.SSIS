﻿DECLARE @LocalInstance							NVARCHAR(2000) = '$(TargetInstanceName)'
DECLARE @ServerName_SMTP						NVARCHAR(2000) = '$(Parameter_SMTP)'
DECLARE @ServerName_FinanceDataMart				NVARCHAR(2000) = '$(Parameter_FinanceDataMart)'


DECLARE @ReferenceID INT = 0
WHILE EXISTS	(SELECT	* FROM	ssisdb.catalog.environment_references r WHERE	r.environment_name = 'FinanceDataContractEnvironment' AND r.reference_id > @ReferenceID)
BEGIN
	SELECT	@ReferenceID = MIN(reference_id)
	FROM	ssisdb.catalog.environment_references r
	WHERE	r.environment_name = 'FinanceDataContractEnvironment'
		AND reference_id > @ReferenceID
	
	EXEC SSISDB.catalog.delete_environment_reference @ReferenceID
END

IF EXISTS (SELECT * FROM SSISDB.catalog.environments WHERE Name = 'FinanceDataContractEnvironment') 
	EXEC [SSISDB].[catalog].[delete_environment] @folder_name = 'FinanceDataContract', @Environment_Name = 'FinanceDataContractEnvironment'

EXEC [SSISDB].[catalog].[create_environment] @folder_name = 'FinanceDataContract', @Environment_Name = 'FinanceDataContractEnvironment'

SET @ReferenceID = NULL
EXEC [SSISDB].[catalog].[create_environment_reference] @folder_name = N'FinanceDataContract', @project_name = N'FinanceDataContract.SSIS', @environment_name = N'FinanceDataContractEnvironment', @Reference_type = 'R', @reference_id = @ReferenceID

EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceDataContractEnvironment',	@variable_name=N'ServerName_FinanceDataContract', @sensitive=False, @folder_name=N'FinanceDataContract', @value=@LocalInstance, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceDataContractEnvironment',	@variable_name=N'ServerName_FinanceDataMart', @sensitive=False, @folder_name=N'FinanceDataContract', @value=@ServerName_FinanceDataMart, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceDataContractEnvironment',	@variable_name=N'ServerName_FinanceLanding', @sensitive=False, @folder_name=N'FinanceDataContract', @value=@LocalInstance, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceDataContractEnvironment',	@variable_name=N'ServerName_Orchestram', @sensitive=False, @folder_name=N'FinanceDataContract', @value=@LocalInstance, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FinanceDataContractEnvironment',	@variable_name=N'ServerName_SMTP', @sensitive=False, @folder_name=N'FinanceDataContract', @value=@ServerName_SMTP, @data_type=N'String'

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_FinanceDataContract',	@object_name=N'FinanceDataContract.SSIS', @folder_name=N'FinanceDataContract', @project_name=N'FinanceDataContract.SSIS', @value_type=R, @parameter_value=N'ServerName_FinanceDataContract'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_FinanceDataMart',		@object_name=N'FinanceDataContract.SSIS', @folder_name=N'FinanceDataContract', @project_name=N'FinanceDataContract.SSIS', @value_type=R, @parameter_value=N'ServerName_FinanceDataMart'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_FinanceLanding',			@object_name=N'FinanceDataContract.SSIS', @folder_name=N'FinanceDataContract', @project_name=N'FinanceDataContract.SSIS', @value_type=R, @parameter_value=N'ServerName_FinanceLanding'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_Orchestram',				@object_name=N'FinanceDataContract.SSIS', @folder_name=N'FinanceDataContract', @project_name=N'FinanceDataContract.SSIS', @value_type=R, @parameter_value=N'ServerName_Orchestram'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_SMTP',					@object_name=N'FinanceDataContract.SSIS', @folder_name=N'FinanceDataContract', @project_name=N'FinanceDataContract.SSIS', @value_type=R, @parameter_value=N'ServerName_SMTP'

