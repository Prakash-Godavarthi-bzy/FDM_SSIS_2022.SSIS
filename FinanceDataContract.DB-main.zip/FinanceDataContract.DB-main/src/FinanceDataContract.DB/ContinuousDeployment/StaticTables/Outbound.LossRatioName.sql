﻿USE [FinanceDataContract]
GO
SET NOCOUNT ON 
GO
SET IDENTITY_INSERT [Outbound].[LossRatioName] ON 
GO

MERGE INTO [Outbound].[LossRatioName] AS Target

USING (VALUES

              (1,  'XLS.LossRatio',	'LR-G-CM',	'Loss Ratio - Cat Margin',	NULL)

       )AS Source ([PK_LossRatioName], [Table], [LossRatioAccount], [LossRatioName], [LossRatioScenario])
			
ON (Target.[PK_LossRatioName] = Source.[PK_LossRatioName])

WHEN MATCHED THEN 

UPDATE SET  [Table]              = Source.[Table]
           ,[LossRatioAccount]   = Source.[LossRatioAccount]
		   ,[LossRatioName]      = Source.[LossRatioName]
		   ,[LossRatioScenario]  = Source.[LossRatioScenario]
		   
WHEN NOT MATCHED BY TARGET THEN

INSERT ([PK_LossRatioName], [Table], [LossRatioAccount], [LossRatioName], [LossRatioScenario])
VALUES (Source.[PK_LossRatioName], Source.[Table], Source.[LossRatioAccount], Source.[LossRatioName], Source.[LossRatioScenario])
		   
WHEN NOT MATCHED BY SOURCE THEN DELETE;

GO                                                                                                                                                                                                       
DECLARE @mergeError int                                                                                                                                                                                  
       ,@mergeCount int                                                                                                                                                                                       
SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT                                                                                                                                                   
IF @mergeError != 0                                                                                                                                                                                      
 BEGIN                                                                                                                                                                                                   
 PRINT 'ERROR OCCURRED IN MERGE FOR [Outbound].[LossRatioName]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); -- SQL should always return zero rows affected                           
 END                                                                                                                                                                                                     
ELSE                                                                                                                                                                                                     
 BEGIN                                                                                                                                                                                                   
 PRINT '[Outbound].[LossRatioName] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));                                                                                              
 END                                                                                                                                                                                                     
GO                                                                                                                                                                                                       
                                                                                                                                                                                                         
SET IDENTITY_INSERT [Outbound].[LossRatioName] OFF                                                                                                                                             
GO                                                                                                                                                                                                       
SET NOCOUNT OFF                                                                                                                                                                                          
GO     
