﻿USE [FinanceDataContract]
GO
SET NOCOUNT ON 
GO

MERGE INTO [Outbound].[PatternName] AS Target

USING (VALUES

             ('C-GC-NE',  'Gross Claims Nat Cat Margin Earnings Pattern')

             ,('C-GC-PP',  'Gross Claims Payment Pattern')
             ,('P-GP-PP',  'Gross Premium Payment Pattern')
             ,('P-GP-BP',  'Brokerage Payment Pattern')
             ,('C-RC-PP',  'RI Claims Payment Pattern')
             ,('P-RP-PP',  'RI Premium Payment Pattern')

       )AS Source (  [PatternKey], [patternnames])
			
ON (Target.[PatternKey] = Source.[PatternKey])

WHEN MATCHED and Target.[patternnames] != Source.[patternnames] THEN 
UPDATE SET  [patternnames] = Source.[patternnames]
		   
WHEN NOT MATCHED BY TARGET THEN
INSERT ( [PatternKey], [patternnames])
VALUES (Source.[PatternKey], Source.[patternnames])
		   
WHEN NOT MATCHED BY SOURCE THEN DELETE;

GO                                                                                                                                                                                                       
DECLARE @mergeError int                                                                                                                                                                                  
       ,@mergeCount int                                                                                                                                                                                       
SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT                                                                                                                                                   
IF @mergeError != 0                                                                                                                                                                                      
 BEGIN                                                                                                                                                                                                   
 PRINT 'ERROR OCCURRED IN MERGE FOR [Outbound].[PatternName]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); -- SQL should always return zero rows affected                           
 END                                                                                                                                                                                                     
ELSE                                                                                                                                                                                                     
 BEGIN                                                                                                                                                                                                   
 PRINT '[Outbound].[PatternName] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));                                                                                              
 END                                                                                                                                                                                                     
GO                                                                                                                                                                                                       

SET NOCOUNT OFF                                                                                                                                                                                          
GO     
