﻿CREATE TYPE [log].[utt_ActivityLog] AS TABLE (
    [ID]                      INT            IDENTITY (1, 1) NOT NULL,
    [LogDate]                 DATETIME2 (0)  DEFAULT (getdate()) NULL,
    [ActivityName]            VARCHAR (50)   DEFAULT (object_name(@@procid)) NULL,
    [RowsAffected]            INT            DEFAULT (@@rowcount) NULL,
    [ActivityStatus]          INT            NULL,
    [ActivitySSISExecutionId] INT            NULL,
    [ActivityMessage]         VARCHAR (4000) NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC));