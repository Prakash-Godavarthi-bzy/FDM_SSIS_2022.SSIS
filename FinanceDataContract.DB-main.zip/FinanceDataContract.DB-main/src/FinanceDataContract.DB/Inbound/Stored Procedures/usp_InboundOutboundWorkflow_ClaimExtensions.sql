﻿CREATE PROCEDURE [Inbound].[usp_InboundOutboundWorkflow_ClaimExtensions]
AS
-- =============================================

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	2021-05-26
-- Changes:				Removed the section reference from the extensions table, and made changes for the table rename LargeLossCatCode to CatCode.

-- =============================================	

BEGIN

	set nocount on

	DECLARE @Logging	log.utt_ActivityLog;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Trancount INT = @@Trancount;
	DECLARE @BatchID_ClaimCentreLargeLoss AS BATCHID;
	DECLARE @BatchID_LargeLossCatCode AS BATCHID;


	INSERT @Logging(ActivityStatus, ActivityName) SELECT 1, @p_ActivityName;
	
	BEGIN TRY

		IF @Trancount = 0 BEGIN TRAN;

		--update q
		--SET [Status] = 'InBound' -- 
		----select *
		--FROM Inbound.BatchQueue q 
		--where DataSet='ClaimCentreExtensions' and Pk_Batch=4360
		
		--SELECT * FROM Inbound.BatchQueue WHERE DataSet = 'ClaimCentreExtensions'
		-- Status = 'InBound' AND 

		IF EXISTS (SELECT Pk_Batch FROM Inbound.BatchQueue WHERE Status = 'InBound' AND DataSet = 'ClaimCentreExtensions')
		BEGIN

			/*=============================================================================================
         	Select Pending BatchID 
			==============================================================================================*/

			INSERT INTO @BatchID_ClaimCentreLargeLoss
			SELECT	Pk_Batch
					,DataSet
					,AsAt
			FROM	Inbound.BatchQueue
			WHERE	[Status] = 'InBound'
			AND     DataSet in ('ClaimCentreExtensions')--, 'ClaimCentreLargeLoss');
			
			RAISERROR('@BatchID_ClaimCentreExtensions: %i', 0, 0, @@rowcount) WITH NOWAIT;

			---set batch status to running from Pending
			UPDATE		bq
			SET			[Status] = 'Running'
			FROM		Inbound.BatchQueue	bq
			INNER JOIN	@BatchID_ClaimCentreLargeLoss bi 
				ON  bq.Pk_Batch = bi.PK_BatchID
				

			RAISERROR('Running: %i', 0, 0, @@rowcount) WITH NOWAIT;
				 
			
            INSERT INTO Outbound.[Transaction_Claim_Extensions_Bridge] WITH(TABLOCK)
			( 
				[RowHash_Transaction]
				,[RowHash_Transaction_Claim_Extensions]
	            ,[FK_Batch]
			)
			SELECT 
				 p.[RowHash_Transaction] 
				,p.[RowHash_Transaction_Claim_Extensions]
				,p.[FK_Batch]
			FROM   
				[Inbound].Transaction_Claim_Extensions_Bridge p
				JOIN @BatchID_ClaimCentreLargeLoss b ON b.PK_BatchID = p.FK_Batch
				LEFT JOIN Outbound.[Transaction_Claim_Extensions_Bridge] t 
					ON  t.[RowHash_Transaction] = p.[RowHash_Transaction]
					AND t.[RowHash_Transaction_Claim_Extensions] = p.[RowHash_Transaction_Claim_Extensions]
			WHERE
				t.[RowHash_Transaction] is null

			RAISERROR('[Outbound].[Transaction_Claim_Extensions_Bridge]: %i', 0, 0, @@rowcount) WITH NOWAIT;

			--print 'INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)'
			--select len('Inbound.usp_InboundOutboundWorkflow_ClaimExtensions'), len('Process Inbound to outbound for Transaction_Claim_Extensions_Bridge')

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, 'Inbound.usp_InboundOutboundWorkflow_ClaimExtens...', 'Process Inbound to outbound for Transaction_Claim_Extensions_Bridge';

			--print 'INSERT INTO Outbound.Transaction_Claim_Extensions WITH(TABLOCK)'

            INSERT INTO Outbound.Transaction_Claim_Extensions WITH(TABLOCK)
			( 
				 [RowHash_Transaction_Claim_Extensions]
				,[DateOfLoss]
				,[SourceSystem]
				,[PolicySourceSystem]
				,[UnderwritingPlatformCode]
				,[UnderwritingPlatformName]
				,[UWOfficeLocation]
				,[MovementType]
				,[TransactionTrackingStatus]
				,[InsuredState]
				,[InsuredCountry]
				,[BeazleyCatCode]
				,[IsLargeLossClaim]
				,[FK_Batch]
				,[MovementDate]
				,[ExposureReference]
				,[SCMReference]
				,[ClaimReference]
			)
			SELECT 
				 p.[RowHash_Transaction_Claim_Extensions]
				,p.[DateOfLoss]
				,p.[SourceSystem]
				,p.[PolicySourceSystem]
				,p.[UnderwritingPlatformCode]
				,p.[UnderwritingPlatformName]
				,p.[UWOfficeLocation]
				,p.[MovementType]
				,p.[TransactionTrackingStatus]
				,p.[InsuredState]
				,p.[InsuredCountry]
				,p.[BeazleyCatCode]
				,p.[IsLargeLossClaim]
				,p.[FK_Batch]
				,p.[MovementDate]
				,p.[ExposureReference]
				,p.[SCMReference]
				,p.[ClaimReference]
			FROM   
				[Inbound].Transaction_Claim_Extensions p
				JOIN @BatchID_ClaimCentreLargeLoss b ON b.PK_BatchID = p.FK_Batch
				LEFT JOIN Outbound.Transaction_Claim_Extensions t 
					ON  t.[RowHash_Transaction_Claim_Extensions] = p.[RowHash_Transaction_Claim_Extensions]
			WHERE
				t.[RowHash_Transaction_Claim_Extensions] is null

			RAISERROR('[Outbound].[Transaction_Claim_Extensions]: %i', 0, 0, @@rowcount) WITH NOWAIT;

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, 'Inbound.usp_InboundOutboundWorkflow_ClaimExtens...', 'Process Inbound to outbound for Transaction_Claim_Extensions';


			/*=============================================================================================
					Delete data from inbound where batchID Has been processed to outbound and Change S
			==============================================================================================*/

			DELETE I FROM [Inbound].Transaction_Claim_Extensions_Bridge I JOIN @BatchID_ClaimCentreLargeLoss B ON B.PK_BatchID = I.[FK_Batch];
			DELETE I FROM [Inbound].Transaction_Claim_Extensions I JOIN @BatchID_ClaimCentreLargeLoss B ON B.PK_BatchID = I.[FK_Batch];

			---Change status to Complete from running
			UPDATE	bq
			SET		[Status] = 'Outbound'
			FROM	Inbound.BatchQueue	bq
			JOIN	@BatchID_ClaimCentreLargeLoss bi 
				ON  bq.Pk_Batch = bi.PK_BatchID
				

			RAISERROR('Completed Transaction_Claim_Extensions: %i', 0, 0, @@rowcount) WITH NOWAIT;

		END;

		declare @DataSetCC char(7) = 'CatCode'

		IF EXISTS (SELECT Pk_Batch FROM Inbound.BatchQueue WHERE Status = 'InBound' AND DataSet = @DataSetCC)
		BEGIN

			/*=============================================================================================
         	Select Pending BatchID 
			==============================================================================================*/

			INSERT INTO @BatchID_LargeLossCatCode
			SELECT	Pk_Batch
					,DataSet
					,AsAt
			FROM	Inbound.BatchQueue
			WHERE	[Status] = 'InBound'
			AND     DataSet = @DataSetCC;
			
			RAISERROR('@BatchID_CatCode: %i', 0, 0, @@rowcount) WITH NOWAIT;

			---set batch status to running from Pending
			UPDATE		bq
			SET			[Status] = 'Running'
			FROM		Inbound.BatchQueue	bq
			INNER JOIN	@BatchID_LargeLossCatCode bi 
				ON  bq.Pk_Batch = bi.PK_BatchID
				

			RAISERROR('Running: %i', 0, 0, @@rowcount) WITH NOWAIT;
				 
			
			update t
			set 
				 [MarketCatCode] = p.[MarketCatCode]
				,[BeazleyCatDesription] = p.[BeazleyCatDesription]
				,[BeazleySpecial] = p.[BeazleySpecial]
				,[EventYear] = p.[EventYear]
				,[BeazleyEventName] = p.[BeazleyEventName]
				,[LargeLossIndicator] = p.[LargeLossIndicator]
				,[AuditSourceBatchID] = p.FK_Batch
				,[AuditGenerateDateTime] = GETUTCDATE()
				,[FK_Batch] = t.[FK_Batch]
				,[DataSet] = b.[DataSet] 
			from	
				[Outbound].[CatCode] t
				join [Inbound].[CatCode] p on p.BeazleyCatCode = t.BeazleyCatCode
				join @BatchID_LargeLossCatCode b ON b.PK_BatchID = p.FK_Batch
			where
				   1 = case
						when t.[MarketCatCode] = p.[MarketCatCode] then 0
						when t.[MarketCatCode] is null and p.[MarketCatCode] is null then 0
						else 1
						end
				or 
				   1 = case
						when t.[BeazleyCatDesription] = p.[BeazleyCatDesription] then 0
						when t.[BeazleyCatDesription] is null and p.[BeazleyCatDesription] is null then 0
						else 1
						end
				or 
				   1 = case
						when t.[BeazleySpecial] = p.[BeazleySpecial] then 0
						when t.[BeazleySpecial] is null and p.[BeazleySpecial] is null then 0
						else 1
						end
				or 
				   1 = case
						when t.[EventYear] = p.[EventYear] then 0
						when t.[EventYear] is null and p.[EventYear] is null then 0
						else 1
						end
				or 
				   1 = case
						when t.[BeazleyEventName] = p.[BeazleyEventName] then 0
						when t.[BeazleyEventName] is null and p.[BeazleyEventName] is null then 0
						else 1
						end
				or 
				   1 = case
						when t.[LargeLossIndicator] = p.[LargeLossIndicator] then 0
						when t.[LargeLossIndicator] is null and p.[LargeLossIndicator] is null then 0
						else 1
						end
				or 
				   t.[DataSet] != @DataSetCC

			RAISERROR('[Outbound].[CatCode] update: %i', 0, 0, @@rowcount) WITH NOWAIT;


			INSERT INTO [Outbound].[CatCode] WITH(TABLOCK)
			(
				[MarketCatCode]
				,[BeazleyCatCode]
				,[BeazleyCatDesription]
				,[BeazleySpecial]
				,[EventYear]
				,[BeazleyEventName]
				,[LargeLossIndicator]
				,[AuditSourceBatchID]
				,[AuditGenerateDateTime]
				,[FK_Batch]
				,[DataSet]
			)
			SELECT 
				p.[MarketCatCode]
				,p.[BeazleyCatCode]
				,p.[BeazleyCatDesription]
				,p.[BeazleySpecial]
				,p.[EventYear]
				,p.[BeazleyEventName]
				,p.[LargeLossIndicator]
				,[AuditSourceBatchID] = p.FK_Batch
				,[AuditGenerateDateTime] = GETUTCDATE()
				,p.[FK_Batch]
				,b.[DataSet] 
			FROM   
				[Inbound].[CatCode] p
				join @BatchID_LargeLossCatCode b ON b.PK_BatchID = p.FK_Batch
				left join [Outbound].[CatCode] t on t.BeazleyCatCode = p.BeazleyCatCode
			WHERE
				t.BeazleyCatCode is null
							   			

			RAISERROR('[Outbound].[CatCode] insert: %i', 0, 0, @@rowcount) WITH NOWAIT;

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, 'Inbound.usp_InboundOutboundWorkflow_ClaimExtens...', 'Process Inbound to outbound for CatCode';


			/*=============================================================================================
					Delete data from inbound where batchID Has been processed to outbound and Change S
			==============================================================================================*/

			DELETE I FROM [Inbound].[CatCode] I JOIN @BatchID_LargeLossCatCode B ON B.PK_BatchID = I.[FK_Batch];

			UPDATE	bq
			SET		[Status] = 'Outbound'
			FROM	Inbound.BatchQueue	bq
			JOIN	@BatchID_LargeLossCatCode bi 
				ON  bq.Pk_Batch = bi.PK_BatchID
				

			RAISERROR('Completed CatCode: %i', 0, 0, @@rowcount) WITH NOWAIT;

		END;

		-- LOGIN THE RESULT WITH SUCCESS
		INSERT @Logging(ActivityStatus, ActivityName) SELECT 2 , @p_ActivityName;

		--Generate logging for success
		EXEC log.usp_LogContract @Input = @Logging;

		IF @Trancount = 0 COMMIT;

	END TRY
	BEGIN CATCH

		IF @Trancount = 0 ROLLBACK;

		-----On error Change status to failed from running
		UPDATE		q
		SET			Status = 'OutBoundFailed'
		FROM		Inbound.BatchQueue	q
		INNER JOIN	@BatchID_ClaimCentreLargeLoss B ON q.Pk_Batch = B.PK_BatchID;

		UPDATE		q
		SET			Status = 'OutBoundFailed'
		FROM		Inbound.BatchQueue	q
		INNER JOIN	@BatchID_LargeLossCatCode B ON q.Pk_Batch = B.PK_BatchID;

		-- LOG THE RESULT WITH ERROR
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 4, 'Inbound.usp_InboundOutboundWorkflow_ClaimExtens...', ERROR_MESSAGE();

		EXEC log.usp_LogContract @Input = @Logging;

		THROW;

	END CATCH;
END
GO

--exec [Inbound].[usp_InboundOutboundWorkflow_ClaimExtensions]
