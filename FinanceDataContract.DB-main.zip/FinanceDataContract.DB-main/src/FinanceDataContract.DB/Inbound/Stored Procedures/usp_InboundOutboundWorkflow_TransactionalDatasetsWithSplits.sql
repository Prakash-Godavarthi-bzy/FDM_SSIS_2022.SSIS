CREATE PROCEDURE [Inbound].[usp_InboundOutboundWorkflow_TransactionalDatasetsWithSplits]
	@DoNonIFRS17_Tests bit = 0
	,@Transactionaldate datetime =NULL
/*
--============================================================



-- Modified by:			pavani.bandaru@beazley.com
-- Modification date:	10-08-2023
-- Changes:				https://beazley.atlassian.net/browse/I1B-2765

--Change Version	: 1.0 
--Sprint			: BR1 Q3 24 committed
--Author			: lakshman.akasapu@beazley.com
--Modify Date	?   : 2024-08-05 
--Description		: https://beazley.atlassian.net/browse/I1B-5328
						--Removed the procedures that were not using anymore
						--[Test].[usp_LogBatchAggregate_ActualOutboundFDMCHE]
						--[Test].[usp_LogBatchAggregate_ExpectedTechnicalHubUSSYND]

Modified by : Venkat.yerravati@beazley.com
Modification Date : 06-11-2024
Sprint : BR1 24Q4  Committed
Description : capturing the programmecode change and allocate the reversals to the original period

-- ==================================================================*/
AS
BEGIN
	--SET NOCOUNT ON;

	DECLARE @Trancount	INT = @@Trancount;

	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;
	DECLARE @p_Account NVARCHAR(255) = NULL;
	DECLARE @p_SourceSystem NVARCHAR(255) = NULL;
	DECLARE @CurrentDate DATETIME2	= GETDATE();
	DECLARE @BatchID AS BatchID;

	INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
	SELECT 1, @p_ActivityName, 'Inbound OutBound Workflow  Started';

	BEGIN TRY
		IF @Trancount = 0 
		BEGIN TRAN;
		IF EXISTS (SELECT Pk_Batch FROM Inbound.BatchQueue WHERE Status = 'InBound')
			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, 'TransactionalDatasets CDC', 'Pending  batches are being checked';
		BEGIN

			/*=============================================================================================
							Genrate Hashrow for inbound
		 ==============================================================================================*/

			--EXEC Inbound.usp_GenerateHashRow @p_SourceSystem, @p_Account;

			--INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			--SELECT 5, '[Inbound].[usp_InboundOutboundWorkflow]', 'Genrate Hashrow for inbound created';

			/*=============================================================================================
         					Select Pending BatchID 
			==============================================================================================*/

			--DECLARE @BatchID AS BatchID;
			INSERT @BatchID 
			SELECT	Pk_Batch, 
					[DataSet],
					AsAt
			FROM	Inbound.BatchQueue 
			WHERE	Status = 'InBound'
				AND (RunDescription = 'Baseload' OR RunDescription IS NULL);

			--declare @AsAt int
			--select @AsAt=ASAT from 	Inbound.BatchQueue 
			--WHERE	Status = 'InBound'
			--	AND (RunDescription = 'Baseload' OR RunDescription IS NULL);


			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, 'TransactionalDatasets CDC', 'Select Pending BatchID ';
			
			---set batch status to running from Pending
			UPDATE		q
			SET			Status = 'Running'
			FROM		Inbound.BatchQueue	q
			INNER JOIN	@BatchID B ON q.Pk_Batch = B.PK_BatchID;
			

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, 'TransactionalDatasets CDC', 'Batches are set to Running ';

			/*=============================================================================================
         					LogOutboundExpected Results
			==============================================================================================*/

			--if @DoNonIFRS17_Tests = 1
			--begin

			--	EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_ExpectedOutbound] @BatchID;
			--	--EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_ExpectedOutboundPFT] @BatchID; /*Commented it for I1B-1011*/
			--	EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_ExpectedOutboundFDM] @BatchID;
			--	EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_ExpectedOutboundFDMCHE] @BatchID;
				
			--	EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_ExpectedOutBoundBICI] @BatchID;
			--	EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_ExpectedOutBoundBAIC] @BatchID;
			--	EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_ExpectedOutBoundUSSYND] @BatchID;
			--	EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_ExpectedOutboundBIDAC] @BatchID;


			
			--	INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			--	SELECT 5, '[Inbound].[usp_InboundOutboundWorkflow]', 'LogOutboundExpected Results';

			--end

			/*=============================================================================================
					Process Inbound to outbound
			==============================================================================================*/
			


				/*
				=================================================================================================
				       Create CTE's and Temp tables for Inbound and Outbound
				=================================================================================================
				
				*/
			--	DECLARE @BatchID AS BatchID;
			--INSERT @BatchID 
			--DROP TABLE IF EXISTS #TEMP1
			--SELECT	Pk_Batch as PK_batchID, 
			--		[DataSet] 
			--		into #temp1
			--FROM	Inbound.BatchQueue 
			--WHERE	Status = 'InBound'
			--	AND (RunDescription = 'Baseload' OR RunDescription IS NULL);

			--DROP TABLE IF EXISTS #TEMP
			--SELECT	Pk_Batch AS PK_BatchID, 
			--		OriginalName,DataSet INTO #TEMP
			--FROM	Inbound.BatchQueue  
			--WHERE	--Status = 'InBound'
			--Status = 'Running' 
			--	AND (RunDescription = 'Baseload' OR RunDescription IS NULL);

			drop table if exists	#temp_IB
			
				;With Inbound as
				(
				SELECT			SumofInbound				= SUM([Value])
											,I.Scenario
											,I.Account
											,I.[Dataset]
											,I.DateOfFact
											,I.BusinessKey
											,I.PolicyNumber
											,I.InceptionDate
											,I.ExpiryDate
											,I.BindDate
											,I.DueDate
											,I.[BoundDate]
											,I.TrifocusCode
											,I.Entity
											,I.StatsCode
											,I.YOA
											,I.TypeOfBusiness
											,I.SettlementCCY
											,I.OriginalCCY
											,I.IsToDate
											,I.RowHash
											,I.FK_Allocation
											,AuditSourceBatchID		= ISNULL(I.AuditSourceBatchID, B.PK_BatchID)
											,AuditGenerateDateTime	= MAX(I.AuditGenerateDateTime)
											,I.AuditHost
											,I.[Basis]
											,I.[Location]
											,OrigSumofInbound		= SUM(I.[ValueOrig])
											,BusinessProcessCode	= (I.[BusinessProcessCode])
											,FK_Batch				= MAX(I.[FK_Batch])
											,B.ASAT

							FROM			Inbound.[Transaction]														AS I
							INNER JOIN		@BatchID																	AS B ON I.AuditSourceBatchID = B.PK_BatchID
																															AND I.[Dataset] = B.DataSet
							GROUP BY Scenario
									,Account
									,I.[Dataset]
									,DateOfFact
									,BusinessKey
									,PolicyNumber
									,InceptionDate
									,ExpiryDate
									,BindDate
									,DueDate
									,I.[BoundDate]
									,TrifocusCode
									,Entity
									,StatsCode
									,YOA
									,TypeOfBusiness
									,SettlementCCY
									,OriginalCCY
									,IsToDate
									,I.RowHash
									,AuditSourceBatchID
									,AuditHost
									,B.PK_BatchID
									,I.FK_Allocation
									,I.[Basis]
									,I.[Location]
									,I.DeltaType
									,B.ASAT
									,I.[BusinessProcessCode]
											
									Having SUM(Value)<>0
									) 
	Select * into #temp_IB from Inbound 

	DRop table if exists #IB_BPC --5897

	select distinct BusinessProcessCode into #IB_BPC from #temp_IB; --5897


	drop table if exists	#temp_oB
	;with  Outbound as 
	(
	SELECT			Sumofoutbound		= SUM([Value])
											,Scenario
											,Account
											,o.[Dataset]
											,DateOfFact		= MAX(DateOfFact)
											,BusinessKey
											,PolicyNumber
											,InceptionDate
											,ExpiryDate
											,BindDate
											,DueDate
											,o.[BoundDate]
											,TrifocusCode
											,Entity
											,StatsCode
											,YOA
											,TypeOfBusiness
											,SettlementCCY
											,OriginalCCY
											,IsToDate
											,RowHash
										--	,o.FK_Allocation
											,B.PK_BatchID
											,o.[Basis]
											,o.[Location]
											,OrigSumofOutbound		= SUM(o.[ValueOrig])
											,BusinessProcessCode	= (o.[BusinessProcessCode])
											,FK_Batch				= MAX(o.[FK_Batch])
											--						
							FROM			
								Outbound.[Transaction]	o

								JOIN Inbound.BatchQueue BQ 
									ON  BQ.Pk_Batch = o.AuditSourceBatchID 
									AND BQ.DataSet = o.Dataset
								Join @BatchID B ON o.DataSet=B.DataSet and BQ.DataSet=B.Dataset

							WHERE			
								IsToDate = 'N'
							GROUP BY Scenario
									,Account
									,o.[Dataset]
									,BusinessKey
									,PolicyNumber
									,InceptionDate
									,ExpiryDate
									,BindDate
									,DueDate
									,o.[BoundDate]
									,TrifocusCode
									,Entity
									,StatsCode
									,YOA
									,TypeOfBusiness
									,SettlementCCY
									,OriginalCCY
									,IsToDate
									,RowHash
								--	,o.FK_Allocation
									,B.PK_BatchID
									,o.[Basis]
									,o.[Location]
									,o.[BusinessProcessCode]

							HAVING			
								SUM([Value]) <> 0 ---Don't process Hashrows that already been processed as deleted or missing 
									
	)


	Select * into #temp_OB from Outbound;

	DRop table if exists #OB_BPC

	select distinct BusinessProcessCode into #OB_BPC from #temp_OB

	drop table if exists #outbound_Rowhash
	select BusinessProcessCode,min(dateoffact) dateoffact
	into #outbound_Rowhash
	from FinanceDataContract.Outbound.[Transaction]
	where deltatype in ('New','Restatement')
	group by BusinessProcessCode;
	/*
	==========================================================================================================================
	          Fetch New And Adjustments Records
	==========================================================================================================================

	select *
	from #temp_IB where  PolicyNumber='W0000151418P_PC' and Account='P-GP-P'

	select *
	from #temp_OB where PolicyNumber='W0000151418P_PC' and Account='P-GP-P'
		
	*/

		Drop table if exists #IB_BK

	select distinct BusinessKey into #IB_BK from #temp_IB; --5897

	drop table if exists #temp_OutboundTransactions
	Select * Into #temp_OutboundTransactions from 
	   (
	   SELECT * FROM
	   (
			select 
			I.Scenario, 
			I.Account, 
			I.[Dataset],
			--I.ASAT,
			--I.DateOfFact,

			case 
			      when I.Dataset  in ('RI LPSO TTY','ReinsuranceRebates_Paid','Signed Profit Commission') and  O.BusinessKey is   null and I.BusinessKey is not null and  I.BusinessProcessCode=B.BusinessProcessCode then CAST(@Transactionaldate as date)
			      when O.BusinessKey is  null and I.BusinessKey is not null   then I.DateOfFact 
			      when O.BusinessKey=I.BusinessKey and O.RowHash=I.RowHash  then cast(@Transactionaldate as date)--I.ASAT
				  End as DateOfFact,

			I.BusinessKey, 
			I.PolicyNumber, 
			I.InceptionDate, 
			I.ExpiryDate
			,I.BindDate
			,I.DueDate
			,I.[BoundDate]
			,I.TrifocusCode
			,I.Entity
			,I.StatsCode
			,I.YOA
			,I.TypeOfBusiness
			,I.SettlementCCY
			,I.OriginalCCY
			,I.IsToDate
			--,I.[Value]
			,I.RowHash
			,I.FK_Allocation
			,I.AuditSourceBatchID
			,I.AuditGenerateDateTime
			,I.AuditHost
		--	,I.DeltaType
			,I.[Basis]
			,I.[Location]
			--,I.[ValueOrig]
			,I.[BusinessProcessCode]
			,I.[FK_Batch]
						
			,sum(I.SumofInbound) as IB_Val
		    ,sum(O.Sumofoutbound) as OB_Val
			,sum(ISNULL(I.SumofInbound,0))-sum(ISNULL(O.SumofOutbound,0)) as val
			,sum(ISNULL(I.OrigSumofInbound, 0.0000)) -sum( ISNULL(O.OrigSumofOutbound, 0.0000)) as ValueOrig
			,O.PolicyNumber as OB_PolicyNumber 
	     	,O.BusinessKey as OBBK, O.RowHash  OBRH
			,case 
			      when O.BusinessKey is  null and I.BusinessKey is not null  then 'New' 
			      when O.BusinessKey=I.BusinessKey and O.RowHash=I.RowHash  then 'Adjustment'
								
			End as Deltatype
				
			From #temp_IB I
			LEFT JOIN #temp_OB O ON O.BusinessKey=I.BusinessKey
			LEft Join #OB_BPC   B ON RTRIM(LTRIM(I.BusinessProcessCode))=RTRIM(LTRIM(B.BusinessProcessCode))
			--where  I.BusinessKey='P-OR-P-TTY|R0139M16|2623|2016|EUR|768'
			Group by 
			
			I.BusinessKey 
			,I.RowHash 
			,O.BusinessKey 
			,O.RowHash  
			,O.PolicyNumber
			,I.Scenario 
			,I.Account
			,I.[Dataset]
			,I.DateOfFact
			,I.PolicyNumber 
			,I.InceptionDate
			,I.ExpiryDate
			,I.BindDate
			,I.DueDate
			,I.[BoundDate]
			,I.TrifocusCode
			,I.Entity
			,I.StatsCode
			,I.YOA
			,I.TypeOfBusiness
			,I.SettlementCCY
			,I.OriginalCCY
			,I.IsToDate
			--,I.[Value]
			--,I.RowHash
			,I.FK_Allocation
			,I.AuditSourceBatchID
			,I.AuditGenerateDateTime
			,I.AuditHost
		--	,I.DeltaType
			,I.[Basis]
			,I.[Location]
			--,I.[ValueOrig]
			,I.[BusinessProcessCode]
			,B.BusinessProcessCode
			,I.[FK_Batch]
			--,I.ASAT
		Having sum(ISNULL(I.SumofInbound,0))-sum(ISNULL(O.SumofOutbound,0))<>0
		) AS F WHERE F.Deltatype IS NOT NULL
		/*
		=================================================================================================================
		Fetch Reversals (including restatement reversals)
		=================================================================================================================
		*/
	Union All

		Select * from (									
			Select
			O.Scenario
			,O.Account
			,O.[Dataset]
			--,B1.ASAT
			
			,DateOfFact				= case when B.BusinessProcessCode is null and bk.BusinessKey is null  then n.DateOfFact --5897
										   else CAST(@Transactionaldate as date)--convert(date, cast(B1.ASAT as varchar) + '01')
									  end
			
			
			--,DateOfFact				= case when Left(Replace(convert(date,O.InceptionDate,105),'-',''),6) < cast(B1.ASAT as int) 
			--											then eomonth(convert(date, cast(B1.ASAT as varchar) + '01'))
			--											else O.InceptionDate
			--										END 
													
												
			--,DateOfFact				= CAST(case when convert(varchar(6), Replace(O.InceptionDate,'-',''), 112) < cast(B1.ASAT as varchar) 
			--											then eomonth(convert(date, cast(B1.ASAT as varchar) + '01'))
			--											else O.InceptionDate
			--										END 
			--										AS DATETIME2
			--							)
		--	, case when I.[Transactional] is not null then I.DateOfFact else O.DateOfFact end as DateOfFact
			,O.BusinessKey 
			,O.PolicyNumber
			,O.InceptionDate
			,O.ExpiryDate
			,O.BindDate
			,O.DueDate
			,O.[BoundDate]
			,O.TrifocusCode
			,O.Entity
			,O.StatsCode
			,O.YOA
			,O.TypeOfBusiness
			,O.SettlementCCY
			,O.OriginalCCY
			,O.IsToDate
			--,O.[Value]
			,O.RowHash
			--,O.FK_Allocation
			,Year(@Transactionaldate)*100+Month(@Transactionaldate) as FK_Allocation
			,o.PK_BatchID as AuditSourceBatchID
			,getdate() as AuditGenerateDateTime
			,@@SERVERNAME as AuditHost
		--	,O.DeltaType
			,O.[Basis]
			,O.[Location]
			--,O.[ValueOrig]
			,O.[BusinessProcessCode]
			,O.[FK_Batch]
									
			,sum(I.SumofInbound) as IB_Val
		    ,sum(O.Sumofoutbound) as OB_Val
			,sum(ISNULL(I.SumofInbound,0))-sum(ISNULL(O.SumofOutbound,0)) as val	
            ,sum(ISNULL(I.OrigSumofInbound, 0.0000)) - sum(ISNULL(O.OrigSumofOutbound, 0.0000)) as ValueOrig
									
			,I.PolicyNumber as IB_Policy
			,I.BusinessKey as IBBK,I.RowHash IBRH
			,case 
			    when  I.BusinessKey is null and I.RowHash is null and O.BusinessKey is not null and O.Rowhash is  not null then 'Reversal'
			 End as Deltatype
									
			From #temp_OB O
			left Join  #temp_IB I on O.RowHash=I.RowHash
			--Inner join  @BatchID B1 on O.PK_BatchID=B1.PK_BatchID

			Left Join #IB_BPC   B ON RTRIM(LTRIM(B.BusinessProcessCode))=RTRIM(LTRIM(O.BusinessProcessCode)) --5897
			left join #IB_BK bk on bk.BusinessKey = o.BusinessKey --5897
			left join #outbound_Rowhash N on RTRIM(LTRIM(N.BusinessProcessCode))=RTRIM(LTRIM(O.BusinessProcessCode))

			--where  I.BusinessKey='P-OR-P-TTY|R0139M16|2623|2016|EUR|768'
			Group by 
			 O.Scenario
			,O.Account
			,O.[Dataset]
			,N.DateOfFact
			,O.BusinessKey 
			,O.PolicyNumber
			,O.InceptionDate
			,O.ExpiryDate
			,O.BindDate
			,O.DueDate
			,O.[BoundDate]
			,O.TrifocusCode
			,O.Entity
			,O.StatsCode
			,O.YOA
			,O.TypeOfBusiness
			,O.SettlementCCY
			,O.OriginalCCY
			,O.IsToDate
			--,O.[Value]
			,O.RowHash
			--,Year(@Transactionaldate)*100+Month(@Transactionaldate)
			--,O.FK_Allocation
			,o.PK_BatchID 
			--,isnull(O.AuditSourceBatchID,i.AuditSourceBatchID)
			--,getdate() 
			--,ISNULL(Inbound.AuditGenerateDateTime, @CurrentDate)
			--,O.AuditHost
			--,@@SERVERNAME 
		--	,O.DeltaType
			,O.[Basis]
			,O.[Location]
			--,O.[ValueOrig]
			,O.[BusinessProcessCode]
			,B.BusinessProcessCode --5897
			,O.[FK_Batch]
			,I.BusinessKey 
			,I.RowHash ,
			I.PolicyNumber,
			bk.BusinessKey
			--,I.[Transactional]
			--,B1.ASAT
		Having sum(ISNULL(i.SumofInbound,0))-sum(ISNULL(O.SumofOutbound,0))<>0
		) as e where e.Deltatype is not null


		) as OutboubdTran



			/*		
	--	=================================================================================================================
	--Fetch Restatements
	--	=================================================================================================================
	--	***/
	--	union all
		

	--	Select 	
	--	  	 I.Scenario 
	--		,I.Account 
	--		,I.[Dataset]
	--		,I.ASAT
	--		--,I.DateOfFact
	--	--	,convert(date, cast(I.ASAT as varchar) + '01') as DateOfFact
	--	,CAST(@Transactionaldate as date) as DateOfFact

	--		,I.BusinessKey 
	--		,I.PolicyNumber 
	--		,I.InceptionDate 
	--		,I.ExpiryDate
	--		,I.BindDate
	--		,I.DueDate
	--		,I.[BoundDate]
	--		,I.TrifocusCode
	--		,I.Entity
	--		,I.StatsCode
	--		,I.YOA
	--		,I.TypeOfBusiness
	--		,I.SettlementCCY
	--		,I.OriginalCCY
	--		,I.IsToDate
	--		--,I.[Value]
	--		,I.RowHash
	--		,I.FK_Allocation
	--		,I.AuditSourceBatchID
	--		,I.AuditGenerateDateTime
	--		,I.AuditHost
	--	--	,I.DeltaType
	--		,I.[Basis]
	--		,I.[Location]
	--		--,I.[ValueOrig]
	--		,I.[BusinessProcessCode]
	--		,I.[FK_Batch]
		
	--		,sum(I.SumofInbound) as IB_Val
	--		,sum(O.Sumofoutbound) as OB_Val
 --           ,sum(ISNULL(I.SumofInbound,0))-sum(ISNULL(O.SumofOutbound,0)) as val
	--		,sum(ISNULL(i.OrigSumofInbound, 0.0000)) - sum(ISNULL(OrigSumofOutbound, 0.0000)) as ValueOrig

	--		,O.PolicyNumber as OB_Policy
	--		,O.BusinessKey as OBBK
	--		,O.RowHash  OBRH
	--		--,case when O.BusinessKey is  null and I.BusinessKey is not null then 'New' 
	--		--	else 'Adjustment'
	--		--   End as Deltatype
	--		,'Restatement' as Deltatype 
								
	--		From #temp_IB I
	--		Left Join #temp_OB O on I.BusinessKey=O.BusinessKey and 		
	--		O.ROWHASH<>I.RowHash
	--		Where  O.BusinessKey is not null and O.RowHash is not null

									
	--		Group by 
							
	--		I.BusinessKey 
	--		,I.RowHash 
	--		,O.BusinessKey 
	--		,O.RowHash  
	--		,O.PolicyNumber
	--		,I.Scenario 
	--		,I.Account
	--		,I.[Dataset]
	--		,I.DateOfFact
	--		,I.PolicyNumber 
	--		,I.InceptionDate
	--		,I.ExpiryDate
	--		,I.BindDate
	--		,I.DueDate
	--		,I.[BoundDate]
	--		,I.TrifocusCode
	--		,I.Entity
	--		,I.StatsCode
	--		,I.YOA
	--		,I.TypeOfBusiness
	--		,I.SettlementCCY
	--		,I.OriginalCCY
	--		,I.IsToDate
	--		--,I.[Value]
	--		--,I.RowHash
	--		,I.FK_Allocation
	--		,I.AuditSourceBatchID
	--		,I.AuditGenerateDateTime
	--		,I.AuditHost
	--	--	,I.DeltaType
	--		,I.[Basis]
	--		,I.[Location]
	--		--,I.[ValueOrig]
	--		,I.[BusinessProcessCode]
	--		,I.[FK_Batch]
	--		,I.ASAT
	--	Having sum(ISNULL(I.SumofInbound,0))-sum(ISNULL(O.SumofOutbound,0))<>0
		
		




		/*
		======================================================================================
		Insert New, Adjustment, Reversal, Restatement records into outbound table
		======================================================================================
		*/

		

			/*		
	--	=================================================================================================================
	--Fetch Restatements
	--	=================================================================================================================
	--	***/
	
		
	drop table if exists #temp_Restatements;
	Select 	 Scenario, Account, [Dataset], CAST(@Transactionaldate as date) as DateOfFact, BusinessKey, PolicyNumber, InceptionDate, ExpiryDate
															,BindDate, DueDate, [BoundDate], 
															TrifocusCode, Entity, StatsCode, YOA, TypeOfBusiness, SettlementCCY
															,OriginalCCY, IsToDate, val, RowHash, FK_Allocation,
															AuditSourceBatchID, AuditGenerateDateTime, AuditHost
															,'Restatement' as Deltatype, [Basis], [Location], [ValueOrig], [BusinessProcessCode], [FK_Batch]
	
	Into #temp_Restatements
	FROM (

		Select 	
		  	 I.Scenario 
			,I.Account 
			,I.[Dataset]
			--,I.ASAT
			--,I.DateOfFact
		--	,convert(date, cast(I.ASAT as varchar) + '01') as DateOfFact
	--	, cast(CAST(@Transactionaldate as date) as datetime) as DateOfFact

			,I.BusinessKey 
			,I.PolicyNumber 
			,I.InceptionDate 
			,I.ExpiryDate
			,I.BindDate
			,I.DueDate
			,I.[BoundDate]
			,I.TrifocusCode
			,I.Entity
			,I.StatsCode
			,I.YOA
			,I.TypeOfBusiness
			,I.SettlementCCY
			,I.OriginalCCY
			,I.IsToDate
			--,I.[Value]
			,I.RowHash
			,I.FK_Allocation
			,I.AuditSourceBatchID
			,I.AuditGenerateDateTime
			,I.AuditHost
		--	,I.DeltaType
			,I.[Basis]
			,I.[Location]
			--,I.[ValueOrig]
			,I.[BusinessProcessCode]
			,I.[FK_Batch]
		
			,sum(I.SumofInbound) as IB_Val
			,sum(O.Sumofoutbound) as OB_Val
            ,sum(ISNULL(I.SumofInbound,0))-sum(ISNULL(O.SumofOutbound,0)) as val
			,sum(ISNULL(i.OrigSumofInbound, 0.0000)) - sum(ISNULL(OrigSumofOutbound, 0.0000)) as ValueOrig

			,O.PolicyNumber as OB_Policy
			,O.BusinessKey as OBBK
			,O.RowHash  OBRH
			,case when O.BusinessKey is  null and I.BusinessKey is not null then 'New' 
				else 'Adjustment'
			   End as Deltatype
		--	,'Restatement' as Deltatype 

		--	into #temp_Restatements
			From #temp_IB I
			Left Join #temp_OB O on O.ROWHASH=I.RowHash
									
			Group by 
							
			I.BusinessKey 
			,I.RowHash 
			,O.BusinessKey 
			,O.RowHash  
			,O.PolicyNumber
			,I.Scenario 
			,I.Account
			,I.[Dataset]
			,I.DateOfFact
			,I.PolicyNumber 
			,I.InceptionDate
			,I.ExpiryDate
			,I.BindDate
			,I.DueDate
			,I.[BoundDate]
			,I.TrifocusCode
			,I.Entity
			,I.StatsCode
			,I.YOA
			,I.TypeOfBusiness
			,I.SettlementCCY
			,I.OriginalCCY
			,I.IsToDate
			--,I.[Value]
			--,I.RowHash
			,I.FK_Allocation
			,I.AuditSourceBatchID
			,I.AuditGenerateDateTime
			,I.AuditHost
		--	,I.DeltaType
			,I.[Basis]
			,I.[Location]
			--,I.[ValueOrig]
			,I.[BusinessProcessCode]
			,I.[FK_Batch]
			--,I.ASAT
		Having sum(ISNULL(I.SumofInbound,0))-sum(ISNULL(O.SumofOutbound,0))<>0
		Except
		(
		 Select 
		   	 I.Scenario 
			,I.Account 
			,I.[Dataset]
			--,I.ASAT
			,I.BusinessKey 
			,I.PolicyNumber 
			,I.InceptionDate 
			,I.ExpiryDate
			,I.BindDate
			,I.DueDate
			,I.[BoundDate]
			,I.TrifocusCode
			,I.Entity
			,I.StatsCode
			,I.YOA
			,I.TypeOfBusiness
			,I.SettlementCCY
			,I.OriginalCCY
			,I.IsToDate
			--,I.[Value]
			,I.RowHash
			,I.FK_Allocation
			,I.AuditSourceBatchID
			,I.AuditGenerateDateTime
			,I.AuditHost
		--	,I.DeltaType
			,I.[Basis]
			,I.[Location]
			--,I.[ValueOrig]
			,I.[BusinessProcessCode]
			,I.[FK_Batch]
			,I.IB_Val
			,I.OB_Val
			,I.val,I.ValueOrig
			,I.OB_PolicyNumber
			,I.OBBK
			,I.OBRH
			,I.Deltatype
		

		 from #temp_OutboundTransactions  I
		)

		) as Restatement 

	
		

		


		

			INSERT Outbound.[Transaction] (Scenario, Account, [Dataset], DateOfFact, BusinessKey, PolicyNumber, InceptionDate, ExpiryDate
															,BindDate, DueDate, [BoundDate], 
															TrifocusCode, Entity, StatsCode, YOA, TypeOfBusiness, SettlementCCY
															,OriginalCCY, IsToDate, [Value], RowHash, FK_Allocation, AuditSourceBatchID, AuditGenerateDateTime, AuditHost
															,DeltaType, [Basis], [Location], [ValueOrig], [BusinessProcessCode], [FK_Batch])

			Select Scenario, Account, [Dataset], DateOfFact, BusinessKey, PolicyNumber, InceptionDate, ExpiryDate
															,BindDate, DueDate, [BoundDate], 
															TrifocusCode, Entity, StatsCode, YOA, TypeOfBusiness, SettlementCCY
															,OriginalCCY, IsToDate, val, RowHash, FK_Allocation,
															AuditSourceBatchID, AuditGenerateDateTime, AuditHost
															,DeltaType, [Basis], [Location], [ValueOrig], [BusinessProcessCode], [FK_Batch]

															From #temp_OutboundTransactions

				union all
				
		
			Select Scenario, Account, [Dataset], DateOfFact, BusinessKey, PolicyNumber, InceptionDate, ExpiryDate
															,BindDate, DueDate, [BoundDate], 
															TrifocusCode, Entity, StatsCode, YOA, TypeOfBusiness, SettlementCCY
															,OriginalCCY, IsToDate, val, RowHash, FK_Allocation,
															AuditSourceBatchID, AuditGenerateDateTime, AuditHost
															,DeltaType, [Basis], [Location], [ValueOrig], [BusinessProcessCode], [FK_Batch]

															From #temp_Restatements
		

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, 'TransactionalDatasets CDC', 'Process Inbound to outbound';

			/*=============================================================================================
					Delete data from inbound where batchID Has been processed to outbound and Change S
			==============================================================================================*/

			DELETE I FROM Inbound.[Transaction] I INNER JOIN @BatchID B ON B.PK_BatchID = I.AuditSourceBatchID;

			---Change status to Complete from running
			UPDATE		q
			SET			Status = 'OutBound'
			FROM		Inbound.BatchQueue	q
			INNER JOIN	@BatchID			B ON q.Pk_Batch = B.PK_BatchID;

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT	5
					,	'TransactionalDatasets CDC'
					,'Delete data from inbound where batchID Has been processed to outbound and Change S';

			/*
			=============================================================================================
				LogOutbound Aggregate Actual Value
			==============================================================================================
			*/

			if @DoNonIFRS17_Tests = 1
			begin

				EXEC [Test].[usp_LogBatchAggregate_ActualOutbound] @BatchID;

				--EXEC [Test].[usp_LogBatchAggregate_ActualOutboundPFT] @BatchID; /*Commented it for I1B-1011*/

				EXEC [Test].[usp_LogBatchAggregate_ActualOutboundFDM] @BatchID;

				 
				EXEC [Test].[usp_LogBatchAggregate_ActualOutBoundBICI]  @BatchID;
				EXEC [Test].[usp_LogBatchAggregate_ActualOutBoundBAIC]   @BatchID;
				EXEC [Test].[usp_LogBatchAggregate_ActualOutBoundUSSYND] @BatchID;
				EXEC [Test].[usp_LogBatchAggregate_ActualOutboundBIDAC]  @BatchID;

				INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
				SELECT 5, 'TransactionalDatasets CDC', 'LogOutbound Aggregate Actual Value';
				/*
				=============================================================================================
					Log Aggregate expected Value in technicalHubdb.fact.technicalresult
				==============================================================================================
				*/

				EXEC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHub] @BatchID;

		  	    EXEC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHubPFT] @BatchID;

				EXEC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHubFDM] @BatchID;

				EXEC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHubFDMCHE] @BatchID;

				EXEC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHubUSBAIC] @BatchID;

				EXEC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHubBIDAC] @BatchID;

				EXEC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHubBICI] @BatchID;

	

				INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
				SELECT	5
						,	'TransactionalDatasets CDC'
						,'Log Aggregate expected Value in technicalHubdb.fact.technicalresult';

			end --if @DoNonIFRS17_Tests = 1


		END;
		IF @Trancount = 0 
			BEGIN
				RAISERROR('committing', 0, 0) WITH NOWAIT;
				COMMIT;
			END;
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, 'TransactionalDatasets CDC', ' Succeeded';

		--Generate logging for success
		EXEC log.usp_LogContract @Input = @Logging;

	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK
		-----On error Change status to failed from running
		UPDATE		q
		SET			Status = 'OutBoundFailed'
		FROM		Inbound.BatchQueue	q
		INNER JOIN	@BatchID			B ON q.Pk_Batch = B.PK_BatchID;

		--Generate logging for error (outside tran)
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)

		SELECT 4, 'TransactionalDatasets CDC', ERROR_MESSAGE();
		EXEC log.usp_LogContract @Input = @Logging;

		THROW;
	END CATCH;
END;