﻿CREATE PROCEDURE [Inbound].[usp_InboundOutboundWorkflow_PremiumExtensions]
AS
BEGIN
	/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Version:	  Sprint 24Q2 CommittedVersion
	Author		:  Shah Nawaz Ahmed    <shahnawaz.ahmed@beazley.com>
	Modify Date	:  01/05/2024 - Sprint Q2 Committed version
	Description	:  https://beazley.atlassian.net/browse/I1B-3817
					Code updated to improve performance, Now Insert [Outbound].[Premium_Extensions] RowHash in #TempOut
					and then performing join with Inbound.
	----================================================================================================================*/
	set nocount on

	DECLARE @Logging	log.utt_ActivityLog;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Trancount INT = @@Trancount;
	DECLARE @BatchID_PremiumExtensions AS BATCHID;
	DECLARE @DataSet varchar(50) = 'PremiumExtensions'

	INSERT @Logging(ActivityStatus, ActivityName) SELECT 1, @p_ActivityName;
	
	BEGIN TRY

		IF @Trancount = 0 BEGIN TRAN;

		IF EXISTS (SELECT Pk_Batch FROM Inbound.BatchQueue WHERE Status = 'InBound' AND DataSet = @DataSet)
		BEGIN

			/*=============================================================================================
         	Select Pending BatchID 
			==============================================================================================*/

			INSERT INTO @BatchID_PremiumExtensions
			SELECT	Pk_Batch
					,DataSet
					,AsAt
			FROM	Inbound.BatchQueue
			WHERE	[Status] = 'InBound'
			AND     DataSet = @DataSet
			
			RAISERROR('@BatchID_PremiumExtensions: %i', 0, 0, @@rowcount) WITH NOWAIT;

			---set batch status to running from Pending
			UPDATE		bq
			SET			[Status] = 'Running'
			FROM		Inbound.BatchQueue	bq
			INNER JOIN	@BatchID_PremiumExtensions bi 
				ON  bq.Pk_Batch = bi.PK_BatchID
				

			RAISERROR('Running: %i', 0, 0, @@rowcount) WITH NOWAIT;
				 
			
            INSERT INTO Outbound.Premium_Extensions_Bridge WITH(TABLOCK)
			( 
				[RowHash_Transaction]
				,RowHash_Transaction_Premium_Extensions
	            ,[FK_Batch]
			)
			SELECT 
				 p.[RowHash_Transaction] 
				,p.RowHash_Transaction_Premium_Extensions
				,[FK_Batch] = MAX(p.[FK_Batch])
			FROM   
				[Inbound].Premium_Extensions_Bridge p
				JOIN @BatchID_PremiumExtensions b ON b.PK_BatchID = p.FK_Batch
				LEFT JOIN Outbound.Premium_Extensions_Bridge t 
					ON  t.[RowHash_Transaction] = p.[RowHash_Transaction]
					AND t.RowHash_Transaction_Premium_Extensions = p.RowHash_Transaction_premium_Extensions
			WHERE
				t.[RowHash_Transaction] is null
			GROUP BY 
				 p.[RowHash_Transaction] 
				,p.RowHash_Transaction_Premium_Extensions
				

			RAISERROR('[Outbound].[Premium_Extensions_Bridge]: %i', 0, 0, @@rowcount) WITH NOWAIT;

			

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, @p_ActivityName, 'Process Inbound to outbound for Premium_Extensions_Bridge';

			/*=============================================================================================
         	Insert [Outbound].[Premium_Extensions] RowHash in TempOut
			==============================================================================================*/
			DROP TABLE IF EXISTS #TempOut

			SELECT	DISTINCT RowHash_Transaction_Premium_Extensions
			INTO	#TempOut
			FROM	Outbound.Premium_Extensions

			INSERT INTO [Outbound].[Premium_Extensions]  WITH(TABLOCK)
			(
					 [RowHash_Transaction_Premium_Extensions]
					,[PolicyClaimBasis]
					,[PolicyMOPCode]
					,[PolicyCobCode] 
					,[PolicyNumber]
					,[FK_Batch]
			)
			SELECT 
					 p.[RowHash_Transaction_Premium_Extensions]
					,p.PolicyClaimBasis 
					,p.PolicyMOPCode
					,P.PolicyCobCode
					,p.PolicyNumber
					,[FK_Batch] = MAX(p.[FK_Batch])
			FROM   
				[Inbound].Premium_Extensions p
				JOIN @BatchID_PremiumExtensions b ON b.PK_BatchID = p.FK_Batch
				LEFT JOIN #TempOut t--Outbound.Premium_Extensions t 
					ON  t.RowHash_Transaction_Premium_Extensions = p.RowHash_Transaction_Premium_Extensions
			WHERE
				t.RowHash_Transaction_Premium_Extensions is null
			GROUP BY  
					 p.[RowHash_Transaction_Premium_Extensions]
					,p.PolicyClaimBasis 
					,p.PolicyMOPCode
					,P.PolicyCobCode
					,p.PolicyNumber
					,p.[ContractType]
				 


			RAISERROR('[Outbound].[Premium_Extensions]: %i', 0, 0, @@rowcount) WITH NOWAIT;

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, @p_ActivityName, 'Process Inbound to outbound for Premium_Extensions';


			/*=============================================================================================
					Delete data from inbound where batchID Has been processed to outbound and Change S
			==============================================================================================*/

			DELETE I FROM [Inbound].Premium_Extensions_Bridge I JOIN @BatchID_PremiumExtensions B ON B.PK_BatchID = I.[FK_Batch];
			DELETE I FROM [Inbound].Premium_Extensions I JOIN @BatchID_PremiumExtensions B ON B.PK_BatchID = I.[FK_Batch];

			---Change status to Complete from running
			UPDATE	bq
			SET		[Status] = 'Outbound'
			FROM	Inbound.BatchQueue	bq
			JOIN	@BatchID_PremiumExtensions bi 
				ON  bq.Pk_Batch = bi.PK_BatchID
				

			RAISERROR('Completed Premium_Extensions: %i', 0, 0, @@rowcount) WITH NOWAIT;

		END;

		-- LOGIN THE RESULT WITH SUCCESS
		INSERT @Logging(ActivityStatus, ActivityName) SELECT 2 , @p_ActivityName;

		--Generate logging for success
		EXEC log.usp_LogContract @Input = @Logging;

		IF @Trancount = 0 COMMIT;

	END TRY
	BEGIN CATCH

		IF @Trancount = 0 ROLLBACK;

		-----On error Change status to failed from running
		UPDATE		q
		SET			Status = 'OutBoundFailed'
		FROM		Inbound.BatchQueue	q
		INNER JOIN	@BatchID_PremiumExtensions B ON q.Pk_Batch = B.PK_BatchID;

		-- LOG THE RESULT WITH ERROR
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 4, @p_ActivityName, ERROR_MESSAGE();

		EXEC log.usp_LogContract @Input = @Logging;

		THROW;

	END CATCH;
END