﻿

CREATE PROCEDURE [Inbound].[usp_InboundOutboundWorkflow_Pattern] 
--@p_DataSet NVARCHAR(255),@p_Account NVARCHAR(255)
	
AS
BEGIN

	DECLARE @Logging	log.utt_ActivityLog;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Trancount INT = @@Trancount;

	INSERT @Logging(ActivityStatus, ActivityName) SELECT 1, @p_ActivityName;
	
	BEGIN TRY

		IF @Trancount = 0 BEGIN TRAN;

		IF EXISTS (SELECT Pk_Batch 
		           FROM   Inbound.BatchQueue 
				   WHERE  [Status] = 'InBound' 
		           AND    RunDescription = 'Pattern' --AND  DataSet  = ISNULL(@p_DataSet,DataSet)
		           )
		BEGIN

			/*=============================================================================================
         	Select Pending BatchID 
			==============================================================================================*/

			DECLARE @BatchID AS BATCHID;

			INSERT INTO @BatchID
			SELECT	Pk_Batch
					,DataSet
					,AsAt
			FROM	Inbound.BatchQueue
			WHERE	[Status] = 'InBound'
			--AND     DataSet  = ISNULL(@p_DataSet,DataSet)
			AND     RunDescription = 'Pattern';
			
			RAISERROR('@BatchID: %i', 0, 0, @@rowcount) WITH NOWAIT;

			---set batch status to running from Pending
			UPDATE		bq
			SET			[Status] = 'Running'
			FROM		Inbound.BatchQueue	bq
			INNER JOIN	@BatchID			bi 
			ON          bq.Pk_Batch = bi.PK_BatchID
			--AND         bq.DataSet  = bi.DataSet;

			RAISERROR('Running: %i', 0, 0, @@rowcount) WITH NOWAIT;

			/*=============================================================================================
			Process Inbound to outbound
			==============================================================================================*/

			INSERT INTO Outbound.[Pattern] WITH(TABLOCK)([PatternScenario], [PatternScenarioVersion], [PatternKey], [DataSet], [TrifocusCode], [YOA], [InceptionYear]
														,[SettlementCCY], [DevelopmentPercentageIncrement], [DevelopmentQuarter], [AuditSourceBatchID]
														,[AuditHost], AuditGenerateDateTime, FK_Batch, BusinessProcessCode, BusinessKey)
			SELECT	p.[PatternScenario]
					,p.[PatternScenarioVersion]
					,p.[PatternKey]
					,p.[DataSet]
					,p.[TrifocusCode]
					,p.[YOA]
					,p.[InceptionYear]
					,p.[SettlementCCY]
					,p.[DevelopmentPercentageIncrement]
					,p.[DevelopmentQuarter]
					,p.[AuditSourceBatchID]
					,p.[AuditHost]
					,p.AuditGenerateDateTime
					,p.FK_Batch
					,p.BusinessProcessCode
					,p.BusinessKey
			FROM	Inbound.[Pattern] p
			JOIN	@BatchID b ON b.PK_BatchID = P.AuditSourceBatchID
			--AND     b.DataSet = p.DataSet


			RAISERROR('Outbound.[Pattern]: %i', 0, 0, @@rowcount) WITH NOWAIT;

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, '[Inbound].[usp_InboundOutboundWorkflow_Pattern]', 'Process Inbound to outbound';

			/*=============================================================================================
					Delete data from inbound where batchID Has been processed to outbound and Change S
			==============================================================================================*/

			DELETE I FROM Inbound.[Pattern] I INNER JOIN @BatchID B ON B.PK_BatchID = I.AuditSourceBatchID;

			---Change status to Complete from running
			UPDATE	bq
			SET		[Status] = 'Outbound'
			FROM	Inbound.BatchQueue	bq
			JOIN	@BatchID			bi 
			ON      bq.Pk_Batch = bi.PK_BatchID
			--AND     bq.DataSet  = bi.DataSet;

			RAISERROR('Completed: %i', 0, 0, @@rowcount) WITH NOWAIT;

			-- LOGIN THE RESULT WITH SUCCESS
			INSERT @Logging(ActivityStatus, ActivityName) SELECT 2 , @p_ActivityName;

		END;

		--Generate logging for success
		EXEC log.usp_LogContract @Input = @Logging;

		IF @Trancount = 0 COMMIT;

	END TRY
	BEGIN CATCH

		IF @Trancount = 0 ROLLBACK;

		-----On error Change status to failed from running
		UPDATE		q
		SET			Status = 'OutBoundFailed'
		FROM		Inbound.BatchQueue	q
		INNER JOIN	@BatchID			B 
		ON          q.Pk_Batch = B.PK_BatchID
		--AND         bq.DataSet  = bi.DataSet;

		-- LOG THE RESULT WITH ERROR
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 4, '[Inbound].[usp_InboundOutboundWorkflow]', ERROR_MESSAGE();

		EXEC log.usp_LogContract @Input = @Logging;

		THROW;

	END CATCH;
END;