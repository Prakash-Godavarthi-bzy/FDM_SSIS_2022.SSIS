﻿CREATE PROCEDURE [Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTrifocusAllocationsTreaty]
AS
-- =============================================

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	2021-08-09
-- Changes:				Original version. Does a delete,update & insert so the outbound table is a reflection of source.

-- =============================================	

BEGIN

	set nocount on

	DECLARE @Logging	log.utt_ActivityLog;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Trancount INT = @@Trancount;
	DECLARE @BatchID AS BATCHID;

	DECLARE @DataSet varchar(50) = ('ReInsuranceTrifocusAllocationsTreaty')

	INSERT @Logging(ActivityStatus, ActivityName) SELECT 1, @p_ActivityName;
	
	BEGIN TRY

		IF EXISTS (SELECT Pk_Batch FROM Inbound.BatchQueue WHERE Status = 'InBound' AND DataSet = @DataSet)
		BEGIN

			/*=============================================================================================
         	Select Pending BatchID 
			==============================================================================================*/

			INSERT INTO @BatchID
			SELECT	Pk_Batch
					,DataSet
					,AsAt
			FROM	Inbound.BatchQueue
			WHERE	[Status] = 'InBound'
			AND     DataSet = @DataSet;
			
			RAISERROR('@BatchID: %i', 0, 0, @@rowcount) WITH NOWAIT;


			if OBJECT_ID('tempdb..#Inbound') is not null drop table #Inbound

			SELECT 
				 p.[EntityCode]
				,p.[EntityName]
				,p.[AccountCode]
				,p.[AccountingPeriod]
				,p.[RIPolicyNumber]
				,p.[YOA]
				,p.[RIType]
				,p.[RIProgramme]
				,p.[TrifocusCode]
				,p.[TrifocusName]
				,p.[SettlementCurrency]
				,p.[Amount]
				,p.[TotalAmount]
				,p.[Allocation]
				,p.[FK_Batch]
				,p.[AuditDateTime]
				,p.[AuditUser]
				,p.[AuditHost]
				,p.[DataSet]
				,p.BusinessKey
			INTO
				#Inbound
			FROM 
				[Inbound].ReInsuranceTrifocusAllocationsTreaty p
				join @BatchID b ON b.PK_BatchID = p.FK_Batch
			
			create clustered index ix on #Inbound (BusinessKey)

			--select COUNT(*) from #Inbound


			if OBJECT_ID('tempdb..#Outbound') is not null drop table #Outbound
			SELECT 
				 p.BusinessKey
				,p.id
			INTO
				#Outbound
			FROM 
				Outbound.ReInsuranceTrifocusAllocationsTreaty p

			create clustered index ix on #Outbound (BusinessKey)

			--select COUNT(*) from #Outbound


			IF @Trancount = 0 BEGIN TRAN;


			---set batch status to running from Pending
			UPDATE		bq
			SET			[Status] = 'Running'
			FROM		Inbound.BatchQueue	bq
			INNER JOIN	@BatchID bi 
				ON  bq.Pk_Batch = bi.PK_BatchID				

			RAISERROR('Running: %i', 0, 0, @@rowcount) WITH NOWAIT;


			delete t
			from
				[Outbound].ReInsuranceTrifocusAllocationsTreaty t
				join #Outbound o on o.id = t.id
				left join #Inbound s on s.BusinessKey = o.BusinessKey
			where
				s.BusinessKey is null

			RAISERROR('[Outbound].[ReInsuranceTrifocusAllocationsTreaty] delete: %i', 0, 0, @@rowcount) WITH NOWAIT;

			
			update t
			set 
				[EntityCode]			= s.[EntityCode]
				,[EntityName]			= s.[EntityName]
				,[AccountCode]			= s.[AccountCode]
				,[AccountingPeriod]		= s.[AccountingPeriod]
				,[RIPolicyNumber]		= s.[RIPolicyNumber]
				,[YOA]					= s.[YOA]
				,[RIType]				= s.[RIType]
				,[RIProgramme]			= s.[RIProgramme]
				,[TrifocusCode]			= s.[TrifocusCode]
				,[TrifocusName]			= s.[TrifocusName]
				,[SettlementCurrency]	= s.[SettlementCurrency]
				,[Amount]				= s.[Amount]
				,[TotalAmount]			= s.[TotalAmount]
				,[Allocation]			= s.[Allocation]
				,[FK_BatchUpdate]		= s.[FK_Batch]
				,[AuditUpdateDateTime]	= s.[AuditDateTime]
				,[AuditUpdateUser]		= s.[AuditUser]
				,[AuditUpdateHost]		= s.[AuditHost]
			from
				[Outbound].ReInsuranceTrifocusAllocationsTreaty t
				join #Outbound o on o.id = t.id
				join #Inbound s on s.BusinessKey = o.BusinessKey
			where
				1 = case 
					when t.[Amount] = s.[Amount] then 0 
					when t.[Amount] is null and s.[Amount] is null then 0
					else 1
					end
				or
				1 = case 
					when t.[TotalAmount] = s.[TotalAmount] then 0 
					when t.[TotalAmount] is null and s.[TotalAmount] is null then 0
					else 1
					end
				or
				1 = case 
					when t.[Allocation] = s.[Allocation] then 0 
					when t.[Allocation] is null and s.[Allocation] is null then 0
					else 1
					end

			RAISERROR('[Outbound].[ReInsuranceTrifocusAllocationsTreaty] update: %i', 0, 0, @@rowcount) WITH NOWAIT;


			insert into [Outbound].ReInsuranceTrifocusAllocationsTreaty
			(
				[EntityCode]
				,[EntityName]
				,[AccountCode]
				,[AccountingPeriod]
				,[RIPolicyNumber]
				,[YOA]
				,[RIType]
				,[RIProgramme]
				,[TrifocusCode]
				,[TrifocusName]
				,[SettlementCurrency]
				,[Amount]
				,[TotalAmount]
				,[Allocation]
				,[FK_BatchCreate]
				,[AuditCreateDateTime]
				,[AuditCreateUser]
				,[AuditCreateHost]
				,[DataSet]
			)
			SELECT 
				 p.[EntityCode]
				,p.[EntityName]
				,p.[AccountCode]
				,p.[AccountingPeriod]
				,p.[RIPolicyNumber]
				,p.[YOA]
				,p.[RIType]
				,p.[RIProgramme]
				,p.[TrifocusCode]
				,p.[TrifocusName]
				,p.[SettlementCurrency]
				,p.[Amount]
				,p.[TotalAmount]
				,p.[Allocation]
				,p.[FK_Batch]
				,p.[AuditDateTime]
				,p.[AuditUser]
				,p.[AuditHost]
				,p.[DataSet]
			FROM 
				#Inbound p
				left join #Outbound t on t.BusinessKey = p.BusinessKey
			WHERE
				t.BusinessKey is null

			RAISERROR('[Outbound].[ReInsuranceTrifocusAllocationsTreaty] insert: %i', 0, 0, @@rowcount) WITH NOWAIT;


			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, @p_ActivityName, 'Process Inbound to outbound for ReInsuranceTrifocusAllocationsTreaty';

			/*=============================================================================================
					Change Status to Outbound
			==============================================================================================*/

			UPDATE	bq
			SET		[Status] = 'Outbound'
			FROM	Inbound.BatchQueue	bq
			JOIN	@BatchID bi 
				ON  bq.Pk_Batch = bi.PK_BatchID
				

			RAISERROR('Completed ReInsuranceTrifocusAllocationsTreaty: %i', 0, 0, @@rowcount) WITH NOWAIT;

		END;

		-- LOGIN THE RESULT WITH SUCCESS
		INSERT @Logging(ActivityStatus, ActivityName) SELECT 2 , @p_ActivityName;

		--Generate logging for success
		EXEC log.usp_LogContract @Input = @Logging;

		IF @Trancount = 0 and @@TRANCOUNT <> 0 COMMIT;

	END TRY
	BEGIN CATCH

		IF @Trancount = 0 ROLLBACK;

		-----On error Change status to failed from running
		UPDATE		q
		SET			Status = 'OutBoundFailed'
		FROM		Inbound.BatchQueue	q
		INNER JOIN	@BatchID B ON q.Pk_Batch = B.PK_BatchID;


		-- LOG THE RESULT WITH ERROR
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 4, @p_ActivityName, ERROR_MESSAGE();

		EXEC log.usp_LogContract @Input = @Logging;

		THROW;

	END CATCH;
END

