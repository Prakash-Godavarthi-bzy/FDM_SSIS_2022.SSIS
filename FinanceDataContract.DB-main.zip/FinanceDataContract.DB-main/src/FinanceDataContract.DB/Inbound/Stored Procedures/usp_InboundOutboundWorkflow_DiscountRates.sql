﻿


						 
CREATE  PROCEDURE [Inbound].[usp_InboundOutboundWorkflow_DiscountRates]
      --@p_SourceSystem           NVARCHAR(255)	
	 --,@p_Account				NVARCHAR(255) 
	 -- We need next 3 parameters to log if we run from a JOB/ SSIS package
	 --,@p_ParentActivityLogId	BIGINT			= NULL
	 --,@p_ActivityJobId			VARCHAR(50)		= NULL

AS
BEGIN

		DECLARE @Logging	log.utt_ActivityLog;
		DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
		DECLARE @Trancount INT = @@Trancount;

		INSERT @Logging(ActivityStatus, ActivityName) SELECT 1, @p_ActivityName;
	
		BEGIN TRY

			IF @Trancount = 0 BEGIN TRAN;

			IF EXISTS (SELECT Pk_Batch FROM Inbound.BatchQueue WHERE Status = 'InBound' AND RunDescription = 'DiscountRates')
			BEGIN

				/*=============================================================================================
         		Select Pending BatchID 
				==============================================================================================*/

				DECLARE @BatchID AS BATCHID;

				INSERT INTO @BatchID
				SELECT	Pk_Batch
						,DataSet
						,AsAt
				FROM	Inbound.BatchQueue
				WHERE	[Status] = 'InBound'
				AND     RunDescription = 'DiscountRates';
			
				RAISERROR('@BatchID: %i', 0, 0, @@rowcount) WITH NOWAIT;

				---set batch status to running from Pending
				UPDATE		bq
				SET			[Status] = 'Running'
				FROM		Inbound.BatchQueue	bq
				INNER JOIN	@BatchID			bi ON bq.Pk_Batch = bi.PK_BatchID;

				RAISERROR('Running: %i', 0, 0, @@rowcount) WITH NOWAIT;

				/*=============================================================================================
				Process Inbound to outbound
				==============================================================================================*/		
			
		--DECLARE @Trancount INT= @@Trancount;

		--DECLARE @v_ErrorMessage NVARCHAR(4000);
		--DECLARE @v_SQL NVARCHAR(4000);			-- For dynamic SQL statement
		--DECLARE @v_CurrentDate DATETIME2 = GETUTCDATE();

		--DECLARE @v_RC							INT
		--DECLARE @v_ActivityLogTag				BIGINT
		--DECLARE @v_ActivitySource				SMALLINT
		--DECLARE @v_ActivityType					SMALLINT
		--DECLARE @v_ActivityStatusStart			SMALLINT
		--DECLARE @v_ActivityStatusStop			SMALLINT
		--DECLARE @v_ActivityStatusFail			SMALLINT
		--DECLARE @v_ActivityHost					VARCHAR(100)
		--DECLARE @v_ActivityDatabase				VARCHAR(100) 
		--DECLARE @v_ActivityName					VARCHAR(100)
		--DECLARE @v_ActivityDateTime				DATETIME2(2)
		--DECLARE @v_ActivityMessage				NVARCHAR(4000)
		--DECLARE @v_ActivityErrorCode			NVARCHAR(50)
		--DECLARE @v_ActivityLogIdIn				BIGINT
		--DECLARE @v_ActivityLogIdOut				BIGINT
		--DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL
		--DECLARE @v_AffectedRows					INT
		--DECLARE @v_TotalAffectedRows			INT

		--SELECT @v_ActivityStatusStart = PK_ActivityStatus 
		--FROM Orchestram.Log.ActivityStatus	
		--WHERE ActivityStatus = 'STARTED'

		--SELECT @v_ActivityStatusStop = PK_ActivityStatus 
		--FROM Orchestram.Log.ActivityStatus	
		--WHERE ActivityStatus = 'SUCCEEDED'

		--SELECT @v_ActivityStatusFail = PK_ActivityStatus 
		--FROM Orchestram.Log.ActivityStatus	
		--WHERE ActivityStatus = 'ERRORED'

		--/* Log the start of the insert */
		--SELECT   
		--	@v_ActivityLogTag		        = NULL
		--,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'IFRS17')
		--,@v_ActivityType				= (SELECT PK_ActivityType	
		--									FROM Orchestram.Log.ActivityType	
		--									WHERE ActivityType = CASE 
		--															WHEN @p_ParentActivityLogId IS NULL 
		--																THEN 'Manual process' 
		--																ELSE 'Automated process' 
		--															END)
		--,@v_ActivityHost				= @@SERVERNAME
		--,@v_ActivityName				= 'Load data into Outbound.DiscountRates'
		--,@v_ActivityDateTime			= GETUTCDATE()
		--,@v_ActivityMessage				= NULL
		--,@v_ActivityErrorCode			= NULL
		--,@v_AffectedRows				= 0

		--EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
		--			@p_ParentActivityLogId
		--			,@v_ActivityLogTag
		--			,@v_ActivitySource
		--			,@v_ActivityType
		--			,@v_ActivityStatusStart
		--			,@v_ActivityHost
		--			,@v_ActivityDatabase
		--			,@p_ActivityJobId
		--			,@v_ActivitySSISExecutionId
		--			,@v_ActivityName
		--			,@v_ActivityDateTime
		--			,@v_ActivityMessage
		--			,@v_ActivityErrorCode
		--			,@v_AffectedRows
		--			,@v_ActivityLogIdIn OUTPUT

		--SELECT @v_ActivityLogTag = @v_ActivityLogIdIn

		--   BEGIN TRY

		--			IF @Trancount = 0

		--			BEGIN TRAN;

		--			IF EXISTS
		--			(
		--				SELECT PK_Batch

		--				FROM Inbound.BatchQueue

		--				WHERE STATUS = 'Pending'
		--				AND   RunDescription = 'DiscountRates'
		--				AND   SourceSystem = @p_SourceSystem 
		--			)
		--				BEGIN
         
		--					/*=============================================================================================
  --       					Select Pending BatchID 
		--					==============================================================================================*/

		--					DECLARE @BatchID AS Inbound.BATCHID;

		--					INSERT INTO @BatchID

		--						   SELECT PK_Batch, 
		--								  SourceSystem

		--						   FROM Inbound.BatchQueue

		--						   WHERE [Status] = 'Pending'
		--						   AND   SourceSystem = @p_SourceSystem 
		--						   AND   RunDescription = 'DiscountRates'


		--					---set batch status to running from Pending
		--					UPDATE bq

		--					SET  [Status] = 'Running'

		--					FROM Inbound.BatchQueue bq

		--					INNER JOIN @BatchID bi ON bq.Pk_Batch = bi.PK_BatchID;																							  
		--				   /*=============================================================================================
		--					Process Inbound to outbound
		--					==============================================================================================*/

							INSERT INTO Outbound.[DiscountRates] WITH(TABLOCK)

							( 
								   [AsAtDate] 
								  ,[DiscountRateName] 
								  ,[DiscountRateKey] 
								  ,[DataSet] 
								  ,[SettlementCCY] 
								  ,[CumulativeDevelopmentPercentage] 
								  ,[DevelopmentYear] 
								  ,[AuditSourceBatchID]
								  ,[AuditHost]
								  ,[AuditGenerateDateTime] 
								  ,[FK_Batch] 
							)

							SELECT 
								   [AsAtDate] 
								  ,[DiscountRateName] 
								  ,[DiscountRateKey] 
								  ,p.[DataSet] 
								  ,[SettlementCCY] 
								  ,[CumulativeDevelopmentPercentage] 
								  ,[DevelopmentYear] 
								  ,[AuditSourceBatchID]
								  ,[AuditHost]
								  ,[AuditGenerateDateTime] 
								  ,[FK_Batch] 

							FROM   Inbound.[DiscountRates] p
							JOIN	@BatchID b ON b.PK_BatchID = P.AuditSourceBatchID
							

			RAISERROR('Outbound.[DiscountRates]: %i', 0, 0, @@rowcount) WITH NOWAIT;

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, 'Inbound.usp_InboundOutboundWorkflow_DiscountRates', 'Process Inbound to outbound';


			/*=============================================================================================
					Delete data from inbound where batchID Has been processed to outbound and Change S
			==============================================================================================*/

			DELETE I FROM Inbound.[DiscountRates] I INNER JOIN @BatchID B ON B.PK_BatchID = I.AuditSourceBatchID;

			---Change status to Complete from running
			UPDATE	bq
			SET		[Status] = 'Outbound'
			FROM	Inbound.BatchQueue	bq
			JOIN	@BatchID			bi ON bq.Pk_Batch = bi.PK_BatchID;

			RAISERROR('Completed: %i', 0, 0, @@rowcount) WITH NOWAIT;

			-- LOGIN THE RESULT WITH SUCCESS
			INSERT @Logging(ActivityStatus, ActivityName) SELECT 2 , @p_ActivityName;

		END;

		--Generate logging for success
		EXEC log.usp_LogContract @Input = @Logging;

		IF @Trancount = 0 COMMIT;

	END TRY
	BEGIN CATCH

		IF @Trancount = 0 ROLLBACK;

		-----On error Change status to failed from running
		UPDATE		q
		SET			Status = 'OutBoundFailed'
		FROM		Inbound.BatchQueue	q
		INNER JOIN	@BatchID			B ON q.Pk_Batch = B.PK_BatchID;

		-- LOG THE RESULT WITH ERROR
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 4, 'Inbound.usp_InboundOutboundWorkflow_DiscountRates', ERROR_MESSAGE();

		EXEC log.usp_LogContract @Input = @Logging;

		THROW;

	END CATCH;
END

GO
EXECUTE sp_addextendedproperty @name = N'Stored Procedure Parameters', @value = N'Input:

					@p_SourceSystem           NVARCHAR(255)	
					The source system for which the transfer will be done. To apply on ALL systems, assign NULL.

					@p_Account				NVARCHAR(255) 
					The account for which the transfer will be done. To apply on ALL accounts, assign NULL.', @level0type = N'SCHEMA', @level0name = N'Inbound', @level1type = N'PROCEDURE', @level1name = N'usp_InboundOutboundWorkflow_DiscountRates';


GO
EXECUTE sp_addextendedproperty @name = N'Stored Procedure Call', @value = N'The procedure transfer delta`ed data from the Inbound to Outbound schema.

					•	Remarks:

					1.	TRY/CATCH BLOCKS are required to handle errors in the stored procedure.', @level0type = N'SCHEMA', @level0name = N'Inbound', @level1type = N'PROCEDURE', @level1name = N'usp_InboundOutboundWorkflow_DiscountRates';

