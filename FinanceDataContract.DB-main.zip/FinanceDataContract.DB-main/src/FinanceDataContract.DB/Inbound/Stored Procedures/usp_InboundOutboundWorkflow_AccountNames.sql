﻿CREATE PROCEDURE [Inbound].[usp_InboundOutboundWorkflow_AccountNames]
AS
-- =============================================

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	2021-06-29
-- Changes:				Loads and keeps the table [Outbound].AccountName up to date.

-- =============================================	

BEGIN

	set nocount on

	DECLARE @Logging	log.utt_ActivityLog;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Trancount INT = @@Trancount;
	DECLARE @BatchID AS BATCHID;


	INSERT @Logging(ActivityStatus, ActivityName) SELECT 1, @p_ActivityName;
	
	BEGIN TRY

		IF @Trancount = 0 BEGIN TRAN;


		declare @DataSet char(26) = ('AccountName')

		IF EXISTS (SELECT Pk_Batch FROM Inbound.BatchQueue WHERE Status = 'InBound' AND DataSet = @DataSet)
		BEGIN

			/*=============================================================================================
         	Select Pending BatchID 
			==============================================================================================*/

			INSERT INTO @BatchID
			SELECT	Pk_Batch
					,DataSet
					,AsAt
			FROM	Inbound.BatchQueue
			WHERE	[Status] = 'InBound'
			AND     DataSet = @DataSet;
			
			RAISERROR('@BatchID: %i', 0, 0, @@rowcount) WITH NOWAIT;

			---set batch status to running from Pending
			UPDATE		bq
			SET			[Status] = 'Running'
			FROM		Inbound.BatchQueue	bq
			INNER JOIN	@BatchID bi 
				ON  bq.Pk_Batch = bi.PK_BatchID				

			RAISERROR('Running: %i', 0, 0, @@rowcount) WITH NOWAIT;

			
			merge [Outbound].AccountName as t
			using
			(
				SELECT 
					 p.[AccountKey]
					,p.[AccountNames]
					,p.[FK_Batch]
				FROM   
					[Inbound].AccountName p
					join @BatchID b ON b.PK_BatchID = p.FK_Batch
			) s 
			on 
				s.[AccountKey] = t.[AccountKey]
			when not matched then 
				insert values(s.[AccountKey],s.[AccountNames],s.[FK_Batch])
			when matched and 
				1 = case 
					when t.[AccountNames] = s.[AccountNames] then 0 
					when t.[AccountNames] is null and s.[AccountNames] is null then 0
					else 1
					end
				then
					update 
					set 
						[AccountNames] = s.[AccountNames]
						,[FK_Batch] = s.[FK_Batch];

			RAISERROR('[Outbound].[AccountName] merge: %i', 0, 0, @@rowcount) WITH NOWAIT;


			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, 'Inbound.usp_InboundOutboundWorkflow_AccountName...', 'Process Inbound to outbound for AccountName';


			/*=============================================================================================
					Delete data from inbound where batchID Has been processed to outbound and Change S
			==============================================================================================*/

			DELETE I FROM [Inbound].[CatCode] I JOIN @BatchID B ON B.PK_BatchID = I.[FK_Batch];

			UPDATE	bq
			SET		[Status] = 'Outbound'
			FROM	Inbound.BatchQueue	bq
			JOIN	@BatchID bi 
				ON  bq.Pk_Batch = bi.PK_BatchID
				

			RAISERROR('Completed AccountName: %i', 0, 0, @@rowcount) WITH NOWAIT;

		END;

		-- LOGIN THE RESULT WITH SUCCESS
		INSERT @Logging(ActivityStatus, ActivityName) SELECT 2 , @p_ActivityName;

		--Generate logging for success
		EXEC log.usp_LogContract @Input = @Logging;

		IF @Trancount = 0 COMMIT;

	END TRY
	BEGIN CATCH

		IF @Trancount = 0 ROLLBACK;

		-----On error Change status to failed from running
		UPDATE		q
		SET			Status = 'OutBoundFailed'
		FROM		Inbound.BatchQueue	q
		INNER JOIN	@BatchID B ON q.Pk_Batch = B.PK_BatchID;


		-- LOG THE RESULT WITH ERROR
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 4, 'Inbound.usp_InboundOutboundWorkflow_AccountName...', ERROR_MESSAGE();

		EXEC log.usp_LogContract @Input = @Logging;

		THROW;

	END CATCH;
END
GO


