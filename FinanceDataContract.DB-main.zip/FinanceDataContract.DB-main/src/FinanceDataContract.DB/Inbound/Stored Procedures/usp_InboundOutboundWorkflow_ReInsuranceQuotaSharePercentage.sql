﻿CREATE PROCEDURE [Inbound].[usp_InboundOutboundWorkflow_ReInsuranceQuotaSharePercentage]
AS
-- =============================================

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	2021-07-21
-- Changes:				Original version. Does a merge (delete,update & insert) so the outbound table is a reflection of source.

-- =============================================	

BEGIN

	set nocount on

	DECLARE @Logging	log.utt_ActivityLog;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Trancount INT = @@Trancount;
	DECLARE @BatchID AS BATCHID;


	INSERT @Logging(ActivityStatus, ActivityName) SELECT 1, @p_ActivityName;
	
	BEGIN TRY

		IF @Trancount = 0 BEGIN TRAN;


		declare @DataSet varchar(50) = ('ReInsuranceQuotaSharePercentage')

		IF EXISTS (SELECT Pk_Batch FROM Inbound.BatchQueue WHERE Status = 'InBound' AND DataSet = @DataSet)
		BEGIN

			/*=============================================================================================
         	Select Pending BatchID 
			==============================================================================================*/

			INSERT INTO @BatchID
			SELECT	Pk_Batch
					,DataSet
					,AsAt
			FROM	Inbound.BatchQueue
			WHERE	[Status] = 'InBound'
			AND     DataSet = @DataSet;
			
			RAISERROR('@BatchID: %i', 0, 0, @@rowcount) WITH NOWAIT;

			---set batch status to running from Pending
			UPDATE		bq
			SET			[Status] = 'Running'
			FROM		Inbound.BatchQueue	bq
			INNER JOIN	@BatchID bi 
				ON  bq.Pk_Batch = bi.PK_BatchID				

			RAISERROR('Running: %i', 0, 0, @@rowcount) WITH NOWAIT;

			
			merge [Outbound].ReInsuranceQuotaSharePercentage as t
			using
			(
				select
					[BusinessKey]
					,[AccountingPeriod]
					,[TrifocusCode]
					,[TrifocusName]
					,[Entity]
					,[YOA]
					,[SettlementCCY]
					,[QS_Premium]
					,[GrossUltimates]
					,[QS%]
					,[FK_Batch]
					,[AuditDateTime]
					,[AuditUser]
					,[AuditHost]
				from 
					[Inbound].[ReInsuranceQuotaSharePercentage] p
					join @BatchID b ON b.PK_BatchID = p.FK_Batch
			) s 
			on 
				s.[BusinessKey] = t.[BusinessKey]
			when not matched by source then
				delete 
			when not matched then 
				insert 
				(
					[BusinessKey],
					[AccountingPeriod],
					[TrifocusCode],
					[TrifocusName],
					[Entity],
					[YOA],
					[SettlementCCY],
					[QS_Premium],
					[GrossUltimates],
					[QS%],
					[FK_Batch_Insert],
					[AuditCreateDateTime],
					[AuditUserCreate],
					[AuditHostCreate]
				)
				values
				(
					s.[BusinessKey],
					s.[AccountingPeriod],
					s.[TrifocusCode],
					s.[TrifocusName],
					s.[Entity],
					s.[YOA],
					s.[SettlementCCY],
					s.[QS_Premium],
					s.[GrossUltimates],
					s.[QS%],
					s.[FK_Batch],
					s.[AuditDateTime],
					s.[AuditUser],
					s.[AuditHost]
				)
			when matched and 
				1 = case 
					when t.[TrifocusName] = s.[TrifocusName] then 0 
					when t.[TrifocusName] is null and s.[TrifocusName] is null then 0
					else 1
					end

				or

				1 = case 
					when t.[QS_Premium] = s.[QS_Premium] then 0 
					when t.[QS_Premium] is null and s.[QS_Premium] is null then 0
					else 1
					end

				or

				1 = case 
					when t.[GrossUltimates] = s.[GrossUltimates] then 0 
					when t.[GrossUltimates] is null and s.[GrossUltimates] is null then 0
					else 1
					end

				or

				1 = case 
					when t.[QS%] = s.[QS%] then 0 
					when t.[QS%] is null and s.[QS%] is null then 0
					else 1
					end

				then
					update 
					set 
						[AccountingPeriod] = s.[AccountingPeriod]
						,[TrifocusCode] = s.[TrifocusCode]
						,[TrifocusName] = s.[TrifocusName]
						,[Entity] = s.[Entity]
						,[YOA] = s.[YOA]
						,[SettlementCCY] = s.[SettlementCCY]
						,[QS_Premium] = s.[QS_Premium]
						,[GrossUltimates] = s.[GrossUltimates]
						,[QS%] = s.[QS%]
						,[FK_Batch_Update] = s.[FK_Batch]
						,[AuditUpdateDateTime] = s.[AuditDateTime]
						,[AuditUserUpdate] = s.[AuditUser]
						,[AuditHostUpdate] = s.[AuditHost];

			RAISERROR('[Outbound].[ReInsuranceQuotaSharePercentage] merge: %i', 0, 0, @@rowcount) WITH NOWAIT;


			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, @p_ActivityName, 'Process Inbound to outbound for ReInsuranceQuotaSharePercentage';

			/*=============================================================================================
					Delete data from inbound where batchID Has been processed to outbound and Change S
			==============================================================================================*/

			DELETE I FROM [Inbound].[CatCode] I JOIN @BatchID B ON B.PK_BatchID = I.[FK_Batch];

			UPDATE	bq
			SET		[Status] = 'Outbound'
			FROM	Inbound.BatchQueue	bq
			JOIN	@BatchID bi 
				ON  bq.Pk_Batch = bi.PK_BatchID
				

			RAISERROR('Completed ReInsuranceQuotaSharePercentage: %i', 0, 0, @@rowcount) WITH NOWAIT;

		END;

		-- LOGIN THE RESULT WITH SUCCESS
		INSERT @Logging(ActivityStatus, ActivityName) SELECT 2 , @p_ActivityName;

		--Generate logging for success
		EXEC log.usp_LogContract @Input = @Logging;

		IF @Trancount = 0 COMMIT;

	END TRY
	BEGIN CATCH

		IF @Trancount = 0 ROLLBACK;

		-----On error Change status to failed from running
		UPDATE		q
		SET			Status = 'OutBoundFailed'
		FROM		Inbound.BatchQueue	q
		INNER JOIN	@BatchID B ON q.Pk_Batch = B.PK_BatchID;


		-- LOG THE RESULT WITH ERROR
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 4, @p_ActivityName, ERROR_MESSAGE();

		EXEC log.usp_LogContract @Input = @Logging;

		THROW;

	END CATCH;
END

