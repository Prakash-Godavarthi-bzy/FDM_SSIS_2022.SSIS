﻿CREATE PROCEDURE [Inbound].[usp_InboundOutboundWorkflow_RIPercentage]
AS
-- =============================================

-- Modified by:			samata.putumbaka@beazley.com
-- Modification date:	2021-06-07
-- Changes:				Code moves treaty contract details from Inbound to Outbound.

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	2021-08-10
-- Changes:				Removed the columns [RI_Code] & [RI_Programme_Description] and added the new column ProgrammeCode.

-- Modified by:			Nikil.Nallamothu@beazley.com
-- Modification date:	2023-01-27
-- Changes:				Added the Truncate script of OutBound.RIPercentage Table. Done as part of ticket https://beazley.atlassian.net/browse/I1B-3629
-- =============================================	

BEGIN

	set nocount on

	DECLARE @Logging	log.utt_ActivityLog;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Trancount INT = @@Trancount;
	DECLARE @BatchID AS BATCHID;


	INSERT @Logging(ActivityStatus, ActivityName) SELECT 1, @p_ActivityName;
	
	BEGIN TRY

		IF @Trancount = 0 BEGIN TRAN;


		DECLARE @DataSet	VARCHAR(50)	= 'RIPercentage'
		--SELECT * FROM Inbound.BatchQueue WHERE Status = 'InBound' AND DataSet = @DataSet

		IF EXISTS (SELECT Pk_Batch FROM Inbound.BatchQueue WHERE Status = 'InBound' AND DataSet = @DataSet)
		BEGIN

			/*=============================================================================================
         	Select Pending BatchID 
			==============================================================================================*/

			INSERT INTO @BatchID
			SELECT	Pk_Batch
					,DataSet
					,AsAt
			FROM	Inbound.BatchQueue
			WHERE	[Status] = 'InBound'
			AND     DataSet = @DataSet;
			
			RAISERROR('@BatchID: %i', 0, 0, @@rowcount) WITH NOWAIT;

			---set batch status to running from Pending
			UPDATE		bq
			SET			[Status] = 'Running'
			FROM		Inbound.BatchQueue	bq
			INNER JOIN	@BatchID bi 
				ON  bq.Pk_Batch = bi.PK_BatchID				

			RAISERROR('Running: %i', 0, 0, @@rowcount) WITH NOWAIT;
				 
		/*==========================================================================
				Commented out the condition , Done as part of https://beazley.atlassian.net/browse/I1B-3629
		  ============================================================================			
			update t
			set
				t.RowIsLatest = 0
			from 
				[Outbound].[RIPercentage] t
				join Inbound.RIPercentage s on s.Businesskey = t.BusinessKey
				join @BatchID b ON b.PK_BatchID = s.FK_Batch
			where
				t.RowIsLatest != 0
        */

			/*==========================================================================
				Inside Iteration- Truncate OutBound.RIPercentage Table , Done as part of https://beazley.atlassian.net/browse/I1B-3629
			 ============================================================================*/

					 IF EXISTS(SELECT  1 FROM [FinanceDataContract].[Outbound].[RIPercentage]) 
						BEGIN

							TRUNCATE TABLE [FinanceDataContract].Outbound.[RIPercentage]

							INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
						   SELECT 5, 'Inbound.usp_InboundOutboundWorkflow_RIPercentage', '[Outbound].[RIPercentage] table Truncated';

									
						END
			/*=======================================================================================================================================
				Inside Iteration- Insert Inbound.RIPercentage table data into OutBound.RIPercentage Table
			========================================================================================================================================*/
			INSERT INTO [Outbound].[RIPercentage] WITH(TABLOCK)
			(
			     [AccountingPeriod]
				 ,[TrifocusCode]
				 ,[TrifocusName]
				 ,[Entity]
				 ,[YOA]
				 ,[YOI]
				 ,[RIProgramme]
				 ,[RIType]
				 ,[SettlementCCY]
				 ,[RIPolicyNumber]
				 ,[InceptionDate]
				 ,[ExpiryDate]
				 ,[ClaimsBasis]
				 ,[RIPremium]
				 ,[GrossNetUltimates]
				 ,[RI%]
				 ,[Businesskey]
				 ,[FK_Batch]
				 ,[AuditCreateDateTime]
				 ,[AuditUserCreate]
				 ,[AuditHost]
				 ,[AuditAction]
				 ,[RowHash]
				 ,[RowIsLatest] 
				 ,[RowVersionNumber]
			)
			SELECT 
				 [AccountingPeriod]
				 ,[TrifocusCode]
				 ,[TrifocusName]
				 ,[Entity]
				 ,[YOA]
				 ,[YOI]
				 ,[RIProgramme]
				 ,[RIType]
				 ,[SettlementCCY]
				 ,[RIPolicyNumber]
				 ,[InceptionDate]
				 ,[ExpiryDate]
				 ,[ClaimsBasis]
				 ,[RIPremium]
				 ,[GrossNetUltimates]
				 ,[RI%]
				 ,[Businesskey]
				 ,[FK_Batch]
				 ,[AuditCreateDateTime]
				 ,[AuditUserCreate]
				 ,[AuditHost]
				 ,[AuditAction]
				 ,[RowHash]
				 ,[RowIsLatest] = 1
				 ,[RowVersionNumber]
			FROM   
				[Inbound].RIPercentage p
				join @BatchID b ON b.PK_BatchID = p.FK_Batch

			RAISERROR('[Outbound].[RIPercentage] insert: %i', 0, 0, @@rowcount) WITH NOWAIT;


			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, 'Inbound.usp_InboundOutboundWorkflow_RIPercentage', 'Process Inbound to outbound for RIPercentage';

			/*=============================================================================================
					Delete data from inbound where batchID Has been processed to outbound and Change S
			==============================================================================================*/

			DELETE I FROM [Inbound].[RIPercentage] I JOIN @BatchID B ON B.PK_BatchID = I.[FK_Batch];

			UPDATE	bq
			SET		[Status] = 'Outbound'
			FROM	Inbound.BatchQueue	bq
			JOIN	@BatchID bi 
				ON  bq.Pk_Batch = bi.PK_BatchID
				

			RAISERROR('Completed RIPercentage: %i', 0, 0, @@rowcount) WITH NOWAIT;

		END;

		-- LOGIN THE RESULT WITH SUCCESS
		INSERT @Logging(ActivityStatus, ActivityName) SELECT 2 , @p_ActivityName;

		--Generate logging for success
		EXEC log.usp_LogContract @Input = @Logging;

		IF @Trancount = 0 COMMIT;

	END TRY
	BEGIN CATCH

		IF @Trancount = 0 ROLLBACK;

		-----On error Change status to failed from running
		UPDATE		q
		SET			Status = 'OutBoundFailed'
		FROM		Inbound.BatchQueue	q
		INNER JOIN	@BatchID B ON q.Pk_Batch = B.PK_BatchID;


		-- LOG THE RESULT WITH ERROR
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 4, 'Inbound.usp_InboundOutboundWorkflow_RIPercentage', ERROR_MESSAGE();

		EXEC log.usp_LogContract @Input = @Logging;

		THROW;

	END CATCH;
END
GO


