﻿CREATE PROCEDURE [Inbound].[usp_InboundOutboundWorkflow_PolicySectionReferences]
AS
-- =============================================

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	2021-05-26
-- Changes:				Removed the section reference from the extensions table, and made changes for the table rename LargeLossCatCode to CatCode.

-- =============================================	

BEGIN

	set nocount on

	DECLARE @Logging	log.utt_ActivityLog;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Trancount INT = @@Trancount;
	DECLARE @BatchID AS BATCHID;


	INSERT @Logging(ActivityStatus, ActivityName) SELECT 1, @p_ActivityName;
	
	BEGIN TRY

		IF @Trancount = 0 BEGIN TRAN;


		declare @DataSet char(26) = ('BI_PolicySectionReferences')

		IF EXISTS (SELECT Pk_Batch FROM Inbound.BatchQueue WHERE Status = 'InBound' AND DataSet = @DataSet)
		BEGIN

			/*=============================================================================================
         	Select Pending BatchID 
			==============================================================================================*/

			INSERT INTO @BatchID
			SELECT	Pk_Batch
					,DataSet
					,AsAt
			FROM	Inbound.BatchQueue
			WHERE	[Status] = 'InBound'
			AND     DataSet = @DataSet;
			
			RAISERROR('@BatchID: %i', 0, 0, @@rowcount) WITH NOWAIT;

			---set batch status to running from Pending
			UPDATE		bq
			SET			[Status] = 'Running'
			FROM		Inbound.BatchQueue	bq
			INNER JOIN	@BatchID bi 
				ON  bq.Pk_Batch = bi.PK_BatchID				

			RAISERROR('Running: %i', 0, 0, @@rowcount) WITH NOWAIT;
				 
			
			INSERT INTO [Outbound].PolicySectionReference WITH(TABLOCK)
			(
				 [PolicyReference]
				,[SectionReference]
				,[FK_Batch]
			)
			SELECT 
				 p.[PolicyReference]
				,p.[SectionReference]
				,p.[FK_Batch]
			FROM   
				[Inbound].PolicySectionReference p
				join @BatchID b ON b.PK_BatchID = p.FK_Batch
				left join [Outbound].PolicySectionReference t 
					on  t.[PolicyReference] = p.[PolicyReference]
					and t.[SectionReference] = p.[SectionReference]
			where
				t.[SectionReference] is null							   			

			RAISERROR('[Outbound].[PolicySectionReference] insert: %i', 0, 0, @@rowcount) WITH NOWAIT;


			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, 'Inbound.usp_InboundOutboundWorkflow_PolicySecti...', 'Process Inbound to outbound for PolicySectionReference';


			/*=============================================================================================
					Delete data from inbound where batchID Has been processed to outbound and Change S
			==============================================================================================*/

			DELETE I FROM [Inbound].[CatCode] I JOIN @BatchID B ON B.PK_BatchID = I.[FK_Batch];

			UPDATE	bq
			SET		[Status] = 'Outbound'
			FROM	Inbound.BatchQueue	bq
			JOIN	@BatchID bi 
				ON  bq.Pk_Batch = bi.PK_BatchID
				

			RAISERROR('Completed PolicySectionReference: %i', 0, 0, @@rowcount) WITH NOWAIT;

		END;

		-- LOGIN THE RESULT WITH SUCCESS
		INSERT @Logging(ActivityStatus, ActivityName) SELECT 2 , @p_ActivityName;

		--Generate logging for success
		EXEC log.usp_LogContract @Input = @Logging;

		IF @Trancount = 0 COMMIT;

	END TRY
	BEGIN CATCH

		IF @Trancount = 0 ROLLBACK;

		-----On error Change status to failed from running
		UPDATE		q
		SET			Status = 'OutBoundFailed'
		FROM		Inbound.BatchQueue	q
		INNER JOIN	@BatchID B ON q.Pk_Batch = B.PK_BatchID;


		-- LOG THE RESULT WITH ERROR
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 4, 'Inbound.usp_InboundOutboundWorkflow_PolicySecti...', ERROR_MESSAGE();

		EXEC log.usp_LogContract @Input = @Logging;

		THROW;

	END CATCH;
END
GO


