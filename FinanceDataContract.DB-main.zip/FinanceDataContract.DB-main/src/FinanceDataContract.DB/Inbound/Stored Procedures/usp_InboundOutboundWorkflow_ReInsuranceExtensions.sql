﻿CREATE PROCEDURE [Inbound].[usp_InboundOutboundWorkflow_ReInsuranceExtensions]
AS
BEGIN

	set nocount on

	DECLARE @Logging	log.utt_ActivityLog;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Trancount INT = @@Trancount;
	DECLARE @BatchID_ReInsuranceExtensions AS BATCHID;
	DECLARE @DataSet varchar(50) = 'ReInsuranceExtensions'

	INSERT @Logging(ActivityStatus, ActivityName) SELECT 1, @p_ActivityName;
	
	BEGIN TRY

		IF @Trancount = 0 BEGIN TRAN;

		--update q
		--SET [Status] = 'InBound' -- 
		--select *
		--FROM Inbound.BatchQueue q 
		--where DataSet='ReInsuranceExtensions' and Pk_Batch=4016

		IF EXISTS (SELECT Pk_Batch FROM Inbound.BatchQueue WHERE Status = 'InBound' AND DataSet = @DataSet)
		BEGIN

			/*=============================================================================================
         	Select Pending BatchID 
			==============================================================================================*/

			INSERT INTO @BatchID_ReInsuranceExtensions
			SELECT	Pk_Batch
					,DataSet
					,AsAt
			FROM	Inbound.BatchQueue
			WHERE	[Status] = 'InBound'
			AND     DataSet = @DataSet
			
			RAISERROR('@BatchID_ReInsuranceExtensions: %i', 0, 0, @@rowcount) WITH NOWAIT;

			---set batch status to running from Pending
			UPDATE		bq
			SET			[Status] = 'Running'
			FROM		Inbound.BatchQueue	bq
			INNER JOIN	@BatchID_ReInsuranceExtensions bi 
				ON  bq.Pk_Batch = bi.PK_BatchID
				

			RAISERROR('Running: %i', 0, 0, @@rowcount) WITH NOWAIT;
				 
			
            INSERT INTO Outbound.Transaction_ReInsurance_Extensions_Bridge WITH(TABLOCK)
			( 
				[RowHash_Transaction]
				,RowHash_Transaction_ReInsurance_Extensions
	            ,[FK_Batch]
			)
			SELECT 
				 p.[RowHash_Transaction] 
				,p.RowHash_Transaction_ReInsurance_Extensions
				,[FK_Batch] = MAX(p.[FK_Batch])
			FROM   
				[Inbound].Transaction_ReInsurance_Extensions_Bridge p
				JOIN @BatchID_ReInsuranceExtensions b ON b.PK_BatchID = p.FK_Batch
				LEFT JOIN Outbound.Transaction_ReInsurance_Extensions_Bridge t 
					ON  t.[RowHash_Transaction] = p.[RowHash_Transaction]
					AND t.RowHash_Transaction_ReInsurance_Extensions = p.RowHash_Transaction_ReInsurance_Extensions
			WHERE
				t.[RowHash_Transaction] is null
			GROUP BY 
				 p.[RowHash_Transaction] 
				,p.RowHash_Transaction_ReInsurance_Extensions
				

			RAISERROR('[Outbound].[Transaction_ReInsurance_Extensions_Bridge]: %i', 0, 0, @@rowcount) WITH NOWAIT;

			--print 'INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)'
			--select len('Inbound.usp_InboundOutboundWorkflow_ClaimExtensions'), len('Process Inbound to outbound for Transaction_Claim_Extensions_Bridge')

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, @p_ActivityName, 'Process Inbound to outbound for Transaction_ReInsurance_Extensions_Bridge';

			INSERT INTO [Outbound].[Transaction_ReInsurance_Extensions]  WITH(TABLOCK)
			(
				 [RowHash_Transaction_ReInsurance_Extensions]
				,[RIPolicyType]
				,[ProgrammeCode]
				,[BeazleyCatCode]
				,[TransactionDate]
				,[IsLargeLoss]
				,[FK_Batch]
			)
			SELECT 
				 p.[RowHash_Transaction_ReInsurance_Extensions]
				,p.[RIPolicyType]
				,p.[ProgrammeCode]
				,p.[BeazleyCatCode]
				,p.[TransactionDate]
				,p.[IsLargeLoss]
				,[FK_Batch] = MAX(p.[FK_Batch])
			FROM   
				[Inbound].Transaction_ReInsurance_Extensions p
				JOIN @BatchID_ReInsuranceExtensions b ON b.PK_BatchID = p.FK_Batch
				LEFT JOIN Outbound.Transaction_ReInsurance_Extensions t 
					ON  t.RowHash_Transaction_ReInsurance_Extensions = p.RowHash_Transaction_ReInsurance_Extensions
			WHERE
				t.RowHash_Transaction_ReInsurance_Extensions is null
			GROUP BY  
				 p.[RowHash_Transaction_ReInsurance_Extensions]
				,p.[RIPolicyType]
				,p.[ProgrammeCode]
				,p.[BeazleyCatCode]
				,p.[TransactionDate]
				,p.[IsLargeLoss]


			RAISERROR('[Outbound].[Transaction_ReInsurance_Extensions]: %i', 0, 0, @@rowcount) WITH NOWAIT;

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, @p_ActivityName, 'Process Inbound to outbound for Transaction_ReInsurance_Extensions';


			/*=============================================================================================
					Delete data from inbound where batchID Has been processed to outbound and Change S
			==============================================================================================*/

			DELETE I FROM [Inbound].Transaction_ReInsurance_Extensions_Bridge I JOIN @BatchID_ReInsuranceExtensions B ON B.PK_BatchID = I.[FK_Batch];
			DELETE I FROM [Inbound].Transaction_ReInsurance_Extensions I JOIN @BatchID_ReInsuranceExtensions B ON B.PK_BatchID = I.[FK_Batch];

			---Change status to Complete from running
			UPDATE	bq
			SET		[Status] = 'Outbound'
			FROM	Inbound.BatchQueue	bq
			JOIN	@BatchID_ReInsuranceExtensions bi 
				ON  bq.Pk_Batch = bi.PK_BatchID
				

			RAISERROR('Completed Transaction_ReInsurance_Extensions: %i', 0, 0, @@rowcount) WITH NOWAIT;

		END;

		-- LOGIN THE RESULT WITH SUCCESS
		INSERT @Logging(ActivityStatus, ActivityName) SELECT 2 , @p_ActivityName;

		--Generate logging for success
		EXEC log.usp_LogContract @Input = @Logging;

		IF @Trancount = 0 COMMIT;

	END TRY
	BEGIN CATCH

		IF @Trancount = 0 ROLLBACK;

		-----On error Change status to failed from running
		UPDATE		q
		SET			Status = 'OutBoundFailed'
		FROM		Inbound.BatchQueue	q
		INNER JOIN	@BatchID_ReInsuranceExtensions B ON q.Pk_Batch = B.PK_BatchID;

		-- LOG THE RESULT WITH ERROR
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 4, @p_ActivityName, ERROR_MESSAGE();

		EXEC log.usp_LogContract @Input = @Logging;

		THROW;

	END CATCH;
END
GO


