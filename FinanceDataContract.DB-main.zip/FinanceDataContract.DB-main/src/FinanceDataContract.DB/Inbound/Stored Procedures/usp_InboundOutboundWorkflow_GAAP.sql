﻿CREATE PROC [Inbound].[usp_InboundOutboundWorkflow_GAAP]
	
	@DoNonIFRS17_Tests bit = 1

AS
-- =======================================================================================================================================

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	2021-05-27
-- Changes:				Added the column FK_Allocation as it is used for the re-insurance allocations.

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	2021-08-31
-- Changes:				All entries in Outbound for IsToDate = 'N' entries are getting Delta Type 'New'. 
--						Now getting Adjustment when there are related entries.

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	2021-09-14
-- Changes:				Added the optional parameter @DoNonIFRS17_Tests so IFRS17 code doesn't have to run the tests that aren't applicable.

-- Modified by:			pavani.bandaru@beazley.com
-- Modification date:	2022-07-08
-- Changes:				CDC-change data capture , Amended DOF for reversals


--This Proc is using for GAAP datasets UsPremium, BICI,BIDAC, BAIC to perform delta Calculations as these are AsAt type of source

-- Also using for Non-GAAP dataset ObligatedPremium_MunichQQS included part of JIRA https://beazley.atlassian.net/browse/I1B-3621

-- Modified by:			pavani.bandaru@beazley.com
-- Modification date:	2024-04-18
-- Changes:				For Eurobase dataset if delta type is Adj or Restatement and Inbound BK,RH matches Outbount BK,RH then we are pulling DOF 
--						from batchQueue table else from Inbound.Transaction.
-- Jira:				https://beazley.atlassian.net/browse/I1B-3817
-- Parent Proc:			[Eb].[usp_LandingToInboundToOutboundWorkflow_Eurobase]

-- Modified by:			bhargav.entha@beazley.com
-- Modification date:	2024-06-24
-- Changes:				Case statement added for DateOfFact column
-- Jira:				https://beazley.atlassian.net/browse/I1B-5635

-- Modified by:			shahnawaz.ahmed@beazley.com
-- Modification date:	2024-07-22
-- Changes:				Removed case statement for DateOfFact column for Eurobase
-- Jira:				https://beazley.atlassian.net/browse/I1B-5672

--Change Version	: 1.0 
--Sprint			: BR1 Q3 24 committed
--Author			: lakshman.akasapu@beazley.com
--Modify Date	    : 2024-08-05 
--Description		: https://beazley.atlassian.net/browse/I1B-5328
						--Removed the procedures that were not using anymore
						--[Test].[usp_LogBatchAggregate_ExpectedOutboundFDMCHE]
						--[Test].[usp_LogBatchAggregate_ActualOutboundFDMCHE]
						--[Test].[usp_LogBatchAggregate_ExpectedTechnicalHubUSSYND]
						--[Test].[usp_LogBatchAggregate_ExpectedOutBoundUSSYND]

-- =======================================================================================================================================	
BEGIN
	--SET NOCOUNT ON;

	DECLARE @Trancount	INT = @@Trancount;

	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;
	DECLARE @p_Account NVARCHAR(255) = NULL;
	DECLARE @p_SourceSystem NVARCHAR(255) = NULL;
	DECLARE @CurrentDate DATETIME2	= GETDATE();
	DECLARE @BatchID AS BatchID;

	INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
	SELECT 1, @p_ActivityName, 'Inbound OutBound Workflow  Started';

	BEGIN TRY
		IF @Trancount = 0 
		BEGIN TRAN;
		IF EXISTS (SELECT Pk_Batch FROM Inbound.BatchQueue WHERE Status = 'InBound')
			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, '[Inbound].[usp_InboundOutboundWorkflow]', 'Pending  batches are being checked';
		BEGIN

			/*=============================================================================================
							Genrate Hashrow for inbound
		 ==============================================================================================*/

			--EXEC Inbound.usp_GenerateHashRow @p_SourceSystem, @p_Account;

			--INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			--SELECT 5, '[Inbound].[usp_InboundOutboundWorkflow]', 'Genrate Hashrow for inbound created';

			/*=============================================================================================
         					Select Pending BatchID 
			==============================================================================================*/

			--DECLARE @BatchID AS BatchID;
			INSERT @BatchID 
			SELECT	Pk_Batch, 
					[DataSet],
					AsAt
			FROM	Inbound.BatchQueue 
			WHERE	Status = 'InBound'
				AND (RunDescription = 'Baseload' OR RunDescription IS NULL);

			--declare @AsAt int
			--select @AsAt=ASAT from 	Inbound.BatchQueue 
			--WHERE	Status = 'InBound'
			--	AND (RunDescription = 'Baseload' OR RunDescription IS NULL);


			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, '[Inbound].[usp_InboundOutboundWorkflow]', 'Select Pending BatchID ';
			
			---set batch status to running from Pending
			UPDATE		q
			SET			Status = 'Running'
			FROM		Inbound.BatchQueue	q
			INNER JOIN	@BatchID B ON q.Pk_Batch = B.PK_BatchID;
			

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, '[Inbound].[usp_InboundOutboundWorkflow]', 'Batches are set to Running ';

			/*=============================================================================================
         					LogOutboundExpected Results
			==============================================================================================*/

			if @DoNonIFRS17_Tests = 1
			begin

				EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_ExpectedOutbound] @BatchID;
				--EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_ExpectedOutboundPFT] @BatchID; /*Commented it for I1B-1011*/
				EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_ExpectedOutboundFDM] @BatchID;
				
				EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_ExpectedOutBoundBICI] @BatchID;
				EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_ExpectedOutBoundBAIC] @BatchID;
				EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_ExpectedOutboundBIDAC] @BatchID;


			
				INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
				SELECT 5, '[Inbound].[usp_InboundOutboundWorkflow]', 'LogOutboundExpected Results';

			end

			/*=============================================================================================
					Process Inbound to outbound
			==============================================================================================*/
			


				/*
				=================================================================================================
				       Create CTE's and Temp tables for Inbound and Outbound
				=================================================================================================
				
				*/
			--	DECLARE @BatchID AS BatchID;
			--INSERT @BatchID 
			--DROP TABLE IF EXISTS #TEMP1
			--SELECT	Pk_Batch as PK_batchID, 
			--		[DataSet] 
			--		into #temp1
			--FROM	Inbound.BatchQueue 
			--WHERE	Status = 'InBound'
			--	AND (RunDescription = 'Baseload' OR RunDescription IS NULL);

			DROP TABLE IF EXISTS #TEMP
			SELECT	Pk_Batch AS PK_BatchID, 
					OriginalName,DataSet INTO #TEMP
			FROM	Inbound.BatchQueue  
			WHERE	--Status = 'InBound'
			Status = 'Running' 
				AND (RunDescription = 'Baseload' OR RunDescription IS NULL);

			drop table if exists	#temp_IB
			
				;With Inbound as
				(
				SELECT			SumofInbound				= SUM([Value])
											,I.Scenario
											,I.Account
											,I.[Dataset]
											,I.DateOfFact
											,I.BusinessKey
											,I.PolicyNumber
											,I.InceptionDate
											,I.ExpiryDate
											,I.BindDate
											,I.DueDate
											,I.[BoundDate]
											,I.TrifocusCode
											,I.Entity
											,I.StatsCode
											,I.YOA
											,I.TypeOfBusiness
											,I.SettlementCCY
											,I.OriginalCCY
											,I.IsToDate
											,I.RowHash
											,I.FK_Allocation
											,AuditSourceBatchID		= ISNULL(I.AuditSourceBatchID, B.PK_BatchID)
											,AuditGenerateDateTime	= MAX(I.AuditGenerateDateTime)
											,I.AuditHost
											,Transactional			= CASE 
																		WHEN I.DeltaType IS NOT NULL THEN I.DeltaType
																		WHEN d.RowHash IS NULL AND I.IsToDate = 'N' THEN 'New' 
																		WHEN d.RowHash IS NOT NULL AND I.IsToDate = 'N' THEN 'Adjustment' 
																		END
											,I.[Basis]
											,I.[Location]
											,OrigSumofInbound		= SUM(I.[ValueOrig])
											,BusinessProcessCode	= MAX(I.[BusinessProcessCode])
											,FK_Batch				= MAX(I.[FK_Batch])
											,B.ASAT
							FROM			Inbound.[Transaction]														AS I
							LEFT JOIN		(SELECT DISTINCT RowHash FROM Outbound.[Transaction] WHERE IsToDate = 'N')	AS d ON I.RowHash = d.RowHash
							INNER JOIN		@BatchID																	AS B ON I.AuditSourceBatchID = B.PK_BatchID
																															AND I.[Dataset] = B.DataSet
							GROUP BY Scenario
									,Account
									,I.[Dataset]
									,DateOfFact
									,BusinessKey
									,PolicyNumber
									,InceptionDate
									,ExpiryDate
									,BindDate
									,DueDate
									,I.[BoundDate]
									,TrifocusCode
									,Entity
									,StatsCode
									,YOA
									,TypeOfBusiness
									,SettlementCCY
									,OriginalCCY
									,IsToDate
									,I.RowHash
									,AuditSourceBatchID
									,AuditHost
									,B.PK_BatchID
									,d.RowHash
									,I.FK_Allocation
									,I.[Basis]
									,I.[Location]
									,I.DeltaType
									,B.ASAT

									Having SUM(Value)<>0
									) 
	Select * into #temp_IB from Inbound 

	drop table if exists	#temp_oB
	;with  Outbound as 
	(
	SELECT			Sumofoutbound		= SUM([Value])
											,Scenario
											,Account
											,o.[Dataset]
											,DateOfFact		= MAX(DateOfFact)
											,BusinessKey
											,PolicyNumber
											,InceptionDate
											,ExpiryDate
											,BindDate
											,DueDate
											,o.[BoundDate]
											,TrifocusCode
											,Entity
											,StatsCode
											,YOA
											,TypeOfBusiness
											,SettlementCCY
											,OriginalCCY
											,IsToDate
											,RowHash
											,o.FK_Allocation
											,B.PK_BatchID
											,o.[Basis]
											,o.[Location]
											,OrigSumofOutbound		= SUM(o.[ValueOrig])
											,BusinessProcessCode	= MAX(o.[BusinessProcessCode])
											,FK_Batch				= MAX(o.[FK_Batch])
							FROM			
								Outbound.[Transaction]	o

								JOIN Inbound.BatchQueue BQ 
									ON  BQ.Pk_Batch = o.AuditSourceBatchID 
									AND BQ.DataSet = o.Dataset

								JOIN #TEMP AS B 
									ON 
									(
										CASE WHEN BQ.[OriginalName] = 'Adjustments' THEN o.Dataset + BQ.OriginalName ELSE o.Dataset END
									)
									= 
									(
										CASE WHEN B.OriginalName = 'Adjustments' THEN B.Dataset + B.OriginalName ELSE B.Dataset END 
									)
							WHERE			
								IsToDate = 'Y'
							GROUP BY Scenario
									,Account
									,o.[Dataset]
									,BusinessKey
									,PolicyNumber
									,InceptionDate
									,ExpiryDate
									,BindDate
									,DueDate
									,o.[BoundDate]
									,TrifocusCode
									,Entity
									,StatsCode
									,YOA
									,TypeOfBusiness
									,SettlementCCY
									,OriginalCCY
									,IsToDate
									,RowHash
									,o.FK_Allocation
									,B.PK_BatchID
									,o.[Basis]
									,o.[Location]
							HAVING			
								SUM([Value]) <> 0 ---Don't process Hashrows that already been processed as deleted or missing 
									
	)


	Select * into #temp_OB from Outbound;

	/*
	==========================================================================================================================
	          Fetch New And Adjustments Records
	==========================================================================================================================

	select *
	from #temp_IB where  PolicyNumber='W0000151418P_PC' and Account='P-GP-P'

	select *
	from #temp_OB where PolicyNumber='W0000151418P_PC' and Account='P-GP-P'
		
	*/

	drop table if exists #temp_OutboundTransactions
	Select * Into #temp_OutboundTransactions from 
	   (
	   SELECT * FROM
	   (
			select 
			I.Scenario, 
			I.Account, 
			I.[Dataset],
			I.ASAT,
			I.DateOfFact,
			/*
			case 
			      when I.Dataset='Eurobase' and O.BusinessKey=I.BusinessKey and O.RowHash=I.RowHash
				  and ISNULL(sum(I.SumofInbound),0)<>ISNULL(Sum(O.Sumofoutbound),0) 
				  then convert(date, cast(I.ASAT as varchar) + '01')
				 else I.DateOfFact			
			End as DateOfFact
			*/
			--I.DateOfFact,
			I.BusinessKey, 
			I.PolicyNumber, 
			I.InceptionDate, 
			I.ExpiryDate
			,I.BindDate
			,I.DueDate
			,I.[BoundDate]
			,I.TrifocusCode
			,I.Entity
			,I.StatsCode
			,I.YOA
			,I.TypeOfBusiness
			,I.SettlementCCY
			,I.OriginalCCY
			,I.IsToDate
			--,I.[Value]
			,I.RowHash
			,I.FK_Allocation
			,I.AuditSourceBatchID
			,I.AuditGenerateDateTime
			,I.AuditHost
		--	,I.DeltaType
			,I.[Basis]
			,I.[Location]
			--,I.[ValueOrig]
			,I.[BusinessProcessCode]
			,I.[FK_Batch]
						
			,sum(I.SumofInbound) as IB_Val
		    ,sum(O.Sumofoutbound) as OB_Val
			,sum(ISNULL(I.SumofInbound,0))-sum(ISNULL(O.SumofOutbound,0)) as val
			,sum(ISNULL(I.OrigSumofInbound, 0.0000)) -sum( ISNULL(O.OrigSumofOutbound, 0.0000)) as ValueOrig
			,O.PolicyNumber as OB_PolicyNumber 
	     	,O.BusinessKey as OBBK, O.RowHash  OBRH
			,case 
			      when O.BusinessKey is  null and I.BusinessKey is not null  then 'New' 
			      when O.BusinessKey=I.BusinessKey and O.RowHash=I.RowHash  then 'Adjustment'
								
			End as Deltatype
				
			From #temp_IB I
			LEFT JOIN #temp_OB O ON O.BusinessKey=I.BusinessKey
			--where  I.BusinessKey='P-OR-P-TTY|R0139M16|2623|2016|EUR|768'
			Group by 
			I.[Transactional]
			,I.BusinessKey 
			,I.RowHash 
			,O.BusinessKey 
			,O.RowHash  
			,O.PolicyNumber
			,I.Scenario 
			,I.Account
			,I.[Dataset]
			,I.DateOfFact
			,I.PolicyNumber 
			,I.InceptionDate
			,I.ExpiryDate
			,I.BindDate
			,I.DueDate
			,I.[BoundDate]
			,I.TrifocusCode
			,I.Entity
			,I.StatsCode
			,I.YOA
			,I.TypeOfBusiness
			,I.SettlementCCY
			,I.OriginalCCY
			,I.IsToDate
			--,I.[Value]
			--,I.RowHash
			,I.FK_Allocation
			,I.AuditSourceBatchID
			,I.AuditGenerateDateTime
			,I.AuditHost
		--	,I.DeltaType
			,I.[Basis]
			,I.[Location]
			--,I.[ValueOrig]
			,I.[BusinessProcessCode]
			,I.[FK_Batch]
			,I.ASAT
		Having sum(ISNULL(I.SumofInbound,0))-sum(ISNULL(O.SumofOutbound,0))<>0
		) AS F WHERE F.Deltatype IS NOT NULL
		/*
		=================================================================================================================
		Fetch Reversals (including restatement reversals)
		=================================================================================================================
		*/
	Union All

		Select * from (									
			Select
			O.Scenario
			,O.Account
			,O.[Dataset]
			,B1.ASAT
			
			,DateOfFact				= convert(date, cast(B1.ASAT as varchar) + '01')
			
			
			--,DateOfFact				= case when Left(Replace(convert(date,O.InceptionDate,105),'-',''),6) < cast(B1.ASAT as int) 
			--											then eomonth(convert(date, cast(B1.ASAT as varchar) + '01'))
			--											else O.InceptionDate
			--										END 
													
												
			--,DateOfFact				= CAST(case when convert(varchar(6), Replace(O.InceptionDate,'-',''), 112) < cast(B1.ASAT as varchar) 
			--											then eomonth(convert(date, cast(B1.ASAT as varchar) + '01'))
			--											else O.InceptionDate
			--										END 
			--										AS DATETIME2
			--							)
		--	, case when I.[Transactional] is not null then I.DateOfFact else O.DateOfFact end as DateOfFact
			,O.BusinessKey 
			,O.PolicyNumber
			,O.InceptionDate
			,O.ExpiryDate
			,O.BindDate
			,O.DueDate
			,O.[BoundDate]
			,O.TrifocusCode
			,O.Entity
			,O.StatsCode
			,O.YOA
			,O.TypeOfBusiness
			,O.SettlementCCY
			,O.OriginalCCY
			,O.IsToDate
			--,O.[Value]
			,O.RowHash
			,O.FK_Allocation
			,o.PK_BatchID as AuditSourceBatchID
			,getdate() as AuditGenerateDateTime
			,@@SERVERNAME as AuditHost
		--	,O.DeltaType
			,O.[Basis]
			,O.[Location]
			--,O.[ValueOrig]
			,O.[BusinessProcessCode]
			,O.[FK_Batch]
									
			,sum(I.SumofInbound) as IB_Val
		    ,sum(O.Sumofoutbound) as OB_Val
			,sum(ISNULL(I.SumofInbound,0))-sum(ISNULL(O.SumofOutbound,0)) as val	
            ,sum(ISNULL(I.OrigSumofInbound, 0.0000)) - sum(ISNULL(O.OrigSumofOutbound, 0.0000)) as ValueOrig
									
			,I.PolicyNumber as IB_Policy
			,I.BusinessKey as IBBK,I.RowHash IBRH
			,case 
			    when  I.BusinessKey is null and I.RowHash is null and O.BusinessKey is not null and O.Rowhash is  not null then 'Reversal'
			 End as Deltatype
									
			From #temp_IB I
			Right Join #temp_OB O on O.RowHash=I.RowHash
			Inner join  @BatchID B1 on O.PK_BatchID=B1.PK_BatchID
			--where  I.BusinessKey='P-OR-P-TTY|R0139M16|2623|2016|EUR|768'
			Group by 
			 O.Scenario
			,O.Account
			,O.[Dataset]
			,O.DateOfFact
			,O.BusinessKey 
			,O.PolicyNumber
			,O.InceptionDate
			,O.ExpiryDate
			,O.BindDate
			,O.DueDate
			,O.[BoundDate]
			,O.TrifocusCode
			,O.Entity
			,O.StatsCode
			,O.YOA
			,O.TypeOfBusiness
			,O.SettlementCCY
			,O.OriginalCCY
			,O.IsToDate
			--,O.[Value]
			,O.RowHash
			,O.FK_Allocation
			,o.PK_BatchID 
			--,isnull(O.AuditSourceBatchID,i.AuditSourceBatchID)
			--,getdate() 
			--,ISNULL(Inbound.AuditGenerateDateTime, @CurrentDate)
			--,O.AuditHost
			--,@@SERVERNAME 
		--	,O.DeltaType
			,O.[Basis]
			,O.[Location]
			--,O.[ValueOrig]
			,O.[BusinessProcessCode]
			,O.[FK_Batch]
			,I.BusinessKey 
			,I.RowHash ,
			I.PolicyNumber
			,I.[Transactional]
			,B1.ASAT
		Having sum(ISNULL(i.SumofInbound,0))-sum(ISNULL(O.SumofOutbound,0))<>0
		) as e where e.Deltatype is not null

		) as OutboubdTran


		/*
		======================================================================================
		Insert New, Adjustment, Reversal records into outbound table
		======================================================================================
		*/

		
			INSERT Outbound.[Transaction] (Scenario, Account, [Dataset], DateOfFact, BusinessKey, PolicyNumber, InceptionDate, ExpiryDate
															,BindDate, DueDate, [BoundDate], 
															TrifocusCode, Entity, StatsCode, YOA, TypeOfBusiness, SettlementCCY
															,OriginalCCY, IsToDate, [Value], RowHash, FK_Allocation, AuditSourceBatchID, AuditGenerateDateTime, AuditHost
															,DeltaType, [Basis], [Location], [ValueOrig], [BusinessProcessCode], [FK_Batch])

			Select Scenario, Account, [Dataset], DateOfFact, BusinessKey, PolicyNumber, InceptionDate, ExpiryDate
															,BindDate, DueDate, [BoundDate], 
															TrifocusCode, Entity, StatsCode, YOA, TypeOfBusiness, SettlementCCY
															,OriginalCCY, IsToDate, val, RowHash, FK_Allocation,
															AuditSourceBatchID, AuditGenerateDateTime, AuditHost
															,DeltaType, [Basis], [Location], [ValueOrig], [BusinessProcessCode], [FK_Batch]

															From #temp_OutboundTransactions





		/*
		===============================================================================================================
		Fetch and Insert Restatement records by excluding New records
		================================================================================================================

	select top 100 * from	#temp_OutboundTransactions
		*/

		
			INSERT Outbound.[Transaction] (Scenario, Account, [Dataset], DateOfFact, BusinessKey, PolicyNumber, InceptionDate, ExpiryDate
															,BindDate, DueDate, [BoundDate], 
															TrifocusCode, Entity, StatsCode, YOA, TypeOfBusiness, SettlementCCY
															,OriginalCCY, IsToDate, [Value], RowHash, FK_Allocation, AuditSourceBatchID, AuditGenerateDateTime, AuditHost
															,DeltaType, [Basis], [Location], [ValueOrig], [BusinessProcessCode], [FK_Batch])
		Select 	Scenario, Account, [Dataset], DateOfFact, /*case when dataset = 'Eurobase' then convert(date, cast(ASAT as varchar)+'01')
												else DateOfFact 
												end as DateOfFact,*/ BusinessKey, PolicyNumber, InceptionDate, ExpiryDate,BindDate, DueDate, [BoundDate], 
															TrifocusCode, Entity, StatsCode, YOA, TypeOfBusiness, SettlementCCY
															,OriginalCCY, IsToDate, val, RowHash, FK_Allocation,AuditSourceBatchID,AuditGenerateDateTime, AuditHost
														    ,'Restatement' as Deltatype , [Basis], [Location], [ValueOrig], [BusinessProcessCode], [FK_Batch]

      From (

		Select 	
		  	 I.Scenario 
			,I.Account 
			,I.[Dataset]
			,I.ASAT
			,I.DateOfFact
			/*case 
			      when I.Dataset='Eurobase' and O.BusinessKey=I.BusinessKey and O.RowHash=I.RowHash
				  and ISNULL(sum(I.SumofInbound),0)<>ISNULL(Sum(Sumofoutbound),0) 
				  then convert(date, cast(I.ASAT as varchar) + '01')
				 else I.DateOfFact			
			End as DateOfFact
			*/

			--,I.DateOfFact
			,I.BusinessKey 
			,I.PolicyNumber 
			,I.InceptionDate 
			,I.ExpiryDate
			,I.BindDate
			,I.DueDate
			,I.[BoundDate]
			,I.TrifocusCode
			,I.Entity
			,I.StatsCode
			,I.YOA
			,I.TypeOfBusiness
			,I.SettlementCCY
			,I.OriginalCCY
			,I.IsToDate
			--,I.[Value]
			,I.RowHash
			,I.FK_Allocation
			,I.AuditSourceBatchID
			,I.AuditGenerateDateTime
			,I.AuditHost
		--	,I.DeltaType
			,I.[Basis]
			,I.[Location]
			--,I.[ValueOrig]
			,I.[BusinessProcessCode]
			,I.[FK_Batch]
		
			,sum(I.SumofInbound) as IB_Val
			,sum(O.Sumofoutbound) as OB_Val
            ,sum(ISNULL(I.SumofInbound,0))-sum(ISNULL(O.SumofOutbound,0)) as val
			,sum(ISNULL(i.OrigSumofInbound, 0.0000)) - sum(ISNULL(OrigSumofOutbound, 0.0000)) as ValueOrig

			,O.PolicyNumber as OB_Policy
			,O.BusinessKey as OBBK
			,O.RowHash  OBRH
			,case 
			      when O.BusinessKey is  null and I.BusinessKey is not null  then 'New' 
			      when O.BusinessKey=I.BusinessKey and O.RowHash=I.RowHash  then 'Adjustment'
								
			End as Deltatype
								
			From #temp_IB I
			Left Join #temp_OB O on O.ROWHASH=I.RowHash
			where I.[Transactional] is null
		--	where Deltatype='New'
									
			Group by 
							
			I.BusinessKey 
			,I.RowHash 
			,O.BusinessKey 
			,O.RowHash  
			,O.PolicyNumber
			,I.Scenario 
			,I.Account
			,I.[Dataset]
			,I.DateOfFact
			,I.PolicyNumber 
			,I.InceptionDate
			,I.ExpiryDate
			,I.BindDate
			,I.DueDate
			,I.[BoundDate]
			,I.TrifocusCode
			,I.Entity
			,I.StatsCode
			,I.YOA
			,I.TypeOfBusiness
			,I.SettlementCCY
			,I.OriginalCCY
			,I.IsToDate
			--,I.[Value]
			--,I.RowHash
			,I.FK_Allocation
			,I.AuditSourceBatchID
			,I.AuditGenerateDateTime
			,I.AuditHost
		--	,I.DeltaType
			,I.[Basis]
			,I.[Location]
			--,I.[ValueOrig]
			,I.[BusinessProcessCode]
			,I.[FK_Batch]
			,I.ASAT
		Having sum(ISNULL(I.SumofInbound,0))-sum(ISNULL(O.SumofOutbound,0))<>0
		
		Except
		(
		 Select * from #temp_OutboundTransactions 
		)

		) as RestatementRecords

		

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, '[Inbound].[usp_InboundOutboundWorkflow]', 'Process Inbound to outbound';

			/*=============================================================================================
					Delete data from inbound where batchID Has been processed to outbound and Change S
			==============================================================================================*/

			DELETE I FROM Inbound.[Transaction] I INNER JOIN @BatchID B ON B.PK_BatchID = I.AuditSourceBatchID;

			---Change status to Complete from running
			UPDATE		q
			SET			Status = 'OutBound'
			FROM		Inbound.BatchQueue	q
			INNER JOIN	@BatchID			B ON q.Pk_Batch = B.PK_BatchID;

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT	5
					,	'[Inbound].[usp_InboundOutboundWorkflow]'
					,'Delete data from inbound where batchID Has been processed to outbound and Change S';

			/*
			=============================================================================================
				LogOutbound Aggregate Actual Value
			==============================================================================================
			*/

			if @DoNonIFRS17_Tests = 1
			begin

				EXEC [Test].[usp_LogBatchAggregate_ActualOutbound] @BatchID;

				--EXEC [Test].[usp_LogBatchAggregate_ActualOutboundPFT] @BatchID; /*Commented it for I1B-1011*/

				EXEC [Test].[usp_LogBatchAggregate_ActualOutboundFDM] @BatchID;

				 
				EXEC [Test].[usp_LogBatchAggregate_ActualOutBoundBICI]  @BatchID;
				EXEC [Test].[usp_LogBatchAggregate_ActualOutBoundBAIC]   @BatchID;
				EXEC [Test].[usp_LogBatchAggregate_ActualOutBoundUSSYND] @BatchID;
				EXEC [Test].[usp_LogBatchAggregate_ActualOutboundBIDAC]  @BatchID;

				INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
				SELECT 5, '[Inbound].[usp_InboundOutboundWorkflow]', 'LogOutbound Aggregate Actual Value';
				/*
				=============================================================================================
					Log Aggregate expected Value in technicalHubdb.fact.technicalresult
				==============================================================================================
				*/

				EXEC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHub] @BatchID;

		  	    EXEC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHubPFT] @BatchID;

				EXEC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHubFDM] @BatchID;

				EXEC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHubFDMCHE] @BatchID;

				EXEC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHubUSBAIC] @BatchID;

				EXEC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHubBIDAC] @BatchID;

				EXEC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHubBICI] @BatchID;

	

				INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
				SELECT	5
						,	'[Inbound].[usp_InboundOutboundWorkflow]'
						,'Log Aggregate expected Value in technicalHubdb.fact.technicalresult';

			end --if @DoNonIFRS17_Tests = 1


		END;
		IF @Trancount = 0 
			BEGIN
				RAISERROR('committing', 0, 0) WITH NOWAIT;
				COMMIT;
			END;
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, '[Eb].[usp_LandingInboundWorkflow]', 'Eurobase Succeeded';

		--Generate logging for success
		EXEC log.usp_LogContract @Input = @Logging;

	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK
		-----On error Change status to failed from running
		UPDATE		q
		SET			Status = 'OutBoundFailed'
		FROM		Inbound.BatchQueue	q
		INNER JOIN	@BatchID			B ON q.Pk_Batch = B.PK_BatchID;

		--Generate logging for error (outside tran)
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)

		SELECT 4, '[Inbound].[usp_InboundOutboundWorkflow]', ERROR_MESSAGE();
		EXEC log.usp_LogContract @Input = @Logging;

		THROW;
	END CATCH;
END;
GO