﻿CREATE PROCEDURE [Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTreatyContractAttributes]
AS
-- =============================================

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	2021-06-07
-- Changes:				Code moves treaty contract details from Inbound to Outbound.

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	2021-08-10
-- Changes:				Removed the columns [RI_Code] & [RI_Programme_Description] and added the new column ProgrammeCode.

-- =============================================	

BEGIN

	set nocount on

	DECLARE @Logging	log.utt_ActivityLog;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Trancount INT = @@Trancount;
	DECLARE @BatchID AS BATCHID;


	INSERT @Logging(ActivityStatus, ActivityName) SELECT 1, @p_ActivityName;
	
	BEGIN TRY

		IF @Trancount = 0 BEGIN TRAN;


		DECLARE @DataSet						VARCHAR(50)	= 'TreatyReInsurance_ContractAttributes'
		--SELECT * FROM Inbound.BatchQueue WHERE Status = 'InBound' AND DataSet = @DataSet

		IF EXISTS (SELECT Pk_Batch FROM Inbound.BatchQueue WHERE Status = 'InBound' AND DataSet = @DataSet)
		BEGIN

			/*=============================================================================================
         	Select Pending BatchID 
			==============================================================================================*/

			INSERT INTO @BatchID
			SELECT	Pk_Batch
					,DataSet
					,AsAt
			FROM	Inbound.BatchQueue
			WHERE	[Status] = 'InBound'
			AND     DataSet = @DataSet;
			
			RAISERROR('@BatchID: %i', 0, 0, @@rowcount) WITH NOWAIT;

			---set batch status to running from Pending
			UPDATE		bq
			SET			[Status] = 'Running'
			FROM		Inbound.BatchQueue	bq
			INNER JOIN	@BatchID bi 
				ON  bq.Pk_Batch = bi.PK_BatchID				

			RAISERROR('Running: %i', 0, 0, @@rowcount) WITH NOWAIT;
				 
			
			update t
			set
				t.RowIsLatest = 0
			from 
				[Outbound].ReInsuranceTreatyContractAttributes t
				join Inbound.ReInsuranceTreatyContractAttributes s on s.RI_Section_Reference = t.RI_Section_Reference
				join @BatchID b ON b.PK_BatchID = s.FK_Batch
			where
				t.RowIsLatest != 0

			INSERT INTO [Outbound].ReInsuranceTreatyContractAttributes WITH(TABLOCK)
			(
			    [RI_Section_Reference]
			   ,[RI_Policy_Type]
			   ,[ProgrammeCode]
			   ,[Inception_Date]
			   ,[Expiry_Date]
			   ,[Number_of_Reinstatements]
			   ,[Claim_Basis]
			   ,[Slip_Order_%]
			   ,[General_Description]
			   ,[Sum_Insured_Limit]
			   ,[Excess_Limit]
			   ,[Sum_Insured_Currency]
			   ,[Event_Limit]
			   ,[Event_Limit_Currency]
			   ,[Settlement_Limit]
			   ,[Settlement_Limit_Currency]
			   ,[Currency_Converter]
			   ,[Profit_Commission]
			   ,[Profit_Commission_Management_Expenses]
			   ,[Profit_Commission_Currency]
			   ,[Overrider]
			   ,[Average_QS_%]
			   ,[Number_of_QS_Policies]
			   ,[%_Ceded_to_QS]
			   ,[FK_Batch]
			   ,[AuditCreateDateTime]
			   ,[AuditUserCreate]
			   ,[AuditHost]
			   ,[AuditAction]
			   ,[RowHash]
			   ,[RowIsLatest]
			   ,[RowVersionNumber]
			)
			SELECT 
			    [RI_Section_Reference]
			   ,[RI_Policy_Type]
			   ,[ProgrammeCode]
			   ,[Inception_Date]
			   ,[Expiry_Date]
			   ,[Number_of_Reinstatements]
			   ,[Claim_Basis]
			   ,[Slip_Order_%]
			   ,[General_Description]
			   ,[Sum_Insured_Limit]
			   ,[Excess_Limit]
			   ,[Sum_Insured_Currency]
			   ,[Event_Limit]
			   ,[Event_Limit_Currency]
			   ,[Settlement_Limit]
			   ,[Settlement_Limit_Currency]
			   ,[Currency_Converter]
			   ,[Profit_Commission]
			   ,[Profit_Commission_Management_Expenses]
			   ,[Profit_Commission_Currency]
			   ,[Overrider]
			   ,[Average_QS_%]
			   ,[Number_of_QS_Policies]
			   ,[%_Ceded_to_QS]
			   ,[FK_Batch]
			   ,[AuditCreateDateTime]
			   ,[AuditUserCreate]
			   ,[AuditHost]
			   ,[AuditAction]
			   ,[RowHash]
			   ,[RowIsLatest] = 1
			   ,[RowVersionNumber]
			FROM   
				[Inbound].ReInsuranceTreatyContractAttributes p
				join @BatchID b ON b.PK_BatchID = p.FK_Batch

			RAISERROR('[Outbound].[ReInsuranceTreatyContractAttributes] insert: %i', 0, 0, @@rowcount) WITH NOWAIT;


			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, 'Inbound.usp_InboundOutboundWorkflow_ReInsurance...', 'Process Inbound to outbound for ReInsuranceTreatyContractAttributes';

			/*=============================================================================================
					Delete data from inbound where batchID Has been processed to outbound and Change S
			==============================================================================================*/

			DELETE I FROM [Inbound].ReInsuranceTreatyContractAttributes I JOIN @BatchID B ON B.PK_BatchID = I.[FK_Batch];

			UPDATE	bq
			SET		[Status] = 'Outbound'
			FROM	Inbound.BatchQueue	bq
			JOIN	@BatchID bi 
				ON  bq.Pk_Batch = bi.PK_BatchID
				

			RAISERROR('Completed ReInsuranceTreatyContractAttributes: %i', 0, 0, @@rowcount) WITH NOWAIT;

		END;

		-- LOGIN THE RESULT WITH SUCCESS
		INSERT @Logging(ActivityStatus, ActivityName) SELECT 2 , @p_ActivityName;

		--Generate logging for success
		EXEC log.usp_LogContract @Input = @Logging;

		IF @Trancount = 0 COMMIT;

	END TRY
	BEGIN CATCH

		IF @Trancount = 0 ROLLBACK;

		-----On error Change status to failed from running
		UPDATE		q
		SET			Status = 'OutBoundFailed'
		FROM		Inbound.BatchQueue	q
		INNER JOIN	@BatchID B ON q.Pk_Batch = B.PK_BatchID;


		-- LOG THE RESULT WITH ERROR
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 4, 'Inbound.usp_InboundOutboundWorkflow_ReInsurance...', ERROR_MESSAGE();

		EXEC log.usp_LogContract @Input = @Logging;

		THROW;

	END CATCH;
END
GO


