﻿CREATE PROC [Inbound].[usp_InboundOutboundWorkflow]
	
	@DoNonIFRS17_Tests bit = 1

AS
-- =======================================================================================================================================

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	2021-05-27
-- Changes:				Added the column FK_Allocation as it is used for the re-insurance allocations.

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	2021-08-31
-- Changes:				All entries in Outbound for IsToDate = 'N' entries are getting Delta Type 'New'. 
--						Now getting Adjustment when there are related entries.

-- Modified by:			mark.baekdal@beazley.com
-- Modification date:	2021-09-14
-- Changes:				Added the optional parameter @DoNonIFRS17_Tests so IFRS17 code doesn't have to run the tests that aren't applicable.

--Change Version	: 1.0 
--Sprint			: BR1 Q3 24 committed
--Author			: lakshman.akasapu@beazley.com
--Modify Date	    : 2024-08-05 
--Description		: https://beazley.atlassian.net/browse/I1B-5328
						--Removed the procedures that were not using anymore
						--[Test].[usp_LogBatchAggregate_ExpectedOutboundFDMCHE]
						--[Test].[usp_LogBatchAggregate_ActualOutboundFDMCHE]
						--[Test].[usp_LogBatchAggregate_ExpectedTechnicalHubUSSYND]
						--[Test].[usp_LogBatchAggregate_ExpectedOutBoundUSSYND]
-- =======================================================================================================================================	
BEGIN
	--SET NOCOUNT ON;

	DECLARE @Trancount	INT = @@Trancount;

	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;
	DECLARE @p_Account NVARCHAR(255) = NULL;
	DECLARE @p_SourceSystem NVARCHAR(255) = NULL;
	DECLARE @CurrentDate DATETIME2	= GETDATE();
	DECLARE @BatchID AS BatchID;

	INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
	SELECT 1, @p_ActivityName, 'Inbound OutBound Workflow  Started';

	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
		IF EXISTS (SELECT Pk_Batch FROM Inbound.BatchQueue WHERE Status='Inbound')
			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, '[Inbound].[usp_InboundOutboundWorkflow]', 'Pending  batches are being checked';
		BEGIN

			/*=============================================================================================
							Genrate Hashrow for inbound
		 ==============================================================================================*/

			--EXEC Inbound.usp_GenerateHashRow @p_SourceSystem, @p_Account;

			--INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			--SELECT 5, '[Inbound].[usp_InboundOutboundWorkflow]', 'Genrate Hashrow for inbound created';

			/*=============================================================================================
         					Select Pending BatchID 
			==============================================================================================*/

			
			INSERT @BatchID 
			SELECT	Pk_Batch, 
					[DataSet],
					AsAt
			FROM	Inbound.BatchQueue 
			WHERE	Status='Inbound'
				AND (RunDescription = 'Baseload' OR RunDescription IS NULL);


				
/*Adding #BatchID to remove dependency from table variable @BatchID*/
			DROP table if exists #BatchID;
			SELECT	Pk_Batch as PK_BatchID, 
					[DataSet],
					AsAt
			Into #BatchID
			FROM	Inbound.BatchQueue 
			WHERE	Status='Inbound'
				AND (RunDescription = 'Baseload' OR RunDescription IS NULL);

			
			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, '[Inbound].[usp_InboundOutboundWorkflow]', 'Select Pending BatchID ';
			
			---set batch status to running from Pending
			UPDATE		q
			SET			Status = 'Running'
			FROM		Inbound.BatchQueue	q
			INNER JOIN	#BatchID			B ON q.Pk_Batch = B.PK_BatchID;
			

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, '[Inbound].[usp_InboundOutboundWorkflow]', 'Batches are set to Running ';

			/*=============================================================================================
         					LogOutboundExpected Results
			==============================================================================================*/

			if @DoNonIFRS17_Tests = 1
			begin

				EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_ExpectedOutbound] @BatchID;
				--EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_ExpectedOutboundPFT] @BatchID; /*Commented it for I1B-1011*/
				EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_ExpectedOutboundFDM] @BatchID;

				EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_ExpectedOutBoundBICI] @BatchID;
				EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_ExpectedOutBoundBAIC] @BatchID;
				EXEC [FinanceDataContract].[Test].[usp_LogBatchAggregate_ExpectedOutboundBIDAC] @BatchID;


			
				INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
				SELECT 5, '[Inbound].[usp_InboundOutboundWorkflow]', 'LogOutboundExpected Results';

			end

			/*=============================================================================================
					Process Inbound to outbound
			==============================================================================================*/


			--DROP TABLE IF EXISTS #TEMP
			--SELECT	Pk_Batch AS PK_BatchID, 
			--		OriginalName,DataSet INTO #TEMP
			--FROM	Inbound.BatchQueue 
			--WHERE	Status = 'Running' 
			--	AND (RunDescription = 'Baseload' OR RunDescription IS NULL);


			INSERT Outbound.[Transaction] WITH(TABLOCK)(Scenario, Account, [Dataset], DateOfFact, BusinessKey, PolicyNumber, InceptionDate, ExpiryDate
															,BindDate, DueDate, [BoundDate], 
															TrifocusCode, Entity, StatsCode, YOA, TypeOfBusiness, SettlementCCY
															,OriginalCCY, IsToDate, [Value], RowHash, FK_Allocation, AuditSourceBatchID, AuditGenerateDateTime, AuditHost
															,DeltaType, [Basis], [Location], [ValueOrig], [BusinessProcessCode], [FK_Batch])
			-- OUTPUT inserted.*
			SELECT		ISNULL(Inbound.Scenario, Outbound.Scenario)
						,ISNULL(Inbound.Account, Outbound.Account)
						,ISNULL(Inbound.[Dataset], Outbound.[Dataset])
						,ISNULL(Inbound.DateOfFact, Outbound.DateOfFact)
						,ISNULL(Inbound.BusinessKey, Outbound.BusinessKey)
						,ISNULL(Inbound.PolicyNumber, Outbound.PolicyNumber)
						,ISNULL(Inbound.InceptionDate, Outbound.InceptionDate)
						,ISNULL(Inbound.ExpiryDate, Outbound.ExpiryDate)
						,ISNULL(Inbound.BindDate, Outbound.BindDate)
						,ISNULL(Inbound.DueDate, Outbound.DueDate)
						,ISNULL(Inbound.[BoundDate], Outbound.[BoundDate])
						,ISNULL(Inbound.TrifocusCode, Outbound.TrifocusCode)
						,ISNULL(Inbound.Entity, Outbound.Entity)
						,ISNULL(Inbound.StatsCode, Outbound.StatsCode)
						,ISNULL(Inbound.YOA, Outbound.YOA)
						,ISNULL(Inbound.TypeOfBusiness, Outbound.TypeOfBusiness)
						,ISNULL(Inbound.SettlementCCY, Outbound.SettlementCCY)
						,ISNULL(Inbound.OriginalCCY, Outbound.OriginalCCY)
						,ISNULL(Inbound.IsToDate, Outbound.IsToDate)
						,ISNULL(Inbound.SumofInbound, 0.0000) - ISNULL(Sumofoutbound, 0.0000)
						,ISNULL(Inbound.RowHash, Outbound.RowHash)
						,ISNULL(Inbound.FK_Allocation, Outbound.FK_Allocation)
						,ISNULL(Inbound.AuditSourceBatchID, Outbound.PK_Batch)
						,ISNULL(Inbound.AuditGenerateDateTime, @CurrentDate)
						,ISNULL(Inbound.AuditHost, @@SERVERNAME)
						,Deltatype	= CASE WHEN Inbound.Transactional IS NOT NULL THEN Inbound.Transactional
											WHEN Inbound.RowHash IS NULL THEN 'Reversal' -- Deleted/ Missing 
											WHEN Outbound.RowHash IS NULL THEN 'New' -- New 
											ELSE 'Adjustment' -- Matched
										END
						,ISNULL(Inbound.[Basis], Outbound.[Basis])
						,ISNULL(Inbound.[Location], Outbound.[Location])
						,ISNULL(Inbound.OrigSumofInbound, 0.0000) - ISNULL(OrigSumofOutbound, 0.0000)
						,ISNULL(Inbound.[BusinessProcessCode], Outbound.[BusinessProcessCode])
						,ISNULL(Inbound.[FK_Batch], Outbound.[FK_Batch])

			FROM		(
							SELECT			SumofInbound				= SUM([Value])
											,I.Scenario
											,I.Account
											,I.[Dataset]
											,I.DateOfFact
											,I.BusinessKey
											,I.PolicyNumber
											,I.InceptionDate
											,I.ExpiryDate
											,I.BindDate
											,I.DueDate
											,I.[BoundDate]
											,I.TrifocusCode
											,I.Entity
											,I.StatsCode
											,I.YOA
											,I.TypeOfBusiness
											,I.SettlementCCY
											,I.OriginalCCY
											,I.IsToDate
											,I.RowHash
											,I.FK_Allocation
											,AuditSourceBatchID		= ISNULL(I.AuditSourceBatchID, B.PK_BatchID)
											,AuditGenerateDateTime	= MAX(I.AuditGenerateDateTime)
											,I.AuditHost
											,Transactional			= CASE 
																		WHEN I.DeltaType IS NOT NULL THEN I.DeltaType
																		WHEN d.RowHash IS NULL AND I.IsToDate = 'N' THEN 'New' 
																		WHEN d.RowHash IS NOT NULL AND I.IsToDate = 'N' THEN 'Adjustment' 
																		END
											,I.[Basis]
											,I.[Location]
											,OrigSumofInbound		= SUM(I.[ValueOrig])
											,BusinessProcessCode	= MAX(I.[BusinessProcessCode])
											,FK_Batch				= MAX(I.[FK_Batch])
							FROM			Inbound.[Transaction]														AS I
							LEFT JOIN		(SELECT DISTINCT RowHash FROM Outbound.[Transaction] WHERE IsToDate = 'N')	AS d ON I.RowHash = d.RowHash
							INNER JOIN		#BatchID																	AS B ON I.AuditSourceBatchID = B.PK_BatchID
																															AND I.[Dataset] = B.DataSet
							GROUP BY Scenario
									,Account
									,I.[Dataset]
									,DateOfFact
									,BusinessKey
									,PolicyNumber
									,InceptionDate
									,ExpiryDate
									,BindDate
									,DueDate
									,I.[BoundDate]
									,TrifocusCode
									,Entity
									,StatsCode
									,YOA
									,TypeOfBusiness
									,SettlementCCY
									,OriginalCCY
									,IsToDate
									,I.RowHash
									,AuditSourceBatchID
									,AuditHost
									,B.PK_BatchID
									,d.RowHash
									,I.FK_Allocation
									,I.[Basis]
									,I.[Location]
									,I.DeltaType
						)	Inbound
			FULL JOIN	(
							SELECT			Sumofoutbound		= SUM([Value])
											,Scenario
											,Account
											,o.[Dataset]
											,DateOfFact		= MAX(DateOfFact)
											,BusinessKey
											,PolicyNumber
											,InceptionDate
											,ExpiryDate
											,BindDate
											,DueDate
											,o.[BoundDate]
											,TrifocusCode
											,Entity
											,StatsCode
											,YOA
											,TypeOfBusiness
											,SettlementCCY
											,OriginalCCY
											,IsToDate
											,RowHash
											,o.FK_Allocation
											,ds.PK_BatchID as PK_Batch
											,o.[Basis]
											,o.[Location]
											,OrigSumofOutbound		= SUM(o.[ValueOrig])
											,BusinessProcessCode	= MAX(o.[BusinessProcessCode])
											,FK_Batch				= MAX(o.[FK_Batch])
							FROM			
								Outbound.[Transaction]	o

								JOIN Inbound.BatchQueue BQ 
									ON  BQ.Pk_Batch = o.AuditSourceBatchID 
									AND BQ.DataSet = o.Dataset 
								
								JOIN #BatchID ds
								    ON  BQ.DataSet=ds.Dataset and o.Dataset=ds.DataSet
								--JOIN #TEMP AS B 
								--	ON 
								--	(
								--		CASE WHEN BQ.[OriginalName] = 'Adjustments' THEN o.Dataset + BQ.OriginalName ELSE o.Dataset END
								--	)
								--	= 
								--	(
								--		CASE WHEN B.OriginalName = 'Adjustments' THEN B.Dataset + B.OriginalName ELSE B.Dataset END 
								--	)
							WHERE			
								IsToDate = 'Y'
							GROUP BY Scenario
									,Account
									,o.[Dataset]
									,BusinessKey
									,PolicyNumber
									,InceptionDate
									,ExpiryDate
									,BindDate
									,DueDate
									,o.[BoundDate]
									,TrifocusCode
									,Entity
									,StatsCode
									,YOA
									,TypeOfBusiness
									,SettlementCCY
									,OriginalCCY
									,IsToDate
									,RowHash
									,o.FK_Allocation
									,ds.PK_BatchID
									,o.[Basis]
									,o.[Location]
							HAVING			
								SUM([Value]) <> 0 ---Don't process Hashrows that already been processed as deleted or missing 
						)	
							AS Outbound 
								ON  Inbound.RowHash = Outbound.RowHash
								AND Inbound.AuditSourceBatchID = Outbound.PK_Batch
			WHERE		
				ISNULL(Inbound.SumofInbound, 0.0000) - ISNULL(Sumofoutbound, 0.0000) <> 0
				OPTION (RECOMPILE,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, '[Inbound].[usp_InboundOutboundWorkflow]', 'Process Inbound to outbound';

			/*=============================================================================================
					Delete data from inbound where batchID Has been processed to outbound and Change S
			==============================================================================================*/

			DELETE I FROM Inbound.[Transaction] I INNER JOIN #BatchID B ON B.PK_BatchID = I.AuditSourceBatchID;

			---Change status to Complete from running
			UPDATE		q
			SET			Status = 'OutBound'
			FROM		Inbound.BatchQueue	q
			INNER JOIN	#BatchID			B ON q.Pk_Batch = B.PK_BatchID;

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT	5
					,	'[Inbound].[usp_InboundOutboundWorkflow]'
					,'Delete data from inbound where batchID Has been processed to outbound and Change S';

			/*
			=============================================================================================
				LogOutbound Aggregate Actual Value
			==============================================================================================
			*/

			if @DoNonIFRS17_Tests = 1
			begin

				EXEC [Test].[usp_LogBatchAggregate_ActualOutbound] @BatchID;

				--EXEC [Test].[usp_LogBatchAggregate_ActualOutboundPFT] @BatchID; /*Commented it for I1B-1011*/

				EXEC [Test].[usp_LogBatchAggregate_ActualOutboundFDM] @BatchID;

				 
				EXEC [Test].[usp_LogBatchAggregate_ActualOutBoundBICI]  @BatchID;
				EXEC [Test].[usp_LogBatchAggregate_ActualOutBoundBAIC]   @BatchID;
				EXEC [Test].[usp_LogBatchAggregate_ActualOutBoundUSSYND] @BatchID;
				EXEC [Test].[usp_LogBatchAggregate_ActualOutboundBIDAC]  @BatchID;

				INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
				SELECT 5, '[Inbound].[usp_InboundOutboundWorkflow]', 'LogOutbound Aggregate Actual Value';
				/*
				=============================================================================================
					Log Aggregate expected Value in technicalHubdb.fact.technicalresult
				==============================================================================================
				*/

				EXEC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHub] @BatchID;

				EXEC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHubPFT] @BatchID;

				EXEC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHubFDM] @BatchID;

				EXEC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHubFDMCHE] @BatchID;

				EXEC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHubUSBAIC] @BatchID;

				EXEC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHubBIDAC] @BatchID;

				EXEC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHubBICI] @BatchID;



				INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
				SELECT	5
						,	'[Inbound].[usp_InboundOutboundWorkflow]'
						,'Log Aggregate expected Value in technicalHubdb.fact.technicalresult';

			end --if @DoNonIFRS17_Tests = 1

		END;
		IF @Trancount = 0 
			BEGIN
				RAISERROR('committing', 0, 0) WITH NOWAIT;
				COMMIT;
			END;
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, '[Inbound].[usp_InboundOutboundWorkflow]', 'usp_InboundOutboundWorkflow Succeeded';

		--Generate logging for success
		EXEC log.usp_LogContract @Input = @Logging;

	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK
		-----On error Change status to failed from running
		UPDATE		q
		SET			Status = 'OutBoundFailed'
		FROM		Inbound.BatchQueue	q
		INNER JOIN	#BatchID			B ON q.Pk_Batch = B.PK_BatchID;

		--Generate logging for error (outside tran)
		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)

		SELECT 4, '[Inbound].[usp_InboundOutboundWorkflow]', ERROR_MESSAGE();
		EXEC log.usp_LogContract @Input = @Logging;

		THROW;
	END CATCH;
END;
GO