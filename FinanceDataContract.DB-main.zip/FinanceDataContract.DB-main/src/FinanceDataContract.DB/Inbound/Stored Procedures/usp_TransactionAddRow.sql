﻿
CREATE PROCEDURE Inbound.usp_TransactionAddRow 
	 @p_Scenario              NVARCHAR (2)     
    ,@p_Account               NVARCHAR (10)    
    ,@p_SourceSystem          NVARCHAR (255)   
    ,@p_DateOfFact            DATETIME2 (7)    
    ,@p_BusinessKey           NVARCHAR (255)   
    ,@p_PolicyNumber          NVARCHAR (255)   
    ,@p_InceptionDate         DATETIME2 (7)     
    ,@p_ExpiryDate            DATETIME2 (7)     
    ,@p_BindDate              DATETIME2 (7)    
    ,@p_DueDate               DATETIME2 (7)     
    ,@p_TrifocusCode          NVARCHAR (25)    
    ,@p_Entity                NVARCHAR (10)    
    ,@p_YOA                   NVARCHAR (5)     
    ,@p_TypeOfBusiness        NVARCHAR (1)      
    ,@p_SettlementCCY         NVARCHAR (3)     
    ,@p_OriginalCCY           NVARCHAR (3)     
    ,@p_IsToDate              NVARCHAR (1)     
    ,@p_Value                 NUMERIC (19,4)   
    ,@p_RowHash               VARBINARY (1)    
    ,@p_AuditSourceBatchID    NVARCHAR (255)   
    ,@p_AuditGenerateDateTime DATETIME2 (7)    
    ,@p_AuditHost             NVARCHAR (255)
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @v_ErrorMessage NVARCHAR(4000)	

	BEGIN TRY

		INSERT INTO Inbound.[Transaction]
			(Scenario
			,Account
			,[DataSet]
			,DateOfFact
			,BusinessKey
			,PolicyNumber
			,InceptionDate
			,ExpiryDate
			,BindDate
			,DueDate
			,TrifocusCode
			,Entity
			,YOA
			,TypeOfBusiness
			,SettlementCCY
			,OriginalCCY
			,IsToDate
			,Value
			,RowHash
			,AuditSourceBatchID
			,AuditGenerateDateTime
			,AuditHost)

		SELECT
			 @p_Scenario
			,@p_Account
			,@p_SourceSystem
			,@p_DateOfFact
			,@p_BusinessKey
			,@p_PolicyNumber
			,@p_InceptionDate
			,@p_ExpiryDate
			,@p_BindDate
			,@p_DueDate
			,@p_TrifocusCode
			,@p_Entity
			,@p_YOA
			,@p_TypeOfBusiness
			,@p_SettlementCCY
			,@p_OriginalCCY
			,@p_IsToDate
			,@p_Value
			,@p_RowHash
			,@p_AuditSourceBatchID
			,@p_AuditGenerateDateTime
			,@p_AuditHost

		RETURN 0

	END TRY

	BEGIN CATCH
		
		-- LOG ERROR
		SELECT    @v_ErrorMessage = 'API error detected at line insert in Inbound.[Transaction]: ' + ERROR_MESSAGE()
		RAISERROR(@v_ErrorMessage, 16, 1)
	
	END CATCH
	
END
GO
EXECUTE sp_addextendedproperty @name = N'Stored Procedure Parameters', @value = N'Input:

					A parameter for each of the columns without a default or constraint in the table definition of DataContract.InwardContract', @level0type = N'SCHEMA', @level0name = N'Inbound', @level1type = N'PROCEDURE', @level1name = N'usp_TransactionAddRow';


GO
EXECUTE sp_addextendedproperty @name = N'Stored Procedure Definition', @value = N'An API stored procedure to add individual rows to the DataContract.InwardContract table. Useful for Bus / BPA type architectures.', @level0type = N'SCHEMA', @level0name = N'Inbound', @level1type = N'PROCEDURE', @level1name = N'usp_TransactionAddRow';


GO
EXECUTE sp_addextendedproperty @name = N'Stored Procedure Call', @value = N'The procedure can be called from the external applications which will pass all the
					required parameters (details in the next column) to insert just one record per call in the contract table
					DataContract.InwardContract
					To insert the data each column in the DataContract.InwardContract table has a linked input parameter (see
					list of input parameters).
					Remarks:
					1. TRY/CATCH BLOCKS are required to handle errors in the stored procedure. Raise errors where insert fails.
					2. The insert operation will require all the `NOT NULL-able` columns in the InwardContract table to be
					populated. This should be controlled via the stored procedure SQL input parameters natively by SQL Server.
					3. SQL Transactions (BEGIN TRAN/COMMIT) are NOT allowed in this stored procedure.', @level0type = N'SCHEMA', @level0name = N'Inbound', @level1type = N'PROCEDURE', @level1name = N'usp_TransactionAddRow';

