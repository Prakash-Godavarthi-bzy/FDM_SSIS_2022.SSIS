﻿CREATE TABLE [Inbound].[Premium_Extensions](
	[RowHash_Transaction_Premium_Extensions] [varbinary](255) NOT NULL,
	[PolicyClaimBasis] [varchar](10) NULL,
	[PolicyMOPCode] [varchar](10) NULL,
	[PolicyCobCode] [varchar](10) NULL,
	[PolicyNumber] [varchar](255) NOT NULL,
	[FK_Batch] [int] NOT NULL,
	[ContractType] [char](3) NOT NULL
) ON [PRIMARY]

GO

ALTER TABLE Inbound.Premium_Extensions ADD CONSTRAINT
	CK_Premium_Extensions CHECK (ContractType in ('EUR','BID'))

GO