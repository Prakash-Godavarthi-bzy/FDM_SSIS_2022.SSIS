﻿CREATE TABLE [Inbound].[LossRatio] (
    [PK_LossRatio]             INT             IDENTITY (1, 1) NOT NULL,
    [DataSet]                  VARCHAR (50)    NOT NULL,
    [LossRatioPeriod]          VARCHAR (10)    NOT NULL,
    [LossRatioAccount]         VARCHAR (50)    NOT NULL,
    [TrifocusCode]             VARCHAR (10)    NOT NULL,
    [TrifocusName]             VARCHAR (255)   NOT NULL,
    [YOA]                      VARCHAR (5)     NOT NULL,
    [LossRatioPercentage]      NUMERIC (19, 6) NOT NULL,
    [AuditSourceBatchID]       VARCHAR (255)   NOT NULL,
    [AuditCreateDateTime]      DATETIME        CONSTRAINT [DF_LossRatio_AuditCreateDateTime] DEFAULT (getutcdate()) NOT NULL,
    [AuditGenerateDateTime]    DATETIME        NOT NULL,
    [AuditUserCreate]          VARCHAR (255)   CONSTRAINT [DF_LossRatio_AuditUserCreate] DEFAULT (suser_sname()) NOT NULL,
    [AuditHost]                VARCHAR (255)   CONSTRAINT [DF_LossRatio_AuditUserHost] DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))) NOT NULL,
    CONSTRAINT [PK_INBD_LossRatio] PRIMARY KEY CLUSTERED ([PK_LossRatio] ASC) WITH (FILLFACTOR = 90)
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'The server name of the system generating the batch (without instance)', @level0type = N'SCHEMA', @level0name = N'Inbound', @level1type = N'TABLE', @level1name = N'LossRatio', @level2type = N'COLUMN', @level2name = N'AuditHost';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'A user name to attribute the load to. Could be person or system account', @level0type = N'SCHEMA', @level0name = N'Inbound', @level1type = N'TABLE', @level1name = N'LossRatio', @level2type = N'COLUMN', @level2name = N'AuditUserCreate';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Datetime when data EXTRACTED from source system', @level0type = N'SCHEMA', @level0name = N'Inbound', @level1type = N'TABLE', @level1name = N'LossRatio', @level2type = N'COLUMN', @level2name = N'AuditGenerateDateTime';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FTH generated - schema default current datetime - users do not populate', @level0type = N'SCHEMA', @level0name = N'Inbound', @level1type = N'TABLE', @level1name = N'LossRatio', @level2type = N'COLUMN', @level2name = N'AuditCreateDateTime';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'The source system batch id for the provided data', @level0type = N'SCHEMA', @level0name = N'Inbound', @level1type = N'TABLE', @level1name = N'LossRatio', @level2type = N'COLUMN', @level2name = N'AuditSourceBatchID';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'The value of the discountrate(percentage)', @level0type = N'SCHEMA', @level0name = N'Inbound', @level1type = N'TABLE', @level1name = N'LossRatio', @level2type = N'COLUMN', @level2name = N'LossRatioPercentage';



GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Name of the Trifocus', @level0type = N'SCHEMA', @level0name = N'Inbound', @level1type = N'TABLE', @level1name = N'LossRatio', @level2type = N'COLUMN', @level2name = N'TrifocusName';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Beazley internal cost -profit centre', @level0type = N'SCHEMA', @level0name = N'Inbound', @level1type = N'TABLE', @level1name = N'LossRatio', @level2type = N'COLUMN', @level2name = N'TrifocusCode';




GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'The appropriate FTH account', @level0type = N'SCHEMA', @level0name = N'Inbound', @level1type = N'TABLE', @level1name = N'LossRatio', @level2type = N'COLUMN', @level2name = N'LossRatioAccount';




GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Indicates reporting period for the Loss Ratio', @level0type = N'SCHEMA', @level0name = N'Inbound', @level1type = N'TABLE', @level1name = N'LossRatio', @level2type = N'COLUMN', @level2name = 'LossRatioPeriod';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Plain text name of source system', @level0type = N'SCHEMA', @level0name = N'Inbound', @level1type = N'TABLE', @level1name = N'LossRatio', @level2type = N'COLUMN', @level2name = N'DataSet';


GO
EXECUTE sp_addextendedproperty @name = N'Table usage', @value = N'Table used to store the Loss Ratio into the Finance Data Hub (Current)', @level0type = N'SCHEMA', @level0name = N'Inbound', @level1type = N'TABLE', @level1name = N'LossRatio';

