﻿
CREATE TABLE [Inbound].[ReInsuranceQuotaSharePercentage](
	[BusinessKey] [nvarchar](800) NOT NULL,
	[AccountingPeriod] [int] NOT NULL,
	[TrifocusCode] [nvarchar](255) NULL,
	[TrifocusName] [nvarchar](255) NULL,
	[Entity] [nvarchar](255) NULL,
	[YOA] [int] NOT NULL,
	[SettlementCCY] [nvarchar](25) NULL,
	[QS_Premium] [decimal](38, 4) NULL,
	[GrossUltimates] [decimal](38, 4) NULL,
	[QS%] [decimal](38, 6) NULL,
	[FK_Batch] int not null,
	[AuditDateTime] datetime not null,
	[AuditUser] nvarchar(255) not null,
	[AuditHost] nvarchar(255) not null,
)
GO

ALTER TABLE [Inbound].[ReInsuranceQuotaSharePercentage] ADD  CONSTRAINT [DF_ReInsuranceQuotaSharePercentage_AuditDateTime]  DEFAULT (getutcdate()) FOR [AuditDateTime]
GO

ALTER TABLE [Inbound].[ReInsuranceQuotaSharePercentage] ADD  CONSTRAINT [DF_ReInsuranceQuotaSharePercentage_AuditHost]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO

ALTER TABLE [Inbound].[ReInsuranceQuotaSharePercentage] ADD  CONSTRAINT [DF_ReInsuranceQuotaSharePercentage_AuditUser]  DEFAULT (suser_sname()) FOR [AuditUser]
GO


