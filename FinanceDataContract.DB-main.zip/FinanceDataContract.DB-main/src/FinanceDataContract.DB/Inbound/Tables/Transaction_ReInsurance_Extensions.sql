
CREATE TABLE [Inbound].[Transaction_ReInsurance_Extensions](
	[RowHash_Transaction_ReInsurance_Extensions] [varbinary](255) NOT NULL,
	[RIPolicyType] [varchar](50) NULL,
	[ProgrammeCode] [varchar](100) NULL,
	ContractType char(3) not null,
	BeazleyCatCode [varchar](12) NULL,
	TransactionDate date null,
	[IsLargeLoss] bit null,
	[FK_Batch] [int] NOT NULL
) 
GO

ALTER TABLE Inbound.Transaction_ReInsurance_Extensions ADD CONSTRAINT
	CK_Transaction_ReInsurance_Extensions CHECK (ContractType in ('TTY','FAC','PC','CCY','RRU','CCI','CRO','OBP','RIP','SAP','SPA','RRP','UPC','ROC','BRI','BUP','BPI','BEA','BRP','BUC','SUP','ADM','QQS','RAC','AEA','OPU','RDP','EPI','BOT','SOT')) 
GO