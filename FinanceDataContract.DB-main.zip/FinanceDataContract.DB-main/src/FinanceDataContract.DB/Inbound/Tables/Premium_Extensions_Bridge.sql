﻿
CREATE TABLE [Inbound].[Premium_Extensions_Bridge](
	[RowHash_Transaction] [varbinary](255) NOT NULL,
	[RowHash_Transaction_Premium_Extensions] [varbinary](255) NOT NULL,
	[FK_Batch] [int] NOT NULL,
	[ContractType] [char](3) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE Inbound.[Premium_Extensions_Bridge] ADD CONSTRAINT
	CK_Premium_Extensions_Bridge CHECK (ContractType in ('EUR','BID'))
GO
