﻿CREATE TABLE [Inbound].[RIPercentage](
	[AccountingPeriod] [varchar](25) NULL,
	[TrifocusCode] [nvarchar](50) NULL,
	[TrifocusName] [nvarchar](255) NULL,
	[Entity] [varchar](50) NULL,
	[YOA] [int] NULL,
	[YOI] [int] NULL,
	[RIProgramme] [varchar](255) NULL,
	[RIType] [varchar](50) NULL,
	[SettlementCCY] [varchar](25) NULL,
	[RIPolicyNumber] [varchar](255) NULL,
	[InceptionDate] [datetime] NULL,
	[ExpiryDate] [datetime] NULL,
	[ClaimsBasis] [varchar](10) NULL,
	[RIPremium] [numeric](19, 6) NULL,
	[GrossNetUltimates] [numeric](19, 6) NULL,
	[RI%] [numeric](19, 6) NULL,
	[Businesskey] [varchar](500) NOT NULL,
	[FK_Batch] [int] NOT NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL,
	[AuditHost] [nvarchar](255) NOT NULL,
	[AuditAction] [char](1) NOT NULL,
	[RowHash] [varbinary](255) NOT NULL,
	[RowVersionNumber] [int] NOT NULL,
 CONSTRAINT [PK_RIPercentage] PRIMARY KEY CLUSTERED 
(
	[Businesskey] ASC
)
) ON [PRIMARY]
GO

ALTER TABLE [Inbound].[RIPercentage] ADD  CONSTRAINT [DF_RIPercentage_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [Inbound].[RIPercentage] ADD  CONSTRAINT [DF_RIPercentage_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [Inbound].[RIPercentage] ADD  CONSTRAINT [DF_RIPercentage_AuditHost]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO

