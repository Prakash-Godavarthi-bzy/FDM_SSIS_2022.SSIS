﻿
CREATE TABLE [Inbound].[PolicySectionReference](
	[PolicyReference] [varchar](255) NOT NULL,
	[SectionReference] [varchar](255) NOT NULL,
	[FK_Batch] [int] NOT NULL
) 
GO

EXEC sys.sp_addextendedproperty 
@name=N'description', 
@value=N'Used to hold a snapshot of all the section references and policy references sourced from BI. 
Data fed by [FinanceLanding].[Claims_BI_ODS].[usp_LandingToInbound_PolicySectionReference] ready to go to the outbound table. 
See the outbound table to see how that is loaded.' , 
@level0type=N'SCHEMA',@level0name=N'Inbound', @level1type=N'TABLE',@level1name=N'PolicySectionReference'
GO
