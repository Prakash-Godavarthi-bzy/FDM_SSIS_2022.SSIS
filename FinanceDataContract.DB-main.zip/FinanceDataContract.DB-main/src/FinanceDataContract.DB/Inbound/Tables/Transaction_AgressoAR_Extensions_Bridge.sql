﻿CREATE TABLE [Inbound].[Transaction_AgressoAR_Extensions_Bridge](
	[RowHash_Transaction] [varbinary](255) NOT NULL,
	[RowHash_Transaction_AgressoAR_Extensions] [varbinary](255) NOT NULL,
	[ContractType] [char](3) NOT NULL,
	[FK_Batch] [int] NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [Inbound].[Transaction_AgressoAR_Extensions_Bridge]  WITH CHECK ADD  CONSTRAINT [CK_Transaction_AgressoAR_Extensions_Bridge] CHECK  (([ContractType]='OBP' OR [ContractType]='CRO' OR [ContractType]='CCI' OR [ContractType]='RRU' OR [ContractType]='CCY' OR [ContractType]='PC' OR [ContractType]='FAC' OR [ContractType]='TTY' OR [ContractType]='RIP' OR [ContractType]='SPA' OR [ContractType]='RRP' OR [ContractType]='ARU' OR [ContractType]='ARB'))
GO

ALTER TABLE [Inbound].[Transaction_AgressoAR_Extensions_Bridge] CHECK CONSTRAINT [CK_Transaction_AgressoAR_Extensions_Bridge]
GO
