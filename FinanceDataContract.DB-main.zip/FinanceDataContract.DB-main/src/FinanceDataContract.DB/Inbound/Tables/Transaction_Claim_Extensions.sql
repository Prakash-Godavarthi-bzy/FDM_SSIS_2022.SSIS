﻿
CREATE TABLE [Inbound].[Transaction_Claim_Extensions](
	[RowHash_Transaction_Claim_Extensions] [varbinary](255) NOT NULL,
	[DateOfLoss] [date] NULL,
	[SourceSystem] [varchar](100) NULL,
	[PolicySourceSystem] [varchar](255) NOT NULL,
	[UnderwritingPlatformCode] [varchar](255) NOT NULL,
	[UnderwritingPlatformName] [varchar](255) NOT NULL,
	[UWOfficeLocation] [varchar](255) NULL,
	[MovementType] [varchar](255) NOT NULL,
	[TransactionTrackingStatus] [varchar](255) NULL,
	[InsuredState] [varchar](255) NULL,
	[InsuredCountry] [varchar](255) NULL,
	[BeazleyCatCode] [varchar](255) NULL,
	[IsLargeLossClaim] [bit] NULL,
	[FK_Batch] [int] NOT NULL,
	[MovementDate] date not null,
	[ExposureReference] [varchar](255) not NULL,
	[SCMReference] [varchar](255) NULL,
	[ClaimReference] [varchar](255) not NULL,
) ON [PRIMARY]
GO


CREATE UNIQUE NONCLUSTERED INDEX [idx_RowHash_Transaction_Claim_Extensions] ON [Inbound].[Transaction_Claim_Extensions]
(
	[RowHash_Transaction_Claim_Extensions] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO

