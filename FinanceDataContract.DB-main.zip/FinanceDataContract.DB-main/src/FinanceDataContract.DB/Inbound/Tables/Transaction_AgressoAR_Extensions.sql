﻿CREATE TABLE [Inbound].[Transaction_AgressoAR_Extensions](
	[RowHash_Transaction_AgressoAR_Extensions] [varbinary](255) NOT NULL,
	[GLBusinessKey] [varchar](255) NULL,
	[GLPolicyNumber] [varchar](255) NULL,
	[GLTransactionType] [varchar](5) NULL,
	[GLSupplierCust] [varchar](25) NULL,
	[SyndicateSplitPercentage] [numeric](3, 2) NULL,
	[ContractType] [char](3) NOT NULL,
	[FK_Batch] [int] NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [Inbound].[Transaction_AgressoAR_Extensions]  WITH CHECK ADD  CONSTRAINT [CK_Transaction_AgressoAR_Extensions] CHECK  (([ContractType]='FAC' OR [ContractType]='TTY' OR [ContractType]='PC' OR [ContractType]='CCY' OR [ContractType]='RRU' OR [ContractType]='CCI' OR [ContractType]='CRO' OR [ContractType]='OBP' OR [ContractType]='RIP' OR [ContractType]='SPA' OR [ContractType]='RRP' OR [ContractType]='ARU' OR [ContractType]='ARB'))
GO

ALTER TABLE [Inbound].[Transaction_AgressoAR_Extensions] CHECK CONSTRAINT [CK_Transaction_AgressoAR_Extensions]
GO
