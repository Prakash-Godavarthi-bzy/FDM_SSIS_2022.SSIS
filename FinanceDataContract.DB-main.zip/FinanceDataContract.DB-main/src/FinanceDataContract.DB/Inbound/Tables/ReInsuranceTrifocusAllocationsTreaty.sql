﻿-- drop  TABLE Inbound.[ReInsuranceTrifocusAllocationsTreaty]
CREATE TABLE Inbound.[ReInsuranceTrifocusAllocationsTreaty](
	[EntityCode] [nvarchar](255) NULL,
	[EntityName] [nvarchar](255) NULL,
	[AccountCode] [nvarchar](255) NULL,
	[AccountingPeriod] [int] NOT NULL,
	[RIPolicyNumber] [nvarchar](255) NULL,
	[YOA] [int] NOT NULL,
	[RIType] [nvarchar](50) NULL,
	[RIProgramme] [nvarchar](255) NULL,
	[TrifocusCode] [nvarchar](255) NULL,
	[TrifocusName] [nvarchar](255) NULL,
	[SettlementCurrency] [nvarchar](25) NULL,
	[Amount] [decimal](38, 3) NULL,
	[TotalAmount] [decimal](38, 3) NULL,
	[Allocation] [decimal](38, 6) NULL,
	[FK_Batch] [int] NOT NULL,
	[AuditDateTime] [datetime] NOT NULL,
	[AuditUser] [varchar](255) NOT NULL,
	[AuditHost] [varchar](255) NOT NULL,
	[DataSet] [varchar](50) NOT NULL,
	[BusinessKey] as
				 concat(
					ISNULL(ltrim(rtrim( [EntityCode])), '<isnull>') , '|' ,
					ISNULL(ltrim(rtrim([EntityName])), '<isnull>')  , '|' ,
					ISNULL(ltrim(rtrim([AccountCode])), '<isnull>') , '|' ,
					ISNULL(convert(varchar(30), [AccountingPeriod]), '<isnull>')  , '|' ,
					ISNULL(ltrim(rtrim([RIPolicyNumber])), '<isnull>') , '|' ,
					ISNULL(convert(varchar(30), [YOA]), '<isnull>')  , '|' ,
					ISNULL(ltrim(rtrim([RIType])), '<isnull>') , '|' ,
					ISNULL(ltrim(rtrim([RIProgramme])), '<isnull>') , '|' ,
					ISNULL(ltrim(rtrim([TrifocusCode])), '<isnull>') , '|' ,
					ISNULL(ltrim(rtrim([TrifocusName])), '<isnull>') , '|' ,
					ISNULL(ltrim(rtrim([SettlementCurrency])), '<isnull>') 
					)  ,

)
GO


ALTER TABLE [Inbound].[ReInsuranceTrifocusAllocationsTreaty] ADD  CONSTRAINT [DF_ReInsuranceTrifocusAllocationsTreaty_AuditDateTime]  DEFAULT (getutcdate()) FOR [AuditDateTime]
GO

ALTER TABLE [Inbound].[ReInsuranceTrifocusAllocationsTreaty] ADD  CONSTRAINT [DF_ReInsuranceTrifocusAllocationsTreaty_AuditUser]  DEFAULT (suser_sname()) FOR [AuditUser]
GO

ALTER TABLE [Inbound].[ReInsuranceTrifocusAllocationsTreaty] ADD  CONSTRAINT [DF_ReInsuranceTrifocusAllocationsTreaty_AuditHost]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO


