﻿CREATE TABLE [Inbound].[BatchQueue] (
    [Pk_Batch]              INT            NOT NULL,
    [Status]                VARCHAR (50)   CONSTRAINT [DF_Status_Batch] DEFAULT ('Pending') NOT NULL,
    [RunDescription]        VARCHAR (2000) NULL,
    [DataSet]               VARCHAR (50)   NULL,
    [OriginalName]          VARCHAR (50)   NULL,
    [AuditSourceBatchID]    VARCHAR (255)  NULL,
    [AuditCreateDateTime]   DATETIME       CONSTRAINT [DF_BatchQueue_AuditCreateDateTime] DEFAULT (getutcdate()) NOT NULL,
    [AuditGenerateDateTime] DATETIME       NULL,
    [AuditUserCreate]       VARCHAR (255)  CONSTRAINT [DF_BatchQueue_AuditUserCreate] DEFAULT (suser_sname()) NOT NULL,
    [AuditHost]             VARCHAR (255)  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) NOT NULL,
	AsAt Varchar(6) NULL,
    CONSTRAINT [PK_BatchQueue] PRIMARY KEY CLUSTERED ([Pk_Batch] ASC, [Status] ASC)
);


GO

EXECUTE sp_addextendedproperty 
		 @name		 = N'Table usage'
		,@value		 = N'Table used to generate surrogate batches for data load'
		,@level0type = N'SCHEMA'
		,@level0name = N'Inbound'
		,@level1type = N'TABLE'
		,@level1name = N'BatchQueue'
GO

EXECUTE sp_addextendedproperty 
		 @name       = N'MS_Description'
		,@value      = N'Status of the current batch. Default is Pending and is changed to reflect the current processing stage of the loaded data'
		,@level0type = N'SCHEMA'
		,@level0name = N'Inbound'
		,@level1type = N'TABLE'
		,@level1name = N'BatchQueue'
		,@level2type = N'COLUMN'
		,@level2name = N'Status'
GO

EXECUTE sp_addextendedproperty 
		 @name       = N'MS_Description'
		,@value      = N'Is a description of the batch, to help identify the content of it'
		,@level0type = N'SCHEMA'
		,@level0name = N'Inbound'
		,@level1type = N'TABLE'
		,@level1name = N'BatchQueue'
		,@level2type = N'COLUMN'
		,@level2name = N'RunDescription'
GO

EXECUTE sp_addextendedproperty 
		 @name       = N'MS_Description'
		,@value      = N'Is the source system from which data are loaded'
		,@level0type = N'SCHEMA'
		,@level0name = N'Inbound'
		,@level1type = N'TABLE'
		,@level1name = N'BatchQueue'
		,@level2type = N'COLUMN'
		,@level2name = N'DataSet'
GO

--EXECUTE sp_addextendedproperty 
--		 @name       = N'MS_Description'
--		,@value      = N'The server identifier from the source system. Could be a description, an ID etc.'
--		,@level0type = N'SCHEMA'
--		,@level0name = N'Inbound'
--		,@level1type = N'TABLE'
--		,@level1name = N'BatchQueue'
--		,@level2type = N'COLUMN'
--		,@level2name = N'OriginalName'
--GO

--EXECUTE sp_addextendedproperty 
--		 @name       = N'MS_Description'
--		,@value      = N'FTH generated - schema default current datetime - users do not populate'
--		,@level0type = N'SCHEMA'
--		,@level0name = N'Inbound'
--		,@level1type = N'TABLE'
--		,@level1name = N'BatchQueue'
--		,@level2type = N'COLUMN'
--		,@level2name = N'AuditCreateDateTime'
--GO

--EXECUTE sp_addextendedproperty 
--		 @name       = N'MS_Description'
--		,@value      = N'Datetime when data EXTRACTED from source system'
--		,@level0type = N'SCHEMA'
--		,@level0name = N'Inbound'
--		,@level1type = N'TABLE'
--		,@level1name = N'BatchQueue'
--		,@level2type = N'COLUMN'
--		,@level2name = N'AuditGenerateDateTime'
--GO

--EXECUTE sp_addextendedproperty 
--		 @name       = N'MS_Description'
--		,@value      = N'A user name to attribute the load to. Could be person or system account'
--		,@level0type = N'SCHEMA'
--		,@level0name = N'Inbound'
--		,@level1type = N'TABLE'
--		,@level1name = N'BatchQueue'
--		,@level2type = N'COLUMN'
--		,@level2name = N'AuditUserCreate'
--GO

--EXECUTE sp_addextendedproperty 
--		 @name       = N'MS_Description'
--		,@value      = N'The server name of the system generating the batch (without instance)'
--		,@level0type = N'SCHEMA'
--		,@level0name = N'Inbound'
--		,@level1type = N'TABLE'
--		,@level1name = N'BatchQueue'
--		,@level2type = N'COLUMN'
--		,@level2name = N'AuditHost'
--GO
