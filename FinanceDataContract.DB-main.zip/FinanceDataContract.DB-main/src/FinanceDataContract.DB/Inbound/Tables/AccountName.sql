﻿
CREATE TABLE [Inbound].[AccountName](
	[AccountKey] [varchar](255) NOT NULL,
	[AccountNames] [varchar](200) NULL,
	[FK_Batch] [int] NOT NULL
) ON [PRIMARY]
GO

EXEC sys.sp_addextendedproperty 
@name=N'description', 
@value=N'The data is loaded by the procedure [FinanceLanding].[MDS].[usp_LandingToInbound]. 
This is a snapshot of the data and is transient. 
From here it moves to the Outbound table. See the extended properties of that table to see how it is loaded.' , 
@level0type=N'SCHEMA',@level0name=N'Inbound', @level1type=N'TABLE',@level1name=N'AccountName'
GO
