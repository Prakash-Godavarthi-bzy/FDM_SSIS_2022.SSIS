﻿
CREATE TABLE [Inbound].[Transaction_Claim_Extensions_Bridge](
	[RowHash_Transaction] [varbinary](255) NOT NULL,
	[RowHash_Transaction_Claim_Extensions] [varbinary](255) NOT NULL,
	[FK_Batch] [int] NOT NULL
) ON [PRIMARY]
GO


CREATE UNIQUE CLUSTERED INDEX [idx_Transaction_Claim_Extensions_Bridge] ON [Inbound].[Transaction_Claim_Extensions_Bridge]
(
	[RowHash_Transaction] ASC,
	[RowHash_Transaction_Claim_Extensions] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO

