﻿
CREATE TABLE Inbound.[CatCode](
	[MarketCatCode] [varchar](12) NULL,
	[BeazleyCatCode] [char](12) NOT NULL,
	[BeazleyCatDesription] [varchar](30) NULL,
	[BeazleySpecial] [char](15) NULL,
	[EventYear] [int] NULL,
	[BeazleyEventName] [varchar](100) NULL,
	[LargeLossIndicator] [tinyint] NULL,
	[FK_Batch] int not null, 
    CONSTRAINT [PK_CatCode] PRIMARY KEY ([BeazleyCatCode]),
) ON [PRIMARY]
GO


EXEC sys.sp_addextendedproperty @name=N'description', @value=N'Holds the transient data which will go into Outbound.CatCode. This data is loaded via the procedure FinanceLanding.[MDS].[usp_LandingToInbound]' , @level0type=N'SCHEMA',@level0name=N'Inbound', @level1type=N'TABLE',@level1name=N'CatCode'
GO

