﻿
CREATE TABLE [Inbound].[ReInsuranceTreatyContractAttributes](
	[RI_Section_Reference] [varchar](12) NOT NULL,
	[RI_Policy_Type] [varchar](3) NULL,
	[ProgrammeCode] [varchar](100) NULL,
	[Inception_Date] [datetime] NULL,
	[Expiry_Date] [datetime] NULL,
	[Number_of_Reinstatements] [int] NULL,
	[Claim_Basis] [varchar](3) NULL,
	[Slip_Order_%] [numeric](19, 6) NULL,
	[General_Description] [varchar](240) NULL,
	[Sum_Insured_Limit] [numeric](19, 6) NULL,
	[Excess_Limit] [numeric](19, 6) NULL,
	[Sum_Insured_Currency] [varchar](3) NULL,
	[Event_Limit] [numeric](19, 6) NULL,
	[Event_Limit_Currency] [varchar](3) NULL,
	[Settlement_Limit] [numeric](19, 6) NULL,
	[Settlement_Limit_Currency] [varchar](3) NULL,
	[Currency_Converter] [numeric](19, 6) NULL,
	[Profit_Commission] [numeric](19, 6) NULL,
	[Profit_Commission_Management_Expenses] [numeric](19, 6) NULL,
	[Profit_Commission_Currency] [varchar](3) NULL,
	[Overrider] [numeric](19, 6) NULL,
	[Average_QS_%] [numeric](19, 6) NULL,
	[Number_of_QS_Policies] [int] NULL,
	[%_Ceded_to_QS] [numeric](19, 6) NULL,
	[FK_Batch] [int] NOT NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL,
	[AuditHost] [nvarchar](255) NOT NULL,
	[AuditAction] char(1) not null,
	[RowHash] varbinary(255) not null,
	[RowVersionNumber] int not null,

 CONSTRAINT [PK_ReInsuranceTreatyContractAttributes] PRIMARY KEY CLUSTERED 
(
	[RI_Section_Reference] ASC
)
)
GO

ALTER TABLE [Inbound].[ReInsuranceTreatyContractAttributes] ADD  CONSTRAINT [DF_ReInsuranceTreatyContractAttributes_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [Inbound].[ReInsuranceTreatyContractAttributes] ADD  CONSTRAINT [DF_ReInsuranceTreatyContractAttributes_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [Inbound].[ReInsuranceTreatyContractAttributes] ADD  CONSTRAINT [DF_ReInsuranceTreatyContractAttributes_AuditHost]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO


