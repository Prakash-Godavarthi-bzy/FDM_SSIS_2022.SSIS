
CREATE TABLE [Inbound].[Transaction_ReInsurance_Extensions_Bridge](
	[RowHash_Transaction] [varbinary](255) NOT NULL,
	[RowHash_Transaction_ReInsurance_Extensions] [varbinary](255) NOT NULL,
	ContractType char(3) not null,
	[FK_Batch] [int] NOT NULL
) 
GO
ALTER TABLE Inbound.[Transaction_ReInsurance_Extensions_Bridge] ADD CONSTRAINT
	CK_Transaction_ReInsurance_Extensions_Bridge CHECK (ContractType in ('TTY','FAC','PC','CCY','RRU','CCI','CRO','OBP','RIP','SAP','SPA','RRP','UPC','ROC','BRI','BUP','BPI','BEA','BRP','BUC','SUP','ADM','QQS','RAC','AEA','OPU','RDP','EPI','BOT','SOT'))
GO