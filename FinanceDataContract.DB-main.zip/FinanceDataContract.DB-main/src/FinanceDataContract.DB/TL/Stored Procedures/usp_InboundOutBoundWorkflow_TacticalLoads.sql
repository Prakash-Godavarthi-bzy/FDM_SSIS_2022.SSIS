﻿CREATE PROCEDURE [TL].[usp_InboundOutBoundWorkflow_TacticalLoads]
AS
BEGIN


	DECLARE @Trancount	INT = @@Trancount;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;
	DECLARE @v_AffectedRows INT= NULL;



	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;



		IF EXISTS (SELECT Pk_Batch FROM FinanceDataContract.Inbound.BatchQueue WHERE ( [Status] = 'InBound' or [Status]='OutBoundFailed' ) AND RunDescription = 'CSV files data as source')
			BEGIN

				/*=============================================================================================
         						Select Pending Batches with status Inbound
				==============================================================================================*/

				--DECLARE @BatchID AS BATCHID;

				declare @Batches table(PK_Batches int,DataSet varchar(50), id int identity(1,1))
				insert into @Batches(PK_Batches,DataSet)
				
				SELECT	Pk_Batch
						,DataSet
				FROM	FinanceDataContract.Inbound.BatchQueue
				WHERE	( [Status] = 'InBound' or [Status]='OutBoundFailed' )
				AND     RunDescription = 'CSV files data as source';

				SELECT *
				FROM @Batches
			
				RAISERROR('@Batches: %i', 0, 0, @@rowcount) WITH NOWAIT;

				
			/*=============================================================================================
         						Iterate DataSet wise if we have multiple datasets with Status Inbound
				==============================================================================================*/
			declare @id int = 1,
						@PK_Batch INT,
						@DataSet VARCHAR(50)
			
			while exists(select 1 from @Batches where id=@id)
			begin

			if object_id('tempdb..#Batch') is not null 
			drop table #Batch
					--declare #Batch table(PK_Batch int,DataSet varchar(50), i int )
				
					--	insert into @Batch(PK_Batch,DataSet,i)
				
						select @PK_Batch = PK_Batches,@DataSet = dataset--,id
						--INTO #Batch
						from @Batches
						where id=@id
						
						--SELECT *
						--FROM #Batch

						--set (select PK_Batches	from #Batch)       --s where id=@id)
						--=(select DataSet	from #Batch  )     --s where id=@id)

						--SELECT @PK_Batch,@DataSet


					---set batch status to running from Pending
						UPDATE		bq
						SET			[Status] = 'Running'
						FROM		FinanceDataContract.Inbound.BatchQueue	bq
						--INNER JOIN	#Batch			bi ON bq.Pk_Batch = bi.PK_Batches
						WHERE BQ.DataSet=@DataSet AND BQ.Pk_Batch=@PK_Batch

						RAISERROR('Running: %i', 0, 0, @@rowcount) WITH NOWAIT;

	

						INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
						--SELECT 5, '[BP].[usp_LandingInboundOutBoundWorkflow]', 'Batch Created';
						SELECT 5, '[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]', ' '+CONVERT(VARCHAR,@PK_Batch)+' Batch set to Running';

			/*=======================================================================================================================================
				Inside Iteration- Delete OutBound.Transaction Table data when latest batch has the AccountingPeriod which is already in OutBound
			========================================================================================================================================*/
	

				--		declare @Dates table(AccountingPeriod int, i int identity(1,1))
						
				--		insert into @Dates(AccountingPeriod)
				--		SELECT distinct LEFT(CAST(CONVERT(CHAR(10),DateOfFact,112) AS INT),6) AS AccountingPeriod
				--		FROM FinanceDataContract.Inbound.[Transaction] 
				--		WHERE Dataset= @DataSet--'BusinessPlan'  
				--		 AND AuditSourceBatchID = @PK_Batch
				--		ORDER BY 1 ASC
		
				--SELECT *
				--FROM @Dates
	
						if exists(select 1 from [FinanceDataContract].Outbound.[Transaction] where DataSet = @DataSet) --AND LEFT(CAST(CONVERT(CHAR(10),DateOfFact,112) AS INT),6) in (select AccountingPeriod from @Dates))
						begin

								--declare @i int = 1,
								--		@v_AccountingPeriod int= NULL
									
								--	while exists(select 1 from @Dates where i=@i)
								--	begin

								--			set @v_AccountingPeriod = (select AccountingPeriod from @Dates where i=@i)

								--				select [@v_AccountingPeriod] = @v_AccountingPeriod 

											DELETE OT
											FROM FinanceDataContract.Outbound.[Transaction] OT
											--JOIN #Batch  B ON  B.DataSet=OT.Dataset
											WHERE OT.Dataset= @DataSet --'BusinessPlan'
											--AND LEFT(CAST(CONVERT(CHAR(10),DateOfFact,112) AS INT),6)=@v_AccountingPeriod

											SELECT   @v_AffectedRows			= @@ROWCOUNT;

											INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
											SELECT 5, '[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]', 'Deleted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows in Outbound.Transaction table ' +' Of DataSet:'+convert(varchar,@DataSet) + ' Batch: ' +convert(varchar,@PK_Batch);

										--set @i += 1
									--END
						END

			/*-------------Deleting Box-4 Data----------------------*/
			if exists(select 1 from TechnicalHub.dim.DataSet  where BK_DataSet = @DataSet)
			begin

				DELETE TR 
				FROM TechnicalHub.FCT.TechnicalResult tr
				join TechnicalHub.dim.DataSet ds on tr.FK_DataSet=ds.PK_DataSet
				WHERE ds.BK_DataSet=@DataSet

				SELECT   @v_AffectedRows			= @@ROWCOUNT;

				INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
				SELECT 5, '[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]', 'Deleted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows in TechnicalHub.FCT.TechnicalResult table '+' Of DataSet:'+convert(varchar,@DataSet) + ' Batch: ' +convert(varchar,@PK_Batch);

			End

			/*=======================================================================================================================================
				Inside Iteration- Insert Inbound.Transaction table data into OutBound.Transaction Table
			========================================================================================================================================*/

				INSERT INTO [FinanceDataContract].[Outbound].[Transaction] WITH(TABLOCK)
								( [Scenario],[Basis],[Account],[DataSet],[DateOfFact],[BusinessKey],[PolicyNumber],[InceptionDate],[ExpiryDate],[BindDate],[DueDate],[TrifocusCode]
									,[Entity],[Location],[YOA],[TypeOfBusiness],[SettlementCCY],[OriginalCCY],[IsToDate],[Value],[ValueOrig],[RowHash],[BusinessProcessCode]
									,[AuditSourceBatchID],[AuditGenerateDateTime],[StatsCode],[FK_Batch],[DeltaType],[FK_Allocation],[AuditUserCreate],[AuditCreateDateTime],AuditHost,[BoundDate]
								)	
				SELECT
						IB.[Scenario],IB.[Basis],IB.[Account],IB.[DataSet],IB.[DateOfFact],IB.[BusinessKey],IB.[PolicyNumber],IB.[InceptionDate],IB.[ExpiryDate],IB.[BindDate],IB.[DueDate],IB.[TrifocusCode]
						,IB.[Entity],IB.[Location],IB.[YOA],IB.[TypeOfBusiness],IB.[SettlementCCY],IB.[OriginalCCY],IB.[IsToDate],IB.[Value],IB.[ValueOrig],IB.[RowHash],IB.[BusinessProcessCode]
						,IB.[AuditSourceBatchID],IB.[AuditGenerateDateTime],IB.[StatsCode],IB.[FK_Batch],IB.[DeltaType],IB.[FK_Allocation],IB.[AuditUserCreate],IB.[AuditCreateDateTime],IB.AuditHost,IB.[BoundDate]
				FROM FinanceDataContract.Inbound.[Transaction] IB
				--JOIN #Batch B ON B.PK_Batches=IB.AuditSourceBatchID 
							--AND B.DataSet=IB.Dataset
				WHERE IB.DATASET=@DataSet AND IB.AuditSourceBatchID = @PK_Batch
	

				SELECT   @v_AffectedRows			= @@ROWCOUNT;

					INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
					SELECT 5, '[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]', 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' into Outbound.Transaction table'  +' DataSet:'+convert(varchar,@DataSet) + ' Batch: ' +convert(varchar,@PK_Batch);
			
			/*=======================================================================================================================================
				Inside Iteration- DELETE  Inbound.Transaction table data FOR THE dataset wise in iteration
			========================================================================================================================================*/

					DELETE 			IB	
					FROM    [FinanceDataContract].[Inbound].[Transaction]	IB
					--JOIN #Batch B ON B.PK_Batches=IB.AuditSourceBatchID
					where ib.Dataset=@DataSet AND AuditSourceBatchID = @PK_Batch

					SELECT   @v_AffectedRows			= @@ROWCOUNT;

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
			SELECT 5, '[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]', 'Deleted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows in INbound.Transaction table for DataSet '+convert(varchar,@DataSet) ;


				/* =================UPDATE the batchqueue TO OUTBOUND========================= */

					UPDATE BQ
					SET BQ.Status='OutBound'
					FROM [FinanceDataContract].[Inbound].[BatchQueue] BQ
					--JOIN #Batch B ON B.PK_Batches=BQ.Pk_Batch
					WHERE BQ.DataSet=@DataSet AND BQ.Pk_Batch=@PK_Batch
								
					RAISERROR('Completed: %i', 0, 0, @@rowcount) WITH NOWAIT;

				-- LOGIN THE RESULT WITH SUCCESS
					INSERT @Logging(ActivityStatus, ActivityName) SELECT 2 , @p_ActivityName;

			
				set @id += 1  /*=======Multiple Batches Iteration for @Batches================*/
				
			END; 

		END -- If Exists
		IF @Trancount = 0 
		COMMIT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, '[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]', 'Business Plan InBoundOutbound Succeeded';

		--Generate logging for success
		EXEC log.usp_LogContract @Input = @Logging;

	END TRY

	BEGIN CATCH

		IF @Trancount = 0  
				ROLLBACK;
			
			
			-- LOG THE RESULT WITH ERROR

				UPDATE BQ
				SET BQ.Status='OutBoundFailed'
				FROM [FinanceDataContract].[Inbound].[BatchQueue] BQ
				--JOIN #Batch B ON B.PK_Batches=BQ.Pk_Batch
				WHERE BQ.DataSet=@DataSet AND BQ.Pk_Batch=@PK_Batch

			INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)	
			SELECT 4, '[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]', ERROR_MESSAGE();
			EXEC log.usp_LogContract @Input = @Logging;


			

		    THROW;

		
	END CATCH;

END;
