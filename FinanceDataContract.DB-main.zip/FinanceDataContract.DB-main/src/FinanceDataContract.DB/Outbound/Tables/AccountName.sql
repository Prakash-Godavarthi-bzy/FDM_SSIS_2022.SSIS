﻿
CREATE TABLE [Outbound].[AccountName](
	[AccountKey] [varchar](255) NOT NULL,
	[AccountNames] [varchar](200) NULL,
	[FK_Batch] [int] NOT NULL
) ON [PRIMARY]
GO



EXEC sys.sp_addextendedproperty 
@name=N'description', 
@value=N'The data is loaded/updated by the procedure [Inbound].[usp_InboundOutboundWorkflow_AccountNames]. 
The AccountKey matches the Account in the transaction table.
If the data changes, the FK_Batch is updated. The data origin is a static data script which will have the lineage. No need to have it here at this time.' , 
@level0type=N'SCHEMA',@level0name=N'Outbound', @level1type=N'TABLE',@level1name=N'AccountName'

GO

