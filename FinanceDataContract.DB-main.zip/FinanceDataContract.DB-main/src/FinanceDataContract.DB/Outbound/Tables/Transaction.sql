﻿CREATE TABLE [Outbound].[Transaction] (
    [PK_Transaction]        BIGINT          IDENTITY (1, 1) NOT NULL,
    [Scenario]              VARCHAR (2)     NOT NULL,
    [Account]               VARCHAR (14)    NOT NULL,
    [Dataset]               VARCHAR (255)   NOT NULL,
    [DateOfFact]            DATETIME        NOT NULL,
    [BusinessKey]           VARCHAR (255)   NOT NULL,
    [PolicyNumber]          VARCHAR (255)   NOT NULL,
    [InceptionDate]         DATETIME        CONSTRAINT [DF_Transaction_InceptionDate] DEFAULT ('19800101') NOT NULL,
    [ExpiryDate]            DATETIME        CONSTRAINT [DF_Transaction_ExpiryDate] DEFAULT ('19800101') NOT NULL,
    [BindDate]              DATETIME        CONSTRAINT [DF_Transaction_BindDate] DEFAULT ('19800101') NOT NULL,
    [DueDate]               DATETIME        CONSTRAINT [DF_Transaction_DueDate] DEFAULT ('19800101') NOT NULL,
    [TrifocusCode]          VARCHAR (25)    NOT NULL,
    [Entity]                VARCHAR (25)    NOT NULL,
    [YOA]                   VARCHAR (5)     NOT NULL,
    [TypeOfBusiness]        VARCHAR (1)     NOT NULL,
    [StatsCode]             VARCHAR (25)    NULL,
    [SettlementCCY]         VARCHAR (3)     NOT NULL,
    [OriginalCCY]           VARCHAR (3)     NOT NULL,
    [IsToDate]              VARCHAR (1)     NOT NULL,
    [Value]                 NUMERIC (19, 4) NOT NULL,
    [RowHash]               VARBINARY (255) NOT NULL,
    [FK_Allocation]         INT             NULL,
    [DeltaType]             VARCHAR (50)    NULL,
    [AuditSourceBatchID]    VARCHAR (255)   NOT NULL,
    [AuditCreateDateTime]   DATETIME        CONSTRAINT [DF_Transaction_AuditCreateDateTime] DEFAULT (getutcdate()) NOT NULL,
    [AuditGenerateDateTime] DATETIME        NOT NULL,
    [AuditUserCreate]       VARCHAR (255)   CONSTRAINT [DF_Transaction_AuditUserCreate] DEFAULT (suser_sname()) NOT NULL,
    [AuditHost]             VARCHAR (255)   DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) NOT NULL,
    [Basis]                 VARCHAR (2)     CONSTRAINT [DF_Transaction_Basis] DEFAULT ('-') NOT NULL,
    [Location]              VARCHAR (100)    CONSTRAINT [DF_Transaction_Location] DEFAULT ('-') NOT NULL,
    [ValueOrig]             NUMERIC (19, 4) NULL,
    [BusinessProcessCode]   VARCHAR (255)   NULL,
    [FK_Batch]              INT             NULL,
	[BoundDate]				DateTime2		NULL,
    CONSTRAINT [CK_Outbound_Transaction_Basis] CHECK ([Basis]='B' OR [Basis]='E' OR [Basis]='-'),
    CONSTRAINT [CK_Outbound_Transaction_IsToDate] CHECK ([IsToDate]='Y' OR [IsToDate]='N'),
    CONSTRAINT [CK_Outbound_Transaction_Scenario] CHECK ([Scenario]='B' OR [Scenario]='F' OR [Scenario]='A'),
    CONSTRAINT [CK_Outbound_Transaction_TypeOfBusiness] CHECK ([TypeOfBusiness]='N' OR [TypeOfBusiness]='R' OR [TypeOfBusiness]='-')
);

GO

CREATE NONCLUSTERED INDEX [IX_Transaction_Dataset] ON [Outbound].[Transaction] ([Dataset] ASC)
INCLUDE ([Scenario], [Account], [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate]
, [ExpiryDate], [DueDate], [TrifocusCode], [Entity],[YOA], 
[TypeOfBusiness], [StatsCode], [SettlementCCY], [OriginalCCY], [Value]
, [RowHash], [FK_Allocation], [AuditSourceBatchID], [Location]
)
GO

CREATE CLUSTERED COLUMNSTORE INDEX [CCI_Transaction_DataSet_IsToDate] ON [Outbound].[Transaction] WITH (DROP_EXISTING = OFF, COMPRESSION_DELAY = 0) ON [PRIMARY]

GO

EXECUTE sp_addextendedproperty 
		 @name = N'Table usage'
		,@value = N'Table used to store the provided deltas for onward consumption into the Finance Data Hub (Last valid)'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction';
GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'Whether the record is actual,forecast or budget.'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'Scenario';
GO

--EXECUTE sp_addextendedproperty 
--		 @name		 = N'MS_Description'
--		,@value		 = N'Whether the number is Estimated or Booked.'
--		,@level0type = N'SCHEMA'
--		,@level0name = N'Outbound'
--		,@level1type = N'TABLE'
--		,@level1name = N'Transaction'
--		,@level2type = N'COLUMN'
--		,@level2name = N'Basis';
--GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'The appropriate FTH account'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'Account';
GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'Plain text name of source system'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'DataSet';
GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'The date to log the transaction to'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'DateOfFact';
GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'The business unique reference for the record'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'BusinessKey';
GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'Most records will need to be attributed to a policy'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'PolicyNumber';
GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'Inception / start date of Policy / MTA – or associated policy if claim record'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'InceptionDate';
GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'Inception / start date of Policy / MTA – or associated policy if claim record'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'ExpiryDate';
GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'Inception / start date of Policy / MTA – or associated policy if claim record'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'BindDate';
GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'The due date of the transaction'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'DueDate';
GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'Beazley internal cost / profit centre'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'TrifocusCode';
GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'Beazley Legal Entity the transaction is booked to'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'Entity';
GO

--EXECUTE sp_addextendedproperty 
--		 @name		 = N'MS_Description'
--		,@value		 = N'Any location data provided - this does not need to be conformed'
--		,@level0type = N'SCHEMA'
--		,@level0name = N'Outbound'
--		,@level1type = N'TABLE'
--		,@level1name = N'Transaction'
--		,@level2type = N'COLUMN'
--		,@level2name = N'Location';
--GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'The value being recorded expressed in original currency'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'Value';
GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'Year of Account,or inception year if non Lloyds'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'YOA';
GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'Whether the measure is for new or renewal business'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'TypeOfBusiness';
GO

EXECUTE sp_addextendedproperty 
		 @name		 = N'MS_Description'
		,@value		 = N'Used for defining sidecar'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'StatsCode';
GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'Beazley Settlement CCY'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'SettlementCCY';
GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'Original Booked currency for transaction (if available - Repeat settlement currency if not)'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'OriginalCCY';
GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'A transaction can either be to-date / positional or purely transactional. The data contract can take to-date data and automatically generate a to-date delta to be fed through to the outbound portion of the contract.'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'IsToDate';
GO

--EXECUTE sp_addextendedproperty 
--		 @name = N'MS_Description'
--		,@value = N'The value being recorded expressed in settlement currency'
--		,@level0type = N'SCHEMA'
--		,@level0name = N'Outbound'
--		,@level1type = N'TABLE'
--		,@level1name = N'Transaction'
--		,@level2type = N'COLUMN'
--		,@level2name = N'ValueSett';
--GO

--EXECUTE sp_addextendedproperty 
--		 @name = N'MS_Description'
--		,@value = N'The value being recorded expressed in original currency'
--		,@level0type = N'SCHEMA'
--		,@level0name = N'Outbound'
--		,@level1type = N'TABLE'
--		,@level1name = N'Transaction'
--		,@level2type = N'COLUMN'
--		,@level2name = N'ValueOrg';
--GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'Used to generate unique keys per each record inserted. This is calculated via the SQL Server HASHBYTES function and using the concatenation of all the columns in the Transaction entity except the Value and Audit(s) columns.'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'RowHash';
GO

--EXECUTE sp_addextendedproperty 
--		 @name		 = N'MS_Description'
--		,@value		 = N'Used to indicate the transformation or group of transformations that are applied to the records before storing here.'
--		,@level0type = N'SCHEMA'
--		,@level0name = N'Outbound'
--		,@level1type = N'TABLE'
--		,@level1name = N'Transaction'
--		,@level2type = N'COLUMN'
--		,@level2name = N'BusinessProcessCode';
--GO

--EXECUTE sp_addextendedproperty 
--		 @name		 = N'MS_Description'
--		,@value		 = N'Identifier for specific load in landing database'
--		,@level0type = N'SCHEMA'
--		,@level0name = N'Outbound'
--		,@level1type = N'TABLE'
--		,@level1name = N'Transaction'
--		,@level2type = N'COLUMN'
--		,@level2name = N'FK_Batch';
--GO

EXECUTE sp_addextendedproperty 
		 @name		 = N'MS_Description'
		,@value		 = N'Identifier for specific load in landing database'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'DeltaType';
GO
EXECUTE sp_addextendedproperty 
		 @name		 = N'MS_Description'
		,@value		 = N'Identifier for specific load in landing database'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'FK_Allocation';
GO

EXECUTE sp_addextendedproperty	
		 @name = N'MS_Description'
		,@value = N'The source system batch id for the provided data'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'AuditSourceBatchID';
GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'FTH generated - schema default current datetime - users do not populate'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'AuditCreateDateTime';
GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'Datetime when data EXTRACTED from source system'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'AuditGenerateDateTime';
GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'A user name to attribute the load to. Could be person or system account'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'AuditUserCreate';
GO

EXECUTE sp_addextendedproperty 
		 @name = N'MS_Description'
		,@value = N'The server name of the system generating the batch (without instance)'
		,@level0type = N'SCHEMA'
		,@level0name = N'Outbound'
		,@level1type = N'TABLE'
		,@level1name = N'Transaction'
		,@level2type = N'COLUMN'
		,@level2name = N'AuditHost';
GO