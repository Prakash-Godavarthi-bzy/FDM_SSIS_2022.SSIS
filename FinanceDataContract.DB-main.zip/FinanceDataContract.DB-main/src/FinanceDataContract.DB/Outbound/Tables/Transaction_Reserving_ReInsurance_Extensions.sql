﻿-- drop  TABLE [Outbound].[Transaction_Reserving_ReInsurance_Extensions]
CREATE TABLE [Outbound].[Transaction_Reserving_ReInsurance_Extensions](
	[RowHash_Transaction_Reserving_ReInsurance_Extensions] [varbinary](255) NOT NULL,
	[special] [nvarchar](100) NULL,
	[datasetname] [nvarchar](200) NULL,
	[datasetgroup] [char](100) NULL,
	[att_cat] [nvarchar](30) NULL,
	[trianglegroup] [nvarchar](50) NULL,
	[FK_Batch] [int] NOT NULL,
	[BeazleyCatCode] [varchar](12) NULL
) 