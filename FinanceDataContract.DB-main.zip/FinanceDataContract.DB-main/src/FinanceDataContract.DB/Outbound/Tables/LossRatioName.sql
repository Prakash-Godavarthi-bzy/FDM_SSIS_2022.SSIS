﻿CREATE TABLE [Outbound].[LossRatioName] (
    [PK_LossRatioName]  INT           IDENTITY (1, 1) NOT NULL,
    [Table]             VARCHAR (200) NULL,
    [LossRatioAccount]  VARCHAR (50)  NULL,
    [LossRatioName]     VARCHAR (200) NULL,
    [LossRatioScenario] VARCHAR (50)  NULL
);

