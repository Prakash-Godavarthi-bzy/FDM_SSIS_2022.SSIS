﻿CREATE TABLE [Outbound].[Transaction_AgressoAR_Extensions_Bridge](
	[RowHash_Transaction] [varbinary](255) NOT NULL,
	[RowHash_Transaction_AgressoAR_Extensions] [varbinary](255) NOT NULL,
	[FK_Batch] [int] NOT NULL
) ON [PRIMARY]
GO
