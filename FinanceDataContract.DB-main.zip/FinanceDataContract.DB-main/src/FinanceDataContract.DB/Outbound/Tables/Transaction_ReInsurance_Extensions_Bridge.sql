﻿
CREATE TABLE [Outbound].[Transaction_ReInsurance_Extensions_Bridge](
	[RowHash_Transaction] [varbinary](255) NOT NULL,
	[RowHash_Transaction_ReInsurance_Extensions] [varbinary](255) NOT NULL,
	[FK_Batch] [int] NOT NULL
) 