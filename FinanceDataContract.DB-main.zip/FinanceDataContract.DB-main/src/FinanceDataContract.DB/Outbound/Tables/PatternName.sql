﻿CREATE TABLE [Outbound].[PatternName] (
    [PatternKey]      VARCHAR (20)  NOT NULL,
    [PatternNames]    VARCHAR (200) NOT NULL, 
    CONSTRAINT [PK_PatternName] PRIMARY KEY ([PatternKey]),
);

GO
EXEC sys.sp_addextendedproperty 
@name=N'description', 
@value=N'The data is loaded/updated by the procedure [Inbound].[usp_InboundOutboundWorkflow_AccountNames]. 
The AccountKey matches the Account in the transaction table.
If the data changes, the FK_Batch is updated. The data origin is a static data script (in FinanceLanding) which will have the lineage.' 
, @level0type=N'SCHEMA',@level0name=N'Outbound', @level1type=N'TABLE',@level1name=N'PatternName'
GO
