﻿
CREATE TABLE [Outbound].[Transaction_ReInsurance_Extensions](
	[RowHash_Transaction_ReInsurance_Extensions] [varbinary](255) NOT NULL,
	[RIPolicyType] [varchar](50) NULL,
	[ProgrammeCode] [varchar](100) NULL,
	BeazleyCatCode [varchar](12) NULL,
	TransactionDate date null,
	[IsLargeLoss] bit null ,
	[FK_Batch] [int] NOT NULL
)