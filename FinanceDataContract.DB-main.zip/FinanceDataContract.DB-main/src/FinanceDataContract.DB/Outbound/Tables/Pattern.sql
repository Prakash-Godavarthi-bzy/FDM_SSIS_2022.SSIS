﻿CREATE TABLE [Outbound].[Pattern] (
    [PK_Pattern]                     INT             IDENTITY (1, 1) NOT NULL,
    [PatternScenario]                VARCHAR (10)    NOT NULL,
    [PatternScenarioVersion]         INT             NOT NULL,
    [PatternKey]                    VARCHAR (20)    NOT NULL,
    [DataSet]                        VARCHAR (50)    NOT NULL,
    [TrifocusCode]                   VARCHAR (100)   NOT NULL,
    [YOA]                            VARCHAR (5)     NULL,
    [InceptionYear]                  SMALLINT        NULL,
    [SettlementCCY]                  VARCHAR (3)     NULL,
    [DevelopmentPercentageIncrement] NUMERIC (19, 6) NOT NULL,
    [DevelopmentQuarter]             INT             NOT NULL,
    [BusinessProcessCode]            VARCHAR (255)   NOT NULL,
    [FK_Batch]                       INT             NOT NULL,
    [AuditSourceBatchID]             VARCHAR (255)   NOT NULL,
    [AuditCreateDateTime]            DATETIME        CONSTRAINT [DF_Pattern_AuditCreateDateTime] DEFAULT (getutcdate()) NOT NULL,
    [AuditGenerateDateTime]          DATETIME        NOT NULL,
    [AuditUserCreate]                VARCHAR (255)   CONSTRAINT [DF_Pattern_AuditUserCreate] DEFAULT (suser_sname()) NOT NULL,
    [AuditHost]                      VARCHAR (255)   DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))) NOT NULL,
	[BusinessKey]                    VARCHAR (255)   NULL,
    CONSTRAINT [PK_INBD_Pattern] PRIMARY KEY CLUSTERED ([PK_Pattern] ASC) WITH (FILLFACTOR = 90)
);

