﻿CREATE TABLE [Outbound].[Premium_Extensions](
	[RowHash_Transaction_Premium_Extensions] [varbinary](255) NOT NULL,
	[PolicyClaimBasis] [varchar](10) NULL,
	[PolicyMOPCode] [varchar](10) NULL,
	[PolicyCobCode] [varchar](10) NULL,
	[PolicyNumber] [varchar](255) NOT NULL,
	[FK_Batch] [int] NOT NULL
) ON [PRIMARY]
GO
