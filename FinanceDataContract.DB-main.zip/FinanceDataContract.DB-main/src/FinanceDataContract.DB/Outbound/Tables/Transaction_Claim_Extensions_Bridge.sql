﻿
CREATE TABLE [Outbound].[Transaction_Claim_Extensions_Bridge](
	[RowHash_Transaction] [varbinary](255) NOT NULL,
	[RowHash_Transaction_Claim_Extensions] [varbinary](255) NOT NULL,
	[FK_Batch] [int] NOT NULL
) ON [PRIMARY]
GO


