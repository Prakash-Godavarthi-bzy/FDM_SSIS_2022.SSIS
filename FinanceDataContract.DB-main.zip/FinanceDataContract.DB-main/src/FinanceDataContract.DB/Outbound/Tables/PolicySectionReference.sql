﻿
CREATE TABLE [Outbound].[PolicySectionReference](
	[PolicyReference] [varchar](255) NOT NULL,
	[SectionReference] [varchar](255) NOT NULL,
	[FK_Batch] [int] NOT NULL
)