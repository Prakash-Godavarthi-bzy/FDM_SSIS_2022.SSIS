﻿
CREATE TABLE [Outbound].[ReInsuranceTreatyContractAttributes](
	[RI_Section_Reference] [varchar](12) NOT NULL,
	[RI_Policy_Type] [varchar](3) NULL,
	[ProgrammeCode] [varchar](100) NULL,
	[Inception_Date] [datetime] NULL,
	[Expiry_Date] [datetime] NULL,
	[Number_of_Reinstatements] [int] NULL,
	[Claim_Basis] [varchar](3) NULL,
	[Slip_Order_%] [numeric](19, 6) NULL,
	[General_Description] [varchar](240) NULL,
	[Sum_Insured_Limit] [numeric](19, 6) NULL,
	[Excess_Limit] [numeric](19, 6) NULL,
	[Sum_Insured_Currency] [varchar](3) NULL,
	[Event_Limit] [numeric](19, 6) NULL,
	[Event_Limit_Currency] [varchar](3) NULL,
	[Settlement_Limit] [numeric](19, 6) NULL,
	[Settlement_Limit_Currency] [varchar](3) NULL,
	[Currency_Converter] [numeric](19, 6) NULL,
	[Profit_Commission] [numeric](19, 6) NULL,
	[Profit_Commission_Management_Expenses] [numeric](19, 6) NULL,
	[Profit_Commission_Currency] [varchar](3) NULL,
	[Overrider] [numeric](19, 6) NULL,
	[Average_QS_%] [numeric](19, 6) NULL,
	[Number_of_QS_Policies] [int] NULL,
	[%_Ceded_to_QS] [numeric](19, 6) NULL,
	[FK_Batch] [int] NOT NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL,
	[AuditHost] [nvarchar](255) NOT NULL,
	[AuditAction] [char](1) NOT NULL,
	[RowHash] [varbinary](255) NOT NULL,
	[RowIsLatest] [bit] NOT NULL,
	[RowVersionNumber] [int] NOT NULL,
 CONSTRAINT [PK_ReInsuranceTreatyContractAttributes] PRIMARY KEY CLUSTERED 
(
	[RI_Section_Reference] ASC,
	[RowVersionNumber] ASC
)
) 
GO

ALTER TABLE [Outbound].[ReInsuranceTreatyContractAttributes]  WITH CHECK ADD  CONSTRAINT [CK_ReInsuranceTreatyContractAttributes] CHECK  (([AuditAction]='D' OR [AuditAction]='U' OR [AuditAction]='I'))
GO

ALTER TABLE [Outbound].[ReInsuranceTreatyContractAttributes] CHECK CONSTRAINT [CK_ReInsuranceTreatyContractAttributes]
GO

EXEC sys.sp_addextendedproperty 
	@name=N'description', 
	@value=N'Contains attributes for Re-Insurance treaty contracts from Eurobase. This holds history. To get the latest set of contracts, use the column RowIsLatest=1. If you don''t want to get deleted contract, filter on AuditAction <> ''D''' , 
	@level0type=N'SCHEMA',@level0name=N'Outbound', @level1type=N'TABLE',@level1name=N'ReInsuranceTreatyContractAttributes'
GO


