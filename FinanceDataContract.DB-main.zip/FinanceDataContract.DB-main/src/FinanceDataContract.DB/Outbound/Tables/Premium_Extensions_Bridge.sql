﻿
CREATE TABLE [Outbound].[Premium_Extensions_Bridge](
	[RowHash_Transaction] [varbinary](255) NOT NULL,
	[RowHash_Transaction_Premium_Extensions] [varbinary](255) NOT NULL,
	[FK_Batch] [int] NOT NULL
) ON [PRIMARY]
GO
