﻿--drop  TABLE Outbound.[ReInsuranceTrifocusAllocationsTreaty]

CREATE TABLE Outbound.[ReInsuranceTrifocusAllocationsTreaty](
	id int identity(1,1) not null primary key,
	[EntityCode] [nvarchar](255) NULL,
	[EntityName] [nvarchar](255) NULL,
	[AccountCode] [nvarchar](255) NULL,
	[AccountingPeriod] [int] NOT NULL,
	[RIPolicyNumber] [nvarchar](255) NULL,
	[YOA] [int] NOT NULL,
	[RIType] [nvarchar](50) NULL,
	[RIProgramme] [nvarchar](255) NULL,
	[TrifocusCode] [nvarchar](255) NULL,
	[TrifocusName] [nvarchar](255) NULL,
	[SettlementCurrency] [nvarchar](25) NULL,
	[Amount] [decimal](38, 3) NULL,
	[TotalAmount] [decimal](38, 3) NULL,
	[Allocation] [decimal](38, 6) NULL,
	[FK_BatchCreate] [int] NOT NULL,
	[FK_BatchUpdate] [int] NULL,
	[AuditCreateDateTime] [datetime] NOT NULL, 
	[AuditUpdateDateTime] [datetime] NULL, 
	[AuditCreateUser] [varchar](255) NOT NULL,
	[AuditUpdateUser] [varchar](255) NULL,
	[AuditCreateHost] [varchar](255) NOT NULL,
	[AuditUpdateHost] [varchar](255) NULL,
	[DataSet] [varchar](50) NOT NULL,
	[BusinessKey] as
				 concat(
					ISNULL(ltrim(rtrim( [EntityCode])), '<isnull>') , '|' ,
					ISNULL(ltrim(rtrim([EntityName])), '<isnull>')  , '|' ,
					ISNULL(ltrim(rtrim([AccountCode])), '<isnull>') , '|' ,
					ISNULL(convert(varchar(30), [AccountingPeriod]), '<isnull>')  , '|' ,
					ISNULL(ltrim(rtrim([RIPolicyNumber])), '<isnull>') , '|' ,
					ISNULL(convert(varchar(30), [YOA]), '<isnull>')  , '|' ,
					ISNULL(ltrim(rtrim([RIType])), '<isnull>') , '|' ,
					ISNULL(ltrim(rtrim([RIProgramme])), '<isnull>') , '|' ,
					ISNULL(ltrim(rtrim([TrifocusCode])), '<isnull>') , '|' ,
					ISNULL(ltrim(rtrim([TrifocusName])), '<isnull>') , '|' ,
					ISNULL(ltrim(rtrim([SettlementCurrency])), '<isnull>') 
					)  ,


)