﻿
CREATE TABLE [Outbound].[CatCode](
	[MarketCatCode] [varchar](12) NULL,
	[BeazleyCatCode] [char](12) NOT NULL,
	[BeazleyCatDesription] [varchar](30) NULL,
	[BeazleySpecial] [char](15) NULL,
	[EventYear] [int] NULL,
	[BeazleyEventName] [varchar](100) NULL,
	[LargeLossIndicator] [tinyint] NULL,
	[AuditSourceBatchID] [varchar](255) NOT NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditGenerateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [varchar](255) NOT NULL,
	[AuditHost] [varchar](255) NULL,
	[FK_Batch] int not null,
	[DataSet] [varchar](50) NOT NULL, 
    CONSTRAINT [PK_CatCode] PRIMARY KEY ([BeazleyCatCode]),
) ON [PRIMARY]
GO


ALTER TABLE [Outbound].[CatCode] ADD  CONSTRAINT [DF_Outbd_CatCode_AuditCreateDateTime]  DEFAULT (getutcdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [Outbound].[CatCode] ADD  CONSTRAINT [DF_Outbd_CatCode_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [Outbound].[CatCode] ADD  CONSTRAINT [DF_Outbd_CatCode_AuditUserHost]  DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO


