﻿--===========================================================
--Stored Procedures
--===========================================================

IF EXISTS (SELECT * FROM SYS.PROCEDURES WHERE NAME='USP_LOGBATCHAGGREGATE_INBOUNDFDMCHE')
BEGIN
DROP PROCEDURE [TEST].[USP_LOGBATCHAGGREGATE_INBOUNDFDMCHE]
END

IF EXISTS (SELECT * FROM SYS.PROCEDURES WHERE NAME='usp_LogBatchAggregate_ExpectedOutboundFDMCHE')
BEGIN
DROP PROCEDURE [TEST].usp_LogBatchAggregate_ExpectedOutboundFDMCHE
END

IF EXISTS (SELECT * FROM SYS.PROCEDURES WHERE NAME='usp_LogBatchAggregate_ActualOutboundFDMCHE')
BEGIN
DROP PROCEDURE [TEST].usp_LogBatchAggregate_ActualOutboundFDMCHE
END

IF EXISTS (SELECT * FROM SYS.PROCEDURES WHERE NAME='usp_LogBatchAggregate_InboundUSSYND')
BEGIN
DROP PROCEDURE [TEST].usp_LogBatchAggregate_InboundUSSYND
END

IF EXISTS (SELECT * FROM SYS.PROCEDURES WHERE NAME='usp_LogBatchAggregate_ExpectedTechnicalHubUSSYND')
BEGIN
DROP PROCEDURE [TEST].usp_LogBatchAggregate_ExpectedTechnicalHubUSSYND
END

IF EXISTS (SELECT * FROM SYS.PROCEDURES WHERE NAME='usp_LogBatchAggregate_ExpectedOutBoundUSSYND')
BEGIN
DROP PROCEDURE [TEST].usp_LogBatchAggregate_ExpectedOutBoundUSSYND
END
