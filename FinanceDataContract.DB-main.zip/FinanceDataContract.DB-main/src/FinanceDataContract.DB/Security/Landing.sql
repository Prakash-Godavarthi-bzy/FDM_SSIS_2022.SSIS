﻿CREATE SCHEMA [Landing]
    AUTHORIZATION [dbo];


GO
EXECUTE sp_addextendedproperty @name = N'Schema usage', @value = N'This schema will be used for bulk pull operations from modules that can`t provide deltas', @level0type = N'SCHEMA', @level0name = N'Landing';

