﻿CREATE SCHEMA [Test]
    AUTHORIZATION [dbo];














GO
EXECUTE sp_addextendedproperty @name = N'Schema usage', @value = N'This schema will be used for tables that will store calculated delta for tables owned by Landing schema', @level0type = N'SCHEMA', @level0name = N'Test';

