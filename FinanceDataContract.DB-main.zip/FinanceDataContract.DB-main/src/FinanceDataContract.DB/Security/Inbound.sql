﻿CREATE SCHEMA [Inbound]
    AUTHORIZATION [dbo];




























GO
EXECUTE sp_addextendedproperty @name = N'Schema usage', @value = N'This schema will be used for tables that will accomodate calculated and/or pushed deltas', @level0type = N'SCHEMA', @level0name = N'Inbound';

