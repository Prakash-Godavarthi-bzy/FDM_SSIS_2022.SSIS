﻿CREATE PROCEDURE [dbo].[usp_LogDataContract]	
													@v_ActivityMessage         NVARCHAR(4000), 
													@v_ActivityStatus          SMALLINT, --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName            VARCHAR(50)    = NULL,
													@v_ActivitySSISExecutionId VARCHAR(50)    = NULL,
													@V_JobId                      INT=Null
													

AS

    BEGIN

/*
		=========================================================================================================
						Insert into Log table
		=========================================================================================================
*/

        INSERT INTO [Orchestram].[Log].[ActivityLog]
					(
					 FK_ParentActivityLog, 
					 FK_ActivityLogTag, 
					 FK_ActivitySource, 
					 FK_ActivityType, 
					 FK_ActivityStatus, 
					 ActivityHost, 
					 ActivityDatabase, 
					 ActivityJobId, 
					 ActivitySSISExecutionId, 
					 ActivityName, 
					 ActivityDateTime, 
					 ActivityMessage
					)
            SELECT	NULL, 
                      NULL, 
                      2, --DataContract
                      3, --DataQuality
                      @v_ActivityStatus, 
                      @@SERVERNAME, 
                      'DataContract', 
                      @V_JobId, 
                      @v_ActivitySSISExecutionId, 
                      ISNULL(@v_ActivityName,' Import into FinanceLanding'),
                      GETDATE(), 
                      @v_ActivityMessage;
    END;