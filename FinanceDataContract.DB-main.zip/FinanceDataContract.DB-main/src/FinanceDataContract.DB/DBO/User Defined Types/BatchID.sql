﻿CREATE TYPE [dbo].[BatchID] AS TABLE (
    [PK_BatchID]   INT           NULL,
    DataSet        NVARCHAR (50) NULL,
	ASAT           VARCHAR(6) NULL
	
	);

