﻿CREATE	PROC [Test].[usp_LogBatchAggregate_ExpectedOutBoundBICI] @batchid AS BatchID READONLY
AS
	--     /* 
	--        ========================================================================================================= 
	--          Insert expected outbound value into logging table, insert statment has been used to logg row per b atchID  
	--    ========================================================================================================= 
	--*/ 

	IF EXISTS (SELECT ActivityJobId FROM [Orchestram].[Log].[ActivityLog] a WHERE a.ActivityName = 'BICITechnicalHubActual.test.usp_LogBatchAggregate')
	BEGIN

	DECLARE @MaxIDBICI INT=(	SELECT ISNULL(MAX(CAST(ActivityJobId AS INT)), 0)
							FROM [Orchestram].[Log].[ActivityLog] 
							WHERE ActivityName = 'BICITechnicalHubActual.test.usp_LogBatchAggregate'
						)
		INSERT	INTO [Orchestram].[Log].[ActivityLog](FK_ParentActivityLog, FK_ActivityLogTag, FK_ActivitySource, FK_ActivityType, FK_ActivityStatus
													,ActivityHost, ActivityDatabase, ActivityJobId, ActivitySSISExecutionId, ActivityName, ActivityDateTime
													,ActivityMessage)
		SELECT	NULL
				,NULL
				,2 --DataContract
				,3 --DataQuality
				,5 --Information
				,@@servername
				,'DataContract'
				,a.ActivityJobId
				,NULL
				,'BICIOutboundExpected.test.usp_LogBatchAggregateBICI'
				,GETDATE()
				,a.activitymessage
		FROM	(
					SELECT	ActivityJobId
							,valuecurrnt	= CAST(ActivityMessage AS NUMERIC(19, 4))
							,previousvalue	= (CASE WHEN BQ.OriginalName='Adjustments' THEN 0
														ELSE
														ISNULL(CAST(LAG(ActivityMessage, 1, 0) OVER (ORDER BY CAST(bq.originalName AS Varchar(20))) AS NUMERIC(19, 4)), 0)
													END )
							--ISNULL(CAST(LAG(ActivityMessage, 1, 0) OVER (ORDER BY CAST(ActivityJobID AS INT)) AS NUMERIC(19, 4)), 0)
							,activitymessage = CAST(ActivityMessage AS NUMERIC(19, 4))
												- (CASE WHEN BQ.OriginalName='Adjustments' THEN 0
														ELSE ISNULL(CAST(LAG(ActivityMessage, 1, 0) OVER (ORDER BY CAST(bq.originalName AS Varchar(20))) AS NUMERIC(19, 4)), 0) 
														END )
												--ISNULL(CAST(LAG(ActivityMessage, 1, 0) OVER (ORDER BY CAST(ActivityJobID AS INT)) AS NUMERIC(19, 4)), 0)
					FROM	[Orchestram].[Log].[ActivityLog] a
					Inner JOIN FinanceDataContract.Inbound.BatchQueue BQ ON BQ.Pk_Batch=CAST(A.ActivityJobId AS INT)
					WHERE	a.ActivityName = 'Inbound.test.usp_LogBatchAggregateBICI'
						AND ActivityJobId IS NOT NULL
						--AND CAST(ActivityJobId AS INT) >= (SELECT ISNULL(MAX(CAST(ActivityJobId AS INT)), 0)FROM [Orchestram].[Log].[ActivityLog] WHERE ActivityName = 'FDMTechnicalHubActual.test.usp_LogBatchAggregate')
				)			a
		JOIN	@batchid	b ON a.ActivityJobId = CAST(b.PK_BatchID AS NVARCHAR(50))
		AND CAST(ActivityJobId AS INT) >= ISNULL(@MaxIDBICI,0)
							AND b.DataSet = 'BICI';

	END;
	/*        ========================================================================================================= 
         First Run
        ========================================================================================================= 
    */
	ELSE
	BEGIN
		INSERT	INTO [Orchestram].[Log].[ActivityLog](FK_ParentActivityLog, FK_ActivityLogTag, FK_ActivitySource, FK_ActivityType, FK_ActivityStatus
													,ActivityHost, ActivityDatabase, ActivityJobId, ActivitySSISExecutionId, ActivityName, ActivityDateTime
													,ActivityMessage)
		SELECT	NULL
				,NULL
				,2 --DataContract
				,3 --DataQuality
				,5 --Information
				,@@servername
				,'DataContract'
				,a.ActivityJobId
				,NULL
				,'BICIOutboundExpected.test.usp_LogBatchAggregateBICI'
				,GETDATE()
				,a.activitymessage
		FROM	(
					SELECT	ActivityJobId
							,activitymessage = CAST(ActivityMessage AS NUMERIC(19, 4))
												- ISNULL(CAST(LAG(ActivityMessage, 1, 0) OVER (ORDER BY CAST(ActivityJobID AS INT)) AS NUMERIC(19, 4)), 0)
					FROM	[Orchestram].[Log].[ActivityLog]	lal
					JOIN	Inbound.BatchQueue					ibq ON ibq.Pk_Batch = lal.ActivityJobId
					WHERE	ActivityName = 'Inbound.test.usp_LogBatchAggregateBICI'
						AND ibq.Status <> 'OutboundFailed'
				)			a
		JOIN	@batchid	b ON a.ActivityJobId = CAST(b.PK_BatchID AS NVARCHAR(50));
	END;
