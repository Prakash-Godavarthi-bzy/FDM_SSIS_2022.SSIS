﻿CREATE PROC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHub] @BatchID AS BATCHID READONLY
AS
     --     /*
     --        =========================================================================================================
     --						Set logging parameters for inbound value test
     --		=========================================================================================================
     --*/

     INSERT INTO [Orchestram].[Log].[ActivityLog]
     (FK_ParentActivityLog, 
      FK_ActivityLogTag, 
      FK_ActivitySource, 
      FK_ActivityType, 
      FK_ActivityStatus, 
      ActivityHost, 
      ActivityDatabase, 
      ActivityJobId, 
      ActivitySSISExecutionId, 
      ActivityName, 
      ActivityDateTime, 
      ActivityMessage
     )
            SELECT NULL, 
                   NULL, 
                   5, 
                   1, 
                   5, 
                   @@SERVERNAME, 
                   'DataContract', 
                   A.BatchID, 
                   NULL, 
                   'TechnicalHubExpected.test.usp_LogBatchAggregate', 
                   GETDATE(), 
                   a.activitymessage
            FROM
            (
                SELECT SUM([value]) AS activitymessage, 
                       [AuditSourceBatchID] AS BatchID
                FROM FinanceDataContract.[Outbound].[Transaction] O
                     INNER JOIN @BatchID B ON CAST(o.AuditSourceBatchID AS INT) = B.PK_BatchID
                WHERE o.[DataSet] = B.DataSet
				      AND o.[DataSet] = 'Eurobase' AND CAST(O.YOA AS VARCHAR(20))>'1992'
					  AND O.ENTITY <>  '6107'

                --      AND O.TrifocusCode IN   --SIT NFT Hotfix
                --(
                --    SELECT TrifocusCode COLLATE DATABASE_DEFAULT
                --    FROM FinanceLanding.sp.TrifocusCode 
                --    WHERE ISNULL(IsUSTrifocus, 0) <> 1
                --          AND SourceSystem = 'Eurobase'
                --)
                      AND LEFT(O.PolicyNumber, 6) COLLATE DATABASE_DEFAULT NOT IN
                (
                    SELECT [UsPolicyRef] COLLATE DATABASE_DEFAULT
                    FROM [FinanceLanding].[sp].[EurobaseUSPolicyExclusion]
                )
                GROUP BY [AuditSourceBatchID]
            ) a
            JOIN @BatchID B ON A.BatchID = CAST(B.PK_BatchID AS NVARCHAR(50));