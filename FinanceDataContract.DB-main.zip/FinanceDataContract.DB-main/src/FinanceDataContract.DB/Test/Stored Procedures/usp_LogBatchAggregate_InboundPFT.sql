﻿CREATE PROC [Test].[usp_LogBatchAggregate_InboundPFT] @BatchId INT
AS

/*
        =========================================================================================================
						Set logging parameters for inbound value test
		=========================================================================================================
*/

     DECLARE
     @v_ActivityStatus SMALLINT= 5, --1 started 2 succeded 3 stopped 4 errored 5 information 
     @v_ActivityName VARCHAR(50)= 'PFTInbound.test.usp_LogBatchAggregatePFT', @v_JobID INT= @BatchID, @v_ActivityMessage NVARCHAR(4000)=
     (
         SELECT SUM(ISNULL([VALUE],0)) 
		 FROM FinanceDataContract.[Inbound].[Transaction]
		WHERE AuditSourceBatchID = @BatchId
               AND DataSet = 'PFT'
         GROUP BY [AuditSourceBatchID]
     );

/*
		=========================================================================================================
						Log PFT total value in Landing for testing inbound datacontract value
		=========================================================================================================
*/

     EXEC [dbo].[usp_LogDataContract] 
         
          @v_ActivityMessage, 
          @v_ActivityStatus, 
          @v_ActivityName, 
          NULL, 
          @v_JobID;

/*
		=========================================================================================================
						IF PFTLandingvalue not equal to PFTInboundvalue raise error
		=========================================================================================================
*/

     IF EXISTS
     (
         SELECT L.ActivityMessage, 
                I.ActivityMessage
         FROM Orchestram.[Log].ActivityLog L
              JOIN Orchestram.[Log].ActivityLog I ON L.ActivityJobId = I.ActivityJobId
         WHERE L.ActivityJobId = @BatchId
               AND L.ActivityName = 'PFTLanding.test.usp_LogBatchAggregatePFT'
               AND I.ActivityName = 'PFTInbound.test.usp_LogBatchAggregatePFT'
               AND CAST(ROUND(L.ActivityMessage,00) AS NUMERIC(16,4)) <>CAST(ROUND(I.ActivityMessage,00) AS NUMERIC(16,4))
     )
         BEGIN
             RAISERROR('PFTInbound value is not matching to PFTlanding value for BatchID: %i',16,1,@BatchId);
     END;