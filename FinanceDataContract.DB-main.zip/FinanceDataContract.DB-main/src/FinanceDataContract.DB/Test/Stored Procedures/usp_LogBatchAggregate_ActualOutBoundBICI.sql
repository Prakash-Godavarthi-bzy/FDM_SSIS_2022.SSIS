﻿CREATE PROC [Test].[usp_LogBatchAggregate_ActualOutBoundBICI]  
		@BatchID  AS BatchID READONLY
AS
--     /*
--        =========================================================================================================
--						Set logging parameters for BICIOutBound value test
--		=========================================================================================================
--*/

    

      INSERT INTO [Orchestram].[Log].[ActivityLog]
					(
					 FK_ParentActivityLog, 
					 FK_ActivityLogTag, 
					 FK_ActivitySource, 
					 FK_ActivityType, 
					 FK_ActivityStatus, 
					 ActivityHost, 
					 ActivityDatabase, 
					 ActivityJobId, 
					 ActivitySSISExecutionId, 
				     ActivityName, 
					 ActivityDateTime, 
					 ActivityMessage
					)
 
  SELECT			 NULL, 
                      NULL, 
                      2, --DataContract
                      3, --DataQuality
                      5, --Information
                      @@SERVERNAME, 
                      'DataContract', 
					   A.AuditSourceBatchID,
					      NULL, 
                      'BICIOutboundActual.test.usp_LogBatchAggregateBICI',
                      GETDATE(), 
					  SUM(ISNULL(A.[VALUE],0)) AS activitymessage
	          FROM Outbound.[Transaction] a
			  JOIN @BatchID B ON  A.AuditSourceBatchID=CAST(B.PK_BatchID AS VARCHAR(50)) and a.[DataSet]=b.DataSet
			  AND a.[DataSet]='BICI'
			  GROUP BY A.AuditSourceBatchID

					   
/*
		=========================================================================================================
						IF BICIActualOutbound is not equal to BICIExpectedOutbound raise error
		=========================================================================================================
*/

   --  IF EXISTS
   --  (
   --      SELECT E.ActivityMessage, 
   --             A.ActivityMessage
   --      FROM Orchestram.[Log].ActivityLog E
		 --     JOIN @BatchID B ON  E.ActivityJobId=CAST(B.PK_BatchID AS VARCHAR(50))
   --           JOIN Orchestram.[Log].ActivityLog A ON E.ActivityJobId = A.ActivityJobId
			-- JOIN Inbound.BatchQueue as bq ON B.PK_BatchID = bq.Pk_Batch 
   --      WHERE  E.ActivityName = 'BICIOutboundExpected.test.usp_LogBatchAggregateBICI'
   --            AND A.ActivityName = 'BICIOutboundActual.test.usp_LogBatchAggregateBICI'
   --           AND ABS(CAST(E.ActivityMessage AS NUMERIC(25,6)) - CAST(A.ActivityMessage AS NUMERIC(25,6)))>20.0
			--  AND bq.OriginalName IS NULL
   --  )
   --      BEGIN
   --           DECLARE @Message VARCHAR(250);

		 --SELECT @Message = 'BICI Error: BICI Expected Outbound does not match actual outbound. Expected: '+E.ActivityMessage +', Actual: '+
   --             A.ActivityMessage
   --      FROM Orchestram.[Log].ActivityLog E
		 --     JOIN @BatchID B ON  E.ActivityJobId=CAST(B.PK_BatchID AS VARCHAR(50))
   --           JOIN Orchestram.[Log].ActivityLog A ON E.ActivityJobId = A.ActivityJobId
			--  JOIN Inbound.BatchQueue as bq ON B.PK_BatchID = bq.Pk_Batch 
		 --WHERE  E.ActivityName = 'BICIOutboundExpected.test.usp_LogBatchAggregateBICI'
   --            AND A.ActivityName = 'BICIOutboundActual.test.usp_LogBatchAggregateBICI'
   --            AND ABS(ABS(CAST(E.ActivityMessage AS NUMERIC(25,4))) - ABS(CAST(A.ActivityMessage AS NUMERIC(25,4))))>20
			--   AND bq.OriginalName IS NULL
   --          RAISERROR(@Message,16,1);
   --  END;
