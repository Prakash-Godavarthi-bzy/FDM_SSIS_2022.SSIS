﻿CREATE PROC  [Test].[usp_InboundOutboundWorkflow_TransactionalReversal]
AS 
         DECLARE @Trancount INT = @@Trancount
         BEGIN TRY
              IF @Trancount = 0 BEGIN TRAN;
/*=====================================================================================================================
            Set up Data for Test
 ======================================================================================================================*/
 	
	----Batch1 set up and process

	     INSERT [Inbound].[Transaction] 
	     ( [Scenario], [Account], [DataSet], [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate], [ExpiryDate], [BindDate], [DueDate], [TrifocusCode], [Entity], [YOA], [TypeOfBusiness], [SettlementCCY], [OriginalCCY], [IsToDate], [Value], [RowHash], [AuditSourceBatchID], [AuditCreateDateTime], [AuditGenerateDateTime], [AuditUserCreate], [AuditHost])
	     VALUES ( 'A', 'P-GW', 'USPremium', CAST('2018-12-11T00:00:00' AS Date), 'Policy12345', 'Policy12345', CAST('2018-01-12T00:00:00' AS Date), CAST('2018-11-18T14:50:08' AS Date), CAST(N'2018-11-08T14:50:08.4133333' AS Date), CAST('2018-11-28T14:50:08' AS Date), 'NOTFC-1', 'NOENTITY-1', '2017', 'N', 'GBP', 'GBP', 'Y', CAST(100.0000 AS Numeric(19, 4)), 0x6E0C3EDA4032BA31A6,'-1', CAST('2019-06-06T13:50:08' AS Date), CAST('2019-06-06T14:50:08' AS Date), N'BFL\bhare', N'UKDVDV456')
	 	  
		  INSERT INTO [Inbound].[BatchQueue]
            ([Pk_Batch],  
             [Status],
			 [RunDescription],
			 [DataSet]
            )
            VALUES
            ( -1, 
             'InBound',
			 'TestTransactionalReversal',
			 'USPremium'
            ); 
	EXECUTE [Inbound].[usp_InboundOutboundWorkflow] ;
	 
	 -----Batch2 set up and process

	     INSERT [Inbound].[Transaction] 
	     ( [Scenario], [Account], [DataSet], [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate], [ExpiryDate], [BindDate], [DueDate], [TrifocusCode], [Entity], [YOA], [TypeOfBusiness], [SettlementCCY], [OriginalCCY], [IsToDate], [Value], [RowHash], [AuditSourceBatchID], [AuditCreateDateTime], [AuditGenerateDateTime], [AuditUserCreate], [AuditHost])
	      VALUES ( 'A', 'P-GW', 'USPremium', CAST('2018-12-11T00:00:00' AS Date), 'Policy12345', 'Policy12345', CAST('2018-01-12T00:00:00' AS Date), CAST('2018-11-18T14:51:01' AS Date), CAST('2018-11-08T14:51:01' AS Date), CAST('2018-11-28T14:51:01' AS Date), 'NOTFC-1', 'NOENTITY-1', '2017', 'N', 'GBP', 'GBP', 'Y', CAST(40.0000 AS Numeric(19, 4)), 0x6E0C3EDA4032BA31A6DE08B8928F4,'-2', CAST('2019-06-07T13:51:01' AS Date), CAST('2019-06-07T14:51:01' AS Date), N'BFL\bhare', N'UKDVDV456')
	     
		 INSERT INTO [Inbound].[BatchQueue]
            ([Pk_Batch],  
             [Status],
			 [RunDescription],
			 [DataSet]
            )
            VALUES
            ( -2, 
             'InBound',
			 'TestTransactionalReversal',
			 'USPremium'
            ); 
		 EXECUTE [Inbound].[usp_InboundOutboundWorkflow] ;
  		
	------Batch3 set up and process

		 INSERT [Inbound].[Transaction] 
		 ( [Scenario], [Account], [DataSet], [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate], [ExpiryDate], [BindDate], [DueDate], [TrifocusCode], [Entity], [YOA], [TypeOfBusiness], [SettlementCCY], [OriginalCCY], [IsToDate], [Value], [RowHash], [AuditSourceBatchID], [AuditCreateDateTime], [AuditGenerateDateTime], [AuditUserCreate], [AuditHost])
		  VALUES ('A', 'P-GW', 'USPremium', CAST('2018-12-11T00:00:00' AS Date), 'Policy12345', 'Policy12345', CAST('2018-01-12T00:00:00' AS Date), CAST('2018-11-18T13:54:43' AS Date), CAST('2018-11-08T13:54:43' AS Date), CAST('2018-11-28T13:54:43' AS Date), 'NOTFC-1', 'NOENTITY-1', '2017', 'N', 'GBP', 'GBP', 'Y', CAST(70.0000 AS Numeric(19, 4)), 0x6E0C3EDA4032BA31A6DE08B892,'-3', CAST('2019-06-08T12:54:43' AS Date), CAST('2019-06-08T13:54:43' AS Date), N'BFL\bhare', N'UKDVDV456')
	
		INSERT INTO [Inbound].[BatchQueue]
            ([Pk_Batch],  
             [Status],
			 [RunDescription],
			 [DataSet]
            )
            VALUES
            ( -3, 
             'InBound',
			 'TestTransactionalReversal',
			 'USPremium'
            ); 
		 EXECUTE [Inbound].[usp_InboundOutboundWorkflow] ;

		 ---- create missing batches and process
		DELETE  FROM [Inbound].[Transaction] WHERE AuditSourceBatchID IN ('-1','-2','-3')

		EXEC [Inbound].[usp_InboundOutboundWorkflow] ;

		 
/*=====================================================================================================================
            Run Test and Roll back dont commit test data to tables
 ======================================================================================================================*/

		 WITH Actual AS (SELECT * FROM [Inbound].[Transaction]  WHERE AuditSourceBatchID IN ('-1','-2','-3')),
			 Expected as (SELECT * FROM [Outbound].[Transaction] WHERE AuditSourceBatchID IN (-1,-2,-3) AND Deltatype='NEW')

			 SELECT  [Scenario], [Account], [DataSet], [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate], [ExpiryDate], [BindDate], [DueDate], 
					[TrifocusCode], [Entity], [YOA], [TypeOfBusiness], [SettlementCCY], [OriginalCCY], [IsToDate], [Value], [RowHash], 
					[AuditSourceBatchID],  [AuditGenerateDateTime]
			FROM Actual
			EXCEPT
			SELECT  [Scenario], [Account], [DataSet], [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate], [ExpiryDate], [BindDate], [DueDate], 
					[TrifocusCode], [Entity], [YOA], [TypeOfBusiness], [SettlementCCY], [OriginalCCY], [IsToDate], [Value], [RowHash], 
					[AuditSourceBatchID], [AuditGenerateDateTime] 
			FROM Expected
		 
			UNION ALL
		 
			SELECT  [Scenario], [Account], [DataSet], [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate], [ExpiryDate], [BindDate], [DueDate], 
					[TrifocusCode], [Entity], [YOA], [TypeOfBusiness], [SettlementCCY], [OriginalCCY], [IsToDate], [Value], [RowHash], 
					[AuditSourceBatchID],  [AuditGenerateDateTime] 
			FROM Expected
			EXCEPT
			SELECT [Scenario], [Account], [DataSet], [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate], [ExpiryDate], [BindDate], [DueDate], 
					[TrifocusCode], [Entity], [YOA], [TypeOfBusiness], [SettlementCCY], [OriginalCCY], [IsToDate], [Value], [RowHash], 
					[AuditSourceBatchID],  [AuditGenerateDateTime]
			FROM Actual;


		 
			SELECT	   
		
			OutboundValue		       =(ISNULL([Value], 0.0000))
			,TestName                  ='Transactional_Reversal'
			,TestResult		           =CASE
										WHEN AuditSourceBatchID='-1' AND [Value]=100 THEN 'Pass'
										WHEN AuditSourceBatchID='-2' AND [Value]=80 THEN 'Pass'
										WHEN AuditSourceBatchID='-3' AND [Value]=30 THEN 'Pass'
										ELSE 'Fail'				
										END
			,AuditSourceBatchID
			,DeltaType

	    FROM  [Outbound].[Transaction] 
		WHERE AuditSourceBatchID IN ('-1','-2','-3') AND Deltatype='NEW'
		ORDER BY AuditSourceBatchID ASC

              ROLLBACK; 
         END TRY
         BEGIN CATCH
               ROLLBACK;
              THROW;
         END CATCH