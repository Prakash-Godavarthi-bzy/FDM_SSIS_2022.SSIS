﻿
CREATE PROC [Test].[usp_InboundOutboundWorkflow_RunAllTest]
AS
   

                EXEC [Test].[usp_InboundOutboundWorkflow_Deltaaddition]
                EXEC [Test].[usp_InboundOutboundWorkflow_DeltaReversal]
                EXEC [Test].[usp_InboundOutboundWorkflow_InboundDeltaDuplicates]