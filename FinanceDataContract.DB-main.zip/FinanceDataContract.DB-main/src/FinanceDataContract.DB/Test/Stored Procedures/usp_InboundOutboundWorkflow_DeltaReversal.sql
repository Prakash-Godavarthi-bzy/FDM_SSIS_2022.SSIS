﻿CREATE PROC  [Test].[usp_InboundOutboundWorkflow_DeltaReversal]
 AS 
        DECLARE @Trancount INT = @@Trancount
        BEGIN TRY
             IF @Trancount = 0 BEGIN TRAN;
/*====================================================================================================================
           Set up Data for Test
 =====================================================================================================================*/

	
	----atch1 set up and process

	    INSERT [Inbound].[Transaction] 
	    ( [Scenario], [Account], [DataSet], [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate], [ExpiryDate], [BindDate], [DueDate], [TrifocusCode], [Entity], [YOA], [TypeOfBusiness], [SettlementCCY], [OriginalCCY], [IsToDate], [Value], [RowHash], [AuditSourceBatchID], [AuditCreateDateTime], [AuditGenerateDateTime], [AuditUserCreate], [AuditHost])
	    VALUES ( 'A', 'P-GW', 'Eurobase', CAST('2018-12-11T00:00:00' AS Date), 'Policy12345', 'Policy12345', CAST('2018-01-12T00:00:00' AS Date), CAST('2018-11-18T14:50:08' AS Date), CAST('2018-11-08T14:50:08' AS Date), CAST('2018-11-28T14:50:08' AS Date), 'DEV', 'NOENTITY', '2017', 'N', 'GPB', 'GPB', 'Y', CAST(100.0000 AS Numeric(19, 4)), 0x6E0C3EDA4032BA31A6,'-1', CAST('2019-06-06T13:50:08' AS Date), CAST('2019-06-06T14:50:08' AS Date), N'BFL\masos', N'BFL\masos')
	 	 
		 INSERT INTO [Inbound].[BatchQueue]
            ([Pk_Batch],  
             [Status],
			 [RunDescription],
			 [DataSet]
            )
            VALUES
            ( -1, 
             'InBound',
			 'TestDeltaReversal',
			 'Eurobase'
            ); 
	    EXECUTE [Inbound].[usp_InboundOutboundWorkflow] ;
	 
	 ----Batch2 set up and process

	    INSERT [Inbound].[Transaction] 
	    ( [Scenario], [Account], [DataSet], [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate], [ExpiryDate], [BindDate], [DueDate], [TrifocusCode], [Entity], [YOA], [TypeOfBusiness], [SettlementCCY], [OriginalCCY], [IsToDate], [Value], [RowHash], [AuditSourceBatchID], [AuditCreateDateTime], [AuditGenerateDateTime], [AuditUserCreate], [AuditHost])
	     VALUES ( 'A', 'P-GW', 'Eurobase', CAST('2018-12-11T00:00:00' AS Date), 'Policy12345', 'Policy12345', CAST('2018-01-12T00:00:00' AS Date), CAST('2018-11-18T14:51:01' AS Date), CAST('2018-11-08T14:51:01' AS Date), CAST('2018-11-28T14:51:01' AS Date), 'DEV', 'NOENTITY', '2017', 'N', 'GPB', 'GPB', 'Y', CAST(40.0000 AS Numeric(19, 4)), 0x6E0C3EDA4032BA31A6DE08B8928F4,'-2', CAST('2019-06-07T13:51:01' AS Date), CAST('2019-06-07T14:51:01' AS Date), N'BFL\masos', N'BFL\masos')
	    
		INSERT INTO [Inbound].[BatchQueue]
            ([Pk_Batch],  
             [Status],
			 [RunDescription],
			 [DataSet]
            )
            VALUES
            ( -2, 
             'InBound',
			 'TestDeltaReversal',
			 'Eurobase'
            );  
		EXECUTE [Inbound].[usp_InboundOutboundWorkflow];
  		
	-----Batch3 set up and process

		INSERT [Inbound].[Transaction] 
		( [Scenario], [Account], [DataSet], [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate], [ExpiryDate], [BindDate], [DueDate], [TrifocusCode], [Entity], [YOA], [TypeOfBusiness], [SettlementCCY], [OriginalCCY], [IsToDate], [Value], [RowHash], [AuditSourceBatchID], [AuditCreateDateTime], [AuditGenerateDateTime], [AuditUserCreate], [AuditHost])
		 VALUES ('A', 'P-GW', 'Eurobase', CAST('2018-12-11T00:00:00' AS Date), 'Policy12345', 'Policy12345', CAST('2018-01-12T00:00:00' AS Date), CAST('2018-11-18T13:54:43' AS Date), CAST('2018-11-08T13:54:43' AS Date), CAST('2018-11-28T13:54:43' AS Date), 'DEV', 'NOENTITY', '2017', 'N', 'GPB', 'GPB', 'Y', CAST(70.0000 AS Numeric(19, 4)), 0x6E0C3EDA4032BA31A6DE08B892,'-3', CAST('2019-06-08T12:54:43' AS Date), CAST('2019-06-08T13:54:43' AS Date), N'BFL\masos', N'BFL\masos')
	
	INSERT INTO [Inbound].[BatchQueue]
            ([Pk_Batch],  
             [Status],
			 [RunDescription],
			 [DataSet]
            )
            VALUES
            ( -3, 
             'InBound',
			 'TestDeltaReversal',
			 'Eurobase'
            ); 
		EXECUTE [Inbound].[usp_InboundOutboundWorkflow] ;

		---- create missing	batches and process
		DELETE  FROM [Inbound].[Transaction] WHERE AuditSourceBatchID IN (-1,-2,-3)

		EXEC [Inbound].[usp_InboundOutboundWorkflow] ;



/*====================================================================================================================
           and Roll back dont commit test data to tables
 =====================================================================================================================*/
		

		
		SELECT	   
		
			OutboundValue		       = (ISNULL([Value], 0.0000))
			,TestName                  ='Delta_Reversal'
			,TestResult		           =CASE
										WHEN AuditSourceBatchID='-1' AND [Value]=100 THEN 'Pass'
										WHEN AuditSourceBatchID='-2' AND [Value]=-60 THEN 'Pass'
										WHEN AuditSourceBatchID='-3' AND [Value]=30 THEN 'Pass'
										
									
									ELSE 'Fail'				
									END
			,AuditSourceBatchID
			,DeltaType

	    FROM  [Outbound].[Transaction] 
		WHERE AuditSourceBatchID IN ('-1','-2','-3') AND Deltatype='NEW'
		ORDER BY AuditSourceBatchID ASC
	

            ROLLBACK; 
        END TRY
        BEGIN CATCH
              ROLLBACK;
             THROW;
        END CATCH