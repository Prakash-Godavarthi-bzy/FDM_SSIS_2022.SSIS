﻿CREATE PROC [Test].[usp_InboundOutboundWorkflow_Deltaaddition]
 AS 
         DECLARE @Trancount INT = @@Trancount
         BEGIN TRY
              IF @Trancount = 0 BEGIN TRAN;
/*=====================================================================================================================
            Set up Data for Test
 ======================================================================================================================*/
 	
	----Batch1 set up and process

	     INSERT [Inbound].[Transaction] 
	     ( [Scenario], [Account], [DataSet], [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate], [ExpiryDate], [BindDate], [DueDate], [TrifocusCode], [Entity], [YOA], [TypeOfBusiness], [SettlementCCY], [OriginalCCY], [IsToDate], [Value], [RowHash], [AuditSourceBatchID], [AuditCreateDateTime], [AuditGenerateDateTime], [AuditUserCreate], [AuditHost])
	     VALUES ( 'A', 'P-GW', 'Eurobase', CAST('2018-12-11T00:00:00' AS Date), 'Policy12345', 'Policy12345', CAST('2018-01-12T00:00:00' AS Date), CAST('2018-11-18T14:50:08' AS Date), CAST('2018-11-08T14:50:08' AS Date), CAST('2018-11-28T14:50:08' AS Date), 'DEV', 'NOENTITY', '2017', 'N', 'GPB', 'GPB', 'Y', CAST(100.0000 AS Numeric(19, 4)), 0x6E0C3EDA4032BA31A6,'-1', CAST('2019-06-06T13:50:08' AS Date), CAST('2019-06-06T14:50:08' AS Date), N'BFL\masos', N'BFL\masos')
	 	  
		  INSERT INTO [Inbound].[BatchQueue]
            ([Pk_Batch],  
             [Status],
			 [RunDescription],
			 [DataSet]
            )
            VALUES
            ( -1, 
             'InBound',
			 'TestDeltaAddition',
			 'Eurobase'
            ); 
	EXECUTE [Inbound].[usp_InboundOutboundWorkflow] ;
	 
	 -----Batch2 set up and process

	     INSERT [Inbound].[Transaction] 
	     ( [Scenario], [Account], [DataSet], [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate], [ExpiryDate], [BindDate], [DueDate], [TrifocusCode], [Entity], [YOA], [TypeOfBusiness], [SettlementCCY], [OriginalCCY], [IsToDate], [Value], [RowHash], [AuditSourceBatchID], [AuditCreateDateTime], [AuditGenerateDateTime], [AuditUserCreate], [AuditHost])
	      VALUES ( 'A', 'P-GW', 'Eurobase', CAST('2018-12-11T00:00:00' AS Date), 'Policy12345', 'Policy12345', CAST('2018-01-12T00:00:00' AS Date), CAST('2018-11-18T14:51:01' AS Date), CAST('2018-11-08T14:51:01' AS Date), CAST('2018-11-28T14:51:01' AS Date), 'DEV', 'NOENTITY', '2017', 'N', 'GPB', 'GPB', 'Y', CAST(40.0000 AS Numeric(19, 4)), 0x6E0C3EDA4032BA31A6DE08B8928F4,'-2', CAST('2019-06-07T13:51:01' AS Date), CAST('2019-06-07T14:51:01' AS Date), N'BFL\masos', N'BFL\masos')
	     
		 INSERT INTO [Inbound].[BatchQueue]
            ([Pk_Batch],  
             [Status],
			 [RunDescription],
			 [DataSet]
            )
            VALUES
            ( -2, 
             'InBound',
			 'TestDeltaAddition',
			 'Eurobase'
            ); 
		 EXECUTE [Inbound].[usp_InboundOutboundWorkflow] ;
  		
	------Batch3 set up and process

		 INSERT [Inbound].[Transaction] 
		 ( [Scenario], [Account], [DataSet], [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate], [ExpiryDate], [BindDate], [DueDate], [TrifocusCode], [Entity], [YOA], [TypeOfBusiness], [SettlementCCY], [OriginalCCY], [IsToDate], [Value], [RowHash], [AuditSourceBatchID], [AuditCreateDateTime], [AuditGenerateDateTime], [AuditUserCreate], [AuditHost])
		  VALUES ('A', 'P-GW', 'Eurobase', CAST('2018-12-11T00:00:00' AS Date), 'Policy12345', 'Policy12345', CAST('2018-01-12T00:00:00' AS Date), CAST('2018-11-18T13:54:43' AS Date), CAST('2018-11-08T13:54:43' AS Date), CAST('2018-11-28T13:54:43' AS Date), 'DEV', 'NOENTITY', '2017', 'N', 'GPB', 'GPB', 'Y', CAST(70.0000 AS Numeric(19, 4)), 0x6E0C3EDA4032BA31A6DE08B892,'-3', CAST('2019-06-08T12:54:43' AS Date), CAST('2019-06-08T13:54:43' AS Date), N'BFL\masos', N'BFL\masos')
	
	INSERT INTO [Inbound].[BatchQueue]
            ([Pk_Batch],  
             [Status],
			 [RunDescription],
			 [DataSet]
            )
            VALUES
            ( -3, 
             'InBound',
			 'TestDeltaAddition',
			 'Eurobase'
            ); 
		 EXECUTE [Inbound].[usp_InboundOutboundWorkflow] ;

		 
/*=====================================================================================================================
            Run Test and Roll back dont commit test data to tables
 ======================================================================================================================*/
         
		 
		  DROP TABLE IF EXISTS #temp_Inbound
	 CREATE TABLE #temp_Inbound(
	[Scenario] [varchar](2) COLLATE DATABASE_DEFAULT NOT NULL,
	[Account] [varchar](10) COLLATE DATABASE_DEFAULT NOT NULL,
	[DataSet] [nvarchar] (255) COLLATE DATABASE_DEFAULT NOT NULL,
	[DateOfFact] [datetime] NOT NULL,
	[BusinessKey] [varchar](255) COLLATE DATABASE_DEFAULT NOT NULL,
	[PolicyNumber] [varchar](255) COLLATE DATABASE_DEFAULT NOT NULL,
	[InceptionDate] [datetime]  NOT NULL,
	[ExpiryDate] [datetime] NOT NULL,
	[BindDate] [datetime] NOT NULL,
	[DueDate] [datetime] NOT NULL,
	[TrifocusCode] [varchar](25) COLLATE DATABASE_DEFAULT NOT NULL,
	[Entity] [varchar](10) COLLATE DATABASE_DEFAULT NOT NULL,
	[YOA] [varchar](5) COLLATE DATABASE_DEFAULT NOT NULL,
	[TypeOfBusiness] [varchar](1) COLLATE DATABASE_DEFAULT NOT NULL,
	[SettlementCCY] [varchar](3) COLLATE DATABASE_DEFAULT NOT NULL,
	[OriginalCCY] [varchar](3) COLLATE DATABASE_DEFAULT NOT NULL,
	[IsToDate] [varchar](1) COLLATE DATABASE_DEFAULT NOT NULL,
	[Value] [numeric](19, 4)  NOT NULL,
	[RowHash] [varbinary](8000)   NULL,
	[AuditSourceBatchID] [varchar](255), --COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditGenerateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) COLLATE DATABASE_DEFAULT NOT NULL,
	[AuditHost] [nvarchar](255)COLLATE DATABASE_DEFAULT NOT NULL
)
	 INSERT #temp_Inbound 
	     ( [Scenario], [Account], [DataSet], [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate], [ExpiryDate], 
		 [BindDate], [DueDate], [TrifocusCode], [Entity], [YOA], [TypeOfBusiness], [SettlementCCY], [OriginalCCY], [IsToDate],
		  [Value], [RowHash], [AuditSourceBatchID], [AuditCreateDateTime], [AuditGenerateDateTime], [AuditUserCreate], [AuditHost])
		 VALUES
		 ( 'A', 'P-GW', 'Eurobase', CAST('2018-12-11T00:00:00' AS Date), 'Policy12345', 'Policy12345', CAST('2018-01-12T00:00:00' AS Date), CAST('2018-11-18T14:50:08' AS Date), CAST('2018-11-08T14:50:08' AS Date), CAST('2018-11-28T14:50:08' AS Date), 'DEV','NOENTITY', '2017', 'N', 'GPB', 'GPB', 'Y', CAST(100.0000 AS Numeric(19, 4)), 0x6E0C3EDA4032BA31A6,'-1', CAST('2019-06-06T13:50:08' AS Date), CAST('2019-06-06T14:50:08' AS Date), N'BFL\masos', N'BFL\masos')
	 	,( 'A', 'P-GW', 'Eurobase', CAST('2018-12-11T00:00:00' AS Date), 'Policy12345', 'Policy12345', CAST('2018-01-12T00:00:00' AS Date), CAST('2018-11-18T14:51:01' AS Date), CAST('2018-11-08T14:51:01' AS Date), CAST('2018-11-28T14:51:01' AS Date), 'DEV','NOENTITY', '2017', 'N', 'GPB', 'GPB', 'Y', CAST(40.0000 AS Numeric(19, 4)), 0x6E0C3EDA4032BA31A6DE08B8928F4,'-2', CAST('2019-06-07T13:51:01' AS Date), CAST('2019-06-07T14:51:01' AS Date), N'BFL\masos', N'BFL\masos')
		,('A', 'P-GW', 'Eurobase', CAST('2018-12-11T00:00:00' AS Date), 'Policy12345', 'Policy12345', CAST('2018-01-12T00:00:00' AS Date), CAST('2018-11-18T13:54:43' AS Date), CAST('2018-11-08T13:54:43' AS Date), CAST('2018-11-28T13:54:43' AS Date), 'DEV','NOENTITY', '2017', 'N', 'GPB', 'GPB', 'Y', CAST(70.0000 AS Numeric(19, 4)), 0x6E0C3EDA4032BA31A6DE08B892,'-3', CAST('2019-06-08T12:54:43' AS Date), CAST('2019-06-08T13:54:43' AS Date), N'BFL\masos', N'BFL\masos')
	
		 
		 SELECT	   
	             InboundValue		      =(ISNULL(Inbound.Value, 0.0000))
	            ,OutboundValue		      =(ISNULL(Outbound.Value, 0.0000))
	            ,TestName                 = 'Deltaaddition'
	            ,TestResult		          = CASE
	            							WHEN Inbound.AuditSourceBatchID='-1' AND Outbound.[Value]=100 THEN 'Pass'
	            							WHEN Inbound.AuditSourceBatchID='-2' AND Outbound.[Value]=-60 THEN 'Pass'
	            							WHEN Inbound.AuditSourceBatchID='-3' AND Outbound.[Value]=30 THEN 'Pass'
	            							ELSE 'Fail'				
	            						    END
	            ,Inbound.AuditSourceBatchID
				,DeltaType
	      
         FROM #temp_Inbound AS Inbound 
         JOIN [Outbound].[Transaction] AS Outbound  ON Inbound.RowHash = Outbound.RowHash 
         AND Inbound.AuditSourceBatchID=Outbound.AuditSourceBatchID 
		 WHERE Outbound.AuditSourceBatchID IN ('-1','-2','-3') AND Inbound.AuditSourceBatchID IN ('-1','-2','-3') AND Outbound.DeltaType='NEW'
		 ORDER BY AuditSourceBatchID ASC
              ROLLBACK; 
         END TRY
         BEGIN CATCH
               ROLLBACK;
              THROW;
         END CATCH