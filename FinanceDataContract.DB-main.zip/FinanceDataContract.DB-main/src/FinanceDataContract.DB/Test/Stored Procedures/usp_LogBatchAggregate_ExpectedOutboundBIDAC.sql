﻿CREATE	PROCEDURE [Test].[usp_LogBatchAggregate_ExpectedOutboundBIDAC] @batchid AS	BatchID READONLY
AS
	--     /* 
	--        ========================================================================================================= 
	--          Insert expected outbound value into logging table, insert statment has been used to logg row per b atchID  
	--    ========================================================================================================= 
	--*/ 

	IF EXISTS (SELECT ActivityJobId FROM [Orchestram].[Log].[ActivityLog] a WHERE a.ActivityName = 'BIDACTechnicalHubActual.test.usp_LogBatchAggregate')
	BEGIN
		INSERT	INTO [Orchestram].[Log].[ActivityLog](FK_ParentActivityLog, FK_ActivityLogTag, FK_ActivitySource, FK_ActivityType, FK_ActivityStatus
													,ActivityHost, ActivityDatabase, ActivityJobId, ActivitySSISExecutionId, ActivityName, ActivityDateTime
													,ActivityMessage)
		SELECT	NULL
				,NULL
				,2 --DataContract
				,3 --DataQuality
				,5 --Information
				,@@servername
				,'DataContract'
				,a.ActivityJobId
				,NULL
				,'BIDACOutboundExpected.test.usp_LogBatchAggregateBIDAC'
				,GETDATE()
				,a.activitymessage
		FROM	(
					SELECT	ActivityJobId
							,valuecurrnt	= CAST(ActivityMessage AS NUMERIC(19, 4))
							,previousvalue	= ISNULL(CAST(LAG(ActivityMessage, 1, 0) OVER (ORDER BY CAST(ActivityJobID AS INT)) AS NUMERIC(19, 4)), 0)
							,activitymessage = CAST(ActivityMessage AS NUMERIC(19, 4))
												- ISNULL(CAST(LAG(ActivityMessage, 1, 0) OVER (ORDER BY CAST(ActivityJobID AS INT)) AS NUMERIC(19, 4)), 0)
					FROM	[Orchestram].[Log].[ActivityLog] a
					WHERE	a.ActivityName = 'Inbound.test.usp_LogBatchAggregateBIDAC'
						AND ActivityJobId IS NOT NULL
						AND CAST(ActivityJobId AS INT) >= (
															SELECT		ISNULL(MAX(CAST(ActivityJobId AS INT)), 0)
																FROM	[Orchestram].[Log].[ActivityLog]
															WHERE		ActivityName = 'BIDACTechnicalHubActual.test.usp_LogBatchAggregate'
														)
				)			a
		JOIN	@batchid	b ON a.ActivityJobId = CAST(b.PK_BatchID AS NVARCHAR(50))
							AND b.DataSet = 'BIDAC';
	END;
	/*        ========================================================================================================= 
         First Run
        ========================================================================================================= 
    */
	ELSE
	BEGIN
		INSERT	INTO [Orchestram].[Log].[ActivityLog](FK_ParentActivityLog, FK_ActivityLogTag, FK_ActivitySource, FK_ActivityType, FK_ActivityStatus
													,ActivityHost, ActivityDatabase, ActivityJobId, ActivitySSISExecutionId, ActivityName, ActivityDateTime
													,ActivityMessage)
		SELECT	NULL
				,NULL
				,2 --DataContract
				,3 --DataQuality
				,5 --Information
				,@@servername
				,'DataContract'
				,a.ActivityJobId
				,NULL
				,'BIDACOutboundExpected.test.usp_LogBatchAggregateBIDAC'
				,GETDATE()
				,a.activitymessage
		FROM	(
					SELECT	ActivityJobId
							,activitymessage = CAST(ActivityMessage AS NUMERIC(19, 4))
												- ISNULL(CAST(LAG(ActivityMessage, 1, 0) OVER (ORDER BY CAST(ActivityJobID AS INT)) AS NUMERIC(19, 4)), 0)
					FROM	[Orchestram].[Log].[ActivityLog]	lal
					JOIN	Inbound.BatchQueue					ibq ON ibq.Pk_Batch = lal.ActivityJobId
					WHERE	1 = 1
						AND ibq.Status <> 'OutboundFailed'
						AND ActivityName = 'Inbound.test.usp_LogBatchAggregateBIDAC'
				)			a
		JOIN	@batchid	b ON a.ActivityJobId = CAST(b.PK_BatchID AS NVARCHAR(50));
	END;