﻿CREATE PROC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHubUSBAIC]
			@BatchID AS BATCHID READONLY
AS
     --     /*
     --        =========================================================================================================
     --						Set logging parameters for THub Expected USBAIC value test
     --		=========================================================================================================
     --*/

     INSERT INTO [Orchestram].[Log].[ActivityLog]
     (FK_ParentActivityLog, 
      FK_ActivityLogTag, 
      FK_ActivitySource, 
      FK_ActivityType, 
      FK_ActivityStatus, 
      ActivityHost, 
      ActivityDatabase, 
      ActivityJobId, 
      ActivitySSISExecutionId, 
      ActivityName, 
      ActivityDateTime, 
      ActivityMessage
     )
            SELECT NULL, 
                   NULL, 
                   2, --DataContract
                   3, --DataQuality
                   5, --Information
                   @@SERVERNAME, 
                   'DataContract', 
                   A.BatchID, 
                   NULL, 
                   'BAICTechnicalHubExpected.test.usp_LogBatchAggregate', 
                   GETDATE(), 
                   a.activitymessage
            FROM
            (
                SELECT SUM(ISNULL([value],0)) AS activitymessage, 
                       [AuditSourceBatchID] AS BatchID
                FROM [Outbound].[Transaction] O
                     INNER JOIN @BatchID B ON CAST(o.AuditSourceBatchID AS INT) = B.PK_BatchID
                WHERE o.[DataSet] = B.DataSet
				AND o.[DataSet] = 'USBAIC' AND CAST(O.YOA AS VARCHAR(20))>'1992'
				GROUP BY [AuditSourceBatchID]
            ) a
            JOIN @BatchID B ON A.BatchID = CAST(B.PK_BatchID AS NVARCHAR(50));
