﻿CREATE PROC [Test].[usp_LogBatchAggregate_Inbound] @BatchId INT
AS
/*
        =========================================================================================================
						Set logging parameters for inbound value test
		=========================================================================================================
*/

     DECLARE
     @v_ActivityStatus_GP SMALLINT= 5, --1 started 2 succeded 3 stopped 4 errored 5 information 
     @v_ActivityName_GP VARCHAR(100)= 'EBInbound.test.usp_LogBatchAggregate_Gross', @v_JobID INT= @BatchID, @v_ActivityMessage_GP NVARCHAR(4000)=
     (
         SELECT ISNULL(SUM([value]),0) AS 'TotalValue'
         FROM FinanceDataContract.Inbound.[Transaction]
         WHERE AuditSourceBatchID = @BatchId 
               AND DataSet = 'Eurobase'
			   AND Account IN ('P-GP-P','P-GP-B')
         GROUP BY [AuditSourceBatchID]
     );


/*
		=========================================================================================================
						Log eurobase total value in Landing for testing inbound datacontract value
		=========================================================================================================
*/

     EXEC [dbo].[usp_LogDataContract] 
         
          @v_ActivityMessage_GP, 
          @v_ActivityStatus_GP, 
          @v_ActivityName_GP, 
          NULL, 
          @v_JobID;

/*
		=========================================================================================================
						IF Landingvalue not equal to Inbound raise error
		=========================================================================================================
*/

     IF  EXISTS
     (
         SELECT L.ActivityMessage, 
                I.ActivityMessage
		 FROM Orchestram.[Log].ActivityLog L
              JOIN Orchestram.[Log].ActivityLog I ON L.ActivityJobId = I.ActivityJobId
         WHERE L.ActivityJobId = @BatchId
               AND L.ActivityName = 'EbLanding.test.usp_LogBatchAggregate_Gross'
               AND I.ActivityName = 'EBInbound.test.usp_LogBatchAggregate_Gross'
               AND L.ActivityMessage <> I.ActivityMessage
     )
         BEGIN
             RAISERROR('Inbound value for Gross is not matching to landing value for BatchID: %i',16,1,@BatchId);
     END;

/*
=========================================================================================================================
                      GET THE VALUE FOR ACCOUNTS P-AC-P,P-AC-B,P-LB-P,P-LB-B
=========================================================================================================================
*/

 DECLARE
     @v_ActivityStatus_AC SMALLINT= 5, --1 started 2 succeded 3 stopped 4 errored 5 information 
     @v_ActivityName_AC VARCHAR(100)= 'EBInbound.test.usp_LogBatchAggregate_AcquitionsCos', @v_ActivityMessage_AC NVARCHAR(4000)=
     (
         SELECT SUM([value]) AS 'TotalValue'
         FROM FinanceDataContract.Inbound.[Transaction]
         WHERE AuditSourceBatchID = @BatchId 
               AND DataSet = 'Eurobase'
			   AND Account IN ('P-AC-P','P-AC-B','P-LB-P','P-LB-B')
         GROUP BY [AuditSourceBatchID]
     );

	 /*
		=========================================================================================================
						Log eurobase total value in Landing for testing inbound datacontract value
		=========================================================================================================
*/

     EXEC [dbo].[usp_LogDataContract] 
         
          @v_ActivityMessage_ac, 
          @v_ActivityStatus_AC, 
          @v_ActivityName_AC, 
          NULL, 
          @v_JobID;

/*
		=========================================================================================================
						IF Landingvalue not equal to Inbound raise error
		=========================================================================================================
*/

  DECLARE @DIFF NUMERIC(19,4)
        
		 SELECT @DIFF=abs(CAST(L.ActivityMessage AS numeric) - CAST(I.ActivityMessage AS numeric))
		 FROM Orchestram.[Log].ActivityLog L
              JOIN Orchestram.[Log].ActivityLog I ON L.ActivityJobId = I.ActivityJobId
         WHERE L.ActivityJobId = @BatchId
               AND L.ActivityName = 'EbLanding.test.usp_LogBatchAggregate_AcquitionsCos'
               AND I.ActivityName = 'EBInbound.test.usp_LogBatchAggregate_AcquitionsCos'
   
   IF  (@DIFF  NOT BETWEEN 0 AND 10)           
         BEGIN
             RAISERROR('Inbound value for AcquitionsCost  is not matching to landing value for BatchID: %i',16,1,@BatchId);
		 END;

/*
        =========================================================================================================
						Set logging parameters for inbound value test
		=========================================================================================================
*/

     DECLARE
     @v_ActivityStatus SMALLINT= 5, --1 started 2 succeded 3 stopped 4 errored 5 information 
     @v_ActivityName VARCHAR(100)= 'EBInbound.test.usp_LogBatchAggregate', @v_ActivityMessage NVARCHAR(4000)=
     (
         SELECT SUM([value]) AS 'TotalValue'
         FROM FinanceDataContract.Inbound.[Transaction]
         WHERE AuditSourceBatchID = @BatchId 
               AND DataSet = 'Eurobase'
         GROUP BY [AuditSourceBatchID]
     );


/*
		=========================================================================================================
						Log eurobase total value in Landing for testing inbound datacontract value
		=========================================================================================================
*/

     EXEC [dbo].[usp_LogDataContract] 
         
          @v_ActivityMessage, 
          @v_ActivityStatus, 
          @v_ActivityName, 
          NULL, 
          @v_JobID;
