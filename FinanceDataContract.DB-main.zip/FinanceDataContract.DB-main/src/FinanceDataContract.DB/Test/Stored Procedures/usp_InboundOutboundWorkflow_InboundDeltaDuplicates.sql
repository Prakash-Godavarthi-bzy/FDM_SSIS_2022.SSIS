﻿CREATE PROC [Test].[usp_InboundOutboundWorkflow_InboundDeltaDuplicates]

 AS 
       DECLARE @Trancount INT = @@Trancount
       BEGIN TRY
            IF @Trancount = 0 
	   BEGIN TRAN;
/*===================================================================================================================
          Set up Data for Test
 ====================================================================================================================*/

	
	--create duplicates batches in inbound and process
	  
        INSERT [Inbound].[Transaction] 
        ( [Scenario], [Account], [DataSet], [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate], [ExpiryDate], [BindDate], [DueDate], [TrifocusCode], [Entity], [YOA], [TypeOfBusiness], [SettlementCCY], [OriginalCCY], [IsToDate], [Value], [RowHash], [AuditSourceBatchID], [AuditCreateDateTime], [AuditGenerateDateTime], [AuditUserCreate], [AuditHost])
        VALUES ( 'A', 'P-GW', 'Eurobase', CAST('2018-12-11T00:00:00' AS Date), 'Policy12345', 'Policy12345', CAST('2018-01-12T00:00:00' AS Date), CAST('2018-11-18T14:50:08' AS Date), CAST('2018-11-08T14:50:08' AS Date), CAST('2018-11-28T14:50:08' AS Date), 'DEV', 'NOENTITY', '2017', 'N', 'GPB', 'GPB', 'Y', CAST(50.0000 AS Numeric(19, 4)), 0x6E0C3EDA4032BA31A6,'-1', CAST('2019-06-06T13:50:08' AS Date), CAST('2019-06-06T14:50:08' AS Date), N'BFL\masos', N'BFL\masos'),
               ( 'A', 'P-GW', 'Eurobase', CAST('2018-12-11T00:00:00' AS Date), 'Policy12345', 'Policy12345', CAST('2018-01-12T00:00:00' AS Date), CAST('2018-11-18T14:50:08' AS Date), CAST('2018-11-08T14:50:08' AS Date), CAST('2018-11-28T14:50:08' AS Date), 'DEV', 'NOENTITY', '2017', 'N', 'GPB', 'GPB', 'Y', CAST(50.0000 AS Numeric(19, 4)), 0x6E0C3EDA4032BA31A6,'-1', CAST('2019-06-06T13:50:08' AS Date), CAST('2019-06-06T14:50:08' AS Date), N'BFL\masos', N'BFL\masos')
        

		INSERT INTO [Inbound].[BatchQueue]
            ([Pk_Batch],  
             [Status],
			 [RunDescription],
			 [DataSet]
            )
            VALUES
            ( -1, 
             'InBound',
			 'TestDeltaDuplicates ',
			 'Eurobase'
            ); 
        EXECUTE [Inbound].[usp_InboundOutboundWorkflow] ;



/*=====================================================================================================================
            Run Test and Roll back dont commit test data to tables
 ======================================================================================================================*/

     IF EXISTS (SELECT Rowhash,COUNT(*) FROM FinanceDataContract.[Outbound].[Transaction]
				WHERE AuditSourceBatchID='-1'
				GROUP BY RowHash
				HAVING COUNT(*)>1)

     BEGIN
         SELECT 'Fail There are duplicate rowhashes '+AuditSourceBatchID+' in inbound Table' AS TestResults
         FROM [Outbound].[Transaction] WHERE AuditSourceBatchID='-1' GROUP BY AuditSourceBatchID HAVING COUNT(RowHash)>1
     END 

     ELSE 
     BEGIN
         SELECT	 OutboundValue	      =(ISNULL([Value], 0.0000))
            ,TestName             ='DuplicatesHashrow'
     		,TestResult		      = CASE
     							    WHEN AuditSourceBatchID='-1' AND [Value]=100 THEN 'Pass'
     						        ELSE 'Fail'				
     								END
     		,AuditSourceBatchID
     
         FROM  [Outbound].[Transaction]
		 WHERE AuditSourceBatchID='-1'  AND DeltaType='NEW'
     END
           ROLLBACK; 
     END TRY
     BEGIN CATCH
          ROLLBACK;
               THROW;
     END CATCH