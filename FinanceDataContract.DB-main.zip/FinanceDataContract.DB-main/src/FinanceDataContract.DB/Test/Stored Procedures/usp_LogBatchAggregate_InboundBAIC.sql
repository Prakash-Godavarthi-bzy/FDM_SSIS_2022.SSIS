﻿CREATE PROC [Test].[usp_LogBatchAggregate_InboundBAIC] @BatchId INT
AS

/*
        =========================================================================================================
						Set logging parameters for inbound value test
		=========================================================================================================
*/

     DECLARE
     @v_ActivityStatus SMALLINT= 5, --1 started 2 succeded 3 stopped 4 errored 5 information 
     @v_ActivityName VARCHAR(50)= 'Inbound.test.usp_LogBatchAggregateBAIC', @v_JobID INT= @BatchID, @v_ActivityMessage NVARCHAR(4000)=
     (
		 SELECT SUM(ISNULL([VALUE],0)) 
		 FROM [Inbound].[Transaction]
		 WHERE AuditSourceBatchID = @BatchId
               AND [DataSet] = 'USBAIC'
         GROUP BY [AuditSourceBatchID]
     );

/*
		=========================================================================================================
						Log FDM total value in Landing for testing inbound datacontract value
		=========================================================================================================
*/

     EXEC [dbo].[usp_LogDataContract] 
         
          @v_ActivityMessage, 
          @v_ActivityStatus, 
          @v_ActivityName, 
          NULL, 
          @v_JobID;

/*
		=========================================================================================================
						IF FDMLandingvalue not equal to FDMInboundvalue raise error
		=========================================================================================================
*/	 DECLARE @DupIBValue NUMERIC(16,4)=(SELECT ActivityMessage 
									  FROM Orchestram.[Log].ActivityLog 
									  WHERE ActivityName = 'Inbound.test.usp_LogBatchAggregateBAIC' 
									  AND ActivityJobId = @BatchId );
	DECLARE		 @LandingValue NUMERIC(16,4)=(SELECT ActivityMessage 
									  FROM Orchestram.[Log].ActivityLog 
									  WHERE ActivityName = 'Landing.test.usp_LogBatchAggregate_BAIC' 
									  AND ActivityJobId = @BatchId);

		 IF ( ROUND(@LandingValue,00) <> ROUND(@DupIBValue,00))

         BEGIN
             RAISERROR('BAICInbound value is not matching to BAICLanding value for BatchID: %i',16,1,@BatchId);
     END;
