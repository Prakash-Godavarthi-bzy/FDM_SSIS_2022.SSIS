﻿CREATE PROC [Test].[usp_LogBatchAggregate_ExpectedTechnicalHubPFT]
			@BatchID AS BATCHID READONLY
AS
     --     /*
     --        =========================================================================================================
     --						Set logging parameters for InboundPFT value test
     --		=========================================================================================================
     --*/

     INSERT INTO [Orchestram].[Log].[ActivityLog]
     (FK_ParentActivityLog, 
      FK_ActivityLogTag, 
      FK_ActivitySource, 
      FK_ActivityType, 
      FK_ActivityStatus, 
      ActivityHost, 
      ActivityDatabase, 
      ActivityJobId, 
      ActivitySSISExecutionId, 
      ActivityName, 
      ActivityDateTime, 
      ActivityMessage
     )
            SELECT NULL, 
                   NULL, 
                   2, --DataContract
                   3, --DataQuality
                   5, --Information
                   @@SERVERNAME, 
                   'DataContract', 
                   A.BatchID, 
                   NULL, 
                   'PFTTechnicalHubExpected.test.usp_LogBatchAggregate', 
                   GETDATE(), 
                   a.activitymessage
            FROM
            (
                SELECT SUM([value]) AS activitymessage, 
                       [AuditSourceBatchID] AS BatchID
                FROM FinanceDataContract.[Outbound].[Transaction] O
                     INNER JOIN @BatchID B ON CAST(o.AuditSourceBatchID AS INT) = B.PK_BatchID
                WHERE o.[DataSet] = B.DataSet
				AND o.[DataSet] = 'PFT' AND CAST(O.YOA AS VARCHAR(20))>'1992'
				GROUP BY [AuditSourceBatchID]
            ) a
            JOIN @BatchID B ON A.BatchID = CAST(B.PK_BatchID AS NVARCHAR(50));