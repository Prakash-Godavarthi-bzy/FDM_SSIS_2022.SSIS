﻿CREATE PROC [Test].[usp_InboundOutboundWorkflow_InboundTransactionalDuplicates]

 AS 
       DECLARE @Trancount INT = @@Trancount
       BEGIN TRY
            IF @Trancount = 0 
	   BEGIN TRAN;
/*===================================================================================================================
          Set up Data for Test
 ====================================================================================================================*/

	
	--create duplicates batches in inbound and process
	  
        INSERT [Inbound].[Transaction] 
        ( [Scenario], [Account], [DataSet], [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate], [ExpiryDate], [BindDate], [DueDate], [TrifocusCode], [Entity], [YOA], [TypeOfBusiness], [SettlementCCY], [OriginalCCY], [IsToDate], [Value], [RowHash], [AuditSourceBatchID], [AuditCreateDateTime], [AuditGenerateDateTime], [AuditUserCreate], [AuditHost])
        VALUES ( 'A', 'P-GW', 'USPremium', CAST('2018-12-11T00:00:00' AS Date), 'Policy12345', 'Policy12345', CAST('2018-01-12T00:00:00' AS Date), CAST('2018-11-18T14:50:08' AS Date), CAST('2018-11-08T14:50:08' AS Date), CAST('2018-11-28T14:50:08' AS Date), 'NOTFC', 'NOENTITY', '2017', 'N', 'GBP', 'GBP', 'Y', CAST(50.0000 AS Numeric(19, 4)), 0x6E0C3EDA4032BA31A6,'-1', CAST('2019-06-06T13:50:08' AS Date), CAST('2019-06-06T14:50:08' AS Date), N'BFL\bhare', N'UKDVDV456'),
               ( 'A', 'P-GW', 'USPremium', CAST('2018-12-11T00:00:00' AS Date), 'Policy12345', 'Policy12345', CAST('2018-01-12T00:00:00' AS Date), CAST('2018-11-18T14:50:08' AS Date), CAST('2018-11-08T14:50:08' AS Date), CAST('2018-11-28T14:50:08' AS Date), 'NOTFC', 'NOENTITY', '2017', 'N', 'GBP', 'GBP', 'Y', CAST(50.0000 AS Numeric(19, 4)), 0x6E0C3EDA4032BA31A6,'-1', CAST('2019-06-06T13:50:08' AS Date), CAST('2019-06-06T14:50:08' AS Date), N'BFL\bhare', N'UKDVDV456')
        
	--	Create new batchque

		INSERT INTO [Inbound].[BatchQueue]
            ([Pk_Batch],  
             [Status],
			 [RunDescription],
			 [DataSet]
            )
            VALUES
            ( -1, 
             'InBound',
			 'TestTransactionalDuplicates ',
			 'USPremium'
            );
	   EXECUTE [Inbound].[usp_InboundOutboundWorkflow] ;



/*=====================================================================================================================
            Run Test and Roll back dont commit test data to tables
 ======================================================================================================================*/

		----CTE To check the duplicate data in Inbound.Transaction(Resultset-1)
DROP TABLE IF EXISTS #temp_Inbound
	 CREATE TABLE #temp_Inbound(
	[Scenario] [varchar](2) COLLATE DATABASE_DEFAULT NOT NULL,
	[Account] [varchar](10) COLLATE DATABASE_DEFAULT NOT NULL,
	DataSet [varchar] (255) COLLATE DATABASE_DEFAULT NOT NULL,
	[DateOfFact] [datetime] NOT NULL,
	[BusinessKey] [varchar](255) COLLATE DATABASE_DEFAULT NOT NULL,
	[PolicyNumber] [varchar](255) COLLATE DATABASE_DEFAULT NOT NULL,
	[InceptionDate] [datetime]  NOT NULL,
	[ExpiryDate] [datetime] NOT NULL,
	[BindDate] [datetime] NOT NULL,
	[DueDate] [datetime] NOT NULL,
	[TrifocusCode] [varchar](25) COLLATE DATABASE_DEFAULT NOT NULL,
	[Entity] [varchar](10) COLLATE DATABASE_DEFAULT NOT NULL,
	[YOA] [varchar](5) COLLATE DATABASE_DEFAULT NOT NULL,
	[TypeOfBusiness] [varchar](1) COLLATE DATABASE_DEFAULT NOT NULL,
	[SettlementCCY] [varchar](3) COLLATE DATABASE_DEFAULT NOT NULL,
	[OriginalCCY] [varchar](3)COLLATE DATABASE_DEFAULT NOT NULL,
	[IsToDate] [varchar](1)COLLATE DATABASE_DEFAULT NOT NULL,
	[Value] [numeric](19, 4)  NOT NULL,
	[RowHash] [varbinary](8000)   NULL,
	[AuditSourceBatchID] [varchar](255) ,--COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditGenerateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [nvarchar](255) COLLATE DATABASE_DEFAULT NOT NULL,
	[AuditHost] [nvarchar](255)COLLATE DATABASE_DEFAULT NOT NULL
)
	 INSERT #temp_Inbound
	     ( [Scenario], [Account], DataSet, [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate], [ExpiryDate], 
		 [BindDate], [DueDate], [TrifocusCode], [Entity], [YOA], [TypeOfBusiness], [SettlementCCY], [OriginalCCY], [IsToDate],
		  [Value], [RowHash], [AuditSourceBatchID], [AuditCreateDateTime], [AuditGenerateDateTime], [AuditUserCreate], [AuditHost])
		  VALUES ( 'A', 'P-GW', 'USPremium', CAST('2018-12-11T00:00:00' AS Date), 'Policy12345', 'Policy12345', CAST('2018-01-12T00:00:00' AS Date), CAST('2018-11-18T14:50:08' AS Date), CAST('2018-11-08T14:50:08' AS Date), CAST('2018-11-28T14:50:08' AS Date), 'NOTFC', 'NOENTITY', '2017', 'N', 'GBP', 'GBP', 'Y', CAST(50.0000 AS Numeric(19, 4)), 0x6E0C3EDA4032BA31A6,'-1', CAST('2019-06-06T13:50:08' AS Date), CAST('2019-06-06T14:50:08' AS Date), N'BFL\bhare', N'UKDVDV456'),
               ( 'A', 'P-GW', 'USPremium', CAST('2018-12-11T00:00:00' AS Date), 'Policy12345', 'Policy12345', CAST('2018-01-12T00:00:00' AS Date), CAST('2018-11-18T14:50:08' AS Date), CAST('2018-11-08T14:50:08' AS Date), CAST('2018-11-28T14:50:08' AS Date), 'NOTFC', 'NOENTITY', '2017', 'N', 'GBP', 'GBP', 'Y', CAST(50.0000 AS Numeric(19, 4)), 0x6E0C3EDA4032BA31A6,'-1', CAST('2019-06-06T13:50:08' AS Date), CAST('2019-06-06T14:50:08' AS Date), N'BFL\bhare', N'UKDVDV456')
        
		

		;WITH	Actual AS (SELECT * FROM  #temp_Inbound WHERE AuditSourceBatchID='-1'),
				Expected AS (SELECT * FROM [Outbound].[Transaction] WHERE AuditSourceBatchID='-1' AND DeltaType='NEW')
				
			SELECT  [Scenario], [Account], DataSet, [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate], [ExpiryDate], [BindDate], [DueDate], 
					[TrifocusCode], [Entity], [YOA], [TypeOfBusiness], [SettlementCCY], [OriginalCCY], [IsToDate], [Value], [RowHash], 
					[AuditSourceBatchID],  [AuditGenerateDateTime]
			FROM Actual
			EXCEPT
			SELECT  [Scenario], [Account], [DataSet], [DateOfFact], [BusinessKey], [PolicyNumber], [InceptionDate], [ExpiryDate], [BindDate], [DueDate], 
					[TrifocusCode], [Entity], [YOA], [TypeOfBusiness], [SettlementCCY], [OriginalCCY], [IsToDate], [Value], [RowHash], 
					[AuditSourceBatchID], [AuditGenerateDateTime]
			FROM Expected;
		 
		 ----To Check duplicate data in Outbound.Transaction(Resultset-2)

     IF EXISTS (SELECT Rowhash,COUNT(*) FROM FinanceDataContract.[Outbound].[Transaction]
				WHERE AuditSourceBatchID='-1'
				GROUP BY RowHash
				HAVING COUNT(*)>1)

     BEGIN
         SELECT 'Fail There are duplicate rowhashes '+AuditSourceBatchID+' in inbound Table' AS TestResults
         FROM [Outbound].[Transaction] WHERE AuditSourceBatchID='-1' GROUP BY AuditSourceBatchID HAVING COUNT(RowHash)>1
     END 

     ELSE 
     BEGIN
         SELECT	 OutboundValue	      =(ISNULL([Value], 0.0000))
            ,TestName             ='DuplicatesHashrow'
     		,TestResult		      = CASE
     							    WHEN AuditSourceBatchID='-1' AND [Value]=100 THEN 'Pass'
     						        ELSE 'Fail'				
     								END
     		,AuditSourceBatchID
     
         FROM  [Outbound].[Transaction]
		 WHERE AuditSourceBatchID='-1' AND DeltaType='NEW'
     END
           ROLLBACK; 
     END TRY
     BEGIN CATCH
          ROLLBACK;
               THROW;
     END CATCH