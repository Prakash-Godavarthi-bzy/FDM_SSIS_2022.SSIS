Sprint 24Q3
-In Progress 12/07/2024
-Sprint 24 Q2 release in https://beazley.atlassian.net/wiki/spaces/IDR/pages/4372103856/Release+47+-+BR1+Release+24Q2+Committed+MAY+UAT and HotFixes in https://beazley.atlassian.net/wiki/spaces/IDR/pages/4417421330/Release+50+-+BR1+Data+Refresh+24Q2+PRD

