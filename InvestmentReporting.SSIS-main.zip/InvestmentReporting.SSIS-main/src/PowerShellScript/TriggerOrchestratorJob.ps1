﻿ 
    param(
            [string]$tenant,
            [string]$Username,
            [string]$Password,
            [string]$UIpathURL,
            [string]$RoboName,
            [string]$ProcessKeyName,
            [string]$ClearWaterDateRange,
            [string]$UNCSharedPath,
            [string]$logfile
          )

          Write-Host "Tenant Name :" $tenant
          Write-Host "UserName :" $Username
          Write-Host "password :" $Password
          Write-Host "UIPathURL  :" $UIpathURL
          Write-Host "Robot Name :" $RoboName
          Write-Host "ProcessKey Name :" $ProcessKeyName
          Write-Host "ClearWater Date Range :" $ClearWaterDateRange
          Write-Host "Unc Path :" $UNCSharedPath
		  write-Host "LogFile :" $logfile
   
 
        Try 
        { 
            $Uncpath = [regex]::Escape($UNCSharedPath)
           
        <# End of Parameter declaration #>
        <# Bearer token  #>
            Write-Host "Bearer Token is being retrieval started"
            $json = “{”“tenancyName”" : ""$tenant"", ““usernameOrEmailAddress””:""$Username"", ““password”” : ""$Password""}"
            $out = Invoke-WebRequest “$UIpathURL/api/Account/Authenticate” -Method Post -Body $json -ContentType “application/json”
            $token = $out | ConvertFrom-Json
            $bearerToken = $token.result
            Write-Host "Bearer Token has been retrieved"

        <# Org ID #>
            Write-Host "Org ID retrieval started"
            $headers = New-Object “System.Collections.Generic.Dictionary[[String],[String]]”
            $headers.Add(“Authorization”, “Bearer $bearerToken”)
            $OrgID = Invoke-WebRequest "$UIpathURL/odata/OrganizationUnits?""$""filter=DisplayName%20%3D%20UK" -Method Get -ContentType “application/json” -Headers $headers
            $OrgResult = $OrgID |ConvertFrom-Json
            $OrgIDResult = $OrgResult.value | Where-Object {$_.DisplayName -eq "UK"} |Select-Object ID
            $headers.add("X-UIPATH-OrganizationUnitId",$OrgIDResult.Id)
            Write-Host "Org ID has been retrieved"

        <#  Release Key retrieval#>
            Write-Host "Get Release Key from Odata/releases using input parameters (Bearer Token, Org ID) by get method"
            $Relases = Invoke-WebRequest "$UIpathURL/odata/Releases" -Method Get -Headers $headers
            $ReleaseContent = $Relases | ConvertFrom-Json
            $ReleaseKey = $ReleaseContent.value | Where-Object {$_.ProcessKey -eq "$ProcessKeyName"} |Select-Object Key #Yasaswini needs to ask paula about Asset Name
            $Key = $ReleaseKey.Key

        <#  Robo ID Retrieval #>
            Write-Host "Get Robo ID from Odata/Jobs using input parameters (Bearer Token, Org ID) by get method"
            $getRobos = Invoke-WebRequest "$UIpathURL/odata/Robots" -Method Get -Headers $headers
            $Robocontent = $getRobos | ConvertFrom-Json
            $RoboID = $Robocontent.value | Where-Object {$_.Name -eq "$RoboName"} #Yasaswini needs to ask paula about Robo
            $RoboID  = "["+$RoboID.Id+"]"
            #$RoboID

             <#  Asset ID Retrieval for SharedPath #>
            Write-Host "Get Asset ID from odata/Assets"
            $getAssets = Invoke-WebRequest "$UIpathURL/odata/Assets" -Method Get -Headers $headers
            $AssetContent = $getAssets | ConvertFrom-Json
            $AssetId = $AssetContent.value | Where-Object {$_.Name -eq "clearwater.finance.sharepath"} 
            $AstID = $AssetId.Id
            $AstID

         <# Editing Asset Sharedpath to copy files based on env triggered from #>
            Write-Host "Edit Asset using env powershell is triggered from" 
            Write-Host "https://uipath-dev.bfl.local/odata/Assets($AstID)" #$AstID
            $json_body = "{  ""Name"": ""clearwater.finance.sharepath"",  ""CanBeDeleted"": true,  ""ValueScope"": ""Global"",  ""ValueType"": ""Text"",  ""Value"": ""string"",  ""StringValue"": ""$Uncpath"",  ""BoolValue"": true,  ""IntValue"": 0,  ""CredentialUsername"": ""string"",  ""CredentialPassword"": ""string"",  ""ExternalName"": ""string"",  ""CredentialStoreId"": 0,  ""KeyValueList"": [    {      ""Key"": ""string"",      ""Value"": ""string""    }  ],  ""HasDefaultValue"": true,  ""Description"": ""string"",  ""RobotValues"": [    {      ""RobotId"": 0,      ""RobotName"": ""string"",      ""KeyTrail"": ""string"",      ""ValueType"": ""DBConnectionString"",      ""StringValue"": ""string"",      ""BoolValue"": true,      ""IntValue"": 0,      ""Value"": ""string"",      ""CredentialUsername"": ""string"",      ""CredentialPassword"": ""string"",      ""ExternalName"": ""string"",      ""CredentialStoreId"": 0,      ""KeyValueList"": [        {          ""Key"": ""string"",          ""Value"": ""string""        }      ],      ""Id"": 0    } ],  ""Id"": $AstID}"
            #"{  ""Name"": ""clearwater.finance.sharepath"",  ""CanBeDeleted"": true,  ""ValueScope"": ""Global"",  ""ValueType"": ""Text"",  ""Value"": ""string"",  ""StringValue"": ""$UNCSharedPath"",  ""BoolValue"": true,  ""IntValue"": 0,  ""CredentialUsername"": ""string"",  ""CredentialPassword"": ""string"",  ""ExternalName"": ""string"",  ""CredentialStoreId"": 0,  ""KeyValueList"": [    {      ""Key"": ""string"",      ""Value"": ""string""    }  ],  ""HasDefaultValue"": true,  ""Description"": ""string"",  ""RobotValues"": [    {      ""RobotId"": 0,      ""RobotName"": ""string"",      ""KeyTrail"": ""string"",      ""ValueType"": ""DBConnectionString"",      ""StringValue"": ""string"",      ""BoolValue"": true,      ""IntValue"": 0,      ""Value"": ""string"",      ""CredentialUsername"": ""string"",      ""CredentialPassword"": ""string"",      ""ExternalName"": ""string"",      ""CredentialStoreId"": 0,      ""KeyValueList"": [        {          ""Key"": ""string"",          ""Value"": ""string""        }      ],      ""Id"": 0    } ],  ""Id"": $AstID}"
            write-Host $json_body
			$EditAsset = Invoke-WebRequest "$UIpathURL/odata/Assets($AstID)"-Method PUT -Body $json_body   -ContentType “application/json” -Headers $headers

        <#  Asset ID Retrieval #>
            Write-Host "Get Asset ID from odata/Assets"
            $getAssets = Invoke-WebRequest "$UIpathURL/odata/Assets" -Method Get -Headers $headers
            $AssetContent = $getAssets | ConvertFrom-Json
            $AssetId = $AssetContent.value | Where-Object {$_.Name -eq "clearwater.dbreport.daterange"} 
            $AstID = $AssetId.Id
            $AstID

         <# Editing Asset DateRange based on User Selected Date Range #>
            Write-Host "Edit Asset using the Date Range selected by user" 
            Write-Host "https://uipath-dev.bfl.local/odata/Assets($AstID)" #$AstID
            $json_body = "{  ""Name"": ""clearwater.dbreport.daterange"",  ""CanBeDeleted"": true,  ""ValueScope"": ""Global"",  ""ValueType"": ""Text"",  ""Value"": ""string"",  ""StringValue"": ""$ClearWaterDateRange"",  ""BoolValue"": true,  ""IntValue"": 0,  ""CredentialUsername"": ""string"",  ""CredentialPassword"": ""string"",  ""ExternalName"": ""string"",  ""CredentialStoreId"": 0,  ""KeyValueList"": [    {      ""Key"": ""string"",      ""Value"": ""string""    }  ],  ""HasDefaultValue"": true,  ""Description"": ""string"",  ""RobotValues"": [    {      ""RobotId"": 0,      ""RobotName"": ""string"",      ""KeyTrail"": ""string"",      ""ValueType"": ""DBConnectionString"",      ""StringValue"": ""string"",      ""BoolValue"": true,      ""IntValue"": 0,      ""Value"": ""string"",      ""CredentialUsername"": ""string"",      ""CredentialPassword"": ""string"",      ""ExternalName"": ""string"",      ""CredentialStoreId"": 0,      ""KeyValueList"": [        {          ""Key"": ""string"",          ""Value"": ""string""        }      ],      ""Id"": 0    } ],  ""Id"": $AstID}"
            write-Host $json_body
			$EditAsset = Invoke-WebRequest "$UIpathURL/odata/Assets($AstID)"-Method PUT -Body $json_body   -ContentType “application/json” -Headers $headers
            #$EditAsset

            
	     #$EditAsset

            <#Checking if Asset value has changed or not
            $getAssets = Invoke-WebRequest "$UIpathURL/odata/Assets" -Method Get -Headers $headers
            $AssetContent = $getAssets | ConvertFrom-Json
            $AssetId = $AssetContent.value | Where-Object {$_.Name -eq "clearwater.dbreport.daterange"} 
            $AssetId#>

        <#  Triggering Orchestrator Job#>
            Write-Host "Triggering Orchestrator Job"
            $json_body = "{""startInfo"": {""ReleaseKey"": ""$Key"",""Strategy"": ""Specific"",""RobotIds"": $RoboID,""NoOfRobots"": 0,""JobsCount"": 0,""Source"": ""Manual"",""InputArguments"": """"}}"
            $Output = Invoke-WebRequest “$UIpathURL/odata/Jobs/UiPath.Server.Configuration.OData.StartJobs” -Method Post -Body $json_body -ContentType “application/json” -Headers $headers
            $JobRunOutput = $Output | ConvertFrom-Json
            $JobRunOutput.value
            Write-Host "Job Run initialisation successful"

        <#====== Clearing Variables cache ======#>
             Clear-Variable -Name ("tenant","Username","Password","UIpathURL","RoboName","json","out","token","headers","OrgID","OrgResult","OrgIDResult","Relases","ReleaseContent","ReleaseKey","Key","getRobos","RoboContent","RoboID","getAssets","AssetContent","AssetId","AstID","EditAsset","Output","JobRunOutput","bearerToken")
        } 
        Catch 
        { 
            $_.Exception.Message | out-file -Filepath $logfile -append   
        } 
     
    
