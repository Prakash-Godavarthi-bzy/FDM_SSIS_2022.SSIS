﻿-- INCLUDE #{Credential_Pre_v4}
 
SET @credential_name = '#{SSISProxyName}'--_#{Environment.Shortname}'
SET @credentialPassword = '#{pxy_fdm.ad.user.password}'
SET @proxy_name = @credential_name -- proxy and credential names normally the same, but can be overridden
 
SET @credential_identity = 'BFL\#{SSISProxyName}_#{Environment.Shortname}'
 
-- INCLUDE #{Credential_Post_v4}
/*
 
Instructions:
=============
1. Set the @credential_name
2. Create an Octopus variable for the @credentialPassword
 
NOTES:
The credential and proxy names should be the same, but can be overridden
The credential identity (AD user) will be derived (Beazley standards), but can be changed, or overridden with an Octopus variable
The credential will only be dropped and re-created if there are no proxy accounts against it, so changing it requires a manual DROP PROXY script.
 
*/