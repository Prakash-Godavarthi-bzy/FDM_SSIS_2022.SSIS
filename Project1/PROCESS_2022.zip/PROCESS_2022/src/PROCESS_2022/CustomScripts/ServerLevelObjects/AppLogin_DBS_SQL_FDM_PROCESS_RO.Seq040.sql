﻿-- INCLUDE #{Login1_Pre_v4}
 
SET @user_name = 'DBS.SQL.FDM_PROCESS.RO'
 
/*
Create a Business access windows login OR an IT Diagnostic access windows login
 
    The username will be the same in all environments          - App.applicationname[usertype].access OR DBS.SQL.databasename.access
        where usertype is the user level access, e.g. Users, Admins
        where access is the type of access within the database, e.g. RO (ReadOnly), RW (Read+Write), WO (Write Only)
    The windows login will change depending on the environment - e.g. domain\App.applicationname[usertype].access[.TST]
        The login will be BFL\<user_name> in production and BFL\<user_name>.TST for all other environments
 
Instructions:
=============
1. Set the @user_name
 
*/
-- INCLUDE #{Login1_Post_v4}