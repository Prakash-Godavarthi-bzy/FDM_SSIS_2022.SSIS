﻿DECLARE @LoginName NVARCHAR(255) = N'BFL\FDM Developers'
DECLARE @SQL NVARCHAR(MAX)
DECLARE @Env NVARCHAR(MAX) = '#{Environment}'
DECLARE @UserName NVARCHAR(255) = N'FDM Developers'
 
SELECT @Env = CAST([value] AS NVARCHAR(3)) FROM [master].[sys].[fn_listextendedproperty] (NULL, NULL, NULL, NULL, NULL, NULL, NULL) WHERE [name] = N'Environment Name'

PRINT @Env
IF NOT EXISTS    
    ( SELECT    NAME FROM    sys.server_principals WHERE NAME = @LoginName)
    BEGIN
        SET    @SQL = 'CREATE LOGIN ['+@LoginName+'] FROM WINDOWS WITH DEFAULT_DATABASE=[master]'
        EXEC sp_executesql @SQL
		Print 'Login Created for '+@LoginName
    END

IF @Env = 'DEV'
BEGIN
    SET        @SQL = 'ALTER SERVER ROLE [sysadmin] ADD MEMBER ['+@LoginName+']'
    EXEC sp_executesql @SQL
END
ELSE IF @Env = 'SYS'
BEGIN
    SET        @SQL = 'ALTER SERVER ROLE [sysadmin] ADD MEMBER ['+@LoginName+']'
    EXEC sp_executesql @SQL
END

