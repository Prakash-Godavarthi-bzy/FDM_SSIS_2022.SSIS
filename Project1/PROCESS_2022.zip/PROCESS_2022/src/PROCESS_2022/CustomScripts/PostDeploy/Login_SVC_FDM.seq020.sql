﻿USE FDM_DB; /* Only if not the target database */ 
-- INCLUDE #{User_Pre_v4}
 
SET @user_name = 'SVC_FDM'
 
-- INCLUDE #{User_Mid_v4}
/*
 
Create database user against a login
Users will always be dropped and re-created
 
Instructions:
=============
1. Optionally, set the databasename (at the top of this script)
2. Set the @user_name
3. Set user permissions by uncommenting lines below, or define your own (using the same syntax)
 
*/
 
/* New versions syntax */
-- INSERT @T (Code) VALUES ('ALTER ROLE [ReportingRead] ADD MEMBER ['+@user_name+']')
-- INSERT @T (Code) VALUES ('GRANT SELECT ON SCHEMA::[Reporting] TO ['+@user_name+']')
-- INSERT @T (Code) VALUES ('ALTER ROLE [db_datareader] ADD MEMBER ['+@user_name+']')
INSERT @T (Code) VALUES ('ALTER ROLE [db_datareader] ADD MEMBER ['+@user_name+']')
INSERT @T (Code) VALUES ('ALTER ROLE [db_datawriter] ADD MEMBER ['+@user_name+']')
-- INSERT @T (Code) VALUES ('ALTER ROLE [ssis_admin] ADD MEMBER ['+@user_name+']')
-- INSERT @T (Code) VALUES ('ALTER ROLE [db_ssisoperator] ADD MEMBER ['+@user_name+']')
 
/* Older versions syntax */
-- INSERT @T (Code) VALUES ('EXECUTE [sys].[sp_addrolemember] @rolename=N''db_owner'', @membername='+@user_name)
-- INSERT @T (Code) VALUES ('EXECUTE [sys].[sp_addrolemember] @rolename=N''db_ddladmin'', @membername='+@user_name)
-- INSERT @T (Code) VALUES ('EXECUTE [sys].[sp_addrolemember] @rolename=N''db_datareader'', @membername='+@user_name)
-- INSERT @T (Code) VALUES ('EXECUTE [sys].[sp_addrolemember] @rolename=N''db_datawriter'', @membername='+@user_name)
 
-- INCLUDE #{User_Post_v4}