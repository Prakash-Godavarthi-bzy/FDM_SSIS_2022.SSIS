﻿USE staging_agresso
GO

DECLARE @LoginName NVARCHAR(255) = N'BFL\FDM Developers'
DECLARE @UserName NVARCHAR(255) = N'FDM Developers'
DECLARE @SQL NVARCHAR(MAX)
DECLARE @Env NVARCHAR(MAX) = '#{Environment}'
 
SELECT @Env = CAST([value] AS NVARCHAR(3)) FROM [master].[sys].[fn_listextendedproperty] (NULL, NULL, NULL, NULL, NULL, NULL, NULL) WHERE [name] = N'Environment Name'

PRINT @Env

IF NOT EXISTS    
    ( SELECT    NAME FROM    sys.database_principals WHERE NAME = @UserName)
    BEGIN
        SET    @SQL = 'CREATE USER ['+@UserName+'] FOR LOGIN ['+@LoginName+']'
        EXEC sp_executesql @SQL
		Print 'User Created for '+@UserName
    END
 
IF @Env = 'DEV'
BEGIN
    SET        @SQL = 'ALTER ROLE [db_owner] ADD MEMBER ['+@UserName+']'
    EXEC sp_executesql @SQL
	Print 'User permissions assigned to '+@UserName + ' - ' + @SQL
 --   SET        @SQL = 'ALTER SERVER ROLE [sysadmin] ADD MEMBER ['+@UserName+']'
 --   EXEC sp_executesql @SQL
	--Print 'User permissions assigned to '+@UserName + ' - ' + @SQL
END
ELSE IF @Env = 'SYS'
BEGIN 
    SET        @SQL = 'ALTER ROLE [db_owner] ADD MEMBER ['+@UserName+']'
    EXEC sp_executesql @SQL
	Print 'User permissions assigned to '+@UserName + ' - ' + @SQL
 --   SET        @SQL = 'ALTER SERVER ROLE [sysadmin] ADD MEMBER ['+@UserName+']'
 --   EXEC sp_executesql @SQL
	--Print 'User permissions assigned to '+@UserName + ' - ' + @SQL
 --   SET        @SQL = 'ALTER ROLE [db_datareader] ADD MEMBER ['+@LoginName+']'
 --   EXEC sp_executesql @SQL
	--Print 'User permissions assigned to '+@LoginName + ' - ' + @SQL
 --   SET        @SQL = 'ALTER ROLE [db_datawriter] ADD MEMBER ['+@LoginName+']'
 --   EXEC sp_executesql @SQL
	--Print 'User permissions assigned to '+@LoginName + ' - ' + @SQL
END 
ELSE IF @Env = 'UAT'
BEGIN 
    SET        @SQL = 'ALTER ROLE [db_datareader] ADD MEMBER ['+@UserName+']'
    EXEC sp_executesql @SQL
	Print 'User permissions assigned to '+@UserName + ' - ' + @SQL
END 
ELSE IF @Env = 'PRD'
BEGIN 
    SET        @SQL = 'ALTER ROLE [db_datareader] ADD MEMBER ['+@UserName+']'
    EXEC sp_executesql @SQL
	Print 'User permissions assigned to '+@UserName + ' - ' + @SQL
END

