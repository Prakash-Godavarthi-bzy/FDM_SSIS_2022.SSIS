﻿/*
 Pre-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be executed before the build script.	
 Use SQLCMD syntax to include a file in the pre-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the pre-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
--USE msdb
--GO
----Drop the proxy if it is already existing
--IF EXISTS (SELECT 1 FROM msdb.dbo.sysproxies WHERE name = N'PXY_FDM')
--BEGIN
--EXEC msdb.dbo.sp_delete_proxy
--@proxy_name = N'PXY_FDM'
--END
--GO

IF NOT EXISTS (SELECT 1 FROM msdb.dbo.sysproxies WHERE name = N'PXY_FDM')
BEGIN
    --Create a proxy and use the same credential as created above
    EXEC msdb.dbo.sp_add_proxy
    @proxy_name = N'PXY_FDM',
    @credential_name=N'PXY_FDM',
    @enabled=1

    PRINT 'Proxy added'
END
    
GO
----To enable or disable you can use this command
--EXEC msdb.dbo.sp_update_proxy
--@proxy_name = N'PXY_FDM',
--@enabled = 1 --@enabled = 0
--GO

--    PRINT 'Proxy Enabled'