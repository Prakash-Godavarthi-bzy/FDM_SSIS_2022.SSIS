﻿CREATE ROLE [FDMExecuteJob]
    AUTHORIZATION [dbo];

