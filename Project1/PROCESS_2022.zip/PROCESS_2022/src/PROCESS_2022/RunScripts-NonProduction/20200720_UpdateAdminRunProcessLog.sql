USE FDM_PROCESS
GO

DECLARE @RowsToDelete INT = 13 ;

BEGIN TRY ;

	BEGIN

		BEGIN TRAN ;

			INSERT INTO [FDM_PROCESS].[Admin].[RunProcessLog]
			SELECT Top 1 
			  '-1' AS [fk_RunProcessConfig]  
			  ,'Not Applicable' AS [FileName]   
			  , 'Overnight' AS [Module]
			  ,GETDATE()-1 AS [CreatedDate] 
			  ,'FDM' AS [CreatedBy] 
			  ,' 202007' AS [SelectedAccountingPeriod]
			  ,GETDATE()-1 AS [StartTime]  
			  , GETDATE()-1 AS [EndTime]
			  ,'Success' [Status] 
			  , 'Y' [FileStatus]
			  ,332579215 [LastInsertedAgrtid] 
			FROM [FDM_PROCESS].[Admin].[RunProcessLog]

		IF @@ROWCOUNT = 1 
			COMMIT ;

		ELSE 
			BEGIN
				ROLLBACK ;
				SELECT 'Updating [Admin].RunProcessLog: inexpected number of rows' AS ErrorMessage;
				THROW 51000, 'Updating [Admin].RunProcessLog: inexpected number of rows', 1; 
			END
	END ;

END TRY 

BEGIN CATCH ;

	IF @@TRANCOUNT > 0
		ROLLBACK ;
	
	SELECT @@Error; 

	THROW ;

END CATCH ;
