﻿CREATE TABLE [Admin].[FDMReconciliationOvernight] (
    [FDMReconciliationOvernightID] INT              IDENTITY (1, 1) NOT NULL,
    [FK_RunProcessLogID]           INT              NULL,
    [Source]                       NVARCHAR (20)    NULL,
    [CapturedTime]                 DATETIME         NULL,
    [Client]                       NVARCHAR (20)    NULL,
    [Entity]                       NVARCHAR (20)    NULL,
    [Currency]                     NVARCHAR (20)    NULL,
    [Account]                      NVARCHAR (20)    NULL,
    [TransactionCount]             BIGINT           NULL,
    [CurAmount]                    DECIMAL (28, 10) NULL,
    CONSTRAINT [pk_FDMReconciliationOvernight] PRIMARY KEY CLUSTERED ([FDMReconciliationOvernightID] ASC) WITH (FILLFACTOR = 90)
);

