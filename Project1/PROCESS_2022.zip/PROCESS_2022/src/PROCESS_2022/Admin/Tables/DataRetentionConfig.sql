﻿CREATE TABLE [Admin].[DataRetentionConfig]
(
	[DataRetentionConfigId] INT IDENTITY(1,1 ) NOT NULL PRIMARY KEY, 
    [TableName] VARCHAR(255) NOT NULL, 
	[Description] VARCHAR(500),
    [RetentionPeriod] INT NOT NULL, 
    [RetentionPeriodType] VARCHAR(255) NOT NULL, 
	[RetentionDay] VARCHAR(50) NOT NULL,
	[RowsPerBatch] INT NOT NULL,
    [CreatedDate] DATETIME NULL, 
    [CreatedBy] VARCHAR(50) NULL, 
    [ModifiedDate] DATETIME NULL, 
    [ModifiiedBy] VARCHAR(50) NULL
)
