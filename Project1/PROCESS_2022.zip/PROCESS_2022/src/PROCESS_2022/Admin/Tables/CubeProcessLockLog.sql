﻿CREATE TABLE [Admin].[CubeProcessLockLog] (
    [pk_ProcessLockLogID] INT            IDENTITY (1, 1) NOT NULL,
    [PackageName]         NVARCHAR (255) NOT NULL,
    [LockFlag]            INT            NOT NULL,
    CONSTRAINT [PK_CubeProcessLockLog] PRIMARY KEY CLUSTERED ([pk_ProcessLockLogID] ASC) WITH (FILLFACTOR = 90)
);

