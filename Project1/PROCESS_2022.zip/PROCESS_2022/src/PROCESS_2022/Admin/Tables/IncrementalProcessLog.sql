﻿CREATE TABLE [Admin].[IncrementalProcessLog] (
    [pk_ProcessLogID]   INT            IDENTITY (1, 1) NOT NULL,
    [ObjectID]          NVARCHAR (255) NOT NULL,
    [ObjectType]        NVARCHAR (255) NOT NULL,
    [FromModule]        NVARCHAR (255) NOT NULL,
    [InsertDate]        DATETIME       NOT NULL,
    [ProcessingState]   NVARCHAR (150) NOT NULL,
    [fk_CubeProcessLog] INT            NULL,
	[RunProcessLogID]   INT			CONSTRAINT [DEF_IncrementalLog_RunProcessLogID] DEFAULT (-1) NOT NULL,
	 CONSTRAINT [PK_IncrementalProcessLog] PRIMARY KEY CLUSTERED ([pk_ProcessLogID] ASC) WITH (FILLFACTOR = 90)
);

