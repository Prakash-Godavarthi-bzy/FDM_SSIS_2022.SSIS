﻿CREATE TABLE [Admin].[RunProcessConfig] (
    [pk_RunProcessConfig] INT            IDENTITY (1, 1) NOT NULL,
    [FolderName]          NVARCHAR (255) NOT NULL,
    [ModuleName]          NVARCHAR (255) NOT NULL,
    [PackageName]         NVARCHAR (255) NOT NULL,
    [UserInitiated]       BIT            NOT NULL,
    [Stream]              INT            NOT NULL,
    [RunOrder]            INT            NOT NULL,
    [SSISFolderName]      NVARCHAR (255) CONSTRAINT [SSISFolderName_Default] DEFAULT ('FDM_SSIS') NOT NULL,
    CONSTRAINT [pk_RunProcessConfig] PRIMARY KEY CLUSTERED ([pk_RunProcessConfig] ASC) WITH (FILLFACTOR = 90)
);

