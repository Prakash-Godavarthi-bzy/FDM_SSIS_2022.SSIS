﻿CREATE TABLE [Admin].[DBRestoreHistoryLog]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY(1,1), 
    [DataBaseName] NVARCHAR(256) NULL, 
    [RestoreDate] DATETIME NULL, 
    [Backup_Date] DATETIME NULL, 
    [BackupFrom] VARCHAR(50) NULL, 
    [ApplicationName] VARCHAR(50) NULL
)
