﻿CREATE TABLE [Admin].[OverseasASLProcessLog] (
    [pk_ProcessLogID]   INT            IDENTITY (1, 1) NOT NULL,
    [ExtractLoadId]     INT            NULL,
    [RunProcessBatchId] INT            NOT NULL,
    [FileName]          NVARCHAR (100) NOT NULL,
    [InsertDate]        DATETIME       NOT NULL,
    [ProcessingState]   NVARCHAR (150) NOT NULL,
    [AccountingPeriod]  INT            NOT NULL,
    [ReportingDate]     DATETIME       NULL,
    CONSTRAINT [PK_OverseasASLProcessLog] PRIMARY KEY CLUSTERED ([pk_ProcessLogID] ASC) WITH (FILLFACTOR = 90)
);

