﻿CREATE TABLE [Admin].[MDXQueryLog_Archive] (
    [MDXQueryLogId]     BIGINT         IDENTITY (1, 1) NOT NULL,
    [EventClass]        NVARCHAR (128) NULL,
    [SPID]              INT            NULL,
    [EventSubclass]     NVARCHAR (128) NULL,
    [NTUserName]        NVARCHAR (128) NULL,
    [TextData]          NVARCHAR (MAX) NULL,
    [StartTime]         DATETIME       NULL,
    [DatabaseName]      NVARCHAR (128) NULL,
    [CurrentTime]       DATETIME       NULL,
    [EndTime]           DATETIME       NULL,
    [Duration]          BIGINT         NULL,
    [CPUTime]           BIGINT         NULL,
    [Error]             BIGINT         NULL,
    [ServerName]        NVARCHAR (128) NULL,
    [SessionID]         NVARCHAR (128) NULL,
    [ConnectionID]      INT            NULL,
    [RequestParameters] NVARCHAR (MAX) NULL,
    [RequestProperties] NVARCHAR (MAX) NULL,
    CONSTRAINT [PK_MDXQueryLog_Archive_MDXQueryLogId] PRIMARY KEY CLUSTERED ([MDXQueryLogId] ASC) WITH (FILLFACTOR = 90)
);

