﻿CREATE TABLE [Admin].[FactFDMUWPatternLog](
	[UWPatternRunID] [int] IDENTITY(1,1) NOT NULL,
	[RunProcessLogID] [int] NULL,
	[StartTime] [datetime] NULL,
	[EndTime] [datetime] NULL,
	[Status] [varchar](55) NULL, 
    CONSTRAINT [PK_FactFDMUWPatternLog] PRIMARY KEY CLUSTERED ([UWPatternRunID] ASC) WITH (FILLFACTOR = 90)
) ON [PRIMARY]
GO