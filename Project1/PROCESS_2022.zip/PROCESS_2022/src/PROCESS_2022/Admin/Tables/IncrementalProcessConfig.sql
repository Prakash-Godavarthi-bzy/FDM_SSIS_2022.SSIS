﻿CREATE TABLE [Admin].[IncrementalProcessConfig] (
    [ObjectID]              VARCHAR (255) NOT NULL,
    [ObjectName]            VARCHAR (255) NOT NULL,
    [ObjectType]            VARCHAR (255) NOT NULL,
    [ParentObjectID]        VARCHAR (255) NULL,
    [ParentObjectName]      VARCHAR (255) NULL,
    [ProcessType]           VARCHAR (50)  NOT NULL,
    [ProcessAddElementName] VARCHAR (255) NULL,
    [ProcessAddQuery]       VARCHAR (MAX) NULL,
    [ProcessAddTableName]   VARCHAR (255) NULL,
    [AlwaysPartOfBatch]     BIT           NOT NULL,
    [CubeID]                VARCHAR (100) NULL,
    [CubeName]              VARCHAR (100) NULL,
    CONSTRAINT [PK_IntradayConfig] PRIMARY KEY CLUSTERED ([ObjectID] ASC) WITH (FILLFACTOR = 90)
);

