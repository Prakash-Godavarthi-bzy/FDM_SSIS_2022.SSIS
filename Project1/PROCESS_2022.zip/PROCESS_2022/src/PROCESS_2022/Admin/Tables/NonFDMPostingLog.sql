﻿CREATE TABLE [Admin].[NonFDMPostingLog] (
    [NonFDMPostingLogID] INT           IDENTITY (1, 1) NOT NULL,
    [VoucherNo]          BIGINT        NULL,
    [VoucherType]        NVARCHAR (20) NULL,
    [AgressoLedgerDate]  DATETIME      NULL,
    [FDMDate]            DATETIME      NULL,
    [Username]           NVARCHAR (10) NULL,
    [AccountingPeriod]   INT           NULL,
    [TransactionCount]   BIGINT        NULL,
    CONSTRAINT [pk_NonFDMPostingLog] PRIMARY KEY CLUSTERED ([NonFDMPostingLogID] ASC) WITH (FILLFACTOR = 90)
);

