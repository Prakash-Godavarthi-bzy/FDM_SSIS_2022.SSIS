﻿CREATE TABLE [Admin].[CubeProcessLog] (
    [pk_CubeProcessLog] INT           IDENTITY (1, 1) NOT NULL,
    [ProcessType]       NVARCHAR (50) NOT NULL,
    [StartTime]         DATETIME      NOT NULL,
    [EndTime]           DATETIME      NULL,
    [Result]            NVARCHAR (50) NULL,
	[RunProcessLogID]   INT CONSTRAINT [DEF_CubeProcessLog_RunProcessLogID] DEFAULT (-1) NOT NULL,
    CONSTRAINT [PK_CubeProcessLog] PRIMARY KEY CLUSTERED ([pk_CubeProcessLog] ASC) WITH (FILLFACTOR = 90)
);

