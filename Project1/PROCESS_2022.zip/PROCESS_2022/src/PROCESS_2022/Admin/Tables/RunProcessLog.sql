﻿CREATE TABLE [Admin].[RunProcessLog] (
    [RunProcessLogID]          INT            IDENTITY (1, 1) NOT NULL,
    [fk_RunProcessConfig]      INT            NOT NULL,
    [FileName]                 NVARCHAR (255) NOT NULL,
    [Module]                   NVARCHAR (255) NOT NULL,
    [CreatedDate]              DATETIME       NOT NULL,
    [CreatedBy]                NVARCHAR (150) NOT NULL,
    [SelectedAccountingPeriod] INT            NOT NULL,
    [StartTime]                DATETIME       NULL,
    [EndTime]                  DATETIME       NULL,
    [Status]                   NVARCHAR (150) NOT NULL,
    [FileStatus]               NVARCHAR (150) NOT NULL,
    [LastInsertedAgrtid]       BIGINT         NULL,
    CONSTRAINT [pk_RunProcessLog] PRIMARY KEY CLUSTERED ([RunProcessLogID] ASC) WITH (FILLFACTOR = 90)
);


GO
CREATE NONCLUSTERED INDEX [IDX_RunProcessLog_Module]
    ON [Admin].[RunProcessLog]([Module] ASC) WITH (FILLFACTOR = 90);

