﻿CREATE TABLE [Admin].[DataRetentionLog]
(
	[DataRetentionLogId] INT IDENTITY(1,1) NOT NULL PRIMARY KEY, 
    [fk_DataRetentionConfigId] INT NOT NULL,
	[StartTime]	datetime,
	[EndTime]	datetime,
	[RowCount]	BIGINT, 
	[ActionType] VARCHAR(255),
    [CreatedDate] DATETIME NULL, 
    [CreatedBy] VARCHAR(50) NULL, 
    CONSTRAINT [FK_DataRetentionLog_DataRetentionConfig] FOREIGN KEY ([fk_DataRetentionConfigId]) REFERENCES [Admin].[DataRetentionConfig]([DataRetentionConfigId])
)
