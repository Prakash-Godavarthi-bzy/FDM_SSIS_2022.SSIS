﻿CREATE TABLE [Admin].[FDMReconciliation] (
    [FDMReconciliationID] INT           IDENTITY (1, 1) NOT NULL,
    [FK_RunProcessLogID]  INT           NULL,
    [Source]              NVARCHAR (20) NULL,
    [CapturedTime]        DATETIME      NULL,
    [RecDate]             DATE          NULL,
    [TransactionCount]    BIGINT        NULL,
    CONSTRAINT [pk_FDMReconciliation] PRIMARY KEY CLUSTERED ([FDMReconciliationID] ASC) WITH (FILLFACTOR = 90)
);

