﻿CREATE TABLE [Admin].[StageAgressoVoucher] (
    [StageAgressoVoucherID] INT           IDENTITY (1, 1) NOT NULL,
    [Client]                NVARCHAR (10) NULL,
    [ExtInvRef]             NVARCHAR (25) NULL,
    [VoucherType]           NVARCHAR (25) NOT NULL,
    [VoucherNo]             BIGINT        NOT NULL,
    [number_1]              BIGINT        NULL,
    [BackInFDMDate]         DATETIME      NOT NULL,
    [IsFDM]                 BIT           NOT NULL,
    CONSTRAINT [PK_StageAgressoVoucher] PRIMARY KEY CLUSTERED ([StageAgressoVoucherID] ASC) WITH (FILLFACTOR = 90)
);

