
CREATE PROCEDURE [Admin].[usp_BatchDetailCSVExport]
(	  @package_name NVARCHAR(255) 
	 ,@Account NVARCHAR(255) 
	 ,@batchid NVARCHAR(255)
	 ,@Currency NVARCHAR(255)
	 ,@Entity NVARCHAR(255)
	 ,@Trifocus NVARCHAR(255)
	 ,@Voucher NVARCHAR(255)
	 ,@YOA NVARCHAR(255)
)
AS
BEGIN
    
		DECLARE @RC int
		DECLARE @execution_id bigint
		DECLARE @object_type smallint = 20
		DECLARE @parameter_name NVARCHAR(128)
		DECLARE @parameter_value sql_variant

		DECLARE @executionStatus int = 0
		DECLARE @folder_name NVARCHAR(255) = 'FDM'
		DECLARE @project_name NVARCHAR(255) = 'FDM_SSIS'
		DECLARE @package_parameter_name1 NVARCHAR(128) = 'Account'
		DECLARE @package_parameter_name2 NVARCHAR(128) = 'BatchID'
		DECLARE @package_parameter_name3 NVARCHAR(128) = 'Currency'
		DECLARE @package_parameter_name4 NVARCHAR(128) = 'Entity'
		DECLARE @package_parameter_name5 NVARCHAR(128) = 'Trifocus'
		DECLARE @package_parameter_name6 NVARCHAR(128) = 'Voucher'
		DECLARE @package_parameter_name7 NVARCHAR(128) = 'YOA'
		DECLARE @environment_name NVARCHAR(255) = 'FDM_SSIS'

		--SELECT	 @project_name = SSISFolderName FROM FDM_PROCESS.admin.RunProcessConfig
		--WHERE	PackageName = @package_name




		 exec ssisdb.catalog.create_execution 
		  @folder_name = @folder_name
		 ,@project_name = @project_name
		 ,@package_name = @package_name
		 ,@execution_id = @execution_id output



		

		DECLARE param_cursor CURSOR FOR 
			 SELECT [name]
				  ,[value]
			  FROM [SSISDB].[internal].[environment_variables] a
			  JOIN [SSISDB].[internal].[execution_parameter_values]   b
			  ON	a.name = b.parameter_name
			  WHERE environment_id = (SELECT [environment_id]
									  FROM [SSISDB].[internal].[environments]
									  WHERE environment_name = @environment_name)
			  AND execution_id = @execution_id
			  AND parameter_value IS NULL

		OPEN param_cursor  
				FETCH NEXT FROM param_cursor   
				INTO @parameter_name, @parameter_value 

				WHILE @@FETCH_STATUS = 0  
				BEGIN  
					EXECUTE @RC = [SSISDB].[catalog].[set_execution_parameter_value] 
					   @execution_id =@execution_id
					  ,@object_type = @object_type
					  ,@parameter_name = @parameter_name
					  ,@parameter_value = @parameter_value


					FETCH NEXT FROM param_cursor   
						INTO @parameter_name, @parameter_value  
				END   
		CLOSE param_cursor;  
		DEALLOCATE param_cursor; 
	
 

		EXECUTE @RC = [SSISDB].[catalog].[set_execution_parameter_value] 
		   @execution_id =@execution_id
		  ,@object_type = 30
		  ,@parameter_name = @package_parameter_name1
		  ,@parameter_value = @Account
		

		  EXECUTE @RC = [SSISDB].[catalog].[set_execution_parameter_value] 
		   @execution_id =@execution_id
		  ,@object_type = 30
		  ,@parameter_name = @package_parameter_name2
		  ,@parameter_value = @Batchid
	
		  EXECUTE @RC = [SSISDB].[catalog].[set_execution_parameter_value] 
		   @execution_id =@execution_id
		  ,@object_type = 30
		  ,@parameter_name = @package_parameter_name3
		  ,@parameter_value = @Currency

		  EXECUTE @RC = [SSISDB].[catalog].[set_execution_parameter_value] 
		   @execution_id =@execution_id
		  ,@object_type = 30
		  ,@parameter_name = @package_parameter_name4
		  ,@parameter_value = @Entity

		  EXECUTE @RC = [SSISDB].[catalog].[set_execution_parameter_value] 
		   @execution_id =@execution_id
		  ,@object_type = 30
		  ,@parameter_name = @package_parameter_name5
		  ,@parameter_value = @Trifocus

		  EXECUTE @RC = [SSISDB].[catalog].[set_execution_parameter_value] 
		   @execution_id =@execution_id
		  ,@object_type = 30
		  ,@parameter_name = @package_parameter_name6
		  ,@parameter_value = @Voucher

		  EXECUTE @RC = [SSISDB].[catalog].[set_execution_parameter_value] 
		   @execution_id =@execution_id
		  ,@object_type = 30
		  ,@parameter_name = @package_parameter_name7
		  ,@parameter_value = @YOA
		
		EXECUTE @RC = [SSISDB].[catalog].[start_execution] 
		   @execution_id =@execution_id

		WHILE EXISTS (
		SELECT [Status] FROM [SSISDB].[catalog].[executions](nolock)
		WHERE execution_id = @execution_id
		AND [status] in (1,2,5))

		BEGIN
		 WAITFOR DELAY '00:00:02'; 
		END


		SELECT 
			@executionStatus = CASE   [status] 
					   WHEN 1 THEN '1' 
					   WHEN 2 THEN '1' 
					   WHEN 3 THEN '0' 
					   WHEN 4 THEN '0' 
					   WHEN 5 THEN '1' 
					   WHEN 6 THEN '0' 
					   WHEN 7 THEN '1' 
					   WHEN 8 THEN '0' 
					   WHEN 9 THEN '1' 
			 END 
		FROM   [SSISDB].[catalog] .[executions] 
		WHERE  execution_id = @execution_id -- replace with your execution_id 

		IF @executionStatus = 0
		BEGIN
			DECLARE @DBID INT;
			SET @DBID = DB_ID();

			DECLARE @DBNAME NVARCHAR(128);
			SET @DBNAME = DB_NAME();

				SELECT @executionStatus = [Status]
				FROM   [SSISDB].[catalog] .[executions] 
				WHERE  execution_id = @execution_id

			DECLARE @ErrorMessage VARCHAR(255) = 'Package execution failed for '+@package_name+' with ExecutionID:'+CAST(@execution_id AS VARCHAR(10)) +'. Execution status from the package is:' +CAST(@executionStatus AS varchar(5))

			RAISERROR
				(@ErrorMessage,
				11, -- Severity.
				1, -- State.
				@DBID, -- First substitution argument.
				@DBNAME); -- Second substitution argument.
			END


END
