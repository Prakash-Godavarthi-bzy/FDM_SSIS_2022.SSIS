﻿

-- =============================================
-- Author:		Stuart Johnstone
-- Create date: 04/10/2016
-- Description:	Popuate cube objects that need to be processed
-- =============================================

CREATE PROCEDURE [Admin].[usp_InsertIntoIncrementalProcessLog]

	@ObjectID AS VARCHAR(255),
	@ObjectType AS VARCHAR(255),
	@FromModule AS VARCHAR(255),
	@RunProcessLogID AS INT

AS
BEGIN

	SET NOCOUNT ON;
	

	INSERT INTO [Admin].[IncrementalProcessLog]
           ([ObjectID]
           ,[ObjectType]
           ,[FromModule]
           ,[InsertDate]
           ,[ProcessingState]
		   ,[RunProcessLogID])
     VALUES
           (@ObjectID
           ,@ObjectType
           ,@FromModule
           ,getDate()
           ,'Pending'
		   ,@RunProcessLogID)

END
