﻿CREATE TABLE [dbo].[LookupCodes] (
    [ID]                 INT           IDENTITY (1, 1) NOT NULL,
    [IDCode]             VARCHAR (50)  NULL,
    [NACE]               VARCHAR (50)  NULL,
    [NACECode]           VARCHAR (50)  NULL,
    [CIC]                VARCHAR (50)  NULL,
    [LEI]                VARCHAR (50)  NULL,
    [LEIRiskIssuer]      VARCHAR (255) NULL,
    [SIIValuationMethod] VARCHAR (50)  NULL,
    [Status]             VARCHAR (50)  NULL,
    [EffectiveDate]      DATETIME      NULL,
    [PayRateTYpe]        VARCHAR (50)  NULL,
    [BondCategory]       VARCHAR (50)  NULL,
    [ChartData]          VARCHAR (50)  NULL,
    [GovtGtd]            VARCHAR (50)  NULL,
    CONSTRAINT [PK_LookupCodes] PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);

