﻿CREATE TABLE [dbo].[AuditDataSetInstance] (
    [DataSetInstanceId]   INT          IDENTITY (1, 1) NOT NULL,
    [DataSetId]           VARCHAR (12) NOT NULL,
    [DataSetInstanceDate] DATETIME     NOT NULL,
    CONSTRAINT [PKAuditDataSetInstance] PRIMARY KEY CLUSTERED ([DataSetInstanceId] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ__AuditDat__9413BA3A49C163EC] UNIQUE NONCLUSTERED ([DataSetInstanceId] ASC) WITH (FILLFACTOR = 90)
);

