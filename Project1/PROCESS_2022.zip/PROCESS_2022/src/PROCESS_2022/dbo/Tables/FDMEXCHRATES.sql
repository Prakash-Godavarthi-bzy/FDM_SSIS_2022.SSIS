﻿CREATE TABLE [dbo].[FDMEXCHRATES] (
    [BatchId]      VARCHAR (12)    NULL,
    [PackageID]    VARCHAR (12)    NULL,
    [client]       VARCHAR (25)    NOT NULL,
    [cur_type]     VARCHAR (25)    NOT NULL,
    [cur_unit]     INT             NOT NULL,
    [currency]     VARCHAR (25)    NOT NULL,
    [date_from]    DATETIME        NOT NULL,
    [date_to]      DATETIME        NOT NULL,
    [exch_rate]    DECIMAL (28, 8) NOT NULL,
    [last_update]  DATETIME        NOT NULL,
    [rate_exp]     SMALLINT        NOT NULL,
    [reg_rate]     DECIMAL (28, 8) NOT NULL,
    [sequence_no]  INT             NOT NULL,
    [user_id]      VARCHAR (25)    NOT NULL,
    [import_date]  DATETIME        NULL,
    [ImportStatus] VARCHAR (1)     NULL,
    [FilePeriod]   VARCHAR (50)    NULL,
    [agrtid]       INT             IDENTITY (1, 1) NOT NULL,
    CONSTRAINT [PK_FDMEXCHRATES] PRIMARY KEY CLUSTERED ([agrtid] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ__FDMEXCHR__1A3C8123468E8155] UNIQUE NONCLUSTERED ([agrtid] ASC) WITH (FILLFACTOR = 90)
);

