﻿CREATE TABLE [dbo].[Lookup201LineNumber] (
    [ID]            INT          IDENTITY (1, 1) NOT NULL,
    [QMA201]        VARCHAR (50) NULL,
    [LineNumber]    VARCHAR (50) NULL,
    [Status]        VARCHAR (50) NULL,
    [EffectiveDate] DATETIME     NULL,
    CONSTRAINT [PK_Lookup201LineNumber] PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);

