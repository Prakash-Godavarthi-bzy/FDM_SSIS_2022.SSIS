﻿CREATE TABLE [dbo].[LookupGLCode] (
    [ID]                INT           IDENTITY (1, 1) NOT NULL,
    [GLCode]            VARCHAR (255) NULL,
    [CustAccName]       VARCHAR (255) NULL,
    [NorthernTrustCode] VARCHAR (255) NULL,
    [Status]            VARCHAR (50)  NULL,
    [EffectiveDate]     DATETIME      NULL,
    CONSTRAINT [PK_LookupGLCode] PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);

