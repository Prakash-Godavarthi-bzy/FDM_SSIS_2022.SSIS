﻿CREATE TABLE [dbo].[FilePeriod] (
    [Area]     VARCHAR (50) NULL,
    [Period]   VARCHAR (50) NULL,
    [FileType] VARCHAR (12) NULL,
    [ID]       INT          IDENTITY (1, 1) NOT NULL,
    CONSTRAINT [PK_FilePeriod] PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);

