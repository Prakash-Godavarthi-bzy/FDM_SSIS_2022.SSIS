﻿CREATE TABLE [dbo].[LookupLevelRating] (
    [ID]            INT          IDENTITY (1, 1) NOT NULL,
    [BondCat]       VARCHAR (50) NULL,
    [InvAssetType]  VARCHAR (50) NULL,
    [IssuerCountry] VARCHAR (50) NULL,
    [LevelRating]   VARCHAR (50) NULL,
    [Status]        VARCHAR (50) NULL,
    [EffectiveDate] DATETIME     NULL,
    CONSTRAINT [PK_LookupLevelRating] PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);

