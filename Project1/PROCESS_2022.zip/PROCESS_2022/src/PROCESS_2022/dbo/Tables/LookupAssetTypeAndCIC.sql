﻿CREATE TABLE [dbo].[LookupAssetTypeAndCIC] (
    [ID]           INT          IDENTITY (1, 1) NOT NULL,
    [BondCategory] VARCHAR (50) NULL,
    [InvAssetType] VARCHAR (50) NULL,
    [AssetType]    VARCHAR (50) NULL,
    [CIC]          VARCHAR (50) NULL,
    CONSTRAINT [PK_LookupAssetTypeAndCIC] PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);

