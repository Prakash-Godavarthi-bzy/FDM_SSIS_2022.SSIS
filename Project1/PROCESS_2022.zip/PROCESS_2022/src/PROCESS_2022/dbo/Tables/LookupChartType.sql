﻿CREATE TABLE [dbo].[LookupChartType] (
    [ID]            INT          IDENTITY (1, 1) NOT NULL,
    [GVT_GTD]       VARCHAR (50) NULL,
    [PayRateType]   VARCHAR (50) NULL,
    [BondCat]       VARCHAR (50) NULL,
    [ChartData]     VARCHAR (50) NULL,
    [Status]        VARCHAR (50) NULL,
    [EffectiveDate] DATETIME     NULL,
    CONSTRAINT [PK_LookupChartType] PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);

