﻿CREATE TABLE [dbo].[LookupEntityAndScenario] (
    [pk_LookupEntityAndScenario] INT          IDENTITY (1, 1) NOT NULL,
    [client]                     VARCHAR (25) NULL,
    [dim_3]                      VARCHAR (25) NULL,
    [EntityCode]                 VARCHAR (25) NULL,
    [ScenarioCode]               VARCHAR (25) NULL,
    CONSTRAINT [PK_LookupEntityAndScenario] PRIMARY KEY CLUSTERED ([pk_LookupEntityAndScenario] ASC) WITH (FILLFACTOR = 90)
);

