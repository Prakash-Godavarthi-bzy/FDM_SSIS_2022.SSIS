﻿CREATE TABLE [dbo].[LookupCountryDetails] (
    [ID]          NCHAR (10)   NOT NULL,
    [CountryCode] VARCHAR (50) NULL,
    [CountryName] VARCHAR (50) NULL,
    [Level]       VARCHAR (50) NULL,
    CONSTRAINT [PK_LookupCountryDetails] PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);

