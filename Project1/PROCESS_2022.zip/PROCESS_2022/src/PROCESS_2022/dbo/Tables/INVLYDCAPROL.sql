﻿CREATE TABLE [dbo].[INVLYDCAPROL] (
    [BatchId]                   VARCHAR (12)    NULL,
    [PackageID]                 VARCHAR (12)    NULL,
    [FileType]                  VARCHAR (12)    NULL,
    [Account_Description]       VARCHAR (255)   NULL,
    [Syndicate]                 VARCHAR (255)   NULL,
    [Notional_Principal_Amount] DECIMAL (28, 8) NULL,
    [Daily_Factor]              DECIMAL (28, 8) NULL,
    [CCY]                       VARCHAR (255)   NULL,
    [Local_CCY]                 DECIMAL (28, 8) NULL,
    [Unrealized_Gain]           DECIMAL (28, 8) NULL,
    [Realized_Gain]             DECIMAL (28, 8) NULL,
    [Unrealized_Income]         DECIMAL (28, 8) NULL,
    [Realised_Income]           DECIMAL (28, 8) NULL,
    [Management_Fees]           DECIMAL (28, 8) NULL,
    [Custody_Fees]              DECIMAL (28, 8) NULL,
    [import_date]               DATETIME        NULL,
    [ImportStatus]              VARCHAR (1)     NULL,
    [FilePeriod]                VARCHAR (50)    NULL,
    [agrtid]                    INT             IDENTITY (1, 1) NOT NULL,
    CONSTRAINT [PK_INVLYDCAPROL] PRIMARY KEY CLUSTERED ([agrtid] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ__INVLYDCA__1A3C812397FD6D29] UNIQUE NONCLUSTERED ([agrtid] ASC) WITH (FILLFACTOR = 90)
);

