﻿CREATE TABLE [dbo].[Lookup219LineNumber] (
    [ID]            INT          IDENTITY (1, 1) NOT NULL,
    [QMA219]        VARCHAR (50) NULL,
    [LineNumber]    VARCHAR (50) NULL,
    [Status]        VARCHAR (50) NULL,
    [EffectiveDate] DATETIME     NULL,
    CONSTRAINT [PK_Lookup219LineNumber] PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);

