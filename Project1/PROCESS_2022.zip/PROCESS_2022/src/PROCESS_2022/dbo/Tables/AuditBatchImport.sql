﻿CREATE TABLE [dbo].[AuditBatchImport] (
    [BatchImportID] INT           IDENTITY (1, 1) NOT NULL,
    [BatchId]       VARCHAR (12)  NOT NULL,
    [Package_Name]  VARCHAR (255) NOT NULL,
    [ImportTime]    DATETIME      NOT NULL,
    [ImportStatus]  VARCHAR (1)   NOT NULL,
    CONSTRAINT [PK_AuditBatchImport] PRIMARY KEY CLUSTERED ([BatchImportID] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ__AuditBat__448EBFBE45B0BED7] UNIQUE NONCLUSTERED ([BatchImportID] ASC) WITH (FILLFACTOR = 90)
);

