﻿CREATE TABLE [dbo].[AuditPackageSchedule] (
    [PackageId] VARCHAR (12) NOT NULL
);

