﻿CREATE TABLE [dbo].[JobPermissions] (
    [job_name]   NVARCHAR (128) NULL,
    [group_name] NVARCHAR (256) NULL
);

