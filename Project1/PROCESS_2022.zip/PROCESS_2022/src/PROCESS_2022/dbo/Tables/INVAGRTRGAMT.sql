﻿CREATE TABLE [dbo].[INVAGRTRGAMT] (
    [BatchId]       VARCHAR (12)    NULL,
    [PackageID]     VARCHAR (12)    NULL,
    [FileType]      VARCHAR (12)    NULL,
    [Entity]        VARCHAR (12)    NULL,
    [Trifocus_Code] VARCHAR (12)    NULL,
    [YOA1]          DECIMAL (28, 8) NULL,
    [YOA2]          DECIMAL (28, 8) NULL,
    [YOA3]          DECIMAL (28, 8) NULL,
    [agrtid]        INT             IDENTITY (1, 1) NOT NULL,
    [import_date]   DATETIME        NULL,
    [ImportStatus]  VARCHAR (1)     NULL,
    [FilePeriod]    VARCHAR (50)    NULL,
    CONSTRAINT [PK_INVAGRTRGAMT] PRIMARY KEY CLUSTERED ([agrtid] ASC) WITH (FILLFACTOR = 90)
);

