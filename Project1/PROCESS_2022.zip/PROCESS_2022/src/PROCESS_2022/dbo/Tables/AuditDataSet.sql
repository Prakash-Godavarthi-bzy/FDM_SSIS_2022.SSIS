﻿CREATE TABLE [dbo].[AuditDataSet] (
    [DataSetId]           INT           IDENTITY (1, 1) NOT NULL,
    [DataSetName]         VARCHAR (255) NOT NULL,
    [DataSetFinanceOwner] VARCHAR (255) NOT NULL,
    CONSTRAINT [PKAuditDataSet] PRIMARY KEY CLUSTERED ([DataSetId] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ__AuditDat__222C05DE6B27B15E] UNIQUE NONCLUSTERED ([DataSetId] ASC) WITH (FILLFACTOR = 90)
);

