﻿CREATE TABLE [dbo].[INVAGRBANKCODE] (
    [account]          VARCHAR (12)  NULL,
    [bankcode]         VARCHAR (12)  NULL,
    [bank_description] VARCHAR (255) NULL,
    [FilePeriod]       VARCHAR (50)  NULL,
    [agrtid]           INT           IDENTITY (1, 1) NOT NULL,
    CONSTRAINT [PK_INVAGRBANKCODE] PRIMARY KEY CLUSTERED ([agrtid] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ__INVAGRBA__1A3C8123381EBC45] UNIQUE NONCLUSTERED ([agrtid] ASC) WITH (FILLFACTOR = 90)
);

