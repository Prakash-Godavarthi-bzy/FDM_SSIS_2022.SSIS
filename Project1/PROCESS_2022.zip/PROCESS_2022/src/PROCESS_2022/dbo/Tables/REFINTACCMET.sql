﻿CREATE TABLE [dbo].[REFINTACCMET] (
    [pk_AccountMetric]       INT            IDENTITY (1000000, 1) NOT NULL,
    [AccountMetricCode]      NVARCHAR (255) NULL,
    [AccountMetricName]      NVARCHAR (255) NULL,
    [InUse]                  BIT            CONSTRAINT [DF_REFINTACCMET_InUse] DEFAULT ((1)) NOT NULL,
    [AccountMetricGroupCode] NVARCHAR (255) NULL,
    [AccountMetricGroupName] NVARCHAR (255) NULL,
    [AccountIsMoney]         NCHAR (1)      NULL,
    [AccountIsSnapshot]      NCHAR (1)      NULL,
    [FormatString]           NVARCHAR (255) NULL,
    [MDX]                    NVARCHAR (500) NULL,
    CONSTRAINT [PK_AccountMetric] PRIMARY KEY CLUSTERED ([pk_AccountMetric] ASC) WITH (FILLFACTOR = 90)
);

