﻿CREATE TABLE [dbo].[LookupBankName] (
    [ID]          INT           IDENTITY (1, 1) NOT NULL,
    [Account]     VARCHAR (50)  NULL,
    [Description] VARCHAR (255) NULL,
    [BankName]    VARCHAR (255) NULL,
    CONSTRAINT [PK_LookupBankName] PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);

