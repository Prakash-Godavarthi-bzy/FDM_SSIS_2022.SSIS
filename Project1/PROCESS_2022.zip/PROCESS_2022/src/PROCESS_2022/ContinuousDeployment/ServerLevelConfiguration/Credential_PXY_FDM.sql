﻿DECLARE @login_name SYSNAME, @user_name SYSNAME, @environment_name NVARCHAR (3)

SET @user_name = N'PXY_FDM'

-- set @login_name (for non-production: development) [default]
SET @login_name = N'BFL\' + @user_name + N'_DEV'

-- set @login_name (for production) based upon the 'Environment Name' extended property on 'master' database
SELECT @environment_name = CAST([value] AS NVARCHAR(3)) FROM [master].[sys].[fn_listextendedproperty] (NULL, NULL, NULL, NULL, NULL, NULL, NULL) WHERE [name] = N'Environment Name'
IF (@environment_name IS NULL)
    RAISERROR ('Login "%s" used for user "%s" - no environment specific value [extended property].', 10, 1, @login_name, @user_name)
ELSE IF (@environment_name IN ('PKG', 'PRD'))
    SET @login_name = N'BFL\' + @user_name + N'_PRD'
ELSE
    SET @login_name = N'BFL\' + @user_name + N'_' + @environment_name

IF (NOT EXISTS (SELECT 1 FROM [master].[sys].[server_principals] WHERE [name] = @login_name))
BEGIN
    RAISERROR ('Login "%s" does not exist for user "%s".', 16, 1, @login_name, @user_name)
    RETURN
END

IF (@user_name = N'SVC_[APPLICATION]')
BEGIN
    RAISERROR ('Login "%s" using template token value and must be modified [user_name].', 16, 1, @login_name)
    RETURN
END

IF (EXISTS (SELECT 1 FROM [sys].[database_principals] WHERE [name] = @user_name))
BEGIN
    EXECUTE ('DROP USER [' + @user_name + ']')
END

EXECUTE ('CREATE USER [' + @user_name + '] FOR LOGIN [' + @login_name + ']')
RAISERROR ('Login "%s" mapped to database user "%s".', 10, 1, @login_name, @user_name)

IF (EXISTS (SELECT 1 FROM [sys].[database_principals] WHERE [name] = @user_name))
BEGIN
    EXECUTE ('GRANT CONNECT TO [' + @user_name + ']')
    EXECUTE [sys].[sp_addrolemember] @rolename=N'db_owner', @membername=@user_name		
END




