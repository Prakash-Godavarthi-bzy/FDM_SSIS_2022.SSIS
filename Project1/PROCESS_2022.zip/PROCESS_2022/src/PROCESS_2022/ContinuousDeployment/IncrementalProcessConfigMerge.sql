﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

--SET NOCOUNT ON
--PRINT '***********[FDM_PROCESS].[Admin].[IncrementalProcessConfig]***********';
--DECLARE @dbo_IncrementalProcessConfig_start_time DATETIME2(7) = SYSDATETIME();
--DECLARE @dbo_IncrementalProcessConfig_split_time DATETIME2(7);
--DECLARE @dbo_IncrementalProcessConfig_time_char VARCHAR(20);
--DECLARE @dbo_IncrementalProcessConfig_interim_row_count INT = 0;
--DECLARE @dbo_IncrementalProcessConfig_row_count_char VARCHAR(10);
--DECLARE @dbo_IncrementalProcessConfig_rowcounts TABLE(mergeAction NVARCHAR(10));
--DECLARE @dbo_IncrementalProcessConfig_insertCount INT, @dbo_IncrementalProcessConfig_updateCount INT, @dbo_IncrementalProcessConfig_deleteCount INT;

DECLARE @IncrementalProcessConfig TABLE
(
	[ObjectID] [varchar](255) NOT NULL,
	[ObjectName] [varchar](255) NOT NULL,
	[ObjectType] [varchar](255) NOT NULL,
	[ParentObjectID] [varchar](255) NULL,
	[ParentObjectName] [varchar](255) NULL,
	[ProcessType] [varchar](50) NOT NULL,
	[ProcessAddElementName] [varchar](255) NULL,
	[ProcessAddQuery] [varchar](max) NULL,
	[ProcessAddTableName] [varchar](255) NULL,
	[AlwaysPartOfBatch] [bit] NOT NULL,
	[CubeID] [varchar](100) NULL,
	[CubeName] [varchar](100) NULL

)

INSERT @IncrementalProcessConfig([ObjectID],[ObjectName],[ObjectType],[ParentObjectID],[ParentObjectName],[ProcessType],[ProcessAddElementName],[ProcessAddQuery],[ProcessAddTableName],[AlwaysPartOfBatch],[CubeID],[CubeName])
VALUES 
('4dynamic','Dynamic','Partition','Fact FDM','Amounts','Full',NULL,'SELECT     fk_Account, fk_AccountingPeriod, fk_BusinessPlan, fk_ClaimExposure, fk_DataStage, fk_Entity, fk_Expense, fk_Holding, fk_LloydsClassifications, fk_Office,  fk_PolicySection, fk_Process, fk_Product, fk_Project, fk_RIPolicy,fk_Location, fk_Scenario, fk_SourceSystem, fk_TriFocus, fk_YOA, [Value], pk_FactFDM, value_3, value_2,   value_1, cur_amount, currency, fk_User, fk_client,[tax_code]  ,[tax_system], Dim2,[bk_TransactionID],[fk_special],[fk_classofbusiness], - 1 AS fk_AllocationRules, - 1 AS CombinationID,fk_DimEarnings,fk_PolicySectionv2,Fk_TargetEntity,Fk_TargetPeriod FROM FactFDM WHERE [bk_TransactionID] > ##ReplaceID##','FactFDM',0,'FinanceDataMart','FinanceDataMart'),
('Account','Account','Dimension','Account','Account','Update',NULL,NULL,NULL,1,NULL,NULL),
('Account Tree','Account Tree','Dimension','Account Tree','Account Tree','Update',NULL,NULL,NULL,1,NULL,NULL),
('Accounting Period','Accounting Period','Dimension','Accounting Period','Accounting Period','Update',NULL,NULL,NULL,1,NULL,NULL),
('Accounting Period Status','Accounting Period Status','Dimension','Accounting Period Status','Accounting Period Status','Update',NULL,NULL,NULL,1,NULL,NULL),
('Allocation Rules','Allocation Rules','Dimension','Allocation Rules','Allocation Rules','Update',NULL,NULL,NULL,1,NULL,NULL),
('Allocation Source','Allocation Source','Dimension','Allocation Source','Allocation Source','Update',NULL,NULL,NULL,0,NULL,NULL),
('AllocationDynamic','AllocationsDynamic','Partition','Fact FDM','Amounts','Full',NULL,NULL,NULL,0,'FinanceDataMart','FinanceDataMart'),
('Allocations','Allocations','Partition','Fact FDM','Amounts','Full',NULL,NULL,NULL,0,'FinanceDataMart','FinanceDataMart'),
('Bri Account Account Tree','Bri Account Account Tree','Partition','Bri Account Account Tree','Bri Account Account Tree','Full',NULL,NULL,NULL,1,'FinanceDataMart','FinanceDataMart'),
('Bri Entity Entity Tree','Bri Entity Entity Tree','Partition','Bri Entity Entity Tree','Bri Entity Entity Tree','Full',NULL,NULL,NULL,1,'FinanceDataMart','FinanceDataMart'),
('Bri Product Product Tree','Bri Product Product Tree','Partition','Bri Product Product Tree','Bri Product Product Tree','Full',NULL,NULL,NULL,1,'FinanceDataMart','FinanceDataMart'),
('Bri Trifocus Trifocus Tree','Bri Trifocus Trifocus Tree','Partition','Bri Trifocus Trifocus Tree','Bri Trifocus Trifocus Tree','Full',NULL,NULL,NULL,1,'FinanceDataMart','FinanceDataMart'),
('Class of Business','Class of Business','Dimension','Class of Business','Class of Business','Update',NULL,NULL,NULL,1,NULL,NULL),
('Cur Rate Scenario','Cur Rate Scenario','Dimension','Cur Rate Scenario','Cur Rate Scenario','Update',NULL,NULL,NULL,1,NULL,NULL),
('Cur Report Currency','Cur Reporting Currency','Dimension','Cur Report Currency','Cur Reporting Currency','Update',NULL,NULL,NULL,1,NULL,NULL),
('Dim Location','Location','Dimension','Dim Location','Location','Update',NULL,NULL,NULL,1,NULL,NULL),
('Earnings','Earnings','Dimension','Earnings','Earnings','Update',NULL,NULL,NULL,0,NULL,NULL),
('EIC Investment Income','EIC Investment Income','Partition','Fact FDM','Amounts','Full',NULL,NULL,NULL,0,'FinanceDataMart','FinanceDataMart'),
('Entity','Entity','Dimension','Entity','Entity','Update',NULL,NULL,NULL,1,NULL,NULL),
('Entity Tree','Entity Tree','Dimension','Entity Tree','Entity Tree','Update',NULL,NULL,NULL,1,NULL,NULL),
('Eurobase EPI Adjustments','Eurobase EPI Adjustments','Partition','Fact FDM','Amounts','Full',NULL,NULL,NULL,0,'FinanceDataMart','FinanceDataMart'),
('External EPI','External EPI','Partition','Fact FDM','Amounts','Full',NULL,NULL,NULL,0,'FinanceDataMart','FinanceDataMart'),
('External OverseasASL','External OverseasASL','Partition','Fact FDM','Amounts','Full',NULL,NULL,NULL,0,'FinanceDataMart','FinanceDataMart'),
('Fact FDMUW Patterns','Fact FDMUW Patterns','Partition','Fact FDMUW Patterns','UW Patterns','Full',NULL,NULL,NULL,0,'FinanceDataMart','FinanceDataMart'),
('Fact FX Rate','Fact FX Rate','Partition','Fact FX Rate','FX Rate','Full',NULL,NULL,NULL,1,'FinanceDataMart','FinanceDataMart'),
('Fact FX Rate Denom','Fact FX Rate Denom','Partition','Fact FX Rate Denom','FX Rate Step 2','Full',NULL,NULL,NULL,1,'FinanceDataMart','FinanceDataMart'),
('Fact Inception Rates','Fact Inception Rates','Partition','Fact Inception Rates','Inception Rates','Full',NULL,NULL,NULL,1,'FinanceDataMart','FinanceDataMart'),
('Fact US Premium Tax','Fact US Premium Tax','Partition','Fact US Premium Tax','US Premium Tax','Full',NULL,NULL,NULL,0,'FinanceDataMart','FinanceDataMart'),
('FX Rate','Cur FX Rate','Dimension','FX Rate','Cur FX Rate','Update',NULL,NULL,NULL,1,NULL,NULL),
('Holding','Holding','Dimension','Holding','Holding','Update',NULL,NULL,NULL,1,NULL,NULL),
('Inv Account','Inv Account','Dimension','Inv Account','Inv Account','Update',NULL,NULL,NULL,0,NULL,NULL),
('Inv Custodian','Inv Custodian','Dimension','Inv Custodian','Inv Custodian','Update',NULL,NULL,NULL,0,NULL,NULL),
('Inv Derivative','Inv Derivative','Dimension','Inv Derivative','Inv Derivative','Update',NULL,NULL,NULL,0,NULL,NULL),
('Inv Dim Holding Currency','Inv Holding Currency','Dimension','Inv Dim Holding Currency','Inv Holding Currency','Update',NULL,NULL,NULL,0,NULL,NULL),
('Inv Investment','Inv Investment','Dimension','Inv Investment','Inv Investment','Update',NULL,NULL,NULL,0,NULL,NULL),
('Inv Issuer','Inv Issuer','Dimension','Inv Issuer','Inv Issuer','Update',NULL,NULL,NULL,0,NULL,NULL),
('Inv Lloyds Reporting','Inv Lloyds Reporting','Dimension','Inv Lloyds Reporting','Inv Lloyds Reporting','Update',NULL,NULL,NULL,0,NULL,NULL),
('Inv Maturity','Inv Maturity','Dimension','Inv Maturity','Inv Maturity','Update',NULL,NULL,NULL,0,NULL,NULL),
('Inv Model','Inv Model','Dimension','Inv Model','Inv Model','Update',NULL,NULL,NULL,1,NULL,NULL),
('Inv Profit and Loss','Inv Profit and Loss','Dimension','Inv Profit and Loss','Inv Profit and Loss','Update',NULL,NULL,NULL,0,NULL,NULL),
('Inv Ratings and Levels','Inv Ratings and Levels','Dimension','Inv Ratings and Levels','Inv Ratings and Levels','Update',NULL,NULL,NULL,0,NULL,NULL),
('Inv TGK Reporting','Inv TGK Reporting','Dimension','Inv TGK Reporting','Inv TGK Reporting','Update',NULL,NULL,NULL,0,NULL,NULL),
('Investment Dynamic','Investment Dynamic','Partition','Fact Investment','Investment','Full',NULL,NULL,NULL,0,'FDM DB','Investments'),
('Investment Reporting','Investment Reporting','Partition','Fact FDM','Amounts','Full',NULL,NULL,NULL,0,'FinanceDataMart','FinanceDataMart'),
('Manual Import','Manual Import','Partition','Fact FDM','Amounts','Full',NULL,NULL,NULL,0,'FinanceDataMart','FinanceDataMart'),
('Policy Section New','Policy Section','Dimension','Policy Section New','Policy Section','Update',NULL,NULL,NULL,0,NULL,NULL),
('Premium Estimates','Premium Estimates','Partition','Fact FDM','Amounts','Full',NULL,NULL,NULL,0,'FinanceDataMart','FinanceDataMart'),
('Premium Forecast','Premium Forecast','Partition','Fact FDM','Amounts','Full',NULL,NULL,NULL,0,'FinanceDataMart','FinanceDataMart'),
('Process','Process','Dimension','Process','Process','Update',NULL,NULL,NULL,1,NULL,NULL),
('Product','Product','Dimension','Product','Product','Update',NULL,NULL,NULL,1,NULL,NULL),
('Product Tree','Product Tree','Dimension','Product Tree','Product Tree','Update',NULL,NULL,NULL,1,NULL,NULL),
('Profit Commission','Profit Commission','Partition','Fact FDM','Amounts','Full',NULL,NULL,NULL,0,'FinanceDataMart','FinanceDataMart'),
('Project','Project','Dimension','Project','Project','Update',NULL,NULL,NULL,1,NULL,NULL),
('Reporting Currency','Cur Bridge Currency','Dimension','Reporting Currency','Cur Bridge Currency','Update',NULL,NULL,NULL,1,NULL,NULL),
('RI Policy','RI Policy','Dimension','RI Policy','RI Policy','Update',NULL,NULL,NULL,0,NULL,NULL),
('RI Spend','RI Spend','Partition','Fact FDM','Amounts','Full',NULL,NULL,NULL,0,'FinanceDataMart','FinanceDataMart'),
('RIESCO Splits','RIESCO Splits','Partition','RIESCO Splits','RIESCO Splits','Full',NULL,NULL,NULL,0,'FDM DB','Investments'),
('RITC Current Year','RITC Current Year','Partition','Fact FDM','Amounts','Full',NULL,NULL,NULL,0,'FinanceDataMart','FinanceDataMart'),
('RITC Prior Years','RITC Prior Years','Partition','Fact FDM','Amounts','Full',NULL,NULL,NULL,0,'FinanceDataMart','FinanceDataMart'),
('Sec Rate Scenario','Sec Rate Scenario','Partition','Sec Rate Scenario','Sec Rate Scenario','Full',NULL,NULL,NULL,1,'FinanceDataMart','FinanceDataMart'),
('Sec User','Sec User','Dimension','Sec User','Sec User','Update',NULL,NULL,NULL,1,NULL,NULL),
('Settlement Currency','Cur Transaction Currency','Dimension','Settlement Currency','Cur Transaction Currency','Update',NULL,NULL,NULL,1,NULL,NULL),
('Special','Special','Dimension','Special','Special','Update',NULL,NULL,NULL,1,NULL,NULL),
('State','State','Dimension','State','State','Update',NULL,NULL,NULL,1,NULL,NULL),
('Target Entity','Target Entity','Dimension','Target Entity','Target Entity','Update',NULL,NULL,NULL,1,NULL,NULL),
('Target Period','Target Period','Dimension','Target Period','Target Period','Update',NULL,NULL,NULL,1,NULL,NULL),
('Transaction Details','Transaction Details','Dimension','Transaction Details','Transaction Details','Add','dbo_DimTransactionDetails','SELECT pk_FactFDM, bk_TransactionID, Description, ExtRef, ExtInvRef, VoucherNumber, insert_date, ap_ar_id, ap_ar_type, tax_code, tax_system, AccountingPeriod, MCVoucherNumber, transaction_date FROM dbo.DimTransactionDetailsV1_Current WHERE [bk_TransactionID] > ##ReplaceID##','DimTransactionDetails',0,NULL,NULL),
('Tri Focus','Tri Focus','Dimension','Tri Focus','Tri Focus','Update',NULL,NULL,NULL,1,NULL,NULL),
('Trifocus Tree','Trifocus Tree','Dimension','Trifocus Tree','Trifocus Tree','Update',NULL,NULL,NULL,1,NULL,NULL),
('US Stat Line','US Stat Line','Dimension','US Stat Line','US Stat Line','Update',NULL,NULL,NULL,1,NULL,NULL),
('User','User','Dimension','User','User','Update',NULL,NULL,NULL,1,NULL,NULL),
('Wizi Current Year','Wizi Current Year','Partition','Fact FDM','Amounts','Full',NULL,NULL,NULL,0,'FinanceDataMart','FinanceDataMart'),
('Wizi Prior Year','Wizi Prior Year','Partition','Fact FDM','Amounts','Full',NULL,NULL,NULL,0,'FinanceDataMart','FinanceDataMart'),
('YOA','YOA','Dimension','YOA','YOA','Update',NULL,NULL,NULL,1,NULL,NULL),
('YOA Group','YOA Group','Dimension','YOA Group','YOA Group','Update',NULL,NULL,NULL,1,NULL,NULL)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


MERGE [FDM_PROCESS].[Admin].[IncrementalProcessConfig] AS TGT
USING @IncrementalProcessConfig AS SRC

ON (

		ISNULL(TGT.[ObjectID],'') = ISNULL(SRC.[ObjectID],'') AND
		ISNULL(TGT.[ObjectName],'') = ISNULL(SRC.[ObjectName],'') AND
		ISNULL(TGT.[ObjectType],'') = ISNULL(SRC.[ObjectType],'') AND
		ISNULL(TGT.[ParentObjectID],'') = ISNULL(SRC.[ParentObjectID],'') AND
		ISNULL(TGT.[ParentObjectName],'') = ISNULL(SRC.[ParentObjectName],'') 

)
WHEN MATCHED AND

            ISNULL(TGT.[ProcessType],'') <> ISNULL(SRC.[ProcessType],'') OR
			ISNULL(TGT.[ProcessAddElementName],'') <> ISNULL(SRC.[ProcessAddElementName],'') OR
			ISNULL(TGT.[ProcessAddQuery],'') <> ISNULL(SRC.[ProcessAddQuery],'') OR
			ISNULL(TGT.[ProcessAddTableName],'') <> ISNULL(SRC.[ProcessAddTableName],'') OR
			ISNULL(TGT.[AlwaysPartOfBatch],'') <> ISNULL(SRC.[AlwaysPartOfBatch],'') OR
			ISNULL(TGT.[CubeID],'') <> ISNULL(SRC.[CubeID],'') OR		
			ISNULL(TGT.[CubeName],'') <> ISNULL(SRC.[CubeName],'') 

THEN

      UPDATE SET TGT.[ProcessType] = SRC.[ProcessType],
				 TGT.[ProcessAddElementName] = SRC.[ProcessAddElementName],
				 TGT.[ProcessAddQuery] = SRC.[ProcessAddQuery],
				 TGT.[ProcessAddTableName] = SRC.[ProcessAddTableName],
				 TGT.[AlwaysPartOfBatch] = SRC.[AlwaysPartOfBatch],
				 TGT.[CubeID] = SRC.[CubeID],
				 TGT.[CubeName] = SRC.[CubeName]
				 

WHEN NOT MATCHED BY TARGET THEN

      INSERT ([ObjectID],[ObjectName],[ObjectType],[ParentObjectID],[ParentObjectName],[ProcessType],[ProcessAddElementName],[ProcessAddQuery],[ProcessAddTableName],[AlwaysPartOfBatch],[CubeID],[CubeName])

      VALUES ([ObjectID],[ObjectName],[ObjectType],[ParentObjectID],[ParentObjectName],[ProcessType],[ProcessAddElementName],[ProcessAddQuery],[ProcessAddTableName],[AlwaysPartOfBatch],[CubeID],[CubeName])
	  ;
	  
--OUTPUT $action INTO @dbo_IncrementalProcessConfig_rowcounts;

--SET @dbo_IncrementalProcessConfig_split_time = SYSDATETIME();

--SET @dbo_IncrementalProcessConfig_time_char = CONVERT(VARCHAR(10),DATEDIFF(ss,@dbo_IncrementalProcessConfig_start_time,@dbo_IncrementalProcessConfig_split_time)) + ' seconds';

--SELECT @dbo_IncrementalProcessConfig_insertCount = SUM(CASE WHEN mergeAction = 'INSERT' THEN 1 ELSE 0 END),

--      @dbo_IncrementalProcessConfig_updatecount = SUM(CASE WHEN mergeAction = 'UPDATE' THEN 1 ELSE 0 END),

--      @dbo_IncrementalProcessConfig_deletecount = SUM(CASE WHEN mergeAction = 'DELETE' THEN 1 ELSE 0 END)

--FROM @dbo_IncrementalProcessConfig_rowcounts 

--PRINT '[FDM_PROCESS].[Admin].[IncrementalProcessConfig] @insertcount = ' + cast(ISNULL(@dbo_IncrementalProcessConfig_insertcount,0) as varchar(max)) + ' in ' + @dbo_IncrementalProcessConfig_time_char;

--PRINT '[FDM_PROCESS].[Admin].[IncrementalProcessConfig] @updatecount = ' + cast(ISNULL(@dbo_IncrementalProcessConfig_updatecount,0) as varchar(max)) + ' in ' + @dbo_IncrementalProcessConfig_time_char;

--PRINT '[FDM_PROCESS].[Admin].[IncrementalProcessConfig] @deletecount = ' + cast(ISNULL(@dbo_IncrementalProcessConfig_deletecount,0) as varchar(max)) + ' in ' + @dbo_IncrementalProcessConfig_time_char;

--PRINT '***********[FDM_PROCESS].[Admin].[IncrementalProcessConfig]***********';