﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

DECLARE @CubeProcessLockLog TABLE
(	[pk_ProcessLockLogID] INT IDENTITY(1,1) NOT NULL,
	[PackageName] [nvarchar](255) NOT NULL,
	[LockFlag] [int] NOT NULL

)

INSERT @CubeProcessLockLog([PackageName],[LockFlag])
VALUES 
('PremiumForecastStage.dtsx',0),
('RISpendStage.dtsx',0),
('EurobaseEPIAdjustments.dtsx',0),
('WiziMovements.dtsx',0),
('RITCMovements.dtsx',0),
('OYClaims.dtsx',0),
('EarningsCloseYOA.dtsx',0),
('PremiumEstimates.dtsx',0),
('FactUWPatterns.dtsx',0),
('Control.Allocations.dtsx',0),
('BIEPIProcessing.dtsx',0),
('EurobaseEPIProcessing.dtsx',0),
('InvestmentReportingPostModel.dtsx',0),
('InvestmentReportingRunModel.dtsx',0),
('ServiceCompanyCostPlus.dtsx',0),
('ProfitCommission.dtsx',0),
('AEUSPremiumSidecar.dtsx',0),
('AgressoPosting.dtsx',0),
('USPremiumTaxRate.dtsx',0),
('EICInvestments.dtsx',0),
('6107ORC.dtsx',0),
('6107PC.dtsx',0),
('6107InvestmentIncome.dtsx',0),
('OverseasandASLProcessing.dtsx',0),
('BIDACFDMTDMControlpackage.dtsx',0),
('BIDACProfitBeforeTax.dtsx',0),
('DimFXScenarios.dtsx.dtsx',0),
('BIDACBadDebts.dtsx',0) -- Added for FDM-475
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


MERGE [FDM_PROCESS].[Admin].[CubeProcessLockLog] AS TGT
USING @CubeProcessLockLog AS SRC

ON (

		ISNULL(TGT.pk_ProcessLockLogID,'') = ISNULL(SRC.pk_ProcessLockLogID,'') 
		
		--ISNULL(TGT.[PackageName],'') <> ISNULL(SRC.[PackageName],'') AND
		--ISNULL(TGT.[LockFlag],'') = ISNULL(SRC.[LockFlag],'') 
		

)

WHEN MATCHED AND
		
		ISNULL(TGT.[PackageName],'') <> ISNULL(SRC.[PackageName],'')

THEN UPDATE
	SET	 TGT.[PackageName]= SRC.[PackageName]
	

WHEN NOT MATCHED BY TARGET THEN

      INSERT ([PackageName],[LockFlag])

      VALUES ([PackageName],[LockFlag]);
