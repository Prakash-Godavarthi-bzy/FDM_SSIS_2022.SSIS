/*SQL Server Agent Job-FDM_RestartSSASService --Start*/
--BEGIN TRANSACTION
--DECLARE @ReturnCode INT
--DECLARE @jobId BINARY(16)
--SELECT @ReturnCode = 0
----SQL JOB-FDM_RestartSSASService Job Creation
--IF NOT EXISTS(SELECT 'x' FROM msdb.dbo.sysjobs WHERE NAME='FDM_RestartSSASService')
--BEGIN
--	IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
--		BEGIN
--			EXEC msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
--			IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
--		END

--	EXEC @ReturnCode = msdb.dbo.sp_add_job @job_name=N'FDM_RestartSSASService', 
--			@enabled=0, 
--			@notify_level_eventlog=0, 
--			@notify_level_email=0, 
--			@notify_level_netsend=0, 
--			@notify_level_page=0, 
--			@delete_level=0, 
--			@description=N'Overnight FDM Update.', 
--			@category_name=N'[Uncategorized (Local)]', 
--			@owner_login_name=N'BFL\Beazley_Reader', @job_id = @jobId OUTPUT
--	IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
--  EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
--  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
--END

----SQL JOB-FDM_RestartSSASService Steps Creation
--	IF EXISTS (SELECT 'X' FROM msdb.dbo.sysjobs A JOIN msdb.dbo.sysjobsteps B
--			   ON A.job_id=B.job_id
--			   WHERE A.NAME='FDM_RestartSSASService')
--		BEGIN 
--			EXEC msdb.dbo.sp_delete_jobstep  
--				@job_name = N'FDM_RestartSSASService',  
--				@step_id = 0 ;
--		END

--	EXEC @ReturnCode = msdb.dbo.sp_add_jobstep
--		@job_name = N'FDM_RestartSSASService', 
--		@step_name=N'Disable FDM_Intraday', 
--		@step_id=1, 
--		@cmdexec_success_code=0, 
--		@on_success_action=4, 
--		@on_success_step_id=2, 
--		@on_fail_action=2,--4, 
--		@on_fail_step_id=2, 
--		@retry_attempts=0, 
--		@retry_interval=0, 
--		@os_run_priority=0, 
--		@subsystem=N'TSQL', 
--		@command=N'exec msdb..sp_update_job @job_name = ''FDM_Intraday'', @enabled = 0

--DECLARE @WaitFlag INT,
--		@JOB_NAME NVARCHAR(100),
--        @JOB_ID AS UNIQUEIDENTIFIER,
--        @StopDate DATETIME;

--SET @JOB_NAME = N''FDM_ExternalFeed'';

--set @WaitFlag = (SELECT count(*) FROM FDM_Process.ADMIN.RunProcessLog 
--				 where module not in (''Overnight'',''Intraday Update'') and status = ''Processing'' and EndTime is null and createddate >= getDate()-1);

--WHILE @WaitFlag >= 1
--BEGIN
--WAITFOR DELAY ''00:00:05''
--set @WaitFlag = (SELECT count(*) FROM  FDM_Process.ADMIN.RunProcessLog 
--				 where module not in (''Overnight'',''Intraday Update'') and status = ''Processing'' and EndTime is null and createddate >= getDate()-1)
--END;

--SELECT @JOB_ID = JOB_ID 
--FROM MSDB.DBO.SYSJOBS 
--WHERE NAME=@JOB_NAME;
                  
--SELECT TOP 1 @StopDate = STOP_EXECUTION_DATE
--FROM MSDB.DBO.SYSJOBACTIVITY 
--WHERE JOB_ID=@JOB_ID
--ORDER BY START_EXECUTION_DATE DESC;
          
--IF @StopDate IS NULL    
--	  EXEC msdb.dbo.sp_stop_job @job_name;

--	  set @WaitFlag = (SELECT COUNT(*) FROM FDM_Process.ADMIN.RunProcessLog 
--					WHERE Module IN (''Intraday Update'',''Overnight'')
--						AND Starttime >= getDate()-1 and EndTime is null);
--WHILE @WaitFlag >= 1
--BEGIN
--	WAITFOR DELAY ''00:00:05''
--	set @WaitFlag = (SELECT COUNT(*) FROM FDM_Process.ADMIN.RunProcessLog 
--					  WHERE Module IN (''Intraday Update'',''Overnight'')
--					  AND Starttime >= getDate()-1 and EndTime is null)
--END;', 
--		@database_name=N'msdb', 
--		@flags=0


--IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

--		EXEC @ReturnCode = msdb.dbo.sp_add_jobstep 
--		@job_name = N'FDM_RestartSSASService',
--		@step_name=N'Restart-SSAS-Service', 
--		@step_id=2, 
--		@cmdexec_success_code=0, 
--		@on_success_action=4,--3, 
--		@on_success_step_id=3, --0
--		@on_fail_action=3, 
--		@on_fail_step_id=0, 
--		@retry_attempts=3, 
--		@retry_interval=0, 
--		@os_run_priority=0, @subsystem=N'PowerShell', 
--		@command=N'
--[String]$ServiceName="MSOLAP`$UKAC01"


--[System.Collections.ArrayList]$ServicesToRestart = @()

--function Custom-GetDependServices ($ServiceInput)
--{
	
--	If ($ServiceInput.DependentServices.Count -gt 0)
--	{
--		ForEach ($DepService in $ServiceInput.DependentServices)
--		{
			
--			If ($DepService.Status -eq "Running")
--			{
				
--				$CurrentService = Get-Service -Name $DepService.Name
				
--                # get dependancies of running service
--				Custom-GetDependServices $CurrentService                
--			}
--			Else
--			{
				
--			}
			
--		}
--	}

--    if ($ServicesToRestart.Contains($ServiceInput.Name) -eq $false)
--    {
--        $ServicesToRestart.Add($ServiceInput.Name)
--    }
--}

--# Get the main service
--$Service = Get-Service -Name $ServiceName

--# Get dependancies and stop order
--Custom-GetDependServices -ServiceInput $Service


--foreach($ServiceToStop in $ServicesToRestart)
--{
    
--    Stop-Service $ServiceToStop -Verbose #-Force
--}

--$ServicesToRestart.Reverse()

--foreach($ServiceToStart in $ServicesToRestart)
--{
    
--    Start-Service $ServiceToStart -Verbose
--}


--', 
--		@database_name=N'master', 
--		@flags=0
--IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback		

--		EXEC @ReturnCode = msdb.dbo.sp_add_jobstep 
--		@job_name = N'FDM_RestartSSASService', 
--		@step_name=N'Enable FDM_Intraday', 
--		@step_id=3, 
--		@cmdexec_success_code=0, 
--		@on_success_action=1, 
--		@on_success_step_id=0, 
--		@on_fail_action=2, 
--		@on_fail_step_id=0, 
--		@retry_attempts=0, 
--		@retry_interval=0, 
--		@os_run_priority=0, @subsystem=N'TSQL', 
--		@command=N'exec msdb..sp_update_job @job_name = ''FDM_Intraday'', @enabled = 1', 
--		@database_name=N'master', 
--		@flags=0
--	IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback	

----SQLJOB-FDM_RestartSSASService Schedule Creation

--IF EXISTS(SELECT 'x' FROM msdb.dbo.sysjobs A JOIN msdb.dbo.sysjobschedules B
--			   ON A.job_id=B.job_id
--			   WHERE A.NAME='FDM_RestartSSASService')
--	BEGIN
--		DECLARE @Schedule_name1  nvarchar(100)
--					SELECT @Schedule_name1= C.NAME FROM msdb.dbo.sysjobs A join msdb.dbo.sysjobschedules B
--										   ON A.job_id=B.job_id
--										   JOIN msdb.dbo.sysschedules C ON B.schedule_id=C.schedule_id
--										   WHERE A.NAME='FDM_RestartSSASService'

--					EXEC msdb.dbo.sp_delete_schedule  
--						 @schedule_name = @Schedule_name1,
--						 @force_delete = 1;  
--	END

--	EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule 
--				@job_name = 'FDM_RestartSSASService', 
--				@name=N'SSAS Restart for every 1 week on Saturday at 12:01 AM UK time', 
--				@enabled=1, 
--				@freq_type=8, 
--				@freq_interval=64, 
--				@freq_subday_type=1, 
--				@freq_subday_interval=0, 
--				@freq_relative_interval=0, 
--				@freq_recurrence_factor=1, 
--				@active_start_date=20201021, 
--				@active_end_date=99991231, 
--				@active_start_time=100, 
--				@active_end_time=235959
--IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
--COMMIT TRANSACTION
--GOTO EndSave
--QuitWithRollback:
--    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
--EndSave:

/*SQL Server Agent Job-FDM_RestartSSASService --End*/




/*******SQL Server Agent Job-FDM_Overnight --Start******/

BEGIN TRANSACTION
DECLARE @ReturnCode1 INT
DECLARE @jobId1 BINARY(16)
	
SELECT @ReturnCode1 = 0
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode1 = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode1 <> 0) GOTO QuitWithRollback1

END

--SQL JOB-FDM_Overnight Job Creation
IF NOT EXISTS(SELECT 'x' FROM msdb.dbo.sysjobs WHERE NAME='FDM_Overnight')
BEGIN
	EXEC @ReturnCode1 =	msdb.dbo.sp_add_job @job_name=N'FDM_Overnight', 
			@enabled=1, 
			@notify_level_eventlog=0, 
			@notify_level_email=0, 
			@notify_level_netsend=0, 
			@notify_level_page=0, 
			@delete_level=0, 
			@description=N'KB0011683
KB0011681', 
			@category_name=N'[Uncategorized (Local)]', 
			@owner_login_name=N'BFL\Beazley_Reader', @job_id = @jobId1 OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode1 <> 0) GOTO QuitWithRollback1
EXEC @ReturnCode1 = msdb.dbo.sp_add_jobserver @job_id = @jobId1, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode1 <> 0) GOTO QuitWithRollback1
END

--SQL JOB-FDM_Overnight Job Steps Creation
IF EXISTS (SELECT 'X' FROM msdb.dbo.sysjobs A JOIN msdb.dbo.sysjobsteps B
			   ON A.job_id=B.job_id
			   WHERE A.NAME='FDM_Overnight')
		BEGIN 
			EXEC msdb.dbo.sp_delete_jobstep  
				@job_name = N'FDM_Overnight',  
				@step_id = 0 ;
		END

	DECLARE @Env NVARCHAR(20) = (SELECT CAST(reference_id AS varchar) 
								FROM SSISDB.internal.environment_references A 
								join SSISDB.internal.projects B
								ON A.project_id=B.project_id
								JOIN SSISDB.internal.folders C
								ON B.folder_id=C.folder_id
								WHERE B.NAME='FDM_SSIS' AND A.environment_name='FDM_SSIS' AND C.NAME='FDM')

	DECLARE @Command5 NVARCHAR(4000) = '/ISSERVER "\"\SSISDB\FDM\FDM_SSIS\1 Control Load FDM.dtsx\"" /SERVER "\"$(Param_Target_FDMInstance)\"" /ENVREFERENCE ' + @Env + ' /Par "\"IncrementalLoad(Boolean)\"";False /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'
	
			EXEC @ReturnCode1 = msdb.dbo.sp_add_jobstep
				@job_name=N'FDM_Overnight', 
				@step_name=N'Disable FDM_Intraday', 
				@step_id=1, 
				@cmdexec_success_code=0, 
				@on_success_action=3, 
				@on_success_step_id=0, 
				@on_fail_action=2, 
				@on_fail_step_id=0, 
				@retry_attempts=5, 
				@retry_interval=2, 
				@os_run_priority=0, 
				@subsystem=N'TSQL', 
				@command=N'use msdb 
	go

	-- This is polling to see if the external data feed and intraday jobs are finished.
	-- Original version details unknown
	-- Code neatly formatted by John T (with Nanda witnessing) on 8 Mar 2019

	DECLARE 
			@msg varchar(1000),
			@WaitFlag INT,
			@JOB_NAME NVARCHAR(100),
			@JOB_ID1 AS UNIQUEIDENTIFIER,
			@StopDate DATETIME;


	exec dbo.sp_update_job  
			@job_name = ''FDM_Intraday'', 
			@enabled = 0;

	exec dbo.sp_bzy_print ''sp_update_job'';

	SET @JOB_NAME = N''FDM_ExternalFeed'';

	set @WaitFlag = (
			SELECT 
					count(*) 
			FROM 
					FDM_Process.ADMIN.RunProcessLog 
			where 
					1 = 1
					and module not in (''Overnight'',''Intraday Update'') 
					and [status] = ''Processing'' 
					and EndTime is null 
					and createddate >= getDate()-1
	);
	set @msg = ''@WaitFlag (not in loop) = '' + convert(varchar(10), @WaitFlag);
	exec dbo.sp_bzy_print @msg;

	WHILE @WaitFlag >= 1 BEGIN
			WAITFOR DELAY ''00:00:05''
			set @WaitFlag = (
					SELECT 
							count(*) 
					FROM -- select * from 
							FDM_Process.ADMIN.RunProcessLog 
					where 
							1 = 1
							and module not in (''Overnight'',''Intraday Update'') 
							and [status] = ''Processing'' 
							and EndTime is null 
							and createddate >= getDate()-1
			);
			--set @WaitFlag = (SELECT count(*) FROM  FDM_Process.ADMIN.RunProcessLog  where module not in (''Overnight'',''Intraday Update'') and status = ''Processing'' and EndTime is null and createddate >= getDate()-1)
			set @msg = ''@WaitFlag = '' + convert(varchar(10), @WaitFlag);
			exec dbo.sp_bzy_print @msg;
	END;

	SELECT 
			@JOB_ID1 = JOB_ID 
	FROM 
			dbo.sysjobs 
	WHERE 
			name=@JOB_NAME;

	set @msg = ''@JOB_NAME = '' + @JOB_NAME;
	exec dbo.sp_bzy_print @msg;

                  
	SELECT TOP 1 
			@StopDate = STOP_EXECUTION_DATE
	FROM 
			dbo.sysjobactivity 
	WHERE 
			job_id=@JOB_ID1
	ORDER BY 
			start_execution_date DESC;

	set @msg = ''@StopDate = '' + isnull(convert(varchar(26), @StopDate, 120), ''<null>'');
	exec dbo.sp_bzy_print @msg;

	IF @StopDate IS NULL begin
			EXEC msdb.dbo.sp_stop_job @job_name;
			exec dbo.sp_bzy_print ''job stopped'';
	end

	',  
				@database_name=N'msdb', 
				@flags=0
	IF (@@ERROR <> 0 OR @ReturnCode1 <> 0) GOTO QuitWithRollback1

			EXEC @ReturnCode1 = msdb.dbo.sp_add_jobstep
				@job_name=N'FDM_Overnight', 
				@step_name=N'go', 
				@step_id=2, 
				@cmdexec_success_code=0, 
				@on_success_action=3, 
				@on_success_step_id=0, 
				@on_fail_action=3, 
				@on_fail_step_id=0, 
				@retry_attempts=2, 
				@retry_interval=10, 
				@os_run_priority=0, 
				@subsystem=N'SSIS', 
				@command=@Command5, 
				@database_name=N'master', 
				@flags=0, 
				@proxy_name=N'$(SSISProxyName)'
IF (@@ERROR <> 0 OR @ReturnCode1 <> 0) GOTO QuitWithRollback1

			EXEC @ReturnCode1 =  msdb.dbo.sp_add_jobstep
				@job_name=N'FDM_Overnight', 
				@step_name=N'Enable FDM_Intraday', 
				@step_id=3, 
				@cmdexec_success_code=0, 
				@on_success_action=1, 
				@on_success_step_id=0, 
				@on_fail_action=2, 
				@on_fail_step_id=0, 
				@retry_attempts=5, 
				@retry_interval=2, 
				@os_run_priority=0, @subsystem=N'TSQL', 
				@command=N'DECLARE @WaitFlag INT=0

set @WaitFlag = 
(
SELECT COUNT(*) 
FROM FDM_PROCESS.ADMIN.RunProcessLog 
WHERE Module = ''QMADataForReporting'' AND 
CAST(StartTime AS DATE)=CAST(GETDATE() AS DATE) AND 
EndTime IS NULL AND 
Status = ''Processing'' AND
CreatedBy=''FDM'' AND
RunProcessLogID = (SELECT MAX(RunProcessLogID) FROM FDM_PROCESS.Admin.RunProcessLog) AND
GETDATE()<CAST(CAST(CAST(GETDATE() AS DATE) AS VARCHAR)+'' 07:00:00.000'' AS DATETIME)
)

WHILE @WaitFlag >= 1
BEGIN
WAITFOR DELAY ''00:00:30''
set @WaitFlag = 
(
SELECT COUNT(*) 
FROM FDM_PROCESS.ADMIN.RunProcessLog 
WHERE Module = ''QMADataForReporting'' AND 
CAST(StartTime AS DATE)=CAST(GETDATE() AS DATE) AND 
EndTime IS NULL AND 
Status = ''Processing'' AND
CreatedBy=''FDM'' AND
RunProcessLogID = (SELECT MAX(RunProcessLogID) FROM FDM_PROCESS.Admin.RunProcessLog) AND
GETDATE()<CAST(CAST(CAST(GETDATE() AS DATE) AS VARCHAR)+'' 07:00:00.000'' AS DATETIME)
)
END

exec msdb..sp_update_job @job_name = ''FDM_Intraday'', @enabled = 1', 
				@database_name=N'master', 
				@flags=0
	IF (@@ERROR <> 0 OR @ReturnCode1 <> 0) GOTO QuitWithRollback1
	SELECT @jobId1=job_id FROM msdb.dbo.sysjobs where name='FDM_Overnight'
	EXEC @ReturnCode1 = msdb.dbo.sp_update_job @job_id = @jobId1, @start_step_id = 1
	IF (@@ERROR <> 0 OR @ReturnCode1 <> 0) GOTO QuitWithRollback1

--SQL Jobs-FDM_Overnight Schedule Creation
IF EXISTS(SELECT 'x' FROM msdb.dbo.sysjobs A JOIN msdb.dbo.sysjobschedules B
			   ON A.job_id=B.job_id
			   WHERE A.NAME='FDM_Overnight')
	BEGIN
		DECLARE @Schedule_name  nvarchar(100)
					SELECT @Schedule_name= C.NAME FROM msdb.dbo.sysjobs A join msdb.dbo.sysjobschedules B
										   ON A.job_id=B.job_id
										   JOIN msdb.dbo.sysschedules C ON B.schedule_id=C.schedule_id
										   WHERE A.NAME='FDM_Overnight'

					EXEC msdb.dbo.sp_delete_schedule  
						 @schedule_name = @Schedule_name,
						 @force_delete = 1;  
	END

	EXEC @ReturnCode1 = msdb.dbo.sp_add_jobschedule 
				@job_name = 'FDM_Overnight', 
				@name=N'2am or thereabouts', 
				@enabled=1, 
				@freq_type=4, 
				@freq_interval=1, 
				@freq_subday_type=1, 
				@freq_subday_interval=0, 
				@freq_relative_interval=0, 
				@freq_recurrence_factor=0, 
				@active_start_date=20150507, 
				@active_end_date=99991231, 
				@active_start_time=15700, 
				@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode1 <> 0) GOTO QuitWithRollback1
COMMIT TRANSACTION
GOTO EndSave1
QuitWithRollback1:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave1:
/*******SQL Server Agent Job-FDM_Overnight --End*******/	

/********SQL Server Agent Job-FDM_Intraday --Start*******/
BEGIN TRANSACTION
DECLARE @ReturnCode2 INT
DECLARE @jobId2 BINARY(16)
SELECT  @ReturnCode2 = 0

IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode2 = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode2 <> 0) GOTO QuitWithRollback2

END
--SQL JOB-FDM_Intraday Job Creation
IF NOT EXISTS(SELECT 'x' FROM msdb.dbo.sysjobs WHERE NAME='FDM_Intraday')
BEGIN
	EXEC @ReturnCode2 = msdb.dbo.sp_add_job @job_name=N'FDM_Intraday', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'
IntraDay FDM Update from Agresso which is a top up to the FDM cube, 
overnight FULL process of the cube occurs also in a different job. 
For context it can be considered like a tlog backup.
', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'BFL\Beazley_Reader', @job_id = @jobId2 OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode2 <> 0) GOTO QuitWithRollback2
EXEC @ReturnCode2 = msdb.dbo.sp_add_jobserver @job_id = @jobId2, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode2 <> 0) GOTO QuitWithRollback2
END

--SQL JOB-FDM_Intraday Steps Creation
	IF EXISTS (SELECT 'X' FROM msdb.dbo.sysjobs A JOIN msdb.dbo.sysjobsteps B
			   ON A.job_id=B.job_id
			   WHERE A.NAME='FDM_Intraday')
		BEGIN 
			EXEC msdb.dbo.sp_delete_jobstep  
				@job_name = N'FDM_Intraday',  
				@step_id = 0 ;
		END

	DECLARE @Env1 NVARCHAR(20) = (SELECT CAST(reference_id AS varchar) 
								FROM SSISDB.internal.environment_references A 
								join SSISDB.internal.projects B
								ON A.project_id=B.project_id
								JOIN SSISDB.internal.folders C
								ON B.folder_id=C.folder_id
								WHERE B.NAME='FDM_SSIS' AND A.environment_name='FDM_SSIS' AND C.NAME='FDM')

	DECLARE @Command2 NVARCHAR(4000) = '/ISSERVER "\"\SSISDB\FDM\FDM_SSIS\1 Control Load FDM.dtsx\"" /SERVER "\"$(Param_Target_FDMInstance)\"" /ENVREFERENCE ' +@Env1 + ' /Par "\"IncrementalLoad(Boolean)\"";True /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'

	EXEC @ReturnCode2 =  msdb.dbo.sp_add_jobstep
			@job_name=N'FDM_Intraday', 
			@step_name=N'Check Scheduling Package Is Running', 
			@step_id=1, 
			@cmdexec_success_code=0, 
			@on_success_action=3, 
			@on_success_step_id=0, 
			@on_fail_action=3, 
			@on_fail_step_id=0, 
			@retry_attempts=0, 
			@retry_interval=0, 
			@os_run_priority=0, 
			@subsystem=N'TSQL', 
			@command=N'DECLARE @JOB_NAME SYSNAME = N''FDM_ExternalFeed''; 
IF NOT EXISTS(     
        select 1 
        from msdb.dbo.sysjobs_view job  
        inner join msdb.dbo.sysjobactivity activity on job.job_id = activity.job_id 
        where  
            activity.run_Requested_date is not null  
        and activity.stop_execution_date is null  
        and job.name = @JOB_NAME 
        ) 
BEGIN      
    PRINT ''Starting job '''''' + @JOB_NAME + ''''''''; 
    EXEC msdb.dbo.sp_start_job @JOB_NAME; 
END',  
			@database_name=N'master', 
			@flags=0
IF (@@ERROR <> 0 OR @ReturnCode2 <> 0) GOTO QuitWithRollback2			

			EXEC @ReturnCode2 = msdb.dbo.sp_add_jobstep
			@job_name=N'FDM_Intraday', 
			@step_name=N'IntraDay', 
			@step_id=2, 
			@cmdexec_success_code=0, 
			@on_success_action=1, 
			@on_success_step_id=0, 
			@on_fail_action=2, 
			@on_fail_step_id=0, 
			@retry_attempts=0, 
			@retry_interval=0, 
			@os_run_priority=0, 
			@subsystem=N'SSIS', 
			@command=@Command2, 
			@database_name=N'master', 
			@flags=0, 
			@proxy_name=N'$(SSISProxyName)'
IF (@@ERROR <> 0 OR @ReturnCode2 <> 0) GOTO QuitWithRollback2
SELECT @jobId2=job_id FROM msdb.dbo.sysjobs where name='FDM_Intraday'
EXEC @ReturnCode2 = msdb.dbo.sp_update_job @job_id = @jobId2, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode2 <> 0) GOTO QuitWithRollback2

--SQL Jobs-FDM_Intraday Schedule Creation
IF EXISTS(SELECT 'x' FROM msdb.dbo.sysjobs A JOIN msdb.dbo.sysjobschedules B
		   ON A.job_id=B.job_id
		   WHERE A.NAME='FDM_Intraday')
BEGIN
	EXEC msdb.dbo.sp_delete_schedule  
						 @schedule_name = N'realtime',
						 @force_delete = 1;
END	
	 EXEC @ReturnCode2 = msdb.dbo.sp_add_jobschedule 
					@job_name=N'FDM_Intraday', 
					@name=N'realtime', 
					@enabled=1, 
					@freq_type=4, 
					@freq_interval=1, 
					@freq_subday_type=4, 
					@freq_subday_interval=2, 
					@freq_relative_interval=0, 
					@freq_recurrence_factor=0, 
					@active_start_date=20150120, 
					@active_end_date=99991231, 
					@active_start_time=20200, 
					@active_end_time=14500 
IF (@@ERROR <> 0 OR @ReturnCode2 <> 0) GOTO QuitWithRollback2
COMMIT TRANSACTION
GOTO EndSave2
QuitWithRollback2:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave2:
/******SQL Server Agent Job-FDM_Intraday --End*******/

/*******SQL Server Agent Job-FDM_ExternalFeed --Start*********/
BEGIN TRANSACTION
DECLARE @ReturnCode3 INT
DECLARE @jobId3 BINARY(16)
SELECT @ReturnCode3 = 0

IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode3 = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode3 <> 0) GOTO QuitWithRollback3
END

--SQL JOB-FDM_ExternalFeed Job Creation
IF NOT EXISTS(SELECT 'x' FROM msdb.dbo.sysjobs WHERE NAME='FDM_ExternalFeed')
BEGIN
	
	EXEC @ReturnCode3 = msdb.dbo.sp_add_job @job_name=N'FDM_ExternalFeed', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'FDM Update from ExternalFeeds like GrossUlt or bobDB etc.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'BFL\Beazley_Reader', @job_id = @jobId3 OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode3 <> 0) GOTO QuitWithRollback3
EXEC @ReturnCode3 = msdb.dbo.sp_add_jobserver @job_id = @jobId3, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode3 <> 0) GOTO QuitWithRollback3
END

--SQL JOB-FDM_ExternalFeed Steps Creation
	IF EXISTS (SELECT 'X' FROM msdb.dbo.sysjobs A JOIN msdb.dbo.sysjobsteps B
			   ON A.job_id=B.job_id
			   WHERE A.NAME='FDM_ExternalFeed')
		BEGIN 
			EXEC msdb.dbo.sp_delete_jobstep  
				@job_name = N'FDM_ExternalFeed',  
				@step_id = 0 ;
		END

	DECLARE @Env2 NVARCHAR(20) = (SELECT CAST(reference_id AS varchar) 
								FROM SSISDB.internal.environment_references A 
								join SSISDB.internal.projects B
								ON A.project_id=B.project_id
								JOIN SSISDB.internal.folders C
								ON B.folder_id=C.folder_id
								WHERE B.NAME='FDM_SSIS' AND A.environment_name='FDM_SSIS' AND C.NAME='FDM')

	DECLARE @Command NVARCHAR(4000) = '/ISSERVER "\"\SSISDB\FDM\FDM_SSIS\ControlRunFDMProcess.dtsx\"" /SERVER "\"$(Param_Target_FDMInstance)\"" /ENVREFERENCE ' + @Env2 + ' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";2 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'
	
	EXEC @ReturnCode3 =  msdb.dbo.sp_add_jobstep
			@job_name=N'FDM_ExternalFeed', 
			@step_name=N'go', 
			@step_id=1, 
			@cmdexec_success_code=0, 
			@on_success_action=1, 
			@on_success_step_id=0, 
			@on_fail_action=2,  
			@on_fail_step_id=0, 
			@retry_attempts=0, 
			@retry_interval=0, 
			@os_run_priority=0, 
			@subsystem=N'SSIS', 
			@command=@Command, 
			@database_name=N'master', 
			@flags=0, 
			@proxy_name=N'$(SSISProxyName)'
IF (@@ERROR <> 0 OR @ReturnCode3 <> 0) GOTO QuitWithRollback3
SELECT @jobId3=job_id FROM msdb.dbo.sysjobs where name='FDM_ExternalFeed'
EXEC @ReturnCode3 = msdb.dbo.sp_update_job @job_id = @jobId3, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode3 <> 0) GOTO QuitWithRollback3
COMMIT TRANSACTION
GOTO EndSave3
QuitWithRollback3:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave3:

/*SQL Server Agent Job-FDM_ExternalFeed --End*/

/********SQL Server Agent Job-FDM_to_Drake --Start*******/
BEGIN TRANSACTION
DECLARE @ReturnCode4 INT
DECLARE @jobId4 BINARY(16)
SELECT  @ReturnCode4 = 0

IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode4 = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode4 <> 0) GOTO QuitWithRollback4

END
--SQL JOB-FDM_to_Drake Job Creation
IF NOT EXISTS(SELECT 'x' FROM msdb.dbo.sysjobs WHERE NAME='FDM_to_Drake')
BEGIN
	EXEC @ReturnCode4 = msdb.dbo.sp_add_job @job_name=N'FDM_to_Drake', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'
FDM_to_Drake is a data delivery job, where data from FACTFDM
to a table in Drake server', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'BFL\Beazley_Reader', @job_id = @jobId4 OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode4 <> 0) GOTO QuitWithRollback4
EXEC @ReturnCode4 = msdb.dbo.sp_add_jobserver @job_id = @jobId4, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode4 <> 0) GOTO QuitWithRollback4
END

--SQL JOB-FDM_to_Drake Steps Creation
	IF EXISTS (SELECT 'X' FROM msdb.dbo.sysjobs A JOIN msdb.dbo.sysjobsteps B
			   ON A.job_id=B.job_id
			   WHERE A.NAME='FDM_to_Drake')
		BEGIN 
			EXEC msdb.dbo.sp_delete_jobstep  
				@job_name = N'FDM_to_Drake',  
				@step_id = 0 ;
		END

	DECLARE @Env4 NVARCHAR(20) = (SELECT CAST(reference_id AS varchar) 
								FROM SSISDB.internal.environment_references A 
								join SSISDB.internal.projects B
								ON A.project_id=B.project_id
								JOIN SSISDB.internal.folders C
								ON B.folder_id=C.folder_id
								WHERE B.NAME='FDM_SSIS' AND A.environment_name='FDM_SSIS' AND C.NAME='FDM')

	DECLARE @Command3 NVARCHAR(4000) = '/ISSERVER "\"\SSISDB\FDM\FDM_SSIS\DrakeReporting.dtsx\"" /SERVER "\"$(Param_Target_FDMInstance)\"" /ENVREFERENCE ' +@Env4 + ' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'
		
			EXEC @ReturnCode4 = msdb.dbo.sp_add_jobstep
			@job_name=N'FDM_to_Drake', 
			@step_name=N'Kick-off Drake', 
			@step_id=1, 
			@cmdexec_success_code=0, 
			@on_success_action=1, 
			@on_success_step_id=0, 
			@on_fail_action=2, 
			@on_fail_step_id=0, 
			@retry_attempts=0, 
			@retry_interval=0, 
			@os_run_priority=0, 
			@subsystem=N'SSIS', 
			@command=@Command3, 
			@database_name=N'master', 
			@flags=0, 
			@proxy_name=N'$(SSISProxyName)'
IF (@@ERROR <> 0 OR @ReturnCode4 <> 0) GOTO QuitWithRollback4
SELECT @jobId4=job_id FROM msdb.dbo.sysjobs where name='FDM_to_Drake'
EXEC @ReturnCode4 = msdb.dbo.sp_update_job @job_id = @jobId4, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode4 <> 0) GOTO QuitWithRollback4

--SQL Jobs-FDM_to_Drake Schedule Creation
IF EXISTS(SELECT 'x' FROM msdb.dbo.sysjobs A JOIN msdb.dbo.sysjobschedules B
		   ON A.job_id=B.job_id
		   WHERE A.NAME='FDM_to_Drake')
BEGIN
	EXEC msdb.dbo.sp_delete_schedule  
						 @schedule_name = N'DrakeExport',
						 @force_delete = 1;
END	
	 EXEC @ReturnCode4 = msdb.dbo.sp_add_jobschedule 
					@job_name=N'FDM_to_Drake', 
					@name=N'DrakeExport', 
					@enabled=1, 
					@freq_type=4, 
					@freq_interval=1, 
					@freq_subday_type=1, 
					@freq_subday_interval=0, 
					@freq_relative_interval=0, 
					@freq_recurrence_factor=0, 
					@active_start_date=20201009, 
					@active_end_date=99991231, 
					@active_start_time=220500, 
					@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode4 <> 0) GOTO QuitWithRollback4
COMMIT TRANSACTION
GOTO EndSave4
QuitWithRollback4:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave4:

/******SQL Server Agent FDM_to_Drake --End*******/

/*******SQL Server Agent Job-FDM_TDMEurobaseExtract --Start*********/
BEGIN TRANSACTION
DECLARE @ReturnCode5 INT
DECLARE @jobId5 BINARY(16)
SELECT @ReturnCode5 = 0

IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode5 = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode5 <> 0) GOTO QuitWithRollback5
END

--SQL JOB-FDM_TDMEurobaseExtract Job Creation
IF NOT EXISTS(SELECT 'x' FROM msdb.dbo.sysjobs WHERE NAME='FDM_TDMEurobaseExtract')
BEGIN
	
	EXEC @ReturnCode5 = msdb.dbo.sp_add_job @job_name=N'FDM_TDMEurobaseExtract', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Extract Eurobase Stats and Office location codes data.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'BFL\Beazley_Reader', @job_id = @jobId5 OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode5 <> 0) GOTO QuitWithRollback5
EXEC @ReturnCode5 = msdb.dbo.sp_add_jobserver @job_id = @jobId5, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode5 <> 0) GOTO QuitWithRollback5
END

--SQL JOB-FDM_TDMEurobaseExtract Steps Creation
	IF EXISTS (SELECT 'X' FROM msdb.dbo.sysjobs A JOIN msdb.dbo.sysjobsteps B
			   ON A.job_id=B.job_id
			   WHERE A.NAME='FDM_TDMEurobaseExtract')
		BEGIN 
			EXEC msdb.dbo.sp_delete_jobstep  
				@job_name = N'FDM_TDMEurobaseExtract',  
				@step_id = 0 ;
		END

	DECLARE @Env5 NVARCHAR(20) = (SELECT CAST(reference_id AS varchar) 
								FROM SSISDB.internal.environment_references A 
								join SSISDB.internal.projects B
								ON A.project_id=B.project_id
								JOIN SSISDB.internal.folders C
								ON B.folder_id=C.folder_id
								WHERE B.NAME='TDM_SSIS' AND A.environment_name='TDM_SSIS' AND C.NAME='TDM')

	DECLARE @Command6 NVARCHAR(4000) = '/ISSERVER "\"\SSISDB\TDM\TDM_SSIS\TDMEurobaseExtract.dtsx\"" /SERVER "\"$(Param_Target_FDMInstance)\"" /X86 /ENVREFERENCE ' + @Env5 + ' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";2 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'
	
	EXEC @ReturnCode5 =  msdb.dbo.sp_add_jobstep
			@job_name=N'FDM_TDMEurobaseExtract', 
			@step_name=N'go', 
			@step_id=1, 
			@cmdexec_success_code=0, 
			@on_success_action=1, 
			@on_success_step_id=0, 
			@on_fail_action=2,  
			@on_fail_step_id=0, 
			@retry_attempts=0, 
			@retry_interval=0, 
			@os_run_priority=0, 
			@subsystem=N'SSIS', 
			@command=@Command6, 
			@database_name=N'master', 
			@flags=0, 
			@proxy_name=N'$(SSISProxyName)'
IF (@@ERROR <> 0 OR @ReturnCode5 <> 0) GOTO QuitWithRollback5
SELECT @jobId5=job_id FROM msdb.dbo.sysjobs where name='FDM_TDMEurobaseExtract'
EXEC @ReturnCode5 = msdb.dbo.sp_update_job @job_id = @jobId5, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode5 <> 0) GOTO QuitWithRollback5
COMMIT TRANSACTION
GOTO EndSave5
QuitWithRollback5:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave5:

/*SQL Server Agent Job-FDM_TDMEurobaseExtract --End*/