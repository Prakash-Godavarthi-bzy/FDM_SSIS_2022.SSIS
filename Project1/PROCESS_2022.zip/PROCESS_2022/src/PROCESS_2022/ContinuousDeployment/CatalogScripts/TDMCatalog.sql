﻿/*==================TDM_SSIS============================*/
 
	
DECLARE @TDMFolder VARCHAR(30)='TDM',@TDM_SSISEnv VARCHAR(30)='TDM_SSIS',@FolderId_TDM INT
 /*=====  Create catalog Environement TDM_SSIS if Folder exists ===== */

IF NOT  EXISTS(SELECT Name	FROM SSISDB.catalog.folders	WHERE Name=@TDMFolder)

	EXEC SSISDB.catalog.create_folder @TDMFolder,@FolderId_TDM OUTPUT

	-- you know the folder exists

IF NOT EXISTS( SELECT E.NAME	FROM SSISDB.catalog.environments E
							JOIN   SSISDB.catalog.folders F ON E.folder_id=F.folder_id
							WHERE F.name=@TDMFolder)

				
	EXEC SSISDB.catalog.create_environment @TDMFolder,@TDM_SSISEnv,'TDM_SSIS'