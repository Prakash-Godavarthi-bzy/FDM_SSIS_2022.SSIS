﻿/*================================FDM Catalog Folder  and FDM_SSIS Catalog Environment ======================================================*/

		DECLARE @FDMFolder VARCHAR(30)='FDM',
				@FDM_SSISEnv VARCHAR(30)='FDM_SSIS',
				--@FDM_DC_SSISEnv VARCHAR(30)='FDM_DC_SSIS',
				@FolderId_FDM INT
 
	/*==========Create FDM Folder catalog if not exists============================================*/
 
	IF NOT EXISTS(SELECT Name	FROM SSISDB.catalog.folders	WHERE Name=@FDMFolder)
	
		EXEC SSISDB.catalog.create_folder @FDMFolder,@FolderId_FDM OUTPUT	
	
	/*==========Create FDM_SSIS  catalog Environment if not exists in FDM Catalog folder============*/

	IF NOT EXISTS( SELECT E.NAME	FROM SSISDB.catalog.environments E
					JOIN   SSISDB.catalog.folders F ON E.folder_id=F.folder_id
					WHERE F.name=@FDMFolder AND E.Name=@FDM_SSISEnv)

		EXEC SSISDB.catalog.create_environment @FDMFolder,@FDM_SSISEnv,'FDM_SSIS' 

	--/*==========Create FDM_dc_SSIS  catalog Environment if not exists in FDM Catalog folder============*/

	--IF NOT EXISTS( SELECT E.NAME	FROM SSISDB.catalog.environments E
	--				JOIN   SSISDB.catalog.folders F ON E.folder_id=F.folder_id
	--				WHERE F.name=@FDMFolder AND E.Name=@FDM_DC_SSISEnv)
				
	--	EXEC SSISDB.catalog.create_environment @FDMFolder,@FDM_DC_SSISEnv,'FDM_DC_SSIS' 
				