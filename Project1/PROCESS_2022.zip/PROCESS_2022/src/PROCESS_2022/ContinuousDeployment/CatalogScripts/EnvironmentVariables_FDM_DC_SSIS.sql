﻿DECLARE @FDM_CubeServer							NVARCHAR(2000) = '$(Param_Target_FDMInstance)' --SSAS FDM
DECLARE @FDM_Server								NVARCHAR(2000) = '$(Param_Target_FDMInstance)'
DECLARE @BIRed_CubeServer						NVARCHAR(2000) = '$(Param_BeazleyIntelligenceODS)'-----New Modified 
DECLARE @URL_SharePoint_UserName				NVARCHAR(2000) = '$(Param_Sharepoint01_UserName)'
DECLARE @URL_SharePoint_Password				NVARCHAR(2000) = '$(Param_Sharepoint01_Password)'
DECLARE @MDS_ServerName							NVARCHAR(2000) = '$(MDSInstance)'


/*===========================================================================================================================================
	Delete unwanted references 
	1.if the project referenced to multiple environments(different names of environments/unexpected environment)
	and 
	2.delete references if it is existing from two same name projects,two same name environments but from different catalog folders
============================================================================================================================================*/

DECLARE @ReferenceID_FDMDC INT=0

WHILE EXISTS	(SELECT	ER.* FROM	ssisdb.catalog.environment_references ER
							JOIN ssisdb.catalog.Projects p on ER.Project_id=p.project_id
							WHERE P.name='FDM_DC_SSIS' AND (er.environment_name<>'FDM_DC_SSIS' OR (er.environment_folder_name IS NOT NULL AND									                                                                    er.environment_folder_name<>'FDM') ) 
														AND ER.reference_id > @ReferenceID_FDMDC
				)
BEGIN
	SELECT	@ReferenceID_FDMDC=MIN(reference_id) 
	FROM	ssisdb.catalog.environment_references ER
	JOIN	ssisdb.catalog.Projects p on ER.Project_id=p.project_id
	WHERE	P.name='FDM_DC_SSIS' AND (er.environment_name<>'FDM_DC_SSIS' OR (er.environment_folder_name IS NOT NULL AND																															er.environment_folder_name<>'FDM') ) 
								 AND ER.reference_id > @ReferenceID_FDMDC
	
	EXEC SSISDB.catalog.delete_environment_reference @ReferenceID_FDMDC
END


/*===================================================================================================================
	Create/Map the reference(Environment) to the SSIS Project of expecting folder if not exists
====================================================================================================================*/


IF NOT EXISTS	(SELECT	reference_id 
					FROM	ssisdb.catalog.environment_references r 
					JOIN	SSISDB.Catalog.Projects P				ON p.project_id=r.project_id
					WHERE	r.environment_name ='FDM_DC_SSIS' 
							AND P.name='FDM_DC_SSIS' 
				)
BEGIN
	EXEC [SSISDB].[catalog].[create_environment_reference] @folder_name = N'FDM', @project_name = N'FDM_DC_SSIS', @environment_name = N'FDM_DC_SSIS', @Reference_type = 'R', @reference_id = @ReferenceID_FDMDC OUTPUT
END




/*=============================================================================================================================
		Delete and re-create Environment variables if not exists for expecting EnvIronment NAME, Env variable, Env Value
===============================================================================================================================*/


IF NOT EXISTS (SELECT	variable_id
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='FDM' AND	E.name='FDM_DC_SSIS'	AND EV.NAME='FDM_CUBE_ServerName' AND CAST(EV.value AS NVARCHAR(500))=@FDM_CubeServer
				)
BEGIN
	IF EXISTS(SELECT	variable_id
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='FDM_DC_SSIS'	AND EV.NAME='FDM_CUBE_ServerName')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'FDM' , @environment_name=N'FDM_DC_SSIS' ,@variable_name =N'FDM_CUBE_ServerName'
	EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FDM_DC_SSIS', @variable_name=N'FDM_CUBE_ServerName',@value=@FDM_CubeServer,			@data_type=N'String', @sensitive=False, @folder_name=N'FDM'
END

IF NOT EXISTS (SELECT	variable_id
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='FDM' AND	E.name='FDM_DC_SSIS'	AND		EV.NAME='FDMServer'		AND		CAST(EV.value AS NVARCHAR(500))=@FDM_Server
				)
BEGIN
	IF EXISTS(SELECT	variable_id
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='FDM_DC_SSIS'	AND EV.NAME='FDMServer')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'FDM' , @environment_name=N'FDM_DC_SSIS' ,@variable_name =N'FDMServer'
	EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FDM_DC_SSIS', @variable_name=N'FDMServer',@value=@FDM_Server,		@data_type=N'String', @sensitive=False, @folder_name=N'FDM'
END

IF NOT EXISTS (SELECT	variable_id
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='FDM' AND	E.name='FDM_DC_SSIS'	AND EV.NAME='BeazleyIntelligenceODS_ServerName' AND CAST(EV.value AS NVARCHAR(500))=@BIRed_CubeServer
				)
BEGIN
	IF EXISTS(SELECT	variable_id
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='FDM_DC_SSIS'	AND EV.NAME='BeazleyIntelligenceODS_ServerName')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'FDM' , @environment_name=N'FDM_DC_SSIS' ,@variable_name =N'BeazleyIntelligenceODS_ServerName'
	EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'FDM_DC_SSIS', @variable_name=N'BeazleyIntelligenceODS_ServerName',				@value=@BIRed_CubeServer,				@data_type=N'String', @sensitive=False, @folder_name=N'FDM'
END

IF NOT EXISTS (SELECT	variable_id
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='FDM' AND	E.name='FDM_DC_SSIS'	AND EV.NAME='Sharepoint01_UserName' AND CAST(EV.value AS NVARCHAR(500))=@URL_SharePoint_UserName
				)
BEGIN
	IF EXISTS(SELECT	variable_id
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='FDM_DC_SSIS'	AND EV.NAME='Sharepoint01_UserName')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'FDM' , @environment_name=N'FDM_DC_SSIS' ,@variable_name =N'Sharepoint01_UserName'
	EXEC[SSISDB].[catalog].[create_environment_variable] @environment_name=N'FDM_DC_SSIS',@variable_name=N'Sharepoint01_UserName',@value=@URL_SharePoint_UserName,@data_type=N'String', @sensitive=False, @folder_name=N'FDM'
END

IF NOT EXISTS (SELECT	variable_id
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='FDM' AND	E.name='FDM_DC_SSIS'	AND EV.NAME='Sharepoint01_Password' AND CAST(EV.value AS NVARCHAR(500))=@URL_SharePoint_Password
				)
BEGIN
	IF EXISTS(SELECT	variable_id
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='FDM_DC_SSIS'	AND EV.NAME='Sharepoint01_Password')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'FDM' , @environment_name=N'FDM_DC_SSIS' ,@variable_name =N'Sharepoint01_Password'
	EXEC[SSISDB].[catalog].[create_environment_variable] @environment_name=N'FDM_DC_SSIS',@variable_name=N'Sharepoint01_Password',@value=@URL_SharePoint_Password,@data_type=N'String', @sensitive=False, @folder_name=N'FDM'
END

IF NOT EXISTS (SELECT	variable_id
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='FDM' AND	E.name='FDM_DC_SSIS'	AND EV.NAME='MDS_ServerName' AND CAST(EV.value AS NVARCHAR(500))=@MDS_ServerName
				)
BEGIN
	IF EXISTS(SELECT	variable_id
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='FDM_DC_SSIS'	AND EV.NAME='MDS_ServerName')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'FDM' , @environment_name=N'FDM_DC_SSIS' ,@variable_name =N'MDS_ServerName'
	EXEC[SSISDB].[catalog].[create_environment_variable] @environment_name=N'FDM_DC_SSIS',@variable_name=N'MDS_ServerName',@value=@MDS_ServerName,@data_type=N'String', @sensitive=False, @folder_name=N'FDM'
END



/*===========================================================================================================================

	Map the Parameter values to the required parameter name of the Project
=============================================================================================================================*/


EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'FDM_CUBE_ServerName',	@parameter_value=N'FDM_CUBE_ServerName'	,@object_name=N'FDM_DC_SSIS', @folder_name=N'FDM', @project_name=N'FDM_DC_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'FDMServer',				@parameter_value=N'FDMServer'			,@object_name=N'FDM_DC_SSIS', @folder_name=N'FDM', @project_name=N'FDM_DC_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'BeazleyIntelligenceODS_ServerName',			@parameter_value=N'BeazleyIntelligenceODS_ServerName'			,@object_name=N'FDM_DC_SSIS', @folder_name=N'FDM', @project_name=N'FDM_DC_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'Sharepoint01_UserName',		@parameter_value=N'Sharepoint01_UserName'		,@object_name=N'FDM_DC_SSIS', @folder_name=N'FDM', @project_name=N'FDM_DC_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'Sharepoint01_Password',	@parameter_value=N'Sharepoint01_Password'	,@object_name=N'FDM_DC_SSIS', @folder_name=N'FDM', @project_name=N'FDM_DC_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'MDS_ServerName',	@parameter_value=N'MDS_ServerName'	,@object_name=N'FDM_DC_SSIS', @folder_name=N'FDM', @project_name=N'FDM_DC_SSIS', @value_type=R
