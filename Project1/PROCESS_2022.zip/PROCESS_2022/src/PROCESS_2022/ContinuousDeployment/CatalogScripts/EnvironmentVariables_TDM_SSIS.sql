﻿--BEGIN TRY

DECLARE @ADMInputs_DBName			NVARCHAR(1000) ='GroupActuaryReserving_inputs'		--'$(Param_ADMOInputsDB_Name)'		---'GroupActuaryReserving_inputs'
DECLARE @ADMOutputs_DBName			NVARCHAR(1000) ='GroupActuaryReserving_outputs'		--	'$(Param_ADMOutputsDB_Name)'			
DECLARE @ADM_DBServer				NVARCHAR(1000) =	'$(Param_ADM_Instance)'					--'DBS-ry6-GroupActuaryReserving_inputs-SYS,13020'
DECLARE @Agresso_DBName				NVARCHAR(1000) ='Agresso'								--'$(Param_AgressoDB_Name)'					--''
DECLARE @Agresso_DBServer			NVARCHAR(1000) =	'$(Param_AgressoInstance)'				--'DBS-ki2-Agresso-SYS,1415'		--Agresso_TDM
DECLARE @BIRedCube_DBName			NVARCHAR(1000) ='Red'									--'$(Param_BIRedCubeDB_Name)'			--
DECLARE @BIRedCube_Server			NVARCHAR(1000) =	'$(Param_BIRedCube_Instance)'			--'UKDVDB123\SYSSSAS'  
DECLARE @CededRIVault_DBName		NVARCHAR(1000) ='CededRIVaultV2'							--'$(Param_CededRIVault_DBName)'		--
DECLARE @CededRIVault_DBServer		NVARCHAR(1000) =	'$(Param_CededRIVault_Instance)'	--'DBS-joe-CededRIVaultV2-SYS,13100'
DECLARE @ExternalFeedLocation_TDM	NVARCHAR(1000) =	'$(Param_ExternalFeedLocation)'		--'\\bfl.local\uk-sys\Groups\Finance\Reporting\TDM\Feeds'
DECLARE @FDMCube_DBName				NVARCHAR(1000) ='FDM_CUBE'										--'$(Param_FDM_CUBE_Name)'				--
DECLARE @FDMCube_ServerName			NVARCHAR(1000) =	'$(Param_Target_FDMSSASInstance)'				--SSAS FDM		--'UKDVDB106\UKAC01'
DECLARE @FDMProcess_DBName			NVARCHAR(1000) ='FDM_Process'									--'$(Param_FDMProcess_DBName)'			--
DECLARE @FDMProcess_DBServer		NVARCHAR(1000) =	'$(Param_Target_FDMInstance)'			--'DBS-5tq-FinanceDataMart-SYS,12870'
DECLARE @FDM_DBName					NVARCHAR(1000) ='FDM_DB'										--'$(Param_FDM_DBName)'					--
DECLARE @FDM_DBServer				NVARCHAR(1000) =	'$(Param_Target_FDMInstance)'					--'DBS-5tq-FinanceDataMart-SYS,12870'
DECLARE @Sharepoint01_Password		NVARCHAR(1000) =	'$(Param_Sharepoint01_Password)'		--'w1x8Hv2TQy(U'
DECLARE @Sharepoint01_Username		NVARCHAR(1000) =	'$(Param_Sharepoint01_UserName)'		--'BFL\PXY_FDM_SYS'
DECLARE @SMTP_Server				NVARCHAR(1000) =	'$(Param_SMTP_Server)'				--'testrelay.bfl.local'
DECLARE @SSAS_DBName				NVARCHAR(1000) ='TDM'									--'$(Param_TDM_DBName)'						--
DECLARE @SSAS_Server				NVARCHAR(1000) =	'$(Param_Target_FDMSSASInstance)'	--SSAS FDM			--'UKDVDB106\UKAC01'
DECLARE @SSISShared_DBName			NVARCHAR(1000) ='msdb'										--'$(Param_SSISSharedDBName)'		--
DECLARE @SSISShared_DBServerName	NVARCHAR(1000) =	'$(Param_SSISSharedDB_Instance)'		--'DBS-g56-SSIS-2012-SYS,1407'
DECLARE @TDM_DBName					NVARCHAR(1000) ='TDM'										--'$(Param_TDM_DBName)'				--
DECLARE @TDM_DBServer				NVARCHAR(1000) =	'$(Param_Target_FDMInstance)'				--'DBS-5tq-FinanceDataMart-SYS,12870'
DECLARE @MDS_DBServer				NVARCHAR(2000) = '$(MDSInstance)'
DECLARE @Eurobase_DSN				NVARCHAR(1000) = '$(Param_Eurobase_DSN)'


/*===========================================================================================================================================
	Delete unwanted references 
	1.if the project referenced to multiple environments(different names of environments/unexpected environment)
	and 
	2.delete references if it is existing from two same name projects,two same name environments but from different catalog folders
============================================================================================================================================*/

DECLARE @ReferenceID_TDM INT=0

WHILE EXISTS	(SELECT	ER.* FROM	ssisdb.catalog.environment_references ER
							JOIN ssisdb.catalog.Projects p on ER.Project_id=p.project_id
							WHERE P.name='TDM_SSIS' AND (er.environment_name<>'TDM_SSIS' OR (er.environment_folder_name IS NOT NULL AND									                                                                    er.environment_folder_name<>'TDM') ) 
													AND ER.reference_id > @ReferenceID_TDM
				)
BEGIN
	SELECT	@ReferenceID_TDM=MIN(reference_id) 
	FROM	ssisdb.catalog.environment_references ER
	JOIN ssisdb.catalog.Projects p on ER.Project_id=p.project_id
	WHERE P.name='TDM_SSIS' AND (er.environment_name<>'TDM_SSIS' OR (er.environment_folder_name IS NOT NULL AND																															er.environment_folder_name<>'TDM') ) 
							AND ER.reference_id > @ReferenceID_TDM
	
	EXEC SSISDB.catalog.delete_environment_reference @ReferenceID_TDM
END

/*====================================================================================
	Create/Map the reference(Environment) to the SSIS Project if not exists
=====================================================================================*/


IF NOT EXISTS	(SELECT	reference_id 
					FROM	ssisdb.catalog.environment_references r 
					JOIN	SSISDB.Catalog.Projects P				ON p.project_id=r.project_id
					WHERE	r.environment_name ='TDM_SSIS' 
							AND P.name='TDM_SSIS'
				)
BEGIN
	EXEC [SSISDB].[catalog].[create_environment_reference] @folder_name = N'TDM', @project_name = N'TDM_SSIS', @environment_name = N'TDM_SSIS', @Reference_type = 'R', 
	@reference_id = @ReferenceID_TDM OUTPUT
END



/*=============================================================================================================================
		Delete and re-create Environment variables if not exists for expecting EnvIronment NAME, Env variable, Env Value
===============================================================================================================================*/


IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='ADMInputs_DBName' AND CAST(EV.value AS NVARCHAR(500))=@ADMInputs_DBName
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='ADMInputs_DBName')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'ADMInputs_DBName'	
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'ADMInputs_DBName', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@ADMInputs_DBName, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='ADMOutputs_DBName' AND CAST(EV.value AS NVARCHAR(500))=@ADMOutputs_DBName
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='ADMOutputs_DBName')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'ADMOutputs_DBName'	
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'ADMOutputs_DBName', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@ADMOutputs_DBName, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='ADM_DBServer' AND CAST(EV.value AS NVARCHAR(500))=@ADM_DBServer
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='ADM_DBServer')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'ADM_DBServer'	
    EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'ADM_DBServer', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@ADM_DBServer, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='Agresso_DBName'  AND CAST(EV.value AS NVARCHAR(500))=@Agresso_DBName
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='Agresso_DBName')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'Agresso_DBName'	
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'Agresso_DBName', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@Agresso_DBName, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='Agresso_DBServer' AND CAST(EV.value AS NVARCHAR(500))=@Agresso_DBServer
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='Agresso_DBServer')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'Agresso_DBServer'	
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'Agresso_DBServer', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@Agresso_DBServer, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='BIRedCube_DBName' AND CAST(EV.value AS NVARCHAR(500))=@BIRedCube_DBName
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='BIRedCube_DBName')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'BIRedCube_DBName'	
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'BIRedCube_DBName', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@BIRedCube_DBName, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='BIRedCube_Server' AND CAST(EV.value AS NVARCHAR(500))=@BIRedCube_Server
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='BIRedCube_Server')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'BIRedCube_Server'	
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'BIRedCube_Server', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@BIRedCube_Server, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='CededRIVault_DBName' AND CAST(EV.value AS NVARCHAR(500))=@CededRIVault_DBName
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='CededRIVault_DBName')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'CededRIVault_DBName'	
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'CededRIVault_DBName', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@CededRIVault_DBName, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='CededRIVault_DBServer' AND CAST(EV.value AS NVARCHAR(500))=@CededRIVault_DBServer
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='CededRIVault_DBServer')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'CededRIVault_DBServer'	
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'CededRIVault_DBServer', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@CededRIVault_DBServer, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='ExternalFeedLocation' AND CAST(EV.value AS NVARCHAR(500))=@ExternalFeedLocation_TDM
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='ExternalFeedLocation')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'ExternalFeedLocation'	
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'ExternalFeedLocation', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@ExternalFeedLocation_TDM, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='FDMCube_DBName' AND CAST(EV.value AS NVARCHAR(500))=@FDMCube_DBName
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='FDMCube_DBName')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'FDMCube_DBName'	
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'FDMCube_DBName', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@FDMCube_DBName, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='FDMCube_ServerName' AND CAST(EV.value AS NVARCHAR(500))=@FDMCube_ServerName
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='FDMCube_ServerName')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'FDMCube_ServerName'
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'FDMCube_ServerName', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@FDMCube_ServerName, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='FDMProcess_DBName' AND CAST(EV.value AS NVARCHAR(500))=@FDMProcess_DBName
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='FDMProcess_DBName')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'FDMProcess_DBName'
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'FDMProcess_DBName', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@FDMProcess_DBName, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='FDMProcess_DBServer' AND CAST(EV.value AS NVARCHAR(500))=@FDMProcess_DBServer
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='FDMProcess_DBServer')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'FDMProcess_DBServer'
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'FDMProcess_DBServer', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@FDMProcess_DBServer, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='FDM_DBName' AND CAST(EV.value AS NVARCHAR(500))=@FDM_DBName
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='FDM_DBName')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'FDM_DBName'
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'FDM_DBName', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@FDM_DBName, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='FDM_DBServer' AND CAST(EV.value AS NVARCHAR(500))=@FDM_DBServer
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='FDM_DBServer')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'FDM_DBServer'
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'FDM_DBServer', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@FDM_DBServer, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='Sharepoint01_Password' AND CAST(EV.value AS NVARCHAR(500))=@Sharepoint01_Password
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='Sharepoint01_Password')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'Sharepoint01_Password'
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'Sharepoint01_Password', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@Sharepoint01_Password, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='Sharepoint01_Username' AND CAST(EV.value AS NVARCHAR(500))=@Sharepoint01_Username
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='Sharepoint01_Username')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'Sharepoint01_Username'
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'Sharepoint01_Username', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@Sharepoint01_Username, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='SMTP_Server' AND CAST(EV.value AS NVARCHAR(500))=@SMTP_Server
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='SMTP_Server')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'SMTP_Server'
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'SMTP_Server', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@SMTP_Server, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='SSAS_DBName' AND CAST(EV.value AS NVARCHAR(500))=@SSAS_DBName
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='SSAS_DBName')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'SSAS_DBName'
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'SSAS_DBName', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@SSAS_DBName, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='SSAS_Server' AND CAST(EV.value AS NVARCHAR(500))=@SSAS_Server
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='SSAS_Server')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'SSAS_Server'
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'SSAS_Server', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@SSAS_Server, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='SSISShared_DBName' AND CAST(EV.value AS NVARCHAR(500))=@SSISShared_DBName
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='SSISShared_DBName')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'SSISShared_DBName'
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'SSISShared_DBName', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@SSISShared_DBName, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='SSISShared_DBServerName' AND CAST(EV.value AS NVARCHAR(500))=@SSISShared_DBServerName
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='SSISShared_DBServerName')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'SSISShared_DBServerName'
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'SSISShared_DBServerName', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@SSISShared_DBServerName, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='TDM_DBName' AND CAST(EV.value AS NVARCHAR(500))=@TDM_DBName
				)
BEGIN
	IF EXISTS(SELECT	variable_id	
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='TDM_DBName')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'TDM_DBName'
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'TDM_DBName', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@TDM_DBName, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	,*
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='TDM_DBServer' AND CAST(EV.value AS NVARCHAR(500))=@TDM_DBServer
				)
BEGIN
	IF EXISTS(SELECT	variable_id	,*
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='TDM_DBServer')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'TDM_DBServer'
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'TDM_DBServer', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@TDM_DBServer, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	,*
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='MDS_DBServer' AND CAST(EV.value AS NVARCHAR(500))=@MDS_DBServer
				)
BEGIN
	IF EXISTS(SELECT	variable_id	,*
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='MDS_DBServer')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'MDS_DBServer'
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'MDS_DBServer', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@MDS_DBServer, @data_type=N'String'
END

IF NOT EXISTS (SELECT	variable_id	,*
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				JOIN	SSISDB.catalog.folders F ON E.folder_id=F.folder_id
				WHERE	F.name='TDM' AND	E.name='TDM_SSIS'	AND EV.NAME='Eurobase_DSN' AND CAST(EV.value AS NVARCHAR(500))=@Eurobase_DSN
				)
BEGIN
	IF EXISTS(SELECT	variable_id	,*
				FROM	SSISDB.catalog.environment_variables EV
				JOIN	SSISDB.catalog.environments E	ON E.environment_id=EV.environment_id
				WHERE	E.name='TDM_SSIS'	AND EV.NAME='Eurobase_DSN')
	EXEC SSISDB.catalog.delete_environment_variable @folder_name =N'TDM' , @environment_name=N'TDM_SSIS' ,@variable_name =N'Eurobase_DSN'
	EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'Eurobase_DSN', @sensitive=False, @description=N'', @environment_name=N'TDM_SSIS', @folder_name=N'TDM', @value=@Eurobase_DSN, @data_type=N'String'
END


/*===========================================================================================================================

	Map the Parameter values to the required parameter name of the Project
=============================================================================================================================*/

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ADMInputs_DBName',			@parameter_value=N'ADMInputs_DBName'	,
@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ADMOutputs_DBName',			@parameter_value=N'ADMOutputs_DBName'		,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ADM_DBServer',				@parameter_value=N'ADM_DBServer'			,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'Agresso_DBName',			@parameter_value=N'Agresso_DBName'			,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'Agresso_DBServer',			@parameter_value=N'Agresso_DBServer'		,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'BIRedCube_DBName',			@parameter_value=N'BIRedCube_DBName'		,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'BIRedCube_Server',			@parameter_value=N'BIRedCube_Server'		,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'CededRIVault_DBName',		@parameter_value=N'CededRIVault_DBName'		,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'CededRIVault_DBServer',		@parameter_value=N'CededRIVault_DBServer'	,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ExternalFeedLocation',		@parameter_value=N'ExternalFeedLocation'	,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'FDMCube_DBName',			@parameter_value=N'FDMCube_DBName'			,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'FDMCube_ServerName',		@parameter_value=N'FDMCube_ServerName'		,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'FDMProcess_DBName',			@parameter_value=N'FDMProcess_DBName'		,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'FDMProcess_DBServer',		@parameter_value=N'FDMProcess_DBServer'		,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'FDM_DBName',				@parameter_value=N'FDM_DBName'				,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'FDM_DBServer',				@parameter_value=N'FDM_DBServer'			,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'Sharepoint01_Password',		@parameter_value=N'Sharepoint01_Password'	,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'Sharepoint01_Username',		@parameter_value=N'Sharepoint01_Username'	,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'SMTP_Server',			    @parameter_value=N'SMTP_Server'				,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'SSAS_DBName',			    @parameter_value=N'SSAS_DBName'				,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'SSAS_Server',			    @parameter_value=N'SSAS_Server'				,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'SSISShared_DBName',			@parameter_value=N'SSISShared_DBName'		,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'SSISShared_DBServerName',	@parameter_value=N'SSISShared_DBServerName'	,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'TDM_DBName',			    @parameter_value=N'TDM_DBName'				,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'TDM_DBServer',			    @parameter_value=N'TDM_DBServer'			,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'MDS_DBServer',				@parameter_value=N'MDS_DBServer'			,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'Eurobase_DSN',				@parameter_value=N'Eurobase_DSN'			,@object_name=N'TDM_SSIS', @folder_name=N'TDM', @project_name=N'TDM_SSIS', @value_type=R


--END TRY

--BEGIN CATCH

--SELECT  ERROR_MESSAGE() AS ErrorMessage

--END CATCH;

