﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

IF
		(
			SELECT COUNT(*)
			FROM [Admin].[IncrementalProcessConfig]
			WHERE [ObjectID] = 'BIDAC ContractChange'
		) = 0 
BEGIN
	BEGIN TRAN
			INSERT INTO [Admin].[IncrementalProcessConfig]
			SELECT 'BIDAC ContractChange' [ObjectID]
				  ,'BIDAC ContractChange'[ObjectName]
				  ,'Partition'[ObjectType]
				  ,'Fact FDM'[ParentObjectID]
				  ,'Amounts'[ParentObjectName]
				  ,'Full'[ProcessType]
				  ,null [ProcessAddElementName]
				  ,null [ProcessAddQuery]
				  ,null [ProcessAddTableName]
				  ,0 [AlwaysPartOfBatch]
				  ,'FinanceDataMart'[CubeID]
				  ,'FinanceDataMart'[CubeName]
	IF @@ROWCOUNT = 1 
		COMMIT
	ELSE
		BEGIN
				ROLLBACK;
				THROW 51000, 'Updating [Admin].[IncrementalProcessConfig]: more than one row involved', 1; 
			END
END

MERGE INTO [Admin].[IncrementalProcessConfig] AS TARGET
USING ( VALUES ( 'BIDAC Claims and OS' 
      ,'BIDAC Claims and OS'
      ,'Partition'
      ,'Fact FDM'
      ,'Amounts'
      ,'Full'
      ,null 
      ,null 
      ,null 
      ,0 
      ,'FinanceDataMart'
      ,'FinanceDataMart'
	  )
	  )
	  AS 
	  SOURCE 
	  ([ObjectID],[ObjectName],[ObjectType],[ParentObjectID],[ParentObjectName],[ProcessType],[ProcessAddElementName]
	  ,[ProcessAddQuery],[ProcessAddTableName]
	  ,[AlwaysPartOfBatch],[CubeID],[CubeName]
	  )
ON TARGET.[ObjectID] = SOURCE.[ObjectID]
WHEN MATCHED THEN UPDATE SET
	 TARGET.[ObjectID]				= SOURCE.[ObjectID]
	,TARGET.[ObjectName]			= SOURCE.[ObjectName]
	,TARGET.[ObjectType]			= SOURCE.[ObjectType]
	,TARGET.[ParentObjectID]		= SOURCE.[ParentObjectID]
	,TARGET.[ParentObjectName]		= SOURCE.[ParentObjectName]
	,TARGET.[ProcessType]			= SOURCE.[ProcessType]
	,TARGET.[ProcessAddElementName]	= SOURCE.[ProcessAddElementName]
	,TARGET.[ProcessAddQuery]		= SOURCE.[ProcessAddQuery]
	,TARGET.[ProcessAddTableName]	= SOURCE.[ProcessAddTableName]
	,TARGET.[AlwaysPartOfBatch]		= SOURCE.[AlwaysPartOfBatch]
	,TARGET.[CubeID]				= SOURCE.[CubeID]
	,TARGET.[CubeName]				= SOURCE.[CubeName]

WHEN NOT MATCHED BY TARGET THEN

INSERT (
	 [ObjectID]
	,[ObjectName]
	,[ObjectType]
	,[ParentObjectID]
	,[ParentObjectName]
	,[ProcessType]
	,[ProcessAddElementName]
	,[ProcessAddQuery]
	,[ProcessAddTableName]
	,[AlwaysPartOfBatch]
	,[CubeID]
	,[CubeName])
VALUES 
(
	 SOURCE.[ObjectID]
	,SOURCE.[ObjectName]
	,SOURCE.[ObjectType]
	,SOURCE.[ParentObjectID]
	,SOURCE.[ParentObjectName]
	,SOURCE.[ProcessType]
	,SOURCE.[ProcessAddElementName]
	,SOURCE.[ProcessAddQuery]
	,SOURCE.[ProcessAddTableName]
	,SOURCE.[AlwaysPartOfBatch]
	,SOURCE.[CubeID]
	,SOURCE.[CubeName]
)
;

MERGE INTO [Admin].[RunProcessConfig] AS TARGET
USING 
	(
		VALUES
		('BIDACClaimsandOS'		,'BIDACClaimsandOS'		,'BIDACFDMTDMControlpackage.dtsx'	,1	,1	,22	,'FDM_SSIS'),
		('BIDACContractChange'	,'BIDAC ContractChange'	,'BIDACProfitBeforeTax.dtsx'		,1	,1	,24 ,'FDM_SSIS' )
	)
AS SOURCE ([FolderName],[ModuleName],[PackageName],[UserInitiated],[Stream],[RunOrder],[SSISFolderName])
ON TARGET.[PackageName] = SOURCE.[PackageName]

WHEN MATCHED THEN 
	UPDATE SET
		 TARGET.[FolderName]	 = SOURCE.[FolderName]
		,TARGET.[ModuleName]	 = SOURCE.[ModuleName]
		,TARGET.[UserInitiated]	 = SOURCE.[UserInitiated]
		,TARGET.[Stream]		 = SOURCE.[Stream]
		,TARGET.[RunOrder]		 = SOURCE.[RunOrder]
		,TARGET.[SSISFolderName] = SOURCE.[SSISFolderName]

WHEN NOT MATCHED BY TARGET THEN
	INSERT 
		(
			 [FolderName]
			,[ModuleName]
			,[PackageName]
			,[UserInitiated]
			,[Stream]
			,[RunOrder]
			,[SSISFolderName]
		)
	VALUES 
		(
			 SOURCE.[FolderName]
			,SOURCE.[ModuleName]
			,SOURCE.[PackageName]
			,SOURCE.[UserInitiated]
			,SOURCE.[Stream]
			,SOURCE.[RunOrder]
			,SOURCE.[SSISFolderName]
		)
;