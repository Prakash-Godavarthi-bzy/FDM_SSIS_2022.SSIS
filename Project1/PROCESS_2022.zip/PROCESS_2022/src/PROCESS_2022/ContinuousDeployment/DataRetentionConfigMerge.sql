﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
DECLARE @DataRetentionConfig TABLE
(
	--[DataRetentionConfigId] INT IDENTITY(1,1 ) NOT NULL PRIMARY KEY, 
    [TableName] VARCHAR(255) NOT NULL, 
	[Description] VARCHAR(500),
    [RetentionPeriod] INT NOT NULL, 
    [RetentionPeriodType] VARCHAR(255) NOT NULL,
	[RetentionDay] VARCHAR(50) NOT NULL,
	[RowsPerBatch] INT, 
    [CreatedDate] DATETIME NULL, 
    [CreatedBy] VARCHAR(50) NULL, 
    [ModifiedDate] DATETIME NULL, 
    [ModifiiedBy] VARCHAR(50) NULL

)

INSERT @DataRetentionConfig([TableName],[Description],[RetentionPeriod],[RetentionPeriodType],[RetentionDay],[RowsPerBatch],[CreatedDate],[CreatedBy],[ModifiedDate],[ModifiiedBy])
VALUES 
('FactFDMExternal_Current','Move data from FactFDMExternal_Current to FactFDMExternal_History',7,'Days','Saturday',10000,GETDATE(),NULL,NULL,NULL),
('DimTransactionDetailsV1_Current','Move data from DimTransactionDetailsV1_Current to DimTransactionDetailsV1_History',7,'Days','Saturday',10000,GETDATE(),NULL,NULL,NULL),
('DimTransactionDetailsV1_History','Delete data from DimTransactionDetailsV1_History',3,'Years','Saturday',100000,GETDATE(),NULL,NULL,NULL),
('FactAllocationsV1_Current','Move data from FactAllocationsV1_Current to FactAllocationsV1_History',15,'Months','Saturday',10000,GETDATE(),NULL,NULL,NULL)

/*
RetentionPeriodType :
Days
Weeks
Months
Years
*/
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

MERGE [FDM_PROCESS].[Admin].[DataRetentionConfig] AS TGT
USING @DataRetentionConfig AS SRC

ON (

		ISNULL(TGT.[TableName],'') = ISNULL(SRC.[TableName],'')  

)
WHEN MATCHED AND

            ISNULL(TGT.[RetentionPeriod],'') <> ISNULL(SRC.[RetentionPeriod],'') OR
			ISNULL(TGT.[RetentionPeriodType],'') <> ISNULL(SRC.[RetentionPeriodType],'') OR
			ISNULL(TGT.[RetentionDay],'') <> ISNULL(SRC.[RetentionDay],'') OR
			ISNULL(TGT.[RowsPerBatch],'') <> ISNULL(SRC.[RowsPerBatch],'') OR
			ISNULL(TGT.[Description],'') <> ISNULL(SRC.[Description],'') 
			
			 

THEN

      UPDATE SET TGT.[RetentionPeriod] = SRC.[RetentionPeriod],
				 TGT.[RetentionPeriodType] = SRC.[RetentionPeriodType],
				 TGT.[RetentionDay]=SRC.[RetentionDay],
				 TGT.[RowsPerBatch] = SRC.[RowsPerBatch],
				 TGT.[Description] = SRC.[Description],
				 TGT.[ModifiedDate] = GETDATE(),
				 TGT.[ModifiiedBy] = NULL
				 

WHEN NOT MATCHED BY TARGET THEN

      INSERT ([TableName],[Description],[RetentionPeriod],[RetentionPeriodType],[RetentionDay],[RowsPerBatch],[CreatedDate],[CreatedBy],[ModifiedDate],[ModifiiedBy])

      VALUES ([TableName],[Description],[RetentionPeriod],[RetentionPeriodType],[RetentionDay],[RowsPerBatch],[CreatedDate],[CreatedBy],[ModifiedDate],[ModifiiedBy])
	  ;
	  
