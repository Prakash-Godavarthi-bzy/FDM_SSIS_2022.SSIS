﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]				
--------------------------------------------------------------------------------------
*/
--SET NOCOUNT ON
--PRINT '***********[FDM_PROCESS].[Admin].[RunProcessConfig]***********';
--DECLARE @dbo_RunProcessConfig_start_time DATETIME2(7) = SYSDATETIME();
--DECLARE @dbo_RunProcessConfig_split_time DATETIME2(7);
--DECLARE @dbo_RunProcessConfig_time_char VARCHAR(20);
--DECLARE @dbo_RunProcessConfig_interim_row_count INT = 0;
--DECLARE @dbo_RunProcessConfig_row_count_char VARCHAR(10);
--DECLARE @dbo_RunProcessConfig_rowcounts TABLE(mergeAction NVARCHAR(10));
--DECLARE @dbo_RunProcessConfig_insertCount INT, @dbo_RunProcessConfig_updateCount INT, @dbo_RunProcessConfig_deleteCount INT;

DECLARE @RunProcessConfig TABLE
( 
	[pk_RunProcessConfig] INT IDENTITY(1,1) NOT NULL,
	[FolderName] [nvarchar](255) NOT NULL,
	[ModuleName] [nvarchar](255) NOT NULL,
	[PackageName] [nvarchar](255) NOT NULL,
	[UserInitiated] [bit] NOT NULL,
	[Stream] [int] NOT NULL,
	[RunOrder] [int] NOT NULL,
	[SSISFolderName] [nvarchar](255) NOT NULL

)

INSERT @RunProcessConfig([FolderName],[ModuleName],[PackageName],[UserInitiated],[Stream],[RunOrder],[SSISFolderName])
VALUES 

('PostingQueries','Referesh Posting Queries','RefreshPostingQueries.dtsx',0,1,1,'FDM_SSIS'),
('AgressoDataFix','Agresso Data Fix','AgressoDataFix.dtsx',0,1,2,'FDM_SSIS'),
('AllocationTriggerImport','AL Import','AllocationTriggerImport.dtsx',1,2,3,'FDM_SSIS'),
('PremiumForecast','Premium Forecast Import','PremiumForecastStage.dtsx',1,1,4,'FDM_SSIS'),
('EurobaseEPI','UA','EurobaseEPIProcessing.dtsx',1,1,5,'FDM_SSIS'),
('OYClaims','OY Claims','OYClaims.dtsx',1,1,6,'FDM_SSIS'),
('BIEPI','UA','BIEPIProcessing.dtsx',1,1,7,'FDM_SSIS'),
('RISpend','RI Spend Import','RISpendStage.dtsx',1,1,8,'FDM_SSIS'),
('EarningsCloseYOA','Earnings Close YOA','EarningsCloseYOA.dtsx',0,1,9,'FDM_SSIS'),
('FXScenarios','FX','DimFXScenarios.dtsx',1,1,10,'FDM_SSIS'),
('Wizi','Wizi','WiziMovements.dtsx',1,1,11,'FDM_SSIS'),
('RITC','RITC','RITCMovements.dtsx',1,1,12,'FDM_SSIS'),
('AllocationTriggerRun','Allocations','Control.Allocations.dtsx',1,2,1,'FDM_SSIS'),
('PostingEngine','Agresso Posting','AgressoPosting.dtsx',1,3,1,'FDM_SSIS'),
('SolvencyII','SolvencyII','SolvencyIIDataMapping.dtsx',1,1,13,'FDM_SSIS'),--(FIN-8543)(Dt:27-06-2023)-Replaced the FDM_Solvency II folder with FDM_SSIS
('PremiumEstimates','Premium Estimates','PremiumEstimates.dtsx',1,1,13,'FDM_SSIS'),
('EurobaseEPIAdjustments','Eurobase EPI Adjustments','EurobaseEPIAdjustments.dtsx',1,1,14,'FDM_SSIS'),
('InvestmentReporting','Investment Data Feed','InvestmentReporting.dtsx',1,1,15,'FDM_SSIS'),
('Not Applicable','Investment Run Model','InvestmentReportingRunModel.dtsx',1,1,15,'FDM_SSIS'),
('Not Applicable','Investment Post Model','InvestmentReportingPostModel.dtsx',1,1,15,'FDM_SSIS'),
('AllocationTriggerRunSCCostPlus','Service Company Cost Plus','ServiceCompanyCostPlus.dtsx',1,2,3,'FDM_SSIS'),
('623ProfitCommission','623 Profit Commission','ProfitCommission.dtsx',1,1,1,'FDM_SSIS'),
('AllocationTriggerRunUSPremSC','US Premium','AEUSPremiumSidecar.dtsx',1,2,3,'FDM_SSIS'),
('PFTSharepoint','PFT Sharepoint','Dimensions_FDM_DC.dtsx',1,1,1,'FDM_DC_SSIS'),
('Not Applicable','Investment TGK Extract','InvestmentReportingTGKExtract.dtsx',1,1,15,'FDM_SSIS'),
('USPremiumTax','US Premium Tax Rates','USPremiumTaxRate.dtsx',1,1,16,'FDM_SSIS'),
('AllocationTriggerRunAR2GL','AR 2 GL EIC','AR2GL.dtsx',1,2,17,'FDM_SSIS'),
('AllocationTriggerRunAR2GLBSOL','AR 2 GL BSOL','AR2GLBSOL.dtsx',1,2,18,'FDM_SSIS'),
('EICInvestments','EIC Investment Allocations','EICInvestments.dtsx',1,1,19,'FDM_SSIS'),
('6107ORC','6107 ORC','6107ORC.dtsx',1,1,17,'FDM_SSIS'),
('6107PC','6107 PC','6107PC.dtsx',1,1,18,'FDM_SSIS'),
('6107InvestmentIncome','6107 Investment Income','6107InvestmentIncome.dtsx',1,1,18,'FDM_SSIS'),
('TDMUS','TDM US','US_ControlLoad.dtsx',1,1,17,'TDM_SSIS'),
('TDMUSIBNR','TDM US IBNR','US_ControlLoadIBNR.dtsx',1,1,18,'TDM_SSIS'),
('TDMUSCHE','TDM US CHE','US_ControlCHE.dtsx',1,1,19,'TDM_SSIS'),
('TDM Publish','TDM Publish','PublishTriangleToADM.dtsx',1,1,20,'TDM_SSIS'),
('TDMBIDAC','TDM BIDAC','BIDAC_ControlLoad.dtsx',1,1,21,'TDM_SSIS'),
('PFTPublish','PFT Datasets','FeedDataSet.dtsx',1,1,2,'FDM_DC_SSIS'),
('TDMAdjustments','TDM Adjustments','TDMAdjustment.dtsx',1,1,22,'TDM_SSIS'),
('OverseasandASL','Overseas ASL','OverseasandASLProcessing.dtsx',1,1,20,'FDM_SSIS'),
('BIDACClaimsandOS','BIDACClaimsandOS','BIDACFDMTDMControlpackage.dtsx',1,1,22,'FDM_SSIS'),
('QMADataForReporting','QMADataForReporting','RRProjFDMDataControl100_RemovingFields.dtsx',1,1,99,'FDM_SSIS'),
('BIDACContractChange','BIDAC ContractChange','BIDACProfitBeforeTax.dtsx',1,1,24,'FDM_SSIS'),
('BIDACBadDebts','BIDAC Bad Debts','BIDACBadDebts.dtsx',1,1,6,'FDM_SSIS'), -- Added for FDM-475
('BIDACLRClaims' ,'BIDACLRClaims' ,'BIDACTDMLRClaims.dtsx',1,1,28,'FDM_SSIS')
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


MERGE [FDM_PROCESS].[Admin].[RunProcessConfig] AS TGT

USING @RunProcessConfig AS SRC

ON (
		--TGT.[pk_RunProcessConfig]=SRC.[pk_RunProcessConfig] AND
		TGT.[FolderName] = SRC.[FolderName] AND
		TGT.[ModuleName] = SRC.[ModuleName]

)

WHEN MATCHED AND

			   ISNULL(TGT.[PackageName],'') <> ISNULL(SRC.[PackageName],'') OR
			   ISNULL(TGT.[UserInitiated],'') <> ISNULL(SRC.[UserInitiated],'') OR
			   ISNULL(TGT.[Stream],'') <> ISNULL(SRC.[Stream],'') OR 
			   ISNULL(TGT.[RunOrder],'') <> ISNULL(SRC.[RunOrder],'') OR
			   ISNULL(TGT.[SSISFolderName],'') <> ISNULL(SRC.[SSISFolderName],'')

THEN

      UPDATE SET TGT.[PackageName] = SRC.[PackageName],
				 TGT.[UserInitiated] = SRC.[UserInitiated],
				 TGT.[Stream] = SRC.[Stream],
				 TGT.[RunOrder] = SRC.[RunOrder],
				 TGT.[SSISFolderName] = SRC.[SSISFolderName]
				 
			 
				

WHEN NOT MATCHED BY TARGET THEN

      INSERT ([FolderName],[ModuleName],[PackageName],[UserInitiated],[Stream],[RunOrder],[SSISFolderName])

      VALUES ([FolderName],[ModuleName],[PackageName],[UserInitiated],[Stream],[RunOrder],[SSISFolderName])
	  ;

--OUTPUT $action INTO @dbo_RunProcessConfig_rowcounts;

--SET @dbo_RunProcessConfig_split_time = SYSDATETIME();

--SET @dbo_RunProcessConfig_time_char = CONVERT(VARCHAR(10),DATEDIFF(ss,@dbo_RunProcessConfig_start_time,@dbo_RunProcessConfig_split_time)) + ' seconds';

--SELECT @dbo_RunProcessConfig_insertCount = SUM(CASE WHEN mergeAction = 'INSERT' THEN 1 ELSE 0 END),

--      @dbo_RunProcessConfig_updatecount = SUM(CASE WHEN mergeAction = 'UPDATE' THEN 1 ELSE 0 END),

--      @dbo_RunProcessConfig_deletecount = SUM(CASE WHEN mergeAction = 'DELETE' THEN 1 ELSE 0 END)

--FROM @dbo_RunProcessConfig_rowcounts 

--PRINT '[FDM_PROCESS].[Admin].[RunProcessConfig] @insertcount = ' + cast(ISNULL(@dbo_RunProcessConfig_insertcount,0) as varchar(max)) + ' in ' + @dbo_RunProcessConfig_time_char;

--PRINT '[FDM_PROCESS].[Admin].[RunProcessConfig] @updatecount = ' + cast(ISNULL(@dbo_RunProcessConfig_updatecount,0) as varchar(max)) + ' in ' + @dbo_RunProcessConfig_time_char;

--PRINT '[FDM_PROCESS].[Admin].[RunProcessConfig] @deletecount = ' + cast(ISNULL(@dbo_RunProcessConfig_deletecount,0) as varchar(max)) + ' in ' + @dbo_RunProcessConfig_time_char;

--PRINT '***********[FDM_PROCESS].[Admin].[RunProcessConfig]***********';