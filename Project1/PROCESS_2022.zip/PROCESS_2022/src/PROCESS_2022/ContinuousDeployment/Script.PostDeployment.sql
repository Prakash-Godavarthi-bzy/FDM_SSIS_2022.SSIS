﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

DECLARE @Trancount INT = @@Trancount

BEGIN TRY;
	
	IF @Trancount = 0 BEGIN TRAN;

		:r .\CubeProcessLockLogMerge.sql
		:r .\IncrementalProcessConfigMerge.sql
		:r .\RunProcessConfigMerge.sql
        --:r .\ServerLevelConfiguration\Credential_PXY_FDM.sql
		

		:r .\CatalogScripts\FDMCatalog.sql
		:r .\CatalogScripts\TDMCatalog.sql
		:r .\CatalogScripts\EnvironmentVariables_FDM_SSIS.sql
		--:r .\CatalogScripts\EnvironmentVariables_FDM_DC_SSIS.sql
		:r .\CatalogScripts\EnvironmentVariables_TDM_SSIS.sql 

		
		:r .\DataRetentionConfigMerge.sql
		:r .\CatalogScripts\SQLServer_Agent_JobSteps.sql

	IF @Trancount = 0 COMMIT;

END TRY

BEGIN CATCH;

	IF @Trancount = 0 
		ROLLBACK;

	THROW;

END CATCH;

