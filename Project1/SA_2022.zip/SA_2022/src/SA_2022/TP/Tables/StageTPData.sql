﻿CREATE TABLE [TP].[StageTPData] (
    [AsAt]               INT             NULL,
    [Synd]               NVARCHAR (50)   NULL,
    [SII_Class]          NVARCHAR (255)  NULL,
    [Department]         NVARCHAR (255)  NULL,
    [Class]              NVARCHAR (255)  NULL,
    [YOA]                INT             NULL,
    [Dataset_Type]       NVARCHAR (255)  NULL,
    [Gross_Net]          NVARCHAR (255)  NULL,
    [Currency]           NVARCHAR (255)  NULL,
    [Undiscounted_value] NUMERIC (18, 4) NULL,
    [Discounted_value]   NUMERIC (18, 4) NULL,
    [Risk_Margin_undisc] NUMERIC (18, 4) NULL,
    [Risk_Margin_disc]   NUMERIC (18, 4) NULL
);

