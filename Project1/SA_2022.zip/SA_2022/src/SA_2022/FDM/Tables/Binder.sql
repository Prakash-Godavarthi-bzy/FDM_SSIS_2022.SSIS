﻿CREATE TABLE [FDM].[Binder] (
    [PK_Section]        BIGINT         NOT NULL,
    [FK_Policy]         BIGINT         NOT NULL,
    [FK_Facility]       BIGINT         NOT NULL,
    [PolicyReference]   NVARCHAR (255) NOT NULL,
    [SectionReference]  NVARCHAR (255) NOT NULL,
    [FacilityReference] NVARCHAR (255) NULL,
    [FacilityType]      NVARCHAR (255) NULL,
    [IsFacility]        BIT            NOT NULL,
    [AuditTimestamp]    DATETIME       NOT NULL,
    [AuditUser]         NVARCHAR (255) NOT NULL
);

