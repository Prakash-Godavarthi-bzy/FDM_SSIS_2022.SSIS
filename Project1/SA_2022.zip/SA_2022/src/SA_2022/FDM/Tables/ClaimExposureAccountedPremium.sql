﻿CREATE TABLE [FDM].[ClaimExposureAccountedPremium] (
    [FK_Section]                     BIGINT           NOT NULL,
    [FK_Policy]                      BIGINT           NOT NULL,
    [FK_ClaimExposure]               BIGINT           NOT NULL,
    [FK_LPSOTransaction]             BIGINT           NOT NULL,
    [FK_NonLLoydsPremiumTransaction] BIGINT           NOT NULL,
    [EntityPerspective]              NVARCHAR (255)   NOT NULL,
    [ShareType]                      NVARCHAR (255)   NOT NULL,
    [ReportingCurrencyOverride]      NVARCHAR (255)   NOT NULL,
    [OriginalCurrencyCode]           NVARCHAR (255)   NOT NULL,
    [SettlementCurrencyCode]         NVARCHAR (255)   NOT NULL,
    [OriginalCCYToSettlementCCYRate] NUMERIC (19, 12) NULL,
    [AccountingPeriod]               DATETIME         NULL,
    [AccountedClaimPaid]             NUMERIC (19, 4)  NULL,
    [SyndicateNumber]                INT              NOT NULL,
    [SyndicatePercentage]            NUMERIC (19, 12) NULL,
    [AuditTimestamp]                 DATETIME         NOT NULL,
    [AuditUser]                      NVARCHAR (255)   NOT NULL
);

