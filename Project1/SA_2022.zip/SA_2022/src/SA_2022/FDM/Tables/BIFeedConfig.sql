﻿CREATE TABLE [FDM].[BIFeedConfig] (
    [AdhocLoadDate]     DATETIME       NULL,
    [FeedName]          NVARCHAR (255) NULL,
    [ScheduledLoadDate] DATETIME       NULL,
    [ScheduleEnabled]   BIT            NULL,
    [ScheduleFrequency] NVARCHAR (255) NULL
);

