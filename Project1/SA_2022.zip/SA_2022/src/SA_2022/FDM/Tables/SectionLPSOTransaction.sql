﻿CREATE TABLE [FDM].[SectionLPSOTransaction] (
    [PK_LPSOTransaction] BIGINT         NOT NULL,
    [FK_Section]         BIGINT         NOT NULL,
    [ActualPaymentDate]  DATETIME       NULL,
    [CategoryCode]       NVARCHAR (255) NOT NULL,
    [Category]           NVARCHAR (255) NOT NULL,
    [RiskClassCode]      NVARCHAR (255) NULL,
    [YearOfAccount]      INT            NOT NULL,
    [SigningDate]        DATETIME       NOT NULL,
    [SigningNumber]      INT            NOT NULL,
    [AuditTimestamp]     DATETIME       NOT NULL,
    [AuditUser]          NVARCHAR (255) NOT NULL
);

