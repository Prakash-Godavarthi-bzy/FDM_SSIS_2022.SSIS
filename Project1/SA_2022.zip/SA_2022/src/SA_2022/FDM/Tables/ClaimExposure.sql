﻿CREATE TABLE [FDM].[ClaimExposure] (
    [PK_ClaimExposure]  BIGINT         NOT NULL,
    [FK_Claim]          BIGINT         NOT NULL,
    [ClaimReference]    NVARCHAR (255) NOT NULL,
    [ExposureReference] NVARCHAR (255) NOT NULL,
    [ClaimantName]      NVARCHAR (255) NULL,
    [AuditTimestamp]    DATETIME       NOT NULL,
    [AuditUser]         NVARCHAR (255) NOT NULL
);

