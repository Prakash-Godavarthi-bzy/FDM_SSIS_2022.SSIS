﻿CREATE TABLE [FDM].[SectionWrittenPremium] (
    [FK_Section]                        BIGINT           NOT NULL,
    [FK_Policy]                         BIGINT           NOT NULL,
    [EntityPerspective]                 NVARCHAR (255)   NOT NULL,
    [ShareType]                         NVARCHAR (255)   NOT NULL,
    [ReportingCurrencyOverride]         NVARCHAR (255)   NOT NULL,
    [LimitCCYToSettlementCCYRate]       NUMERIC (19, 12) NULL,
    [OriginalCCYToSettlementCCYRate]    NUMERIC (19, 12) NULL,
    [ReinstatementPremiumInOriginalCCY] NUMERIC (19, 4)  NULL,
    [OriginalCurrencyCode]              NVARCHAR (255)   NOT NULL,
    [SettlementCurrencyCode]            NVARCHAR (255)   NOT NULL,
    [LimitCurrencyCode]                 NVARCHAR (255)   NULL,
    [AcquisitionCostBasis]              NVARCHAR (255)   NOT NULL,
    [WrittenOrEstimatedPremium]         NUMERIC (19, 4)  NULL,
    [ExpiringWrittenOrEstimatedPremium] NUMERIC (19, 4)  NULL,
    [SyndicateNumber]                   INT              NOT NULL,
    [SyndicatePercentage]               NUMERIC (19, 12) NULL,
    [SpecialPurposeSyndicatePercentage] NUMERIC (19, 12) NULL,
    [AuditTimestamp]                    DATETIME         NOT NULL,
    [AuditUser]                         NVARCHAR (255)   NOT NULL
);

