﻿CREATE TABLE [FDM].[Policy] (
    [PK_Policy]             BIGINT         NOT NULL,
    [PolicyReference]       NVARCHAR (255) NOT NULL,
    [InsuredParty]          NVARCHAR (255) NULL,
    [MethodOfPlacement]     NVARCHAR (255) NULL,
    [MethodOfPlacementCode] NVARCHAR (255) NULL,
    [CRMBrokerBranch]       NVARCHAR (255) NULL,
    [PlacingBrokerGroup]    NVARCHAR (255) NULL,
    [ProducingBrokerGroup]  NVARCHAR (255) NULL,
    [SourceSystem]          NVARCHAR (255) NOT NULL,
    [AuditTimestamp]        DATETIME       NOT NULL,
    [AuditUser]             NVARCHAR (255) NOT NULL
);

