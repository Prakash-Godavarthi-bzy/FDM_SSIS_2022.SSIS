﻿CREATE TABLE [FDM].[SectionNonLloydsPremiumTransaction] (
    [PK_NonLloydsPremiumTransaction] BIGINT         NOT NULL,
    [FK_Section]                     BIGINT         NOT NULL,
    [DateCreated]                    DATETIME       NULL,
    [EffectiveFromDate]              DATETIME       NULL,
    [EffectiveToDate]                DATETIME       NULL,
    [TransactionTypeCode]            NVARCHAR (255) NULL,
    [TransactionType]                NVARCHAR (255) NULL,
    [AuditTimestamp]                 DATETIME       NOT NULL,
    [AuditUser]                      NVARCHAR (255) NOT NULL
);

