﻿CREATE TABLE [FDM].[ClaimExposureMovement] (
    [FK_Section]                                BIGINT           NOT NULL,
    [FK_ClaimExposure]                          BIGINT           NOT NULL,
    [SlipLineNumber]                            BIGINT           NOT NULL,
    [SequenceNumber]                            INT              NOT NULL,
    [MovementReference]                         NVARCHAR (255)   NOT NULL,
    [EntityPerspective]                         NVARCHAR (255)   NOT NULL,
    [ShareType]                                 NVARCHAR (255)   NOT NULL,
    [ReportingCurrencyOverride]                 NVARCHAR (255)   NOT NULL,
    [OriginalCurrencyCode]                      NVARCHAR (255)   NOT NULL,
    [SettlementCurrencyCode]                    NVARCHAR (255)   NOT NULL,
    [PaidOriginalCCYToSettlementCCYRate]        NUMERIC (19, 12) NULL,
    [OutstandingOriginalCCYToSettlementCCYRate] NUMERIC (19, 12) NULL,
    [MovementDate]                              DATETIME         NOT NULL,
    [MovementTotalPaid]                         NUMERIC (19, 4)  NULL,
    [MovementTotalOutstanding]                  NUMERIC (19, 4)  NULL,
    [MovementTotalIncurred]                     NUMERIC (19, 4)  NULL,
    [SyndicateNumber]                           INT              NOT NULL,
    [SyndicatePercentage]                       NUMERIC (19, 12) NULL,
    [AuditTimestamp]                            DATETIME         NOT NULL,
    [AuditUser]                                 NVARCHAR (255)   NOT NULL
);

