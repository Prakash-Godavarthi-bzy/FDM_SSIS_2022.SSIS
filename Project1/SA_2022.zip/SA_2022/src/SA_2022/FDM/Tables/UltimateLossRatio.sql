﻿CREATE TABLE [FDM].[UltimateLossRatio] (
    [TriFocusName]               NVARCHAR (255)   NOT NULL,
    [TriFocusCode]               NVARCHAR (255)   NOT NULL,
    [YearOfAccount]              NVARCHAR (255)   NOT NULL,
    [DevelopmentMonth]           NVARCHAR (255)   NOT NULL,
    [DevelopmentQuarter]         NVARCHAR (255)   NOT NULL,
    [DevelopmentYear]            NVARCHAR (255)   NOT NULL,
    [EntityPerspective]          NVARCHAR (255)   NOT NULL,
    [ShareType]                  NVARCHAR (255)   NOT NULL,
    [AcquisitionCostBasis]       NVARCHAR (255)   NOT NULL,
    [UltimatePremium]            NUMERIC (19, 4)  NOT NULL,
    [UltimateIncurred]           NUMERIC (19, 4)  NOT NULL,
    [ReportingCurrencyOverride]  NVARCHAR (255)   NOT NULL,
    [SettlementCurrencyCode]     NVARCHAR (255)   NOT NULL,
    [SyndicateNumber]            INT              NOT NULL,
    [SyndicatePercentage]        NUMERIC (19, 12) NULL,
    [BICIBUSAIndicator]          NVARCHAR (255)   NOT NULL,
    [SpecialCategoryCatastrophe] NVARCHAR (255)   NOT NULL,
    [SpecialCategorySection]     NVARCHAR (255)   NOT NULL,
    [AuditTimestamp]             DATETIME         NOT NULL,
    [AuditUser]                  NVARCHAR (255)   NOT NULL
);

