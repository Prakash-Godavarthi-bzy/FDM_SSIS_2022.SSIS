﻿CREATE TABLE [FDMOutput].[AgressoPostingAccountExceptions] (
    [PK_AgressoPostingAccountExceptions] INT             IDENTITY (1, 1) NOT NULL,
    [ExceptionDescription]               VARCHAR (255)   NULL,
    [PostingBatchID]                     VARCHAR (25)    NOT NULL,
    [ProcessCode]                        VARCHAR (25)    NULL,
    [Scenario]                           VARCHAR (100)   NULL,
    [Client]                             VARCHAR (255)   NULL,
    [YOA]                                VARCHAR (25)    NULL,
    [Entity]                             VARCHAR (25)    NULL,
    [FunctionalCurrency]                 VARCHAR (25)    NULL,
    [Account]                            VARCHAR (25)    NULL,
    [CurAmount]                          DECIMAL (28, 3) NULL,
    CONSTRAINT [PK_AgressoPostingAccountExceptions] PRIMARY KEY CLUSTERED ([PK_AgressoPostingAccountExceptions] ASC) WITH (FILLFACTOR = 90)
);

