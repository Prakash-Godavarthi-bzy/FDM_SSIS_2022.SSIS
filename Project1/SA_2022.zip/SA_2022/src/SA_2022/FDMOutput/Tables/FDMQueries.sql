﻿CREATE TABLE [FDMOutput].[FDMQueries] (
    [PK_FDMQueries]       INT            IDENTITY (1, 1) NOT NULL,
    [FDMQuery]            NVARCHAR (MAX) NOT NULL,
    [FDMQueryOrder]       INT            NOT NULL,
    [FDMQueryDescription] NVARCHAR (255) NULL,
    [FDMProcess]          NVARCHAR (50)  NULL,
    [FDMSubProcess]       NVARCHAR (50)  NULL,
    CONSTRAINT [PK_MDXQueries] PRIMARY KEY CLUSTERED ([PK_FDMQueries] ASC) WITH (FILLFACTOR = 90)
);

