﻿CREATE PROCEDURE [dbo].[usp_AccountPeriod]
AS
BEGIN

DECLARE @PrevQ VARCHAR(25)
DECLARE @NextQ VARCHAR(25)

DECLARE @DateVal AS DATETIME= GETDATE()

--SELECT @DateVal

DECLARE @MonthMod as INT= DATEPART(MM,@DateVal)%3

DECLARE @DayVal AS INT= DATEPART(DD,@DateVal)

DECLARE @YYYYVal AS INT= DATEPART(YYYY,@DateVal)

DECLARE @QQVal AS INT = DATEPART(QQ,@DateVal)

IF @MonthMod = 1 OR (@MonthMod = 2 and @DayVal <=15) 
BEGIN 

IF @QQVal = 1
BEGIN 
SELECT @PrevQ =  CAST(@YYYYVal-1 AS varchar(4))+'12',@NextQ =	CAST(@YYYYVal AS varchar(4))+'03'
END

ELSE 
	BEGIN 
		SELECT @NextQ = CASE WHEN @QQVal*3 <10 THEN  CAST(@YYYYVal AS varchar(4))+'0'+CAST(@QQVal*3 AS VARCHAR(1)) ELSE CAST(@YYYYVal AS varchar(4))+CAST(@QQVal*3 AS VARCHAR(2)) END
		SELECT @PrevQ = CASE WHEN (@QQVal-1)*3 <10 THEN  CAST(@YYYYVal AS varchar(4))+'0'+CAST((@QQVal-1)*3 AS VARCHAR(1)) ELSE CAST(@YYYYVal AS varchar(4))+CAST((@QQVal-1)*3 AS VARCHAR(1)) END
	END
END 

ELSE 
	BEGIN 
		SELECT @NextQ = CASE WHEN @QQVal*3 <10 THEN  CAST(@YYYYVal AS varchar(4))+'0'+CAST(@QQVal*3 AS VARCHAR(1)) ELSE CAST(@YYYYVal AS varchar(4))+CAST(@QQVal*3 AS VARCHAR(2)) END
	END

--SELECT @PrevQ,@NextQ

SELECT	AccountingPeriod
FROM	FDM_DB.DBO.DimAccountingPeriod
WHERE AccountingPeriod IN(@PrevQ,@NextQ)

END
GO

