﻿

CREATE Procedure [dbo].[USP_MDXQueryforYOABatch]
@Outputname VARCHAR(20),
@MDXQueryraw VARCHAR(MAX)
AS 
BEGIN




SELECT   NTILE(4) OVER(ORDER BY pk_YOA) YRNO,
		CASE WHEN pk_YOA=-1 THEN 'NO YOA' 
		ELSE
			CASE WHEN PK_YOA=9997 THEN 'OLD' 
		ELSE 
			CASE WHEN PK_YOA=9998 THEN 'NOYOA' 
		ELSE 
			CASE WHEN PK_YOA=9999 THEN 'CALX' 
		ELSE 
			CONVERT(VARCHAR(50),pk_YOA) 
		END 
			END 
				END 
					END AS YOA 
INTO #YOA 
FROM FDM_DB.[dbo].[DimYOA]


DECLARE @PrevQ VARCHAR(25)
DECLARE @NextQ VARCHAR(25)

DECLARE @DateVal AS DATETIME= GETDATE()

--SELECT @DateVal

DECLARE @MonthMod as INT= DATEPART(MM,@DateVal)%3

DECLARE @DayVal AS INT= DATEPART(DD,@DateVal)

DECLARE @YYYYVal AS INT= DATEPART(YYYY,@DateVal)

DECLARE @QQVal AS INT = DATEPART(QQ,@DateVal)

IF @MonthMod = 1 OR (@MonthMod = 2 and @DayVal <=15) 
BEGIN 

IF @QQVal = 1
BEGIN 
SELECT @PrevQ =  CAST(@YYYYVal-1 AS varchar(4))+'12',@NextQ =	CAST(@YYYYVal AS varchar(4))+'03'
END

ELSE 
	BEGIN 
		SELECT @NextQ = CASE WHEN @QQVal*3 <10 THEN  CAST(@YYYYVal AS varchar(4))+'0'+CAST(@QQVal*3 AS VARCHAR(1)) ELSE CAST(@YYYYVal AS varchar(4))+CAST(@QQVal*3 AS VARCHAR(2)) END
		SELECT @PrevQ = CASE WHEN (@QQVal-1)*3 <10 THEN  CAST(@YYYYVal AS varchar(4))+'0'+CAST((@QQVal-1)*3 AS VARCHAR(1)) ELSE CAST(@YYYYVal AS varchar(4))+CAST((@QQVal-1)*3 AS VARCHAR(1)) END
	END
END 

ELSE 
	BEGIN 
		SELECT @NextQ = CASE WHEN @QQVal*3 <10 THEN  CAST(@YYYYVal AS varchar(4))+'0'+CAST(@QQVal*3 AS VARCHAR(1)) ELSE CAST(@YYYYVal AS varchar(4))+CAST(@QQVal*3 AS VARCHAR(2)) END
	END

--SELECT @PrevQ,@NextQ

SELECT	AccountingPeriod
INTO #AcctPeriod
FROM	FDM_DB.DBO.DimAccountingPeriod
WHERE AccountingPeriod IN(@PrevQ,@NextQ)


SELECT A.YRNO,A.YOA,B.AccountingPeriod 
INTO #YOA_AcctPeriod
FROM #YOA A CROSS JOIN #AcctPeriod B



SELECT  ROW_NUMBER() OVER(PARTITION BY YRNO ORDER BY A.YOA) RNO,A.*
INTO #YOA_Batch 
FROM #YOA_AcctPeriod A
LEFT JOIN 
staging_agresso..StageMDXResults19_LTDYTD_100RemovingFields_201909 B 
ON B.AccountPeriod=A.AccountingPeriod AND A.YOA=B.YOA AND B.OutputName=@Outputname
WHERE B.AccountPeriod IS NULL AND B.YOA IS NULL 


CREATE TABLE #Qry(YRNO varchar(50), QRY VARCHAR(MAX))

DECLARE @YOARN_start int,
		@YOARN_end int,
		@START INT,
		@END INT,
		@Qry varchar(max)

SELECT @YOARN_start=MIN(YRNO),@YOARN_end=MAX(YRNO) FROM #YOA_Batch

WHILE (@YOARN_start<=@YOARN_end)
BEGIN
SET @START=1 
SET @Qry=''
SELECT @END=MAX(RNO) FROM #YOA_Batch WHERE YRNO=@YOARN_start
	WHILE (@START<=@END)
	BEGIN 
		declare @iAcctperiod int,@iYOA varchar(50),@iQuery Varchar(max)
		SELECT @iAcctperiod=AccountingPeriod,
			   @iYOA= CASE WHEN YOA='NO YOA' THEN '-1'
						ELSE
							CASE WHEN YOA='OLD' THEN '9997'
								ELSE 
								 CASE WHEN YOA='NOYOA' THEN '9998'
									ELSE 
										CASE WHEN YOA='CALX' THEN '9999'
											ELSE 
												YOA
						END 
							END 
								END 
									END  
		FROM #YOA_Batch 
		WHERE RNO=@Start and YRNO=@YOARN_start
		SELECT @iQuery=REPLACE(REPLACE('([YOA].[YOA].&[reYOA],[Accounting Period].[Accounting Period].&[reAcctperiod]),','reAcctperiod',@iAcctperiod),'reYOA',@iYOA)
		SELECT @Qry=CONCAT(@Qry,@iQuery)
		SET @START=@START+1
	END
INSERT INTO #Qry VALUES(@YOARN_start,LEFT(@Qry,CASE WHEN LEN(@QRY)-1<0 THEN LEN(@QRY) ELSE LEN(@QRY)-1 END))
SET @YOARN_start=@YOARN_start+1
END

UPDATE #Qry
SET QRY=REPLACE(@MDXQueryraw,'MDXCOMBINATION',QRY)
WHERE QRY <> ''


--SELECT DISTINCT QRY FROM #Qry WHERE QRY <> ''

SELECT DISTINCT QRY, 'WITH SET [TOP 10 RECORDS] AS
TOPCOUNT
(
NONEMPTY( ' +SUBSTRING(qry,CHARINDEX('NON EMPTY',qry)+9,(CHARINDEX('ON 1',qry))-(CHARINDEX('NON EMPTY',qry)+9))+'),10)'
+SUBSTRING(qry,CHARINDEX('select',qry),CHARINDEX('ON 0',qry)+5)+'{    [TOP 10 RECORDS] } ON 1  ' + SUBSTRING(qry,CHARINDEX('FROM', qry),LEN(qry)+1)  as Validate_Qry
FROM #Qry WHERE QRY <> ''

END
GO


