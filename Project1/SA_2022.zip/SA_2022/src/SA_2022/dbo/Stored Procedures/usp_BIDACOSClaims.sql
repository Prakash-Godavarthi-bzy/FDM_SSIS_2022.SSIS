﻿CREATE PROCEDURE   [dbo].[usp_BIDACOSClaims]
AS 
BEGIN
SELECT [Entity.EntityCode.EntityCode] As EntityCode,	
    [Account.Account.Account] As Account,
    [Trifocus.TrifocusCode.TrifocusCode] AS TrifocusCode,
    [YOA.YOA.YOA]	AS YOA,
    [FXTransactionCurrency.TransactionCurrency.TransactionCurrency] As Currency,
	FK_Account  = 80200,
	ProcessCode = '6A',
    [Measures.Amount]*-1 As cur_amount
FROM StageTDMMDXResults  WHERE [Account.Account.Account]='10011 - Gross Clm Reserve'
UNION
SELECT [Entity.EntityCode.EntityCode] As EntityCode,	
    [Account.Account.Account] As Account,
    [Trifocus.TrifocusCode.TrifocusCode] AS TrifocusCode,
    [YOA.YOA.YOA]	AS YOA,
    [FXTransactionCurrency.TransactionCurrency.TransactionCurrency] As Currency,
	FK_Account  = 22100,
	ProcessCode = '6A',
    [Measures.Amount] As cur_amount
       
FROM StageTDMMDXResults  WHERE [Account.Account.Account]='10011 - Gross Clm Reserve'
UNION
SELECT [Entity.EntityCode.EntityCode] As EntityCode,	
        [Account.Account.Account] As Account,
        [Trifocus.TrifocusCode.TrifocusCode] AS TrifocusCode,
        [YOA.YOA.YOA]	AS YOA,
        [FXTransactionCurrency.TransactionCurrency.TransactionCurrency] As Currency,
		FK_Account  = 73200,
		ProcessCode = '6B',
        [Measures.Amount]*-1  As cur_amount
      
FROM StageTDMMDXResults  WHERE [Account.Account.Account]='10013 - RI Clm Reserve'
UNION
SELECT [Entity.EntityCode.EntityCode] As EntityCode,	
        [Account.Account.Account] As Account,
        [Trifocus.TrifocusCode.TrifocusCode] AS TrifocusCode,
        [YOA.YOA.YOA]	AS YOA,
        [FXTransactionCurrency.TransactionCurrency.TransactionCurrency] As Currency,
		FK_Account  = 23100,
		ProcessCode = '6B',
        [Measures.Amount]  As cur_amount
FROM StageTDMMDXResults  WHERE [Account.Account.Account]='10013 - RI Clm Reserve'

-----------
UNION
SELECT [Entity.EntityCode.EntityCode] As EntityCode,	
    [Account.Account.Account] As Account,
    [Trifocus.TrifocusCode.TrifocusCode] AS TrifocusCode,
    [YOA.YOA.YOA]	AS YOA,
    [FXTransactionCurrency.TransactionCurrency.TransactionCurrency] As Currency,
	FK_Account  = 20100,
	ProcessCode = '4K',
    [Measures.Amount] As cur_amount
FROM StageTDMMDXResults  WHERE [Account.Account.Account]='10010 - Gross Clm Paid'
UNION
SELECT [Entity.EntityCode.EntityCode] As EntityCode,	
    [Account.Account.Account] As Account,
    [Trifocus.TrifocusCode.TrifocusCode] AS TrifocusCode,
    [YOA.YOA.YOA]	AS YOA,
    [FXTransactionCurrency.TransactionCurrency.TransactionCurrency] As Currency,
	FK_Account  = 74452,
	ProcessCode = '4K',
    [Measures.Amount]*-1 As cur_amount
       
FROM StageTDMMDXResults  WHERE [Account.Account.Account]='10010 - Gross Clm Paid'
UNION
SELECT [Entity.EntityCode.EntityCode] As EntityCode,	
        [Account.Account.Account] As Account,
        [Trifocus.TrifocusCode.TrifocusCode] AS TrifocusCode,
        [YOA.YOA.YOA]	AS YOA,
        [FXTransactionCurrency.TransactionCurrency.TransactionCurrency] As Currency,
		FK_Account  = 21100,
		ProcessCode = '4N',
        [Measures.Amount]   As cur_amount
      
FROM StageTDMMDXResults  WHERE [Account.Account.Account]='10012 - RI Clm Paid'
UNION
SELECT [Entity.EntityCode.EntityCode] As EntityCode,	
        [Account.Account.Account] As Account,
        [Trifocus.TrifocusCode.TrifocusCode] AS TrifocusCode,
        [YOA.YOA.YOA]	AS YOA,
        [FXTransactionCurrency.TransactionCurrency.TransactionCurrency] As Currency,
		FK_Account  = 74415,
		ProcessCode = '4N',
        [Measures.Amount] * -1 As cur_amount
FROM StageTDMMDXResults  WHERE [Account.Account.Account]='10012 - RI Clm Paid'
END
