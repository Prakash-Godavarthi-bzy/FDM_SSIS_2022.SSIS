﻿

CREATE PROCEDURE [dbo].[GetAllTrees](@type as nvarchar(255))

AS 

IF OBJECT_ID (N'tempdb..#tree') IS NOT NULL
    DROP TABLE #tree

	
DECLARE @cutoverClient as varchar(5)
SELECT  top 1 @cutoverClient=  [client]  FROM [staging_agresso].[dbo].[AMCCutoverConfig]	

DECLARE @i INT

CREATE TABLE #tree (
	[pkDimAccountTree]			nvarchar(255)
	,[Description]				nvarchar(255)
	,[pkDimAccountTreeParent]	nvarchar(255)
)

INSERT INTO #tree

SELECT 
	[pkDimAccountTree] = cast(s.[att_agrid] as nvarchar(255)) + '_' + cast(s.[att_agrid] as nvarchar(255))
	,[Description] = cast(s.description as nvarchar(255))
	,[pkDimAccountTreeParent] = cast(null as nvarchar(255))
FROM 
	[dbo].[acrtreesetup] s
WHERE
	s.att_1_col = @type and 
	(s.client = (SELECT top 1  [client]  FROM [staging_agresso].[dbo].[AMCCutoverConfig]) OR s.client ='*')  and
	len(ltrim(rtrim(s.att_2_id))) = 0

DECLARE c CURSOR for
	select [att_agrid] from acrtreesetup where att_1_col = @type and (client = (SELECT top 1  [client]
  FROM [staging_agresso].[dbo].[AMCCutoverConfig]) OR client ='*') and
	len(ltrim(rtrim(att_2_id))) = 0
OPEN c
FETCH NEXT FROM c into @i
WHILE @@FETCH_STATUS = 0
BEGIN
	INSERT INTO #tree
	select 
		*
	FROM
		dbo.GetTree(@i,@cutoverClient)
	FETCH NEXT FROM c into @i
END

close c
deallocate c

update #tree set
	[pkDimAccountTreeParent] = dbo.R_TRIM([pkDimAccountTreeParent],'_')



select * from #tree

drop table #tree
