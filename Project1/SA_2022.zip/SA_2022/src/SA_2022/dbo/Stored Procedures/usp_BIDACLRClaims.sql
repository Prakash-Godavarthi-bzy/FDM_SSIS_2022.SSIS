﻿CREATE PROCEDURE [dbo].[usp_BIDACLRClaims]
AS
BEGIN
SELECT 
    [Account.AccountCode.AccountCode] As Account,
    [Trifocus.TrifocusCode.TrifocusCode] AS TrifocusCode,
    [YOA.YOA.YOA]	AS YOA,
    [CurTransactionCurrency.TranCurr.TranCurr] As Currency,
	FK_Account  = 1010081,
	ProcessCode = '6E',
	CASE WHEN [Location.LocationCode.LocationCode]='London'THEN 'BIUK' 
	 WHEN [Location.LocationCode.LocationCode]='Barcelona'THEN 'BISP'
	 WHEN [Location.LocationCode.LocationCode]='Munich'THEN 'BIGE'
	 WHEN [Location.LocationCode.LocationCode]='Paris'THEN 'BIFR'
	 WHEN [Location.LocationCode.LocationCode]='Zurich'THEN 'BISW'
	 WHEN [Location.LocationCode.LocationCode] IN ('',NULL)THEN 'Unknown' END As EntityCode,	
	 [Location.LocationCode.LocationCode] as OfficeLoacation,
    [Measures.Amount] As cur_amount
FROM StageMDXResults  WHERE [Account.AccountCode.AccountCode]= '10081 - Gross Ultimate Premium'
---------------------------------
UNION
SELECT 	
    [Account.AccountCode.AccountCode] As Account,
    [Trifocus.TrifocusCode.TrifocusCode] AS TrifocusCode,
    [YOA.YOA.YOA]	AS YOA,
    [CurTransactionCurrency.TranCurr.TranCurr] As Currency,
	FK_Account  = 1010082,
	ProcessCode = '6E',
	CASE WHEN [Location.LocationCode.LocationCode]='London'THEN 'BIUK' 
	 WHEN [Location.LocationCode.LocationCode]='Barcelona'THEN 'BISP'
	 WHEN [Location.LocationCode.LocationCode]='Munich'THEN 'BIGE'
	 WHEN [Location.LocationCode.LocationCode]='Paris'THEN 'BIFR'
	 WHEN [Location.LocationCode.LocationCode]='Zurich'THEN 'BISW'
	 WHEN [Location.LocationCode.LocationCode]IN ('',NULL)THEN 'Unknown' END As EntityCode,
	 [Location.LocationCode.LocationCode] as OfficeLoacation,
    [Measures.Amount] As cur_amount
       
FROM StageMDXResults  WHERE [Account.AccountCode.AccountCode]= '10082 - Gross Ultimate Claim'
--------------------------------------

UNION
SELECT 	
        [Account.AccountCode.AccountCode] As Account,
        [Trifocus.TrifocusCode.TrifocusCode] AS TrifocusCode,
        [YOA.YOA.YOA]	AS YOA,
        [CurTransactionCurrency.TranCurr.TranCurr] As Currency,
		FK_Account  = 1010086,
		ProcessCode = '6F',
		CASE WHEN [Location.LocationCode.LocationCode]='London'THEN 'BIUK' 
	 WHEN [Location.LocationCode.LocationCode]='Barcelona'THEN 'BISP'
	 WHEN [Location.LocationCode.LocationCode]='Munich'THEN 'BIGE'
	 WHEN [Location.LocationCode.LocationCode]='Paris'THEN 'BIFR'
	 WHEN [Location.LocationCode.LocationCode]='Zurich'THEN 'BISW'
	 WHEN [Location.LocationCode.LocationCode]IN ('',NULL)THEN 'Unknown' END As EntityCode,
	 [Location.LocationCode.LocationCode] as OfficeLoacation,
        [Measures.Amount]  As cur_amount
      
FROM StageMDXResults  WHERE [Account.AccountCode.AccountCode]= '10086 - Net Ultimate Premium'
-----------------------
UNION
SELECT 
        [Account.AccountCode.AccountCode] As Account,
        [Trifocus.TrifocusCode.TrifocusCode] AS TrifocusCode,
        [YOA.YOA.YOA]	AS YOA,
        [CurTransactionCurrency.TranCurr.TranCurr] As Currency,
		FK_Account  = 1010087,
		ProcessCode = '6F',
		CASE WHEN [Location.LocationCode.LocationCode]='London'THEN 'BIUK' 
	 WHEN [Location.LocationCode.LocationCode]='Barcelona'THEN 'BISP'
	 WHEN [Location.LocationCode.LocationCode]='Munich'THEN 'BIGE'
	 WHEN [Location.LocationCode.LocationCode]='Paris'THEN 'BIFR'
	 WHEN [Location.LocationCode.LocationCode]='Zurich'THEN 'BISW'
	 WHEN [Location.LocationCode.LocationCode]IN ('',NULL)THEN 'Unknown' END As EntityCode,
	 [Location.LocationCode.LocationCode] as OfficeLoacation,
        [Measures.Amount]  As cur_amount
FROM StageMDXResults  WHERE [Account.AccountCode.AccountCode]= '10087 - Net Ultimate Claim'

END