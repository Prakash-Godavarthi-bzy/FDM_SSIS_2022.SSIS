﻿CREATE TABLE [dbo].[aglrelation] (
    [att_name]     VARCHAR (25) NULL,
    [attribute_id] VARCHAR (4)  NULL,
    [bflag]        INT          NULL,
    [client]       VARCHAR (25) NULL,
    [dim_v1_txt]   VARCHAR (25) NULL,
    [duplicates]   TINYINT      NULL,
    [flag]         VARCHAR (1)  NULL,
    [last_update]  DATETIME     NULL,
    [maintenance]  VARCHAR (1)  NULL,
    [module]       VARCHAR (3)  NULL,
    [percent_set]  TINYINT      NULL,
    [period_id]    VARCHAR (25) NULL,
    [rel_attr_id]  VARCHAR (4)  NULL,
    [rel_grp]      VARCHAR (25) NULL,
    [related_attr] VARCHAR (25) NULL,
    [required]     VARCHAR (1)  NULL,
    [sort_order]   INT          NULL,
    [user_id]      VARCHAR (25) NULL,
    [agrtid]       BIGINT       NULL
);

