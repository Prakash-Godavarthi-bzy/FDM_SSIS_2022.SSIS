﻿CREATE TABLE [dbo].[TrifocusTreeStage] (
    [pkDimTrifocusTree]       NVARCHAR (255) NULL,
    [Description]             NVARCHAR (255) NULL,
    [pkDimTrifocusTreeParent] NVARCHAR (255) NULL
);

