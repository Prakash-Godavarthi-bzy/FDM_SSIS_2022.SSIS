﻿CREATE TABLE [dbo].[RISpendMunichCedePercentage] (
    [RISpendMunichCedePercentagesId] INT             IDENTITY (1, 1) NOT NULL,
    [YOA]                            INT             NULL,
    [Entity]                         NVARCHAR (20)   NULL,
    [TrifocusCode]                   NVARCHAR (255)  NULL,
    [TrifocusName]                   NVARCHAR (255)  NULL,
    [Percentage]                     DECIMAL (10, 5) NULL,
    [ORCPercentage]                  DECIMAL (10, 5) NULL,
    CONSTRAINT [PK_RISpendMunichCedePercentage] PRIMARY KEY CLUSTERED ([RISpendMunichCedePercentagesId] ASC) WITH (FILLFACTOR = 90)
);

