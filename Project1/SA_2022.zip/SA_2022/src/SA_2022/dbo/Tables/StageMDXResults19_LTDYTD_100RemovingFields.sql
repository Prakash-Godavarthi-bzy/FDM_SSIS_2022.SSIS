﻿CREATE TABLE [dbo].[StageMDXResults19_LTDYTD_100RemovingFields] (
    [Entity]                   VARCHAR (250) NULL,
    [Account Code]             VARCHAR (250) NULL,
    [Account Name]             VARCHAR (250) NULL,
    [Tran Curr]                VARCHAR (250) NULL,
    [Trifocus Code]            VARCHAR (250) NULL,
    [Tri Focus Name]           VARCHAR (250) NULL,
    [TransCurrencyAmount]      VARCHAR (250) NULL,
    [GroupCurrencyAmount]      VARCHAR (250) NULL,
    [FunctionalCurrencyAmount] VARCHAR (250) NULL,
    [Module]                   VARCHAR (50)  NULL,
    [OutputName]               VARCHAR (50)  NULL,
    [AccountPeriod]            VARCHAR (50)  NULL,
    [YOA]                      VARCHAR (50)  NULL,
    [LoadTime]                 DATETIME      NULL
);
GO