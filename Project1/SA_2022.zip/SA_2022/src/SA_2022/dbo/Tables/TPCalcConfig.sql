﻿CREATE TABLE [dbo].[TPCalcConfig] (
    [TargetAccount] BIGINT        NULL,
    [Entity]        VARCHAR (50)  NULL,
    [Calc]          VARCHAR (MAX) NULL
);

