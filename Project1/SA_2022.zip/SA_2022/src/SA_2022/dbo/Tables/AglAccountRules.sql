﻿CREATE TABLE [dbo].[AglAccountRules] (
    [client]       VARCHAR (25)  NULL,
    [account]      VARCHAR (25)  NULL,
    [account_rule] INT           NULL,
    [Dim1Field]    VARCHAR (255) NULL,
    [Dim2Field]    VARCHAR (255) NULL,
    [Dim3Field]    VARCHAR (255) NULL,
    [Dim4Field]    VARCHAR (255) NULL,
    [Dim5Field]    VARCHAR (255) NULL,
    [Dim6Field]    VARCHAR (255) NULL,
    [Dim7Field]    VARCHAR (255) NULL
);

