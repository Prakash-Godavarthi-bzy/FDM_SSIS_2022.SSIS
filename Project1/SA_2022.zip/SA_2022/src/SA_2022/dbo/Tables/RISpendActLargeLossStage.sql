﻿CREATE TABLE [dbo].[RISpendActLargeLossStage] (
    [RISpendActLargeLossStageId] INT              IDENTITY (1, 1) NOT NULL,
    [Quarter]                    NVARCHAR (7)     NULL,
    [YOA]                        INT              NULL,
    [TrifocusCode]               NVARCHAR (255)   NULL,
    [TrifocusName]               NVARCHAR (255)   NULL,
    [Entity]                     NVARCHAR (20)    NULL,
    [CCY]                        NVARCHAR (5)     NULL,
    [InwardsUltReinstatements]   NUMERIC (18, 10) NULL,
    [OutwardsUltReinstatements]  NUMERIC (18, 10) NULL,
    CONSTRAINT [PK_RISpendActLargeLossStage] PRIMARY KEY CLUSTERED ([RISpendActLargeLossStageId] ASC) WITH (FILLFACTOR = 90)
);

