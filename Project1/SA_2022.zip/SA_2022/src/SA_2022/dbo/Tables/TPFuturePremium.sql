﻿CREATE TABLE [dbo].[TPFuturePremium] (
    [TPDataType]  VARCHAR (50) NULL,
    [PremiumType] VARCHAR (50) NULL
);

