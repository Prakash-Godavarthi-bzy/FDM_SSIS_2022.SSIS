﻿CREATE TABLE [dbo].[StageBIDACLRClaims](
	[EntityCode] [varchar](50) NULL,
	[Account] [varchar](250) NULL,
	[TrifocusCode] [varchar](50) NULL,
	[YOA] [varchar](50) NULL,
	[Currency] [varchar](50) NULL,
	[FK_Account] [int] NULL,
	[cur_amount] [numeric](30, 3) NULL,
	[ProcessCode] [varchar](3) NULL,
	[OfficeLocation] [varchar](50) NULL
) ;
