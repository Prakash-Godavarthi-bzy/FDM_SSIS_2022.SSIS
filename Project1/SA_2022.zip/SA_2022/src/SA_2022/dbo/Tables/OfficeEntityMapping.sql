﻿CREATE TABLE [dbo].[OfficeEntityMapping] (
    [pk_OfficeEntityMapping] INT           IDENTITY (1, 1) NOT NULL,
    [OfficeCode]             NVARCHAR (50) NULL,
    [EntityCode]             NVARCHAR (50) NULL,
    CONSTRAINT [PK_OfficeEntityMapping] PRIMARY KEY CLUSTERED ([pk_OfficeEntityMapping] ASC) WITH (FILLFACTOR = 90)
);

