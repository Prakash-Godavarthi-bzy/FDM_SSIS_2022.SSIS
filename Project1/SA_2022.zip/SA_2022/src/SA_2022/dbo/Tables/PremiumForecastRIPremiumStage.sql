﻿CREATE TABLE [dbo].[PremiumForecastRIPremiumStage] (
    [PremiumForecastRIPremiumStageId] INT             IDENTITY (1, 1) NOT NULL,
    [Period]                          NVARCHAR (7)    NULL,
    [AccountingPeriod]                INT             NULL,
    [YOA]                             INT             NULL,
    [Entity]                          NVARCHAR (20)   NULL,
    [TrifocusCode]                    NVARCHAR (255)  NULL,
    [RIProgramme]                     NVARCHAR (255)  NULL,
    [RIType]                          NVARCHAR (10)   NULL,
    [Currency]                        NVARCHAR (5)    NULL,
    [RIPremium]                       NUMERIC (18, 9) NULL,
    CONSTRAINT [PK_PremiumForecastRIPremiumStage] PRIMARY KEY CLUSTERED ([PremiumForecastRIPremiumStageId] ASC) WITH (FILLFACTOR = 90)
);

