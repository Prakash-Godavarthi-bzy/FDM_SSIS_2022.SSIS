﻿CREATE TABLE [dbo].[EntityTreeStage] (
    [pkDimEntityTree]       NVARCHAR (255) NULL,
    [Description]           NVARCHAR (255) NULL,
    [pkDimEntityTreeParent] NVARCHAR (255) NULL
);

