﻿CREATE TABLE [dbo].[TPDataConfig] (
    [Gross_Net]   VARCHAR (50)  NULL,
    [TreatyType]  VARCHAR (50)  NULL,
    [MeasureType] VARCHAR (255) NULL,
    [Account]     BIGINT        NULL,
    [PremiumType] VARCHAR (255) NULL
);

