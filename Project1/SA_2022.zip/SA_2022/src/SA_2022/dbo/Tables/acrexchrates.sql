﻿CREATE TABLE [dbo].[acrexchrates] (
    [client]      VARCHAR (25)    NULL,
    [cur_type]    VARCHAR (25)    NULL,
    [cur_unit]    INT             NULL,
    [currency]    VARCHAR (25)    NULL,
    [date_from]   DATETIME        NULL,
    [date_to]     DATETIME        NULL,
    [exch_rate]   NUMERIC (28, 8) NULL,
    [last_update] DATETIME        NULL,
    [rate_exp]    SMALLINT        NULL,
    [reg_rate]    NUMERIC (28, 8) NULL,
    [sequence_no] INT             NULL,
    [user_id]     VARCHAR (25)    NULL,
    [agrtid]      BIGINT          NULL
);

