﻿CREATE TABLE [dbo].[aglrelvalue] (
    [att_val_from] VARCHAR (25)     NULL,
    [att_val_to]   VARCHAR (25)     NULL,
    [att_value]    VARCHAR (25)     NULL,
    [attribute_id] VARCHAR (4)      NULL,
    [client]       VARCHAR (25)     NULL,
    [date_from]    DATETIME         NULL,
    [date_to]      DATETIME         NULL,
    [last_update]  DATETIME         NULL,
    [percentage]   NUMERIC (28, 8)  NULL,
    [priority]     INT              NULL,
    [rel_attr_id]  VARCHAR (4)      NULL,
    [rel_id]       UNIQUEIDENTIFIER NULL,
    [rel_value]    VARCHAR (25)     NULL,
    [user_id]      VARCHAR (25)     NULL,
    [value_1]      NUMERIC (28, 8)  NULL,
    [agrtid]       BIGINT           NULL
);


GO
CREATE NONCLUSTERED INDEX [nlx_aglrelvalue_psec]
    ON [dbo].[aglrelvalue]([client] ASC, [rel_attr_id] ASC)
    INCLUDE([att_value], [rel_value]) WITH (FILLFACTOR = 90);

