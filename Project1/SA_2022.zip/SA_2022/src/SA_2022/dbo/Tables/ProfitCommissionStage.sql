﻿CREATE TABLE [dbo].[ProfitCommissionStage] (
    [ProfitCommissionStageId] INT             IDENTITY (1, 1) NOT NULL,
    [AccountingPeriod]        INT             NULL,
    [YOA]                     INT             NULL,
    [AccountCode]             NVARCHAR (20)   NULL,
    [Client]                  NVARCHAR (20)   NULL,
    [Entity]                  NVARCHAR (20)   NULL,
    [TrifocusCode]            NVARCHAR (255)  NULL,
    [Currency]                NVARCHAR (5)    NULL,
    [cur_amount]              NUMERIC (18, 9) NULL,
    [amount]                  NUMERIC (18, 9) NULL,
    [value_2]                 NUMERIC (18, 9) NULL,
    [value_3]                 NUMERIC (18, 9) NULL,
    CONSTRAINT [PK_ProfitCommissionStage] PRIMARY KEY CLUSTERED ([ProfitCommissionStageId] ASC) WITH (FILLFACTOR = 90)
);

