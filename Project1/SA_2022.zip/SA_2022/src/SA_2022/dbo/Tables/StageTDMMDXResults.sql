﻿CREATE TABLE [dbo].[StageTDMMDXResults] (
    [Entity.EntityCode.EntityCode]                                  VARCHAR (50)    NULL,
    [Account.Account.Account]                                       VARCHAR (250)   NULL,
    [Measures.Amount]                                               NUMERIC (18, 2) NULL,
    [Trifocus.TrifocusCode.TrifocusCode]                            VARCHAR (50)    NULL,
    [YOA.YOA.YOA]                                                   VARCHAR (50)    NULL,
    [FXTransactionCurrency.TransactionCurrency.TransactionCurrency] VARCHAR (50)    NULL,
    [Module]                                                        VARCHAR (50)    NULL,
    [OutputName]                                                    VARCHAR (50)    NULL
);

