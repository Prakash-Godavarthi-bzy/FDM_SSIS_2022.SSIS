﻿CREATE TABLE [dbo].[afxclientent] (
    [attribute_id] CHAR (4)     NOT NULL,
    [dim_value]    VARCHAR (25) NOT NULL,
    [line_no]      INT          NOT NULL,
    [client]       VARCHAR (25) NOT NULL,
    [date_from]    DATETIME     NOT NULL,
    [date_to]      DATETIME     NOT NULL,
    [entity_fx]    VARCHAR (25) NOT NULL,
    [last_update]  DATETIME     NOT NULL,
    [user_id]      CHAR (25)    NOT NULL,
    [agrtid]       BIGINT       NOT NULL
);

