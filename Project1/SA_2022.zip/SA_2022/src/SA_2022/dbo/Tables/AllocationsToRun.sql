﻿CREATE TABLE [dbo].[AllocationsToRun] (
    [AllocationGroup] VARCHAR (100) NULL,
    [AllocationCode]  VARCHAR (100) NULL,
    [AccountPeriod]   VARCHAR (100) NULL
);

