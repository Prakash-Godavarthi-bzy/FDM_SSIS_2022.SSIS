﻿CREATE TABLE [dbo].[EurobaseEPI] (
    [Policy Reference]           NVARCHAR (255) NULL,
    [Inception Date]             DATETIME       NULL,
    [Expiry Date]                DATETIME       NULL,
    [Underwriter Name]           NVARCHAR (255) NULL,
    [Department]                 NVARCHAR (255) NULL,
    [TriFocus Group]             NVARCHAR (255) NULL,
    [Policy YOA]                 NVARCHAR (255) NULL,
    [Stats Code]                 NVARCHAR (255) NULL,
    [Policy Settlement Currency] NVARCHAR (255) NULL,
    [Syndicate Number]           NVARCHAR (255) NULL,
    [Total Acquisition Cost]     FLOAT (53)     NULL,
    [Estimated Premium Income]   FLOAT (53)     NULL,
    [LBS Ceding Commission]      FLOAT (53)     NULL,
    [MOP]                        NVARCHAR (255) NULL,
    [report_date]                DATETIME       NULL
);

