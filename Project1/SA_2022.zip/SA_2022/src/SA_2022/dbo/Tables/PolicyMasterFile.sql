﻿CREATE TABLE [dbo].[PolicyMasterFile] (
    [PolicyType] VARCHAR (6)  NULL,
    [mop]        VARCHAR (25) NULL,
    [section]    VARCHAR (25) NULL,
    [policy]     VARCHAR (25) NULL
);

