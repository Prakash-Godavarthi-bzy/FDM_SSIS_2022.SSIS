﻿CREATE TABLE [dbo].[RISpendTriFocusMapping] (
    [RISpendTrifocusMappingId] INT            IDENTITY (1, 1) NOT NULL,
    [SourceTriFocus]           NVARCHAR (255) NULL,
    [FDMTriFocusCode]          NVARCHAR (255) NULL,
    [Sourcesystem]             NVARCHAR (255) NULL,
    CONSTRAINT [PK_RISpendTrifocusMapping] PRIMARY KEY CLUSTERED ([RISpendTrifocusMappingId] ASC) WITH (FILLFACTOR = 90)
);

