﻿CREATE TABLE [dbo].[AccountTreeStage] (
    [pkDimAccountTree]       NVARCHAR (255) NULL,
    [Description]            NVARCHAR (255) NULL,
    [pkDimAccountTreeParent] NVARCHAR (255) NULL
);

