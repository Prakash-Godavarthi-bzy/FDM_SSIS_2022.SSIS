﻿CREATE TABLE [dbo].[ProductTreeStage] (
    [pkDimProductTree]       NVARCHAR (255) NULL,
    [Description]            NVARCHAR (255) NULL,
    [pkDimProductTreeParent] NVARCHAR (255) NULL
);

