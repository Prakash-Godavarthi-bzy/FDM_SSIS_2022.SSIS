﻿CREATE TABLE [dbo].[MostRecentDate] (
    [MostRecentDate] DATETIME NOT NULL
);

