﻿CREATE TABLE [dbo].[acrvouchtype] (
    [client]       VARCHAR (25)  NULL,
    [description]  VARCHAR (255) NULL,
    [last_update]  DATETIME      NULL,
    [status]       VARCHAR (1)   NULL,
    [treat_code]   VARCHAR (25)  NULL,
    [user_id]      VARCHAR (25)  NULL,
    [vouch_series] VARCHAR (2)   NULL,
    [voucher_type] VARCHAR (25)  NULL,
    [agrtid]       BIGINT        NULL
);

