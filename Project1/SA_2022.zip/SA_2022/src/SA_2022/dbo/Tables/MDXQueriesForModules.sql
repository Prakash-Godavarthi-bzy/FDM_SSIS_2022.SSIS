﻿CREATE TABLE [dbo].[MDXQueriesForModules] (
    [Module]     NVARCHAR (50)  NULL,
    [OutputName] NVARCHAR (50)  NULL,
    [MDXQuery]   NVARCHAR (MAX) NULL
);

