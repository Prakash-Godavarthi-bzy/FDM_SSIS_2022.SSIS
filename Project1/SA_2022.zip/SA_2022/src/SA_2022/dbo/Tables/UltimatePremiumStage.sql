﻿CREATE TABLE [dbo].[UltimatePremiumStage] (
    [UltimatePremiumStageId]      INT             IDENTITY (1, 1) NOT NULL,
    [Period]                      NVARCHAR (7)    NULL,
    [YOA]                         NVARCHAR (20)   NULL,
    [OrigEntity]                  NVARCHAR (20)   NULL,
    [Entity]                      NVARCHAR (20)   NULL,
    [PercentageSplit]             FLOAT (53)      NULL,
    [TrifocusCode]                NVARCHAR (255)  NULL,
    [TrifocusName]                NVARCHAR (255)  NULL,
    [Currency]                    NVARCHAR (5)    NULL,
    [SyndicateGrossGrossPremium]  NUMERIC (18, 9) NULL,
    [SyndicateExternalBrokerage]  NUMERIC (18, 9) NULL,
    [SyndicateInternalCommission] NUMERIC (18, 9) NULL,
    [SyndicateGrossNetPremium]    NUMERIC (18, 9) NULL
);

