﻿CREATE TABLE [dbo].[tmp_FactFXRate] (
    [fk_AccountingPeriod]    INT             NOT NULL,
    [fk_FXRate]              INT             NOT NULL,
    [fk_TransactionCurrency] NVARCHAR (25)   NOT NULL,
    [fk_ReportingCurrency]   INT             NOT NULL,
    [RateDate]               DATE            NULL,
    [FXRate]                 NUMERIC (28, 8) NULL,
    [fk_RateScenario]        INT             NULL
);

