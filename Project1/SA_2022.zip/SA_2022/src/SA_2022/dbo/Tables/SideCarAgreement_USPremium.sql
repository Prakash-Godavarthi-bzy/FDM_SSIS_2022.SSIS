﻿CREATE TABLE [dbo].[SideCarAgreement_USPremium]
(
	[Trifocus] [nvarchar](50) NOT NULL,
	[StatsCode] [nvarchar](50) NOT NULL,
	[YOA] [smallint] NOT NULL,
	[CedePercent] [numeric](10, 4) NOT NULL
) ON [PRIMARY]