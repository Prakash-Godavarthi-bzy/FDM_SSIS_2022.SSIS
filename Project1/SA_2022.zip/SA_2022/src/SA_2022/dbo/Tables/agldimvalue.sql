﻿CREATE TABLE [dbo].[agldimvalue] (
    [attribute_id] VARCHAR (4)     NULL,
    [client]       VARCHAR (25)    NULL,
    [description]  VARCHAR (255)   NULL,
    [dim_value]    VARCHAR (25)    NULL,
    [last_update]  DATETIME        NULL,
    [period_from]  INT             NULL,
    [period_to]    INT             NULL,
    [rel_value]    VARCHAR (25)    NULL,
    [status]       VARCHAR (1)     NULL,
    [user_id]      VARCHAR (25)    NULL,
    [value_1]      NUMERIC (28, 8) NULL,
    [wf_state]     VARCHAR (1)     NULL,
    [agrtid]       BIGINT          NULL
);


GO
CREATE NONCLUSTERED INDEX [nlx_agldimvalue_psec]
    ON [dbo].[agldimvalue]([attribute_id] ASC, [client] ASC, [dim_value] ASC) WITH (FILLFACTOR = 90);

