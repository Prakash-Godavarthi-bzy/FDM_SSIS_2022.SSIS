﻿CREATE TABLE [dbo].[StageBIDACOSClaims](
	[EntityCode] [varchar](50) NULL,
	[Account] [varchar](250) NULL,
	[TrifocusCode] [varchar](50) NULL,
	[YOA] [varchar](50) NULL,
	[Currency] [varchar](50) NULL,
	[FK_Account] [int] NULL,
	[ProcessCode] [varchar](2) NULL,
	[cur_amount] [numeric](12, 2) NULL
) ;
GO
