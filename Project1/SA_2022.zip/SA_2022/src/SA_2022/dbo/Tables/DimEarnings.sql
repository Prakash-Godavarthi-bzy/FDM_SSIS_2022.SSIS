﻿CREATE TABLE [dbo].[DimEarnings] (
    [pk_DimEarnings] BIGINT         IDENTITY (1, 10) NOT NULL,
    [InceptionDate]  DATE           NULL,
    [ExpiryDate]     DATE           NULL,
    [PolicyYOA]      INT            NULL,
    [PolicyType]     NVARCHAR (255) NULL,
    [USPolicy]       SMALLINT       NULL,
    [KrRePolicy]     SMALLINT       NULL,
    CONSTRAINT [PK_DimEarnings] PRIMARY KEY CLUSTERED ([pk_DimEarnings] ASC) WITH (FILLFACTOR = 90)
);

