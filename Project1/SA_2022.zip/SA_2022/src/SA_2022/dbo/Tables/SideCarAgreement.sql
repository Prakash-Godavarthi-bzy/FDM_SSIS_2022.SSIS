﻿CREATE TABLE [dbo].[SideCarAgreement] (
    [Trifocus]    NVARCHAR (50)   NOT NULL,
    [StatsCode]   NVARCHAR (50)   NOT NULL,
    [YOA]         SMALLINT        NOT NULL,
    [CedePercent] NUMERIC (10, 4) NOT NULL
);

