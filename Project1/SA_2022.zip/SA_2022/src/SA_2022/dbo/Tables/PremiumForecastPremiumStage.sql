﻿CREATE TABLE [dbo].[PremiumForecastPremiumStage] (
    [PremiumForecastPremiumStageId] INT             IDENTITY (1, 1) NOT NULL,
    [Period]                        NVARCHAR (7)    NULL,
    [AccountingPeriod]              INT             NULL,
    [YOA]                           INT             NULL,
    [EntityRISideCar]               NVARCHAR (20)   NULL,
    [Entity]                        NVARCHAR (20)   NULL,
    [TrifocusCode]                  NVARCHAR (255)  NULL,
    [MoP]                           NVARCHAR (20)   NULL,
    [InceptionDate]                 DATE            NULL,
    [InceptionMonth]                INT             NULL,
    [Currency]                      NVARCHAR (5)    NULL,
    [GrossGrossPremium]             NUMERIC (18, 9) NULL,
    [ExternalBrokerage]             NUMERIC (18, 9) NULL,
    [InternalCommission]            NUMERIC (18, 9) NULL,
    [GrossNetPremium]               NUMERIC (18, 9) NULL,
    CONSTRAINT [PK_PremiumForecastPremiumStage] PRIMARY KEY CLUSTERED ([PremiumForecastPremiumStageId] ASC) WITH (FILLFACTOR = 90)
);

