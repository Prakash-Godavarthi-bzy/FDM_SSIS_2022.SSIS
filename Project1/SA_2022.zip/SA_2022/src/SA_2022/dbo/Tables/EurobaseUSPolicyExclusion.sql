﻿CREATE TABLE [dbo].[EurobaseUSPolicyExclusion] (
    [UsPolicyRef] NVARCHAR (15) NOT NULL
);

