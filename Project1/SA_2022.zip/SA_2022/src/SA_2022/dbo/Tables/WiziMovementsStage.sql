﻿CREATE TABLE [dbo].[WiziMovementsStage] (
    [Period]          NVARCHAR (255)  NULL,
    [YOA]             NVARCHAR (255)  NULL,
    [Currency]        NVARCHAR (25)   NULL,
    [Entity]          NVARCHAR (255)  NULL,
    [TriangleGroup]   NVARCHAR (255)  NULL,
    [Special]         NVARCHAR (255)  NULL,
    [SpecialGroup]    NVARCHAR (255)  NULL,
    [ClassofBusiness] NVARCHAR (255)  NULL,
    [Account]         NVARCHAR (255)  NULL,
    [Amount]          DECIMAL (28, 3) NULL
);

