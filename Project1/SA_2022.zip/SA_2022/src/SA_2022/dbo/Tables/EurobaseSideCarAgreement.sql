﻿CREATE TABLE [dbo].[EurobaseSideCarAgreement] (
    [StatsCode]   NVARCHAR (50)  NOT NULL,
    [YOA]         SMALLINT       NOT NULL,
    [CedePercent] NUMERIC (6, 2) NOT NULL
);

