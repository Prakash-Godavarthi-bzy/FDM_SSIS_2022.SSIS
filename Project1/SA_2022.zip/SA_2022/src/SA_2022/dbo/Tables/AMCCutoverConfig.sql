﻿CREATE TABLE [dbo].[AMCCutoverConfig] (
    [AccountingPeriod] VARCHAR (6)  NULL,
    [client]           VARCHAR (25) NULL
);

