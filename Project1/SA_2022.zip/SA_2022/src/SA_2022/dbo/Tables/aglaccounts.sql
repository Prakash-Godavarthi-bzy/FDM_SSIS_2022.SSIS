﻿CREATE TABLE [dbo].[aglaccounts] (
    [account]      VARCHAR (25)  NULL,
    [account_grp]  VARCHAR (25)  NULL,
    [account_rule] INT           NULL,
    [account_type] VARCHAR (2)   NULL,
    [bflag]        INT           NULL,
    [client]       VARCHAR (25)  NULL,
    [description]  VARCHAR (255) NULL,
    [head_account] VARCHAR (25)  NULL,
    [last_update]  DATETIME      NULL,
    [period_from]  INT           NULL,
    [period_to]    INT           NULL,
    [res_bal]      VARCHAR (1)   NULL,
    [status]       VARCHAR (1)   NULL,
    [user_id]      VARCHAR (25)  NULL,
    [agrtid]       BIGINT        NULL
);

