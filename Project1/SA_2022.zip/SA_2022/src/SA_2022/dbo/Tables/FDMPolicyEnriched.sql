﻿CREATE TABLE [dbo].[FDMPolicyEnriched] (
    [SectionReference]  NVARCHAR (255) NOT NULL,
    [PolicyReference]   NVARCHAR (255) NULL,
    [MOP]               NVARCHAR (255) NULL,
    [PolicyType]        NVARCHAR (255) NULL,
    [UnderwriterName]   NVARCHAR (255) NULL,
    [COB]               NVARCHAR (255) NULL,
    [InceptionDate]     DATE           NULL,
    [ExpiryDate]        DATE           NULL,
    [NewRenewal]        NVARCHAR (255) NULL,
    [LocationOfRisk]    NVARCHAR (255) NULL,
    [LocationOfInsured] NVARCHAR (255) NULL,
    [YOA]               INT            NULL,
    [OriginalCurrency]  NVARCHAR (255) NULL,
    [Insured]           NVARCHAR (255) NULL,
    CONSTRAINT [PK_FDMPolicyEnriched] PRIMARY KEY CLUSTERED ([SectionReference] ASC) WITH (FILLFACTOR = 90)
);

