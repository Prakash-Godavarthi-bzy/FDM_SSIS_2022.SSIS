﻿


CREATE FUNCTION [dbo].[GetTree](@att_agrid as integer,@cutoverClient as varchar(5))

RETURNS TABLE

AS RETURN
(

	SELECT distinct
	[pkDimAccountTree] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255))
	,[Description] = cast(v.description as nvarchar(255))
	,[pkDimAccountTreeParent] = cast(@att_agrid as nvarchar(25)) + '_' + cast(s.[att_agrid] as nvarchar(255))
      
  FROM 
	[dbo].[acrtreesetup] s join 
	[dbo].[acrtrees] t on (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] = t.[att_agrid] left outer join
	dbo.agldimvalue v on CASE WHEN s.client='*' THEN @cutoverClient ELSE s.client END =v.client and v.attribute_id = att_id_a and t.dim_a=v.dim_value
  where (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] =@att_agrid and len(t.dim_a)>0 and len(t.cat_2) = 0 and len(ltrim(rtrim(att_2_id))) = 0
union
SELECT distinct
	
	[pkDimAccountTree] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255))
	,[Description] = cast(vc.description as nvarchar(255))
	,[pkDimAccountTreeParent] = cast(@att_agrid as nvarchar(25)) + '_' + t.dim_a
     
  FROM 
	[dbo].[acrtreesetup] s join 
	[dbo].[acrtrees] t on (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] = t.[att_agrid] left outer join 
	dbo.agldimvalue vc on CASE WHEN s.client='*' THEN @cutoverClient ELSE s.client END =vc.client and vc.attribute_id = att_id_b and t.dim_b=vc.dim_value 
  where (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] =@att_agrid and len(t.dim_b)>0 and len(t.cat_2) = 0 and len(ltrim(rtrim(att_2_id))) = 0
union
SELECT distinct
	
	[pkDimAccountTree] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255)) + '_' + cast(t.dim_c as nvarchar(255))
	,[Description] = cast(vc.description as nvarchar(255))
	,[pkDimAccountTreeParent] =cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255))
     
  FROM 
	[dbo].[acrtreesetup] s join 
	[dbo].[acrtrees] t on (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] = t.[att_agrid] left outer join
	dbo.agldimvalue vc on CASE WHEN s.client='*' THEN @cutoverClient ELSE s.client END =vc.client and vc.attribute_id = att_id_c and t.dim_c=vc.dim_value 
  where (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] =@att_agrid and len(t.dim_c)>0 and len(t.cat_2) = 0 and len(ltrim(rtrim(att_2_id))) = 0
union
SELECT distinct
	
	[pkDimAccountTree] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255)) + '_' + cast(t.dim_c as nvarchar(255)) + '_' + cast(t.dim_d as nvarchar(255))
	,[Description] = cast(vc.description as nvarchar(255))
	,[pkDimAccountTreeParent] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255)) + '_' + cast(t.dim_c as nvarchar(255))
     
  FROM 
	[dbo].[acrtreesetup] s join 
	[dbo].[acrtrees] t on (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] = t.[att_agrid] left outer join
	dbo.agldimvalue vc on CASE WHEN s.client='*' THEN @cutoverClient ELSE s.client END =vc.client and vc.attribute_id = att_id_d and t.dim_d=vc.dim_value 
  where (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] =@att_agrid and len(t.dim_d)>0 and len(t.cat_2) = 0 and len(ltrim(rtrim(att_2_id))) = 0
union
SELECT distinct
	
	[pkDimAccountTree] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255)) + '_' + cast(t.dim_c as nvarchar(255)) + '_' + cast(t.dim_d as nvarchar(255)) + '_' + cast(t.dim_e as nvarchar(255))
	,[Description] = cast(vc.description as nvarchar(255))
	,[pkDimAccountTreeParent] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255)) + '_' + cast(t.dim_c as nvarchar(255)) + '_'  + cast(t.dim_d as nvarchar(255))
     
  FROM 
	[dbo].[acrtreesetup] s join 
	[dbo].[acrtrees] t on (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] = t.[att_agrid] left outer join
	dbo.agldimvalue vc on CASE WHEN s.client='*' THEN @cutoverClient ELSE s.client END =vc.client and vc.attribute_id = att_id_e and t.dim_e=vc.dim_value 
  where (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] =@att_agrid and len(t.dim_e)>0 and len(t.cat_2) = 0 and len(ltrim(rtrim(att_2_id))) = 0
union
SELECT distinct
	
	[pkDimAccountTree] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255)) + '_' + cast(t.dim_c as nvarchar(255)) + '_' + cast(t.dim_d as nvarchar(255)) + '_' + cast(t.dim_e as nvarchar(255)) + '_' + cast(t.dim_f as nvarchar(255))
	,[Description] = cast(vc.description as nvarchar(255))
	,[pkDimAccountTreeParent] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255)) + '_' + cast(t.dim_c as nvarchar(255)) + '_' + cast(t.dim_d as nvarchar(255)) + '_' + cast(t.dim_e as nvarchar(255))
     
  FROM 
	[dbo].[acrtreesetup] s join 
	[dbo].[acrtrees] t on (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] = t.[att_agrid] left outer join
	dbo.agldimvalue vc on CASE WHEN s.client='*' THEN @cutoverClient ELSE s.client END =vc.client and vc.attribute_id = att_id_f and t.dim_f=vc.dim_value 
  where (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] =@att_agrid and len(t.dim_f)>0 and len(t.cat_2) = 0 and len(ltrim(rtrim(att_2_id))) = 0
  union
SELECT distinct
	
	[pkDimAccountTree] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255)) + '_' + cast(t.dim_c as nvarchar(255)) + '_' + cast(t.dim_d as nvarchar(255)) + '_' + cast(t.dim_e as nvarchar(255)) + '_' + cast(t.dim_f as nvarchar(255)) + '_' + cast(t.dim_g as nvarchar(255))
	,[Description] = cast(vc.description as nvarchar(255))
	,[pkDimAccountTreeParent] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255)) + '_' + cast(t.dim_c as nvarchar(255)) + '_' + cast(t.dim_d as nvarchar(255)) + '_' + cast(t.dim_e as nvarchar(255)) + '_' + cast(t.dim_f as nvarchar(255))
     
  FROM 
	[dbo].[acrtreesetup] s join 
	[dbo].[acrtrees] t on (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] = t.[att_agrid] left outer join
	dbo.agldimvalue vc on CASE WHEN s.client='*' THEN @cutoverClient ELSE s.client END =vc.client and vc.attribute_id = att_id_g and t.dim_g=vc.dim_value 
  where (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] =@att_agrid and len(t.dim_g)>0 and len(t.cat_2) = 0 and len(ltrim(rtrim(att_2_id))) = 0
  union
SELECT distinct
	
	[pkDimAccountTree] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255)) + '_' + cast(t.dim_c as nvarchar(255)) + '_' + cast(t.dim_d as nvarchar(255)) + '_' + cast(t.dim_e as nvarchar(255)) + '_' + cast(t.dim_f as nvarchar(255)) + '_' + cast(t.dim_g as nvarchar(255)) + '_' + cast(t.dim_h as nvarchar(255))
	,[Description] = cast(vc.description as nvarchar(255))
	,[pkDimAccountTreeParent] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255)) + '_' + cast(t.dim_c as nvarchar(255)) + '_' + cast(t.dim_d as nvarchar(255)) + '_' + cast(t.dim_e as nvarchar(255)) + '_' + cast(t.dim_f as nvarchar(255)) + '_' + cast(t.dim_g as nvarchar(255))
     
  FROM 
	[dbo].[acrtreesetup] s join 
	[dbo].[acrtrees] t on (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] = t.[att_agrid] left outer join
	dbo.agldimvalue vc on CASE WHEN s.client='*' THEN @cutoverClient ELSE s.client END =vc.client and vc.attribute_id = att_id_h and t.dim_h=vc.dim_value 
  where (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] =@att_agrid and len(t.dim_h)>0 and len(t.cat_2) = 0 and len(ltrim(rtrim(att_2_id))) = 0
  union
SELECT distinct
	
	[pkDimAccountTree] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255)) + '_' + cast(t.dim_c as nvarchar(255)) + '_' + cast(t.dim_d as nvarchar(255)) + '_' + cast(t.dim_e as nvarchar(255)) + '_' + cast(t.dim_f as nvarchar(255)) + '_' + cast(t.dim_g as nvarchar(255)) + '_' + cast(t.dim_h as nvarchar(255)) + '_' + cast(t.dim_i as nvarchar(255))
	,[Description] = cast(vc.description as nvarchar(255))
	,[pkDimAccountTreeParent] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255)) + '_' + cast(t.dim_c as nvarchar(255)) + '_' + cast(t.dim_d as nvarchar(255)) + '_' + cast(t.dim_e as nvarchar(255)) + '_' + cast(t.dim_f as nvarchar(255)) + '_' + cast(t.dim_g as nvarchar(255)) + '_' + cast(t.dim_h as nvarchar(255))
     
  FROM 
	[dbo].[acrtreesetup] s join 
	[dbo].[acrtrees] t on (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] = t.[att_agrid] left outer join
	dbo.agldimvalue vc on CASE WHEN s.client='*' THEN @cutoverClient ELSE s.client END =vc.client and vc.attribute_id = att_id_i and t.dim_i=vc.dim_value 
  where (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] =@att_agrid and len(t.dim_i)>0 and len(t.cat_2) = 0 and len(ltrim(rtrim(att_2_id))) = 0
  union
SELECT distinct
	
	[pkDimAccountTree] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255)) + '_' + cast(t.dim_c as nvarchar(255)) + '_' + cast(t.dim_d as nvarchar(255)) + '_' + cast(t.dim_e as nvarchar(255)) + '_' + cast(t.dim_f as nvarchar(255)) + '_' + cast(t.dim_g as nvarchar(255)) + '_' + cast(t.dim_h as nvarchar(255)) + '_' + cast(t.dim_i as nvarchar(255)) + '_' + cast(t.dim_j as nvarchar(255))
	,[Description] = cast(vc.description as nvarchar(255))
	,[pkDimAccountTreeParent] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255)) + '_' + cast(t.dim_c as nvarchar(255)) + '_' + cast(t.dim_d as nvarchar(255)) + '_' + cast(t.dim_e as nvarchar(255)) + '_' + cast(t.dim_f as nvarchar(255)) + '_' + cast(t.dim_g as nvarchar(255)) + '_' + cast(t.dim_h as nvarchar(255)) + '_' + cast(t.dim_i as nvarchar(255))
     
  FROM 
	[dbo].[acrtreesetup] s join 
	[dbo].[acrtrees] t on (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] = t.[att_agrid] left outer join
	dbo.agldimvalue vc on CASE WHEN s.client='*' THEN @cutoverClient ELSE s.client END =vc.client and vc.attribute_id = att_id_j and t.dim_j=vc.dim_value 
  where (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] =@att_agrid and len(t.dim_j)>0 and len(t.cat_2) = 0 and len(ltrim(rtrim(att_2_id))) = 0
  union
SELECT distinct
	
	[pkDimAccountTree] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255)) + '_' + cast(t.dim_c as nvarchar(255)) + '_' + cast(t.dim_d as nvarchar(255)) + '_' + cast(t.dim_e as nvarchar(255)) + '_' + cast(t.dim_f as nvarchar(255)) + '_' + cast(t.dim_g as nvarchar(255)) + '_' + cast(t.dim_h as nvarchar(255)) + '_' + cast(t.dim_i as nvarchar(255)) + '_' + cast(t.dim_j as nvarchar(255)) + '_' + cast(t.dim_k as nvarchar(255))
	,[Description] = cast(vc.description as nvarchar(255))
	,[pkDimAccountTreeParent] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255)) + '_' + cast(t.dim_c as nvarchar(255)) + '_' + cast(t.dim_d as nvarchar(255)) + '_' + cast(t.dim_e as nvarchar(255)) + '_' + cast(t.dim_f as nvarchar(255)) + '_' + cast(t.dim_g as nvarchar(255)) + '_' + cast(t.dim_h as nvarchar(255)) + '_' + cast(t.dim_i as nvarchar(255)) + '_' + cast(t.dim_j as nvarchar(255))
     
  FROM 
	[dbo].[acrtreesetup] s join 
	[dbo].[acrtrees] t on (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] = t.[att_agrid] left outer join
	dbo.agldimvalue vc on CASE WHEN s.client='*' THEN @cutoverClient ELSE s.client END =vc.client and vc.attribute_id = att_id_k and t.dim_k=vc.dim_value 
  where (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] =@att_agrid and len(t.dim_k)>0 and len(t.cat_2) = 0 and len(ltrim(rtrim(att_2_id))) = 0
  union
SELECT distinct
	
	[pkDimAccountTree] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255)) + '_' + cast(t.dim_c as nvarchar(255)) + '_' + cast(t.dim_d as nvarchar(255)) + '_' + cast(t.dim_e as nvarchar(255)) + '_' + cast(t.dim_f as nvarchar(255)) + '_' + cast(t.dim_g as nvarchar(255)) + '_' + cast(t.dim_h as nvarchar(255)) + '_' + cast(t.dim_i as nvarchar(255)) + '_' + cast(t.dim_j as nvarchar(255)) + '_' + cast(t.dim_k as nvarchar(255)) + '_' + cast(t.dim_l as nvarchar(255))
	,[Description] = cast(vc.description as nvarchar(255))
	,[pkDimAccountTreeParent] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255)) + '_' + cast(t.dim_c as nvarchar(255)) + '_' + cast(t.dim_d as nvarchar(255)) + '_' + cast(t.dim_e as nvarchar(255)) + '_' + cast(t.dim_f as nvarchar(255)) + '_' + cast(t.dim_g as nvarchar(255)) + '_' + cast(t.dim_h as nvarchar(255)) + '_' + cast(t.dim_i as nvarchar(255)) + '_' + cast(t.dim_j as nvarchar(255)) + '_' + cast(t.dim_k as nvarchar(255))
     
  FROM 
	[dbo].[acrtreesetup] s join 
	[dbo].[acrtrees] t on (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] = t.[att_agrid] left outer join
	dbo.agldimvalue vc on CASE WHEN s.client='*' THEN @cutoverClient ELSE s.client END =vc.client and vc.attribute_id = att_id_l and t.dim_l=vc.dim_value 
  where (s.client = @cutoverClient OR s.client ='*') and s.[att_agrid] =@att_agrid and len(t.dim_l)>0 and len(t.cat_2) = 0 and len(ltrim(rtrim(att_2_id))) = 0

  union

  select distinct
	[pkDimAccountTree]= cast(s.att_agrid as nvarchar(255)) + '_' + cast(ltrim(rtrim(s.att_1_id)) as nvarchar(255)) + '_' + cast(cat_1  as nvarchar(255)) collate SQL_Latin1_General_CP1_CI_AS
	,[Description] = cast(cat_1  as nvarchar(255)) + ' ' + cast(vc.description as nvarchar(255)) collate SQL_Latin1_General_CP1_CI_AS
	,[pkDimAccountTreeParent] = cast(@att_agrid as nvarchar(25)) + '_' + cast(t.dim_a as nvarchar(255)) + '_' + cast(t.dim_b as nvarchar(255)) + '_' + cast(t.dim_c as nvarchar(255)) + '_' + cast(t.dim_d as nvarchar(255)) + '_' + cast(t.dim_e as nvarchar(255)) + '_' + cast(t.dim_f as nvarchar(255)) + '_' + cast(t.dim_g as nvarchar(255)) + '_' + cast(t.dim_h as nvarchar(255)) + '_' + cast(t.dim_i as nvarchar(255)) + '_' + cast(t.dim_j as nvarchar(255)) + '_' + cast(t.dim_k as nvarchar(255)) + '_' + cast(t.dim_l as nvarchar(255))
from 
	acrtrees t join
	acrtreesetup s on t.att_agrid = s.att_agrid left outer join
	dbo.agldimvalue vc on CASE WHEN s.client='*' THEN @cutoverClient ELSE s.client END =vc.client and ltrim(rtrim(vc.attribute_id)) = ltrim(rtrim(s.att_1_id)) and ltrim(rtrim(t.cat_1))=ltrim(rtrim(vc.dim_value)) 

where
	(t.client = @cutoverClient OR t.client ='*') and 
cat_1 in (
select dim_value from agldimvalue
where
(client = @cutoverClient OR client ='*')
and ltrim(rtrim(attribute_id)) = ltrim(rtrim(s.att_1_id))
and dim_value <>'1'
) and s.att_agrid = @att_agrid
and len(t.cat_2) = 0 and len(ltrim(rtrim(att_2_id))) = 0 and t.dim_a!=''



)

