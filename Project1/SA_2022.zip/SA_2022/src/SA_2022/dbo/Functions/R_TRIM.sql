﻿
CREATE FUNCTION [dbo].[R_TRIM](@String VARCHAR(MAX), @Char varchar(5))
RETURNS VARCHAR(MAX)
BEGIN
  RETURN REVERSE(SUBSTRING(REVERSE(@String)
        ,PATINDEX('%[^' + @Char + ' ]%'
        ,REVERSE(@String)),DATALENGTH(@String)))
END
