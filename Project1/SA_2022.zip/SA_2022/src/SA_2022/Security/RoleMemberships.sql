﻿ALTER ROLE [db_owner] ADD MEMBER [PXY_FDM];


GO
ALTER ROLE [db_datareader] ADD MEMBER [SSASServerUser];


GO
ALTER ROLE [db_datareader] ADD MEMBER [DBS.SQL.Staging_Agresso.RO];


GO
ALTER ROLE [db_datareader] ADD MEMBER [FDM Developers];

