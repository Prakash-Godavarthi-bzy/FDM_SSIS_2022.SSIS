﻿CREATE USER [DBS.SQL.Staging_Agresso.RO] FOR LOGIN [BFL\DBS.SQL.Staging_Agresso.RO.TST];

