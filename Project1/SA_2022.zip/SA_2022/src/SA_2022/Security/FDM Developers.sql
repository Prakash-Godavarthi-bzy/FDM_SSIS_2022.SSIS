﻿CREATE USER [FDM Developers] FOR LOGIN [BFL\FDM Developers];

