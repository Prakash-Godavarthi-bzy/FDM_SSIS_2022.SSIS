﻿



-- =============================================
-- Author:		Venkat
-- Create date: 26/10/2018
-- Description:	Modify Accident Year for changes to date claims made
-- =============================================


CREATE PROCEDURE [Mart].[UpdateAY_FactTriangle]
AS
  
  BEGIN
  SET NOCOUNT ON
  IF object_id('tempdb..#UpAY ') IS NOT NULL
       DROP TABLE #UpAY

SELECT DATEPART(YYYY, SRC.DateClaimMade) AS AccidentYear
       ,tgt.pk_Claim
       ,tgt.fk_SourceSystem
INTO #UpAY
FROM staging.DimClaim src
INNER JOIN Mart.DimClaim tgt ON tgt.ClaimReference = src.ClaimReference
       AND tgt.MasterClaimReference = src.MasterClaimReference
       AND tgt.UWProduct = src.UWProduct
       AND tgt.fk_SourceSystem = src.fk_SourceSystem
WHERE src.DateClaimMade <> tgt.DateClaimMade


Update MFT set fk_AccidentYear = UpAY.AccidentYear
FROM [Mart].[FactTriangle] MFT
INNER JOIN #UpAY UpAY ON MFT.fk_Claim = UpAY.pk_Claim
       AND MFT.fk_SourceSystem = UpAY.FK_SourceSystem

UPDATE MFTA SET MFTA.fk_AccidentYear=UpAY.AccidentYear
FROM [Mart].[FactTriangleAdjustment] MFTA
INNER JOIN #UpAY UpAY ON MFTA.fk_Claim = UpAY.pk_Claim
       AND MFTA.fk_SourceSystem = UpAY.FK_SourceSystem

 DROP TABLE #UpAY

END
