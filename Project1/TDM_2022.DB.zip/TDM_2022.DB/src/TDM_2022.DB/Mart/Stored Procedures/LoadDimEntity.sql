﻿







CREATE PROCEDURE [Mart].[LoadDimEntity]
AS
  MERGE mart.DimEntity
  AS tgt
  
  USING 
		staging.DimEntity
  AS src
	ON (tgt.EntityCode = src.EntityCode and tgt.fk_SourceSystem = src.fk_SourceSystem)
  
  WHEN NOT MATCHED BY TARGET 
	THEN INSERT (
				 EntityCode
				 ,EntityName
				 ,Platform
				 ,Status
				 ,fk_SourceSystem 
				 ,InsertDate 
				 ,UpdateDate
				 ) 
		 VALUES (
				 src.EntityCode
				 ,src.EntityName
				 ,src.Platform
				 ,src.Status 
				 ,src.fk_SourceSystem
				 ,getDate()
				 ,getDate() 
				 )
  
  WHEN MATCHED 
			AND (
				src.EntityName <> tgt.EntityName OR
				src.Status <> tgt.Status
				) 
	THEN UPDATE SET tgt.EntityName = src.EntityName, tgt.Status = src.Status, tgt.UpdateDate = getDate();






