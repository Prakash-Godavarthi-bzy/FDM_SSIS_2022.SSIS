﻿





CREATE PROCEDURE [Mart].[LoadDimTrifocus]
AS
  MERGE mart.DimTriFocus 
  AS tgt
  
  USING staging.DimTriFocus AS src
	ON tgt.TriFocusCode = src.TriFocusCode and tgt.fk_SourceSystem = src.fk_SourceSystem
  
  WHEN NOT MATCHED BY TARGET 
	THEN INSERT (
				 TriFocusCode 
				 ,TriFocusName
				 ,Status
				 ,fk_SourceSystem 
				 ,InsertDate 
				 ,UpdateDate
				 ) 
		 VALUES (
				 src.TriFocusCode
				 ,src.TriFocusName
				 ,src.Status 
				 ,src.fk_SourceSystem
				 ,getDate()
				 ,getDate() 
				 )
  
  WHEN MATCHED 
			AND (
				src.TriFocusName <> tgt.TriFocusName OR
				src.Status <> tgt.Status
				) 
	THEN UPDATE SET tgt.TriFocusName = src.TriFocusName, tgt.Status = src.Status, tgt.UpdateDate = getDate();




