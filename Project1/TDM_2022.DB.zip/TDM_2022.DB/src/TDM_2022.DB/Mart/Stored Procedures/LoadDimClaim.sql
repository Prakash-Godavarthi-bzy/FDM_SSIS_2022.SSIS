﻿CREATE PROCEDURE [Mart].[LoadDimClaim]
AS
  MERGE Mart.DimClaim
  AS tgt
  
  USING  (SELECT  pk_stageDimClaim,
                                  ClaimReference,
                                  MasterClaimReference,
                                  UWProduct,
                                  ClaimStatus,
                                  DateClaimMade,
                                  DateOfLoss,
                                  DateClaimClosed,
                                  Claimant,
                                  LossLocation,
                                  FK_SourceSystem,
                                  UWPlatform
                     FROM (
                                  SELECT *,
                                  ROW_NUMBER() OVER (PARTITION BY ClaimReference,MasterClaimReference,UWProduct,FK_SourceSystem ORDER BY pk_stageDimClaim) AS ROW_NUMBER
                                  FROM staging.DimClaim
                           ) AS ROWS
                     WHERE ROW_NUMBER = 1)
  AS src
       ON isnull(tgt.ClaimReference,'') = isnull(src.ClaimReference,'') and 
          isnull(tgt.MasterClaimReference,'') = isnull(src.MasterClaimReference,'') and 
          isnull(tgt.UWProduct,'') = isnull(src.UWProduct,'') and 
          isnull(tgt.fk_SourceSystem,'') = isnull(src.fk_SourceSystem,'')

  WHEN NOT MATCHED BY TARGET 
       THEN INSERT (
                           ClaimReference
                           ,MasterClaimReference
                           ,UWProduct
                           ,ClaimStatus
                           ,DateClaimMade
                           ,DateOfLoss
                           ,DateClaimClosed
                           ,Claimant
                           ,LossLocation
                           ,fk_SourceSystem
                           ,InsertDate
                           ,UpdateDate
                           ,UWPlatform
                           ) 
               VALUES (
                           src.[ClaimReference]
                           ,src.[MasterClaimReference]
                           ,src.[UWProduct]
                           ,src.[ClaimStatus]
                           ,src.[DateClaimMade]
                           ,src.[DateOfLoss]
                           ,src.[DateClaimClosed]
                           ,src.[Claimant]
                           ,src.[LossLocation]
                           ,src.fk_SourceSystem
                           ,getDate()
                           ,getDate() 
                            ,src.UWPlatform
                           )
  
  WHEN MATCHED 
                     AND (
                           isnull(src.ClaimStatus,'') <> isnull(tgt.ClaimStatus,'') OR
                           isnull(src.DateClaimMade,'') <> isnull(tgt.DateClaimMade,'') OR
                           isnull(src.DateOfLoss,'') <> isnull(tgt.DateOfLoss,'') OR
                           isnull(src.DateClaimClosed,'') <> isnull(tgt.DateClaimClosed,'') OR
                           isnull(src.Claimant,'') <> isnull(tgt.Claimant,'') OR
                           isnull(src.LossLocation,'') <> isnull(tgt.LossLocation,'') OR
                           (ISNULL(tgt.UWPlatform,'') <> ISNULL(src.UWPlatform,'') or (tgt.uwplatform is null AND SRC.uwplatform  IS NOT NULL))  
                           ) 
       THEN UPDATE SET tgt.ClaimStatus = src.ClaimStatus,
                           tgt.DateClaimMade = src.DateClaimMade ,
                           tgt.DateOfLoss = src.DateOfLoss,
                           tgt.DateClaimClosed = src.DateClaimClosed,
                           tgt.Claimant = src.Claimant,
                           tgt.LossLocation = src.LossLocation,
                           tgt.UpdateDate = getDate(),
                           tgt.UWPlatform = src.uwplatform;
GO

