﻿




CREATE PROCEDURE [Mart].[LoadDimStatLine]
AS
 
 UPDATE ds set IsCurrent = 0 
 from staging.DimStatLine stg
 JOIN Mart.DimStatLine ds ON stg.UwProd = ds.UwProd and stg.taxcat = ds.taxcat and stg.fk_SourceSystem = ds.fk_SourceSystem
 WHERE STG.Statline <> ds.Statline OR stg.Schedulep <> ds.Schedulep

 INSERT INTO Mart.DimStatLine (UwProd,TaxCat,Statline,Schedulep,fk_SourceSystem ,IsCurrent, InsertDate ,UpdateDate)
 select stg.UWProd, stg.TaxCat, stg.StatLine, stg.Schedulep, stg.FK_SourceSystem, 1, getDate(), getDate() 
 from staging.DimStatLine stg
 LEFT JOIN Mart.DimStatLine ds ON stg.UwProd = ds.UwProd and stg.taxcat = ds.taxcat and stg.fk_SourceSystem = ds.fk_SourceSystem
 WHERE (STG.Statline <> ds.Statline OR stg.Schedulep <> ds.Schedulep) OR ds.pk_StatLine is null

/*
  MERGE Mart.DimStatLine
  AS tgt
  
  USING staging.DimStatLine AS src
	ON tgt.UwProd = src.UwProd and tgt.taxcat = src.taxcat and tgt.fk_SourceSystem = src.fk_SourceSystem
  
  WHEN NOT MATCHED BY TARGET 
	THEN INSERT (
				 UwProd
				 ,TaxCat
				 ,Statline
				 ,Schedulep
				 ,fk_SourceSystem 
				 ,InsertDate 
				 ,UpdateDate
				 ) 
		 VALUES (
				 src.UwProd
				 ,src.TaxCat
				 ,src.Statline 
				 ,src.Schedulep
				 ,src.fk_SourceSystem
				 ,1
				 ,getDate()
				 ,getDate() 
				 )
  
  WHEN MATCHED 
			AND (
				src.Statline <> tgt.Statline OR
				src.Schedulep <> tgt.Schedulep
				) 

	THEN 
	UPDATE SET tgt.IsCurrent = 0 , tgt.UpdateDate = getDate();

	INSERT (
				 UwProd
				 ,TaxCat
				 ,Statline
				 ,Schedulep
				 ,fk_SourceSystem 
				 ,InsertDate 
				 ,UpdateDate
				 ) 
		 VALUES (
				 src.UwProd
				 ,src.TaxCat
				 ,src.Statline 
				 ,src.Schedulep
				 ,src.fk_SourceSystem
				 ,1
				 ,getDate()
				 ,getDate() 
				 );
	*/








