﻿

CREATE PROCEDURE [Mart].[LoadDimLOB]
AS

  

  declare @sourcesystem int;


  -- Merge Master Data

  set @sourcesystem = (SELECT pk_Sourcesystem from Mart.DimSourceSystem WHERE sourcesystemname = 'Master Data')

  MERGE Mart.DimLOB AS tgt
  
  USING staging.DimLOB AS src
	ON tgt.TriFocusCode = src.TriFocusCode and 
	   tgt.UWProductCode = src.UWProductCode and 
	   tgt.EntityCode = src.EntityCode
	AND tgt.fk_sourcesystem = @sourcesystem
  
  WHEN NOT MATCHED BY TARGET 
	THEN INSERT (
			 [TriFocusCode]
			,[UWProductCode]
			,[UWProductName]
			,[CoBCode]			 
			,[EntityCode]
			,[LOB]
			,[ReservingGrp]
			,[ActReservingGrp]
			,[Team]
			,[fk_SourceSystem]
			,[InsertDate]
			,[UpdateDate]
	) 
		 VALUES (
				 src.TriFocusCode
				 ,src.UWProductCode
				 ,src.UWProductName
				 ,'UNK'
				 ,src.EntityCode
				 ,src.LOB
				 ,src.ReservingGrp
				 ,src.ActReservingGrp
				 ,src.Team
				 ,@sourcesystem
				 ,getDate()
				 ,getDate() 
				 )
  
  WHEN MATCHED 
			AND (
				src.UWProductName <> tgt.UWProductName OR
				src.LOB <> tgt.LOB OR
				src.ReservingGrp <> tgt.ReservingGrp OR
				src.ActReservingGrp <> tgt.ActReservingGrp OR
				src.Team <> tgt.Team 
				)
			AND tgt.fk_sourcesystem = @sourcesystem	 

	THEN UPDATE SET 		
				tgt.UWProductName = src.UWProductName
				,tgt.LOB = src.LOB
				,tgt.ReservingGrp = src.ReservingGrp
				,tgt.ActReservingGrp = src.ActReservingGrp
				,tgt.Team = src.Team 
				,tgt.UpdateDate = getDate();
	

	




