﻿
CREATE PROCEDURE [Mart].[LoadDimPolicy]
AS

 -- Merge FDM Policies 
  MERGE Mart.DimPolicy
  AS tgtFDM
  
  USING (SELECT DISTINCT dp.PolicyReference, dp.YOA, dp.InceptionDate, dp.ExpiryDate, dp.Insured, dp.fk_sourcesystem
		 FROM staging.DimPolicy DP 
		 INNER JOIN staging.EarnedPremium FE on DP.PolicyReference = FE.PolicyNo 
		 INNER JOIN Mart.DimSourceSystem DS on dp.FK_SourceSystem = ds.pk_sourcesystem 
		 WHERE ds.sourcesystemname = 'FDM') AS srcFDM
	ON tgtFDM.PolicyReference = srcFDM.PolicyReference and tgtFDM.YOA = srcFDM.YOA and tgtFDM.fk_SourceSystem = srcFDM.fk_SourceSystem
  
  WHEN NOT MATCHED BY TARGET 
	THEN INSERT (
				 PolicyReference 
				 ,InceptionDate
				 ,ExpiryDate
				 ,YOA
				 ,Insured
				 ,fk_SourceSystem 
				 ,InsertDate 
				 ,UpdateDate
				 ) 
		 VALUES (
				  srcFDM.PolicyReference
				 ,srcFDM.InceptionDate
				 ,srcFDM.expiryDate
				 ,srcFDM.YOA 
				 ,srcFDM.Insured
				 ,srcFDM.fk_SourceSystem
				 ,getDate()
				 ,getDate() 
				 )
  
  WHEN MATCHED 
			AND (
				srcFDM.InceptionDate <> tgtFDM.InceptionDate OR
				srcFDM.ExpiryDate <> tgtFDM.ExpiryDate OR
				srcFDM.Insured <> tgtFDM.Insured 
				) 
	THEN UPDATE SET tgtFDM.InceptionDate = srcFDM.InceptionDate, tgtFDM.ExpiryDate = srcFDM.ExpiryDate, tgtFDM.Insured = srcFDM.Insured, tgtFDM.UpdateDate = getDate();


  MERGE Mart.DimPolicy AS tgt

   USING (SELECT DISTINCT dp.PolicyReference, dp.YOA, dp.InceptionDate, dp.ExpiryDate, dp.Insured, dp.fk_sourcesystem
		 FROM staging.DimPolicy DP 
		 INNER JOIN (SELECT a.PolicyReference, a.YOA, MAX(pk_stageDimPolicy) pk_stagedimpolicy FROM staging.DimPolicy a
					 INNER JOIN Mart.DimSourceSystem b on a.FK_SourceSystem = b.pk_sourcesystem 
					 WHERE B.sourcesystemname = 'Claims Bdx'
					 group by a.PolicyReference, a.YOA
					) MAXPOL on dp.pk_stageDimPolicy = maxpol.pk_stagedimpolicy
		  INNER JOIN Mart.DimSourceSystem DS on dp.FK_SourceSystem = ds.pk_sourcesystem 
		 WHERE ds.sourcesystemname = 'Claims Bdx') AS src
	ON tgt.PolicyReference = src.PolicyReference and tgt.YOA = src.YOA and tgt.fk_SourceSystem = src.fk_SourceSystem
  
  WHEN NOT MATCHED BY TARGET 
	THEN INSERT (
				 PolicyReference 
				 ,InceptionDate
				 ,ExpiryDate
				 ,YOA
				 ,Insured
				 ,fk_SourceSystem 
				 ,InsertDate 
				 ,UpdateDate
				 ) 
		 VALUES (
				 src.PolicyReference
				 ,src.InceptionDate
				 ,src.expiryDate
				 ,src.YOA 
				 ,src.Insured
				 ,src.fk_SourceSystem
				 ,getDate()
				 ,getDate() 
				 )
  
  WHEN MATCHED 
			AND (
				src.InceptionDate <> tgt.InceptionDate OR
				src.ExpiryDate <> tgt.ExpiryDate OR
				src.Insured <> tgt.Insured 
				) 
	THEN UPDATE SET tgt.InceptionDate = src.InceptionDate, tgt.ExpiryDate = src.ExpiryDate, tgt.Insured = src.Insured, tgt.UpdateDate = getDate();




