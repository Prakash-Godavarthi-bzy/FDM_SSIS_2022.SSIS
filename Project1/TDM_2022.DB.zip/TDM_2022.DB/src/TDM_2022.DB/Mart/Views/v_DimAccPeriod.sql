﻿

CREATE VIEW [Mart].[v_DimAccPeriod]
as
SELECT DISTINCT
CAST(CAST(DATEPART(yyyy, DateName) AS NVARCHAR) + SUBSTRING(CONVERT(NVARCHAR(6), DateName, 112), 5, 2) AS INT) AccPeriodKey, 
CAST(DATEPART(yyyy, DateName) AS VARCHAR) + ' - ' + SUBSTRING(DATENAME([MONTH], DateName), 1, 3) AccPeriodName,
DATEPART(yyyy, DateName) YearKey,
CAST(DATEPART(yyyy, DateName) AS NVARCHAR(4)) YearName,
CAST(CAST(DATEPART(yyyy, DateName) AS VARCHAR) + CAST(DATEPART(quarter,datename) AS VARCHAR) AS INT)  YearQuarterKey,
CAST(DATEPART(yyyy, DateName) AS VARCHAR) + ' - ' + 'Q' + DATENAME(QUARTER, DATENAME) YearQuarterName
FROM 
Mart.DimDate
WHERE 
DATEPART(yyyy, DateName) <= DATEPART(yyyy, getDate()) 
