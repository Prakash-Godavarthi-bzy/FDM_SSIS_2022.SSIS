﻿

CREATE VIEW [Mart].[v_DimClaim]
AS
SELECT 
dc.pk_Claim,
dc.ClaimReference,
dc.MasterClaimReference,
dc.UWProduct,
dc.ClaimStatus,
dc.Claimant,
dc.LossLocation ,
ds.SourceSystemName,
ddm.DateKey ClaimMadeDateKey,
ddm.DateName ClaimMadeDateName,
ddm.YearMonthKey  ClaimMadeMonthKey,
ddm.YearMonthName  ClaimMadeMonthName,
ddm.YearQuarterKey  ClaimMadeQuarterKey,
ddm.YearQuarterName  ClaimMadeQuarterName,
ddm.YearKey  ClaimMadeYearKey,
ddm.YearName  ClaimMadeYearName,
ddc.DateKey ClaimClosedDateKey,
ddc.DateName ClaimClosedDateName,
ddc.YearMonthKey  ClaimClosedMonthKey,
ddc.YearMonthName  ClaimClosedMonthName,
ddc.YearQuarterKey  ClaimClosedQuarterKey,
ddc.YearQuarterName  ClaimClosedQuarterName,
ddc.YearKey  ClaimClosedYearKey,
ddc.YearName  ClaimClosedYearName
FROM Mart.DimClaim dc
INNER JOIN Mart.v_DimDate ddm on dc.DateClaimMade = ddm.DateName
LEFT JOIN Mart.v_DimDate ddc on dc.DateClaimClosed = ddc.DateName
INNER JOIN Mart.DimSourceSystem ds on dc.FK_SourceSystem = ds.pk_SourceSystem
