﻿CREATE VIEW [Mart].[v_ActuarialLAE]
AS
	SELECT 
	CASE Department When 'Specialty Risks' Then 'Specialty Risks' ELSE 'Other'END Department,  Class,
	GrossNet, Period,AYear, DataSetType, sum(Numerator) BICILAE, sum(Denominator) BICIClaims,
	cast(sum(Numerator) as float) / sum(denominator) LossLAEPercentage
	FROM staging.ActuarialSplit WHERE DatasetType = 'BICI LAE' 
	GROUP BY 
	CASE Department When 'Specialty Risks' Then 'Specialty Risks' ELSE 'Other'END, 
	Period,DataSetType, GrossNet, AYear, Class
	HAVING SUM(denominator) <> 0;

