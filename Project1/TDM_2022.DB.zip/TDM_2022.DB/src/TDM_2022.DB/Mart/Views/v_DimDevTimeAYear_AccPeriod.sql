﻿
CREATE VIEW [Mart].[v_DimDevTimeAYear_AccPeriod]
AS 
SELECT pk_DevelopmentTime, DevelopmentMonth, DevelopmentQuarterKey, DevelopmentQuarter, DevelopmentYearKey, DevelopmentYear 
FROM Mart.DimDevelopmentTime
