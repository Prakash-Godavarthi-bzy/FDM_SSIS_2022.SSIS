﻿
CREATE VIEW [Mart].[v_DimLossFund]
AS 
SELECT -2 pk_LossFund, 'Not Applicable' LossFundDesc
UNION ALL
SELECT 0 pk_LossFund, 'No' LossFund
UNION ALL 
SELECT  1 pk_LossFund, 'Yes' LossFund
