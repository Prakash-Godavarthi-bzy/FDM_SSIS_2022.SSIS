﻿
 CREATE VIEW [Mart].[v_FactFXRate_InceptPeriod_GBP]
  AS
  SELECT fk_Period, fk_TransactionCurrency, fk_ReportingCurrency, fk_RateType, 1 / FXRate as FXRate  
  FROM Mart.FactFXRate FX
  INNER JOIN Mart.DimReportingCurrency drc on fx.fk_ReportingCurrency = drc.pk_ReportingCurrency
  INNER JOIN Mart.DimRateType drt on fx.fk_RateType = drt.pk_RateType
  WHERE drc.CurrencyCode = 'GBP' and drt.RateTypeName like '%Inception%'
