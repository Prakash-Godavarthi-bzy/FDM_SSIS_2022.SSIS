﻿
  CREATE VIEW [Mart].[v_TriangleYear]
  AS 
  SELECT pk_AccidentYear as pk_TriangleYear, AccidentYear as TriangleYear FROM Mart.DimAccidentYear
  UNION
  SELECT pk_YOA as pk_TriangleYear, YOA as TriangleYear FROM Mart.DimYOA
