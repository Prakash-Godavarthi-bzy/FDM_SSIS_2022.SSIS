﻿
CREATE VIEW [Mart].[v_TimeSeries]
as
SELECT  1 AS PK_TimeSeries, 'Current Period' AS TimeSeriesName
UNION ALL
SELECT  2 AS PK_TimeSeries, 'Acc Period LTD' AS TimeSeriesName
UNION ALL
SELECT  3 AS PK_TimeSeries, 'Acc Period YTD' AS TimeSeriesName
UNION ALL
SELECT  4 AS PK_TimeSeries, 'Acc Period QTD' AS TimeSeriesName
UNION ALL
SELECT  5 AS PK_TimeSeries, 'Development AYear AccPeriod LTD' AS TimeSeriesName
UNION ALL
SELECT  6 AS PK_TimeSeries, 'Development YOA AccPeriod LTD' AS TimeSeriesName
