﻿
CREATE VIEW [Mart].[v_DimEntity]
AS
SELECT de.[pk_Entity]
      ,de.[EntityCode]
      ,de.[EntityName]
      ,de.[Platform]
      ,de.[Status]
      ,de.[FK_SourceSystem]
	  ,ISNULL(del.[OfficeLocCode], 'Not Applicable') OfficeLocationkey
	  ,ISNULL(del.[OfficeLocDescription], 'Not Applicable') OfficeLocation
	  ,ISNULL(del.[OfficeLocCountryDescription], 'Not Applicable') OfficeLocationCountry
      ,de.[InsertDate]
      ,de.[UpdateDate]
  FROM [Mart].[DimEntity] de
  LEFT JOIN [Mart].[DimEntityLocationMapping] del ON de.EntityCode = del.EntityCode
