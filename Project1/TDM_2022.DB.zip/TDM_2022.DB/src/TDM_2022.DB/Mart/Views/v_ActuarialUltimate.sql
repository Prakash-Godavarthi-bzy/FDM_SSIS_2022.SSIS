﻿
CREATE VIEW [Mart].[v_ActuarialUltimate]
AS
SELECT 
Period, Class, AYear, DataSetType, GrossNet, numerator BICIClaims, denominator BICIEarnedPremium, (cast(numerator as float) / denominator) ActPercentage
FROM
staging.ActuarialSplit WHERE DatasetType in ('Stat BICI Claims', 'Stat PURE Claims' ) and denominator <> 0
GO

