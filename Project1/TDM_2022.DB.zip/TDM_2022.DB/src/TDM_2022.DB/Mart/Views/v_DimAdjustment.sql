﻿
CREATE VIEW [Mart].[v_DimAdjustment]
AS
SELECT  1 AS PK_Adjustment, 'Non Adjusted' AS AdjustmentName
UNION ALL
SELECT  2 AS PK_Adjustment, 'Adjusted' AS AdjustmentName
