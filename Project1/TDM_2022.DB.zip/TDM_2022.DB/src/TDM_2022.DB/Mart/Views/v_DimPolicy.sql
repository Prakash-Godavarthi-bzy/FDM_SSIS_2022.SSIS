﻿
CREATE VIEW [Mart].[v_DimPolicy]
AS
SELECT 
pk_Policy, 
PolicyReference, 
YOA, 
Insured,
ds.SourceSystemName,
ddi.DateKey InceptionDateKey,
ddi.DateName InceptionDateName,
ddi.YearMonthKey  InceptionMonthKey,
ddi.YearMonthName  InceptionMonthName,
ddi.YearQuarterKey  InceptionQuarterKey,
ddi.YearQuarterName  InceptionQuarterName,
ddi.YearKey  InceptionYearKey,
ddi.YearName  InceptionYearName,
dde.DateKey ExpiryDateKey,
dde.DateName ExpiryDateName,
dde.YearMonthKey  ExpiryMonthKey,
dde.YearMonthName  ExpiryMonthName,
dde.YearQuarterKey  ExpiryQuarterKey,
dde.YearQuarterName  ExpiryQuarterName,
dde.YearKey  ExpiryYearKey,
dde.YearName  ExpiryYearName
FROM Mart.DimPolicy dp
INNER JOIN Mart.v_DimDate ddi on dp.InceptionDate = ddi.DateName
INNER JOIN Mart.v_DimDate dde on dp.ExpiryDate = dde.DateName
INNER JOIN Mart.DimSourceSystem ds on dp.FK_SourceSystem = ds.pk_SourceSystem
