﻿

CREATE VIEW [Mart].[v_TriangulationPeriods]
AS 
SELECT 
	YOA.pk_YOA Year,
	Dev.pk_DevelopmentTime,
	Calc2.ProjectedDate,
	CASE WHEN Calc2.ProjectedDate > GetDate() THEN NULL ELSE 1 END AS Triangulatable
FROM 
	Mart.DimDevelopmentTime Dev
CROSS JOIN 
	Mart.DimYOA YOA
	CROSS APPLY 
	(
		SELECT
			--Treat Unknown as year prior to start so it develops from there
			 CASE WHEN YOA.pk_YOA = 9999 THEN 1899 ELSE YOA.pk_YOA END AS YOAMod 
	) Calc1
CROSS APPLY 
	(
		SELECT 
			DateAdd(Month, Dev.pk_DevelopmentTime - 1, CONVERT(DATETIME, CAST(calc1.YOAMod AS VARCHAR) + '-01-01',120))  AS ProjectedDate
	) Calc2
WHERE 
	Calc2.ProjectedDate <= GetDate()
AND 	YOA.pk_YOA > 1992 AND YOA.pk_YOA < 9997


