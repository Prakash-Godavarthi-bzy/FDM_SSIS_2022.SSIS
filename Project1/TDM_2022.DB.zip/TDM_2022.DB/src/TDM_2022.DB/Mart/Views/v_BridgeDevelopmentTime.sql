﻿

CREATE VIEW [Mart].[v_BridgeDevelopmentTime] 
AS
SELECT pk_DevTimeCombHidden as fk_DevTimeCombHidden, [fk_DevTimeYOA_AccPeriod] fk_DevelopmentTime, 1 fk_DevelopmentType, fk_YOA as fk_TriangleYear  FROM [Mart].[DimDevTimeCombHidden]
UNION ALL
SELECT pk_DevTimeCombHidden as fk_DevTimeCombHidden, [fk_DevTimeAYear_AccPeriod] fk_DevelopmentTime, 2 fk_DevelopmentType, fk_AccidentYear as fk_TriangleYear FROM [Mart].[DimDevTimeCombHidden]
UNION ALL
SELECT pk_DevTimeCombHidden as fk_DevTimeCombHidden, [fk_DevTimeYOA_InceptionDate] fk_DevelopmentTime, 3 fk_DevelopmentType, fk_YOA as fk_TriangleYear  FROM [Mart].[DimDevTimeCombHidden]
UNION ALL
SELECT pk_DevTimeCombHidden as fk_DevTimeCombHidden, [fk_DevTimeAYear_InceptionDate] fk_DevelopmentTime, 4 fk_DevelopmentType, fk_AccidentYear as fk_TriangleYear FROM [Mart].[DimDevTimeCombHidden]
UNION ALL
SELECT pk_DevTimeCombHidden as fk_DevTimeCombHidden, [fk_DevTimeYOA_DateClaimMade] fk_DevelopmentTime, 5 fk_DevelopmentType, fk_YOA as fk_TriangleYear  FROM [Mart].[DimDevTimeCombHidden]
UNION ALL
SELECT pk_DevTimeCombHidden as fk_DevTimeCombHidden, [fk_DevTimeAYear_DateClaimMade] fk_DevelopmentTime, 6 fk_DevelopmentType, fk_AccidentYear as fk_TriangleYear FROM [Mart].[DimDevTimeCombHidden]
