﻿
CREATE VIEW [Mart].[v_DimDevTimeYOA_AccPeriod]
AS 
SELECT pk_DevelopmentTime, DevelopmentMonth, DevelopmentQuarterKey, DevelopmentQuarter, DevelopmentYearKey, DevelopmentYear 
FROM Mart.DimDevelopmentTime
