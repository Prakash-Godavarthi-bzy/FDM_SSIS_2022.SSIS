﻿

CREATE VIEW [Mart].[v_DimDate]
as
select 
pk_Date DateKey, 
DateName,
DATEPART(yyyy, DateName) YearKey, 
CAST(DATEPART(yyyy, DateName) AS NVARCHAR(4)) YearName , 
CAST(CAST(DATEPART(yyyy, DateName) AS NVARCHAR) + SUBSTRING(CONVERT(NVARCHAR(6), DateName, 112), 5, 2) AS INT) AS YearMonthKey,
CAST(DATEPART(yyyy, DateName) AS VARCHAR) + ' - ' + SUBSTRING(DATENAME([MONTH], DateName), 1, 3) YearMonthName,
CAST(CAST(DATEPART(yyyy, DateName) AS VARCHAR) + CAST(DATEPART(quarter,datename) AS VARCHAR) AS INT)  YearQuarterKey,
CAST(DATEPART(yyyy, DateName) AS VARCHAR) + ' - ' + 'Q' + DATENAME(QUARTER, DATENAME) YearQuarterName,
cast(SUBSTRING(CONVERT(NVARCHAR(6), DateName, 112), 5, 2) as int) MonthKey,
SUBSTRING(DATENAME([MONTH], DateName), 1, 3) MonthName,
DATEPART(quarter,datename) QuarterKey,
'Q' + DATENAME(QUARTER, DATENAME) QuarterName
from Mart.DimDate
