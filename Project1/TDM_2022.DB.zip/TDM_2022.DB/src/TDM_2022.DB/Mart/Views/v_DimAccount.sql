﻿


CREATE VIEW [Mart].[v_DimAccount]
AS
SELECT [pk_Account]
      ,[AccountCode]
      ,[AccountName]
      ,[AccountGroup]
	  ,cast([AccountCode] as nvarchar(10)) + ' - ' + [AccountName] AS AccountDescription 
	  ,LossType
	  ,InsuranceType
  FROM [Mart].[DimAccount]


