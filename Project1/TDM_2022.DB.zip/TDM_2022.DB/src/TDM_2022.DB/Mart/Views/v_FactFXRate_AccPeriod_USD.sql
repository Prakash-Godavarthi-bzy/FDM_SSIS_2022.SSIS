﻿
CREATE VIEW [Mart].[v_FactFXRate_AccPeriod_USD]
  AS
  SELECT fk_Period, fk_TransactionCurrency, fk_ReportingCurrency, fk_RateType, 1 / FXRate as FXRate, 0.0000000000 as FXRateLatest  
  FROM Mart.FactFXRate FX
  INNER JOIN Mart.DimReportingCurrency drc on fx.fk_ReportingCurrency = drc.pk_ReportingCurrency
  INNER JOIN Mart.DimRateType drt on fx.fk_RateType = drt.pk_RateType
  WHERE drc.CurrencyCode = 'USD' 


