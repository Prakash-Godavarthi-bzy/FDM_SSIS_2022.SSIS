﻿CREATE TABLE [Mart].[AccidentYearFix] (
    [ClaimReference] VARCHAR (100) NULL,
    [AccidentYear]   INT           NULL
);
GO
