﻿CREATE TABLE [Mart].[DimDevTimeCombHidden] (
    [pk_DevTimeCombHidden]          NVARCHAR (150) NOT NULL,
    [fk_DevTimeYOA_AccPeriod]       INT            NOT NULL,
    [fk_DevTimeAYear_AccPeriod]     INT            NOT NULL,
    [fk_DevTimeYOA_InceptionDate]   INT            NOT NULL,
    [fk_DevTimeAYear_InceptionDate] INT            NOT NULL,
    [fk_DevTimeYOA_DateClaimMade]   INT            NOT NULL,
    [fk_DevTimeAYear_DateClaimMade] INT            NOT NULL,
    [fk_AccidentYear]               INT            NULL,
    [fk_YOA]                        INT            NOT NULL,
    CONSTRAINT [pk_DevTimeCombHidden] PRIMARY KEY CLUSTERED ([pk_DevTimeCombHidden] ASC) WITH (FILLFACTOR = 90)
);

