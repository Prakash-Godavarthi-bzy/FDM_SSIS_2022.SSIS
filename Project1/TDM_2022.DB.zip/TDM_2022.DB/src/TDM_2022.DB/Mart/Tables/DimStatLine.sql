﻿CREATE TABLE [Mart].[DimStatLine] (
    [pk_StatLine]     INT            IDENTITY (1, 1) NOT NULL,
    [UWProd]          NVARCHAR (255) NULL,
    [TaxCat]          NVARCHAR (255) NULL,
    [StatLine]        NVARCHAR (255) NULL,
    [Schedulep]       NVARCHAR (10)  NULL,
    [FK_SourceSystem] INT            NULL,
    [IsCurrent]       BIT            NOT NULL,
    [InsertDate]      DATE           NOT NULL,
    [UpdateDate]      DATE           NOT NULL,
    CONSTRAINT [PK_DimStatLine] PRIMARY KEY CLUSTERED ([pk_StatLine] ASC) WITH (FILLFACTOR = 90)
);

