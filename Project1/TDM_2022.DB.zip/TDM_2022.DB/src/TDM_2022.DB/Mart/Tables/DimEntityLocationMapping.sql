﻿CREATE TABLE [Mart].[DimEntityLocationMapping] (
    [pk_EntityLocationMapping]    INT            IDENTITY (1, 1) NOT NULL,
    [EntityCode]                  NVARCHAR (255) NULL,
    [OfficeLocCode]               NVARCHAR (255) NULL,
    [OfficeLocDescription]        NVARCHAR (255) NULL,
    [OfficeLocCountryDescription] NVARCHAR (255) NULL,
    [FK_SourceSystem]             INT            NULL,
    [InsertDate]                  DATETIME       NOT NULL,
    [UpdateDate]                  DATETIME       NOT NULL,
    CONSTRAINT [PK_DimEntityLocationMapping] PRIMARY KEY CLUSTERED ([pk_EntityLocationMapping] ASC) WITH (FILLFACTOR = 90)
);

