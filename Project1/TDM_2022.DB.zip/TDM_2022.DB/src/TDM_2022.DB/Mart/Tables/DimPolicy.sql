﻿CREATE TABLE [Mart].[DimPolicy] (
    [pk_Policy]       INT            IDENTITY (1, 1) NOT NULL,
    [PolicyReference] NVARCHAR (255) NOT NULL,
    [InceptionDate]   DATE           NOT NULL,
    [ExpiryDate]      DATE           NOT NULL,
    [YOA]             NVARCHAR (50)  NOT NULL,
    [Insured]         NVARCHAR (255) NOT NULL,
    [FK_SourceSystem] INT            NOT NULL,
    [InsertDate]      DATETIME       NOT NULL,
    [UpdateDate]      DATETIME       NOT NULL,
    CONSTRAINT [PK_DimPolicy] PRIMARY KEY CLUSTERED ([pk_Policy] ASC) WITH (FILLFACTOR = 90)
);

