﻿CREATE TABLE [Mart].[DimReportingCurrency] (
    [pk_ReportingCurrency] INT            NOT NULL,
    [CurrencyCode]         NVARCHAR (40)  NULL,
    [CurrencyName]         NVARCHAR (100) NULL,
    CONSTRAINT [PK_ReportingCurrency] PRIMARY KEY CLUSTERED ([pk_ReportingCurrency] ASC) WITH (FILLFACTOR = 90)
);

