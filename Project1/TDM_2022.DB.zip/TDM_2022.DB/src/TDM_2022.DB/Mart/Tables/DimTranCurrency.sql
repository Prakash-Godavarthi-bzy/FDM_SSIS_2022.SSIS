﻿CREATE TABLE [Mart].[DimTranCurrency] (
    [pk_TransactionCurrency] INT            IDENTITY (1, 1) NOT NULL,
    [CurrencyCode]           NVARCHAR (40)  NULL,
    [CurrencyName]           NVARCHAR (100) NULL,
    CONSTRAINT [PK_TransactionCurrency] PRIMARY KEY CLUSTERED ([pk_TransactionCurrency] ASC) WITH (FILLFACTOR = 90)
);

