﻿CREATE TABLE [Mart].[DimLOB] (
    [pk_LOB]          INT            IDENTITY (1, 1) NOT NULL,
    [TriFocusCode]    NVARCHAR (255) NULL,
    [UWProductCode]   NVARCHAR (255) NULL,
    [UWProductName]   NVARCHAR (255) NULL,
    [CoBCode]         NVARCHAR (255) NULL,
    [EntityCode]      NVARCHAR (255) NULL,
    [LOB]             NVARCHAR (255) NULL,
    [ReservingGrp]    NVARCHAR (255) NULL,
    [ActReservingGrp] NVARCHAR (255) NULL,
    [Team]            NVARCHAR (255) NULL,
    [fk_SourceSystem] INT            NOT NULL,
    [InsertDate]      DATETIME       NOT NULL,
    [UpdateDate]      DATETIME       NOT NULL,
    CONSTRAINT [PK_DimLOB] PRIMARY KEY CLUSTERED ([pk_LOB] ASC) WITH (FILLFACTOR = 90)
);

