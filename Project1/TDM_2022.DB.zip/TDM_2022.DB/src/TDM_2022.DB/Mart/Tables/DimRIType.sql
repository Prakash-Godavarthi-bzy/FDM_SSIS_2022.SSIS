﻿CREATE TABLE [Mart].[DimRIType] (
    [pk_RIType] INT           NOT NULL,
    [RIType]    NVARCHAR (50) NOT NULL,
    CONSTRAINT [PK_RIType] PRIMARY KEY CLUSTERED ([pk_RIType] ASC) WITH (FILLFACTOR = 90)
);

