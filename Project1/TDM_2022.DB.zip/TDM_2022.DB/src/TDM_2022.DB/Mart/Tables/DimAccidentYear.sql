﻿CREATE TABLE [Mart].[DimAccidentYear] (
    [pk_AccidentYear] INT            NOT NULL,
    [AccidentYear]    NVARCHAR (100) NULL,
    CONSTRAINT [PK_AccidentYear] PRIMARY KEY CLUSTERED ([pk_AccidentYear] ASC) WITH (FILLFACTOR = 90)
);

