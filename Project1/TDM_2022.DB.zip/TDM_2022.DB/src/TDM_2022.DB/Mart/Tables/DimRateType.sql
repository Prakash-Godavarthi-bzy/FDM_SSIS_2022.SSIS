﻿CREATE TABLE [Mart].[DimRateType] (
    [pk_RateType]         INT            IDENTITY (1, 1) NOT NULL,
    [RateTypeName]        NVARCHAR (250) NOT NULL,
    [RateTypeDescription] NVARCHAR (400) NOT NULL,
    CONSTRAINT [PK_RateType] PRIMARY KEY CLUSTERED ([pk_RateType] ASC) WITH (FILLFACTOR = 90)
);

