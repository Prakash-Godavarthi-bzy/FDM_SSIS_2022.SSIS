﻿CREATE TABLE [Mart].[DimEntity] (
    [pk_Entity]       INT            IDENTITY (1, 1) NOT NULL,
    [EntityCode]      NVARCHAR (255) NULL,
    [EntityName]      NVARCHAR (255) NULL,
    [Platform]        NVARCHAR (255) NULL,
    [Status]          NVARCHAR (255) NULL,
    [FK_SourceSystem] INT            NULL,
    [InsertDate]      DATETIME       NOT NULL,
    [UpdateDate]      DATETIME       NOT NULL,
    CONSTRAINT [PK_DimEntitity] PRIMARY KEY CLUSTERED ([pk_Entity] ASC) WITH (FILLFACTOR = 90)
);

