﻿CREATE TABLE [Mart].[DimTrifocus] (
    [pk_Trifocus]     INT            IDENTITY (1, 1) NOT NULL,
    [TrifocusCode]    NVARCHAR (255) NULL,
    [TrifocusName]    NVARCHAR (255) NULL,
    [Status]          NVARCHAR (255) NULL,
    [fk_SourceSystem] INT            NULL,
    [InsertDate]      DATETIME       NULL,
    [UpdateDate]      DATETIME       NULL,
    CONSTRAINT [PK_DimTrifocus] PRIMARY KEY CLUSTERED ([pk_Trifocus] ASC) WITH (FILLFACTOR = 90)
);

