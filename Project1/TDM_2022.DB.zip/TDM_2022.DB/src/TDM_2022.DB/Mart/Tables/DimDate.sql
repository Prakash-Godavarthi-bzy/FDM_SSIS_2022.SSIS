﻿CREATE TABLE [Mart].[DimDate] (
    [pk_Date]  INT  NOT NULL,
    [DateName] DATE NULL,
    CONSTRAINT [PK__DimDate] PRIMARY KEY CLUSTERED ([pk_Date] ASC) WITH (FILLFACTOR = 90)
);

