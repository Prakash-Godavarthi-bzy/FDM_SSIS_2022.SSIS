﻿CREATE TABLE [Mart].[DimSourceSystem] (
    [pk_SourceSystem]  INT            IDENTITY (1, 1) NOT NULL,
    [SourceSystemName] NVARCHAR (255) NULL,
    CONSTRAINT [PK__DimSourcesystem] PRIMARY KEY CLUSTERED ([pk_SourceSystem] ASC) WITH (FILLFACTOR = 90)
);

