﻿CREATE TABLE [Mart].[FactFXRate] (
    [pk_FXRate]              INT             IDENTITY (1, 1) NOT NULL,
    [fk_Period]              INT             NULL,
    [fk_TransactionCurrency] INT             NULL,
    [fk_ReportingCurrency]   INT             NULL,
    [fk_RateType]            INT             NULL,
    [FXRate]                 NUMERIC (28, 8) NULL,
    [InsertDate]             DATETIME        NULL,
    [UpdateDate]             DATETIME        NULL,
    CONSTRAINT [PK_FactFXRate] PRIMARY KEY CLUSTERED ([pk_FXRate] ASC) WITH (FILLFACTOR = 90)
);

