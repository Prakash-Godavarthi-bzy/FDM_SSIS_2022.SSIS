﻿CREATE TABLE [Mart].[DimClaim] (
    [pk_Claim]             INT            IDENTITY (1, 1) NOT NULL,
    [ClaimReference]       NVARCHAR (255) NULL,
    [MasterClaimReference] NVARCHAR (255) NULL,
    [UWProduct]            NVARCHAR (25)  NULL,
    [ClaimStatus]          NVARCHAR (50)  NULL,
    [DateClaimMade]        DATE           NULL,
    [DateOfLoss]           DATE           NULL,
    [DateClaimClosed]      DATE           NULL,
    [Claimant]             NVARCHAR (255) NULL,
    [LossLocation]         NVARCHAR (255) NULL,
    [FK_SourceSystem]      INT            NULL,
    [InsertDate]           DATETIME       NOT NULL,
    [UpdateDate]           DATETIME       NOT NULL,
    [UWPlatform]           NVARCHAR (255)  NULL,
    CONSTRAINT [PK_stageDimClaim] PRIMARY KEY CLUSTERED ([pk_Claim] ASC) WITH (FILLFACTOR = 90)
);

