﻿CREATE TABLE [Mart].[DimAccount] (
    [pk_Account]       INT            NOT NULL,
    [AccountCode]      INT            NOT NULL,
    [AccountName]      NVARCHAR (255) NOT NULL,
    [AccountGroup]     NVARCHAR (255) NOT NULL,
    [InsuranceType]    NVARCHAR (255) NOT NULL,
    [LossType]         NVARCHAR (255) NOT NULL,
    [USCalculation]    NVARCHAR (255) NOT NULL,
    [BIDACCalculation] NVARCHAR (255) NOT NULL,
    CONSTRAINT [PK_DimAccount] PRIMARY KEY CLUSTERED ([pk_Account] ASC) WITH (FILLFACTOR = 90)
);

