﻿CREATE TABLE [Mart].[DimDevelopmentType] (
    [pk_DevelopmentType]         INT            NOT NULL,
    [DevelopmentTypeName]        NVARCHAR (150) NOT NULL,
    [DevelopmentTypeDescription] NVARCHAR (250) NOT NULL,
    CONSTRAINT [PK_DevelopmentType] PRIMARY KEY CLUSTERED ([pk_DevelopmentType] ASC) WITH (FILLFACTOR = 90)
);

