﻿CREATE TABLE [Mart].[MarineFix] (
    [ClaimReference]  VARCHAR (100) NULL,
    [PolicyReference] VARCHAR (255) NULL
);
GO