﻿CREATE TABLE [Mart].[DimClaimUltimateType] (
    [pk_ClaimUltimateType] INT            NOT NULL,
    [ClaimUltimateType]    NVARCHAR (255) NULL,
    [FK_SourceSystem]      INT            NULL,
    [InsertDate]           DATETIME       NOT NULL,
    [UpdateDate]           DATETIME       NOT NULL,
    CONSTRAINT [pk_ClaimUltimateType] PRIMARY KEY CLUSTERED ([pk_ClaimUltimateType] ASC) WITH (FILLFACTOR = 90)
);

