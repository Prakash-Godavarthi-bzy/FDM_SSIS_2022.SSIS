﻿CREATE TABLE [TDMOutput].[RIFeedClaimHandlingExpense] (
    [pk_RIFeedClaimHandlingExpense] INT              IDENTITY (1, 1) NOT NULL,
    [Period]                        INT              NOT NULL,
    [ExpenseType]                   NVARCHAR (50)    NULL,
    [ClaimReference]                NVARCHAR (255)   NULL,
    [PrimarySectionReference]       NVARCHAR (255)   NULL,
    [TriFocusName]                  NVARCHAR (150)   NULL,
    [TriFocusCode]                  NVARCHAR (50)    NULL,
    [YOA]                           INT              NULL,
    [AccidentYear]                  INT              NULL,
    [InHousePartyCreationDate]      DATE             NULL,
    [InHouseEndDate]                DATE             NULL,
    [AppliedSeverityRating]         INT              NULL,
    [ProportionOpen]                NUMERIC (18, 10) NULL,
    [ClaimWeighting]                NUMERIC (18, 10) NULL,
    [Currency]                      NVARCHAR (50)    NULL,
    [CostsInQtr]                    NUMERIC (28, 10) NULL,
    CONSTRAINT [PK_ClaimHandlingExpense] PRIMARY KEY CLUSTERED ([pk_RIFeedClaimHandlingExpense] ASC) WITH (FILLFACTOR = 90)
);

