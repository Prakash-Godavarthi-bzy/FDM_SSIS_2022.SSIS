﻿CREATE SCHEMA [staging]
    AUTHORIZATION [dbo];

