﻿CREATE SCHEMA [Master]
    AUTHORIZATION [dbo];

