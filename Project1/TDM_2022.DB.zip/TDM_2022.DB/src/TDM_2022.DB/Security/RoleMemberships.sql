﻿ALTER ROLE [db_owner] ADD MEMBER [PXY_FDM];


GO
ALTER ROLE [db_datareader] ADD MEMBER [SVC_FDM];


GO
ALTER ROLE [db_datareader] ADD MEMBER [SSASServerUser];


GO
ALTER ROLE [db_datareader] ADD MEMBER [DBS.SQL.TDM.RO];


GO
ALTER ROLE [db_datareader] ADD MEMBER [FDM Developers];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [SVC_FDM];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [SSASServerUser];

