﻿

CREATE VIEW [staging].[v_MaxMinDates]
  AS 
SELECT MIN(MinDate) MinDate, Max(maxdate) MaxDate
FROM
(
 SELECT 
 CAST(CAST(MIN(period) AS NVARCHAR) + '01' AS DATE) MinDate ,
 EOMonth(CAST(CAST(MAX(period) AS NVARCHAR) + '01' AS DATE))  MaxDate 
 FROM staging.EarnedPremium
 UNION ALL
 SELECT 
 CAST(CAST(MIN(Period) AS NVARCHAR) + '01' AS DATE) MinDate ,
 EOMonth(CAST(CAST(MAX(Period) AS NVARCHAR) + '01' AS DATE))  MaxDate 
 FROM [staging].[ClaimsBdx_AandH]
 UNION ALL
 SELECT 
 MIN(CAST(InceptionDate AS DATE))  MinDate ,
 MAX(CAST(DCC AS DATE))   MaxDate 
 FROM [staging].[ClaimsBdx_BR]
 WHERE ISDATE(DCC) = 1 
 UNION ALL
 SELECT 
 MIN(CAST(InceptionDT AS DATE))  MinDate ,
 MAX(CAST(DCC AS DATE))   MaxDate
 FROM [staging].[ClaimsBdx_CP]
 UNION ALL
 SELECT 
 MIN(CAST(PolicyInceptionDate AS DATE))  MinDate ,
 MAX(CAST(DateClaimMade AS DATE))   MaxDate
 FROM [staging].[ClaimsBdx_Marine]
 UNION ALL
 SELECT 
 MIN(CAST([Claim MadeDate] AS DATE))  MinDate ,
 MAX(CAST([Claim MadeDate] AS DATE))   MaxDate
 FROM [staging].[ClaimsBdx_PCG]
 UNION ALL
SELECT 
 MIN(CAST([InceptionDate] AS DATE))  MinDate ,
 MAX(CAST([ClaimClosedDate] AS DATE))   MaxDate
 FROM [staging].[ClaimsBdx_SL]
 UNION ALL
select * from
(select min(InceptionDate) MinDate from staging.DimPolicy
WHERE InceptionDate != '1900-01-01') a
cross join
(select max(ExpiryDate) MaxDate from staging.DimPolicy
WHERE ExpiryDate != '9999-12-31') b
UNION ALL 
select * from
(select min(DateClaimMade) MinDate from staging.DimClaim
WHERE DateClaimMade != '1900-01-01') a
cross join
(select max(DateClaimClosed) MaxDate from staging.DimClaim
WHERE DateClaimClosed != '9999-12-31') b
UNION ALL
select * from
(select min(DateClaimMade) MinDate from staging.DimClaim
WHERE DateClaimMade != '1900-01-01') a
cross join
(select max(DateClaimClosed) MaxDate from staging.DimClaim
WHERE DateClaimClosed != '9999-12-31') b
) A

