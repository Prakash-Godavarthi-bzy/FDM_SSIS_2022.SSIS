﻿
CREATE VIEW [staging].[v_MaxDevelopmentTime]
  AS 
SELECT MAX(maxdevperiod) maxdevperiod from
(
 SELECT 
 MAX(DATEDIFF(month,	
	    CAST(CAST(YOA AS NVARCHAR) + '01' + '01' AS DATE) ,
		CAST(CAST(period AS NVARCHAR) + '01' AS DATE)  		
	)) MaxDevPeriod
 FROM staging.EarnedPremium
 WHERE ISNUMERIC(yoa) = 1
 UNION ALL
SELECT 
 MAX(DATEDIFF(month,	
	    CAST(CAST(YOA AS NVARCHAR) + '01' + '01' AS DATE) ,
		CAST(CAST(Period AS NVARCHAR) + '01' AS DATE)  		
	)) MaxDevPeriod
 FROM [staging].[ClaimsBdx_BR]
 WHERE ISNUMERIC(yoa) = 1
 UNION ALL
 SELECT 
 MAX(DATEDIFF(month,	
	    CAST(CAST(YOA AS NVARCHAR) + '01' + '01' AS DATE) ,
		CAST(CAST(Period AS NVARCHAR) + '01' AS DATE)  		
	)) MaxDevPeriod
 FROM [staging].[ClaimsBdx_CP]
 WHERE ISNUMERIC(yoa) = 1
 UNION ALL
 SELECT 
 MAX(DATEDIFF(month,	
	    CAST(CAST(YOA AS NVARCHAR) + '01' + '01' AS DATE) ,
		CAST(CAST(Period AS NVARCHAR) + '01' AS DATE)  		
	)) MaxDevPeriod
 FROM [staging].[ClaimsBdx_Marine]
 WHERE ISNUMERIC(yoa) = 1
 UNION ALL
 SELECT 
 MAX(DATEDIFF(month,	
	    CAST(CAST(yoa AS NVARCHAR) + '01' + '01' AS DATE) ,
		CAST(CAST(Period AS NVARCHAR) + '01' AS DATE)  		
	)) MaxDevPeriod
 FROM [staging].[ClaimsBdx_SL]
 WHERE ISNUMERIC(yoa) = 1
 UNION ALL
 SELECT 
 MAX(DATEDIFF(month,	
	    CAST(CAST(Ayear AS NVARCHAR) + '01' + '01' AS DATE) ,
		CAST(CAST(Period AS NVARCHAR) + '01' AS DATE)  		
	)) MaxDevPeriod
 FROM [staging].[ClaimsBdx_BR]
 WHERE ISNUMERIC(ayEAR) = 1
 UNION ALL
 SELECT 
 MAX(DATEDIFF(month,	
	    CAST(CAST(AY AS NVARCHAR) + '01' + '01' AS DATE) ,
		CAST(CAST(Period AS NVARCHAR) + '01' AS DATE)  		
	)) MaxDevPeriod
 FROM [staging].[ClaimsBdx_CP]
 WHERE ISNUMERIC(AY) = 1
 UNION ALL
  SELECT 
 MAX(DATEDIFF(month,	
	    CAST(CAST(datepart(year,cast(isnull(DCM, dol) as date)) AS NVARCHAR) + '01' + '01' AS DATE) ,
		CAST(CAST(Period AS NVARCHAR) + '01' AS DATE)  		
	)) MaxDevPeriod
 FROM [staging].[ClaimsBdx_SL]
 WHERE ISNUMERIC(datepart(year,cast(isnull(DCM, dol) as date))) = 1
 UNION ALL
   SELECT 
 MAX(DATEDIFF(month,	
	    CAST(CAST(YOA AS NVARCHAR) + '01' + '01' AS DATE) ,
		CAST(CAST(asat AS NVARCHAR) + '01' AS DATE)  		
	)) MaxDevPeriod
 FROM staging.ActuarialReservingData
 WHERE ISNUMERIC(yoa) = 1
 AND AsAt%100<=12
)  a
