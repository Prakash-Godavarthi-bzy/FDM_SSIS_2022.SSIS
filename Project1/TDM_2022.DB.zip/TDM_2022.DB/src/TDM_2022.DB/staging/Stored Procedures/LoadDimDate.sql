﻿

CREATE PROCEDURE [staging].[LoadDimDate]
(
@StartDate as date,
@EndDate as date
)
AS



Declare @Current as date = DATEADD(DD, 1, @StartDate);

WHILE @Current <= @EndDate
BEGIN
insert into staging.DimDate
VALUES(cast(convert(varchar(10), @Current, 112) as int), @Current);
set @Current = DATEADD(DD, 1, @Current) 
END
