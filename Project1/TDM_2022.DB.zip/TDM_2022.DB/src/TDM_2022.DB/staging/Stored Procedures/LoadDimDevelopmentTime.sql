﻿




CREATE PROCEDURE [staging].[LoadDimDevelopmentTime]
(
@StartPeriod as NUMERIC(18,10),
@EndPeriod as NUMERIC(18,10)
)
AS



Declare @Current as NUMERIC(18,10) = @StartPeriod + 1;

WHILE @Current <= @EndPeriod
BEGIN
INSERT INTO staging.DimDevelopmentTime
VALUES(@Current, 
'M' +RIGHT('000'+CAST(CAST(@Current AS INT) AS VARCHAR(3)),3), 
cast(ceiling(@Current / 3) as int),
'Q' + RIGHT('000'+CAST(CAST(CEILING(@Current / 3) AS INT)  AS VARCHAR(3)),3),
cast(ceiling(@Current / 12) as int),
'Y' + RIGHT('000'+CAST(CAST(CEILING(@Current / 12) AS INT) AS VARCHAR(3)),3)
);
 
set @Current = @Current + 1 

END


