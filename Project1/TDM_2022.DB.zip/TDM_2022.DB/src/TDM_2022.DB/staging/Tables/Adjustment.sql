﻿CREATE TABLE [staging].[Adjustment] (
    [pk_Adjustment]   BIGINT           IDENTITY (1, 1) NOT NULL,
    [Period]          INT              NULL,
    [Entity]          NVARCHAR (20)    NULL,
    [AccountCode]     INT              NULL,
    [AccidentYear]    INT              NULL,
    [YOA]             NVARCHAR (20)    NULL,
    [TriFocusCode]    NVARCHAR (25)    NULL,
    [UWProdCode]      NVARCHAR (200)   NULL,
    [TaxCat]          NVARCHAR (20)    NULL,
    [ClaimReference]  NVARCHAR (100)   NULL,
    [PolicyReference] NVARCHAR (100)   NULL,
    [TransactionCCY]  NVARCHAR (20)    NULL,
    [Amount]          NUMERIC (18, 10) NULL,
    [Description]     NVARCHAR (100)   NULL,
    CONSTRAINT [pk_Adjustment] PRIMARY KEY CLUSTERED ([pk_Adjustment] ASC) WITH (FILLFACTOR = 90)
);

