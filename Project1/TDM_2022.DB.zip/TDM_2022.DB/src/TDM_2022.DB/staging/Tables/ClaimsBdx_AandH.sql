﻿CREATE TABLE [staging].[ClaimsBdx_AandH] (
    [pk_AandHClaimsBdx] INT              IDENTITY (1, 1) NOT NULL,
    [GROUPNUM]          NVARCHAR (250)   NULL,
    [PolicyRef]         NVARCHAR (250)   NULL,
    [INCURREDDATE]      NVARCHAR (250)   NULL,
    [SPYGLASSCLAIM]     NVARCHAR (250)   NULL,
    [CLAIMID]           NVARCHAR (250)   NULL,
    [ISSUESTATE]        NVARCHAR (250)   NULL,
    [STATE_VAL]         NVARCHAR (250)   NULL,
    [PRODUCT]           NVARCHAR (250)   NULL,
    [CHECKNUM]          NVARCHAR (250)   NULL,
    [CHECKDATE]         NVARCHAR (250)   NULL,
    [PAYEENAME]         NVARCHAR (250)   NULL,
    [CHECKAMT]          NUMERIC (18, 10) NULL,
    [Period]            INT              NULL,
	[UWPlatform]		NVARCHAR (255)	 NULL,
    CONSTRAINT [pk_AandH_ClaimsBdx] PRIMARY KEY CLUSTERED ([pk_AandHClaimsBdx] ASC) WITH (FILLFACTOR = 90)
);

