﻿CREATE TABLE [staging].[ActuarialUltimate] (
    [pk_ActuarialUltimate] INT              IDENTITY (1, 1) NOT NULL,
    [Period]               INT              NULL,
    [Department]           NVARCHAR (250)   NULL,
    [Class]                NVARCHAR (250)   NULL,
    [DatasetType]          NVARCHAR (250)   NULL,
    [GrossNet]             NVARCHAR (250)   NULL,
    [AYear]                INT              NULL,
    [Value]                NUMERIC (28, 10) NULL,
    [Premium]              NUMERIC (28, 10) NULL,
    [Percent]              DECIMAL (15, 10) NULL,
    CONSTRAINT [PK_stgActuarialUltimate] PRIMARY KEY CLUSTERED ([pk_ActuarialUltimate] ASC) WITH (FILLFACTOR = 90)
);

