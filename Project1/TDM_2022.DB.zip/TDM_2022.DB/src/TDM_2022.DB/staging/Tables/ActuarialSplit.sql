﻿CREATE TABLE [staging].[ActuarialSplit] (
    [pk_ActuarialSplit] INT              IDENTITY (1, 1) NOT NULL,
    [Period]            INT              NULL,
    [Department]        NVARCHAR (250)   NULL,
    [Class]             NVARCHAR (250)   NULL,
    [DatasetType]       NVARCHAR (250)   NULL,
    [GrossNet]          NVARCHAR (250)   NULL,
    [AYear]             INT              NULL,
    [Numerator]         NUMERIC (28, 10) NULL,
    [Denominator]       NUMERIC (28, 10) NULL,
    CONSTRAINT [PK_stgActuarialSplit] PRIMARY KEY CLUSTERED ([pk_ActuarialSplit] ASC) WITH (FILLFACTOR = 90)
);

