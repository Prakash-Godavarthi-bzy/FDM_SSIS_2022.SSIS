﻿CREATE TABLE [staging].[BICIClaimsTotals] (
    [pk_BICIClaimsTotals] BIGINT           IDENTITY (1, 1) NOT NULL,
    [Entity]              NVARCHAR (20)    NULL,
    [YOA]                 NVARCHAR (20)    NULL,
    [UWProduct]           NVARCHAR (200)   NULL,
    [Policy]              NVARCHAR (100)   NULL,
    [TS]                  NVARCHAR (255)   NULL,
    [Exposure Reference]  NVARCHAR (255)   NULL,
    [RI Policy]           NVARCHAR (255)   NULL,
    [Amount]              NUMERIC (18, 10) NULL,
    [Description]         NVARCHAR (255)   NULL,
    [TriFocus]            NVARCHAR (25)    NULL,
    [Loss/Expense]        NVARCHAR (25)    NULL,
    [US Policy]           NVARCHAR (255)   NULL,
    [Account No]          INT              NULL,
    [Accounting Period]   INT              NULL,
    [Paid or Oustanding]  NVARCHAR (25)    NULL,
    CONSTRAINT [pk_BICIClaimsTotals] PRIMARY KEY CLUSTERED ([pk_BICIClaimsTotals] ASC) WITH (FILLFACTOR = 90)
);

