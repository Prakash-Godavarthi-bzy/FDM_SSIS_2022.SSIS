﻿CREATE TABLE [staging].[DimStatLine] (
    [pk_StatLine]     INT            IDENTITY (1, 1) NOT NULL,
    [UWProd]          NVARCHAR (255) NULL,
    [TaxCat]          NVARCHAR (255) NULL,
    [StatLine]        NVARCHAR (20)  NULL,
    [Schedulep]       NVARCHAR (10)  NULL,
    [FK_SourceSystem] INT            NULL,
    CONSTRAINT [PK_stageDimStatLine] PRIMARY KEY CLUSTERED ([pk_StatLine] ASC) WITH (FILLFACTOR = 90)
);

