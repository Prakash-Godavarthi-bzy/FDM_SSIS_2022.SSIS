﻿CREATE TABLE [staging].[DimDevelopmentTime] (
    [pk_DevelopmentTime]    INT           NOT NULL,
    [DevelopmentMonth]      NVARCHAR (10) NULL,
    [DevelopmentQuarterKey] INT           NULL,
    [DevelopmentQuarter]    NVARCHAR (10) NULL,
    [DevelopmentYearKey]    INT           NULL,
    [DevelopmentYear]       NVARCHAR (10) NULL,
    CONSTRAINT [PK_stageDevelopmentTime] PRIMARY KEY CLUSTERED ([pk_DevelopmentTime] ASC) WITH (FILLFACTOR = 90)
);

