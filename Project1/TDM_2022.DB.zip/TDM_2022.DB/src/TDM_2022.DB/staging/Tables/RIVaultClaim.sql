﻿CREATE TABLE [staging].[RIVaultClaim] (
    [pk_RIVaultClaim]   BIGINT           IDENTITY (1, 1) NOT NULL,
    [Period]            INT              NULL,
    [YOA]               INT              NULL,
    [ExposureReference] NVARCHAR (100)   NULL,
    [DatasetType]       NVARCHAR (100)   NULL,
    [TransactionCCY]    NVARCHAR (20)    NULL,
    [Amount]            NUMERIC (18, 10) NULL,
    CONSTRAINT [pk_RIVaultClaim] PRIMARY KEY CLUSTERED ([pk_RIVaultClaim] ASC) WITH (FILLFACTOR = 90)
);

