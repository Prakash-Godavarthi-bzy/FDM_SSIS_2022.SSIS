﻿CREATE TABLE [staging].[EarnedPremium] (
    [pk_stageEarnedPremium] BIGINT           IDENTITY (1, 1) NOT NULL,
    [Client]                NVARCHAR (20)    NULL,
    [Period]                INT              NULL,
    [AccidentYear]          INT              NULL,
    [Account]               NVARCHAR (20)    NULL,
    [Entity]                NVARCHAR (20)    NULL,
    [YOA]                   NVARCHAR (20)    NULL,
    [TriFocus]              NVARCHAR (25)    NULL,
    [UWProd]                NVARCHAR (200)   NULL,
    [TaxCat]                NVARCHAR (20)    NULL,
    [PolicyNo]              NVARCHAR (100)   NULL,
    [TransactionCCY]        NVARCHAR (20)    NULL,
    [PremiumType]           NVARCHAR (50)    NULL,
    [Amount]                NUMERIC (18, 10) NULL,
    [fk_SourceSystem]       INT              NULL,
    CONSTRAINT [pk_stageEarnedPremium] PRIMARY KEY CLUSTERED ([pk_stageEarnedPremium] ASC) WITH (FILLFACTOR = 90)
);

