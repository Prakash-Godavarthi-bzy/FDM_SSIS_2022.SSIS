﻿CREATE TABLE [staging].[DimSpecial] (
    [pk_Special]      INT            IDENTITY (1, 1) NOT NULL,
    [Special]         NVARCHAR (255) NULL,
    [FK_SourceSystem] INT            NOT NULL,
    CONSTRAINT [PK_stgDimSpecial] PRIMARY KEY CLUSTERED ([pk_Special] ASC) WITH (FILLFACTOR = 90)
);

