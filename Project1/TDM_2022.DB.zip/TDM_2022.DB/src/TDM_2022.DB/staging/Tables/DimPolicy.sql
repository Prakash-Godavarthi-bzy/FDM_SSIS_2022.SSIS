﻿CREATE TABLE [staging].[DimPolicy] (
    [pk_stageDimPolicy] INT            IDENTITY (1, 1) NOT NULL,
    [PolicyReference]   NVARCHAR (255) NULL,
    [InceptionDate]     DATE           NULL,
    [ExpiryDate]        DATE           NULL,
    [YOA]               NVARCHAR (50)  NULL,
    [Insured]           NVARCHAR (255) NULL,
    [FK_SourceSystem]   INT            NULL,
    CONSTRAINT [PK_stageDimPolicy] PRIMARY KEY CLUSTERED ([pk_stageDimPolicy] ASC) WITH (FILLFACTOR = 90)
);

