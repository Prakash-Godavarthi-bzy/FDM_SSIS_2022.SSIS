﻿CREATE TABLE [staging].[Wizi] (
    [pk_stageWizi]        BIGINT           IDENTITY (1, 1) NOT NULL,
    [Period]              INT              NULL,
    [Account]             NVARCHAR (20)    NULL,
    [Entity]              NVARCHAR (20)    NULL,
    [YOA]                 NVARCHAR (20)    NULL,
    [TriFocusCode]        NVARCHAR (25)    NULL,
    [ClassofBusinessCode] NVARCHAR (25)    NULL,
    [Currency]            NVARCHAR (25)    NULL,
    [Amount]              NUMERIC (18, 10) NULL,
    [fk_SourceSystem]     INT              NULL,
    CONSTRAINT [pk_stageWizi] PRIMARY KEY CLUSTERED ([pk_stageWizi] ASC) WITH (FILLFACTOR = 90)
);

