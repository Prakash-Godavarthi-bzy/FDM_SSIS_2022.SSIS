﻿CREATE TABLE [staging].[DimPremiumAgressoAccount] (
    [DimPremiumAgressoAccountID] INT           IDENTITY (1, 1) NOT NULL,
    [PremiumAgressoAccount]      VARCHAR (25)  NOT NULL,
    [TDMAccount]                 VARCHAR (25)  NULL,
    [CededType]                  VARCHAR (255) NULL,
    [CEPType]                    VARCHAR (20)  NULL
);

