﻿CREATE TABLE [staging].[USLRInput] (
    [pk_USLRInput]      INT            IDENTITY (1, 1) NOT NULL,
    [ReservingGroup]    NVARCHAR (250) NULL,
    [AccidentYear]      INT            NULL,
    [HeldEqualIncurred] NVARCHAR (1)   NULL,
    CONSTRAINT [PK_stgUSLRInput] PRIMARY KEY CLUSTERED ([pk_USLRInput] ASC) WITH (FILLFACTOR = 90)
);

