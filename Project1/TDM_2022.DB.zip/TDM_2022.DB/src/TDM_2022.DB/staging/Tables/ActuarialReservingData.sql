﻿CREATE TABLE [staging].[ActuarialReservingData] (
    [pk_ActuarialReservingData] INT              IDENTITY (1, 1) NOT NULL,
    [ReservingDataSourceID]     BIGINT           NULL,
    [Department]                NVARCHAR (255)   NULL,
    [TriangleGroup]             NVARCHAR (255)   NULL,
    [YOA]                       INT              NULL,
    [GrossRI]                   NVARCHAR (50)    NULL,
    [CCY]                       NVARCHAR (100)   NULL,
    [Value]                     NUMERIC (28, 10) NULL,
    [DatasetName]               NVARCHAR (255)   NULL,
    [AttCat]                    NVARCHAR (255)   NULL,
    [Special]                   NVARCHAR (255)   NULL,
    [Synd]                      INT              NULL,
    [OfficeLocation]            NVARCHAR (255)   NULL,
    [DatasetGroup]              NVARCHAR (255)   NULL,
    [AsAt]                      INT              NULL,
    [FK_SourceSystem]           INT              NULL,
    CONSTRAINT [PK_stageActuarialReservingData] PRIMARY KEY CLUSTERED ([pk_ActuarialReservingData] ASC) WITH (FILLFACTOR = 90)
);

