﻿CREATE TABLE [staging].[DimTrifocus] (
    [pk_Trifocus]     INT            NOT NULL,
    [TrifocusCode]    NVARCHAR (255) NULL,
    [TrifocusName]    NVARCHAR (255) NULL,
    [TrifocusGroup]   NVARCHAR (255) NULL,
    [IsUSTrifocus]    TINYINT        NULL,
    [IsKrReTrifocus]  TINYINT        NULL,
    [Status]          NVARCHAR (255) NULL,
    [fk_SourceSystem] INT            NULL,
    CONSTRAINT [PK_stageDimTrifocus] PRIMARY KEY CLUSTERED ([pk_Trifocus] ASC) WITH (FILLFACTOR = 90)
);

