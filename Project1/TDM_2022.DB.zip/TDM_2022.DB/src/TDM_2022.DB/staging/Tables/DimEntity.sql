﻿CREATE TABLE [staging].[DimEntity] (
    [pk_Entity]       INT            IDENTITY (1, 1) NOT NULL,
    [EntityCode]      NVARCHAR (255) NULL,
    [EntityName]      NVARCHAR (255) NULL,
    [Platform]        NVARCHAR (255) NULL,
    [Status]          NVARCHAR (255) NULL,
    [FK_SourceSystem] INT            NULL,
    CONSTRAINT [PK_DimEntitity] PRIMARY KEY CLUSTERED ([pk_Entity] ASC) WITH (FILLFACTOR = 90)
);

