﻿CREATE TABLE [staging].[DimLOBWizi] (
    [pk_stageDimLOBWizi] INT            IDENTITY (1, 1) NOT NULL,
    [CoBCode]            NVARCHAR (20)  NULL,
    [EntityCode]         NVARCHAR (255) NULL,
    [LOB]                NVARCHAR (255) NULL,
    [ReservingGrp]       NVARCHAR (255) NULL,
    [ActReservingGrp]    NVARCHAR (255) NULL,
    CONSTRAINT [PK_stageLOBWizi] PRIMARY KEY CLUSTERED ([pk_stageDimLOBWizi] ASC) WITH (FILLFACTOR = 90)
);

