﻿CREATE TABLE [staging].[DimLOB] (
    [pk_stageDimLOB]  INT            IDENTITY (1, 1) NOT NULL,
    [TriFocusCode]    NVARCHAR (255) NULL,
    [UWProductCode]   NVARCHAR (255) NULL,
    [UWProductName]   NVARCHAR (255) NULL,
    [EntityCode]      NVARCHAR (255) NULL,
    [LOB]             NVARCHAR (255) NULL,
    [ReservingGrp]    NVARCHAR (255) NULL,
    [ActReservingGrp] NVARCHAR (255) NULL,
    [Team]            NVARCHAR (255) NULL,
    [fk_SourceSystem] NVARCHAR (255) NULL,
    CONSTRAINT [PK_stageLOB] PRIMARY KEY CLUSTERED ([pk_stageDimLOB] ASC) WITH (FILLFACTOR = 90)
);

