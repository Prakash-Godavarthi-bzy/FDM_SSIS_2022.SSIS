﻿CREATE TABLE [staging].[DimDate] (
    [pk_Date]  INT  NOT NULL,
    [DateName] DATE NULL,
    CONSTRAINT [PK_stageDimDate] PRIMARY KEY CLUSTERED ([pk_Date] ASC) WITH (FILLFACTOR = 90)
);

