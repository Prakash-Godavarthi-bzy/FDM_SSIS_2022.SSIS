﻿CREATE TABLE [staging].[OneOffCHEIBNR] (
    [pk_OneOffCHEIBNR] INT              IDENTITY (1, 1) NOT NULL,
    [Period]           INT              NULL,
    [CededType]        NVARCHAR (255)   NULL,
    [LOB]              NVARCHAR (255)   NULL,
    [ReservingGrp]     NVARCHAR (255)   NULL,
    [Entity]           NVARCHAR (255)   NULL,
    [UWProd]           NVARCHAR (255)   NULL,
    [TriFocusCode]     NVARCHAR (255)   NULL,
    [TriFocusName]     NVARCHAR (255)   NULL,
    [YOA]              NVARCHAR (255)   NULL,
    [AYear]            NVARCHAR (255)   NULL,
    [StatLine]         NVARCHAR (255)   NULL,
    [SchP]             NVARCHAR (255)   NULL,
    [Paid_CHE]         NUMERIC (38, 10) NULL,
    [IBNR_Idem]        NUMERIC (38, 10) NULL,
    [IBNR_Exp]         NUMERIC (38, 10) NULL,
    [Held_Idem]        NUMERIC (38, 10) NULL,
    [Held_Exp]         NUMERIC (38, 10) NULL,
    CONSTRAINT [pk_OneOffCHEIBNR] PRIMARY KEY CLUSTERED ([pk_OneOffCHEIBNR] ASC) WITH (FILLFACTOR = 90)
);

