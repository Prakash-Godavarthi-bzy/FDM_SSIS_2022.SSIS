﻿CREATE TABLE [staging].[DimTranCurrency] (
    [CurrencyCode] NVARCHAR (40)  NULL,
    [CurrencyName] NVARCHAR (100) NULL
);

