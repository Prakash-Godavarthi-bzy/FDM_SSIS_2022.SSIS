﻿CREATE TABLE [staging].[DimAccidentYear] (
    [pk_AccYear] INT           NOT NULL,
    [AccYear]    NVARCHAR (20) NULL,
    CONSTRAINT [PK_stageDimAccidentYear] PRIMARY KEY CLUSTERED ([pk_AccYear] ASC) WITH (FILLFACTOR = 90)
);

