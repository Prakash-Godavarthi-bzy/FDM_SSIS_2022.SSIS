﻿CREATE TABLE [staging].[DimYOA] (
    [pk_YOA] INT           NOT NULL,
    [YOA]    NVARCHAR (20) NULL,
    CONSTRAINT [PK_stageDimYOA] PRIMARY KEY CLUSTERED ([pk_YOA] ASC) WITH (FILLFACTOR = 90)
);

