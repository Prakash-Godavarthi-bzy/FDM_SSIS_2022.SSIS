﻿CREATE TABLE [staging].[DimClaim] (
    [pk_stageDimClaim]     INT            IDENTITY (1, 1) NOT NULL,
    [ClaimReference]       NVARCHAR (255) NULL,
    [MasterClaimReference] NVARCHAR (255) NULL,
    [UWProduct]            NVARCHAR (50)  NULL,
    [ClaimStatus]          NVARCHAR (50)  NULL,
    [DateClaimMade]        DATE           NULL,
    [DateOfLoss]           DATE           NULL,
    [DateClaimClosed]      DATE           NULL,
    [Claimant]             NVARCHAR (255) NULL,
    [LossLocation]         NVARCHAR (255) NULL,
    [FK_SourceSystem]      INT            NULL,
    [UWPlatform]           NVARCHAR (255) NULL,
    CONSTRAINT [PK_stageDimClaim] PRIMARY KEY CLUSTERED ([pk_stageDimClaim] ASC) WITH (FILLFACTOR = 90)
);

