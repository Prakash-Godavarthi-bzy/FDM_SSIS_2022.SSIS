﻿CREATE TABLE [staging].[office_location_codes] (
    [pk_office_location_codes] BIGINT         IDENTITY (1, 1) NOT NULL,
    [olc_code]                 NVARCHAR (250) NULL,
    [olc_description]          NVARCHAR (250) NULL,
    [olc_country]              NVARCHAR (250) NULL,
    CONSTRAINT [pk_office_location_codes] PRIMARY KEY CLUSTERED ([pk_office_location_codes] ASC) WITH (FILLFACTOR = 90)
);

