﻿
DECLARE @DimEntity TABLE
(
	
	[EntityCode] [nvarchar](255) NULL,
	[EntityName] [nvarchar](255) NULL,
	[Platform] [nvarchar](255) NULL,
	[Status] [nvarchar](255) NULL,
	[FK_SourceSystem] [int] NULL,
	[InsertDate] [datetime] NOT NULL,
	[UpdateDate] [datetime] NOT NULL

)

INSERT @DimEntity([EntityCode],[EntityName],[Platform],[Status],
[FK_SourceSystem],[InsertDate],[UpdateDate])
VALUES 
('Unknown','Unknown','BIDAC','N',1,'2018-12-13 14:52:45.790','2018-12-13 14:52:45.790'),
('USBICI','Beazley Insurance Company Inc.','US','N',	1,'2018-02-09 00:00:00.000','2018-02-09 00:00:00.000'),
('BIFR','Beazley Insurance dac France','BIDAC','N',	1,'2018-08-02 00:00:00.000','2018-08-02 00:00:00.000'),
('BERE','Beazley Re Limited','BIDAC','N',1,'2018-08-09 15:24:14.100','2018-08-09 15:24:14.100'),
('BIARFR','Beazley Insurance dac France Accounts Receivable','BIDAC','N',1,'2018-08-09 15:24:14.100','2018-08-09 15:24:14.100'),
('BIARGE','Beazley Insurance dac Germany Accounts Receivable','BIDAC','N',1,'2018-08-09 15:24:14.100','2018-08-09 15:24:14.100'),
('BIARSP','Beazley Insurance dac Spain Accounts Receivabable','BIDAC','N',1,'2018-08-09 15:24:14.100','2018-08-09 15:24:14.100'),
('BIARUK','Beazley Insurance dac UK Accounts Receivable','BIDAC','N',1,'2018-08-09 15:24:14.100','2018-08-09 15:24:14.100'),
('BIGE','Beazley Insurance dac Germany','BIDAC','N',	1,'2018-08-09 15:24:14.100','2018-08-09 15:24:14.100'),
('BIIFR','Beazley Insurance dac France IFRS Adj','BIDAC','N',1,'2018-08-09 15:24:14.100','2018-08-09 15:24:14.100'),
('BIIGE','Beazley Insurance dac Germany IFRS Adj','BIDAC','N',1,'2018-08-09 15:24:14.100','2018-08-09 15:24:14.100'),
('BIISP','Beazley Insurance dac Spain IFRS Adj','BIDAC','N',1,'2018-08-09 15:24:14.100','2018-08-09 15:24:14.100'),
('BIIUK','Beazley Insurance dac UK IFRS Adj','BIDAC','N',1,'2018-08-09 15:24:14.100','2018-08-09 15:24:14.100'),
('BISP','Beazley Insurance dac Spain','BIDAC','N',1,'2018-08-09 15:24:14.100','2018-08-09 15:24:14.100'),
('BIUK','Beazley Insurance dac UK','BIDAC','N',1,'2018-08-09 15:24:14.100','2018-08-09 15:24:14.100'),
('BSOL','Beazley Solutions Ltd','BIDAC','N',1,'2018-08-09 15:24:14.100','2018-08-09 15:24:14.100'),
('BSOLFR','Beazley Solutions Limited - France','BIDAC','N',1,'2018-08-09 15:24:14.100','2018-08-09 15:24:14.100'),
('BSOLGE','Beazley Solutions Limited - Germany','BIDAC','N',1,'2018-08-09 15:24:14.100','2018-08-09 15:24:14.100'),
('BSOLNO','Beazley Solutions Limited - Norway','BIDAC','N',1,'2018-08-09 15:24:14.100','2018-08-09 15:24:14.100'),
('BSOLSP','Beazley Solutions Spain','BIDAC','N',1,'2018-08-09 15:24:14.100','2018-08-09 15:24:14.100'),
('SIIADJBIFR','Beazley Insurance dac France Solvency II Adj','BIDAC','N',1,'2018-08-09 15:24:14.100','2018-08-09 15:24:14.100'),
('SIIADJBIGE','Beazley Insurance dac Germany Solvency II Adj','BIDAC','N',1,'2018-08-09 15:24:14.100','2018-08-09 15:24:14.100'),
('SIIADJBISP','Beazley Insurance dac Spain Solvency II Adj','BIDAC','N',1,'2018-08-09 15:24:14.100','2018-08-09 15:24:14.100'),
('SIIADJBIUK','Beazley Insurance dac UK Solvency II Adj','BIDAC','N',1,'2018-08-09 15:24:14.100','2018-08-09 15:24:14.100'),
('USBAIC','Beazley America Insurance Company','US','N',1,'2019-06-06 15:43:42.453','2019-06-06 15:43:42.453'),
('BISW','BIDAC Switzerland (GL client)','BIDAC','N',1,'2019-11-11 14:48:43.067','2020-01-10 13:40:59.787'),
('BIARSW','Beazley Insurance dac Switzerland Accounts Receivable','BIDAC','N',1,'2020-01-10 13:40:59.787','2020-01-10 13:40:59.787'),
('BIISW','Beazley Insurance dac Switzerland IFRS Adj','BIDAC','N',1,'2020-01-10 13:40:59.787','2020-01-10 13:40:59.787'),
('FINMABISW','BIDAC Insurance dac Switzerland FINMA Adj','BIDAC','C',1,'2020-01-10 13:40:59.787','2020-01-10 13:40:59.787'),
('SIIADJBISW','Beazley Insurance dac Switzerland Solvency II Adj','BIDAC','C',1,'2020-01-10 13:40:59.787','2020-01-10 13:40:59.787')
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


MERGE [Mart].[DimEntity] AS TGT
USING @DimEntity AS SRC

ON (

		
		TGT.[EntityCode] = SRC.[EntityCode] AND
		TGT.[EntityName] = SRC.[EntityName]
)

WHEN MATCHED AND

            ISNULL(TGT.[Platform],'') <> ISNULL(SRC.[Platform],'')
			OR ISNULL(TGT.[Status],'') <> ISNULL(SRC.[Status],'')
			OR ISNULL(TGT.[FK_SourceSystem],0) <> ISNULL(SRC.[FK_SourceSystem],0)
			OR ISNULL(TGT.[InsertDate],'1990-01-01 00:00:00.000') <> ISNULL(SRC.[InsertDate],'1990-01-01 00:00:00.000')
			OR ISNULL(TGT.[UpdateDate],'1990-01-01 00:00:00.000') <> ISNULL(SRC.[UpdateDate],'1990-01-01 00:00:00.000')
THEN

      UPDATE SET  TGT.[Platform] = SRC.[Platform] ,
				TGT.[Status]=SRC.[Status],
				TGT.[FK_SourceSystem]=SRC.[FK_SourceSystem],
				TGT.[InsertDate]=SRC.[InsertDate],
				TGT.[UpdateDate]=SRC.[UpdateDate]

           
WHEN NOT MATCHED BY TARGET THEN

      insert ([EntityCode],[EntityName],[Platform],[Status],
[FK_SourceSystem],[InsertDate],[UpdateDate])

      values ([EntityCode],[EntityName],[Platform],[Status],
[FK_SourceSystem],[InsertDate],[UpdateDate])

;