﻿
BEGIN TRY
	DECLARE @DimPremiumAgressoAccount TABLE
	(
		[PremiumAgressoAccount] [varchar](25) NOT NULL,
		[TDMAccount] [varchar](25) NULL,
		[CededType] [varchar](255) NULL,
		[CEPType] [varchar](20) NULL

	)

	INSERT @DimPremiumAgressoAccount([PremiumAgressoAccount],[TDMAccount],[CededType],[CEPType])
	VALUES 
('11100','10001','Ceded','Internal'),
('11110','10001','Ceded','EXternal'),
('16100','10001','Ceded','External'),
('16110','10001','Ceded','Internal'),
('11111','10001','Ceded','Internal'),
('16111','10001','Ceded','Internal'),
('10100','10000','Gross',NULL),
('15100','10000','Gross',NULL),
('11170','10001','Ceded','EXternal'),
('11102','10001','Ceded','EXternal'),
('11103','10001','Ceded','EXternal'),
('10260','10090','Assumed',NULL),
('15200','10090','Assumed',NULL),
('10265','10089','Assumed',NULL),
('15250','10089','Assumed',NULL),
('11110','10031','Ceded',NULL),
('16100','10031','Ceded',NULL),
('11170','10031','Ceded',NULL),
('11102','10031','Ceded',NULL),
('11103','10031','Ceded',NULL),
('11100','10030','Ceded',NULL),
('16110','10030','Ceded',NULL),
('11111','10030','Ceded',NULL),
('16111','10030','Ceded',NULL),
('10100','10092','Gross','EXternal'),
('10265','10093','Assumed',NULL),
('10260','10094','Assumed','EXternal'),
('11100','10126','Ceded',NULL),
('11110','10126','Ceded',NULL),
('11111','10126','Ceded',NULL),
('11102','10126','Ceded',NULL),
('11103','10126','Ceded',NULL)

	--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


	MERGE [TDM].[Staging].[DimPremiumAgressoAccount] AS TGT
	USING @DimPremiumAgressoAccount AS SRC

	ON (

			TGT.[PremiumAgressoAccount] = SRC.[PremiumAgressoAccount] AND
			TGT.[TDMAccount] = SRC.[TDMAccount] 
	)

	WHEN MATCHED AND

				ISNULL(TGT.CededType,'') <> ISNULL(SRC.CededType,'')
				OR ISNULL(TGT.CEPType,'') <> ISNULL(SRC.CEPType,'')

	THEN

		  UPDATE SET TGT.CededType = SRC.CededType,
					TGT.CEPType=SRC.CEPType

           
	WHEN NOT MATCHED BY TARGET THEN

		  insert ([PremiumAgressoAccount],[TDMAccount],[CededType],[CEPType])

		  values ([PremiumAgressoAccount],[TDMAccount],[CededType],[CEPType])

	WHEN NOT MATCHED BY SOURCE THEN DELETE

	;

END TRY

BEGIN CATCH;

	IF @@TRANCOUNT > 0
		ROLLBACK;

	THROW;

END CATCH;