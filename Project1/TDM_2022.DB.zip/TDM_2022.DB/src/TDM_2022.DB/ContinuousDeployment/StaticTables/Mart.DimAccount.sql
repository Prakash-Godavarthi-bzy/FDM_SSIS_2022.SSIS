﻿
BEGIN TRY;
	DECLARE @DimAccount TABLE
	(
		[pk_Account] [int] NOT NULL,
		[AccountCode] [int] NOT NULL,
		[AccountName] [nvarchar](255) NOT NULL,
		[AccountGroup] [nvarchar](255) NOT NULL,
		[InsuranceType] [nvarchar](255) NOT NULL,
		[LossType] [nvarchar](255) NOT NULL,
		[USCalculation] [nvarchar](255) NOT NULL,
		[BIDACCalculation] [nvarchar](255) NOT NULL

	)

	INSERT @DimAccount([pk_Account],[AccountCode],[AccountName],[AccountGroup],[InsuranceType],[LossType],[USCalculation],[BIDACCalculation])
	VALUES 
(10110,10110,'Gross Gross Written Premiums','Premium','Gross','Combined','10092+10093','Not Applicable'),
(10111,10111,'Gross Gross Indemnity Paid','Claim','Gross','Loss','10002+10100','Not Applicable'),
(10112,10112,'Gross Gross Expense Paid','Claim','Gross','LAE','10003+10101','Not Applicable'),
(10113,10113,'Gross Gross Total Paid','Claim','Gross','Combined','10002+10003+10100+10101','Not Applicable'),
(10114,10114,'Gross Gross Indemnity Case Reserve','Claim','Gross','Loss','10004+10103','Not Applicable'),
(10115,10115,'Gross Gross Expense Case Reserve','Claim','Gross','LAE','10005+10104','Not Applicable'),
(10116,10116,'Gross Gross Total Case Reserve','Claim','Gross','Combined','10004+10005+10103+10104','Not Applicable'),
(10117,10117,'Gross Gross Indemnity Incurred','Claim','Gross','Loss','10002+10004+10100+10103','Not Applicable'),
(10118,10118,'Gross Gross Expense Incurred','Claim','Gross','LAE','10003+10005+10101+10104','Not Applicable'),
(10119,10119,'Gross Gross Total Incurred','Claim','Gross','Combined','10002+10004+10100+10103+10003+10005+10101+10104','Not Applicable'),
(10120,10120,'Gross Gross Indemnity IBNR','IBNR','Gross','Loss','10032+10104+10109','Not Applicable'),
(10121,10121,'Gross Gross Expense IBNR','IBNR','Gross','LAE','10033+10105+10110','Not Applicable'),
(10122,10122,'Gross Gross Total IBNR','IBNR','Gross','Combined','10032+10104+10109+10033+10105+10110','Not Applicable'),
(10123,10123,'Gross Gross Indemnity Ultimate Held','IBNR','Gross','Loss','10002+10004+10100+10103+10032+10104+10109','Not Applicable'),
(10124,10124,'Gross Gross Expense Ultimate Held','IBNR','Gross','LAE','10003+10005+10101+10104+10033+10105+10110','Not Applicable'),
(10125,10125,'Gross Gross Total Ultimate Held','IBNR','Gross','Combined','10002+10004+10100+10103+10003+10005 +10101+10104+10032+10104+10109+10033+10105+10110','Not Applicable'),
(10130,10130,'Gross Gross Total PURE IBNR','IBNR','Gross','Combined','10128+10129','Not Applicable'),
(10131,10131,'Ceded Total PURE IBNR','IBNR','Ceded','Combined','Not Applicable','Not Applicable'),
(10088,10088,'Assumed Earned Premium','Premium','Assumed','Combined','10089 + 10090','Not Applicable'),
(10092,10092,'Gross Written Premium','Premium','Gross','Combined','Not Applicable','Not Applicable'),
(10093,10093,'Assumed Internal Written Premium','Premium','Assumed','Combined','Not Applicable','Not Applicable'),
(10094,10094,'Assumed External Written Premium','Premium','Assumed','Combined','Not Applicable','Not Applicable'),
(10095,10095,'Gross Gross Written Premium','Premium','Assumed','Combined','10092 + 10093 + 10094','Not Applicable'),
(10126,10126,'Ceded Written Premiums','Premium','Ceded','Combined','Not Applicable','Not Applicable'),
(10014,10014,'Net Clm Paid','Claim','Net','Combined','10002 + 10003 + 10006 + 10007+ 10100+ 10101','10010 + 10012'),
(10015,10015,'Net Clm Reserve','Claim','Net','Combined','10004 + 10005 + 10008 + 10009+ 10103+ 10104','10011 + 10013'),
(10022,10022,'Net Clm Incurred Indemnity','Claim','Net','Loss','10002 + 10004 + 10006 + 10008+ 10100+ 10103','Not Applicable'),
(10023,10023,'Net Clm Incurred Expense','Claim','Net','LAE','10003 + 10005 + 10007 + 10009+ 10101+ 10104','Not Applicable'),
(10024,10024,'Net Clm Incurred Total','Claim','Net','Combined','10002 + 10003 + 10004 + 10005 + 10006 + 10007 + 10008 + 10009+ 10100+ 10103+ 10101+ 10104','Not Applicable'),
(10025,10025,'Net Earned Premium','Premium','Net','Combined','10000 + 10001+ 10088','Not Applicable'),
(10026,10026,'Net Clm Paid Indemnity','Claim','Net','Loss','10002 + 10006+ 10100','Not Applicable'),
(10027,10027,'Net Clm Paid Expense','Claim','Net','LAE','10003 + 10007+ 10101','Not Applicable'),
(10028,10028,'Net Clm Reserve Indemnity','Claim','Net','Loss','10004 + 10008+ 10103','Not Applicable'),
(10029,10029,'Net Clm Reserve Expense','Claim','Net','LAE','10005 + 10009+ 10104','Not Applicable'),
(10058,10058,'Net IBNR Indemnity','IBNR','Net','Loss','10032 + 10034','Not Applicable'),
(10059,10059,'Net IBNR Expense','IBNR','Net','LAE','10033 + 10035','Not Applicable'),
(10060,10060,'Net IBNR Total','IBNR','Net','Combined','10032 + 10033 + 10034+ 10035','Not Applicable'),
(10063,10063,'Net Held Indemnity','IBNR','Net','Loss','10040 + 10042','Not Applicable'),
(10064,10064,'Net Held Expense','IBNR','Net','LAE','10041 + 10043','Not Applicable'),
(10065,10065,'Net Held Total','IBNR','Net','Combined','10040 + 10041 + 10042 + 10043','Not Applicable'),
(10127,10127,'Net Written Premiums','Premium','Net','Combined', '10092 + 10093 + 10094 + 10126','Not Applicable'),
(10132,10132,'Net Total PURE IBNR','IBNR','Net','Combined','10130 + 10131','Not Applicable'),
(10102,10102,'Assumed Internal Total Paid','Claim','Assumed','Combined','10100 + 10101','Not Applicable'),
(10105,10105,'Assumed Internal Total Case Reserve','Claim','Assumed','Combined','10103 + 10104','Not Applicable'),
(10106,10106,'Assumed Internal Indemnity Incurred','Claim','Assumed','Loss','10100 + 10103','Not Applicable'),
(10107,10107,'Assumed Internal Expense Incurred','Claim','Assumed','LAE','10101 + 10104','Not Applicable'),
(10108,10108,'Assumed Internal Total Incurred','Claim','Assumed','Combined','10100 + 10101 +10103 + 10104','Not Applicable'),
(10134,10134,'Assumed Internal Total IBNR','IBNR','Assumed','Combined','10109 + 10110','Not Applicable'),
(10135,10135,'Assumed Internal Indemnity Ultimate Held','IBNR','Assumed','Loss','10100 + 10103 + 10109','Not Applicable'),
(10136,10136,'Assumed Internal Expense Ultimate Held','IBNR','Assumed','LAE','10101 + 10104 + 10110','Not Applicable'),
(10137,10137,'Assumed Internal Total Ultimate Held','IBNR','Assumed','Combined','10100 + 10101 +10103 + 10104 + 10109 + 10110','Not Applicable'),
(10100,10100,'Assumed Internal Indemnity Paid','Claim','Assumed','Loss','Not Applicable','Not Applicable'),
(10101,10101,'Assumed Internal Expense Paid','Claim','Assumed','LAE','Not Applicable','Not Applicable'),
(10103,10103,'Assumed Internal Indemnity Case Reserve','Claim','Assumed','Loss','Not Applicable','Not Applicable'),
(10104,10104,'Assumed Internal Expense Case Reserve','Claim','Assumed','LAE','Not Applicable','Not Applicable'),
(10109,10109,'Assumed Internal Indemnity IBNR','IBNR','Assumed','Loss','Not Applicable','Not Applicable'),
(10133,10133,'Assumed Internal Expense IBNR','IBNR','Assumed','LAE','Not Applicable','Not Applicable'),
(10128,10128,'Gross PURE IBNR','IBNR','Gross','Combined','Not Applicable','Not Applicable'),
(10129,10129,'Assumed Internal PURE IBNR','IBNR','Assumed','Combined','Not Applicable','Not Applicable')

	MERGE [Mart].[DimAccount] AS TGT
	USING @DimAccount AS SRC

	ON (
		TGT.pk_Account = SRC.pk_Account AND
		TGT.AccountCode = SRC.AccountCode AND
		TGT.AccountName = SRC.AccountName AND
		TGT.AccountGroup = SRC.AccountGroup AND
		TGT.InsuranceType = SRC.InsuranceType AND
		TGT.LossType = SRC.LossType
	)

	WHEN MATCHED AND
				ISNULL(TGT.USCalculation,'') <> ISNULL(SRC.USCalculation,'')
				OR ISNULL(TGT.BIDACCalculation,'') <> ISNULL(SRC.BIDACCalculation,'')

	THEN

		  UPDATE SET TGT.USCalculation = SRC.USCalculation,
					TGT.BIDACCalculation=SRC.BIDACCalculation

           
	WHEN NOT MATCHED BY TARGET THEN

		  insert ( [pk_Account],[AccountCode],[AccountName],[AccountGroup],[InsuranceType],[LossType],[USCalculation],[BIDACCalculation])

		  values ( [pk_Account],[AccountCode],[AccountName],[AccountGroup],[InsuranceType],[LossType],[USCalculation],[BIDACCalculation])
;
END TRY

BEGIN CATCH;

	IF @@TRANCOUNT > 0
		ROLLBACK;

	THROW;

END CATCH;