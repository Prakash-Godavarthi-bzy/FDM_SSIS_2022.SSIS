List of JIRA tickets involved :
FIN-11686: BU-2024 YOA split update for 2623/623

Details of the changes :
Added 2024 split in VW_Syndicatesplitbyyoa