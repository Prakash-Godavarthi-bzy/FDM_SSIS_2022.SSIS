﻿
CREATE PROC [InvestmentReporting].[usp_FeedData] (@Feed AS NVARCHAR(255), @VersionID AS INT)
AS
BEGIN

	-- Balance Sheet
	IF @Feed = 'BS' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-2) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT S.[RowID],[BS1],[BS2],[BS3],[BS4],[BS5],[BS6],[BS7],[BS8],[BS9],[BS10],[BS11],[BS12],[BS13],[BS14],[BS15]
						,CAST([BS16] AS nvarchar(255)) AS [BS16],CAST([BS17] AS nvarchar(255))  AS [BS17],CAST([BS18] AS nvarchar(255))  AS [BS18],CAST([BS19] AS nvarchar(255))  AS [BS19]
						,CAST([BS20] AS nvarchar(255))  AS [BS20],CAST([BS21] AS nvarchar(255)) AS [BS21],CAST([BS22] AS nvarchar(255)) AS [BS22],[BS23],[BS24],[BS25],[BS26],[BS27]
				FROM [InvestmentReporting].[SRC_AUMAssetReport] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([BS1],[BS2],[BS3],[BS4],[BS5],[BS6],[BS7],[BS8],[BS9],[BS10],[BS11],[BS12],[BS13],[BS14],[BS15]
																,[BS16],[BS17],[BS18],[BS19],[BS20],[BS21],[BS22],[BS23],[BS24],[BS25],[BS26],[BS27])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	-- Risk and Bloomberg Report
	IF @Feed = 'RR' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-2) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [RR1] ) AS [RowID]
						,[RR1],[RR2],[RR3],[RR4],[RR5],[RR6],[RR7],[RR8],[RR9],CAST([RR10] AS nvarchar(255)) [RR10] ,[RR11],[RR12],[RR13],[RR14],[RR15]
						,[RR16]  AS [RR16],[RR17]   AS [RR17],[RR18]   AS [RR18],[RR19]   AS [RR19]
						,[RR20]   AS [RR20],[RR21]  AS [RR21],[RR22]  AS [RR22],[RR23],[RR24],[RR25],[RR26],[RR27]
				FROM [InvestmentReporting].[SRC_RiskAndBloombergReport] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([RR1],[RR2],[RR3],[RR4],[RR5],[RR6],[RR7],[RR8],[RR9],[RR10],[RR11],[RR12],[RR13],[RR14],[RR15]
																,[RR16],[RR17],[RR18],[RR19],[RR20],[RR21],[RR22],[RR23],[RR24],[RR25],[RR26],[RR27])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	-- Closed Derivatives Report
	IF @Feed = 'CDR' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT S.[RowID],[CDR1],[CDR2],[CDR3],[CDR4],[CDR5],[CDR6],[CDR7],[CDR8],[CDR9],[CDR10],[CDR11],[CDR12],[CDR13],[CDR14],[CDR15]
						,[CDR16],[CDR17],CAST([CDR18] AS nvarchar(255)) [CDR18] ,[CDR19],CAST([CDR20]AS nvarchar(255)) [CDR20],CAST([CDR21]AS nvarchar(255)) [CDR21]
						,CAST([CDR22]AS nvarchar(255)) [CDR22],CAST([CDR23]AS nvarchar(255)) [CDR23],CAST([CDR24]AS nvarchar(255)) [CDR24],CAST([CDR25]AS nvarchar(255)) [CDR25]
						,[CDR26],CAST([CDR27]AS nvarchar(255)) [CDR27],CAST([CDR28]AS nvarchar(255)) [CDR28],CAST([CDR29]AS nvarchar(255)) [CDR29],[CDR30],[CDR31],[CDR32],[CDR33]
						,CAST([CDR34]AS nvarchar(255)) [CDR34],CAST([CDR35]AS nvarchar(255)) [CDR35],CAST([CDR36]AS nvarchar(255)) [CDR36],[CDR37],[CDR38],[CDR39],[CDR40],[CDR41]
				FROM [InvestmentReporting].[SRC_ClosedDerivativesReport] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([CDR1],[CDR2],[CDR3],[CDR4],[CDR5],[CDR6],[CDR7],[CDR8],[CDR9],[CDR10],[CDR11],[CDR12],[CDR13],[CDR14],[CDR15]
																,[CDR16],[CDR17],[CDR18],[CDR19],[CDR20],[CDR21],[CDR22],[CDR23],[CDR24],[CDR25],[CDR26],[CDR27]
																,[CDR28],[CDR29],[CDR30],[CDR31],[CDR32],[CDR33],[CDR34],[CDR35],[CDR36],[CDR37],[CDR38],[CDR39],[CDR40],[CDR41])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	-- Overseas Extract
	IF @Feed = 'OE' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [OE1] ) AS [RowID],[OE1],[OE2],[OE3],[OE4],CAST([OE5] AS nvarchar(255)) AS [OE5]
				FROM [InvestmentReporting].[SRC_OverseasExtract] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([OE1],[OE2],[OE3],[OE4],[OE5])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	-- Cash Extract
	IF @Feed = 'CE' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [CE1] ) AS [RowID],[CE1],[CE2],[CE3],[CE4],CAST([CE5] AS nvarchar(255)) AS [CE5]
				FROM [InvestmentReporting].[SRC_CashExtract] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([CE1],[CE2],[CE3],[CE4],[CE5])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	-- MTDYTD P&L Report
	IF @Feed = 'PL' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT S.[RowID],[PL1],[PL2],[PL3],[PL4],[PL5],[PL6],[PL7],[PL8],[PL9],[PL10],[PL11],CAST([PL12] AS NVARCHAR(255)) AS [PL12],CAST([PL13] AS NVARCHAR(255)) AS [PL13],CAST([PL14] AS NVARCHAR(255)) AS [PL14],
						CAST([PL15] AS NVARCHAR(255)) AS [PL15],CAST([PL16] AS NVARCHAR(255)) AS [PL16],CAST([PL17] AS NVARCHAR(255)) AS [PL17],CAST([PL18] AS NVARCHAR(255)) AS [PL18],CAST([PL19] AS NVARCHAR(255)) AS [PL19],
						CAST([PL20] AS NVARCHAR(255)) AS [PL20],CAST([PL21] AS NVARCHAR(255)) AS [PL21],CAST([PL22] AS NVARCHAR(255)) AS [PL22],CAST([PL23] AS NVARCHAR(255)) AS [PL23],CAST([PL24] AS NVARCHAR(255)) AS [PL24],
						CAST([PL25] AS NVARCHAR(255)) AS [PL25],CAST([PL26] AS NVARCHAR(255)) AS [PL26],CAST([PL27] AS NVARCHAR(255)) AS [PL27],CAST([PL28] AS NVARCHAR(255)) AS [PL28],CAST([PL29] AS NVARCHAR(255)) AS [PL29]
				FROM [InvestmentReporting].[SRC_PLReport] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([PL1],[PL2],[PL3],[PL4],[PL5],[PL6],[PL7],[PL8],[PL9],[PL10],[PL11],[PL12],[PL13],[PL14],[PL15]
																,[PL16],[PL17],[PL18],[PL19],[PL20],[PL21],[PL22],[PL23],[PL24],[PL25],[PL26],[PL27]
																,[PL28],[PL29])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	-- Open Derivatives Report
	IF @Feed = 'ODR' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT S.[RowID],[ODR1],[ODR2],[ODR3],[ODR4],[ODR5],[ODR6],[ODR7],[ODR8],[ODR9],[ODR10],[ODR11],[ODR12],[ODR13],[ODR14],[ODR15]
						,[ODR16],[ODR17],[ODR18] ,[ODR19],CAST([ODR20]AS nvarchar(255)) [ODR20],CAST([ODR21]AS nvarchar(255)) [ODR21]
						,[ODR22],CAST([ODR23]AS nvarchar(255)) [ODR23],CAST([ODR24]AS nvarchar(255)) [ODR24],CAST([ODR25]AS nvarchar(255)) [ODR25]
						,CAST( [ODR26] AS nvarchar(255)) [ODR26] ,CAST([ODR27]AS nvarchar(255)) [ODR27],CAST([ODR28]AS nvarchar(255)) [ODR28],CAST([ODR29]AS nvarchar(255)) [ODR29],CAST([ODR30] AS nvarchar(255)) [ODR30]
						,CAST([ODR31] AS nvarchar(255)) [ODR31],[ODR32],[ODR33], [ODR34],[ODR35],CAST([ODR36]AS nvarchar(255)) [ODR36],[ODR37],CAST([ODR38] AS nvarchar(255)) [ODR38]
						,CAST([ODR39] AS nvarchar(255)) [ODR39],CAST([ODR40] AS nvarchar(255)) [ODR40],[ODR41],[ODR42],[ODR43],[ODR44],[ODR45]
				FROM [InvestmentReporting].[SRC_OpenDerivativesReport] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([ODR1],[ODR2],[ODR3],[ODR4],[ODR5],[ODR6],[ODR7],[ODR8],[ODR9],[ODR10],[ODR11],[ODR12],[ODR13],[ODR14],[ODR15]
																,[ODR16],[ODR17],[ODR18],[ODR19],[ODR20],[ODR21],[ODR22],[ODR23],[ODR24],[ODR25],[ODR26],[ODR27],[ODR28],[ODR29]
																,[ODR30],[ODR31],[ODR32],[ODR33],[ODR34],[ODR35],[ODR36],[ODR37],[ODR38],[ODR39],[ODR40],[ODR41],[ODR42],[ODR43],[ODR44],[ODR45])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	-- Risk and Bloomberg Report ID Code
	IF @Feed = 'RRIDC' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-5) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [RRIDC1] ) AS [RowID] ,[RRIDC1],[RRIDC2]
				FROM [InvestmentReporting].[SRC_RiskAndBloombergReportIDCode] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([RRIDC1],[RRIDC2])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	-- Asset Type Classification
	IF @Feed = 'ATC' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort]
		FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [ATC1] ) AS [RowID],[ATC1],[ATC2],CAST([ATC3] AS nvarchar(255)) AS [ATC3]
				FROM [InvestmentReporting].[SRC_ATC] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([ATC1],[ATC2],[ATC3])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	-- Bond Category A Customer Reclassification
	IF @Feed = 'BCA' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-3) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [BCA1] ) AS [RowID],[BCA1],[BCA2],[BCA3],[BCA4],[BCA5]
				FROM [InvestmentReporting].[SRC_BCA] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([BCA1],[BCA2],[BCA3],[BCA4],[BCA5])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	-- Bond Category B ID Code Reclassifiaction
	IF @Feed = 'BCB' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-3) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [BCB1] ) AS [RowID],[BCB1],[BCB2]
				FROM [InvestmentReporting].[SRC_BCB] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([BCB1],[BCB2])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	-- Bond Category C Inv Asset Type Classifiaction
	IF @Feed = 'BCC' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-3) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [BCC1] ) AS [RowID],[BCC1],[BCC2]
				FROM [InvestmentReporting].[SRC_BCC] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([BCC1],[BCC2])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	-- Bond Category D Overseas Inv Asset Type Classification
	IF @Feed = 'BCD' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-3) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [BCD1] ) AS [RowID],[BCD1],[BCD2]
				FROM [InvestmentReporting].[SRC_BCD] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([BCD1],[BCD2])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	-- CIC Lookup
	IF @Feed = 'CIC' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-3) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [CIC1] ) AS [RowID],[CIC1],[CIC2],[CIC3],[CIC4],[CIC5]
				FROM [InvestmentReporting].[SRC_CIC] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([CIC1],[CIC2],[CIC3],[CIC4],[CIC5])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END
	
	-- CIC Rules
	IF @Feed = 'CICR' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-4) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [CICR1] ) AS [RowID],[CICR1],[CICR2],[CICR3],[CICR4],[CICR5],[CICR6],[CICR7],[CICR8],[CICR9],[CICR10],[CICR11]
				FROM [InvestmentReporting].[SRC_CICR] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([CICR1],[CICR2],[CICR3],[CICR4],[CICR5],[CICR6],[CICR7],[CICR8],[CICR9],[CICR10],[CICR11])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--CustodianDataLookup	CSTDL	6
	IF @Feed = 'CSTDL' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-5) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [CSTDL1] ) AS [RowID],[CSTDL1],[CSTDL2],[CSTDL3],[CSTDL4],[CSTDL5],[CSTDL6]
				FROM [InvestmentReporting].[SRC_CSTDL] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([CSTDL1],[CSTDL2],[CSTDL3],[CSTDL4],[CSTDL5],[CSTDL6])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--Customer Custodian Lookup	CSTDCUS	5
	IF @Feed = 'CSTDCUS' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-7) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [CSTDCUS1] ) AS [RowID],[CSTDCUS1],[CSTDCUS2],[CSTDCUS3],[CSTDCUS4],[CSTDCUS5]
				FROM [InvestmentReporting].[SRC_CSTDCUS] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([CSTDCUS1],[CSTDCUS2],[CSTDCUS3],[CSTDCUS4],[CSTDCUS5])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--Custodian Group Lookup
	IF @Feed = 'CGL' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-3) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [CGL1] ) AS [RowID],[CGL1],[CGL2]
				FROM [InvestmentReporting].[SRC_CGL] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([CGL1],[CGL2])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END


	--Entity Lookup	ENT	3
	IF @Feed = 'ENT' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-3) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [ENT1] ) AS [RowID],[ENT1],[ENT2],[ENT3]
				FROM [InvestmentReporting].[SRC_ENT] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([ENT1],[ENT2],[ENT3])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--Group Rating Classification	GR	3
	IF @Feed = 'GR' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-2) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [GR1] ) AS [RowID],[GR1],[GR2],[GR3]
				FROM [InvestmentReporting].[SRC_GR] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([GR1],[GR2],[GR3])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--IMS Category A ID Code Reclassification	IMSA	4
	IF @Feed = 'IMSA' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-4) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [IMSA1] ) AS [RowID],[IMSA1],[IMSA2],[IMSA3],[IMSA4]
				FROM [InvestmentReporting].[SRC_IMSA] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([IMSA1],[IMSA2],[IMSA3],[IMSA4])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--IMS Category B Customer Reclassification	IMSB	2
	IF @Feed = 'IMSB' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-4) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [IMSB1] ) AS [RowID],[IMSB1],[IMSB2]
				FROM [InvestmentReporting].[SRC_IMSB] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([IMSB1],[IMSB2])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--IMS Category C Customer Inv Asset Type Reclassification	IMSC	4
	IF @Feed = 'IMSC' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-4) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [IMSC1] ) AS [RowID],[IMSC1],[IMSC2],[IMSC3],[IMSC4]
				FROM [InvestmentReporting].[SRC_IMSC] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([IMSC1],[IMSC2],[IMSC3],[IMSC4])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--IMS Category D Inv Asset Type Classification	IMSD	2
	IF @Feed = 'IMSD' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-4) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [IMSD1] ) AS [RowID],[IMSD1],[IMSD2]
				FROM [InvestmentReporting].[SRC_IMSD] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([IMSD1],[IMSD2])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END
	
	--Infra
	IF @Feed = 'INF' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-3) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [INF1] ) AS [RowID],[INF1],[INF2],[INF3],[INF4],[INF5],[INF6],[INF7],[INF8],[INF9],[INF10],[INF11]
				FROM [InvestmentReporting].[SRC_INF] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([INF1],[INF2],[INF3],[INF4],[INF5],[INF6],[INF7],[INF8],[INF9],[INF10],[INF11])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END


	--Issuer Sector	IS	2
	IF @Feed = 'IS' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-2) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [IS1] ) AS [RowID],[IS1],[IS2]
				FROM [InvestmentReporting].[SRC_IS] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([IS1],[IS2])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--QAD ASSET HELD IN UNIT LINKED AND INDEX LINKED CONTRACTS	QAUL	3
	IF @Feed = 'QAUL' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-4) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [QAUL1] ) AS [RowID],[QAUL1],[QAUL2],[QAUL3]
				FROM [InvestmentReporting].[SRC_QAUL] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([QAUL1],[QAUL2],[QAUL3])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--QAD ASSET PLEDGED AS COLLATERAL	QAPC	3
	IF @Feed = 'QAPC' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-4) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [QAPC1] ) AS [RowID],[QAPC1],[QAPC2],[QAPC3]
				FROM [InvestmentReporting].[SRC_QAPC] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([QAPC1],[QAPC2],[QAPC3])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--QAD CREDIT QUALITY STEP	QCQ	3
	IF @Feed = 'QCQ' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-3) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [QCQ1] ) AS [RowID],[QCQ1],[QCQ2],[QCQ3]
				FROM [InvestmentReporting].[SRC_QCQ] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([QCQ1],[QCQ2],[QCQ3])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--QAD CurrencyT Table Classification	QCTC	2
	IF @Feed = 'QCTC' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-4) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [QCTC1] ) AS [RowID],[QCTC1],[QCTC2]
				FROM [InvestmentReporting].[SRC_QCTC] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([QCTC1],[QCTC2])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--QAD HOLDINGS IN RELATED UNDERTAKING INCLUDING PARTICIPATION (SOLO)	QHRU	3
	IF @Feed = 'QHRU' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-4) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [QHRU1] ) AS [RowID],[QHRU1],[QHRU2],[QHRU3]
				FROM [InvestmentReporting].[SRC_QHRU] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([QHRU1],[QHRU2],[QHRU3])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--QAD ID Code Type Category Classification	QIDCT	3
	IF @Feed = 'QIDCT' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-5) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [QIDCT1] ) AS [RowID],[QIDCT1],[QIDCT2],[QIDCT3]
				FROM [InvestmentReporting].[SRC_QIDCT] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([QIDCT1],[QIDCT2],[QIDCT3])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END
	
	--QAD INFRASTRUCTURE INVESTMENT	QII	3
	IF @Feed = 'QII' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-3) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [QII1] ) AS [RowID],[QII1],[QII2],[QII3]
				FROM [InvestmentReporting].[SRC_QII] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([QII1],[QII2],[QII3])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--QAD ISSUER SECTOR - EXCLUSIONS	QISE	3
	IF @Feed = 'QISE' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-4) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [QISE1] ) AS [RowID],[QISE1],[QISE2],[QISE3]
				FROM [InvestmentReporting].[SRC_QISE] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([QISE1],[QISE2],[QISE3])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--QAD Nominated ECAI	QNECAI	3
	IF @Feed = 'QNECAI' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-6) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [QNECAI1] ) AS [RowID],[QNECAI1],[QNECAI2],[QNECAI3]
				FROM [InvestmentReporting].[SRC_QNECAI] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([QNECAI1],[QNECAI2],[QNECAI3])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--QAD PORTFOLIO	QPF	3
	IF @Feed = 'QPF' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-3) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [QPF1] ) AS [RowID],[QPF1],[QPF2],[QPF3]
				FROM [InvestmentReporting].[SRC_QPF] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([QPF1],[QPF2],[QPF3])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--QAD TYPE OF ISSUER CODE	QTIC	3
	IF @Feed = 'QTIC' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-4) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [QTIC1] ) AS [RowID],[QTIC1],[QTIC2],[QTIC3]
				FROM [InvestmentReporting].[SRC_QTIC] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([QTIC1],[QTIC2],[QTIC3])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--QAD VALUATION METHOD	QVM	3
	IF @Feed = 'QVM' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-3) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [QVM1] ) AS [RowID],[QVM1],[QVM2],[QVM3]
				FROM [InvestmentReporting].[SRC_QVM] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([QVM1],[QVM2],[QVM3])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--QMA Form 201 Lookup	F201L	6
	IF @Feed = 'F201L' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-5) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [F201L1] ) AS [RowID],[F201L1],[F201L2],[F201L3],[F201L4],[F201L5],[F201L6]
				FROM [InvestmentReporting].[SRC_F201L] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([F201L1],[F201L2],[F201L3],[F201L4],[F201L5],[F201L6])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--QMA Form 212u Lookup	F212uL	6
	IF @Feed = 'F212uL' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-6) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [F212uL1] ) AS [RowID],[F212uL1],[F212uL2],[F212uL3],[F212uL4],[F212uL5],[F212uL6]
				FROM [InvestmentReporting].[SRC_F212uL] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([F212uL1],[F212uL2],[F212uL3],[F212uL4],[F212uL5],[F212uL6])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--QMA Form 219u Lookup	F219uL	3
	IF @Feed = 'F219uL' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-6) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [F219uL1] ) AS [RowID],[F219uL1],[F219uL2],[F219uL3]
				FROM [InvestmentReporting].[SRC_F219uL] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([F219uL1],[F219uL2],[F219uL3])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--QMA4XX	QMA	12
	IF @Feed = 'QMA' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],CAST(RIGHT(UNPS.[ColumnHeader],LEN(UNPS.[ColumnHeader])-3) AS int) AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [QMA1] ) AS [RowID],[QMA1],[QMA2],[QMA3],[QMA4],[QMA5],[QMA6],[QMA7],[QMA8],[QMA9],[QMA10],[QMA11],[QMA12]
				FROM [InvestmentReporting].[SRC_QMA] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([QMA1],[QMA2],[QMA3],[QMA4],[QMA5],[QMA6],[QMA7],[QMA8],[QMA9],[QMA10],[QMA11],[QMA12])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END	

	-- CBA	Cash Bank Acct
	IF @Feed = 'CBA' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [CBA1] ) AS [RowID]
						,[CBA1],[CBA2],[CBA3],[CBA4],[CBA5],[CBA6],[CBA7],[CBA8],[CBA9],[CBA10],[CBA11],[CBA12],[CBA13],[CBA14],[CBA15]
						,[CBA16],[CBA17],[CBA18],[CBA19],[CBA20],[CBA21],[CBA22],[CBA23],[CBA24],[CBA25]
				FROM [InvestmentReporting].[SRC_CBA] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([CBA1],[CBA2],[CBA3],[CBA4],[CBA5],[CBA6],[CBA7],[CBA8],[CBA9],[CBA10],[CBA11],[CBA12],[CBA13],[CBA14],[CBA15]
																,[CBA16],[CBA17],[CBA18],[CBA19],[CBA20],[CBA21],[CBA22],[CBA23],[CBA24],[CBA25])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	-- LMIF	LMIF
	IF @Feed = 'LMIF' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [LMIF1] ) AS [RowID]
						,[LMIF1],[LMIF2],[LMIF3],[LMIF4],[LMIF5],[LMIF6],[LMIF7],[LMIF8],[LMIF9],[LMIF10],[LMIF11],[LMIF12],[LMIF13],[LMIF14],[LMIF15]
						,[LMIF16],[LMIF17],[LMIF18],[LMIF19],[LMIF20],[LMIF21],[LMIF22],[LMIF23],[LMIF24],[LMIF25],[LMIF26],[LMIF27],[LMIF28],[LMIF29],[LMIF30]
				FROM [InvestmentReporting].[SRC_LMIF] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([LMIF1],[LMIF2],[LMIF3],[LMIF4],[LMIF5],[LMIF6],[LMIF7],[LMIF8],[LMIF9],[LMIF10],[LMIF11],[LMIF12],[LMIF13],[LMIF14],[LMIF15]
																,[LMIF16],[LMIF17],[LMIF18],[LMIF19],[LMIF20],[LMIF21],[LMIF22],[LMIF23],[LMIF24],[LMIF25],[LMIF26],[LMIF27],[LMIF28],[LMIF29],[LMIF30])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END


	-- ARC	Accelerated Reporting Categorisation
	IF @Feed = 'ARC' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [ARC1] ) AS [RowID]
						,[ARC1],[ARC2],[ARC3]
				FROM [InvestmentReporting].[SRC_ARC] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([ARC1],[ARC2],[ARC3])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END


	--WFCTP	WESTERN & FIERA - Cash Template Population

	IF @Feed = 'WFCTP' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [WFCTP1] ) AS [RowID]
						,[WFCTP1],[WFCTP2],[WFCTP3],[WFCTP4],[WFCTP5],[WFCTP6]
				FROM [InvestmentReporting].[SRC_WFCTP] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([WFCTP1],[WFCTP2],[WFCTP3],[WFCTP4],[WFCTP5],[WFCTP6])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--OD	Overseas Deposits
	IF @Feed = 'OD' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [OD1] ) AS [RowID]
						,[OD1],[OD2],[OD3],[OD4],[OD5],[OD6],[OD7],[OD8],[OD9],[OD10],[OD11]
				FROM [InvestmentReporting].[SRC_OD] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([OD1],[OD2],[OD3],[OD4],[OD5],[OD6],[OD7],[OD8],[OD9],[OD10],[OD11])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--FAS FAS Levle
	IF @Feed = 'FAS' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [FAS1] ) AS [RowID]
						,[FAS1],[FAS2],[FAS3],[FAS4],[FAS5]
				FROM [InvestmentReporting].[SRC_FAS] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([FAS1],[FAS2],[FAS3],[FAS4],[FAS5])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--FAS FAS Levle
	IF @Feed = 'BR' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [BR1] ) AS [RowID]
						,[BR1],[BR2],[BR3]
				FROM [InvestmentReporting].[SRC_BloombergRating] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([BR1],[BR2],[BR3])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--DYA	YOA Allocations - RIESCO 
		IF @Feed = 'DYA' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [DYA1] ) AS [RowID]
						,[DYA1],CAST([DYA2] AS nvarchar(255)) AS [DYA2],CAST([DYA3] AS nvarchar(255)) AS [DYA3],CAST([DYA4] AS nvarchar(255)) AS [DYA4]
				FROM [InvestmentReporting].[SRC_DYA] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([DYA1],[DYA2],[DYA3],[DYA4])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--DJO	Derivative Journal Output
		IF @Feed = 'DJO' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [DJO1] ) AS [RowID]
						,[DJO1],[DJO2],[DJO3],[DJO4],[DJO5],[DJO6]
				FROM [InvestmentReporting].[SRC_DJO] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([DJO1],[DJO2],[DJO3],[DJO4],[DJO5],[DJO6])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--DDC	Derivative Data Classifications 
	IF @Feed = 'DDC' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [DDC1] ) AS [RowID]
						,[DDC1],[DDC2],[DDC3],[DDC4],[DDC5],[DDC6],[DDC7],[DDC8],[DDC9],[DDC10]
				FROM [InvestmentReporting].[SRC_DDC] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([DDC1],[DDC2],[DDC3],[DDC4],[DDC5],[DDC6],[DDC7],[DDC8],[DDC9],[DDC10])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--F234C	234 Classification
	IF @Feed = 'F234C' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [F234C1] ) AS [RowID]
						,[F234C1],[F234C2]
				FROM [InvestmentReporting].[SRC_F234C] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([F234C1],[F234C2])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--DPR	Pay Rate
	IF @Feed = 'DPR' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [DPR1] ) AS [RowID]
						,[DPR1],[DPR2],[DPR3]
				FROM [InvestmentReporting].[SRC_DPR] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([DPR1],[DPR2],[DPR3])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--DMBC	Maturity Bucket Classifications
	IF @Feed = 'DMBC' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [DMBC1] ) AS [RowID]
						,[DMBC1],[DMBC2],[DMBC3],[DMBC4]
				FROM [InvestmentReporting].[SRC_DMBC] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([DMBC1],[DMBC2],[DMBC3],[DMBC4])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--DUOD	TGK - USE OF DERIVATIVE
	IF @Feed = 'DUOD' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [DUOD1] ) AS [RowID]
						,[DUOD1],[DUOD2]
				FROM [InvestmentReporting].[SRC_DUOD] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([DUOD1],[DUOD2])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--DUTC	TGK - Unwind Trigger of Contract
	IF @Feed = 'DUTC' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [DUTC1] ) AS [RowID]
						,[DUTC1],[DUTC2]
				FROM [InvestmentReporting].[SRC_DUTC] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([DUTC1],[DUTC2])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END

	--DBS	 TGK - BUYER/SELLER 
		IF @Feed = 'DBS' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [DBS1] ) AS [RowID]
						,[DBS1],[DBS2]
				FROM [InvestmentReporting].[SRC_DBS] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([DBS1],[DBS2])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END


	--F212uE1	 Form 212 Exclusions
	IF @Feed = 'F212uE' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [F212uE1] ) AS [RowID]
						,[F212uE1],[F212uE2],[F212uE3]
				FROM [InvestmentReporting].[SRC_F212uE] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([F212uE1],[F212uE2],[F212uE3])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END


	--PLR Profit & Loss Reference
	IF @Feed = 'PLR' 
	BEGIN	
		SELECT [RowID],M.[MetricDesc] AS [ColumnHeader],[ColumnValue],M.[MetricSort] AS [ColumnHeaderSort] FROM
		(
			SELECT [RowID],[ColumnHeader],[ColumnValue] FROM
			(
				SELECT ROW_NUMBER() OVER(ORDER BY [PLR1] ) AS [RowID]
						,[PLR1],[PLR2],[PLR3],[PLR4],[PLR5]
				FROM [InvestmentReporting].[SRC_PLR] S
				INNER JOIN [InvestmentReporting].[FeedDetails] FD
				ON FD.[pkFeedVersionID] = S.[VersionID]
				AND  FD.[pkFeedVersionID] = @VersionID
			) S
			UNPIVOT ( [ColumnValue] FOR [ColumnHeader] IN ([PLR1],[PLR2],[PLR3],[PLR4],[PLR5])) UNPS
		) UNPS
		INNER JOIN [InvestmentReporting].[Metrics] M
		ON M.[pkMetricID] = UNPS.[ColumnHeader] AND M.[MetricType] = 'Input'
	END




END
