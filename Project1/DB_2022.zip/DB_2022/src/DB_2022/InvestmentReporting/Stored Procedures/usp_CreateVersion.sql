﻿
CREATE  PROC  [InvestmentReporting].[usp_CreateVersion] 
	(	 @strReport AS NVARCHAR(255)
		,@strModelType AS NVARCHAR(255)
		,@strVersionName AS NVARCHAR(255)
		,@strUserID AS NVARCHAR(255)
		,@strAccountingPeriod AS NVARCHAR(255)
		,@strAUMAssetRpt AS NVARCHAR(255)
		,@strReference AS NVARCHAR(255)
		,@strRiskReport AS NVARCHAR(255)
		,@strClosedDerRpt AS NVARCHAR(255)
		,@strOpenDerRpt AS NVARCHAR(255)
		,@strOverseas AS NVARCHAR(255)
		,@strCash AS NVARCHAR(255)
		,@strPL AS NVARCHAR(255)
		,@strBloomberg AS NVARCHAR(255)
		,@strDescription AS NVARCHAR(255)
	)
AS
BEGIN


DECLARE @Error AS NVARCHAR(1000)
SET @Error = ''
SET @strUserID = SUBSTRING(@strUserID, CHARINDEX('\',@strUserID)+1,100)

	IF EXISTS (SELECT * FROM [InvestmentReporting].[ModelConfig] WHERE [VersionDesc] = @strVersionName)
		SET @Error = 'Version with the same name already exists, please select a different version name.'
	ELSE IF NOT EXISTS (SELECT * FROM [InvestmentReporting].[Users] WHERE [userid] = @strUserID AND [UserGroup] <> 'Deleted' )
		SET @Error = 'You do not have access to run the Investment Reporting models, please contact FDM support.'
	ELSE
	BEGIN
	
		INSERT INTO [InvestmentReporting].[ModelConfig] ([VersionDesc],[fkUserID],[updated_userid],[fkAccountingPeriod],[MetricGroup],[ModelType],[CreatedDate],[UpdatedDate],[Status],[Description],[JRStatus])
		VALUES(@strVersionName,@strUserID,@strUserID,@strAccountingPeriod,@strReport,@strModelType,GETDATE(),GETDATE(),'Configured',@strDescription,'NA')
		
		IF @strAUMAssetRpt <> 'NA'
		BEGIN
			INSERT INTO [InvestmentReporting].[ModelFeedConfig] ([fkModelID],[fkFeedVersionID])
			SELECT 
				(SELECT [pkModelID] FROM [InvestmentReporting].[ModelConfig] WHERE [VersionDesc] = @strVersionName),
				(SELECT [pkFeedVersionID] FROM [InvestmentReporting].[FeedDetails] FD INNER JOIN [InvestmentReporting].[FeedConfig] FC ON FC.[pkFeedID] = FD.[fkFeedID]
				WHERE FC.[FeedDesc] = 'AUM Asset Report' AND FD.[VersionDesc] = @strAUMAssetRpt AND FD.[pkFeedVersionID] = FD.[ParentID])
		END

		IF @strReference <> 'NA'
		BEGIN
			INSERT INTO [InvestmentReporting].[ModelFeedConfig] ([fkModelID],[fkFeedVersionID])
			SELECT 
				(SELECT [pkModelID] FROM [InvestmentReporting].[ModelConfig] WHERE [VersionDesc] = @strVersionName),
				(SELECT [pkFeedVersionID] FROM [InvestmentReporting].[FeedDetails] FD INNER JOIN [InvestmentReporting].[FeedConfig] FC ON FC.[pkFeedID] = FD.[fkFeedID]
				WHERE FC.[FeedDesc] = 'Reference' AND FD.[VersionDesc] = @strReference AND FD.[pkFeedVersionID] = FD.[ParentID])
		END

		IF @strBloomberg <> 'NA'
		BEGIN
			INSERT INTO [InvestmentReporting].[ModelFeedConfig] ([fkModelID],[fkFeedVersionID])
			SELECT 
				(SELECT [pkModelID] FROM [InvestmentReporting].[ModelConfig] WHERE [VersionDesc] = @strVersionName),
				(SELECT [pkFeedVersionID] FROM [InvestmentReporting].[FeedDetails] FD INNER JOIN [InvestmentReporting].[FeedConfig] FC ON FC.[pkFeedID] = FD.[fkFeedID]
				WHERE FC.[FeedDesc] = 'Bloomberg Rating' AND FD.[VersionDesc] = @strBloomberg AND FD.[pkFeedVersionID] = FD.[ParentID])
		END

		IF @strRiskReport <> 'NA'
		BEGIN
			INSERT INTO [InvestmentReporting].[ModelFeedConfig] ([fkModelID],[fkFeedVersionID])
			SELECT 
				(SELECT [pkModelID] FROM [InvestmentReporting].[ModelConfig] WHERE [VersionDesc] = @strVersionName),
				(SELECT [pkFeedVersionID] FROM [InvestmentReporting].[FeedDetails] FD INNER JOIN [InvestmentReporting].[FeedConfig] FC ON FC.[pkFeedID] = FD.[fkFeedID]
				WHERE FC.[FeedDesc] = 'Risk and Bloomberg Report' AND FD.[VersionDesc] = @strRiskReport AND FD.[pkFeedVersionID] = FD.[ParentID])
		END

		IF @strOpenDerRpt <> 'NA'
		BEGIN
			INSERT INTO [InvestmentReporting].[ModelFeedConfig] ([fkModelID],[fkFeedVersionID])
			SELECT 
			(SELECT [pkModelID] FROM [InvestmentReporting].[ModelConfig] WHERE [VersionDesc] = @strVersionName),
			(SELECT [pkFeedVersionID] FROM [InvestmentReporting].[FeedDetails] FD INNER JOIN [InvestmentReporting].[FeedConfig] FC ON FC.[pkFeedID] = FD.[fkFeedID]
			WHERE FC.[FeedDesc] = 'Open Derivatives Report' AND FD.[VersionDesc] = @strOpenDerRpt AND FD.[pkFeedVersionID] = FD.[ParentID])
		END

		IF @strClosedDerRpt <> 'NA'
		BEGIN
			INSERT INTO [InvestmentReporting].[ModelFeedConfig] ([fkModelID],[fkFeedVersionID])
			SELECT 
				(SELECT [pkModelID] FROM [InvestmentReporting].[ModelConfig] WHERE [VersionDesc] = @strVersionName),
				(SELECT [pkFeedVersionID] FROM [InvestmentReporting].[FeedDetails] FD INNER JOIN [InvestmentReporting].[FeedConfig] FC ON FC.[pkFeedID] = FD.[fkFeedID]
				WHERE FC.[FeedDesc] = 'Closed Derivatives Report' AND FD.[VersionDesc] = @strClosedDerRpt AND FD.[pkFeedVersionID] = FD.[ParentID])
		END

		IF @strOverseas <> 'NA'
		BEGIN
			INSERT INTO [InvestmentReporting].[ModelFeedConfig] ([fkModelID],[fkFeedVersionID])
			SELECT 
				(SELECT [pkModelID] FROM [InvestmentReporting].[ModelConfig] WHERE [VersionDesc] = @strVersionName),
				(SELECT [pkFeedVersionID] FROM [InvestmentReporting].[FeedDetails] FD INNER JOIN [InvestmentReporting].[FeedConfig] FC ON FC.[pkFeedID] = FD.[fkFeedID]
				WHERE FC.[FeedDesc] = 'FDM Overseas GL Extract' AND FD.[VersionDesc] = @strOverseas AND FD.[pkFeedVersionID] = FD.[ParentID])
		END

		IF @strCash <> 'NA'
		BEGIN
			INSERT INTO [InvestmentReporting].[ModelFeedConfig] ([fkModelID],[fkFeedVersionID])
			SELECT 
				(SELECT [pkModelID] FROM [InvestmentReporting].[ModelConfig] WHERE [VersionDesc] = @strVersionName),
				(SELECT [pkFeedVersionID] FROM [InvestmentReporting].[FeedDetails] FD INNER JOIN [InvestmentReporting].[FeedConfig] FC ON FC.[pkFeedID] = FD.[fkFeedID]
				WHERE FC.[FeedDesc] = 'FDM Cash GL Extract' AND FD.[VersionDesc] = @strCash AND FD.[pkFeedVersionID] = FD.[ParentID])
		END

		IF @strPL <> 'NA'
		BEGIN
			INSERT INTO [InvestmentReporting].[ModelFeedConfig] ([fkModelID],[fkFeedVersionID])
			SELECT 
				(SELECT [pkModelID] FROM [InvestmentReporting].[ModelConfig] WHERE [VersionDesc] = @strVersionName),
				(SELECT [pkFeedVersionID] FROM [InvestmentReporting].[FeedDetails] FD INNER JOIN [InvestmentReporting].[FeedConfig] FC ON FC.[pkFeedID] = FD.[fkFeedID]
				WHERE FC.[FeedDesc] = 'MTDYTD P&L Report' AND FD.[VersionDesc] = @strPL AND FD.[pkFeedVersionID] = FD.[ParentID])
		END
				
		
		IF EXISTS (SELECT 1 FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[VersionDesc] = @strVersionName
					LEFT JOIN [InvestmentReporting].[FeedDetails] FD ON FD.[pkFeedVersionID] = MFC.[fkFeedVersionID] WHERE FD.[VersionDesc] IS NULL)
		BEGIN
			SET @Error = 'One or more Input file is deleted, please reconfigure the Model'
			UPDATE [InvestmentReporting].[ModelConfig] SET [Status] = 'Failed' WHERE [VersionDesc] = @strVersionName
		END

		IF @Error = ''
		BEGIN
			INSERT INTO [FDM_PROCESS].[Admin].[RunProcessLog] ([fk_RunProcessConfig],[FileName],[Module],[CreatedDate],[CreatedBy],[SelectedAccountingPeriod],[Status],[FileStatus])
				SELECT [pk_RunProcessConfig],@strVersionName,[ModuleName],GETDATE(),@strUserID,@strAccountingPeriod ,'Pending','Y' FROM [FDM_PROCESS].[Admin].[RunProcessConfig] R
				WHERE R.[ModuleName] = 'Investment Run Model'

			SET @Error = 'Model Configured Successfully, you will get an email alert with the status of Model Run'
		END
	END 
	
	SELECT 0 AS [ID], @Error AS [Msg]
END

--UPDATE [InvestmentReporting].[ModelConfig] SET [Status] = 'Failed' WHERE [Status] = 'Running'
--UPDATE [InvestmentReporting].[ModelConfig] SET [Status] = 'Running' WHERE [VersionDesc] = 'Test'


