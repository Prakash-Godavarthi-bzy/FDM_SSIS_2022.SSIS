﻿



CREATE PROC [InvestmentReporting].[usp_ReportAction] (@Action AS NVARCHAR(255),@VersionID INT,@User NVARCHAR(255),@VDesc NVARCHAR(255))
AS
BEGIN


	DECLARE @Msg as NVARCHAR(500)
	
	SET  @Msg = ''
	SET @User = SUBSTRING(@User, CHARINDEX('\',@User)+1,100)
	IF NOT EXISTS (SELECT * FROM [InvestmentReporting].[Users] WHERE [userid]= @User)
		SET @Msg = 'You do not have access to perform any Investment Model actions, please contact FDM support.'
	ELSE
	BEGIN
		IF @Action = 'Delete Input' AND EXISTS (SELECT 1 FROM [InvestmentReporting].[FeedDetails] WHERE [pkFeedVersionID] = @VersionID)
		BEGIN
			IF NOT EXISTS (SELECT 1 FROM [InvestmentReporting].[ModelFeedConfig] WHERE [fkFeedVersionID] = @VersionID)
			BEGIN
				DELETE FROM [InvestmentReporting].[SRC_AUMAssetReport] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_BloombergRating] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_CashExtract] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_ClosedDerivativesReport] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_OpenDerivativesReport] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_OverseasExtract] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_PLReport] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_RiskAndBloombergReport] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_RiskAndBloombergReportIDCode] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_ARC] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_ATC] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_BCA] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_BCB] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_BCC] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_BCD] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_CBA] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_CGL] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_CIC] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_CICR] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_CSTDCUS] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_CSTDL] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_DBS] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_DDC] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_DJO] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_DMBC] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_DPR] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_DUOD] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_DUTC] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_DYA] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_ENT] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_F201L] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_F212uE] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_F212uL] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_F219uL] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_F234C] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_FAS] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_GR] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_IMSA] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_IMSB] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_IMSC] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_IMSD] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_INF] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_IS] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_LMIF] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_OD] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_PLR] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_QAPC] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_QAUL] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_QCQ] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_QCTC] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_QHRU] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_QIDCT] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_QII] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_QISE] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_QMA] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_QNECAI] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_QPF] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_QTIC] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_QVM] WHERE [VersionID] = @VersionID
				DELETE FROM [InvestmentReporting].[SRC_WFCTP] WHERE [VersionID] = @VersionID
			
				SELECT @Msg =  'Deleted ' + FC.[FeedType] + ' - ' + FC.[FeedDesc] + ' with version name ' + FD.[VersionDesc] FROM [InvestmentReporting].[FeedConfig] FC INNER JOIN [InvestmentReporting].[FeedDetails] FD ON FD.[pkFeedVersionID] = @VersionID AND FD.[fkFeedID] = FC.pkFeedID

				DELETE FROM [InvestmentReporting].[FeedDetails] WHERE [pkFeedVersionID] = @VersionID
			END
		END

		IF @Action = 'Update Desc' AND EXISTS (SELECT 1 FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID)
		BEGIN

			IF	(	(SELECT [Status] FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID) IN ('Locked')
						AND EXISTS (SELECT * FROM [InvestmentReporting].[Users] WHERE [userid]= @User AND [UserGroup] IN ('Super User'))
					)
					OR
					(	(SELECT [Status] FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID) IN ('Available')
						AND EXISTS (SELECT * FROM [InvestmentReporting].[ModelConfig] WHERE [fkUserID] = @User AND [pkModelID] = @VersionID)
					)
			BEGIN 
				UPDATE [InvestmentReporting].[ModelConfig] SET [Description] = @VDesc,[updated_userid] = @User, [UpdatedDate] = GETDATE() WHERE [pkModelID] = @VersionID
				SELECT @Msg =  [VersionDesc] + ' version description updated' FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID
			END
			ELSE
				SELECT @Msg =  'You don''t have access to updated description of this model, please contact FDM support'
		END


		IF @Action = 'Delete Model' AND EXISTS (SELECT 1 FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID)
		BEGIN

			IF (SELECT [Status] FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID) = 'Failed'
			BEGIN
				SELECT @Msg =  'Deleted ' + [VersionDesc]  FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID
				DELETE FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID
				DELETE FROM [InvestmentReporting].[ModelFeedConfig] WHERE [fkModelID] = @VersionID
			END
			ELSE IF	(	(SELECT [Status] FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID) IN ('Available')
						AND EXISTS (SELECT * FROM [InvestmentReporting].[Users] WHERE [userid]= @User AND [UserGroup] IN ('Admin','Super User'))
					)
					OR
					(	(SELECT [Status] FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID) IN ('Available')
						AND EXISTS (SELECT * FROM [InvestmentReporting].[ModelConfig] WHERE [fkUserID] = @User AND [pkModelID] = @VersionID)
					)
			BEGIN 
				UPDATE [InvestmentReporting].[ModelConfig] SET [Status] = 'Deleted',[updated_userid] = @User, [UpdatedDate] = GETDATE() WHERE [pkModelID] = @VersionID
				SELECT @Msg =  [VersionDesc] + ' marked for deletion' FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID
			END
			ELSE
				SELECT @Msg =  'You don''t have access to delete this model, please contact FDM support'
		END

		IF @Action = 'Recover Model' AND EXISTS (SELECT 1 FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID)
		BEGIN
			IF (SELECT [Status] FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID) = 'Deleted'
			BEGIN
				UPDATE [InvestmentReporting].[ModelConfig] SET [Status] = 'Available',[updated_userid] = @User, [UpdatedDate] = GETDATE() WHERE [pkModelID] = @VersionID
				SELECT @Msg =  [VersionDesc] + ' restored' FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID
			END
		END

		IF @Action = 'Lock Model' AND EXISTS (SELECT 1 FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID)
		BEGIN
			IF (SELECT [Status] FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID) = 'Available'
			BEGIN
				UPDATE [InvestmentReporting].[ModelConfig] SET [Status] = 'Locked',[updated_userid] = @User, [UpdatedDate] = GETDATE() WHERE [pkModelID] = @VersionID
				SELECT @Msg =  [VersionDesc] + ' locked' FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID
			END
		END

		IF @Action = 'Submit Model' AND EXISTS (SELECT 1 FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID)
		BEGIN
			IF (SELECT [Status] FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID) IN ('Available','Locked')
			BEGIN
				UPDATE [InvestmentReporting].[ModelConfig] SET [Status] = 'Submitted',[updated_userid] = @User, [UpdatedDate] = GETDATE() WHERE [pkModelID] = @VersionID
				SELECT @Msg =  [VersionDesc] + ' marked as submitted' FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID
			END
		END

		IF @Action = 'Unlock Model' AND EXISTS (SELECT 1 FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID)
		BEGIN
			IF	(	(	(SELECT [Status] FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID) IN ('Submitted','Locked')
						AND EXISTS (SELECT * FROM [InvestmentReporting].[Users] WHERE [userid]	 = @User AND [UserGroup] IN ('Super User'))
					)
					OR
					(	SELECT [Status] FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID) IN ('Locked')
						AND EXISTS (SELECT * FROM [InvestmentReporting].[ModelConfig] WHERE [fkUserID] = @User AND [pkModelID] = @VersionID)
					)
			
			BEGIN
				UPDATE [InvestmentReporting].[ModelConfig] SET [Status] = 'Available',[updated_userid] = @User, [UpdatedDate] = GETDATE() WHERE [pkModelID] = @VersionID
				SELECT @Msg =  [VersionDesc] + ' unlocked' FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID
			END
			ELSE
					SELECT @Msg =  'You don''t have access to unlock this model, please contact FDM support'
		END

		IF @Action = 'Post Journal' AND EXISTS (SELECT 1 FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID)
		BEGIN
			IF		(	(SELECT [Status] FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID) IN ('Submitted','Locked','Available')
						AND EXISTS (SELECT * FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID AND [JrStatus] NOT IN ('NA','Posting') )
					)			
			BEGIN
				
				UPDATE [InvestmentReporting].[ModelConfig] SET [updated_userid] = @User, [UpdatedDate] = GETDATE(), [JrStatus] = 'Posting'  WHERE [pkModelID] = @VersionID

				INSERT INTO [FDM_PROCESS].[Admin].[RunProcessLog] ([fk_RunProcessConfig],[FileName],[Module],[CreatedDate],[CreatedBy],[SelectedAccountingPeriod],[Status],[FileStatus])
				SELECT [pk_RunProcessConfig],[VersionDesc],[ModuleName],GETDATE(),@User,MC.[fkAccountingPeriod] ,'Pending','Y' FROM [FDM_PROCESS].[Admin].[RunProcessConfig] R
				INNER JOIN [InvestmentReporting].[ModelConfig]  MC ON [pkModelID] = @VersionID 
				WHERE R.[ModuleName] = 'Investment Post Model'
			
				SELECT @Msg =  'FDM posting process initiated for ' + [VersionDesc] + ', you will get an email alert for the status.' FROM [InvestmentReporting].[ModelConfig] WHERE [pkModelID] = @VersionID
			END
			ELSE
					SELECT @Msg =  'The model can''t be posted to FDM, please contact FDM support for more details.'
		END
	END
	SELECT 0 AS [ID], @Msg AS [Msg]

END



