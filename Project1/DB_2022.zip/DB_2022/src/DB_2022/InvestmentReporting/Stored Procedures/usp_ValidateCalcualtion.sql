﻿
--select * from InvestmentReporting.Metrics where MetricGroup = 'bs'
--select distinct pkMetricID from InvestmentReporting.Metrics where MetricGroup = 'bs'
--EXEC [InvestmentReporting].[usp_ValidateCalcualtion]

CREATE PROC [InvestmentReporting].[usp_ValidateCalcualtion]
AS
BEGIN
	DECLARE @strMetricGroup AS NVARCHAR(255)
	DECLARE @strMetricID AS NVARCHAR(255)
	DECLARE @strMetricCalc AS NVARCHAR(1000)
	DECLARE @intStartLocation AS INT
	DECLARE @intEndLocation AS INT
	DECLARE @intMetricSequence AS INT

	--Update Existing Data
	DELETE FROM [InvestmentReporting].[MetricsDependency] WHERE [Version] = 'Prev'
	DELETE FROM [InvestmentReporting].[MetricsSequence] WHERE [Version] = 'Prev'
	
	UPDATE [InvestmentReporting].[MetricsDependency] SET [Version] = 'Prev'
	UPDATE [InvestmentReporting].[MetricsSequence] SET [Version] = 'Prev'
	
	SET @strMetricGroup = ''

	WHILE EXISTS (SELECT 1 FROM [InvestmentReporting].[Reports] WHERE [MetricGroup] > @strMetricGroup)
	BEGIN
		SELECT TOP 1 @strMetricGroup = [MetricGroup]  FROM [InvestmentReporting].[Reports] WHERE [MetricGroup] > @strMetricGroup ORDER BY [MetricGroup]	
	
		SET @intMetricSequence = 1
		SET @strMetricID = ''
		
		SELECT TOP 1 @strMetricID = [pkMetricID], @strMetricCalc = [MetricCalculation] + ' ' + [UniqueValue]  FROM [InvestmentReporting].[Metrics] WHERE [MetricGroup] = @strMetricGroup AND [pkMetricID] > @strMetricID AND [MetricType] = 'Calculation' ORDER BY [pkMetricID]

		WHILE @strMetricID IS NOT NULL
		BEGIN
			PRINT @strMetricID + ' Calc - ' + @strMetricCalc
			SET @intStartLocation = 1
			
			WHILE @intStartLocation <> 0
			BEGIN
				SET @intStartLocation = CHARINDEX('[',@strMetricCalc,@intStartLocation)
				IF @intStartLocation <> 0
				BEGIN
					SET @intEndLocation = CHARINDEX(']',@strMetricCalc,@intStartLocation)
					PRINT SUBSTRING(@strMetricCalc,@intStartLocation+1,@intEndLocation - @intStartLocation - 1)
					IF NOT EXISTS (SELECT * FROM [InvestmentReporting].[MetricsDependency] WHERE [MetricGroup] = @strMetricGroup AND [pkMetricID] = @strMetricID AND [MetricDependency] = SUBSTRING(@strMetricCalc,@intStartLocation+1,@intEndLocation - @intStartLocation - 1) AND [Version] IS NULL )
						INSERT INTO [InvestmentReporting].[MetricsDependency] ([MetricGroup],[pkMetricID],[MetricDependency])
						VALUES (@strMetricGroup,@strMetricID,SUBSTRING(@strMetricCalc,@intStartLocation+1,@intEndLocation - @intStartLocation - 1))
					SET @intStartLocation = @IntEndLocation + 1
				END
			END

			IF NOT EXISTS (SELECT * FROM [InvestmentReporting].[Metrics] WHERE [MetricGroup] = @strMetricGroup AND [pkMetricID] > @strMetricID AND [MetricType] = 'Calculation' )
				SET @strMetricID = NULL
			ELSE
				SELECT TOP 1 @strMetricID = [pkMetricID], @strMetricCalc = [MetricCalculation] + ' ' + [UniqueValue] FROM [InvestmentReporting].[Metrics] WHERE [MetricGroup] = @strMetricGroup AND [pkMetricID] > @strMetricID AND [MetricType] = 'Calculation' ORDER BY [pkMetricID]
			END

			-- Sequence

			INSERT INTO [InvestmentReporting].[MetricsSequence] ([pkMetricID],[MetricGroup],[MetricSequence])
			SELECT M.[pkMetricID],M.[MetricGroup],@intMetricSequence FROM [InvestmentReporting].[Metrics] M
			LEFT JOIN [InvestmentReporting].[MetricsDependency] MD
			ON M.[pkMetricID] = MD.[pkMetricID]
			AND M.[MetricGroup] = MD.[MetricGroup]
			AND MD.[Version] IS NULL
			WHERE M.[MetricGroup] = @strMetricGroup AND MD.pkMetricID IS NULL
			

			WHILE EXISTS (SELECT 1 FROM [InvestmentReporting].[MetricsSequence] WHERE [MetricGroup] = @strMetricGroup AND [MetricSequence] = @intMetricSequence AND [Version] IS NULL )
			BEGIN
				--SELECT 'here',@intMetricSequence,@strMetricGroup
				SET @intMetricSequence = @intMetricSequence + 1
	
				INSERT INTO [InvestmentReporting].[MetricsSequence] ([pkMetricID],[MetricGroup],[MetricSequence])
				
				SELECT MD.[pkMetricID],@strMetricGroup,@intMetricSequence
				FROM [InvestmentReporting].[MetricsDependency] MD 
				LEFT JOIN [InvestmentReporting].[MetricsSequence] MS ON MD.[MetricDependency] = MS.[pkMetricID] AND MD.[MetricGroup] = MS.[MetricGroup] AND MS.[Version] IS NULL
				LEFT JOIN [InvestmentReporting].[MetricsSequence] RESOLVED ON RESOLVED.[pkMetricID] = MD.[pkMetricID] AND RESOLVED.[MetricGroup] = MD.[MetricGroup] AND RESOLVED.[Version] IS NULL
				WHERE RESOLVED.[pkMetricID] IS NULL AND MD.[Version] IS NULL AND MD.[MetricGroup] = @strMetricGroup
				GROUP BY MD.[pkMetricID]
				HAVING COUNT(MD.MetricDependency) - COUNT(MS.pkMetricID)  = 0

				PRINT @intMetricSequence

			END
	END
	
	IF EXISTS ( SELECT 1 FROM [InvestmentReporting].[MetricsDependency] MD LEFT JOIN [InvestmentReporting].[MetricsSequence] MS
				ON MD.[pkMetricID] = MS.[pkMetricID] AND MD.[MetricGroup] = MS.[MetricGroup] AND MS.[Version] IS NULL
				WHERE MD.[Version] IS NULL AND MS.[pkMetricID] IS NULL)
	BEGIN
		UPDATE [InvestmentReporting].[MetricsDependency] SET [Version] = 'Live' WHERE [Version] = 'Prev'
		UPDATE [InvestmentReporting].[MetricsSequence] SET [Version] = 'Live' WHERE [Version] = 'Prev'

		UPDATE [InvestmentReporting].[MetricsDependency] SET [Version] = 'Prev' WHERE [Version] IS NULL
		UPDATE [InvestmentReporting].[MetricsSequence] SET [Version] = 'Prev' WHERE [Version] IS NULL

		DELETE FROM [InvestmentReporting].[Metrics] WHERE [pkMetricID] NOT LIKE 'OLD_%'
		UPDATE [InvestmentReporting].[Metrics] SET [pkMetricID] = RIGHT([pkMetricID],LEN([pkMetricID])-4) , [MetricGroup] =  RIGHT([MetricGroup],LEN([MetricGroup])-4)

		SELECT 'Error in resolving metric dependeny for the new set of calculaitons, FDM has reverted to old calcualtions. Please refer to metric dependency report for more details' AS [Error]			
			
	END
	ELSE
	BEGIN
		UPDATE [InvestmentReporting].[MetricsDependency] SET [Version] = 'Live' WHERE [Version] IS NULL
		UPDATE [InvestmentReporting].[MetricsSequence] SET [Version] = 'Live' WHERE [Version] IS NULL
		DELETE FROM [InvestmentReporting].[Metrics] WHERE [pkMetricID] LIKE 'OLD_%'
		SELECT '' AS [Error]
	END
	/*


	

	
	 SELECT MD.[pkMetricID],MD.[MetricDependency],M.[MetricCalculation] FROM [InvestmentReporting].[MetricsDependency] MD LEFT JOIN [InvestmentReporting].[MetricsSequence] MS
	 ON MD.[pkMetricID] = MS.[pkMetricID] AND MD.[MetricGroup] = MS.[MetricGroup]
	 LEFT JOIN [InvestmentReporting].[MetricsSequence] RESOLVED ON RESOLVED.[pkMetricID] = MD.[MetricDependency] AND RESOLVED.[MetricGroup] = MD.[MetricGroup]
	 LEFT JOIN [InvestmentReporting].[Metrics] M ON M.[pkMetricID] = MD.[pkMetricID] AND M.[MetricGroup] = MD.[MetricGroup]
	 WHERE MS.pkMetricID IS NULL AND MD.[MetricGroup] = @strMetricGroup  AND RESOLVED.[pkMetricID] IS NULL
	 ORDER BY 1


	 */
END
