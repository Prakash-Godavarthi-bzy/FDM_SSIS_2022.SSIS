﻿

CREATE PROC [InvestmentReporting].[usp_ModelData] (@Model AS NVARCHAR(255), @VersionID AS INT, @Reference NVARCHAR(255))
AS
BEGIN
	IF @Model = 'AUM'
	BEGIN
		SELECT M.[pkMetricID] + ' - ' + M.[MetricDesc] AS [MetricDesc],M.[MetricSort],ISNULL(FCT.[RowID],1) AS [RowID],[ValueC],[ValueN],M.[MetricCalculation]
		,CASE WHEN M.[DataType] LIKE 'NVARCHAR%' THEN 'Text' ELSE 'Num' END AS [DataType]
		FROM [InvestmentReporting].[Metrics] M
		LEFT JOIN [InvestmentReporting].[AUMAssetModel] FCT ON M.[pkMetricID] = FCT.[Metric]  AND FCT.[VersionID] = @VersionID 
		WHERE (CHARINDEX(M.[MetricGroup],M.[pkMetricID],1) > 0 OR M.[MetricReference] = '' OR @Reference = 'Yes') AND M.[MetricGroup] = @Model
	END
	IF @Model = 'DMC'
	BEGIN
		SELECT M.[pkMetricID] + ' - ' + M.[MetricDesc] AS [MetricDesc],M.[MetricSort],ISNULL(FCT.[RowID],1) AS [RowID],[ValueC],[ValueN],M.[MetricCalculation]
		,CASE WHEN M.[DataType] LIKE 'NVARCHAR%' THEN 'Text' ELSE 'Num' END AS [DataType]
		FROM [InvestmentReporting].[Metrics] M
		LEFT JOIN [InvestmentReporting].[DerivativesClosedModel]  FCT ON M.[pkMetricID] = FCT.[Metric]  AND FCT.[VersionID] = @VersionID 
		WHERE (CHARINDEX(M.[MetricGroup],M.[pkMetricID],1) > 0 OR  @Reference = 'Yes') AND M.[MetricGroup] = @Model
	END
	IF @Model = 'DMO'
	BEGIN
		SELECT M.[pkMetricID] + ' - ' + M.[MetricDesc] AS [MetricDesc],M.[MetricSort],ISNULL(FCT.[RowID],1) AS [RowID],[ValueC],[ValueN],M.[MetricCalculation]
		,CASE WHEN M.[DataType] LIKE 'NVARCHAR%' THEN 'Text' ELSE 'Num' END AS [DataType]
		FROM [InvestmentReporting].[Metrics] M
		LEFT JOIN [InvestmentReporting].[DerivativesOpenModel]  FCT ON M.[pkMetricID] = FCT.[Metric]  AND FCT.[VersionID] = @VersionID 
		WHERE (CHARINDEX(M.[MetricGroup],M.[pkMetricID],1) > 0  OR @Reference = 'Yes') AND M.[MetricGroup] = @Model
	END
	IF @Model = 'LOM'
	BEGIN
		SELECT M.[pkMetricID] + ' - ' + M.[MetricDesc] AS [MetricDesc],M.[MetricSort],ISNULL(FCT.[RowID],11) AS [RowID],[ValueC],[ValueN],M.[MetricCalculation]
		,CASE WHEN M.[DataType] LIKE 'NVARCHAR%' THEN 'Text' ELSE 'Num' END AS [DataType]
		FROM [InvestmentReporting].[Metrics] M
		LEFT JOIN [InvestmentReporting].[LloydsOverseasModel]  FCT ON M.[pkMetricID] = FCT.[Metric]  AND FCT.[VersionID] = @VersionID 
		WHERE (CHARINDEX(M.[MetricGroup],M.[pkMetricID],1) > 0  OR @Reference = 'Yes') AND M.[MetricGroup] = @Model
	END
	IF @Model = 'CBM'
	BEGIN
		SELECT M.[pkMetricID] + ' - ' + M.[MetricDesc] AS [MetricDesc],M.[MetricSort],ISNULL(FCT.[RowID],1) AS [RowID],[ValueC],[ValueN],M.[MetricCalculation]
		,CASE WHEN M.[DataType] LIKE 'NVARCHAR%' THEN 'Text' ELSE 'Num' END AS [DataType]
		FROM [InvestmentReporting].[Metrics] M
		LEFT JOIN [InvestmentReporting].[CashAtBankModel]  FCT ON M.[pkMetricID] = FCT.[Metric]  AND FCT.[VersionID] = @VersionID 
		WHERE (CHARINDEX(M.[MetricGroup],M.[pkMetricID],1) > 0  OR @Reference = 'Yes') AND M.[MetricGroup] = @Model
	END

	IF @Model = 'PLM'
	BEGIN
		SELECT M.[pkMetricID] + ' - ' + M.[MetricDesc] AS [MetricDesc],M.[MetricSort],ISNULL(FCT.[RowID],1) AS [RowID],[ValueC],[ValueN],M.[MetricCalculation]
		,CASE WHEN M.[DataType] LIKE 'NVARCHAR%' THEN 'Text' ELSE 'Num' END AS [DataType]
		FROM [InvestmentReporting].[Metrics] M
		LEFT JOIN [InvestmentReporting].[PLModel]  FCT ON M.[pkMetricID] = FCT.[Metric]  AND FCT.[VersionID] = @VersionID 
		WHERE (CHARINDEX(M.[MetricGroup],M.[pkMetricID],1) > 0  OR @Reference = 'Yes') AND M.[MetricGroup] = @Model
	END
	
END
