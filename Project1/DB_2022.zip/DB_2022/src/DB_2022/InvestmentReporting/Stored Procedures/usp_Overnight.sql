﻿
CREATE PROC [InvestmentReporting].[usp_Overnight]
 AS
 
 DECLARE @IntDays AS INT
 SET @IntDays = 50
 
 SELECT @IntDays = [ConfigValue] FROM [ProcessConfig] WHERE [ProcessDesc] ='InvestmentReporting' AND [ConfigDesc] = 'Deletion Days'
 
 DELETE FROM [InvestmentReporting].[FactModel] 
 WHERE [fk_ModelID] IN (SELECT  [pkModelID] FROM [InvestmentReporting].[ModelConfig] WHERE [Status] = 'Deleted' AND DATEADD(D,@IntDays,[UpdatedDate]) < GETDATE())

 DELETE FROM [InvestmentReporting].[AUMAssetModel] WHERE 
 [VersionID] IN (SELECT  [pkModelID] FROM [InvestmentReporting].[ModelConfig] WHERE [Status] = 'Deleted' AND DATEADD(D,@IntDays,[UpdatedDate]) < GETDATE())
 
 DELETE FROM [InvestmentReporting].[CashAtBankModel] WHERE 
 [VersionID] IN (SELECT  [pkModelID] FROM [InvestmentReporting].[ModelConfig] WHERE [Status] = 'Deleted' AND DATEADD(D,@IntDays,[UpdatedDate]) < GETDATE())
 
 DELETE FROM [InvestmentReporting].[DerivativesClosedModel] WHERE 
 [VersionID] IN (SELECT  [pkModelID] FROM [InvestmentReporting].[ModelConfig] WHERE [Status] = 'Deleted' AND DATEADD(D,@IntDays,[UpdatedDate]) < GETDATE())
 
 DELETE FROM [InvestmentReporting].[DerivativesOpenModel] WHERE 
 [VersionID] IN (SELECT  [pkModelID] FROM [InvestmentReporting].[ModelConfig] WHERE [Status] = 'Deleted' AND DATEADD(D,@IntDays,[UpdatedDate]) < GETDATE())
 
 DELETE FROM [InvestmentReporting].[PLModel] WHERE 
 [VersionID] IN (SELECT  [pkModelID] FROM [InvestmentReporting].[ModelConfig] WHERE [Status] = 'Deleted' AND DATEADD(D,@IntDays,[UpdatedDate]) < GETDATE())
 
 DELETE FROM [InvestmentReporting].[LloydsOverseasModel] WHERE 
 [VersionID] IN (SELECT  [pkModelID] FROM [InvestmentReporting].[ModelConfig] WHERE [Status] = 'Deleted' AND DATEADD(D,@IntDays,[UpdatedDate]) < GETDATE())

 DELETE FROM [InvestmentReporting].[ModelFeedConfig] WHERE [fkModelID] IN 
 (SELECT  [pkModelID] FROM [InvestmentReporting].[ModelConfig] WHERE [Status] = 'Deleted' AND DATEADD(D,@IntDays,[UpdatedDate]) < GETDATE())
 
 DELETE FROM [InvestmentReporting].[ModelConfig] WHERE [Status] = 'Deleted' AND DATEADD(D,@IntDays,[UpdatedDate]) < GETDATE()

 DELETE FROM [InvestmentReporting].[InvDimCustodian] WHERE [pk_Custodian] NOT IN (SELECT DISTINCT [fk_Custodian] FROM [InvestmentReporting].[FactModel])
 
 DELETE FROM [InvestmentReporting].[InvDimDerivative] WHERE [pk_Derivative] NOT IN (SELECT DISTINCT [fk_Derivative] FROM [InvestmentReporting].[FactModel])
 
 DELETE FROM [InvestmentReporting].[InvDimHoldingCurrency] WHERE [HoldingCurrency] NOT IN (SELECT DISTINCT [fk_HoldingCurrency] FROM [InvestmentReporting].[FactModel])
 
 DELETE FROM [InvestmentReporting].[InvDimInvestment] WHERE [pk_Investment] NOT IN (SELECT DISTINCT [fk_Investment] FROM [InvestmentReporting].[FactModel])
 
 DELETE FROM [InvestmentReporting].[InvDimIssuer] WHERE [pk_Issuer] NOT IN (SELECT DISTINCT [fk_Issuer] FROM [InvestmentReporting].[FactModel])
 
 DELETE FROM [InvestmentReporting].[InvDimLloydsReporting] WHERE [pk_LloydsReporting] NOT IN (SELECT DISTINCT [fk_LloydsReporting] FROM [InvestmentReporting].[FactModel])
 
 DELETE FROM [InvestmentReporting].[InvDimMaturity] WHERE [pk_Maturity] NOT IN (SELECT DISTINCT [pk_Maturity] FROM [InvestmentReporting].[FactModel])
 
 DELETE FROM [InvestmentReporting].[InvDimProfitAndLoss] WHERE [pk_ProfitAndLoss] NOT IN (SELECT DISTINCT [fk_ProfitAndLoss] FROM [InvestmentReporting].[FactModel])
 
 DELETE FROM [InvestmentReporting].[InvDimRatingsAndLevels] WHERE [pk_Rating] NOT IN (SELECT DISTINCT [fk_Rating] FROM [InvestmentReporting].[FactModel])
 
 DELETE FROM [InvestmentReporting].[InvDimTGKReporting] WHERE [pk_TGKReporting] NOT IN (SELECT DISTINCT [fk_TGKReporting] FROM [InvestmentReporting].[FactModel])

 

 
