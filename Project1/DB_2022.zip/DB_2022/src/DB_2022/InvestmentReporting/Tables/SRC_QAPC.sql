﻿CREATE TABLE [InvestmentReporting].[SRC_QAPC] (
    [VersionID] INT            NULL,
    [QAPC1]     NVARCHAR (255) NULL,
    [QAPC2]     NVARCHAR (255) NULL,
    [QAPC3]     NVARCHAR (255) NULL
);

