﻿CREATE TABLE [InvestmentReporting].[ReferenceAudit] (
    [ListName] NVARCHAR (255) NULL,
    [Modified] DATETIME       NULL
);

