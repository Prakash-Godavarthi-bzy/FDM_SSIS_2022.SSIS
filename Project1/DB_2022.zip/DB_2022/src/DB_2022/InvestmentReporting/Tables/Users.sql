﻿CREATE TABLE [InvestmentReporting].[Users] (
    [userid]    NVARCHAR (255) NOT NULL,
    [UserName]  NVARCHAR (255) NULL,
    [UserEmail] NVARCHAR (255) NULL,
    [UserGroup] NVARCHAR (255) NULL,
    CONSTRAINT [UQ__Users__CBA1B25674A6EE67] UNIQUE NONCLUSTERED ([userid] ASC) WITH (FILLFACTOR = 90)
);

