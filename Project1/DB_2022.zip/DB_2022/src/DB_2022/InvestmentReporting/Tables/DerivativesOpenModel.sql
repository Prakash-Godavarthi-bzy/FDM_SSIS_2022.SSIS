﻿CREATE TABLE [InvestmentReporting].[DerivativesOpenModel] (
    [VersionID] INT             NULL,
    [RowID]     INT             NULL,
    [Metric]    NVARCHAR (255)  NULL,
    [ValueC]    NVARCHAR (255)  NULL,
    [ValueN]    NUMERIC (28, 4) NULL
);


GO
CREATE NONCLUSTERED INDEX [Ind_IR_DerivativesOpenModel]
    ON [InvestmentReporting].[DerivativesOpenModel]([VersionID] ASC)
    INCLUDE([RowID], [Metric], [ValueC], [ValueN]) WITH (FILLFACTOR = 90);

