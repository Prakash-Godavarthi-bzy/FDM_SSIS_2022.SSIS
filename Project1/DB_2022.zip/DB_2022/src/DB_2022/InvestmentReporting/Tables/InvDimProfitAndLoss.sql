﻿CREATE TABLE [InvestmentReporting].[InvDimProfitAndLoss] (
    [pk_ProfitAndLoss] INT            IDENTITY (1, 1) NOT NULL,
    [Port]             NVARCHAR (255) NULL,
    [Strat]            NVARCHAR (255) NULL,
    [PriceList]        NVARCHAR (255) NULL
);

