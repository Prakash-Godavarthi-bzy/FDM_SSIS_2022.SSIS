﻿CREATE TABLE [InvestmentReporting].[MetricsSequence] (
    [pkMetricID]     NVARCHAR (255) NOT NULL,
    [MetricGroup]    NVARCHAR (255) NULL,
    [MetricSequence] INT            NULL,
    [Version]        NVARCHAR (255) NULL
);

