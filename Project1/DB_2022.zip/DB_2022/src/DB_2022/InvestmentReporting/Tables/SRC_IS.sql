﻿CREATE TABLE [InvestmentReporting].[SRC_IS] (
    [VersionID] INT            NULL,
    [IS1]       NVARCHAR (255) NULL,
    [IS2]       NVARCHAR (255) NULL
);

