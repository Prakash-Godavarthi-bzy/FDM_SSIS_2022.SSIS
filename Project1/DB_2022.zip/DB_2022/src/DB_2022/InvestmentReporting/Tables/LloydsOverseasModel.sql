﻿CREATE TABLE [InvestmentReporting].[LloydsOverseasModel] (
    [VersionID] INT             NULL,
    [RowID]     INT             NULL,
    [Metric]    NVARCHAR (255)  NULL,
    [ValueC]    NVARCHAR (255)  NULL,
    [ValueN]    NUMERIC (28, 4) NULL
);


GO
CREATE NONCLUSTERED INDEX [Ind_IR_LloydsOverseasModel]
    ON [InvestmentReporting].[LloydsOverseasModel]([VersionID] ASC)
    INCLUDE([RowID], [Metric], [ValueC], [ValueN]) WITH (FILLFACTOR = 90);

