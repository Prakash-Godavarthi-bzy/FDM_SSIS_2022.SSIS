﻿CREATE TABLE [InvestmentReporting].[SRC_QNECAI] (
    [VersionID] INT            NULL,
    [QNECAI1]   NVARCHAR (255) NULL,
    [QNECAI2]   NVARCHAR (255) NULL,
    [QNECAI3]   NVARCHAR (255) NULL
);

