﻿CREATE TABLE [InvestmentReporting].[SRC_FAS] (
    [VersionID] INT            NULL,
    [FAS1]      NVARCHAR (255) NULL,
    [FAS2]      NVARCHAR (255) NULL,
    [FAS3]      NVARCHAR (255) NULL,
    [FAS4]      NVARCHAR (255) NULL,
    [FAS5]      NVARCHAR (255) NULL
);

