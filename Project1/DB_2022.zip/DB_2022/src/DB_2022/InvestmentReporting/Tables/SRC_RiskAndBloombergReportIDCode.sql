﻿CREATE TABLE [InvestmentReporting].[SRC_RiskAndBloombergReportIDCode] (
    [VersionID] INT            NULL,
    [RRIDC1]    NVARCHAR (255) NULL,
    [RRIDC2]    NVARCHAR (255) NULL
);

