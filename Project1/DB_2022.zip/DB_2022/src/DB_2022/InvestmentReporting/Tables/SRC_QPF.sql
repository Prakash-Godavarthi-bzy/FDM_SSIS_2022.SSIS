﻿CREATE TABLE [InvestmentReporting].[SRC_QPF] (
    [VersionID] INT            NULL,
    [QPF1]      NVARCHAR (255) NULL,
    [QPF2]      NVARCHAR (255) NULL,
    [QPF3]      NVARCHAR (255) NULL
);

