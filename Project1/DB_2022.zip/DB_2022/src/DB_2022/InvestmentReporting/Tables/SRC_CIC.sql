﻿CREATE TABLE [InvestmentReporting].[SRC_CIC] (
    [VersionID] INT            NULL,
    [CIC1]      NVARCHAR (255) NULL,
    [CIC2]      NVARCHAR (255) NULL,
    [CIC3]      NVARCHAR (255) NULL,
    [CIC4]      NVARCHAR (255) NULL,
    [CIC5]      NVARCHAR (255) NULL
);

