﻿CREATE TABLE [InvestmentReporting].[InvDimDerivative] (
    [pk_Derivative]                                                INT            IDENTITY (1, 1) NOT NULL,
    [Contract Name]                                                NVARCHAR (255) NULL,
    [Instrument Underlying the Derivative]                         NVARCHAR (255) NULL,
    [Use of Derivative]                                            NVARCHAR (255) NULL,
    [Buyer/Seller Position]                                        NVARCHAR (255) NULL,
    [Swap Delivered Currency]                                      NVARCHAR (255) NULL,
    [Swap Received Currency]                                       NVARCHAR (255) NULL,
    [Initial Date]                                                 NVARCHAR (255) NULL,
    [Type of code of asset or liability underlying the derivative] NVARCHAR (255) NULL,
    [Unwind Trigger of Contracts]                                  NVARCHAR (255) NULL,
    [GL Account]                                                   NVARCHAR (255) NULL,
    [Balancing GL Account]                                         NVARCHAR (255) NULL
);

