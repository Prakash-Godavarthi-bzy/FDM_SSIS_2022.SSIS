﻿CREATE TABLE [InvestmentReporting].[SRC_QIDCT] (
    [VersionID] INT            NULL,
    [QIDCT1]    NVARCHAR (255) NULL,
    [QIDCT2]    NVARCHAR (255) NULL,
    [QIDCT3]    NVARCHAR (255) NULL
);

