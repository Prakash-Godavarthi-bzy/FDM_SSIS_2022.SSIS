﻿CREATE TABLE [InvestmentReporting].[SRC_ARC] (
    [VersionID] INT            NULL,
    [ARC1]      NVARCHAR (255) NULL,
    [ARC2]      NVARCHAR (255) NULL,
    [ARC3]      NVARCHAR (255) NULL
);

