﻿CREATE TABLE [InvestmentReporting].[SRC_DBS] (
    [VersionID] INT            NULL,
    [DBS1]      NVARCHAR (255) NULL,
    [DBS2]      NVARCHAR (255) NULL
);

