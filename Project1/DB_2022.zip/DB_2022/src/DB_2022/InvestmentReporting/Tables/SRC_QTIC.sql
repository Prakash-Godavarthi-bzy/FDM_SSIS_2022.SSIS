﻿CREATE TABLE [InvestmentReporting].[SRC_QTIC] (
    [VersionID] INT            NULL,
    [QTIC1]     NVARCHAR (255) NULL,
    [QTIC2]     NVARCHAR (255) NULL,
    [QTIC3]     NVARCHAR (255) NULL
);

