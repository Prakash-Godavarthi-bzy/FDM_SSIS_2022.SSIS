﻿CREATE TABLE [InvestmentReporting].[SRC_ATC] (
    [VersionID] INT              NULL,
    [ATC0]      INT              NULL,
    [ATC1]      NVARCHAR (255)   NULL,
    [ATC2]      NVARCHAR (255)   NULL,
    [ATC3]      NUMERIC (28, 10) NULL
);

