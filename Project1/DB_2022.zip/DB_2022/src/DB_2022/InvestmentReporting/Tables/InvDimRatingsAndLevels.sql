﻿CREATE TABLE [InvestmentReporting].[InvDimRatingsAndLevels] (
    [pk_Rating]                        INT            IDENTITY (1, 1) NOT NULL,
    [FAS Level]                        NVARCHAR (255) NULL,
    [Credit Quality Step]              NVARCHAR (255) NULL,
    [S & P Rating]                     NVARCHAR (255) NULL,
    [GlobeOp Rating]                   NVARCHAR (255) NULL,
    [S&P and Globe Op Rating Combined] NVARCHAR (255) NULL,
    [Rating]                           NVARCHAR (255) NULL,
    [QMA Group Rating Tier]            NVARCHAR (255) NULL,
    [SII External Rating]              NVARCHAR (255) NULL,
    [Nominated ECAI Rating Agency]     NVARCHAR (255) NULL,
    [Internal Rating]                  NVARCHAR (255) NULL
);

