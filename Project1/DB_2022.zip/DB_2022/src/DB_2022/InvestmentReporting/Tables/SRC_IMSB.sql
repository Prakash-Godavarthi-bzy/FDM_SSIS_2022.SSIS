﻿CREATE TABLE [InvestmentReporting].[SRC_IMSB] (
    [VersionID] INT            NULL,
    [IMSB1]     NVARCHAR (255) NULL,
    [IMSB2]     NVARCHAR (255) NULL
);

