﻿CREATE TABLE [InvestmentReporting].[SRC_BCD] (
    [VersionID] INT            NULL,
    [BCD1]      NVARCHAR (255) NULL,
    [BCD2]      NVARCHAR (255) NULL
);

