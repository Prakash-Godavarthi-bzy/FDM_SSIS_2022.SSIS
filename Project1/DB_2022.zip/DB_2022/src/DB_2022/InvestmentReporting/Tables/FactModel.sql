﻿CREATE TABLE [InvestmentReporting].[FactModel] (
    [fk_ModelID]          INT              NULL,
    [RowID]               INT              NULL,
    [fk_AccountingPeriod] INT              NULL,
    [fk_Account]          INT              NULL,
    [fk_Entity]           INT              NULL,
    [fk_Maturity]         INT              NULL,
    [fk_Issuer]           INT              NULL,
    [fk_Investment]       INT              NULL,
    [fk_Rating]           INT              NULL,
    [fk_LloydsReporting]  INT              NULL,
    [fk_TGKReporting]     INT              NULL,
    [fk_Currency]         NVARCHAR (5)     NULL,
    [fk_HoldingCurrency]  NVARCHAR (5)     NULL,
    [fk_Custodian]        INT              NULL,
    [fk_ProfitAndLoss]    INT              NULL,
    [fk_Derivative]       INT              NULL,
    [Value]               DECIMAL (28, 10) NULL
);

