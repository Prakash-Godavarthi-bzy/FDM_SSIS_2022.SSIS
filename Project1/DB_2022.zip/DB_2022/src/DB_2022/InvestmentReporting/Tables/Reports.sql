﻿CREATE TABLE [InvestmentReporting].[Reports] (
    [ReportName]     NVARCHAR (255) NULL,
    [MetricGroup]    NVARCHAR (255) NULL,
    [InputFeedTable] NVARCHAR (255) NULL,
    [OutputTable]    NVARCHAR (255) NULL
);

