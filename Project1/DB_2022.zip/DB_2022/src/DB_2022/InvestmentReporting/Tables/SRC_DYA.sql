﻿CREATE TABLE [InvestmentReporting].[SRC_DYA] (
    [VersionID] INT             NULL,
    [DYA1]      NVARCHAR (255)  NULL,
    [DYA2]      NUMERIC (28, 3) NULL,
    [DYA3]      NUMERIC (28, 3) NULL,
    [DYA4]      NUMERIC (28, 3) NULL
);

