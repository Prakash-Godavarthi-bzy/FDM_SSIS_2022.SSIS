﻿CREATE TABLE [InvestmentReporting].[SRC_DDC] (
    [VersionID] INT            NULL,
    [DDC1]      NVARCHAR (255) NULL,
    [DDC2]      NVARCHAR (255) NULL,
    [DDC3]      NVARCHAR (255) NULL,
    [DDC4]      NVARCHAR (255) NULL,
    [DDC5]      NVARCHAR (255) NULL,
    [DDC6]      NVARCHAR (255) NULL,
    [DDC7]      NVARCHAR (255) NULL,
    [DDC8]      NVARCHAR (255) NULL,
    [DDC9]      NVARCHAR (255) NULL,
    [DDC10]     NVARCHAR (255) NULL,
    [DDC11]     NVARCHAR (255) NULL
);

