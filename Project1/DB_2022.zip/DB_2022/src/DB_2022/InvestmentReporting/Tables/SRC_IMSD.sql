﻿CREATE TABLE [InvestmentReporting].[SRC_IMSD] (
    [VersionID] INT            NULL,
    [IMSD1]     NVARCHAR (255) NULL,
    [IMSD2]     NVARCHAR (255) NULL
);

