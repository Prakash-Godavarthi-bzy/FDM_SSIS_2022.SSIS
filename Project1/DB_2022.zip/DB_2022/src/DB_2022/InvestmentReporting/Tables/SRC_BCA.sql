﻿CREATE TABLE [InvestmentReporting].[SRC_BCA] (
    [VersionID] INT            NULL,
    [BCA1]      NVARCHAR (255) NULL,
    [BCA2]      NVARCHAR (255) NULL,
    [BCA3]      NVARCHAR (255) NULL,
    [BCA4]      NVARCHAR (255) NULL,
    [BCA5]      NVARCHAR (255) NULL
);

