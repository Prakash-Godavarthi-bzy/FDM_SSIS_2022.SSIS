﻿CREATE TABLE [InvestmentReporting].[FeedDetails] (
    [pkFeedVersionID]    INT            IDENTITY (1, 1) NOT NULL,
    [fkFeedID]           INT            NULL,
    [VersionDesc]        NVARCHAR (255) NULL,
    [fkUserID]           NVARCHAR (255) NULL,
    [fkAccountingPeriod] INT            NULL,
    [ImportDate]         DATETIME       NULL,
    [ParentID]           INT            NULL
);

