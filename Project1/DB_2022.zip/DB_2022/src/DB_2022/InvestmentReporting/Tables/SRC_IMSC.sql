﻿CREATE TABLE [InvestmentReporting].[SRC_IMSC] (
    [VersionID] INT            NULL,
    [IMSC1]     NVARCHAR (255) NULL,
    [IMSC2]     NVARCHAR (255) NULL,
    [IMSC3]     NVARCHAR (255) NULL,
    [IMSC4]     NVARCHAR (255) NULL
);

