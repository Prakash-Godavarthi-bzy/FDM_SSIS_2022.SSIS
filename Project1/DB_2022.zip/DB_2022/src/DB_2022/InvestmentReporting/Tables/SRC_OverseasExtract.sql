﻿CREATE TABLE [InvestmentReporting].[SRC_OverseasExtract] (
    [VersionID] INT             NULL,
    [RowID]     INT             NULL,
    [OE1]       NVARCHAR (255)  NULL,
    [OE2]       NVARCHAR (255)  NULL,
    [OE3]       NVARCHAR (255)  NULL,
    [OE4]       NVARCHAR (255)  NULL,
    [OE5]       NUMERIC (28, 3) NULL
);

