﻿CREATE TABLE [InvestmentReporting].[SRC_F234C] (
    [VersionID] INT            NULL,
    [F234C1]    NVARCHAR (255) NULL,
    [F234C2]    NVARCHAR (255) NULL
);

