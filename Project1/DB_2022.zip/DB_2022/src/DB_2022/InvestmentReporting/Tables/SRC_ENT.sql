﻿CREATE TABLE [InvestmentReporting].[SRC_ENT] (
    [VersionID] INT            NULL,
    [ENT1]      NVARCHAR (255) NULL,
    [ENT2]      NVARCHAR (255) NULL,
    [ENT3]      NVARCHAR (255) NULL
);

