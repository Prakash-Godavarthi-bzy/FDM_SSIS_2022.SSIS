﻿CREATE TABLE [InvestmentReporting].[ReferenceAuditConfig] (
    [ListName]        NVARCHAR (255) NULL,
    [ListDescription] NVARCHAR (255) NULL,
    [ListViewURL]     NVARCHAR (MAX) NULL
);

