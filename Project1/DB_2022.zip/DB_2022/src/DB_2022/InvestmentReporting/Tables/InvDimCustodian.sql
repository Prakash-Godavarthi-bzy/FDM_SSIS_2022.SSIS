﻿CREATE TABLE [InvestmentReporting].[InvDimCustodian] (
    [pk_Custodian]       INT            IDENTITY (1, 1) NOT NULL,
    [Custodian]          NVARCHAR (255) NULL,
    [Custodian LEI]      NVARCHAR (255) NULL,
    [Country of Custody] NVARCHAR (255) NULL
);

