﻿CREATE TABLE [InvestmentReporting].[ModelConfig] (
    [pkModelID]          INT            IDENTITY (1, 1) NOT NULL,
    [VersionDesc]        NVARCHAR (255) NULL,
    [fkUserID]           NVARCHAR (255) NULL,
    [updated_userid]     NVARCHAR (255) NULL,
    [fkAccountingPeriod] INT            NULL,
    [MetricGroup]        NVARCHAR (255) NULL,
    [ModelType]          NVARCHAR (255) NULL,
    [CreatedDate]        DATETIME       NULL,
    [UpdatedDate]        DATETIME       NULL,
    [Status]             NVARCHAR (255) NULL,
    [JrStatus]           NVARCHAR (255) NULL,
    [Description]        NVARCHAR (255) NULL
);

