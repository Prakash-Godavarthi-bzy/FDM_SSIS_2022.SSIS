﻿CREATE TABLE [InvestmentReporting].[SRC_CSTDL] (
    [VersionID] INT            NULL,
    [CSTDL1]    NVARCHAR (255) NULL,
    [CSTDL2]    NVARCHAR (255) NULL,
    [CSTDL3]    NVARCHAR (255) NULL,
    [CSTDL4]    NVARCHAR (255) NULL,
    [CSTDL5]    NVARCHAR (255) NULL,
    [CSTDL6]    NVARCHAR (255) NULL
);

