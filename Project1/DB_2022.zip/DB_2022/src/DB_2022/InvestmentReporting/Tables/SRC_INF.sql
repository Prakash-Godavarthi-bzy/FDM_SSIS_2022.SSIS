﻿CREATE TABLE [InvestmentReporting].[SRC_INF] (
    [VersionID] INT            NULL,
    [INF1]      NVARCHAR (255) NULL,
    [INF2]      NVARCHAR (255) NULL,
    [INF3]      NVARCHAR (255) NULL,
    [INF4]      NVARCHAR (255) NULL,
    [INF5]      NVARCHAR (255) NULL,
    [INF6]      NVARCHAR (255) NULL,
    [INF7]      NVARCHAR (255) NULL,
    [INF8]      NVARCHAR (255) NULL,
    [INF9]      NVARCHAR (255) NULL,
    [INF10]     NVARCHAR (255) NULL,
    [INF11]     NVARCHAR (255) NULL
);

