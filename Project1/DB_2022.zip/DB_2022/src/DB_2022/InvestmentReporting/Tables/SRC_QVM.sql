﻿CREATE TABLE [InvestmentReporting].[SRC_QVM] (
    [VersionID] INT            NULL,
    [QVM1]      NVARCHAR (255) NULL,
    [QVM2]      NVARCHAR (255) NULL,
    [QVM3]      NVARCHAR (255) NULL
);

