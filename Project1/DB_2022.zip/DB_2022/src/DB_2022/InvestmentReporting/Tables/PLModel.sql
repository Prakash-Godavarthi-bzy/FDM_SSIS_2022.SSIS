﻿CREATE TABLE [InvestmentReporting].[PLModel] (
    [VersionID] INT             NULL,
    [RowID]     INT             NULL,
    [Metric]    NVARCHAR (255)  NULL,
    [ValueC]    NVARCHAR (255)  NULL,
    [ValueN]    NUMERIC (28, 4) NULL
);


GO
CREATE NONCLUSTERED INDEX [Ind_IR_PLModel]
    ON [InvestmentReporting].[PLModel]([VersionID] ASC)
    INCLUDE([RowID], [Metric], [ValueC], [ValueN]) WITH (FILLFACTOR = 90);

