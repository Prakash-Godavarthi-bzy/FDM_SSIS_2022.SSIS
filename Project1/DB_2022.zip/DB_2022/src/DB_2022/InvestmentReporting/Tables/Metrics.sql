﻿CREATE TABLE [InvestmentReporting].[Metrics] (
    [pkMetricID]             NVARCHAR (255)  NOT NULL,
    [fkFeedID]               INT             NULL,
    [MetricDesc]             NVARCHAR (255)  NULL,
    [MetricSort]             INT             NULL,
    [MetricType]             NVARCHAR (255)  NULL,
    [MetricGroup]            NVARCHAR (255)  NULL,
    [MetricGroupDescription] NVARCHAR (255)  NULL,
    [MetricCalculation]      NVARCHAR (1000) NULL,
    [MetricReference]        NVARCHAR (255)  NULL,
    [DataType]               NVARCHAR (255)  NULL,
    [UniqueValue]            NVARCHAR (255)  NULL
);


GO
CREATE NONCLUSTERED INDEX [Indx_InvestmentReporting_Metrics]
    ON [InvestmentReporting].[Metrics]([MetricGroup] ASC, [MetricSort] ASC) WITH (FILLFACTOR = 90);

