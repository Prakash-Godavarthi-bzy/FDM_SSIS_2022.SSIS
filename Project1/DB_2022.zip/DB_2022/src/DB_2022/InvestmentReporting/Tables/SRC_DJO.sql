﻿CREATE TABLE [InvestmentReporting].[SRC_DJO] (
    [VersionID] INT            NULL,
    [DJO1]      NVARCHAR (255) NULL,
    [DJO2]      NVARCHAR (255) NULL,
    [DJO3]      NVARCHAR (255) NULL,
    [DJO4]      NVARCHAR (255) NULL,
    [DJO5]      NVARCHAR (255) NULL,
    [DJO6]      NVARCHAR (255) NULL
);

