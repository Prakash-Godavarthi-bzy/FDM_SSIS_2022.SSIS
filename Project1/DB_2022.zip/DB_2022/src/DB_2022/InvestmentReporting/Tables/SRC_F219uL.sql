﻿CREATE TABLE [InvestmentReporting].[SRC_F219uL] (
    [VersionID] INT            NULL,
    [F219uL1]   NVARCHAR (255) NULL,
    [F219uL2]   NVARCHAR (255) NULL,
    [F219uL3]   NVARCHAR (255) NULL
);

