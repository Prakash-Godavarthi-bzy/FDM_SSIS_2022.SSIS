﻿CREATE TABLE [InvestmentReporting].[CubeConfig] (
    [ReportingColumn] NVARCHAR (255) NULL,
    [ReportingGroup]  NVARCHAR (255) NULL,
    [MetricGroup]     NVARCHAR (255) NULL,
    [Metric]          NVARCHAR (255) NULL
);

