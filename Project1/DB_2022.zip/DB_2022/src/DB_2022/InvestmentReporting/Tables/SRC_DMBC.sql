﻿CREATE TABLE [InvestmentReporting].[SRC_DMBC] (
    [VersionID] INT            NULL,
    [DMBC1]     NVARCHAR (255) NULL,
    [DMBC2]     NVARCHAR (255) NULL,
    [DMBC3]     NVARCHAR (255) NULL,
    [DMBC4]     NVARCHAR (255) NULL
);

