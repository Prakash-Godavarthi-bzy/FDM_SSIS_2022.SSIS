﻿CREATE TABLE [InvestmentReporting].[ModelFeedMapping] (
    [MetricGroup] NVARCHAR (255) NULL,
    [Feed]        NVARCHAR (255) NULL
);

