﻿CREATE TABLE [InvestmentReporting].[Journals] (
    [MetricGroup]            NVARCHAR (255) NULL,
    [ProcessCode]            NVARCHAR (255) NULL,
    [Type]                   NVARCHAR (255) NULL,
    [Entity]                 NVARCHAR (255) NULL,
    [Currency]               NVARCHAR (255) NULL,
    [AccountColumn]          NVARCHAR (255) NULL,
    [BalancingAccountColumn] NVARCHAR (255) NULL,
    [Account]                NVARCHAR (255) NULL,
    [Value Column]           NVARCHAR (255) NULL,
    [Multiplier]             INT            NULL
);

