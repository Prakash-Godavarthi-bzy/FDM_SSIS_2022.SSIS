﻿CREATE TABLE [InvestmentReporting].[ModelFeedConfig] (
    [fkModelID]       INT NULL,
    [fkFeedVersionID] INT NULL
);

