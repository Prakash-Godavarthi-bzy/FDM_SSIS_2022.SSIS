﻿CREATE TABLE [InvestmentReporting].[SRC_F212uE] (
    [VersionID] INT            NULL,
    [F212uE1]   NVARCHAR (255) NULL,
    [F212uE2]   NVARCHAR (255) NULL,
    [F212uE3]   NVARCHAR (255) NULL
);

