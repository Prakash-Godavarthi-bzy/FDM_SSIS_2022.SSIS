﻿CREATE TABLE [InvestmentReporting].[FeedConfig] (
    [pkFeedID] INT            IDENTITY (1, 1) NOT NULL,
    [FeedDesc] NVARCHAR (255) NULL,
    [FeedType] NVARCHAR (50)  NULL
);

