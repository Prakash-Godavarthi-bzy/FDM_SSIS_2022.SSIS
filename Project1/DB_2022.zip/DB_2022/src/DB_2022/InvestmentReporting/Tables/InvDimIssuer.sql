﻿CREATE TABLE [InvestmentReporting].[InvDimIssuer] (
    [pk_Issuer]              INT            IDENTITY (1, 1) NOT NULL,
    [Issuer Name]            NVARCHAR (255) NULL,
    [Issuer Sector]          NVARCHAR (255) NULL,
    [Issuer Country]         NVARCHAR (255) NULL,
    [Risk Issuer Industry]   NVARCHAR (255) NULL,
    [Risk Industry Sector]   NVARCHAR (255) NULL,
    [Risk Industry Group]    NVARCHAR (255) NULL,
    [Risk Industry Subgroup] NVARCHAR (255) NULL,
    [Issuer Code]            NVARCHAR (255) NULL,
    [Issuer Code Type]       NVARCHAR (255) NULL
);

