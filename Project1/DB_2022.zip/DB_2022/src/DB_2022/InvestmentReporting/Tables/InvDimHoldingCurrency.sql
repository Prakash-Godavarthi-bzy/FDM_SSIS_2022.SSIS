﻿CREATE TABLE [InvestmentReporting].[InvDimHoldingCurrency] (
    [HoldingCurrency] NVARCHAR (255) NULL
);

