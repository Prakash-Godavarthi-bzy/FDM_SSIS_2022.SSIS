﻿CREATE TABLE [InvestmentReporting].[InvDimInvestment] (
    [pk_Investment]     INT            IDENTITY (1, 1) NOT NULL,
    [Investment ID]     NVARCHAR (255) NULL,
    [ID Code type]      NVARCHAR (255) NULL,
    [Item Title]        NVARCHAR (255) NULL,
    [County of Custody] NVARCHAR (255) NULL,
    [Portfolio name]    NVARCHAR (255) NULL,
    [Asset Type]        NVARCHAR (255) NULL,
    [Pay Rate Type]     NVARCHAR (255) NULL,
    [Bond Category]     NVARCHAR (255) NULL,
    [Govt_Gtd]          NVARCHAR (255) NULL,
    [CIC]               NVARCHAR (255) NULL,
    [CIC ##]            NVARCHAR (255) NULL,
    [CIC####]           NVARCHAR (255) NULL,
    [IMS Asset Split]   NVARCHAR (255) NULL,
    [Issue Type]        NVARCHAR (255) NULL
);

