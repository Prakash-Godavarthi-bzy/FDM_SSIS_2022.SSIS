﻿CREATE TABLE [InvestmentReporting].[SRC_CashExtract] (
    [VersionID] INT             NULL,
    [RowID]     INT             NULL,
    [CE1]       NVARCHAR (255)  NULL,
    [CE2]       NVARCHAR (255)  NULL,
    [CE3]       NVARCHAR (255)  NULL,
    [CE4]       NVARCHAR (255)  NULL,
    [CE5]       NUMERIC (28, 3) NULL
);

