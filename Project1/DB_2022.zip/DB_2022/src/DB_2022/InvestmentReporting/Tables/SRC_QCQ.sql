﻿CREATE TABLE [InvestmentReporting].[SRC_QCQ] (
    [VersionID] INT            NULL,
    [QCQ1]      NVARCHAR (255) NULL,
    [QCQ2]      NVARCHAR (255) NULL,
    [QCQ3]      NVARCHAR (255) NULL
);

