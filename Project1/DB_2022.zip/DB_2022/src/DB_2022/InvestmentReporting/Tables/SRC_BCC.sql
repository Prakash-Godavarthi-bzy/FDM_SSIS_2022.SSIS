﻿CREATE TABLE [InvestmentReporting].[SRC_BCC] (
    [VersionID] INT            NULL,
    [BCC1]      NVARCHAR (255) NULL,
    [BCC2]      NVARCHAR (255) NULL
);

