﻿CREATE TABLE [InvestmentReporting].[SRC_DUOD] (
    [VersionID] INT            NULL,
    [DUOD1]     NVARCHAR (255) NULL,
    [DUOD2]     NVARCHAR (255) NULL
);

