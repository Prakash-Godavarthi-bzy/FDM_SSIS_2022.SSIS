﻿CREATE TABLE [InvestmentReporting].[SRC_WFCTP] (
    [VersionID] INT            NULL,
    [WFCTP1]    NVARCHAR (255) NULL,
    [WFCTP2]    NVARCHAR (255) NULL,
    [WFCTP3]    NVARCHAR (255) NULL,
    [WFCTP4]    NVARCHAR (255) NULL,
    [WFCTP5]    NVARCHAR (255) NULL,
    [WFCTP6]    NVARCHAR (255) NULL
);

