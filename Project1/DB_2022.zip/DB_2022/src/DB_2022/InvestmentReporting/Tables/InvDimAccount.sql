﻿CREATE TABLE [InvestmentReporting].[InvDimAccount] (
    [pk_Account]  INT            IDENTITY (1, 1) NOT NULL,
    [Account]     NVARCHAR (255) NULL,
    [RIESCOSplit] NVARCHAR (255) NULL
);

