﻿CREATE TABLE [InvestmentReporting].[SRC_QCTC] (
    [VersionID] INT            NULL,
    [QCTC1]     NVARCHAR (255) NULL,
    [QCTC2]     NVARCHAR (255) NULL
);

