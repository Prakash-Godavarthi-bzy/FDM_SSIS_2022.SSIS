﻿CREATE TABLE [InvestmentReporting].[SRC_DPR] (
    [VersionID] INT            NULL,
    [DPR1]      NVARCHAR (255) NULL,
    [DPR2]      NVARCHAR (255) NULL,
    [DPR3]      NVARCHAR (255) NULL
);

