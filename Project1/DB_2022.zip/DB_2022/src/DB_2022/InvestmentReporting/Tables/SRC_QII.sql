﻿CREATE TABLE [InvestmentReporting].[SRC_QII] (
    [VersionID] INT            NULL,
    [QII1]      NVARCHAR (255) NULL,
    [QII2]      NVARCHAR (255) NULL,
    [QII3]      NVARCHAR (255) NULL
);

