﻿CREATE TABLE [InvestmentReporting].[SRC_IMSA] (
    [VersionID] INT            NULL,
    [IMSA1]     NVARCHAR (255) NULL,
    [IMSA2]     NVARCHAR (255) NULL,
    [IMSA3]     NVARCHAR (255) NULL,
    [IMSA4]     NVARCHAR (255) NULL
);

