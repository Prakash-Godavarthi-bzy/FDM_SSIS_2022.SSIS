﻿CREATE TABLE [InvestmentReporting].[SRC_BloombergRating] (
    [VersionID] INT            NULL,
    [BR1]       NVARCHAR (255) NULL,
    [BR2]       NVARCHAR (255) NULL,
    [BR3]       NVARCHAR (255) NULL
);

