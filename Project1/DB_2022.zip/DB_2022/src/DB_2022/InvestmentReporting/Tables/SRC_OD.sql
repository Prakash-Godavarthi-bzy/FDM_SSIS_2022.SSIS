﻿CREATE TABLE [InvestmentReporting].[SRC_OD] (
    [VersionID] INT            NULL,
    [OD1]       NVARCHAR (255) NULL,
    [OD2]       NVARCHAR (255) NULL,
    [OD3]       NVARCHAR (255) NULL,
    [OD4]       NVARCHAR (255) NULL,
    [OD5]       NVARCHAR (255) NULL,
    [OD6]       NVARCHAR (255) NULL,
    [OD7]       NVARCHAR (255) NULL,
    [OD8]       NVARCHAR (255) NULL,
    [OD9]       NVARCHAR (255) NULL,
    [OD10]      NVARCHAR (255) NULL,
    [OD11]      NVARCHAR (255) NULL
);

