﻿CREATE TABLE [InvestmentReporting].[SRC_QHRU] (
    [VersionID] INT            NULL,
    [QHRU1]     NVARCHAR (255) NULL,
    [QHRU2]     NVARCHAR (255) NULL,
    [QHRU3]     NVARCHAR (255) NULL
);

