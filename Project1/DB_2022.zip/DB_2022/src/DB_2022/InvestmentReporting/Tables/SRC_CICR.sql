﻿CREATE TABLE [InvestmentReporting].[SRC_CICR] (
    [VersionID] INT            NULL,
    [CICR1]     NVARCHAR (255) NULL,
    [CICR2]     NVARCHAR (255) NULL,
    [CICR3]     NVARCHAR (255) NULL,
    [CICR4]     NVARCHAR (255) NULL,
    [CICR5]     NVARCHAR (255) NULL,
    [CICR6]     NVARCHAR (255) NULL,
    [CICR7]     NVARCHAR (255) NULL,
    [CICR8]     NVARCHAR (255) NULL,
    [CICR9]     NVARCHAR (255) NULL,
    [CICR10]    NVARCHAR (255) NULL,
    [CICR11]    NVARCHAR (255) NULL
);

