﻿CREATE TABLE [InvestmentReporting].[SRC_QMA] (
    [VersionID] INT            NULL,
    [QMA1]      NVARCHAR (255) NULL,
    [QMA2]      NVARCHAR (255) NULL,
    [QMA3]      NVARCHAR (255) NULL,
    [QMA4]      NVARCHAR (255) NULL,
    [QMA5]      NVARCHAR (255) NULL,
    [QMA6]      NVARCHAR (255) NULL,
    [QMA7]      NVARCHAR (255) NULL,
    [QMA8]      NVARCHAR (255) NULL,
    [QMA9]      NVARCHAR (255) NULL,
    [QMA10]     NVARCHAR (255) NULL,
    [QMA11]     NVARCHAR (255) NULL,
    [QMA12]     NVARCHAR (255) NULL,
    [QMA13]     NVARCHAR (255) NULL,
    [QMA14]     NVARCHAR (255) NULL
);

