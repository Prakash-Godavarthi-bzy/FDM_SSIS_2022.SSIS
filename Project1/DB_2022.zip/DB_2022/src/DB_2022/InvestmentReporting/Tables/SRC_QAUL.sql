﻿CREATE TABLE [InvestmentReporting].[SRC_QAUL] (
    [VersionID] INT            NULL,
    [QAUL1]     NVARCHAR (255) NULL,
    [QAUL2]     NVARCHAR (255) NULL,
    [QAUL3]     NVARCHAR (255) NULL
);

