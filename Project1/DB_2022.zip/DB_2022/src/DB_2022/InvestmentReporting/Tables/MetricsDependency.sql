﻿CREATE TABLE [InvestmentReporting].[MetricsDependency] (
    [pkMetricID]       NVARCHAR (255) NOT NULL,
    [MetricGroup]      NVARCHAR (255) NULL,
    [MetricDependency] NVARCHAR (255) NULL,
    [Version]          NVARCHAR (255) NULL
);

