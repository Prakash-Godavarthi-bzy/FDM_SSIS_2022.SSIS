﻿CREATE TABLE [InvestmentReporting].[SRC_PLR] (
    [VersionID] INT            NULL,
    [PLR1]      NVARCHAR (255) NULL,
    [PLR2]      NVARCHAR (255) NULL,
    [PLR3]      NVARCHAR (255) NULL,
    [PLR4]      NVARCHAR (255) NULL,
    [PLR5]      NVARCHAR (255) NULL
);

