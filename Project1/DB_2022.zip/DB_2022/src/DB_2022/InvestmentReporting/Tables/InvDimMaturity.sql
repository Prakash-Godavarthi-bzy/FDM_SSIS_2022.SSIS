﻿CREATE TABLE [InvestmentReporting].[InvDimMaturity] (
    [pk_Maturity]     INT            IDENTITY (1, 1) NOT NULL,
    [Maturity Bucket] NVARCHAR (255) NULL,
    [Duration Bucket] NVARCHAR (255) NULL,
    [Mod Duration]    NVARCHAR (255) NULL,
    [Maturity Date]   NVARCHAR (255) NULL
);

