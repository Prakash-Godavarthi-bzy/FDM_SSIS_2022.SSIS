﻿CREATE TABLE [InvestmentReporting].[SRC_F201L] (
    [VersionID] INT            NULL,
    [F201L1]    NVARCHAR (255) NULL,
    [F201L2]    NVARCHAR (255) NULL,
    [F201L3]    NVARCHAR (255) NULL,
    [F201L4]    NVARCHAR (255) NULL,
    [F201L5]    NVARCHAR (255) NULL,
    [F201L6]    NVARCHAR (255) NULL
);

