﻿CREATE TABLE [InvestmentReporting].[SRC_F212uL] (
    [VersionID] INT            NULL,
    [F212uL1]   NVARCHAR (255) NULL,
    [F212uL2]   NVARCHAR (255) NULL,
    [F212uL3]   NVARCHAR (255) NULL,
    [F212uL4]   NVARCHAR (255) NULL,
    [F212uL5]   NVARCHAR (255) NULL,
    [F212uL6]   NVARCHAR (255) NULL
);

