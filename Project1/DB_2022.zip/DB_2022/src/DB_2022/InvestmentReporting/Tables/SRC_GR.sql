﻿CREATE TABLE [InvestmentReporting].[SRC_GR] (
    [VersionID] INT            NULL,
    [GR1]       NVARCHAR (255) NULL,
    [GR2]       NVARCHAR (255) NULL,
    [GR3]       NVARCHAR (255) NULL
);

