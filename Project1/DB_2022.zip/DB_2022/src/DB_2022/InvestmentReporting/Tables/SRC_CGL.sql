﻿CREATE TABLE [InvestmentReporting].[SRC_CGL] (
    [VersionID] INT            NULL,
    [CGL1]      NVARCHAR (255) NULL,
    [CGL2]      NVARCHAR (255) NULL
);

