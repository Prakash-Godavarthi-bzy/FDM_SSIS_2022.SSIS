﻿CREATE TABLE [InvestmentReporting].[SRC_BCB] (
    [VersionID] INT            NULL,
    [BCB1]      NVARCHAR (255) NULL,
    [BCB2]      NVARCHAR (255) NULL
);

