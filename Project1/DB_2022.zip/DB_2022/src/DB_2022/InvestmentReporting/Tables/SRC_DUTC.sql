﻿CREATE TABLE [InvestmentReporting].[SRC_DUTC] (
    [VersionID] INT            NULL,
    [DUTC1]     NVARCHAR (255) NULL,
    [DUTC2]     NVARCHAR (255) NULL
);

