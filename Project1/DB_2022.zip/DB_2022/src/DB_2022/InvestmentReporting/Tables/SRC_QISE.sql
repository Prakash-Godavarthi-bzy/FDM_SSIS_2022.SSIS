﻿CREATE TABLE [InvestmentReporting].[SRC_QISE] (
    [VersionID] INT            NULL,
    [QISE1]     NVARCHAR (255) NULL,
    [QISE2]     NVARCHAR (255) NULL,
    [QISE3]     NVARCHAR (255) NULL
);

