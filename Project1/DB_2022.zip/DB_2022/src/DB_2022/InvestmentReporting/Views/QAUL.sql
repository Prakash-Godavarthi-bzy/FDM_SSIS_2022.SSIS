﻿

CREATE VIEW [InvestmentReporting].[QAUL]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [QAUL1] ASC) AS RowID
			, [QAUL1]
			, [QAUL2]
			, [QAUL3]
			, [QAUL3] AS [DEF_QAUL]
	FROM [InvestmentReporting].[SRC_QAUL] A


	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[QAUL1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [QAUL1] ASC) AS RowID, [QAUL1] FROM [InvestmentReporting].[SRC_QAUL]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [QAUL1]
) B ON A.[RowID] = B.[RowID]
