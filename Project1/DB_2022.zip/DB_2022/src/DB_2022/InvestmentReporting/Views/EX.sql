﻿


CREATE VIEW [InvestmentReporting].[EX]
AS
SELECT   [fk_TransactionCurrency] AS [Currency], [USD] AS [EXUSD],[GBP] AS [EXGBP]
FROM
(	SELECT [fk_TransactionCurrency],DRC.[ReportingCurrencyCode],F.[FXRate]
FROM [FactFXRate] F 
INNER JOIN [DimRateScenario] DS
ON F.[fk_RateScenario] = DS.[pk_RateScenario]
INNER JOIN [DimFXRate] DR
ON F.[fk_FXRate] = DR.[pk_FXRate]
INNER JOIN [DimReportingCurrency] DRC
ON DRC.[pk_ReportingCurrency] = F.[fk_ReportingCurrency]
WHERE [fk_AccountingPeriod] = (SELECT [fkAccountingPeriod] FROM [InvestmentReporting].[ModelConfig] WHERE [Status] = 'Running')
AND DS.[RateName] = 'Agresso' AND DRC.[ReportingCurrencyCode] IN ('USD','GBP') AND DR.[FXRateName] = 'SPOT'
) FX
PIVOT
(
       SUM(FXRate)
       FOR [ReportingCurrencyCode] IN ([GBP],[USD])
) AS P
