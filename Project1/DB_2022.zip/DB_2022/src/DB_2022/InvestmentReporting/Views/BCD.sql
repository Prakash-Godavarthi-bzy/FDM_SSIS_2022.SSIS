﻿

CREATE VIEW [InvestmentReporting].[BCD]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [BCD1] ASC) AS RowID
			, [BCD1]
			, [BCD2]
	FROM [InvestmentReporting].[SRC_BCD] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[BCD1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [BCD1] ASC) AS RowID, [BCD1] FROM [InvestmentReporting].[SRC_BCD]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [BCD1]
) B ON A.[RowID] = B.[RowID]
