﻿

CREATE VIEW [InvestmentReporting].[QIDCT]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [QIDCT1] ASC) AS RowID
			, [QIDCT1]
			, [QIDCT2]
			, [QIDCT3]
	FROM [InvestmentReporting].[SRC_QIDCT] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[QIDCT1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [QIDCT1] ASC) AS RowID, [QIDCT1] FROM [InvestmentReporting].[SRC_QIDCT]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [QIDCT1]
) B ON A.[RowID] = B.[RowID]
