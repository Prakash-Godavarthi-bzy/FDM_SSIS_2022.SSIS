﻿
CREATE VIEW [InvestmentReporting].[BCA]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [BCA1] ASC) AS RowID
			, [BCA1]
			, [BCA2]
			, [BCA3]
			, [BCA4]
			, [BCA5]
	FROM [InvestmentReporting].[SRC_BCA] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[BCA1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [BCA1] ASC) AS RowID, [BCA1] FROM [InvestmentReporting].[SRC_BCA]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [BCA1]
) B ON A.[RowID] = B.[RowID]
