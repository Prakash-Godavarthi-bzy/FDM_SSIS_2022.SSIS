﻿


CREATE VIEW [InvestmentReporting].[QTIC]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [QTIC1] ASC) AS RowID
			, [QTIC1]
			, [QTIC2]
			, [QTIC3]
			, [QTIC3] AS [DEF_QTIC]
	FROM [InvestmentReporting].[SRC_QTIC] A


	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[QTIC1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [QTIC1] ASC) AS RowID, [QTIC1] FROM [InvestmentReporting].[SRC_QTIC]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [QTIC1]
) B ON A.[RowID] = B.[RowID]
