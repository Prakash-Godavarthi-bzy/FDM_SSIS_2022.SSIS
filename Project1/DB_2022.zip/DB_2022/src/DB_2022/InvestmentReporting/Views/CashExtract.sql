﻿

CREATE VIEW [InvestmentReporting].[CashExtract]
AS
SELECT 
	  F.[VersionID]
	, CASE WHEN FD.[ParentID] = FD.[pkFeedVersionID] THEN F.[RowID] ELSE F.[RowID] + 100000 END AS [RowID]
	, F.[CE1]
	, F.[CE2]
	, F.[CE3]
	, F.[CE4]
	, F.[CE5]
FROM [InvestmentReporting].[SRC_CashExtract] F
INNER JOIN [InvestmentReporting].[FeedDetails] FD ON FD.[pkFeedVersionID] = F.[VersionID]
AND FD.[ParentID] IN  (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
