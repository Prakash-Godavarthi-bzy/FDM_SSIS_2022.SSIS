﻿
CREATE VIEW [InvestmentReporting].[FAS]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [FAS5] ASC) AS RowID
			, [FAS1]
			, [FAS2]
			, [FAS3]
			, [FAS4]
			, [FAS5]
	FROM [InvestmentReporting].[SRC_FAS] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[FAS5] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [FAS5] ASC) AS RowID, [FAS5] FROM [InvestmentReporting].[SRC_FAS]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [FAS5]
) B ON A.[RowID] = B.[RowID]
