﻿


CREATE VIEW [InvestmentReporting].[CIC]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [CIC3] ASC) AS RowID
			, [CIC3]
			, [CIC4]
			, [CIC5]
	FROM [InvestmentReporting].[SRC_CIC] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[CIC3] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [CIC3] ASC) AS RowID, [CIC3] FROM [InvestmentReporting].[SRC_CIC]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [CIC3]
) B ON A.[RowID] = B.[RowID]
