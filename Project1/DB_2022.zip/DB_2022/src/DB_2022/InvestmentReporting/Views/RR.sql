﻿


CREATE VIEW [InvestmentReporting].[RR]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [RR26] ASC) AS RowID
			, [RR1]
			, [RR2]
			, [RR3]
			, [RR4]
			, [RR5]
			, [RR6]
			, [RR7]
			, [RR8]
			, [RR9]
			, [RR10]
			, [RR11]
			, [RR12]
			, [RR13]
			, [RR14]
			, [RR15]
			, [RR16]
			, [RR17]
			, [RR18]
			, [RR19]
			, [RR20]
			, [RR21]
			, [RR22]
			, [RR23]
			, [RR24]
			, [RR25]
			, [RR26]
			, [RR27]
	FROM [InvestmentReporting].[SRC_RiskAndBloombergReport] A


	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[RR26] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [RR26] ASC) AS RowID, [RR26] FROM [InvestmentReporting].[SRC_RiskAndBloombergReport]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [RR26]
) B ON A.[RowID] = B.[RowID]
