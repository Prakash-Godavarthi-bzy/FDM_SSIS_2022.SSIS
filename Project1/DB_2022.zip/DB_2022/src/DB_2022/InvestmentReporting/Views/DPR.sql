﻿


CREATE VIEW [InvestmentReporting].[DPR]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [DPR1] ASC) AS RowID
			, [DPR1]
			, [DPR2]
			, [DPR3]
	FROM [InvestmentReporting].[SRC_DPR] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[DPR1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [DPR1] ASC) AS RowID, [DPR1] FROM [InvestmentReporting].[SRC_DPR]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [DPR1]
) B ON A.[RowID] = B.[RowID]
