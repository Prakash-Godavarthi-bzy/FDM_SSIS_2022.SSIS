﻿

CREATE VIEW [InvestmentReporting].[F219uLC]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [F219uL1] ASC) AS RowID
			, [F219uL1] AS [F219uLC1]
			, [F219uL2] AS [F219uLC2]
			, [F219uL3] AS [F219uLC3]
	FROM [InvestmentReporting].[SRC_F219uL] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[F219uL1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [F219uL1] ASC) AS RowID, [F219uL1] FROM [InvestmentReporting].[SRC_F219uL]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [F219uL1]
) B ON A.[RowID] = B.[RowID]
