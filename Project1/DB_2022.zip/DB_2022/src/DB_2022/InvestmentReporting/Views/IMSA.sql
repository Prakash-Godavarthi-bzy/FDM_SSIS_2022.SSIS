﻿


CREATE VIEW [InvestmentReporting].[IMSA]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [IMSA1] ASC) AS RowID
			, [IMSA1]
			, [IMSA2]
			, [IMSA3]
			, [IMSA4]
	FROM [InvestmentReporting].[SRC_IMSA] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[IMSA1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [IMSA1] ASC) AS RowID, [IMSA1] FROM [InvestmentReporting].[SRC_IMSA]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [IMSA1]
) B ON A.[RowID] = B.[RowID]
