﻿

CREATE VIEW [InvestmentReporting].[OD]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [OD9] ASC) AS RowID
			, [OD1]
			, [OD2]
			, [OD3]
			, [OD4]
			, [OD5]
			, [OD6]
			, [OD7]
			, [OD8]
			, [OD9]
			, [OD10]
			, [OD11]
	FROM [InvestmentReporting].[SRC_OD] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[OD9] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [OD9] ASC) AS RowID, [OD9] FROM [InvestmentReporting].[SRC_OD]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [OD9]
) B ON A.[RowID] = B.[RowID]
