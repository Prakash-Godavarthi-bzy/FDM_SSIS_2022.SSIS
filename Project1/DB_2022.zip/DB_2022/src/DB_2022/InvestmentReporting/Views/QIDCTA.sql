﻿

CREATE VIEW [InvestmentReporting].[QIDCTA]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [QIDCT2] ASC) AS RowID
			, [QIDCT2] AS [QIDCTA2]
			, [QIDCT3] AS [QIDCTA3]
			, [QIDCT3] AS [DEF_QIDCTA]
	FROM [InvestmentReporting].[SRC_QIDCT] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[QIDCT2] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [QIDCT2] ASC) AS RowID, [QIDCT2] FROM [InvestmentReporting].[SRC_QIDCT]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [QIDCT2]
) B ON A.[RowID] = B.[RowID]
