﻿


CREATE VIEW [InvestmentReporting].[QPF]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [QPF1] ASC) AS RowID
			, [QPF1]
			, [QPF2]
			, [QPF3]
			, [QPF3] AS [DEF_QPF]
	FROM [InvestmentReporting].[SRC_QPF] A


	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[QPF1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [QPF1] ASC) AS RowID, [QPF1] FROM [InvestmentReporting].[SRC_QPF]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [QPF1]
) B ON A.[RowID] = B.[RowID]
