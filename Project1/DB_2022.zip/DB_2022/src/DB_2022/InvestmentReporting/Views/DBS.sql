﻿

CREATE VIEW [InvestmentReporting].[DBS]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [DBS1] ASC) AS RowID
			, [DBS1]
			, [DBS2]
	FROM [InvestmentReporting].[SRC_DBS] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[DBS1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [DBS1] ASC) AS RowID, [DBS1] FROM [InvestmentReporting].[SRC_DBS]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [DBS1]
) B ON A.[RowID] = B.[RowID]
