﻿


CREATE VIEW [InvestmentReporting].[BR]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [BR1] ASC) AS RowID
			, [BR1]
			, [BR2]
			, [BR3]
	FROM [InvestmentReporting].[SRC_BloombergRating] A


	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[BR1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [BR1] ASC) AS RowID, [BR1] FROM [InvestmentReporting].[SRC_BloombergRating]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [BR1]
) B ON A.[RowID] = B.[RowID]
