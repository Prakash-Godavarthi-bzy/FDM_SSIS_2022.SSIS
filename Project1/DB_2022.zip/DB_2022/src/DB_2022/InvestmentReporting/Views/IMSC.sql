﻿

CREATE VIEW [InvestmentReporting].[IMSC]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [IMSC3] ASC) AS RowID
			, [IMSC1]
			, [IMSC2]
			, [IMSC3]
			, [IMSC4]
	FROM [InvestmentReporting].[SRC_IMSC] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[IMSC3] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [IMSC3] ASC) AS RowID, [IMSC3] FROM [InvestmentReporting].[SRC_IMSC]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [IMSC3]
) B ON A.[RowID] = B.[RowID]
