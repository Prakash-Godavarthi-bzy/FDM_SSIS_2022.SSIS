﻿


CREATE VIEW [InvestmentReporting].[ARC]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [ARC1] ASC) AS RowID
			, [ARC1]
			, [ARC2]
			, [ARC3]
	FROM [InvestmentReporting].[SRC_ARC] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[ARC1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [ARC1] ASC) AS RowID, [ARC1] FROM [InvestmentReporting].[SRC_ARC]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [ARC1]
) B ON A.[RowID] = B.[RowID]
