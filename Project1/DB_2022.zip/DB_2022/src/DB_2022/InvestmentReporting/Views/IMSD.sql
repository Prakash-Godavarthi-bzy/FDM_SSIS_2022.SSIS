﻿


 CREATE VIEW [InvestmentReporting].[IMSD]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [IMSD1] ASC) AS RowID
			, [IMSD1]
			, [IMSD2]

	FROM [InvestmentReporting].[SRC_IMSD] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[IMSD1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [IMSD1] ASC) AS RowID, [IMSD1] FROM [InvestmentReporting].[SRC_IMSD]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [IMSD1]
) B ON A.[RowID] = B.[RowID]
