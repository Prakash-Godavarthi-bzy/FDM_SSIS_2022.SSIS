﻿

CREATE VIEW [InvestmentReporting].[CGL]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [CGL1] ASC) AS RowID
			, [CGL1]
			, [CGL2]
	FROM [InvestmentReporting].[SRC_CGL] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[CGL1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [CGL1] ASC) AS RowID, [CGL1] FROM [InvestmentReporting].[SRC_CGL]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [CGL1]
) B ON A.[RowID] = B.[RowID]
