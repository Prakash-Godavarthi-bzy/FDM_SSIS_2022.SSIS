﻿

CREATE VIEW [InvestmentReporting].[PLR]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [PLR1] ASC) AS RowID
			, [PLR1]
			, [PLR2]
			, [PLR3]
			, [PLR4]
			, [PLR5]
	FROM [InvestmentReporting].[SRC_PLR] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[PLR1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [PLR1] ASC) AS RowID, [PLR1] FROM [InvestmentReporting].[SRC_PLR]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [PLR1]
) B ON A.[RowID] = B.[RowID]
