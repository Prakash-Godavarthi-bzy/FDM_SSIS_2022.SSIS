﻿
CREATE VIEW [InvestmentReporting].[DJO]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [DJO3] ASC) AS RowID
			, [DJO3]
			, [DJO4]
			, [DJO5]
			, [DJO6]
	FROM [InvestmentReporting].[SRC_DJO] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[DJO3] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [DJO3] ASC) AS RowID, [DJO3] FROM [InvestmentReporting].[SRC_DJO]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [DJO3]
) B ON A.[RowID] = B.[RowID]
