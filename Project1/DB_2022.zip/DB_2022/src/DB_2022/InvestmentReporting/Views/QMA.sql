﻿



CREATE VIEW [InvestmentReporting].[QMA]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [QMA2] ASC) AS RowID
			, [QMA1]
			, [QMA2]
			, [QMA3]
			, [QMA4]
			, [QMA5]
			, [QMA6]
			, [QMA7]
			, [QMA8]
			, [QMA9]
			, [QMA10]
			, [QMA11]
			, [QMA12]
			, [QMA13]
			, [QMA14]
	FROM [InvestmentReporting].[SRC_QMA] A

	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[QMA2] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [QMA2] ASC) AS RowID, [QMA2] FROM [InvestmentReporting].[SRC_QMA]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [QMA2]
) B ON A.[RowID] = B.[RowID]
