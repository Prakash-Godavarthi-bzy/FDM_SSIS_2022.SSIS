﻿

CREATE VIEW [InvestmentReporting].[QII]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [QII1] ASC) AS RowID
			, [QII1]
			, [QII2]
			, [QII3]
			, [QII3] AS [DEF_QII]
	FROM [InvestmentReporting].[SRC_QII] A


	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[QII1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [QII1] ASC) AS RowID, [QII1] FROM [InvestmentReporting].[SRC_QII]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [QII1]
) B ON A.[RowID] = B.[RowID]
