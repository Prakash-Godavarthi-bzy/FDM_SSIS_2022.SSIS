﻿


CREATE VIEW [InvestmentReporting].[CSTDCUS]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [CSTDCUS1] ASC) AS RowID
			, [CSTDCUS1]
			, [CSTDCUS2]
			, [CSTDCUS3]
			, [CSTDCUS4]
			, [CSTDCUS5]
	FROM [InvestmentReporting].[SRC_CSTDCUS] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[CSTDCUS1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [CSTDCUS1] ASC) AS RowID, [CSTDCUS1] FROM [InvestmentReporting].[SRC_CSTDCUS]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [CSTDCUS1]
) B ON A.[RowID] = B.[RowID]
