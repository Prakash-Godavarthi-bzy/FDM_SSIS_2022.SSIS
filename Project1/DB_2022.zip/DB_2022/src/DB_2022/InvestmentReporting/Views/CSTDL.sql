﻿

CREATE VIEW [InvestmentReporting].[CSTDL]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [CSTDL1] ASC) AS RowID
			, [CSTDL1]
			, [CSTDL2]
			, [CSTDL3]
			, [CSTDL4]
			, [CSTDL5]
			, [CSTDL6]
	FROM [InvestmentReporting].[SRC_CSTDL] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[CSTDL1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [CSTDL1] ASC) AS RowID, [CSTDL1] FROM [InvestmentReporting].[SRC_CSTDL]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [CSTDL1]
) B ON A.[RowID] = B.[RowID]
