﻿


CREATE VIEW [InvestmentReporting].[F212uE]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [F212uE1] ASC) AS RowID
			, [F212uE1]
			, [F212uE2]
			, [F212uE3]
	FROM [InvestmentReporting].[SRC_F212uE] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[F212uE1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [F212uE1] ASC) AS RowID, [F212uE1] FROM [InvestmentReporting].[SRC_F212uE]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [F212uE1]
) B ON A.[RowID] = B.[RowID]
