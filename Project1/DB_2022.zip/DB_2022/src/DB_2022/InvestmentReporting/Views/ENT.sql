﻿

CREATE VIEW [InvestmentReporting].[ENT]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [ENT1] ASC) AS RowID
			, [ENT1]
			, [ENT2]
			, [ENT3]
	FROM [InvestmentReporting].[SRC_ENT] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[ENT1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [ENT1] ASC) AS RowID, [ENT1] FROM [InvestmentReporting].[SRC_ENT]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [ENT1]
) B ON A.[RowID] = B.[RowID]
