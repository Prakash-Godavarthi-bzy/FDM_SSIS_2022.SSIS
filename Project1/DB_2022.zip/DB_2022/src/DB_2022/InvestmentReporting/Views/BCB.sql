﻿

CREATE VIEW [InvestmentReporting].[BCB]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [BCB1] ASC) AS RowID
			, [BCB1]
			, [BCB2]
	FROM [InvestmentReporting].[SRC_BCB] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[BCB1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [BCB1] ASC) AS RowID, [BCB1] FROM [InvestmentReporting].[SRC_BCB]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [BCB1]
) B ON A.[RowID] = B.[RowID]
