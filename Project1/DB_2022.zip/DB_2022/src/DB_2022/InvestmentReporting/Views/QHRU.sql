﻿

CREATE VIEW [InvestmentReporting].[QHRU]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [QHRU1] ASC) AS RowID
			, [QHRU1]
			, [QHRU2]
			, [QHRU3]
			, [QHRU3] AS [DEF_QHRU]
	FROM [InvestmentReporting].[SRC_QHRU] A


	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[QHRU1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [QHRU1] ASC) AS RowID, [QHRU1] FROM [InvestmentReporting].[SRC_QHRU]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [QHRU1]
) B ON A.[RowID] = B.[RowID]
