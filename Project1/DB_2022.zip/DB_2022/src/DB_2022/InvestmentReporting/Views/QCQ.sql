﻿

CREATE VIEW [InvestmentReporting].[QCQ]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [QCQ1] ASC) AS RowID
			, [QCQ1]
			, [QCQ2]
			, [QCQ3]
			, [QCQ3] AS [DEF_QCQ]
	FROM [InvestmentReporting].[SRC_QCQ] A


	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[QCQ1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [QCQ1] ASC) AS RowID, [QCQ1] FROM [InvestmentReporting].[SRC_QCQ]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [QCQ1]
) B ON A.[RowID] = B.[RowID]
