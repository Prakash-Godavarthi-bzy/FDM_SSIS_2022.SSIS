﻿

CREATE VIEW [InvestmentReporting].[QNECAI]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [QNECAI1] ASC) AS RowID
			, [QNECAI1]
			, [QNECAI2]
			, [QNECAI3]
			, [QNECAI3] AS [DEF_QNECAI]
	FROM [InvestmentReporting].[SRC_QNECAI] A


	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[QNECAI1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [QNECAI1] ASC) AS RowID, [QNECAI1] FROM [InvestmentReporting].[SRC_QNECAI]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [QNECAI1]
) B ON A.[RowID] = B.[RowID]
