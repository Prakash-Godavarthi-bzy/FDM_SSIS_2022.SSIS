﻿


 CREATE VIEW [InvestmentReporting].[INFA]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [INF4] ASC) AS RowID
			, [INF4] AS [INFA1]
			, [INF5] AS [INFA2]

	FROM [InvestmentReporting].[SRC_INF] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[INF4] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [INF4] ASC) AS RowID, [INF4] FROM [InvestmentReporting].[SRC_INF]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [INF4]
) B ON A.[RowID] = B.[RowID]
