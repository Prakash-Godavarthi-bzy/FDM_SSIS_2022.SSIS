﻿


CREATE VIEW [InvestmentReporting].[CICR]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [CICR1] ASC) AS RowID
			, [CICR1]
			, [CICR2]
			, [CICR3]
			, [CICR4]
			, [CICR5]
			, [CICR6]
			, [CICR7]
			, [CICR8]
			, [CICR9]
			, [CICR10]
			, [CICR11]
	FROM [InvestmentReporting].[SRC_CICR] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[CICR1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [CICR1] ASC) AS RowID, [CICR1] FROM [InvestmentReporting].[SRC_CICR]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [CICR1]
) B ON A.[RowID] = B.[RowID]
