﻿


CREATE VIEW [InvestmentReporting].[OverseasExtract]
AS
SELECT 
	  OE.[VersionID]
	, OE.RowID * 10 + A.[ATC0] AS [RowID]
	, OE.[OE1]
	, OE.[OE2]
	, OE.[OE3]
	, OE.[OE4]
	, A.[ATC2] AS [ATC2]
	, A.[ATC3] * [OE5] AS [OE5]
FROM [InvestmentReporting].[SRC_OverseasExtract] OE
INNER JOIN [InvestmentReporting].[FeedDetails] FD ON FD.[pkFeedVersionID] = OE.[VersionID]
INNER JOIN [InvestmentReporting].[SRC_ATC] A ON A.[VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
AND FD.[ParentID] IN  (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
