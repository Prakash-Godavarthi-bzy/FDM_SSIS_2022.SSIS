﻿


CREATE VIEW [InvestmentReporting].[QCTC]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [QCTC1] ASC) AS RowID
			, [QCTC1]
			, [QCTC2]

	FROM [InvestmentReporting].[SRC_QCTC] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[QCTC1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [QCTC1] ASC) AS RowID, [QCTC1] FROM [InvestmentReporting].[SRC_QCTC]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [QCTC1]
) B ON A.[RowID] = B.[RowID]
