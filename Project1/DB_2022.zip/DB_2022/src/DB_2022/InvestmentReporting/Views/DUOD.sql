﻿

CREATE VIEW [InvestmentReporting].[DUOD]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [DUOD1] ASC) AS RowID
			, [DUOD1]
			, [DUOD2]
	FROM [InvestmentReporting].[SRC_DUOD] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[DUOD1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [DUOD1] ASC) AS RowID, [DUOD1] FROM [InvestmentReporting].[SRC_DUOD]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [DUOD1]
) B ON A.[RowID] = B.[RowID]
