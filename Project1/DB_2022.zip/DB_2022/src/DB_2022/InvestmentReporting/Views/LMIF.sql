﻿



CREATE VIEW [InvestmentReporting].[LMIF]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [LMIF4] ASC) AS RowID
			, [LMIF1]
			, [LMIF2]
			, [LMIF3]
			, [LMIF4]
			, [LMIF5]
			, [LMIF6]
			, [LMIF7]
			, [LMIF8]
			, [LMIF9]
			, [LMIF10]
			, [LMIF11]
			, [LMIF12]
			, [LMIF13]
			, [LMIF14]
			, [LMIF15]
			, [LMIF16]
			, [LMIF17]
			, [LMIF18]
			, [LMIF19]
			, [LMIF20]
			, [LMIF21]
			, [LMIF22]
			, [LMIF23]
			, [LMIF24]
			, [LMIF25]
			, [LMIF26]
			, [LMIF27]
			, [LMIF28]
			, [LMIF29]
			, [LMIF30]
	FROM [InvestmentReporting].[SRC_LMIF] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[LMIF4] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [LMIF4] ASC) AS RowID, [LMIF4] FROM [InvestmentReporting].[SRC_LMIF]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [LMIF4]
) B ON A.[RowID] = B.[RowID]
