﻿


CREATE VIEW [InvestmentReporting].[AUMAssetReport]
AS
SELECT 
	  F.[VersionID]
	, CASE WHEN FD.[ParentID] = FD.[pkFeedVersionID] THEN F.[RowID] ELSE F.[RowID] + 100000 END AS [RowID]
	, F.[BS1]
	, F.[BS2]
	, F.[BS3]
	, F.[BS4]
	, F.[BS5]
	, F.[BS6]
	, F.[BS7]
	, F.[BS8]
	, F.[BS9]
	, F.[BS10]
	, F.[BS11]
	, F.[BS12]
	, F.[BS13]
	, F.[BS14]
	, F.[BS15]
	, F.[BS16]
	, F.[BS17]
	, F.[BS18]
	, F.[BS19]
	, F.[BS20]
	, F.[BS21]
	, F.[BS22]
	, F.[BS23]
	, F.[BS24]
	, F.[BS25]
	, F.[BS26]
	, F.[BS27]
FROM [InvestmentReporting].[SRC_AUMAssetReport] F
INNER JOIN [InvestmentReporting].[FeedDetails] FD ON FD.[pkFeedVersionID] = F.[VersionID]
AND FD.[ParentID] IN  (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
