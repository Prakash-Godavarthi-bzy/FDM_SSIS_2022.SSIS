﻿


CREATE VIEW [InvestmentReporting].[GR]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [GR1] ASC) AS RowID
			, [GR1]
			, [GR2]
			, [GR3]
	FROM [InvestmentReporting].[SRC_GR] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[GR1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [GR1] ASC) AS RowID, [GR1] FROM [InvestmentReporting].[SRC_GR]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [GR1]
) B ON A.[RowID] = B.[RowID]
