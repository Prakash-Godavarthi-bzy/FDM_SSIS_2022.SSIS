﻿
CREATE VIEW [InvestmentReporting].[DYA]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [DYA1] ASC) AS RowID
			, [DYA1]
			, [DYA2]
			, [DYA3]
			, [DYA4]
	FROM [InvestmentReporting].[SRC_DYA] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[DYA1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [DYA1] ASC) AS RowID, [DYA1] FROM [InvestmentReporting].[SRC_DYA]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [DYA1]
) B ON A.[RowID] = B.[RowID]
