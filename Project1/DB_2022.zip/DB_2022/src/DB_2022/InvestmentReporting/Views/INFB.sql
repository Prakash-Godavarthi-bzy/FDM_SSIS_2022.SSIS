﻿

 CREATE VIEW [InvestmentReporting].[INFB]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [INF1] ASC) AS RowID
			, [INF1] AS [INFB1]
			, [INF6] AS [INFB2]

	FROM [InvestmentReporting].[SRC_INF] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[INF1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [INF1] ASC) AS RowID, [INF1] FROM [InvestmentReporting].[SRC_INF]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [INF1]
) B ON A.[RowID] = B.[RowID]
