﻿

CREATE VIEW [InvestmentReporting].[DDCA]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [DDC7] ASC) AS RowID
			, [DDC7] AS [DDCA7]
			, [DDC8] AS [DDCA8]
			, [DDC9] AS [DDCA9]
			, [DDC10] AS [DDCA10]
			, [DDC11] AS [DDCA11]
	FROM [InvestmentReporting].[SRC_DDC] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[DDC7] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [DDC7] ASC) AS RowID, [DDC7] FROM [InvestmentReporting].[SRC_DDC]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [DDC7]
) B ON A.[RowID] = B.[RowID]
