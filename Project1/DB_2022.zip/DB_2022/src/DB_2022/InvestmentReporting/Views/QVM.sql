﻿

CREATE VIEW [InvestmentReporting].[QVM]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [QVM1] ASC) AS RowID
			, [QVM1]
			, [QVM2]
			, [QVM3]
			, [QVM3] AS [DEF_QVM]
	FROM [InvestmentReporting].[SRC_QVM] A


	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[QVM1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [QVM1] ASC) AS RowID, [QVM1] FROM [InvestmentReporting].[SRC_QVM]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [QVM1]
) B ON A.[RowID] = B.[RowID]
