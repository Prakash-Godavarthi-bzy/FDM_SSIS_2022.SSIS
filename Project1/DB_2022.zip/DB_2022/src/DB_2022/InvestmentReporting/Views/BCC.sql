﻿

CREATE VIEW [InvestmentReporting].[BCC]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [BCC1] ASC) AS RowID
			, [BCC1]
			, [BCC2]
	FROM [InvestmentReporting].[SRC_BCC] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[BCC1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [BCC1] ASC) AS RowID, [BCC1] FROM [InvestmentReporting].[SRC_BCC]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [BCC1]
) B ON A.[RowID] = B.[RowID]
