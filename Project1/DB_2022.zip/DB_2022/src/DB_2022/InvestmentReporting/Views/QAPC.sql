﻿

CREATE VIEW [InvestmentReporting].[QAPC]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [QAPC1] ASC) AS RowID
			, [QAPC1]
			, [QAPC2]
			, [QAPC3]
			, [QAPC3] AS [DEF_QAPC]
	FROM [InvestmentReporting].[SRC_QAPC] A


	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[QAPC1] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [QAPC1] ASC) AS RowID, [QAPC1] FROM [InvestmentReporting].[SRC_QAPC]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [QAPC1]
) B ON A.[RowID] = B.[RowID]
