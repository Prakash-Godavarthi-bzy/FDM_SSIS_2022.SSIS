﻿


CREATE VIEW [InvestmentReporting].[CBA]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [CBA25] ASC) AS RowID
			, [CBA1]
			, [CBA2]
			, [CBA3]
			, [CBA4]
			, [CBA5]
			, [CBA6]
			, [CBA7]
			, [CBA8]
			, [CBA9]
			, [CBA10]
			, [CBA11]
			, [CBA12]
			, [CBA13]
			, [CBA14]
			, [CBA15]
			, [CBA16]
			, [CBA17]
			, [CBA18]
			, [CBA19]
			, [CBA19] AS [CBAA19]
			, [CBA20]
			, [CBA21]
			, [CBA22]
			, [CBA23]
			, [CBA24]
			, [CBA25]
	FROM [InvestmentReporting].[SRC_CBA] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[CBA25] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [CBA25] ASC) AS RowID, [CBA25] FROM [InvestmentReporting].[SRC_CBA]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [CBA25]
) B ON A.[RowID] = B.[RowID]
