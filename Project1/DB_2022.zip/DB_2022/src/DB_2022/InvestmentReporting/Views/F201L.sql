﻿



CREATE VIEW [InvestmentReporting].[F201L]
AS
SELECT A.* FROM
(	SELECT	  ROW_NUMBER() OVER(ORDER BY [F201L4] ASC) AS RowID
			, [F201L1]
			, [F201L2]
			, [F201L3]
			, [F201L4]
			, [F201L5]
			, [F201L6]
	FROM [InvestmentReporting].[SRC_F201L] A
	WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
) A
INNER JOIN
(
	SELECT MIN(RowID) AS [RowID],[F201L4] FROM
	(	SELECT ROW_NUMBER() OVER(ORDER BY [F201L4] ASC) AS RowID, [F201L4] FROM [InvestmentReporting].[SRC_F201L]
		WHERE [VersionID] IN (SELECT [fkFeedVersionID] FROM [InvestmentReporting].[ModelFeedConfig] MFC INNER JOIN [InvestmentReporting].[ModelConfig] MC ON MC.[pkModelID] = MFC.[fkModelID] AND MC.[Status] = 'Running')
	) DUP
	GROUP BY [F201L4]
) B ON A.[RowID] = B.[RowID]
