﻿/*
 Pre-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be executed before the build script.	
 Use SQLCMD syntax to include a file in the pre-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the pre-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/


--Changing the Table name  --FactFDMExternal
IF(OBJECT_ID('dbo.FactFDMExternal_History') IS NULL AND OBJECT_ID('dbo.FactFDMExternal') IS NOT NULL) 

BEGIN	
	
--Table Rename

		EXEC sp_rename 'dbo.FactFDMExternal', 'FactFDMExternal_History';


--Indexes Rename

	EXEC sp_rename @objname = N'dbo.FactFDMExternal_History.Ind_FactFDMExternal_AccountingPeriod', @newname = N'Ind_FactFDMExternal_AccountingPeriod_History', @objtype = N'INDEX';
	EXEC sp_rename @objname = N'dbo.FactFDMExternal_History.nlx_FactFDMExternal_fk_PolicySection_cvr', @newname = N'nlx_FactFDMExternal_fk_PolicySection_cvr_History', @objtype = N'INDEX';
	EXEC sp_rename @objname = N'dbo.FactFDMExternal_History.nlx_FactFDMExternal_fk_PolicySection_Dim5', @newname = N'nlx_FactFDMExternal_fk_PolicySection_Dim5_History', @objtype = N'INDEX';
	EXEC sp_rename @objname = N'dbo.FactFDMExternal_History.nlx_FactFDMExternal_fk_PolicySection_transaction_date', @newname = N'nlx_FactFDMExternal_fk_PolicySection_transaction_date_History', @objtype = N'INDEX';
	EXEC sp_rename @objname = N'dbo.FactFDMExternal_History.nlx_FactFDMExternal_fk_PolicySection_voucher_date', @newname = N'nlx_FactFDMExternal_fk_PolicySection_voucher_date_History', @objtype = N'INDEX';
	EXEC sp_rename @objname = N'dbo.FactFDMExternal_History.PK_FactFDMExternal', @newname = N'PK_FactFDMExternal_History', @objtype = N'INDEX';

--Constarint rename
 
EXEC sp_rename N'dbo.DF__FactFDMEx__fk_Cl__45BE5BA9',N'DF__FactFDMEx_HIS__fk_Cl__45BE5BA9';
EXEC sp_rename N'dbo.DF__FactFDMEx__fk_sp__43D61337',N'DF__FactFDMEx_HIS__fk_sp__43D61337';
EXEC sp_rename N'dbo.fk_FactFDMExternalAccount_FK1',N'fk_FactFDMExternal_HistoryAccount_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalAccountingPeriod_FK1',N'fk_FactFDMExternal_HistoryAccountingPeriod_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalBusinessPlan_FK1',N'fk_FactFDMExternal_HistoryBusinessPlan_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalClaimExposure_FK1',N'fk_FactFDMExternal_HistoryClaimExposure_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalClassofBusiness_FK1',N'fk_FactFDMExternal_HistoryClassofBusiness_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalClient_FK1',N'fk_FactFDMExternal_HistoryClient_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalCURRENCY_FK1',N'fk_FactFDMExternal_HistoryCURRENCY_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalDataStage_FK1',N'fk_FactFDMExternal_HistoryDataStage_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalEntity_FK1',N'fk_FactFDMExternal_HistoryEntity_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalExpense_FK1',N'fk_FactFDMExternal_HistoryExpense_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalInvestment_FK1',N'fk_FactFDMExternal_HistoryInvestment_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalLloydsClassifications',N'fk_FactFDMExternal_HistoryLloydsClassifications';
EXEC sp_rename N'dbo.fk_FactFDMExternalOffice_FK1',N'fk_FactFDMExternal_HistoryOffice_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalPolicySection_FK1',N'fk_FactFDMExternal_HistoryPolicySection_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalProcess_FK1',N'fk_FactFDMExternal_HistoryProcess_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalProduct_FK1',N'fk_FactFDMExternal_HistoryProduct_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalProject_FK1',N'fk_FactFDMExternal_HistoryProject_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalRIPolicy_FK1',N'fk_FactFDMExternal_HistoryRIPolicy_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalScenario_FK1',N'fk_FactFDMExternal_HistoryScenario_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalSourceSystem_FK1',N'fk_FactFDMExternal_HistorySourceSystem_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalSpecial_FK1',N'fk_FactFDMExternal_HistorySpecial_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalTriFocus_FK1',N'fk_FactFDMExternal_HistoryTriFocus_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalUser_FK1',N'fk_FactFDMExternal_HistoryUser_FK1';
EXEC sp_rename N'dbo.fk_FactFDMExternalYOA_FK1',N'fk_FactFDMExternal_HistoryYOA_FK1';

 
END


--Changing the Table name  --FACTAllocationsV1
IF(OBJECT_ID('dbo.FACTAllocationsV1_History') IS NULL AND OBJECT_ID('dbo.FACTAllocationsV1') IS NOT NULL) 

BEGIN
	
	--Table Rename
	EXEC sp_rename 'dbo.FACTAllocationsV1', 'FACTAllocationsV1_History';

	--Indexes Rename
	EXEC sp_rename @objname = N'dbo.FACTAllocationsV1_History.nlx_FACTAllocationsV1_AllocDelete', @newname = N'nlx_FACTAllocationsV1_Hisotry__AllocDelete', @objtype = N'INDEX';
	EXEC sp_rename @objname = N'dbo.FACTAllocationsV1_History.nlx_FactAllocationsV1_fk_PolicySection_cvr', @newname = N'nlx_FactAllocationsV1_Hisotry__fk_PolicySection_cvr', @objtype = N'INDEX';
	EXEC sp_rename @objname = N'dbo.FACTAllocationsV1_History.nlx_FactAllocationsV1_fk_PolicySection_Dim5', @newname = N'nlx_FactAllocationsV1_Hisotry_fk_PolicySection_Dim5', @objtype = N'INDEX';
	EXEC sp_rename @objname = N'dbo.FACTAllocationsV1_History.nlx_FactAllocationsV1_fk_PolicySection_transaction_date', @newname = N'nlx_FactAllocationsV1_History_fk_PolicySection_transaction_date', @objtype = N'INDEX';
	EXEC sp_rename @objname = N'dbo.FACTAllocationsV1_History.nlx_FactAllocationsV1_fk_PolicySection_voucher_date', @newname = N'nlx_FactAllocationsV1_Hisotry_fk_PolicySection_voucher_date', @objtype = N'INDEX';
	EXEC sp_rename @objname = N'dbo.FACTAllocationsV1_History.nlx_FACTAllocationsV1_ReAllocations', @newname = N'nlx_FACTAllocationsV1_Hisotry_ReAllocations', @objtype = N'INDEX';
	EXEC sp_rename @objname = N'dbo.FACTAllocationsV1_History.PK_FACTAllocationsV1', @newname = N'PK_FACTAllocationsV1_History', @objtype = N'INDEX';


	--Constraints Rename
	EXEC sp_rename N'dbo.DF__FACTAlloc__SoftD__0E6E26BF', N'DF__FACTAlloc__SoftD__0E6E26BF_History';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1Account_FK1', N'fk_FACTAllocationsV1_History_Account_FK1';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1AccountingPeriod_FK1', N'fk_FACTAllocationsV1_History_AccountingPeriod_FK1';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1AllocationRules_FK1', N'fk_FACTAllocationsV1_History_AllocationRules_FK1';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1BusinessPlan_FK1', N'fk_FACTAllocationsV1_History_BusinessPlan_FK1';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1ClaimExposure_FK1', N'fk_FACTAllocationsV1_History_ClaimExposure_FK1';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1Client_FK1', N'fk_FACTAllocationsV1_History_Client_FK1';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1CURRENCY_FK1', N'fk_FACTAllocationsV1_History_CURRENCY_FK1';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1DataStage_FK1', N'fk_FACTAllocationsV1_History_DataStage_FK1';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1Entity_FK1', N'fk_FACTAllocationsV1_History_Entity_FK1';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1Expense_FK1', N'fk_FACTAllocationsV1_History_Expense_FK1';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1Investment_FK1', N'fk_FACTAllocationsV1_History_Investment_FK1';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1LloydsClassifications', N'fk_FACTAllocationsV1_History_LloydsClassifications';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1Office_FK1', N'fk_FACTAllocationsV1_History_Office_FK1';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1PolicySection_FK1', N'fk_FACTAllocationsV1_History_PolicySection_FK1';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1Process_FK1', N'fk_FACTAllocationsV1_History_Process_FK1';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1Product_FK1', N'fk_FACTAllocationsV1_History_Product_FK1';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1Project_FK1', N'fk_FACTAllocationsV1_History_Project_FK1';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1RIPolicy_FK1', N'fk_FACTAllocationsV1_History_RIPolicy_FK1';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1Scenario_FK1', N'fk_FACTAllocationsV1_History_Scenario_FK1';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1SourceSystem_FK1', N'fk_FACTAllocationsV1_History_SourceSystem_FK1';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1TriFocus_FK1', N'fk_FACTAllocationsV1_History_TriFocus_FK1';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1User_FK1', N'fk_FACTAllocationsV1_History_User_FK1';
	EXEC sp_rename N'dbo.fk_FACTAllocationsV1YOA_FK1', N'fk_FACTAllocationsV1_History_YOA_FK1';
	

END

--Changing the Table name  --DimTransactionDetailsV1

IF(OBJECT_ID('dbo.DimTransactionDetailsV1_History') IS NULL AND OBJECT_ID('dbo.DimTransactionDetailsV1') IS NOT NULL) 
		

BEGIN 

--Table Rename
	EXEC sp_rename 'dbo.DimTransactionDetailsV1', 'DimTransactionDetailsV1_History';

--Index Rename
	EXEC sp_rename @objname = N'dbo.DimTransactionDetailsV1_History.Clx_DimTransactionDetailsV1_pk_FatcFDM', @newname = N'Clx_DimTransactionDetailsV1_pk_FatcFDM_History', @objtype = N'INDEX';
	EXEC sp_rename @objname = N'dbo.DimTransactionDetailsV1_History.nlx_DimTransactionDetailsV1_AccPeriod', @newname = N'nlx_DimTransactionDetailsV1_AccPeriod_History', @objtype = N'INDEX';
	EXEC sp_rename @objname = N'dbo.DimTransactionDetailsV1_History.nlx_DimTransactionDetailsV1_AccPeriodv1', @newname = N'nlx_DimTransactionDetailsV1_AccPeriodv1_History', @objtype = N'INDEX';
	EXEC sp_rename @objname = N'dbo.DimTransactionDetailsV1_History.nxl_DimTransactionDetailsV1_CombinationID', @newname = N'nxl_DimTransactionDetailsV1_CombinationID_History', @objtype = N'INDEX';

--Constarint Rename
--No Constraints

END