﻿--MoveFactAllocationsV1ToCurrent
IF NOT EXISTS(SELECT 'X' FROM FDM_DB..FACTAllocationsV1_Current)

BEGIN

DECLARE @AccountPeriodLimit INT,
		@MAXAccoutingPeriod INT

SELECT @AccountPeriodLimit = CAST(YEAR(DATEADD(mm,-15, GETDATE())) AS VARCHAR(4)) +''+ RIGHT('0' + CAST(MONTH(DATEADD(mm,-15, GETDATE())) AS VARCHAR(2)), 2)

SELECT @MAXAccoutingPeriod=MAX(fk_AccountingPeriod) FROM FDM_DB..FACTAllocationsV1_History

WHILE(@MAXAccoutingPeriod>=@AccountPeriodLimit)

	BEGIN

		INSERT INTO FDM_DB..FACTAllocationsV1_Current  WITH(TABLOCK)
		SELECT  * FROM FDM_DB..FACTAllocationsV1_History
		WHERE fk_AccountingPeriod=@MAXAccoutingPeriod

		DELETE FROM FDM_DB..FACTAllocationsV1_history
	    WHERE fk_AccountingPeriod=@MAXAccoutingPeriod
		
		SET @MAXAccoutingPeriod= Convert(int,Substring(CONVERT(VARCHAR,DATEADD(MONTH,-1,CONVERT(datetime,CONVERT(VARCHAR,@MAXAccoutingPeriod)+'01')),112),1,6))
		

	 END
	 
		

END
