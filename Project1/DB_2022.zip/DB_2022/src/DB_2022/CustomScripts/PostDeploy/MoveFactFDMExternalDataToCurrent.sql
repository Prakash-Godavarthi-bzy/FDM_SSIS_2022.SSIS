﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

DECLARE @Currentpk_FactFDMExterna int;
SELECT @Currentpk_FactFDMExterna = IDENT_CURRENT( 'dbo.FactFDMExternal_Current')
--IF NOT EXISTS (SELECT TOP 1 pk_FactFDMExternal FROM dbo.FactFDMExternal_Current)
IF (@Currentpk_FactFDMExterna = -1)
	BEGIN
		--DECLARE @Currentpk_FactFDMExterna int;
		--SELECT @Currentpk_FactFDMExterna = IDENT_CURRENT( 'dbo.FactFDMExternal_Current')

		DECLARE @Max_pk_FactFDMExternal BIGINT

		SELECT @Max_pk_FactFDMExternal = MIN(pk_FactFDMExternal)-1
				FROM dbo.FactFDMExternal_History A
		
		/********************Identity reseed to max value of pk_FactFDMExternal column in FactFDMExternal***************************************/
		
		IF (LEN(@Max_pk_FactFDMExternal) > 0)
			DBCC CHECKIDENT ('dbo.FactFDMExternal_Current', RESEED, @Max_pk_FactFDMExternal)
		
	
		/************Update RunProcessLogID as it is a new column*******************/
		UPDATE dbo.FactFDMExternal_History
		   SET RunProcessLogID = -1
		 WHERE RunProcessLogID IS NULL
		 
	END