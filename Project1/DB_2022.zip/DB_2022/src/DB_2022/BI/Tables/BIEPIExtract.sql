﻿CREATE TABLE [BI].[BIEPIExtract] (
    [PolicyReference]          NVARCHAR (255) NULL,
    [InceptionDate]            DATETIME       NULL,
    [ExpiryDate]               DATETIME       NULL,
    [UnderwriterName]          NVARCHAR (255) NULL,
    [Department]               NVARCHAR (255) NULL,
    [TriFocusGroup]            NVARCHAR (255) NULL,
    [TriFocusCode]             NVARCHAR (255) NULL,
    [PolicyYOA]                INT            NULL,
    [StatsCode]                NVARCHAR (255) NULL,
    [PolicySettlementCurrency] NVARCHAR (255) NULL,
    [SyndicateNumber]          FLOAT (53)     NULL,
    [TotalAcquisitionCost]     FLOAT (53)     NULL,
    [EstimatedPremiumIncome]   FLOAT (53)     NULL,
    [RecordID]                 INT            IDENTITY (1, 1) NOT NULL,
    [LoadID]                   INT            NOT NULL,
    [BatchID]                  INT            NOT NULL,
    [ExclusionID]              SMALLINT       NOT NULL,
    [USTri]                    SMALLINT       NOT NULL,
    [Mop]                      NVARCHAR (10)  NOT NULL,
    [ReportDate]               DATETIME       NOT NULL
);

