﻿CREATE FUNCTION [dbo].[tf_PFT_CombinedPremium] 
(	
	@cycle nvarchar(255)
)
RETURNS TABLE 
AS
RETURN 
(
SELECT
	bo.[Platform]
	, p.* 
	, IC = isnull(c.IC,0)
	, EC = isnull(c.EC,0)
	, [GNP Exc IC] = p.[GNP inc IC] * (1/1+isnull(c.IC,0))
	, [GGP] = p.[GNP inc IC] / (1-isnull(c.EC,0))
FROM 
(
SELECT * FROM tf_PFT_SyndPremium(@cycle)
UNION ALL
SELECT * FROM tf_PFT_BIDACPremium(@cycle)
) p left outer join
[FDM_DC].[vPFTCommission] c on 
p.PolicyType = c.PolicyType
and p.ReviewCycle = c.ReviewCycle
and p.YOA = c.YOA
and p.TriFocus = c.TriFocus
and p.OfficeChannel= c.OfficeChannel left outer join
(
SELECT        pk_OfficeChannel, OfficeChannelName, Platform
FROM            FDM_DC.DimOfficeChannel
WHERE        (pk_OfficeChannel <> 'BIUK')
UNION
SELECT        'BIFR' AS pk_OfficeChannel, 'France' AS OfficeChannelName, 'BID' AS Platform
UNION
SELECT        'BIDE' AS pk_OfficeChannel, 'Germany' AS OfficeChannelName, 'BID' AS Platform
UNION
SELECT        'BISP' AS pk_OfficeChannel, 'Spain' AS OfficeChannelName, 'BID' AS Platform
UNION
SELECT        'BIUK' AS pk_OfficeChannel, 'UK' AS OfficeChannelName, 'BID' AS Platform
UNION
SELECT        'BISW' AS pk_OfficeChannel, 'Switzerland' AS OfficeChannelName, 'BID' AS Platform
UNION
SELECT        'USBAIC' AS pk_OfficeChannel, 'USBAIC' AS OfficeChannelName, 'USA' AS Platform
) bo on isnull(p.OfficeChannel,'LDN') = bo.pk_OfficeChannel

)
GO

