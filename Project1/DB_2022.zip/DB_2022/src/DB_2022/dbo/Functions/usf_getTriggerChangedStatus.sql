﻿


-- =============================================
-- Author:		Nanda Gottumukkala
-- Create date: 02/10/2015
-- Description:	To retrieve Trigger Changed Status
-- =============================================
CREATE FUNCTION [dbo].[usf_getTriggerChangedStatus] 
(
	@AllocationGroup AS VARCHAR(100)
	,@AllocationCode  AS VARCHAR(100) =''
)
RETURNS INT
AS
BEGIN

	DECLARE @CurrentVerison AS INT
	,@newVersion AS INT
	,@TriggersChanged AS INT = 0

	IF(@AllocationCode ='')
		BEGIN
		 SELECT	@CurrentVerison = MAX(b.AllocationGroupVersionCode)
		 FROM	BriExpensesTransactionDetailsV4 b
		 JOIN	DimAllocationRules a 
		 --ON		a.PK_AllocationRules = b.FK_AllocationRules
		 ON		a.PK_Alt_AllocationRules = b.FK_AllocationRules
		 WHERE	a.AllocationGroup = @AllocationGroup


		 SELECT	@newVersion =MAX(a.AllocationGroupCodeVersion)
		 FROM	DimAllocationRules a 
		 WHERE	a.AllocationGroup = @AllocationGroup

		 IF( @newVersion<>ISNULL(@CurrentVerison,0))
			BEGIN
				SET @TriggersChanged = 1
			END
		END
	ELSE IF (@AllocationCode <>'')
		BEGIN
		 SELECT	@CurrentVerison = MAX(b.AllocationGroupVersionCode)
		 FROM	BriExpensesTransactionDetailsV4 b
		 JOIN	DimAllocationRules a 
		 --ON		a.PK_AllocationRules = b.FK_AllocationRules
		 ON		a.PK_Alt_AllocationRules = b.FK_AllocationRules
		 WHERE	a.AllocationGroup = @AllocationGroup
		 AND	a.AllocationCode = @AllocationCode


		 SELECT	@newVersion =MAX(a.AllocationGroupCodeVersion)
		 FROM	DimAllocationRules a 
		 WHERE	a.AllocationGroup = @AllocationGroup
		 AND	a.AllocationCode = @AllocationCode

			 IF( @newVersion<>ISNULL(@CurrentVerison,0))
			 BEGIN
				SET @TriggersChanged = 1
			END
		END
	RETURN @TriggersChanged

END
