﻿-- =============================================
-- Author:		Dave Grant
-- Create date: 11/09/2018
-- Description:	combine premium from PFT cube writeback tables - include cede
-- =============================================
CREATE FUNCTION [dbo].[tf_PFT_CombinedPremiumIncCede] 
(	
	@cycle nvarchar(255)
)
RETURNS TABLE 
AS
RETURN 
(
SELECT
	bo.[Platform]
	, p.* 
	, IC = isnull(c.IC,0)
	, EC = isnull(c.EC,0)
	, [Synd Premium GIC] = p.[GNP inc IC] 
	, [Synd Premium NIC] = (p.[GNP inc IC] / (1-isnull(c.EC,0))) * (1-isnull(c.IC,0)-isnull(c.EC,0))
	, [GGP] = p.[GNP inc IC] / (1-isnull(c.EC,0))
FROM 
(
select GNP = sum(GNP), Department, OfficeChannel,InceptionMonth,PolicyType,ReviewCycle,TriFocus,yoa,TransactionCurency,ToLloyds,Host,tohost,Entity,ToSyndicate, [GNP inc IC] = sum([GNP inc IC]) from
	(
		SELECT GNP, Department, OfficeChannel,InceptionMonth,PolicyType,ReviewCycle,TriFocus,yoa,TransactionCurency,ToLloyds,Host,tohost,Entity,ToSyndicate, [GNP inc IC] FROM tf_PFT_SyndPremium(@cycle)
		UNION ALL
		SELECT GNP, Department, OfficeChannel,InceptionMonth,PolicyType,ReviewCycle,TriFocus,yoa,TransactionCurency,ToLloyds,Host,tohost,Entity,ToSyndicate, [GNP inc IC] FROM tf_PFT_BIDACPremium(@cycle)
		UNION ALL
		SELECT GNP, Department, OfficeChannel,InceptionMonth,PolicyType,ReviewCycle,TriFocus,yoa,TransactionCurency,ToLloyds,Host,tohost,Entity,ToSyndicate, [GNP inc IC] FROM tf_PFT_CedePremium(@cycle)
		UNION ALL
		SELECT GNP, Department, OfficeChannel,InceptionMonth,PolicyType,ReviewCycle,TriFocus,yoa,TransactionCurency,ToLloyds,Host,tohost,Entity,ToSyndicate, [GNP inc IC] FROM tf_PFT_USPremium(@cycle)
	) a group by Department, OfficeChannel,InceptionMonth,PolicyType,ReviewCycle,TriFocus,yoa,TransactionCurency,ToLloyds,Host,tohost,Entity,ToSyndicate

	--fix for tom h re issue with USBICI portion of unoverridden 
	UNION ALL
	(
		SELECT 
		GNP = CASE 
				WHEN t.TriFocusName like '%BICI%' AND pk_TransactionCurrency_9 = 'USD' AND sum(po.OverridePremium_0) <>0 then sum(p.GNP_0) - min([OverridePremium_0])
				ELSE sum(p.GNP_0)
				END
		  --,UserID = [UserID_1]
		  ,Department = [Department_2]
		  ,OfficeChannel = [pk_OfficeChannel_3]
		  ,InceptionMonth = [pk_InceptionMonth_4]
		  ,PolicyType = [pk_PolicyType_5]
		  ,ReviewCycle = [pk_ReviewCycle_6]
		  ,TriFocus = [pk_TriFocus_7]
		  ,YOA = [pk_YOA_8]
		  ,TransactionCurency = [pk_TransactionCurrency_9]
		  ,ToLloyds = 1
		  ,Host = 'USBICI'
		  ,ToHost = 1
		  ,Entity = 'USBICI'
		  ,ToSyndicate = 1
		  ,[GNP inc IC]= CASE 
				WHEN t.TriFocusName like '%BICI%' AND pk_TransactionCurrency_9 = 'USD' AND sum(po.OverridePremium_0) <>0 then sum(p.GNP_0) - min([OverridePremium_0])
				ELSE sum(p.GNP_0)
				END

	  FROM 
		[WriteTable_01 Premium] p 
		join
			(
				SELECT [OverridePremium_0] = sum( [OverridePremium_0])
					  ,[pk_ReviewCycle_1]
					  ,[pk_TriFocus_2]
					  ,[pk_YOA_3]
				  FROM [WriteTable_zOverridePremium]
						group by 
						[pk_ReviewCycle_1]
							  ,[pk_TriFocus_2]
							  ,[pk_YOA_3]
			) po on 
				p.[pk_ReviewCycle_6] = po.pk_ReviewCycle_1
				and p.[pk_TriFocus_7] = po.pk_TriFocus_2
				and p.[pk_YOA_8] = po.pk_YOA_3 
		join	FDM_DC.DimTriFocus t on p.pk_TriFocus_7 = t.pk_TriFocus
	  where 
		pk_ReviewCycle_6 = @cycle
		and pk_YOA_3 in ('2016', '2017', '2018')
		and [pk_TriFocus_7]<>'903'
	  group by 
			--[UserID_1]
		  [Department_2]
		  ,[pk_OfficeChannel_3]
		  ,[pk_InceptionMonth_4]
		  ,[pk_PolicyType_5]
		  ,[pk_ReviewCycle_6]
		  ,[pk_TriFocus_7]
		  ,t.TriFocusName
		  ,[pk_YOA_8]
		  ,[pk_TransactionCurrency_9]
		  --,[pk_InsertDate_10]

	)
-- end fix
) p 
left outer join	[FDM_DC].[vPFTCommission] c on p.PolicyType = c.PolicyType
				and p.ReviewCycle = c.ReviewCycle
				and p.YOA = c.YOA
				and p.TriFocus = c.TriFocus
				and p.OfficeChannel= c.OfficeChannel 
left outer join
			(
			SELECT        pk_OfficeChannel, OfficeChannelName, Platform
			FROM            FDM_DC.DimOfficeChannel
			WHERE        (pk_OfficeChannel <> 'BIUK')
			UNION
			SELECT        'BIFR' AS pk_OfficeChannel, 'France' AS OfficeChannelName, 'BID' AS Platform
			UNION
			SELECT        'BIDE' AS pk_OfficeChannel, 'Germany' AS OfficeChannelName, 'BID' AS Platform
			UNION
			SELECT        'BISP' AS pk_OfficeChannel, 'Spain' AS OfficeChannelName, 'BID' AS Platform
			UNION
			SELECT        'BIUK' AS pk_OfficeChannel, 'UK' AS OfficeChannelName, 'BID' AS Platform
			UNION
			SELECT        'BISW' AS pk_OfficeChannel, 'Switzerland' AS OfficeChannelName, 'BID' AS Platform
			UNION
			SELECT        'USBAIC' AS pk_OfficeChannel, 'USBAIC' AS OfficeChannelName, 'USA' AS Platform
			) bo on isnull(p.OfficeChannel,'LDN') = bo.pk_OfficeChannel

)
GO

