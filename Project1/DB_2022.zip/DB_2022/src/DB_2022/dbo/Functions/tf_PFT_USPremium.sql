﻿-- =============================================
-- Author:		Dave Grant
-- Create date: 11/09/2018
-- Description:	US Premium from PFT cube writeback tables 
-- =============================================

CREATE FUNCTION [dbo].[tf_PFT_USPremium] 
(	
	@cycle nvarchar(255)
)
RETURNS TABLE 
AS
RETURN 
(
select 
	rp.* 
	, ToLloyds = 1 - tl.ToLloyds
	, Host = 'USBICI'
	, ToHost = 1
	, Entity = 'USBICI'
	, ToSyndicate = 1
	, [GNP inc IC] = gnp*(1 - isnull(tl.ToLloyds,0))
from 
	tf_PFT_RawPremium(@cycle) rp left outer join
	FDM_DC.vFactToLloyds tl on 
		rp.ReviewCycle = tl.ReviewCycle
		and rp.TriFocus = tl.TriFocus
		and rp.YOA = tl.YOA 
where (gnp*(1 - isnull(tl.ToLloyds,0))) <>0 
)
GO

