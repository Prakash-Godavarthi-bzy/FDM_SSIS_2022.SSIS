﻿
-- =============================================
-- Author:		Nanda Gottumukkala
-- Create date: 02/10/2015
-- Description:	To retrieve LastProcessedID
-- =============================================
CREATE FUNCTION [dbo].[udf_WhiteSpace] (@IntChars int)  
RETURNS varchar(100) AS  
BEGIN 

       Return(LEFT('                                                                                                    ',@IntChars))

END
