﻿


-- =============================================
-- Author:		Dave Grant
-- Create date: 11/09/2018
-- Description:	get raw non allocated premium from PFT cube writeback tables
-- =============================================
CREATE FUNCTION [dbo].[tf_PFT_RawPremium]
(	
	@cycle nvarchar(255)
)
RETURNS TABLE 
AS
RETURN 
(
SELECT GNP = CASE 
			WHEN t.TriFocusName like '%BICI%' AND pk_TransactionCurrency_9 = 'USD' AND sum(po.OverridePremium_0) <>0 then min([OverridePremium_0])
			ELSE sum(p.GNP_0)
			END
      --,UserID = [UserID_1]
      ,Department = [Department_2]
      ,OfficeChannel = [pk_OfficeChannel_3]
      ,InceptionMonth = [pk_InceptionMonth_4]
      ,PolicyType = [pk_PolicyType_5]
      ,ReviewCycle = [pk_ReviewCycle_6]
      ,TriFocus = [pk_TriFocus_7]
      ,YOA = [pk_YOA_8]
      ,TransactionCurency = [pk_TransactionCurrency_9]
      --,InsertDate = [pk_InsertDate_10]
  FROM 
	[WriteTable_01 Premium] p left outer join
	(
		SELECT [OverridePremium_0] = sum( [OverridePremium_0])
			  ,[pk_ReviewCycle_1]
			  ,[pk_TriFocus_2]
			  ,[pk_YOA_3]
		  FROM [WriteTable_zOverridePremium]
				group by 
				[pk_ReviewCycle_1]
					  ,[pk_TriFocus_2]
					  ,[pk_YOA_3]
	) po on 
		p.[pk_ReviewCycle_6] = po.pk_ReviewCycle_1
		and p.[pk_TriFocus_7] = po.pk_TriFocus_2
		and p.[pk_YOA_8] = po.pk_YOA_3 join
	FDM_DC.DimTriFocus t on p.pk_TriFocus_7 = t.pk_TriFocus
  where 
	pk_ReviewCycle_6 = @cycle

  group by 
		--[UserID_1]
      [Department_2]
      ,[pk_OfficeChannel_3]
      ,[pk_InceptionMonth_4]
      ,[pk_PolicyType_5]
      ,[pk_ReviewCycle_6]
      ,[pk_TriFocus_7]
	  ,t.TriFocusName
      ,[pk_YOA_8]
      ,[pk_TransactionCurrency_9]
      --,[pk_InsertDate_10]

union 
SELECT 
	GNP = sum( [OverridePremium_0])
	--,UserID = 'OVERRIDE'
	,Department = t.Department
	,OfficeChannel = 'LDN'
	,InceptionMonth = 1
	,PolicyType = 'Policy'
	,ReviewCycle = [pk_ReviewCycle_1]
	,TriFocus = [pk_TriFocus_2]
	,YOA = [pk_YOA_3]
	,TransactionCurency = 'USD'
	--,InsertDate = convert(nvarchar(255),max(ms_audit_time_4),112)
	
FROM 
	[WriteTable_zOverridePremium] op join
	FDM_DC.DimTriFocus t on op.pk_TriFocus_2 = t.pk_TriFocus
where 	
	CONCAT(pk_TriFocus_2, '-', pk_ReviewCycle_1, '-', pk_YOA_3) not in (select distinct CONCAT(pk_TriFocus_7, '-',pk_ReviewCycle_6 ,'-',pk_YOA_8 ) from [WriteTable_01 Premium])
	and pk_ReviewCycle_1 = @cycle
group by 
	[pk_ReviewCycle_1]
	,[pk_TriFocus_2]
	,t.pk_TriFocus
	,t.Department
	,[pk_YOA_3]


)
