﻿

-- =============================================
-- Author:		Nanda Gottumukkala
-- Create date: 02/10/2015
-- Description:	To retrieve LastProcessedID
-- =============================================
CREATE FUNCTION [dbo].[usf_getProcessingID] 
(
	@TableName as VARCHAR(255)
)
RETURNS BIGINT
AS
BEGIN

	DECLARE @ExecutionLog table(
    ExecutionID int NOT NULL,
    LastInsertedID bigint,
    TableName VARCHAR(255)
	)

	INSERT INTO @ExecutionLog
		SELECT	TOP 2 ExecutionID,LastInsertedID,TableName
		FROM	[FDM_DB].[dbo].[ExecutionLog]
		WHERE	TableName = @TableName
		ORDER	BY ExecutionID DESC
	DECLARE @LastInsertedID AS BIGINT

	SELECT @LastInsertedID = LastInsertedID
	FROM @ExecutionLog WHERE ExecutionID = (SELECT MIN(ExecutionID) FROM @ExecutionLog)
	IF @LastInsertedID = 0 
		SET @LastInsertedID= 999999999999
	RETURN @LastInsertedID

END
