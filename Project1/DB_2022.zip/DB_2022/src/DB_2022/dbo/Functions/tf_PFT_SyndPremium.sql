﻿-- =============================================
-- Author:		Dave Grant
-- Create date: 11/09/2018
-- Description:	get syndicate specific premium from PFT cube writeback tables
-- =============================================
CREATE FUNCTION [dbo].[tf_PFT_SyndPremium]
(	
	@cycle nvarchar(255)
)
RETURNS TABLE 
AS
RETURN 
(
select 
	rp.* 
	, tl.ToLloyds
	, th.Host
	, th.ToHost
	, ts.Entity
	, ts.ToSyndicate
	, [GNP inc IC] = gnp*tl.ToLloyds*th.ToHost* ts.ToSyndicate
from 
	tf_PFT_RawPremium(@cycle) rp left outer join
	FDM_DC.vFactToLloyds tl on 
		rp.ReviewCycle = tl.ReviewCycle
		and rp.TriFocus = tl.TriFocus
		and rp.YOA = tl.YOA left outer join
	FDM_DC.vFactToHost th on 
		rp.ReviewCycle = th.ReviewCycle
		and rp.TriFocus = th.TriFocus
		and rp.YOA = th.YOA left outer join
	FDM_DC.vFactToSyndicate ts on
		rp.ReviewCycle = ts.ReviewCycle
		and rp.YOA = ts.YOA
		and th.Host = ts.Host
where (gnp*tl.ToLloyds*th.ToHost* ts.ToSyndicate) <>0 and rp.OfficeChannel not like 'BI%' and th.Host not in ('6050', '6107')
)
GO


