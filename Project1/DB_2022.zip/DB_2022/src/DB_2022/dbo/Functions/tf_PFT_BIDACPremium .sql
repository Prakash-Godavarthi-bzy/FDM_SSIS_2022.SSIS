﻿-- =============================================
-- Author:		Dave Grant
-- Create date: 11/09/2018
-- Description:	get BIDAC specific premium from PFT cube writeback tables
-- =============================================
CREATE FUNCTION [dbo].[tf_PFT_BIDACPremium] 
(	
	@cycle nvarchar(255)
)
RETURNS TABLE 
AS
RETURN 
(
select 
	* 
	, ToLloyds = 1
	, Host = OfficeChannel
	, ToHost = 1
	, Entity = OfficeChannel
	, ToSyndicate = 1
	, [GNP inc IC] = GNP
from 
	tf_PFT_RawPremium(@cycle)    
where 
	OfficeChannel like 'BI%'
	OR
	officeChannel like 'USBAIC'

)
GO

