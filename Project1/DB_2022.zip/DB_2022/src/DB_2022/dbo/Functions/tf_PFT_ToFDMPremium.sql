﻿-- =============================================
-- Author:		Dave Grant
-- Create date: 11/09/2018
-- Description:	format and align PFT data to FDM staging
-- =============================================

CREATE FUNCTION [dbo].[tf_PFT_ToFDMPremium] 
(	
	@cycle nvarchar(255)
)
RETURNS TABLE 
AS
RETURN 
(
select 
	[PremiumForecastPremiumStageId] = ROW_NUMBER() OVER(ORDER BY Period asc)
	,* 
from
(
select  
	[Period] 
    ,[AccountingPeriod] 
    ,[YOA]
    ,[EntityRISideCar]
    ,[Entity] = case when [Entity] = 'BIDE' then 'BIGE' else [Entity] end
    ,[TrifocusCode] 
    ,[MoP] 
    ,[InceptionDate] 
    ,[InceptionMonth]
    ,[Currency] 
    ,[GrossGrossPremium]=sum([GrossGrossPremium])
    ,[ExternalBrokerage]=sum([ExternalBrokerage])
    ,[InternalCommission]=sum([InternalCommission])
    ,[GrossNetPremium]=sum([GrossNetPremium])
from
(
select
	[Period] = replace(ReviewCycle, 'Q', '.')
    ,[AccountingPeriod] = left(convert(nvarchar(255),datefromparts(left(ReviewCycle, 4), right(ReviewCycle, 1)*3,1), 112),6)
    ,[YOA]
    ,[EntityRISideCar] = null
    ,[Entity]
    ,[TrifocusCode] = Trifocus
    ,[MoP] = case when PolicyType = 'Policy' then cast('P' as nvarchar(1)) else cast('B' as nvarchar(1)) END
    ,[InceptionDate] = datefromparts(YOA, InceptionMonth,15)
    ,[InceptionMonth]
    ,[Currency] = TransactionCurency
    ,[GrossGrossPremium] = -1 * GGP
    ,[ExternalBrokerage] = -1 * ([GNP inc IC]-GGP)
    ,[InternalCommission] = -1 * ( [Synd Premium NIC] - [GNP inc IC] )
    ,[GrossNetPremium] = -1 * [GNP inc IC]
from [dbo].[tf_PFT_CombinedPremiumIncCede](@cycle) 
where Host not in  ('6050', '6107')

UNION ALL
select 
	[Period] = replace(ReviewCycle, 'Q', '.')
    ,[AccountingPeriod] = left(convert(nvarchar(255),datefromparts(left(ReviewCycle, 4), right(ReviewCycle, 1)*3,1), 112),6)
    ,[YOA]
    ,[EntityRISideCar] = Entity
    ,[Entity] = Host
    ,[TrifocusCode] = Trifocus
    ,[MoP] = case when PolicyType = 'Policy' then 'P' else 'B' END
    ,[InceptionDate] = datefromparts(YOA, InceptionMonth,15)
    ,[InceptionMonth]
    ,[Currency] = TransactionCurency
    ,[GrossGrossPremium] = GGP
    ,[ExternalBrokerage] = ([GNP inc IC]-GGP)
    ,[InternalCommission] = ( [Synd Premium NIC] - [GNP inc IC] )
    ,[GrossNetPremium] = [GNP inc IC]
from [dbo].[tf_PFT_CombinedPremiumIncCede](@cycle) 
where Host in ('6050', '6107') and Entity not in ('6050', '6107')
) a group by
	[Period] 
    ,[AccountingPeriod] 
    ,[YOA]
    ,[EntityRISideCar]
    ,[Entity]
    ,[TrifocusCode] 
    ,[MoP] 
    ,[InceptionDate] 
    ,[InceptionMonth]
    ,[Currency]
) b
)
GO

