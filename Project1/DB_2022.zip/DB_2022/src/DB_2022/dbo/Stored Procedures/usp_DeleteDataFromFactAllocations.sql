﻿


-- =============================================
-- Author:		<Nanda Gottumukkala>
-- Create date: <13/11/2015>
-- Description:	<Description>
-- =============================================

CREATE PROCEDURE [dbo].[usp_DeleteDataFromFactAllocations]
@Adhoc AS BIT
,@IntraDay AS BIT
,@AccountingPeriod AS VARCHAR(10)
,@AllocationGroup AS VARCHAR(255)
,@Client AS VARCHAR(50)
AS
BEGIN
--DECLARE @Adhoc AS BIT = 1
--,@IntraDay AS BIT = 0
--,@AccountingPeriod AS INT = 201506
--,@AllocationGroup AS VARCHAR(255) = 'Expenses'
DECLARE	@TriggersChanged int
IF OBJECT_ID('tempdb.dbo.#PeriodsToDelete', 'U') IS NOT NULL
	DROP TABLE #PeriodsToDelete;

IF OBJECT_ID('tempdb.dbo.#AllocationGroupToDelete', 'U') IS NOT NULL
	DROP TABLE #AllocationGroupToDelete;

CREATE TABLE #PeriodsToDelete (
		AccountPeriod VARCHAR(100)
		)
CREATE TABLE #AllocationGroupToDelete (
		AllocationGroup VARCHAR(100)
		)

SELECT @TriggersChanged= [dbo].[usf_getTriggerChangedStatus] (@AllocationGroup,'')

IF @Adhoc = 1 
	BEGIN
		;WITH CTE_Periods AS (
		SELECT CAST([AccountingPeriod] AS INT) AS [AccountingPeriod]
		FROM [dbo].[DimAccountingPeriod]
		WHERE AccountingMonth BETWEEN 1 AND 12 AND AccountingYear = @AccountingPeriod
		UNION 
		SELECT   CAST([AccountingPeriod] AS INT) AS  [AccountingPeriod] 
		FROM [dbo].[DimAccountingPeriod] 
		WHERE  AccountingPeriod = @AccountingPeriod
		)
		INSERT INTO #PeriodsToDelete 
		SELECT * FROM CTE_Periods
	END
ELSE 
	BEGIN 
		INSERT INTO #PeriodsToDelete
		SELECT   CAST([AccountingPeriod] AS INT) AS  [AccountingPeriod]  
		FROM [dbo].[DimAccountingPeriod] 
		WHERE  AccountingPeriod = CAST(YEAR(GETDATE()) AS varchar)+CASE WHEN LEN(CAST(MONTH(GETDATE()) AS varchar)) =1 THEN '0'+CAST(MONTH(GETDATE()) AS varchar) ELSE CAST(MONTH(GETDATE()) AS varchar) END
		
	END

IF @Adhoc = 1 AND @AllocationGroup <> ''
	BEGIN 
		INSERT INTO #AllocationGroupToDelete
		SELECT	DISTINCT AllocationGroup
		FROM	dbo.DimAllocationRules
		WHERE	[AllocationGroup] IN (@AllocationGroup)
	END
ELSE IF @Intraday = 0 AND @Adhoc = 0
	BEGIN 
		INSERT INTO #AllocationGroupToDelete
		SELECT [AllocationGroup]  FROM RealTimeAllocations
	END

DELETE	FROM DimAllocationTransactionDetailsV2
FROM	DimAllocationTransactionDetailsV2 d
JOIN	VW_FACTAllocationV1_Total f
ON		d.pk_FactAllocation = f.pk_FACTAllocations
JOIN	dbo.DimAllocationRules sv
--ON		sv.PK_AllocationRules = f.FK_AllocationRules
ON		sv.PK_Alt_AllocationRules = f.FK_AllocationRules
JOIN	#PeriodsToDelete p
ON		p.AccountPeriod = f.fk_AccountingPeriod
JOIN	#AllocationGroupToDelete ag
ON		ag.AllocationGroup = sv.AllocationGroup
JOIN    DimClient c 
ON		c.pk_Client = f.fk_Client
JOIN	DimScenario on pk_Scenario = fk_Scenario
WHERE	ScenarioCode = @Client or FriendlyName = @Client


DELETE	FROM FACTAllocationsV1_Current
FROM	FACTAllocationsV1_Current f
JOIN	dbo.DimAllocationRules sv
--ON		sv.PK_AllocationRules = f.FK_AllocationRules
ON		sv.PK_Alt_AllocationRules = f.FK_AllocationRules
JOIN	#PeriodsToDelete p
ON		p.AccountPeriod = f.fk_AccountingPeriod
JOIN	#AllocationGroupToDelete ag
ON		ag.AllocationGroup = sv.AllocationGroup
JOIN    DimClient c 
ON		c.pk_Client = f.fk_Client
JOIN	DimScenario on pk_Scenario = fk_Scenario
WHERE	ScenarioCode = @Client or FriendlyName = @Client


DELETE	FROM FACTAllocationsV1_History
FROM	FACTAllocationsV1_History f
JOIN	dbo.DimAllocationRules sv
--ON		sv.PK_AllocationRules = f.FK_AllocationRules
ON		sv.PK_Alt_AllocationRules = f.FK_AllocationRules
JOIN	#PeriodsToDelete p
ON		p.AccountPeriod = f.fk_AccountingPeriod
JOIN	#AllocationGroupToDelete ag
ON		ag.AllocationGroup = sv.AllocationGroup
JOIN    DimClient c 
ON		c.pk_Client = f.fk_Client
JOIN	DimScenario on pk_Scenario = fk_Scenario
WHERE	ScenarioCode = @Client or FriendlyName = @Client

IF OBJECT_ID('tempdb.dbo.#PeriodsToDelete', 'U') IS NOT NULL
	DROP TABLE #PeriodsToDelete;

IF OBJECT_ID('tempdb.dbo.#AllocationGroupToDelete', 'U') IS NOT NULL
	DROP TABLE #AllocationGroupToDelete;


END
