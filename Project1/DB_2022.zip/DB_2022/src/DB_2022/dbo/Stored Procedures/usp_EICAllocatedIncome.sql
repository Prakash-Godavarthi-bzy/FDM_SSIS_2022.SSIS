﻿
-- =============================================
-- Author:		Nanda Gottumukkala
-- Create date: 14/11/2017
-- Description:	Allocate Investment Income for EIC
-- =============================================
CREATE PROCEDURE [dbo].[usp_EICAllocatedIncome] 
	@AccountingPeriod  VARCHAR(50),
	@AccountingYear   VARCHAR(50)
AS
BEGIN

DECLARE @OpeningPeriod AS int = @AccountingYear+''+'00'

IF OBJECT_ID (N'tempdb.dbo.#EICInvestmentProcessing', N'U') IS NOT NULL
	DROP TABLE #EICInvestmentProcessing

IF OBJECT_ID (N'tempdb.dbo.#JournalPrep', N'U') IS NOT NULL
	DROP TABLE #JournalPrep


IF OBJECT_ID (N'tempdb.dbo.#EICInvestmentIncomeBranch', N'U') IS NOT NULL
DROP TABLE #EICInvestmentIncomeBranch
	

CREATE TABLE #EICInvestmentProcessing(
	[AccountingPeriod]  INT NULL,
	[TrifocusCode] [varchar](50) NULL,
	[EntityCode] [varchar](50) NULL,
	[AccountCode] [varchar](50) NULL,
	[ConvertedAmount] [decimal](28, 10) NULL,
	[Module] [varchar](50) NULL,
	[OutputName] [varchar](50) NULL
)

INSERT INTO #EICInvestmentProcessing
SELECT [AccountingPeriod.AccountingPeriod.AccountingPeriod]
	  ,NULL AS [TrifocusCode]
	  ,[Entity.EntityCode.EntityCode]
      ,[Account.AccountCode.AccountCode]
      ,[Measures.ConvertedAmount]
      ,[Module]
      ,[OutputName]
  FROM [$(staging_agresso)].[dbo].[StageMDXResults]

CREATE TABLE #EICInvestmentIncomeBranch(
	[EntityCode] [varchar](50) NULL,
	[InterCompanyDebitorAccount] [varchar](50) NULL,
	[SCR] [decimal](28, 10) NULL,
	[AVGInterComapnyBalance] [decimal](28, 10) NULL,
	[OpeningReatinedEarnings] [decimal](28, 10) NULL,
	[AVGNetInvestReturn] [decimal](28, 10) NULL,
	[TotalInvestment] AS (ISNULL([SCR],0)+ISNULL([AVGInterComapnyBalance],0)+ISNULL([OpeningReatinedEarnings],0)),
	[InvestIncomeForBranch] AS ((ISNULL([SCR],0)+ISNULL([AVGInterComapnyBalance],0)+ISNULL([OpeningReatinedEarnings],0))*ISNULL([AVGNetInvestReturn],0))
) 

INSERT INTO #EICInvestmentIncomeBranch
           ([EntityCode]
		   ,InterCompanyDebitorAccount
           ,SCR
		   ,AVGInterComapnyBalance
		   ,[OpeningReatinedEarnings])
SELECT s.EntityCode,s.InterCompanyDebitorAccount,CAST(ISNULL([SCR],0) AS [decimal](28, 10)),AVGInterComapnyBalance,OpeningRetaineEarnings
FROM FDM_DB.dbo.BIDACSCR s
LEFT JOIN (	SELECT EntityCode,AVG([ConvertedAmount]) AVGInterComapnyBalance 
			FROM #EICInvestmentProcessing
			WHERE OutputName = 'AvgIntercomanyBalance'
			AND AccountingPeriod <=@AccountingPeriod
			GROUP BY EntityCode
) a ON a.EntityCode = s.EntityCode
LEFT JOIN ( SELECT EntityCode,([ConvertedAmount]) OpeningRetaineEarnings 
			FROM #EICInvestmentProcessing
			WHERE OutputName = 'OpeningRetaineEarnings'
			AND AccountingPeriod =@OpeningPeriod
) b ON b.EntityCode = s.EntityCode


;WITH CTE1 AS (
SELECT EntityCode,SUM(([ConvertedAmount]))  AS InvestmentIncomeGainsBERE
FROM #EICInvestmentProcessing
WHERE OutputName = 'InvestmentIncomeGainsBERE'
GROUP BY EntityCode
)
,CTE2 AS (
SELECT EntityCode,SUM(([ConvertedAmount]))  AS CashAndInvestmentAssests
FROM #EICInvestmentProcessing
WHERE OutputName = 'CashAndInvestmentAssests'
GROUP BY EntityCode
)

UPDATE #EICInvestmentIncomeBranch
SET [AVGNetInvestReturn] = (
SELECT ABS((CTE1.InvestmentIncomeGainsBERE/CTE2.CashAndInvestmentAssests))
FROM CTE1
LEFT JOIN CTE2
ON CTE1.EntityCode = CTE2.EntityCode
)



SELECT * ,AccountPercentage*InvestIncomeForBranch AS AllocatedIncome
INTO #JournalPrep
FROM #EICInvestmentIncomeBranch
CROSS APPLY(
SELECT b.AccountingPeriod,b.EntityCode AS HOEntityCode ,AccountCode AS PNLAccountCode,ConvertedAmount/ABS(TotalConvertedAmount) AS AccountPercentage
FROM #EICInvestmentProcessing b
JOIN (	SELECT AccountingPeriod,EntityCode,OutputName,SUM(ConvertedAmount) TotalConvertedAmount
		FROM #EICInvestmentProcessing
		WHERE OutputName = 'InvestmentIncomeGainsBERE'
		GROUP BY AccountingPeriod,EntityCode,OutputName
 ) a
ON b.EntityCode = a.EntityCode
AND b.OutputName = a.OutputName
WHERE b.OutputName = 'InvestmentIncomeGainsBERE'
) c

SELECT	AccountingPeriod,
		EntityCode,
		PNLAccountCode,
		AllocatedIncome
FROM	#JournalPrep
UNION
SELECT  DISTINCT AccountingPeriod,
		HOEntityCode,
		InterCompanyDebitorAccount,
		InvestIncomeForBranch
FROM	#JournalPrep
UNION
SELECT  DISTINCT AccountingPeriod,
		EntityCode,
		'74530',
		InvestIncomeForBranch
FROM	#JournalPrep
UNION
SELECT  AccountingPeriod,
		HOEntityCode,
		InterCompanyDebitorAccount,
		AllocatedIncome
FROM	#JournalPrep

END

