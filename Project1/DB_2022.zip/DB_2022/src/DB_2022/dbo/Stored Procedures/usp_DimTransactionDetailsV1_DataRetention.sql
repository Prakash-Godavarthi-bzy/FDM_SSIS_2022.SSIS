﻿CREATE PROCEDURE [dbo].[usp_DimTransactionDetailsV1_DataRetention]	
AS
BEGIN
	SET NOCOUNT ON		
		
		/***********************Getting Retention period config values ****************************************************/
		DECLARE @RetentionPeriod INT,@RetentionPeriodType VARCHAR(50),@RowsPerBatch INT,@RetentionConfigId INT

		SELECT @RetentionPeriod = RetentionPeriod
		     , @RetentionPeriodType = RetentionPeriodType
			 , @RowsPerBatch = RowsPerBatch 
			 , @RetentionConfigId = DataRetentionConfigId
		  FROM FDM_PROCESS.[Admin].[DataRetentionConfig] 
		 WHERE TableName = 'DimTransactionDetailsV1_Current'
		
		SET @RetentionPeriod = ISNULL(@RetentionPeriod,0)
			
		DECLARE @RetentionDate DATE
		SET @RetentionDate = DATEADD(DD,-(@RetentionPeriod), GETDATE()) 
		
		IF (@RetentionPeriodType = 'Days') 
			SET @RetentionDate = DATEADD(DD,-(@RetentionPeriod), GETDATE())
		ELSE IF (@RetentionPeriodType = 'Weeks')
			SET @RetentionDate = DATEADD(WK,-(@RetentionPeriod), GETDATE())
		ELSE IF (@RetentionPeriodType = 'Months')
			SET @RetentionDate = DATEADD(MM,-(@RetentionPeriod), GETDATE())
		ELSE IF (@RetentionPeriodType = 'Years')
			SET @RetentionDate = DATEADD(YY,-(@RetentionPeriod), GETDATE())
		ELSE 
			SET @RetentionDate = DATEADD(DD,-(@RetentionPeriod), GETDATE())
		
		--SELECT @RetentionDate
		--SELECT @RetentionPeriod,@RetentionPeriodType,@RowsPerBatch
		/***************DimTransactionDetailsV1_Current table will contain data for specified retention period ************************/
			
		IF(OBJECT_ID('tempdb..#DimTransactionDetailsV1_Current') IS NOT NULL)
			DROP TABLE #DimTransactionDetailsV1_Current

		SELECT A.*,ROW_NUMBER() OVER (ORDER BY A.pk_FactFDM) AS RowId
		INTO #DimTransactionDetailsV1_Current
		FROM --dbo.DimTransactionDetailsV1_Current A
			 ( 
				SELECT *
				  FROM dbo.DimTransactionDetailsV1_Current			
				 WHERE insert_date < @RetentionDate			  
			 ) AS A
		  LEFT JOIN dbo.DimTransactionDetailsV1_History C
			ON A.pk_FactFDM = C.pk_FactFDM
		 WHERE C.pk_FactFDM IS NULL

		DECLARE @BatchSize INT,@TotalRowsCount INT,@loopCount INT,@StartId INT,@EndId INT,@LoopBatchrowcnt int
		DECLARE @StartTime DATETIME,@EndTime DATETIME
		SET @StartTime = GETDATE()

		SET @BatchSize = ISNULL(@RowsPerBatch,10000)
				
		SET @TotalRowsCount = (SELECT COUNT(1) FROM #DimTransactionDetailsV1_Current)
		
		SET @loopCount = 1
		SET @StartId = 1
		SET @EndId = @BatchSize
		
BEGIN TRY

	WHILE (@loopCount < @TotalRowsCount)
		
		BEGIN

		BEGIN TRAN

		SET @StartTime = GETDATE()

			--SELECT MIN(RowId) AS MINID,MAX(RowId) AS MAXID FROM #DimTransactionDetailsV1_Current WHERE RowId BETWEEN @StartId AND @EndId

			INSERT INTO dbo.DimTransactionDetailsV1_History (pk_FactFDM,bk_TransactionID,[Description],ExtRef,ExtInvRef,Dim1,Dim2,	Dim3,Dim4,Dim5,Dim6,Dim7
				 , VoucherNumber,insert_date,ap_ar_id,ap_ar_type,tax_code,tax_system,AccountCode,ProcessCode,AccountingPeriod
				 , CombinationID,MCVoucherNumber,transaction_date)
			SELECT pk_FactFDM,bk_TransactionID,[Description],ExtRef,ExtInvRef,Dim1,Dim2,	Dim3,Dim4,Dim5,Dim6,Dim7
				 , VoucherNumber,insert_date,ap_ar_id,ap_ar_type,tax_code,tax_system,AccountCode,ProcessCode,AccountingPeriod
				 , CombinationID,MCVoucherNumber,transaction_date
			  FROM  #DimTransactionDetailsV1_Current T WHERE RowId BETWEEN @StartId AND @EndId


			  SET @LoopBatchrowcnt=@@ROWCOUNT
		
			/*******************************Delete last week data *************************************/
			
			--SELECT A.*
			 DELETE A
			 FROM dbo.DimTransactionDetailsV1_Current A
			 INNER JOIN #DimTransactionDetailsV1_Current B
			 ON A.pk_FactFDM = B.pk_FactFDM 
			 WHERE RowId BETWEEN @StartId AND @EndId	
			 
			 SET @EndTime = GETDATE()
	
			 INSERT INTO FDM_PROCESS.[Admin].[DataRetentionLog] (fk_DataRetentionConfigId,StartTime,EndTime,[RowCount],CreatedDate,CreatedBy,ActionType)
			 SELECT @RetentionConfigId,@StartTime,@EndTime,@LoopBatchrowcnt,GETDATE(),null,'Moved data to History table'

			 SET @LoopBatchrowcnt=0

			 SET @loopCount += @BatchSize;
			 SET @StartId = @EndId + 1 ;
			 SET @EndId = @StartId + @BatchSize - 1;

		Commit Tran
	END

	IF(@TotalRowsCount=0)
	BEGIN
	
		SET @StartTime=GETDATE()
		SET @EndTime=GETDATE()

		INSERT INTO FDM_PROCESS.[Admin].[DataRetentionLog] (fk_DataRetentionConfigId,StartTime,EndTime,[RowCount],CreatedDate,CreatedBy,ActionType)
		SELECT @RetentionConfigId,@StartTime,@EndTime,@TotalRowsCount,GETDATE(),null,'Moved data to History table'
	END

END TRY
	BEGIN CATCH
		IF @@TRANCOUNT>0 
			
			ROLLBACK Tran

				SET @LoopBatchrowcnt=0
	
				SET @EndTime = GETDATE()

				INSERT INTO FDM_PROCESS.[Admin].[DataRetentionLog] (fk_DataRetentionConfigId,StartTime,EndTime,[RowCount],CreatedDate,CreatedBy,ActionType)
				SELECT @RetentionConfigId,@StartTime,@EndTime,@LoopBatchrowcnt,GETDATE(),NULL,SUBSTRING(ERROR_MESSAGE(),1,255)
	END CATCH;
END
