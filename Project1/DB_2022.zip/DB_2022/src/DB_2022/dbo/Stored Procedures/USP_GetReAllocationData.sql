﻿



-- =============================================
-- Author:		<Nanda Gottumukkala>
-- Create date: <13/11/2015>
-- Description:	<Description>
-- =============================================

CREATE PROCEDURE [dbo].[USP_GetReAllocationData] @AllocationCode AS VARCHAR(255)
,@ReAllocationStartID AS BIGINT
,@MaxID AS BIGINT
,@AllocationGroup AS VARCHAR(255)
AS
BEGIN
 

--SET @AllocationCode = 'I2'
--SET @AllocationGroup = 'Investments'
--SET @ReAllocationStartID = -45688963
--SET @MaxID = -45693062

IF  OBJECT_ID('tempdb.dbo.#CTE1') is not null
DROP TABLE #CTE1

IF  OBJECT_ID('tempdb.dbo.#CTE2') is not null
DROP TABLE #CTE2

SELECT * INTO #CTE1 FROM	[dbo].[DimAllocationTransactionDetailsV2](nolock)
WHERE pk_FACTAllocation < @ReAllocationStartID  AND pk_FACTAllocation >= @MaxID
AND SoftDeleteFlag = 0


SELECT b.AllocationCode
		,b.FK_AllocationRules 
		,b.AllocationPercent AS AllocationPercent
		,RTRIM(LTRIM(b.AccountDest)) AccountDest
		,RTRIM(LTRIM(b.LocationDest)) LocationDest
		,RTRIM(LTRIM(b.EntityDest)) EntityDest
		,RTRIM(LTRIM(b.YOADest)) YOADest
		,RTRIM(LTRIM(b.ProcessDest)) ProcessDest
		,RTRIM(LTRIM(b.ProjectDest)) ProjectDest
		,RTRIM(LTRIM(b.TriFocusDest)) AS TriFocusDest
                                     ,RTRIM(LTRIM(b.TargetCurrencyDest)) AS TargetCurrencyDest
		,RTRIM(LTRIM(b.TargetEntityDest)) AS TargetEntityDest
		,RTRIM(LTRIM(b.TargetPeriodDest)) AS TargetPeriodDest
		,1 AS RuleApplicable
		,CombinationID
		 INTO #CTE2
FROM	BriExpensesTransactionDetailsV4 b(nolock)
JOIN	DimAllocationRules c
--ON		c.PK_AllocationRules = b.FK_AllocationRules
ON		c.PK_Alt_AllocationRules = b.FK_AllocationRules

--LEFT	JOIN	(
--		SELECT	MIN(a.AccountFrom) AccountFrom 
--				,MAX(a.AccountTo) AccountTo 
--				,1 AS Applicable
--		FROM	dbo.DimAllocationRules a
--                                      Where a.AccountFrom <>  'Unknown'
--) d
--ON		b.AccountDest BETWEEN d.AccountFrom and d.AccountTo 
WHERE	b.AllocationCode = @AllocationCode
AND		c.AllocationGroup = @AllocationGroup
AND isCurrent =1

SELECT	DISTINCT pk_FactAllocation AS pk_FactFDM
		,a.CombinationID
        ,b.AllocationCode
		,b.FK_AllocationRules AS RuleID
		,b.AllocationPercent AS AllocationPercent
		,RTRIM(LTRIM(b.AccountDest)) AccountDest
		,RTRIM(LTRIM(b.LocationDest)) LocationDest
		,RTRIM(LTRIM(b.EntityDest)) EntityDest
		,RTRIM(LTRIM(b.YOADest)) YOADest
		,RTRIM(LTRIM(b.ProcessDest)) ProcessDest
		,RTRIM(LTRIM(b.ProjectDest)) ProjectDest
		,RTRIM(LTRIM(b.TriFocusDest)) AS TriFocusDest
        ,RTRIM(LTRIM(b.TargetCurrencyDest)) AS TargetCurrencyDest
		,RTRIM(LTRIM(b.TargetEntityDest)) AS TargetEntityDest
		,RTRIM(LTRIM(b.TargetPeriodDest)) AS TargetPeriodDest
		,RuleApplicable
FROM	#CTE1 a
JOIN	#CTE2 b(nolock)
ON		a.CombinationID = b.CombinationID
ORDER	BY pk_FactAllocation

IF  OBJECT_ID('tempdb.dbo.#CTE1') is not null
DROP TABLE #CTE1

IF  OBJECT_ID('tempdb.dbo.#CTE2') is not null
DROP TABLE #CTE2
END

--EXEC USP_GetReAllocationData @AllocationCode = 'I2'
--,@AllocationGroup = 'Investments'
--,@ReAllocationStartID = -45688963
--,@MaxID = -45693062

