﻿


-- =============================================
-- Author:		<Nanda Gottumukkala>
-- Create date: <13/11/2015>
-- Description:	<Description>
-- =============================================

CREATE PROCEDURE [dbo].[usp_GetEPIDeltaOnLTD]
	@IncrementedLoadID AS VARCHAR(100)
AS
BEGIN

DECLARE @i int = 0 

DECLARE	@LastLoadID INT, @CurrentLoadID INT, @curLoadID int, @LoadID int
SELECT	@curLoadID = ISNULL(MAX(LoadID),0) FROM [Eurobase].[EuroBaseExtract]

DECLARE	db_cursor CURSOR FOR  
SELECT	Distinct TOP 2  LOADID FROM [Eurobase].[EuroBaseExtract]
WHERE	LoadID <=@IncrementedLoadID
ORDER	BY LoadID DESC

OPEN	db_cursor   
FETCH	NEXT FROM db_cursor INTO @LoadID

WHILE	@@FETCH_STATUS = 0   
BEGIN  
		SET	@i = @i+1
		IF @i =1 
		BEGIN
			SET @CurrentLoadID = @LoadID
		END
		ELSE IF @i =2
		BEGIN
			SET @LastLoadID = @LoadID
		END
		FETCH NEXT FROM db_cursor INTO @LoadID
END   
CLOSE	db_cursor   
DEALLOCATE db_cursor

--To handle first load or if a full refreshed is planned
IF @LastLoadID IS NULL
BEGIN 

	SELECT	[PolicyReference]
			,[InceptionDate]
			,[ExpiryDate]
			,[UnderwriterName]
			,[Department]
			,[TriFocusCode]
			,[PolicyYOA]
			,CASE WHEN [StatsCode] = 'SC' THEN 'SC' ELSE 'ALL' END AS [JoinStatsCode]
			,[StatsCode]
			,[PolicySettlementCurrency]
			,[SyndicateNumber]
			,[ExclusionID]
			,Mop
			,-1*SUM([TotalAcquisitionCost]) -1*SUM([EstimatedPremiumIncome]) AS EPI_Movement
			,1*SUM([TotalAcquisitionCost])-1*SUM(LBSComm) AS Brokerage_Movement
			,1*SUM(LBSComm) AS LBSCommission
			,-1*(
					(-1*SUM([TotalAcquisitionCost]) -1*SUM([EstimatedPremiumIncome])) +	(1*SUM([TotalAcquisitionCost])+1*SUM(LBSComm))
				) AS  Total_Movement
	FROM	[Eurobase].[EuroBaseExtract]
	WHERE	LoadID = @CurrentLoadID
	AND		PolicyReference IS NOT NULL
	GROUP BY [PolicyReference]
			,[InceptionDate]
			,[ExpiryDate]
			,[UnderwriterName]
			,[Department]
			,[TriFocusCode]
			,[PolicyYOA]
			,[StatsCode]
			,[PolicySettlementCurrency]
			,[SyndicateNumber]
			,[ExclusionID]
			,Mop
	ORDER	BY PolicyReference

END
ELSE 
	BEGIN
		;WITH	Last_Load AS (
		SELECT	[PolicyReference]
				,[InceptionDate]
				,[ExpiryDate]
				,[UnderwriterName]
				,[Department]
				,[TriFocusCode]
				,[PolicyYOA]
				,CASE WHEN [StatsCode] = 'SC' THEN 'SC' ELSE 'ALL' END AS [JoinStatsCode]
				,[StatsCode]
				,[PolicySettlementCurrency]
				,[SyndicateNumber]
				,[ExclusionID]
				,Mop
				,-1*SUM([TotalAcquisitionCost]) -1*SUM([EstimatedPremiumIncome]) AS [EstimatedPremiumIncome]
				,1*SUM([TotalAcquisitionCost]) AS TotalAcquisitionCost
				,1*SUM(ISNULL(LBSComm,0)) AS LBSCommission
				,[LoadID]
		FROM	[Eurobase].[EuroBaseExtract]
		WHERE	LoadID = @LastLoadID
		AND 	[ExclusionID] = 0
		AND		PolicyReference IS NOT NULL
		GROUP	BY [PolicyReference]
				,[InceptionDate]
				,[ExpiryDate]
				,[UnderwriterName]
				,[Department]
				,[TriFocusCode]
				,[PolicyYOA]
				,[StatsCode]
				,[PolicySettlementCurrency]
				,[SyndicateNumber]
				,[ExclusionID]
				,Mop
				,[LoadID]
		), 
		current_Load AS (
		SELECT	[PolicyReference]
				,[InceptionDate]
				,[ExpiryDate]
				,[UnderwriterName]
				,[Department]
				,[TriFocusCode]
				,[PolicyYOA]
				,CASE WHEN [StatsCode] = 'SC' THEN 'SC' ELSE 'ALL' END AS [JoinStatsCode]
				,[StatsCode]
				,[PolicySettlementCurrency]
				,[SyndicateNumber]
				,[ExclusionID]
				,Mop
				,-1*SUM([TotalAcquisitionCost]) -1*SUM([EstimatedPremiumIncome]) AS [EstimatedPremiumIncome]
				,1*SUM([TotalAcquisitionCost]) AS TotalAcquisitionCost
				,1*SUM(ISNULL(LBSComm,0)) AS LBSCommission
				,[LoadID]
		FROM	[Eurobase].[EuroBaseExtract]
		WHERE	LoadID = @CurrentLoadID
		AND		PolicyReference IS NOT NULL
		GROUP	BY [PolicyReference]
				,[InceptionDate]
				,[ExpiryDate]
				,[UnderwriterName]
				,[Department]
				,[TriFocusCode]
				,[PolicyYOA]
				,[StatsCode]
				,[PolicySettlementCurrency]
				,[SyndicateNumber]
				,[ExclusionID]
				,Mop
				,[LoadID]
		)

		SELECT	ISNULL (cl.PolicyReference,ll.PolicyReference) AS PolicyReference
				,ISNULL(cl.[InceptionDate],ll.[InceptionDate]) AS [InceptionDate]
				,ISNULL(cl.[ExpiryDate],ll.[ExpiryDate]) AS [ExpiryDate]
				,ISNULL(cl.[UnderwriterName],ll.[UnderwriterName]) AS [UnderwriterName]
				,ISNULL(cl.[Department],ll.[Department]) AS [Department]
				,ISNULL(cl.[TriFocusCode],ll.[TriFocusCode]) AS [TriFocusCode]
				,ISNULL(cl.[PolicyYOA],ll.[PolicyYOA]) AS [PolicyYOA]
				,CASE WHEN ISNULL(cl.[StatsCode],ll.StatsCode) = 'SC' THEN 'SC' ELSE 'ALL' END AS [JoinStatsCode]
				,ISNULL(cl.[StatsCode],ll.[StatsCode]) AS [StatsCode]
				,ISNULL(cl.PolicySettlementCurrency,ll.PolicySettlementCurrency) AS PolicySettlementCurrency
				,ISNULL(cl.SyndicateNumber,ll.SyndicateNumber) AS SyndicateNumber
				,ISNULL(cl.ExclusionID,ll.ExclusionID) AS ExclusionID		
				,ISNULL(cl.Mop,ll.Mop) AS Mop
				,ISNULL(cl.EstimatedPremiumIncome-ISNULL(ll.EstimatedPremiumIncome,0),-1*ll.EstimatedPremiumIncome) AS EPI_Movement
				,ISNULL((cl.TotalAcquisitionCost-cl.LBSCommission)-ISNULL((ll.TotalAcquisitionCost-ll.LBSCommission) ,0),-1*(ll.TotalAcquisitionCost-ll.LBSCommission)) AS Brokerage_Movement
				,ISNULL(cl.LBSCommission-ISNULL(ll.LBSCommission,0),-1*ll.LBSCommission) AS LBSCommission
				,ISNULL(-1*((cl.EstimatedPremiumIncome-ISNULL(ll.EstimatedPremiumIncome,0)) + (cl.TotalAcquisitionCost-ISNULL(ll.TotalAcquisitionCost ,0))),ll.EstimatedPremiumIncome+ll.TotalAcquisitionCost) AS Total_Movement

		FROM	current_Load cl 
		FULL	OUTER	JOIN Last_Load  ll
		ON		ll.PolicyReference = cl.PolicyReference
		ANd		ll.PolicySettlementCurrency = cl.PolicySettlementCurrency
		AND		ll.SyndicateNumber = cl.SyndicateNumber
		AND		ll.[TriFocusCode] = cl.[TriFocusCode]
		AND		ll.[PolicyYOA]= cl.[PolicyYOA]
		AND		ll.[InceptionDate] = cl.[InceptionDate]
		AND		ll.[ExpiryDate] = cl.[ExpiryDate]
		AND		ll.Mop	= cl.Mop
		AND     ll.JoinStatsCode = cl.JoinStatsCode
		WHERE	 1=1
		AND 	((ROUND(ISNULL(cl.EstimatedPremiumIncome-ISNULL(ll.EstimatedPremiumIncome,0),-1*ll.EstimatedPremiumIncome),2) NOT BETWEEN -1 and 1) 
		OR		(ROUND(ISNULL(cl.TotalAcquisitionCost-ISNULL(ll.TotalAcquisitionCost,0),-1*ll.TotalAcquisitionCost),2) NOT BETWEEN -1 and 1)
		OR 		(ROUND(ISNULL(cl.LBSCommission-ISNULL(ll.LBSCommission,0),-1*ll.LBSCommission),2) NOT BETWEEN -1 and 1)  
		)	
		--AND ISNULL (cl.PolicyReference,ll.PolicyReference) = 'B1494A19BNFR'--'B0984A15ANFT'
	END
END	


--EXEC usp_GetEPIDeltaOnLTD 28