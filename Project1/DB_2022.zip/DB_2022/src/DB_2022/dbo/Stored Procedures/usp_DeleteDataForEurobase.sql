﻿

-- =============================================
-- Author:		<Nanda Gottumukkala>
-- Create date: <13/11/2015>
-- Description:	<Description>
-- =============================================

CREATE PROCEDURE [dbo].[usp_DeleteDataForEurobase]
@BatchID int
AS
BEGIN

DELETE FROM [Eurobase].[EuroBaseExtract]
WHERE  BatchID  = @BatchID

END
