﻿CREATE PROCEDURE [dbo].[usp_GetProcessedPremiumForecastData]
/*
	EXEC dbo.usp_GetProcessedPremiumForecastData
	WITH RESULT SETS
	(
	 ( 
		[Period] NVARCHAR(10),AccountingPeriod INT,YOA INT,EntityRISideCar NVARCHAR(255)			 
			 , [Entity] NVARCHAR(255)
			 , TrifocusCode NVARCHAR(255),TrifocusName NVARCHAR(255),MoP NVARCHAR(2),InceptionDate Date,InceptionMonth INT,Currency NVARCHAR(10)
			 , [Gross Gross Premium] [numeric](18, 4)
			 , ExternalBrokerage [numeric](18, 4)
			 , [Internal Commission] [numeric](18, 4)
			 , [Gross Net Premium] [numeric](18, 4)
			 , Insert_Date DateTime
	  
	 ) 
	) 

*/
	AS
	BEGIN
		IF(OBJECT_ID('tempdb..#Temp1') IS NOT NULL)
			DROP TABLE #Temp1

		SELECT ExtractDate
			 , CAST(LEFT(AccountingPeriod,4) AS VARCHAR(4)) + '.' + CAST(RIGHT(AccountingPeriod,2)/3 AS VARCHAR(2)) AS [Period]
			 , AccountingPeriod
			 , YOA
			 , NULLIF(EntityRISideCar,'NULL') AS EntityRISideCar
			 , NULLIF(Entity,'NULL') AS Entity		 
			 , TrifocusCode
			 , TrifocusName		 
			 , [MoP] = case when MoP = 'Policy' then cast('P' as nvarchar(1)) else cast('B' as nvarchar(1)) END
			 , [Currency]
			 , Accounts
			 , MONTH(CAST('01-' + Months +'-' +'2023' AS DATE)) AS [InceptionMonth]
			 , Amount
		  INTO #Temp1
		  FROM
				(SELECT Insert_Date AS ExtractDate,AccountingPeriod,YoA--,1 AS [PremiumMonth]
					  , RTRIM(LTRIM([EntityRISideCar])) AS [EntityRISideCar]
					  , RTRIM(LTRIM([Entity])) AS Entity				 
					  , RTRIM(LTRIM([TrifocusCode])) AS TrifocusCode
					  , RTRIM(LTRIM(TrifocusName)) AS TrifocusName
					  , CASE WHEN RTRIM(LTRIM(Method_Of_Placement)) = 'Delegated' THEN 'Binder' ELSE 'Policy' END AS MoP,[Currency]				  
					  , [Jan],[Feb],[Mar],[Apr],[May],[Jun],[Jul],[Aug],[Sep],[Oct],[Nov],[Dec],  Accounts
				   FROM [$(staging_agresso)].dbo.[StagePremiumForecastPremiumStage] A
				) AS T
				UNPIVOT
				(Amount FOR Months IN ([Jan],[Feb],[Mar],[Apr],[May],[Jun],[Jul],[Aug],[Sep],[Oct],[Nov],[Dec])		
			) AS P1 --WHERE [Gross Gross Premium] != 0
	
		--SELECT * FROM #Temp1

		IF(OBJECT_ID('tempdb..#Temp2') IS NOT NULL)
			DROP TABLE #Temp2
	
		SELECT ExtractDate,[Period],[InceptionMonth],AccountingPeriod,MOP
			 , [InceptionDate] = datefromparts(YOA, InceptionMonth,15)		
			 , TrifocusName,TrifocusCode,Department
			 , YoA,[Currency]
			 , EntityRISideCar
			 , Entity		 
			  ,ISNULL([Gross Gross Premium],0) AS [Gross Gross Premium]
			  ,ISNULL([Gross Net Premium],0) AS [Gross Net Premium]		  
			  ,ISNULL([External Brokerage],0) AS [External Brokerage]
			  , 0 AS [Internal Commission]		  
		  INTO #Temp2
		  FROM
				(SELECT ExtractDate,[Period],[InceptionMonth],AccountingPeriod,MOP
				
					 , A.TrifocusName
					 , A.TrifocusCode
					 , B.Department
					 , YoA,[Currency]
					 , EntityRISideCar
					 , Entity				 
					 , Amount
					 , Accounts
				   FROM #Temp1 A
				   LEFT JOIN FDM_DB.FDM_DC.DimTriFocus B
					 ON A.TrifocusCode = B.pk_TriFocus
				   LEFT JOIN FDM_DB.dbo.DimEntity E
					 ON A.Entity = E.EntityCode		  
				) AS T
				PIVOT
				(SUM(Amount) FOR Accounts IN ([Gross Gross Premium],[Gross Net Premium],[External Brokerage])		
			) AS P1 
				 	
			SELECT [Period],AccountingPeriod,YOA,EntityRISideCar			 
				 , [Entity] = case when [Entity] = 'BIDE' then 'BIGE' else [Entity] end
				 , TrifocusCode,TrifocusName,MoP,InceptionDate,InceptionMonth,Currency
				 , [Gross Gross Premium],ExternalBrokerage,[Internal Commission],[Gross Net Premium],Insert_Date
			  FROM
			(
				SELECT [Period],AccountingPeriod,YOA,EntityRISideCar,Entity,TrifocusCode,TrifocusName,MoP,InceptionDate,InceptionMonth,Currency
					 , [Gross Gross Premium] --= -1 * [Gross Gross Premium]
					 , [External Brokerage] AS ExternalBrokerage
					 , [Internal Commission]
					 , [Gross Net Premium] --= -1 * [Gross Net Premium]
					 , ExtractDate AS Insert_Date
				  FROM #Temp2 
				  --WHERE EntityRISideCar IS NULL AND Entity NOT IN ('6107', '6050' , '5623')--37884
				--UNION ALL
				--SELECT [Period],AccountingPeriod,YOA,EntityRISideCar,Entity,TrifocusCode,TrifocusName,MoP,InceptionDate,InceptionMonth,Currency
				--	 , [Gross Gross Premium]
				--	 , [External Brokerage] AS ExternalBrokerage
				--	 , [Internal Commission]
				--	 , [Gross Net Premium]
				--	 , ExtractDate AS Insert_Date
				--  FROM #Temp2 WHERE EntityRISideCar IS NOT NULL OR Entity IN ('6107', '6050' , '5623')--3852
			) AS T
		

	END
		
		