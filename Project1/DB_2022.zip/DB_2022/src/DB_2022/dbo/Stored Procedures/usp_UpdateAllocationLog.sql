﻿


-- =============================================
-- Author:		Nanda Gottumukkala
-- Create date: 02/10/2015
-- Description:	TO log the execution and record movements on the tables
-- =============================================
CREATE PROCEDURE [dbo].[usp_UpdateAllocationLog]
	@BridgeEndTime varchar(50) = NULL
	,@AllocationStartTime varchar(50) =NULL
	,@AllocationEndTime varchar(50) =NULL
	,@CubeStartTime varchar(50) =NULL
	,@CubeEndTime varchar(50) =NULL
	,@BridgeCount int =NULL
	,@AllocationCount int =NULL
	,@ReAllocationCount int =NULL
	,@AccountingPeriod int=NULL
	,@Status varchar(50)
	,@StartID BIGINT  = NULL
	,@BatchID int
	,@AllocationCode varchar(50) = NULL


AS
BEGIN

DECLARE @ExecutionID as INT



IF		@AllocationCode IS NOT NULL 
BEGIN

SELECT	@ExecutionID = ExecutionID
FROM	AllocationEngineLog
WHERE	BatchID = @BatchID
AND		AllocationCode = @AllocationCode

UPDATE	AllocationEngineLog
SET		[BridgeEndTime] = ISNULL(@BridgeEndTime,[BridgeEndTime])
		,AllocationStartTime= ISNULL(@AllocationStartTime,AllocationStartTime)
		,AllocationEndTime=ISNULL(@AllocationEndTime,AllocationEndTime)
		,[BridgeCount] = ISNULL(@BridgeCount, [BridgeCount])
		,ReAllocationCount = ISNULL(@ReAllocationCount,ReAllocationCount)
		,AllocationCount = ISNULL(@AllocationCount,AllocationCount)
		,AccountingPeriod = ISNULL(@AccountingPeriod,AccountingPeriod)
		,StartID = ISNULL(@StartID,StartID)
		,[Status] = @Status
WHERE	ExecutionID = @ExecutionId
END
ELSE
UPDATE	AllocationEngineLog
SET		CubeStartTime= ISNULL(@CubeStartTime,CubeStartTime)
		,CubeEndTime=ISNULL(@CubeEndTime,CubeEndTime)
		,[Status] = @Status
WHERE	BatchID = @BatchID

END
