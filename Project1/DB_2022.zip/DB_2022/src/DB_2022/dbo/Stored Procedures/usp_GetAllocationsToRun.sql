﻿


-- =============================================
-- Author:		<Nanda Gottumukkala>
-- Create date: <13/11/2015>
-- Description:	<Description>
-- =============================================

CREATE PROCEDURE [dbo].[usp_GetAllocationsToRun]
@Adhoc AS BIT
,@IntraDay AS BIT
,@AccountingPeriod AS INT
,@AllocationGroup AS VARCHAR(255)

AS
BEGIN
--DECLARE @Adhoc AS BIT = 1
--,@IntraDay AS BIT = 0
--,@AccountingPeriod AS INT = 201506
--,@AllocationGroup AS VARCHAR(255) = 'Expenses'


IF OBJECT_ID('tempdb.dbo.#PeriodsToDelete', 'U') IS NOT NULL
	DROP TABLE #PeriodsToDelete;

IF OBJECT_ID('tempdb.dbo.#AllocationGroupToDelete', 'U') IS NOT NULL
	DROP TABLE #AllocationGroupToDelete;

TRUNCATE TABLE staging_Agresso.dbo.AllocationsToRun 

CREATE TABLE #PeriodsToDelete (
		AccountPeriod VARCHAR(100)
		)
CREATE TABLE #AllocationGroupToDelete (
		AllocationGroup VARCHAR(100)
		,AllocationCode VARCHAR(100)
		)

IF @Adhoc = 1 AND @AllocationGroup NOT IN (SELECT [AllocationGroup]  FROM [FDM_DB].[dbo].RealTimeAllocations)
	BEGIN
		;WITH CTE_Periods AS (
		SELECT CAST([AccountingPeriod] AS INT) AS [AccountingPeriod]
		FROM [FDM_DB].[dbo].[DimAccountingPeriod]
		WHERE AccountingMonth BETWEEN 1 AND CASE WHEN YEAR(getDate())>@AccountingPeriod THEN 12 ELSE  Month(getDate()) END AND AccountingYear = @AccountingPeriod
		UNION 
		SELECT   CAST([AccountingPeriod] AS INT) AS  [AccountingPeriod] 
		FROM [FDM_DB].[dbo].[DimAccountingPeriod] 
		WHERE  AccountingPeriod = @AccountingPeriod
		)
		INSERT INTO #PeriodsToDelete 
		SELECT * FROM CTE_Periods
	END
ELSE IF @Adhoc = 1 AND @AllocationGroup IN (SELECT [AllocationGroup]  FROM [FDM_DB].[dbo].RealTimeAllocations)
	BEGIN

		INSERT INTO #PeriodsToDelete 
		SELECT   CAST([AccountingPeriod] AS INT) AS  [AccountingPeriod]  
		FROM [FDM_DB].[dbo].[DimAccountingPeriod] 
		WHERE  AccountingPeriod = CAST(YEAR(GETDATE()) AS varchar)+CASE WHEN LEN(CAST(MONTH(GETDATE()) AS varchar)) =1 THEN '0'+CAST(MONTH(GETDATE()) AS varchar) ELSE CAST(MONTH(GETDATE()) AS varchar) END
		
	END
ELSE 
	BEGIN 
		INSERT INTO #PeriodsToDelete
		SELECT   CAST([AccountingPeriod] AS INT) AS  [AccountingPeriod]  
		FROM [FDM_DB].[dbo].[DimAccountingPeriod] 
		WHERE  AccountingPeriod = CAST(YEAR(GETDATE()) AS varchar)+CASE WHEN LEN(CAST(MONTH(GETDATE()) AS varchar)) =1 THEN '0'+CAST(MONTH(GETDATE()) AS varchar) ELSE CAST(MONTH(GETDATE()) AS varchar) END
		
	END

IF @Adhoc = 1 AND @AllocationGroup <> '' 
	BEGIN 
		INSERT INTO #AllocationGroupToDelete
		SELECT	DISTINCT AllocationGroup,AllocationCode
		FROM	[FDM_DB].dbo.DimAllocationRules
		WHERE	[AllocationGroup] IN (@AllocationGroup)
		AND		IsCurrent = 1
	END
ELSE IF @Adhoc = 0
	BEGIN 
		INSERT INTO #AllocationGroupToDelete
		SELECT	DISTINCT a.AllocationGroup,AllocationCode
		FROM	[FDM_DB].dbo.DimAllocationRules a
		JOIN	[FDM_DB].[dbo].RealTimeAllocations b
		ON		a.AllocationGroup = b.AllocationGroup
		WHERE	a.IsCurrent = 1
	END

INSERT	INTO staging_Agresso.dbo.AllocationsToRun 
SELECT	*
FROM	#AllocationGroupToDelete CROSS APPLY #PeriodsToDelete
ORDER	BY AllocationGroup, AccountPeriod,AllocationCode


IF OBJECT_ID('tempdb.dbo.#PeriodsToDelete', 'U') IS NOT NULL
	DROP TABLE #PeriodsToDelete;

IF OBJECT_ID('tempdb.dbo.#AllocationGroupToDelete', 'U') IS NOT NULL
	DROP TABLE #AllocationGroupToDelete;


END
