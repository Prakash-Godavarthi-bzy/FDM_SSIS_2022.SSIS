﻿-- =============================================
-- Author:		Samata Putumbaka
-- Create date: 02/07/2017
-- Description:	Perform OverseasASLDelta on Overseas files from Lloyds
-- =============================================
--EXEC [dbo].[usp_GetOverseasASLDelta] 15,201909
CREATE PROCEDURE [dbo].[usp_GetOverseasASLDelta]
	@IncrementedLoadID AS VARCHAR(100)
   ,@AccountingPeriod AS INT
AS
BEGIN
DECLARE @i int = 0 

--DECLARE	@LastLoadID INT, @CurrentLoadID INT, @curLoadID int, @LoadID int
--SELECT	@curLoadID = ISNULL(MAX(LoadID),0) FROM [dbo].[OverseasandASLExtract]

DECLARE @AccountingYear INT ,
		@AccountingMonth INT,
        @StartYear INT,
		@EndYear INT
		
SELECT @AccountingYear = LEFT(@AccountingPeriod,4)
SELECT @StartYear = CAST(LEFT(@AccountingPeriod,4) AS CHAR(4))+'01'
SELECT @AccountingMonth = CAST(@AccountingPeriod AS CHAR(6))+'01'
SELECT @EndYear   = LEFT(CONVERT(VARCHAR(10),CONVERT(DATETIME,CONVERT(VARCHAR(10),@AccountingMonth,120)),112),6)

	SELECT
	   [AccountHolder]
      ,ext.[SyndicateNo]
      ,[DepositNo]
	  ,ext.[AccountCode]
      ,[ReportingDate]
      ,CASE WHEN [YOA]>=@AccountingYear-2 
			THEN YOA 
			ELSE @AccountingYear-2 
		END AS YOA
      ,ISNULL(ReportingCurrencyCode,ext.Currency) AS Currency
	  ,'Z140'  AS Trifocus
      ,SUM([TotalIncome]+TotalCapital)  AS Total_amount
	  ,t.FXRate AS FXRate
	  ,SUM([TotalIncome]+TotalCapital)/ISNULL(FXRate,1)  AS cur_amount
	  -- NULL AS Value_2
  FROM [dbo].[OverseasandASLExtract] as ext
  LEFT JOIN
  (SELECT  ext.Currency,rep.ReportingCurrencyCode,
  SUM(fx.FXRate)/RIGHT(@AccountingPeriod,2) AS FXRate
 FROM
   (SELECT DISTINCT  SyndicateNo,AccountCode,Currency,LoadId
  FROM
  dbo.OverseasandASLExtract
  WHERE LoadId=@IncrementedLoadID) AS ext
  JOIN
  dbo.OverseasandASLConfig as cfg
  ON ext.AccountCode = cfg.GL
  AND ext.SyndicateNo = cfg.Syndicate
  JOIN
  dbo.DimReportingCurrency as rep
  ON cfg.Currency = rep.ReportingCurrencyCode
  JOIN
  dbo.FactFXRate fx
 ON  ext.Currency  =  fx.fk_TransactionCurrency
  and rep.pk_ReportingCurrency  =  fx.fk_ReportingCurrency
  AND fk_FXRate = 1
  and fk_AccountingPeriod between @StartYear AND @EndYear
  GROUP BY ext.Currency,rep.ReportingCurrencyCode) t
  ON ext.Currency = t.Currency
  WHERE	ext.LoadID = @IncrementedLoadID
  
  GROUP BY   ext.[AccountHolder]
			,ext.[SyndicateNo]
			,[DepositNo]
			,ext.[AccountCode]
			,[ReportingDate]
			,CASE WHEN [YOA]>=@AccountingYear-2 
				  THEN YOA 
				  ELSE @AccountingYear-2 
			 END
			,ISNULL(ReportingCurrencyCode,ext.Currency)
			,t.FXRate
END
GO

