﻿
-- =============================================
-- Author:		Nanda Gottumukkala
-- Create date: 02/10/2015
-- Description:	TO log the execution and record movements on the tables
-- =============================================
CREATE PROCEDURE [dbo].[usp_SIIExtracts] 
	@AccountingPeriodFrom int,
	@AccountingPeriodTo int,
	@SIIForm varchar(255),
	@EntityGroup varchar(255)
AS
BEGIN

IF @SIIForm <> 'S.02.02' AND @SIIForm <> 'S.02.01'

BEGIN
	
	EXECUTE [dbo].[usp_SIIGetBaseData] 
	   @AccountingPeriodFrom
	  ,@AccountingPeriodTo
	  ,@SIIForm


	EXECUTE [dbo].[usp_SIIAllocationPercentages] 
	   @AccountingPeriodFrom
	  ,@AccountingPeriodTo
	  ,@SIIForm

END	  

ELSE

BEGIN

	EXECUTE[dbo].[usp_SIIBaseDataS0201] 
	   @AccountingPeriodFrom
	  ,@AccountingPeriodTo
	  ,@SIIForm
	  ,@EntityGroup

	EXECUTE [dbo].[usp_SIIAllocatedDataBS] 
	   @EntityGroup
   
END
	  
IF @SIIForm = 'S.04.01'
	EXECUTE [dbo].[usp_SIIAllocateDataS0401] 
	   @AccountingPeriodFrom
	  ,@AccountingPeriodTo
	  ,@SIIForm
	  ,@EntityGroup

IF @SIIForm = 'S.05.02'
	EXECUTE [dbo].[usp_SIIAllocateDataS0502] 
	   @AccountingPeriodFrom
	  ,@AccountingPeriodTo
	  ,@SIIForm
	  ,@EntityGroup
	  
IF @SIIForm = 'S.05.01'
	EXECUTE [dbo].[usp_SIIAllocateDataS0502] 
	   @AccountingPeriodFrom
	  ,@AccountingPeriodTo
	  ,@SIIForm
	  ,@EntityGroup
	  

	  
END
