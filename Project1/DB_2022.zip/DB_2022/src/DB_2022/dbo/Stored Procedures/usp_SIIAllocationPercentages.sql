﻿


-- =============================================
-- Author:		Nanda Gottumukkala
-- Create date: 02/10/2015
-- Description:	TO log the execution and record movements on the tables
-- =============================================
CREATE PROCEDURE[dbo].[usp_SIIAllocationPercentages]
 @AccountingPeriodFrom AS INT
, @AccountingPeriodTo AS INT
,@SIIForm AS VARCHAR(255)
AS
BEGIN

--SET @AccountingPeriodFrom = 201501
--SET @AccountingPeriodTo = 201512
----SET @SIIForm = 'S.04.01'
--SET @SIIForm = 'S.05.02'

DECLARE @MovementDateFrom AS DATE
DECLARE @MovementDateTo AS DATE

SELECT @MovementDateFrom = CAST(CAST(CASE WHEN @AccountingPeriodFrom%100 = 00 THEN @AccountingPeriodFrom+1 else @AccountingPeriodFrom END  AS VARCHAR(6))+'01' as datetime)
SELECT @MovementDateTo = CAST(CAST( CASE WHEN @AccountingPeriodTo%100 = 13 THEN @AccountingPeriodTo -1  else @AccountingPeriodTo END  AS VARCHAR(6))+'01' as datetime)
SELECT @MovementDateTo = CAST(CAST(CASE WHEN @AccountingPeriodTo%100 = 13 THEN @AccountingPeriodTo -1  else @AccountingPeriodTo END  AS VARCHAR(6))+CAST(DAY(EOMONTH(@MovementDateTo))AS VARCHAR(2)) as datetime)  

DELETE FROM AllocationPercentages
WHERE SIIType = @SIIForm

;WITH CTE AS (
SELECT	LOB,	
		Channel,	
		AgressoAccountCategory,	
		SIIType,	
		ISNULL(CASE WHEN Basis ='UnderwritingLocation' THEN  (CASE WHEN UnderwritingLocation = 'UNKNOWN' OR UnderwritingLocation IS NULL THEN 'GB' ELSE UnderwritingLocation END)
		WHEN Basis ='LocationOfRisk' THEN  LocationOfRisk
		ELSE 'UNKNOWN' END,'UNKNOWN') AS ReportingCountry,	
		e.EntityAllocationGroup,
		Basis,
		--OriginalCurrencyCode,		
		SUM(cur_amount) cur_amount,
		SUM(Value) Value
FROM	UnAllocatedDataTF s
JOIN	SIIEntityAllocationBasis e
ON		s.EntityCode = e.Entity
JOIN	(SELECT DIstinct AgressoAccountCategoryToAllocate FROM SIIAccountAllocationBasis) a
ON		s.AgressoAccountCategory = a.AgressoAccountCategoryToAllocate
WHERE	ISNULL(CASE WHEN Basis ='UnderwritingLocation' THEN  (CASE WHEN UnderwritingLocation = 'UNKNOWN' OR UnderwritingLocation IS NULL THEN 'GB' ELSE UnderwritingLocation END)
		WHEN Basis ='LocationOfRisk' THEN  LocationOfRisk
		ELSE 'UNKNOWN' END,'UNKNOWN') <> 'UNKNOWN'
		AND		SIIType=@SIIForm 
GROUP	BY LOB,	
		Channel,	
		AgressoAccountCategory,	
		SIIType,	
		ISNULL(CASE WHEN Basis ='UnderwritingLocation' THEN  (CASE WHEN UnderwritingLocation = 'UNKNOWN' OR UnderwritingLocation IS NULL THEN 'GB' ELSE UnderwritingLocation END)
		WHEN Basis ='LocationOfRisk' THEN  LocationOfRisk
		ELSE 'UNKNOWN' END,'UNKNOWN'),
		e.EntityAllocationGroup,
		Basis
)
,CTE2 AS (
SELECT	LOB,	
		Channel,	
		AgressoAccountCategory,	
		SIIType,	
		EntityAllocationGroup,
		Basis,
		SUM(cur_amount) cur_amount,
		SUM(Value) Value
FROM	CTE
WHERE	CASE WHEN Basis ='UnderwritingLocation' AND ReportingCountry = 'Unknown' THEN 'GB' ELSE ReportingCountry END <> 'UNKNOWN'
GROUP	BY LOB,	
		Channel,	
		AgressoAccountCategory,	
		SIIType,	
		Basis,
		EntityAllocationGroup
)
,CTE3 AS (
SELECT	LOB,	
		Channel,	
		AgressoAccountCategory,	
		SIIType,	
		EntityAllocationGroup,
		ReportingCountry,
		Basis,
		SUM(cur_amount) cur_amount,
		SUM(Value) Value
FROM	CTE
WHERE	CASE WHEN Basis ='UnderwritingLocation' AND ReportingCountry = 'Unknown' THEN 'GB' ELSE ReportingCountry END <> 'UNKNOWN'
GROUP	BY LOB,	
		Channel,	
		AgressoAccountCategory,	
		SIIType,	
		EntityAllocationGroup,
		ReportingCountry,
		Basis
)

INSERT INTO [dbo].[AllocationPercentages]
           ([LOB]
           ,[Channel]
           ,[AgressoAccountCategory]
           ,[SIIType]
           ,ReportingCountry
           ,[EntityAllocationGroup]
           ,[Basis]
           ,[cur_amount]
           ,[TOTALcur_amount]
           ,[Value]
           ,[TotalValue]
           )
SELECT	CTE3.LOB,	
		CTE3.Channel,	
		CTE3.AgressoAccountCategory,	
		CTE3.SIIType,	
		ReportingCountry,	
		CTE3.EntityAllocationGroup,
		CTE3.Basis,
		CASE WHEN CTE3.cur_amount = 0 and CTE2.cur_amount = 0 THEN 1 ELSE CTE3.cur_amount END AS cur_amount,
		CASE WHEN CTE3.cur_amount = 0 and CTE2.cur_amount = 0 THEN 1 ELSE CTE2.cur_amount END AS TOTALcur_amount,
		CASE WHEN CTE3.Value = 0 and CTE2.Value = 0 THEN 1 ELSE CTE3.Value END AS Value,
		CASE WHEN CTE3.Value = 0 and CTE2.Value = 0 THEN 1 ELSE CTE2.Value END AS TotalValue

FROM	CTE3
JOIN	CTE2
ON		CTE3.AgressoAccountCategory = CTE2.AgressoAccountCategory
AND		CTE3.Channel = CTE2.Channel
AND		CTE3.EntityAllocationGroup = CTE2.EntityAllocationGroup
AND		CTE3.LoB = CTE2.LoB
AND		CTE3.Basis = CTE2.Basis

DELETE FROM AllocationPercentages
WHERE	SIIType = @SIIForm
AND AgressoAccountCategory = 'AC2000'

SELECT @MovementDateFrom = CAST(CAST(CASE WHEN @AccountingPeriodFrom%100 = 00 THEN @AccountingPeriodFrom+1 else @AccountingPeriodFrom END  AS VARCHAR(6))+'01' as datetime)
SELECT @MovementDateTo = CAST(CAST( CASE WHEN @AccountingPeriodTo%100 = 13 THEN @AccountingPeriodTo -1  else @AccountingPeriodTo END  AS VARCHAR(6))+'01' as datetime)
SELECT @MovementDateTo = CAST(CAST(CASE WHEN @AccountingPeriodTo%100 = 13 THEN @AccountingPeriodTo -1  else @AccountingPeriodTo END  AS VARCHAR(6))+CAST(DAY(EOMONTH(@MovementDateTo))AS VARCHAR(2)) as datetime)  

IF OBJECT_ID('tempdb.dbo.#CTE', 'U') IS NOT NULL
  DROP TABLE #CTE; 

IF OBJECT_ID('tempdb.dbo.#CTE1', 'U') IS NOT NULL
  DROP TABLE #CTE1; 

IF @SIIForm = 'S.05.02' 
BEGIN
;WITH CTE AS (
SELECT c.SyndicateNumber
--,s.AreaCode
,a.ISOCountryCode AS LocationOfRisk
,ISNULL(CASE WHEN SourceSystem = 'BeazleyPro' THEN 'US' WHEN (SourceSystem IS NULL OR SourceSystem <> 'BeazleyPro') AND  o.ISOCountryCode IS NULL  THEN 'GB' ELSE o.ISOCountryCode END,'UNKNOWN') AS UnderwritingLocation
,s.OriginalCurrencyCode
,p.SourceSystem
,s.YearOfAccount
,s.TrifocusCode
,'AC2000' AS AgressoAccountCategory
,@SIIForm AS SIIType
,SUM((c.MovementTotalPaid/c.PaidOriginalCCYToSettlementCCYRate)+(c.MovementTotalOutstanding/c.OutstandingOriginalCCYToSettlementCCYRate)) AS Cur_Amount
  FROM [$(staging_agresso)].[FDM].[ClaimExposureMovement] c
  JOIN  [$(staging_agresso)].[FDM].Section s
  ON PK_Section = fk_section
  JOIN	 [$(staging_agresso)].[FDM].Policy p 
  ON p.PK_Policy = s.FK_Policy
  LEFT	JOIN	FDM_DB.dbo.AreaToISOCountryMapping a
	ON		a.AreaCode = s.AreaCode
LEFT	JOIN	FDM_DB.dbo.OfficeToISOCountryMapping o
ON		o.BeazleyOfficeLocation = s.BeazleyOfficeLocation
  WHERE EntityPerspective = 'Combined View'
  AND c.MovementDate BETWEEN @MovementDateFrom AND @MovementDateTo
  GROUP By 
c.SyndicateNumber
,a.ISOCountryCode
,ISNULL(CASE WHEN SourceSystem = 'BeazleyPro' THEN 'US' WHEN (SourceSystem IS NULL OR SourceSystem <> 'BeazleyPro') AND  o.ISOCountryCode IS NULL  THEN 'GB' ELSE o.ISOCountryCode END,'UNKNOWN')
,s.OriginalCurrencyCode
,p.SourceSystem
,s.YearOfAccount
,s.TrifocusCode
--,s.AreaCode
)

SELECT  CAST(SyndicateNumber AS VARCHAR(255)) AS EntityCode
		,EntityGroup
		,e.LOB
		,e.Channel
		,AgressoAccountCategory
		,SIIType
		,CASE WHEN CASE WHEN @SIIForm = 'S.04.01' THEN 'UnderwritingLocation' ELSE  l.Basis END ='UnderwritingLocation' THEN  UnderwritingLocation
		WHEN CASE WHEN @SIIForm = 'S.04.01' THEN 'UnderwritingLocation' ELSE  l.Basis END ='LocationOfRisk' THEN  LocationOfRisk
		ELSE 'UNKNOWN' END AS ReportingCountry
		,Basis
		,SUM(ISNULL(cur_amount,0.00)) cur_amount 
INTO	#CTE
FROM	CTE 
LEFT JOIN	vw_SIILOBMappingV1 e
ON		e.Entity = CAST(cte.SyndicateNumber AS VARCHAR(255))
AND		e.TrifocusCode = CTE.TrifocusCode
LEFT	JOIN SIILOBAllocationBasis l
ON		LTRIM(RTRIM(l.LOB))=LTRIM(RTRIM(e.LOB))
AND		LTRIM(RTRIM(e.Channel))=LTRIM(RTRIM(l.Channel))
WHERE	EntityGroup IS NOT NULL
AND		SIIType = @SIIForm
GROUP BY SyndicateNumber
		,EntityGroup
		,e.LOB
		,e.Channel
		,AgressoAccountCategory
		,SIIType
		,CASE WHEN CASE WHEN @SIIForm = 'S.04.01' THEN 'UnderwritingLocation' ELSE  l.Basis END ='UnderwritingLocation' THEN  UnderwritingLocation
		WHEN CASE WHEN @SIIForm = 'S.04.01' THEN 'UnderwritingLocation' ELSE  l.Basis END ='LocationOfRisk' THEN  LocationOfRisk
		ELSE 'UNKNOWN' END
		,Basis

;WITH CTE3 AS (
SELECT	LOB,	
		Channel,	
		AgressoAccountCategory,	
		SIIType,
		e.EntityAllocationGroup,	
		ReportingCountry,
		Basis,
		SUM(cur_amount) cur_amount
FROM	#CTE s
JOIN	SIIEntityAllocationBasis e
ON		s.EntityCode = e.Entity
WHERE ReportingCountry <> 'UNKNOWN'
GROUP	BY LOB,	
		Channel,	
		AgressoAccountCategory,	
		SIIType,
		e.EntityAllocationGroup,	
		ReportingCountry ,
		Basis
)
,CTE4 AS (
SELECT	LOB,	
		Channel,	
		AgressoAccountCategory,	
		SIIType,
		e.EntityAllocationGroup,	
		Basis,
		SUM(cur_amount) cur_amount
FROM	#CTE s
JOIN	SIIEntityAllocationBasis e
ON		s.EntityCode = e.Entity
WHERE ReportingCountry <> 'UNKNOWN'
GROUP	BY LOB,	
		Channel,	
		AgressoAccountCategory,	
		SIIType,
		e.EntityAllocationGroup,
		Basis
)
INSERT INTO [dbo].[AllocationPercentages]
           ([LOB]
           ,[Channel]
           ,[AgressoAccountCategory]
           ,[SIIType]
           ,ReportingCountry
           ,[EntityAllocationGroup]
           ,[Basis]
           ,[cur_amount]
           ,[TOTALcur_amount]
           ,[Value]
           ,[TotalValue]
           )
SELECT	CTE3.LOB,	
		CTE3.Channel,	
		CTE3.AgressoAccountCategory,	
		CTE3.SIIType,	
		ReportingCountry,	
		CTE3.EntityAllocationGroup,
		CTE3.Basis,
		CASE WHEN CTE3.cur_amount = 0 and CTE4.cur_amount = 0 THEN 1 ELSE CTE3.cur_amount END AS cur_amount,
		CASE WHEN CTE3.cur_amount = 0 and CTE4.cur_amount = 0 THEN 1 ELSE CTE4.cur_amount END AS TOTALcur_amount,
		CASE WHEN CTE3.cur_amount = 0 and CTE4.cur_amount = 0 THEN 1 ELSE CTE3.cur_amount END AS Value,
		CASE WHEN CTE3.cur_amount = 0 and CTE4.cur_amount = 0 THEN 1 ELSE CTE4.cur_amount END AS TotalValue
FROM	CTE3
JOIN	CTE4
ON		CTE3.AgressoAccountCategory = CTE4.AgressoAccountCategory
AND		CTE3.Channel = CTE4.Channel
AND		CTE3.EntityAllocationGroup = CTE4.EntityAllocationGroup
AND		CTE3.LoB = CTE4.LoB
AND		CTE3.Basis = CTE4.Basis
WHERE	ReportingCountry <> 'Unknown'
END

IF @SIIForm = 'S.04.01' 
BEGIN

;WITH CTE AS (
SELECT c.SyndicateNumber
--,s.AreaCode
,a.ISOCountryCode AS LocationOfRisk
,ISNULL(CASE WHEN SourceSystem = 'BeazleyPro' THEN 'US' WHEN (SourceSystem IS NULL OR SourceSystem <> 'BeazleyPro') AND  o.ISOCountryCode IS NULL  THEN 'GB' ELSE o.ISOCountryCode END,'UNKNOWN') AS UnderwritingLocation
,s.OriginalCurrencyCode
,p.SourceSystem
,s.YearOfAccount
,s.TrifocusCode
,'AC2000' AS AgressoAccountCategory
,@SIIForm AS SIIType
,SUM((c.MovementTotalPaid/c.PaidOriginalCCYToSettlementCCYRate)+(c.MovementTotalOutstanding/c.OutstandingOriginalCCYToSettlementCCYRate)) AS Cur_Amount
  FROM [$(staging_agresso)].[FDM].[ClaimExposureMovement] c
  JOIN  [$(staging_agresso)].[FDM].Section s
  ON PK_Section = fk_section
  JOIN	 [$(staging_agresso)].[FDM].Policy p 
  ON p.PK_Policy = s.FK_Policy
  LEFT	JOIN	FDM_DB.dbo.AreaToISOCountryMapping a
	ON		a.AreaCode = s.AreaCode
LEFT	JOIN	FDM_DB.dbo.OfficeToISOCountryMapping o
ON		o.BeazleyOfficeLocation = s.BeazleyOfficeLocation
  WHERE EntityPerspective = 'Combined View'
  AND c.MovementDate BETWEEN @MovementDateFrom AND @MovementDateTo
  GROUP By 
c.SyndicateNumber
,a.ISOCountryCode
,ISNULL(CASE WHEN SourceSystem = 'BeazleyPro' THEN 'US' WHEN (SourceSystem IS NULL OR SourceSystem <> 'BeazleyPro') AND  o.ISOCountryCode IS NULL  THEN 'GB' ELSE o.ISOCountryCode END,'UNKNOWN')
,s.OriginalCurrencyCode
,p.SourceSystem
,s.YearOfAccount
,s.TrifocusCode
--,s.AreaCode
)

SELECT  CAST(SyndicateNumber AS VARCHAR(255)) AS EntityCode
		,EntityGroup
		,e.LOB
		,e.Channel
		,AgressoAccountCategory
		,SIIType
		,UnderwritingLocation
		,LocationOfRisk
		,Basis
		,SUM(ISNULL(cur_amount,0.00)) cur_amount 
INTO	#CTE1
FROM	CTE 
LEFT JOIN	vw_SIILOBMappingV1 e
ON		e.Entity = CAST(cte.SyndicateNumber AS VARCHAR(255))
AND		e.TrifocusCode = CTE.TrifocusCode
LEFT	JOIN SIILOBAllocationBasis l
ON		LTRIM(RTRIM(l.LOB))=LTRIM(RTRIM(e.LOB))
AND		LTRIM(RTRIM(e.Channel))=LTRIM(RTRIM(l.Channel))
WHERE	EntityGroup IS NOT NULL
AND		SIIType = @SIIForm
GROUP BY SyndicateNumber
		,EntityGroup
		,e.LOB
		,e.Channel
		,AgressoAccountCategory
		,SIIType
		,UnderwritingLocation
		,LocationOfRisk
		,Basis

;WITH CTE3 AS (
SELECT	LOB,	
		Channel,	
		AgressoAccountCategory,	
		SIIType,
		e.EntityAllocationGroup,	
		UnderwritingLocation,
		LocationOfRisk,
		Basis,
		SUM(cur_amount) cur_amount
FROM	#CTE1 s
JOIN	SIIEntityAllocationBasis e
ON		s.EntityCode = e.Entity
GROUP	BY LOB,	
		Channel,	
		AgressoAccountCategory,	
		SIIType,
		e.EntityAllocationGroup,	
		UnderwritingLocation,
		LocationOfRisk,
		Basis
)
,CTE4 AS (
SELECT	LOB,	
		Channel,	
		AgressoAccountCategory,	
		SIIType,
		e.EntityAllocationGroup,	
		Basis,
		SUM(cur_amount) cur_amount
FROM	#CTE1 s
JOIN	SIIEntityAllocationBasis e
ON		s.EntityCode = e.Entity
GROUP	BY LOB,	
		Channel,	
		AgressoAccountCategory,	
		SIIType,
		e.EntityAllocationGroup,
		Basis
)


INSERT INTO [dbo].[AllocationPercentages]
           ([LOB]
           ,[Channel]
           ,[AgressoAccountCategory]
           ,[SIIType]
           ,[UnderwritingLocation]
           ,[LocationOfRisk]
           ,[EntityAllocationGroup]
           ,[Basis]
           ,[cur_amount]
           ,[TOTALcur_amount]
           ,[Value]
           ,[TotalValue]
           )
SELECT	CTE3.LOB,	
		CTE3.Channel,	
		CTE3.AgressoAccountCategory,	
		CTE3.SIIType,	
		UnderwritingLocation,
		LocationOfRisk,	
		CTE3.EntityAllocationGroup,
		CTE3.Basis,
		CASE WHEN CTE3.cur_amount = 0 and CTE4.cur_amount = 0 THEN 1 ELSE CTE3.cur_amount END AS cur_amount,
		CASE WHEN CTE3.cur_amount = 0 and CTE4.cur_amount = 0 THEN 1 ELSE CTE4.cur_amount END AS TOTALcur_amount,
		CASE WHEN CTE3.cur_amount = 0 and CTE4.cur_amount = 0 THEN 1 ELSE CTE3.cur_amount END AS Value,
		CASE WHEN CTE3.cur_amount = 0 and CTE4.cur_amount = 0 THEN 1 ELSE CTE4.cur_amount END AS TotalValue
FROM	CTE3
JOIN	CTE4
ON		CTE3.AgressoAccountCategory = CTE4.AgressoAccountCategory
AND		CTE3.Channel = CTE4.Channel
AND		CTE3.EntityAllocationGroup = CTE4.EntityAllocationGroup
AND		CTE3.LoB = CTE4.LoB
AND		CTE3.Basis = CTE4.Basis

UPDATE [AllocationPercentages]
SET LocationOfRisk = 'GB'
,UnderwritingLocation = 'GB'
WHERE LocationOfRisk IS NULL and UnderwritingLocation IS NULL
AND AgressoAccountCategory = 'AC2000'


END
END


