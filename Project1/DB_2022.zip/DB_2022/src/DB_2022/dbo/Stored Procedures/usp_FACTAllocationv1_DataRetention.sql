﻿CREATE PROCEDURE [dbo].[usp_FACTAllocationv1_DataRetention]
	AS
BEGIN
	SET NOCOUNT ON		
		/***********************Getting Retention period config values ****************************************************/
	--BEGIN TRAN

	DECLARE @RetentionPeriod INT,
				@RetentionPeriodType VARCHAR(50),
				@RowsPerBatch INT,
				@RetentionConfigId INT

		SELECT @RetentionPeriod = RetentionPeriod
		     , @RetentionPeriodType = RetentionPeriodType
			 , @RowsPerBatch = RowsPerBatch 
			 , @RetentionConfigId = DataRetentionConfigId
		  FROM FDM_PROCESS.[Admin].[DataRetentionConfig] 
		 WHERE TableName = 'FactAllocationsV1_Current'
		
		SET @RetentionPeriod = ISNULL(@RetentionPeriod,0)
			
		DECLARE @RetentionDate DATE
		DECLARE @RetentionAcctPeriod int
		SET @RetentionDate = getdate()
		
		IF (@RetentionPeriodType = 'Days') 
			SET @RetentionDate = DATEADD(DD,-(@RetentionPeriod), GETDATE())
		ELSE IF (@RetentionPeriodType = 'Weeks')
			SET @RetentionDate = DATEADD(WK,-(@RetentionPeriod), GETDATE())
		ELSE IF (@RetentionPeriodType = 'Months')
			SET @RetentionDate = DATEADD(MM,-(@RetentionPeriod), GETDATE())
		ELSE IF (@RetentionPeriodType = 'Years')
			SET @RetentionDate = DATEADD(YY,-(@RetentionPeriod), GETDATE())
		ELSE 
			SET @RetentionDate = DATEADD(DD,-(@RetentionPeriod), GETDATE())
		
		SET @RetentionAcctPeriod=CAST(YEAR(@RetentionDate) AS VARCHAR(4)) +''+ RIGHT('0' + CAST(MONTH(@RetentionDate) AS VARCHAR(2)), 2)
		--SELECT @RetentionDate
		--SELECT @RetentionPeriod,@RetentionPeriodType,@RowsPerBatch
		
		/***************FactAllocationv1_Current table will contain 16 months of data ************************/
		
	
		IF(OBJECT_ID('tempdb..#FactAllocationv1_History') IS NOT NULL)
			DROP TABLE #FactAllocationv1_History

		SELECT T.*,ROW_NUMBER() OVER (ORDER BY T.pk_FACTAllocations) AS RowId
		INTO #FactAllocationv1_History
		FROM FACTAllocationsV1_Current T
		LEFT JOIN dbo.FACTAllocationsV1_History C
		ON T.pk_FACTAllocations = C.pk_FACTAllocations
		WHERE C.pk_FACTAllocations IS NULL AND T.fk_AccountingPeriod<@RetentionAcctPeriod

		ALTER TABLE #FactAllocationv1_History ADD PRIMARY KEY (pk_FACTAllocations) 

		DECLARE @BatchSize INT,@TotalRowsCount INT,@loopCount INT,@StartId INT,@EndId INT,@LoopBatchrowcnt int

		SET @BatchSize = ISNULL(@RowsPerBatch,10000)
		DECLARE @StartTime DATETIME,@EndTime DATETIME
		

		SET @TotalRowsCount = (SELECT COUNT(1) FROM #FactAllocationv1_History)
		
		SET @loopCount = 1
		SET @StartId = 1
		SET @EndId = @BatchSize
		
BEGIN TRY
		


	WHILE (@loopCount < @TotalRowsCount)
		
		BEGIN

		BEGIN TRAN

		SET @StartTime = GETDATE()
		
		INSERT INTO dbo.FACTAllocationsV1_History WITH(TABLOCK)
			(pk_FACTAllocations,pk_tempFactFDM,Source_pk_tempFactFDM,fk_Account,fk_AccountingPeriod,
			 fk_BusinessPlan,fk_ClaimExposure,fk_DataStage,fk_Entity,fk_Expense,fk_Holding,
			 fk_LloydsClassifications,fk_Office,fk_OriginalCurrency,fk_PolicySection,
			 SectionReference,fk_Process,fk_Product,fk_Project,fk_RIPolicy,fk_Scenario,
			 fk_SourceSystem,fk_TriFocus,fk_YOA,fk_Client,bk_TransactionID,VoucherNumber,
			 [Value],cur_amount,currency,value_1,value_2,value_3,fk_User,insert_date,
			 insert_time,voucher_date,transaction_date,tax_code,tax_system,fk_Location,
			 fk_InceptionDate,fk_ExpiryDate,CombinationID,FK_AllocationRules,AllocationPercent,
			 AccountDest,LocationDest,EntityDest,YOADest,ProcessDest,ProjectDest,TriFocusDest,
			 RuleApplicable,AllocationCOde,fk_DimEarnings,fk_TargetEntity,fk_TargetPeriod,
			 fk_PolicySectionV2,TargetCurrencyDest,BatchID,gl_AccountingPeriod,SoftDeleteFlag)
		SELECT pk_FACTAllocations,pk_tempFactFDM,Source_pk_tempFactFDM,fk_Account,fk_AccountingPeriod,
			 fk_BusinessPlan,fk_ClaimExposure,fk_DataStage,fk_Entity,fk_Expense,fk_Holding,
			 fk_LloydsClassifications,fk_Office,fk_OriginalCurrency,fk_PolicySection,
			 SectionReference,fk_Process,fk_Product,fk_Project,fk_RIPolicy,fk_Scenario,
			 fk_SourceSystem,fk_TriFocus,fk_YOA,fk_Client,bk_TransactionID,VoucherNumber,
			 [Value],cur_amount,currency,value_1,value_2,value_3,fk_User,insert_date,
			 insert_time,voucher_date,transaction_date,tax_code,tax_system,fk_Location,
			 fk_InceptionDate,fk_ExpiryDate,CombinationID,FK_AllocationRules,AllocationPercent,
			 AccountDest,LocationDest,EntityDest,YOADest,ProcessDest,ProjectDest,TriFocusDest,
			 RuleApplicable,AllocationCOde,fk_DimEarnings,fk_TargetEntity,fk_TargetPeriod,
			 fk_PolicySectionV2,TargetCurrencyDest,BatchID,gl_AccountingPeriod,SoftDeleteFlag			
		FROM  #FactAllocationv1_History T WHERE RowId BETWEEN @StartId AND @EndId	
		
		SET @LoopBatchrowcnt=@@ROWCOUNT

		DELETE A
		FROM dbo.FACTAllocationsV1_Current A
		INNER JOIN #FactAllocationv1_History B
	    ON A.pk_FACTAllocations = B.pk_FACTAllocations 
		WHERE RowId BETWEEN @StartId AND @EndId		
			
		SET @EndTime = GETDATE()

		INSERT INTO FDM_PROCESS.[Admin].[DataRetentionLog] (fk_DataRetentionConfigId,StartTime,EndTime,[RowCount],CreatedDate,CreatedBy,ActionType)
		SELECT @RetentionConfigId,@StartTime,@EndTime,@LoopBatchrowcnt,GETDATE(),null,'Moved data to History table'

		SET @LoopBatchrowcnt=0

		SET @loopCount += @BatchSize;
		SET @StartId = @EndId + 1 ;
		SET @EndId = @StartId + @BatchSize - 1;	
		
		Commit Tran
	END		 --Whille Loop Completed

	IF(@TotalRowsCount=0)
	BEGIN

		SET @StartTime=GETDATE()
		SET @EndTime=GETDATE()

		INSERT INTO FDM_PROCESS.[Admin].[DataRetentionLog] (fk_DataRetentionConfigId,StartTime,EndTime,[RowCount],CreatedDate,CreatedBy,ActionType)
		SELECT @RetentionConfigId,@StartTime,@EndTime,@TotalRowsCount,GETDATE(),null,'Moved data to History table'
	END

END TRY

	BEGIN CATCH
		IF @@TRANCOUNT>0 
			
			ROLLBACK Tran

				SET @LoopBatchrowcnt=0
	
				SET @EndTime = GETDATE()

				INSERT INTO FDM_PROCESS.[Admin].[DataRetentionLog] (fk_DataRetentionConfigId,StartTime,EndTime,[RowCount],CreatedDate,CreatedBy,ActionType)
				SELECT @RetentionConfigId,@StartTime,@EndTime,@LoopBatchrowcnt,GETDATE(),NULL,SUBSTRING(ERROR_MESSAGE(),1,255)
	END CATCH;
END

