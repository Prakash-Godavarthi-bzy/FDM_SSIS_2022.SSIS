﻿


-- =============================================
-- Author:		Nanda Gottumukkala
-- Create date: 02/10/2015
-- Description:	Get the solvency base data specific to the form
-- =============================================

CREATE PROCEDURE [dbo].[usp_SIIAllocateDataS0502]
 @AccountingPeriodFrom AS INT
,@AccountingPeriodTo AS INT
,@SIIForm AS VARCHAR(255)
,@EntityGroup AS VARCHAR(255)
AS
BEGIN

--SET @SIIForm = 'S.05.02'
--SET @EntityGroup = 'BEREBRQS'

UPDATE AllocationPercentages
SET ReportingCountry = 'GB'
WHERE EntityAllocationGroup = '6107'

UPDATE AllocationPercentages
SET ReportingCountry = 'GB'
WHERE EntityAllocationGroup = '6050'
AND Basis = 'UnderwritingLocation'

--Requirement for ceding Underwriter location
UPDATE AllocationPercentages
SET ReportingCountry = 'GB'
WHERE EntityAllocationGroup = 'BEREBRQS'
--AND Basis = 'UnderwritingLocation'

--------------------------------------------------------
--Description: Added USBESI entity(FIN-8543)
--Date Modified: 12/06/2023
--User: Sruthi Pitchikala(PITCS)
--------------------------------------------------------
UPDATE AllocationPercentages
SET ReportingCountry = 'US'
WHERE EntityAllocationGroup in ('USBICI','USBESI')
--AND Basis = 'UnderwritingLocation'


DELETE FROM SIIAllocatedDataV2
WHERE SIIType = @SIIForm
AND	  EntityReportingType = @EntityGroup
--Siitagacc	Siiagracc	Siiloblv1	Siiloblv1(T)	Siilob	Siilob(T)	Account	Account(T)	Entity	Trifocus	Amount




DECLARE @EntityGroupToReport table(  
    EntityGroup NVARCHAR(255));  

INSERT	INTO @EntityGroupToReport
SELECT	DISTINCT EntityGroup FROM SIIEntityGroups
WHERE	EntityReportingType = @EntityGroup

;WITH CTE AS (
SELECT	DISTINCT LOB,
		Channel,	
		--a.AgressoAccountCategory,
		b.AgressoAccountCategory,	
		a.SIIType,
		ReportingCountry,
		EntityAllocationGroup,
		Value,
		TotalValue,
		a.Basis,
		AllocationPercent = CAST(Value AS DECIMAL(24,12))/CAST(TotalValue AS DECIMAL(24,12))
FROM	AllocationPercentages a
JOIN	SIIAccountAllocationBasis b
ON		a.AgressoAccountCategory = b.AgressoAccountCategoryToAllocate
AND		a.SIIType = b.SIIType
JOIN	@EntityGroupToReport c
ON		c.EntityGroup = EntityAllocationGroup
WHERE	b.SIIType = @SIIForm
)
,CTE2 AS (
SELECT	EntityCode,	
		u.EntityGroup,
		LOB,	
		Channel,	
		AgressoAccountCategory,	
		SIIType,
		u.Basis,
		SUM(cur_amount) AS CurAmount,
		SUM(Value) AS Value
FROM	UnAllocatedDataTF u
JOIN	@EntityGroupToReport c
ON		c.EntityGroup = u.EntityGroup
WHERE	SIIType = @SIIForm
GROUP	BY EntityCode,	
		u.EntityGroup,
		LOB,	
		Channel,	
		AgressoAccountCategory,	
		u.Basis,
		SIIType
)

INSERT INTO [dbo].[SIIAllocatedDataV2]
           ([EntityCode]
           ,[EntityGroup]
           ,[LOB]
           ,[Channel]
           ,[AgressoAccountCategory]
           ,[SIIType]
           ,[Basis]
           ,[Value]
           ,[ReportingCountry]
           ,[AllocationPercent]
           ,[AllocatedValue]
		   ,EntityReportingType)
   
SELECT	CTE2.EntityCode
           ,[EntityGroup]
           ,CTE2.[LOB]
           ,CTE2.[Channel]
           ,CTE2.[AgressoAccountCategory]
           ,CTE2.[SIIType]
           ,CTE2.[Basis]
           ,CTE2.[Value]
		,CASE WHEN (EntityCode = '6050' OR EntityCode = '6107') AND ReportingCountry IS NULL THEN 'GB' ELSE cte.ReportingCountry END AS ReportingCountry
		,cte.AllocationPercent
		,ISNULL((CTE2.Value*CTE.AllocationPercent),CTE2.Value) AS AllocatedValue
		,@EntityGroup AS EntityReportingType
FROM	CTE2  
LEFT	JOIN CTE	  
ON		CTE2.EntityGroup = CTE.EntityAllocationGroup
AND		CTE2.LOB = CTE.LOB
AND		CTE2.Channel = CTE.Channel	
AND		CTE2.AgressoAccountCategory = CTE.AgressoAccountCategory
AND		CTE2.SIIType = CTE.SIIType
AND		CTE2.Basis = cte.Basis


--Update where reporting coutry is unknown or null to GB
UPDATE	SIIAllocatedDataV2
SET		ReportingCountry = 'GB'
WHERE	ReportingCountry IS NULL or ReportingCountry = 'unknown'
AND SIIType = 'S.05.02'

-------------------------------------------------------------
--Description: Added USBESI entity(FIN-8543)
--Date Modified: 12/06/2023
--User: Sruthi Pitchikala(PITCS)
-------------------------------------------------------------
UPDATE	SIIAllocatedDataV2
SET		ReportingCountry = 'US'
WHERE	EntityCode IN ('USBICI','BUCO','USBESI')
AND SIIType = 'S.05.02'

--Requirement for ceding Underwriter location
UPDATE	SIIAllocatedDataV2
SET		ReportingCountry = 'US'
WHERE	EntityCode = '3623'
AND Channel IN ('Accepted Non Proportional Reinsurance','Accepted Proportional Reinsurance')
AND SIIType = 'S.05.02'

END


