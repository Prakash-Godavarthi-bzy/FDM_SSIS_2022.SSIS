﻿


-- =============================================
-- Author:		Nanda Gottumukkala
-- Create date: 02/10/2015
-- Description:	TO log the execution and record movements on the tables
-- =============================================
CREATE PROCEDURE [dbo].[usp_SIIAllocateDataS0401]
 @AccountingPeriodFrom AS INT
,@AccountingPeriodTo AS INT
,@SIIForm AS VARCHAR(255)
,@EntityGroup AS VARCHAR(255)
AS
BEGIN

--SET @SIIForm = 'S.04.01'

--SET @EntityGroup = 'BEREBRQS'

UPDATE AllocationPercentages
SET ReportingCountry = 'GB'
,UnderwritingLocation = 'GB'
,LocationOfRisk = 'GB'
WHERE EntityAllocationGroup = '6107'

UPDATE AllocationPercentages
SET ReportingCountry = 'GB'
,UnderwritingLocation = 'GB'
,LocationOfRisk = 'GB'
WHERE EntityAllocationGroup = '6050'


DECLARE @EntityGroupToReport table(  
    EntityGroup NVARCHAR(255));  

INSERT	INTO @EntityGroupToReport
SELECT	DISTINCT EntityGroup FROM SIIEntityGroups
WHERE	EntityReportingType = @EntityGroup

--SELECT * FROM UnAllocatedData
--WHERE EntityGroup = 'BEREBRQS'

--SELECT * FROM AllocationPercentages
--WHERE EntityAllocationGroup = 'BEREBRQS'

DELETE FROM [SIIAllocatedDataV2]
WHERE SIIType = @SIIForm
AND EntityReportingType = @EntityGroup

;WITH CTE AS (
SELECT	DISTINCT LOB,
		Channel,	
		--a.AgressoAccountCategory,
		b.AgressoAccountCategory,	
		a.SIIType,
		ReportingCountry,
		CASE WHEN (EntityAllocationGroup = '6050' OR EntityAllocationGroup = '6107') THEN 'GB' ELSE UnderwritingLocation END AS UnderwritingLocation,
		CASE WHEN (EntityAllocationGroup = '6050' OR EntityAllocationGroup = '6107') THEN 'GB' ELSE LocationOfRisk END AS LocationOfRisk,
		EntityAllocationGroup,
		Value,
		TotalValue,
		a.Basis,
		AllocationPercent = CAST(Value AS DECIMAL(24,12))/CAST(TotalValue AS DECIMAL(24,12))
FROM	AllocationPercentages a
JOIN	SIIAccountAllocationBasis b
ON		a.AgressoAccountCategory = b.AgressoAccountCategoryToAllocate
AND		a.SIIType = b.SIIType
JOIN	@EntityGroupToReport c
ON		c.EntityGroup = EntityAllocationGroup
WHERE	b.SIIType = @SIIForm
)
,CTE2 AS (
SELECT	EntityCode
		,u.EntityGroup	
		,LOB	
		,Channel	
		,AgressoAccountCategory	
		,SIIType	
		,CASE WHEN (u.EntityGroup = '6050' OR u.EntityGroup = '6107') THEN 'GB' ELSE UnderwritingLocation END AS UnderwritingLocation
		,CASE WHEN (u.EntityGroup = '6050' OR u.EntityGroup = '6107') THEN 'GB' ELSE LocationOfRisk END AS LocationOfRisk
		,OriginalCurrencyCode	
		,Basis	
		,cur_amount	
		,Value
FROM	UnAllocatedDataTF u
JOIN	@EntityGroupToReport c
ON		c.EntityGroup = u.EntityGroup
WHERE	SIIType = @SIIForm

)
,CTE3 AS (

SELECT	EntityCode
		,CTE2.EntityGroup	
		,CTE2.LOB	
		,CTE2.Channel	
		,CTE2.AgressoAccountCategory	
		,CTE2.SIIType	
		,CASE WHEN CTE2.AgressoAccountCategory = 'AC2000' THEN CTE.LocationOfRisk ELSE CTE2.LocationOfRisk END AS LocationOfRisk		
		,CASE WHEN (EntityCode = '6050' OR EntityCode = '6107') AND CTE.UnderwritingLocation IS NULL THEN 'GB' ELSE CASE WHEN CTE.AgressoAccountCategory = 'AC2000' THEN cte.UnderwritingLocation ELSE CTE.ReportingCountry END END AS UnderwritingLocation	
		,OriginalCurrencyCode	
		,CTE2.Basis	
		,cur_amount	
		,CTE2.Value
		,CASE WHEN (EntityCode = '6050' OR EntityCode = '6107') AND ReportingCountry IS NULL THEN 'GB' ELSE cte.ReportingCountry END AS ReportingCountry
		,cte.AllocationPercent
		,ISNULL((CTE2.Value*CTE.AllocationPercent),CTE2.Value) AS AllocatedValue
FROM	CTE2  
LEFT	JOIN CTE	  
ON		CTE2.EntityGroup = CTE.EntityAllocationGroup
AND		CTE2.LOB = CTE.LOB
AND		CTE2.Channel = CTE.Channel	
AND		CTE2.AgressoAccountCategory = CTE.AgressoAccountCategory
AND		CTE2.SIIType = CTE.SIIType
WHERE	CTE2.AgressoAccountCategory = 'AC2000'
UNION
SELECT	EntityCode
		,CTE2.EntityGroup	
		,CTE2.LOB	
		,CTE2.Channel	
		,CTE2.AgressoAccountCategory	
		,CTE2.SIIType	
		,CTE2.LocationOfRisk  AS LocationOfRisk		
		,CASE WHEN (EntityCode = '6050' OR EntityCode = '6107') AND CTE2.UnderwritingLocation IS NULL THEN 'GB' ELSE cte2.UnderwritingLocation END AS UnderwritingLocation	
		,OriginalCurrencyCode	
		,CTE2.Basis	
		,cur_amount	
		,CTE2.Value
		,NULL AS ReportingCountry
		,1.0 AS AllocationPercent
		,CTE2.Value AS AllocatedValue
FROM	CTE2  
WHERE	CTE2.AgressoAccountCategory = 'AC1000'
UNION
SELECT	EntityCode
		,CTE2.EntityGroup	
		,CTE2.LOB	
		,CTE2.Channel	
		,CTE2.AgressoAccountCategory	
		,CTE2.SIIType	
		,CTE2.LocationOfRisk  AS LocationOfRisk		
		,CASE WHEN (EntityCode = '6050' OR EntityCode = '6107') AND CTE2.UnderwritingLocation IS NULL THEN 'GB' ELSE cte2.UnderwritingLocation END AS UnderwritingLocation	
		,OriginalCurrencyCode	
		,CTE2.Basis	
		,cur_amount	
		,CTE2.Value
		,NULL AS ReportingCountry
		,1.0 AS AllocationPercent
		,CTE2.Value AS AllocatedValue
FROM	CTE2  
WHERE	CTE2.AgressoAccountCategory = 'AC300_1000'
)

INSERT		INTO	[SIIAllocatedDataV2] 
			(EntityCode
			,EntityGroup	
			,LOB	
			,Channel	
			,AgressoAccountCategory	
			,SIIType	
			,LocationOfRisk		
			,UnderwritingLocation	
			,OriginalCurrencyCode	
			,Basis	
			,cur_amount	
			,Value
			,ReportingCountry
			,AllocationPercent
			,AllocatedValue
		   ,EntityReportingType)
SELECT	EntityCode
		,EntityGroup	
		,LOB	
		,Channel	
		,AgressoAccountCategory	
		,SIIType	
		,LocationOfRisk		
		,UnderwritingLocation	
		,OriginalCurrencyCode	
		,Basis	
		,cur_amount	
		,Value
		,ReportingCountry
		,AllocationPercent
		,AllocatedValue
		,@EntityGroup AS EntityReportingType
FROM	CTE3

UPDATE	[SIIAllocatedDataV2]
SET		UnderwritingLocation = CASE WHEN @EntityGroup = 'SYNDICATE' AND (UnderwritingLocation IS NULL OR UnderwritingLocation = 'Unknown') AND ReportingCountry  IS NULL AND AgressoAccountCategory <> 'AC2000' THEN 'GB' WHEN @EntityGroup = 'BEREBRQS' THEN 'IE' ELSE UnderwritingLocation END
FROM	[SIIAllocatedDataV2] s
JOIN	SIIEntityGroups sg ON sg.EntityGroup = s.EntityGroup
WHERE	sg.EntityReportingType = @EntityGroup
AND		Basis = 'UnderwritingLocation'
AND		@SIIForm ='S.04.01'


IF		@EntityGroup = 'Syndicate' or @EntityGroup = 'LifeSyndicate'
BEGIN

UPDATE SIIAllocatedDataV2
SET LocationOfRisk = 'GB'
,UnderwritingLocation = 'GB'
WHERE LocationOfRisk IS NULL and UnderwritingLocation IS NULL
AND AgressoAccountCategory = 'AC2000'

UPDATE	SIIAllocatedDataV2 
SET		HOMECountry=
				CASE	WHEN (UnderwritingLocation = 'GB') 
						THEN UnderwritingLocation 
						ELSE NULL 
				END
			
FROM	SIIAllocatedDataV2 t
JOIN	ISOCountry ON t.UnderwritingLocation = ISOCountryCode
WHERE	SIIType = @SIIForm
AND		EntityReportingType = @EntityGroup

UPDATE	SIIAllocatedDataV2 
SET		HomeCountry_Branch= 'GB'
FROM	SIIAllocatedDataV2 t
LEFT	JOIN	ISOCountry uw ON t.UnderwritingLocation = uw.ISOCountryCode
LEFT	JOIN	ISOCountry l ON  t.LocationOfRisk = l.ISOCountryCode
WHERE	SIIType = @SIIForm
AND		HomeCountry = 'GB'
AND		LocationOfRisk = UnderwritingLocation
AND		EntityReportingType = @EntityGroup


UPDATE	SIIAllocatedDataV2 
SET		HomeCountryUW_FPS= 'GB'	
FROM	SIIAllocatedDataV2 t
LEFT	JOIN	ISOCountry uw ON t.UnderwritingLocation = uw.ISOCountryCode
LEFT	JOIN	ISOCountry l ON  t.LocationOfRisk = l.ISOCountryCode
WHERE	SIIType = @SIIForm
AND		HomeCountry = 'GB'
AND		LocationOfRisk <> UnderwritingLocation
AND		l.EEAIdentifier = 'EEA'
AND		EntityReportingType = @EntityGroup

UPDATE	SIIAllocatedDataV2 
SET		NonEEACountry= LocationOfRisk	
FROM	SIIAllocatedDataV2 t
LEFT	JOIN	ISOCountry uw ON t.UnderwritingLocation = uw.ISOCountryCode
LEFT	JOIN	ISOCountry l ON  t.LocationOfRisk = l.ISOCountryCode
WHERE	SIIType = @SIIForm
AND		HomeCountry = 'GB'
AND		LocationOfRisk <> UnderwritingLocation
AND		l.EEAIdentifier = 'Non-EEA'
AND		EntityReportingType = @EntityGroup

--)
UPDATE	SIIAllocatedDataV2 
SET		NonEEACountry = UnderwritingLocation
FROM	SIIAllocatedDataV2 v
LEFT	JOIN ISOCountry lor
ON		LocationOfRisk = lor.ISOCountryCode
LEFT	JOIN ISOCountry uw
ON		UnderwritingLocation = uw.ISOCountryCode
WHERE	HomeCountry IS NULL
AND		EEACountryUW_FPS IS NULL
AND		EEACountryUW_Branch IS NULL
AND		[EEACountryLOR_FPS] IS NULL
AND		SIIType = @SIIForm
AND		EntityReportingType = @EntityGroup
AND		uw.EEAIdentifier = 'Non-EEA'

UPDATE	SIIAllocatedDataV2 
SET		EEACountryUW_FPS = UnderwritingLocation
,		HomeCountryLOR_FPS =  LocationOfRisk  
FROM	SIIAllocatedDataV2 
LEFT	JOIN	ISOCountry lor
ON		LocationOfRisk = lor.ISOCountryCode
LEFT	JOIN	ISOCountry uw
ON		UnderwritingLocation = uw.ISOCountryCode
WHERE	HOMECountry IS NULL
AND		LocationOfRisk = 'GB'
AND		SIIType = @SIIForm
AND		EntityReportingType = @EntityGroup
AND		uw.EEAIdentifier <> 'NON-EEA'

UPDATE	SIIAllocatedDataV2 
SET		[EEACountryUW_Branch] = LocationOfRisk  
FROM	SIIAllocatedDataV2 
LEFT	JOIN	ISOCountry lor
ON		LocationOfRisk = lor.ISOCountryCode
LEFT	JOIN	ISOCountry uw
ON		UnderwritingLocation = uw.ISOCountryCode
WHERE	HOMECountry IS NULL
AND		LocationOfRisk <> 'GB'
AND		LocationOfRisk = UnderwritingLocation
AND		SIIType = @SIIForm
AND		EntityReportingType = @EntityGroup
AND		uw.EEAIdentifier = 'EEA'

UPDATE	SIIAllocatedDataV2 
SET		[EEACountryUW_Branch] = UnderwritingLocation  
FROM	SIIAllocatedDataV2 
LEFT	JOIN	ISOCountry uw
ON		UnderwritingLocation = uw.ISOCountryCode
WHERE	HOMECountry IS NULL
AND		[EEACountryUW_Branch] IS NULL
AND		(LocationOfRisk = 'Unknown' OR LocationOfRisk IS NULL)
AND		SIIType = @SIIForm
AND		EntityReportingType = @EntityGroup
AND		uw.EEAIdentifier = 'EEA'

UPDATE	SIIAllocatedDataV2 
SET		[EEACountryUW_FPS] = UnderwritingLocation  
,		[EEACountryLOR_FPS] = LocationOfRisk
FROM	SIIAllocatedDataV2 v
LEFT	JOIN	ISOCountry lor
ON		LocationOfRisk = lor.ISOCountryCode
LEFT	JOIN	ISOCountry uw
ON		UnderwritingLocation = uw.ISOCountryCode
WHERE	HomeCountry IS NULL
AND		EEACountryUW_FPS IS NULL
AND		EEACountryUW_Branch IS NULL
AND		SIIType = @SIIForm
AND		EntityReportingType = @EntityGroup
AND		lor.EEAIdentifier = 'EEA'
AND		uw.EEAIdentifier = 'EEA'

UPDATE	SIIAllocatedDataV2 
SET		NonEEACountry = LocationOfRisk
FROM	SIIAllocatedDataV2 v
LEFT	JOIN	ISOCountry lor
ON		LocationOfRisk = lor.ISOCountryCode
LEFT	JOIN	ISOCountry uw
ON		UnderwritingLocation = uw.ISOCountryCode
WHERE	HomeCountry IS NULL
AND		EEACountryUW_FPS IS NULL
AND		EEACountryUW_Branch IS NULL
AND		[EEACountryLOR_FPS] IS NULL
AND		[NonEEACountry] IS NULL
AND		SIIType = @SIIForm
AND		EntityReportingType = @EntityGroup
AND		lor.EEAIdentifier = 'Non-EEA'

UPDATE	SIIAllocatedDataV2 
SET		NonEEACountry = UnderwritingLocation  
FROM	SIIAllocatedDataV2 
LEFT	JOIN	ISOCountry uw
ON		UnderwritingLocation = uw.ISOCountryCode
WHERE	HomeCountry IS NULL
AND		EEACountryUW_FPS IS NULL
AND		EEACountryUW_Branch IS NULL
AND		[EEACountryLOR_FPS] IS NULL
AND		[NonEEACountry] IS NULL
AND		(LocationOfRisk = 'Unknown' OR LocationOfRisk IS NULL)
AND		SIIType = @SIIForm
AND		EntityReportingType = @EntityGroup
AND		uw.EEAIdentifier = 'Non-EEA'

UPDATE	SIIAllocatedDataV2 
SET		HomeCountry_Branch = UnderwritingLocation  
FROM	SIIAllocatedDataV2 
WHERE	SIIType = @SIIForm
AND		EntityReportingType = @EntityGroup
AND NOT (EEACountryUW_FPS IS NOT NULL OR	EEACountryUW_Branch IS NOT NULL OR		EEACountryLOR_Branch IS NOT NULL OR		EEACountryLOR_FPS IS NOT NULL OR NonEEACountry IS NOT NULL OR	
		HomeCountry_Branch	IS NOT NULL OR	 HomeCountryUW_FPS	IS NOT NULL OR	 HomeCountryLOR_FPS IS NOT NULL )

END
ELSE
BEGIN
UPDATE	SIIAllocatedDataV2 
SET		HOMECountry= 'IE'
FROM	SIIAllocatedDataV2 t
JOIN	ISOCountry ON t.UnderwritingLocation = ISOCountryCode
WHERE	SIIType = @SIIForm
AND		EntityReportingType = @EntityGroup

UPDATE	SIIAllocatedDataV2 
SET		HomeCountry_Branch= 'IE'
FROM	SIIAllocatedDataV2 t
JOIN	ISOCountry ON t.UnderwritingLocation = ISOCountryCode
WHERE	SIIType = @SIIForm
AND		EntityReportingType = @EntityGroup

END

END

