﻿-- =============================================
-- Author:		<Nanda Gottumukkala>
-- Create date: <13/11/2015>
-- Description:	<Description>
-- =============================================

CREATE PROCEDURE [dbo].[usp_GetAllocationsV4]
	@AllocationCode AS VARCHAR(100)
	,@AllocationGroup AS VARCHAR(100) =''
	,@IntradayFlag AS BIT
	,@MAXTranID AS BIGINT = 0
	,@Adhoc AS BIT
	,@AccountingPeriod AS INT = 0
WITH RECOMPILE 
AS
BEGIN

DECLARE  @locAllocationCode AS VARCHAR(100)
DECLARE  @minAccountFrom AS VARCHAR(255)
DECLARE  @MaxAccountTO AS VARCHAR(255)
DECLARE  @OrderofCurrentAllocation AS INT
DECLARE	 @MaxCombinationID AS BIGINT
DECLARE	 @TriggersChanged AS INT
DECLARE	 @YoungestYear AS INT

SET		@locAllocationCode = @AllocationCode

SELECT	@minAccountFrom = MIN(a.AccountFrom)  
		,@MaxAccountTO = MAX(a.AccountTo)  
FROM	dbo.DimAllocationRules a
WHERE		a.IsCurrent = 1
AND		AllocationGroup = @AllocationGroup

SELECT @TriggersChanged= [dbo].[usf_getTriggerChangedStatus] (@AllocationGroup,@AllocationCode)

IF OBJECT_ID('tempdb..#AllocationRules') IS NOT NULL
    DROP TABLE #AllocationRules

IF OBJECT_ID('tempdb..#AllocationOrder') IS NOT NULL
    DROP TABLE #AllocationOrder

IF OBJECT_ID('tempdb..#YOAIncrements') IS NOT NULL
    DROP TABLE #YOAIncrements

;WITH CTE_YR AS (
SELECT 'YR' AS YOACode, YEAR(GETDATE()) AS YOA
UNION
SELECT 'YR-1' AS YOACode, YEAR(GETDATE())-1 AS YOA
UNION
SELECT 'YR-2' AS YOACode, YEAR(GETDATE())-2 AS YOA
UNION
SELECT 'YR-3' AS YOACode, YEAR(GETDATE())-3 AS YOA
UNION
SELECT 'YR-4' AS YOACode, YEAR(GETDATE())-4 AS YOA
UNION
SELECT 'YR-5' AS YOACode, YEAR(GETDATE())-5 AS YOA
)
SELECT * INTO #YOAIncrements
FROM CTE_YR




CREATE TABLE #AllocationRules(
	[RowId] INT IDENTITY(1,1),
	[AccountFrom] [nvarchar](50) NOT NULL,
	[AccountTo] [nvarchar](50) NULL,
	[EntityFrom] [nvarchar](50) NOT NULL,
	[EntityTo] [nvarchar](50) NULL,
	[TargetEntityFrom] [nvarchar](50) NOT NULL,
	[TargetEntityTo] [nvarchar](50) NULL,
	[TrifocusFrom] [nvarchar](50) NOT NULL,
	[TrifocusTo] [nvarchar](50) NULL,
	[ProcessFrom] [nvarchar](50) NOT NULL,
	[ProcessTo] [nvarchar](50) NULL,
	[ProjectFrom] [nvarchar](50) NULL,
	[ProjectTo] [nvarchar](50) NULL,
	[LocationFrom] [nvarchar](50) NULL,
	[LocationTo] [nvarchar](50) NULL,
	[YOAFrom] [nvarchar](50) NULL,
	[YOATo] [nvarchar](50) NULL,
	[AllocationGroup] [nvarchar](50) NULL,
	[AllocationGroupCodeVersion] [int] NULL,
	[AllocationCode] [nvarchar](50) NULL,
	IsCurrent [int] NULL,
	[RuleID] [int] NOT NULL,
	[AccountDest] [nvarchar](50) NULL,
	[TriFocusDest] [nvarchar](50) NULL,
	[EntityDest] [nvarchar](50) NULL,
	[LocationDest] [nvarchar](50) NULL,
	[ProjectDest] [nvarchar](50) NULL,
	[YOADest] [nvarchar](50) NULL,
	[ProcessDest] [nvarchar](50) NULL,
	[StepCode] [nvarchar](4) NULL,
	[TargetPeriodDest] [nvarchar](50) NULL,
	[TargetEntityDest] [nvarchar](50) NULL,
	[TargetCurrencyDest] [nvarchar] (50) NULL,
	[AllocationPercent] [decimal](28, 8) NOT NULL,
	[BatchID] INT NOT NULL,  /*Added BatchID to loop through batches to bridge*/
	Changetype Varchar(50)
) 




CREATE TABLE #AllocationOrder(
	[AllocationCode] [nvarchar](50) NULL,
	[RunOrder] [bigint] NULL
) 

INSERT INTO #AllocationOrder
SELECT	DISTINCT [AllocationCode]
		,RANK() OVER (ORDER BY [AllocationCode] ASC) AS  [RunOrder]
FROM	dbo.DimAllocationRules
WHERE	AllocationGroup = @AllocationGroup
AND		IsCurrent = 1
ORDER BY RunOrder

SELECT	@OrderofCurrentAllocation =  [RunOrder] 
FROM	#AllocationOrder
WHERE	AllocationCode = @AllocationCode

DELETE	FROM #AllocationOrder
WHERE	[RunOrder] < @OrderofCurrentAllocation

INSERT INTO #AllocationRules
SELECT  ISNULL(AccountFrom,'') AccountFrom
			,CASE WHEN CHARINDEX('~',AccountTo)>0 THEN 'ZZZZ'
			ELSE AccountTo END  AccountTo 
			,ISNULL(EntityFrom,'') EntityFrom
			,CASE WHEN CHARINDEX('~',EntityTo)>0 THEN 'ZZZZ'
			ELSE EntityTo END  EntityTo
			,ISNULL(TargetEntityFrom,'') TargetEntityFrom
			,CASE WHEN CHARINDEX('~',TargetEntityTo)>0 THEN 'ZZZZ'
			ELSE TargetEntityTo END  TargetEntityTo
			,ISNULL(TrifocusFrom,'') TrifocusFrom
			,CASE WHEN CHARINDEX('~',TrifocusTo)>0 THEN 'ZZZZ'
			ELSE TrifocusTo END TrifocusTo
			,ISNULL(ProcessFrom,'') ProcessFrom
			,CASE WHEN CHARINDEX('~',ProcessTo)>0 THEN 'ZZZZ'
			ELSE ProcessTo END ProcessTo
			,CASE WHEN ProjectFrom='-1' THEN ''
			ELSE ProjectFrom END  ProjectFrom
			,CASE WHEN CHARINDEX('~',ProjectTo)>0 THEN 'ZZZZ'
			ELSE ProjectTo END  ProjectTo
			,CASE WHEN LocationFrom='-1' THEN ''
			ELSE LocationFrom END  LocationFrom
			,CASE WHEN CHARINDEX('~',LocationTo)>0 THEN 'ZZZZ'
				 WHEN LocationTo='-1' THEN 'ZZZZ'
			ELSE LocationTo END  LocationTo
			,CASE WHEN YOAFrom='' THEN '0'
			ELSE YOAFrom END  YOAFrom
			,CASE WHEN CHARINDEX('~',YOATo)>0 THEN 'ZZZZ'
				 WHEN YOATo='-1' THEN 'ZZZZ'
			ELSE YOATo END  YOATo
			,AllocationGroup
			,AllocationGroupCodeVersion
			,[AllocationCode]
			,IsCurrent
			--,PK_AllocationRules AS RuleID
			,PK_Alt_AllocationRules AS RuleID
			,AccountDest
			,TriFocusDest
			,EntityDest
			,LocationDest
			,ProjectDest
			,YOADest
			,ProcessDest
			,StepCode
			,TargetPeriodDest
			,TargetEntityDest
			,[TargetCurrencyDest]
			,AllocationPercent
			,100000 AS BatchID /*Default of 100000 added as BathcID*/
			,ChangeType
	FROM	dbo.DimAllocationRules
	WHERE	[AllocationCode] = @locAllocationCode
	AND	  AllocationGroup IN (
			CASE	WHEN	@Adhoc = 1 AND @AllocationGroup <> '' THEN @AllocationGroup
					WHEN 	@IntradayFlag = 1 THEN (SELECT AllocationGroup FROM RealTimeAllocations)
					WHEN 	@IntradayFlag = 0 AND @Adhoc = 0 THEN @AllocationGroup
			ELSE	''
		  END)
    AND		IsCurrent = 1

UPDATE	#AllocationRules
SET		YOAFrom = YOA
FROM	#AllocationRules
JOIN	#YOAIncrements ON YOACode = YOAFrom

UPDATE	#AllocationRules
SET		YOATo = YOA
FROM	#AllocationRules
JOIN	#YOAIncrements ON YOACode = YOATo

SELECT	@MaxCombinationID = ISNULL(MAX(CombinationID),0)
FROM	BriExpensesTransactionDetailsV4 b
JOIN	#AllocationRules a
ON		a.RuleID = b.FK_AllocationRules 
WHERE	a.AllocationGroup = @AllocationGroup
AND		a.IsCurrent = 1

/*Logic to split the rules into batches of size 500*/

DECLARE @current int = 1
DECLARE @BatchSize int = 500
DECLARE @NoOfBatch int 
DECLARE @batchStart int 

SELECT	@batchStart = MIN([RowId]),@NoOfBatch =(COUNT(*)/@BatchSize)+1 FROM #AllocationRules

WHILE	@current <= @NoOfBatch
BEGIN

UPDATE	#AllocationRules
SET		BatchID=@current
WHERE	[RowId] BETWEEN @batchStart AND @batchStart+@BatchSize

SET	@current = @current + 1
SET	@batchStart = @batchStart+@BatchSize

END

/*Logic of batch split ends here*/

TRUNCATE TABLE BriExpensesTransactionDetailsV4_Stage

IF	@TriggersChanged = 1
BEGIN

/* Logic to to loop through batches and stage the results into BriExpensesTransactionDetailsV4_Stage - Looping only happens when triggers are changed*/

	DECLARE	@CurrentBatchID int = 1
	DECLARE	@MaxBatchNo int 

	SELECT	@CurrentBatchID = MIN(BatchID),@MaxBatchNo =MAX(BatchID) FROM #AllocationRules

	WHILE	@CurrentBatchID <= @MaxBatchNo
	BEGIN
	
		IF	OBJECT_ID('tempdb..#BatchAllocationRules') IS NOT NULL
		DROP TABLE #BatchAllocationRules
		
		SELECT	* INTO #BatchAllocationRules 
		FROM	#AllocationRules
		WHERE	BatchID=@CurrentBatchID

		INSERT	INTO BriExpensesTransactionDetailsV4_Stage
		SELECT	a.AccountCode
				,a.ProcessCode
				,a.TriFocusCode
				,a.EntityCode
				,a.LocationCode
				,a.ProjectCode
				,a.TargetEntity
				,YOAName AS YOA 
				,b.RuleID
				,b.AllocationCode
				,b.AllocationGroup
				,b.AllocationGroupCodeVersion
				,b.StepCode
				,CASE WHEN (ISNULL(b.AccountDest,a.AccountCode))='' THEN a.AccountCode ELSE  b.AccountDest END AccountDest
				,CASE WHEN ISNULL(b.TriFocusDest,TriFocusCode) ='' THEN a.TriFocusCode ELSE  b.TriFocusDest END TriFocusDest
				,CASE WHEN ISNULL(b.EntityDest,EntityCode)='' THEN a.EntityCode ELSE  b.EntityDest END EntityDest
				,CASE WHEN ISNULL(ProcessDest,a.ProcessCode)='' THEN a.ProcessCode ELSE  b.ProcessDest END ProcessDest
				,CASE WHEN ISNULL(LocationDest,a.LocationCode)='' THEN a.LocationCode ELSE  b.LocationDest END LocationDest
				,CASE WHEN ISNULL(ProjectDest,a.ProjectCode)='' THEN a.ProjectCode ELSE  b.ProjectDest END ProjectDest
				,CASE WHEN ISNULL(b.YOADest,YOAName)='' THEN YOAName ELSE b.YOADest END  AS YOADest
				,CASE WHEN ISNULL(b.TargetEntityDest,a.TargetEntity)='' THEN TargetEntity ELSE b.TargetEntityDest END  AS TargetEntityDest
				,b.TargetPeriodDest
				,b.TargetCurrencyDest
				,b.AllocationPercent
				,a.CombinationID
		FROM	[dbo].[DimAllocationCombinations](nolock) a
		JOIN	DimYOA ON pk_YOA =  CASE 
					WHEN Isnumeric([YOA])=1 THEN [YOA] 
					WHEN [YOA]='CALX' THEN 9999 
					WHEN [YOA]='NOYOA' THEN 9998
					WHEN [YOA]='OLD' THEN 9997
					ELSE -1  END
		JOIN #BatchAllocationRules b 
		ON a.AccountCode between b.AccountFrom AND b.AccountTo
		AND a.TriFocusCode between b.TrifocusFrom AND b.TrifocusTo
		AND a.EntityCode Between b.EntityFrom AND b.EntityTo
		AND a.ProjectCode between b.ProjectFrom AND b.ProjectTo
		AND a.LocationCode between b.LocationFrom AND b.LocationTo
		AND a.ProcessCode between b.ProcessFrom AND b.ProcessTo
		AND ISNULL(a.TargetEntity,'') between b.TargetEntityFrom AND b.TargetEntityTo
		AND YOAName between b.YOAFrom AND b.YOATo
		WHERE a.AccountCode BETWEEN @minAccountFrom AND ISNULL(@MaxAccountTO,99999)
		AND ProcessCode NOT IN (SELECT [AllocationCode] FROM #AllocationOrder)
		AND     B.ChangeType IN ('NEW', 'Percent Update')
UNION ALL
		SELECT	a.AccountCode
				,a.ProcessCode
				,a.TriFocusCode
				,a.EntityCode
				,a.LocationCode
				,a.ProjectCode
				,a.TargetEntity
				,YOAName AS YOA 
				,b.RuleID
				,b.AllocationCode
				,b.AllocationGroup
				,b.AllocationGroupCodeVersion
				,b.StepCode
				,CASE WHEN (ISNULL(b.AccountDest,a.AccountCode))='' THEN a.AccountCode ELSE  b.AccountDest END AccountDest
				,CASE WHEN ISNULL(b.TriFocusDest,TriFocusCode) ='' THEN a.TriFocusCode ELSE  b.TriFocusDest END TriFocusDest
				,CASE WHEN ISNULL(b.EntityDest,EntityCode)='' THEN a.EntityCode ELSE  b.EntityDest END EntityDest
				,CASE WHEN ISNULL(ProcessDest,a.ProcessCode)='' THEN a.ProcessCode ELSE  b.ProcessDest END ProcessDest
				,CASE WHEN ISNULL(LocationDest,a.LocationCode)='' THEN a.LocationCode ELSE  b.LocationDest END LocationDest
				,CASE WHEN ISNULL(ProjectDest,a.ProjectCode)='' THEN a.ProjectCode ELSE  b.ProjectDest END ProjectDest
				,CASE WHEN ISNULL(b.YOADest,YOAName)='' THEN YOAName ELSE b.YOADest END  AS YOADest
				,CASE WHEN ISNULL(b.TargetEntityDest,a.TargetEntity)='' THEN TargetEntity ELSE b.TargetEntityDest END  AS TargetEntityDest
				,b.TargetPeriodDest
				,b.TargetCurrencyDest
				,b.AllocationPercent
				,a.CombinationID
		FROM [dbo].[DimAllocationCombinations](nolock) a
		JOIN DimYOA ON pk_YOA =  CASE 
					WHEN Isnumeric([YOA])=1 THEN [YOA] 
					WHEN [YOA]='CALX' THEN 9999 
					WHEN [YOA]='NOYOA' THEN 9998
					WHEN [YOA]='OLD' THEN 9997
					ELSE -1  END
		JOIN #BatchAllocationRules b 
		ON a.AccountCode between b.AccountFrom AND b.AccountTo
		AND a.TriFocusCode between b.TrifocusFrom AND b.TrifocusTo
		AND a.EntityCode Between b.EntityFrom AND b.EntityTo
		AND a.ProjectCode between b.ProjectFrom AND b.ProjectTo
		AND a.LocationCode between b.LocationFrom AND b.LocationTo
		AND a.ProcessCode between b.ProcessFrom AND b.ProcessTo
		AND ISNULL(a.TargetEntity,'') between b.TargetEntityFrom AND b.TargetEntityTo
		AND YOAName between b.YOAFrom AND b.YOATo
		WHERE a.AccountCode BETWEEN @minAccountFrom AND @MaxAccountTO
		AND ProcessCode NOT IN (SELECT [AllocationCode] FROM #AllocationOrder)
		AND a.CombinationID>@MaxCombinationID AND  B.ChangeType ='No Change'
		
		SET @CurrentBatchID = @CurrentBatchID+1
	END

/*Logic of looping ends here*/

END
ELSE
BEGIN
	SET @CurrentBatchID = 1

	SELECT	@CurrentBatchID = MIN(BatchID),@MaxBatchNo =MAX(BatchID) FROM #AllocationRules

	WHILE	@CurrentBatchID <= @MaxBatchNo
	BEGIN
	
		IF	OBJECT_ID('tempdb..#BatchAllocationRules_New') IS NOT NULL
		DROP TABLE #BatchAllocationRules_New
		
		SELECT	* INTO #BatchAllocationRules_New 
		FROM	#AllocationRules
		WHERE	BatchID=@CurrentBatchID

		INSERT	INTO BriExpensesTransactionDetailsV4_Stage
		SELECT	a.AccountCode
				,a.ProcessCode
				,a.TriFocusCode
				,a.EntityCode
				,a.LocationCode
				,a.ProjectCode
				,a.TargetEntity
				,YOAName AS YOA 
				,b.RuleID
				,b.AllocationCode
				,b.AllocationGroup
				,b.AllocationGroupCodeVersion
				,b.StepCode
				,CASE WHEN (ISNULL(b.AccountDest,a.AccountCode))='' THEN a.AccountCode ELSE  b.AccountDest END AccountDest
				,CASE WHEN ISNULL(b.TriFocusDest,TriFocusCode) ='' THEN a.TriFocusCode ELSE  b.TriFocusDest END TriFocusDest
				,CASE WHEN ISNULL(b.EntityDest,EntityCode)='' THEN a.EntityCode ELSE  b.EntityDest END EntityDest
				,CASE WHEN ISNULL(ProcessDest,a.ProcessCode)='' THEN a.ProcessCode ELSE  b.ProcessDest END ProcessDest
				,CASE WHEN ISNULL(LocationDest,a.LocationCode)='' THEN a.LocationCode ELSE  b.LocationDest END LocationDest
				,CASE WHEN ISNULL(ProjectDest,a.ProjectCode)='' THEN a.ProjectCode ELSE  b.ProjectDest END ProjectDest
				,CASE WHEN ISNULL(b.YOADest,YOAName)='' THEN YOAName ELSE b.YOADest END  AS YOADest
				,CASE WHEN ISNULL(b.TargetEntityDest,a.TargetEntity)='' THEN TargetEntity ELSE b.TargetEntityDest END  AS TargetEntityDest
				,b.TargetPeriodDest
				,b.TargetCurrencyDest
				,b.AllocationPercent
				,a.CombinationID
		FROM	[dbo].[DimAllocationCombinations](nolock) a
		JOIN	DimYOA ON pk_YOA = CASE 
					WHEN Isnumeric([YOA])=1 THEN [YOA] 
					WHEN [YOA]='CALX' THEN 9999 
					WHEN [YOA]='NOYOA' THEN 9998
					WHEN [YOA]='OLD' THEN 9997
					ELSE -1  END
		JOIN	#BatchAllocationRules_New b 
		ON		a.AccountCode between b.AccountFrom AND b.AccountTo
		AND		a.TriFocusCode between b.TrifocusFrom AND b.TrifocusTo
		AND		a.EntityCode Between b.EntityFrom AND b.EntityTo
		AND		a.ProjectCode between b.ProjectFrom AND b.ProjectTo

		AND		a.LocationCode between b.LocationFrom AND b.LocationTo
		AND		a.ProcessCode between b.ProcessFrom AND b.ProcessTo
		AND		YOAName between b.YOAFrom AND b.YOATo
		AND		ISNULL(a.TargetEntity,'') between b.TargetEntityFrom AND b.TargetEntityTo
		WHERE	a.AccountCode BETWEEN ISNULL(@minAccountFrom,'') AND ISNULL(@MaxAccountTO,'99999')
		AND		a.CombinationID > @MaxCombinationID 
		AND		ProcessCode NOT IN (SELECT [AllocationCode] FROM #AllocationOrder)
	
		SET @CurrentBatchID = @CurrentBatchID+1
	END
END



IF OBJECT_ID('tempdb..#AllocationRules') IS NOT NULL
    DROP TABLE #AllocationRules

IF OBJECT_ID('tempdb..#YOAIncrements') IS NOT NULL
    DROP TABLE #YOAIncrements

END
GO
