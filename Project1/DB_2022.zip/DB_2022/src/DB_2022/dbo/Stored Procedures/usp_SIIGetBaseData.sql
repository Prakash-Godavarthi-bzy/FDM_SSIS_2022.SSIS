﻿


-- =============================================
-- Author:		Nanda Gottumukkala
-- Create date: 02/10/2015
-- Description:	Get the solvency base data specific to the form
-- =============================================

CREATE PROCEDURE [dbo].[usp_SIIGetBaseData]
 @AccountingPeriodFrom AS INT
, @AccountingPeriodTo AS INT
,@SIIForm AS VARCHAR(255)
AS
BEGIN

--SET @AccountingPeriodFrom = 201501
--SET @AccountingPeriodTo = 201512
----SET @SIIForm = 'S.04.01'
--SET @SIIForm = 'S.05.02'

DECLARE @MovementDateFrom AS DATE
DECLARE @MovementDateTo AS DATE

SELECT @MovementDateFrom = CAST(CAST(CASE WHEN @AccountingPeriodFrom%100 = 00 THEN @AccountingPeriodFrom+1 else @AccountingPeriodFrom END  AS VARCHAR(6))+'01' as datetime)
SELECT @MovementDateTo = CAST(CAST( CASE WHEN @AccountingPeriodTo%100 = 13 THEN @AccountingPeriodTo -1  else @AccountingPeriodTo END  AS VARCHAR(6))+'01' as datetime)
SELECT @MovementDateTo = CAST(CAST(CASE WHEN @AccountingPeriodTo%100 = 13 THEN @AccountingPeriodTo -1  else @AccountingPeriodTo END  AS VARCHAR(6))+CAST(DAY(EOMONTH(@MovementDateTo))AS VARCHAR(2)) as datetime)  

DELETE FROM UnAllocatedData
WHERE SIIType = @SIIForm

;WITH CTE  AS (
SELECT	EntityCode,
		TrifocusCode,
		AgressoAccountCategory,
		SIIType,
		OrigLocationOfRisk,
		OrigUnderwritingLocation ,
		ISNULL(b.LocationOfRisk,'Unknown') AS LocationOfRisk,  
		ISNULL(CASE WHEN (b.UnderwritingLocation IS NULL OR b.UnderwritingLocation ='Unknown') AND EntityCode = '6050' AND (AgressoAccountCategory <> 'AC2000' AND AgressoAccountCategory <> 'AC2100') THEN 'GB' ELSE b.UnderwritingLocation END ,'Unknown') AS UnderwritingLocation,
		ISNULL(b.OriginalCurrencyCode,'Unknown') AS OriginalCurrencyCode,
		SUM(ISNULL(cur_amount,0.00)) cur_amount,
		SUM(ISNULL(Value,0.00)) Value
FROM	FactFDM f
JOIN	(SELECT s.*,pk_Account FROM  SIIAccountMapping s
		 JOIN DimAccount ON AgressoAccount = AccountCode 	 WHERE SIIType = @SIIForm) a
ON		a.pk_Account = f.fk_Account
JOIN	DimTrifocus t
ON		t.pk_Trifocus = f.fk_TriFocus
JOIN	DimEntity e
ON		e.pk_Entity = f.fk_Entity
LEFT	JOIN v_SIIPolicyLocationsMapping b
ON		b.pk_PolicySection = f.fk_SIIPolicy
WHERE	fk_AccountingPeriod >= @AccountingPeriodFrom AND fk_AccountingPeriod <=@AccountingPeriodTo
AND		fk_scenario = 1
AND		a.SIIType = @SIIForm
GROUP	BY 
		EntityCode,
		TrifocusCode,
		AgressoAccountCategory,
		SIIType,
		ISNULL(b.LocationOfRisk,'Unknown'),
		ISNULL(CASE WHEN (b.UnderwritingLocation IS NULL OR b.UnderwritingLocation ='Unknown') AND EntityCode = '6050' AND (AgressoAccountCategory <> 'AC2000' AND AgressoAccountCategory <> 'AC2100') THEN 'GB' ELSE b.UnderwritingLocation END ,'Unknown'),
		ISNULL(b.OriginalCurrencyCode,'Unknown'),
		OrigLocationOfRisk,
		OrigUnderwritingLocation 
)
,CTE2 AS (
SELECT	EntityCode
		,EntityGroup
		,e.LOB
		,e.Channel
		,AgressoAccountCategory
		,SIIType
		,LocationOfRisk		
		,UnderwritingLocation
		,OriginalCurrencyCode
		,SUM(ISNULL(cur_amount,0.00)) cur_amount
		,SUM(ISNULL(Value,0.00)) Value
		,OrigLocationOfRisk
		,OrigUnderwritingLocation
FROM	CTE 
JOIN	vw_SIILOBMappingV1 e
ON		e.Entity = cte.EntityCode
AND		e.TrifocusCode = CTE.TrifocusCode
GROUP	BY EntityCode
		,EntityGroup
		,e.LOB
		,e.Channel
		,AgressoAccountCategory
		,SIIType
		,LocationOfRisk
		,OrigLocationOfRisk
		,UnderwritingLocation
		,OrigUnderwritingLocation
		,OriginalCurrencyCode
)


INSERT INTO [dbo].[UnAllocatedData]
           ([EntityCode]
           ,[EntityGroup]
           ,[LOB]
           ,[Channel]
           ,[AgressoAccountCategory]
           ,[SIIType]
           ,[LocationOfRisk]
           ,[UnderwritingLocation]
           ,[OriginalCurrencyCode]
           ,[Basis]
           ,[cur_amount]
           ,[Value]
           ,[OrigUnderwritingLocation]
           ,[OrigLocationOfRisk])
SELECT DISTINCT EntityCode
		,EntityGroup
		,e.LOB
		,e.Channel
		,AgressoAccountCategory
		,SIIType
		,LocationOfRisk
		,UnderwritingLocation
		,OriginalCurrencyCode
		,CASE WHEN @SIIForm = 'S.04.01' THEN 'UnderwritingLocation' ELSE  l.Basis END AS Basis
		,cur_amount
		,Value
		,ISNULL(OrigUnderwritingLocation,'Unknown') AS OrigUnderwritingLocation
		,ISNULL(OrigLocationOfRisk,'Unknown') AS OrigUnderwritingLocation
FROM	CTE2 e
LEFT	JOIN SIILOBAllocationBasis l
ON		LTRIM(RTRIM(l.LOB))=LTRIM(RTRIM(e.LOB))
AND		LTRIM(RTRIM(l.Channel))=LTRIM(RTRIM(e.Channel))
WHERE	EntityGroup IS NOT NULL

UPDATE	UnAllocatedData
SET		UnderwritingLocation = 'GB'
WHERE	@SIIForm = 'S.04.01' AND SIIType = @SIIForm AND UnderwritingLocation = 'Unknown'


DELETE FROM UnAllocatedDataTF
WHERE	SIIType = @SIIForm

INSERT INTO [dbo].[UnAllocatedDataTF]
           ([EntityCode]
           ,[EntityGroup]
           ,[LOB]
           ,[Channel]
           ,[AgressoAccountCategory]
           ,[SIIType]
           ,[LocationOfRisk]
           ,[UnderwritingLocation]
           ,[OriginalCurrencyCode]
           ,[Basis]
           ,[cur_amount]
           ,[Value]
           ,[OrigUnderwritingLocation]
           ,[OrigLocationOfRisk])
 SELECT	 EntityCode
		,EntityGroup
		,LOB
		,Channel
		,AgressoAccountCategory
		,SIIType
		,LocationOfRisk
		,UnderwritingLocation
		,OriginalCurrencyCode
		,Basis
		,cur_amount
		,Value 
		,OrigUnderwritingLocation
		,OrigLocationOfRisk
FROM	UnAllocatedData
WHERE	LOB IS NOT NULL AND LTRIM(RTRIM(LOB)) <>''
AND		SIIType=@SIIForm 

--Allocation of Unknown LOB and Channel combinations

;WITH CTE AS (
SELECT	EntityCode
		,EntityGroup
		,LOB
		,Channel
		,AgressoAccountCategory
		,SIIType
		--,Basis
		,SUM(Value) AS Value
 FROM	UnAllocatedDataTF
 WHERE	LOB IS NOT NULL
 AND		SIIType=@SIIForm 
 GROUP	BY EntityCode
		,EntityGroup
		,LOB
		,Channel
		,AgressoAccountCategory
		,SIIType
		--,Basis
), CTE2 AS 
(
SELECT	EntityCode
		,EntityGroup
		,AgressoAccountCategory
		,SIIType
		--,Basis
		,SUM(Value) AS TotalValue
 FROM	CTE
 WHERE	LOB IS NOT NULL
 GROUP	BY EntityCode
		,EntityGroup
		,AgressoAccountCategory
		,SIIType
		--,Basis
)
,CTE3 AS (
SELECT  CTE.EntityCode
		,CTE.EntityGroup
		,LOB
		,Channel
		,CTE.AgressoAccountCategory
		,CTE.SIIType
		--,CTE.Basis
		,CAST(Value AS DECIMAL(24,12))/ISNULL((CAST(CASE WHEN TotalValue = 0 AND Value <> 0 THEN Value WHEN TotalValue = 0 AND Value = 0 THEN 1 ELSE TotalValue END AS DECIMAL(24,12))),1) TriFocuAllocationPercent
FROM	CTE
JOIN	CTe2 
ON		CTE.AgressoAccountCategory = CTE2.AgressoAccountCategory
AND		CTE.EntityCode =CTE2.EntityCode
AND		CTE.EntityGroup = CTE2.EntityGroup
AND		CTE.SIIType = CTE2.SIIType
--AND		CTE.Basis = CTE2.Basis
), CTE4 AS (
SELECT	 DISTINCT a.EntityCode
		,a.EntityGroup
		,LOB
		,Channel
		,a.AgressoAccountCategory
		,a.SIIType
		,LocationOfRisk
		,UnderwritingLocation
		,OriginalCurrencyCode
		,Basis
		,cur_amount
		,Value 
		,OrigUnderwritingLocation
		,OrigLocationOfRisk
 FROM	UnAllocatedData a
 WHERE	(a.LOB IS NULL OR LTRIM(RTRIM(a.LOB)) ='')
 AND	SIIType = @SIIForm

 )
INSERT INTO [dbo].[UnAllocatedDataTF]
           ([EntityCode]
           ,[EntityGroup]
           ,[LOB]
           ,[Channel]
           ,[AgressoAccountCategory]
           ,[SIIType]
           ,[LocationOfRisk]
           ,[UnderwritingLocation]
           ,[OriginalCurrencyCode]
           ,[Basis]
           ,[cur_amount]
           ,[Value]
           ,[OrigUnderwritingLocation]
           ,[OrigLocationOfRisk])
 SELECT	 DISTINCT a.EntityCode
		,a.EntityGroup
		,e.LOB
		,e.Channel
		,a.AgressoAccountCategory
		,a.SIIType
		,LocationOfRisk
		,UnderwritingLocation
		,OriginalCurrencyCode
		,CASE WHEN @SIIForm = 'S.04.01' THEN 'UnderwritingLocation' ELSE  l.Basis END AS Basis
		,cur_amount
		,Value * TriFocuAllocationPercent AS Value
		,OrigUnderwritingLocation
		,OrigLocationOfRisk
 FROM	CTE4 a
 JOIN	CTE3 e
 ON		e.AgressoAccountCategory = a.AgressoAccountCategory
 AND	e.EntityCode = a.EntityCode
 AND	e.EntityGroup = a.EntityGroup
 AND	e.SIIType = a.SIIType
 JOIN	SIILOBAllocationBasis l
 ON		l.Channel = e.Channel
 AND	l.LOB = e.LOB

END

