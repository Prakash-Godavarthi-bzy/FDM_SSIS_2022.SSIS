﻿


-- =============================================
-- Author:		Nanda Gottumukkala
-- Create date: 02/10/2015
-- Description:	TO log the execution and record movements on the tables
-- =============================================
CREATE PROCEDURE [dbo].[usp_InsertIntoAllocationLog]
	@AllocationCode AS VARCHAR(100),
	@BridgeStartTime varchar(50),
	@AllocationGroup varchar(255),
    @AllocationGroupVersion varchar(10)=0,
	@UserID varchar(255),
    @BatchID int,
	@Status varchar(50) 




AS
BEGIN

SELECT @AllocationGroupVersion= AllocationGroupCodeVersion FROM DimAllocationRules
WHERE AllocationGroup = @AllocationGroup
AND AllocationCode = @AllocationCode
AND IsCurrent = 1

INSERT INTO [dbo].[AllocationEngineLog]
           ([AllocationCode]
           ,[BridgeStartTime]
           ,[AllocationGroup]
           ,[AllocationGroupVersion]
           ,[UserID]
           ,[BatchID]
		   ,[Status])
     VALUES
           (@AllocationCode
           ,@BridgeStartTime
           ,@AllocationGroup
           ,@AllocationGroupVersion
           ,@UserID
           ,@BatchID
		   ,@Status
		   )

SELECT @@IDENTITY AS ExecutionId
END
