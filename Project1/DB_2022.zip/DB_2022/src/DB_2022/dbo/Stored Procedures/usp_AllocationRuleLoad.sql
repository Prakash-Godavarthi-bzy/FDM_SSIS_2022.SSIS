﻿CREATE PROCEDURE dbo.usp_AllocationRuleLoad( @AllocationGroup					VARCHAR(255)
										   , @AllocationCode					VARCHAR(255)
										   , @AllocationGroupCodeVersion		INT
										   , @AllocationGroupId					INT
										   , @AllocationType					VARCHAR(50)
										   )
AS
/********************************************************************************/  
/* Copyright @2020 Xyenta														*/  
/*																				*/  
/* Author			: Srinivas Tummala											*/  
/* CreationDate     : 2020-03-26												*/
/* ModifiedDate     : 															*/  
/* Description		: Check existing allocation rules and find changes.			*/  
/*																				*/  
/* InPut Params     : @AllocationGroup	- Allocation Group						*/  
/*					  @AllocationCode	- Allocation Code						*/
/*					  @AllocationGroupCodeVersion - Existing Group Code version	*/
/*					  @AllocationGroupId - Unique Group Id						*/
/*					  @AllocationType	- Allocation Type						*/
/* Output params    : None														*/  
/* Return params    : None														*/  
/* Note				:															*/  
/********************************************************************************/  
  
/*  
	 DECLARE @AllocationGroup VARCHAR(255), @AllocationCode VARCHAR(255), @AllocationGroupCodeVersion INT
		   , @AllocationGroupId INT, @AllocationType VARCHAR(50)

	SET @AllocationGroup = 'Investment.2016UpdatedV1'
	SET @AllocationCode = 'EIC'
													

	SET @AllocationGroupId = ISNULL((select CASE WHEN ISNULL(min(AllocationGroupId),0) = 0 
											THEN (SELECT ISNULL(MAX(AllocationGroupID),0)+1 AllocationGroupId FROM DimAllocationRules)
									      ELSE ISNULL(min(AllocationGroupId),0) 
									 END AS AllocationGroupId 
							    from DimAllocationRules where AllocationGroup = @AllocationGroup
								 and AllocationGroupID > 0),1)
	SET @AllocationGroupId = CASE WHEN @AllocationGroupId = 0 THEN 1 ELSE @AllocationGroupId END
	SET @AllocationGroupCodeVersion = (select cast(ISNULL(max(AllocationGroupCodeVersion),0) as numeric) AllocationGroupCodeVersion 
										 from DimAllocationRules 
										WHERE AllocationGroup = @AllocationGroup AND AllocationCode = @AllocationCode)
	SET @AllocationType = 'Investment'--'Expenses'
	--SELECT @AllocationGroupCodeVersion,@AllocationGroupId		      
	EXEC dbo.usp_AllocationRuleLoad @AllocationGroup,@AllocationCode,@AllocationGroupCodeVersion,@AllocationGroupId,@AllocationType	
		      
	 
 
 */
BEGIN
	SET NOCOUNT ON
			  
	DECLARE @InsertDate DateTime = GETDATE()
		  , @AllocationUser VARCHAR(50)
		  , @BatchId INT
		  		
	SELECT TOP 1 @AllocationUser = AllocationUser
		 , @BatchId = BatchID 
	  FROM staging_agresso.dbo.AllocationRulesStage
	 WHERE AllocationGroup = @AllocationGroup 
	   AND AllocationCode = @AllocationCode			
	/*******************************************************************************************************
		Generate Row hash for source allocation data by grouping all columns excepts percentage
	********************************************************************************************************/

	IF(OBJECT_ID('tempdb..#AllocationRules_Staging') IS NOT NULL)
		DROP TABLE #AllocationRules_Staging

	SELECT  MAX(AllocationRulesStageId) AS AllocationRulesStageId
		 , AllocationGroup--,AllocationUser
		 , AllocationCode,StepCode,GranularityFlag
		 , AccountDest,TrifocusDest,EntityDest,LocationDest,ProjectDest,YOADest,ProcessDest,TargetPeriodDest,TargetEntityDest,TargetCurrencyDest
		 , AccountFrom,AccountTo,TrifocusFrom,TrifocusTo,EntityFrom,EntityTo,LocationFrom,LocationTo,ProjectFrom,ProjectTo
		 , YOAFrom,YOATo,ProcessFrom,ProcessTo,TargetEntityFrom,TargetEntityTo
		 , SUM(AllocationPercent) AS AllocationPercent		
		 , RowHash = HASHBYTES('SHA2_512',CONCAT(AccountFrom, 
								'§~§', AccountTo, 
								'§~§', TrifocusFrom, 
								'§~§', TrifocusTo, 
								'§~§', EntityFrom, 
								'§~§', EntityTo, 
								'§~§', LocationFrom, 
								'§~§', LocationTo, 
								'§~§', ProjectFrom, 
								'§~§', ProjectTo, 
								'§~§', YOAFrom, 
								'§~§', YOATo, 
								'§~§', ProcessFrom, 
								'§~§', ProcessTo, 
								'§~§', TargetEntityFrom, 
								'§~§', TargetEntityTo,
								'§~§', GranularityFlag,
								'§~§', AccountDest,
								'§~§', TrifocusDest,
								'§~§', EntityDest,
								'§~§', LocationDest,
								'§~§', ProjectDest,
								'§~§', YOADest,
								'§~§', ProcessDest,
								'§~§', TargetPeriodDest,
								'§~§', TargetEntityDest,
								'§~§', TargetCurrencyDest,
								--'§~§',StepCode,								
								'§~§'))
	  INTO #AllocationRules_Staging
	  FROM staging_agresso.dbo.AllocationRulesStage 
	 WHERE AllocationGroup = @AllocationGroup
	   AND AllocationCode = @AllocationCode
	   AND AllocationPercent != '0.00000000'
	   AND AllocationPercent > 0
	 GROUP BY AllocationGroup--,AllocationUser
		 , AllocationCode,StepCode,GranularityFlag
		 , AccountDest,TrifocusDest,EntityDest,LocationDest,ProjectDest,YOADest,ProcessDest,TargetPeriodDest,TargetEntityDest,TargetCurrencyDest
		 , AccountFrom,AccountTo,TrifocusFrom,TrifocusTo,EntityFrom,EntityTo,LocationFrom,LocationTo,ProjectFrom,ProjectTo
		 , YOAFrom,YOATo,ProcessFrom,ProcessTo,TargetEntityFrom,TargetEntityTo
	UNION
	SELECT  MAX(AllocationRulesStageId) AS AllocationRulesStageId
		 , AllocationGroup--,AllocationUser
		 , AllocationCode,StepCode,GranularityFlag
		 , AccountDest,TrifocusDest,EntityDest,LocationDest,ProjectDest,YOADest,ProcessDest,TargetPeriodDest,TargetEntityDest,TargetCurrencyDest
		 , AccountFrom,AccountTo,TrifocusFrom,TrifocusTo,EntityFrom,EntityTo,LocationFrom,LocationTo,ProjectFrom,ProjectTo
		 , YOAFrom,YOATo,ProcessFrom,ProcessTo,TargetEntityFrom,TargetEntityTo
		 , SUM(AllocationPercent) AS AllocationPercent		
		 , RowHash = HASHBYTES('SHA2_512',CONCAT(AccountFrom, 
								'§~§', AccountTo, 
								'§~§', TrifocusFrom, 
								'§~§', TrifocusTo, 
								'§~§', EntityFrom, 
								'§~§', EntityTo, 
								'§~§', LocationFrom, 
								'§~§', LocationTo, 
								'§~§', ProjectFrom, 
								'§~§', ProjectTo, 
								'§~§', YOAFrom, 
								'§~§', YOATo, 
								'§~§', ProcessFrom, 
								'§~§', ProcessTo, 
								'§~§', TargetEntityFrom, 
								'§~§', TargetEntityTo,
								'§~§', GranularityFlag,
								'§~§', AccountDest,
								'§~§', TrifocusDest,
								'§~§', EntityDest,
								'§~§', LocationDest,
								'§~§', ProjectDest,
								'§~§', YOADest,
								'§~§', ProcessDest,
								'§~§', TargetPeriodDest,
								'§~§', TargetEntityDest,
								'§~§', TargetCurrencyDest,
								--'§~§',StepCode,								
								'§~§'))
	  --INTO #AllocationRules_Staging
	  FROM staging_agresso.dbo.AllocationRulesStage 
	 WHERE AllocationGroup = @AllocationGroup
	   AND AllocationCode = @AllocationCode
	   AND AllocationPercent != '0.00000000'
	   AND AllocationPercent < 0
	 GROUP BY AllocationGroup--,AllocationUser
		 , AllocationCode,StepCode,GranularityFlag
		 , AccountDest,TrifocusDest,EntityDest,LocationDest,ProjectDest,YOADest,ProcessDest,TargetPeriodDest,TargetEntityDest,TargetCurrencyDest
		 , AccountFrom,AccountTo,TrifocusFrom,TrifocusTo,EntityFrom,EntityTo,LocationFrom,LocationTo,ProjectFrom,ProjectTo
		 , YOAFrom,YOATo,ProcessFrom,ProcessTo,TargetEntityFrom,TargetEntityTo	 
	--SELECT * FROM #AllocationRules_Staging

	/******************************************************************************
	Generate Row hash for Dim allocation data by grouping all columns excepts percentage
	*******************************************************************************/

	IF(OBJECT_ID('tempdb..#DimAllocationRules') IS NOT NULL)
		DROP TABLE #DimAllocationRules

	SELECT MAX(PK_AllocationRules) AS PK_AllocationRules
		 , AllocationGroup--,AllocationUser
		 ,AllocationCode,StepCode,GranularityFlag
		 , AccountDest,TrifocusDest,EntityDest,LocationDest,ProjectDest,YOADest,ProcessDest,TargetPeriodDest,TargetEntityDest,TargetCurrencyDest
		 , AccountFrom,AccountTo,TrifocusFrom,TrifocusTo,EntityFrom,EntityTo,LocationFrom,LocationTo,ProjectFrom,ProjectTo
		 , YOAFrom,YOATo,ProcessFrom,ProcessTo,TargetEntityFrom,TargetEntityTo
		 , MAX(AllocationGroupCodeVersion) AS AllocationGroupCodeVersion,MAX(AllocationGroupCodeSubVersion) AS AllocationGroupCodeSubVersion
		 , SUM(AllocationPercent) AS AllocationPercent
		 , RowHash
		 , Count(PK_AllocationRules) AS RCount
	  INTO #DimAllocationRules
	  FROM FDM_DB.dbo.DimAllocationRules
	 WHERE AllocationGroup = @AllocationGroup
	   AND AllocationCode = @AllocationCode 
	   AND IsCurrent = 1
	   AND AllocationPercent > 0
	 GROUP BY AllocationGroup--,AllocationUser
		 , AllocationCode,StepCode,GranularityFlag,RowHash
		 , AccountDest,TrifocusDest,EntityDest,LocationDest,ProjectDest,YOADest,ProcessDest,TargetPeriodDest,TargetEntityDest,TargetCurrencyDest
		 , AccountFrom,AccountTo,TrifocusFrom,TrifocusTo,EntityFrom,EntityTo,LocationFrom,LocationTo,ProjectFrom,ProjectTo
		 , YOAFrom,YOATo,ProcessFrom,ProcessTo,TargetEntityFrom,TargetEntityTo

	UNION
	SELECT MAX(PK_AllocationRules) AS PK_AllocationRules
		 , AllocationGroup--,AllocationUser
		 ,AllocationCode,StepCode,GranularityFlag
		 , AccountDest,TrifocusDest,EntityDest,LocationDest,ProjectDest,YOADest,ProcessDest,TargetPeriodDest,TargetEntityDest,TargetCurrencyDest
		 , AccountFrom,AccountTo,TrifocusFrom,TrifocusTo,EntityFrom,EntityTo,LocationFrom,LocationTo,ProjectFrom,ProjectTo
		 , YOAFrom,YOATo,ProcessFrom,ProcessTo,TargetEntityFrom,TargetEntityTo
		 , MAX(AllocationGroupCodeVersion) AS AllocationGroupCodeVersion,MAX(AllocationGroupCodeSubVersion) AS AllocationGroupCodeSubVersion
		 , SUM(AllocationPercent) AS AllocationPercent
		 , RowHash
		 , Count(PK_AllocationRules) AS RCount
	  FROM FDM_DB.dbo.DimAllocationRules
	 WHERE AllocationGroup = @AllocationGroup
	   AND AllocationCode = @AllocationCode 
	   AND IsCurrent = 1
	   AND AllocationPercent < 0
	 GROUP BY AllocationGroup--,AllocationUser
		 , AllocationCode,StepCode,GranularityFlag,RowHash
		 , AccountDest,TrifocusDest,EntityDest,LocationDest,ProjectDest,YOADest,ProcessDest,TargetPeriodDest,TargetEntityDest,TargetCurrencyDest
		 , AccountFrom,AccountTo,TrifocusFrom,TrifocusTo,EntityFrom,EntityTo,LocationFrom,LocationTo,ProjectFrom,ProjectTo
		 , YOAFrom,YOATo,ProcessFrom,ProcessTo,TargetEntityFrom,TargetEntityTo

	--SELECT * FROM #DimAllocationRules
	
	/******************************************************************************
	Find and log the allocation rules which are not changed
	*******************************************************************************/
	--SELECT * FROM #AllocationRules_Staging
	--SELECT * FROM #DimAllocationRules
		
	IF(OBJECT_ID('tempdb..#AllocationRulesTemp') IS NOT NULL)
		DROP TABLE #AllocationRulesTemp

	SELECT B.PK_AllocationRules,A.AllocationRulesStageId
		 ,  COALESCE(A.AllocationGroup				,B.AllocationGroup			  ) AS AllocationGroup
		 --, COALESCE(A.AllocationUser				,B.AllocationUser			  ) AS AllocationUser
		 , COALESCE(A.AllocationCode				,B.AllocationCode			  ) AS AllocationCode
		 , COALESCE(A.StepCode					    ,B.StepCode					  ) AS StepCode
		 , COALESCE(A.GranularityFlag			    ,B.GranularityFlag			  ) AS GranularityFlag		 
		 , COALESCE(A.AccountDest					,B.AccountDest				  ) AS AccountDest
		 , COALESCE(A.TrifocusDest					,B.TrifocusDest				  ) AS TrifocusDest
		 , COALESCE(A.EntityDest					,B.EntityDest				  ) AS EntityDest
		 , COALESCE(A.LocationDest				    ,B.LocationDest				  ) AS LocationDest
		 , COALESCE(A.ProjectDest				    ,B.ProjectDest				  ) AS ProjectDest
		 , COALESCE(A.YOADest					    ,B.YOADest					  ) AS YOADest
		 , COALESCE(A.ProcessDest				    ,B.ProcessDest				  ) AS ProcessDest
		 , COALESCE(A.TargetPeriodDest			    ,B.TargetPeriodDest			  ) AS TargetPeriodDest
		 , COALESCE(A.TargetEntityDest			    ,B.TargetEntityDest			  ) AS TargetEntityDest
		 , COALESCE(A.TargetCurrencyDest			,B.TargetCurrencyDest		  ) AS TargetCurrencyDest
		 , COALESCE(A.AccountFrom				    ,B.AccountFrom				  ) AS AccountFrom
		 , COALESCE(A.AccountTo					    ,B.AccountTo				  ) AS AccountTo
		 , COALESCE(A.TrifocusFrom				    ,B.TrifocusFrom				  ) AS TrifocusFrom
		 , COALESCE(A.TrifocusTo					,B.TrifocusTo				  ) AS TrifocusTo
		 , COALESCE(A.EntityFrom					,B.EntityFrom				  ) AS EntityFrom
		 , COALESCE(A.EntityTo					    ,B.EntityTo					  ) AS EntityTo
		 , COALESCE(A.LocationFrom				    ,B.LocationFrom				  ) AS LocationFrom
		 , COALESCE(A.LocationTo					,B.LocationTo				  ) AS LocationTo
		 , COALESCE(A.ProjectFrom				    ,B.ProjectFrom				  ) AS ProjectFrom
		 , COALESCE(A.ProjectTo					    ,B.ProjectTo				  ) AS ProjectTo
		 , COALESCE(A.YOAFrom					    ,B.YOAFrom					  ) AS YOAFrom
		 , COALESCE(A.YOATo						    ,B.YOATo					  ) AS YOATo
		 , COALESCE(A.ProcessFrom				    ,B.ProcessFrom				  ) AS ProcessFrom
		 , COALESCE(A.ProcessTo					    ,B.ProcessTo				  ) AS ProcessTo
		 , COALESCE(A.TargetEntityFrom			    ,B.TargetEntityFrom			  ) AS TargetEntityFrom
		 , COALESCE(A.TargetEntityTo				,B.TargetEntityTo			  ) AS TargetEntityTo
		 , COALESCE(A.AllocationPercent			    ,B.AllocationPercent		  ) AS AllocationPercent
		 , COALESCE(A.RowHash						,B.RowHash					  ) AS RowHash		
		 --, COALESCE(B.AllocationGroupCodeVersion	,0							  ) AS AllocationGroupCodeVersion
		 --, COALESCE(B.AllocationGroupCodeSubVersion	,0							  ) AS AllocationGroupCodeSubVersion
		 , CASE				
				WHEN A.RowHash IS NOT NULL AND B.RowHash IS NOT NULL AND (A.AllocationPercent = B.AllocationPercent AND  B.RCount = 1) THEN CAST('No Change' AS VARCHAR(50))
				WHEN A.RowHash IS NOT NULL AND B.RowHash IS NULL THEN 'New'
				WHEN A.RowHash IS NULL AND B.RowHash IS NOT NULL THEN 'Deleted'
				WHEN (A.RowHash IS NOT NULL AND B.RowHash IS NOT NULL AND (A.AllocationPercent != B.AllocationPercent OR B.RCount > 1) ) THEN CAST('Percent Update' AS VARCHAR(50))
		  END AS ChangeType
		  --,A.RowHash AS DimRowHash , B.RowHash AS StageRowHash
	 INTO #AllocationRulesTemp
	 FROM #AllocationRules_Staging A
	 FULL OUTER JOIN #DimAllocationRules B
	   ON A.AllocationGroup = B.AllocationGroup
	  AND A.AllocationCode = B.AllocationCode
	  AND A.StepCode = B.StepCode 
	  AND A.RowHash = CONVERT(VARBINARY(255),B.RowHash)
	 --WHERE A.AllocationPercent != '0.00000000'
	WHERE A.AllocationPercent > 0 AND B.AllocationPercent > 0
	--ORDER BY B.PK_AllocationRules
	UNION 
	SELECT B.PK_AllocationRules,A.AllocationRulesStageId
		 ,  COALESCE(A.AllocationGroup				,B.AllocationGroup			  ) AS AllocationGroup
		 --, COALESCE(A.AllocationUser				,B.AllocationUser			  ) AS AllocationUser
		 , COALESCE(A.AllocationCode				,B.AllocationCode			  ) AS AllocationCode
		 , COALESCE(A.StepCode					    ,B.StepCode					  ) AS StepCode
		 , COALESCE(A.GranularityFlag			    ,B.GranularityFlag			  ) AS GranularityFlag		 
		 , COALESCE(A.AccountDest					,B.AccountDest				  ) AS AccountDest
		 , COALESCE(A.TrifocusDest					,B.TrifocusDest				  ) AS TrifocusDest
		 , COALESCE(A.EntityDest					,B.EntityDest				  ) AS EntityDest
		 , COALESCE(A.LocationDest				    ,B.LocationDest				  ) AS LocationDest
		 , COALESCE(A.ProjectDest				    ,B.ProjectDest				  ) AS ProjectDest
		 , COALESCE(A.YOADest					    ,B.YOADest					  ) AS YOADest
		 , COALESCE(A.ProcessDest				    ,B.ProcessDest				  ) AS ProcessDest
		 , COALESCE(A.TargetPeriodDest			    ,B.TargetPeriodDest			  ) AS TargetPeriodDest
		 , COALESCE(A.TargetEntityDest			    ,B.TargetEntityDest			  ) AS TargetEntityDest
		 , COALESCE(A.TargetCurrencyDest			,B.TargetCurrencyDest		  ) AS TargetCurrencyDest
		 , COALESCE(A.AccountFrom				    ,B.AccountFrom				  ) AS AccountFrom
		 , COALESCE(A.AccountTo					    ,B.AccountTo				  ) AS AccountTo
		 , COALESCE(A.TrifocusFrom				    ,B.TrifocusFrom				  ) AS TrifocusFrom
		 , COALESCE(A.TrifocusTo					,B.TrifocusTo				  ) AS TrifocusTo
		 , COALESCE(A.EntityFrom					,B.EntityFrom				  ) AS EntityFrom
		 , COALESCE(A.EntityTo					    ,B.EntityTo					  ) AS EntityTo
		 , COALESCE(A.LocationFrom				    ,B.LocationFrom				  ) AS LocationFrom
		 , COALESCE(A.LocationTo					,B.LocationTo				  ) AS LocationTo
		 , COALESCE(A.ProjectFrom				    ,B.ProjectFrom				  ) AS ProjectFrom
		 , COALESCE(A.ProjectTo					    ,B.ProjectTo				  ) AS ProjectTo
		 , COALESCE(A.YOAFrom					    ,B.YOAFrom					  ) AS YOAFrom
		 , COALESCE(A.YOATo						    ,B.YOATo					  ) AS YOATo
		 , COALESCE(A.ProcessFrom				    ,B.ProcessFrom				  ) AS ProcessFrom
		 , COALESCE(A.ProcessTo					    ,B.ProcessTo				  ) AS ProcessTo
		 , COALESCE(A.TargetEntityFrom			    ,B.TargetEntityFrom			  ) AS TargetEntityFrom
		 , COALESCE(A.TargetEntityTo				,B.TargetEntityTo			  ) AS TargetEntityTo
		 , COALESCE(A.AllocationPercent			    ,B.AllocationPercent		  ) AS AllocationPercent
		 , COALESCE(A.RowHash						,B.RowHash					  ) AS RowHash			 	
		 --, COALESCE(B.AllocationGroupCodeVersion	,0							  ) AS AllocationGroupCodeVersion
		 --, COALESCE(B.AllocationGroupCodeSubVersion	,0							  ) AS AllocationGroupCodeSubVersion
		 , CASE				
				WHEN A.RowHash IS NOT NULL AND B.RowHash IS NOT NULL AND (A.AllocationPercent = B.AllocationPercent AND  B.RCount = 1) THEN CAST('No Change' AS VARCHAR(50))
				WHEN A.RowHash IS NOT NULL AND B.RowHash IS NULL THEN 'New'
				WHEN A.RowHash IS NULL AND B.RowHash IS NOT NULL THEN 'Deleted'
				WHEN (A.RowHash IS NOT NULL AND B.RowHash IS NOT NULL AND (A.AllocationPercent != B.AllocationPercent OR B.RCount > 1) ) THEN CAST('Percent Update' AS VARCHAR(50))
		  END AS ChangeType
		  --,A.RowHash AS DimRowHash , B.RowHash AS StageRowHash	 
	 FROM #AllocationRules_Staging A
	 FULL OUTER JOIN #DimAllocationRules B
	   ON A.AllocationGroup = B.AllocationGroup
	  AND A.AllocationCode = B.AllocationCode
	  AND A.StepCode = B.StepCode 
	  AND A.RowHash = CONVERT(VARBINARY(255),B.RowHash)
	 --WHERE A.AllocationPercent != '0.00000000'	
	 WHERE A.AllocationPercent < 0 AND B.AllocationPercent < 0
	ORDER BY B.PK_AllocationRules

		/****************************************************************************************
			Insert Rules which are not exists and considering them as new rules.			
		*****************************************************************************************/
		INSERT INTO #AllocationRulesTemp (PK_AllocationRules,AllocationRulesStageId		   
			 , AllocationGroup--,AllocationUser
			 , AllocationCode,StepCode,GranularityFlag
			 , AccountDest,TrifocusDest,EntityDest,LocationDest,ProjectDest,YOADest,ProcessDest,TargetPeriodDest,TargetEntityDest,TargetCurrencyDest
			 , AccountFrom,AccountTo,TrifocusFrom,TrifocusTo,EntityFrom,EntityTo,LocationFrom,LocationTo,ProjectFrom,ProjectTo
			 , YOAFrom,YOATo,ProcessFrom,ProcessTo,TargetEntityFrom,TargetEntityTo
			 , AllocationPercent,RowHash
			 --, AllocationGroupCodeVersion,AllocationGroupCodeSubVersion
			 , ChangeType
			 )
		SELECT A.AllocationRulesStageId,0 AS PK_AllocationRules
			 , A.AllocationGroup--,A.AllocationUser
			 , A.AllocationCode,A.StepCode,A.GranularityFlag
			 , A.AccountDest,A.TrifocusDest,A.EntityDest,A.LocationDest,A.ProjectDest,A.YOADest,A.ProcessDest,A.TargetPeriodDest,A.TargetEntityDest,A.TargetCurrencyDest
			 , A.AccountFrom,A.AccountTo,A.TrifocusFrom,A.TrifocusTo,A.EntityFrom,A.EntityTo,A.LocationFrom,A.LocationTo,A.ProjectFrom,A.ProjectTo
			 , A.YOAFrom,A.YOATo,A.ProcessFrom,A.ProcessTo,A.TargetEntityFrom,A.TargetEntityTo	
			 , A.AllocationPercent,A.RowHash 	 
			 --, A.AllocationGroupCodeVersion,A.AllocationGroupCodeSubVersion	
			 , 'New' AS ChangeType
		  FROM #AllocationRules_Staging A
		  LEFT JOIN #DimAllocationRules B
		    ON A.StepCode = B.StepCode 
		   AND A.AllocationGroup = B.AllocationGroup
		   AND A.AllocationCode = B.AllocationCode
		   AND A.RowHash = CONVERT(VARBINARY(255),B.RowHash)
		 WHERE B.RowHash IS NULL
		   AND A.AllocationGroup = @AllocationGroup 
		   AND A.AllocationCode =  @AllocationCode 

		/****************************************************************************************************************************************
			Insert Rules which are having duplicate data and not part of above result set (As taking Max Pk id by summing Percent). 
			so other rules are considering as Deleted
		*****************************************************************************************************************************************/
		INSERT INTO #AllocationRulesTemp (PK_AllocationRules,AllocationRulesStageId		   
			 , AllocationGroup--,AllocationUser
			 , AllocationCode,StepCode,GranularityFlag
			 , AccountDest,TrifocusDest,EntityDest,LocationDest,ProjectDest,YOADest,ProcessDest,TargetPeriodDest,TargetEntityDest,TargetCurrencyDest
			 , AccountFrom,AccountTo,TrifocusFrom,TrifocusTo,EntityFrom,EntityTo,LocationFrom,LocationTo,ProjectFrom,ProjectTo
			 , YOAFrom,YOATo,ProcessFrom,ProcessTo,TargetEntityFrom,TargetEntityTo
			 , AllocationPercent,RowHash
			 --, AllocationGroupCodeVersion,AllocationGroupCodeSubVersion
			 , ChangeType
			 )
		SELECT A.PK_AllocationRules,0 AS AllocationRulesStageId
			 , A.AllocationGroup--,A.AllocationUser
			 , A.AllocationCode,A.StepCode,A.GranularityFlag
			 , A.AccountDest,A.TrifocusDest,A.EntityDest,A.LocationDest,A.ProjectDest,A.YOADest,A.ProcessDest,A.TargetPeriodDest,A.TargetEntityDest,A.TargetCurrencyDest
			 , A.AccountFrom,A.AccountTo,A.TrifocusFrom,A.TrifocusTo,A.EntityFrom,A.EntityTo,A.LocationFrom,A.LocationTo,A.ProjectFrom,A.ProjectTo
			 , A.YOAFrom,A.YOATo,A.ProcessFrom,A.ProcessTo,A.TargetEntityFrom,A.TargetEntityTo	
			 , A.AllocationPercent,A.RowHash 	 
			 --, A.AllocationGroupCodeVersion,A.AllocationGroupCodeSubVersion	
			 , 'Deleted' AS ChangeType
		  FROM dbo.DimAllocationRules A
		  LEFT JOIN #AllocationRulesTemp B
			ON A.PK_AllocationRules = B.PK_AllocationRules
		   --AND A.AllocationGroup = B.AllocationCode
		 WHERE A.IsCurrent = 1	  
		   AND B.PK_AllocationRules IS NULL
		   AND A.AllocationGroup = @AllocationGroup 
		   AND A.AllocationCode =  @AllocationCode 
	
		/*
		SELECT * FROM #AllocationRulesTemp ORDER BY PK_AllocationRules,ChangeType
		SELECT * FROM #AllocationRulesTemp WHERE ChangeType IN ('New','Deleted','PercentUpdate') ORDER BY ChangeType
		SELECT * FROM #AllocationRulesTemp WHERE ChangeType  IN ('No Change') ORDER BY ChangeType		
		*/
			
		/**********************************************************************************
			Make IsCurrent flag to false for Previous active rules
		***********************************************************************************/
			UPDATE dbo.DimAllocationRules
			   SET IsCurrent = 0
			 WHERE AllocationCode = @AllocationCode 
			   AND AllocationGroup = @AllocationGroup 
			   AND AllocationGroupCodeVersion = @AllocationGroupCodeVersion
			   AND IsCurrent = 1

			--SELECT TOP 100 * FROM #DimAllocationRules
		/******************************************************************************
			Insert New Rules and put AllocationGroupCodeSubVersion 1 by default
		*******************************************************************************/
		INSERT INTO dbo.DimAllocationRules (AllocationGroupId,AllocationGroup,AllocationUser,AllocationCode,AllocationGroupCodeVersion
				  , StepCode,AccountFrom,AccountTo,TrifocusFrom,TrifocusTo,EntityFrom,EntityTo,LocationFrom,LocationTo,ProjectFrom,ProjectTo
				  , YOAFrom,YOATo,ProcessFrom,ProcessTo,AccountDest,TrifocusDest,EntityDest,LocationDest,ProjectDest,YOADest,ProcessDest
				  , AllocationPercent,IsCurrent,RunOrder,InsertDate,TargetEntityFrom,TargetEntityTo,TargetEntityDest,GranularityFlag,BatchID
				  , UserID,TargetPeriodDest,TargetCurrencyDest,AllocationType
				  , ChangeType,PK_Alt_AllocationRules,AllocationGroupCodeSubVersion,RowHash)
		SELECT		@AllocationGroupId AS AllocationGroupId,AllocationGroup
				  , @AllocationUser AS AllocationUser,AllocationCode,@AllocationGroupCodeVersion + 1 AS AllocationGroupCodeVersion
				  , StepCode,AccountFrom,AccountTo,TrifocusFrom,TrifocusTo,EntityFrom,EntityTo,LocationFrom,LocationTo,ProjectFrom,ProjectTo
				  , YOAFrom,YOATo,ProcessFrom,ProcessTo,AccountDest,TrifocusDest,EntityDest,LocationDest,ProjectDest,YOADest,ProcessDest
				  , AllocationPercent,1 AS IsCurrent,null AS RunOrder,@InsertDate,TargetEntityFrom,TargetEntityTo,TargetEntityDest
				  , GranularityFlag,@BatchId AS BatchId
				  , @AllocationUser AS UserID,TargetPeriodDest,TargetCurrencyDest,@AllocationType AS AllocationType
				  , ChangeType,null AS PK_Alt_AllocationRules,1 AS AllocationGroupCodeSubVersion,RowHash
		  FROM #AllocationRulesTemp 
		 WHERE ChangeType = 'New'

		 UPDATE dbo.DimAllocationRules 
			SET PK_Alt_AllocationRules = PK_AllocationRules
		  WHERE ChangeType = 'New'
			AND BatchId = @BatchId
			AND AllocationGroup = @AllocationGroup
			AND AllocationCode = @AllocationCode
			AND PK_Alt_AllocationRules IS NULL

		/**************************************************************************************************************************************
			Insert Deleted/Percent Update Rules and increment AllocationGroupCodeSubVersion ,make Is current flag False and True respectively
		***************************************************************************************************************************************/

		INSERT INTO dbo.DimAllocationRules (AllocationGroupId,AllocationGroup,AllocationUser,AllocationCode,AllocationGroupCodeVersion
				  , StepCode,AccountFrom,AccountTo,TrifocusFrom,TrifocusTo,EntityFrom,EntityTo,LocationFrom,LocationTo,ProjectFrom,ProjectTo
				  , YOAFrom,YOATo,ProcessFrom,ProcessTo,AccountDest,TrifocusDest,EntityDest,LocationDest,ProjectDest,YOADest,ProcessDest
				  , AllocationPercent,IsCurrent,RunOrder,InsertDate,TargetEntityFrom,TargetEntityTo,TargetEntityDest,GranularityFlag,BatchID
				  , UserID,TargetPeriodDest,TargetCurrencyDest,AllocationType
				  , ChangeType,PK_Alt_AllocationRules,AllocationGroupCodeSubVersion,RowHash)
		SELECT		@AllocationGroupId AS AllocationGroupId,A.AllocationGroup
				  , @AllocationUser AS AllocationUser,A.AllocationCode,@AllocationGroupCodeVersion + 1 AS AllocationGroupCodeVersion
				  , A.StepCode,A.AccountFrom,A.AccountTo,A.TrifocusFrom,A.TrifocusTo,A.EntityFrom,A.EntityTo,A.LocationFrom,A.LocationTo,A.ProjectFrom,A.ProjectTo
				  , A.YOAFrom,A.YOATo,A.ProcessFrom,A.ProcessTo,A.AccountDest,A.TrifocusDest,A.EntityDest,A.LocationDest,A.ProjectDest,A.YOADest,A.ProcessDest
				  , CASE WHEN B.ChangeType = 'Percent Update' THEN B.AllocationPercent ELSE A.AllocationPercent END AS AllocationPercent
				  , CASE WHEN B.ChangeType != 'Deleted' THEN 1 ELSE 0 END AS IsCurrent
				  , null AS RunOrder,@InsertDate,A.TargetEntityFrom,A.TargetEntityTo,A.TargetEntityDest
				  , A.GranularityFlag,@BatchId AS BatchId
				  , @AllocationUser AS UserID,A.TargetPeriodDest,A.TargetCurrencyDest,@AllocationType AS AllocationType
				  , B.ChangeType
				  , A.PK_Alt_AllocationRules
				  , CASE WHEN B.ChangeType = 'No Change' THEN ISNULL(AllocationGroupCodeSubVersion,0) + 1 
						 WHEN B.ChangeType = 'Percent Update' THEN 1
						 WHEN B.ChangeType = 'Deleted' THEN ISNULL(AllocationGroupCodeSubVersion,0) + 1					  
					END AS AllocationGroupCodeSubVersion
				 , A.RowHash
		  FROM dbo.DimAllocationRules A
		 INNER JOIN #AllocationRulesTemp B
			ON A.PK_AllocationRules = B.PK_AllocationRules
		 WHERE B.ChangeType IN ( 'Deleted','Percent Update','No Change')
		
			
END
