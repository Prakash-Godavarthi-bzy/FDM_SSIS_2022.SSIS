﻿



-- =============================================
-- Author:		<Nanda Gottumukkala>
-- Create date: <13/11/2015>
-- Description:	<Description>
-- =============================================

CREATE PROCEDURE [dbo].[usp_GetBIEPIDeltaOnLTD]
	@IncrementedLoadID AS VARCHAR(100)
AS
BEGIN

Declare	@LastLoadID INT, @CurrentLoadID INT, @curLoadID int, @LoadID int
SELECT	@curLoadID = ISNULL(MAX(LoadID),0) FROM [BI].[BIEPIExtract]

--IF @curLoadID <> @IncrementedLoadID
--BEGIN
--RAISERROR ('Error raised :: LoadID conflict arrised', -- Message text.
--               16, -- Severity.
--               1 -- State.
--               );
--END

DECLARE @i int = 0 

DECLARE	db_cursor CURSOR FOR  
SELECT	Distinct TOP 2  LOADID FROM [BI].[BIEPIExtract]
WHERE	LoadID <=@IncrementedLoadID
ORDER	BY LoadID DESC

OPEN	db_cursor   
FETCH	NEXT FROM db_cursor INTO @LoadID

WHILE	@@FETCH_STATUS = 0   
BEGIN  
		SET	@i = @i+1
		IF @i =1 
		BEGIN
			SET @CurrentLoadID = @LoadID
		END
		ELSE IF @i =2
		BEGIN
			SET @LastLoadID = @LoadID
		END
		FETCH NEXT FROM db_cursor INTO @LoadID
END   
CLOSE	db_cursor   
DEALLOCATE db_cursor

--To handle first load or if a full refreshed is planned
IF @LastLoadID IS NULL
BEGIN 

	SELECT	[PolicyReference]
			,[InceptionDate]
			,[ExpiryDate]
			,[UnderwriterName]
			,[Department]
			,[TriFocusCode]
			,[PolicyYOA]
			,[StatsCode]
			,[PolicySettlementCurrency]
			,[SyndicateNumber]
			,[ExclusionID]
			,[Mop]
			,-1*[TotalAcquisitionCost] -1*[EstimatedPremiumIncome] AS EPI_Movement
			,1*[TotalAcquisitionCost] AS Brokerage_Movement
			,-1*(
					(-1*[TotalAcquisitionCost] -1*[EstimatedPremiumIncome]) +	(1*[TotalAcquisitionCost])
				) AS  Total_Movement
	FROM	[BI].[BIEPIExtract]
	WHERE	LoadID = @CurrentLoadID
	AND		PolicyReference IS NOT NULL
	AND 	[ExclusionID] <> -1
	ORDER	BY PolicyReference
	--AND PolicyReference ='B0984A15ANFT' --'B0996C13ANFJ'

END
ELSE 
	BEGIN
		;WITH	Last_Load AS (
		SELECT	[PolicyReference]
				,[InceptionDate]
				,[ExpiryDate]
				,[UnderwriterName]
				,[Department]
				,[TriFocusCode]
				,[PolicyYOA]
				,[StatsCode]
				,[PolicySettlementCurrency]
				,[SyndicateNumber]
				,[ExclusionID]
				,[Mop]
				,-1*[TotalAcquisitionCost] -1*[EstimatedPremiumIncome] AS [EstimatedPremiumIncome]
				,1*[TotalAcquisitionCost] AS [TotalAcquisitionCost]
				,[LoadID]
		FROM	[BI].[BIEPIExtract]
		WHERE	LoadID = @LastLoadID
		AND 	[ExclusionID] <> -1
		AND		PolicyReference IS NOT NULL
		), 
		current_Load AS (
		SELECT	[PolicyReference]
				,[InceptionDate]
				,[ExpiryDate]
				,[UnderwriterName]
				,[Department]
				,[TriFocusCode]
				,[PolicyYOA]
				,[StatsCode]
				,[PolicySettlementCurrency]
				,[SyndicateNumber]
				,[ExclusionID]
				,[Mop]
				,-1*[TotalAcquisitionCost] -1*[EstimatedPremiumIncome] AS [EstimatedPremiumIncome]
				,1*[TotalAcquisitionCost] AS [TotalAcquisitionCost]
				,[LoadID]
		FROM	[BI].[BIEPIExtract]
		WHERE	LoadID = @CurrentLoadID
		AND 	[ExclusionID] <> -1
		AND		PolicyReference IS NOT NULL
		)

		SELECT	ISNULL (cl.PolicyReference,ll.PolicyReference) AS PolicyReference
				,ISNULL(cl.[InceptionDate],ll.[InceptionDate]) AS [InceptionDate]
				,ISNULL(cl.[ExpiryDate],ll.[ExpiryDate]) AS [ExpiryDate]
				,ISNULL(cl.[UnderwriterName],ll.[UnderwriterName]) AS [UnderwriterName]
				,ISNULL(cl.[Department],ll.[Department]) AS [Department]
				,ISNULL(cl.[TriFocusCode],ll.[TriFocusCode]) AS [TriFocusCode]
				,ISNULL(cl.[PolicyYOA],ll.[PolicyYOA]) AS [PolicyYOA]
				,ISNULL(cl.[StatsCode],ll.[StatsCode]) AS [StatsCode]
				,ISNULL(cl.PolicySettlementCurrency,ll.PolicySettlementCurrency) AS PolicySettlementCurrency
				,ISNULL(cl.SyndicateNumber,ll.SyndicateNumber) AS SyndicateNumber
				,ISNULL(cl.ExclusionID,ll.ExclusionID) AS ExclusionID		
				,ISNULL(cl.Mop,ll.Mop) AS Mop	
				,ISNULL(cl.EstimatedPremiumIncome-ISNULL(ll.EstimatedPremiumIncome,0),-1*ll.EstimatedPremiumIncome) AS EPI_Movement
				,ISNULL(cl.TotalAcquisitionCost-ISNULL(ll.TotalAcquisitionCost ,0),-1*ll.TotalAcquisitionCost) AS Brokerage_Movement
				,ISNULL(-1*((cl.EstimatedPremiumIncome-ISNULL(ll.EstimatedPremiumIncome,0)) + (cl.TotalAcquisitionCost-ISNULL(ll.TotalAcquisitionCost ,0))),ll.EstimatedPremiumIncome+ll.TotalAcquisitionCost) AS Total_Movement
		FROM	current_Load cl 
		FULL	OUTER	JOIN Last_Load  ll
		ON		ll.PolicyReference = cl.PolicyReference
		ANd		ll.PolicySettlementCurrency = cl.PolicySettlementCurrency
		AND		ll.SyndicateNumber = cl.SyndicateNumber
		AND		ll.[TriFocusCode] = cl.[TriFocusCode]
		AND		ll.[PolicyYOA]= cl.[PolicyYOA]
		AND		ll.[InceptionDate] = cl.[InceptionDate]
		AND		ll.[ExpiryDate] = cl.[ExpiryDate]
		AND		ll.Mop	= cl.Mop
		WHERE	 1=1
		AND 	((ROUND(ISNULL(cl.EstimatedPremiumIncome-ISNULL(ll.EstimatedPremiumIncome,0),-1*ll.EstimatedPremiumIncome),2) NOT BETWEEN -1 and 1) 
		OR		(ROUND(ISNULL(cl.TotalAcquisitionCost-ISNULL(ll.TotalAcquisitionCost,0),-1*ll.TotalAcquisitionCost),2) NOT BETWEEN -1 and 1) 
		)	
		--AND ISNULL (cl.PolicyReference,ll.PolicyReference) = 'B0984A15ANFT'--'B0984A15ANFT'
	END
END	


--EXEC usp_GetEPIDeltaOnLTD 1


