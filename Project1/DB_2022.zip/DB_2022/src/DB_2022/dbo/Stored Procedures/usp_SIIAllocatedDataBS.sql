﻿


-- =============================================
-- Author:		Nanda Gottumukkala
-- Create date: 02/10/2015
-- Description:	TO log the execution and record movements on the tables
-- =============================================
CREATE PROCEDURE[dbo].[usp_SIIAllocatedDataBS]
@EntityReportingType AS VARCHAR(255)
AS
BEGIN

IF		OBJECT_ID('tempdb.dbo.#TPDataForAllocations', 'U') IS NOT NULL
DROP	TABLE #TPDataForAllocations;
IF		OBJECT_ID('tempdb.dbo.#BSAllocationPercentage', 'U') IS NOT NULL
DROP	TABLE #BSAllocationPercentage;  

TRUNCATE TABLE SIIAllocatedDataBS


;WITH CTE_Gross AS (
		SELECT	[AsAt]
				,[Synd]
				,[SII_Class]
				,[Department]
				,[Class]
				,[YOA]
				,[Dataset_Type]
				,[Gross_Net]
				,[Currency]
				,[Undiscounted_value]
				,[Discounted_value]
				,[Risk_Margin_undisc]
				,[Risk_Margin_disc]
		FROM	[$(staging_agresso)].[TP].[StageTPData]
		WHERE	Gross_Net = 'GROSS'
)
,CTE_NET AS	(
		SELECT	[AsAt]
				,[Synd]
				,[SII_Class]
				,[Department]
				,[Class]
				,[YOA]
				,[Dataset_Type]
				,[Gross_Net]
				,[Currency]
				,[Undiscounted_value]
				,[Discounted_value]
				,[Risk_Margin_undisc]
				,[Risk_Margin_disc]
		FROM	[$(staging_agresso)].[TP].[StageTPData]
		WHERE	Gross_Net = 'NET'
	)
SELECT	ISNULL(g.Synd,n.Synd) Synd
		,ISNULL(g.SII_Class,n.SII_Class) SII_Class
		,ISNULL(g.Class,n.Class) TrifocusName
		,ISNULL(g.Department,n.Department) Class
		,ISNULL(g.YOA,n.YOA) YOA
		,ISNULL(g.Dataset_Type,n.Dataset_Type) Dataset_Type
		,ISNULL(g.Currency,n.Currency) Currency
		,ISNULL(IsTreaty,'Non-Treaty') SIIClassType
		,ISNULL(g.discounted_value,0.0000) GrossDiscValue
		,ISNULL(g.Undiscounted_value,0.0000) GrossUnDiscValue
		,ISNULL(g.Risk_Margin_disc,0.0000) GrossDiscRiskMargin
		,ISNULL(g.Risk_Margin_undisc,0.0000) GrossUnDiscRiskMargin
		,ISNULL(n.discounted_value,0.0000) NetDiscValue
		,ISNULL(n.Undiscounted_value,0.0000) NetUnDiscValue
		,ISNULL(n.Risk_Margin_disc,0.0000) NetDiscRiskMargin
		,ISNULL(n.Risk_Margin_undisc,0.0000) NetUnDiscRiskMargin
INTO	#TPDataForAllocations
FROM	CTE_Gross g
FULL	OUTER JOIN	CTE_NET n
ON		g.Synd = n.Synd
AND		g.Department = n.Department
AND		g.Class = n.Class
AND		g.YOA = n.YOA
and		g.Dataset_Type = n.Dataset_Type
AND		g.SII_Class = n.SII_Class
and		g.Currency =n.Currency
LEFT	JOIN SIITreatyTrifocusMapping tt
ON		LTRIM(RTRIM(TrifocusName)) = LTRIM(RTRIM(ISNULL(g.Class,n.Class)))
AND		ISNULL(g.Synd,n.Synd) = CASE WHEN Entity = 'ANY' THEN ISNULL(g.Synd,n.Synd) ELSE Entity END


;WITH CTE AS (
SELECT	DISTINCT Synd,Currency ,SIIClassType,'Reinsurance Receivables' AS SIIField,'S0201Field' AS SIIMappingType,
		SUM(GrossUnDiscValue) OVER(PARTITION BY Synd,Currency)*1.000000000 /
		SUM(GrossUnDiscValue) OVER(PARTITION BY Synd) *1.000000000 AS AllocationPercentage
FROM	#TPDataForAllocations
WHERE	SIIClassType = 'Treaty'
		AND		LTRIM(RTRIM(Dataset_Type)) IN ('CP - Acq Costs EFP',
		'CP - Future Premiums Gross of Commission',
		'PP - Acq Costs UFP',
		'PP - Future Premiums Gross of Commission'
		)
UNION
SELECT	DISTINCT Synd,Currency ,SIIClassType,'Insurance & intermediaries receivables' AS SIIField, 'S0201Field' AS SIIMappingType,
		SUM(GrossUnDiscValue) OVER(PARTITION BY Synd,Currency)*1.000000000 /
		SUM(GrossUnDiscValue) OVER(PARTITION BY Synd) *1.000000000 AS AllocationPercentage
FROM	#TPDataForAllocations
WHERE	SIIClassType = 'Non-Treaty'
AND		LTRIM(RTRIM(Dataset_Type)) IN ('CP - Acq Costs EFP',
		'CP - Future Premiums Gross of Commission',
		'PP - Acq Costs UFP',
		'PP - Future Premiums Gross of Commission'
		)
UNION
SELECT	DISTINCT Synd,Currency ,'All' AS SIIClassType,'Reinsurance Payables' AS SIIField, 'S0201Field' AS SIIMappingType,
		SUM(GrossUnDiscValue - NetUnDiscValue) OVER(PARTITION BY Synd,Currency) /
		SUM(GrossUnDiscValue - NetUnDiscValue) OVER(PARTITION BY Synd) AS AllocationPercentage
FROM	#TPDataForAllocations
WHERE	LTRIM(RTRIM(Dataset_Type)) IN ('CP - Acq Costs EFP',
		'CP - Future Premiums Gross of Commission',
		'PP - Acq Costs UFP',
		'PP - Future Premiums Gross of Commission'
		)
UNION
SELECT	DISTINCT Synd,Currency ,'All' AS SIIClassType,'Technical provisions (excluding index-linked and unit-linked funds)' AS SIIField, 'S0202Field' AS SIIMappingType,
		SUM(GrossDiscValue + NetDiscRiskMargin) OVER(PARTITION BY Synd,Currency) /
		SUM(GrossDiscValue + NetDiscRiskMargin) OVER(PARTITION BY Synd) AS AllocationPercentage
FROM	#TPDataForAllocations
UNION
SELECT	DISTINCT Synd,Currency ,'All' AS SIIClassType,'Reinsurance recoverables' AS SIIField,'S0202Field' AS SIIMappingType,
		SUM(GrossDiscValue - NetDiscValue) OVER(PARTITION BY Synd,Currency) /
		SUM(GrossDiscValue - NetDiscValue) OVER(PARTITION BY Synd) AS AllocationPercentage
FROM	#TPDataForAllocations
UNION
SELECT	DISTINCT 'BEREBRQS' AS Synd,Currency ,'All' AS SIIClassType,'Technical provisions (excluding index-linked and unit-linked funds)' AS SIIField, 'S0202Field' AS SIIMappingType,
		SUM(NetDiscValue + NetDiscRiskMargin) OVER(PARTITION BY  'BEREBRQS' ,Currency) /
		SUM(NetDiscValue + NetDiscRiskMargin) OVER(PARTITION BY  'BEREBRQS') AS AllocationPercentage
FROM	#TPDataForAllocations
WHERE	Synd IN (SELECT Entity FROM SIIEntityAllocationBasis WHERE EntityAllocationGroup = 'BEREBRQS')
)
SELECT	*
INTO	#BSAllocationPercentage
FROM	CTE



;WITH	CTE1 AS (
SELECT	synd
		,SIIClassType
		,SIIField
		,Currency
		,AllocationPercentage
		,RANK() OVER   
				(PARTITION BY synd,SIIClassType,SIIField ORDER BY AllocationPercentage DESC) AS TopCurrency FROM #BSAllocationPercentage
)
,CTE2	AS (
SELECT	synd
		,SIIClassType
		,SIIField
		,1-SUM(AllocationPercentage) AS LeftOver  
FROM	#BSAllocationPercentage b
GROUP	BY synd,SIIClassType,SIIField
HAVING	SUM(AllocationPercentage) <> 1
)

UPDATE	a
SET		AllocationPercentage = a.AllocationPercentage + LeftOver
FROM	 #BSAllocationPercentage a
JOIN	CTE1 c
ON		c.Currency = a.Currency
AND		c.SIIClassType = a.SIIClassType
AND		c.SIIField = a.SIIField
AND		c.Synd = a.Synd
JOIN	CTE2 b 
ON		c.SIIClassType = b.SIIClassType
AND		c.SIIField = b.SIIField
AND		c.Synd = b.Synd
WHERE	c.TopCurrency = 1

TRUNCATE TABLE [dbo].[SIIAllocatedDataBS]

;WITH	CTE AS (
SELECT	[S0201Category]
		,[S0202Category]
		,b.AgressoAccount
		,ISNULL(currencyToReport,[currency]) AS [currency]
		,b.[EntityReportingType]
		,CASE WHEN b.[EntityReportingType] = 'Syndicate' THEN b.ReportingEntityCode ELSE b.[EntityReportingType] END AS EntityGroup
		,[EntityType]
		,[S0201TagetikAccount]
		,[S0202TagetikAccount]
		,SUM(Value) Value
FROM	[dbo].[SIIUnAllocatedDataBS] b
LEFT	JOIN (SELECT 'BPLC' [EntityReportingType], Entity FROM SIIEntityGroups WHERE EntityGroup = 'BEREBRQS') a 
ON		a.EntityReportingType = b.EntityReportingType
AND		a.Entity = b.EntityCode
WHERE	a.Entity IS NULL
GROUP	BY [S0201Category]
		,[S0202Category]
		,b.AgressoAccount
		,ISNULL(currencyToReport,[currency]) 
		,b.[EntityReportingType]
		,[EntityType]
		,[S0201TagetikAccount]
		,[S0202TagetikAccount]
		,CASE WHEN b.[EntityReportingType] = 'Syndicate' THEN b.ReportingEntityCode ELSE b.[EntityReportingType] END
UNION
SELECT	[S0201Category]
		,[S0202Category]
		,b.AgressoAccount
		,ISNULL(currencyToReport,[currency]) AS [currency]
		,b.[EntityReportingType]
		,'BEREBRQS' AS EntityGroup
		,[EntityType]
		,[S0201TagetikAccount]
		,[S0202TagetikAccount]
		,SUM(Value) VALUE
FROM	[dbo].[SIIUnAllocatedDataBS] b
JOIN	(SELECT 'BPLC' [EntityReportingType], Entity FROM SIIEntityGroups WHERE EntityGroup = 'BEREBRQS') a 
ON		a.EntityReportingType = b.EntityReportingType
AND		a.Entity = b.EntityCode
GROUP	BY [S0201Category]
		,[S0202Category]
		,ISNULL(currencyToReport,[currency])
		,b.[EntityReportingType]
		,[EntityType]
		,[S0201TagetikAccount]
		,[S0202TagetikAccount]
		,b.AgressoAccount
)

INSERT	INTO [dbo].[SIIAllocatedDataBS]
		([S0201Category]
		,[S0202Category]
		,c.AgressoAccount
		,[currency]
		,[EntityReportingType]
		,[EntityGroup]
		,[EntityType]
		,[S0201TagetikAccount]
		,[S0202TagetikAccount]
		,[Value]
		,[AllocationPercentage]
		,[ReportingCurrency]
		,[AllocateValue])
SELECT	c.[S0201Category]
		,c.[S0202Category]
		,c.AgressoAccount
		,c.[currency]
		,c.[EntityReportingType]
		,c.[EntityGroup]
		,c.[EntityType]
		,c.[S0201TagetikAccount]
		,c.[S0202TagetikAccount]
		,c.[Value]
		,ISNULL(AllocationPercentage,1.00) AS AllocationPercentage
		,ISNULL(p.Currency,c.currency) AS ReportingCurrency
		,c.Value*ISNULL(AllocationPercentage,1.00) AS AllocateValue 
FROM	CTE  c
LEFT	JOIN	#BSAllocationPercentage p
ON		LTRIM(RTRIM(p.Synd)) =  LTRIM(RTRIM( c.EntityGroup)) 
AND		p.SIIField = CASE WHEN p.SIIMappingType = 'S0201Field' THEN c.S0201Category ELSE c.S0202Category END
WHERE	EntityReportingType = @EntityReportingType
ORDER	BY Value

IF		OBJECT_ID('tempdb.dbo.#TPDataForAllocations', 'U') IS NOT NULL
DROP	TABLE #TPDataForAllocations; 

IF		OBJECT_ID('tempdb.dbo.#BSAllocationPercentage', 'U') IS NOT NULL
DROP	TABLE #BSAllocationPercentage; 

END
