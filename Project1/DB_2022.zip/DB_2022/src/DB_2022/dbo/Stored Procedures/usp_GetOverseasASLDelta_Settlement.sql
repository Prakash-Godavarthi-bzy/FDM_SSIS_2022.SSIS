﻿---- =============================================
---- Author:		Samata Putumbaka
---- Create date: 02/07/2019
---- Description:	Create settlement rows for Overseas
---- =============================================
----EXEC [dbo].[usp_GetOverseasASLDelta_Settlement] 3,201909
CREATE PROCEDURE [dbo].[usp_GetOverseasASLDelta_Settlement]

	@IncrementedLoadID AS VARCHAR(100) 
   ,@AccountingPeriod AS INT 
AS
BEGIN
DECLARE @i int = 0 

--DECLARE	@LastLoadID INT, @CurrentLoadID INT, @curLoadID int, @LoadID int
--SELECT	@curLoadID = ISNULL(MAX(LoadID),0) FROM [dbo].[OverseasandASLExtract]
DECLARE @AccountingYear INT ,
		@AccountingMonth INT,
        @StartYear INT,
		@EndYear INT
SELECT @AccountingYear = LEFT(@AccountingPeriod,4)
SELECT @StartYear = CAST(LEFT(@AccountingPeriod,4) AS CHAR(4))+'01'
SELECT @AccountingMonth = CAST(@AccountingPeriod AS CHAR(6))+'01'
SELECT @EndYear   = LEFT(CONVERT(VARCHAR(10),CONVERT(DATETIME,CONVERT(VARCHAR(10),@AccountingMonth,120)),112),6)

	SELECT
	   [AccountHolder]
      ,ext.[SyndicateNo]
      ,[DepositNo]
	  ,ext.[AccountCode]
      ,[ReportingDate]
	  ,YOA
      ,'USD' AS Currency
      ,SUM(ISNULL(GBPSettlementAmount,0))  AS Settlement_amount
	  ,fx.FXRate AS FXRate
	  ,'Z140'  AS Trifocus
	  ,ROUND(SUM(ISNULL(GBPSettlementAmount,0))/ISNULL(FXRate,1),3)  AS cur_amount
	  ,ROUND(SUM(ISNULL(GBPSettlementAmount,0)),3)  AS Value_3---GBP
	  ,ROUND(SUM(ISNULL(GBPSettlementAmount,0))/ISNULL(FXRate,1),3) AS Amount---USD	 
	  ,CASE WHEN SyndicateNo='3622' THEN ROUND(SUM(ISNULL(GBPSettlementAmount,0)),3) ELSE  ROUND(SUM(ISNULL(GBPSettlementAmount,0))/ISNULL(FXRate,1),3) END AS Value_2---USD	
  FROM [dbo].[OverseasandASLExtract] as ext
   CROSS APPLY
  (SELECT fx.FXRate
  FROM
  dbo.FactFXRate fx 
  JOIN
  dbo.DimReportingCurrency as rep
  ON fx.fk_ReportingCurrency = rep.pk_ReportingCurrency
  WHERE fx.fk_TransactionCurrency = 'GBP'
  AND rep.ReportingCurrencyCode = 'USD'
  AND fk_FXRate = 2
  and fk_AccountingPeriod =@AccountingPeriod) fx
  WHERE	LoadID = @IncrementedLoadID
  AND ext.AccountCode IN ('75605','75570','75580','75590')
  GROUP BY   ext.[AccountHolder]
			,ext.[SyndicateNo]
			,[DepositNo]
			,[ReportingDate]
			,YOA
			,ext.AccountCode
			,fx.FXRate
	UNION
	SELECT
	   [AccountHolder]
      ,ext.[SyndicateNo]
      ,[DepositNo]
	  ,ext.[AccountCode]
      ,[ReportingDate]
	  ,YOA
      ,'GBP' AS Currency
      ,SUM(ISNULL(GBPSettlementAmount,0))*-1  AS Settlement_amount
	  ,fx.FXRate AS FXRate
	  ,'Z140'  AS Trifocus
	  ,ROUND(SUM(ISNULL(GBPSettlementAmount,0))*-1,3)  AS cur_amount
	  ,ROUND(SUM(ISNULL(GBPSettlementAmount,0))*-1,3)  AS Value_3---GBP
	  ,ROUND(SUM(ISNULL(GBPSettlementAmount,0))/ISNULL(FXRate,1)*-1,3) AS Amount---USD	 
	  ,CASE WHEN SyndicateNo = '3622' THEN ROUND(SUM(ISNULL(GBPSettlementAmount,0))*-1,3) ELSE ROUND(SUM(ISNULL(GBPSettlementAmount,0))/ISNULL(FXRate,1)*-1,3) END AS Value_2---USD	
  FROM [dbo].[OverseasandASLExtract] as ext
   CROSS APPLY
  (SELECT fx.FXRate
  FROM
  dbo.FactFXRate fx 
  JOIN
  dbo.DimReportingCurrency as rep
  ON fx.fk_ReportingCurrency = rep.pk_ReportingCurrency
  WHERE fx.fk_TransactionCurrency = 'GBP'
  AND rep.ReportingCurrencyCode = 'USD'
  AND fk_FXRate = 2
  and fk_AccountingPeriod =@AccountingPeriod) fx
  WHERE	LoadID = @IncrementedLoadID
  AND ext.AccountCode IN ('75605','75570','75580','75590')
  GROUP BY   ext.[AccountHolder]
			,ext.[SyndicateNo]
			,[DepositNo]
			,[ReportingDate]
			,YOA
			,ext.AccountCode
			,fx.FXRate

END
GO

