﻿CREATE PROCEDURE [dbo].[usp_FACTFDMExternal_DataRetention]	
AS
BEGIN
	SET NOCOUNT ON		
		/***********************Getting Retention period config values ****************************************************/
		DECLARE @RetentionPeriod INT,@RetentionPeriodType VARCHAR(50),@RowsPerBatch INT,@RetentionConfigId INT

		SELECT @RetentionPeriod = RetentionPeriod
		     , @RetentionPeriodType = RetentionPeriodType
			 , @RowsPerBatch = RowsPerBatch 
			 , @RetentionConfigId = DataRetentionConfigId
		  FROM FDM_PROCESS.[Admin].[DataRetentionConfig] 
		 WHERE TableName = 'FactFDMExternal_Current'
		
		SET @RetentionPeriod = ISNULL(@RetentionPeriod,0)
			
		DECLARE @RetentionDate DATE
		SET @RetentionDate = DATEADD(DD,-(@RetentionPeriod), GETDATE()) 
		
		IF (@RetentionPeriodType = 'Days') 
			SET @RetentionDate = DATEADD(DD,-(@RetentionPeriod), GETDATE())
		ELSE IF (@RetentionPeriodType = 'Weeks')
			SET @RetentionDate = DATEADD(WK,-(@RetentionPeriod), GETDATE())
		ELSE IF (@RetentionPeriodType = 'Months')
			SET @RetentionDate = DATEADD(MM,-(@RetentionPeriod), GETDATE())
		ELSE IF (@RetentionPeriodType = 'Years')
			SET @RetentionDate = DATEADD(YY,-(@RetentionPeriod), GETDATE())
		ELSE 
			SET @RetentionDate = DATEADD(DD,-(@RetentionPeriod), GETDATE())
		
		--SELECT @RetentionDate
		--SELECT @RetentionPeriod,@RetentionPeriodType,@RowsPerBatch
		
		/***************FactFDMExternal_Current table will contain data for the current week ************************/
		
	
		IF(OBJECT_ID('tempdb..#FactFDMExternal_Current') IS NOT NULL)
			DROP TABLE #FactFDMExternal_Current

		SELECT T.*,ROW_NUMBER() OVER (ORDER BY T.pk_FactFDMExternal) AS RowId
		INTO #FactFDMExternal_Current
		FROM ( 
				SELECT F.* FROM dbo.FactFDMExternal_Current F
				 INNER JOIN FDM_PROCESS.[admin].[RunProcessLog] l
					ON F.RunProcessLogID = l.RunProcessLogID
				 WHERE l.StartTime < @RetentionDate						  
			 ) AS T
		  LEFT JOIN dbo.FactFDMExternal_History C
			ON T.pk_FactFDMExternal = C.pk_FactFDMExternal
		 WHERE C.pk_FactFDMExternal IS NULL

		DECLARE @BatchSize INT,@TotalRowsCount INT,@loopCount INT,@StartId INT,@EndId INT,@LoopBatchrowcnt int

		SET @BatchSize = ISNULL(@RowsPerBatch,10000)
		DECLARE @StartTime DATETIME,@EndTime DATETIME
		SET @StartTime = GETDATE()

		SET @TotalRowsCount = (SELECT COUNT(1) FROM #FactFDMExternal_Current)
		
		SET @loopCount = 1
		SET @StartId = 1
		SET @EndId = @BatchSize

BEGIN TRY
	WHILE (@loopCount < @TotalRowsCount)

		BEGIN

			BEGIN TRAN

			SET @StartTime = GETDATE()

			--SELECT MIN(RowId) AS MINID,MAX(RowId) AS MAXID FROM #FactFDMExternal_Current WHERE RowId BETWEEN @StartId AND @EndId

			INSERT INTO dbo.FactFDMExternal_History (pk_FactFDMExternal,fk_Account,fk_AccountingPeriod,fk_BusinessPlan,fk_ClaimExposure,fk_DataStage
					  , fk_Entity,fk_Expense,fk_Holding,fk_LloydsClassifications,fk_Office,fk_OriginalCurrency,fk_PolicySection,fk_Process,fk_Product
					  , fk_Project,fk_RIPolicy,fk_Scenario,fk_SourceSystem,fk_TriFocus,fk_YOA,fk_Client,bk_TransactionID,[Description],ExtRef,ExtInvRef
					  , ap_ar_id,ap_ar_type,Dim1,Dim2,Dim3,Dim4,Dim5,Dim6,Dim7,VoucherNumber,[Value],cur_amount,currency,value_1,value_2,value_3,fk_User
					  , insert_date,insert_time,voucher_date,transaction_date,tax_code,tax_system,fk_Special,fk_ClassofBusiness,fk_DimEarnings
					  , fk_TargetEntity,fk_TargetPeriod,fk_PolicySectionV2,RunProcessLogID)
			SELECT T.pk_FactFDMExternal,T.fk_Account,T.fk_AccountingPeriod,T.fk_BusinessPlan,T.fk_ClaimExposure,T.fk_DataStage
					  , T.fk_Entity,T.fk_Expense,T.fk_Holding,T.fk_LloydsClassifications,T.fk_Office,T.fk_OriginalCurrency,T.fk_PolicySection,T.fk_Process,T.fk_Product
					  , T.fk_Project,T.fk_RIPolicy,T.fk_Scenario,T.fk_SourceSystem,T.fk_TriFocus,T.fk_YOA,T.fk_Client,T.bk_TransactionID,T.[Description],T.ExtRef,T.ExtInvRef
					  , T.ap_ar_id,T.ap_ar_type,T.Dim1,T.Dim2,T.Dim3,T.Dim4,T.Dim5,T.Dim6,T.Dim7,T.VoucherNumber,T.[Value],T.cur_amount,T.currency,T.value_1,T.value_2,T.value_3,T.fk_User
					  , T.insert_date,T.insert_time,T.voucher_date,T.transaction_date,T.tax_code,T.tax_system,T.fk_Special,T.fk_ClassofBusiness,T.fk_DimEarnings
					  , T.fk_TargetEntity,T.fk_TargetPeriod,T.fk_PolicySectionV2,ISNULL(T.RunProcessLogID,-1) AS RunProcessLogID ---1 AS RunProcessLogID		
			  FROM  #FactFDMExternal_Current T WHERE RowId BETWEEN @StartId AND @EndId

			  SET @LoopBatchrowcnt=@@ROWCOUNT
		
			/*******************************Delete last week data *************************************/
			
			--SELECT A.*
			DELETE A
			FROM dbo.FactFDMExternal_Current A
			INNER JOIN #FactFDMExternal_Current B
			ON A.pk_FactFDMExternal = B.pk_FactFDMExternal 
			WHERE RowId BETWEEN @StartId AND @EndId	
			 
			 SET @EndTime = GETDATE()

			 INSERT INTO FDM_PROCESS.[Admin].[DataRetentionLog] (fk_DataRetentionConfigId,StartTime,EndTime,[RowCount],CreatedDate,CreatedBy,ActionType)
			 SELECT @RetentionConfigId,@StartTime,@EndTime,@LoopBatchrowcnt,GETDATE(),null,'Moved data to History table'

			 SET @LoopBatchrowcnt=0
			 
			SET @loopCount += @BatchSize;
			SET @StartId = @EndId + 1 ;
			SET @EndId = @StartId + @BatchSize - 1;

		Commit Tran
		END

IF(@TotalRowsCount=0)
	BEGIN

	SET @StartTime=GETDATE()
	SET @EndTime=GETDATE()

		INSERT INTO FDM_PROCESS.[Admin].[DataRetentionLog] (fk_DataRetentionConfigId,StartTime,EndTime,[RowCount],CreatedDate,CreatedBy,ActionType)
		SELECT @RetentionConfigId,@StartTime,@EndTime,@TotalRowsCount,GETDATE(),null,'Moved data to History table'
	END

END TRY
	
	BEGIN CATCH
		IF @@TRANCOUNT>0 
			
			ROLLBACK Tran

				SET @LoopBatchrowcnt=0
	
				SET @EndTime = GETDATE()

				INSERT INTO FDM_PROCESS.[Admin].[DataRetentionLog] (fk_DataRetentionConfigId,StartTime,EndTime,[RowCount],CreatedDate,CreatedBy,ActionType)
				SELECT @RetentionConfigId,@StartTime,@EndTime,@LoopBatchrowcnt,GETDATE(),NULL,SUBSTRING(ERROR_MESSAGE(),1,255)
	END CATCH;
END