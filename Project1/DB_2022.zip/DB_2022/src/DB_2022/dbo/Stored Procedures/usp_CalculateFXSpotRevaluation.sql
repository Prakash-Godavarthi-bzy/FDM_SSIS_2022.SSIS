﻿
-- =============================================
-- Author:		Samata Putumbaka
-- Create date: 23/08/2019
-- Description:	Perform FX Spot Revaluation on Overseas files from Lloyds
-- =============================================

--EXEC [dbo].[usp_CalculateFXSpotRevaluation] 34,201909
CREATE PROCEDURE [dbo].[usp_CalculateFXSpotRevaluation]
	@IncrementedLoadID AS VARCHAR(100)
   ,@AccountingPeriod AS INT
AS
BEGIN
DECLARE @i int = 0 

--DECLARE @LastLoadID INT, @CurrentLoadID INT, @curLoadID int, @LoadID int
--SELECT  @curLoadID = ISNULL(MAX(LoadID),0) FROM [dbo].[OverseasandASLExtract]
DECLARE --@AccountingPeriod INT = 201909,
        @PrevAccountingPeriod INT 
		SET @PrevAccountingPeriod = LEFT(CONVERT(VARCHAR(10),DATEADD(quarter,-1,CAST((LEFT(@AccountingPeriod,4) + '-' + RIGHT(@AccountingPeriod,2)+'-01') AS DATE)),112),6)

DECLARE @AccountingYear INT ,
		@AccountingMonth INT,
		@ZeroYear INT,
        @StartYear INT,
		@EndYear INT
SELECT @AccountingYear = LEFT(@AccountingPeriod,4)
SELECT @ZeroYear = CAST(LEFT(@AccountingPeriod,4) AS CHAR(4))+'00'
SELECT @StartYear = CAST(LEFT(@AccountingPeriod,4) AS CHAR(4))+'01'
SELECT @AccountingMonth = CAST(@AccountingPeriod AS CHAR(6))+'01'
SELECT @EndYear   = LEFT(CONVERT(VARCHAR(10),DATEADD("MM",-1,CONVERT(DATETIME,CONVERT(VARCHAR(10),@AccountingMonth,120))),112),6)

SELECT
	   [AccountHolder]
      ,ext.[SyndicateNo]
      ,ext.[DepositNo]
	  ,ext.[AccountCode]
      ,[ReportingDate]
	  ,fx.ReportingCurrencyCode AS Currency
      ,CASE WHEN ext.[YOA]>=@AccountingYear-2 
			THEN ext.YOA 
			ELSE @AccountingYear-2 
		END AS YOA
      ,SUM([TotalIncome]+[TotalCapital])  AS InvCap_Income
	  ,SUM([MktValueBF]) AS MarketValue_BF
	  ,SUM(AdjustmentAmount) AS AdjustmentAmount_CurrentQ
	  ,SUM(ext_prevq.AdjustmentAmount_PrevQ) AS AdjustmentAmount_PrevQ
	  ,SUM(os_ext.Cur_Amount) AS OS_Amount
	  ,SUM(ot_ext.Cur_Amount) AS OT_Amount
	  ,SUM(op_PrevQ.Cur_Amount) AS OpeningBal_PrevQ
	  ,fx.FXRate
	  /*,(SUM([MktValueBF]) + SUM([TotalIncome]+[TotalCapital]) + SUM(AdjustmentAmount) + SUM(ext_prevq.AdjustmentAmount_PrevQ))
	  ,(SUM([MktValueBF]) + SUM([TotalIncome]+[TotalCapital]) + SUM(AdjustmentAmount) + SUM(ext_prevq.AdjustmentAmount_PrevQ))/ fx.FXRate  
	  ,(SUM(op_PrevQ.Cur_Amount) + SUM(os_ext.Cur_Amount) + SUM(ot_ext.Cur_Amount)) 
	  */,(SUM(ISNULL([MktValueBF],0)) + SUM(ISNULL([TotalIncome],0)+ISNULL([TotalCapital],0)) + SUM(ISNULL(AdjustmentAmount,0)) + SUM(ISNULL(ext_prevq.AdjustmentAmount_PrevQ,0)))/ fx.FXRate - 
	   (SUM(ISNULL(op_PrevQ.Cur_Amount,0)) + SUM(ISNULL(os_ext.Cur_Amount,0)) + SUM(ISNULL(ot_ext.Cur_Amount,0))) AS cur_Amount

FROM 
OverseasandASLExtract AS ext 
JOIN
OverseasandASLConfig AS con
ON ext.SyndicateNo = con.Syndicate
AND ext.DepositNo = con.[TAB Number]
LEFT JOIN
(SELECT ext.SyndicateNo,ext.DepositNo,
		CASE WHEN [YOA]>=LEFT(@PrevAccountingPeriod,4)-2 
			THEN YOA 
			ELSE LEFT(@PrevAccountingPeriod,4)-2 
		END AS YOA_prevq,
		SUM(ext.AdjustmentAmount) AS AdjustmentAmount_PrevQ
FROM
(SELECT SyndicateNo,DepositNo,MAX(LoadId) AS LoadId
FROM
OverseasandASLExtract
wHERE AccountingPeriod = @PrevAccountingPeriod
GROUP BY SyndicateNo,DepositNo
) AS ext_max
JOIN
OverseasandASLExtract as ext
ON ext_max.SyndicateNo = ext.SyndicateNo
AND ext_max.DepositNo  = ext.DepositNo
AND ext_max.LoadId     = ext.LoadId
wHERE ext.AccountingPeriod = @PrevAccountingPeriod
GROUP BY 
ext.SyndicateNo,ext.DepositNo,
		CASE WHEN [YOA]>=LEFT(@PrevAccountingPeriod,4)-2 
			THEN YOA 
			ELSE LEFT(@PrevAccountingPeriod,4)-2 
		END) ext_prevq
ON ext.SyndicateNo = ext_prevq.SyndicateNo
AND ext.DepositNo = ext_prevq.DepositNo
AND ext.YOA = ext_prevq .YOA_prevq
LEFT JOIN
(SELECT f.fk_TransactionCurrency,rep.ReportingCurrencyCode,f.FXRate
FROM
FactFXRate as f
JOIN
DimReportingCurrency as rep
ON f.fk_ReportingCurrency = rep.pk_ReportingCurrency
JOIN
DimFXRate as rat
ON f.fk_FXRate = rat.pk_FXRate
WHERE rat.FXRateName = 'Spot'
--AND fk_TransactionCurrency = 'ZAR'
AND rep.ReportingCurrencyCode in ('USD','GBP')
AND fk_AccountingPeriod = @AccountingPeriod) FX
ON ext.Currency = fx.fk_TransactionCurrency
AND CASE con.DepositType WHEN 'Overseas'
						 THEN 'USD'
						 ELSE 'GBP'
    END = fx.ReportingCurrencyCode
LEFT JOIN
(SELECT f.fk_YOA,SUM(Cur_Amount) as Cur_Amount
FROM
FactFDMExternal  as f
JOIN
DimProcess as p
ON f.fk_Process = p.pk_Process
JOIN
DimEntity as e
ON f.fk_Entity = e.pk_Entity
JOIN 
OverseasandASLExtract as ext 
ON e.EntityCode = ext.SyndicateNo
AND f.fk_YOA = ext.YOA
WHERE p.ProcessCode = 'OS'
AND fk_AccountingPeriod = @AccountingPeriod
AND fk_Account = '75570'
AND ext.LoadId = @IncrementedLoadID
GROUP BY fk_YOA) os_ext
ON ext.YOA = os_ext.fk_YOA
LEFT JOIN
(SELECT CASE WHEN [fk_YOA]>=@AccountingYear-2 
			THEN [fk_YOA] 
			ELSE @AccountingYear-2 
		END AS YOA
	    ,SUM(Cur_Amount) as Cur_Amount
FROM
FactFDMExternal  as f
JOIN
DimProcess as p
ON f.fk_Process = p.pk_Process
JOIN
DimEntity as e
ON f.fk_Entity = e.pk_Entity
JOIN 
OverseasandASLExtract as ext 
ON e.EntityCode = cast(ext.SyndicateNo as varchar)
AND f.fk_YOA = ext.YOA
WHERE p.ProcessCode = 'OT'
AND fk_AccountingPeriod = @AccountingPeriod
AND fk_Account = '75570'
AND f.currency = 'USD'
AND ext.LoadId = @IncrementedLoadID
GROUP BY CASE WHEN [fk_YOA]>=@AccountingYear-2 
			THEN [fk_YOA] 
			ELSE @AccountingYear-2 
		END) ot_ext
ON ext.YOA = ot_ext.YOA
LEFT JOIN
(SELECT CASE WHEN [fk_YOA]>=@AccountingYear-2 
			THEN [fk_YOA] 
			ELSE @AccountingYear-2 
		END AS YOA,
	    SUM(f.cur_amount) as Cur_Amount
FROM
FactFDM as f
JOIN
DimProcess as p
ON f.fk_Process = p.pk_Process
JOIN
DimEntity as e
ON f.fk_Entity = e.pk_Entity
JOIN
(SELECT DISTINCT cast(ext.SyndicateNo as varchar(10)) AS Syndicate
FROM OverseasandASLExtract as ext
WHERE LoadId = @IncrementedLoadID)ext
ON e.EntityCode = ext.Syndicate
WHERE fk_AccountingPeriod between @ZeroYear and  @PrevAccountingPeriod
AND fk_DataStage = 4
AND fk_Account = '75570'
AND f.currency = 'USD'
group BY CASE WHEN [fk_YOA]>=@AccountingYear-2 
			THEN [fk_YOA] 
			ELSE @AccountingYear-2 
		END
) AS op_PrevQ
on ext.YOA = op_PrevQ.YOA
WHERE AccountingPeriod = @AccountingPeriod
--AND ext.SyndicateNo = '2623'
--and ext.DepositNo = '708'
and LoadId = @IncrementedLoadID
GROUP BY
	   [AccountHolder]
      ,ext.[SyndicateNo]
      ,ext.[DepositNo]
	  ,ext.[AccountCode]
      ,[ReportingDate]
	  ,fx.ReportingCurrencyCode
	  ,CASE WHEN ext.[YOA]>=@AccountingYear-2 
			THEN ext.YOA 
			ELSE @AccountingYear-2 
		END
	  ,fx.FXRate
 
END
