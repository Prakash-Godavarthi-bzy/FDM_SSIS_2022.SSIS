﻿CREATE PROCEDURE [dbo].[usp_LoadPolicyMasterFile] 
WITH RECOMPILE
AS
BEGIN

;with cte_AgressoPolicy AS
(
SELECT 
               mop =LTRIM(RTRIM( isnull(r3.rel_value, 'NOMOP')))
              , section = LTRIM(RTRIM(r2.dim_value))
              , policy = LTRIM(RTRIM(case when left(r2.dim_value,1) in ('W','V') then ---US
                                         case when charindex('-',r2.dim_value,0) > 0 then
                                                left(r2.dim_value,charindex('-',r2.dim_value)-1)
                                  else
                                         r2.dim_value
                                  end
                                  else
                                         left(r2.dim_value,8) --Eurobase
                                  end))
								--  INTO #Test
       FROM
              staging_agresso.dbo.agldimvalue r2
              LEFT OUTER JOIN staging_agresso.dbo.aglrelvalue r3
              on r2.dim_value = r3.att_value and r2.client = r3.client AND r3.rel_attr_id = 'ZZ21'
       WHERE r2.client = (SELECT top 1  [client]
	   FROM [$(staging_agresso)].[dbo].[AMCCutoverConfig])
       AND r2.attribute_id = 'ZZ05'

)

SELECT src.MOPCode
		,src.PolicyReference
		,src.SectionReference
		,src.UWPlatform
		,src.PolicyDescription
FROM 
dbo.PolicyMasterFile as src
 LEFT JOIN
cte_AgressoPolicy as agg
ON src.SectionReference = agg.section
LEFT JOIN
dbo.PolicyMaster_toAgresso(nolock) as pol_mas
ON src.sectionReference = pol_mas.SectionReference
WHERE agg.policy is NULL AND pol_mas.PolicyReference IS NULL
--WHERE 1=2
END
GO

