﻿

-- =============================================
-- Author:		Nanda Gottumukkala
-- Create date: 02/10/2015
-- Description:	TO log the execution and record movements on the tables
-- =============================================
CREATE PROCEDURE [dbo].[usp_InsertIntoExecLog]
	@insertCount AS INT,
	@updateCount AS INT,
	@TableName AS VARCHAR(100),
	@DimensionType AS INT,
	@IntraDayFlag AS BIT,
	@MaxInsertedID AS BIGINT,
	@MaxDate AS DateTime


AS
BEGIN

	SET NOCOUNT ON;
	
	INSERT INTO [dbo].[ExecutionLog]
			   ([TableName]
			   ,[LastInsertedID]
			   ,[InsertCount]
			   ,[UpdateCount]
			   ,[LastInsertDate]
			   ,[IntraDayFlag]
			   ,[DimensionType])
		 VALUES
			   (@TableName
			   ,@MaxInsertedID
			   ,@insertCount
			   ,@updateCount
			   ,CASE WHEN @MaxDate is NULL THEN getDate()
			   ELSE @MaxDate END
			   ,@IntraDayFlag
			   ,@DimensionType)

END

