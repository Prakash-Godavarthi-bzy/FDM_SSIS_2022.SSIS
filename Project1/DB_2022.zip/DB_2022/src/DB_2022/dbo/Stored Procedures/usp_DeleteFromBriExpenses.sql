
-- =============================================
-- Author:		<Nanda Gottumukkala>
-- Create date: <26/01/2016>
-- Description:	<Description>
-- =============================================

CREATE PROCEDURE [dbo].[usp_DeleteFromBriExpenses]
	@AllocationGroup AS VARCHAR(255),
	@Adhoc AS BIT
AS
BEGIN

	SET NOCOUNT ON;
	--DECLARE @TriggersChanged INT
	--SELECT @TriggersChanged= [dbo].[usf_getTriggerChangedStatus] (@AllocationGroup,'')

	IF(OBJECT_ID('tempdb..#AllocationGroupToDelete') IS NOT NULL)
		DROP TABLE #AllocationGroupToDelete

	CREATE TABLE #AllocationGroupToDelete (
		AllocationGroup VARCHAR(100),AllocationCode VARCHAR(100),RowId INT IDENTITY
	)

	IF @Adhoc = 1 AND @AllocationGroup <> '' --AND @TriggersChanged = 1
	BEGIN 
		INSERT INTO #AllocationGroupToDelete (AllocationGroup,AllocationCode)
		SELECT	DISTINCT AllocationGroup,AllocationCode
		FROM	dbo.DimAllocationRules
		WHERE	[AllocationGroup] IN (@AllocationGroup)
		ORDER BY AllocationGroup,AllocationCode
	END
	ELSE IF @Adhoc = 0 --AND @TriggersChanged = 1
	BEGIN 
		INSERT INTO #AllocationGroupToDelete(AllocationGroup,AllocationCode)
		SELECT	DISTINCT a.AllocationGroup,AllocationCode
		FROM	[FDM_DB].dbo.DimAllocationRules a
		JOIN	[FDM_DB].[dbo].RealTimeAllocations b
		ON		a.AllocationGroup = b.AllocationGroup
		ORDER BY AllocationGroup,AllocationCode
	END


	IF(OBJECT_ID('tempdb..#AllocationGroupcodeversionToDelete') IS NOT NULL)
		DROP TABLE #AllocationGroupcodeversionToDelete

	SELECT A.AllocationGroup,A.AllocationCode,MAX(B.AllocationGroupCodeVersion) as AllocationGroupCodeVersion 
	INTO #AllocationGroupcodeversionToDelete 
	FROM #AllocationGroupToDelete A 
	JOIN dbo.DimAllocationRules B 
	  ON A.AllocationGroup=B.AllocationGroup
	  AND A.AllocationCode = B.AllocationCode
	GROUP BY A.AllocationGroup,A.AllocationCode

	DECLARE @RowsCoount INT,@CurrentRow INT = 1
	DECLARE @strAllocationGroup VARCHAR(100),@strAllocationCode VARCHAR(100)
	DECLARE @TriggersChanged INT

	SELECT @RowsCoount = COUNT(1) FROM #AllocationGroupToDelete
	WHILE (@RowsCoount >=@CurrentRow)
	BEGIN
		SELECT @strAllocationGroup = AllocationGroup,@strAllocationCode = AllocationCode 
		  FROM #AllocationGroupToDelete WHERE RowId = @CurrentRow
		
		SELECT @TriggersChanged= [dbo].[usf_getTriggerChangedStatus] (@strAllocationGroup,@strAllocationCode)
		--SELECT @TriggersChanged

		IF (@TriggersChanged = 1)
		BEGIN

			DELETE	FROM [BriExpensesTransactionDetailsV4]
			FROM	[FDM_DB].[dbo].[BriExpensesTransactionDetailsV4] b
			JOIN	dbo.DimAllocationRules v
			ON		b.FK_AllocationRules = v.PK_Alt_AllocationRules
			JOIN	#AllocationGroupToDelete r
			ON		r.AllocationGroup = v.AllocationGroup 
			--AND v.AllocationGroupCodeVersion=r.AllocationGroupCodeVersion
			WHERE v.AllocationGroup  =  @strAllocationGroup AND v.AllocationCode = @strAllocationCode
			 AND ( (V.ChangeType='Percent Update' AND IsCurrent = 1) OR ( V.ChangeType='Deleted' AND IsCurrent = 0) )
		END

		SET @CurrentRow = @CurrentRow + 1
		SET @TriggersChanged = 0
	END

	--DELETE	FROM [BriExpensesTransactionDetailsV4]
	--FROM	[FDM_DB].[dbo].[BriExpensesTransactionDetailsV4] b
	--JOIN	dbo.DimAllocationRules v
	--ON		b.FK_AllocationRules = v.PK_Alt_AllocationRules
	--JOIN	#AllocationGroupcodeversionToDelete r
	--ON		r.AllocationGroup = v.AllocationGroup 
	----AND v.AllocationGroupCodeVersion=r.AllocationGroupCodeVersion
	--WHERE  ( (V.ChangeType='Percent Update' AND IsCurrent = 1) OR ( V.ChangeType='Deleted' AND IsCurrent = 0) )
	----V.ChangeType IN('Percent Update','Deleted') AND IsCurrent=1
END