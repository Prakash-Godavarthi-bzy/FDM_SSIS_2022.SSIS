﻿CREATE PROCEDURE [dbo].[usp_DimTransactionDetailsV1_HistoryClean]	
AS
BEGIN	
			
		/***********************Get current Accounting Period and Accounting Period Limit *******************************************************/
		DECLARE @RetentionPeriod INT,@RetentionPeriodType VARCHAR(50),@RowsPerBatch INT,@RetentionConfigId INT

		SELECT @RetentionPeriod = RetentionPeriod
		     , @RetentionPeriodType = RetentionPeriodType
			 , @RowsPerBatch = RowsPerBatch 
			 , @RetentionConfigId = DataRetentionConfigId
		  FROM FDM_PROCESS.[Admin].[DataRetentionConfig] 
		 WHERE TableName = 'DimTransactionDetailsV1_History'
		
		SET @RetentionPeriod = ISNULL(@RetentionPeriod,0)
			
		DECLARE @AccountingPeriod INT,@AccountPeriodLimit INT
		SELECT @AccountingPeriod = CAST(YEAR(GETDATE()) AS VARCHAR(4)) +''+ RIGHT('0' + CAST(MONTH(GETDATE()) AS VARCHAR(2)), 2)

		IF (@RetentionPeriodType = 'Days') 
			SELECT @AccountPeriodLimit = CAST(YEAR(DATEADD(DD,-(@RetentionPeriod), GETDATE())) AS VARCHAR(4)) +''+ RIGHT('0' + CAST(MONTH(DATEADD(DD,-(@RetentionPeriod), GETDATE())) AS VARCHAR(2)), 2)
		ELSE IF (@RetentionPeriodType = 'Weeks')
			SELECT @AccountPeriodLimit = CAST(YEAR(DATEADD(WK,-(@RetentionPeriod), GETDATE())) AS VARCHAR(4)) +''+ RIGHT('0' + CAST(MONTH(DATEADD(WK,-(@RetentionPeriod), GETDATE())) AS VARCHAR(2)), 2)
		ELSE IF (@RetentionPeriodType = 'Months')
			SELECT @AccountPeriodLimit = CAST(YEAR(DATEADD(MM,-(@RetentionPeriod), GETDATE())) AS VARCHAR(4)) +''+ RIGHT('0' + CAST(MONTH(DATEADD(MM,-(@RetentionPeriod), GETDATE())) AS VARCHAR(2)), 2)
		ELSE IF (@RetentionPeriodType = 'Years')
			SELECT @AccountPeriodLimit = CAST(YEAR(DATEADD(YY,-(@RetentionPeriod), GETDATE())) AS VARCHAR(4)) +''+ RIGHT('0' + CAST(MONTH(DATEADD(YY,-(@RetentionPeriod), GETDATE())) AS VARCHAR(2)), 2)
		ELSE 
			SELECT @AccountPeriodLimit = CAST(YEAR(DATEADD(DD,-(@RetentionPeriod), GETDATE())) AS VARCHAR(4)) +''+ RIGHT('0' + CAST(MONTH(DATEADD(DD,-(@RetentionPeriod), GETDATE())) AS VARCHAR(2)), 2)						
		
		--SELECT @AccountingPeriod,@AccountPeriodLimit
		--SELECT @RetentionPeriod,@RetentionPeriodType,@RowsPerBatch

		/***************Delete data from DimTransactionDetailsV1_History table for older than specified period************************/
		
		IF(OBJECT_ID('tempdb..#DimTransactionDetailsV1_History') IS NOT NULL)
			DROP TABLE #DimTransactionDetailsV1_History

		SELECT A.pk_FactFDM
			 , A.AccountingPeriod
			 , ROW_NUMBER() OVER (ORDER BY A.pk_FactFDM) AS RowId
		  INTO #DimTransactionDetailsV1_History
		  FROM dbo.DimTransactionDetailsV1_History A
		 INNER JOIN dbo.DimAccountingPeriod B
		    ON A.AccountingPeriod = B.pk_AccountingPeriod 
		 WHERE B.AccountingPeriod <= @AccountPeriodLimit
		   AND A.Dim3 NOT IN ('BIARSP','BIARUK', 'BIARFR', 'BIARGE')

		--SELECT TOP 100 * FROM #DimTransactionDetailsV1_History 
		/*******************************Delete data older than 15 months*************************************/
		DECLARE @BatchSize INT,@TotalRowsCount INT,@loopCount INT,@StartId INT,@EndId INT
		DECLARE @StartTime DATETIME,@EndTime DATETIME
		SET @StartTime = GETDATE()

		SET @BatchSize = ISNULL(@RowsPerBatch,100000)
		SET @TotalRowsCount = (SELECT COUNT(1) FROM #DimTransactionDetailsV1_History)
		
		SET @loopCount = 1
		SET @StartId = 1
		SET @EndId = @BatchSize
		WHILE (@loopCount < @TotalRowsCount)
		BEGIN				
		
			/*******************************Delete data *************************************/
			
			--SELECT A.*
			DELETE A
			  FROM dbo.DimTransactionDetailsV1_History A
			 INNER JOIN #DimTransactionDetailsV1_History B
			    ON A.pk_FactFDM = B.pk_FactFDM 
			 WHERE RowId BETWEEN @StartId AND @EndId		
			 
			SET @loopCount += @BatchSize;
			SET @StartId = @EndId + 1 ;
			SET @EndId = @StartId + @BatchSize - 1;
		END	
		SET @EndTime = GETDATE()

		/***************************Loging data**************************************/
		INSERT INTO FDM_PROCESS.[Admin].[DataRetentionLog] (fk_DataRetentionConfigId,StartTime,EndTime,[RowCount],CreatedDate,CreatedBy,ActionType)
		SELECT @RetentionConfigId,@StartTime,@EndTime,@TotalRowsCount,GETDATE(),null,'Deleted data from History table'
END
