﻿
-- =============================================
-- Author:		Nanda Gottumukkala
-- Create date: 02/10/2015
-- Description:	To get base data for S.02.01 form
-- =============================================
CREATE PROCEDURE [dbo].[usp_SIIBaseDataS0201]
 @AccountingPeriodFrom AS INT
,@AccountingPeriodTo AS INT
,@SIIForm AS VARCHAR(255)
,@EntityGroup AS VARCHAR(255)
AS
BEGIN

SET @SIIForm = 'S.02.01'

--SET @EntityGroup = 'BEREBRQS'

IF OBJECT_ID('tempdb.dbo.#UnAllocatedData', 'U') IS NOT NULL
  DROP TABLE #UnAllocatedData; 
  
  
  TRUNCATE TABLE SIIUnAllocatedDataBS



SELECT	AgressoAccount,
		EntityCode AS SIIEntityCode,
		CASE WHEN EntityCode= 'SIIADJCONSOL' THEN 'USUKCONSOL' ELSE REPLACE(EntityCode,'SIIADJ','') END EntityCode,
		CASE WHEN LEN(dim7) > 2 THEN Dim7 ELSE '' END AS TargetEntity,
		@SIIForm AS SIIType,
		f.currency,
		EntityGroup,
		NULL AS Signage,
		SUM(ISNULL(Value,0.00)) Value
INTO	#UnAllocatedData
FROM	FactFDM f
JOIN	DimEntity e
ON		e.pk_Entity = f.fk_Entity
LEFT	JOIN SIIEntityGroups e1
ON		e1.Entity = CASE WHEN EntityCode= 'SIIADJCONSOL' THEN 'USUKCONSOL' ELSE REPLACE(EntityCode,'SIIADJ','') END
JOIN	(SELECT DISTINCT AgressoAccount,pk_Account FROM  SIIAccountMapping
		 JOIN DimAccount ON AgressoAccount = AccountCode 	 WHERE SIIType = 'S.02.01') a
ON		a.pk_Account = f.fk_Account
WHERE	fk_AccountingPeriod >= @AccountingPeriodFrom AND fk_AccountingPeriod <=@AccountingPeriodTo
AND		fk_scenario = 1
GROUP	BY 
		EntityCode,
		CASE WHEN EntityCode= 'SIIADJCONSOL' THEN 'USUKCONSOL' ELSE REPLACE(EntityCode,'SIIADJ','') END,
		f.currency,
		AgressoAccount,
		EntityGroup,
		CASE WHEN LEN(dim7) > 2 THEN Dim7 ELSE '' END 
HAVING	SUM(ISNULL(Value,0.00)) <> 0
--GO

INSERT INTO [dbo].[SIIUnAllocatedDataBS]
           ([AgressoAccount]
           ,[S0201Category]
           ,[S0202Category]
           ,[Signage]
           ,[EntityCode]
           ,[SIIEntityCode]
           ,[ReportingEntityCode]
           ,[TargetEntity]
           ,[SIIType]
           ,[currency]
           ,[Value]
           ,[EntityReportingType]
           ,[EntityType]
		   ,[S0201TagetikAccount]
		   ,[S0202TagetikAccount])
SELECT  u.AgressoAccount
		,CASE WHEN ISNULL(re.EntityType,'Consolidated') = 'Equity' THEN 'Participations' ELSE a.SIICategory END AS S0201Category
		,sm.S0202SIIField AS S0202Category
		,a.Signage
		,u.EntityCode
		,u.SIIEntityCode
		,CASE WHEN (e.TargetEntityFlag = 1 ) THEN (CASE WHEN TargetEntity= 'SIIADJCONSOL' THEN 'USUKCONSOL' ELSE REPLACE(TargetEntity,'SIIADJ','') END)  ELSE u.EntityCode END AS ReportingEntityCode
		,u.TargetEntity
		,u.SIIType
		,u.currency
		,u.Value
		,e.EntityReportingType 
		,ISNULL(re.EntityType,'Consolidated') AS EntityType
		,sm.S0201TagetikAccount
		,sm.S0202TagetikAccount
FROM	#UnAllocatedData u
JOIN	SIIEntityGroups e
ON		e.Entity = u.EntityCode
AND		e.EntityGroup = u.EntityGroup
LEFT	JOIN	(SELECT DISTINCT EntityType,Entity, EntityReportingType FROM SIIEntityGroups) re
ON		CASE WHEN (e.TargetEntityFlag = 1 ) THEN (CASE WHEN TargetEntity= 'SIIADJCONSOL' THEN 'USUKCONSOL' ELSE REPLACE(TargetEntity,'SIIADJ','') END)  ELSE u.EntityCode END = re.Entity
AND		re.EntityReportingType	= e.EntityReportingType
JOIN	(SELECT	u.EntityGroup
		,ISNULL(re.EntityType,'Consolidated') AS EntityType
		,AgressoAccount
		,SUM(Value) AS SignageVAlue
		FROM	#UnAllocatedData u
		JOIN	SIIEntityGroups e
		ON		e.Entity = u.EntityCode
		AND		e.EntityGroup = u.EntityGroup
		LEFT	JOIN	(SELECT DISTINCT EntityType,Entity, EntityReportingType FROM SIIEntityGroups) re
		ON		CASE WHEN (e.TargetEntityFlag = 1 ) THEN (CASE WHEN TargetEntity= 'SIIADJCONSOL' THEN 'USUKCONSOL' ELSE REPLACE(TargetEntity,'SIIADJ','') END)  ELSE u.EntityCode END = re.Entity
		AND		re.EntityReportingType	= e.EntityReportingType
		GROUP   BY
		u.EntityGroup
		,ISNULL(re.EntityType,'Consolidated')
		,AgressoAccount ) b
ON		u.AgressoAccount = b.AgressoAccount
AND		u.EntityGroup = b.EntityGroup
AND		ISNULL(re.EntityType,'Consolidated') = b.EntityType
JOIN	SIIAccountMapping a
ON		a.AgressoAccount = u.AgressoAccount
AND		a.EntityGroup = e.EntityGroup
AND		CASE WHEN SignageVAlue >=0.00 THEN 'DR' ELSE 'CR' END = a.Signage
AND		u.SIIType = a.SIIType
LEFT	JOIN	SIIS0201To0202Mapping sm
ON		sm.Signage = CASE WHEN SignageVAlue >=0.00 THEN 'DR' ELSE 'CR' END
AND		ltrim(rtrim(sm.S0201SIIField)) = ltrim(rtrim(CASE WHEN ISNULL(re.EntityType,'Consolidated') = 'Equity' THEN 'Participations' ELSE a.SIICategory END))
AND		sm.EntityReportingType = e.EntityReportingType
WHERE	e.EntityReportingType = 'BPLC'
ORDER BY 2 desc

INSERT INTO [dbo].[SIIUnAllocatedDataBS]
           ([AgressoAccount]
           ,[S0201Category]
           ,[S0202Category]
           ,[Signage]
           ,[EntityCode]
           ,[SIIEntityCode]
           ,[ReportingEntityCode]
           ,[TargetEntity]
           ,[SIIType]
           ,[currency]
           ,[Value]
           ,[EntityReportingType]
           ,[EntityType]
		   ,[S0201TagetikAccount]
		   ,[S0202TagetikAccount])
SELECT  u.AgressoAccount
		,CASE WHEN ISNULL(re.EntityType,'Consolidated') = 'Equity' THEN 'Participations' ELSE a.SIICategory END AS S0201Category
		,sm.S0202SIIField AS S0202Category
		,a.Signage
		,u.EntityCode
		,u.SIIEntityCode
		,CASE WHEN (e.TargetEntityFlag = 1 ) THEN (CASE WHEN TargetEntity= 'SIIADJCONSOL' THEN 'USUKCONSOL' ELSE REPLACE(TargetEntity,'SIIADJ','') END)  ELSE u.EntityCode END AS ReportingEntityCode
		,u.TargetEntity
		,u.SIIType
		,u.currency
		,u.Value
		,e.EntityReportingType 
		,ISNULL(re.EntityType,'Consolidated') AS EntityType
		,sm.S0201TagetikAccount
		,sm.S0202TagetikAccount
FROM	#UnAllocatedData u
JOIN	SIIEntityGroups e
ON		e.Entity = u.EntityCode
AND		e.EntityGroup = u.EntityGroup
JOIN	(SELECT	EntityGroup
		,AgressoAccount
		,SUM(Value) AS SignageVAlue
		FROM	#UnAllocatedData
		GROUP   BY
		EntityGroup
		,AgressoAccount ) b
ON		u.AgressoAccount = b.AgressoAccount
AND		u.EntityGroup = b.EntityGroup
JOIN	SIIAccountMapping a
ON		a.AgressoAccount = u.AgressoAccount
AND		a.EntityGroup = e.EntityGroup
AND		CASE WHEN SignageVAlue >=0.00 THEN 'DR' ELSE 'CR' END = a.Signage
AND		u.SIIType = a.SIIType
LEFT	JOIN	(SELECT DISTINCT EntityType,Entity, EntityReportingType FROM SIIEntityGroups) re
ON		CASE WHEN (e.TargetEntityFlag = 1 ) THEN (CASE WHEN TargetEntity= 'SIIADJCONSOL' THEN 'USUKCONSOL' ELSE REPLACE(TargetEntity,'SIIADJ','') END)  ELSE u.EntityCode END = re.Entity
AND		re.EntityReportingType	= e.EntityReportingType
LEFT	JOIN	SIIS0201To0202Mapping sm
ON	sm.EntityReportingType = e.EntityReportingType
AND		sm.Signage = CASE WHEN SignageVAlue >=0.00 THEN 'DR' ELSE 'CR' END
AND		ltrim(rtrim(sm.S0201SIIField)) = ltrim(rtrim(CASE WHEN ISNULL(re.EntityType,'Consolidated') = 'Equity' THEN 'Participations' ELSE a.SIICategory END))
WHERE	e.EntityReportingType = 'BEREBRQS'
ORDER BY 2 desc

INSERT INTO [dbo].[SIIUnAllocatedDataBS]
           ([AgressoAccount]
           ,[S0201Category]
           ,[S0202Category]
           ,[Signage]
           ,[EntityCode]
           ,[SIIEntityCode]
           ,[ReportingEntityCode]
           ,[TargetEntity]
           ,[SIIType]
           ,[currency]
           ,[Value]
           ,[EntityReportingType]
           ,[EntityType]
		   ,[S0201TagetikAccount]
		   ,[S0202TagetikAccount])
SELECT  u.AgressoAccount
		,CASE WHEN ISNULL(re.EntityType,'Consolidated') = 'Equity' THEN 'Participations' ELSE a.SIICategory END AS S0201Category
		,sm.S0202SIIField AS S0202Category
		,a.Signage
		,u.EntityCode
		,u.SIIEntityCode
		,CASE WHEN (e.TargetEntityFlag = 1 ) THEN (CASE WHEN TargetEntity= 'SIIADJCONSOL' THEN 'USUKCONSOL' ELSE REPLACE(TargetEntity,'SIIADJ','') END)  ELSE u.EntityCode END AS ReportingEntityCode
		,u.TargetEntity
		,u.SIIType
		,u.currency
		,u.Value
		,e.EntityReportingType 
		,ISNULL(re.EntityType,'Consolidated') AS EntityType
		,sm.S0201TagetikAccount
		,sm.S0202TagetikAccount
FROM	#UnAllocatedData u
JOIN	SIIEntityGroups e
ON		e.Entity = u.EntityCode
AND		e.EntityGroup = u.EntityGroup
JOIN	(SELECT	EntityGroup
		,AgressoAccount
		,SUM(Value) AS SignageVAlue
		FROM	#UnAllocatedData
		GROUP   BY
		EntityGroup
		,AgressoAccount ) b
ON		u.AgressoAccount = b.AgressoAccount
AND		u.EntityGroup = b.EntityGroup
JOIN	SIIAccountMapping a
ON		a.AgressoAccount = u.AgressoAccount
AND		a.EntityGroup = e.EntityGroup
AND		CASE WHEN SignageVAlue >=0.00 THEN 'DR' ELSE 'CR' END = a.Signage
AND		u.SIIType = a.SIIType
JOIN	(SELECT DISTINCT EntityType,Entity, EntityReportingType FROM SIIEntityGroups) re
ON		CASE WHEN (e.TargetEntityFlag = 1 ) THEN (CASE WHEN TargetEntity= 'SIIADJCONSOL' THEN 'USUKCONSOL' ELSE REPLACE(TargetEntity,'SIIADJ','') END)  ELSE u.EntityCode END = re.Entity
AND		re.EntityReportingType	= e.EntityReportingType
LEFT	JOIN	SIIS0201To0202Mapping sm
ON		ISNULL(sm.entitycode,sm.entityGroup) = e.EntityGroup
AND		sm.Signage = CASE WHEN SignageVAlue >=0.00 THEN 'DR' ELSE 'CR' END
AND		ltrim(rtrim(sm.S0201SIIField)) = ltrim(rtrim(CASE WHEN ISNULL(re.EntityType,'Consolidated') = 'Equity' THEN 'Participations' ELSE a.SIICategory END))
WHERE	e.EntityReportingType = 'syndicate'
ORDER	BY 5,2 desc

--Signage dependednt on Net of all accounts
UPDATE	a
SET		S0201Category = b.S0201SIIField
,		S0202Category = b.S0202SIIField
,		S0201TagetikAccount = b.S0201TagetikAccount
,		S0202TagetikAccount = b.S0202TagetikAccount
,		Signage = b.Signage
FROM	SIIUnAllocatedDataBS a
JOIN	(
			SELECT	DISTINCT a.AgressoAccount,m.*,n.Type FROM SIIAccountMapping a
			JOIN	SIIS0201To0202Mapping m
			ON		a.EntityGroup = m.EntityGroup
			AND		a.SIICategory = m.S0201SIIField
			JOIN	SIINetAccountsForBS n
			ON		n.AgressoAccount = a.AgressoAccount
			AND		n.EntityReportingType = a.EntityGroup
			JOIN	(			SELECT	CASE WHEN b.EntityReportingType = 'Syndicate' THEN ReportingEntityCode ELSE b.EntityReportingType END AS EntityReportingType,Type,SUM(Value) SignageValue FROM SIIUnAllocatedDataBS b
					JOIN	SIINetAccountsForBS n
					ON		n.AgressoAccount = b.AgressoAccount
					AND		n.EntityReportingType = CASE WHEN b.EntityReportingType = 'Syndicate' THEN ReportingEntityCode ELSE b.EntityReportingType END 		
					WHERE	EntityType = 'Consolidated'
					GROUP	BY CASE WHEN b.EntityReportingType = 'Syndicate' THEN ReportingEntityCode ELSE b.EntityReportingType END ,Type
			) sg
			ON		sg.EntityReportingType = m.EntityGroup
			AND		sg.Type = n.Type
			AND		m.Signage = CASE WHEN SignageVAlue >=0.00 THEN 'DR' ELSE 'CR' END

)		b
ON		CASE WHEN a.EntityReportingType = 'Syndicate' THEN  a.ReportingEntityCode ELSE a.EntityReportingType END = b.EntityReportingType
AND		a.AgressoAccount = b.AgressoAccount
WHERE	EntityType = 'Consolidated'

UPDATE b
SET	CurrencyToReport = a.SIIFunctionalCurrency
FROM [SIIUnAllocatedDataBS] b
JOIN (SELECT  * FROM SIIEntityGroups
WHERE EntityReportingType = 'BPLC'
AND EntityType = 'Equity') a 
ON	a.Entity = b.ReportingEntityCode
AND a.EntityReportingType = b.EntityReportingType

UPDATE b
SET	CurrencyToReport = a.SIIFunctionalCurrency
FROM [SIIUnAllocatedDataBS] b
JOIN (SELECT  * FROM SIIEntityGroups
WHERE EntityReportingType = 'BPLC'
AND EntityType = 'Consolidated'
AND	SIIFunctionalCurrency IS NOT NULL) a 
ON	a.Entity = b.ReportingEntityCode
AND a.EntityReportingType = b.EntityReportingType
WHERE b.S0201Category = 'Participations'



END

