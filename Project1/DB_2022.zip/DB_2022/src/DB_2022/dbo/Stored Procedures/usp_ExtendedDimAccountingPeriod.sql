﻿

-- =============================================
-- Author:		<Rishi Gupta>
-- Create date: <13/07/2017>
-- Description:	<Description>
-- =============================================

CREATE PROCEDURE [dbo].[usp_ExtendedDimAccountingPeriod]
AS
BEGIN
	DECLARE @MaxAPFact AS INT
	DECLARE @MaxAPDim AS INT



	SELECT @MaxAPFact = MAX([fk_AccountingPeriod]) FROM [FactFDM] WITH(NOLOCK) 
	SET @MaxAPFact =  @MaxAPFact + 1500
	--PRINT @maxapfact

	SELECT @MaxAPDim = MAX([pk_AccountingPeriod]) FROM [DimAccountingPeriod] WITH(NOLOCK)

	WHILE @MaxAPDim < @MaxAPFact
	BEGIN
		IF @MaxAPDim % 100 = 13
			SET @MaxAPDim = @MaxAPDim + 87
		ELSE
			SET @MaxAPDim = @MaxAPDim + 1
		INSERT INTO [DimAccountingPeriod] ([pk_AccountingPeriod],[AccountingPeriod],[AccountingYear],[AccountingYearName],[AccountingMonth],[AccountingMonthName])
		SELECT @MaxAPDim,@MaxAPDim,@MaxAPDim/100,@MaxAPDim/100,@MaxAPDim%100,RIGHT('0' + CAST(@MaxAPDim%100 AS nvarchar),2)
	END
END
