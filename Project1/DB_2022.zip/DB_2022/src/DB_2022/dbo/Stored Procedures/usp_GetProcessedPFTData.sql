﻿CREATE PROCEDURE dbo.usp_GetProcessedPFTData
/*
	EXEC dbo.usp_GetProcessedPFTData
	WITH RESULT SETS
	(
	 ( 
	  ExtractDate DateTime,
	  PFTDate NVARCHAR(10),
	  PremiumMonth INT,
	  ReviewCycle NVARCHAR(255),
	  MOP NVARCHAR(20),
	  TrifocusName NVARCHAR(255),
	  TrifocusCode NVARCHAR(255),
	  Department NVARCHAR(255),
	  YOA INT,
	  [TranCurr] NVARCHAR(255),
	  Entity NVARCHAR(255),
	  [Platform] NVARCHAR(255),
	  [Office Channel] NVARCHAR(255),
	  [Gross Gross Premium] [numeric](18, 4),
	  [Synd Premium NIC] [numeric](18, 4),
	  [Synd Premium GIC] [numeric](18, 4)
	 ) 
	) 

*/
	AS
	BEGIN
		IF(OBJECT_ID('tempdb..#Temp1') IS NOT NULL)
			DROP TABLE #Temp1

		SELECT ExtractDate
			 ,'01' + '/' + CASE WHEN RIGHT(ReviewCycle,1) = 1 THEN '03'
															 WHEN RIGHT(ReviewCycle,1) = 2 THEN '06'
															 WHEN RIGHT(ReviewCycle,1) = 3 THEN '09'
															 WHEN RIGHT(ReviewCycle,1) = 4 THEN '12'
														END + '/'+ CAST(LEFT(ReviewCycle,4) AS VARCHAR(4)) AS PFTDate
			 , ReviewCycle
			 , YOA
			 , EntityCode		 
			 , TrifocusCode
			 , TrifocusName
			 , [Platform],[Office Channel]		 
			 , MoP		  
			 , Base_Currency AS [Tran Curr]
			 , Accounts
			 , MONTH(CAST('01-' + Months +'-' +'2023' AS DATE)) AS [PremiumMonth]
			 , Amount
		  INTO #Temp1
		  FROM
				(SELECT Insert_Date AS ExtractDate,ReviewCycle,YoA,1 AS [PremiumMonth], RTRIM(LTRIM([Level])) AS EntityCode
					  , RTRIM(LTRIM([ProductCode])) AS TrifocusCode
					  , RTRIM(LTRIM(Product)) AS TrifocusName
					  , CASE WHEN RTRIM(LTRIM(Method_Of_Placement)) = 'Delegated' THEN 'Binder' ELSE 'Policy' END AS MoP,Base_Currency,RTRIM(LTRIM([Platform])) AS [Platform]
					  , RTRIM(LTRIM([Office Channel])) AS [Office Channel]
					  , [Jan],[Feb],[Mar],[Apr],[May],[Jun],[Jul],[Aug],[Sep],[Oct],[Nov],[Dec],  Accounts
				   FROM [$(staging_agresso)].[dbo].[StagePFT_SYND_WITH_CEDE] A	    
				) AS T
				UNPIVOT
				(Amount FOR Months IN ([Jan],[Feb],[Mar],[Apr],[May],[Jun],[Jul],[Aug],[Sep],[Oct],[Nov],[Dec])		
			) AS P1 --WHERE [Gross Gross Premium] != 0
	

	
		SELECT ExtractDate,PFTDate,[PremiumMonth],ReviewCycle,MOP		
			 , TrifocusName,TrifocuCode,Department
			 , YoA,[Tran Curr]
			 , ISNULL(Entity,EntityCodeSource) AS Entity		 
			 , [Platform]
			 , [Office Channel]
			 , ISNULL([Gross Gross Premium],0) AS [Gross Gross Premium]
			 , ISNULL([Gross Net Premium],0) AS [Synd Premium NIC]
			 , ISNULL([Gross Net Premium],0) AS [Synd Premium GIC]
			  --,(ISNULL([Gross Gross Premium],0) - ISNULL([Acquisition Costs],0)) AS  [Synd Premium NIC]
			  --,(ISNULL([Gross Gross Premium],0) - ISNULL([Acquisition Costs],0)) AS  [Synd Premium GIC]
			  --,[Gross Net Premium]
			  --,[Acquisition Costs]
		  
		  FROM
				(SELECT ExtractDate,PFTDate,[PremiumMonth],ReviewCycle,MOP				
					 , A.TrifocusName
					 , A.TrifocusCode AS TrifocuCode
					 , B.Department
					 , YoA,[Tran Curr]
					 , E.EntityCode AS Entity
					 , A.EntityCode AS EntityCodeSource
					 , A.[Platform]				 
					 , A.[Office Channel]				
					 , Amount
					 , Accounts
				   FROM #Temp1 A
				   LEFT JOIN FDM_DB.FDM_DC.DimTriFocus B
					 ON A.TrifocusCode = B.pk_TriFocus
				   LEFT JOIN FDM_DB.dbo.DimEntity E
					 ON A.EntityCode = E.EntityCode		  
				) AS T
				PIVOT
				(SUM(Amount) FOR Accounts IN ([Gross Gross Premium],[Gross Net Premium])--,[Acquisition Costs])		
			) AS P1 		
		 	
	END