﻿CREATE VIEW [dbo].[VW_FACTAllocationV1_Total]
	AS 
SELECT * FROM FACTAllocationsV1_Current
UNION ALL
SELECT * FROM FACTAllocationsV1_History

