﻿/************============================================
This view was created to avoid the breaking of SO1 Functionality after the TableSplit release happened to FDM.
Created :21-08-2020
========================================****************/
CREATE VIEW [dbo].[FACTAllocationsV1]
AS 
SELECT [pk_FACTAllocations],[pk_tempFactFDM],[Source_pk_tempFactFDM],[fk_Account],[fk_AccountingPeriod],[fk_BusinessPlan],[fk_ClaimExposure],[fk_DataStage]
      ,[fk_Entity],[fk_Expense],[fk_Holding],[fk_LloydsClassifications],[fk_Office],[fk_OriginalCurrency],[fk_PolicySection],[SectionReference],[fk_Process]
      ,[fk_Product],[fk_Project],[fk_RIPolicy],[fk_Scenario],[fk_SourceSystem],[fk_TriFocus],[fk_YOA],[fk_Client],[bk_TransactionID],[VoucherNumber],[Value],[cur_amount]
      ,[currency],[value_1],[value_2],[value_3],[fk_User],[insert_date],[insert_time],[voucher_date],[transaction_date],[tax_code],[tax_system],[fk_Location],[fk_InceptionDate]
      ,[fk_ExpiryDate],[CombinationID],[FK_AllocationRules],[AllocationPercent],[AccountDest],[LocationDest],[EntityDest],[YOADest],[ProcessDest],[ProjectDest],[TriFocusDest]
      ,[RuleApplicable],[AllocationCOde],[fk_DimEarnings],[fk_TargetEntity],[fk_TargetPeriod],[fk_PolicySectionV2],[TargetCurrencyDest],[BatchID],[gl_AccountingPeriod],[SoftDeleteFlag]
FROM FACTAllocationsV1_Current

UNION ALL

SELECT [pk_FACTAllocations],[pk_tempFactFDM],[Source_pk_tempFactFDM],[fk_Account],[fk_AccountingPeriod],[fk_BusinessPlan],[fk_ClaimExposure],[fk_DataStage]
      ,[fk_Entity],[fk_Expense],[fk_Holding],[fk_LloydsClassifications],[fk_Office],[fk_OriginalCurrency],[fk_PolicySection],[SectionReference],[fk_Process]
      ,[fk_Product],[fk_Project],[fk_RIPolicy],[fk_Scenario],[fk_SourceSystem],[fk_TriFocus],[fk_YOA],[fk_Client],[bk_TransactionID],[VoucherNumber],[Value],[cur_amount]
      ,[currency],[value_1],[value_2],[value_3],[fk_User],[insert_date],[insert_time],[voucher_date],[transaction_date],[tax_code],[tax_system],[fk_Location],[fk_InceptionDate]
      ,[fk_ExpiryDate],[CombinationID],[FK_AllocationRules],[AllocationPercent],[AccountDest],[LocationDest],[EntityDest],[YOADest],[ProcessDest],[ProjectDest],[TriFocusDest]
      ,[RuleApplicable],[AllocationCOde],[fk_DimEarnings],[fk_TargetEntity],[fk_TargetPeriod],[fk_PolicySectionV2],[TargetCurrencyDest],[BatchID],[gl_AccountingPeriod],[SoftDeleteFlag] 
FROM FACTAllocationsV1_History

