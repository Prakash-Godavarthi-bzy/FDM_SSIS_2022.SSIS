﻿



CREATE VIEW [dbo].[v_SIIPolicyLocationsMapping]
AS
SELECT	MIN(p.pk_PolicySection) AS pk_PolicySection
		,ISNULL(AgressoSectionReference,SectionReference) AS SectionReference
		,ISNULL(o.ISOCountryCode, 'Unknown') AS OrigUnderwritingLocation
		,ISNULL(a.ISOCountryCode, 'Unknown') AS OrigLocationOfRisk
		,CASE WHEN SourceSystem = 'BeazleyPro' THEN 'US' WHEN SourceSystem IS NULL THEN 'GB' ELSE o.ISOCountryCode END AS UnderwritingLocation
		,a.ISOCountryCode AS LocationOfRisk
		,OriginalCurrencyCode
FROM	DimPolicySectionV2 p
LEFT	JOIN	AreaToISOCountryMapping a
ON		a.AreaCode = p.AreaCode
LEFT	JOIN	OfficeToISOCountryMapping o
ON		o.BeazleyOfficeLocation = p.BeazleyOfficeLocation
WHERE	SectionReference IS NOT NULL
GROUP	BY ISNULL(AgressoSectionReference,SectionReference)
		,CASE WHEN SourceSystem = 'BeazleyPro' THEN 'US' WHEN SourceSystem IS NULL THEN 'GB' ELSE o.ISOCountryCode END
		,a.ISOCountryCode
		,OriginalCurrencyCode
		,ISNULL(o.ISOCountryCode, 'Unknown') 
		,ISNULL(a.ISOCountryCode, 'Unknown')


