﻿
CREATE VIEW [dbo].[vw_PostingExceptions]
AS
SELECT AccountCode, 'Value2' Exception, ccy.EntityCode, ccy.FunctionalCurrency
FROM dimaccount 
cross join (select EntityCode,FunctionalCurrency FROM DimEntity WHERE FunctionalCurrency IN ('AUD', 'GBP')) ccy  
where ExcludeFromFXCalcs = 'Y' OR AccountCode in ('75700','75710')
UNION ALL
SELECT AccountCode, 'Amount',ccy.EntityCode, ccy.FunctionalCurrency  from dimaccount 
CROSS JOIN (select EntityCode,FunctionalCurrency FROM DimEntity WHERE FunctionalCurrency = 'USD') ccy
where ExcludeFromFXCalcs = 'Y' OR AccountCode in ('75700','75710')
UNION ALL
SELECT AccountCode, 'Amount', ccy.EntityCode, ccy.FunctionalCurrency 
FROM DimAccount 
cross join (select EntityCode,FunctionalCurrency FROM DimEntity WHERE FunctionalCurrency IN ('AUD', 'GBP')) ccy 
WHERE aCCOUNTcODE IN ('64100', '64200') OR AccountCode like '9%'
