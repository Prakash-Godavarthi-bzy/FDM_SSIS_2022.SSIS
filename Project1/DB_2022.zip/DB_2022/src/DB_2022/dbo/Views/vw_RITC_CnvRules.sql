﻿


CREATE VIEW [dbo].[vw_RITC_CnvRules] 
AS
SELECT DISTINCT 'BadDebt IBNR' AS [CnvRule], DT.[TrifocusCode] , 'USD' AS [CnvCurreny] FROM [DimTrifocus] DT
UNION ALL
SELECT DISTINCT 'CHP Split UK' AS [CnvRule], DT.[TrifocusCode] , 'GBP' AS [CnvCurreny] FROM [DimTrifocus] DT WHERE DT.[TrifocusGroup] <> 'BICI'
UNION ALL
SELECT DISTINCT 'CHP Split US' AS [CnvRule], DT.[TrifocusCode] , 'USD' AS [CnvCurreny] FROM [DimTrifocus] DT WHERE DT.[TrifocusGroup] = 'BICI'
