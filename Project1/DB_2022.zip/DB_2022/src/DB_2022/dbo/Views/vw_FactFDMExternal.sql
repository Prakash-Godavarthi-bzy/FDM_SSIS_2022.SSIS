﻿CREATE VIEW [dbo].[vw_FactFDMExternal]
AS 

	SELECT pk_FactFDMExternal,fk_Account,fk_AccountingPeriod,fk_BusinessPlan,fk_ClaimExposure,fk_DataStage
		 , fk_Entity,fk_Expense,fk_Holding,fk_LloydsClassifications,fk_Office,fk_OriginalCurrency,fk_PolicySection,fk_Process,fk_Product
		 , fk_Project,fk_RIPolicy,fk_Scenario,fk_SourceSystem,fk_TriFocus,fk_YOA,fk_Client,bk_TransactionID,[Description],ExtRef,ExtInvRef
		 , ap_ar_id,ap_ar_type,Dim1,Dim2,Dim3,Dim4,Dim5,Dim6,Dim7,VoucherNumber,[Value],cur_amount,currency,value_1,value_2,value_3,fk_User
		 , insert_date,insert_time,voucher_date,transaction_date,tax_code,tax_system,fk_Special,fk_ClassofBusiness,fk_DimEarnings
		 , fk_TargetEntity,fk_TargetPeriod,fk_PolicySectionV2,RunProcessLogID
	  FROM dbo.FactFDMExternal_Current
	 UNION ALL
	SELECT pk_FactFDMExternal,fk_Account,fk_AccountingPeriod,fk_BusinessPlan,fk_ClaimExposure,fk_DataStage
		 , fk_Entity,fk_Expense,fk_Holding,fk_LloydsClassifications,fk_Office,fk_OriginalCurrency,fk_PolicySection,fk_Process,fk_Product
		 , fk_Project,fk_RIPolicy,fk_Scenario,fk_SourceSystem,fk_TriFocus,fk_YOA,fk_Client,bk_TransactionID,[Description],ExtRef,ExtInvRef
		 , ap_ar_id,ap_ar_type,Dim1,Dim2,Dim3,Dim4,Dim5,Dim6,Dim7,VoucherNumber,[Value],cur_amount,currency,value_1,value_2,value_3,fk_User
		 , insert_date,insert_time,voucher_date,transaction_date,tax_code,tax_system,fk_Special,fk_ClassofBusiness,fk_DimEarnings
		 , fk_TargetEntity,fk_TargetPeriod,fk_PolicySectionV2,RunProcessLogID 
	  FROM dbo.FactFDMExternal_History
