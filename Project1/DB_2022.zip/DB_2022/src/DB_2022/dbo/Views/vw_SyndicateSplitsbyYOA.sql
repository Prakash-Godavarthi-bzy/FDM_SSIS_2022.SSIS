﻿


CREATE VIEW [dbo].[vw_SyndicateSplitsbyYOA]
AS
/****************************************************************************************************************************************
** Name			: [dbo].[vw_SyndicateSplitsbyYOA]
** Description	: View to get Syndicate splits by YOA for splitting Syndicate 1174, 623 and 2623 into 623 and 2623
** Author		: GuptR
** Version
*****************************************************************************************************************************************
Version No	Date			Author		Description
1.0			25-Jan-2016		GuptR		Original Version
****************************************************************************************************************************************/
SELECT 
		  MY.[SourceSyndicate]
		, DY.[YOAName]
		, MY.[Syndicate]
		, MY.[AllocationPercentage]
FROM
(
		SELECT CAST('623' AS nvarchar) AS [SourceSyndicate], CAST('1993' AS nvarchar) AS [YOAFrom], CAST('2011' AS nvarchar) AS [YOATo], CAST('623' AS nvarchar) AS [Syndicate], 0.19 AS [AllocationPercentage]
		UNION
		SELECT CAST('623' AS nvarchar) AS [SourceSyndicate], CAST('1993' AS nvarchar) AS [YOAFrom], CAST('2011' AS nvarchar) AS [YOATo], CAST('2623' AS nvarchar) AS [Syndicate], 0.81 AS [AllocationPercentage]
		UNION
		SELECT CAST('2623' AS nvarchar) AS [SourceSyndicate], CAST('1993' AS nvarchar) AS [YOAFrom], CAST('2011' AS nvarchar) AS [YOATo], CAST('623' AS nvarchar) AS [Syndicate], 0.19 AS [AllocationPercentage]
		UNION
		SELECT CAST('2623' AS nvarchar) AS [SourceSyndicate], CAST('1993' AS nvarchar) AS [YOAFrom], CAST('2011' AS nvarchar) AS [YOATo], CAST('2623' AS nvarchar) AS [Syndicate], 0.81 AS [AllocationPercentage]
		UNION
		SELECT CAST('1174' AS nvarchar) AS [SourceSyndicate], CAST('1993' AS nvarchar) AS [YOAFrom], CAST('2011' AS nvarchar) AS [YOATo], CAST('623' AS nvarchar) AS [Syndicate], 0.19 AS [AllocationPercentage]
		UNION
		SELECT CAST('1174' AS nvarchar) AS [SourceSyndicate], CAST('1993' AS nvarchar) AS [YOAFrom], CAST('2011' AS nvarchar) AS [YOATo], CAST('2623' AS nvarchar) AS [Syndicate], 0.81 AS [AllocationPercentage]
		-- From 2012-2022 YOA
		UNION
		SELECT CAST('623' AS nvarchar) AS [SourceSyndicate], CAST('2012' AS nvarchar) AS [YOAFrom], CAST('2022' AS nvarchar) AS [YOATo], CAST('623' AS nvarchar) AS [Syndicate], 0.18 AS [AllocationPercentage]
		UNION
		SELECT CAST('623' AS nvarchar) AS [SourceSyndicate], CAST('2012' AS nvarchar) AS [YOAFrom], CAST('2022' AS nvarchar) AS [YOATo], CAST('2623' AS nvarchar) AS [Syndicate], 0.82 AS [AllocationPercentage]
		UNION
		SELECT CAST('2623' AS nvarchar) AS [SourceSyndicate], CAST('2012' AS nvarchar) AS [YOAFrom], CAST('2022' AS nvarchar) AS [YOATo], CAST('623' AS nvarchar) AS [Syndicate], 0.18 AS [AllocationPercentage]
		UNION
		SELECT CAST('2623' AS nvarchar) AS [SourceSyndicate], CAST('2012' AS nvarchar) AS [YOAFrom], CAST('2022' AS nvarchar) AS [YOATo], CAST('2623' AS nvarchar) AS [Syndicate], 0.82 AS [AllocationPercentage]
		UNION
		SELECT CAST('1174' AS nvarchar) AS [SourceSyndicate], CAST('2012' AS nvarchar) AS [YOAFrom], CAST('2022' AS nvarchar) AS [YOATo], CAST('623' AS nvarchar) AS [Syndicate], 0.18 AS [AllocationPercentage]
		UNION
		SELECT CAST('1174' AS nvarchar) AS [SourceSyndicate], CAST('2012' AS nvarchar) AS [YOAFrom], CAST('2022' AS nvarchar) AS [YOATo], CAST('2623' AS nvarchar) AS [Syndicate], 0.82 AS [AllocationPercentage]
        -- From 2023-2023 YOA(FIN-7191)
		UNION
		SELECT CAST('623' AS nvarchar) AS [SourceSyndicate], CAST('2023' AS nvarchar) AS [YOAFrom], CAST('2023' AS nvarchar) AS [YOATo], CAST('623' AS nvarchar) AS [Syndicate], 0.1779 AS [AllocationPercentage]
		UNION
		SELECT CAST('623' AS nvarchar) AS [SourceSyndicate], CAST('2023' AS nvarchar) AS [YOAFrom], CAST('2023' AS nvarchar) AS [YOATo], CAST('2623' AS nvarchar) AS [Syndicate], 0.8221 AS [AllocationPercentage]
		UNION
		SELECT CAST('2623' AS nvarchar) AS [SourceSyndicate], CAST('2023' AS nvarchar) AS [YOAFrom], CAST('2023' AS nvarchar) AS [YOATo], CAST('623' AS nvarchar) AS [Syndicate], 0.1779 AS [AllocationPercentage]
		UNION
		SELECT CAST('2623' AS nvarchar) AS [SourceSyndicate], CAST('2023' AS nvarchar) AS [YOAFrom], CAST('2023' AS nvarchar) AS [YOATo], CAST('2623' AS nvarchar) AS [Syndicate], 0.8221 AS [AllocationPercentage]
		UNION
		SELECT CAST('1174' AS nvarchar) AS [SourceSyndicate], CAST('2023' AS nvarchar) AS [YOAFrom], CAST('2023' AS nvarchar) AS [YOATo], CAST('623' AS nvarchar) AS [Syndicate], 0.1779 AS [AllocationPercentage]
		UNION
		SELECT CAST('1174' AS nvarchar) AS [SourceSyndicate], CAST('2023' AS nvarchar) AS [YOAFrom], CAST('2023' AS nvarchar) AS [YOATo], CAST('2623' AS nvarchar) AS [Syndicate], 0.8221 AS [AllocationPercentage]
		-- From 2024 YOA (FIN-11628)(Modified date: 12-03-2024)(Modified by : Sruthi Pitchikala)
		UNION 
		SELECT CAST('623' AS nvarchar) AS [SourceSyndicate], CAST('2024' AS nvarchar) AS [YOAFrom], CAST('2024' AS nvarchar) AS [YOATo], CAST('623' AS nvarchar) AS [Syndicate], 0.28 AS [AllocationPercentage]
		UNION
		SELECT CAST('623' AS nvarchar) AS [SourceSyndicate], CAST('2024' AS nvarchar) AS [YOAFrom], CAST('2024' AS nvarchar) AS [YOATo], CAST('2623' AS nvarchar) AS [Syndicate], 0.72 AS [AllocationPercentage]
		UNION
		SELECT CAST('2623' AS nvarchar) AS [SourceSyndicate], CAST('2024' AS nvarchar) AS [YOAFrom], CAST('2024' AS nvarchar) AS [YOATo], CAST('623' AS nvarchar) AS [Syndicate], 0.28 AS [AllocationPercentage]
		UNION
		SELECT CAST('2623' AS nvarchar) AS [SourceSyndicate], CAST('2024' AS nvarchar) AS [YOAFrom], CAST('2024' AS nvarchar) AS [YOATo], CAST('2623' AS nvarchar) AS [Syndicate], 0.72 AS [AllocationPercentage]
		UNION
		SELECT CAST('1174' AS nvarchar) AS [SourceSyndicate], CAST('2024' AS nvarchar) AS [YOAFrom], CAST('2024' AS nvarchar) AS [YOATo], CAST('623' AS nvarchar) AS [Syndicate], 0.28 AS [AllocationPercentage]
		UNION
		SELECT CAST('1174' AS nvarchar) AS [SourceSyndicate], CAST('2024' AS nvarchar) AS [YOAFrom], CAST('2024' AS nvarchar) AS [YOATo], CAST('2623' AS nvarchar) AS [Syndicate], 0.72 AS [AllocationPercentage]
		-- From 2025-9999 YOA
		UNION
		SELECT CAST('623' AS nvarchar) AS [SourceSyndicate], CAST('2025' AS nvarchar) AS [YOAFrom], CAST('9999' AS nvarchar) AS [YOATo], CAST('623' AS nvarchar) AS [Syndicate], 0.18 AS [AllocationPercentage]
		UNION
		SELECT CAST('623' AS nvarchar) AS [SourceSyndicate], CAST('2025' AS nvarchar) AS [YOAFrom], CAST('9999' AS nvarchar) AS [YOATo], CAST('2623' AS nvarchar) AS [Syndicate], 0.82 AS [AllocationPercentage]
		UNION
		SELECT CAST('2623' AS nvarchar) AS [SourceSyndicate], CAST('2025' AS nvarchar) AS [YOAFrom], CAST('9999' AS nvarchar) AS [YOATo], CAST('623' AS nvarchar) AS [Syndicate], 0.18 AS [AllocationPercentage]
		UNION
		SELECT CAST('2623' AS nvarchar) AS [SourceSyndicate], CAST('2025' AS nvarchar) AS [YOAFrom], CAST('9999' AS nvarchar) AS [YOATo], CAST('2623' AS nvarchar) AS [Syndicate], 0.82 AS [AllocationPercentage]
		UNION
		SELECT CAST('1174' AS nvarchar) AS [SourceSyndicate], CAST('2025' AS nvarchar) AS [YOAFrom], CAST('9999' AS nvarchar) AS [YOATo], CAST('623' AS nvarchar) AS [Syndicate], 0.18 AS [AllocationPercentage]
		UNION
		SELECT CAST('1174' AS nvarchar) AS [SourceSyndicate], CAST('2025' AS nvarchar) AS [YOAFrom], CAST('9999' AS nvarchar) AS [YOATo], CAST('2623' AS nvarchar) AS [Syndicate], 0.82 AS [AllocationPercentage]
) MY
INNER JOIN	
		[dbo].[DimYOA] DY
	ON	DY.[YOAName] BETWEEN MY.[YOAFrom] AND MY.[YOATo]
