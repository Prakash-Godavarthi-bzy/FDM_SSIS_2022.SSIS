﻿
CREATE View [dbo].[InvCombinedDelta] as
SELECT 
	client = cast('BP' as nvarchar(255))	
	,f.bk_Holding 
	,f.AccountPeriod
	,Scenario = 1
	,DataStage = 1
	,f.GL_Code
	,Entity = f.Entity
	,TriFocus = 'Z140'
	,f.CurrencyRpt
	,[Quantity] = cast(f.[Quantity] - d.[Quantity]  as decimal(28,3))
	,[Unit_Solvency_II_price] = cast(f.[Unit_Solvency_II_price] -d.[Unit_Solvency_II_price] as decimal(28,3))
	,[Acquisition_Price] = cast(f.[Acquisition_Price] -d.[Acquisition_Price] as decimal(28,3))
	,[Total_Solvency_II_Amount] = cast(f.[Total_Solvency_II_Amount] - d.[Total_Solvency_II_Amount] as decimal(28,3))
	,[Accrued_Interest] = cast(f.[Accrued_Interest] - d.[Accrued_Interest] as decimal(28,3))
	,[Market_Value_Non_FIS] = cast(f.[Market_Value_Non_FIS] - d.[Market_Value_Non_FIS] as decimal(28,3))
	,[Market_Value_FIS] = cast(f.[Market_Value_FIS] - d.[Market_Value_FIS] as decimal(28,3))
	,[mod_dur] = cast(f.[mod_dur] - d.[mod_dur] as decimal(28,3))
	,[Realized_Price] = cast(f.[Realized_Price] - d.[Realized_Price] as decimal(28,3))
	,[Unrealized_Price] = cast(f.[Unrealized_Price] - d.[Unrealized_Price] as decimal(28,3))
	,[Realized_FX] = cast(f.[Realized_FX] - d.[Realized_FX] as decimal(28,3))
	,[Unrealized_FX] = cast(f.[Unrealized_FX] - d.[Unrealized_FX] as decimal(28,3))
	,[Realized_Income] = cast(f.[Realized_Income] - d.[Realized_Income] as decimal(28,3))
	,[Unrealized_Income] = cast(f.[Unrealized_Income] - d.[Unrealized_Income] as decimal(28,3))
	,[Misc_Rev_Exp] = cast(f.[Misc_Rev_Exp] - d.[Misc_Rev_Exp] as decimal(28,3))
,Inv020 = cast(1 as decimal(28,3))
FROM
	[dbo].[InvCombinedDraft] d join
	[dbo].[InvCombinedFinal] f on d.bk_Holding = f.bk_Holding and d.AccountPeriod = f.AccountPeriod
