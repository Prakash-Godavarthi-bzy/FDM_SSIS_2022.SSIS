﻿

CREATE	VIEW DimSourceInceptionExpiry AS 
SELECT	pk_FactFDMExternal AS LinkID,
		ISNULL(Dim5,SectionReference) AS [SectionReference], 
		ISNULL(voucher_date,InceptionDate) AS [InceptionDate], 
		ISNULL(transaction_date,ExpiryDate) AS [ExpiryDate]
FROM	vw_FactFDMExternal
JOIN	DimPolicySection 
ON		pk_PolicySection = fk_PolicySection
WHERE	fk_PolicySection <> -1
UNION	ALL
SELECT	10000000000 + (-1* pk_FACTAllocations)  AS LinkID,
		ISNULL(f.SectionReference,p.SectionReference) AS [SectionReference], 
		ISNULL(voucher_date,InceptionDate) AS [InceptionDate], 
		ISNULL(transaction_date,ExpiryDate) AS [ExpiryDate]
FROM	VW_FACTAllocationV1_Total f
JOIN	DimPolicySection p
ON		pk_PolicySection = fk_PolicySection
WHERE	fk_PolicySection <> -1
UNION	ALL
SELECT	pk_FactFDM  AS LinkID,
		ISNULL(f.Dim5,p.SectionReference) AS [SectionReference], 
		ISNULL(voucher_date,InceptionDate) AS [InceptionDate], 
		ISNULL(transaction_date,ExpiryDate) AS [ExpiryDate]
FROM	FactFDM f
JOIN	DimPolicySection p
ON		pk_PolicySection = fk_PolicySection
WHERE	fk_PolicySection <> -1
AND		fk_AccountingPeriod >= 201300 
