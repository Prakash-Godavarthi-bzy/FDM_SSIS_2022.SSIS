﻿



CREATE	VIEW [dbo].[vw_SIILOBMappingV1]
AS 
SELECT	DISTINCT e.Entity
		,e.EntityGroup
		,TrifocusCode
		,TrifocusName
		,m.[Chanel ] AS Channel
		,m.LoB
		,c.SIIClass
FROM	SIILOBMappingV1 m
JOIN	SIIEntityGroups e ON m.Entity = EntityGroup
LEFT	JOIN	SIIClass c 
ON		c.LoB = m.lob
AND		c.Channel = m.[Chanel ]
--WHERE	e.Entity = 'BRQS' 

