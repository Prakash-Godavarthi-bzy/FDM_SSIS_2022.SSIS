﻿CREATE VIEW [dbo].[vw_DimTransactionDetailsV1]
	AS 
	SELECT pk_FactFDM , bk_TransactionID , [Description] , ExtRef , ExtInvRef
		 , Dim1 , Dim2 , Dim3 , Dim4 , Dim5 , Dim6 , Dim7
		 , VoucherNumber , insert_date , ap_ar_id , ap_ar_type , tax_code , tax_system
		 , AccountCode , ProcessCode , AccountingPeriod	 , CombinationID , MCVoucherNumber , transaction_date 
	  FROM dbo.DimTransactionDetailsV1_Current
	UNION ALL
	SELECT pk_FactFDM , bk_TransactionID , [Description] , ExtRef , ExtInvRef
		 , Dim1 , Dim2 , Dim3 , Dim4 , Dim5 , Dim6 , Dim7
		 , VoucherNumber , insert_date , ap_ar_id , ap_ar_type , tax_code , tax_system
		 , AccountCode , ProcessCode , AccountingPeriod	 , CombinationID , MCVoucherNumber , transaction_date  
	  FROM dbo.DimTransactionDetailsV1_History