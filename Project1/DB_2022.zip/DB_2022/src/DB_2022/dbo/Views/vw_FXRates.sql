﻿

CREATE VIEW [dbo].[vw_FXRates]

AS
SELECT     dbo.DimAccountingPeriod.AccountingPeriod, dbo.DimFXRate.FXRateName, dbo.DimReportingCurrency.ReportingCurrencyCode, 
                      dbo.DimTransactionCurrency.pk_TransactionCurrency AS TransactionCurrencyCode, dbo.DimRateScenario.RateName, dbo.FactFXRate.FXRate
FROM         dbo.DimRateScenario INNER JOIN
                      dbo.DimFXRate INNER JOIN
                      dbo.DimAccountingPeriod INNER JOIN
                      dbo.FactFXRate ON dbo.DimAccountingPeriod.pk_AccountingPeriod = dbo.FactFXRate.fk_AccountingPeriod ON 
                      dbo.DimFXRate.pk_FXRate = dbo.FactFXRate.fk_FXRate INNER JOIN
                      dbo.DimTransactionCurrency ON dbo.FactFXRate.fk_TransactionCurrency = dbo.DimTransactionCurrency.pk_TransactionCurrency INNER JOIN
                      dbo.DimReportingCurrency ON dbo.FactFXRate.fk_ReportingCurrency = dbo.DimReportingCurrency.pk_ReportingCurrency ON 
                      dbo.DimRateScenario.pk_RateScenario = dbo.FactFXRate.fk_RateScenario
