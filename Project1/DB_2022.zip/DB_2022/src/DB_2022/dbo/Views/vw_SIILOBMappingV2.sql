﻿


CREATE	VIEW [dbo].[vw_SIILOBMappingV2]
AS 
SELECT	DISTINCT Entity
		,m.Entity AS EntityGroup
		,TrifocusCode
		,TrifocusName
		,[Chanel ] AS Channel
		,LoB
FROM	SIILOBMappingV1 m

--WHERE EntityGroup = 'synd' 
