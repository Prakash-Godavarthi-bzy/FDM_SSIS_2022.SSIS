﻿CREATE	VIEW [dbo].[vw_ClientScenarioEntityMapping]
AS 
SELECT	client AS ClientCode 
		,entity_fx AS EntityCode,
		'BP' AS ScenarioCode ,
		'Actual' AS Scenario
		FROM [$(staging_agresso)].[dbo].[afxclientent]
UNION
SELECT	ScenarioCode AS clientCode
		,CAST(EntityCode AS VARCHAR(25)) AS entity_fx
		,ScenarioCode AS ScenarioCode
		,FriendlyName AS Scenario
FROM	DimEntity
CROSS	APPLY DIMSCENARIO
WHERE	ScenarioCode <> 'NA'
AND		FriendlyName IS NOT NULL
AND		pk_Entity <> -1
GO
