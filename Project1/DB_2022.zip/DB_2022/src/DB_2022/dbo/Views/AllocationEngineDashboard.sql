﻿
----TRUNCATE TABLE [FDM_DB].[dbo].[AllocationEngineLog]
--/****** Script for SelectTopNRows command from SSMS  ******/
--SELECT *
--  FROM [FDM_DB].[dbo].[AllocationEngineLog]
--  ORDER BY ExecutionID

  CREATE VIEW [dbo].[AllocationEngineDashboard] 
  AS 

	SELECT c.[AllocationCode]
		  ,[BridgeStartTime]
		  ,[BridgeEndTime]
		  ,[AllocationStartTime]
		  ,[AllocationEndTime]
		  ,[CubeStartTime]
		  ,[CubeEndTime]
		  ,[BridgeCount]
		  ,[ReAllocationCount]
		  ,[AllocationCount]
		  ,[AccountingPeriod]
		  ,c.[AllocationGroup]
		  ,[AllocationGroupVersion]
		  ,[StartID]
		  ,c.[UserID] AS ImportedBY
		  ,a.UserID AS RunBy
		  ,c.InsertDate
		  ,[BatchID]
		  ,[Status]
		  ,ExecutionID
  FROM	  (SELECT	DISTINCT AllocationGroup
				,AllocationGroupCodeVersion
				,AllocationCode
				,UserID
				,InsertDate
		FROM	DimAllocationRules) c
  JOIN	  [dbo].[AllocationEngineLog] a On c.AllocationGroup = a.AllocationGroup AND AllocationGroupCodeVersion = AllocationGroupVersion AND c.AllocationCode = a.AllocationCode
