﻿CREATE TABLE [dbo].[SIIHomeCountryMapping] (
    [Entity]      NVARCHAR (255) NULL,
    [HomeCountry] NVARCHAR (255) NULL
);

