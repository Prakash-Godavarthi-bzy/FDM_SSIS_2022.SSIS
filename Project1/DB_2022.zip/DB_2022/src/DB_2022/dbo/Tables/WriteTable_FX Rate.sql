﻿CREATE TABLE [dbo].[WriteTable_FX Rate] (
    [FXRate_0]                 FLOAT (53)     NULL,
    [pk_TransactionCurrency_1] NVARCHAR (25)  NULL,
    [pk_AccountingPeriod_2]    INT            NULL,
    [pk_FXRate_3]              INT            NULL,
    [pk_ReportingCurrency_4]   INT            NULL,
    [pk_RateScenario_5]        INT            NULL,
    [MS_AUDIT_TIME_6]          DATETIME       NULL,
    [MS_AUDIT_USER_7]          NVARCHAR (255) NULL
);

