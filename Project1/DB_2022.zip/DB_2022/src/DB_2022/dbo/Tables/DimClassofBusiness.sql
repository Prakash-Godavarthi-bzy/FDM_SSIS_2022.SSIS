﻿CREATE TABLE [dbo].[DimClassofBusiness] (
    [pk_ClassofBusiness]  INT            IDENTITY (1, 1) NOT NULL,
    [ClassofBusinessCode] NVARCHAR (255) NULL,
    [ClassofBusinessName] NVARCHAR (255) NULL,
    CONSTRAINT [PK_DimClassofBusiness] PRIMARY KEY CLUSTERED ([pk_ClassofBusiness] ASC) WITH (FILLFACTOR = 90)
);

