﻿CREATE TABLE [dbo].[SIIAccountAllocationBasis] (
    [SIIType]                          NVARCHAR (255) NULL,
    [AgressoAccountCategory]           NVARCHAR (255) NULL,
    [AgressoAccountCategoryToAllocate] NVARCHAR (255) NULL
);

