﻿CREATE TABLE [dbo].[DimTransactionDetails] (
    [pk_FactFDM]       BIGINT         NOT NULL,
    [bk_TransactionID] BIGINT         NULL,
    [Description]      NVARCHAR (255) NULL,
    [ExtRef]           NVARCHAR (255) NULL,
    [ExtInvRef]        NVARCHAR (255) NULL,
    [Dim1]             NVARCHAR (255) NULL,
    [Dim2]             NVARCHAR (255) NULL,
    [Dim3]             NVARCHAR (255) NULL,
    [Dim4]             NVARCHAR (255) NULL,
    [Dim5]             NVARCHAR (255) NULL,
    [Dim6]             NVARCHAR (255) NULL,
    [Dim7]             NVARCHAR (255) NULL,
    [VoucherNumber]    NVARCHAR (255) NULL,
    [insert_date]      DATE           NULL,
    [ap_ar_id]         NVARCHAR (255) NULL,
    [ap_ar_type]       NVARCHAR (255) NULL,
    [tax_code]         VARCHAR (25)   NULL,
    [tax_system]       VARCHAR (25)   NULL
);


GO
CREATE NONCLUSTERED INDEX [nlidx_DimTransactionDetails_bk_TransactionID]
    ON [dbo].[DimTransactionDetails]([bk_TransactionID] ASC) WITH (FILLFACTOR = 90);

