﻿CREATE TABLE [dbo].[DimState] (
    [StateCode] NVARCHAR (255) NULL,
    [StateDesc] NVARCHAR (255) NULL
);

