﻿CREATE TABLE [dbo].[FactFDMExternal_Current] (
    [pk_FactFDMExternal]       BIGINT          IDENTITY (-1, -1) NOT NULL,
    [fk_Account]               INT             NOT NULL,
    [fk_AccountingPeriod]      INT             NOT NULL,
    [fk_BusinessPlan]          INT             NOT NULL,
    [fk_ClaimExposure]         BIGINT          NOT NULL,
    [fk_DataStage]             INT             NOT NULL,
    [fk_Entity]                INT             NOT NULL,
    [fk_Expense]               INT             NOT NULL,
    [fk_Holding]               INT             NOT NULL,
    [fk_LloydsClassifications] INT             NOT NULL,
    [fk_Office]                INT             NOT NULL,
    [fk_OriginalCurrency]      INT             NOT NULL,
    [fk_PolicySection]         BIGINT          NOT NULL,
    [fk_Process]               INT             NOT NULL,
    [fk_Product]               INT             NOT NULL,
    [fk_Project]               INT             NOT NULL,
    [fk_RIPolicy]              BIGINT          NOT NULL,
    [fk_Scenario]              INT             NOT NULL,
    [fk_SourceSystem]          INT             NOT NULL,
    [fk_TriFocus]              INT             NOT NULL,
    [fk_YOA]                   INT             NOT NULL,
    [fk_Client]                INT             NOT NULL,
    [bk_TransactionID]         BIGINT          NOT NULL,
    [Description]              NVARCHAR (255)  NULL,
    [ExtRef]                   NVARCHAR (255)  NULL,
    [ExtInvRef]                NVARCHAR (255)  NULL,
    [ap_ar_id]                 NVARCHAR (255)  NULL,
    [ap_ar_type]               NVARCHAR (255)  NULL,
    [Dim1]                     NVARCHAR (255)  NULL,
    [Dim2]                     NVARCHAR (255)  NULL,
    [Dim3]                     NVARCHAR (255)  NULL,
    [Dim4]                     NVARCHAR (255)  NULL,
    [Dim5]                     NVARCHAR (255)  NULL,
    [Dim6]                     NVARCHAR (255)  NULL,
    [Dim7]                     NVARCHAR (255)  NULL,
    [VoucherNumber]            NVARCHAR (255)  NULL,
    [Value]                    NUMERIC (18, 4) NOT NULL,
    [cur_amount]               DECIMAL (28, 3) NULL,
    [currency]                 NVARCHAR (25)   NULL,
    [value_1]                  DECIMAL (28, 3) NULL,
    [value_2]                  DECIMAL (28, 3) NULL,
    [value_3]                  DECIMAL (28, 3) NULL,
    [fk_User]                  INT             NULL,
    [insert_date]              DATE            NULL,
    [insert_time]              TIME (7)        NULL,
    [voucher_date]             DATE            NULL,
    [transaction_date]         DATE            NULL,
    [tax_code]                 VARCHAR (25)    NULL,
    [tax_system]               VARCHAR (25)    NULL,
    [fk_Special]               INT             CONSTRAINT [DF__FactFDMExCu__fk_sp__43D61337] DEFAULT ((-1)) NOT NULL,
    [fk_ClassofBusiness]       INT             CONSTRAINT [DF__FactFDMExCu__fk_Cl__45BE5BA9] DEFAULT ((-1)) NOT NULL,
    [fk_DimEarnings]           BIGINT          NULL,
    [fk_TargetEntity]          INT             NULL,
    [fk_TargetPeriod]          INT             NULL,
    [fk_PolicySectionV2]       BIGINT          NULL,
	[RunProcessLogID]		   INT			   CONSTRAINT [DF_FactFDMExt_Curr_RPLogId]  DEFAULT -1 NULL	,		
    CONSTRAINT [PK_FactFDMExternal_Current] PRIMARY KEY CLUSTERED ([pk_FactFDMExternal] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [fk_FactFDMExternal_CurrentAccount_FK1] FOREIGN KEY ([fk_Account]) REFERENCES [dbo].[DimAccount] ([pk_Account]),
    CONSTRAINT [fk_FactFDMExternal_CurrentAccountingPeriod_FK1] FOREIGN KEY ([fk_AccountingPeriod]) REFERENCES [dbo].[DimAccountingPeriod] ([pk_AccountingPeriod]),
    CONSTRAINT [fk_FactFDMExternal_CurrentBusinessPlan_FK1] FOREIGN KEY ([fk_BusinessPlan]) REFERENCES [dbo].[DimBusinessPlan] ([pk_BusinessPlan]),
    CONSTRAINT [fk_FactFDMExternal_CurrentClaimExposure_FK1] FOREIGN KEY ([fk_ClaimExposure]) REFERENCES [dbo].[DimClaimExposure] ([pk_ClaimExposure]),
    CONSTRAINT [fk_FactFDMExternal_CurrentClassofBusiness_FK1] FOREIGN KEY ([fk_ClassofBusiness]) REFERENCES [dbo].[DimClassofBusiness] ([pk_ClassofBusiness]),
    CONSTRAINT [fk_FactFDMExternal_CurrentClient_FK1] FOREIGN KEY ([fk_Client]) REFERENCES [dbo].[DimClient] ([pk_Client]),
    CONSTRAINT [fk_FactFDMExternal_CurrentCURRENCY_FK1] FOREIGN KEY ([currency]) REFERENCES [dbo].[DimTransactionCurrency] ([pk_TransactionCurrency]),
    CONSTRAINT [fk_FactFDMExternal_CurrentDataStage_FK1] FOREIGN KEY ([fk_DataStage]) REFERENCES [dbo].[DimDataStage] ([pk_DataStage]),
    CONSTRAINT [fk_FactFDMExternal_CurrentEntity_FK1] FOREIGN KEY ([fk_Entity]) REFERENCES [dbo].[DimEntity] ([pk_Entity]),
    CONSTRAINT [fk_FactFDMExternal_CurrentExpense_FK1] FOREIGN KEY ([fk_Expense]) REFERENCES [dbo].[DimExpense] ([pk_Expense]),
    CONSTRAINT [fk_FactFDMExternal_CurrentInvestment_FK1] FOREIGN KEY ([fk_Holding]) REFERENCES [dbo].[DimHolding] ([pk_Holding]),
    CONSTRAINT [fk_FactFDMExternal_CurrentLloydsClassifications] FOREIGN KEY ([fk_LloydsClassifications]) REFERENCES [dbo].[DimLloydsClassifications] ([pk_LloydsClassifications]),
    CONSTRAINT [fk_FactFDMExternal_CurrentOffice_FK1] FOREIGN KEY ([fk_Office]) REFERENCES [dbo].[DimOffice] ([pk_Office]),
    CONSTRAINT [fk_FactFDMExternal_CurrentPolicySection_FK1] FOREIGN KEY ([fk_PolicySection]) REFERENCES [dbo].[DimPolicySection] ([pk_PolicySection]),
    CONSTRAINT [fk_FactFDMExternal_CurrentProcess_FK1] FOREIGN KEY ([fk_Process]) REFERENCES [dbo].[DimProcess] ([pk_Process]),
    CONSTRAINT [fk_FactFDMExternal_CurrentProduct_FK1] FOREIGN KEY ([fk_Product]) REFERENCES [dbo].[DimProduct] ([pk_Product]),
    CONSTRAINT [fk_FactFDMExternal_CurrentProject_FK1] FOREIGN KEY ([fk_Project]) REFERENCES [dbo].[DimProject] ([pk_Project]),
    CONSTRAINT [fk_FactFDMExternal_CurrentRIPolicy_FK1] FOREIGN KEY ([fk_RIPolicy]) REFERENCES [dbo].[DimRIPolicy] ([pk_RIPolicy]),
    CONSTRAINT [fk_FactFDMExternal_CurrentScenario_FK1] FOREIGN KEY ([fk_Scenario]) REFERENCES [dbo].[DimScenario] ([pk_Scenario]),
    CONSTRAINT [fk_FactFDMExternal_CurrentSourceSystem_FK1] FOREIGN KEY ([fk_SourceSystem]) REFERENCES [dbo].[DimSourceSystem] ([pk_SourceSystem]),
    CONSTRAINT [fk_FactFDMExternal_CurrentSpecial_FK1] FOREIGN KEY ([fk_Special]) REFERENCES [dbo].[DimSpecial] ([pk_Special]),
    CONSTRAINT [fk_FactFDMExternal_CurrentTriFocus_FK1] FOREIGN KEY ([fk_TriFocus]) REFERENCES [dbo].[DimTrifocus] ([pk_Trifocus]),
    CONSTRAINT [fk_FactFDMExternal_CurrentUser_FK1] FOREIGN KEY ([fk_User]) REFERENCES [dbo].[DimUser] ([pk_User]),
    CONSTRAINT [fk_FactFDMExternal_CurrentYOA_FK1] FOREIGN KEY ([fk_YOA]) REFERENCES [dbo].[DimYOA] ([pk_YOA])
);


GO
CREATE NONCLUSTERED INDEX [Ind_FactFDMExternal_Current_AccountingPeriod]
    ON [dbo].[FactFDMExternal_Current]([fk_AccountingPeriod] ASC)
    INCLUDE([fk_Account], [fk_Entity], [fk_TriFocus], [fk_YOA], [cur_amount], [currency], [fk_Special], [fk_ClassofBusiness]) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [nlx_FactFDMExternal_Current_fk_PolicySection_Dim5]
    ON [dbo].[FactFDMExternal_Current]([fk_PolicySection] ASC)
    INCLUDE([Dim5]) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [nlx_FactFDMExternal_Current_fk_PolicySection_transaction_date]
    ON [dbo].[FactFDMExternal_Current]([fk_PolicySection] ASC)
    INCLUDE([transaction_date]) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [nlx_FactFDMExternal_Current_fk_PolicySection_voucher_date]
    ON [dbo].[FactFDMExternal_Current]([fk_PolicySection] ASC)
    INCLUDE([voucher_date]) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [nlx_FactFDMExternal_Current_fk_PolicySection_cvr]
    ON [dbo].[FactFDMExternal_Current]([fk_PolicySection] ASC)
    INCLUDE([pk_FactFDMExternal], [Dim5], [voucher_date], [transaction_date]) WITH (FILLFACTOR = 90);


