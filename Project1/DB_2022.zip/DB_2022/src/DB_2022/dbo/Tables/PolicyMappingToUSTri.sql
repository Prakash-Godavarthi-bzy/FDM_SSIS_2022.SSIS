﻿CREATE TABLE [dbo].[PolicyMappingToUSTri] (
    [SectionReference] NVARCHAR (255) NULL,
    [TrifocusCode]     NVARCHAR (255) NULL
);

