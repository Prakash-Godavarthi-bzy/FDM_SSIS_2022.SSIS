﻿CREATE TABLE [dbo].[WriteTable_Premium Phasing Pattern] (
    [Pattern_0]                FLOAT (53)     NULL,
    [Pattern_1]                FLOAT (53)     NULL,
    [Pattern_2]                FLOAT (53)     NULL,
    [Department_3]             NVARCHAR (255) NULL,
    [pk_InceptionMonth_4]      INT            NULL,
    [pk_PolicyType_5]          NVARCHAR (255) NULL,
    [pk_ReviewCycle_6]         NVARCHAR (255) NULL,
    [pk_TriFocus_7]            NVARCHAR (255) NULL,
    [pk_YOA_8]                 INT            NULL,
    [pk_TransactionCurrency_9] NVARCHAR (25)  NULL,
    [MS_AUDIT_TIME_10]         DATETIME       NULL,
    [MS_AUDIT_USER_11]         NVARCHAR (255) NULL
);

