﻿CREATE TABLE [dbo].[AreaToISOCountryMapping] (
    [AreaCode]       NVARCHAR (255) NULL,
    [ISOCountry]     NVARCHAR (255) NULL,
    [ISOCountryCode] NVARCHAR (255) NULL
);

