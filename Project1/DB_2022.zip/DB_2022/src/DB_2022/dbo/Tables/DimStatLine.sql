﻿CREATE TABLE [dbo].[DimStatLine] (
    [ProductCode]  NVARCHAR (25)  NULL,
    [State]        NVARCHAR (25)  NULL,
    [ScheduleCode] NVARCHAR (25)  NULL,
    [ScheduleName] NVARCHAR (255) NULL,
    [StatLineCode] NVARCHAR (25)  NULL,
    [StatLineName] NVARCHAR (255) NULL, 
    [SubLineCode] NVARCHAR(25) NULL, 
    [SubLineName] NVARCHAR(255) NULL
);

