﻿CREATE TABLE [dbo].[DimProduct] (
    [pk_Product]      INT            IDENTITY (1, 1) NOT NULL,
    [ProductCode]     NVARCHAR (255) NULL,
    [ProductName]     NVARCHAR (255) NULL,
    [ProductCategory] NVARCHAR (255) NULL,
    CONSTRAINT [PK__DimProdu__27FD48F27DE278A1] PRIMARY KEY CLUSTERED ([pk_Product] ASC) WITH (FILLFACTOR = 90)
);

