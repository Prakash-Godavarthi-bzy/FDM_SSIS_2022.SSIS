﻿CREATE TABLE [dbo].[DimTrifocusTree] (
    [pkDimTrifocusTree]       NVARCHAR (255) NOT NULL,
    [Description]             NVARCHAR (255) NULL,
    [pkDimTrifocusTreeParent] NVARCHAR (255) NULL,
    [SortOrder]               INT            NULL,
    CONSTRAINT [PK__DimTrifo__31A1FB215EA49A73] PRIMARY KEY CLUSTERED ([pkDimTrifocusTree] ASC) WITH (FILLFACTOR = 90)
);

