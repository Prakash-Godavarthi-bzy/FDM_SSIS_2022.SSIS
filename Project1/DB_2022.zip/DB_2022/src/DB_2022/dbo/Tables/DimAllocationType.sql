﻿CREATE TABLE [dbo].[DimAllocationType] (
    [pk_AllocationType] INT           NOT NULL,
    [AllocationType]    NVARCHAR (50) NULL,
    CONSTRAINT [PK__DimAlloc__475029530F98FB76] PRIMARY KEY CLUSTERED ([pk_AllocationType] ASC) WITH (FILLFACTOR = 90)
);

