﻿CREATE TABLE [dbo].[EurobaseEPIAdjustmentVersions] (
    [fk_AccountingPeriod] INT      NOT NULL,
    [ImportDataTime]      DATETIME NULL,
    [SourceTimestamp]     DATETIME NULL
);

