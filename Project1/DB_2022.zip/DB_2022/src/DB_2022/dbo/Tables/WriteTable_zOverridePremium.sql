﻿CREATE TABLE [dbo].[WriteTable_zOverridePremium] (
    [OverridePremium_0] FLOAT (53)     NULL,
    [pk_ReviewCycle_1]  NVARCHAR (255) NULL,
    [pk_TriFocus_2]     NVARCHAR (255) NULL,
    [pk_YOA_3]          INT            NULL,
    [MS_AUDIT_TIME_4]   DATETIME       NULL,
    [MS_AUDIT_USER_5]   NVARCHAR (255) NULL
);

