﻿CREATE TABLE [dbo].[briProductProductTree] (
    [pkDimProductTree]    NVARCHAR (255) NOT NULL,
    [pk_Product]          INT            NOT NULL,
    [pk_AccountingPeriod] INT            NULL,
    CONSTRAINT [PK_briProductProductTree] PRIMARY KEY CLUSTERED ([pkDimProductTree] ASC, [pk_Product] ASC) WITH (FILLFACTOR = 90)
);

