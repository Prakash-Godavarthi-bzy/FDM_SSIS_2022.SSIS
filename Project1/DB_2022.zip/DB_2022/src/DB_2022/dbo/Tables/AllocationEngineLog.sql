﻿CREATE TABLE [dbo].[AllocationEngineLog] (
    [ExecutionID]            INT           IDENTITY (1, 1) NOT NULL,
    [AllocationCode]         VARCHAR (255) NOT NULL,
    [BridgeStartTime]        VARCHAR (50)  NOT NULL,
    [BridgeEndTime]          VARCHAR (50)  NULL,
    [AllocationStartTime]    VARCHAR (50)  NULL,
    [AllocationEndTime]      VARCHAR (50)  NULL,
    [CubeStartTime]          VARCHAR (50)  NULL,
    [CubeEndTime]            VARCHAR (50)  NULL,
    [BridgeCount]            INT           NULL,
    [ReAllocationCount]      INT           NULL,
    [AllocationCount]        INT           NULL,
    [AccountingPeriod]       INT           NULL,
    [AllocationGroup]        VARCHAR (255) NULL,
    [AllocationGroupVersion] VARCHAR (10)  NULL,
    [StartID]                BIGINT        NULL,
    [UserID]                 VARCHAR (255) NULL,
    [BatchID]                INT           NULL,
    [Status]                 VARCHAR (50)  NULL
);

