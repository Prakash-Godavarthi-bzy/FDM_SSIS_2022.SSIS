﻿CREATE TABLE [dbo].[SIITagetikReportingCountry] (
    [SIIType]                     NVARCHAR (255) NULL,
    [EntityReportingType]         NVARCHAR (255) NULL,
    [TagetikReportingCountry]     NVARCHAR (255) NULL,
    [TagetikReportingCountryCode] NVARCHAR (255) NULL,
    [LifeEntity]                  BIT            NULL
);

