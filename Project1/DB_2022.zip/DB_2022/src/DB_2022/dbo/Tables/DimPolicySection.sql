﻿CREATE TABLE [dbo].[DimPolicySection] (
    [pk_PolicySection]      BIGINT         IDENTITY (1, 1) NOT NULL,
    [ValidFrom]             DATE           NULL,
    [ValidTo]               DATE           NULL,
    [CurrentKey]            BIGINT         NULL,
    [PreviousKey]           BIGINT         NULL,
    [PolicyReference]       NVARCHAR (255) NULL,
    [SectionReference]      NVARCHAR (255) NULL,
    [UniqueMarketReference] NVARCHAR (255) NULL,
    [PolicyLink]            NVARCHAR (255) NULL,
    [ProgramIndicator]      NVARCHAR (255) NULL,
    [NewRenewalIndicator]   NVARCHAR (255) NULL,
    [PolicyType]            NVARCHAR (255) NULL,
    [BinderType]            NVARCHAR (255) NULL,
    [WrittenSignedStatus]   NVARCHAR (255) NULL,
    [PolicyStatus]          NVARCHAR (255) NULL,
    [UnderwriterIdentifier] NVARCHAR (255) NULL,
    [Underwritername]       NVARCHAR (255) NULL,
    [AccountName]           NVARCHAR (300) NULL,
    [ReinsuredName]         NVARCHAR (300) NULL,
    [CoInsuredName]         NVARCHAR (300) NULL,
    [CoverholderName]       NVARCHAR (300) NULL,
    [LeadInsurerName]       NVARCHAR (300) NULL,
    [ProducingBrokerName]   NVARCHAR (255) NULL,
    [PlacingBrokername]     NVARCHAR (255) NULL,
    [BeazleyCOB]            NVARCHAR (255) NULL,
    [ProductCode]           NVARCHAR (255) NULL,
    [StatsCode]             NVARCHAR (255) NULL,
    [Perils]                NVARCHAR (255) NULL,
    [MOP]                   NVARCHAR (255) NULL,
    [QuoteOrBindDate]       DATE           NULL,
    [InceptionDate]         DATE           NULL,
    [ExpiryDate]            DATE           NULL,
    [BeazleyLed]            BIT            NULL,
    [LocationOfInsured]     NVARCHAR (255) NULL,
    [LocationPremiumPaid]   NVARCHAR (255) NULL,
    [LocationOfRisk]        NVARCHAR (255) NULL,
    [UWProductCode]         NVARCHAR (10)  NULL,
    [PolicyYOA]             INT            NULL,
    [OriginalCurrency]      NVARCHAR (255) NULL,
    [USPolicy]              SMALLINT       CONSTRAINT [DF__DimPolicy__USPol__51BA1E3A] DEFAULT ((0)) NULL,
    CONSTRAINT [PK__DimPolic__7E0F0676EDE8272E] PRIMARY KEY CLUSTERED ([pk_PolicySection] ASC) WITH (FILLFACTOR = 90)
);


GO
CREATE NONCLUSTERED INDEX [_dta_index_DimPolicySection_6_661577395__K7_K3_2_6_8_9_10_11_12_13_15_16_17_18_19_21_23_24_25_26_27_28_29_30_31_32_33]
    ON [dbo].[DimPolicySection]([SectionReference] ASC, [ValidTo] ASC)
    INCLUDE([PolicyReference], [ValidFrom], [UniqueMarketReference], [PolicyLink], [ProgramIndicator], [NewRenewalIndicator], [PolicyType], [BinderType], [PolicyStatus], [UnderwriterIdentifier], [Underwritername], [AccountName], [ReinsuredName], [CoverholderName], [ProducingBrokerName], [PlacingBrokername], [BeazleyCOB], [ProductCode], [StatsCode], [Perils], [MOP], [QuoteOrBindDate], [InceptionDate], [ExpiryDate], [BeazleyLed]) WITH (FILLFACTOR = 90);

