﻿CREATE TABLE [dbo].[RITCJournals] (
    [pk_RITCJournal] INT            NOT NULL,
    [JournalDetails] NVARCHAR (255) NULL,
    [ProcessCode]    NVARCHAR (255) NULL,
    PRIMARY KEY CLUSTERED ([pk_RITCJournal] ASC) WITH (FILLFACTOR = 90)
);

