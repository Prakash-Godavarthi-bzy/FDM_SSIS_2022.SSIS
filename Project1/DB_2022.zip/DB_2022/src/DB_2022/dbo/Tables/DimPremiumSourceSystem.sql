﻿CREATE TABLE [dbo].[DimPremiumSourceSystem] (
    [pk_PremiumSourceSystem]     INT            IDENTITY (1, 1) NOT NULL,
    [PremiumSourceSystemName]    NVARCHAR (255) NULL,
    [DefaultPremiumSourceSystem] BIT            NULL
);

