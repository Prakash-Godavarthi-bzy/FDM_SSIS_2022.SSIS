﻿CREATE TABLE [dbo].[AllocationPercentages] (
    [LOB]                    NVARCHAR (255)  NULL,
    [Channel]                NVARCHAR (255)  NULL,
    [AgressoAccountCategory] NVARCHAR (255)  NULL,
    [SIIType]                NVARCHAR (255)  NULL,
    [ReportingCountry]       NVARCHAR (255)  NULL,
    [EntityAllocationGroup]  NVARCHAR (255)  NULL,
    [Basis]                  NVARCHAR (255)  NULL,
    [cur_amount]             DECIMAL (38, 3) NULL,
    [TOTALcur_amount]        DECIMAL (38, 3) NULL,
    [Value]                  NUMERIC (38, 4) NULL,
    [TotalValue]             NUMERIC (38, 4) NULL,
    [UnderwritingLocation]   NVARCHAR (255)  NULL,
    [LocationOfRisk]         NVARCHAR (255)  NULL
);

