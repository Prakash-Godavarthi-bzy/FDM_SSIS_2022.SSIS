﻿CREATE TABLE [dbo].[FactAllocation] (
    [fk_AllocationType]  INT             NOT NULL,
    [fk_Entity]          INT             NOT NULL,
    [fk_TriFocus]        INT             NOT NULL,
    [fk_YOAGroup]        INT             NOT NULL,
    [AllocationValue]    DECIMAL (28, 8) NULL,
    [fk_YOA]             INT             NULL,
    [fk_Trifocus_Source] INT             NOT NULL,
    [fk_Account]         INT             NOT NULL
);

