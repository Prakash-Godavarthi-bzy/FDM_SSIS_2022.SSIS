﻿CREATE TABLE [dbo].[ExternalFeedConfig] (
    [ExternalFeedID] INT           IDENTITY (1, 1) NOT NULL,
    [Folder]         VARCHAR (255) NOT NULL,
    [NameFormat]     VARCHAR (255) NOT NULL,
    [PackageName]    VARCHAR (255) NOT NULL,
    [IsEnabled]      BIT           NOT NULL,
    [ProcessType]    VARCHAR (255) NOT NULL
);

