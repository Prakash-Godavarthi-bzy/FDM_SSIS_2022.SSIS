﻿CREATE TABLE [dbo].[DimAccount] (
    [pk_Account]         INT            NOT NULL,
    [AccountCode]        NVARCHAR (255) NULL,
    [AccountName]        NVARCHAR (255) NULL,
    [AccountGroup]       NVARCHAR (255) NULL,
    [AccountIsMoney]     NCHAR (1)      NULL,
    [AccountIsSnapshot]  NCHAR (1)      NULL,
    [FormatString]       NVARCHAR (255) NULL,
    [MDX]                NVARCHAR (500) NULL,
    [ExcludeFromFXCalcs] NVARCHAR (1)   NULL,
    [Status]             NVARCHAR (10)  NULL,
    CONSTRAINT [PK__DimAccou__D2BD265CBDBD6110] PRIMARY KEY CLUSTERED ([pk_Account] ASC) WITH (FILLFACTOR = 90)
);

