﻿CREATE TABLE [dbo].[DimReportingCurrency] (
    [pk_ReportingCurrency]  INT            IDENTITY (1, 1) NOT NULL,
    [ReportingCurrencyCode] NVARCHAR (255) NULL,
    [ReportingCurrencyName] NVARCHAR (255) NULL,
    CONSTRAINT [PK__DimRepor__DF512414B13A5217] PRIMARY KEY CLUSTERED ([pk_ReportingCurrency] ASC) WITH (FILLFACTOR = 90)
);

