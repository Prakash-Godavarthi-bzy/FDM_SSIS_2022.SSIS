CREATE TABLE [dbo].[BIDACContractChangeStage](
	[AccountingPeriod] [varchar](50) NULL,
	[YOA] [int] NULL,
	[GroupCurrencyAmount] [numeric](38, 10) NULL,
	[Synd_Profit] [numeric](38, 10) NULL,
	[BRQS_PandL] [numeric](38, 9) NULL,
	[BRQS_BS] [numeric](38, 9) NULL,
	[BRQS_BS_Output] [numeric](38, 9) NULL,
	[BRQS_PandL_Output] [numeric](38, 9) NULL,
	[LTDSyndicateLoss] [varchar](14) NOT NULL
) ON [PRIMARY]
GO


