﻿CREATE TABLE [dbo].[DimOffice] (
    [pk_Office]     INT            IDENTITY (1, 1) NOT NULL,
    [OfficeCode]    NVARCHAR (255) NULL,
    [OfficeName]    NVARCHAR (255) NULL,
    [OfficeCity]    NVARCHAR (255) NULL,
    [OfficeCountry] NVARCHAR (255) NULL,
    CONSTRAINT [PK__DimOffic__D9F9C9909A35FDB8] PRIMARY KEY CLUSTERED ([pk_Office] ASC) WITH (FILLFACTOR = 90)
);

