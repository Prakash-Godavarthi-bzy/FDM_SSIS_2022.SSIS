﻿CREATE TABLE [dbo].[WriteTable_zFact Dept To RI] (
    [IsLink_0]         INT            NULL,
    [pk_RIProgramme_1] INT            NULL,
    [Department_2]     NVARCHAR (255) NULL,
    [MS_AUDIT_TIME_3]  DATETIME       NULL,
    [MS_AUDIT_USER_4]  NVARCHAR (255) NULL
);

