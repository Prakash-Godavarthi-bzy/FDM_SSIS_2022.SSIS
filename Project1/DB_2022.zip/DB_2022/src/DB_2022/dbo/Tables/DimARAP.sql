﻿CREATE TABLE [dbo].[DimARAP] (
    [pk_Arap]    INT            IDENTITY (1, 1) NOT NULL,
    [ap_ar_id]   NVARCHAR (255) NOT NULL,
    [ap_ar_type] NVARCHAR (255) NOT NULL,
    [ap_ar_name] NVARCHAR (255) NOT NULL,
    CONSTRAINT [PK_DimARAP_pk_Arap] PRIMARY KEY CLUSTERED ([pk_Arap] ASC) WITH (FILLFACTOR = 90)
);

