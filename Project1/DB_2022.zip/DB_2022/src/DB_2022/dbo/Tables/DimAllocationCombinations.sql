﻿CREATE TABLE [dbo].[DimAllocationCombinations] (
    [CombinationID] INT            IDENTITY (1, 1) NOT NULL,
    [AccountCode]   NVARCHAR (255) NULL,
    [ProcessCode]   NVARCHAR (255) NULL,
    [TriFocusCode]  NVARCHAR (255) NULL,
    [EntityCode]    NVARCHAR (255) NULL,
    [LocationCode]  NVARCHAR (255) NULL,
    [ProjectCode]   NVARCHAR (255) NULL,
    [YOA]           NVARCHAR (255) NULL,
    [TargetEntity]  NVARCHAR (255) NULL
);


GO
CREATE UNIQUE CLUSTERED INDEX [clx_comID_DimAllocationCombinations]
    ON [dbo].[DimAllocationCombinations]([CombinationID] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [nlx_DimAllocationCombinations_AccCode_CVR]
    ON [dbo].[DimAllocationCombinations]([AccountCode] ASC)
    INCLUDE([CombinationID], [ProcessCode], [TriFocusCode], [EntityCode], [LocationCode], [ProjectCode], [YOA]) WITH (FILLFACTOR = 90);

