﻿CREATE TABLE [dbo].[PremiumRealisationBridge] (
    [SectionReference]        NVARCHAR (255) NULL,
    [AgressoSectionReference] NVARCHAR (255) NULL,
    [PolicyReference]         NVARCHAR (255) NULL,
    [BinderReference]         NVARCHAR (255) NULL,
    [pk_PolicySection]        BIGINT         NULL,
    [PremiumScenario]         VARCHAR (9)    NULL,
    [pk_PremiumView]          SMALLINT       NULL
);

