﻿CREATE TABLE [dbo].[TrifocusMapping] (
    [pk_TrifocustMappingID] INT            IDENTITY (1, 1) NOT NULL,
    [SourceSystem]          NVARCHAR (255) NOT NULL,
    [SourceSystemTrifocus]  NVARCHAR (255) NULL,
    [FDMTrifocusCode]       NVARCHAR (255) NOT NULL,
    CONSTRAINT [PK__Trifocus__4F87D066A93015C5] PRIMARY KEY CLUSTERED ([pk_TrifocustMappingID] ASC) WITH (FILLFACTOR = 90)
);

