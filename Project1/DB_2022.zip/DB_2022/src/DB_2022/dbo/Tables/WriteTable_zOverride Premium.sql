﻿CREATE TABLE [dbo].[WriteTable_zOverride Premium] (
    [OverridePremium_0] FLOAT (53)     NULL,
    [pk_ReviewCycle_1]  NVARCHAR (255) NULL,
    [pk_YOA_2]          INT            NULL,
    [pk_TriFocus_3]     NVARCHAR (255) NULL,
    [MS_AUDIT_TIME_4]   DATETIME       NULL,
    [MS_AUDIT_USER_5]   NVARCHAR (255) NULL
);

