﻿CREATE TABLE [dbo].[SIIS0201To0202Mapping] (
    [Signage]             NVARCHAR (255) NULL,
    [S0201SIIField]       NVARCHAR (255) NULL,
    [S0201TagetikAccount] NVARCHAR (255) NULL,
    [S0202SIIField]       NVARCHAR (255) NULL,
    [S0202TagetikAccount] NVARCHAR (255) NULL,
    [EntityCode]          NVARCHAR (255) NULL,
    [EntityGroup]         NVARCHAR (255) NULL,
    [EntityReportingType] NVARCHAR (255) NULL
);

