﻿CREATE TABLE [dbo].[WriteTable_01 Premium] (
    [GNP_0]                    FLOAT (53)     NULL,
    [UserID_1]                 NVARCHAR (255) NULL,
    [Department_2]             NVARCHAR (255) NULL,
    [pk_OfficeChannel_3]       NVARCHAR (255) NULL,
    [pk_InceptionMonth_4]      INT            NULL,
    [pk_PolicyType_5]          NVARCHAR (255) NULL,
    [pk_ReviewCycle_6]         NVARCHAR (255) NULL,
    [pk_TriFocus_7]            NVARCHAR (255) NULL,
    [pk_YOA_8]                 INT            NULL,
    [pk_TransactionCurrency_9] NVARCHAR (25)  NULL,
    [pk_InsertDate_10]         NVARCHAR (255) NULL,
    [MS_AUDIT_TIME_11]         DATETIME       NULL,
    [MS_AUDIT_USER_12]         NVARCHAR (255) NULL
);

