﻿CREATE TABLE [dbo].[SIILOBMapping] (
    [Trifocus]               NVARCHAR (255) NULL,
    [Channel]                NVARCHAR (255) NULL,
    [SIILOB-2623/623/3623]   NVARCHAR (255) NULL,
    [SIILOB-6107]            NVARCHAR (255) NULL,
    [SIILOB-3622]            NVARCHAR (255) NULL,
    [SIILOB-6050]            NVARCHAR (255) NULL,
    [SIILOB-BERE&BRQS]       NVARCHAR (255) NULL,
    [SIILOB-ConsolidatedPlc] NVARCHAR (255) NULL
);

