﻿CREATE TABLE [dbo].[Policymasterfile] (
    [PolicyReference]  NVARCHAR (255) NULL,
    [SectionReference] NVARCHAR (255) NULL,
    [MOPCode]          NVARCHAR (255) NULL,
    [UWPlatform]       NVARCHAR (255) NULL,
	[PolicyDescription] NVARCHAR(255) NULL
);

