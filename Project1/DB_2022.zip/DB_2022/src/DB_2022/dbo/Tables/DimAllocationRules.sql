﻿CREATE TABLE [dbo].[DimAllocationRules] (
    [PK_AllocationRules]         INT             IDENTITY (1, 1) NOT NULL,
    [AllocationGroupId]          INT             NULL,
    [AllocationGroup]            NVARCHAR (50)   NULL,
    [AllocationUser]             NVARCHAR (50)   NULL,
    [AllocationCode]             NVARCHAR (50)   NULL,
    [AllocationGroupCodeVersion] INT             NULL,
    [StepCode]                   NVARCHAR (4)    NULL,
    [AccountFrom]                NVARCHAR (50)   NULL,
    [AccountTo]                  NVARCHAR (50)   NULL,
    [TrifocusFrom]               NVARCHAR (50)   NULL,
    [TrifocusTo]                 NVARCHAR (50)   NULL,
    [EntityFrom]                 NVARCHAR (50)   NULL,
    [EntityTo]                   NVARCHAR (50)   NULL,
    [LocationFrom]               NVARCHAR (50)   NULL,
    [LocationTo]                 NVARCHAR (50)   NULL,
    [ProjectFrom]                NVARCHAR (50)   NULL,
    [ProjectTo]                  NVARCHAR (50)   NULL,
    [YOAFrom]                    NVARCHAR (50)   NULL,
    [YOATo]                      NVARCHAR (50)   NULL,
    [ProcessFrom]                NVARCHAR (50)   NULL,
    [ProcessTo]                  NVARCHAR (50)   NULL,
    [AccountDest]                NVARCHAR (50)   NULL,
    [TrifocusDest]               NVARCHAR (50)   NULL,
    [EntityDest]                 NVARCHAR (50)   NULL,
    [LocationDest]               NVARCHAR (50)   NULL,
    [ProjectDest]                NVARCHAR (50)   NULL,
    [YOADest]                    NVARCHAR (50)   NULL,
    [ProcessDest]                NVARCHAR (50)   NULL,
    [AllocationPercent]          DECIMAL (28, 8) NOT NULL,
    [IsCurrent]                  INT             NOT NULL,
    [RunOrder]                   INT             NULL,
    [InsertDate]                 DATETIME        CONSTRAINT [DF__tmp_ms_xx__Inser__314D4EA8] DEFAULT (getdate()) NOT NULL,
    [TargetEntityFrom]           NVARCHAR (50)   NULL,
    [TargetEntityTo]             NVARCHAR (50)   NULL,
    [TargetEntityDest]           NVARCHAR (50)   NULL,
    [GranularityFlag]            INT             NULL,
    [BatchID]                    INT             NULL,
    [UserID]                     NVARCHAR (255)  NULL,
    [TargetPeriodDest]           NVARCHAR (50)   NULL,
    [TargetCurrencyDest]         NVARCHAR (50)   NULL,    
    [AllocationType]             NVARCHAR (50)   NULL,
	[ChangeType]				 VARCHAR (50)		 ,
	[PK_Alt_AllocationRules]	 INT				 ,
	[AllocationGroupCodeSubVersion] INT				 ,
	[RowHash]					 VARBINARY (255)
    CONSTRAINT [PK_AllocationRules] PRIMARY KEY CLUSTERED ([PK_AllocationRules] ASC) WITH (FILLFACTOR = 90)
);


GO
CREATE NONCLUSTERED INDEX [nlx_AllocationRules_AllCode_IsCur_cvr]
    ON [dbo].[DimAllocationRules]([AllocationCode] ASC, [IsCurrent] ASC)
    INCLUDE([PK_AllocationRules], [AllocationGroup], [AllocationGroupCodeVersion], [StepCode], [AccountFrom], [AccountTo], [TrifocusFrom], [TrifocusTo], [EntityFrom], [EntityTo], [LocationFrom], [LocationTo], [ProjectFrom], [ProjectTo], [YOAFrom], [YOATo], [ProcessFrom], [ProcessTo], [AccountDest], [TrifocusDest], [EntityDest], [LocationDest], [ProjectDest], [YOADest], [ProcessDest], [AllocationPercent]) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [nlx_AllocationRules_AllocationGroup_cvr]
    ON [dbo].[DimAllocationRules]([AllocationGroup] ASC)
    INCLUDE([AllocationCode]) WITH (FILLFACTOR = 90);

