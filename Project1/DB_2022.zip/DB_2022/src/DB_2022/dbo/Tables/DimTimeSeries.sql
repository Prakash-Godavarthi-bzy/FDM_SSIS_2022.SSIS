﻿CREATE TABLE [dbo].[DimTimeSeries] (
    [pk_TimeSeries]  INT            IDENTITY (1, 1) NOT NULL,
    [TimeSeriesName] NVARCHAR (255) NULL,
    CONSTRAINT [PK__DimTimeS__41F846F59498A168] PRIMARY KEY CLUSTERED ([pk_TimeSeries] ASC) WITH (FILLFACTOR = 90)
);

