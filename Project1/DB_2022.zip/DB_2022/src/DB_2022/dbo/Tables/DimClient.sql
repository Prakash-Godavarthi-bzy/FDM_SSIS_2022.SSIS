﻿CREATE TABLE [dbo].[DimClient] (
    [pk_Client]     INT            IDENTITY (1, 1) NOT NULL,
    [ClientCode]    NVARCHAR (255) NULL,
    [ClientName]    NVARCHAR (255) NULL,
    [ClientType]    NVARCHAR (255) NULL,
    [SortOrder]     INT            NULL,
    [CurrentPeriod] INT            NULL,
    CONSTRAINT [PK__DimCli__BD742F16D926BA1A] PRIMARY KEY CLUSTERED ([pk_Client] ASC) WITH (FILLFACTOR = 90)
);

