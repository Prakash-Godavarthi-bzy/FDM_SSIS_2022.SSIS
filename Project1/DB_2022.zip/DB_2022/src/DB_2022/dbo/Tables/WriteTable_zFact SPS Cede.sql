﻿CREATE TABLE [dbo].[WriteTable_zFact SPS Cede] (
    [SPSCedePercent_0] FLOAT (53)     NULL,
    [pk_Entity_1]      NVARCHAR (255) NULL,
    [pk_Host_2]        NVARCHAR (255) NULL,
    [pk_YOA_3]         INT            NULL,
    [pk_TriFocus_4]    NVARCHAR (255) NULL,
    [MS_AUDIT_TIME_5]  DATETIME       NULL,
    [MS_AUDIT_USER_6]  NVARCHAR (255) NULL
);

