﻿CREATE TABLE [dbo].[OverseasandASLConfig] (
    [OverseasASLConfigId] INT           IDENTITY (1, 1) NOT NULL,
    [Syndicate]           FLOAT (53)    NULL,
    [GL]                  FLOAT (53)    NULL,
    [Description]         VARCHAR (255) NULL,
    [Currency]            VARCHAR (255) NULL,
    [TAB Number]          FLOAT (53)    NULL,
    [Notes]               VARCHAR (255) NULL,
    [DepositType]         VARCHAR (255) NULL
);

