﻿CREATE TABLE [dbo].[WriteTable_02 External Commission] (
    [EC_0]               FLOAT (53)     NULL,
    [pk_PolicyType_1]    NVARCHAR (255) NULL,
    [pk_ReviewCycle_2]   NVARCHAR (255) NULL,
    [pk_YOA_3]           INT            NULL,
    [pk_TriFocus_4]      NVARCHAR (255) NULL,
    [pk_OfficeChannel_5] NVARCHAR (255) NULL,
    [UserID_6]           NVARCHAR (255) NULL,
    [pk_InsertDate_7]    NVARCHAR (255) NULL,
    [Department_8]       NVARCHAR (255) NULL,
    [MS_AUDIT_TIME_9]    DATETIME       NULL,
    [MS_AUDIT_USER_10]   NVARCHAR (255) NULL
);

