﻿CREATE TABLE [dbo].[DimUser] (
    [pk_User]     INT            IDENTITY (1, 1) NOT NULL,
    [ValidFrom]   DATE           NULL,
    [ValidTo]     DATE           NULL,
    [CurrentKey]  INT            NULL,
    [PreviousKey] INT            NULL,
    [UserID]      NVARCHAR (255) NOT NULL,
    [UserName]    NVARCHAR (255) NULL,
    CONSTRAINT [PK__DimUser__FB956BDBF3337056] PRIMARY KEY CLUSTERED ([pk_User] ASC) WITH (FILLFACTOR = 90)
);

