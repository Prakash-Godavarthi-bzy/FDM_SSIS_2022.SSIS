﻿CREATE TABLE [dbo].[DimSpecial] (
    [pk_Special]       INT            IDENTITY (1, 1) NOT NULL,
    [SpecialCode]      NVARCHAR (255) NULL,
    [SpecialName]      NVARCHAR (255) NULL,
    [SpecialGroupName] NVARCHAR (255) NULL,
    CONSTRAINT [PK_DimSpecial] PRIMARY KEY CLUSTERED ([pk_Special] ASC) WITH (FILLFACTOR = 90)
);

