﻿CREATE TABLE [dbo].[BriPolicyMappings] (
    [FK_PolicySectionV2] BIGINT NOT NULL,
    [FK_YOA]             INT    NOT NULL,
    [Fk_TriFocus]        INT    NOT NULL,
    [FK_DimEarnings]     BIGINT NOT NULL
);

