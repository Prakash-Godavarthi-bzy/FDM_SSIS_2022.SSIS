﻿CREATE TABLE [dbo].[DimAccountingPeriodStatus] (
    [pk_AccountingPeriodStatus] INT           NOT NULL,
    [AccountingPeriodStatus]    NVARCHAR (50) NULL,
    CONSTRAINT [PK__DimAccou__33A3DDC850F25297] PRIMARY KEY CLUSTERED ([pk_AccountingPeriodStatus] ASC) WITH (FILLFACTOR = 90)
);

