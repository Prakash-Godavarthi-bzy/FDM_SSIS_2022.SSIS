﻿CREATE TABLE [dbo].[SIIS0202CurrencyAllocationBasis] (
    [TPDataSet]      NVARCHAR (255) NULL,
    [SIIMappingType] NVARCHAR (255) NULL,
    [SIIClassType]   NVARCHAR (255) NULL,
    [S0202SIIField]  NVARCHAR (255) NULL,
    [S0201SIIField]  NVARCHAR (255) NULL
);

