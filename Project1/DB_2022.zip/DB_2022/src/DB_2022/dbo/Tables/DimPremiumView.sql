﻿CREATE TABLE [dbo].[DimPremiumView] (
    [pk_PremiumView] SMALLINT      IDENTITY (1, 1) NOT NULL,
    [PremiumView]    VARCHAR (255) NOT NULL
);

