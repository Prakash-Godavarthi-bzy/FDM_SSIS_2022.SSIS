﻿CREATE TABLE [dbo].[SIIClass] (
    [Channel]  NVARCHAR (255) NULL,
    [LoB]      NVARCHAR (255) NULL,
    [SIIClass] INT            NULL
);

