﻿CREATE TABLE [dbo].[WriteTable_zFact Current Review Cycle] (
    [CurrentCycle_0]   FLOAT (53)     NULL,
    [pk_ReviewCycle_1] NVARCHAR (255) NULL,
    [MS_AUDIT_TIME_2]  DATETIME       NULL,
    [MS_AUDIT_USER_3]  NVARCHAR (255) NULL
);

