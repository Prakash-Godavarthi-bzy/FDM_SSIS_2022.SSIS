﻿CREATE TABLE [dbo].[DimDataStage] (
    [pk_DataStage]  INT            NOT NULL,
    [DataStageName] NVARCHAR (255) NULL,
    CONSTRAINT [PK__DimDataS__13FA731AB7D38719] PRIMARY KEY CLUSTERED ([pk_DataStage] ASC) WITH (FILLFACTOR = 90)
);

