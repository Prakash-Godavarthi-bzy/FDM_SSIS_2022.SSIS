﻿CREATE TABLE [dbo].[FACTAllocationsV1_History] (
    [pk_FACTAllocations]       BIGINT           NOT NULL,
    [pk_tempFactFDM]           BIGINT           NULL,
    [Source_pk_tempFactFDM]    BIGINT           NULL,
    [fk_Account]               INT              NULL,
    [fk_AccountingPeriod]      INT              NULL,
    [fk_BusinessPlan]          INT              NULL,
    [fk_ClaimExposure]         BIGINT           NULL,
    [fk_DataStage]             INT              NULL,
    [fk_Entity]                INT              NULL,
    [fk_Expense]               INT              NULL,
    [fk_Holding]               INT              NULL,
    [fk_LloydsClassifications] INT              NULL,
    [fk_Office]                INT              NULL,
    [fk_OriginalCurrency]      INT              NULL,
    [fk_PolicySection]         BIGINT           NULL,
    [SectionReference]         NVARCHAR (255)   NULL,
    [fk_Process]               INT              NULL,
    [fk_Product]               INT              NULL,
    [fk_Project]               INT              NULL,
    [fk_RIPolicy]              BIGINT           NULL,
    [fk_Scenario]              INT              NULL,
    [fk_SourceSystem]          INT              NULL,
    [fk_TriFocus]              INT              NULL,
    [fk_YOA]                   INT              NULL,
    [fk_Client]                INT              NULL,
    [bk_TransactionID]         BIGINT           NULL,
    [VoucherNumber]            NVARCHAR (255)   NULL,
    [Value]                    NUMERIC (35, 10) NULL,
    [cur_amount]               NUMERIC (35, 10) NULL,
    [currency]                 NVARCHAR (25)    NULL,
    [value_1]                  NUMERIC (35, 10) NULL,
    [value_2]                  NUMERIC (35, 10) NULL,
    [value_3]                  NUMERIC (35, 10) NULL,
    [fk_User]                  INT              NULL,
    [insert_date]              DATE             NULL,
    [insert_time]              TIME (7)         NULL,
    [voucher_date]             DATE             NULL,
    [transaction_date]         DATE             NULL,
    [tax_code]                 VARCHAR (25)     NULL,
    [tax_system]               VARCHAR (25)     NULL,
    [fk_Location]              INT              NULL,
    [fk_InceptionDate]         INT              NULL,
    [fk_ExpiryDate]            INT              NULL,
    [CombinationID]            INT              NULL,
    [FK_AllocationRules]       INT              NULL,
    [AllocationPercent]        NUMERIC (28, 8)  NULL,
    [AccountDest]              NVARCHAR (255)   NULL,
    [LocationDest]             NVARCHAR (255)   NULL,
    [EntityDest]               NVARCHAR (255)   NULL,
    [YOADest]                  NVARCHAR (255)   NULL,
    [ProcessDest]              NVARCHAR (255)   NULL,
    [ProjectDest]              NVARCHAR (255)   NULL,
    [TriFocusDest]             NVARCHAR (255)   NULL,
    [RuleApplicable]           INT              NULL,
    [AllocationCOde]           VARCHAR (25)     NULL,
    [fk_DimEarnings]           BIGINT           NULL,
    [fk_TargetEntity]          INT              NULL,
    [fk_TargetPeriod]          INT              NULL,
    [fk_PolicySectionV2]       BIGINT           NULL,
    [TargetCurrencyDest]       NVARCHAR (255)   NULL,
    [BatchID]                  INT              NULL,
    [gl_AccountingPeriod]      INT              NULL,
    [SoftDeleteFlag]           INT              CONSTRAINT [DF__FACTAlloc__SoftD__0E6E26BF_History] DEFAULT ((0)) NULL,
    CONSTRAINT [PK_FACTAllocationsV1_History] PRIMARY KEY CLUSTERED ([pk_FACTAllocations] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [fk_FACTAllocationsV1_History_Account_FK1] FOREIGN KEY ([fk_Account]) REFERENCES [dbo].[DimAccount] ([pk_Account]),
    CONSTRAINT [fk_FACTAllocationsV1_History_AccountingPeriod_FK1] FOREIGN KEY ([fk_AccountingPeriod]) REFERENCES [dbo].[DimAccountingPeriod] ([pk_AccountingPeriod]),
    CONSTRAINT [fk_FACTAllocationsV1_History_AllocationRules_FK1] FOREIGN KEY ([FK_AllocationRules]) REFERENCES [dbo].[DimAllocationRules] ([PK_AllocationRules]),
    CONSTRAINT [fk_FACTAllocationsV1_History_BusinessPlan_FK1] FOREIGN KEY ([fk_BusinessPlan]) REFERENCES [dbo].[DimBusinessPlan] ([pk_BusinessPlan]),
    CONSTRAINT [fk_FACTAllocationsV1_History_ClaimExposure_FK1] FOREIGN KEY ([fk_ClaimExposure]) REFERENCES [dbo].[DimClaimExposure] ([pk_ClaimExposure]),
    CONSTRAINT [fk_FACTAllocationsV1_History_Client_FK1] FOREIGN KEY ([fk_Client]) REFERENCES [dbo].[DimClient] ([pk_Client]),
    CONSTRAINT [fk_FACTAllocationsV1_History_CURRENCY_FK1] FOREIGN KEY ([currency]) REFERENCES [dbo].[DimTransactionCurrency] ([pk_TransactionCurrency]),
    CONSTRAINT [fk_FACTAllocationsV1_History_DataStage_FK1] FOREIGN KEY ([fk_DataStage]) REFERENCES [dbo].[DimDataStage] ([pk_DataStage]),
    CONSTRAINT [fk_FACTAllocationsV1_History_Entity_FK1] FOREIGN KEY ([fk_Entity]) REFERENCES [dbo].[DimEntity] ([pk_Entity]),
    CONSTRAINT [fk_FACTAllocationsV1_History_Expense_FK1] FOREIGN KEY ([fk_Expense]) REFERENCES [dbo].[DimExpense] ([pk_Expense]),
    CONSTRAINT [fk_FACTAllocationsV1_History_Investment_FK1] FOREIGN KEY ([fk_Holding]) REFERENCES [dbo].[DimHolding] ([pk_Holding]),
    CONSTRAINT [fk_FACTAllocationsV1_History_LloydsClassifications] FOREIGN KEY ([fk_LloydsClassifications]) REFERENCES [dbo].[DimLloydsClassifications] ([pk_LloydsClassifications]),
    CONSTRAINT [fk_FACTAllocationsV1_History_Office_FK1] FOREIGN KEY ([fk_Office]) REFERENCES [dbo].[DimOffice] ([pk_Office]),
    CONSTRAINT [fk_FACTAllocationsV1_History_PolicySection_FK1] FOREIGN KEY ([fk_PolicySection]) REFERENCES [dbo].[DimPolicySection] ([pk_PolicySection]),
    CONSTRAINT [fk_FACTAllocationsV1_History_Process_FK1] FOREIGN KEY ([fk_Process]) REFERENCES [dbo].[DimProcess] ([pk_Process]),
    CONSTRAINT [fk_FACTAllocationsV1_History_Product_FK1] FOREIGN KEY ([fk_Product]) REFERENCES [dbo].[DimProduct] ([pk_Product]),
    CONSTRAINT [fk_FACTAllocationsV1_History_Project_FK1] FOREIGN KEY ([fk_Project]) REFERENCES [dbo].[DimProject] ([pk_Project]),
    CONSTRAINT [fk_FACTAllocationsV1_History_RIPolicy_FK1] FOREIGN KEY ([fk_RIPolicy]) REFERENCES [dbo].[DimRIPolicy] ([pk_RIPolicy]),
    CONSTRAINT [fk_FACTAllocationsV1_History_Scenario_FK1] FOREIGN KEY ([fk_Scenario]) REFERENCES [dbo].[DimScenario] ([pk_Scenario]),
    CONSTRAINT [fk_FACTAllocationsV1_History_SourceSystem_FK1] FOREIGN KEY ([fk_SourceSystem]) REFERENCES [dbo].[DimSourceSystem] ([pk_SourceSystem]),
    CONSTRAINT [fk_FACTAllocationsV1_History_TriFocus_FK1] FOREIGN KEY ([fk_TriFocus]) REFERENCES [dbo].[DimTrifocus] ([pk_Trifocus]),
    CONSTRAINT [fk_FACTAllocationsV1_History_User_FK1] FOREIGN KEY ([fk_User]) REFERENCES [dbo].[DimUser] ([pk_User]),
    CONSTRAINT [fk_FACTAllocationsV1_History_YOA_FK1] FOREIGN KEY ([fk_YOA]) REFERENCES [dbo].[DimYOA] ([pk_YOA])
);
GO

CREATE NONCLUSTERED INDEX [nlx_FACTAllocationsV1_Hisotry__AllocDelete]
    ON [dbo].[FACTAllocationsV1_History]([fk_AccountingPeriod] ASC)
    INCLUDE([pk_FACTAllocations], [fk_Client], [FK_AllocationRules]) WITH (FILLFACTOR = 90);
GO

CREATE NONCLUSTERED INDEX [nlx_FactAllocationsV1_Hisotry__fk_PolicySection_cvr]
    ON [dbo].[FACTAllocationsV1_History]([fk_PolicySection] ASC)
    INCLUDE([pk_FACTAllocations], [SectionReference], [voucher_date], [transaction_date]) WITH (FILLFACTOR = 90);
GO

CREATE NONCLUSTERED INDEX [nlx_FactAllocationsV1_Hisotry_fk_PolicySection_Dim5]
    ON [dbo].[FACTAllocationsV1_History]([fk_PolicySection] ASC)
    INCLUDE([SectionReference]) WITH (FILLFACTOR = 90);
GO

CREATE NONCLUSTERED INDEX [nlx_FactAllocationsV1_History_fk_PolicySection_transaction_date]
    ON [dbo].[FACTAllocationsV1_History]([fk_PolicySection] ASC)
    INCLUDE([transaction_date]) WITH (FILLFACTOR = 90);
GO

CREATE NONCLUSTERED INDEX [nlx_FactAllocationsV1_Hisotry_fk_PolicySection_voucher_date]
    ON [dbo].[FACTAllocationsV1_History]([fk_PolicySection] ASC)
    INCLUDE([voucher_date]) WITH (FILLFACTOR = 90);
GO

CREATE NONCLUSTERED INDEX [nlx_FACTAllocationsV1_Hisotry_ReAllocations]
    ON [dbo].[FACTAllocationsV1_History]([fk_AccountingPeriod] ASC, [fk_Client] ASC, [RuleApplicable] ASC, [pk_FACTAllocations] ASC)
    INCLUDE([pk_tempFactFDM], [fk_Scenario], [Value], [cur_amount], [currency], [value_1], [value_2], [value_3], [FK_AllocationRules]) WITH (FILLFACTOR = 90);
GO
