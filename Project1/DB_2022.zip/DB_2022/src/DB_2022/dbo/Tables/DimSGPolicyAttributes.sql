﻿CREATE TABLE [dbo].[DimSGPolicyAttributes] (
    [PolicyType]             VARCHAR (10) NULL,
    [CANCFLAG]               VARCHAR (55) NULL,
    [INSTYPE]                VARCHAR (55) NULL,
    [RISKLOC]                VARCHAR (55) NULL,
    [SIGNDATE]               VARCHAR (55) NULL,
    [SIGNNO]                 VARCHAR (55) NULL,
    [SLINE]                  VARCHAR (55) NULL,
    [TERRITORY]              VARCHAR (55) NULL,
    [UMR]                    VARCHAR (55) NULL,
    [ZREFNO]                 VARCHAR (55) NULL,
    [AgressoSecionReference] VARCHAR (55) NULL,
    [policyReference]        VARCHAR (55) NULL
);

