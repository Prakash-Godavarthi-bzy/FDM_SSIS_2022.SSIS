﻿CREATE TABLE [dbo].[TrifocusGroups] (
    [TrifocusGroup] VARCHAR (50) NULL,
    [TriFocusCode]  VARCHAR (50) NULL,
    [SLClass]       VARCHAR (50) NULL
);

