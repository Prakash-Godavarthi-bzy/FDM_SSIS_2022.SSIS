﻿CREATE TABLE [dbo].[COBPercentages] (
    [PK_COBPercentages]        INT             IDENTITY (1, 1) NOT NULL,
    [Trifocus]                 NVARCHAR (50)   NULL,
    [YOA]                      NVARCHAR (50)   NULL,
    [pk_LloydsClassOfBusiness] INT             NULL,
    [AllocationPercent]        DECIMAL (28, 8) NOT NULL,
    [LoadID]                   BIGINT          NULL,
    CONSTRAINT [PK_COBPercentages] PRIMARY KEY CLUSTERED ([PK_COBPercentages] ASC) WITH (FILLFACTOR = 90)
);

