﻿CREATE TABLE [dbo].[RITCJournalsDetail] (
    [RITCJournalDetailID]  INT            IDENTITY (1, 1) NOT NULL,
    [fk_RITCJournal]       INT            NULL,
    [SourceAccount]        NVARCHAR (255) NULL,
    [PostingAccount]       NVARCHAR (255) NULL,
    [Multiplier]           INT            NULL,
    [SourceEntity]         NVARCHAR (255) NULL,
    [DestinationEntity]    NVARCHAR (255) NULL,
    [SpecialGroupFilter]   NVARCHAR (255) NULL,
    [SpecialIncludeFilter] NVARCHAR (255) NULL,
    [SpecialExcludeFilter] NVARCHAR (255) NULL,
    CONSTRAINT [fk_RITCJournalsDetailsJournals_FK1] FOREIGN KEY ([fk_RITCJournal]) REFERENCES [dbo].[RITCJournals] ([pk_RITCJournal])
);

