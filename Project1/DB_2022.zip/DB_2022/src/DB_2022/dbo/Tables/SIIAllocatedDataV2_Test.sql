﻿CREATE TABLE [dbo].[SIIAllocatedDataV2_Test] (
    [EntityCode]             NVARCHAR (255)   NULL,
    [EntityGroup]            NVARCHAR (255)   NULL,
    [LOB]                    NVARCHAR (255)   NULL,
    [Channel]                NVARCHAR (255)   NULL,
    [AgressoAccountCategory] NVARCHAR (255)   NULL,
    [SIIType]                NVARCHAR (255)   NULL,
    [LocationOfRisk]         NVARCHAR (255)   NULL,
    [UnderwritingLocation]   NVARCHAR (255)   NULL,
    [OriginalCurrencyCode]   NVARCHAR (255)   NULL,
    [Basis]                  NVARCHAR (255)   NULL,
    [cur_amount]             DECIMAL (38, 3)  NULL,
    [Value]                  NUMERIC (38, 4)  NULL,
    [ReportingCountry]       NVARCHAR (255)   NULL,
    [AllocationPercent]      DECIMAL (38, 14) NULL,
    [AllocatedValue]         NUMERIC (38, 6)  NULL,
    [EntityReportingType]    NVARCHAR (255)   NULL
);

