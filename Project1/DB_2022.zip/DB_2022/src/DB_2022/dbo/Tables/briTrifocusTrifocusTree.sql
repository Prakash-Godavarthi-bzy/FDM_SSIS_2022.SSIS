﻿CREATE TABLE [dbo].[briTrifocusTrifocusTree] (
    [pkDimTrifocusTree]   NVARCHAR (255) NOT NULL,
    [pk_Trifocus]         INT            NOT NULL,
    [pk_AccountingPeriod] INT            NULL,
    CONSTRAINT [PK_briTrifocusTrifocusTree] PRIMARY KEY CLUSTERED ([pkDimTrifocusTree] ASC, [pk_Trifocus] ASC) WITH (FILLFACTOR = 90)
);

