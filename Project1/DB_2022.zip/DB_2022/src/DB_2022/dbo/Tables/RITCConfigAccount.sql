﻿CREATE TABLE [dbo].[RITCConfigAccount] (
    [RITCConfigAccountID] INT            IDENTITY (1, 1) NOT NULL,
    [AccountName]         NVARCHAR (255) NULL,
    [RITCAccountGroup]    NVARCHAR (255) NULL,
    [SourceAccountName]   NVARCHAR (255) NULL,
    [EntityFilter]        NVARCHAR (255) NULL,
    [SpecialFilter]       NVARCHAR (255) NULL,
    [SpecialGroupFilter]  NVARCHAR (255) NULL,
    [CNVRule]             NVARCHAR (255) NULL,
    [LTDCaculation]       NVARCHAR (255) NULL,
    [Calculation]         NVARCHAR (255) NULL,
    [Multiplier]          SMALLINT       NULL,
    [AllocationRule]      NVARCHAR (255) NULL,
    [CalcRule]            NVARCHAR (255) NULL,
    [IntermediateCNV]     NVARCHAR (255) NULL
);

