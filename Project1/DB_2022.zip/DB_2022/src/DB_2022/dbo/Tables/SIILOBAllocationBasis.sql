﻿CREATE TABLE [dbo].[SIILOBAllocationBasis] (
    [Channel] NVARCHAR (255) NULL,
    [LOB]     NVARCHAR (255) NULL,
    [Basis]   NVARCHAR (255) NULL
);

