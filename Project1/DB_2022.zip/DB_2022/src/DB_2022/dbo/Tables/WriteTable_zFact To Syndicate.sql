﻿CREATE TABLE [dbo].[WriteTable_zFact To Syndicate] (
    [ToSyndicate_0]    FLOAT (53)     NULL,
    [ToSyndicate_1]    FLOAT (53)     NULL,
    [pk_ReviewCycle_2] NVARCHAR (255) NULL,
    [pk_YOA_3]         INT            NULL,
    [pk_Host_4]        NVARCHAR (255) NULL,
    [pk_Entity_5]      NVARCHAR (255) NULL,
    [MS_AUDIT_TIME_6]  DATETIME       NULL,
    [MS_AUDIT_USER_7]  NVARCHAR (255) NULL
);

