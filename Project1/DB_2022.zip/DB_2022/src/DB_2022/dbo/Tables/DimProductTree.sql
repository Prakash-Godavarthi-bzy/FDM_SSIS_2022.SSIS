﻿CREATE TABLE [dbo].[DimProductTree] (
    [pkDimProductTree]       NVARCHAR (255) NOT NULL,
    [Description]            NVARCHAR (255) NULL,
    [pkDimProductTreeParent] NVARCHAR (255) NULL,
    [SortOrder]              INT            NULL,
    CONSTRAINT [PK__DimProdu__458E1BC9752305D5] PRIMARY KEY CLUSTERED ([pkDimProductTree] ASC) WITH (FILLFACTOR = 90)
);

