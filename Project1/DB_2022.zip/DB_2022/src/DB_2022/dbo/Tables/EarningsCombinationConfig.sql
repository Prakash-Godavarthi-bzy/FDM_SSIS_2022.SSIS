﻿CREATE TABLE [dbo].[EarningsCombinationConfig] (
    [ProcessCode] VARCHAR (255) NOT NULL,
    [AccountCode] VARCHAR (255) NOT NULL,
    [FK_Process]  INT           NOT NULL
);

