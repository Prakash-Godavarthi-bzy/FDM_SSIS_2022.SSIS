﻿CREATE TABLE [dbo].[SIIEntityAllocationBasis] (
    [Entity]                NVARCHAR (255) NULL,
    [EntityAllocationGroup] NVARCHAR (255) NULL
);

