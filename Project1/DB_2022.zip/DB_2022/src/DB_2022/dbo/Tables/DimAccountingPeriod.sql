﻿CREATE TABLE [dbo].[DimAccountingPeriod] (
    [pk_AccountingPeriod] INT            NOT NULL,
    [AccountingPeriod]    NVARCHAR (255) NULL,
    [AccountingYear]      INT            NULL,
    [AccountingYearName]  NVARCHAR (255) NULL,
    [AccountingMonth]     INT            NULL,
    [AccountingMonthName] NVARCHAR (255) NULL,
    CONSTRAINT [PK__DimAccou__25CC01ECDC361639] PRIMARY KEY CLUSTERED ([pk_AccountingPeriod] ASC) WITH (FILLFACTOR = 90)
);

