﻿CREATE TABLE [dbo].[DimAccountOthers] (
    [pk_Account]         INT            IDENTITY (1000000, 1) NOT NULL,
    [AccountCode]        NVARCHAR (255) NULL,
    [AccountName]        NVARCHAR (255) NULL,
    [AccountGroup]       NVARCHAR (255) NULL,
    [AccountIsMoney]     NCHAR (1)      NULL,
    [AccountIsSnapshot]  NCHAR (1)      NULL,
    [FormatString]       NVARCHAR (255) NULL,
    [MDX]                NVARCHAR (500) NULL,
    [ExcludeFromFXCalcs] NCHAR (1)      NULL,
    [AccountType]        NVARCHAR (50)  NOT NULL,
    [AccountTypeDesc]    NVARCHAR (255) NULL,
    CONSTRAINT [PK_DimAccountOthers_pk_Account] PRIMARY KEY CLUSTERED ([pk_Account] ASC) WITH (FILLFACTOR = 90)
);

