﻿CREATE TABLE [dbo].[DimAllocationTransactionDetailsV2] (
    [pk_FactAllocation] BIGINT NULL,
    [CombinationID]     INT    NULL,
    [SoftDeleteFlag]    INT    CONSTRAINT [DF__DimAlloca__SoftD__2F10007B] DEFAULT ((0)) NULL
);

