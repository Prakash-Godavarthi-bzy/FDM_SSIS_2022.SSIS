﻿CREATE TABLE [dbo].[DimEarnings] (
    [pk_DimEarnings] BIGINT         IDENTITY (1, 1) NOT NULL,
    [InceptionDate]  DATE           NULL,
    [ExpiryDate]     DATE           NULL,
    [PolicyYOA]      INT            NULL,
    [PolicyType]     NVARCHAR (255) NULL,
    [USPolicy]       SMALLINT       NULL,
    [KrRePolicy]     SMALLINT       NULL,
    CONSTRAINT [PK_DimEarnings] PRIMARY KEY CLUSTERED ([pk_DimEarnings] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_DimEarnings] UNIQUE NONCLUSTERED ([InceptionDate] ASC, [ExpiryDate] ASC, [PolicyYOA] ASC, [PolicyType] ASC, [USPolicy] ASC, [KrRePolicy] ASC) WITH (FILLFACTOR = 90)
);

