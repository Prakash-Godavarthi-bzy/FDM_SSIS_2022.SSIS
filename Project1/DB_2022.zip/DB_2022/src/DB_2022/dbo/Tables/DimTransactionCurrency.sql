﻿CREATE TABLE [dbo].[DimTransactionCurrency] (
    [pk_TransactionCurrency]  NVARCHAR (25)  NOT NULL,
    [TransactionCurrencyName] NVARCHAR (255) NULL,
    CONSTRAINT [PK_DimSettlementCurrency] PRIMARY KEY CLUSTERED ([pk_TransactionCurrency] ASC) WITH (FILLFACTOR = 90)
);

