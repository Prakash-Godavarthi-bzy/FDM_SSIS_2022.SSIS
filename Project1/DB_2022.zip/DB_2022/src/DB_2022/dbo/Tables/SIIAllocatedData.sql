﻿CREATE TABLE [dbo].[SIIAllocatedData] (
    [EntityCode]             NVARCHAR (255)   NULL,
    [EntityGroup]            NVARCHAR (255)   NULL,
    [LOB]                    NVARCHAR (255)   NULL,
    [Channel]                NVARCHAR (255)   NULL,
    [AgressoAccountCategory] NVARCHAR (255)   NULL,
    [SIIType]                NVARCHAR (255)   NULL,
    [Basis]                  NVARCHAR (255)   NULL,
    [CurAmount]              DECIMAL (38, 3)  NULL,
    [Value]                  NUMERIC (38, 4)  NULL,
    [ReportingCountry]       NVARCHAR (255)   NULL,
    [AllocationPercent]      DECIMAL (38, 14) NULL,
    [AllocatedValue]         NUMERIC (38, 6)  NULL
);

