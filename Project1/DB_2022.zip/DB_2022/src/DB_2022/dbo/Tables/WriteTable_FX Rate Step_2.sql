﻿CREATE TABLE [dbo].[WriteTable_FX Rate Step_2] (
    [FXRate_0]                 FLOAT (53)     NULL,
    [pk_AccountingPeriod_1]    INT            NULL,
    [pk_FXRate_2]              INT            NULL,
    [pk_ReportingCurrency_3]   INT            NULL,
    [pk_TransactionCurrency_4] NVARCHAR (25)  NULL,
    [pk_RateScenario_5]        INT            NULL,
    [MS_AUDIT_TIME_6]          DATETIME       NULL,
    [MS_AUDIT_USER_7]          NVARCHAR (255) NULL
);

