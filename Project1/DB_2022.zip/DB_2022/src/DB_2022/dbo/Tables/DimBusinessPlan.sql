﻿CREATE TABLE [dbo].[DimBusinessPlan] (
    [pk_BusinessPlan]       INT            IDENTITY (1, 1) NOT NULL,
    [BusinessPlanCode]      NVARCHAR (255) NULL,
    [BusinessPlanName]      NVARCHAR (255) NULL,
    [pk_BusinessPlanParent] INT            NULL,
    CONSTRAINT [PK__DimBusin__BEEB2A2DF8A54009] PRIMARY KEY CLUSTERED ([pk_BusinessPlan] ASC) WITH (FILLFACTOR = 90)
);

