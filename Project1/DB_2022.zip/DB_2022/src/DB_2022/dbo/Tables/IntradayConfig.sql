﻿CREATE TABLE [dbo].[IntradayConfig] (
    [ObjectID]        VARCHAR (255) NOT NULL,
    [Type]            VARCHAR (50)  NOT NULL,
    [MeasureGroupID]  VARCHAR (255) NULL,
    [ElementName]     VARCHAR (255) NULL,
    [DatabaseID]      VARCHAR (255) NOT NULL,
    [QueryDefination] VARCHAR (MAX) NOT NULL,
    [TableName]       VARCHAR (255) NULL,
    [IsEnabled]       BIT           NULL,
    [PartitionID]     VARCHAR (255) NULL,
    CONSTRAINT [PK_IntradayConfig] PRIMARY KEY CLUSTERED ([ObjectID] ASC) WITH (FILLFACTOR = 90)
);

