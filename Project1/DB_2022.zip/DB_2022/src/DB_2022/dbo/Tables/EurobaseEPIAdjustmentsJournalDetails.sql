﻿CREATE TABLE [dbo].[EurobaseEPIAdjustmentsJournalDetails] (
    [JournalDetailID] INT            IDENTITY (1, 1) NOT NULL,
    [ProcessCode]     NVARCHAR (255) NULL,
    [SourceAccount]   NVARCHAR (255) NULL,
    [PostingAccount]  NVARCHAR (255) NULL,
    [Multiplier]      INT            NULL
);

