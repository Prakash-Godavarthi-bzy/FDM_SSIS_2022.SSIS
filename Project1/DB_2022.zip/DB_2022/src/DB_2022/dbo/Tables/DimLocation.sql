﻿CREATE TABLE [dbo].[DimLocation] (
    [pk_Location]  INT            IDENTITY (1, 1) NOT NULL,
    [LocationCode] NVARCHAR (25)  NULL,
    [LocationDesc] NVARCHAR (255) NULL,
    CONSTRAINT [PK_DimLocation_pk_Location] PRIMARY KEY CLUSTERED ([pk_Location] ASC) WITH (FILLFACTOR = 90)
);

