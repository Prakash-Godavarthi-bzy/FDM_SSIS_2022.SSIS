﻿CREATE TABLE [dbo].[SIIEntityGroups] (
    [Entity]                NVARCHAR (255) NULL,
    [EntityGroup]           NVARCHAR (255) NULL,
    [EntityReportingType]   NVARCHAR (255) NULL,
    [TargetEntityFlag]      BIT            NULL,
    [EntityType]            NVARCHAR (255) NULL,
    [LIFEEntity]            BIT            NULL,
    [SIIFunctionalCurrency] NVARCHAR (255) NULL
);

