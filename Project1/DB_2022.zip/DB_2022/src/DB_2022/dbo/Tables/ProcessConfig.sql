﻿CREATE TABLE [dbo].[ProcessConfig] (
    [ConfigID]    INT             IDENTITY (1, 1) NOT NULL,
    [ProcessDesc] NVARCHAR (255)  NOT NULL,
    [ConfigDesc]  NVARCHAR (255)  NOT NULL,
    [ConfigValue] NVARCHAR (2000) NOT NULL
);

