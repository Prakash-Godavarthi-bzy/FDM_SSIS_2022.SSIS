﻿CREATE TABLE [dbo].[WiziConfig] (
    [WiziConfigID] INT           IDENTITY (1, 1) NOT NULL,
    [ConfigDesc]   VARCHAR (255) NOT NULL,
    [ConfigValue]  VARCHAR (255) NOT NULL
);

