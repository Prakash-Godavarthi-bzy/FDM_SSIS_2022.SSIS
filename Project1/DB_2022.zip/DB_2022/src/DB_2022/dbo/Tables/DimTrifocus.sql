﻿CREATE TABLE [dbo].[DimTrifocus] (
    [pk_Trifocus]       INT            IDENTITY (1, 1) NOT NULL,
    [TrifocusCode]      NVARCHAR (255) NULL,
    [TrifocusName]      NVARCHAR (255) NULL,
    [TrifocusGroup]     NVARCHAR (255) NULL,
    [IsUSTrifocus]      TINYINT        CONSTRAINT [DF__DimTrifoc__IsUST__4FD1D5C8] DEFAULT ((0)) NOT NULL,
    [IsKrReTrifocus]    TINYINT        CONSTRAINT [DF_DimTrifoc_IsKrRe] DEFAULT ((0)) NOT NULL,
    [Status]            NVARCHAR (255) NULL,
    [IsUSSyndTrifocus]  TINYINT        NULL,
    [IsSLInternational] TINYINT        CONSTRAINT [DF_DimTrifocus_IsSLInternational] DEFAULT ((0)) NOT NULL,
    [TrifocusTypeCode]  NVARCHAR (255) CONSTRAINT [DF_DimTrifocus_TrifocusTypeCode] DEFAULT ('N') NOT NULL,
    [TrifocusTypeDesc]  NVARCHAR (255) CONSTRAINT [DF_DimTrifocus_TrifocusTypeDesc] DEFAULT ('Unknown') NOT NULL,
    CONSTRAINT [PK__DimTrifo__81D6029F387D4227] PRIMARY KEY CLUSTERED ([pk_Trifocus] ASC) WITH (FILLFACTOR = 90)
);

