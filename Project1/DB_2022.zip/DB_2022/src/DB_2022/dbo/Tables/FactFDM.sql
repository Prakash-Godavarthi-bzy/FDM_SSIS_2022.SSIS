﻿CREATE TABLE [dbo].[FactFDM] (
    [pk_FactFDM]               BIGINT          IDENTITY (1, 1) NOT NULL,
    [fk_Account]               INT             NOT NULL,
    [fk_AccountingPeriod]      INT             NOT NULL,
    [fk_BusinessPlan]          INT             NOT NULL,
    [fk_ClaimExposure]         BIGINT          NOT NULL,
    [fk_DataStage]             INT             NOT NULL,
    [fk_Entity]                INT             NOT NULL,
    [fk_Expense]               INT             NOT NULL,
    [fk_Holding]               INT             NOT NULL,
    [fk_LloydsClassifications] INT             NOT NULL,
    [fk_Office]                INT             NOT NULL,
    [fk_OriginalCurrency]      INT             NOT NULL,
    [fk_PolicySection]         BIGINT          NOT NULL,
    [fk_Process]               INT             NOT NULL,
    [fk_Product]               INT             NOT NULL,
    [fk_Project]               INT             NOT NULL,
    [fk_RIPolicy]              BIGINT          NOT NULL,
    [fk_Scenario]              INT             NOT NULL,
    [fk_SourceSystem]          INT             NOT NULL,
    [fk_TriFocus]              INT             NOT NULL,
    [fk_YOA]                   INT             NOT NULL,
    [fk_Client]                INT             NOT NULL,
    [bk_TransactionID]         BIGINT          NULL,
    [Description]              NVARCHAR (255)  NULL,
    [ExtRef]                   NVARCHAR (255)  NULL,
    [ExtInvRef]                NVARCHAR (255)  NULL,
    [ap_ar_id]                 NVARCHAR (255)  NULL,
    [ap_ar_type]               NVARCHAR (255)  NULL,
    [Dim1]                     NVARCHAR (255)  NULL,
    [Dim2]                     NVARCHAR (255)  NULL,
    [Dim3]                     NVARCHAR (255)  NULL,
    [Dim4]                     NVARCHAR (255)  NULL,
    [Dim5]                     NVARCHAR (255)  NULL,
    [Dim6]                     NVARCHAR (255)  NULL,
    [Dim7]                     NVARCHAR (255)  NULL,
    [VoucherNumber]            NVARCHAR (255)  NULL,
    [Value]                    NUMERIC (18, 4) NOT NULL,
    [cur_amount]               DECIMAL (28, 3) NULL,
    [currency]                 NVARCHAR (25)   NULL,
    [value_1]                  DECIMAL (28, 3) NULL,
    [value_2]                  DECIMAL (28, 3) NULL,
    [value_3]                  DECIMAL (28, 3) NULL,
    [fk_User]                  INT             NULL,
    [insert_date]              DATE            NULL,
    [insert_time]              TIME (7)        NULL,
    [voucher_date]             DATE            NULL,
    [transaction_date]         DATE            NULL,
    [tax_code]                 VARCHAR (25)    NULL,
    [tax_system]               VARCHAR (25)    NULL,
    [fk_Location]              INT             NOT NULL,
    [fk_special]               INT             CONSTRAINT [DF__FactFDM__fk_spec__4A8310C6] DEFAULT ((-1)) NOT NULL,
    [fk_ClassofBusiness]       INT             CONSTRAINT [DF__FactFDM__fk_Clas__4C6B5938] DEFAULT ((-1)) NOT NULL,
    [fk_DimEarnings]           BIGINT          CONSTRAINT [Def_fk_DimEarnings] DEFAULT ((-1)) NOT NULL,
    [fk_TargetEntity]          INT             CONSTRAINT [Def_fk_TargetEntity] DEFAULT ((-1)) NOT NULL,
    [fk_TargetPeriod]          INT             CONSTRAINT [Def_fk_TargetPeriod] DEFAULT ((190001)) NOT NULL,
    [fk_PolicySectionV2]       BIGINT          CONSTRAINT [Def_fk_PolicySectionV2] DEFAULT ((-1)) NOT NULL,
    [fk_SIIPolicy]             BIGINT          CONSTRAINT [Def_fk_SIIPolicy] DEFAULT ((-1)) NULL,
	[MCVoucherNumber]          NVARCHAR (255)  NULL,
    CONSTRAINT [PK_FactFDM_FK_AccPeriod] PRIMARY KEY CLUSTERED ([pk_FactFDM] ASC, [fk_AccountingPeriod] ASC) WITH (FILLFACTOR = 90) ON [PS_FactAccountingPeriods] ([fk_AccountingPeriod]),
    CONSTRAINT [fk_Account_FK1] FOREIGN KEY ([fk_Account]) REFERENCES [dbo].[DimAccount] ([pk_Account]),
    CONSTRAINT [fk_AccountingPeriod_FK1] FOREIGN KEY ([fk_AccountingPeriod]) REFERENCES [dbo].[DimAccountingPeriod] ([pk_AccountingPeriod]),
    CONSTRAINT [fk_BusinessPlan_FK1] FOREIGN KEY ([fk_BusinessPlan]) REFERENCES [dbo].[DimBusinessPlan] ([pk_BusinessPlan]),
    CONSTRAINT [fk_ClaimExposure_FK1] FOREIGN KEY ([fk_ClaimExposure]) REFERENCES [dbo].[DimClaimExposure] ([pk_ClaimExposure]),
    CONSTRAINT [fk_Client_FK1] FOREIGN KEY ([fk_Client]) REFERENCES [dbo].[DimClient] ([pk_Client]),
    CONSTRAINT [fk_CURRENCY_FK1] FOREIGN KEY ([currency]) REFERENCES [dbo].[DimTransactionCurrency] ([pk_TransactionCurrency]),
    CONSTRAINT [fk_DataStage_FK1] FOREIGN KEY ([fk_DataStage]) REFERENCES [dbo].[DimDataStage] ([pk_DataStage]),
    CONSTRAINT [fk_Entity_FK1] FOREIGN KEY ([fk_Entity]) REFERENCES [dbo].[DimEntity] ([pk_Entity]),
    CONSTRAINT [fk_Expense_FK1] FOREIGN KEY ([fk_Expense]) REFERENCES [dbo].[DimExpense] ([pk_Expense]),
    CONSTRAINT [fk_FactFDMClassofBusiness_FK1] FOREIGN KEY ([fk_ClassofBusiness]) REFERENCES [dbo].[DimClassofBusiness] ([pk_ClassofBusiness]),
    CONSTRAINT [fk_FactFDMSpecial_FK1] FOREIGN KEY ([fk_special]) REFERENCES [dbo].[DimSpecial] ([pk_Special]),
    CONSTRAINT [fk_Investment_FK1] FOREIGN KEY ([fk_Holding]) REFERENCES [dbo].[DimHolding] ([pk_Holding]),
    CONSTRAINT [fk_LloydsClassifications] FOREIGN KEY ([fk_LloydsClassifications]) REFERENCES [dbo].[DimLloydsClassifications] ([pk_LloydsClassifications]),
    CONSTRAINT [fk_Location_FK1] FOREIGN KEY ([fk_Location]) REFERENCES [dbo].[DimLocation] ([pk_Location]),
    CONSTRAINT [fk_Office_FK1] FOREIGN KEY ([fk_Office]) REFERENCES [dbo].[DimOffice] ([pk_Office]),
    CONSTRAINT [fk_PolicySection_FK1] FOREIGN KEY ([fk_PolicySection]) REFERENCES [dbo].[DimPolicySection] ([pk_PolicySection]),
    CONSTRAINT [fk_Process_FK1] FOREIGN KEY ([fk_Process]) REFERENCES [dbo].[DimProcess] ([pk_Process]),
    CONSTRAINT [fk_Product_FK1] FOREIGN KEY ([fk_Product]) REFERENCES [dbo].[DimProduct] ([pk_Product]),
    CONSTRAINT [fk_Project_FK1] FOREIGN KEY ([fk_Project]) REFERENCES [dbo].[DimProject] ([pk_Project]),
    CONSTRAINT [fk_RIPolicy_FK1] FOREIGN KEY ([fk_RIPolicy]) REFERENCES [dbo].[DimRIPolicy] ([pk_RIPolicy]),
    CONSTRAINT [fk_Scenario_FK1] FOREIGN KEY ([fk_Scenario]) REFERENCES [dbo].[DimScenario] ([pk_Scenario]),
    CONSTRAINT [fk_SourceSystem_FK1] FOREIGN KEY ([fk_SourceSystem]) REFERENCES [dbo].[DimSourceSystem] ([pk_SourceSystem]),
    CONSTRAINT [fk_TriFocus_FK1] FOREIGN KEY ([fk_TriFocus]) REFERENCES [dbo].[DimTrifocus] ([pk_Trifocus]),
    CONSTRAINT [fk_User_FK1] FOREIGN KEY ([fk_User]) REFERENCES [dbo].[DimUser] ([pk_User]),
    CONSTRAINT [fk_YOA_FK1] FOREIGN KEY ([fk_YOA]) REFERENCES [dbo].[DimYOA] ([pk_YOA]),
	[InsertDate_FDM]			DATETIME2			CONSTRAINT [DEF_FactFDM_InsertDate_FDM] DEFAULT (SYSDATETIME()) NULL
) ON [PS_FactAccountingPeriods] ([fk_AccountingPeriod]);


GO
CREATE NONCLUSTERED INDEX [idx_FactFDM_bk_TransactionID]
    ON [dbo].[FactFDM]([bk_TransactionID] DESC) WITH (FILLFACTOR = 90)
    ON [PS_FactAccountingPeriods] ([fk_AccountingPeriod]);


GO
CREATE NONCLUSTERED INDEX [idx_FactFDM_bk_TransactionID_covered]
    ON [dbo].[FactFDM]([bk_TransactionID] ASC)
    INCLUDE([pk_FactFDM], [Description], [ExtRef], [ExtInvRef], [ap_ar_id], [ap_ar_type], [Dim1], [Dim2], [Dim3], [Dim4], [Dim5], [Dim6], [Dim7], [VoucherNumber], [insert_date], [tax_code], [tax_system]) WITH (FILLFACTOR = 90)
    ON [PS_FactAccountingPeriods] ([fk_AccountingPeriod]);


GO
CREATE NONCLUSTERED INDEX [idx_FactFDM_InsertDate]
    ON [dbo].[FactFDM]([insert_date] ASC)
    INCLUDE([fk_Location], [pk_FactFDM], [fk_Account], [fk_AccountingPeriod], [fk_BusinessPlan], [fk_ClaimExposure], [fk_DataStage], [fk_Entity], [fk_Expense], [fk_Holding], [fk_LloydsClassifications], [fk_Office], [fk_OriginalCurrency], [fk_PolicySection], [fk_Process], [fk_Product], [fk_Project], [fk_RIPolicy], [fk_Scenario], [fk_SourceSystem], [fk_TriFocus], [fk_YOA], [Value], [cur_amount], [currency], [value_1], [value_2], [value_3], [fk_User]) WITH (FILLFACTOR = 90)
    ON [PS_FactAccountingPeriods] ([fk_AccountingPeriod]);


GO
CREATE NONCLUSTERED INDEX [idx_FactFDM_DataStage]
    ON [dbo].[FactFDM]([fk_DataStage] ASC)
    INCLUDE([bk_TransactionID]) WITH (FILLFACTOR = 90)
    ON [PS_FactAccountingPeriods] ([fk_AccountingPeriod]);


GO
CREATE NONCLUSTERED INDEX [nlx_FactFDM_fk_AccountingPeriod_cvr]
    ON [dbo].[FactFDM]([fk_AccountingPeriod] ASC)
    INCLUDE([pk_FactFDM], [fk_Account], [fk_BusinessPlan], [fk_ClaimExposure], [fk_DataStage], [fk_Entity], [fk_Expense], [fk_Holding], [fk_LloydsClassifications], [fk_Office], [fk_OriginalCurrency], [fk_PolicySection], [fk_Process], [fk_Product], [fk_Project], [fk_RIPolicy], [fk_Scenario], [fk_SourceSystem], [fk_TriFocus], [fk_YOA], [fk_Client], [bk_TransactionID], [Description], [ExtRef], [ExtInvRef], [ap_ar_id], [ap_ar_type], [Dim1], [Dim2], [Dim3], [Dim4], [Dim5], [Dim6], [Dim7], [VoucherNumber], [Value], [cur_amount], [currency], [value_1], [value_2], [value_3], [fk_User], [insert_date], [insert_time], [voucher_date], [transaction_date], [tax_code], [tax_system], [fk_Location]) WITH (FILLFACTOR = 90)
    ON [PS_FactAccountingPeriods] ([fk_AccountingPeriod]);


GO
CREATE NONCLUSTERED INDEX [bzyidx_FactFDM_001]
    ON [dbo].[FactFDM]([fk_AccountingPeriod] ASC, [ExtInvRef] ASC) WITH (FILLFACTOR = 90)
    ON [PS_FactAccountingPeriods] ([fk_AccountingPeriod]);

