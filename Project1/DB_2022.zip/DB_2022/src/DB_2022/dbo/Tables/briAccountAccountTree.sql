﻿CREATE TABLE [dbo].[briAccountAccountTree] (
    [pkDimAccountTree]    NVARCHAR (255) NOT NULL,
    [pk_Account]          INT            NOT NULL,
    [pk_AccountingPeriod] INT            NULL,
    CONSTRAINT [PK_briAccountAccountTree] PRIMARY KEY CLUSTERED ([pkDimAccountTree] ASC, [pk_Account] ASC) WITH (FILLFACTOR = 90)
);

