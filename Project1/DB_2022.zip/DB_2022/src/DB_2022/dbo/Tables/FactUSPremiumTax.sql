﻿CREATE TABLE [dbo].[FactUSPremiumTax] (
    [fk_StateCode]        NVARCHAR (255)  NULL,
    [fk_AccountingPeriod] NVARCHAR (255)  NULL,
    [TaxRate]             NUMERIC (28, 6) NULL,
	[InsertDate]			DATETIME2 CONSTRAINT [DEF_FactUSPremiumTax_InsertDate] DEFAULT (SYSDATETIME()) NULL

);

