﻿CREATE TABLE [dbo].[WriteTable_zFact Valid Rate Scenario] (
    [RateValid_0]       FLOAT (53)     NULL,
    [RateDefault_1]     FLOAT (53)     NULL,
    [pk_RateScenario_2] INT            NULL,
    [MS_AUDIT_TIME_3]   DATETIME       NULL,
    [MS_AUDIT_USER_4]   NVARCHAR (255) NULL
);

