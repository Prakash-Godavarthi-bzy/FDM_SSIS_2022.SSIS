﻿CREATE TABLE [dbo].[BIDACSCR] (
    [EntityCode]                 NVARCHAR (255)   NULL,
    [SCR]                        NUMERIC (29, 10) NULL,
    [InterCompanyDebitorAccount] NVARCHAR (255)   NULL
);

