﻿CREATE TABLE [dbo].[DimAccountTree] (
    [pkDimAccountTree]       NVARCHAR (255) NOT NULL,
    [Description]            NVARCHAR (255) NULL,
    [pkDimAccountTreeParent] NVARCHAR (255) NULL,
    [SortOrder]              INT            NULL,
    CONSTRAINT [PK__DimAccou__F3013C2DE61901BD] PRIMARY KEY CLUSTERED ([pkDimAccountTree] ASC) WITH (FILLFACTOR = 90)
);

