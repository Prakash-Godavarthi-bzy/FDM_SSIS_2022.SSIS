﻿CREATE TABLE [dbo].[SIITagetikAccountMapping] (
    [SIIType]                NVARCHAR (255) NULL,
    [EntityReportingType]    NVARCHAR (255) NULL,
    [AgressoAccountCategory] NVARCHAR (255) NULL,
    [SIIClass]               NVARCHAR (255) NULL,
    [TagetikAccountCategory] NVARCHAR (255) NULL
);

