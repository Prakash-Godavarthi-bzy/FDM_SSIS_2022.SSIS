﻿CREATE TABLE [dbo].[DimRIPolicy] (
    [pk_RIPolicy]           BIGINT         IDENTITY (1, 1) NOT NULL,
    [ValidFrom]             DATE           NULL,
    [ValidTo]               DATE           NULL,
    [CurrentKey]            BIGINT         NULL,
    [PreviousKey]           BIGINT         NULL,
    [RIPolicyNumber]        NVARCHAR (255) NULL,
    [RIPolicyDesc]          NVARCHAR (255) NULL,
    [RIBASis]               NVARCHAR (50)  NULL,
    [RIType]                NVARCHAR (50)  NULL,
    [RIProgramme]           NVARCHAR (255) NULL,
    [fk_SourceSystem]       INT            NULL,
    [InceptionDate]         DATE           NULL,
    [ExpiryDate]            DATE           NULL,
    [RIPolicyYOA]           INT            NULL,
    [RIAdjustment]          NVARCHAR (50)  NULL,
    [PolicyNoInAgresso]     NVARCHAR (1)   NULL,
    [EarningsInceptionDate] DATE           NULL,
    [EarningsExpiryDate]    DATE           NULL,
    CONSTRAINT [PK__DimRIPol__45D0A6F358E40F91] PRIMARY KEY CLUSTERED ([pk_RIPolicy] ASC) WITH (FILLFACTOR = 90)
);

