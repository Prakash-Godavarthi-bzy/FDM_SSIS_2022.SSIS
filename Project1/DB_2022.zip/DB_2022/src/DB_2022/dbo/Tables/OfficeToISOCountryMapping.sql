﻿CREATE TABLE [dbo].[OfficeToISOCountryMapping] (
    [BeazleyOfficeLocation] NVARCHAR (255) NULL,
    [ISOCountry]            NVARCHAR (255) NULL,
    [ISOCountryCode]        NVARCHAR (255) NULL
);

