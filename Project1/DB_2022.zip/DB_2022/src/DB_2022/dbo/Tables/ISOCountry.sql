﻿CREATE TABLE [dbo].[ISOCountry] (
    [CountryName]         NVARCHAR (255) NULL,
    [ISOCountryCode]      NVARCHAR (255) NULL,
    [EEAIdentifier]       NVARCHAR (255) NULL,
    [ReportedCountryFlag] FLOAT (53)     NULL
);

