﻿CREATE TABLE [dbo].[FactFDMUWPatterns] (
    [fk_DimEarnings]      BIGINT           NULL,
    [fk_AccountingPeriod] INT              NULL,
    [fk_Account]          INT              NULL,
    [Value]               DECIMAL (15, 10) NULL,
	CONSTRAINT [fk_FactFDMUWPatternsAccount_FK1] FOREIGN KEY ([fk_Account]) REFERENCES [dbo].[DimAccount] ([pk_Account]),
    CONSTRAINT [fk_FactFDMUWPatternsAccountingPeriod_FK1] FOREIGN KEY ([fk_AccountingPeriod]) REFERENCES [dbo].[DimAccountingPeriod] ([pk_AccountingPeriod]),
	[InsertDate]			DATETIME2 CONSTRAINT [DEF_FactFDMUWPatterns_InsertDate] DEFAULT (SYSDATETIME()) NULL
);

