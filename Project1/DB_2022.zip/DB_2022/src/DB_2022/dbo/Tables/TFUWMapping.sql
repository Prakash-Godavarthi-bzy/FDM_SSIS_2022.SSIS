﻿CREATE TABLE [dbo].[TFUWMapping] (
    [TF]            VARCHAR (50)  NULL,
    [UWProd]        VARCHAR (50)  NULL,
    [TrifocusGroup] VARCHAR (255) NULL,
    [TFUWGroup]     VARCHAR (255) NULL
);

