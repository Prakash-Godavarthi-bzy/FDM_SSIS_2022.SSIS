﻿CREATE TABLE [dbo].[BriExpensesTransactionDetailsV4] (
    [CombinationID]              INT             NOT NULL,
    [AccountCode]                NVARCHAR (255)  NULL,
    [ProcessCode]                NVARCHAR (255)  NULL,
    [TriFocusCode]               NVARCHAR (255)  NULL,
    [EntityCode]                 NVARCHAR (255)  NULL,
    [LocationCode]               NVARCHAR (255)  NULL,
    [ProjectCode]                NVARCHAR (255)  NULL,
    [YOA]                        NVARCHAR (255)  NULL,
    [FK_AllocationRules]         INT             NULL,
    [AllocationCode]             VARCHAR (25)    NULL,
    [StepCode]                   VARCHAR (4)     NULL,
    [AccountDest]                NVARCHAR (255)  NULL,
    [TriFocusDest]               NVARCHAR (255)  NULL,
    [EntityDest]                 NVARCHAR (255)  NULL,
    [ProcessDest]                NVARCHAR (255)  NULL,
    [LocationDest]               NVARCHAR (255)  NULL,
    [ProjectDest]                NVARCHAR (255)  NULL,
    [YOADest]                    NVARCHAR (255)  NULL,
    [AllocationPercent]          NUMERIC (28, 8) NULL,
    [AllocationGroup]            VARCHAR (255)   NULL,
    [AllocationGroupVersionCode] INT             NULL,
    [TargetEntity]               NVARCHAR (255)  NULL,
    [TargetPeriodDest]           NVARCHAR (255)  NULL,
    [TargetEntityDest]           NVARCHAR (255)  NULL,
    [TargetCurrencyDest]         NVARCHAR (255)  NULL
);


GO
CREATE NONCLUSTERED INDEX [nlx_ReAllocation]
    ON [dbo].[BriExpensesTransactionDetailsV4]([AllocationCode] ASC)
    INCLUDE([CombinationID], [FK_AllocationRules], [AccountDest], [TriFocusDest], [EntityDest], [ProcessDest], [LocationDest], [ProjectDest], [YOADest], [AllocationPercent], [TargetPeriodDest], [TargetEntityDest], [TargetCurrencyDest]) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [nlx_BriExpensesTransactionDetailsV4_FK_AllocationRules_CombinationID]
    ON [dbo].[BriExpensesTransactionDetailsV4]([FK_AllocationRules] ASC)
    INCLUDE([CombinationID]) WITH (FILLFACTOR = 90);

