﻿CREATE TABLE [dbo].[WriteTable_zFact To Lloyds] (
    [ToLloyds_0]       FLOAT (53)     NULL,
    [ToLloyds_1]       FLOAT (53)     NULL,
    [pk_ReviewCycle_2] NVARCHAR (255) NULL,
    [pk_TriFocus_3]    NVARCHAR (255) NULL,
    [pk_YOA_4]         INT            NULL,
    [MS_AUDIT_TIME_5]  DATETIME       NULL,
    [MS_AUDIT_USER_6]  NVARCHAR (255) NULL
);

