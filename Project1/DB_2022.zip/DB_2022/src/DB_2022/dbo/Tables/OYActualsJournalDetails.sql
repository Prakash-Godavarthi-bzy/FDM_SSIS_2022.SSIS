﻿CREATE TABLE [dbo].[OYActualsJournalDetails] (
    [pk_OYActualsJournalDetails] INT            IDENTITY (1, 1) NOT NULL,
    [fk_OYActualsJournals]       INT            NOT NULL,
    [SourceAccount]              NVARCHAR (255) NULL,
    [PostingAccount]             NVARCHAR (255) NULL,
    [Multiplier]                 INT            NULL,
    [DestinationEntity]          NVARCHAR (255) NULL,
    [SpecialGroupFilter]         NVARCHAR (255) NULL,
    [SpecialFilter]              NVARCHAR (2000) NULL,
    [EntityFilter]               NVARCHAR (255) NULL,
    CONSTRAINT [fk_OYActualsJournalDetails_FK1] FOREIGN KEY ([fk_OYActualsJournals]) REFERENCES [dbo].[OYActualsJournals] ([pk_OYActualsJournals])
);

