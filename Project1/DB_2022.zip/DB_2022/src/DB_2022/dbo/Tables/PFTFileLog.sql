﻿CREATE TABLE [dbo].[PFTFileLog] (
    [FileID]           INT           IDENTITY (1, 1) NOT NULL,
    [RunDate]          DATETIME      NOT NULL,
    [StartTime]        DATETIME      NOT NULL,
    [EndTime]           DATETIME      NULL,
    [FileName]         VARCHAR (255) NOT NULL,    
    [FileStatus]       VARCHAR (255) NULL,
    [TransactionCount] INT           NULL,
    [Comments]         VARCHAR (255) NULL, 
    CONSTRAINT [PK_PFTFileLog] PRIMARY KEY CLUSTERED ([FileID] ASC) WITH (FILLFACTOR = 90)
);
GO
