﻿CREATE TABLE [dbo].[PremiumRealisationScenarios] (
    [BinderReference] NVARCHAR (255) NULL,
    [CurrentView]     INT            NOT NULL,
    [Scenario1]       INT            NOT NULL,
    [Scenario2]       INT            NOT NULL,
    [Scenario3]       INT            NULL,
    [Scenario4]       INT            NULL,
    [Scenario5]       INT            NULL
);

