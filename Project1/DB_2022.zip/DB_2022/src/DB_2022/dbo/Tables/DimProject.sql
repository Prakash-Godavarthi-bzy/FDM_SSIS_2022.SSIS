﻿CREATE TABLE [dbo].[DimProject] (
    [pk_Project]  INT            IDENTITY (1, 1) NOT NULL,
    [ProjectCode] NVARCHAR (255) NULL,
    [ProjectName] NVARCHAR (255) NULL,
    CONSTRAINT [PK__DimProje__D2008CCF14403318] PRIMARY KEY CLUSTERED ([pk_Project] ASC) WITH (FILLFACTOR = 90)
);

