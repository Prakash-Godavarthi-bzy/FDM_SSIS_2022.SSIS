﻿CREATE TABLE [dbo].[DimSourceSystem] (
    [pk_SourceSystem]  INT            IDENTITY (1, 1) NOT NULL,
    [SourceSystemName] NVARCHAR (255) NULL,
    CONSTRAINT [PK__DimSourc__2D025BF77CB59AC3] PRIMARY KEY CLUSTERED ([pk_SourceSystem] ASC) WITH (FILLFACTOR = 90)
);

