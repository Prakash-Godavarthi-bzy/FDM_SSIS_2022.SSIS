﻿CREATE TABLE [dbo].[PremiumEstimatesJournalDetails] (
    [PEJournalDetailID] INT            IDENTITY (1, 1) NOT NULL,
    [SourceAccount]     NVARCHAR (255) NULL,
    [PostingAccount]    NVARCHAR (255) NULL,
    [Multiplier]        INT            NULL
);

