﻿CREATE TABLE [dbo].[DimLloydsClassOfBusiness] (
    [pk_LloydsClassOfBusiness] INT            IDENTITY (1, 1) NOT NULL,
    [LloydsCOBCode]            NVARCHAR (255) NULL,
    [LloydsCOBName]            NVARCHAR (255) NULL,
    [LoadID]                   BIGINT         NULL,
    CONSTRAINT [PK_DimLloydsClassOfBusiness] PRIMARY KEY CLUSTERED ([pk_LloydsClassOfBusiness] ASC) WITH (FILLFACTOR = 90)
);

