﻿CREATE TABLE [dbo].[DimPolicySectionAgresso] (
    [pk_PolicySection] BIGINT         IDENTITY (1, 10) NOT NULL,
    [ValidFrom]        DATE           NULL,
    [ValidTo]          DATE           NULL,
    [PolicyReference]  NVARCHAR (255) NULL,
    [SectionReference] NVARCHAR (255) NULL,
    [StatsCode]        NVARCHAR (255) NULL,
    [PolicyType]       NVARCHAR (255) NULL,
    [MOP]              NVARCHAR (255) NULL,
    [InceptionDate]    DATE           NULL,
    [ExpiryDate]       DATE           NULL,
    [PolicyYOA]        INT            NULL,
    [USPolicy]         SMALLINT       CONSTRAINT [DF_DimPolicyAGRESSO_USPol] DEFAULT ((0)) NULL,
    [KrRePolicy]       SMALLINT       CONSTRAINT [DF_DimPolicyAGRESSO_KrRePolicy] DEFAULT ((0)) NULL,
    [TriFocusCode]     NVARCHAR (255) NULL,
    CONSTRAINT [PK_PolicySection_DimPolicAgress] PRIMARY KEY CLUSTERED ([pk_PolicySection] ASC) WITH (FILLFACTOR = 90)
);

