﻿CREATE TABLE [dbo].[WiziConfigAccount] (
    [WiziConfigAccountID]           INT            IDENTITY (1, 1) NOT NULL,
    [FDMAccountName]                NVARCHAR (255) NULL,
    [WiziAccountGroup]              NVARCHAR (255) NULL,
    [WiziAccountName]               NVARCHAR (255) NULL,
    [WiziRefreshFrequency]          INT            NULL,
    [WiziClosedYOARefreshFrequency] INT            NULL,
    [RITCMonthOffset]               INT            NULL,
    [WiziMultiplier]                INT            NULL,
    [Calculation]                   NVARCHAR (255) NULL,
    [CalculationSequence]           SMALLINT       NULL
);

