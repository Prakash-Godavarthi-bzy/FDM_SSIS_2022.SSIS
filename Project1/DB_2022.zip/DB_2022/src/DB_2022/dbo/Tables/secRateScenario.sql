﻿CREATE TABLE [dbo].[secRateScenario] (
    [NTUser]          NVARCHAR (255) NOT NULL,
    [fk_RateScenario] INT            NOT NULL,
    [Allowed]         INT            NOT NULL
);

