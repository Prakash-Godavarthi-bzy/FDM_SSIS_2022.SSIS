﻿CREATE TABLE [dbo].[ExternalFeedLog] (
    [BatchID]          INT           IDENTITY (1, 1) NOT NULL,
    [ExternalFeedID]   INT           NOT NULL,
    [FileName]         VARCHAR (255) NOT NULL,
    [InsertCount]      INT           NULL,
    [ErrorDescription] VARCHAR (255) NULL
);

