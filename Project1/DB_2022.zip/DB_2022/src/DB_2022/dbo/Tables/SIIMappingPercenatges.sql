﻿CREATE TABLE [dbo].[SIIMappingPercenatges] (
    [EntityCode]            NVARCHAR (255) NULL,
    [Trifocus Code]         NVARCHAR (255) NULL,
    [AreaCode]              NVARCHAR (255) NULL,
    [BeazleyOfficeLocation] NVARCHAR (255) NULL,
    [PolicySourceSystem]    NVARCHAR (255) NULL,
    [AccountTree]           NVARCHAR (255) NULL,
    [AccountGroup]          NVARCHAR (255) NULL,
    [Amount]                NVARCHAR (255) NULL
);

