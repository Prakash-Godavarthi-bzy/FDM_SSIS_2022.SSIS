﻿CREATE TABLE [dbo].[WriteTable_04 RI] (
    [RIValue_0]                FLOAT (53)     NULL,
    [pk_YOA_1]                 INT            NULL,
    [pk_TransactionCurrency_2] NVARCHAR (25)  NULL,
    [pk_ReviewCycle_3]         NVARCHAR (255) NULL,
    [pk_InsertDate_4]          NVARCHAR (255) NULL,
    [UserID_5]                 NVARCHAR (255) NULL,
    [pk_RIProgramme_6]         INT            NULL,
    [pk_OfficeChannel_7]       NVARCHAR (255) NULL,
    [pk_InceptionMonth_8]      INT            NULL,
    [pk_TriFocus_9]            NVARCHAR (255) NULL,
    [MS_AUDIT_TIME_10]         DATETIME       NULL,
    [MS_AUDIT_USER_11]         NVARCHAR (255) NULL
);

