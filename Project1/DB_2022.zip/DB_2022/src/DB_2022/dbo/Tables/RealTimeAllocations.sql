﻿CREATE TABLE [dbo].[RealTimeAllocations] (
    [AllocationGroup] VARCHAR (255) NOT NULL
);

