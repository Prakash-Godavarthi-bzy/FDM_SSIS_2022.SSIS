﻿CREATE TABLE [dbo].[UnAllocatedDataBS] (
    [fk_Account]          INT             NOT NULL,
    [SIICategory]         NVARCHAR (255)  NULL,
    [Signage]             NVARCHAR (255)  NULL,
    [SIIEntity]           NVARCHAR (255)  NULL,
    [Entity]              NVARCHAR (255)  NULL,
    [ReportingEntity]     NVARCHAR (255)  NULL,
    [TargetEntity]        NVARCHAR (255)  NULL,
    [TrifocusCode]        NVARCHAR (255)  NULL,
    [SIIType]             NVARCHAR (255)  NULL,
    [currency]            NVARCHAR (25)   NULL,
    [cur_amount]          DECIMAL (38, 3) NULL,
    [Value]               NUMERIC (38, 4) NULL,
    [EntityReportingType] NVARCHAR (255)  NULL,
    [EntityType]          NVARCHAR (255)  NULL
);

