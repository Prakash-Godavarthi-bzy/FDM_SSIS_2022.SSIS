﻿CREATE TABLE [dbo].[SIILOBMappingV1] (
    [TrifocusCode] NVARCHAR (255) NULL,
    [TrifocusName] NVARCHAR (255) NULL,
    [Entity]       NVARCHAR (255) NULL,
    [Chanel ]      NVARCHAR (255) NULL,
    [LoB]          NVARCHAR (255) NULL
);

