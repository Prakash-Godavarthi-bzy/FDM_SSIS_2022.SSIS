﻿CREATE TABLE [dbo].[DimEntityTree] (
    [pkDimEntityTree]       NVARCHAR (255) NOT NULL,
    [Description]           NVARCHAR (255) NULL,
    [pkDimEntityTreeParent] NVARCHAR (255) NULL,
    [SortOrder]             INT            NULL,
    CONSTRAINT [PK__DimEntit__8F5CD46136B7580C] PRIMARY KEY CLUSTERED ([pkDimEntityTree] ASC) WITH (FILLFACTOR = 90)
);

