﻿CREATE TABLE [dbo].[DimEntity] (
    [pk_Entity]              INT            IDENTITY (1, 1) NOT NULL,
    [EntityCode]             NVARCHAR (255) NULL,
    [EntityName]             NVARCHAR (255) NULL,
    [pk_EntityParent]        INT            NULL,
    [Status]                 NVARCHAR (255) NULL,
    [FunctionalCurrency]     NVARCHAR (255) NULL,
    [ExcludeFromFXCalcs]     NVARCHAR (1)   NULL,
    [TargetEntityIdentifier] NVARCHAR (1)   NULL,
    [Platform]               NVARCHAR (255) NULL,
    CONSTRAINT [PK__DimEntit__A6A34569C8C64235] PRIMARY KEY CLUSTERED ([pk_Entity] ASC) WITH (FILLFACTOR = 90)
);

