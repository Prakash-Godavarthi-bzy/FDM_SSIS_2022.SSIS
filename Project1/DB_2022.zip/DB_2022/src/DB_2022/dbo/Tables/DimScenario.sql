﻿CREATE TABLE [dbo].[DimScenario] (
    [pk_Scenario]   INT            IDENTITY (1, 1) NOT NULL,
    [ScenarioCode]  NVARCHAR (255) NULL,
    [ScenarioName]  NVARCHAR (255) NULL,
    [ScenarioType]  NVARCHAR (255) NULL,
    [SortOrder]     INT            NULL,
    [FriendlyName]  NVARCHAR (255) NULL,
    [CurrentPeriod] INT            NULL,
    CONSTRAINT [PK__DimScena__BD742F16D926BA1A] PRIMARY KEY CLUSTERED ([pk_Scenario] ASC) WITH (FILLFACTOR = 90)
);

