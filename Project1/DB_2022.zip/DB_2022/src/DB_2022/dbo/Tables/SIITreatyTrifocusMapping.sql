﻿CREATE TABLE [dbo].[SIITreatyTrifocusMapping] (
    [Entity]       NVARCHAR (255) NULL,
    [TrifocusCode] NVARCHAR (255) NULL,
    [TrifocusName] NVARCHAR (255) NULL,
    [IsTreaty]     NVARCHAR (255) NULL
);

