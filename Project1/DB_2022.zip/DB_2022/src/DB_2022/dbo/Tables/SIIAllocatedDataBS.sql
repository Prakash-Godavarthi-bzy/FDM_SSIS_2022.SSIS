﻿CREATE TABLE [dbo].[SIIAllocatedDataBS] (
    [S0201Category]        NVARCHAR (255)  NULL,
    [S0202Category]        NVARCHAR (255)  NULL,
    [currency]             NVARCHAR (25)   NULL,
    [EntityReportingType]  NVARCHAR (255)  NULL,
    [EntityGroup]          NVARCHAR (255)  NULL,
    [EntityType]           NVARCHAR (255)  NOT NULL,
    [S0201TagetikAccount]  NVARCHAR (255)  NULL,
    [S0202TagetikAccount]  NVARCHAR (255)  NULL,
    [Value]                NUMERIC (38, 4) NULL,
    [AllocationPercentage] NUMERIC (38, 6) NOT NULL,
    [ReportingCurrency]    NVARCHAR (255)  NULL,
    [AllocateValue]        NUMERIC (38, 6) NULL,
    [AgressoAccount]       NVARCHAR (255)  NULL
);

