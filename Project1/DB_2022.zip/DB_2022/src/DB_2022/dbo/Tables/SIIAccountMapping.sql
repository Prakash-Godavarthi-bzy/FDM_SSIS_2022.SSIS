﻿CREATE TABLE [dbo].[SIIAccountMapping] (
    [SIIType]                NVARCHAR (255) NULL,
    [SIICategory]            NVARCHAR (255) NULL,
    [AgressoAccountCategory] NVARCHAR (255) NULL,
    [AgressoAccount]         NVARCHAR (255) NULL,
    [Signage]                NVARCHAR (255) NULL,
    [EntityGroup]            NVARCHAR (255) NULL
);

