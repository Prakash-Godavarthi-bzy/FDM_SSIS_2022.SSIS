﻿CREATE TABLE [dbo].[ExternalFeedParams] (
    [BatchID]        BIGINT        NOT NULL,
    [ParameterName]  VARCHAR (100) NOT NULL,
    [ParameterValue] VARCHAR (255) NOT NULL
);

