﻿CREATE TABLE [dbo].[PFTFactToSyndicate]
(
    [ToSyndicate] DECIMAL(10,4) NULL, 
    [ReviewCycle] NVARCHAR(255) NULL, 
    [YOA] INT NULL, 
    [Host] NVARCHAR(255) NULL, 
    [Entity] NVARCHAR(255) NULL, 
    [CreatedBy] NVARCHAR(255) NULL, 
    [CreatedDate] DATETIME NULL, 
    [ModifiedBy] NVARCHAR(255) NULL, 
    [ModifiedDate] DATETIME NULL 
)
 