﻿CREATE TABLE [dbo].[PolicyMaster_toAgresso] (
    [PolicyReference]  NVARCHAR (255) NULL,
    [SectionReference] NVARCHAR (255) NULL,
    [MOPCode]          NVARCHAR (255) NULL,
    [UWPlatform]       NVARCHAR (255) NULL,
    [CreatedDate]      DATETIME       NULL,
    [ExecutionLogId]   INT            NULL,
    [ExceptionFlag]    INT            NULL, 
    [PolicyDescription] NVARCHAR(255) NULL
);

