﻿CREATE TABLE [dbo].[DimRateScenario] (
    [pk_RateScenario] INT            IDENTITY (1, 1) NOT NULL,
    [RateCode]        NVARCHAR (255) NULL,
    [RateName]        NVARCHAR (255) NULL,
    [RateGroup]       NVARCHAR (255) NULL,
    [Locked]          NCHAR (1)      NULL,
    [SortOrder]       INT            NULL,
    CONSTRAINT [PK_DimRateScenario] PRIMARY KEY CLUSTERED ([pk_RateScenario] ASC) WITH (FILLFACTOR = 90)
);

