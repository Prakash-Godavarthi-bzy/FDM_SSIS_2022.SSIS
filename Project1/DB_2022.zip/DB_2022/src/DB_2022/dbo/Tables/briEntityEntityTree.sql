﻿CREATE TABLE [dbo].[briEntityEntityTree] (
    [pkDimEntityTree]     NVARCHAR (255) NOT NULL,
    [pk_Entity]           INT            NOT NULL,
    [pk_AccountingPeriod] INT            NULL,
    CONSTRAINT [PK_briEntityEntityTree] PRIMARY KEY CLUSTERED ([pkDimEntityTree] ASC, [pk_Entity] ASC) WITH (FILLFACTOR = 90)
);

