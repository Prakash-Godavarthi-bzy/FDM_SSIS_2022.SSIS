﻿CREATE TABLE [dbo].[FactFXRate] (
    [fk_AccountingPeriod]    INT             NOT NULL,
    [fk_FXRate]              INT             NOT NULL,
    [fk_TransactionCurrency] NVARCHAR (25)   NOT NULL,
    [fk_ReportingCurrency]   INT             NOT NULL,
    [FXRate]                 NUMERIC (28, 8) NULL,
    [fk_RateScenario]        INT             NOT NULL,
	CONSTRAINT [PK_FactFXRate] PRIMARY KEY CLUSTERED ([fk_AccountingPeriod] ASC, [fk_FXRate] ASC, [fk_TransactionCurrency] ASC, [fk_ReportingCurrency] ASC, [fk_RateScenario] ASC) WITH (FILLFACTOR = 90),
	[InsertDate]			 DATETIME2		CONSTRAINT [DEF_FactFXRate_InsertDate] DEFAULT (SYSDATETIME()) NULL
);

