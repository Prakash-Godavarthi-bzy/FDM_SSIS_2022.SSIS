﻿CREATE TABLE [dbo].[AllocationExecutionLogV3] (
    [LoopID]          INT           NOT NULL,
    [AllocationCode]  VARCHAR (255) NOT NULL,
    [ExecutionTime]   VARCHAR (50)  NOT NULL,
    [ExecutionID]     INT           IDENTITY (1, 1) NOT NULL,
    [RecCount]        INT           NULL,
    [Period]          INT           NULL,
    [AllocationGroup] VARCHAR (255) NULL,
    [MAxID]           BIGINT        NULL 
);

