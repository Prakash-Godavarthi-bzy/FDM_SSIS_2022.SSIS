﻿CREATE TABLE [dbo].[DimTransactionDetailsV1_Current]
(
	[pk_FactFDM]       BIGINT         NOT NULL,
    [bk_TransactionID] BIGINT         NULL,
    [Description]      NVARCHAR (255) NULL,
    [ExtRef]           NVARCHAR (255) NULL,
    [ExtInvRef]        NVARCHAR (255) NULL,
    [Dim1]             NVARCHAR (255) NULL,
    [Dim2]             NVARCHAR (255) NULL,
    [Dim3]             NVARCHAR (255) NULL,
    [Dim4]             NVARCHAR (255) NULL,
    [Dim5]             NVARCHAR (255) NULL,
    [Dim6]             NVARCHAR (255) NULL,
    [Dim7]             NVARCHAR (255) NULL,
    [VoucherNumber]    NVARCHAR (255) NULL,
    [insert_date]      DATE           NULL,
    [ap_ar_id]         NVARCHAR (255) NULL,
    [ap_ar_type]       NVARCHAR (255) NULL,
    [tax_code]         VARCHAR (25)   NULL,
    [tax_system]       VARCHAR (25)   NULL,
    [AccountCode]      NVARCHAR (255) NULL,
    [ProcessCode]      NVARCHAR (255) NULL,
    [AccountingPeriod] INT            NOT NULL,
    [CombinationID]    INT            NOT NULL,
    [MCVoucherNumber]  NVARCHAR (255) NULL,
    [transaction_date] DATE           NULL
)


GO
CREATE UNIQUE CLUSTERED INDEX [Clx_DimTransactionDetailsV1_Current_pk_FatcFDM]
    ON [dbo].[DimTransactionDetailsV1_Current]([pk_FactFDM] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [nxl_DimTransactionDetailsV1_Current_CombinationID]
    ON [dbo].[DimTransactionDetailsV1_Current]([CombinationID] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [nlx_DimTransactionDetailsV1_Current_AccPeriodv1]
    ON [dbo].[DimTransactionDetailsV1_Current]([AccountingPeriod] ASC)
    INCLUDE([pk_FactFDM], [CombinationID]) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [nlx_DimTransactionDetailsV1_Current_AccPeriod]
    ON [dbo].[DimTransactionDetailsV1_Current]([AccountingPeriod] ASC)
    INCLUDE([bk_TransactionID], [CombinationID]) WITH (FILLFACTOR = 90);
