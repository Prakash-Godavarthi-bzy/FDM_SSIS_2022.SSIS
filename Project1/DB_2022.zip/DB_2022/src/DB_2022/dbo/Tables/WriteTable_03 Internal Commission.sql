﻿CREATE TABLE [dbo].[WriteTable_03 Internal Commission] (
    [IC_0]             FLOAT (53)     NULL,
    [pk_PolicyType_1]  NVARCHAR (255) NULL,
    [pk_ReviewCycle_2] NVARCHAR (255) NULL,
    [pk_TriFocus_3]    NVARCHAR (255) NULL,
    [pk_YOA_4]         INT            NULL,
    [UserID_5]         NVARCHAR (255) NULL,
    [pk_InsertDate_6]  NVARCHAR (255) NULL,
    [Department_7]     NVARCHAR (255) NULL,
    [MS_AUDIT_TIME_8]  DATETIME       NULL,
    [MS_AUDIT_USER_9]  NVARCHAR (255) NULL
);

