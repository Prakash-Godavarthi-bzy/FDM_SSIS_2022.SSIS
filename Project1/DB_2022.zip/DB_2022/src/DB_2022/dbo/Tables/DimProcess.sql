﻿CREATE TABLE [dbo].[DimProcess] (
    [pk_Process]      INT            IDENTITY (1, 1) NOT NULL,
    [ScenarioCode]    NVARCHAR (255) NULL,
    [ProcessCode]     NVARCHAR (255) NULL,
    [ProcessName]     NVARCHAR (255) NULL,
    [ProcessCategory] NVARCHAR (255) NULL,
    CONSTRAINT [PK__DimProce__87BAB162130BD4BE] PRIMARY KEY CLUSTERED ([pk_Process] ASC) WITH (FILLFACTOR = 90)
);

