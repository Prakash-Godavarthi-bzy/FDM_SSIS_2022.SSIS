﻿CREATE TABLE [dbo].[SIIUnAllocatedDataBS] (
    [AgressoAccount]      NVARCHAR (255)  NULL,
    [S0201Category]       NVARCHAR (255)  NULL,
    [S0202Category]       NVARCHAR (255)  NULL,
    [Signage]             NVARCHAR (255)  NULL,
    [EntityCode]          NVARCHAR (255)  NULL,
    [SIIEntityCode]       NVARCHAR (255)  NULL,
    [ReportingEntityCode] NVARCHAR (255)  NULL,
    [TargetEntity]        NVARCHAR (255)  NULL,
    [SIIType]             NVARCHAR (255)  NULL,
    [currency]            NVARCHAR (25)   NULL,
    [currencyToReport]    NVARCHAR (25)   NULL,
    [Value]               NUMERIC (38, 4) NULL,
    [AllocatedValue]      NUMERIC (38, 4) NULL,
    [EntityReportingType] NVARCHAR (255)  NULL,
    [EntityType]          NVARCHAR (255)  NOT NULL,
    [S0201TagetikAccount] NVARCHAR (255)  NULL,
    [S0202TagetikAccount] NVARCHAR (255)  NULL
);

