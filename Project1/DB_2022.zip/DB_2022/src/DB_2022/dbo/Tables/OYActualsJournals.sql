﻿CREATE TABLE [dbo].[OYActualsJournals] (
    [pk_OYActualsJournals] INT            NOT NULL,
    [JournalDetails]       NVARCHAR (255) NULL,
    [ProcessCode]          NVARCHAR (255) NULL,
    [IsPureWiziProcess]    BIT            NULL,
    PRIMARY KEY CLUSTERED ([pk_OYActualsJournals] ASC) WITH (FILLFACTOR = 90)
);

