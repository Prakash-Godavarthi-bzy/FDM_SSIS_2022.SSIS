﻿CREATE TABLE [dbo].[ExecutionLog] (
    [ExecutionID]    BIGINT       IDENTITY (1, 1) NOT NULL,
    [TableName]      VARCHAR (50) NOT NULL,
    [LastInsertedID] BIGINT       NOT NULL,
    [InsertCount]    INT          NOT NULL,
    [UpdateCount]    INT          NOT NULL,
    [LastInsertDate] DATETIME     NULL,
    [LastUpdateDate] DATETIME     NULL,
    [IntraDayFlag]   BIT          NOT NULL,
    [DimensionType]  INT          NULL
);

