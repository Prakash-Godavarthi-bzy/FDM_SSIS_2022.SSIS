﻿CREATE TABLE [dbo].[DimLloydsClassifications] (
    [pk_LloydsClassifications] INT            IDENTITY (1, 1) NOT NULL,
    [LloydsRiskCode]           NVARCHAR (255) NULL,
    [LloydsRiskName]           NVARCHAR (255) NULL,
    [LloydsCOBCode]            NVARCHAR (255) NULL,
    [LloydsCOBName]            NVARCHAR (255) NULL,
    [LloydsSourceOfBusiness]   NVARCHAR (255) NULL,
    [LloydsPlatform]           NVARCHAR (255) NULL,
    CONSTRAINT [PK__DimLloyd__551C7C0C8D9A5484] PRIMARY KEY CLUSTERED ([pk_LloydsClassifications] ASC) WITH (FILLFACTOR = 90)
);

