﻿CREATE TABLE [dbo].[DimAUSPolicyAttributes] (
    [PolicyType]             VARCHAR (255) NULL,
    [AUSMOP]                 VARCHAR (255) NULL,
    [AUSBINDER]              VARCHAR (255) NULL,
    [AUSPOLDESC]             VARCHAR (255) NULL,
    [AgressoSecionReference] VARCHAR (255) NULL,
    [policyReference]        VARCHAR (255) NULL
);

