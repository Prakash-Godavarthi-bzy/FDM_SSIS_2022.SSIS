﻿CREATE TABLE [dbo].[SIINetAccountsForBS] (
    [EntityReportingType] NVARCHAR (255) NULL,
    [AgressoAccount]      NVARCHAR (255) NULL,
    [Type]                NVARCHAR (255) NULL
);

