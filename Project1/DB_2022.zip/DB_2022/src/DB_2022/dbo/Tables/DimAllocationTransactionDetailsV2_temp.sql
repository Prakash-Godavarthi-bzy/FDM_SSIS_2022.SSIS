﻿CREATE TABLE [dbo].[DimAllocationTransactionDetailsV2_temp] (
    [pk_FactAllocation] BIGINT         NULL,
    [CombinationID]     INT            NULL,
    [AccountCode]       NVARCHAR (255) NULL,
    [ProcessCode]       NVARCHAR (255) NULL,
    [TriFocusCode]      NVARCHAR (255) NULL,
    [EntityCode]        NVARCHAR (255) NULL,
    [LocationCode]      NVARCHAR (255) NULL,
    [ProjectCode]       NVARCHAR (255) NULL,
    [YOA]               NVARCHAR (255) NULL,
    [TargetEntity]      NVARCHAR (255) NULL,
    [SoftDeleteFlag]    INT            NULL
);

