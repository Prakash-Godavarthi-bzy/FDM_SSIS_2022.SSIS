CREATE View [FDM_DC_CUBE_V2].[vw_FactPcentChannel] as
SELECT        CAST(NULL AS nvarchar(255)) AS pk_Channel, CAST(NULL AS nvarchar(255)) AS pk_TF, CAST(NULL AS numeric(18, 4)) AS PcentChannel