CREATE View [FDM_DC_CUBE_V2].[vw_DimOfficeChannel] as

SELECT        pk_OfficeChannel, OfficeChannelName, Platform
FROM            FDM_DC.DimOfficeChannel
WHERE        (pk_OfficeChannel <> 'BIUK')
UNION
SELECT        'BIFR' AS pk_OfficeChannel, 'France' AS OfficeChannelName, 'BID' AS Platform
UNION
SELECT        'BIDE' AS pk_OfficeChannel, 'Germany' AS OfficeChannelName, 'BID' AS Platform
UNION
SELECT        'BISP' AS pk_OfficeChannel, 'Spain' AS OfficeChannelName, 'BID' AS Platform
UNION
SELECT        'BIUK' AS pk_OfficeChannel, 'UK' AS OfficeChannelName, 'BID' AS Platform
UNION
SELECT        'BISW' AS pk_OfficeChannel, 'Switzerland' AS OfficeChannelName, 'BID' AS Platform
UNION
SELECT        'USBAIC' AS pk_OfficeChannel, 'USBAIC' AS OfficeChannelName, 'USA' AS Platform