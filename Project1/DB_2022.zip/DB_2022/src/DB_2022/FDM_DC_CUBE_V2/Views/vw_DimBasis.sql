CREATE View [FDM_DC_CUBE_V2].[vw_DimBasis] as

SELECT        'Data Entry' AS Basis
UNION
SELECT        'Syndicate' AS Basis