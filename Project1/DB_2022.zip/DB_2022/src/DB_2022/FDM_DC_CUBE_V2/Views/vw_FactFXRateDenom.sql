CREATE View [FDM_DC_CUBE_V2].[vw_FactFXRateDenom] as
SELECT        fk_AccountingPeriod, CAST(LEFT(fk_AccountingPeriod, 4) AS int) AS fk_YOA, CAST(RIGHT(fk_AccountingPeriod, 2) AS int) AS fk_InceptionMonth, fk_FXRate, fk_TransactionCurrency, fk_ReportingCurrency, FXRate, 
                         fk_RateScenario
FROM            FactFXRate
WHERE        (fk_TransactionCurrency IN ('USD', 'GBP', 'AUD', 'EUR')) AND (CAST(LEFT(fk_AccountingPeriod, 4) AS int) BETWEEN YEAR(GETDATE()) - 4 AND YEAR(GETDATE()) + 1) AND (CAST(RIGHT(fk_AccountingPeriod, 2) 
                         AS int) BETWEEN 1 AND 12) AND (fk_RateScenario IN
                             (SELECT        pk_RateScenario
                               FROM            DimRateScenario
                               WHERE        (RateName LIKE '%Budget%') OR
                                                         (RateName LIKE '%Forecast%') OR
                                                         (RateName LIKE '%PIM%') OR
                                                         (RateName LIKE '%Spot%')))