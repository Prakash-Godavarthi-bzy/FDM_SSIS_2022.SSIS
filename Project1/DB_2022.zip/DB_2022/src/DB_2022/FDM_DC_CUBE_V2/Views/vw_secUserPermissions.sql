CREATE View [FDM_DC_CUBE_V2].[vw_secUserPermissions] as
SELECT        UserID, CASE WHEN Department = 'Trifocus Tree' THEN 'TFD Specialty Lines' ELSE Department END AS Department, FXRate, MinVersion, MaxVersion
FROM            FDM_DC.secUserPermissions