CREATE View [FDM_DC_CUBE_V2].[vw_DimRateScenario] as

SELECT        pk_RateScenario, RateCode, RateName, RateGroup, Locked, SortOrder
FROM            DimRateScenario
WHERE        (RateName LIKE '%Budget%') OR
                         (RateName LIKE '%Forecast%') OR
                         (RateName LIKE '%PIM%') OR
                         (RateName LIKE '%Spot%')