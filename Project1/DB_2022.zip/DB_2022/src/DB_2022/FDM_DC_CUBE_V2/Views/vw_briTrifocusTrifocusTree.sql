CREATE View [FDM_DC_CUBE_V2].[vw_briTrifocusTrifocusTree] as


SELECT        briTrifocusTrifocusTree.pkDimTrifocusTree, briTrifocusTrifocusTree.pk_Trifocus, briTrifocusTrifocusTree.pk_AccountingPeriod, DimTrifocus.TrifocusCode
FROM            briTrifocusTrifocusTree INNER JOIN
                         DimTrifocus ON briTrifocusTrifocusTree.pk_Trifocus = DimTrifocus.pk_Trifocus