CREATE View [FDM_DC_CUBE_V2].[vw_DimRepCurr] as

SELECT        pk_TransactionCurrency, TransactionCurrencyName
FROM            DimTransactionCurrency
WHERE        (pk_TransactionCurrency IN ('USD', 'GBP', 'AUD', 'EUR'))