CREATE View [FDM_DC_CUBE_V2].[vw_DimReportingCurrency] as

SELECT        pk_ReportingCurrency, ReportingCurrencyCode, ReportingCurrencyName
FROM            DimReportingCurrency
WHERE        (ReportingCurrencyCode <> 'ORIGCUR')