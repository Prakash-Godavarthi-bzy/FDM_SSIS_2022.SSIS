CREATE View [FDM_DC_CUBE_V2].[vw_DimApplyCede] as

SELECT        'Yes' AS pk_ApplyCede
UNION
SELECT        'No' AS pk_ApplyCede