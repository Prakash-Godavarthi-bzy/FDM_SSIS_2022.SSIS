CREATE View [FDM_DC_CUBE_V2].[vw_DimYOA] as

SELECT        pk_YOA, YOAName
FROM            DimYOA
WHERE        (pk_YOA BETWEEN YEAR(GETDATE()) - 20 AND YEAR(GETDATE()) + 1)