CREATE View [FDM_DC_CUBE_V2].[vw_DimDepartment] as

SELECT DISTINCT ISNULL(Department, 'Not Set') AS Department
FROM            FDM_DC.DimTriFocus