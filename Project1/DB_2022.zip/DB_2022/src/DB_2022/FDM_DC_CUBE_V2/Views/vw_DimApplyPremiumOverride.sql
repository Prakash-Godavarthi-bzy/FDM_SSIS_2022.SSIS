CREATE View [FDM_DC_CUBE_V2].[vw_DimApplyPremiumOverride] as
SELECT        'Yes' AS ApplyOverride
UNION
SELECT        'No' AS ApplyOverride