CREATE View [FDM_DC_CUBE_V2].[vw_FactOverridePremium] as
SELECT        fk_Trifocus, fk_YOA, fk_ReviewCycle, OverridePremium
FROM            (SELECT        CAST(NULL AS nvarchar(255)) AS fk_Trifocus, CAST(NULL AS int) AS fk_YOA, CAST(NULL AS nvarchar(255)) AS fk_ReviewCycle, CAST(NULL AS numeric(18, 4)) AS OverridePremium) 
                         AS derivedtbl_1
WHERE        (fk_Trifocus IS NOT NULL)