CREATE View [FDM_DC_CUBE_V2].[vw_nqFactCombinedPercent] as
SELECT        l_1.fk_ReviewCycle, l_1.fk_TriFocus, l_1.fk_YOA, h.fk_Host, s.fk_Entity, l_1.ToLloyds * h.ToHost * s.ToSyndicate AS ThePercent
FROM            (SELECT        fk_ReviewCycle, fk_TriFocus, fk_YOA, SUM(ToLloyds) AS ToLloyds
                          FROM            (SELECT        fk_ReviewCycle, fk_TriFocus, fk_YOA, ToLloyds
                                                    FROM            FDM_DC.FactToLloyds AS l
                                                    UNION ALL
                                                    SELECT        pk_ReviewCycle_2, pk_TriFocus_3, pk_YOA_4, ToLloyds_0
                                                    FROM            [WriteTable_zFact To Lloyds]) AS a
                          GROUP BY fk_ReviewCycle, fk_TriFocus, fk_YOA) AS l_1 INNER JOIN
                             (SELECT        fk_ReviewCycle, fk_TriFocus, fk_Host, fk_YOA, SUM(ToHost) AS ToHost
                               FROM            (SELECT        fk_ReviewCycle, fk_TriFocus, fk_Host, fk_YOA, ToHost
                                                         FROM            FDM_DC.FactToHost
                                                         UNION ALL
                                                         SELECT        pk_ReviewCycle_2, pk_TriFocus_3, pk_Host_5, pk_YOA_4, ToHost_0
                                                         FROM            [WriteTable_zFact To Host]) AS a_2
                               GROUP BY fk_ReviewCycle, fk_TriFocus, fk_Host, fk_YOA) AS h ON l_1.fk_ReviewCycle = h.fk_ReviewCycle AND l_1.fk_TriFocus = h.fk_TriFocus AND l_1.fk_YOA = h.fk_YOA INNER JOIN
                             (SELECT        fk_ReviewCycle, fk_Host, fk_Entity, fk_YOA, SUM(ToSyndicate) AS ToSyndicate
                               FROM            (SELECT        fk_ReviewCycle, fk_Host, fk_Entity, fk_YOA, ToSyndicate
                                                         FROM            FDM_DC.FactToSyndicate
                                                         UNION ALL
                                                         SELECT        pk_ReviewCycle_2, pk_Host_4, pk_Entity_5, pk_YOA_3, ToSyndicate_0
                                                         FROM            [WriteTable_zFact To Syndicate]) AS a_1
                               GROUP BY fk_ReviewCycle, fk_Host, fk_Entity, fk_YOA) AS s ON l_1.fk_ReviewCycle = s.fk_ReviewCycle AND l_1.fk_YOA = s.fk_YOA AND h.fk_Host = s.fk_Host