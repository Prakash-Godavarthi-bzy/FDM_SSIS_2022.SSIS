CREATE View [FDM_DC_CUBE_V2].[vw_FactFXRateNum] as
SELECT        fk_AccountingPeriod, CAST(LEFT(fk_AccountingPeriod, 4) AS int) AS fk_YOA, CAST(RIGHT(fk_AccountingPeriod, 2) AS int) AS fk_InceptionMonth, fk_FXRate, fk_TransactionCurrency, fk_ReportingCurrency, FXRate, 
                         fk_RateScenario
FROM            FactFXRate
WHERE        (RIGHT(fk_AccountingPeriod, 2) BETWEEN '01' AND '12') AND (CAST(LEFT(fk_AccountingPeriod, 4) AS int) BETWEEN YEAR(GETDATE()) - 4 AND YEAR(GETDATE()) + 1) AND (fk_RateScenario IN
                             (SELECT        pk_RateScenario
                               FROM            DimRateScenario
                               WHERE        (RateName LIKE '%Budget%') OR
                                                         (RateName LIKE '%Forecast%') OR
                                                         (RateName LIKE '%PIM%') OR
                                                         (RateName LIKE '%Spot%')))