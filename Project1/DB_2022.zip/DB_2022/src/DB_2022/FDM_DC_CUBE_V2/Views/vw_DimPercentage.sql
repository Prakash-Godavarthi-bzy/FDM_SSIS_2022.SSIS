CREATE View [FDM_DC_CUBE_V2].[vw_DimPercentage] as
SELECT        'None' AS PcentType
UNION
SELECT        'Trifocus' AS PcentType
UNION
SELECT        'Channel' AS PcentType
UNION
SELECT        'ChannelPeriodPolType' AS PcentType