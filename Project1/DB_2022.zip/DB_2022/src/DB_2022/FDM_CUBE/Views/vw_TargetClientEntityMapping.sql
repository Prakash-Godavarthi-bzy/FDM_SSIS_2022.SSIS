﻿CREATE VIEW [FDM_CUBE].[vw_TargetClientEntityMapping]
AS 
SELECT	client AS Target_ClientCode
		,entity_fx AS EntityCode
		,DE.pk_Entity AS pk_TargetEntity
		,'BP' AS ScenarioCode 
		,'Actual' AS Scenario 
		,1 AS pk_scenario
		FROM [$(staging_agresso)].[dbo].[afxclientent] FX
		LEFT JOIN DimEntity DE ON FX.entity_fx=DE.EntityCode
		LEFT JOIN DimClient DC ON FX.client=DC.ClientCode
		
UNION
SELECT	 ScenarioCode AS Target_clientCode
		,CAST(EntityCode AS VARCHAR(25)) AS entity_fx
		,pk_Entity AS  pk_TargetEntity
		,ScenarioCode AS ScenarioCode
		,FriendlyName AS Scenario
		,pk_Scenario
FROM	DimEntity
CROSS	APPLY DIMSCENARIO 
LEFT    JOIN  DimClient DC ON DC.ClientCode=ScenarioCode
WHERE	ScenarioCode <> 'NA'
AND     ScenarioCode in ('BP')
AND     ClientCode not in ('BP')
AND		FriendlyName IS NOT NULL
AND		pk_Entity <> -1