﻿CREATE TABLE [CAMT].[FileLog] (
    [FileID]           INT           IDENTITY (1, 1) NOT NULL,
    [RunDate]          DATETIME      NOT NULL,
    [StartTime]        DATETIME      NOT NULL,
    [Endime]           DATETIME      NULL,
    [FileName]         VARCHAR (255) NOT NULL,
    [FileContent]      VARCHAR (MAX) NOT NULL,
    [FileStatus]       VARCHAR (255) NULL,
    [TransactionCount] INT           NULL,
    [Comments]         VARCHAR (255) NULL
);

