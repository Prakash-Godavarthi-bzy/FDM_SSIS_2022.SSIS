﻿CREATE TABLE [CAMT].[XML_CAMT_FULLFile] (
    [ReturnHeaderID]    INT           NULL,
    [AccountNumber]     VARCHAR (255) NULL,
    [AccountCurrency]   VARCHAR (255) NULL,
    [FinInstnID]        VARCHAR (255) NULL,
    [StatementDateTime] VARCHAR (255) NULL,
    [XML_Balances]      XML           NULL,
    [XML_Entries]       XML           NULL
);

