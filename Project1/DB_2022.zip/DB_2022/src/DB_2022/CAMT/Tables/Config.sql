﻿CREATE TABLE [CAMT].[Config] (
    [ConfigID]         SMALLINT      NOT NULL,
    [RC03FileLocation] VARCHAR (255) NOT NULL,
    [CAMTFileLocation] VARCHAR (255) NOT NULL,
    [ServerName]       VARCHAR (255) NULL
);

