﻿CREATE TABLE [CAMT].[AccountMapping] (
    [Lodgement_Area]             VARCHAR (25)  NULL,
    [client]                     VARCHAR (25)  NULL,
    [Lodgement_Area_Description] VARCHAR (50)  NULL,
    [Bank_Code]                  VARCHAR (25)  NULL,
    [Bank_Name]                  VARCHAR (255) NULL,
    [Agresso_Account]            VARCHAR (25)  NULL,
    [Bank_Account]               VARCHAR (35)  NULL,
    [Currency]                   VARCHAR (25)  NULL,
    [Sort_Code]                  VARCHAR (13)  NULL,
    [Iban_Number]                VARCHAR (35)  NULL,
    [BIC_Code]                   VARCHAR (11)  NULL,
    [Entity]                     VARCHAR (25)  NULL,
    [Payment_Type]               VARCHAR (8)   NULL,
    [file_type]                  VARCHAR (255) NULL,
    [tag25_bank_acc_id]          VARCHAR (50)  NULL,
    [Variant_Number]             INT           NULL
);

