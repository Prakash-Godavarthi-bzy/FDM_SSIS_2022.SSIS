﻿CREATE TABLE [CAMT].[CAMTConfig] (
    [ID]           INT           IDENTITY (1, 1) NOT NULL,
    [FieldColumn]  VARCHAR (50)  NOT NULL,
    [FieldType]    VARCHAR (50)  NOT NULL,
    [FieldElement] VARCHAR (255) NULL,
    [Level]        INT           NOT NULL,
    [Alias]        VARCHAR (50)  NULL,
    [ColumnOrder]  INT           NULL
);

