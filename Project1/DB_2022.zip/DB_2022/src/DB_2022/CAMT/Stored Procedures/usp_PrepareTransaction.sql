﻿

		
CREATE PROCEDURE [CAMT].[usp_PrepareTransaction]
	@piFileID	INT	
AS
BEGIN
	--Standard SET OPTION section
	SET NOCOUNT ON
	SET ANSI_WARNINGS ON
	SET ANSI_NULLS ON
	SET DATEFORMAT DMY

	-- Declare Framework Variables
	DECLARE	@vsStepName				SYSNAME
			, @viReturnValue		INT
			, @vsErrorProcedure		NVARCHAR(126)
			, @vsErrorMessage		NVARCHAR(2048)
	
	-- Set up ReturnValue
	SET	@viReturnValue = 0

	-- Declare procedure-specific variables
	
	BEGIN TRY

		IF @piFileID IS NULL 
			RAISERROR('The ReturnHeaderID can not be null',16,3)

		DELETE FROM CAMT.CAMTTransactionDetails 
		WHERE ReturnHeaderID = @piFileID

		
		TRUNCATE TABLE [CAMT].[CAMTTransactionDetails_Temp]
		Declare		@Statement as VARCHAR(MAX) = 'SELECT	ReturnHeaderID
				,AccountNumber
				,AccountCurrency
				,FinInstnID
				,StatementDateTime, ',
			@Alias VARCHAR(50) = '[SQL]',
			@Alias1 VARCHAR(50),
			@Value VARCHAR(50) = '.value',
			@Tag VARCHAR(50) = '.query',
			@From VARCHAR(255) = ' FROM [CAMT].[XML_CAMT_FULLFile_Temp]', 
			@Apply VARCHAR(255)=' [XML_Entries].nodes(''//@EntryElement'') AS '


		SELECT	@Statement = @Statement +FieldColumn + ' = ' +
							Alias+'.'+@Alias+'.'+CASE WHEN FieldType = 'Value' THEN FieldType+'('+FieldElement+')' ELSE FieldType+'('+FieldElement+')'  END + ' , '
		FROM	CAMT.CAMTConfig
		WHERE	[Level] = 2
		ORDER BY ColumnOrder

		SELECT TOP 1 @Alias1=  Alias+'('+@Alias+')',@Apply  =@From+' CROSS APPLY '+  REPLACE(@Apply,'@EntryElement',Alias) FROM CAMT.CAMTConfig
		WHERE [Level] = 2
		

		SELECT @Statement = substring(@Statement,0,Len(@Statement)-1) +@Apply + @Alias1 

		EXECUTE ( 'INSERT INTO [CAMT].[CAMTTransactionDetails_temp] '+@Statement) 
		
		SELECT	@viReturnValue = COUNT(*)
		FROM	CAMT.CAMTTransactionDetails_temp t
		JOIN 	CAMT.FileLog f ON f.FileID = t.ReturnHeaderID
		WHERE	ReturnHeaderID = @piFileID
		AND 	FileStatus NOT IN ('Duplicate','EmptyFile'	)
		
	END TRY
	
	BEGIN CATCH
		SELECT  @vsErrorProcedure = ERROR_PROCEDURE() 
			,@vsErrorMessage = ERROR_MESSAGE()
		RAISERROR(50003, 16, 1, @vsErrorProcedure, @vsStepName, @vsErrorMessage)
		SET	@viReturnValue = 1
	END CATCH

	RETURN (@viReturnValue)

END
