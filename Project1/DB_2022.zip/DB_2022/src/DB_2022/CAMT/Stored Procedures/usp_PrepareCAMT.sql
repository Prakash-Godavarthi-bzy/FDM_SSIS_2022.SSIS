﻿CREATE PROCEDURE [CAMT].[usp_PrepareCAMT]
	@piFileID	INT

AS
BEGIN

	DECLARE @psXMLString NVARCHAR(MAX) 

	SELECT @psXMLString = [FileContent]
	FROM [CAMT].[FileLog]
	WHERE [FileID] = @piFileID

	--Standard SET OPTION section
	SET NOCOUNT ON
	SET ANSI_WARNINGS ON
	SET ANSI_NULLS ON
	SET DATEFORMAT DMY

	-- Declare Framework Variables
	DECLARE	@vsStepName				SYSNAME
			, @viReturnValue		INT
			, @vsErrorProcedure		NVARCHAR(126)
			, @vsErrorMessage		NVARCHAR(2048)
	
	-- Set up ReturnValue
	SET	@viReturnValue = 0

	-- Declare procedure-specific variables
	DECLARE @vxXML		AS XML,
			@firstIndex INT,
			@lastIndex INT,
			@headerElement VARCHAR(MAX);

		BEGIN TRY

		IF @piFileID IS NULL 
			RAISERROR('The ReturnHeaderID can not be null',16,3)

		SET @firstIndex = 0
		WHILE( @psXMLString IS NOT NULL and @psXMLString <>' ' and CHARINDEX('<Document', @psXMLString,@firstIndex) > @firstIndex)
		BEGIN
			SELECT @firstIndex = CHARINDEX('<Document', @psXMLString,@firstIndex);
			SELECT @lastIndex = CHARINDEX('>', SUBSTRING(@psXMLString,@firstIndex+len('<Document'),len(@psXMLString)),0);
			SELECT @headerElement = SUBSTRING(@psXMLString,@firstIndex+len('<Document'),@lastIndex-1)
			SELECT @psXMLString = REPLACE(@psXMLString,@headerElement,'')	
			SELECT @psXMLString = REPLACE(@psXMLString,'UTF-8','UTF-16')	
		END

		SET @psXMLString = REPLACE(@psXMLString,CHAR(9),'')

		SET @vxXML = @psXMLString
			
		IF OBJECT_ID('tempdb..#Record') IS NOT NULL
			DROP TABLE #Record
		IF OBJECT_ID('tempdb..##Results') IS NOT NULL
			DROP TABLE ##Results
		
		SELECT @vxXML [FileContent]
		INTO #Record

		TRUNCATE TABLE [CAMT].[XML_CAMT_FULLFile_Temp]
		
		DECLARE		
			@Statement as VARCHAR(MAX) = 'SELECT '+CAST(@piFileID AS VARCHAR) +' AS ReturnHeaderID, ',
			@Alias VARCHAR(50) = '[SQL]',
			@Alias1 VARCHAR(50),
			@Value VARCHAR(50) = '.value',
			@Tag VARCHAR(50) = '.query',
			@From VARCHAR(255) = ' FROM #Record', 
			@Apply VARCHAR(255)=' fileContent.nodes(''//@EntryElement'') AS '


		SELECT	@Statement = @Statement +FieldColumn + ' = ' +
							Alias+'.'+@Alias+'.'+CASE WHEN FieldType = 'Value' THEN FieldType+'('+FieldElement+')' ELSE FieldType+'('+FieldElement+')'  END + ' , '
		FROM	CAMT.CAMTConfig
		WHERE	[Level] = 1
		ORDER  BY ColumnOrder

		SELECT	TOP 1 @Alias1=  Alias+'('+@Alias+')',@Apply  =@From+' CROSS APPLY '+  REPLACE(@Apply,'@EntryElement',Alias) FROM CAMT.CAMTConfig
		WHERE	[Level] = 1

		SELECT	@Statement = substring(@Statement,0,Len(@Statement)-1) +  +@Apply + @Alias1 


		EXECUTE ( 'INSERT INTO [CAMT].[XML_CAMT_FULLFile_Temp] '+@Statement) 



		DECLARE @Duplicate as VARCHAR(50)	


		SELECT	TOP 1 @Duplicate = x.AccountNumber
		FROM	[CAMT].[XML_CAMT_FULLFile_Temp] r
		LEFT	JOIN	CAMT.XML_CAMT_FULLFile  x 
		ON		r.AccountNumber = x.AccountNumber
		AND		r.AccountCurrency = x.AccountCurrency
		AND		r.StatementDateTime = x.StatementDateTime
		LEFT	JOIN CAMT.FileLog f
		ON		f.FileID = x.ReturnHeaderID
		WHERE	f.FileStatus NOT IN ('Failed: Variant mapping missing','Failed In Agresso')
		

		IF EXISTS(SELECT 1 FROM CAMT.[XML_CAMT_FULLFile_Temp]  WHERE ReturnHeaderID = @piFileID)
		BEGIN
			IF (@Duplicate IS NOT NULL)
			BEGIN
				UPDATE	[CAMT].[FileLog]
				SET		FileStatus = 'Duplicate'	
				WHERE	[FileID] = @piFileID	
			END
			
		END
		ELSE
			BEGIN
				UPDATE	[CAMT].[FileLog]
				SET		FileStatus = 'EmptyFile'	
				WHERE	[FileID] = @piFileID
		END

		IF OBJECT_ID('tempdb..#Results') IS NOT NULL
			DROP TABLE ##Results
		IF OBJECT_ID('tempdb..#Record') IS NOT NULL
			DROP TABLE #Record

	END TRY
	
	BEGIN CATCH
		SELECT  @vsErrorProcedure = ERROR_PROCEDURE() 
			,@vsErrorMessage = ERROR_MESSAGE()
		RAISERROR(50003, 16, 1, @vsErrorProcedure, @vsStepName, @vsErrorMessage)
		SET	@viReturnValue = 1

		IF OBJECT_ID('tempdb..#Results') IS NOT NULL
		DROP TABLE #Results

		IF OBJECT_ID('tempdb..#Record') IS NOT NULL
			DROP TABLE #Record

	END CATCH

	RETURN (@viReturnValue)
END
GO

