MERGE INTO [dbo].[RITCJournalsDetail] AS Target

USING 
	(VALUES
				
				(16,'1133001 - RITC Net Ultimate Premium','10350',-1,'3623','5623','Tracker',NULL,NULL),--9C
				(16,'1133001 - RITC Net Ultimate Premium','74400',1,'3623','5623','Tracker',NULL,NULL),--9C
				(17,'1143004 - RITC Net Paid Claims','20110',1,'3623','5623','Tracker',NULL,NULL),
				(17,'1143004 - RITC Net Paid Claims','74409',-1,'3623','5623','Tracker',NULL,NULL),
				(18,'1143003 - RITC Net Outstanding Claims','22400',1,'3623','5623','Tracker',NULL,NULL),
				(18,'1143003 - RITC Net Outstanding Claims','80310',-1,'3623','5623','Tracker',NULL,NULL),
				(26,'1133002 - RITC Net Signed Premium','74400',-1,'3623','5623','Tracker',NULL,NULL),
				(26,'1133002 - RITC Net Signed Premium','74408',1,'3623','5623','Tracker',NULL,NULL),
				(19,'1143005 - RITC Net IBNR Claims','22250',-1,'3623','5623','Tracker',NULL,NULL),--9K
				(19,'1143005 - RITC Net IBNR Claims','80320',1,'3623','5623','Tracker',NULL,NULL)--9K


)

AS Source ([fk_RITCJournal],[SourceAccount],[PostingAccount],[Multiplier],[SourceEntity],[DestinationEntity],[SpecialGroupFilter],[SpecialIncludeFilter],[SpecialExcludeFilter])		
	ON (
			Target.[fk_RITCJournal]					= Source.[fk_RITCJournal] 
		AND Target.[SourceAccount]					= Source.[SourceAccount] 
		AND Target.[PostingAccount]					= Source.[PostingAccount] 
		AND Target.[Multiplier]						= Source.[Multiplier] 
		AND ISNULL(Target.[SourceEntity],'')		= ISNULL(Source.[SourceEntity],'')
		AND ISNULL(Target.[DestinationEntity],'')	= ISNULL(Source.[DestinationEntity],'') 
	)

	WHEN MATCHED AND (
						ISNULL(Target.[SpecialGroupFilter],'') <> ISNULL(Source.[SpecialGroupFilter],'') OR 
						ISNULL(Target.[SpecialIncludeFilter],'') <> ISNULL(Source.[SpecialIncludeFilter],'') OR 
						ISNULL(Target.[SpecialExcludeFilter],'') <> ISNULL(Source.[SpecialExcludeFilter],'')
					 )
		
	THEN UPDATE SET [SpecialGroupFilter]   = Source.[SpecialGroupFilter],
					[SpecialIncludeFilter] = Source.[SpecialIncludeFilter],
					[SpecialExcludeFilter] = Source.[SpecialExcludeFilter]
          
	WHEN NOT MATCHED BY TARGET THEN
		INSERT 
			( 
			  [fk_RITCJournal]
			, [SourceAccount]
			, [PostingAccount]
			, [Multiplier]
			, [SourceEntity]
			, [DestinationEntity]
			, [SpecialGroupFilter]
			, [SpecialIncludeFilter]
			, [SpecialExcludeFilter]
			)
		VALUES 
			(
			  Source.[fk_RITCJournal]
			, Source.[SourceAccount]
			, Source.[PostingAccount]
			, Source.[Multiplier]
			, Source.[SourceEntity]
			, Source.[DestinationEntity]
			, Source.[SpecialGroupFilter]
			, Source.[SpecialIncludeFilter]
			, Source.[SpecialExcludeFilter]
			)
	;
			
	DECLARE 
		 @mergeError INT                                                                                                                                                                                  
       , @mergeCount INT ;                                                                                                                                                                                       
	
	SELECT 
		  @mergeError = @@ERROR
		, @mergeCount = @@ROWCOUNT                                                                                                                                                   
	IF @mergeError != 0                                                                                                                                                                                      
		BEGIN                                                                                                                                                                                                   
			PRINT 'ERROR OCCURRED IN MERGE FOR [dbo].[OYActualsJournalDetails]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100));                          
		END                                                                                                                                                                                                     
	ELSE                                                                                                                                                                                                     
		 BEGIN                                                                                                                                                                                                   
			PRINT '[dbo].[OYActualsJournalDetails] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));                                                                                              
		 END                                                                                                                                                                                                     
	GO
	
	;