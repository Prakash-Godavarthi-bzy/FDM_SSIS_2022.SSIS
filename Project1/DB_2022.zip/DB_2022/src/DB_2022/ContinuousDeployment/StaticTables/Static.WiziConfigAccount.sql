
BEGIN TRY;
	DECLARE @WiziConfigAccount TABLE
	(
	[WiziConfigAccountID] [int] NOT NULL,
	[FDMAccountName] [nvarchar](255) NULL,
	[WiziAccountGroup] [nvarchar](255) NULL,
	[WiziAccountName] [nvarchar](255) NULL,
	[WiziRefreshFrequency] [int] NULL,
	[WiziClosedYOARefreshFrequency] [int] NULL,
	[RITCMonthOffset] [int] NULL,
	[WiziMultiplier] [int] NULL,
	[Calculation] [nvarchar](255) NULL,
	[CalculationSequence] [smallint] NULL
	)

	INSERT @WiziConfigAccount(WiziConfigAccountID,FDMAccountName,WiziAccountGroup,WiziAccountName,WiziRefreshFrequency,WiziClosedYOARefreshFrequency,RITCMonthOffset,WiziMultiplier,Calculation,CalculationSequence)
	VALUES 
( 1 , '1111001 - Wizi Gross Ultimate Premium' , 'Syndicates' , 'Uwer_Gross_Prem' , 3 , 3 , -3 , -1000000 , NULL , NULL ) ,
( 2 , '1111002 - Wizi Gross Signed Premium' , 'Syndicates' , 'Premium_Gross' , 1 , 3 , -1 , -1 , NULL , NULL ) ,
( 3 , '1111003 - Wizi Gross Future Premium' , 'Calculation' , NULL , NULL , NULL , NULL , 1 , '1111001 - Wizi Gross Ultimate Premium' , 1 ) ,
( 4 , '1111003 - Wizi Gross Future Premium' , 'Calculation' , NULL , NULL , NULL , NULL , -1 , '1111002 - Wizi Gross Signed Premium' , 1 ) ,
( 5 , '1112001 - Wizi Ultimate RI Premium' , 'Calculation' , NULL , NULL , NULL , NULL , 1 , '1113001 - Wizi Net Ultimate Premium' , 1 ) ,
( 6 , '1112001 - Wizi Ultimate RI Premium' , 'Calculation' , NULL , NULL , NULL , NULL , -1 , '1111001 - Wizi Gross Ultimate Premium' , 1 ) ,
( 7 , '1112002 - Wizi Signed RI Premium' , 'Calculation' , NULL , NULL , NULL , NULL , 1 , '1113002 - Wizi Net Signed Premium' , 1 ) ,
( 8 , '1112002 - Wizi Signed RI Premium' , 'Calculation' , NULL , NULL , NULL , NULL , -1 , '1111002 - Wizi Gross Signed Premium' , 1 ) ,
( 9 , '1112003 - Wizi RI Future Premium' , 'Calculation' , NULL , NULL , NULL , NULL , 1 , '1112001 - Wizi Ultimate RI Premium' , 2 ) ,
( 10 , '1112003 - Wizi RI Future Premium' , 'Calculation' , NULL , NULL , NULL , NULL , 1 , '1112002 - Wizi Signed RI Premium' , 2 ) ,
( 11 , '1113001 - Wizi Net Ultimate Premium' , 'Syndicates' , 'Uwer_Net_Prem' , 3 , 3 , -3 , -1000000 , NULL , NULL ) ,
( 12 , '1113002 - Wizi Net Signed Premium' , 'Syndicates' , 'Premium_Net' , 1 , 3 , -1 , -1 , NULL , NULL ) ,
( 13 , '1113003 - Wizi Net Future Premium' , 'Calculation' , NULL , NULL , NULL , NULL , 1 , '1113001 - Wizi Net Ultimate Premium' , 1 ) ,
( 14 , '1113003 - Wizi Net Future Premium' , 'Calculation' , NULL , NULL , NULL , NULL , -1 , '1113002 - Wizi Net Signed Premium' , 1 ) ,
( 15 , '1121001 - Wizi Gross Ultimate Claims' , 'Syndicates' , 'Uwer_Gross_Inc' , 3 , 3 , -3 , 1000000 , NULL , NULL ) ,
( 16 , '1121002 - Wizi Gross Inc Claims' , 'Syndicates' , 'Inc_Gross' , 1 , 3 , -1 , 1 , NULL , NULL ) ,
( 17 , '1121003 - Wizi Gross Outstanding Claims' , 'Calculation' , NULL , NULL , NULL , NULL , 1 , '1121002 - Wizi Gross Inc Claims' , 1 ) ,
( 18 , '1121003 - Wizi Gross Outstanding Claims' , 'Calculation' , NULL , NULL , NULL , NULL , -1 , '1121004 - Wizi Gross Paid Claims' , 1 ) ,
( 19 , '1121004 - Wizi Gross Paid Claims' , 'Syndicates' , 'Paid_Gross' , 1 , 3 , -1 , 1 , NULL , NULL ) ,
( 20 , '1121005 - Wizi Gross IBNR Claims' , 'Calculation' , NULL , NULL , NULL , NULL , 1 , '1121001 - Wizi Gross Ultimate Claims' , 1 ) ,
( 21 , '1121005 - Wizi Gross IBNR Claims' , 'Calculation' , NULL , NULL , NULL , NULL , -1 , '1121002 - Wizi Gross Inc Claims' , 1 ) ,
( 22 , '1122001 - Wizi RI Ultimate Claims' , 'Calculation' , NULL , NULL , NULL , NULL , 1 , '1123001 - Wizi Net Ultimate Claims' , 1 ) ,
( 23 , '1122001 - Wizi RI Ultimate Claims' , 'Calculation' , NULL , NULL , NULL , NULL , -1 , '1121001 - Wizi Gross Ultimate Claims' , 1 ) ,
( 24 , '1122002 - Wizi RI Inc Claims' , 'Calculation' , NULL , NULL , NULL , NULL , 1 , '1123002 - Wizi Net Inc Claims' , 1 ) ,
( 25 , '1122002 - Wizi RI Inc Claims' , 'Calculation' , NULL , NULL , NULL , NULL , -1 , '1121002 - Wizi Gross Inc Claims' , 1 ) ,
( 26 , '1122003 - Wizi RI Outstanding Claims' , 'Calculation' , NULL , NULL , NULL , NULL , 1 , '1123003 - Wizi Net Outstanding Claims' , 2 ) ,
( 27 , '1122003 - Wizi RI Outstanding Claims' , 'Calculation' , NULL , NULL , NULL , NULL , -1 , '1121003 - Wizi Gross Outstanding Claims' , 2 ) ,
( 28 , '1122004 - Wizi RI Paid Claims' , 'Calculation' , NULL , NULL , NULL , NULL , 1 , '1123004 - Wizi Net Paid Claims' , 1 ) ,
( 29 , '1122004 - Wizi RI Paid Claims' , 'Calculation' , NULL , NULL , NULL , NULL , -1 , '1121004 - Wizi Gross Paid Claims' , 1 ) ,
( 30 , '1122005 - Wizi RI IBNR Claims' , 'Calculation' , NULL , NULL , NULL , NULL , 1 , '1122001 - Wizi RI Ultimate Claims' , 2 ) ,
( 31 , '1122005 - Wizi RI IBNR Claims' , 'Calculation' , NULL , NULL , NULL , NULL , -1 , '1122002 - Wizi RI Inc Claims' , 2 ) ,
( 33 , '1123001 - Wizi Net Ultimate Claims' , 'Syndicates' , 'Uwer_Net_Inc' , 3 , 3 , -3 , '1000000' , NULL , NULL ) ,
( 34 , '1123002 - Wizi Net Inc Claims' , 'Syndicates' , 'Inc_Net' , 1 , 3 , -1 , 1 , NULL , NULL ) ,
( 35 , '1123003 - Wizi Net Outstanding Claims' , 'Calculation' , NULL , NULL , NULL , NULL , 1 , '1123002 - Wizi Net Inc Claims' , 1 ) ,
( 36 , '1123003 - Wizi Net Outstanding Claims' , 'Calculation' , NULL , NULL , NULL , NULL , -1 , '1123004 - Wizi Net Paid Claims' , 1 ) ,
( 37 , '1123004 - Wizi Net Paid Claims' , 'Syndicates' , 'Paid_Net' , 1 , 3 , -1 , 1 , NULL , NULL ) ,
( 38 , '1123005 - Wizi Net IBNR Claims' , 'Calculation' , NULL , NULL , NULL , NULL , 1 , '1123001 - Wizi Net Ultimate Claims' , 1 ) ,
( 39 , '1123005 - Wizi Net IBNR Claims' , 'Calculation' , NULL , NULL , NULL , NULL , -1 , '1123002 - Wizi Net Inc Claims' , 1 ) ,
( 40 , '1112004 - Wizi Signed RI ORC' , 'Syndicates' , 'ORC' , 1 , 1 , -1 , 1 , NULL , NULL ) ,
( 41 , '1113004 - Wizi Signed Net ORC' , 'Syndicates' , 'ORC' , 1 , 1 , -1 , 1 , NULL , NULL ) ,
( 42 , '1112005 - Wizi RI Premium Ex ORC' , 'Calculation' , NULL , NULL , NULL , NULL , 1 , '1112002 - Wizi Signed RI Premium' , 2 ) ,
( 43 , '1112005 - Wizi RI Premium Ex ORC' , 'Calculation' , NULL , NULL , NULL , NULL , -1 , '1112004 - Wizi Signed RI ORC' , 2 ) ,
( 44 , '1113005 - Wizi Net Premium Ex ORC' , 'Calculation' , NULL , NULL , NULL , NULL , 1 , '1113002 - Wizi Net Signed Premium' , 1 ) ,
( 45 , '1113005 - Wizi Net Premium Ex ORC' , 'Calculation' , NULL , NULL , NULL , NULL , -1 , '1113004 - Wizi Signed Net ORC' , 1 )

	MERGE [dbo].[WiziConfigAccount] AS TGT
	USING @WiziConfigAccount AS SRC

	ON (
		ISNULL(TGT.WiziConfigAccountID,0) = ISNULL(SRC.WiziConfigAccountID,0) AND
		ISNULL(TGT.FDMAccountName,'') = ISNULL(SRC.FDMAccountName,'') AND
		ISNULL(TGT.WiziAccountGroup,'') = ISNULL(SRC.WiziAccountGroup,'') AND
		ISNULL(TGT.WiziAccountName,'') = ISNULL(SRC.WiziAccountName,'') AND
		ISNULL(TGT.WiziRefreshFrequency,0) = ISNULL(SRC.WiziRefreshFrequency,0) AND
		ISNULL(TGT.WiziClosedYOARefreshFrequency,0) = ISNULL(SRC.WiziClosedYOARefreshFrequency,0) AND
		ISNULL(TGT.RITCMonthOffset,0) = ISNULL(SRC.RITCMonthOffset,0)
	)
	

	WHEN MATCHED AND
				ISNULL(TGT.WiziMultiplier,0) <> ISNULL(SRC.WiziMultiplier,0)
				OR ISNULL(TGT.Calculation,'') <> ISNULL(SRC.Calculation,'')
				OR ISNULL(TGT.CalculationSequence,0) <> ISNULL(SRC.CalculationSequence,0)

	THEN

		  UPDATE SET TGT.WiziMultiplier = SRC.WiziMultiplier,
					TGT.Calculation=SRC.Calculation,
					TGT.CalculationSequence=SRC.CalculationSequence

           
	WHEN NOT MATCHED BY TARGET THEN

		  insert (FDMAccountName,WiziAccountGroup,WiziAccountName,WiziRefreshFrequency,WiziClosedYOARefreshFrequency,RITCMonthOffset,WiziMultiplier,Calculation,CalculationSequence)

		  values (FDMAccountName,WiziAccountGroup,WiziAccountName,WiziRefreshFrequency,WiziClosedYOARefreshFrequency,RITCMonthOffset,WiziMultiplier,Calculation,CalculationSequence)
;
END TRY

BEGIN CATCH;

	IF @@TRANCOUNT > 0
		ROLLBACK;

	THROW;

END CATCH;