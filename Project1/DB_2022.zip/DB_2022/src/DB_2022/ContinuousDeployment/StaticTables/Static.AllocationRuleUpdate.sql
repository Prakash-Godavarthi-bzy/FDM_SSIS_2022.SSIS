﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
IF NOT EXISTS (SELECT 1 FROM dbo.DimAllocationRules WHERE PK_Alt_AllocationRules IS NOT NULL)
	--IF EXISTS (SELECT 1 FROM dbo.DimAllocationRules WHERE PK_Alt_AllocationRules IS NULL)
	BEGIN
		--/******************************************************************************
		--Update PK_Alt_AllocationRules with existing allocation rule id
		--*******************************************************************************/
		UPDATE dbo.DimAllocationRules
		   SET PK_Alt_AllocationRules = PK_AllocationRules
		 WHERE PK_Alt_AllocationRules IS NULL

		--/******************************************************************************
		--Update Sub Version with 1 for existing allocation rules
		--*******************************************************************************/
		UPDATE dbo.DimAllocationRules
		   SET AllocationGroupCodeSubVersion = 1
		 WHERE ISNULL(AllocationGroupCodeSubVersion,0) = 0

		--/******************************************************************************
		--Update change Type with 'No Change' for existing allocation rules
		--*******************************************************************************/
		UPDATE dbo.DimAllocationRules
		   SET ChangeType = 'No Change'
		   WHERE ChangeType IS NULL

		----/******************************************************************************
		----Generate and update RowHash for existing allocation rules
		----*******************************************************************************/

		UPDATE dbo.DimAllocationRules
		   SET RowHash = HASHBYTES('SHA2_512',CONCAT(AccountFrom, 
								'§~§', AccountTo, 
								'§~§', TrifocusFrom, 
								'§~§', TrifocusTo, 
								'§~§', EntityFrom, 
								'§~§', EntityTo, 
								'§~§', LocationFrom, 
								'§~§', LocationTo, 
								'§~§', ProjectFrom, 
								'§~§', ProjectTo, 
								'§~§', YOAFrom, 
								'§~§', YOATo, 
								'§~§', ProcessFrom, 
								'§~§', ProcessTo, 
								'§~§', TargetEntityFrom, 
								'§~§', TargetEntityTo,
								'§~§', GranularityFlag,
								'§~§', AccountDest,
								'§~§', TrifocusDest,
								'§~§', EntityDest,
								'§~§', LocationDest,
								'§~§', ProjectDest,
								'§~§', YOADest,
								'§~§', ProcessDest,
								'§~§', TargetPeriodDest,
								'§~§', TargetEntityDest,
								'§~§', TargetCurrencyDest,
								--'§~§',StepCode,
								'§~§'))
		 WHERE RowHash  IS NULL
	END