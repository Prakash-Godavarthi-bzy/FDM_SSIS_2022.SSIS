﻿DECLARE @OverseasandASLConfig TABLE
(
	[Syndicate] [FLOAT]  NULL,
	[GL] [FLOAT]  NULL,
	[Description] [varchar](255)  NULL,
	[Currency] [varchar](255) NULL,
	[TAB Number] [FLOAT] NULL,
	[Notes] [varchar](255)  NULL,
	[DepositType] [varchar](255) NULL
	

)

INSERT @OverseasandASLConfig([Syndicate],[GL],[Description],[Currency],[TAB Number],[Notes],[DepositType])
VALUES 
(623,75510,'Kentucky Deposits','USD',775,'Oversea Deposit rec - quarterly only','Overseas'),
(623,75520,'Kentucky JATF','USD',753,'Oversea Deposit rec - quarterly only','Overseas'),
(623,75540,'Illinois Deposit','USD',738,'Oversea Deposit rec - quarterly only','Overseas'),
(623,75550,'CRTF - JATF','USD',805,'Oversea Deposit rec - quarterly only','Overseas'),
(623,75560,'SLTF - JATF','USD',806,'Oversea Deposit rec - quarterly only','Overseas'),
(623,75570,'South African Deposit','USD',708,'Oversea Deposit rec - quarterly only','Overseas'),
(623,75580,'Australian Deposit','USD',590,'Oversea Deposit rec - quarterly only','Overseas'),
(623,75590,'Australian JATF','USD',592,'Oversea Deposit rec - quarterly only','Overseas'),
(623,75600,'Canadian Margin Fund','CAD',757,'Oversea Deposit rec - quarterly only','Overseas'),
(623,75605,'Swiss ASL Investments','USD',471,'Oversea Deposit rec - quarterly only','Overseas'),
(623,75665,'ASL Australian','GBP',410,'ASL rec - quarterly only','ASL'),
(623,75666,'ASL Bahamas','USD',409,'ASL rec - quarterly only','ASL'),
(623,75667,'ASL Grenada','USD',407,'ASL rec - quarterly only','ASL'),
(623,75668,'ASL Hong Kong','GBP',406,'ASL rec - quarterly only','ASL'),
(623,75669,'ASL Lloyds Asia','GBP',401,'ASL rec - quarterly only','ASL'),
(623,75670,'ASL Namiibia','GBP',405,'ASL rec - quarterly only','ASL'),
(623,75671,'ASL Singapore','GBP',400,'ASL rec - quarterly only','ASL'),
(623,75672,'ASL St.Vincent','USD',404,'ASL rec - quarterly only','ASL'),
(623,75673,'ASL Trinadad & Tobago','USD',403,'ASL rec - quarterly only','ASL'),
(623,75674,'ASL Brazil','USD',408,'ASL rec - quarterly only','ASL'),
(623,75675,'ASL Caymans','USD',402,'ASL rec - quarterly only','ASL'),
(2623,75510,'Kentucky Deposits','USD',775,'Oversea Deposit rec - quarterly only','Overseas'),
(2623,75520,'Kentucky JATF','USD',753,'Oversea Deposit rec - quarterly only','Overseas'),
(2623,75540,'Illinois Deposit','USD',738,'Oversea Deposit rec - quarterly only','Overseas'),
(2623,75550,'CRTF - JATF','USD',805,'Oversea Deposit rec - quarterly only','Overseas'),
(2623,75560,'SLTF - JATF','USD',806,'Oversea Deposit rec - quarterly only','Overseas'),
(2623,75570,'South African Deposit','USD',708,'Oversea Deposit rec - quarterly only','Overseas'),
(2623,75580,'Australian Deposit','USD',590,'Oversea Deposit rec - quarterly only','Overseas'),
(2623,75590,'Australian JATF','USD',592,'Oversea Deposit rec - quarterly only','Overseas'),
(2623,75600,'Canadian Margin Fund','CAD',757,'Oversea Deposit rec - quarterly only','Overseas'),
(2623,75605,'Swiss ASL Investments','USD',471,'Oversea Deposit rec - quarterly only','Overseas'),
(2623,75665,'ASL Australian','GBP',410,'ASL rec - quarterly only','ASL'),
(2623,75666,'ASL Bahamas','USD',409,'ASL rec - quarterly only','ASL'),
(2623,75667,'ASL Grenada','USD',407,'ASL rec - quarterly only','ASL'),
(2623,75668,'ASL Hong Kong','GBP',406,'ASL rec - quarterly only','ASL'),
(2623,75669,'ASL Lloyds Asia','GBP',401,'ASL rec - quarterly only','ASL'),
(2623,75670,'ASL Namiibia','GBP',405,'ASL rec - quarterly only','ASL'),
(2623,75671,'ASL Singapore','GBP',400,'ASL rec - quarterly only','ASL'),
(2623,75672,'ASL St.Vincent','USD',404,'ASL rec - quarterly only','ASL'),
(2623,75673,'ASL Trinadad & Tobago','USD',403,'ASL rec - quarterly only','ASL'),
(2623,75674,'ASL Brazil','USD',408,'ASL rec - quarterly only','ASL'),
(2623,75675,'ASL Caymans','USD',402,'ASL rec - quarterly only','ASL'),
(3622,75605,'Swiss ASL Investments','USD',471,'Oversea Deposit rec - quarterly only','Overseas'),
(3622,75666,'ASL Bahamas','USD',409,'ASL rec - quarterly only','ASL'),
(3622,75675,'ASL Caymans','USD',402,'ASL rec - quarterly only','ASL'),
(3623,75510,'Kentucky Deposits','USD',775,'Oversea Deposit rec - quarterly only','Overseas'),
(3623,75520,'Kentucky JATF','USD',753,'Oversea Deposit rec - quarterly only','Overseas'),
(3623,75540,'Illinois Deposit','USD',738,'Oversea Deposit rec - quarterly only','Overseas'),
(3623,75550,'CRTF - JATF','USD',805,'Oversea Deposit rec - quarterly only','Overseas'),
(3623,75560,'SLTF - JATF','USD',806,'Oversea Deposit rec - quarterly only','Overseas'),
(3623,75570,'South African Deposit','USD',708,'Oversea Deposit rec - quarterly only','Overseas'),
(3623,75580,'Australian Deposit','USD',590,'Oversea Deposit rec - quarterly only','Overseas'),
(3623,75590,'Australian JATF','USD',592,'Oversea Deposit rec - quarterly only','Overseas'),
(3623,75600,'Canadian Margin Fund','CAD',757,'Oversea Deposit rec - quarterly only','Overseas'),
(3623,75605,'Swiss ASL Investments','USD',471,'Oversea Deposit rec - quarterly only','Overseas'),
(3623,75665,'ASL Australian','GBP',410,'ASL rec - quarterly only','ASL'),
(3623,75666,'ASL Bahamas','USD',409,'ASL rec - quarterly only','ASL'),
(3623,75667,'ASL Grenada','USD',407,'ASL rec - quarterly only','ASL'),
(3623,75670,'ASL Namibia','GBP',405,'ASL rec - quarterly only','ASL'),
(3623,75671,'ASL Singapore','GBP',400,'ASL rec - quarterly only','ASL'),
(3623,75673,'ASL Trinadad & Tobago','USD',403,'ASL rec - quarterly only','ASL'),
(3623,75674,'ASL Brazil','USD',408,'ASL rec - quarterly only','ASL'),
(3623,75675,'ASL Caymans','USD',402,'ASL rec - quarterly only','ASL'),
(3623,75672,'ASL St Vincent','USD',404,'ASL rec - quarterly only','ASL'),
(3623,75668,'ASL Hong Kong','GBP',406,'ASL rec - quarterly only','ASL'),
(4321,75510,'Kentucky Deposits','USD',775,'Oversea Deposit rec - quarterly only','Overseas'),
(4321,75520,'Kentucky JATF','USD',753,'Oversea Deposit rec - quarterly only','Overseas'),
(4321,75540,'Illinois Deposit','USD',738,'Oversea Deposit rec - quarterly only','Overseas'),
(4321,75550,'CRTF - JATF','USD',805,'Oversea Deposit rec - quarterly only','Overseas'),
(4321,75560,'SLTF - JATF','USD',806,'Oversea Deposit rec - quarterly only','Overseas'),
(4321,75570,'South African Deposit','USD',708,'Oversea Deposit rec - quarterly only','Overseas'),
(4321,75580,'Australian Deposit','USD',590,'Oversea Deposit rec - quarterly only','Overseas'),
(4321,75590,'Australian JATF','USD',592,'Oversea Deposit rec - quarterly only','Overseas'),
(4321,75600,'Canadian Margin Fund','CAD',757,'Oversea Deposit rec - quarterly only','Overseas'),
(4321,75605,'Swiss ASL Investments','USD',471,'Oversea Deposit rec - quarterly only','Overseas'),
(4321,75665,'ASL Australian','GBP',410,'ASL rec - quarterly only','ASL'),
(4321,75666,'ASL Bahamas','USD',409,'ASL rec - quarterly only','ASL'),
(4321,75667,'ASL Grenada','USD',407,'ASL rec - quarterly only','ASL'),
(4321,75668,'ASL Hong Kong','GBP',406,'ASL rec - quarterly only','ASL'),
(4321,75669,'ASL Lloyds Asia','GBP',401,'ASL rec - quarterly only','ASL'),
(4321,75670,'ASL Namiibia','GBP',405,'ASL rec - quarterly only','ASL'),
(4321,75671,'ASL Singapore','GBP',400,'ASL rec - quarterly only','ASL'),
(4321,75672,'ASL St.Vincent','USD',404,'ASL rec - quarterly only','ASL'),
(4321,75673,'ASL Trinadad & Tobago','USD',403,'ASL rec - quarterly only','ASL'),
(4321,75674,'ASL Brazil','USD',408,'ASL rec - quarterly only','ASL'),
(4321,75675,'ASL Caymans','USD',402,'ASL rec - quarterly only','ASL'),
(5623,75510,'Kentucky Deposits','USD',775,'Oversea Deposit rec - quarterly only','Overseas'),
(5623,75520,'Kentucky JATF','USD',753,'Oversea Deposit rec - quarterly only','Overseas'),
(5623,75540,'Illinois Deposit','USD',738,'Oversea Deposit rec - quarterly only','Overseas'),
(5623,75550,'CRTF - JATF','USD',805,'Oversea Deposit rec - quarterly only','Overseas'),
(5623,75560,'SLTF - JATF','USD',806,'Oversea Deposit rec - quarterly only','Overseas'),
(5623,75570,'South African Deposit','USD',708,'Oversea Deposit rec - quarterly only','Overseas'),
(5623,75580,'Australian Deposit','USD',590,'Oversea Deposit rec - quarterly only','Overseas'),
(5623,75590,'Australian JATF','USD',592,'Oversea Deposit rec - quarterly only','Overseas'),
(5623,75600,'Canadian Margin Fund','CAD',757,'Oversea Deposit rec - quarterly only','Overseas'),
(5623,75605,'Swiss ASL Investments','USD',471,'Oversea Deposit rec - quarterly only','Overseas'),
(5623,75665,'ASL Australian','GBP',410,'ASL rec - quarterly only','ASL'),
(5623,75666,'ASL Bahamas','USD',409,'ASL rec - quarterly only','ASL'),
(5623,75667,'ASL Grenada','USD',407,'ASL rec - quarterly only','ASL'),
(5623,75668,'ASL Hong Kong','GBP',406,'ASL rec - quarterly only','ASL'),
(5623,75669,'ASL Lloyds Asia','GBP',401,'ASL rec - quarterly only','ASL'),
(5623,75670,'ASL Namiibia','GBP',405,'ASL rec - quarterly only','ASL'),
(5623,75671,'ASL Singapore','GBP',400,'ASL rec - quarterly only','ASL'),
(5623,75672,'ASL St.Vincent','USD',404,'ASL rec - quarterly only','ASL'),
(5623,75673,'ASL Trinadad & Tobago','USD',403,'ASL rec - quarterly only','ASL'),
(5623,75674,'ASL Brazil','USD',408,'ASL rec - quarterly only','ASL'),
(5623,75675,'ASL Caymans','USD',402,'ASL rec - quarterly only','ASL')
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


MERGE [FDM_DB].[dbo].[OverseasandASLConfig] AS TGT
USING @OverseasandASLConfig AS SRC

ON (

		ISNULL(TGT.[Syndicate],'') = ISNULL(SRC.[Syndicate],'') AND
		--ISNULL(TGT.[GL],'') = ISNULL(SRC.[GL],'') AND
		ISNULL(TGT.[Description],'') = ISNULL(SRC.[Description],'') AND
		ISNULL(TGT.[Currency],'') = ISNULL(SRC.[Currency],'') AND
		ISNULL(TGT.[TAB Number],'') = ISNULL(SRC.[TAB Number],'') AND
		ISNULL(TGT.[Notes],'') = ISNULL(SRC.[Notes],'') AND
		ISNULL(TGT.[DepositType],'') = ISNULL(SRC.[DepositType],'') 

)
WHEN MATCHED AND

		ISNULL(TGT.[Syndicate],'') <> ISNULL(SRC.[Syndicate],'') OR
		ISNULL(TGT.[GL],'') <> ISNULL(SRC.[GL],'') OR
		ISNULL(TGT.[Description],'') <> ISNULL(SRC.[Description],'') OR
		ISNULL(TGT.[Currency],'') <> ISNULL(SRC.[Currency],'') OR
		ISNULL(TGT.[TAB Number],'') <> ISNULL(SRC.[TAB Number],'') OR
		ISNULL(TGT.[Notes],'') <> ISNULL(SRC.[Notes],'') OR
		ISNULL(TGT.[DepositType],'') <> ISNULL(SRC.[DepositType],'') 

THEN

      UPDATE SET TGT.[Syndicate] = SRC.[Syndicate],
				 TGT.[GL] = SRC.[GL],
				 TGT.[Description] = SRC.[Description],
				 TGT.[Currency] = SRC.[Currency],
				 TGT.[TAB Number] = SRC.[TAB Number],
				 TGT.[Notes] = SRC.[Notes],
				 TGT.[DepositType] = SRC.[DepositType]
				 

WHEN NOT MATCHED BY TARGET THEN

      INSERT ([Syndicate],[GL],[Description],[Currency],[TAB Number],[Notes],[DepositType])
      VALUES ([Syndicate],[GL],[Description],[Currency],[TAB Number],[Notes],[DepositType])
	  ;