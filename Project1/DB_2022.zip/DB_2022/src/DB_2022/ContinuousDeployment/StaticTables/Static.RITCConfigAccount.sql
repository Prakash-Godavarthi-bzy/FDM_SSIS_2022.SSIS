MERGE INTO [dbo].[RITCConfigAccount] AS Target

USING 
	(VALUES
				
('1143003 - RITC Net Outstanding Claims','Wizi','1123003 - Wizi Net Outstanding Claims','IN(''3623'')','NOT IN (''ZZZZZZ'')','IN (''TRACKER'')',NULL,NULL,NULL,-1,NULL,NULL,NULL),--9C
('1133001 - RITC Net Ultimate Premium','Wizi','1113001 - Wizi Net Ultimate Premium','IN(''3623'')','NOT IN (''ZZZZZZ'')','IN (''TRACKER'')',NULL,'Yes',NULL,1,NULL,NULL,NULL),
('1143004 - RITC Net Paid Claims','Wizi','1123004 - Wizi Net Paid Claims','IN (''3623'')','NOT IN (''ZZZZZZ'')','IN (''TRACKER'')',NULL,NULL,NULL,-1,NULL,NULL,NULL),
('1133002 - RITC Net Signed Premium','Wizi','1113002 - Wizi Net Signed Premium','IN (''3623'')','NOT IN (''ZZZZZZ'')','IN (''TRACKER'')',NULL,NULL,NULL,1,NULL,NULL,NULL),
('1143005 - RITC Net IBNR Claims','Wizi','1123005 - Wizi Net IBNR Claims','IN (''3623'')','NOT IN (''ZZZZZZ'')','IN (''TRACKER'')',NULL,'Yes',NULL,1,NULL,NULL,NULL)--9K
)


AS Source ([AccountName],[RITCAccountGroup],[SourceAccountName],[EntityFilter],[SpecialFilter],[SpecialGroupFilter],[CNVRule],
			[LTDCaculation],[Calculation],[Multiplier],[AllocationRule],[CalcRule],[IntermediateCNV])		
	ON (
						ISNULL(Target.[AccountName],'')			=		ISNULL(Source.[AccountName],'')
		AND				ISNULL(Target.[RITCAccountGroup],'')	=		ISNULL(Source.[RITCAccountGroup],'')
		AND				ISNULL(Target.[SourceAccountName],'')	=		ISNULL(Source.[SourceAccountName],'')
		AND				ISNULL(Target.[EntityFilter],'')		=		ISNULL(Source.[EntityFilter],'')
		AND				ISNULL(Target.[SpecialGroupFilter],'')	=		ISNULL(Source.[SpecialGroupFilter],'') 
	)

	WHEN MATCHED AND (
						ISNULL(Target.[SpecialFilter],'')		<>		ISNULL(Source.[SpecialFilter],'') OR 
						ISNULL(Target.[CNVRule],'')				<>		ISNULL(Source.[CNVRule],'') OR 
						ISNULL(Target.[LTDCaculation],'')		<>		ISNULL(Source.[LTDCaculation],'') OR
						ISNULL(Target.[Calculation],'')			<>		ISNULL(Source.[Calculation],'') OR
						ISNULL(Target.[Multiplier],0)			<>		ISNULL(Source.[Multiplier],0) OR
						ISNULL(Target.[AllocationRule],'')		<>		ISNULL(Source.[AllocationRule],'') OR
						ISNULL(Target.[CalcRule],'')			<>		ISNULL(Source.[CalcRule],'') OR
						ISNULL(Target.[IntermediateCNV],'')		<>		ISNULL(Source.[IntermediateCNV],'') 


					 )
		
	THEN UPDATE SET	[SpecialFilter]	=	Source.[SpecialFilter],
					[CNVRule]			=	Source.[CNVRule],
					[LTDCaculation]		=	Source.[LTDCaculation],
					[Calculation]		=	Source.[Calculation],
					[Multiplier]		=	Source.[Multiplier],
					[AllocationRule]	=	Source.[AllocationRule],
					[CalcRule]			=	Source.[CalcRule],
					[IntermediateCNV]	=	Source.[IntermediateCNV]

          
	WHEN NOT MATCHED BY TARGET THEN
		INSERT 
			( 
			  [AccountName]
			, [RITCAccountGroup]
			, [SourceAccountName]
			, [EntityFilter]
			, [SpecialFilter]
			, [SpecialGroupFilter]
			, [CNVRule]
			, [LTDCaculation]
			, [Calculation]
			, [Multiplier]
			, [AllocationRule]
			, [CalcRule]
			, [IntermediateCNV]
			)
		VALUES 
			(
			  Source.[AccountName]
			, Source.[RITCAccountGroup]
			, Source.[SourceAccountName]
			, Source.[EntityFilter]
			, Source.[SpecialFilter]
			, Source.[SpecialGroupFilter]
			, Source.[CNVRule]
			, Source.[LTDCaculation]
			, Source.[Calculation]
			, Source.[Multiplier]
			, Source.[AllocationRule]
			, Source.[CalcRule]
			, Source.[IntermediateCNV]
			)
	;
			
	DECLARE 
		 @mergeError INT                                                                                                                                                                                  
       , @mergeCount INT ;                                                                                                                                                                                       
	
	SELECT 
		  @mergeError = @@ERROR
		, @mergeCount = @@ROWCOUNT                                                                                                                                                   
	IF @mergeError != 0                                                                                                                                                                                      
		BEGIN                                                                                                                                                                                                   
			PRINT 'ERROR OCCURRED IN MERGE FOR [dbo].[OYActualsJournalDetails]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100));                          
		END                                                                                                                                                                                                     
	ELSE                                                                                                                                                                                                     
		 BEGIN                                                                                                                                                                                                   
			PRINT '[dbo].[OYActualsJournalDetails] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));                                                                                              
		 END                                                                                                                                                                                                     
	GO
	
	;