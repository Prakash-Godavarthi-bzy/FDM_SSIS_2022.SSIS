﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/



	/*===============Add/Call PostDeployment scripts here=============*/
	
	:r .\StaticTables\Static.OYActualsJournalDetails.sql
	:r .\StaticTables\Static.OverseasandASLConfig.sql
	:r .\StaticTables\Static.WiziConfigAccount.sql
	:r .\StaticTables\Static.AllocationRuleUpdate.sql
	:r .\StaticTables\Static.RITCConfigAccount.sql
	:r .\StaticTables\Static.RITCJournalDetail.sql
	
	
	
	

	
