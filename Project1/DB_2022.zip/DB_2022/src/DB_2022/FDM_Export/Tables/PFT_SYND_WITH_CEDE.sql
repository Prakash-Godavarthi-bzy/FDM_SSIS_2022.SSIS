﻿CREATE TABLE [FDM_Export].[PFT_SYND_WITH_CEDE] (
    [ExtractDate]      DATETIME        NULL,
    [PFTDate]          NVARCHAR (10)   NULL,
    [PremiumMonth]     INT             NULL,
    [Review Cycle]     NVARCHAR (255)  NULL,
    [MoP]              NVARCHAR (255)  NULL,
    [Tri Focus Name]   NVARCHAR (255)  NULL,
    [Tri Focus Code]   NVARCHAR (255)  NULL,
    [Department]       NVARCHAR (255)  NULL,
    [YOA]              NVARCHAR (255)  NULL,
    [Tran Curr]        NVARCHAR (255)  NULL,
    [Entity]           NVARCHAR (255)  NULL,
    [Platform]         NVARCHAR (255)  NULL,
    [Office Channel]   NVARCHAR (255)  NULL,
    [Synd Premium GIC] NUMERIC (18, 4) NULL,
    [Synd Premium NIC] NUMERIC (18, 4) NULL,
    [GGP]              NUMERIC (18, 4) NULL
);

