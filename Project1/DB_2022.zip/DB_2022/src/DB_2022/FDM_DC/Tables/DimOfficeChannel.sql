﻿CREATE TABLE [FDM_DC].[DimOfficeChannel] (
    [pk_OfficeChannel]  NVARCHAR (255) NOT NULL,
    [OfficeChannelName] NVARCHAR (255) NOT NULL,
    [Platform]          NVARCHAR (255) NOT NULL
);

