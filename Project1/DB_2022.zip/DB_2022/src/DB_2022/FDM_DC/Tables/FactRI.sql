﻿CREATE TABLE [FDM_DC].[FactRI] (
    [fk_YOA]                 INT             NULL,
    [fk_TriFocus]            NVARCHAR (255)  NULL,
    [fk_TransactionCurrency] NVARCHAR (255)  NULL,
    [fk_RIProgramme]         INT             NULL,
    [RIValue]                NUMERIC (24, 6) NULL,
    [fk_Version]             INT             NULL,
    [fk_ReviewCycle]         NVARCHAR (255)  NULL,
    [fk_Platform]            NVARCHAR (255)  NULL
);

