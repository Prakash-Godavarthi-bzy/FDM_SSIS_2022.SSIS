﻿CREATE TABLE [FDM_DC].[DimInceptionMonth] (
    [pk_InceptionMonth] INT            NOT NULL,
    [MonthName]         NVARCHAR (255) NULL
);

