﻿CREATE TABLE [FDM_DC].[FactVaildTriFocus] (
    [fk_ReviewCycle] NVARCHAR (255)  NULL,
    [fk_TriFocus]    NVARCHAR (255)  NULL,
    [Valid]          NUMERIC (18, 4) NULL
);

