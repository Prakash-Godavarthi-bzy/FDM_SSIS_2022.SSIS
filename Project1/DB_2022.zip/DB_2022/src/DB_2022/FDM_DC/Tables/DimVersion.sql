﻿CREATE TABLE [FDM_DC].[DimVersion] (
    [pk_Version]  INT            NOT NULL,
    [VersionName] NVARCHAR (255) NULL
);

