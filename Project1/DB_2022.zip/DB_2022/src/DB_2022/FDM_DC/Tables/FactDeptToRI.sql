﻿CREATE TABLE [FDM_DC].[FactDeptToRI] (
    [Department]     NVARCHAR (255) NULL,
    [fk_RIProgramme] INT            NULL,
    [fk_Platform]    NVARCHAR (255) NULL,
    [IsLink]         INT            NULL
);

