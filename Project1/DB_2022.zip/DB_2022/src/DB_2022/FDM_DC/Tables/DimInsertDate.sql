﻿CREATE TABLE [FDM_DC].[DimInsertDate] (
    [pk_InsertDate] NVARCHAR (255) NOT NULL
);

