﻿CREATE TABLE [FDM_DC].[FactTFToHost] (
    [fk_YOA]        INT             NULL,
    [fk_TriFocus]   NVARCHAR (255)  NULL,
    [fk_Host]       NVARCHAR (255)  NULL,
    [PcentTFToHost] NUMERIC (24, 6) NULL
);

