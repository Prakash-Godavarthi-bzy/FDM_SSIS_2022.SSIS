﻿CREATE TABLE [FDM_DC].[WriteTable_Map Host To Entity] (
    [PcentHostToEntity_0] FLOAT (53)     NULL,
    [pk_YOA_1]            INT            NULL,
    [pk_Host_2]           NVARCHAR (255) NULL,
    [pk_Entity_3]         NVARCHAR (255) NULL,
    [MS_AUDIT_TIME_4]     DATETIME       NULL,
    [MS_AUDIT_USER_5]     NVARCHAR (255) NULL
);

