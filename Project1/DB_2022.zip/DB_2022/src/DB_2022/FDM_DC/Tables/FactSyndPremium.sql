﻿CREATE TABLE [FDM_DC].[FactSyndPremium] (
    [fk_PolicyType]          NVARCHAR (255)  NULL,
    [fk_ReviewCycle]         NVARCHAR (255)  NULL,
    [fk_TriFocus]            NVARCHAR (255)  NULL,
    [fk_YOA]                 INT             NULL,
    [fk_OfficeChannel]       NVARCHAR (255)  NULL,
    [fk_InceptionMonth]      INT             NULL,
    [fk_Host]                NVARCHAR (255)  NULL,
    [fk_Entity]              NVARCHAR (255)  NULL,
    [UserID]                 NVARCHAR (255)  NULL,
    [fk_TransactionCurrency] NVARCHAR (255)  NULL,
    [fk_InsertDate]          NVARCHAR (255)  NULL,
    [GNP Inc IC]             NUMERIC (18, 4) NULL,
    [GGP]                    NUMERIC (18, 4) NULL,
    [GNP Exc IC]             NUMERIC (18, 4) NULL, 
    [GGPConverted]			 NUMERIC(18, 4) NULL
);

