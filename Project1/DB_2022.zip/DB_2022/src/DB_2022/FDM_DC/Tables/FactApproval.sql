﻿CREATE TABLE [FDM_DC].[FactApproval] (
    [fk_Department]  NVARCHAR (255)  NULL,
    [fk_ReviewCycle] NVARCHAR (255)  NULL,
    [UserID]         NVARCHAR (255)  NULL,
    [Approval]       NUMERIC (18, 4) NULL
);

