﻿CREATE TABLE [FDM_DC].[WriteTable_Technical Data] (
    [MetricValue_0]            FLOAT (53)     NULL,
    [CNVMetricValue_1]         INT            NULL,
    [pk_Version_2]             INT            NULL,
    [pk_PolicyType_3]          NVARCHAR (255) NULL,
    [pk_Host_4]                NVARCHAR (255) NULL,
    [pk_Entity_5]              NVARCHAR (255) NULL,
    [pk_TransactionCurrency_6] NVARCHAR (25)  NULL,
    [pk_YOA_7]                 INT            NULL,
    [pk_LloydsDistChannel_8]   NVARCHAR (255) NULL,
    [pk_Metric_9]              NVARCHAR (255) NULL,
    [pk_TriFocus_10]           NVARCHAR (255) NULL,
    [pk_BeazleyOffice_11]      NVARCHAR (255) NULL,
    [pk_InceptionMonth_12]     INT            NULL,
    [pk_Platform_13]           NVARCHAR (255) NULL,
    [pk_ReviewCycle_14]        NVARCHAR (255) NULL,
    [MS_AUDIT_TIME_15]         DATETIME       NULL,
    [MS_AUDIT_USER_16]         NVARCHAR (255) NULL
);

