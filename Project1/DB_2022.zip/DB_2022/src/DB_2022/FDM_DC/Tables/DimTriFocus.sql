﻿CREATE TABLE [FDM_DC].[DimTriFocus] (
    [pk_TriFocus]  NVARCHAR (255) NOT NULL,
    [TriFocusName] NVARCHAR (255) NULL,
    [Department]   NVARCHAR (255) NULL
);

