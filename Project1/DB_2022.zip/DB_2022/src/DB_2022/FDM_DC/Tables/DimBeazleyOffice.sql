﻿CREATE TABLE [FDM_DC].[DimBeazleyOffice] (
    [pk_BeazleyOffice]  NVARCHAR (255) NOT NULL,
    [BeazleyOfficeName] NVARCHAR (255) NULL
);

