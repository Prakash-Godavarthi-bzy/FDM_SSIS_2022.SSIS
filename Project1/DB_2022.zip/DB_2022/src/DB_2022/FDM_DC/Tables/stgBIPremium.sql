﻿CREATE TABLE [FDM_DC].[stgBIPremium] (
    [YOA]                          NVARCHAR (255) NULL,
    [TriFocus Code]                NVARCHAR (255) NULL,
    [TriFocus]                     NVARCHAR (255) NULL,
    [Settlement Currency]          NVARCHAR (255) NULL,
    [Inception Month Of Year]      NVARCHAR (255) NULL,
    [Facility Filter]              NVARCHAR (255) NULL,
    [Facility Type]                NVARCHAR (255) NULL,
    [Placing Broker Group]         NVARCHAR (255) NULL,
    [Beazley Office Location]      NVARCHAR (255) NULL,
    [Written Or Estimated Premium] NVARCHAR (255) NULL,
    [Accounted Premium]            NVARCHAR (255) NULL,
    [Channel]                      NVARCHAR (255) NULL,
    [IncMonthNumber]               INT            NULL
);

