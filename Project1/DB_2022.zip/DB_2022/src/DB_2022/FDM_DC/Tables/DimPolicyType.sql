﻿CREATE TABLE [FDM_DC].[DimPolicyType] (
    [pk_PolicyType] NVARCHAR (255) NOT NULL
);

