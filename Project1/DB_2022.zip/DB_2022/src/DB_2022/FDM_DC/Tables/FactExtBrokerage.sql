﻿CREATE TABLE [FDM_DC].[FactExtBrokerage] (
    [fk_YOA]            INT             NULL,
    [fk_PolicyType]     NVARCHAR (255)  NULL,
    [fk_TriFocus]       NVARCHAR (255)  NULL,
    [PcentExtBrokerage] NUMERIC (24, 6) NULL,
    [fk_Platform]       NVARCHAR (255)  NULL,
    [fk_ReviewCycle]    NVARCHAR (255)  NULL
);

