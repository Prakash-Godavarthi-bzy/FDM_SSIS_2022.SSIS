﻿CREATE TABLE [FDM_DC].[FactDataCapture] (
    [fk_Metric]              NVARCHAR (255)  NULL,
    [fk_Version]             INT             NULL,
    [fk_PolicyType]          NVARCHAR (255)  NULL,
    [fk_Host]                NVARCHAR (255)  NULL,
    [fk_Entity]              NVARCHAR (255)  NULL,
    [fk_InceptionMonth]      INT             NULL,
    [fk_TransactionCurrency] NVARCHAR (255)  NULL,
    [fk_YOA]                 INT             NULL,
    [fk_LloydsDistChannel]   NVARCHAR (255)  NULL,
    [fk_TriFocus]            NVARCHAR (255)  NULL,
    [fk_BeazleyOffice]       NVARCHAR (255)  NULL,
    [MetricValue]            NUMERIC (24, 6) NULL,
    [fk_Platform]            NVARCHAR (255)  NULL,
    [fk_ReviewCycle]         NVARCHAR (255)  NULL
);

