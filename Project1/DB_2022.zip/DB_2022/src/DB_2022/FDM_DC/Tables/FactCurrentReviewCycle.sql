﻿CREATE TABLE [FDM_DC].[FactCurrentReviewCycle] (
    [fk_ReviewCycle] NVARCHAR (255)  NULL,
    [CurrentCycle]   NUMERIC (18, 4) NULL
);

