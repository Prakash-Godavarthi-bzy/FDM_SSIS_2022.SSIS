﻿CREATE TABLE [FDM_DC].[FactToHost] (
    [fk_ReviewCycle] NVARCHAR (255)  NULL,
    [fk_TriFocus]    NVARCHAR (255)  NULL,
    [fk_Host]        NVARCHAR (255)  NULL,
    [fk_YOA]         INT             NULL,
    [ToHost]         NUMERIC (18, 4) NULL
);

