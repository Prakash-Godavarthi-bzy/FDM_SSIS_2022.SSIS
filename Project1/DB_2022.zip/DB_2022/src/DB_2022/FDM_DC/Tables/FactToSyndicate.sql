﻿CREATE TABLE [FDM_DC].[FactToSyndicate] (
    [fk_ReviewCycle] NVARCHAR (255)  NULL,
    [fk_Host]        NVARCHAR (255)  NULL,
    [fk_Entity]      NVARCHAR (255)  NULL,
    [fk_YOA]         INT             NULL,
    [ToSyndicate]    NUMERIC (18, 4) NULL
);

