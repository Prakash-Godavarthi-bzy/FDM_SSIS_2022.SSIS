﻿CREATE TABLE [FDM_DC].[DimEntity] (
    [pk_Entity]  NVARCHAR (255) NOT NULL,
    [EntityName] NVARCHAR (255) NULL
);

