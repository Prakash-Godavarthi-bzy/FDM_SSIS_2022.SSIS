﻿CREATE TABLE [FDM_DC].[WriteTable_SPSCede] (
    [SPSCedePercent_0] FLOAT (53)     NULL,
    [pk_Host_1]        NVARCHAR (255) NULL,
    [pk_Entity_2]      NVARCHAR (255) NULL,
    [pk_TriFocus_3]    NVARCHAR (255) NULL,
    [pk_YOA_4]         INT            NULL,
    [MS_AUDIT_TIME_5]  DATETIME       NULL,
    [MS_AUDIT_USER_6]  NVARCHAR (255) NULL
);

