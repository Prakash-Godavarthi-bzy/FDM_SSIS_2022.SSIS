﻿CREATE TABLE [FDM_DC].[FactHostToEntity] (
    [fk_YOA]            INT             NULL,
    [fk_Host]           NVARCHAR (255)  NULL,
    [fk_Entity]         NVARCHAR (255)  NULL,
    [PcentHostToEntity] NUMERIC (24, 6) NULL
);

