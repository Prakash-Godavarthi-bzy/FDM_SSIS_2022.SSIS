﻿CREATE TABLE [FDM_DC].[WriteTable_Map Pcent To Lloyds] (
    [PcentToLloyds_0] FLOAT (53)     NULL,
    [pk_YOA_1]        INT            NULL,
    [pk_TriFocus_2]   NVARCHAR (255) NULL,
    [MS_AUDIT_TIME_3] DATETIME       NULL,
    [MS_AUDIT_USER_4] NVARCHAR (255) NULL
);

