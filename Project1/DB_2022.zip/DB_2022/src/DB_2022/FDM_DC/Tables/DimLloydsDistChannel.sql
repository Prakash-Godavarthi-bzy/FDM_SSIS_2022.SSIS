﻿CREATE TABLE [FDM_DC].[DimLloydsDistChannel] (
    [pk_LloydsDistChannel]  NVARCHAR (255) NOT NULL,
    [LloydsDistChannelName] NVARCHAR (255) NULL
);

