﻿CREATE TABLE [FDM_DC].[WriteTable_RI] (
    [RIValue_0]                FLOAT (53)     NULL,
    [CNVRIValue_1]             INT            NULL,
    [pk_YOA_2]                 INT            NULL,
    [pk_TriFocus_3]            NVARCHAR (255) NULL,
    [pk_TransactionCurrency_4] NVARCHAR (25)  NULL,
    [pk_Version_5]             INT            NULL,
    [pk_ReviewCycle_6]         NVARCHAR (255) NULL,
    [pk_Platform_7]            NVARCHAR (255) NULL,
    [pk_RIProgramme_8]         INT            NULL,
    [MS_AUDIT_TIME_9]          DATETIME       NULL,
    [MS_AUDIT_USER_10]         NVARCHAR (255) NULL
);

