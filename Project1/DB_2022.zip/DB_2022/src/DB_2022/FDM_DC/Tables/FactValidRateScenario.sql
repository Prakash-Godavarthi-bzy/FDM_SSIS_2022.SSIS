﻿CREATE TABLE [FDM_DC].[FactValidRateScenario] (
    [fk_RateScenario] INT             NULL,
    [RateValid]       NUMERIC (18, 4) NULL,
    [RateDefault]     NUMERIC (18, 4) NULL
);

