﻿CREATE TABLE [FDM_DC].[WriteTable_Z Map Dept To RI] (
    [IsLink_0]         INT            NULL,
    [Department_1]     NVARCHAR (255) NULL,
    [pk_RIProgramme_2] INT            NULL,
    [pk_Platform_3]    NVARCHAR (255) NULL,
    [MS_AUDIT_TIME_4]  DATETIME       NULL,
    [MS_AUDIT_USER_5]  NVARCHAR (255) NULL
);

