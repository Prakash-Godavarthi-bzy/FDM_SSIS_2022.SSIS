﻿CREATE TABLE [FDM_DC].[secUser] (
    [NTUser] NVARCHAR (255) NOT NULL
);

