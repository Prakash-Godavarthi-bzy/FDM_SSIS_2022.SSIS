﻿CREATE TABLE [FDM_DC].[FactRawPremium] (
    [fk_PolicyType]          NVARCHAR (255)  NULL,
    [fk_ReviewCycle]         NVARCHAR (255)  NULL,
    [fk_TriFocus]            NVARCHAR (255)  NULL,
    [fk_YOA]                 INT             NULL,
    [fk_OfficeChannel]       NVARCHAR (255)  NULL,
    [fk_InceptionMonth]      INT             NULL,
    [UserID]                 NVARCHAR (255)  NULL,
    [fk_TransactionCurrency] NVARCHAR (255)  NULL,
    [fk_InsertDate]          NVARCHAR (255)  NULL,
    [GNP]                    NUMERIC (18, 4) NULL,
    [IOType]                 NVARCHAR (6)    NULL
);

