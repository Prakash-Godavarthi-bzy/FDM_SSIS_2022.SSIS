﻿CREATE TABLE [FDM_DC].[FactSPSCede] (
    [fk_Host]        NVARCHAR (255)  NULL,
    [fk_Entity]      NVARCHAR (255)  NULL,
    [fk_TriFocus]    NVARCHAR (255)  NULL,
    [fk_YOA]         INT             NULL,
    [SPSCedePercent] NUMERIC (24, 6) NULL
);

