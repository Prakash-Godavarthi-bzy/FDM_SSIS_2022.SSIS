﻿CREATE TABLE [FDM_DC].[DimRIProgramme] (
    [pk_RIProgramme]         INT            NOT NULL,
    [RIProgrammeName]        NVARCHAR (255) NULL,
    [RIProgrammeDescription] NVARCHAR (500) NULL,
    [RIType]                 NVARCHAR (255) NULL,
    [FacUSFlag]              NVARCHAR (1)   NULL
);

