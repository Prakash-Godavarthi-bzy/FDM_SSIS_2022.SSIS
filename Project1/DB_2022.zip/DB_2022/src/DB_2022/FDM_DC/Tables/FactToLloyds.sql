﻿CREATE TABLE [FDM_DC].[FactToLloyds] (
    [fk_ReviewCycle] NVARCHAR (255)  NULL,
    [fk_TriFocus]    NVARCHAR (255)  NULL,
    [fk_YOA]         INT             NULL,
    [ToLloyds]       NUMERIC (18, 4) NULL
);

