﻿CREATE TABLE [FDM_DC].[WriteTable_Map TF To Host] (
    [PcentTFToHost_0] FLOAT (53)     NULL,
    [pk_YOA_1]        INT            NULL,
    [pk_TriFocus_2]   NVARCHAR (255) NULL,
    [pk_Host_3]       NVARCHAR (255) NULL,
    [MS_AUDIT_TIME_4] DATETIME       NULL,
    [MS_AUDIT_USER_5] NVARCHAR (255) NULL
);

