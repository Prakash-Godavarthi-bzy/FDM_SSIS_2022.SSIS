﻿CREATE TABLE [FDM_DC].[DimHost] (
    [pk_Host] NVARCHAR (255) NOT NULL
);

