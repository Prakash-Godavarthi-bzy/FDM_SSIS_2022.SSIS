﻿CREATE TABLE [FDM_DC].[WriteTable_Ext Brokerage] (
    [PcentExtBrokerage_0] FLOAT (53)     NULL,
    [pk_YOA_1]            INT            NULL,
    [pk_PolicyType_2]     NVARCHAR (255) NULL,
    [pk_TriFocus_3]       NVARCHAR (255) NULL,
    [pk_Platform_4]       NVARCHAR (255) NULL,
    [pk_ReviewCycle_5]    NVARCHAR (255) NULL,
    [MS_AUDIT_TIME_6]     DATETIME       NULL,
    [MS_AUDIT_USER_7]     NVARCHAR (255) NULL
);

