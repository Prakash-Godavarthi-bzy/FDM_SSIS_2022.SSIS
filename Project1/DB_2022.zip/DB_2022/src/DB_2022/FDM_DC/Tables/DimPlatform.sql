﻿CREATE TABLE [FDM_DC].[DimPlatform] (
    [pk_Platform] NVARCHAR (255) NOT NULL
);

