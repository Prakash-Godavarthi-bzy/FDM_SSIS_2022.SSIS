﻿CREATE TABLE [FDM_DC].[FactPcentToLloyds] (
    [fk_YOA]        INT             NULL,
    [fk_TriFocus]   NVARCHAR (255)  NULL,
    [PcentToLloyds] NUMERIC (24, 6) NULL
);

