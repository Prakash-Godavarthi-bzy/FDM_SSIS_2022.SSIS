﻿CREATE TABLE [FDM_DC].[DimMetric] (
    [pk_Metric]         NVARCHAR (255)  NOT NULL,
    [MetricName]        NVARCHAR (255)  NULL,
    [MetricDescription] NVARCHAR (255)  NULL,
    [MetricFormat]      NVARCHAR (255)  NULL,
    [MetricWritable]    NCHAR (1)       NULL,
    [MetricCalculation] NVARCHAR (1000) NULL,
    [fk_MetricParent]   NVARCHAR (255)  NULL,
    [MetricPublished]   NCHAR (1)       NULL,
    [SortOrder]         INT             NULL,
    [MetricIsCurrency]  NVARCHAR (255)  NULL
);

