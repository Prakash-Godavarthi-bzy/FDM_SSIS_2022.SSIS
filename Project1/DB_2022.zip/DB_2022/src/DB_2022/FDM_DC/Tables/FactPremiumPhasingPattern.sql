﻿CREATE TABLE [FDM_DC].[FactPremiumPhasingPattern] (
    [fk_PolicyType]          NVARCHAR (255)  NULL,
    [fk_ReviewCycle]         NVARCHAR (255)  NULL,
    [fk_TriFocus]            NVARCHAR (255)  NULL,
    [fk_YOA]                 INT             NULL,
    [fk_InceptionMonth]      INT             NULL,
    [fk_TransactionCurrency] NVARCHAR (255)  NULL,
    [Pattern]                NUMERIC (18, 4) NULL
);

