﻿CREATE TABLE [FDM_DC].[FactInternalCommission] (
    [fk_PolicyType]  NVARCHAR (255)  NULL,
    [fk_ReviewCycle] NVARCHAR (255)  NULL,
    [fk_TriFocus]    NVARCHAR (255)  NULL,
    [fk_YOA]         INT             NULL,
    [UserID]         NVARCHAR (255)  NULL,
    [fk_InsertDate]  NVARCHAR (255)  NULL,
    [IC]             NUMERIC (18, 4) NULL
);

