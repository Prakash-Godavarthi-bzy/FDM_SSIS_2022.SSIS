﻿CREATE TABLE [FDM_DC].[secUserPermissions] (
    [UserID]     NVARCHAR (255) NOT NULL,
    [Department] NVARCHAR (255) NOT NULL,
    [FXRate]     NVARCHAR (255) NULL,
    [MinVersion] INT            NULL,
    [MaxVersion] INT            NULL
);

