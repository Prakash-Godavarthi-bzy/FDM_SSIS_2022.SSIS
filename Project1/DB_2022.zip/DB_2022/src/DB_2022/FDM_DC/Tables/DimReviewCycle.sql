﻿CREATE TABLE [FDM_DC].[DimReviewCycle] (
    [pk_ReviewCycle] NVARCHAR (255) NOT NULL,
    [Order]          INT            NULL
);

