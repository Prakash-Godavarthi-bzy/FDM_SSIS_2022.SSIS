﻿CREATE VIEW [FDM_DC].[vFactToSyndicateCurrent]
AS

select * from [FDM_DC].[vFactToSyndicate] where ReviewCycle = (select top 1 [Review Cycle] from [FDM_Export].[PFT_SYND_WITH_CEDE]) and ToSyndicate >0
GO