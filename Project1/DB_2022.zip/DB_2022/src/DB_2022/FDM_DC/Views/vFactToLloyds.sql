﻿CREATE VIEW [FDM_DC].[vFactToLloyds]
AS
SELECT ToLloyds = sum([ToLloyds_0])
		  ,ReviewCycle= [pk_ReviewCycle_2]
		  ,TriFocus = [pk_TriFocus_3]
		  ,YOA = [pk_YOA_4]

		FROM [dbo].[WriteTable_zFact To Lloyds] tl
		group by
			[pk_ReviewCycle_2]
			,[pk_TriFocus_3]
			,[pk_YOA_4]
GO