﻿CREATE VIEW [FDM_DC].[vFactToHost]
AS
SELECT ToHost= sum([ToHost])
      ,ReviewCycle = [ReviewCycle]
      ,TriFocus = [TriFocus]
      ,YOA = [YOA]
      ,Host = [Host]

  FROM [dbo].[PFTFactToHost]
  group by 
		[ReviewCycle]
      ,[TriFocus]
      ,[YOA]
      ,[Host]
GO