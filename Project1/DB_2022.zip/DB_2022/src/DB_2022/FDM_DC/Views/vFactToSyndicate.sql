﻿CREATE VIEW [FDM_DC].[vFactToSyndicate]
AS
SELECT 
	ToSyndicate = sum([ToSyndicate])
	,ReviewCycle = [ReviewCycle]
	,YOA = [YOA]
	,Host = [Host]
	,Entity = [Entity]

FROM [dbo].[PFTFactToSyndicate]
GROUP BY 
	[ReviewCycle]
	,[YOA]
	,[Host]
	,[Entity]
GO