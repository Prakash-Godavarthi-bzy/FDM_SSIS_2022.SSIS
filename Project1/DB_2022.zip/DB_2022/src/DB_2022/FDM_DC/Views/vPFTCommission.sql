﻿CREATE VIEW [FDM_DC].[vPFTCommission]
AS

select
	ec.PolicyType
    ,ec.ReviewCycle
    ,ec.YOA
    ,ec.TriFocus
    ,ec.OfficeChannel
	, IC
	, EC
FROM
(
SELECT 
	EC = sum([EC_0])
    ,PolicyType = [pk_PolicyType_1]
    ,ReviewCycle = [pk_ReviewCycle_2]
    ,YOA = [pk_YOA_3]
    ,TriFocus = [pk_TriFocus_4]
    ,OfficeChannel = [pk_OfficeChannel_5]
      
FROM [dbo].[WriteTable_02 External Commission]
group by 
	[pk_PolicyType_1]
	,[pk_ReviewCycle_2]
	,[pk_YOA_3]
	,[pk_TriFocus_4]
	,[pk_OfficeChannel_5]
) ec left outer join
(
SELECT 
	IC = sum([IC_0])
    ,PolicyType = [pk_PolicyType_1]
    ,ReviewCycle = [pk_ReviewCycle_2]
    ,TriFocus = [pk_TriFocus_3]
    ,YOA = [pk_YOA_4]
FROM 
	[dbo].[WriteTable_03 Internal Commission]
GROUP BY 
	[pk_PolicyType_1]
    ,[pk_ReviewCycle_2]
    ,[pk_TriFocus_3]
    ,[pk_YOA_4]
) ic on
	ec.PolicyType=ic.PolicyType
	and ec.ReviewCycle=ic.ReviewCycle
	and ec.TriFocus = ic.TriFocus
	and ec.YOA = ic.YOA
GO

