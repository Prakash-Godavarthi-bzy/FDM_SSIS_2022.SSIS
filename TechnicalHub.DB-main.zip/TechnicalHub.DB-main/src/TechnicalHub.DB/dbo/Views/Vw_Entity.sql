﻿CREATE VIEW Vw_Entity
as
SELECT 'ALL' as Entity
UNION
SELECT [BK_Entity] as Entity FROM dim.Entity ;