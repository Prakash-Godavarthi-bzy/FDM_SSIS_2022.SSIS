﻿

CREATE Function [dbo].[fn_GetEmbeddedChildNodes](@ParentNode VARCHAR(15),@MDX VARCHAR(MAX))
RETURNS 
@EmbeddedNodes TABLE 
(
	ParentNode VARCHAR(15),
	ChildNode VARCHAR(15)
)
AS
BEGIN

IF CHARINDEX( 'Opening',@MDX) <=0
BEGIN
declare @str varchar(MAX)=@MDX
declare @gstr varchar(100)=''--for saving the output string
declare @flag int=1--to identify the pattern starting
declare @move int=1-- change start of the string 
 while  PATINDEX('%CT.%', substring(@MDX,@move,LEN(@MDX)))>0
begin
set @MDX=substring(@MDX,@move,LEN(@MDX))
set @flag= PATINDEX('%CT.%', @MDX)
INSERT INTO @EmbeddedNodes VALUES(@ParentNode,SUBSTRING(@MDX, @flag,11))
set @gstr= @gstr+','+SUBSTRING(@MDX, @flag,11)
set @move=@flag+11
end

SET @flag = 1
SET @move=1
while  PATINDEX('%IF.%', substring(@str,@move,LEN(@str)))>0
begin
set @str=substring(@str,@move,LEN(@str))
set @flag= PATINDEX('%IF.%', @str)
INSERT INTO @EmbeddedNodes VALUES(@ParentNode,SUBSTRING(@str, @flag,11))
set @move=@flag+11
end
END
RETURN 

END