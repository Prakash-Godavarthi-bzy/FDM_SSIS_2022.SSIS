﻿
CREATE Function [dbo].[fn_GetTask](@strText VARCHAR(MAX))
RETURNS varchar(1000)
AS
BEGIN
declare @str varchar(100)=@strText
declare @gstr varchar(100)=''--for saving the output string
declare @flag int=1--to identify the pattern starting
declare @move int=1-- change start of the string 
 while  PATINDEX('%CT%', substring(@strText,@move,LEN(@strText)))>0
begin
set @strText=substring(@strText,@move,LEN(@strText))
set @flag= PATINDEX('%CT%', @strText)
set @gstr= @gstr+','+SUBSTRING(@strText, @flag,11)
set @move=@flag+9
end

SET @flag = 0
SET @move=0
while  PATINDEX('%IF%', substring(@str,@move,LEN(@str)))>0
begin
set @str=substring(@str,@move,LEN(@str))
set @flag= PATINDEX('%CT%', @str)
set @gstr= @gstr+','+SUBSTRING(@str, @flag,11)
set @move=@flag+11
end

RETURN STUFF(@gstr,1,1,'')

END