﻿CREATE TABLE [dbo].[ReInsuranceQuotaSharePercentage](
	[BusinessKey] [nvarchar](800) NOT NULL,
	[AccountingPeriod] [int] NOT NULL,
	[TrifocusCode] [nvarchar](255) NULL,
	[TrifocusName] [nvarchar](255) NULL,
	[Entity] [nvarchar](255) NULL,
	[YOA] [int] NOT NULL,
	[SettlementCCY] [nvarchar](25) NULL,
	[QS_Premium] [decimal](38, 4) NULL,
	[GrossUltimates] [decimal](38, 4) NULL,
	[QS%] [decimal](38, 6) NULL,
	[FK_Batch_Insert] [int] NOT NULL,
	[FK_Batch_Update] [int] NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUpdateDateTime] [datetime] NULL,
	[AuditUserCreate] [nvarchar](255) NOT NULL,
	[AuditUserUpdate] [nvarchar](255) NULL,
	[AuditHostCreate] [nvarchar](255) NOT NULL,
	[AuditHostUpdate] [nvarchar](255) NULL
) ON [PRIMARY]
GO


