﻿CREATE TABLE [dbo].[Login] (
    [UserName] VARCHAR (10)  NOT NULL,
    [Password] NVARCHAR (50) NOT NULL,
    [Email]    NVARCHAR (50) NOT NULL
);



