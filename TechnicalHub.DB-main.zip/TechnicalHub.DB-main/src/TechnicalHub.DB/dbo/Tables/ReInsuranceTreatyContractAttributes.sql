﻿CREATE TABLE [dbo].[ReInsuranceTreatyContractAttributes](
	[RI_Section_Reference] [varchar](12) NULL,
	[RI_Policy_Type] [varchar](3) NULL,
	[RI_Code] [varchar](6) NULL,
	[ProgrammeCode] [varchar](100) NULL,
	[Inception_Date] [datetime] NULL,
	[Expiry_Date] [datetime] NULL,
	[Number_of_Reinstatements] [int] NULL,
	[Claim_Basis] [varchar](3) NULL,
	[Slip_Order_%] [float] NULL,
	[General_Description] [varchar](240) NULL,
	[Sum_Insured_Limit] [float] NULL,
	[Excess_Limit] [float] NULL,
	[Sum_Insured_Currency] [varchar](3) NULL,
	[Event_Limit] [float] NULL,
	[Event_Limit_Currency] [varchar](3) NULL,
	[Settlement_Limit] [float] NULL,
	[Settlement_Limit_Currency] [varchar](3) NULL,
	[Currency_Converter] [float] NULL,
	[Profit_Commission] [float] NULL,
	[Profit_Commission_Management_Expenses] [float] NULL,
	[Profit_Commission_Currency] [varchar](3) NULL,
	[Overrider] [float] NULL,
	[Average_QS_%] [float] NULL,
	[Number_of_QS_Policies] [int] NULL,
	[%_Ceded_to_QS] [float] NULL,
	[Auditcreateddatetime] [datetime2](7) NULL,
	[Auditusercreate] [nvarchar](255) NULL,
	[Audithost] [nvarchar](255) NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[ReInsuranceTreatyContractAttributes] ADD  CONSTRAINT [DF_ReInsuranceTreatyContractAttributes_auditcreateddatetime]  DEFAULT (getdate()) FOR [Auditcreateddatetime]
GO

ALTER TABLE [dbo].[ReInsuranceTreatyContractAttributes] ADD  CONSTRAINT [DF_ReInsuranceTreatyContractAttributes_auditusercreate]  DEFAULT (suser_name()) FOR [Auditusercreate]
GO

ALTER TABLE [dbo].[ReInsuranceTreatyContractAttributes] ADD  CONSTRAINT [DF_ReInsuranceTreatyContractAttributes_audithost]  DEFAULT (host_name()) FOR [Audithost]
GO


