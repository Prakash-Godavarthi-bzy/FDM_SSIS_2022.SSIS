﻿CREATE TABLE [dbo].[RIPercentage](
	[AccountingPeriod] [varchar](25) NULL,
	[TrifocusCode] [nvarchar](50) NULL,
	[TrifocusName] [nvarchar](255) NULL,
	[Entity] [varchar](50) NULL,
	[YOA] [int] NULL,
	[YOI] [int] NULL,
	[RIProgramme] [varchar](255) NULL,
	[RIType] [varchar](50) NULL,
	[SettlementCCY] [varchar](25) NULL,
	[RIPolicyNumber] [varchar](255) NULL,
	[InceptionDate] [datetime] NULL,
	[ExpiryDate] [datetime] NULL,
	[ClaimsBasis] [varchar](10) NULL,
	[RIPremium] [numeric](19, 6) NULL,
	[GrossNetUltimates] [numeric](19, 6) NULL,
	[RI%] [numeric](19, 6) NULL,
	[Businesskey] [varchar](500) NOT NULL
) ON [PRIMARY]
GO
