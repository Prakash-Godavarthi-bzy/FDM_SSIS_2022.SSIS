﻿CREATE TABLE [dbo].[fdm_DimRIPolicy](
	[pk_RIPolicy] [bigint] NOT NULL,
	[RIPolicyNumber] [nvarchar](255) NULL,
	[InceptionDate] [date] NULL,
	[ExpiryDate] [date] NULL,
	[RIProgramme] [varchar](100) NULL,
	[RIType] [nvarchar](50) NULL,
	[RIAdjustment] [nvarchar](50) NULL,
	[RIBASis] [nvarchar](50) NULL,
	[Auditcreateddatetime] [datetime2](7) NULL,
	[Auditusercreate] [nvarchar](255) NULL,
	[Audithost] [nvarchar](255) NULL
) ON [PRIMARY]
GO


ALTER TABLE [dbo].[fdm_DimRIPolicy] ADD  CONSTRAINT [DF_DimRIPolicy_auditcreateddatetime]  DEFAULT (getdate()) FOR [Auditcreateddatetime]
GO

ALTER TABLE [dbo].[fdm_DimRIPolicy] ADD  CONSTRAINT [DF_DimRIPolicy_auditusercreate]  DEFAULT (suser_name()) FOR [Auditusercreate]
GO

ALTER TABLE [dbo].[fdm_DimRIPolicy] ADD  CONSTRAINT [DF_DimRIPolicy_audithost]  DEFAULT (host_name()) FOR [Audithost]
GO

