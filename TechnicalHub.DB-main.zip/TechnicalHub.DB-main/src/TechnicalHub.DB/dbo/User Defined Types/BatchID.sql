﻿CREATE TYPE [dbo].[BatchID] AS TABLE 
(
    [PK_BatchID]   INT           NULL,
    [Dataset] NVARCHAR (50)
);

