﻿CREATE PROCEDURE [dbo].[usp_RetrieveValidations] AS

BEGIN

DROP TABLE IF EXISTS #MonthChange
SELECT DISTINCT
	--p.[BK_PolicyNumber]--JPX30E19ANSV
	--,p.PK_Policy --[B0342C20ANFE]-[May  1 2020 12:00AM]-[Apr 30 2021 12:00AM]-[2020]-[Binder]-[N]
	--,PeriodOrder = ROW_NUMBER() OVER(PARTITION BY p.[BK_PolicyNumber] ORDER BY tr.fk_accountingperiod ASC, SUM(Value) DESC)
	--,tr.fk_accountingperiod --202005
	--,p.PolicyType --Binder
	--,PolicyDuration = DATEDIFF(d,p.InceptionDate, p.ExpiryDate)  --364
	--,fk_trifocus --TRI00007
	--,PeriodChange = SUM(Value)
	--,NoOfChanges = COUNT(DISTINCT  [BK_PolicyNumber])

	 pp.SectionReference as Bk_PolicyNumber
	,pp.bK_PolicySection AS Pk_Policy
	,PeriodOrder = ROW_NUMBER() OVER(PARTITION BY pp.SectionReference ORDER BY ap.BK_AccountingPeriod ASC, SUM(Value) DESC)
	,ap.BK_AccountingPeriod as fk_accountingperiod
	,pp.PolicyType
	,PolicyDuration = DATEDIFF(d,pp.InceptionDate, pp.ExpiryDate)
	,dt.BK_Trifocus as fk_trifocus
	,PeriodChange = SUM(Value)
	,NoOfChanges = COUNT(DISTINCT  pp.SectionReference)
INTO #MonthChange
FROM
	TechnicalHub.dim.Policysection pp 
		--		TechnicalHub.IFRS17.PolicySection pp
	--LEFT JOIN	TechnicalHub.IFRS17.FCT_TechnicalResult tr ON pp.PK_Policysection = tr.FK_Policysection 
	--LEFT JOIN	TechnicalHub.IFRS17.Account A ON A.PK_Account=TR.FK_Account
	LEFT JOIN fct.TechnicalResult tr ON pp.PK_Policysection = tr.FK_Policysection 
	LEFT JOIN dim.Account a ON tr.FK_Account = a.[PK_Account]
	LEFT JOIN dim.AccountingPeriod ap on ap.PK_AccountingPeriod=tr.FK_AccountingPeriod
	LEFT JOIN dim.TriFocus dt on dt.PK_TriFocus=tr.FK_Trifocus
	LEFT JOIN dim.DataSet ds on ds.PK_DataSet=tr.FK_DataSet
	LEFT JOIN dim.Entity de on de.PK_Entity=tr.FK_Entity
	LEFT JOIN dim.YOA dy on dy.PK_YOA=tr.FK_YOA
WHERE 
	1=1
	AND a.Level2Group = 'Gross'
	AND ds.[BK_DataSet] = 'Eurobase'
	AND de.bk_Entity IN ('623', '2623', '3623', '3622')
	AND ap.[BK_AccountingPeriod] >= '201801'
	
	--AND tr.fk_trifocus NOT IN 
	--(
	--'737'
	--,'738'
	--,'740'
	--,'741'
	--,'742'
	--,'743'
	--,'765'
	--,'769'
	--,'783'
	--,'810'

	--)
	--AND tr.fk_YOA BETWEEN CAST(LEFT(CONVERT(VARCHAR(8),GETDATE(),112),4) AS INT)-2 AND CAST(LEFT(CONVERT(VARCHAR(8),GETDATE(),112),4) AS INT) + 1
	AND dy.Bk_YOA in (cast(YEAR(GETDATE()) +1 as varchar),cast(YEAR(GETDATE()) as varchar),cast(YEAR(GETDATE())-1  as varchar),cast(YEAR(GETDATE())-2 as varchar) )
GROUP BY
	pp.SectionReference
	,pp.bK_PolicySection
	,ap.BK_AccountingPeriod
	,pp.PolicyType
	,DATEDIFF(d,pp.InceptionDate, pp.ExpiryDate)
	,dt.BK_Trifocus

ORDER BY 
	pp.SectionReference
	,pp.bK_PolicySection
	,ap.BK_AccountingPeriod
	,pp.PolicyType
	,DATEDIFF(d,pp.InceptionDate, pp.ExpiryDate)
	,dt.BK_Trifocus
CREATE CLUSTERED INDEX ix_BK_PolicyNumber_PeriodOrder ON #MonthChange(BK_PolicyNumber,PeriodOrder)

---------------------------------------------------------------------------------------------------------
-- Updated by Rishi Gupta on 17-Feb-2021 to exclude any zero policy movements in the initial period
---------------------------------------------------------------------------------------------------------
	-- Loop until policies have zero premium in first period
	WHILE EXISTS ( SELECT 1 FROM #MonthChange WHERE [PeriodChange] = 0 AND [PeriodOrder]  = 1)
		-- Change the period number (-1) for the policies having 0 value in first period
		UPDATE M SET M.[PeriodOrder] = M.[PeriodOrder] - 1
		FROM
			#MonthChange M
		INNER JOIN
			#MonthChange Invalid
		ON M.[BK_PolicyNumber] = Invalid.[BK_PolicyNumber]
		WHERE Invalid.[PeriodChange] = 0 AND Invalid.[PeriodOrder] = 1

	-- Delete any periods which are less then 1
	DELETE FROM #MonthChange WHERE [PeriodOrder] <= 0


---------------------------------------------------------------------------------------------------------
-- End of change 17-Feb-2021
---------------------------------------------------------------------------------------------------------

DROP TABLE IF EXISTS #Exceptions
SELECT 
	pk_Validation = ROW_NUMBER() OVER(ORDER BY mcc.[BK_PolicyNumber] ,mcc.fk_accountingperiod ASC)
	,mcc.[BK_PolicyNumber] 
	,mcc.PK_Policy
	,mcc.fk_accountingperiod
	,CurrentPolicyType = mcc.PolicyType
	,CurrentPolicyDuration = mcc.policyduration
	,CurrentTriFocus = mcc.fk_trifocus
	,CurrentPeriodChange = (SELECT SUM(PeriodChange) FROM #MonthChange mc WHERE mc.BK_PolicyNumber=mcc.BK_PolicyNumber AND mc.FK_AccountingPeriod = mcc.FK_AccountingPeriod)
	,PriorPeriod = mcp.fk_accountingperiod
	,PriorPolicyType = mcp.PolicyType
	,PriorPolicyDuration = mcp.policyduration
	,PriorTriFocus = mcp.fk_trifocus
	,mcc.PeriodOrder
	--,ValidationType = CASE 
	--	WHEN mcc.PeriodOrder > 1 AND ABS((SELECT SUM(PeriodChange) FROM #MonthChange mc WHERE mc.BK_PolicyNumber=mcc.BK_PolicyNumber AND mc.FK_AccountingPeriod = mcc.FK_AccountingPeriod))>=1000000 THEN 1
	--	WHEN mcc.PeriodOrder > 1 AND mcc.PolicyType <> mcp.PolicyType THEN 2
	--	WHEN mcc.PeriodOrder > 1 AND mcc.policyduration <> mcp.policyduration THEN 3
	--	WHEN mcc.PeriodOrder > 1 AND (mcc.fk_trifocus <> mcp.fk_trifocus) THEN 4
	--	WHEN mcc.PeriodOrder = 1 THEN 5
	--	ELSE  ''
	--END
INTO #Exceptions
FROM 
	#MonthChange mcc LEFT OUTER JOIN
	#MonthChange mcp ON mcc.[BK_PolicyNumber] = mcp.[BK_PolicyNumber] AND mcp.PeriodOrder = mcc.PeriodOrder-1
WHERE 
	--mcc.PeriodOrder > 1
	--and
	(
		mcc.PeriodOrder = 1
		OR mcc.policyduration <> mcp.policyduration
		OR mcc.fk_trifocus <> mcp.fk_trifocus
		OR mcc.PolicyType <> mcp.PolicyType
		OR ABS((SELECT SUM(PeriodChange) FROM #MonthChange mc WHERE mc.BK_PolicyNumber=mcc.BK_PolicyNumber AND mc.FK_AccountingPeriod = mcc.FK_AccountingPeriod))>=1000000
	)

	AND mcc.PeriodChange + ISNULL(mcp.PeriodChange,0) <>0 -- remove reversals
	AND mcc.FK_AccountingPeriod <> ISNULL(mcp.FK_AccountingPeriod,0)

--SELECT * FROM #Exceptions


DROP TABLE IF EXISTS #DeltaChange
SELECT   1 AS ValidationType
		, t1.pk_Validation
		, t1.BK_PolicyNumber
		, t1.PK_Policy
		, t1.FK_AccountingPeriod
		, t1.CurrentPolicyType
		, t1.CurrentPolicyDuration
		, t1.CurrentTriFocus
		, t1.CurrentPeriodChange
		, t1.PriorPeriod
		, t1.PriorPolicyType
		, t1.PriorPolicyDuration
		, t1.PriorTriFocus
		, t1.PeriodOrder
INTO #DeltaChange 
FROM #Exceptions T1 
WHERE ABS(CurrentPeriodChange) > 1000000 
AND PeriodOrder > 1

DROP TABLE IF EXISTS #PolicyTypeChange
SELECT   2 AS ValidationType
		, t1.pk_Validation
		, t1.BK_PolicyNumber
		, t1.PK_Policy
		, t1.FK_AccountingPeriod
		, t1.CurrentPolicyType
		, t1.CurrentPolicyDuration
		, t1.CurrentTriFocus
		, t1.CurrentPeriodChange
		, t1.PriorPeriod
		, t1.PriorPolicyType
		, t1.PriorPolicyDuration
		, t1.PriorTriFocus
		, t1.PeriodOrder
INTO #PolicyTypeChange
FROM #Exceptions T1 
WHERE PeriodOrder > 1 
AND CurrentPolicyType <> PriorPolicyType

DROP TABLE IF EXISTS #PolicyDurationChange
SELECT   3 AS ValidationType
		, t1.pk_Validation
		, t1.BK_PolicyNumber
		, t1.PK_Policy
		, t1.FK_AccountingPeriod
		, t1.CurrentPolicyType
		, t1.CurrentPolicyDuration
		, t1.CurrentTriFocus
		, t1.CurrentPeriodChange
		, t1.PriorPeriod
		, t1.PriorPolicyType
		, t1.PriorPolicyDuration
		, t1.PriorTriFocus
		, t1.PeriodOrder
INTO #PolicyDurationChange
FROM #Exceptions T1 
WHERE T1.CurrentPolicyDuration <> PriorPolicyDuration
AND PeriodOrder > 1

DROP TABLE IF EXISTS #TriFocusChange
SELECT   4 AS ValidationType
		, t1.pk_Validation
		, t1.BK_PolicyNumber
		, t1.PK_Policy
		, t1.FK_AccountingPeriod
		, t1.CurrentPolicyType
		, t1.CurrentPolicyDuration
		, t1.CurrentTriFocus
		, t1.CurrentPeriodChange
		, t1.PriorPeriod
		, t1.PriorPolicyType
		, t1.PriorPolicyDuration
		, t1.PriorTriFocus
		, t1.PeriodOrder
INTO #TriFocusChange
FROM #Exceptions T1 
WHERE CurrentTriFocus <> PriorTriFocus
AND PeriodOrder > 1

DROP TABLE IF EXISTS #NewPolicies
SELECT   5 AS ValidationType
		, t1.pk_Validation
		, t1.BK_PolicyNumber
		, t1.PK_Policy
		, t1.FK_AccountingPeriod
		, t1.CurrentPolicyType
		, t1.CurrentPolicyDuration
		, t1.CurrentTriFocus
		, t1.CurrentPeriodChange
		, t1.PriorPeriod
		, t1.PriorPolicyType
		, t1.PriorPolicyDuration
		, t1.PriorTriFocus
		, t1.PeriodOrder
INTO #NewPolicies
FROM #Exceptions T1 
WHERE PeriodOrder = 1


--Final Select 

DROP TABLE IF EXISTS #TempValidations

;WITH [InitialValidations] AS
(SELECT * FROM #DeltaChange
	UNION 
 SELECT * FROM #PolicyTypeChange
	UNION 
 SELECT * FROM #PolicyDurationChange
	UNION 
 SELECT * FROM #TriFocusChange
	UNION 
 SELECT * FROM #NewPolicies
)
SELECT *,[QUARTER]=CASE WHEN RIGHT(FK_AccountingPeriod,2) IN (01,02) then CAST( LEFT(FK_AccountingPeriod,4)+'Q1'AS varchar(10))
				WHEN RIGHT(FK_AccountingPeriod,2) IN (03,04,05) then CAST( LEFT(FK_AccountingPeriod,4)+'Q2' AS VARCHAR(10))
				WHEN RIGHT(FK_AccountingPeriod,2) IN (06,07,08) then CAST( LEFT(FK_AccountingPeriod,4)+'Q3' AS VARCHAR(10))
				WHEN RIGHT(FK_AccountingPeriod,2) IN (09,10,11) then CAST( LEFT(FK_AccountingPeriod,4)+'Q4' AS VARCHAR(10))
				WHEN RIGHT(FK_AccountingPeriod,2) IN (12) then CAST( (LEFT(FK_AccountingPeriod+100,4))+'Q1' AS VARCHAR(10))
				ELSE CAST(FK_AccountingPeriod AS VARCHAR(10))
				END
INTO #TempValidations
FROM [InitialValidations]
--WHERE BK_PolicyNumber IN  ('JAC50Z20ANHH','B6563B20DNSJ','B7919L20AFLC')

-----------------------------------------------------------------------------------------------------------------------------------------
-- Updated on 07-May-2021 to show one record with Sum of Movement on Quarterwise If movement happen twice/thrice in QuarterPeriod
-- FDM-768 as requested by James H
-----------------------------------------------------------------------------------------------------------------------------------------

;WITH PeriodMovement 
AS (
		SELECT BK_PolicyNumber,[QUARTER],MAX(FK_AccountingPeriod) AS AccountingPeriod,SUM(CurrentPeriodChange) as Movement
		FROM #TempValidations
		GROUP BY BK_PolicyNumber,[QUARTER]
	)
, ValidationColumns
AS	(	SELECT BK_PolicyNumber,CurrentTriFocus,PK_Policy,CurrentPolicyDuration,PriorPolicyDuration,[QUARTER],CurrentPeriodChange,fk_accountingperiod
				,ValidationType,pk_Validation,CurrentPolicyType,PriorPeriod,PriorPolicyType,PriorTriFocus,PeriodOrder
		FROM #TempValidations
	)
	
	--Final Select

	SELECT b.ValidationType,b.pk_Validation,PM.BK_PolicyNumber,b.PK_Policy,PM.AccountingPeriod as fk_AccountingPeriod
			,b.CurrentPolicyType,b.CurrentPolicyDuration,b.CurrentTriFocus,PM.Movement AS CurrentPeriodChange,b.PriorPeriod
			,b.PriorPolicyType,b.PriorPolicyDuration,b.PriorTriFocus,b.PeriodOrder,PM.[Quarter] AS QuarterPeriod
	FROM PeriodMovement AS PM
	INNER JOIN ValidationColumns B	ON PM.BK_PolicyNumber = B.BK_PolicyNumber
	WHERE 1=1
	--AND PM.BK_PolicyNumber IN ('JAC50Z20ANHH') 
	AND B.fk_accountingPeriod =PM.AccountingPeriod
	--AND A.[quarter] = '2021Q1'

---------------------------------------------------------------------------------------------------------------------------------------
--End of change 07-May-2021
---------------------------------------------------------------------------------------------------------------------------------------



END
