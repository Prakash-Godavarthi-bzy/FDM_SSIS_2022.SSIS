﻿
CREATE PROCEDURE [dbo].[usp_UpdateAssumptionDataset] 
AS
BEGIN


declare @max_datetime Datetime 
select @max_datetime= max(RunDateTime)from stg.PowerAppsAuditLog

--print @max_datetime

Update dim.AssumptionDatasets  
set IsDatasetAlreadyUsed = 1 
where AssumptionDatasetName 
in (
	Select distinct Dataset 
	from (
		Select Distinct [ADM] as Dataset From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Pure IELR Q1]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Pure IELR Q2]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Pure IELR Q3]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Pure IELR Q4]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Pure IELR Q5]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Pure IELR SM]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Team IELR Q1]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Team IELR Q2]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Team IELR Q3]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Team IELR Q4]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Team IELR Q5]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Team IELR SM]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [ENIDs Q1]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [ENIDs Q2]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [ENIDs Q3]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [ENIDs Q4]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [ENIDs Q5]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [ENIDs SM]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Discount Rate Q1]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Discount Rate Q2]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Discount Rate Q3]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Discount Rate Q4]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Discount Rate Q5]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Discount Rate SM]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [FX Rate Name (Avg)]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [FX Rate Name (Spot)]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Admin Expense Q1 (Claims Related)]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Admin Expense Q2 (Claims Related)]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Admin Expense Q3 (Claims Related)]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Admin Expense Q4 (Claims Related)]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Admin Expense Q5 (Claims Related)]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Admin Expense SM (Claims Related)]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Admin Expense Q1 (other)]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Admin Expense Q2 (other)]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Admin Expense Q3 (other)]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Admin Expense Q4 (other)]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Admin Expense Q5 (other)]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Admin Expense SM (other)]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Admin Expense Q1 (Premium Related)]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Admin Expense Q2 (Premium Related)]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Admin Expense Q3 (Premium Related)]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Admin Expense Q4 (Premium Related)]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Admin Expense Q5 (Premium Related)]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Admin Expense SM (Premium Related)]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Claims Handling Expenses Q1]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Claims Handling Expenses Q2]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Claims Handling Expenses Q3]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Claims Handling Expenses Q4]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Claims Handling Expenses Q5]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Claims Handling Expenses SM]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Other Acquisition Expenses Q1]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Other Acquisition Expenses Q2]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Other Acquisition Expenses Q3]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Other Acquisition Expenses Q4]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Other Acquisition Expenses Q5]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Other Acquisition Expenses SM]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Profit Commission Q1]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Profit Commission Q2]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Profit Commission Q3]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Profit Commission Q4]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Profit Commission Q5]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Profit Commission SM]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Reinstatement Premium Q1]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Reinstatement Premium Q2]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Reinstatement Premium Q3]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Reinstatement Premium Q4]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Reinstatement Premium Q5]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Reinstatement Premium SM]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime   union all
		Select Distinct [Pattern Scenario]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime  union all
		Select Distinct [Adjustments]  From stg.MappingTotransformationLog  where AuditDateTime>= @max_datetime
		)  a where Dataset is not null

	)

Update stg.PowerAppsAuditLog set RunDateTime=GetDate();


END