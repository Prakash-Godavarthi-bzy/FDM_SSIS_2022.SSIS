﻿CREATE PROCEDURE [IFRS17].[usp_PremDataIncrementalLoad] (@AccPer INT,@StorePAccList VARCHAR(MAX))
AS
BEGIN
--DECLARE @AccPer INT = 201812
--,@StorePAccList VARCHAR(MAX) = 
--('P-RP-P-FAC:BusinessPlanRI,P-GP-B:Eurobase,GP-T-PR:ReservingData,P-AC-P:BusinessPlan,PC-LS-OR-TTY:Ceded_Re_ORC,P-AC-P:BICI,P-AC-P:BIDAC,P-AC-B:PFT_FORECAST,P-RP-P-FAC:ObligatedPremium_RISpend,P-GP-P:PFT_FORECAST,P-AC-B:PFT,P-AC-P:PFT,GP-T-PR:ReservingData_TOPUP,RP-T-PR:ReservingData,P-RP-P-TTY:BusinessPlanRI,P-AC-P:Eurobase,P-RP-P-TTY:ObligatedPremium_RISpend,RP-ULT-R-TTY:Earned_RIP_RISpend,P-OR-P-TTY:Reinsurance_Overriding_Commission,GPE-RP-P:EPI Reinstatement Eurobase,P-AC-B:Eurobase,P-GP-P:USPremium,RP-T-PR:ReservingDataPremiumAlloc,RP-ULT-G:RIPsEventAlloc,P-GP-P:Eurobase,P-GP-B:PFT_FORECAST,P-GP-P:PFT,P-GP-B:PFT,P-AC-P:USPremium,P-GP-P:BICI,P-GP-P:BIDAC,P-AC-B:BusinessPlan,P-RP-P-FAC:BICI_RI_Ultimate_Premium,GP-P-PR:ReservingData,P-AC-P:PFT_FORECAST,P-OR-P-FAC:Reinsurance_Overriding_Commission,P-GP-B:BusinessPlan,P-GP-P:BusinessPlan,P-RP-P-TTY:ObligatedPremium_SPA,P-RP-P-TTY:BICI_RI_Ultimate_Premium,RP-P-PR:ReservingData,PC-LS-OR-FAC:Ceded_Re_ORC,P-RP-P-TTY:ObligatedPremium_Munich_QQS')

;WITH SelectedDatasetAccount AS
(
SELECT SelectedList ,substring(SelectedList, (charindex(':',SelectedList)+1),len(SelectedList)) Dataset,
substring(SelectedList, 1,(charindex(':',SelectedList) - 1)) Account
FROM (SELECT RTRIM(LTRIM(value)) SelectedList
		FROM STRING_SPLIT(@StorePAccList, ',')
	)A
)
--SELECT * FROM SelectedDatasetAccount


SELECT
      FK_Batch
      ,[EarningPercentage]
      ,[Fk_statscode]
      ,[FK_Policy]
      ,[ROWHASH]
      ,[FK_InceptionYear]
      ,[InceptionPeriod]
      ,[BusinessKey]
      ,[Att_Cat]
      ,[FK_TriangleGroup]
      ,[FK_ReservingDataset]
      ,[FK_Allocation]
      ,[FK_Account]
      ,CAST([FK_Basis] AS VARCHAR(10)) [FK_Basis]
      ,CAST([FK_CatCode] AS VARCHAR(90)) [FK_CatCode]
      ,[FK_ClaimExposure]
      ,case [FK_DataSet] when 'ObligatedPremium_MunichQQS' then 'ObligatedPremium_Munich_QQS' else  [FK_DataSet] end as [FK_DataSet]
      ,[FK_DataStage]
      ,CAST([FK_DATE] AS INT) [FK_DATE]
      ,[FK_Entity]
      ,[FK_PolicySection]
      ,[FK_Location]
      ,[FK_Movementype]
      ,[FK_Process]
      ,[FK_Product]
      ,[FK_ProgrammeCode]
      ,[FK_RIPolicyType]
      ,case [FK_DataSet] when 'ObligatedPremium_MunichQQS' then 'A' else [FK_Scenario] end [FK_Scenario]
      ,[FK_TrackingStatus]
      ,[FK_Trifocus]
      ,[FK_YOA]
      ,[FK_CCYOriginal]
      ,[FK_CCYSettlement]
      ,[ClaimBasis]
	  ,MOPCode
	  ,FK_InceptionDate
	  ,ExpiryDate
      ,Max(CAST([FK_AccountingPeriod] AS INT) ) [FK_AccountingPeriod]
      ,SUM([Value]) AS [Value]  
FROM [IFRS17].[fct_TechnicalResult] T1
INNER JOIN SelectedDatasetAccount T2 ON T1.FK_Account = T2.Account AND T1.FK_DataSet = T2.Dataset 
WHERE 
1 = 1
AND [FK_Process] = 'IP' 
AND [FK_AccountingPeriod]  =  @AccPer   
GROUP BY FK_Batch
      ,[EarningPercentage]
      ,[Fk_statscode]
      ,[FK_Policy]
      ,[ROWHASH]
      ,[FK_InceptionYear]
      ,[InceptionPeriod]
      ,[BusinessKey]
      ,[Att_Cat]
      ,[FK_TriangleGroup]
      ,[FK_ReservingDataset]
      ,[FK_Allocation]
      ,[FK_Account]
      ,CAST([FK_Basis] AS VARCHAR(10))
      ,CAST([FK_CatCode] AS VARCHAR(90))
      ,[FK_ClaimExposure]
      ,case [FK_DataSet] when 'ObligatedPremium_MunichQQS' then 'ObligatedPremium_Munich_QQS' else [FK_DataSet] end 
      ,[FK_DataStage]
      ,CAST([FK_DATE] AS INT)
      ,[FK_Entity]
      ,[FK_PolicySection]
      ,[FK_Location]
      ,[FK_Movementype]
      ,[FK_Process]
      ,[FK_Product]
      ,[FK_ProgrammeCode]
      ,[FK_RIPolicyType]
      ,case [FK_DataSet] when 'ObligatedPremium_MunichQQS' then 'A' else [FK_Scenario] end 
      ,[FK_TrackingStatus]
      ,[FK_Trifocus]
      ,[FK_YOA]
      ,[FK_CCYOriginal]
      ,[FK_CCYSettlement]
      ,ClaimBasis
	  ,MOPCode
	  ,FK_InceptionDate
	  ,ExpiryDate


END