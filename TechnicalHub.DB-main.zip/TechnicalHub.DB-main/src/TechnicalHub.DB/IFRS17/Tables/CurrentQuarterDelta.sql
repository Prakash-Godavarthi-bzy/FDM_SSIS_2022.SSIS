﻿CREATE TABLE [IFRS17].[CurrentQuarterDelta](
	[BatchID] [int] NOT NULL,
	[DeltaTypeFlag] [varchar](25) NOT NULL,
	[Extract] [char](5) NOT NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[LoadType] [varchar](25) NOT NULL
) ON [PRIMARY]
GO
