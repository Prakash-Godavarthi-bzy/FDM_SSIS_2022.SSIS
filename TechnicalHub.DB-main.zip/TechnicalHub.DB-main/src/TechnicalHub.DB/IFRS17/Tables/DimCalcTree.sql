﻿CREATE TABLE [dbo].[DimCalcTree] (
    [PK_CalculationTree]       NVARCHAR (2000) NOT NULL,
    [BusinessCode]             NVARCHAR (2000) NULL,
    [CalculationTreeName]      NVARCHAR (2000) NULL,
    [FK_CalculationTreeParent] NVARCHAR (2000) NULL,
    [Operator]                 NVARCHAR (2000) NULL,
    [MDX]                      NVARCHAR (2000) NULL,
    [SortOrder]                NVARCHAR (2000) NULL,
    [PropertiesFormat]         NVARCHAR (2000) NULL,
    [Description]              NVARCHAR (2000) NULL,
    [Finalised]                NVARCHAR (2000) NULL,
    [Release]                  NVARCHAR (2000) NULL,
    [Sourced]                  NVARCHAR (2000) NULL,
    [Item_URN]                 NVARCHAR (2000) NULL,
    [SME/DataSteward]          NVARCHAR (2000) NULL,
    [Notes]                    NVARCHAR (2000) NULL,
    [ValidFrom]                DATETIME2 (7)   NOT NULL,
    [ValidTo]                  DATETIME2 (7)   NOT NULL
);

