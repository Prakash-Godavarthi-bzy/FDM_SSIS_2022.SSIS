﻿CREATE TABLE [dbo].[TestResult] (
    [CalcTree]  VARCHAR (20) NULL,
    [FromCube]  INT          NULL,
    [DateStamp] CHAR (20)    NULL
);

