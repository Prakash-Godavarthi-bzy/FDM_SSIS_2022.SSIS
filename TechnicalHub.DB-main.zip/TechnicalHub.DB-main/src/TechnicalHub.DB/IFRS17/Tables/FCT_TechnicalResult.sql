﻿CREATE TABLE [IFRS17].[FCT_TechnicalResult](
	[Pk_RowID] [bigInt] IDENTITY(1,1)  NOT NULL,
	[PK_FTH] [bigint] NOT NULL,
	[FK_Batch] [int] NOT NULL,
	[Value] [float] NULL,
	[EarningPercentage] [numeric](38, 10) NULL,
	[Fk_statscode] [varchar](25) NULL,
	[FK_Policy] [varchar](255) NOT NULL,
	[ROWHASH] [varbinary](8000) NOT NULL,
	[FK_InceptionDate] [date] NULL,
	[FK_InceptionYear] [int] NULL,
	[InceptionPeriod] [int] NULL,
	[BusinessKey] [varchar](255) NOT NULL,
	[Att_Cat] [varchar](1) NULL,
	[FK_TriangleGroup] [varchar](100) NULL,
	[FK_ReservingDataset] [varchar](100) NULL,
	[FK_Allocation] [int] NULL,
	[FK_Account] [varchar](50) NULL,
	[ReviewCycle] [int] NULL,
	[FK_AccountingPeriod] [bigint] NULL,
	[FK_Basis] [varchar](100) NULL,
	[FK_CatCode] [varchar](100) NULL,
	[FK_ClaimExposure] [varchar](255) NULL,
	[FK_DataSet] [varchar](255) NULL,
	[FK_DataStage] [int] NULL,
	[FK_DATE] [bigint] NULL,
	[FK_DateOfFact] [bigint] NULL,
	[FK_Entity] [varchar](25) NULL,
	[FK_PolicySection] [varchar](255) NULL,
	[FK_Location] [varchar](50) NULL,
	[FK_Movementype] [varchar](50) NULL,
	[FK_Process] [varchar](10) NULL,
	[FK_Product] [varchar](10) NULL,
	[FK_ProgrammeCode] [varchar](100) NOT NULL,
	[FK_RIPolicyType] [varchar](10) NULL,
	[FK_Scenario] [varchar](10) NULL,
	[FK_TrackingStatus] [varchar](50) NULL,
	[FK_Trifocus] [varchar](25) NULL,
	[FK_YOA] [varchar](10) NULL,
	[FK_CCYOriginal] [varchar](10) NULL,
	[FK_CCYSettlement] [varchar](10) NULL,
	[ExpiryDate] [datetime] NULL,
	[FK_SourceEntity] [varchar](25) NULL,
	[BK_DeltaType] [varchar](20) NULL,
	[GroupShare] [float] NULL,
	[Intercompany_PrioritySeq] [int] NULL,
	[ClaimBasis] [nvarchar](50) NULL,
	[MOPCode] [varchar](10) NULL,
	[AuditCreateDateTime] [Datetime] NULL,
	[Value100Prcnt] [float] NULL
) ON [PRIMARY]
GO

CREATE CLUSTERED COLUMNSTORE INDEX [CIX_IFRS17_FCT_TechnicalResult] ON [IFRS17].[FCT_TechnicalResult] WITH (DROP_EXISTING = OFF, COMPRESSION_DELAY = 0) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_FCT_TechnicalResult_FK_Account] ON [IFRS17].[FCT_TechnicalResult]
(
	[FK_Account] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO


CREATE NONCLUSTERED INDEX [IX_FCT_TechnicalResult_FK_Trifocus] ON [IFRS17].[FCT_TechnicalResult]
(
	[FK_Trifocus] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_FCT_TechnicalResult_FK_PolicySection] ON [IFRS17].[FCT_TechnicalResult]
(
	[FK_PolicySection] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_FCT_TechnicalResult_FK_DataSet] ON [IFRS17].[FCT_TechnicalResult]
(
	[FK_DataSet] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO


CREATE NONCLUSTERED INDEX [IX_FCT_TechnicalResult_FK_AccountingPeriod] ON [IFRS17].[FCT_TechnicalResult]
(
	[FK_AccountingPeriod] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO