﻿CREATE TABLE [dbo].[fct_WB_Earning Pattern] (
    [EarningPercent_0]      FLOAT (53)     NULL,
    [PK_CCY_1]              NVARCHAR (3)   NULL,
    [PK_TriFocus_2]         NVARCHAR (25)  NULL,
    [PK_YOA_3]              NVARCHAR (10)  NULL,
    [PK_InceptionYear_4]    INT            NULL,
    [InceptionQuarter_5]    NVARCHAR (6)   NULL,
    [PK_AccountingPeriod_6] INT            NULL,
    [PK_EarningCategory_7]  INT            NULL,
    [MS_AUDIT_TIME_8]       DATETIME       NULL,
    [MS_AUDIT_USER_9]       NVARCHAR (255) NULL
);

