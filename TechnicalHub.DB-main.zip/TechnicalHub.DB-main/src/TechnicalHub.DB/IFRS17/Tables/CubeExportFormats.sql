﻿CREATE TABLE [dbo].[CubeExportFormats] (
    [PK_Format]    INT          IDENTITY (1, 1) NOT NULL,
    [BusinessCode] VARCHAR (3)  NOT NULL,
    [FileFormat]   VARCHAR (10) NOT NULL,
    [OutputIndex]  INT          NOT NULL,
    [TreeStub]     CHAR (5)     NOT NULL,
    [FullTree]     CHAR (11)    NULL,
    [IncludeInRun] BIT          NOT NULL,
    [Runnable]     BIT          NOT NULL,
    [OutputFormat] INT          NULL,
    [FromCube]     BIT          NOT NULL
);

