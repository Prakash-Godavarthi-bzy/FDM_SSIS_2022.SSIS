﻿CREATE VIEW IFRS17.ReportingCurrency AS 
SELECT [PK_ReportingCurrencyCode]
      ,[ReportingCurrencyName]
      ,[ValidFrom]
      ,[ValidTo]
FROM [dim].[ReportingCurrency]


