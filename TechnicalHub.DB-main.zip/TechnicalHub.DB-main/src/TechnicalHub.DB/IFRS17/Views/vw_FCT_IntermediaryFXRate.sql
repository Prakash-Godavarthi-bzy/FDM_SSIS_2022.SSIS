﻿CREATE VIEW IFRS17.FCT_IntermediaryFXRate AS
SELECT [Pk_RequestId]
      ,[DatasetNameId]
      ,[PercentageTypeId]
      ,[LossType]
      ,[ReportingCurrency]
      ,[TransactionCurrency]
      ,[FXRate_0]
  FROM [fct].[IntermediaryFXRate]