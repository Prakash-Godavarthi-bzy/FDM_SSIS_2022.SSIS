﻿CREATE VIEW IFRS17.Account AS 
SELECT [BK_Account] As PK_Account
      ,[AccountName]
      ,[Level1Group]
      ,[Level2Group]
      ,[Level3Group]
      ,[RIFlag]
      ,[AuditSourceBatchID]
      ,[AuditCreateDateTime]
      ,[AuditUserCreate]
      ,[AuditHost]
      ,[ValidFrom]
      ,[ValidTo]
  FROM [dim].[Account]



