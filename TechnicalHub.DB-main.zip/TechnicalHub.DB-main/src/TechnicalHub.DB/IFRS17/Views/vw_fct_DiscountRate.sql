﻿CREATE VIEW IFRS17.fct_DiscountRate AS 
SELECT [PK_DiscountRates],
       [FK_Batch],
       [AsAtDate],
       [DiscountRateName],
       [DiscountRateKey],
       [DataSet],
       [SettlementCCY],
       [CumulativeDevelopmentPercentage],
       [DevelopmentYear],
       [AssumptionDatasetName]
FROM   [fct].[DiscountRate]




