﻿CREATE VIEW [IFRS17].[vw_fct_TechnicalResult]
AS
(
		SELECT TR.PK_FTH
                                                ,TR.FK_Batch
                                                ,TR.Value * ISNULL(TR.GroupShare, 1) AS [Value]
                                                ,TR.EarningPercentage
                                                ,TR.Fk_statscode
                                                ,TR.FK_Policy
                                                ,TR.ROWHASH
                                                ,CASE 
                                                                WHEN da.BK_Account = 'RP-T-PR'            
                                                                                AND d.BK_DataSet = 'ReservingDataPremiumAlloc'            
                                                                                AND dy.BK_YOA < '2016'                
                                                                                THEN cast(dy.BK_YOA + '0101' AS DATE)     
                                                                WHEN da.BK_Account = 'RP-T-PR'            
                                                                                AND d.BK_DataSet = 'ReservingDataPremiumAlloc'            
                                                                                AND pc.BK_ProgrammeCode IN (
                                                                                                'MUNQQS'
                                                                                                ,'Cede 6107'
                                                                                                ,'Cede 5623'
                                                                                                )                
                                                                                THEN cast(dy.BK_YOA + '0101' AS DATE)     
                                                                WHEN da.BK_Account = 'RP-T-PR'            
                                                                                AND d.BK_DataSet = 'ReservingDataPremiumAlloc'          
                                                                                AND dy.BK_YOA >= '2016'                
                                                                                THEN cast(isnull(risp.InceptionPeriod, (dy.BK_YOA + '01')) + '01' AS DATE)     
                                                                WHEN d.BK_DataSet IN (
                                                                                                'ObligatedPremium_SPA'
                                                                                                ,'ObligatedPremium_Munich_QQS'
                                                                                                )
                                                                                THEN cast(dy.BK_YOA + '0101' AS DATE)     
                                                                WHEN d.BK_DataSet <> 'ObligatedPremium_RISpend'            
                                                                                AND ri.BK_RIPolicyType IN (
                                                                                                'PPNL'
                                                                                                ,'QQ'
                                                                                                ,'QS'
                                                                                                ,'Surplus'
                                                                                                ,'UCT'
                                                                                                )                
                                                                                THEN cast(dy.BK_YOA + '0101' AS DATE)     
                                                                WHEN YEAR(inc_dt.DATE) = '1980'            
                                                                                THEN CAST(DY.BK_YOA + CAST(RIGHT(LTRIM(RTRIM(DP.BK_AccountingPeriod)), 2) AS VARCHAR(2)) + '01' AS DATE)          
                                                                ELSE inc_dt.Date  
                                                                END AS FK_InceptionDate
                                                ,CASE 
                                                                WHEN da.BK_Account = 'RP-T-PR'            
                                                                                AND d.BK_DataSet = 'ReservingDataPremiumAlloc'            
                                                                                AND dy.BK_YOA < '2016'                
                                                                                THEN dy.BK_YOA      
                                                                WHEN da.BK_Account = 'RP-T-PR'            
                                                                                AND d.BK_DataSet = 'ReservingDataPremiumAlloc'            
                                                                                AND pc.BK_ProgrammeCode IN (
                                                                                                'MUNQQS'
                                                                                                ,'Cede 6107'
                                                                                                ,'Cede 5623'
                                                                                                )              
                                                                                THEN dy.BK_YOA      
                                                                WHEN da.BK_Account = 'RP-T-PR'            
                                                                                AND d.BK_DataSet = 'ReservingDataPremiumAlloc'          
                                                                                AND dy.BK_YOA >= '2016'                
                                                                                THEN isnull(left(risp.InceptionPeriod, 4), dy.BK_YOA)     
                                                                WHEN d.BK_DataSet IN (
                                                                                                'ObligatedPremium_SPA'
                                                                                                ,'ObligatedPremium_Munich_QQS'
                                                                                                )
                                                                                THEN dy.BK_YOA     
                                                                WHEN d.BK_DataSet <> 'ObligatedPremium_RISpend'            
                                                                                AND ri.BK_RIPolicyType IN (
                                                                                                'PPNL'
                                                                                                ,'QQ'
                                                                                                ,'QS'
                                                                                                ,'Surplus'
                                                                                                ,'UCT'
                                                                                                )                
                                                                                THEN dy.BK_YOA      
                                                                WHEN TR.FK_InceptionYear = '1980'
                                                                                THEN DY.BK_YOA
                                                                ELSE TR.FK_InceptionYear 
                                                                END AS FK_InceptionYear
                                                ,CASE 
                                                                WHEN da.BK_Account = 'RP-T-PR'            
                                                                                AND d.BK_DataSet = 'ReservingDataPremiumAlloc'            
                                                                                AND dy.BK_YOA < '2016'                
                                                                                THEN dy.BK_YOA + '01'     
                                                                WHEN da.BK_Account = 'RP-T-PR'            
                                                                                AND d.BK_DataSet = 'ReservingDataPremiumAlloc'            
                                                                                AND pc.BK_ProgrammeCode IN (
                                                                                                'MUNQQS'
                                                                                                ,'Cede 6107'
                                                                                                ,'Cede 5623'
                                                                                                )                
                                                                                THEN dy.BK_YOA + '01'     
                                                                WHEN da.BK_Account = 'RP-T-PR'            
                                                                                AND d.BK_DataSet = 'ReservingDataPremiumAlloc'          
                                                                                AND dy.BK_YOA >= '2016'                
                                                                                THEN isnull(risp.InceptionPeriod, (dy.BK_YOA + '01'))     
                                                                WHEN d.BK_DataSet IN (
                                                                                                'ObligatedPremium_SPA'
                                                                                                ,'ObligatedPremium_Munich_QQS'
                                                                                                )
                                                                                THEN dy.BK_YOA + '01'     
                                                                WHEN d.BK_DataSet <> 'ObligatedPremium_RISpend'            
                                                                                AND ri.BK_RIPolicyType IN (
                                                                                                'PPNL'
                                                                                                ,'QQ'
                                                                                                ,'QS'
                                                                                                ,'Surplus'
                                                                                                ,'UCT'
                                                                                                )                
                                                                                THEN dy.BK_YOA + '01'     
                                                                WHEN LEFT(TR.InceptionPeriod, 4) = '1980'        
                                                                                THEN CAST(DY.BK_YOA + CAST(RIGHT(LTRIM(RTRIM(DP.BK_AccountingPeriod)), 2) AS VARCHAR(2)) AS INT)     
                                                                ELSE TR.InceptionPeriod
                                                                END AS InceptionPeriod
                                                ,TR.BusinessKey
                                                ,TR.Att_Cat
                                                ,DTG.[BK_TriangleGroup] AS FK_TriangleGroup
                                                ,DRD.[BK_ReservingDataSet] AS FK_ReservingDataset
                                                ,TR.FK_Allocation
                                                ,DA.BK_Account AS FK_Account
                                                ,DP.BK_AccountingPeriod AS ReviewCycle
                                                ,case when D.BK_DataSet = 'PFT' 
                                                                                then cast(left(convert(varchar, dateadd(quarter, 1, cast(cast(DP.BK_AccountingPeriod as varchar) + '01' as date)), 112), 6) as int)
                                                                  else DP.BK_AccountingPeriod 
                                                 end AS FK_AccountingPeriod
                                                ,DB.BK_Basis AS FK_Basis
                                                ,DC.BK_CatCode AS FK_CatCode
                                                ,CE.BK_ClaimExposure AS FK_ClaimExposure
                                                ,D.BK_DataSet as FK_DataSet
                                                --,case when D.BK_DataSet = 'PFT' then 'PFT_FORECAST' else D.BK_DataSet end AS FK_DataSet
                                                ,DS.PK_DataStage AS FK_DataStage
                                                ,DT.BK_Date AS FK_DATE
                                                ,dof_dt.BK_Date AS FK_DateOfFact
                                                ,DE.BK_Entity AS FK_Entity
                                                ,PS.BK_PolicySection AS FK_PolicySection
                                                ,DL.BK_Location AS FK_Location
                                                ,DM.BK_MovementType AS FK_Movementype
                                                ,P.BK_Process AS FK_Process
                                                ,Pr.BK_Product AS FK_Product
                                                ,CASE 
                                                                WHEN DA.RIFlag = 'I'
                                                                                AND PC.BK_ProgrammeCode <> 'Consol Adj'
                                                                                THEN 'GROSS'
                                                                ELSE ISNULL(PC.BK_ProgrammeCode, 'Unknown')
                                                                END AS FK_ProgrammeCode
                                                ,RI.BK_RIPolicyType AS FK_RIPolicyType
                                                ,S.BK_Scenario AS FK_Scenario
                                                ,TS.BK_TrackingStatus AS FK_TrackingStatus
                                                ,T.BK_TriFocus AS FK_Trifocus
                                                ,DY.BK_YOA AS FK_YOA
                                                ,DCO.BK_CCY AS FK_CCYOriginal
                                                ,DCY.BK_CCY AS FK_CCYSettlement
                                                ,CASE 
                                                                WHEN da.BK_Account = 'RP-T-PR'            
                                                                                AND d.BK_DataSet = 'ReservingDataPremiumAlloc'            
                                                                                AND dy.BK_YOA < '2016'                
                                                                                THEN dateadd(day, - 1, dateadd(year, 1, cast(dy.BK_YOA + '0101' AS DATE)))     
                                                                WHEN da.BK_Account = 'RP-T-PR'            
                                                                                AND d.BK_DataSet = 'ReservingDataPremiumAlloc'            
                                                                                AND pc.BK_ProgrammeCode IN (
                                                                                                'MUNQQS'
                                                                                                ,'Cede 6107'
                                                                                                ,'Cede 5623'
                                                                                                )                
                                                                                THEN dateadd(day, - 1, dateadd(year, 1, cast(dy.BK_YOA + '0101' AS DATE)))     
                                                                WHEN da.BK_Account = 'RP-T-PR'            
                                                                                AND d.BK_DataSet = 'ReservingDataPremiumAlloc'          
                                                                                AND dy.BK_YOA >= '2016'                
                                                                                THEN dateadd(day, - 1, dateadd(year, 1, cast(isnull(risp.InceptionPeriod, (dy.BK_YOA + '01')) + '01' AS DATE)))     
                                                                WHEN d.BK_DataSet IN (
                                                                                                'ObligatedPremium_SPA'
                                                                                                ,'ObligatedPremium_Munich_QQS'
                                                                                                )
                                                                                THEN dateadd(day, - 1, dateadd(year, 1, cast(dy.BK_YOA + '0101' AS DATE)))     
                                                                WHEN d.BK_DataSet <> 'ObligatedPremium_RISpend'            
                                                                                AND ri.BK_RIPolicyType IN (
                                                                                                'PPNL'
                                                                                                ,'QQ'
                                                                                                ,'QS'
                                                                                                ,'Surplus'
                                                                                                ,'UCT'
                                                                                                )                
                                                                                THEN dateadd(day, - 1, dateadd(year, 1, cast(dy.BK_YOA + '0101' AS DATE)))          
                                                                WHEN YEAR(PS.ExpiryDate) = '1980'         
                                                                                THEN EOMONTH(DATEADD(YEAR, 1, DATEADD(MONTH, - 1, CAST(DY.BK_YOA + CAST(RIGHT(LTRIM(RTRIM(BK_AccountingPeriod)), 2) AS VARCHAR(2)) + '01' AS DATETIME))))     
                                                                ELSE PS.ExpiryDate
                                                                END AS ExpiryDate
                                                ,DEY.BK_Entity AS FK_SourceEntity
                                                ,DEL.BK_DeltaType
                                                ,TR.GroupShare
                                                ,TR.Intercompany_PrioritySeq
                                                ,ClaimBasis = COALESCE(NULLIF(gcb.ClaimBasis, '-1'), CASE 
                                                                                WHEN RI.BK_RIPolicyType = 'FAC'
                                                                                                AND ps.PolicyReference <> 'NOPOLICY'
                                                                                                AND RCB.ClaimBasis = 'Unknown'
                                                                                                THEN 'RAD'
                                                                                ELSE RCB.ClaimBasis
                                                                                END, 'Unknown')
                                                ,MOPCode = COALESCE(PS.PolicyMOPCode, 'Unknown')
												,TR.[Value] as Value100Prcnt --I1B-5913
												
                                FROM fct.TechnicalResult TR
                                LEFT JOIN Dim.Account DA ON DA.PK_Account = TR.FK_Account
                                LEFT JOIN Dim.AccountingPeriod DP ON DP.PK_AccountingPeriod = TR.FK_AccountingPeriod
                                LEFT JOIN Dim.Basis DB ON DB.PK_Basis = TR.FK_Basis
                                LEFT JOIN Dim.CatCode DC ON DC.PK_CatCode = TR.FK_CatCode
                                LEFT JOIN Dim.ClaimExposure CE ON CE.PK_ClaimExposure = TR.FK_ClaimExposure
                                LEFT JOIN Dim.DataSet D ON D.PK_DataSet = TR.FK_DataSet
                                LEFT JOIN Dim.DataStage DS ON DS.PK_DataStage = TR.FK_DataStage
                                LEFT JOIN Dim.DATE DT ON DT.PK_Date = TR.FK_DateDue
                                LEFT JOIN Dim.Entity DE ON DE.PK_Entity = TR.FK_Entity
                                LEFT JOIN Dim.PolicySection PS ON PS.PK_PolicySection = TR.FK_PolicySection
                                LEFT JOIN Dim.Location DL ON DL.PK_Location = TR.FK_Location
                                LEFT JOIN Dim.MovementType DM ON DM.PK_MovementType = TR.FK_MovementType
                                LEFT JOIN Dim.Process P ON P.PK_Process = TR.FK_Process
                                LEFT JOIN Dim.Product PR ON PR.PK_Product = TR.FK_Product
                                LEFT JOIN Dim.ProgrammeCode PC ON PC.PK_ProgrammeCode = TR.FK_ProgrammeCode
                                LEFT JOIN Dim.RIPolicyType RI ON RI.PK_RIPolicyType = TR.FK_RIPolicyType
                                LEFT JOIN Dim.Scenario S ON S.PK_Scenario = TR.FK_Scenario
                                LEFT JOIN Dim.TrackingStatus TS ON TS.PK_TrackingStatus = TR.FK_TrackingStatus
                                LEFT JOIN Dim.TriFocus T ON T.PK_TriFocus = TR.FK_Trifocus
                                LEFT JOIN Dim.YOA DY ON DY.PK_YOA = TR.FK_YOA
                                LEFT JOIN Dim.CCY DCY ON DCY.PK_CCY = TR.FK_CCYSettlement
                                LEFT JOIN Dim.CCY DCO ON DCO.PK_CCY = TR.FK_CCYOriginal
                                LEFT JOIN Dim.TriangleGroup DTG ON DTG.PK_TriangleGroup = TR.FK_TriangleGroup
                                LEFT JOIN Dim.ReservingDataset DRD ON DRD.PK_ReservingDataset = TR.FK_ReservingDataset
                                LEFT JOIN Dim.DATE inc_dt ON TR.FK_InceptionDate = inc_dt.PK_Date
                                LEFT JOIN Dim.DATE dof_dt ON TR.FK_DateOfFact = dof_dt.PK_Date
                                LEFT JOIN Dim.Entity DEY ON DEY.PK_Entity = TR.FK_SourceEntity
                                LEFT JOIN Dim.DeltaType DEL ON DEL.PK_DeltaType = TR.FK_DeltaType
                                LEFT JOIN (
                                                SELECT RIPolicyNumber
                                                                ,MAX(ClaimBasis) ClaimBasis
                                                FROM (
                                                                SELECT DISTINCT RIPolicyNumber
                                                                                ,RIBasis ClaimBasis
                                                                FROM [dbo].[fdm_DimRIPolicy]
                                                                -- WHERE RIType <>  'QS'
                                                                
                                                                UNION ALL
                                                                
                                                                SELECT RI_Section_Reference
                                                                                ,Claim_Basis
                                                                FROM [dbo].[ReInsuranceTreatyContractAttributes]
                                                                ) t
                                                GROUP BY RIPolicyNumber
                                                ) RCB ON (RCB.RIPolicyNumber = PS.PolicyReference)
                                LEFT JOIN (
                                                SELECT ps.PolicyReference
                                                                ,max(CASE 
                                                                                                WHEN (ps.PolicyClaimBasis = 'Unknown' OR ps.PolicyClaimBasis='NULL')
                                                                                                                THEN '-1'
                                                                                                ELSE PolicyClaimBasis
                                                                                                END) ClaimBasis
                                                FROM dim.PolicySection ps						
                                                GROUP BY ps.PolicyReference
                                                ) gcb ON (gcb.PolicyReference = ps.PolicyReference) 
                                LEFT JOIN (
                                                SELECT 
                                                                
                                                                                                                FK_ProgrammeCode
                                                                                                                , FK_Trifocus
                                                                                                                , FK_Entity
                                                                                                                , FK_YOA
                                                                                                                , cast(min(InceptionPeriod) AS VARCHAR) InceptionPeriod 
                                                                                                                FROM [fct].[TechnicalResult] t 
                                                                                                                INNER JOIN [dim].[DataSet] ds ON (ds.PK_DataSet = t.FK_DataSet)
                                                                
                                                                                                                WHERE BK_DataSet = 'ObligatedPremium_RISpend' 
                                                                                                                GROUP BY FK_ProgrammeCode, FK_Trifocus, FK_YOA,   FK_Entity
                                                                                ) RISP ON (RISP.FK_ProgrammeCode = pc.PK_ProgrammeCode
                                                                                                                                                AND risp.FK_YOA = dy.PK_YOA
                                                                                                                                                AND risp.FK_Trifocus = t.PK_TriFocus
                                                                                                                                                AND risp.FK_Entity = de.PK_Entity
                                                                                                                                                AND d.BK_DataSet = 'ReservingDataPremiumAlloc')
                                WHERE (
                                                                DE.BK_Entity <> '6107'
                                                                AND DA.BK_Account NOT IN ('P-RI-P','P-RI-B')																
                                                                )
                                                --AND D.BK_DataSet <> 'PFT'
                                
                                UNION ALL
                                
/*=====================================================================================================
                PFT dataset with phasing aligned to transactional to be used for topup post 18 months 
                Sprint CV 4.0, JIRA https://beazley.atlassian.net/browse/I1B-3640 Sprint CV4
=========================================================================================================
                                SELECT [PK_FTH]
                                                ,[FK_Batch]
                                                ,[Value]
                                                ,[EarningPercentage]
                                                ,[Fk_statscode]
                                                ,[FK_Policy]
                                                ,[RowHash]
                                                ,[FK_InceptionDate]
                                                ,[FK_InceptionYear]
                                                ,[InceptionPeriod]
                                                ,[BusinessKey]
                                                ,[Att_Cat]
                                                ,[FK_TriangleGroup]
                                                ,[FK_ReservingDataset]
                                                ,[FK_Allocation]
                                                ,[FK_Account]
                                                ,[ReviewCycle]
                                                ,[FK_AccountingPeriod]
                                                ,[FK_Basis]
                                                ,[FK_CatCode]
                                                ,[FK_ClaimExposure]
                                                ,[FK_DataSet]
                                                ,[FK_DataStage]
                                                ,[FK_Date]
                                                ,[FK_DateOfFact]
                                                ,[FK_Entity]
                                                ,[FK_PolicySection]
                                                ,[FK_Location]
                                                ,[FK_MovementType]
                                                ,[FK_Process]
                                                ,[FK_Product]
                                                ,[FK_ProgrammeCode]
                                                ,[FK_RIPolicyType]
                                                ,[FK_Scenario]
                                                ,[FK_TrackingStatus]
                                                ,[FK_Trifocus]
                                                ,[FK_YOA]
                                                ,[FK_CCYOriginal]
                                                ,[FK_CCYSettlement]
                                                ,[Expirydate]
                                                ,[FK_SourceEntity]
                                                ,[FK_DeltaType]
                                                ,[GroupShare]
                                                ,[Intercompany_PrioritySeq]
                                                ,[Claimbasis]
                                                ,[MOPCode]
                                FROM [dbo].[PFTTechnicalResult]
                                
                                UNION ALL

=====================================================================================================
                Additional Reserving dataset with phasing aligned to tactical to be used post-36 months 
                Sprint CV 4.1, JIRA https://beazley.atlassian.net/browse/I1B-3664
=========================================================================================================
                                SELECT [PK_FTH]
                                                ,[FK_Batch]
                                                ,[Value]
                                                ,[EarningPercentage]
                                                ,[Fk_statscode]
                                                ,[FK_Policy]
                                                ,[RowHash]
                                                ,[FK_InceptionDate]
                                                ,[FK_InceptionYear]
                                                ,[InceptionPeriod]
                                                ,[BusinessKey]
                                                ,[Att_Cat]
                                                ,[FK_TriangleGroup]
                                                ,[FK_ReservingDataset]
                                                ,[FK_Allocation]
                                                ,[FK_Account]
                                                ,[ReviewCycle]
                                                ,[FK_AccountingPeriod]
                                                ,[FK_Basis]
                                                ,[FK_CatCode]
                                                ,[FK_ClaimExposure]
                                                ,[FK_DataSet]
                                                ,[FK_DataStage]
                                                ,[FK_Date]
                                                ,[FK_DateOfFact]
                                                ,[FK_Entity]
                                                ,[FK_PolicySection]
                                                ,[FK_Location]
                                                ,[FK_MovementType]
                                                ,[FK_Process]
                                                ,[FK_Product]
                                                ,[FK_ProgrammeCode]
                                                ,[FK_RIPolicyType]
                                                ,[FK_Scenario]
                                                ,[FK_TrackingStatus]
                                                ,[FK_Trifocus]
                                                ,[FK_YOA]
                                                ,[FK_CCYOriginal]
                                                ,[FK_CCYSettlement]
                                                ,[Expirydate]
                                                ,[FK_SourceEntity]
                                                ,[FK_DeltaType]
                                                ,[GroupShare]
                                                ,[Intercompany_PrioritySeq]
                                                ,[Claimbasis]
                                                ,[MOPCode]
                                FROM [dbo].[ADMTechnicalResult]
                                
                                UNION ALL
*/
                                
                                --select sum([value]) from
                                --(
                                /* =================================================================================================================================================================
                                                                                Reversing AgressoARUS data prior to 2016 is a Tactical Fix on Version C- Should be removed when implement Strategical Fix in Version D
====================================================================================================================================================================                */
                                SELECT TR.PK_FTH
                                                ,TR.FK_Batch
                                                ,- TR.Value * ISNULL(TR.GroupShare, 1) AS [Value]
                                                ,TR.EarningPercentage
                                                ,TR.Fk_statscode
                                                ,TR.FK_Policy
                                                ,TR.ROWHASH
                                                ,CASE 
                                                                WHEN YEAR(inc_dt.DATE) = '1980'
                                                                                THEN CAST(DY.BK_YOA + CAST(RIGHT(LTRIM(RTRIM(DP.BK_AccountingPeriod)), 2) AS VARCHAR(2)) + '01' AS DATE)
                                                                ELSE inc_dt.DATE
                                                                END AS FK_InceptionDate
                                                ,CASE 
                                                                WHEN TR.FK_InceptionYear = '1980'
                                                                                THEN DY.BK_YOA
                                                                ELSE TR.FK_InceptionYear
                                                                END AS FK_InceptionYear
                                                ,CASE 
                                                                WHEN LEFT(TR.InceptionPeriod, 4) = '1980'
                                                                                THEN CAST(DY.BK_YOA + CAST(RIGHT(LTRIM(RTRIM(DP.BK_AccountingPeriod)), 2) AS VARCHAR(2)) AS INT)
                                                                ELSE TR.InceptionPeriod
                                                                END AS InceptionPeriod
                                                ,TR.BusinessKey
                                                ,TR.Att_Cat
                                                ,DTG.[BK_TriangleGroup] AS FK_TriangleGroup
                                                ,DRD.[BK_ReservingDataSet] AS FK_ReservingDataset
                                                ,TR.FK_Allocation
                                                ,DA.BK_Account AS FK_Account
                                                ,DP.BK_AccountingPeriod AS ReviewCycle
                                                ,DP.BK_AccountingPeriod AS FK_AccountingPeriod
                                                ,DB.BK_Basis AS FK_Basis
                                                ,DC.BK_CatCode AS FK_CatCode
                                                ,CE.BK_ClaimExposure AS FK_ClaimExposure
                                                ,D.BK_DataSet AS FK_DataSet
                                                ,DS.PK_DataStage AS FK_DataStage
                                                ,DT.BK_Date AS FK_DATE
                                                ,dof_dt.BK_Date AS FK_DateOfFact
                                                ,DE.BK_Entity AS FK_Entity
                                                ,PS.BK_PolicySection AS FK_PolicySection
                                                ,DL.BK_Location AS FK_Location
                                                ,DM.BK_MovementType AS FK_Movementype
                                                ,P.BK_Process AS FK_Process
                                                ,Pr.BK_Product AS FK_Product
                                                ,CASE 
                                                                WHEN DA.RIFlag = 'I'
                                                                                AND PC.BK_ProgrammeCode <> 'Consol Adj'
                                                                                THEN 'GROSS'
                                                                ELSE ISNULL(PC.BK_ProgrammeCode, 'Unknown')
                                                                END AS FK_ProgrammeCode
                                                ,RI.BK_RIPolicyType AS FK_RIPolicyType
                                                ,S.BK_Scenario AS FK_Scenario
                                                ,TS.BK_TrackingStatus AS FK_TrackingStatus
                                                ,T.BK_TriFocus AS FK_Trifocus
                                                ,DY.BK_YOA AS FK_YOA
                                                ,DCO.BK_CCY AS FK_CCYOriginal
                                                ,DCY.BK_CCY AS FK_CCYSettlement
                                                ,CASE 
                                                                WHEN YEAR(PS.ExpiryDate) = '1980'
                                                                                THEN EOMONTH(DATEADD(YEAR, 1, DATEADD(MONTH, - 1, CAST(DY.BK_YOA + CAST(RIGHT(LTRIM(RTRIM(BK_AccountingPeriod)), 2) AS VARCHAR(2)) + '01' AS DATETIME))))
                                                                ELSE PS.ExpiryDate
                                                                END AS ExpiryDate
                                                ,
                                                --PS.ExpiryDate,
                                                DEY.BK_Entity AS FK_SourceEntity
                                                ,DEL.BK_DeltaType
                                                ,TR.GroupShare
                                                ,TR.Intercompany_PrioritySeq
                                                ,ClaimBasis = COALESCE(NULLIF(gcb.ClaimBasis, '-1'), CASE 
                                                                                WHEN RI.BK_RIPolicyType = 'FAC'
                                                                                                AND ps.PolicyReference <> 'NOPOLICY'
                                                                                                AND RCB.ClaimBasis = 'Unknown'
                                                                                                THEN 'RAD'
                                                                                ELSE RCB.ClaimBasis
                                                                                END, 'Unknown')
                                                ,MOPCode = COALESCE(PS.PolicyMOPCode, 'Unknown')
												,-TR.[Value] as Value100Prcnt --I1B-5913
												
                                FROM fct.TechnicalResult TR
                                LEFT JOIN Dim.Account DA ON DA.PK_Account = TR.FK_Account
                                LEFT JOIN Dim.AccountingPeriod DP ON DP.PK_AccountingPeriod = TR.FK_AccountingPeriod
                                LEFT JOIN Dim.Basis DB ON DB.PK_Basis = TR.FK_Basis
                                LEFT JOIN Dim.CatCode DC ON DC.PK_CatCode = TR.FK_CatCode
                                LEFT JOIN Dim.ClaimExposure CE ON CE.PK_ClaimExposure = TR.FK_ClaimExposure
                                LEFT JOIN Dim.DataSet D ON D.PK_DataSet = TR.FK_DataSet
                                LEFT JOIN Dim.DataStage DS ON DS.PK_DataStage = TR.FK_DataStage
                                LEFT JOIN Dim.DATE DT ON DT.PK_Date = TR.FK_DateDue
                                LEFT JOIN Dim.Entity DE ON DE.PK_Entity = TR.FK_Entity
                                LEFT JOIN Dim.PolicySection PS ON PS.PK_PolicySection = TR.FK_PolicySection
                                LEFT JOIN Dim.Location DL ON DL.PK_Location = TR.FK_Location
                                LEFT JOIN Dim.MovementType DM ON DM.PK_MovementType = TR.FK_MovementType
                                LEFT JOIN Dim.Process P ON P.PK_Process = TR.FK_Process
                                LEFT JOIN Dim.Product PR ON PR.PK_Product = TR.FK_Product
                                LEFT JOIN Dim.ProgrammeCode PC ON PC.PK_ProgrammeCode = TR.FK_ProgrammeCode
                                LEFT JOIN Dim.RIPolicyType RI ON RI.PK_RIPolicyType = TR.FK_RIPolicyType
                                LEFT JOIN Dim.Scenario S ON S.PK_Scenario = TR.FK_Scenario
                                LEFT JOIN Dim.TrackingStatus TS ON TS.PK_TrackingStatus = TR.FK_TrackingStatus
                                LEFT JOIN Dim.TriFocus T ON T.PK_TriFocus = TR.FK_Trifocus
                                LEFT JOIN Dim.YOA DY ON DY.PK_YOA = TR.FK_YOA
                                LEFT JOIN Dim.CCY DCY ON DCY.PK_CCY = TR.FK_CCYSettlement
                                LEFT JOIN Dim.CCY DCO ON DCO.PK_CCY = TR.FK_CCYOriginal
                                LEFT JOIN Dim.TriangleGroup DTG ON DTG.PK_TriangleGroup = TR.FK_TriangleGroup
                                LEFT JOIN Dim.ReservingDataset DRD ON DRD.PK_ReservingDataset = TR.FK_ReservingDataset
                                LEFT JOIN Dim.DATE inc_dt ON TR.FK_InceptionDate = inc_dt.PK_Date
                                LEFT JOIN Dim.DATE dof_dt ON TR.FK_DateOfFact = dof_dt.PK_Date
                                LEFT JOIN Dim.Entity DEY ON DEY.PK_Entity = TR.FK_SourceEntity
                                LEFT JOIN Dim.DeltaType DEL ON DEL.PK_DeltaType = TR.FK_DeltaType
                                LEFT JOIN (
                                                SELECT RIPolicyNumber
                                                                ,MAX(ClaimBasis) ClaimBasis
                                                FROM (
                                                                SELECT DISTINCT RIPolicyNumber
                                                                                ,RIBasis ClaimBasis
                                                                FROM [dbo].[fdm_DimRIPolicy]
                                                                -- WHERE RIType <>  'QS'
                                                                
                                                                UNION ALL
                                                                
                                                                SELECT RI_Section_Reference
                                                                                ,Claim_Basis
                                                                FROM [dbo].[ReInsuranceTreatyContractAttributes]
                                                                ) t
                                                GROUP BY RIPolicyNumber
                                                ) RCB ON (RCB.RIPolicyNumber = PS.PolicyReference)
                                LEFT JOIN (
                                                SELECT ps.PolicyReference
                                                                ,max(CASE 
                                                                                                WHEN (ps.PolicyClaimBasis = 'Unknown' OR ps.PolicyClaimBasis='NULL')
                                                                                                                THEN '-1'
                                                                                                ELSE PolicyClaimBasis
                                                                                                END) ClaimBasis
                                                FROM stg.dim_PolicySection ps
                                                GROUP BY ps.PolicyReference
                                                ) gcb ON (gcb.PolicyReference = ps.PolicyReference)
                                WHERE (
                                                                DE.BK_Entity <> '6107'
                                                                AND DA.BK_Account NOT IN (
                                                                                'P-RI-P'
                                                                                ,'P-RI-B'
                                                                                )
                                                                )
                                                AND D.BK_DataSet = 'AgressoARUS'
                                                AND DY.BK_YOA <= '2016'
                                                AND T.BK_TriFocus <> 'TRI00081'
                                --and floor(DP.BK_AccountingPeriod/100) - cast(DY.BK_YOA as int) > 2
                                
                                UNION ALL
                                
                                /* ==============================================================================================================================================================================
                                                                Adding AgressoARUS data(From Written Equivalent Datasets) prior to 2016 which is Reversed out(rom Agresso SOurce) on above Tactical Fix on Version C
                                                                Should be removed when implement Strategical Fix in Version D
                                                
=======================================================================================================================================================================================                */
                                SELECT TR.PK_FTH
                                                ,TR.FK_Batch
                                                ,TR.Value * ISNULL(TR.GroupShare, 1) AS [Value]
                                                ,TR.EarningPercentage
                                                ,TR.Fk_statscode
                                                ,TR.FK_Policy
                                                ,TR.ROWHASH
                                                ,CASE 
                                                                WHEN YEAR(inc_dt.DATE) = '1980'
                                                                                THEN CAST(DY.BK_YOA + CAST(RIGHT(LTRIM(RTRIM(DP.BK_AccountingPeriod)), 2) AS VARCHAR(2)) + '01' AS DATE)
                                                                ELSE inc_dt.DATE
                                                                END AS FK_InceptionDate
                                                ,CASE 
                                                                WHEN TR.FK_InceptionYear = '1980'
                                                                                THEN DY.BK_YOA
                                                                ELSE TR.FK_InceptionYear
                                                                END AS FK_InceptionYear
                                                ,CASE 
                                                                WHEN LEFT(TR.InceptionPeriod, 4) = '1980'
                                                                                THEN CAST(DY.BK_YOA + CAST(RIGHT(LTRIM(RTRIM(DP.BK_AccountingPeriod)), 2) AS VARCHAR(2)) AS INT)
                                                                ELSE TR.InceptionPeriod
                                                                END AS InceptionPeriod
                                                ,TR.BusinessKey
                                                ,TR.Att_Cat
                                                ,DTG.[BK_TriangleGroup] AS FK_TriangleGroup
                                                ,DRD.[BK_ReservingDataSet] AS FK_ReservingDataset
                                                ,TR.FK_Allocation
                                                ,CASE DA.BK_Account
                                                                WHEN 'P-GP-P'
                                                                                THEN 'PC-SD-OT'
                                                                WHEN 'P-AC-P'
                                                                                THEN 'BC-SD-OT'
                                                                ELSE DA.BK_Account
                                                                END AS FK_Account
                                                ,DP.BK_AccountingPeriod AS ReviewCycle
                                                ,DP.BK_AccountingPeriod AS FK_AccountingPeriod
                                                ,DB.BK_Basis AS FK_Basis
                                                ,DC.BK_CatCode AS FK_CatCode
                                                ,CE.BK_ClaimExposure AS FK_ClaimExposure
                                                ,'AgressoARUS' AS FK_DataSet
                                                ,DS.PK_DataStage AS FK_DataStage
                                                ,DT.BK_Date AS FK_DATE
                                                ,dof_dt.BK_Date AS FK_DateOfFact
                                                ,DE.BK_Entity AS FK_Entity
                                                ,PS.BK_PolicySection AS FK_PolicySection
                                                ,DL.BK_Location AS FK_Location
                                                ,DM.BK_MovementType AS FK_Movementype
                                                ,P.BK_Process AS FK_Process
                                                ,Pr.BK_Product AS FK_Product
                                                ,CASE 
                                                                WHEN DA.RIFlag = 'I'
                                                                                AND PC.BK_ProgrammeCode <> 'Consol Adj'
                                                                                THEN 'GROSS'
                                                                ELSE ISNULL(PC.BK_ProgrammeCode, 'Unknown')
                                                                END AS FK_ProgrammeCode
                                                ,RI.BK_RIPolicyType AS FK_RIPolicyType
                                                ,S.BK_Scenario AS FK_Scenario
                                                ,TS.BK_TrackingStatus AS FK_TrackingStatus
                                                ,T.BK_TriFocus AS FK_Trifocus
                                                ,DY.BK_YOA AS FK_YOA
                                                ,DCO.BK_CCY AS FK_CCYOriginal
                                                ,DCY.BK_CCY AS FK_CCYSettlement
                                                ,CASE 
                                                                WHEN YEAR(PS.ExpiryDate) = '1980'
                                                                                THEN EOMONTH(DATEADD(YEAR, 1, DATEADD(MONTH, - 1, CAST(DY.BK_YOA + CAST(RIGHT(LTRIM(RTRIM(BK_AccountingPeriod)), 2) AS VARCHAR(2)) + '01' AS DATETIME))))
                                                                ELSE PS.ExpiryDate
                                                                END AS ExpiryDate
                                                ,
                                                --PS.ExpiryDate,
                                                DEY.BK_Entity AS FK_SourceEntity
                                                ,DEL.BK_DeltaType
                                                ,TR.GroupShare
                                                ,TR.Intercompany_PrioritySeq
                                                ,ClaimBasis = COALESCE(NULLIF(gcb.ClaimBasis, '-1'), CASE 
                                                                                WHEN RI.BK_RIPolicyType = 'FAC'
                                                                                                AND ps.PolicyReference <> 'NOPOLICY'
                                                                                                AND RCB.ClaimBasis = 'Unknown'
                                                                                                THEN 'RAD'
                                                                                ELSE RCB.ClaimBasis
                                                                                END, 'Unknown')
                                                ,MOPCode = COALESCE(PS.PolicyMOPCode, 'Unknown')
												,TR.[Value] as Value100Prcnt --I1B-5913
												
                                FROM fct.TechnicalResult TR
                                LEFT JOIN Dim.Account DA ON DA.PK_Account = TR.FK_Account
                                LEFT JOIN Dim.AccountingPeriod DP ON DP.PK_AccountingPeriod = TR.FK_AccountingPeriod
                                LEFT JOIN Dim.Basis DB ON DB.PK_Basis = TR.FK_Basis
                                LEFT JOIN Dim.CatCode DC ON DC.PK_CatCode = TR.FK_CatCode
                                LEFT JOIN Dim.ClaimExposure CE ON CE.PK_ClaimExposure = TR.FK_ClaimExposure
                                LEFT JOIN Dim.DataSet D ON D.PK_DataSet = TR.FK_DataSet
                                LEFT JOIN Dim.DataStage DS ON DS.PK_DataStage = TR.FK_DataStage
                                LEFT JOIN Dim.DATE DT ON DT.PK_Date = TR.FK_DateDue
                                LEFT JOIN Dim.Entity DE ON DE.PK_Entity = TR.FK_Entity
                                LEFT JOIN Dim.PolicySection PS ON PS.PK_PolicySection = TR.FK_PolicySection
                                LEFT JOIN Dim.Location DL ON DL.PK_Location = TR.FK_Location
                                LEFT JOIN Dim.MovementType DM ON DM.PK_MovementType = TR.FK_MovementType
                                LEFT JOIN Dim.Process P ON P.PK_Process = TR.FK_Process
                                LEFT JOIN Dim.Product PR ON PR.PK_Product = TR.FK_Product
                                LEFT JOIN Dim.ProgrammeCode PC ON PC.PK_ProgrammeCode = TR.FK_ProgrammeCode
                                LEFT JOIN Dim.RIPolicyType RI ON RI.PK_RIPolicyType = TR.FK_RIPolicyType
                                LEFT JOIN Dim.Scenario S ON S.PK_Scenario = TR.FK_Scenario
                                LEFT JOIN Dim.TrackingStatus TS ON TS.PK_TrackingStatus = TR.FK_TrackingStatus
                                LEFT JOIN Dim.TriFocus T ON T.PK_TriFocus = TR.FK_Trifocus
                                LEFT JOIN Dim.YOA DY ON DY.PK_YOA = TR.FK_YOA
                                LEFT JOIN Dim.CCY DCY ON DCY.PK_CCY = TR.FK_CCYSettlement
                                LEFT JOIN Dim.CCY DCO ON DCO.PK_CCY = TR.FK_CCYOriginal
                                LEFT JOIN Dim.TriangleGroup DTG ON DTG.PK_TriangleGroup = TR.FK_TriangleGroup
                                LEFT JOIN Dim.ReservingDataset DRD ON DRD.PK_ReservingDataset = TR.FK_ReservingDataset
                                LEFT JOIN Dim.DATE inc_dt ON TR.FK_InceptionDate = inc_dt.PK_Date
                                LEFT JOIN Dim.DATE dof_dt ON TR.FK_DateOfFact = dof_dt.PK_Date
                                LEFT JOIN Dim.Entity DEY ON DEY.PK_Entity = TR.FK_SourceEntity
                                LEFT JOIN Dim.DeltaType DEL ON DEL.PK_DeltaType = TR.FK_DeltaType
                                LEFT JOIN (
                                                SELECT RIPolicyNumber
                                                                ,MAX(ClaimBasis) ClaimBasis
                                                FROM (
                                                                SELECT DISTINCT RIPolicyNumber
                                                                                ,RIBasis ClaimBasis
                                                                FROM [dbo].[fdm_DimRIPolicy]
                                                                -- WHERE RIType <>  'QS'
                                                                
                                                                UNION ALL
                                                                
                                                                SELECT RI_Section_Reference
                                                                                ,Claim_Basis
                                                                FROM [dbo].[ReInsuranceTreatyContractAttributes]
                                                                ) t
                                                GROUP BY RIPolicyNumber
                                                ) RCB ON (RCB.RIPolicyNumber = PS.PolicyReference)
                                LEFT JOIN (
                                                SELECT ps.PolicyReference
                                                                ,max(CASE 
                                                                                                WHEN (ps.PolicyClaimBasis = 'Unknown' OR ps.PolicyClaimBasis='NULL')
                                                                                                                THEN '-1'
                                                                                                ELSE PolicyClaimBasis
                                                                                                END) ClaimBasis
                                                FROM stg.dim_PolicySection ps
                                                GROUP BY ps.PolicyReference
                                                ) gcb ON (gcb.PolicyReference = ps.PolicyReference)
                                WHERE (
                                                                DE.BK_Entity <> '6107'
                                                                AND DA.BK_Account NOT IN (
                                                                                'P-RI-P'
                                                                                ,'P-RI-B'
                                                                                )
                                                                )
                                                AND D.BK_DataSet IN (
                                                                'USPremium'
                                                                ,'BICI'
                                                                ,'USBAIC'
                                                                )
                                                AND DY.BK_YOA <= '2016'
                                                AND T.BK_TriFocus <> 'TRI00081'
                                                --and floor(DP.BK_AccountingPeriod/100) - cast(DY.BK_YOA as int) > 2
                                )
GO
