﻿CREATE VIEW IFRS17.AccountingPeriod AS 
SELECT [BK_AccountingPeriod] As PK_Accountingperiod
      ,[AccountingPeriodName]
      ,[AccountingYear]
      ,[AccountingYearName]
      ,[AccountingMonth]
      ,[AccountingMonthName]
      ,[AuditSourceBatchID]
      ,[AuditCreateDateTime]
      ,[AuditUserCreate]
      ,[AuditHost]
      ,[ValidFrom]
      ,[ValidTo]
FROM [dim].[AccountingPeriod]


