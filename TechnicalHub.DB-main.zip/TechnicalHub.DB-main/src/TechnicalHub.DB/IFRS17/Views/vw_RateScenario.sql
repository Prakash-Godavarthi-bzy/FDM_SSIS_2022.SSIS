﻿CREATE VIEW IFRS17.RateScenario AS
SELECT [PK_RateCode]
      ,[RateName]
      ,[RateGroup]
      ,[Locked]
      ,[SortOrder]
      ,[ValidFrom]
      ,[ValidTo]
  FROM [dim].[RateScenario]