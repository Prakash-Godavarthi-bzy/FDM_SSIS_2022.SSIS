﻿CREATE VIEW IFRS17.Basis AS 
SELECT [BK_Basis] AS PK_Basis
      ,[BasisName]
      ,[AuditSourceBatchID]
      ,[AuditCreateDateTime]
      ,[AuditUserCreate]
      ,[AuditHost]
      ,[ValidFrom]
      ,[ValidTo]
  FROM [dim].[Basis]
