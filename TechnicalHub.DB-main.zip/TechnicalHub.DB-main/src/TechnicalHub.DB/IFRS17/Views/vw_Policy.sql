﻿CREATE VIEW IFRS17.Policy AS 
SELECT  PK_Policy,
        BK_PolicyNumber AS PolicyReference
      ,[SectionReference]
      ,[InceptionDate]
      ,[ExpiryDate]
      ,[PolicyYOA]
      ,[PolicyType]
      ,[PolicyPattern]
      ,[BindDate]
      ,[TypeOfBusiness]
      ,[MaxEarningDate]
      ,[ValidFrom]
      ,[ValidTo]
      ,[IsUSPolicy]
  FROM [dim].[Policy]
