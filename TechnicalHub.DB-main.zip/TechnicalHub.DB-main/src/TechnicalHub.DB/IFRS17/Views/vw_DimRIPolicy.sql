﻿CREATE VIEW [IFRS17].[DimRIPolicy] AS
SELECT [RIPolicyNumber]
,[InceptionDate]
,[ExpiryDate]
,[RIProgramme]
,[RIType]
,'RAD' AS ClaimsBasis
  FROM [dbo].[DimRIPolicy]
  where RIType = 'FAC'
and RIAdjustment = 'RISPD'

