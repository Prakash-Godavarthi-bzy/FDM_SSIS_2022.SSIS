﻿CREATE VIEW IFRS17.AssumptionPercentageSubType AS 
SELECT [Pk_AssumptionPercentageSubTypeId]
      ,[LossType]
      ,[LossTypeDescription]
      ,[ValidFrom]
      ,[ValidTo]
  FROM [dim].[AssumptionPercentageSubType]
