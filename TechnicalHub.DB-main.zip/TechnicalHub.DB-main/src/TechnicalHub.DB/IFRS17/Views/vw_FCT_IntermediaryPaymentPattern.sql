﻿CREATE VIEW IFRS17.FCT_IntermediaryPaymentPattern AS
SELECT [Pk_RequestId]
      ,[DatasetNameId]
      ,[PercentageTypeId]
      ,[LossType]
      ,[Trifocus]
      ,[DevelopmentQuarter]
      ,[PaymentPerc]
  FROM [fct].[IntermediaryPaymentPattern]

