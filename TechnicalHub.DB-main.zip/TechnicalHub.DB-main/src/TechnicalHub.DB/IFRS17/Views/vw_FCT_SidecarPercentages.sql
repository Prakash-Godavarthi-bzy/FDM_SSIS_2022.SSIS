﻿CREATE VIEW IFRS17.FCT_SidecarPercentages AS 
SELECT [pk_SideCar]
      ,[TriFocus]
      ,[YOA]
      ,[STATSCODE]
      ,[PERCENT]
      ,[ValidFrom]
      ,[ValidTo]
  FROM [fct].[SideCarPercentages]



