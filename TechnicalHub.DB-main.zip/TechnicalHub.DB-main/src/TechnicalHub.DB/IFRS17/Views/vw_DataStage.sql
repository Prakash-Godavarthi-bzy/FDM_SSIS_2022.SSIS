﻿CREATE VIEW IFRS17.DataStage AS 
SELECT [PK_DataStage]
      ,[DataStageName]
      ,[ValidFrom]
      ,[ValidTo]
  FROM [dim].[DataStage]



