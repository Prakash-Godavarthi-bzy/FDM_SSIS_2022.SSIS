﻿CREATE VIEW IFRS17.OBCalTreeNode AS
SELECT [PK_CalcTree]
      ,[ValidFrom]
      ,[ValidTo]
  FROM [dim].[OBCalTreeNode]

