﻿CREATE VIEW IFRS17.FCT_DiscountRate AS 
SELECT [PK_DiscountRates],
       [FK_Batch],
       [AsAtDate],
       [DiscountRateName],
       [DiscountRateKey],
       [DataSet],
       [SettlementCCY],
       [CumulativeDevelopmentPercentage],
       [DevelopmentYear],
       [AssumptionDatasetName]
FROM   [fct].[DiscountRate]




