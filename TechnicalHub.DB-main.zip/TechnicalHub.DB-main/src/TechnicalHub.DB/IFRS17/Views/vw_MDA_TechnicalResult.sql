CREATE VIEW [IFRS17].[vw_MDA_TechnicalResult]
AS

/*================================================================================================================
Created by  : Nikil chowdary
JIRA		: 
		
-----------------------------------------------------------------------------------------------------------------		
Modify By: Entha Bhargav <entha.bhargav@beazley.com>
Created Date: 30/07/2024
Version:
Description: This view extracts IFRS17 BR1 end results with restriction YOA of 2018,2019 
				as requested on JIRA https://beazley.atlassian.net/browse/I1B-5693.
			
			 This will be using by Modern Data Archietect (MDA) team to submit 
			 Remove and re-add as a PR. Two versions


===================================================================================================================*/
(
          SELECT
				 [Pk_RowID]					,
				 [PK_FTH]                   ,
                 [FK_Batch]                 ,
                 [Value]                    ,
                 [EarningPercentage]        ,
                 [Fk_statscode]             ,
                 [FK_Policy]                ,
                 [ROWHASH]                  ,
                 [FK_InceptionDate]         ,
                 [FK_InceptionYear]         ,
                 [InceptionPeriod]          ,
                 [BusinessKey]              ,
                 [Att_Cat]                  ,
                 [FK_TriangleGroup]         ,
                 [FK_ReservingDataset]      ,
                 [FK_Allocation]            ,
                 [FK_Account]               ,
                 [ReviewCycle]              ,
                 [FK_AccountingPeriod]      ,
                 [FK_Basis]                 ,
                 [FK_CatCode]               ,
                 [FK_ClaimExposure]         ,
                 [FK_DataSet]               ,
                 [FK_DataStage]             ,
                 [FK_DATE]                  ,
                 [FK_DateOfFact]            ,
                 [FK_Entity]                ,
                 [FK_PolicySection]         ,
                 [FK_Location]              ,
                 [FK_Movementype]           ,
                 [FK_Process]               ,
                 [FK_Product]               ,
                 [FK_ProgrammeCode]         ,
                 [FK_RIPolicyType]          ,
                 [FK_Scenario]              ,
                 [FK_TrackingStatus]        ,
                 [FK_Trifocus]              ,
                 [FK_YOA]                   ,
                 [FK_CCYOriginal]           ,
                 [FK_CCYSettlement]         ,
                 [ExpiryDate]               ,
                 [FK_SourceEntity]          ,
                 [BK_DeltaType]             ,
                 [GroupShare]               ,
                 [Intercompany_PrioritySeq] ,
                 [ClaimBasis]               ,
                 [MOPCode]                  ,
                 MDA.[BatchID]              ,
                 MDA.[DeltaTypeFlag]        ,
                 MDA.[LoadType]             ,
                 MDA.[Extract]              ,
                 MDA.[AuditCreateDateTime]
          FROM
                 [IFRS17].[FCT_TechnicalResult] tr
          JOIN
                 [IFRS17].[CurrentQuarterDelta] MDA
          ON
                 tr.FK_Batch = MDA.BatchID
          AND    tr.AuditCreateDateTime = MDA.AuditCreateDateTime
          WHERE
                 [Extract]='N'
				 and [FK_YOA] in ('2018','2019')
)
GO
