﻿CREATE VIEW IFRS17.FCT_LossRatioImport AS
SELECT [LossRatioType]
      ,[AccountingYearQuater]
      ,[Trifocus]
      ,[YOA]
      ,[LossRatio]
  FROM [fct].[LossRatioImport]