﻿CREATE VIEW IFRS17.fct_FXRate AS 
SELECT [fk_Batch]
      ,[fk_AccountingPeriod]
      ,[FXRateName]
      ,[fk_TransactionCurrency]
      ,[fK_ReportingCurrencyCode]
      ,[FXRate]
      ,[fK_RateCode]
  FROM [fct].[FXRate]




