﻿CREATE  VIEW [IFRS17].[FCT_TechnicalResult] AS
SELECT  TR.PK_FTH,
        TR.FK_Batch,
		TR.Value * ISNULL(TR.GroupShare,1) AS [Value],
		TR.EarningPercentage,
		TR.Fk_statscode,
		TR.FK_Policy,
		TR.ROWHASH,
		inc_dt.Date AS FK_InceptionDate,
		 TR.FK_InceptionYear AS FK_InceptionYear,
		TR.InceptionPeriod AS InceptionPeriod,
		TR.BusinessKey,
		TR.Att_Cat,
	    DTG. [BK_TriangleGroup] AS FK_TriangleGroup,
	    DRD. [BK_ReservingDataSet] AS FK_ReservingDataset,
		TR.FK_Allocation,
		DA.BK_Account As FK_Account,
		DP.BK_AccountingPeriod as ReviewCycle,
		CASE  WHEN D.BK_DataSet = 'PFT'
					THEN YEAR(DATEADD(QQ,1,cast(cast(DP.BK_AccountingPeriod as varchar(6))+'01'  as date))) *100+MONTH (DATEADD(QQ,1,cast(cast(DP.BK_AccountingPeriod as varchar(6))+'01'  as date)))
			WHEN (	n.PolicyNumber=PS.SectionReference
			and n.Account=DA.BK_Account
			and n.Entity=DE.BK_Entity
			and n.YOA= DY.BK_YOA
			and n.TrifocusCode=T.BK_TriFocus
			and n.SettlementCCY=DCY.BK_CCY
			and n.InceptionDate=inc_dt.[Date]
			and n.ExpiryDate> ps.ExpiryDate
			and D.BK_DataSet='UsPremium'
			and DEL.BK_DeltaType='Reversal'
			) THEN  LEFT(CAST(CONVERT(CHAR(10),n.DateOfFact,112) AS INT),6)
			ELSE DP.BK_AccountingPeriod 
			END AS FK_AccountingPeriod,
		DB.BK_Basis  AS FK_Basis,
		DC.BK_CatCode AS FK_CatCode,
		CE.BK_ClaimExposure AS FK_ClaimExposure,
		D.BK_DataSet AS FK_DataSet,
		DS.PK_DataStage AS FK_DataStage,
		DT.BK_Date AS FK_DATE,
		--dof_dt.BK_Date AS FK_DateOfFact,
		CASE WHEN (n.PolicyNumber=PS.SectionReference
			and n.Account=DA.BK_Account
			and n.Entity=DE.BK_Entity
			and n.YOA= DY.BK_YOA
			and n.TrifocusCode=T.BK_TriFocus
			and n.SettlementCCY=DCY.BK_CCY
			and n.InceptionDate=inc_dt.[Date]
			and n.ExpiryDate> ps.ExpiryDate
			and D.BK_DataSet='UsPremium'
			and DEL.BK_DeltaType='Reversal') 
			THEN  CAST(CONVERT(CHAR(10),n.DateOfFact,112) AS INT)
			ELSE dof_dt.BK_Date 
			END AS FK_DateOfFact,
		DE.BK_Entity AS FK_Entity,
		PS.BK_PolicySection AS FK_PolicySection,
		DL.BK_Location AS FK_Location,
		DM.BK_MovementType AS FK_Movementype,
		P.BK_Process AS FK_Process,
		Pr.BK_Product AS FK_Product,
		ISNULL(PC.BK_ProgrammeCode,'Unknown') AS FK_ProgrammeCode,
		RI.BK_RIPolicyType AS FK_RIPolicyType,
		S.BK_Scenario AS FK_Scenario,
		TS.BK_TrackingStatus AS FK_TrackingStatus,
		T.BK_TriFocus AS FK_Trifocus,
		DY.BK_YOA AS FK_YOA,
		DCO.BK_CCY AS FK_CCYOriginal,
		DCY.BK_CCY AS FK_CCYSettlement,
		ps.ExpiryDate AS ExpiryDate,
		DEY.BK_Entity AS FK_SourceEntity,
		DEL.BK_DeltaType,
		TR.GroupShare,
		TR. Intercompany_PrioritySeq
FROM   fct.TechnicalResult TR
       LEFT JOIN  Dim.Account          DA ON DA.PK_Account=TR.FK_Account
	   LEFT JOIN  Dim.AccountingPeriod DP ON DP.PK_AccountingPeriod= TR.FK_AccountingPeriod
	   LEFT JOIN  Dim.Basis            DB ON DB.PK_Basis = TR.FK_Basis
	   LEFT JOIN  Dim.CatCode          DC ON DC.PK_CatCode=TR.FK_CatCode
	   LEFT JOIN  Dim.ClaimExposure    CE ON CE.PK_ClaimExposure=TR.FK_ClaimExposure
	   LEFT JOIN  Dim.DataSet          D  ON D.PK_DataSet   = TR.FK_DataSet
	   LEFT JOIN  Dim.DataStage        DS ON DS.PK_DataStage=TR.FK_DataStage
	   LEFT JOIN  Dim.Date             DT ON DT.PK_Date = TR.FK_DateDue
	   LEFT JOIN  Dim.Entity           DE ON DE.PK_Entity= TR.FK_Entity
	   LEFT JOIN  Dim.PolicySection    PS ON PS.PK_PolicySection = TR.FK_PolicySection
	   LEFT JOIN  Dim.Location         DL ON DL.PK_Location = TR.FK_Location
	   LEFT JOIN  Dim.MovementType     DM  ON DM.PK_MovementType =TR.FK_MovementType
	   LEFT JOIN  Dim.Process          P   ON  P.PK_Process = TR.FK_Process 
	   LEFT JOIN  Dim.Product          PR  ON PR.PK_Product=TR.FK_Product
	   LEFT JOIN  Dim.ProgrammeCode    PC  ON  PC.PK_ProgrammeCode= TR.FK_ProgrammeCode  
	   LEFT JOIN  Dim.RIPolicyType     RI  ON RI.PK_RIPolicyType =TR.FK_RIPolicyType
	   LEFT JOIN  Dim.Scenario         S   ON S.PK_Scenario =TR.FK_Scenario
	   LEFT JOIN  Dim.TrackingStatus   TS  ON TS.PK_TrackingStatus = TR.FK_TrackingStatus
	   LEFT JOIN  Dim.TriFocus         T  ON T.PK_TriFocus =TR.FK_Trifocus
	   LEFT JOIN  Dim.YOA              DY ON DY.PK_YOA=TR.FK_YOA
	   LEFT JOIN  Dim.CCY              DCY ON  DCY.PK_CCY= TR.FK_CCYSettlement 
	   LEFT join  Dim.CCY              DCO ON DCO.PK_CCY=TR.FK_CCYOriginal
	   LEFT JOIN  Dim.TriangleGroup    DTG  ON DTG.PK_TriangleGroup= TR.FK_TriangleGroup
	   LEFT JOIN  Dim.ReservingDataset DRD  ON DRD.PK_ReservingDataset=TR.FK_ReservingDataset
       LEFT JOIN  Dim.Date			  inc_dt ON  TR.FK_InceptionDate = inc_dt.PK_Date
	   LEFT JOIN  Dim.Date            dof_dt ON  TR.FK_DateOfFact = dof_dt.PK_Date
	   LEFT JOIN  Dim.Entity          DEY ON DEY.PK_Entity=TR.FK_SourceEntity
	   LEFT JOIN  Dim.DeltaType       DEL ON DEL.PK_DeltaType = TR.FK_DeltaType
	    LEFT JOIN	(SELECT DISTINCT DPS.SectionReference as PolicyNumber,
									DA.BK_Account as Account,
									dofdt.BK_Date AS DateOfFact,
									dee.BK_Entity as Entity,
									DYY.BK_YOA AS YOA,
									dtf.BK_TriFocus AS TriFocusCode,
									dcc.BK_CCY as SettlementCCY,
									incdt.[Date] AS InceptionDate,
									dps.ExpiryDate as ExpiryDate,
									T.RowHash AS ROWhASH
					FROM fct.TechnicalResult t
					LEFT JOIN dim.PolicySection DPS ON DPS.PK_PolicySection=t.FK_PolicySection
					LEFT JOIN dim.Account DA ON DA.PK_Account=t.FK_Account
					LEFT JOIN  Dim.[Date]		incdt ON  T.FK_InceptionDate = incdt.PK_Date
					LEFT JOIN Dim.[Date]         dofdt ON  T.FK_DateOfFact = dofdt.PK_Date
					LEFT JOIN	Dim.Entity dee on dee.PK_Entity=t.FK_Entity
					LEFT JOIN dim.yoa  DYY ON DYY.PK_YOA=t.FK_YOA
					LEFT join	dim.TriFocus dtf on dtf.PK_TriFocus=t.FK_Trifocus
					LEFT join dim.CCY dcc on dcc.PK_CCY=t.FK_CCYSettlement
					LEFT join dim.DataSet ds on ds.PK_DataSet=t.FK_DataSet
					LEFT Join dim.DeltaType dt on dt.PK_DeltaType=t.FK_DeltaType
					WHERE ds.BK_DataSet='USPremium'
					AND dt.BK_DeltaType in ('New', 'Adjustment')
					) n on  (1=1 
  								and n.PolicyNumber=PS.SectionReference
								and n.Account=DA.BK_Account
								and n.Entity=DE.BK_Entity
								and n.YOA= DY.BK_YOA
								and n.TrifocusCode=T.BK_TriFocus
								and n.SettlementCCY=DCY.BK_CCY
								and n.InceptionDate=inc_dt.[Date]
								and n.ExpiryDate>ps.ExpiryDate
								and D.BK_DataSet='UsPremium'
								and DEL.BK_DeltaType='Reversal'
							)
GO
