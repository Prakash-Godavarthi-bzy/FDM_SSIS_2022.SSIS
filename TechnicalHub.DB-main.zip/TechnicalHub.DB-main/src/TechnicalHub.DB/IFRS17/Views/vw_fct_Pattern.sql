﻿CREATE VIEW IFRS17.fct_Pattern AS
SELECT    p.PK_Pattern,
          p.FK_Batch,
		  p.FK_InceptionYear,
		  P.DevelopmentQuarter,
		  P.PatternScenario,
		  P.PatternScenarioVersion,
		  p.DevelopmentPercentageIncrement,
     	  ds.BK_DataSet AS FK_Dataset,
		  da.BK_AccountingPeriod as FK_Accountingperiod,
		  dt.BK_Trifocus as FK_Trifocus,
          dy.BK_YOA as FK_YOA,
		  dp.BK_PatternName AS fK_PatternName,
		  dc.BK_CCY AS FK_CCYSettlement,
		  p.[TDH_DatasetName],
		  p.[DevelopmentPercentageCumulative]
FROM     [fct].[Pattern] as p
         LEFT JOIN dim.PatternName      as  dp ON  p.FK_PatternName = dp.PK_PatternName
         LEFT JOIN dim.DataSet          as ds  ON  p.FK_DataSet = ds.PK_DataSet
         LEFT JOIN dim.AccountingPeriod as dA  ON  p.FK_AccountingPeriod= DA.pk_AccountingPeriod
         LEFT JOIN dim.trifocus         as dt  ON  p.fk_trifocus=dt.pk_trifocus
         LEFT JOIN dim.YOA              as dy  ON  p.FK_YOA= dy.pk_YOA
		 LEFT JOIN dim.ccy              as dc  ON p.FK_CCYSettlement=dc.PK_CCY


		 
   