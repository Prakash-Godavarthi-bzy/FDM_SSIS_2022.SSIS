﻿CREATE VIEW IFRS17.AssumptionDatasets AS 
SELECT [Pk_AssumptionDatasetNameId]
      ,[AssumptionDatasetName]
      ,[AssumptionDatasetDescription]
      ,[AssumptionPercentageTypeId]
      ,[IsDatasetAlreadyUsed]
      ,[CreatedDt]
      ,[CreatedBy]
      ,[UpdatedDt]
      ,[UpdatedBy]
      ,[ValidFrom]
      ,[ValidTo]
  FROM [dim].[AssumptionDatasets]



