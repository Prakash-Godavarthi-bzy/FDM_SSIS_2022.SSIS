﻿CREATE VIEW IFRS17.FCT_ADMULRPercentages AS
SELECT [PK_ID]
      ,[YOA]
      ,[Entity]
      ,[Trifocus]
      ,[LossType]
      ,[Gross/RI Flag]
      ,[ULR  Percentage]
      ,[AssumptionDatasetID]
      ,[AssumptionPercentTypeID]
  FROM [fct].[ADMULRPercentages]


