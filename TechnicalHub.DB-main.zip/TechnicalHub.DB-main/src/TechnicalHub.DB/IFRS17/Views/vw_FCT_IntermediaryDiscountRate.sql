﻿CREATE VIEW IFRS17.FCT_IntermediaryDiscountRate AS 
SELECT [Pk_RequestId]
      ,[DatasetNameId]
      ,[PercentageTypeId]
      ,[LossType]
      ,[Currency]
      ,[DevelopmentYear]
      ,[Quarters]
      ,[DiscountRt]
  FROM [fct].[IntermediaryDiscountRate]

