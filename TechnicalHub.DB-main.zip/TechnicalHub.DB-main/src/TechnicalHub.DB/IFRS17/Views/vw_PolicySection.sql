﻿CREATE VIEW [IFRS17].[PolicySection] AS
SELECT 
 [BK_PolicySection] AS PK_PolicySection
, MAX([PK_PolicySection]) SK_PolicySection
, MAX([PolicyReference]) [PolicyReference]
, MAX([SectionReference]) [SectionReference]
, MAX([InceptionDate]) InceptionDate
, MAX([ExpiryDate]) ExpiryDate
, MAX([PolicyYOA]) PolicyYOA
, MAX([PolicyType]) PolicyType
, MAX([BindDate]) BindDate
, MAX([TypeOfBusiness]) TypeOfBusiness
, MAX([MAXEarningDate]) MAXEarningDate
, MAX(CAST([IsUSPolicy] AS INT)) IsUSPolicy
, MAX(PolicyClaimBasis) PolicyClaimBasis
, MAX(PolicyMOPCode) PolicyMOPCode
, MAX([PolicyCobCode]) PolicyCobCode
, MAX([AuditSourceBatchID]) AuditSourceBatchID
, MAX([AuditCreateDateTime]) AuditCreateDateTime
, MAX([AuditUserCreate]) AuditUserCreate
, MAX([AuditHost]) AuditHost
, MAX([ValidFrom]) ValidFrom
, MAX([ValidTo]) ValidTo
FROM [dim].[PolicySection]
group by [BK_PolicySection]
GO


