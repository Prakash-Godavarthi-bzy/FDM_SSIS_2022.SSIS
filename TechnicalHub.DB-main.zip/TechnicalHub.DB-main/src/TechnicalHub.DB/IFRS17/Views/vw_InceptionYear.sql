﻿CREATE VIEW IFRS17.InceptionYear AS 
SELECT [PK_InceptionYear]
      ,[InceptionYear]
  FROM [dim].[InceptionYear]
