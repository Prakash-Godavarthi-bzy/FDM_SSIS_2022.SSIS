﻿CREATE VIEW IFRS17.YOA AS 
SELECT [BK_YOA] AS PK_YOA
      ,[AuditSourceBatchID]
      ,[AuditCreateDateTime]
      ,[AuditUserCreate]
      ,[AuditHost]
      ,[ValidFrom]
      ,[ValidTo]
  FROM [dim].[YOA]
