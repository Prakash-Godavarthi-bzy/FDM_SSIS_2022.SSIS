﻿CREATE VIEW IFRS17.ProgrammeCode AS 
SELECT [BK_ProgrammeCode] AS [PK_ProgrammeCode]
      ,[ProgrammeCode]
      ,[AuditSourceBatchID]
      ,[AuditCreateDateTime]
      ,[AuditUserCreate]
      ,[AuditHost]
      ,[ValidFrom]
      ,[ValidTo]
  FROM [dim].[ProgrammeCode]

