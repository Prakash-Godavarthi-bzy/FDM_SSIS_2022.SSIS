﻿CREATE USER [BFL\Beazley_Reader] FOR LOGIN [BFL\Beazley_Reader];

