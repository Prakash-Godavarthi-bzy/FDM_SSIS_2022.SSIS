﻿CREATE TABLE [stg].[dim_DataStage] (
    [PK_DataStage]  INT          NOT NULL,
    [DataStageName] VARCHAR (50) NULL,
    CONSTRAINT [PK_DataStage] PRIMARY KEY CLUSTERED ([PK_DataStage] ASC) WITH (FILLFACTOR = 90)
);

