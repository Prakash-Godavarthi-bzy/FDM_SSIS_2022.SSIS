﻿CREATE TABLE stg.dim_RateScenario
(
	PK_RateCode			NVARCHAR(255)	NOT NULL ,
	RateName			NVARCHAR(255)	NULL ,
	RateGroup			NVARCHAR(255)	NULL ,
	Locked				NCHAR(1)		NULL ,
	SortOrder			INT				NULL ,
	CONSTRAINT PK_RateScenario PRIMARY KEY CLUSTERED (PK_RateCode ASC)
);
