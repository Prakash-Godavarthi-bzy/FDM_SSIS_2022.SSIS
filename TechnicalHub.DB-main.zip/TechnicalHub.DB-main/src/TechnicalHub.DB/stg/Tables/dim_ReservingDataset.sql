﻿CREATE TABLE [stg].[dim_ReservingDataset](
	[PK_ReservingDataset] [bigint] IDENTITY(1,1) NOT NULL,
	[BK_ReservingDataSet] [varchar](100) NOT NULL,
	[ReservingDataSetName] [varchar](100) NULL,
	[ReservingDataSetGroup] [varchar](100) NULL,
	[AuditSourceBatchID] [varchar](255) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName')))
 CONSTRAINT [PK_ReservingDataset] PRIMARY KEY CLUSTERED ([PK_ReservingDataset] ASC)WITH (FILLFACTOR = 90) ON [PRIMARY]
);
	
