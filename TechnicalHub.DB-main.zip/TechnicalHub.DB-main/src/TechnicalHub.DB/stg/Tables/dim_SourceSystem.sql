﻿CREATE TABLE [stg].[dim_DataSet] (
	[PK_DataSet]	BIGINT			NOT NULL IDENTITY(1,1),
    [BK_Dataset]   VARCHAR (50) NOT NULL,
    [SourceSystem] VARCHAR (50) NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    CONSTRAINT [PK_Dataset] PRIMARY KEY CLUSTERED ([PK_Dataset] ASC) WITH (FILLFACTOR = 90)
);





