﻿CREATE TABLE [stg].[dim_ProgrammeCode] (
       [PK_ProgrammeCode]   BIGINT NOT NULL IDENTITY(1,1),
		[BK_ProgrammeCode]  VARCHAR (100)  NOT NULL,
    [ProgrammeCode]      VARCHAR (100) NULL,
	[Retro_Reinsurance_Ind] [char](2) NULL,
       [AuditSourceBatchID] [varchar](255)  NULL,
       [AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    CONSTRAINT [PK_ProgrammeCode] PRIMARY KEY CLUSTERED ([PK_ProgrammeCode] ASC) WITH (FILLFACTOR = 90)
);


