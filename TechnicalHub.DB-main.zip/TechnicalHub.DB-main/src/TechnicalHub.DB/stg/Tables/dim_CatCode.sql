﻿CREATE TABLE [stg].[dim_CatCode](
		[PK_CatCode] BIGINT  IDENTITY(1,1) NOT NULL,
	   [BK_CatCode] [Varchar] (90) NOT NULL,
       [BeazleyCatCode] [char](50) NOT NULL,
       [MarketCatCode] [varchar](50) NULL,
       [BeazleyCatDesription] [varchar](100) NULL,
       [BeazleySpecial] [char](50) NULL,
       [EventYear] [int] NULL,
       [BeazleyEventName] [varchar](100) NULL,
       [LargeLossIndicator] [tinyint] NULL,
	   [EventDate] [datetime] NULL,
       [AuditSourceBatchID] [varchar](255) NOT NULL,
       [AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
       [AuditGenerateDateTime] [datetime] NOT NULL,
       [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
       [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))), 
    CONSTRAINT [PK_stg_CatCodeID] PRIMARY KEY ([PK_CatCode]),
	
) ON [PRIMARY]
GO