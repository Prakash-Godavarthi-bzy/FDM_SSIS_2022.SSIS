﻿CREATE TABLE [stg].[SideCarPercentages] (
    [pk_SideCar] INT              IDENTITY (1, 1) NOT NULL,
    [TriFocus]	 varchar(255) NOT NULL,
	[YOA]		 INT		  NOT NULL,
	[STATSCODE]	 VARCHAR(25)	NOT NULL,
	[PERCENT]	 NUMERIC(17,4)	NOT NULL
    PRIMARY KEY NONCLUSTERED ([pk_SideCar] ASC)
);





