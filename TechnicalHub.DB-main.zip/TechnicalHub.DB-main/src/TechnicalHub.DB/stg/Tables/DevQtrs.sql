﻿CREATE TABLE [stg].[DevQtrs](
[Id] [int] IDENTITY(1,1) NOT NULL,
[DevQtr] [int] NULL,
[Defaultvalue] [int] NULL
) ON [PRIMARY]
GO