﻿CREATE TABLE [stg].[dim_YOA] (
	[PK_YOA]	BIGINT NOT NULL IDENTITY(1,1),
    [BK_YOA] VARCHAR(10) NOT NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    CONSTRAINT [PK_YOA] PRIMARY KEY CLUSTERED ([PK_YOA] ASC) WITH (FILLFACTOR = 90)
);

