﻿CREATE TABLE [stg].[InterimUSPremium](
	[Scenario] [varchar](1) NULL,
	[Account] [varchar](50) NULL,
	[DateOfFact] [datetime] NULL,
	[Entity] [varchar](50) NULL,
	[PolicyNumber] [varchar](50) NULL,
	[YOA] [int] NULL,
	[BusinessKey] [varchar](255) NULL,
	[Value] [numeric](19, 4) NULL,
	[DeltaType] [varchar](50) NULL,
	[InceptionDate] [datetime] NULL,
	[ExpiryDate] [datetime] NULL,
	[DataSet] [varchar](50) NULL,
	[BindDate] [datetime2](7) NULL,
	[DueDate] [datetime2](7) NULL,
	[TrifocusCode] [varchar](255) NULL,
	[TypeofBusiness] [varchar](1) NULL,
	[SettlementCCY] [varchar](25) NULL,
	[ISTODate] [varchar](1) NULL,
	[fk_Allocation] [int] NULL
) ON [PRIMARY]
GO
