﻿CREATE TABLE [stg].[dim_LargeLossCatCode](
		[PK_CatCode]            VARCHAR (20)  NOT NULL,
    [BeazleyCatCode]        CHAR (12)     NOT NULL,
       
       [MarketCatCode] [varchar](12) NULL,
       [BeazleyCatDesription] [varchar](30) NULL,
       [BeazleySpecial] [char](15) NULL,
       [EventYear] [int] NULL,
       [BeazleyEventName] [varchar](100) NULL,
       [LargeLossIndicator] [tinyint] NULL,
       [AuditSourceBatchID] [varchar](255) NOT NULL,
       [AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
       [AuditGenerateDateTime] [datetime] NOT NULL,
       [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
       [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))), 
    CONSTRAINT [PK_CatCode] PRIMARY KEY ([PK_CatCode])
) ON [PRIMARY]
GO
