﻿CREATE TABLE [stg].[fct_Pattern] (
    [PK_Pattern]                     BIGINT           IDENTITY (1, 1) NOT NULL,
    [FK_Batch]                       INT              NOT NULL,
    [FK_DataSet]                     BIGINT				NULL,
    [FK_PatternName]                 BIGINT			  NOT NULL,
    [FK_Trifocus]					 BIGINT			  NOT NULL,
    [FK_YOA]                         BIGINT			  NOT NULL,
    [FK_InceptionYear]               INT              NOT NULL,
    [FK_CCYSettlement]               BIGINT			  NOT NULL,
    [FK_AccountingPeriod]            BIGINT           NOT NULL,
    [DevelopmentQuarter]             INT              NOT NULL,
    [PatternScenario]                VARCHAR (10)     NOT NULL,
    [PatternScenarioVersion]         INT              NOT NULL,
    [DevelopmentPercentageIncrement] NUMERIC (38, 10) NOT NULL,
    [AuditSourceBatchID]             VARCHAR (510)    NOT NULL,
    [AuditCreateDateTime]            DATETIME2 (7)    NOT NULL,
    [AuditGenerateDateTime]          DATETIME2 (7)    NOT NULL,
    [AuditUserCreate]                VARCHAR (510)    NOT NULL,
    CONSTRAINT [PK_Pattern] PRIMARY KEY CLUSTERED ([PK_Pattern] ASC)
);





