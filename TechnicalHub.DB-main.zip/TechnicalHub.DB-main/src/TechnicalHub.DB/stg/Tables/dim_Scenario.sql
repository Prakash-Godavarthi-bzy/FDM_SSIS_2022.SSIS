﻿CREATE TABLE [stg].[dim_Scenario] (
	[PK_Scenario]	BIGINT NOT NULL IDENTITY(1,1),
    [BK_Scenario]  VARCHAR (10) NOT NULL,
    [ScenarioName] VARCHAR (50) NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    CONSTRAINT [PK_Scenario] PRIMARY KEY CLUSTERED ([PK_Scenario] ASC) WITH (FILLFACTOR = 90)
);

