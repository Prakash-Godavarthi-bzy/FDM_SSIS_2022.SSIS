﻿CREATE TABLE [stg].[EarningPercentage] (
    [pk_EarningPercentage] INT              IDENTITY (1, 1) NOT NULL,
    [FK_earningPAttern]    VARCHAR (5)      NULL,
    [FK_Policy]            VARCHAR (255)    NULL,
	[FK_PolicySection]		VARCHAR (255)	 NULL,
    [pk_Period]            INT              NOT NULL,
    [ClosingPeriod]        INT              NULL,
    [InceptionDate]        DATE             NULL,
    [ExpiryDate]           DATE             NULL,
    [YOA]                  INT              NULL,
    [PolicyLength]         NUMERIC (10, 5)  NULL,
    [PolicyAge]            NUMERIC (10, 5)  NULL,
    [DaysinMonth]          INT              NULL,
    [ZoneALength]          NUMERIC (10, 5)  NULL,
    [ZoneBLength]          NUMERIC (10, 5)  NULL,
    [ZoneABLength]         NUMERIC (10, 5)  NULL,
    [ZoneABCLength]        NUMERIC (10, 5)  NULL,
    [ZoneAEarning]         NUMERIC (38, 15) DEFAULT ((0)) NULL,
    [ZoneBEarning]         NUMERIC (38, 15) DEFAULT ((0)) NULL,
    [ZoneCEarning]         NUMERIC (38, 15) DEFAULT ((0)) NULL,
    [PrevMZoneAEarnings]   NUMERIC (38, 15) DEFAULT ((0)) NULL,
    [PrevMZoneBEarnings]   NUMERIC (38, 15) DEFAULT ((0)) NULL,
    [PrevMZoneCEarnings]   NUMERIC (38, 15) DEFAULT ((0)) NULL,
    [EarningValue]         NUMERIC (38, 10) NULL,
    PRIMARY KEY NONCLUSTERED ([pk_EarningPercentage] ASC)
);




GO
CREATE UNIQUE CLUSTERED INDEX [ix_stg_EarningPercentage]
    ON [stg].[EarningPercentage]([FK_earningPAttern] ASC, [FK_Policy] ASC, [pk_Period] ASC);


GO
CREATE NONCLUSTERED INDEX [ix_EarningBatchFilter_FK_earningPAttern_PolicyAge_Inc]
    ON [stg].[EarningPercentage]([FK_earningPAttern] ASC, [PolicyAge] ASC)
    INCLUDE([FK_Policy], [pk_Period], [ZoneALength]);

