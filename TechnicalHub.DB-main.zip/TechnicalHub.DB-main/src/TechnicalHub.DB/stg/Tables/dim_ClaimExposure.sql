﻿CREATE TABLE [stg].[dim_ClaimExposure](
	[PK_ClaimExposure]		[bigint] IDENTITY(1,1) NOT NULL,
	[BK_ClaimExposure]		[varchar] (255) NOT NULL,
	[ClaimExposure]			[varchar] (255)	NOT NULL,
	[SCMClaimReference]		[varchar] (255) NULL,
	[ClaimReference]		[varchar] (255) NULL,
	[BeazleyCatCode]		[varchar] (255) NULL,
	[DateOfLoss]			[DATE]			NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
 CONSTRAINT [PK_ClaimExposure] PRIMARY KEY CLUSTERED 
(
	[PK_ClaimExposure] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO