﻿CREATE TABLE [stg].[dim_Allocation] (
    [pk_Allocation]           INT             IDENTITY (1, 1) NOT NULL,
    [Account]                 INT             NOT NULL,
    [EntityCode]              VARCHAR (50)    NOT NULL,
    [TrifocusCodeFrom]        VARCHAR (25)    NULL,
    [TrifocusCodeTo]          VARCHAR (25)    NULL,
    [YOAFrom]                 INT             NULL,
    [YOATo]                   INT             NULL,
    [DestinationAccount]      INT             NOT NULL,
    [DestinationEntity]       VARCHAR (50)    NOT NULL,
    [DestinationTrifocusCode] VARCHAR (25)    NULL,
    [AllocationPercentage]    DECIMAL (28, 8) NOT NULL,
    CONSTRAINT [pk_Allocation] PRIMARY KEY CLUSTERED ([pk_Allocation] ASC)
);

