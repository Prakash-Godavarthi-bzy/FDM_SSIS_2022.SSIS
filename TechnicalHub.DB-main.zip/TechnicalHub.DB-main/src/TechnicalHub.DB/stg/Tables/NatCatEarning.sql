﻿CREATE TABLE [stg].[NatCatEarning] (
    [PK_Pattern]                     INT             IDENTITY (1, 1) NOT NULL,
    [PatternScenario]                VARCHAR (10)    NOT NULL,
    [PatternScenarioVersion]         INT             NOT NULL,
    [PatternName]                    VARCHAR (10)    NOT NULL,
    [DataSet]                        VARCHAR (50)    NOT NULL,
    [TrifocusCode]                   VARCHAR (100)   NOT NULL,
    [YOA]                            VARCHAR (5)     NULL,
    [InceptionYear]                  SMALLINT        NULL,
    [SettlementCCY]                  VARCHAR (3)     NULL,
    [DevelopmentPercentageIncrement] NUMERIC (19, 6) NOT NULL,
    [DevelopmentQuarter]             INT             NOT NULL,
    [BusinessProcessCode]            VARCHAR (255)   NOT NULL,
    [FK_Batch]                       INT             NOT NULL,
    [AuditSourceBatchID]             VARCHAR (255)   NOT NULL,
    [AuditCreateDateTime]            DATETIME        NOT NULL,
    [AuditGenerateDateTime]          DATETIME        NOT NULL,
    [AuditUserCreate]                VARCHAR (255)   NOT NULL,
    [AuditHost]                      VARCHAR (255)   NOT NULL
);

