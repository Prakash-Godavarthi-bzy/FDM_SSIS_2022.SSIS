﻿CREATE TABLE stg.fct_FXRate
( 
	fk_Batch					INT             NOT NULL ,
    fk_AccountingPeriod			INT				NOT NULL ,
	FXRateName					NVARCHAR(255)	NOT NULL ,
	fk_TransactionCurrency		NVARCHAR(25)	NOT NULL ,
	fK_ReportingCurrencyCode	NVARCHAR(255)	NOT NULL ,
	FXRate						NUMERIC(28,8)	NULL ,
	fK_RateCode					NVARCHAR(255)	NOT NULL ,
	CONSTRAINT PK_FXRate PRIMARY KEY 
	(
		fk_AccountingPeriod ,
		FXRateName ,
		fk_TransactionCurrency ,
		fK_ReportingCurrencyCode ,
		fK_RateCode 
	)
);
GO