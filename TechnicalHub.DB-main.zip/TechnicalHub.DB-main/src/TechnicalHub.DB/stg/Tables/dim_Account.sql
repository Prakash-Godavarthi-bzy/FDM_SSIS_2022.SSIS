﻿CREATE TABLE [stg].[dim_Account] (
	[PK_Account]	BIGINT			 NOT NULL IDENTITY(1,1),
    [BK_Account]  VARCHAR (50)   NOT NULL,
    [AccountName] VARCHAR (100) NULL,
    [Level1Group] VARCHAR (100) NULL,
    [Level2Group] VARCHAR (100) NULL,
    [Level3Group] VARCHAR (100) NULL,
	[RIFlag]		varchar(2)			NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    CONSTRAINT [PK_Account] PRIMARY KEY CLUSTERED ([PK_Account] ASC) WITH (FILLFACTOR = 90)
);

