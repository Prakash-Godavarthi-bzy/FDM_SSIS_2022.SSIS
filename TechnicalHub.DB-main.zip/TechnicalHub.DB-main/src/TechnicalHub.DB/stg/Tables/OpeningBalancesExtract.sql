﻿CREATE TABLE [stg].[OpeningBalancesExtract] (
    [CalculationTreeNode] NVARCHAR (255) NULL,
    [Entity]              NVARCHAR (255) NULL,
    [InceptionYear]       NVARCHAR (255) NULL,
    [YOA]                 NVARCHAR (255) NULL,
    [TriFocus]            NVARCHAR (255) NULL,
    [CCYSettlement]       NVARCHAR (255) NULL,
    [CalculationResult]   NVARCHAR (255) NULL
);

