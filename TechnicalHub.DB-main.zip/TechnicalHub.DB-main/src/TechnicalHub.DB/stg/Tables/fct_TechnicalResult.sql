﻿CREATE TABLE [stg].[fct_TechnicalResult] (
    [PK_FTH]                BIGINT           IDENTITY (1, 1) NOT NULL,
    [FK_Batch]              INT              NOT NULL,
    [FK_DataSet]            BIGINT				 NOT NULL,
    [FK_Scenario]           BIGINT				 NOT NULL,
    [FK_Account]            BIGINT				 NOT NULL,
    [FK_AccountingPeriod]   BIGINT              NOT NULL,
    [FK_Basis]              BIGINT				 NOT NULL,
    [FK_DataStage]          INT              NOT NULL,
    [FK_Entity]             BIGINT				 NOT NULL,
    [FK_Policy]             VARCHAR (255)    NOT NULL,
	[FK_PolicySection]		BIGINT				 NOT NULL,
    [FK_Process]            BIGINT				 NOT NULL,
    [FK_Product]            BIGINT				 NOT NULL,
    [FK_Location]           BIGINT			     NOT NULL,
    [FK_Trifocus]           BIGINT				 NOT NULL,
    [FK_YOA]                BIGINT				 NOT NULL,
    [FK_Allocation]         INT              NULL,
    [FK_CCYOriginal]        BIGINT				NOT NULL,
    [FK_CCYSettlement]      BIGINT				NOT NULL,
    [FK_DateDue]            BIGINT              NOT NULL,
    [Value]                 NUMERIC (38, 10) NOT NULL,
    [EarningPercentage]     NUMERIC (38, 10) NULL,
    [Fk_statscode]          VARCHAR (25)     NULL,
    [RowHash]               VARBINARY (8000) NOT NULL,
    [AuditSourceBatchID]    NVARCHAR (510)   NOT NULL,
    [AuditCreateDateTime]   DATETIME2 (7)    NOT NULL,
    [AuditGenerateDateTime] DATETIME2 (7)    NOT NULL,
    [AuditUserCreate]       NVARCHAR (510)   NOT NULL,
	[FK_InceptionYear]      INT              NULL,
	[InceptionPeriod]       INT              NULL,
	[FK_CatCode]            BIGINT				NOT NULL,
	[FK_MovementType]		BIGINT				NOT NULL,
	[FK_TrackingStatus]		BIGINT				NOT NULL,
	[FK_ClaimExposure]		BIGINT				NOT NULL,
	[FK_DateOfFact]			BIGINT				NOT NULL,
	[BusinessKey]			VARCHAR(255)		NOT NULL,
	[FK_InceptionDate]		BIGINT				NOT NULL,
	[FK_RIPolicyType]		BIGINT				NOT NULL,
	[FK_ProgrammeCode]		BIGINT				NOT NULL,
	[Att_Cat]				VARCHAR(1)				NULL,
	[FK_ReservingDataset]	VARCHAR(100)			NULL,
	[FK_TriangleGroup]		VARCHAR(100)			NULL,
	[FK_SourceEntity]		BIGINT					NULL,
	[FK_DeltaType]			BIGINT					NULL,
	[GroupShare]		    FLOAT					NULL,
	[Intercompany_PrioritySeq] INT					NULL,
    CONSTRAINT [PK_TechnicalResult] PRIMARY KEY CLUSTERED ([PK_FTH] ASC)
);









