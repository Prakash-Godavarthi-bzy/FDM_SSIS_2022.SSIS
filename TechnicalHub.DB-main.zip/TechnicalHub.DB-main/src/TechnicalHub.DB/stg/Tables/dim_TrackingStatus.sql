﻿CREATE TABLE [stg].[dim_TrackingStatus](
	[PK_TrackingStatus]	BIGINT  NOT NULL IDENTITY(1,1),
	[BK_TrackingStatus] [varchar](50) NOT NULL,
	[TrackingStatus] [varchar](100) NOT NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
 CONSTRAINT [PK_TrackingStatusID] PRIMARY KEY CLUSTERED 
(
	[PK_TrackingStatus] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO