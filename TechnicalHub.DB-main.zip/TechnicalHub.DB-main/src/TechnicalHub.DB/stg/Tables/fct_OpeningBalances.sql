﻿CREATE TABLE [stg].[fct_OpeningBalances] (
    [FK_DataSet]          VARCHAR (10)    DEFAULT ('OB') NOT NULL,
    [FK_BatchRun]         INT             NOT NULL,
    [UnitOfAccount]       VARCHAR (2000)  NOT NULL,
    [TreeNode]            VARCHAR (20)    NOT NULL,
    [FK_AccountingPeriod] VARCHAR (6)     NULL,
    [BalanceValue]        DECIMAL (18, 5) NOT NULL
);

