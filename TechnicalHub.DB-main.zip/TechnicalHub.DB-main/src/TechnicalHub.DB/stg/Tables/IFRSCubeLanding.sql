﻿CREATE TABLE [stg].[IFRSCubeLanding] (
    [YOA]               NVARCHAR (255) NULL,
    [Inception_Year]    NVARCHAR (255) NULL,
    [TriFocus]          NVARCHAR (255) NULL,
    [Entity]            NVARCHAR (255) NULL,
    [CCYSettlement]     NVARCHAR (255) NULL,
    [AccountingPeriod]  NVARCHAR (255) NULL,
    [CalculationResult] NVARCHAR (255) NULL,
    [CalculationTree]   NVARCHAR (20)  NULL
);

