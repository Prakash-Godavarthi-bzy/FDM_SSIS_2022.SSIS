﻿CREATE TABLE [stg].[EarningBatchFilter] (
    [PK_FTH]            BIGINT           NOT NULL,
    [RowHash]           VARBINARY (8000) NOT NULL,
    [FK_Policy]         VARCHAR (225)    NOT NULL,
	[FK_PolicySection]	VARCHAR (255)	 NULL,
    [FK_earningPAttern] VARCHAR (5)      NOT NULL,
    CONSTRAINT [pk_EarningBatchFilter] PRIMARY KEY CLUSTERED ([FK_earningPAttern] ASC, [PK_FTH] ASC) WITH (FILLFACTOR = 90)
);



