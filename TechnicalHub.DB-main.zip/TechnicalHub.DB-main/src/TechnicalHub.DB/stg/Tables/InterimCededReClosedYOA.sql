﻿CREATE TABLE [stg].[InterimCededReClosedYOA](
	[Scenario] [varchar](1) NOT NULL,
	[Basis] [varchar](1) NOT NULL,
	[Dataset] [varchar](255) NOT NULL,
	[Account] [varchar](50) NOT NULL,
	[DateOfFact] [datetime] NULL,
	[RIPolicyType] [varchar](50) NULL,
	[Entity] [varchar](50) NULL,
	[PolicyNumber] [varchar](50) NULL,
	[ProgrmmeCode] [varchar](50) NULL,
	[YOA] [int] NULL,
	[SettlementCurrency] [nvarchar](3) NULL,
	[Trifocus] [varchar](50) NULL,
	[BusinessKey] [varchar](255) NULL,
	[Value] [numeric](19, 4) NULL,
	[DeltaType] [varchar](50) NULL,
	[InceptionDate] [datetime] NOT NULL,
	[ExpiryDate] [datetime] NOT NULL
) ON [PRIMARY]
GO
