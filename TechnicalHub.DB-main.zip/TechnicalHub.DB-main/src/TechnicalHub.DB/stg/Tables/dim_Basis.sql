﻿CREATE TABLE [stg].[dim_Basis] (
	[PK_Basis]	BIGINT NOT NULL IDENTITY(1,1),
    [BK_Basis]  VARCHAR (10)   NOT NULL,
    [BasisName] VARCHAR (100) NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    CONSTRAINT [PK_Basis] PRIMARY KEY CLUSTERED ([PK_Basis] ASC) WITH (FILLFACTOR = 90)
);

