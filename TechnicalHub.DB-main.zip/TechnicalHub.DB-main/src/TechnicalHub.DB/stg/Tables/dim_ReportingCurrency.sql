﻿CREATE TABLE stg.dim_ReportingCurrency
(
	PK_ReportingCurrencyCode	NVARCHAR(255)	NOT NULL ,
	ReportingCurrencyName		NVARCHAR(255)	NULL ,
	CONSTRAINT PK_ReportingCurrency PRIMARY KEY CLUSTERED (PK_ReportingCurrencyCode ASC)
);
