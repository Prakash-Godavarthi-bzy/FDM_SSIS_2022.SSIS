﻿

/*=======================================================================================================
Does:	Extracts newly loaded EB binder data in preparation of earning percentage generation and 
		application
Caller:	FactEarnings.dtsx
=======================================================================================================*/
CREATE   PROCEDURE [stg].[usp_EarningAdjustBinderExtract]
AS
BEGIN
	SET NOCOUNT ON
	
	/*=======================================================================================================
	Selection
	=======================================================================================================*/
	BEGIN TRY
		INSERT	stg.EarningBatchFilter(PK_FTH, RowHash, FK_Policy,FK_PolicySection, FK_earningPAttern)
		SELECT	tr.PK_FTH
				,tr.Rowhash
				,tr.FK_Policy
				,PS.BK_PolicySection
				,FK_earningPAttern = 'TA' 
		FROM	fct.TechnicalResult tr
		--JOIN	dim.Policy p			ON p.PK_Policy = tr.FK_Policy
		JOIN	dim.PolicySection	PS	ON PS.PK_PolicySection=TR.FK_PolicySection   --++
		JOIN	dim.Entity	e			ON e.[PK_Entity] = tr.FK_Entity
		LEFT JOIN  Dim.YOA Y ON Y.PK_YOA=TR.FK_YOA
		LEFT JOIN Dim.Account DA ON DA.PK_Account=TR.FK_Account  --++
		WHERE	tr.fk_Batch IN (SELECT PK_Batch FROM [FinanceDataContract].[Inbound].[BatchQueue]	WHERE Status='TechnicalHub' AND DataSet NOT IN ('BICI','USBAIC','USSYND','BIDAC'))

			--	AND tr.FK_Account IN ( 'P-GP-B','P-AC-B','P-LB-B')  ----
				AND DA.BK_Account IN ( 'P-GP-B','P-AC-B','P-LB-B')  --++
				AND e.Platform = 'Synd'
				AND PS.InceptionDate <= PS.ExpiryDate
				AND	YEAR(PS.InceptionDate) <= PS.PolicyYOA + 1
				AND	DATEDIFF(YY, PS.InceptionDate, PS.ExpiryDate) <= 15
				AND PS.InceptionDate <= PS.ExpiryDate							--++
				AND	YEAR(PS.InceptionDate) <= PS.PolicyYOA + 1				--++
				AND	DATEDIFF(YY, PS.InceptionDate, PS.ExpiryDate) <= 15		--++
				--AND tr.FK_YOA >= 2015;
				AND  Y.BK_YOA>='2015';
		
		RAISERROR('stg.EarningBatchFilter: %i', 0, 0, @@rowcount) WITH NOWAIT;

		IF NOT EXISTS (SELECT * FROM stg.EarningBatchFilter WHERE FK_earningPAttern = 'T')
			RETURN


	END TRY
	BEGIN CATCH
		--Call to logging framework needed here
		THROW;
	END CATCH
END