﻿/*=======================================================================================================
Does:		Caters for rounding issue caused by precision limitations on DECIMAL data type after earning calculations. 
Caller:		FactEarnings.dtsx
Parameters:	@FK_earningPattern(T=Trapezioidal, L=Linear)
=======================================================================================================*/

CREATE   PROCEDURE [stg].[usp_EarningRoundingPercentages]
AS
BEGIN
	BEGIN TRY
		
		/*=======================================================================================================
		Calculate rounding issue caused by precision limitations
		=======================================================================================================*/

		--Produce last value. Caters for rounding issue caused by precision limitations on DECIMAL data type
		UPDATE	ec
		SET		ec.EarningValue = ISNULL(ec.EarningValue, 0) + IIF(ec.pk_EarningPercentage = ISNULL(DIFF.FirstNullValue, DIFF.LastValue), 1 - DIFF.TotalEarningValue, 0)
		--select *, ISNULL(ec.EarningValue, 0) + IIF(ec.pk_EarningPercentage = ISNULL(DIFF.FirstNullValue, DIFF.LastValue), 1 - DIFF.TotalEarningValue, 0)
		FROM	stg.EarningPercentage ec
		JOIN	(
					SELECT	SUM(ISNULL(mec.EarningValue,0)) AS TotalEarningValue, --Added 
							MIN(IIF(mec.EarningValue IS NULL, mec.pk_EarningPercentage, NULL)) AS FirstNullValue,
							MAX(mec.pk_EarningPercentage) AS LastValue,
							mec.fk_policy,
							mec.FK_earningPAttern
					FROM	stg.EarningPercentage mec
					GROUP BY mec.fk_policy,mec.FK_earningPAttern
				) DIFF	ON DIFF.fk_policy = ec.fk_policy
						AND DIFF.FK_earningPAttern = ec.FK_earningPAttern
		WHERE	diff.TotalEarningValue <> 1

		RAISERROR('rounding: %i', 0, 0, @@rowcount) WITH NOWAIT;

		IF EXISTS	(
						SELECT		SUM(EarningValue),
									fk_policy,
									FK_earningPAttern
						FROM		stg.EarningPercentage
						GROUP BY	fk_policy,FK_earningPAttern
						HAVING		SUM(EarningValue) <> 1
					)
		RAISERROR	('!!!!!!!!!!!!!!!!!!!!!!!!!!Earning Percentages don''t sum to 100%!!!!!!!!!!!!!!!!!!!!!!!!!!', 16, 1)
	END TRY
	BEGIN CATCH
		THROW;
	END CATCH
END