﻿

/*=======================================================================================================
Does:	Extracts newly loaded EB binder data in preparation of earning percentage generation and 
		application
Caller:	FactEarnings.dtsx
=======================================================================================================*/
CREATE   PROCEDURE [stg].[usp_EarningBinderExtract]
AS
BEGIN
	SET NOCOUNT ON
	
	/*=======================================================================================================
	Initialisation & metadata
	=======================================================================================================*/
	DROP TABLE IF EXISTS #AccountingPeriod
	SELECT	[BK_AccountingPeriod], 
			DATEFROMPARTS(ap.AccountingYear, ap.AccountingMonth, 1) AS AccountingPeriodDate
	INTO	#AccountingPeriod
	FROM	dim.AccountingPeriod ap
	WHERE	ap.AccountingMonth BETWEEN 1 AND 12

	RAISERROR('#AccountingPeriod: %i', 0, 0, @@rowcount) WITH NOWAIT;

	CREATE UNIQUE CLUSTERED INDEX ix_#AccountingPeriod ON #AccountingPeriod ([BK_AccountingPeriod])

	/*=======================================================================================================
	Selection
	=======================================================================================================*/
	BEGIN TRY
		INSERT	stg.EarningBatchFilter(PK_FTH, RowHash, FK_Policy, FK_PolicySection,FK_earningPAttern)
		SELECT	tr.PK_FTH
				,tr.Rowhash
				,tr.FK_Policy
				,PS.BK_PolicySection
				,FK_earningPAttern = 'T' 
		FROM	fct.TechnicalResult tr
		--JOIN	dim.Policy p			ON p.PK_Policy = tr.FK_Policy
		JOIN	dim.PolicySection	PS	ON PS.PK_PolicySection=TR.FK_PolicySection   --++
		JOIN	dim.Entity	e			ON e.[PK_Entity] = tr.FK_Entity
		LEFT JOIN  Dim.YOA Y ON Y.PK_YOA=TR.FK_YOA   --++
		LEFT JOIN Dim.Account DA ON DA.PK_Account=TR.FK_Account  --++
		WHERE	tr.fk_Batch IN (SELECT PK_Batch FROM [FinanceDataContract].[Inbound].[BatchQueue]	WHERE Status='TechnicalHub' AND DataSet NOT IN ('BICI','USBAIC','USSYND','BIDAC'))
				--AND tr.FK_Account IN ( 'P-GP-B','P-AC-B')           ----
				AND DA.BK_Account IN ( 'P-GP-B','P-AC-B')  --++
				AND e.Platform = 'Synd'
				AND PS.InceptionDate <= PS.ExpiryDate
				AND	YEAR(PS.InceptionDate) <= PS.PolicyYOA + 1
				AND	DATEDIFF(YY, PS.InceptionDate, PS.ExpiryDate) <= 15
				AND PS.InceptionDate <= PS.ExpiryDate						--++
				AND	YEAR(PS.InceptionDate) <= PS.PolicyYOA + 1				--++
				AND	DATEDIFF(YY, PS.InceptionDate, PS.ExpiryDate) <= 15		--++
				--AND tr.FK_YOA >= 2015;
				AND Y.BK_YOA>='2015';  --++
		
		RAISERROR('stg.EarningBatchFilter: %i', 0, 0, @@rowcount) WITH NOWAIT;

		IF NOT EXISTS (SELECT * FROM stg.EarningBatchFilter WHERE FK_earningPAttern = 'T')
			RETURN

		----EB Syndicate Binder, Trapezioidal earning pattern (See above)
		--INSERT		stg.EarningPercentage(fk_policy, InceptionDate, ExpiryDate, YOA, pk_Period, PolicyLength, PolicyAge, ClosingPeriod, ZoneALength, ZoneBLength, ZoneABLength, ZoneABCLength, FK_earningPAttern)
		--SELECT		bf.FK_Policy
		--,			p.InceptionDate
		--,			p.ExpiryDate
		--,			YOA					= p.PolicyYOA
		--,			pk_Period			= ap.PK_AccountingPeriod
		--,			PolicyLength		= DATEDIFF(D, p.InceptionDate, p.ExpiryDate) + 1
		--,			PolicyAge			= DATEDIFF(D, p.InceptionDate, EOMONTH(ap.AccountingPeriodDate)) + 1
		--,			ClosingPeriod		= CONVERT(VARCHAR(8), p.MaxEarningDate, 112)
		--,			ZoneALength			= IIF(DATEDIFF(D, p.InceptionDate, p.ExpiryDate) + 1 <= 365, DATEDIFF(D, p.InceptionDate, p.ExpiryDate) + 1, 365)
		--,			ZoneBLength			= IIF(DATEDIFF(D, p.InceptionDate, p.ExpiryDate) + 1 >= 365, DATEDIFF(D, p.InceptionDate, p.ExpiryDate) + 1, 365)
		--								- IIF(DATEDIFF(D, p.InceptionDate, p.ExpiryDate) + 1 <= 365, DATEDIFF(D, p.InceptionDate, p.ExpiryDate) + 1, 365)
		--,			ZoneABLength		= IIF(DATEDIFF(D, p.InceptionDate, p.ExpiryDate) + 1 >= 365, DATEDIFF(D, p.InceptionDate, p.ExpiryDate) + 1, 365)
		--,			ZoneABCLength		= DATEDIFF(D, p.InceptionDate, p.ExpiryDate) + 1 + 365
		--,			bf.FK_earningPAttern
		--FROM		(SELECT	DISTINCT fk_Policy ,FK_earningPAttern FROM	stg.EarningBatchFilter  WHERE FK_earningPAttern = 'T') bf			
		--JOIN		dim.Policy			p	ON	p.PK_Policy = bf.FK_Policy
		--JOIN		#AccountingPeriod	ap	ON	(
		--												ap.AccountingPeriodDate <= p.MaxEarningDate
		--											AND ap.AccountingPeriodDate BETWEEN p.InceptionDate AND p.MaxEarningDate 
		--										)
		--									OR	(
		--											p.InceptionDate > p.MaxEarningDate 
		--											AND ap.AccountingPeriodDate = p.MaxEarningDate
		--										)

		--RAISERROR('stg.EarningPercentage: %i', 0, 0, @@rowcount) WITH NOWAIT;


	END TRY
	BEGIN CATCH
		--Call to logging framework needed here
		THROW;
	END CATCH
END