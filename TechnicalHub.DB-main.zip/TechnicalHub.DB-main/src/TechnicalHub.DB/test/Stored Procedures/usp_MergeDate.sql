﻿CREATE PROCEDURE [test].[usp_MergeDate]
AS
BEGIN
		 DECLARE @Trancount INT = @@Trancount
         BEGIN TRY
              IF @Trancount = 0 BEGIN TRAN;

			
/*
================================================================================================================================================================
CHECK FOR NEW RECORD INSERTED
================================================================================================================================================================
*/

			  INSERT INTO stg.dim_Date([BK_Date],[Date],[DateName],[Year],[Month],[Day],[PERIOD],[MonthName],[Quarter],QuarterName,DaysInMonth)
				VALUES(99990101,CAST('9999-01-01' AS DATE),'01/01/9999',9999,1,1,999901,'January',1,'First',31)

				EXEC [dim].[usp_MergeDate]

				SELECT   IIF(COUNT(*)>0,'FAIL','PASS') 
			  FROM 
				(
				SELECT [BK_Date],[Date],[DateName],[Year],[Month],[Day],[PERIOD],[MonthName],[Quarter],QuarterName,DaysInMonth
				FROM [stg].[dim_Date]
				WHERE [BK_Date]=99990101
				EXCEPT
				SELECT [BK_Date],[Date],[DateName],[Year],[Month],[Day],[PERIOD],[MonthName],[Quarter],QuarterName,DaysInMonth
				FROM dim.[Date]
				WHERE [BK_Date]=99990101		
				)A
/*
================================================================================================================================================================
CHECK FOR RECORD UPDATED
================================================================================================================================================================
*/
          UPDATE [stg].[dim_Date]
			SET [Date]=CAST('9998-04-04' AS DATE)
				,[DateName]='04/04/9998'
				,[Year]=9998
				,[Month]=4
				,[Day]=4
				,[PERIOD]=999804
				,[MonthName]='April'
				,[Quarter]=2
				,QuarterName='Second'
				,DaysInMonth=30
			WHERE [BK_Date]=99990101

			EXEC [dim].[usp_MergeDate]

			SELECT   IIF(COUNT(*)>1,'FAIL','PASS') 
			  FROM 
				(
			SELECT [BK_Date],[Date],[DateName],[Year],[Month],[Day],[PERIOD],[MonthName],[Quarter],QuarterName,DaysInMonth
			FROM dim.[Date]
			WHERE		[BK_Date]=99990101 
					AND [Date]=CAST('9998-04-04' AS DATE)
					AND [DateName]='04/04/9998'
					AND [Year]=9998
					AND [Month]=4
					AND [Day]=4
					AND [PERIOD]=999804
					AND [MonthName]='April'
					AND [Quarter]=2
					AND QuarterName='Second'
					AND DaysInMonth=30
				)A

			  ROLLBACK; 
         END TRY
         BEGIN CATCH
               ROLLBACK;
              THROW;
         END CATCH

END