﻿CREATE PROCEDURE [test].[usp_MergeYOA]
AS
BEGIN
		 DECLARE @Trancount INT = @@Trancount
         BEGIN TRY
              IF @Trancount = 0 BEGIN TRAN;

			  
/*
================================================================================================================================================================
CHECK FOR NEW RECORD INSERTED
================================================================================================================================================================
*/

			  INSERT INTO stg.dim_YOA([BK_YOA]) VALUES('-2019')

			  EXECUTE [dim].[usp_MergeYOA]
			  
			  SELECT   IIF(COUNT(*)>0,'FAIL','PASS') 
			  FROM 
				(
			  SELECT	[BK_YOA]
			  FROM		stg.dim_YOA 
			  WHERE		[BK_YOA]='-2019' 
			  EXCEPT
			  SELECT	[BK_YOA]
			  FROM		dim.YOA 
			  WHERE		[BK_YOA]='-2019' 
			  ) A


			  ROLLBACK; 
         END TRY
         BEGIN CATCH
               ROLLBACK;
              THROW;
         END CATCH

END