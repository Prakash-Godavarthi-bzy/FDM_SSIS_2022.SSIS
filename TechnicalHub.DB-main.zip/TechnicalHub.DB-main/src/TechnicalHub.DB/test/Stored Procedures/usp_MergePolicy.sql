﻿CREATE PROCEDURE [test].[usp_MergePolicy]
AS
BEGIN
		 DECLARE @Trancount INT = @@Trancount
         BEGIN TRY
              IF @Trancount = 0 BEGIN TRAN;

			 
/*
================================================================================================================================================================
CHECK FOR NEW RECORD INSERTED
================================================================================================================================================================
*/

INSERT INTO [stg].[dim_Policy](PK_Policy,BK_PolicyNumber,InceptionDate,ExpiryDate,PolicyYOA,PolicyType,BindDate,TypeOfBusiness,MaxEarningDate,IsUSPolicy)
VALUES ('[ABCDEFG]-[9997-01-31 00:00:00]-[9998-01-30 00:00:00]-[9997]-[Non-Binder]-[NR]','ABCDEFG',CAST('9997-01-31 00:00:00' AS DATE),CAST('9998-01-30 00:00:00' AS DATE),9997,'Non-Binder',CAST('1000-01-01' AS DATE),'NR',CAST('9999-12-31' AS DATE),0)

EXEC dim.usp_MergePolicy

SELECT   IIF(COUNT(*)>0,'FAIL','PASS') 
			  FROM 
				(
SELECT PK_Policy,BK_PolicyNumber,InceptionDate,ExpiryDate,PolicyYOA,PolicyType,BindDate,TypeOfBusiness,MaxEarningDate,IsUSPolicy
FROM [stg].[dim_Policy]
WHERE PK_Policy='[ABCDEFG]-[9997-01-31 00:00:00]-[9998-01-30 00:00:00]-[9997]-[Non-Binder]-[NR]'
EXCEPT
SELECT PK_Policy,BK_PolicyNumber,InceptionDate,ExpiryDate,PolicyYOA,PolicyType,BindDate,TypeOfBusiness,MaxEarningDate,IsUSPolicy
FROM [dim].[Policy]
WHERE PK_Policy='[ABCDEFG]-[9997-01-31 00:00:00]-[9998-01-30 00:00:00]-[9997]-[Non-Binder]-[NR]'
)A
/*
================================================================================================================================================================
CHECK FOR RECORD UPDATED
================================================================================================================================================================
*/
           UPDATE [stg].[dim_Policy]
			SET BK_PolicyNumber='ABCDEFGH'
				,InceptionDate='9997-03-31 00:00:00'
				,ExpiryDate='9998-03-30 00:00:00'
				,PolicyYOA=9999
				,PolicyType='Binder'
				,BindDate=CAST('1001-01-01' AS DATE)
				,TypeOfBusiness='NRY'
				,MaxEarningDate=CAST('9999-12-31' AS DATE)
				,IsUSPolicy=1
			WHERE PK_Policy='[ABCDEFG]-[9997-01-31 00:00:00]-[9998-01-30 00:00:00]-[9997]-[Non-Binder]-[NR]'

			EXEC dim.usp_MergePolicy

			SELECT   IIF(COUNT(*)>1,'FAIL','PASS') 
			  FROM 
				(
			SELECT PK_Policy,BK_PolicyNumber,InceptionDate,ExpiryDate,PolicyYOA,PolicyType,BindDate,TypeOfBusiness,MaxEarningDate,IsUSPolicy
			FROM [dim].[Policy]
			WHERE		PK_Policy='[ABCDEFG]-[9997-01-31 00:00:00]-[9998-01-30 00:00:00]-[9997]-[Non-Binder]-[NR]'
					AND BK_PolicyNumber='ABCDEFGH'
					AND InceptionDate='9997-03-31 00:00:00'
					AND ExpiryDate='9998-03-30 00:00:00'
					AND PolicyYOA=9999
					AND PolicyType='Binder'
					AND BindDate=CAST('1001-01-01' AS DATE)
					AND TypeOfBusiness='NRY'
					AND MaxEarningDate=CAST('9999-12-31' AS DATE)
					AND IsUSPolicy=1
				)A

			  ROLLBACK; 
         END TRY
         BEGIN CATCH
               ROLLBACK;
              THROW;
         END CATCH

END