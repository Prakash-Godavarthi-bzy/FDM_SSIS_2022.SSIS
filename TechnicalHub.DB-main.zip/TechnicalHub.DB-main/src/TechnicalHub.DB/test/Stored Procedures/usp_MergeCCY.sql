﻿CREATE PROCEDURE [test].[usp_MergeCCY]
AS
BEGIN
		 DECLARE @Trancount INT = @@Trancount
         BEGIN TRY
              IF @Trancount = 0 BEGIN TRAN;

			 
/*
================================================================================================================================================================
CHECK FOR NEW RECORD INSERTED
================================================================================================================================================================
*/

			  INSERT INTO stg.dim_CCY([BK_CCY],CCYName) VALUES('CCC','DDD POUND')

			  EXECUTE [dim].[usp_MergeCCY]


			  SELECT   IIF(COUNT(*)>0,'FAIL','PASS') 
			  FROM 
				(
			  SELECT	[BK_CCY],
						CCYName
			  FROM		stg.dim_CCY 
			  WHERE		[BK_CCY]='CCC' 
			  EXCEPT
			  SELECT	[BK_CCY],
						CCYName
			  FROM		dim.CCY 
			  WHERE		[BK_CCY]='CCC' 
			  )A
/*
================================================================================================================================================================
CHECK FOR RECORD UPDATED
================================================================================================================================================================
*/
            UPDATE	stg.dim_CCY
			SET		CCYName='EEE POUND'
			WHERE	[BK_CCY]='CCC'

			EXECUTE [dim].[usp_MergeCCY]

			SELECT   IIF(COUNT(*)>1,'FAIL','PASS') 
			  FROM 
				(
			SELECT	[BK_CCY],
					CCYName
			FROM	dim.CCY 
			WHERE	[BK_CCY]='CCC' AND CCYName='EEE POUND'

			)A


			  ROLLBACK; 
         END TRY
         BEGIN CATCH
               ROLLBACK;
              THROW;
         END CATCH

END