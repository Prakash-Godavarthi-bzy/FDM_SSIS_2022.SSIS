﻿CREATE PROCEDURE test.usp_LogBatchAggregate_ActualTechnicalHubFxRate
@JobId INT
AS
BEGIN

	 DECLARE
		 @ActivityStatus	SMALLINT = 5, --1 started 2 succeded 3 stopped 4 errored 5 information 
		 @ActivityName      VARCHAR(100) ,
		 @ActivityMessage	NVARCHAR(4000) ;

/*
		=========================================================================================================
						Log Fact.FxRate count and SUM(FXRate) for testing
		=========================================================================================================
*/

		 SELECT 
			 @ActivityMessage = COUNT(*)
			,@ActivityName   = 'FxRate_TechnicalHub.test.LogBatchAggregate_Count'
		 FROM fct.FXRate;

		 EXEC [dbo].[usp_LogTechnicalHUB]
			  @v_ActivityMessage = @ActivityMessage, 
			  @v_ActivityStatus  = @ActivityStatus, 
			  @v_ActivityName    = @ActivityName,
			  @V_JobId           = @Jobid ;

		 SELECT 
			 @ActivityMessage = ISNULL(SUM(FXRate),0)
			,@ActivityName    = 'FxRate_TechnicalHub.test.LogBatchAggregate_Sum'
		 FROM fct.FXRate;

		 EXEC [dbo].[usp_LogTechnicalHUB]
			  @v_ActivityMessage = @ActivityMessage, 
			  @v_ActivityStatus  = @ActivityStatus, 
			  @v_ActivityName    = @ActivityName,
			  @V_JobId           = @Jobid ;

/*
       =========================================================================================================
         If FxRate_TechnicalHub Count or SUM(FXRate) is not equal to FxRate_FDM Count raise error                            
       =========================================================================================================
*/

		IF EXISTS
		(
			SELECT 
				E.ActivityMessage, 
				A.ActivityMessage
			FROM Orchestram.[Log].ActivityLog E
			INNER JOIN Orchestram.[Log].ActivityLog A 
				ON E.ActivityJobId = A.ActivityJobId
			WHERE E.ActivityName = 'FxRate_TechnicalHub.test.LogBatchAggregate_Count'
				AND A.ActivityName = 'FxRate_FDM.test.LogBatchAggregate_Count'
				AND E.ActivityMessage  <> A.ActivityMessage
		)
		BEGIN
			RAISERROR('FxRate_TechnicalHub Count value is not matching to FxRate_FDM Count value', 16, 1);
		END;

	    IF EXISTS
		(
			SELECT 
				E.ActivityMessage, 
				A.ActivityMessage
			FROM Orchestram.[Log].ActivityLog E
			INNER JOIN Orchestram.[Log].ActivityLog A 
				ON E.ActivityJobId = A.ActivityJobId
			WHERE E.ActivityName = 'FxRate_FDM.test.LogBatchAggregate_Sum'
				AND A.ActivityName = 'FxRate_TechnicalHub.test.LogBatchAggregate_Sum'
				AND E.ActivityMessage  <> A.ActivityMessage
		)
		BEGIN
			RAISERROR('FxRate_TechnicalHub Sum value is not matching to FxRate_FDM Sum value', 16, 1);
		END;

END;