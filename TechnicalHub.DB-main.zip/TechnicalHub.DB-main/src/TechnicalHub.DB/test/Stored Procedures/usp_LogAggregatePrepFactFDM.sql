﻿CREATE PROC [Test].[usp_LogAggregatePrepFactFDM] @Jobid INT,@AggregatePrepFact VARCHAR(50)
AS
/*
        =========================================================================================================
						Set logging parameters for prepfactfdmexternal test
		=========================================================================================================
*/

     DECLARE		 @ActivitySource SMALLINT=6, --1 --IFRS17--2--DatatContracct --6--TechnicalHUb
					 @ActivityStatus SMALLINT=5, --1 started 2 succeded 3 stopped 4 errored 5 information 
					 @ActivityName VARCHAR(50)='PrepFactFDM.test.usp_LogBatchAggregate',
					 @ActivityMessage NVARCHAR(4000)=CAST(@AggregatePrepFact AS NVARCHAR(50))

	
		
	/*
		=========================================================================================================
						Log Stg.TechnicalResult_FDM total value  for testing PrepFactFDMExteranl Test
		=========================================================================================================
*/

     EXEC [dbo].[usp_LogTechnicalHUB]
          @v_ActivityMessage = @ActivityMessage, 
          @v_ActivityStatus = @ActivityStatus, 
          @v_ActivityName = @ActivityName,
		  @V_JobId = @Jobid;

		  /*
		=========================================================================================================
						IF Stg.TechnicalResult_FDM value is not equal to Prep.FactFDMExternal value raise error
		=========================================================================================================
*/

     IF EXISTS
     (
         SELECT L.ActivityMessage, 
                I.ActivityMessage
         FROM Orchestram.[Log].ActivityLog L
              JOIN Orchestram.[Log].ActivityLog I ON L.ActivityJobId = I.ActivityJobId
         WHERE
			   L.ActivityName = 'Stg_TechnicalResult_FDM.test.usp_LogBatchAggregate'
               AND I.ActivityName = 'PrepFactFDM.test.usp_LogBatchAggregate'
               AND CAST(ROUND(L.ActivityMessage,00) AS NUMERIC(16,4)) <>CAST(ROUND(I.ActivityMessage,00) AS NUMERIC(16,4))
     )
         BEGIN
             RAISERROR('Stg.TechnicalResult_FDM Value is not matching with the PrepFactFDMExternal value for Max Pk_Batch InBetween Control.FDMPosting and: %i',16,1,@Jobid);
     END;

		 