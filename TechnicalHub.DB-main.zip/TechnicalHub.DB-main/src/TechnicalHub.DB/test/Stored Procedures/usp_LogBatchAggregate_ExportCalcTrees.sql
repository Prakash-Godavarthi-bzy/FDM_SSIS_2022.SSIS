﻿
CREATE PROC [test].[usp_LogBatchAggregate_ExportCalcTrees] (@CalcTree VARCHAR(40), @DetailRows INT)
      
AS
	 DECLARE
     @v_ActivityStatus_VE SMALLINT= 5, --1 started 2 succeded 3 stopped 4 errored 5 information 
     @v_ActivityName_VE VARCHAR(100)= 'ExportCubeCalculations.CalculationTreeExtracts',
	 @v_JobID INT ,
	 @v_ActivityMessage_VE NVARCHAR(4000);


     --     /*
     --        =========================================================================================================
     --                                         Set logging parameters for inbound value test
     --       =========================================================================================================
     --*/

     INSERT INTO [Orchestram].[Log].[ActivityLog]
     (FK_ParentActivityLog, 
      FK_ActivityLogTag, 
      FK_ActivitySource, 
      FK_ActivityType, 
      FK_ActivityStatus, 
      ActivityHost, 
      ActivityDatabase, 
      ActivityJobId, 
      ActivitySSISExecutionId, 
      ActivityName, 
      ActivityDateTime, 
      ActivityMessage
     )
            SELECT NULL, 
                   NULL, 
                   6, --TechnicalHub
                   3, --DataQuality
                   5, --Information
                   @@SERVERNAME, 
                   'TechnicalHub', 
                   @CalcTree, 
                   NULL, 
                   @v_ActivityName_VE, 
                   GETDATE(), 
                   @DetailRows

/*
       =========================================================================================================
                                         IF FDMActualFactTechnicalResult is not equal to FDMExpectedFactTechnicalResult raise error
                                         
                                         
       =========================================================================================================
       */

    IF EXISTS
     (
         SELECT E.ActivityMessage, 
                A.ActivityMessage
         FROM Orchestram.[Log].ActivityLog E
              JOIN Orchestram.[Log].ActivityLog A ON E.ActivityJobId = A.ActivityJobId
			  AND A.ActivityDatabase = E.ActivityDatabase
			  AND A.ActivityJobId = E.ActivityJobId
			  AND CONVERT(CHAR(10), A.ActivityDateTime, 23) = CONVERT(CHAR(10), E.ActivityDateTime, 23)
			  AND CONVERT(CHAR(10), A.ActivityDateTime, 23) = CONVERT(CHAR(10), GETDATE(), 23)
         WHERE E.ActivityName = 'ExportCubeCalculations.CalculationTreeExtracts'
               AND A.ActivityName = 'ImportCubeCalculations.CalculationTreeExtracts'
                 AND ROUND(E.ActivityMessage,00)  <> ROUND(A.ActivityMessage,00)
				 AND A.ActivityJobId = @CalcTree
     )
     BEGIN
         RAISERROR('ExportCubeCalculations.CalculationTreeExtracts row count does not match row count ImportCubeCalculations.CalculationTreeExtracts', 16, 1);
     END;