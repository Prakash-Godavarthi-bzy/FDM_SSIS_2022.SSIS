﻿CREATE PROCEDURE [test].[usp_MergeProduct]
AS
BEGIN
		 DECLARE @Trancount INT = @@Trancount
         BEGIN TRY
              IF @Trancount = 0 BEGIN TRAN;

			 
/*
================================================================================================================================================================
CHECK FOR NEW RECORD INSERTED
================================================================================================================================================================
*/

			  INSERT INTO stg.dim_Product([BK_Product],ProductName) VALUES('SBB','BeazleyBetterServices')

			  EXEC [dim].[usp_MergeProduct]

			  SELECT   IIF(COUNT(*)>0,'FAIL','PASS') 
			  FROM 
				(
			  SELECT	[BK_Product]
						,ProductName
			  FROM		[stg].dim_Product 
			  WHERE		[BK_Product]='SBB' 
			  EXCEPT
			  SELECT	[BK_Product]
						,ProductName
			  FROM		dim.Product 
			  WHERE		[BK_Product]='SBB'
			  )A  
/*
================================================================================================================================================================
CHECK FOR RECORD UPDATED
================================================================================================================================================================
*/
            UPDATE	stg.dim_Product
			SET		ProductName='BeazleyBestServices'
			WHERE	[BK_Product]='SBB'

			EXEC [dim].[usp_MergeProduct]

			SELECT   IIF(COUNT(*)>1,'FAIL','PASS') 
			  FROM 
				(
			SELECT	[BK_Product]
					,ProductName
			FROM	dim.Product 
			WHERE	[BK_Product]='SBB' AND ProductName='BeazleyBestServices'
			)A



			  ROLLBACK; 
         END TRY
         BEGIN CATCH
               ROLLBACK;
              THROW;
         END CATCH

END