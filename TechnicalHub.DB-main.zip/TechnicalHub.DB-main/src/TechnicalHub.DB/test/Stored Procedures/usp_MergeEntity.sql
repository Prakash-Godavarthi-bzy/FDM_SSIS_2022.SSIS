﻿CREATE PROCEDURE [test].[usp_MergeEntity]
AS
BEGIN
		 DECLARE @Trancount INT = @@Trancount
         BEGIN TRY
              IF @Trancount = 0 BEGIN TRAN;

			 
/*
================================================================================================================================================================
CHECK FOR NEW RECORD INSERTED
================================================================================================================================================================
*/

			  INSERT INTO stg.dim_Entity([BK_Entity],Entity,EntityName,[Platform],EntityLevel1,EntityLevel2,EntityLevel3,EntityLevel4) 
									VALUES('B20','B20','Beazley 2020','BB','UNESCO','UN','ES','CO')

			  EXEC [dim].[usp_MergeEntity]

			  SELECT   IIF(COUNT(*)>0,'FAIL','PASS') 
			  FROM 
				(
			  SELECT [BK_Entity],Entity,EntityName,[Platform],EntityLevel1,EntityLevel2,EntityLevel3,EntityLevel4
			  FROM stg.dim_Entity
			  WHERE [BK_Entity]='B20'
			  EXCEPT
			  SELECT [BK_Entity],Entity,EntityName,[Platform],EntityLevel1,EntityLevel2,EntityLevel3,EntityLevel4 
			  FROM dim.Entity
			  WHERE [BK_Entity]='B20'
			  )A
/*
================================================================================================================================================================
CHECK FOR RECORD UPDATED
================================================================================================================================================================
*/
           UPDATE stg.dim_Entity
			SET Entity='B200'
				,EntityName='Beazley 20020'
				,[Platform]='BBB'
				,EntityLevel1='UN-ES-COO'
				,EntityLevel2='UN-'
				,EntityLevel3='ES-'
				,EntityLevel4='COO'
			WHERE [BK_Entity]='B20'

			EXECUTE [dim].[usp_MergeEntity]

			SELECT   IIF(COUNT(*)>1,'FAIL','PASS') 
			  FROM 
				(
			SELECT [BK_Entity],Entity,EntityName,[Platform],EntityLevel1,EntityLevel2,EntityLevel3,EntityLevel4
			FROM dim.Entity
			WHERE [BK_Entity]='B20' AND Entity='B200' AND EntityName='Beazley 20020' AND [Platform]='BBB' AND EntityLevel1='UN-ES-COO'
					AND EntityLevel2='UN-' AND EntityLevel3='ES-' AND EntityLevel4='COO'
			)A



			  ROLLBACK; 
         END TRY
         BEGIN CATCH
               ROLLBACK;
              THROW;
         END CATCH

END