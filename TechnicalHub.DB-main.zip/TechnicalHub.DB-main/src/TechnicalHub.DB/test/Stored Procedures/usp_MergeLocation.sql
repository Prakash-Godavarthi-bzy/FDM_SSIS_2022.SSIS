﻿CREATE PROCEDURE [test].[usp_MergeLocation]
AS
BEGIN
		 DECLARE @Trancount INT = @@Trancount
         BEGIN TRY
              IF @Trancount = 0 BEGIN TRAN;

			  
/*
================================================================================================================================================================
CHECK FOR NEW RECORD INSERTED
================================================================================================================================================================
*/

			  INSERT INTO stg.dim_Location([BK_Location],LocationName) VALUES('AB','AAAAA')

			  EXEC [dim].[usp_MergeLocation]

			  SELECT   IIF(COUNT(*)>0,'FAIL','PASS') 
			  FROM 
				(
			  SELECT	[BK_Location]
						,LocationName
			  FROM		[stg].dim_Location 
			  WHERE		[BK_Location]='AB' 
			  EXCEPT
			   SELECT	[BK_Location]
						,LocationName
			  FROM		dim.[Location]  
			  WHERE		[BK_Location]='AB' 
			  )A 
/*
================================================================================================================================================================
CHECK FOR RECORD UPDATED
================================================================================================================================================================
*/
            UPDATE	stg.dim_Location
			SET		LocationName='BBBBB'
			WHERE	[BK_Location]='AB'

			EXECUTE [dim].[usp_MergeLocation]

			SELECT   IIF(COUNT(*)>1,'FAIL','PASS') 
			  FROM 
				(
			SELECT	[BK_Location]
					,LocationName
			FROM	dim.[Location]  
			WHERE	[BK_Location]='AB'  AND LocationName='BBBBB'
			)A


			  ROLLBACK; 
         END TRY
         BEGIN CATCH
               ROLLBACK;
              THROW;
         END CATCH

END