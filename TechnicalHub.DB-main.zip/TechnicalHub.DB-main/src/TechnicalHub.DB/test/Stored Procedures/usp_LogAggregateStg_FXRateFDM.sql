﻿CREATE PROCEDURE test.usp_LogBatchAggregateStg_FXRateFDM 
	@JobId			INT , 
	@StgRowCount	INT
AS

BEGIN

/*
        ==============================================================================================================================
						Log Stg.fct_FXRate_FDM row count value for testing
		==============================================================================================================================
*/

        DECLARE		 @ActivitySource SMALLINT = 3 , --1 --IFRS17--2--DatatContracct--6--TechnicalHub -- 3FDM
					 @ActivityStatus SMALLINT = 5 , --1 started 2 succeded 3 stopped 4 errored 5 information 
					 @ActivityName VARCHAR(100) ,
					 @ActivityMessage NVARCHAR(4000) ;
	
		SELECT 
			 @ActivityMessage = ISNULL(@StgRowCount,0)
			,@ActivityName = 'FxRate_FDM.test.LogBatchAggregate_Count';

		INSERT INTO [Orchestram].[Log].[ActivityLog]
		(
			FK_ParentActivityLog, 
			FK_ActivityLogTag, 
			FK_ActivitySource, 
			FK_ActivityType, 
			FK_ActivityStatus, 
			ActivityHost, 
			ActivityDatabase, 
			ActivityJobId, 
			ActivitySSISExecutionId, 
			ActivityName, 
			ActivityDateTime, 
			ActivityMessage
		)
        SELECT 
			NULL, 
			NULL, 
			5, --FDM
			3, --DataQuality
			5, --Information
			@@SERVERNAME, 
			'TechnicalHub', 
			@JobId, 
			NULL, 
			@ActivityName, 
			GETDATE(), 
			@ActivityMessage
			;

/*		=========================================================================================================
						Log Stg.fct_FXRate_FDM SUM(FxRate) value for testing 
		=========================================================================================================
*/

		SELECT 
			 @ActivityMessage = ISNULL(SUM(FxRate),0)
			,@ActivityName = 'FxRate_FDM.test.LogBatchAggregate_Sum'
		FROM  stg.fct_FXRate ;

		INSERT INTO [Orchestram].[Log].[ActivityLog]
		(
			FK_ParentActivityLog, 
			FK_ActivityLogTag, 
			FK_ActivitySource, 
			FK_ActivityType, 
			FK_ActivityStatus, 
			ActivityHost, 
			ActivityDatabase, 
			ActivityJobId, 
			ActivitySSISExecutionId, 
			ActivityName, 
			ActivityDateTime, 
			ActivityMessage
		)
        SELECT 
			NULL, 
			NULL, 
			5, --FDM
			3, --DataQuality
			5, --Information
			@@SERVERNAME, 
			'TechnicalHub', 
			@JobId, 
			NULL, 
			@ActivityName, 
			GETDATE(), 
			@ActivityMessage
			;

END