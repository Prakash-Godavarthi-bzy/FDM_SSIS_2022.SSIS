﻿CREATE PROCEDURE [test].[usp_MergeAccountingPeriod]
AS
BEGIN
		 DECLARE @Trancount INT = @@Trancount
         BEGIN TRY
              IF @Trancount = 0 BEGIN TRAN;

			  
/*
================================================================================================================================================================
CHECK FOR NEW RECORD INSERTED
================================================================================================================================================================
*/
		INSERT INTO stg.dim_AccountingPeriod([BK_AccountingPeriod],AccountingPeriodName,AccountingYear,AccountingYearName,AccountingMonth,AccountingMonthName)
		VALUES (999908,'999908',9999,'9999',8,'08')

		EXEC [dim].usp_MergeAccountingPeriod

		SELECT   IIF(COUNT(*)>0,'FAIL','PASS') 
			  FROM 
				(
		SELECT [BK_AccountingPeriod],AccountingPeriodName,AccountingYear,AccountingYearName,AccountingMonth,AccountingMonthName
		FROM stg.dim_AccountingPeriod 
		EXCEPT
		SELECT [BK_AccountingPeriod],AccountingPeriodName,AccountingYear,AccountingYearName,AccountingMonth,AccountingMonthName
		FROM dim.AccountingPeriod 
			)A  
/*
================================================================================================================================================================
CHECK FOR RECORD UPDATED
================================================================================================================================================================
*/
            UPDATE stg.dim_AccountingPeriod
			SET AccountingPeriodName='999913'
				,AccountingYear=9990
				,AccountingYearName='9990'
				,AccountingMonth=13
				,AccountingMonthName='13'
			WHERE [BK_AccountingPeriod]=999908 

			EXEC [dim].usp_MergeAccountingPeriod

			SELECT   IIF(COUNT(*)>1,'FAIL','PASS') 
			  FROM 
				(
			SELECT [BK_AccountingPeriod],AccountingPeriodName,AccountingYear,AccountingYearName,AccountingMonth,AccountingMonthName
			FROM dim.AccountingPeriod 
			WHERE [BK_AccountingPeriod]=999908 AND AccountingPeriodName='999913' AND AccountingYearName='9990'AND AccountingMonth=13

			)A


			  ROLLBACK; 
         END TRY
         BEGIN CATCH
               ROLLBACK;
              THROW;
         END CATCH

END