﻿CREATE PROCEDURE  [test].[usp_MergeTrifocus]
AS
BEGIN
		 DECLARE @Trancount INT = @@Trancount
         BEGIN TRY
              IF @Trancount = 0 BEGIN TRAN;

			
/*
================================================================================================================================================================
CHECK FOR NEW RECORD INSERTED
================================================================================================================================================================
*/--SELECT * FROM stg.dim_TriFocus

			  INSERT INTO stg.dim_TriFocus([BK_TriFocus],TriFocusName,TriFocusLevel1,TriFocusLevel2) 
									VALUES('TFCB20','NationalB20','TFC1','TFC2')

			  EXEC [dim].[usp_MergeTriFocus]

			  SELECT   IIF(COUNT(*)>0,'FAIL','PASS') 
			  FROM 
				(
			  SELECT [BK_TriFocus],TriFocusName,TriFocusLevel1,TriFocusLevel2
			  FROM stg.dim_TriFocus
			  WHERE [BK_TriFocus]='TFCB20'
			  EXCEPT
			  SELECT [BK_TriFocus],TriFocusName,TriFocusLevel1,TriFocusLevel2 
			  FROM dim.TriFocus
			  WHERE [BK_TriFocus]='TFCB20'
			  )A
/*
================================================================================================================================================================
CHECK FOR RECORD UPDATED
================================================================================================================================================================
*/
           UPDATE stg.dim_TriFocus
			SET TriFocusName='NationalB2020'
				,TriFocusLevel1='TFC11'
				,TriFocusLevel2='TFC12'
			WHERE [BK_TriFocus]='TFCB20'

			EXECUTE [dim].[usp_MergeTriFocus]

			SELECT   IIF(COUNT(*)>1,'FAIL','PASS') 
			  FROM 
				(
			SELECT [BK_TriFocus],TriFocusName,TriFocusLevel1,TriFocusLevel2,TriFocusLevel3
			FROM dim.TriFocus
			WHERE [BK_TriFocus]='TFCB20' AND  TriFocusName='NationalB2020' AND  TriFocusLevel1='TFC11'
					AND TriFocusLevel2='TFC12' 
				)A



			  ROLLBACK; 
         END TRY
         BEGIN CATCH
               ROLLBACK;
              THROW;
         END CATCH

END