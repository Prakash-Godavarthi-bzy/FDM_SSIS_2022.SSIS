﻿

CREATE PROC [test].[usp_LogBatchAggregate_ImportCalcTrees] 
      
AS
	 DECLARE
     @v_ActivityStatus_VE SMALLINT= 5, --1 started 2 succeded 3 stopped 4 errored 5 information 
     @v_ActivityName_VE VARCHAR(100)= 'ImportCubeCalculations.CalculationTreeExtracts';

     --     /*
     --        =========================================================================================================
     --                                         Set logging parameters for inbound value test
     --       =========================================================================================================
     --*/

     INSERT INTO [Orchestram].[Log].[ActivityLog]
     (FK_ParentActivityLog, 
      FK_ActivityLogTag, 
      FK_ActivitySource, 
      FK_ActivityType, 
      FK_ActivityStatus, 
      ActivityHost, 
      ActivityDatabase, 
      ActivityJobId, 
      ActivitySSISExecutionId, 
      ActivityName, 
      ActivityDateTime, 
      ActivityMessage
     )
            SELECT NULL, 
                   NULL, 
                   6, --TechnicalHub
                   3, --DataQuality
                   @v_ActivityStatus_VE, --Information
                   @@SERVERNAME, 
                   'TechnicalHub', 
                   A.CalculationTree, 
                   NULL, 
                   @v_ActivityName_VE, 
                   GETDATE(), 
                   a.RowsLoaded
            FROM
            (
                      
             SELECT ICL.CalculationTree, COUNT(*) AS RowsLoaded FROM TechnicalHub.stg.IFRSCubeLanding ICL
JOIN	dbo.CubeExportFormats		 ICS
	ON ICS.FullTree = ICL.CalculationTree
JOIN
		(
			SELECT
					TR.CalcTree
				  , TR.FromCube
				  , TR.DateStamp
			FROM	dbo.TestResult								   TR
			JOIN (	 SELECT MAX(DateStamp) DS FROM dbo.TestResult) DST
				ON TR.DateStamp = DST.DS
		)								 Recs
	ON Recs.CalcTree = ICL.CalculationTree
WHERE
		ICL.CalculationResult IS NOT NULL
		GROUP BY ICL.CalculationTree
            ) a;