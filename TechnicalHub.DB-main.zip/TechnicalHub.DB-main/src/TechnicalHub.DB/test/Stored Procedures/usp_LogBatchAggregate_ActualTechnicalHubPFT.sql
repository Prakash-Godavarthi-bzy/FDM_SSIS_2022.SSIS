﻿CREATE PROC [test].[usp_LogBatchAggregate_ActualTechnicalHubPFT] 
       @BatchID AS BATCHID READONLY,
       @InvalidEntitiesValue Numeric(19,4)=NULL

AS

	DECLARE @BATCH_Id int = (SELECT PK_BATCHid FROM @BatchID WHERE Dataset = 'PFT')
     
	 
	 DECLARE
     @v_ActivityStatus_VE SMALLINT= 5, --1 started 2 succeded 3 stopped 4 errored 5 information 
     @v_ActivityName_VE VARCHAR(100)= 'PFTTechnicalHubActual.testAggregate_ValidEntityValues',
	 @v_JobID INT= @BATCH_Id , 
	 @v_ActivityMessage_VE NVARCHAR(4000)=
     (
       SELECT SUM(CAST([Value] AS NUMERIC(19, 4))) AS activitymessage
                FROM stg.fct_TechnicalResult O
                     INNER JOIN @BatchID B ON CAST(o.AuditSourceBatchID AS INT) = B.PK_BatchID
					 INNER JOIN TechnicalHub.dim.Dataset DS ON DS.PK_DATASET=O.FK_DataSet
                WHERE DS.BK_DataSet = B.Dataset
                           AND DS.BK_DataSet = 'PFT'
                GROUP BY o.[AuditSourceBatchID]
     );


/*
		=========================================================================================================
						Log PFT Valid Entities value in Stage Fact for testing datacontract value
		=========================================================================================================
*/

     EXEC [dbo].[usp_LogTechnicalHUB] 
          @v_ActivityMessage_VE, 
          @v_ActivityStatus_VE, 
          @v_ActivityName_VE, 
          NULL, 
          @v_JobID;
/*
		=========================================================================================================
						Log PFT Invalid Entities value in Stage Fact for testing datacontract value
		=========================================================================================================
*/

     EXEC [dbo].[usp_LogTechnicalHUB] 
          @InvalidEntitiesValue, 
          5, 
          'PFTTechnicalHubActual.testAggregate_InValidEntityValues', 
          NULL, 
          @BATCH_Id;		
     --     /*
     --        =========================================================================================================
     --                                         Set logging parameters for inbound value test
     --       =========================================================================================================
     --*/

     INSERT INTO [Orchestram].[Log].[ActivityLog]
     (FK_ParentActivityLog, 
      FK_ActivityLogTag, 
      FK_ActivitySource, 
      FK_ActivityType, 
      FK_ActivityStatus, 
      ActivityHost, 
      ActivityDatabase, 
      ActivityJobId, 
      ActivitySSISExecutionId, 
      ActivityName, 
      ActivityDateTime, 
      ActivityMessage
     )
            SELECT NULL, 
                   NULL, 
                   6, --TechnicalHub
                   3, --DataQuality
                   5, --Information
                   @@SERVERNAME, 
                   'TechnicalHub', 
                   A.BatchID, 
                   NULL, 
                   'PFTTechnicalHubActual.test.usp_LogBatchAggregate', 
                   GETDATE(), 
                   a.activitymessage + ISNULL(@InvalidEntitiesValue,0)
            FROM
            (
                SELECT SUM(CAST([Value] AS NUMERIC(19, 4))) AS activitymessage, 
                       o.[AuditSourceBatchID] AS BatchID
                FROM stg.fct_TechnicalResult O
                     INNER JOIN @BatchID B ON CAST(o.AuditSourceBatchID AS INT) = B.PK_BatchID
					 INNER JOIN TechnicalHub.Dim.DataSet DS ON DS.PK_DataSet=o.FK_DataSet
                WHERE DS.BK_DataSet = B.Dataset
                           AND DS.BK_DataSet = 'PFT'
                GROUP BY o.[AuditSourceBatchID]
            ) a;

/*
       =========================================================================================================
                                         IF ActulFactTechnicalResult is not equal to ExpecteFactTechnicalResult raise error
                                         
                                         
       =========================================================================================================
       */

    --IF EXISTS
    -- (
    --     SELECT E.ActivityMessage, 
    --            A.ActivityMessage
    --     FROM Orchestram.[Log].ActivityLog E
    --          JOIN @BatchID B ON E.ActivityJobId = CAST(B.PK_BatchID AS VARCHAR(50))
    --          JOIN Orchestram.[Log].ActivityLog A ON E.ActivityJobId = A.ActivityJobId
    --     WHERE E.ActivityName = 'PFTTechnicalHubExpected.test.usp_LogBatchAggregate'
    --           AND A.ActivityName = 'PFTTechnicalHubActual.test.usp_LogBatchAggregate'
    --           AND ROUND(E.ActivityMessage,00)  <> ROUND(A.ActivityMessage,00)
    -- )
    --     BEGIN
    --         RAISERROR('PFTActualFactTechnicalResult value is not matching to  PFTExpectedFactTechnicalResult value', 16, 1);
    -- END;
