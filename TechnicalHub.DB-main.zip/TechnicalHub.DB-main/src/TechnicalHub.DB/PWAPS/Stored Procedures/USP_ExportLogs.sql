﻿-- =============================================
-- Author:		Hemomsu Lakkaraju
-- Create date: 10th May 2021
-- Description:	This woud update the Updateflag in export template for ready to download
-- =============================================
CREATE PROCEDURE PWAPS.USP_ExportLogs
	-- Add the parameters for the stored procedure here
	@FileName Varchar(500)
AS
BEGIN

	Update PWAPS.ExportLogs
	set		UpdateFlag = 5
	where	[FileName] = @FileName

  
END