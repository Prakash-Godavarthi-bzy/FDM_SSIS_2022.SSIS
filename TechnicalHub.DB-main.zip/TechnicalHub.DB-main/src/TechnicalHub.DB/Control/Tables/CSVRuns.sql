﻿CREATE TABLE [Control].[CSVRuns] (
    [PK_BatchRun]  INT          IDENTITY (1, 1) NOT NULL,
    [FK_DataSet]   VARCHAR (10) NOT NULL,
    [BatchRunTS]   VARCHAR (20) NOT NULL,
    [IsPublished]  BIT          DEFAULT ((0)) NOT NULL,
    [AuthorisedBy] VARCHAR (50) NULL
);

