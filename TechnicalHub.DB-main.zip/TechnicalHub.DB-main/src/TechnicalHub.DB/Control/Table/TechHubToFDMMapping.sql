﻿CREATE TABLE [Control].[TechhubToFDMmapping] (
    [pk_ID]                  INT                                         IDENTITY (1, 1) NOT NULL,
    [TechHUb_FK_Process]     VARCHAR (6)                                 NULL,
    [TechHUb_FK_Scenario]    VARCHAR (10)                                NULL,
    [TechHUb_FK_Account]     NVARCHAR (13)                               NULL,
    [TechHub_Period_Modulus] INT                                         NOT NULL,
    [FDM_FK_Process]         VARCHAR (6)                                 NULL,
    [FDM_FK_Account]         INT                                         NULL,
    [FDM_Period_Modifier]    INT                                         NOT NULL,
    [Multiplier]             SMALLINT                                    NOT NULL,
    [ValidFrom]              DATETIME2 (7) GENERATED ALWAYS AS ROW START NOT NULL,
    [ValidTo]                DATETIME2 (7) GENERATED ALWAYS AS ROW END   NOT NULL,
    CONSTRAINT [pk_ID] PRIMARY KEY CLUSTERED ([pk_ID] ASC),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
);

