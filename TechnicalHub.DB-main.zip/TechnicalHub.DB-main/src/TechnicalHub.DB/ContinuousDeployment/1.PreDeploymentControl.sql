﻿/*
This will be executed during the pre-deployment phase.
Use it to apply scripts for all actions that cannot be easily and 
consistently done using just the database project.

Note that the pre-deployment scripts are just prepended to the
generated script.

!!!Make sure your scripts are idempotent(repeatable)!!!

Example invocation:
EXEC sp_execute_script @sql = 'UPDATE Table....', @author = 'Your Name'
*/

--=================================================================================================
--Change Version	: 1.0 
--Sprint			: BR1 Q3 24 committed
--Author			: lakshman.akasapu@beazley.com
--Modify Date	    : 2024-08-06 
--Description		: https://beazley.atlassian.net/browse/I1B-5328
--					  Drop tables and procedures scripts has written here
--=================================================================================================


DECLARE @Trancount INT = @@Trancount

BEGIN TRY;
	
	IF @Trancount = 0 BEGIN TRAN;

/*
IF EXISTS (SELECT * FROM sys.tables where name = 'TechhubToFDMmapping' AND schema_id = SCHEMA_ID('control'))
	TRUNCATE TABLE control.TechhubToFDMmapping


IF EXISTS (SELECT * FROM sys.tables where name = 'FDMPostings' AND schema_id = SCHEMA_ID('Control'))
	ALTER TABLE TechnicalHub.Control.FDMPostings
	ALTER COLUMN  Batch INT

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE	TABLE_SCHEMA = 'FCT' AND TABLE_NAME = 'TechnicalResult' AND CONSTRAINT_NAME = 'FK_TechnicalResult_TriFocus')
	BEGIN
			ALTER TABLE [fct].[TechnicalResult]  WITH CHECK ADD  CONSTRAINT [FK_TechnicalResult_TriFocus] FOREIGN KEY([FK_Trifocus])
			REFERENCES [dim].[TriFocus] ([PK_TriFocus])


			--ALTER TABLE [fct].[TechnicalResult] CHECK CONSTRAINT [FK_TechnicalResult_TriFocus]
	END 

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE	TABLE_SCHEMA = 'FCT' AND TABLE_NAME = 'pattern' AND CONSTRAINT_NAME = 'FK_Pattern_TriFocus')
	BEGIN
			ALTER TABLE [fct].[Pattern]  WITH CHECK ADD  CONSTRAINT [FK_Pattern_TriFocus] FOREIGN KEY([FK_Trifocus])
			REFERENCES [dim].[TriFocus] ([PK_TriFocus])


			--ALTER TABLE [fct].[Pattern] CHECK CONSTRAINT [FK_Pattern_TriFocus]
	END 
	
IF EXISTS (SELECT * FROM sys.tables where name = 'Trifocus' AND schema_id = SCHEMA_ID('DIM'))
BEGIN

ALTER TABLE [fct].[TechnicalResult] DROP CONSTRAINT [FK_TechnicalResult_TriFocus]

ALTER TABLE [fct].[Pattern] DROP CONSTRAINT [FK_Pattern_TriFocus]

	IF EXISTS( SELECT * FROM sys.all_columns WHERE NAME='BK_TriFocus'

				)
			
			BEGIN

			DELETE		
			FROM		DIM.TriFocus	
			WHERE		[BK_TriFocus] NOT IN (	
									SELECT	BK_TriFocus FROM	stg.dim_TriFocus
									UNION	
									SELECT	[BK_TriFocus]	FROM	DIM.TriFocus
									WHERE	TriFocusName = 'Unknown from IFRS17 load'
									UNION
									SELECT	[BK_TriFocus]	FROM	DIM.TriFocus
									WHERE	TriFocusName = 'N/A')
			END
			


ALTER TABLE [fct].[TechnicalResult]  WITH CHECK ADD  CONSTRAINT [FK_TechnicalResult_TriFocus] FOREIGN KEY([FK_Trifocus])
REFERENCES [dim].[TriFocus] ([PK_TriFocus])


ALTER TABLE [fct].[TechnicalResult] CHECK CONSTRAINT [FK_TechnicalResult_TriFocus]

ALTER TABLE [fct].[Pattern]  WITH CHECK ADD  CONSTRAINT [FK_Pattern_TriFocus] FOREIGN KEY([FK_Trifocus])
REFERENCES [dim].[TriFocus] ([PK_TriFocus])

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE	TABLE_SCHEMA = 'FCT' AND TABLE_NAME = 'TechnicalResult' AND CONSTRAINT_NAME = 'FK_TechnicalResult_Allocation')
	BEGIN
			ALTER TABLE [fct].[TechnicalResult] DROP CONSTRAINT [FK_TechnicalResult_Allocation]
	END 

END 

*/
/*
IF  EXISTS	(	SELECT *
					FROM INFORMATION_SCHEMA.COLUMNS 
					WHERE  TABLE_CATALOG='TechnicalHub' AND TABLE_SCHEMA='dim' AND TABLE_NAME='Account' AND COLUMN_NAME='RIFLAG' AND DATA_TYPE<>'VARCHAR'
				)
BEGIN
ALTER TABLE TechnicalHub.dim.Account SET (SYSTEM_VERSIONING=OFF);

	ALTER TABLE TechnicalHub.dim.Account ALTER COLUMN RIFLAG VARCHAR(2) NULL
	ALTER TABLE TechnicalHub.dim.Account_History ALTER COLUMN RIFLAG VARCHAR(2) NULL

	ALTER TABLE TechnicalHub.dim.Account  SET (SYSTEM_VERSIONING=ON (HISTORY_TABLE = dim.Account_History));

ALTER TABLE TechnicalHub.stg.dim_Account ALTER COLUMN RIFLAG VARCHAR(2) NULL
END

----------TECHNICAL CLEAN UP--------------------
IF  EXISTS	(	SELECT *
FROM INFORMATION_SCHEMA.TABLES 
WHERE  TABLE_CATALOG='TechnicalHub' AND TABLE_SCHEMA='Control' AND TABLE_NAME IN ('CSV_CalcTree','CSV_Entity','CSV_InceptionYear','CSV_TrifocusCode','CSV_YOA','CSVRuns','IFRS17TransformationExtractsLog','OB_CalcTree','OB_EarningQuarter','OB_InceptionYear','OB_TrifocusCode','OB_YOA','OpeningBalancesExtractLog'
)
) 
BEGIN
DROP TABLE IF EXISTS Control.CSV_CalcTree
DROP TABLE IF EXISTS Control.CSV_Entity
DROP TABLE IF EXISTS Control.CSV_InceptionYear
DROP TABLE IF EXISTS Control.CSV_TrifocusCode
DROP TABLE IF EXISTS Control.CSV_YOA
DROP TABLE IF EXISTS Control.CSVRuns
DROP TABLE IF EXISTS Control.IFRS17TransformationExtractsLog
DROP TABLE IF EXISTS Control.OB_CalcTree
DROP TABLE IF EXISTS Control.OB_EarningQuarter
DROP TABLE IF EXISTS Control.OB_InceptionYear
DROP TABLE IF EXISTS Control.OB_TrifocusCode
DROP TABLE IF EXISTS Control.OB_YOA
DROP TABLE IF EXISTS Control.OpeningBalancesExtractLog
--13 Tables
END
-------------------------------------------------------------------
IF  EXISTS	(	SELECT *
FROM INFORMATION_SCHEMA.TABLES 
WHERE  TABLE_CATALOG='TechnicalHub' AND TABLE_SCHEMA='dbo' AND TABLE_NAME IN ('BR2_PersistedData','CubeExportFormats
','Fct_WB_LossRatio','WB_AssumptionSetPercent','WB_BriGeneralPercent','WB_Discount Rates','WB_Earning Pattern','WB_FX Rate V2','WB_GeneralPercent','WB_Payment Patterns','WriteTable_Percent Source','WriteTable_Risk AdjustmentProtoDG'))
BEGIN

DROP TABLE IF EXISTS dbo.BR2_PersistedData
DROP TABLE IF EXISTS dbo.CubeExportFormats
DROP TABLE IF EXISTS dbo.Fct_WB_LossRatio
DROP TABLE IF EXISTS dbo.WB_AssumptionSetPercent
DROP TABLE IF EXISTS dbo.WB_BriGeneralPercent
DROP TABLE IF EXISTS dbo.[WB_Discount Rates]
DROP TABLE IF EXISTS dbo.[WB_Earning Pattern]
DROP TABLE IF EXISTS dbo.[WB_FX Rate V2]
DROP TABLE IF EXISTS dbo.[WB_GeneralPercent]
DROP TABLE IF EXISTS dbo.[WB_Payment Patterns]
DROP TABLE IF EXISTS dbo.[WriteTable_Percent Source]
DROP TABLE IF EXISTS dbo.[WriteTable_Risk AdjustmentProtoDG]

--12 Tables
END
---------------------------------------------------------
IF  EXISTS	(	SELECT *
FROM INFORMATION_SCHEMA.TABLES 
WHERE  TABLE_CATALOG='TechnicalHub' AND TABLE_SCHEMA='dim' AND TABLE_NAME IN('AssumptionDatasets','AssumptionDatasets_History','AssumptionPercentageSubType','AssumptionPercentageSubType_History','AssumptionPercentageType','AssumptionPercentageType_History','CalculationTree','CalculationTree_History','OBCalTree_History','OBCalTreeNode'))
BEGIN

	IF EXISTS(SELECT * FROM sys.tables WHERE name in('AssumptionDatasets') AND temporal_type=2)
	BEGIN
	ALTER TABLE [dim].[AssumptionDatasets] SET ( SYSTEM_VERSIONING = OFF  )
	DROP TABLE  dim.AssumptionDatasets
	DROP TABLE  dim.AssumptionDatasets_History
	END
	-------------------- 1
	IF EXISTS(SELECT * FROM sys.tables WHERE name in('AssumptionPercentageSubType') AND temporal_type=2)
	BEGIN
	ALTER TABLE [dim].[AssumptionPercentageSubType] SET ( SYSTEM_VERSIONING = OFF  )
	DROP TABLE IF EXISTS dim.AssumptionPercentageSubType
	DROP TABLE IF EXISTS dim.AssumptionPercentageSubType_History
	END
	-------------------- 2
	IF EXISTS(SELECT * FROM sys.tables WHERE name in('AssumptionPercentageType') AND temporal_type=2)
	BEGIN
	ALTER TABLE [dim].[AssumptionPercentageType] SET ( SYSTEM_VERSIONING = OFF  )
	DROP TABLE IF EXISTS dim.AssumptionPercentageType
	DROP TABLE IF EXISTS dim.AssumptionPercentageType_History
	END
	-------------------- 3
	IF EXISTS(SELECT * FROM sys.tables WHERE name in('CalculationTree') AND temporal_type=2)
	BEGIN
	ALTER TABLE [dim].[CalculationTree] SET ( SYSTEM_VERSIONING = OFF  )
	DROP TABLE IF EXISTS dim.CalculationTree
	DROP TABLE IF EXISTS dim.CalculationTree_History
	END
	-------------------- 4
	IF EXISTS(SELECT * FROM sys.tables WHERE name in ('OBCalTreeNode') AND temporal_type=2)
	BEGIN
	ALTER TABLE [dim].[OBCalTreeNode] SET ( SYSTEM_VERSIONING = OFF  )
	DROP TABLE IF EXISTS dim.OBCalTree_History
	DROP TABLE IF EXISTS dim.OBCalTreeNode
	END
END
----------------------------------------------------------------------------------
IF  EXISTS	(	SELECT *
FROM INFORMATION_SCHEMA.TABLES 
WHERE  TABLE_CATALOG='TechnicalHub' AND TABLE_SCHEMA='fct' AND TABLE_NAME IN ('ADMULRPercentages',
'All_WB_Committed','IntermediaryAssumptionPercentages',
'IntermediaryDiscountRate',
'IntermediaryFXRate',
'IntermediaryPaymentPattern','OpeningBalances','TechnicalResult2017andPrior',
'TechnicalResult2018',
'TechnicalResult2019'


)
)

BEGIN
DROP TABLE IF EXISTS fct.ADMULRPercentages
DROP TABLE IF EXISTS fct.All_WB_Committed
DROP TABLE IF EXISTS fct.IntermediaryAssumptionPercentages
DROP TABLE IF EXISTS fct.IntermediaryDiscountRate
DROP TABLE IF EXISTS fct.IntermediaryFXRate
DROP TABLE IF EXISTS fct.IntermediaryPaymentPattern
DROP TABLE IF EXISTS fct.OpeningBalances
DROP TABLE IF EXISTS fct.TechnicalResult2017andPrior
DROP TABLE IF EXISTS fct.TechnicalResult2018
DROP TABLE IF EXISTS fct.TechnicalResult2019
--10 tables
END

---------------------------------------------------------------------------------------
IF  EXISTS	(	SELECT *
FROM INFORMATION_SCHEMA.TABLES 
WHERE  TABLE_CATALOG='TechnicalHub' AND TABLE_SCHEMA='PWAPS' AND TABLE_NAME IN ('DownloadTemplate',
'ExportLogs',
'stg_Adjustments',
'stg_ADMULRUPE',
'stg_AssumptionsWithLossTypeTemplate',
'stg_AssumptionsWithOutLossTypeTemplate',
'stg_DiscountRatesTemplate',
'stg_FxRateTemplate',
'stg_PaymentPatternTemplate',
'stg_TrifocusMappingTemplate',
'vw_AccountingPeriod',
'vw_Adjustments',
'VW_ADMAsAtDate',
'VW_DownloadTemplate',
'Vw_ExportLog',
'vwAdjustments',
'vwAssumptionSetPercent',
'VWAssumptionSets',
'vwDiscountRateSetPercent',
'vwFxRateSetPercent',
'vwPaymentPatternSetPercent',
'vwReportingYear')
)

BEGIN
DROP TABLE IF EXISTS PWAPS.DownloadTemplate
DROP TABLE IF EXISTS PWAPS.ExportLogs
DROP TABLE IF EXISTS PWAPS.stg_Adjustments
DROP TABLE IF EXISTS PWAPS.stg_ADMULRUPE
DROP TABLE IF EXISTS PWAPS.stg_AssumptionsWithLossTypeTemplate
DROP TABLE IF EXISTS PWAPS.stg_AssumptionsWithOutLossTypeTemplate
DROP TABLE IF EXISTS PWAPS.stg_DiscountRatesTemplate
DROP TABLE IF EXISTS PWAPS.stg_FxRateTemplate
DROP TABLE IF EXISTS PWAPS.stg_PaymentPatternTemplate
DROP TABLE IF EXISTS PWAPS.stg_TrifocusMappingTemplate
DROP VIEW IF EXISTS PWAPS.vw_AccountingPeriod
DROP VIEW IF EXISTS PWAPS.vw_Adjustments
DROP VIEW IF EXISTS PWAPS.VW_ADMAsAtDate
DROP VIEW IF EXISTS PWAPS.VW_DownloadTemplate
DROP VIEW IF EXISTS PWAPS.Vw_ExportLog
DROP VIEW IF EXISTS PWAPS.vwAdjustments
DROP VIEW IF EXISTS PWAPS.vwAssumptionSetPercent
DROP VIEW IF EXISTS PWAPS.VWAssumptionSets
DROP VIEW IF EXISTS PWAPS.vwDiscountRateSetPercent
DROP VIEW IF EXISTS PWAPS.vwFxRateSetPercent
DROP VIEW IF EXISTS PWAPS.vwPaymentPatternSetPercent
DROP VIEW IF EXISTS PWAPS.vwReportingYear
--22 tables

END

------------------------------------------
IF  EXISTS	
(SELECT *
FROM INFORMATION_SCHEMA.TABLES 
WHERE  TABLE_CATALOG='TechnicalHub' AND TABLE_SCHEMA='stg' AND TABLE_NAME IN ('briInitialSubsequent',
'CSVOutput','DevQtrs','dim_CalculationTree','fct_OpeningBalances','MappingTotransformationLog
','PowerAppsAuditLog','VW_AssumptionDataSet','vw_AssumptionPercentageTypes','vw_AssumptionPercentageTypes_Check','VW_InputConfig','VW_OBRunId')
)
BEGIN
DROP TABLE IF EXISTS stg.briInitialSubsequent
DROP TABLE IF EXISTS stg.CSVOutput
DROP TABLE IF EXISTS stg.DevQtrs
DROP TABLE IF EXISTS stg.dim_CalculationTree
DROP TABLE IF EXISTS stg.MappingTotransformationLog
DROP TABLE IF EXISTS stg.fct_OpeningBalances
DROP TABLE IF EXISTS stg.PowerAppsAuditLog
DROP VIEW IF EXISTS  stg.VW_AssumptionDataSet
DROP VIEW IF EXISTS  stg.vw_AssumptionPercentageTypes
DROP VIEW IF EXISTS  stg.vw_AssumptionPercentageTypes_Check
DROP VIEW IF EXISTS  stg.VW_InputConfig
DROP VIEW IF EXISTS  stg.VW_OBRunId
--12 tables
END
-----------------------------------
*/

-----------------------------------------------------------------------------------------------------------------------------------

--===========================================================
--Stored Procedures
--===========================================================

IF (OBJECT_ID('[test].[usp_LogBatchAggregate_ImportCalcTrees]', 'P') IS NOT NULL)
BEGIN
  DROP PROCEDURE [test].[usp_LogBatchAggregate_ImportCalcTrees];
END;

IF (OBJECT_ID('[fct].[usp_BackfillInceptionPeriodTR]', 'P') IS NOT NULL)
BEGIN
  DROP PROCEDURE [fct].[usp_BackfillInceptionPeriodTR];
END;

IF (OBJECT_ID('[test].[usp_LogAggregateStg_TechnicalResult_FDM]', 'P') IS NOT NULL)
BEGIN
  DROP PROCEDURE [test].[usp_LogAggregateStg_TechnicalResult_FDM];
END;

IF (OBJECT_ID('[test].[usp_LogBatchAggregate_ActualTechnicalHubUSSYND]', 'P') IS NOT NULL)
BEGIN
  DROP PROCEDURE [test].[usp_LogBatchAggregate_ActualTechnicalHubUSSYND];
END;
--===========================================================
--Tables
--===========================================================

IF EXISts (SELECT * FROM INFORMATION_SCHEMA.TABLES  WHERE TABLE_SCHEMA='Control' AND TABLE_NAME='FDMPostings')
BEGIN
DROP TABLE [Control].[FDMPostings]
END


IF EXISts (SELECT * FROM INFORMATION_SCHEMA.TABLES  WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='ct1_dest_csv_test')
BEGIN
DROP TABLE [dbo].[ct1_dest_csv_test]
END

IF EXISts (SELECT * FROM INFORMATION_SCHEMA.TABLES  WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='ct1_set_test_final')
BEGIN
DROP TABLE [dbo].[ct1_set_test_final]
END

IF EXISts (SELECT * FROM INFORMATION_SCHEMA.TABLES  WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='dg_testpattern')
BEGIN
DROP TABLE [dbo].[dg_testpattern]
END


IF EXISts (SELECT * FROM INFORMATION_SCHEMA.TABLES  WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='TestResult')
BEGIN
DROP TABLE [dbo].[TestResult]
END

IF EXISts (SELECT * FROM INFORMATION_SCHEMA.TABLES  WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tmp_TechnicalResult')
BEGIN
DROP TABLE [dbo].[tmp_TechnicalResult]
END

IF EXISts (SELECT * FROM INFORMATION_SCHEMA.TABLES  WHERE TABLE_SCHEMA='stg' AND TABLE_NAME='fct_Transaction_ClaimLargeLoss')
BEGIN
DROP TABLE [stg].[fct_Transaction_ClaimLargeLoss]
END

IF EXISts (SELECT * FROM INFORMATION_SCHEMA.TABLES  WHERE TABLE_SCHEMA='stg' AND TABLE_NAME='IFRSCubeLanding')
BEGIN
DROP TABLE [stg].[IFRSCubeLanding]
END

IF EXISts (SELECT * FROM INFORMATION_SCHEMA.TABLES  WHERE TABLE_SCHEMA='stg' AND TABLE_NAME='OpeningBalancesEarningExtract')
BEGIN
DROP TABLE [stg].[OpeningBalancesEarningExtract]
END

IF EXISts (SELECT * FROM INFORMATION_SCHEMA.TABLES  WHERE TABLE_SCHEMA='stg' AND TABLE_NAME='OpeningBalancesExtract')
BEGIN
DROP TABLE [stg].[OpeningBalancesExtract]
END

IF EXISts (SELECT * FROM INFORMATION_SCHEMA.TABLES  WHERE TABLE_SCHEMA='stg' AND TABLE_NAME='TechnicalResult_FDM')
BEGIN
DROP TABLE [stg].[TechnicalResult_FDM]
END

-----------------------------------------------------------------------------------------------------------------------------------


IF @Trancount = 0 COMMIT;

END TRY

BEGIN CATCH;

	IF @Trancount = 0 
		ROLLBACK;

	THROW;

END CATCH;

