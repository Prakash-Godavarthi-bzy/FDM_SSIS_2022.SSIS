﻿Truncate table [stg].[dim_Date]

DECLARE @start DATE = '1985-01-01'
;WITH cte AS (
SELECT @start AS date_
UNION ALL
SELECT DATEADD(dd,1 ,date_)
FROM cte
WHERE date_ < cast(dateadd(year,75,DATEADD (dd, -1, DATEADD(yy, DATEDIFF(yy, 0, GETDATE()) +1, 0)))as date)
)
INSERT INTO [stg].[dim_Date]
([BK_Date]
      ,[Date]
      ,[DateName]
      ,[Year]
      ,[Month]
      ,[Day]
      ,[PERIOD]
      ,[MonthName]
      ,[Quarter]
      ,[QuarterName]
      ,[DaysInMonth] )
SELECT CONVERT(CHAR(10),date_,112),
		date_,
		Convert(varchar(10),date_,103),
		Year(date_),
		Month(date_),
		DAY(date_),
		SUBSTRING(convert(char(10),date_,112),1,6),
		DATENAME(mm,date_),
		DATEPART(qq,date_),
		CASE DATEPART(qq,date_)
			WHEN 1 THEN 'First'
			WHEN 2 THEN 'Second'
			WHEN 3 THEN 'Third'
			WHEN 4 THEN 'Fourth'
			END,
		DAY(EOMONTH(date_))
FROM cte OPTION (maxrecursion 0)

INSERT INTO [stg].[dim_Date]
([BK_Date]
      ,[Date]
      ,[DateName]
      ,[Year]
      ,[Month]
      ,[Day]
      ,[PERIOD]
      ,[MonthName]
      ,[Quarter]
      ,[QuarterName]
      ,[DaysInMonth] )
SELECT CONVERT(CHAR(10),'19800101',112),
		'1980-01-01',
		Convert(varchar(10),'01/01/1980',103),
		Year('1980-01-01'),
		Month('1980-01-01'),
		DAY('1980-01-01'),
		SUBSTRING(convert(char(10),'19800101',112),1,6),
		DATENAME(mm,'1980-01-01'),
		DATEPART(qq,'1980-01-01'),
		CASE DATEPART(qq,'1980-01-01')
			WHEN 1 THEN 'First'
			WHEN 2 THEN 'Second'
			WHEN 3 THEN 'Third'
			WHEN 4 THEN 'Fourth'
			END,
		DAY(EOMONTH('1980-01-01'))

		

--		UNION ALL

--SELECT CONVERT(CHAR(10),'99991231',112),
--        '9999-12-31',
--        Convert(varchar(10),'31/12/9999',103),
--        Year('9999-12-31'),
--        Month('9999-12-31'),
--        DAY('9999-12-31'),
--        SUBSTRING(convert(char(10),'99991231',112),1,6),
--        DATENAME(mm,'9999-12-31'),
--        DATEPART(qq,'9999-12-31'),
--        'Fourth'
--            ,
--        DAY(EOMONTH('9999-12-31'))


Exec [dim].[usp_MergeDate]


DECLARE @Cunt INT
SELECT @CUNT=COUNT(*) FROM TechnicalHub.dim.[Date] 
WHERE PK_Date IN (-1)

IF @CUNT=0

BEGIN
SET IDENTITY_INSERT TechnicalHub.dim.[Date] ON
INSERT INTO TechnicalHub.dim.[Date](PK_Date,BK_Date) 
		VALUES
		(-1,99991231)	
SET IDENTITY_INSERT TechnicalHub.dim.[Date] OFF
END
