﻿MERGE INTO [dim].[YOA] AS tgt
USING(VALUES
		 ('1986'),
		 ('1987'),
		 ('1988'),
		 ('1989'),
		 ('1990'),
		 ('1991'),
		 ('1992')

		) as src ([PK_YOA])
ON	  tgt.[BK_YOA] = src.[PK_YOA]
WHEN  NOT MATCHED BY TARGET
THEN INSERT
			([BK_YOA]
			)
	Values
	(
	src.[PK_YOA]
	);

