﻿MERGE INTO  [dim].[RIPolicyType]  AS tgt
USING	(VALUES('UCT','UCT'),
			   ('IR','IR')) as src ([BK_RIPolicyType],[RIPolicyType])
ON	  tgt.[BK_RIPolicyType] = src.[BK_RIPolicyType]
WHEN  NOT MATCHED BY TARGET
THEN INSERT
			([BK_RIPolicyType],
			[RIPolicyType]
			)
	Values
	(
	src.[BK_RIPolicyType],
	src.[RIPolicyType]
	)
 WHEN MATCHED
 AND (
	  src.[RIPolicyType]<> tgt.[RIPolicyType]	
 )
  THEN UPDATE 
  set 
	   tgt.[RIPolicyType] = src.[RIPolicyType];