﻿MERGE [dim].[Process]  AS TGT
USING	(VALUES('IP','Inward Premium','Premium','Gross','Estimate','201905' ),
		('IE','Inward Earning','Premium','Gross','Estimate','201905' ),
		('IA','Inward Adjustment','Premium','Gross','Estimate','201905' ),
		('T1','IFRS17 Data','','','','201905')
		) as Src ([PK_Process],[ProcessName],[ProcessLevel1],[ProcessLevel2],[ProcessLevel3],[CurrentAccountingPeriod])
ON	  TGT.[BK_Process] = Src.[PK_Process]
WHEN  NOT MATCHED BY TARGET
THEN INSERT
			([BK_Process],
    [ProcessName],
    [ProcessLevel1],
    [ProcessLevel2],
    [ProcessLevel3],
	[CurrentAccountingPeriod]
			)
	Values
	(
	[PK_Process],
    [ProcessName],
    [ProcessLevel1],
    [ProcessLevel2],
    [ProcessLevel3],
	[CurrentAccountingPeriod]
	)
 WHEN MATCHED
 AND (
	  src.[ProcessName]<> tgt.[ProcessName] OR
	  src.[ProcessLevel1]<> tgt.[ProcessLevel1] OR
	  src.[ProcessLevel2]<> tgt.[ProcessLevel2] OR
	  src.[ProcessLevel3]<> tgt.[ProcessLevel3] 
 )
  THEN UPDATE 
  set 
	   tgt.[ProcessName] = src.[ProcessName],
	   tgt.[ProcessLevel1] = src.[ProcessLevel1],
	   tgt.[ProcessLevel2] = src.[ProcessLevel2],
	   tgt.[ProcessLevel3] = src.[ProcessLevel3];