﻿MERGE [dim].[Basis]  AS TGT
USING	(VALUES('Booked','Booked'),
		('Estimated','Estimated')) as Src ([PK_Basis],[BasisName])
ON	  TGT.[BK_Basis] = Src.[PK_Basis]
WHEN  NOT MATCHED BY TARGET
THEN INSERT
			([BK_Basis],
			[BasisName]
			)
	Values
	(
	src.[PK_Basis],
	src.[BasisName]
	)
 WHEN MATCHED
 AND (
	  src.[BasisName]<> tgt.[BasisName]	
 )
  THEN UPDATE 
  set 
	   tgt.[BasisName] = src.[BasisName];