﻿MERGE	dim.[DataSet] AS tgt
USING	(
			VALUES	('PFT', 'PFT'), 
					('Eurobase', 'Eurobase'), 
					('USPremium', 'FDM'), 
					('Agresso', 'Agresso'), 
					('ADM', 'ADM'), 
					('EIOPA', 'EIOPA'),
					('LPSO','LPSO'),
					('BI','BI'),
					('Interim_Ceded_Re_Closed_YOA','Interim_Ceded_Re_Closed_YOA'),
					('Interim_USPremium','Interim_USPremium')
		) AS Source([PK_DataSet], SourceSystem) ON (tgt.[BK_DataSet] = Source.PK_DataSet)
WHEN	MATCHED AND(ISNULL(Source.[SourceSystem], '') <> ISNULL(tgt.[SourceSystem], '')) 
THEN	UPDATE 
		SET [SourceSystem] = Source.[SourceSystem]
WHEN	NOT MATCHED BY TARGET 
THEN	INSERT([BK_DataSet], [SourceSystem])
		VALUES(Source.[PK_DataSet], Source.[SourceSystem]);