﻿MERGE [dim].[Entity] AS TGT
USING	(VALUES
		('8033','8033','Unknown Entity from Softelligence','OTHER','','','',''),
		('8022','8022','Unknown Entity from Softelligence','OTHER','','','',''),
		('NOENTITY','NOENTITY','Unknown Entity from Softelligence','OTHER','','','','')
		) as Src ([PK_Entity],[Entity],[EntityName],[Platform],[EntityLevel1],[EntityLevel2],[EntityLevel3],[EntityLevel4])
ON	  TGT.[BK_Entity] = Src.[PK_Entity]
WHEN  NOT MATCHED BY TARGET
THEN INSERT
			([BK_Entity],[Entity],[EntityName],[Platform],[EntityLevel1],[EntityLevel2],[EntityLevel3],[EntityLevel4]
			)
	Values
	(
	src.[PK_Entity],src.[Entity],src.[EntityName],src.[Platform],src.[EntityLevel1],src.[EntityLevel2],src.[EntityLevel3],src.[EntityLevel4]
	)
 WHEN MATCHED
 AND (
	  src.[Entity]<> tgt.[Entity]	OR
	  src.[EntityName]<> tgt.[EntityName]	OR
	  src.[Platform] <> tgt.[Platform]	OR
	  src.[EntityLevel1]<> tgt.[EntityLevel1]	OR
	  src.[EntityLevel2]<> tgt.[EntityLevel2]	OR
	  src.[EntityLevel3]<> tgt.[EntityLevel3]	OR
	  src.[EntityLevel4]<> tgt.[EntityLevel4]	 
 )
 AND tgt.EntityName = 'Unknown Entity from Softelligence'
  THEN UPDATE 
  set  
		
		tgt.[Entity] = src.[Entity],
		tgt.[EntityName] = src.[EntityName],
		tgt.[Platform] = src.[Platform],
		tgt.[EntityLevel1] = src.[EntityLevel1]	,
		tgt.[EntityLevel2] = src.[EntityLevel2]	,
		tgt.[EntityLevel3] = src.[EntityLevel3]	,
		tgt.[EntityLevel4] = src.[EntityLevel4]	 
	   ;

  