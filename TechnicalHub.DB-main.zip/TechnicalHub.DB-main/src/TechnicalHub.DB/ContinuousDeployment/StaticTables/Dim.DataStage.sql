﻿MERGE INTO [dim].[DataStage] AS Target
USING(VALUES(1,'Result'), 
			(2,'Calculate'), 
			(3,'Report')) AS Source([PK_DataStage],[DataStageName])
ON    (Target.[PK_DataStage] = Source.[PK_DataStage])
    WHEN MATCHED
    THEN UPDATE SET 
                    [DataStageName] = Source.[DataStageName]
					
    WHEN NOT MATCHED BY TARGET
    THEN
      INSERT([PK_DataStage],[DataStageName])
      VALUES(Source.[PK_DataStage],  Source.[DataStageName]);