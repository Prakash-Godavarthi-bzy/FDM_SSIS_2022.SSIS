﻿MERGE INTO dim.[Account] AS tgt
USING
		(VALUES
					 ('P-AA-B',NULL,'Premium','Earning Adj Acquisition Costs','Binder'),
                     ('P-AC-B',NULL,'Premium','Acquisition Costs','Binder'),
                     ('P-AC-P',NULL,'Premium','Acquisition Costs','Policy'),
                     ('P-AP-B',NULL,'Premium','Earning Adj Premium','Binder'),
                     ('P-BA-B',NULL,'Premium','Binder Adjusted Acquisition Cost Earnings','Binder'),
                     ('P-BP-B',NULL,'Premium','Binder Adjusted Premium Earnings','Binder'),
                     ('P-EA-B',NULL,'Premium','Earned Acquisition Costs','Binder'),
                     ('P-EA-P',NULL,'Premium','Earned Acquisition Costs','Policy'),
                     ('P-EP-P',NULL,'Premium','Earned Premium','Policy'),
                     ('P-EP-B',NULL,'Premium','Earned Premium','Binder'),
                     ('P-GP-P',NULL,'Premium','Gross','Policy'), 
                     ('P-GP-B',NULL,'Premium','Gross','Binder'),
					 ('P-LB-P',NULL,'Premium','Lloyd`s Brussels','Policy'), 
                     ('P-LB-B',NULL,'Premium','Lloyd`s Brussels','Binder'),
                     ('P-BL-B',NULL,'Premium','Lloyd`s Brussels Binder Adjustment','Binder'),
                     ('P-IC-P',NULL,'Premium','Internal Commission','Policy'),
					 ('P-RI-P',NULL,'Premium','RE Insurance','Policy'),
					 ('P-RI-B',NULL,'Premium','RE Insurance','Binder')
					 ,('BB-NI-A',NULL,'Premium Acquisition Costs','Policy',NULL)
					, ('BB-NI-P',NULL,'BBNI Premium Gross','Policy',NULL)
					,('BK-CL-B','','','','From Softelligence')
					,('BK-CL-N','','','','From Softelligence')
					,('BK-CR-B','','','','From Softelligence')
					,('BK-CR-N','','','','From Softelligence')
					,('BK-DD-B','','','','From Softelligence')
					,('BK-DD-N','','','','From Softelligence')
					,('BK-DM-B','','','','From Softelligence')
					,('BK-DM-N','','','','From Softelligence')
					,('BK-DR-B','','','','From Softelligence')
					,('BK-DR-N','','','','From Softelligence')
					,('BK-PI-B','','','','From Softelligence')
					,('BK-PI-N','','','','From Softelligence')
					,('BK-PM-B','','','','From Softelligence')
					,('BK-PM-N','','','','From Softelligence')
					,('BK-RP-B','','','','From Softelligence')
					,('BK-RP-N','','','','From Softelligence')
					,('BK-TY-B','','','','From Softelligence')
					,('BK-TY-N','','','','From Softelligence')
					,('BK-X','','','','From Softelligence')
					,('GC-CP-CL-B','','','','From Softelligence')
					,('GC-CP-CL-N','','','','From Softelligence')
					,('GC-CP-TY-B','','','','From Softelligence')
					,('GC-CP-TY-N','','','','From Softelligence')
					,('GC-D-I','','','','From Softelligence')
					,('GC-D-P','','','','From Softelligence')
					,('GC-F-I','','','','From Softelligence')
					,('GC-F-P','','','','From Softelligence')
					,('GC-I-I','','','','From Softelligence')
					,('GC-I-P','','','','From Softelligence')
					,('GP-PR-DD-B','','','','From Softelligence')
					,('GP-PR-DD-N','','','','From Softelligence')
					,('GP-PR-DM-B','','','','From Softelligence')
					,('GP-PR-DM-N','','','','From Softelligence')
					,('GP-PR-PM-B','','','','From Softelligence')
					,('GP-PR-PM-N','','','','From Softelligence')
					,('GP-PR-RP-B','','','','From Softelligence')
					,('GP-PR-RP-N','','','','From Softelligence')
					,('GP-PR-TY-B','','','','From Softelligence')
					,('GP-PR-TY-N','','','','From Softelligence')
					,('RC-CP-CR-B','','','','From Softelligence')
					,('RC-CP-CR-N','','','','From Softelligence')
					,('RP-PR-DR-B','','','','From Softelligence')
					,('RP-PR-DR-N','','','','From Softelligence')
					,('RP-PR-PI-B','','','','From Softelligence')
					,('RP-PR-PI-N','','','','From Softelligence')
					,('GPE-RP-P','Gross Premium EPI - Reinstatement Premium - Policy',NULL,NULL,NULL)
					,('GPE-RP-B','Gross Premium EPI - Reinstatement Premium - Binder',NULL,NULL,NULL)
					,('RP-PR-RR-B','','','','From Softelligence')
					/*,('TPC-G-AC','','','','From Softelligence')
					,('TPC-G-CL','','','','From Softelligence')
					,('TPC-G-EN','','','','From Softelligence')
					,('GC-P-AC','','','','From Softelligence')
					,('GC-P-CM','','','','From Softelligence')
					,('GC-T-AC','','','','From Softelligence')
					,('GC-T-CM','','','','From Softelligence')
					,('GP-P-PR','','','','From Softelligence')
					,('TPC-G-EU','','','','From Softelligence')
					,('TPC-G-EX','','','','From Softelligence')
					,('TPC-G-LL','','','','From Softelligence')
					,('TPC-G-PR','','','','From Softelligence')
					,('TPI-G-AC','','','','From Softelligence')
					,('TPI-G-CL','','','','From Softelligence')
					,('TPI-G-CM','','','','From Softelligence')
					,('TPI-G-EN','','','','From Softelligence')
					,('TPI-G-EU','','','','From Softelligence')
					,('TPI-G-EX','','','','From Softelligence')
					,('TPI-G-PR','','','','From Softelligence')
					,('TPU-G-AC','','','','From Softelligence')
					,('TPU-G-CL','','','','From Softelligence')
					,('TPU-G-CM','','','','From Softelligence')
					,('TPU-G-EN','','','','From Softelligence')
					,('TPU-G-EU','','','','From Softelligence')
					,('TPU-G-EX','','','','From Softelligence')
					,('TPU-G-PR','','','','From Softelligence')*/
					,('C-DI-ATT','Claim Defence Incurred Attritional',NULL,NULL,NULL),
					 ('C-DI-LL','Claim Defence Incurred Large Loss',NULL,NULL,NULL),
					 ('C-DP-ATT','Claim Defence Paid Attritional',NULL,NULL,NULL),
					 ('C-DP-LL','Claim Defence Paid Large Loss',NULL,NULL,NULL),
					 ('C-FI-ATT','Claim Fees Incurred Attritional',NULL,NULL,NULL),
					 ('C-FI-LL','Claim Fees Incurred Large Loss',NULL,NULL,NULL),
					 ('C-FP-ATT','Claim Fees Paid Attritional',NULL,NULL,NULL),
					 ('C-FP-LL','Claim Fees Paid Large Loss',NULL,NULL,NULL),
					 ('C-II-ATT','Claim Indemnity Incurred Attritional',NULL,NULL,NULL),
					 ('C-II-LL','Claim Indemnity Incurred Large Loss',NULL,NULL,NULL),
					 ('C-IP-ATT','Claim Indemnity Paid Attritional',NULL,NULL,NULL),
					 ('C-IP-LL','Claim Indemnity Paid Large Loss',NULL,NULL,NULL),
					 ('BC-LS-OT','Brokerage Cash - Lloyds Settled - Other',NULL,NULL,NULL),
					 ('BC-LS-PC','Brokerage Cash - Lloyds Settled - Profit Commission',NULL,NULL,NULL),
					 ('BC-LS-RT','Brokerage Cash - Lloyds Settled - Reinstatement',NULL,NULL,NULL),
					 ('BC-OS-OT','Brokerage Cash - Other Settled - Other',NULL,NULL,NULL),
					 ('BC-SD-OT','Brokerage Cash - Settled Direct  -Other',NULL,NULL,NULL),
					 ('BC-SD-PC','Brokerage Cash - Settled Direct  - Profit Commission',NULL,NULL,NULL),
					 ('BC-SD-RT','Brokerage Cash - Settled Direct - Reinstatement',NULL,NULL,NULL),
					 ('CC-LS-CLM','Claim Cash - Lloyds Settled - Claim',NULL,NULL,NULL),
					 ('CC-LS-TTY','Claim Cash - Lloyds Settled - Proportional Treaty Statement',NULL,NULL,NULL),
					 ('CC-SD-CLM','Claim Cash - Settled Direct - Claim',NULL,NULL,NULL),
					 ('CC-SD-TTY','Claim Cash - Settled Direct - Proportional Treaty Statement',NULL,NULL,NULL),
					 ('PC-LS-OT','Premium Cash Gross of Brokerage - Lloyds Settled - Other',NULL,NULL,NULL),
					 ('PC-LS-PC','Premium Cash Gross of Brokerage - Lloyds Settled - Profit Commission',NULL,NULL,NULL),
					 ('PC-LS-RT','Premium Cash Gross of Brokerage - Lloyds Settled - Reinstatement',NULL,NULL,NULL),
					 ('PC-OS-OT','Premium Cash Gross of Brokerage -Other Settled- Other',NULL,NULL,NULL),
					 ('PC-SD-OT','Premium Cash Gross of Brokerage - Settled Direct  - Other',NULL,NULL,NULL),
					 ('PC-SD-PC','Premium Cash Gross of Brokerage - Settled Direct  - Profit Commission',NULL,NULL,NULL),
					 ('PC-SD-RT','Premium Cash Gross of Brokerage - Settled Direct - Reinstatement',NULL,NULL,NULL),
					 ('TPC-G-AC','TP Claims Provision Gross Acquisition Costs',NULL,NULL,NULL),
					 ('TPC-N-AC','TP Claims Provision Net Acquisition Costs',NULL,NULL,NULL),
					 ('TPC-G-CL','TP Claims Provision Gross Att Claims',NULL,NULL,NULL),
					 ('TPC-N-CL','TP Claims Provision Net Att Claims',NULL,NULL,NULL),
					 ('TPC-G-BD','TP Claims Provision Gross Bad Debt',NULL,NULL,NULL),
					 ('TPC-N-BD','TP Claims Provision Net Bad Debt',NULL,NULL,NULL),
					 ('TPC-G-EN','TP Claims Provision Gross ENIDs ',NULL,NULL,NULL),
					 ('TPC-N-EN','TP Claims Provision Net ENIDs ',NULL,NULL,NULL),
					 ('TPC-G-EX','TP Claims Provision Gross Expenses non ULAE ',NULL,NULL,NULL),
					 ('TPC-N-EX','TP Claims Provision Net Expenses non ULAE ',NULL,NULL,NULL),
					 ('TPC-G-EU','TP Claims Provision Gross Expenses ULAE ',NULL,NULL,NULL),
					 ('TPC-N-EU','TP Claims Provision Net Expenses ULAE ',NULL,NULL,NULL),
					 ('TPC-G-LL','TP Claims Provision Gross Large Losses',NULL,NULL,NULL),
					 ('TPC-N-LL','TP Claims Provision Net Large Losses ',NULL,NULL,NULL),
					 ('TPC-G-PR','TP Claims Provision Gross Premium ',NULL,NULL,NULL),
					 ('TPC-N-PR','TP Claims Provision Net Premium ',NULL,NULL,NULL),
					 ('TPI-G-AC','TP Premium Provision Incepted Gross Acquisition Costs ',NULL,NULL,NULL),
					 ('TPI-N-AC','TP Premium Provision Incepted Net Acquisition Costs ',NULL,NULL,NULL),
					 ('TPI-G-CL','TP Premium Provision Incepted Gross Att Claims ',NULL,NULL,NULL),
					 ('TPI-N-CL','TP Premium Provision Incepted Net Att Claims ',NULL,NULL,NULL),
					 ('TPI-G-BD','TP Premium Provision Incepted Gross Bad Debt ',NULL,NULL,NULL),
					 ('TPI-N-BD','TP Premium Provision Incepted Net Bad Debt ',NULL,NULL,NULL),
					 ('TPI-G-CM','TP Premium Provision Incepted Gross Cat Margin',NULL,NULL,NULL),
					 ('TPI-N-CM','TP Premium Provision Incepted Net Cat Margin ',NULL,NULL,NULL),
					 ('TPI-G-EN','TP Premium Provision Incepted Gross ENIDs ',NULL,NULL,NULL),
					 ('TPI-N-EN','TP Premium Provision Incepted Net ENIDs ',NULL,NULL,NULL),
					 ('TPI-G-EX','TP Premium Provision Incepted Gross Expenses non ULAE ',NULL,NULL,NULL),
					 ('TPI-N-EX','TP Premium Provision Incepted Net Expenses non ULAE',NULL,NULL,NULL),
					 ('TPI-G-EU','TP Premium Provision Incepted Gross Expenses ULAE',NULL,NULL,NULL),
					 ('TPI-N-EU','TP Premium Provision Incepted Net Expenses ULAE ',NULL,NULL,NULL),
					 ('TPI-G-PR','TP Premium Provision Incepted Gross Premium ',NULL,NULL,NULL),
					 ('TPI-N-PR','TP Premium Provision Incepted Net Premium ',NULL,NULL,NULL),
					 ('TPU-G-AC','TP Premium Provision Unincepted Gross Acquisition Costs ',NULL,NULL,NULL),
					 ('TPU-N-AC','TP Premium Provision Unincepted Net Acquisition Costs ',NULL,NULL,NULL),
					 ('TPU-G-CL','TP Premium Provision Unincepted Gross Att Claims ',NULL,NULL,NULL),
					 ('TPU-N-CL','TP Premium Provision Unincepted Net Att Claims ',NULL,NULL,NULL),
					 ('TPU-G-BD','TP Premium Provision Unincepted Gross Bad Debt ',NULL,NULL,NULL),
					 ('TPU-N-BD','TP Premium Provision Unincepted Net Bad Debt ',NULL,NULL,NULL),
					 ('TPU-G-CM','TP Premium Provision Unincepted Gross Cat Margin ',NULL,NULL,NULL),
					 ('TPU-N-CM','TP Premium Provision Unincepted Net Cat Margin ',NULL,NULL,NULL),
					 ('TPU-G-EN','TP Premium Provision Unincepted Gross ENIDs',NULL,NULL,NULL),
					 ('TPU-N-EN','TP Premium Provision Unincepted Net ENIDs ',NULL,NULL,NULL),
					 ('TPU-G-EX','TP Premium Provision Unincepted Gross Expenses non ULAE ',NULL,NULL,NULL),
					 ('TPU-N-EX','TP Premium Provision Unincepted Net Expenses non ULAE',NULL,NULL,NULL),
					 ('TPU-G-EU','TP Premium Provision Unincepted Gross Expenses ULAE',NULL,NULL,NULL),
					 ('TPU-N-EU','TP Premium Provision Unincepted Net Expenses ULAE ',NULL,NULL,NULL),
					 ('TPU-G-PR','TP Premium Provision Unincepted Gross Premium ',NULL,NULL,NULL),
					 ('TPU-N-PR','TP Premium Provision Unincepted Net Premium ',NULL,NULL,NULL),
					 ('GC-P-AC','Gross Claims Pure Claims Pure Attritional Claims',NULL,NULL,NULL),
					 ('GC-P-CM','Gross Claims Pure Claims Pure Cat Margin',NULL,NULL,NULL),
					 ('GC-P-LL','Gross Claims Pure Claims Pure Large Losses',NULL,NULL,NULL),
					 ('GC-T-AC','Gross Claims Team Claims Team Attritional Claims',NULL,NULL,NULL),
					 ('GC-T-CM','Gross Claims Team Claims Team Cat Margin',NULL,NULL,NULL),
					 ('GC-T-LL','Gross Claims Team Claims Team Large Losses',NULL,NULL,NULL),
					 ('GP-P-PR','Gross Premium Pure Premium Pure Premium',NULL,NULL,NULL),
					 ('GP-T-PR','Gross Premium Team Premium Team Premium',NULL,NULL,NULL),
-- End of 2020 IFRS17 sprint 6 changes
					('CI-LS-TTY-UN','CI-LS-TTY-UN',NULL,NULL,NULL),
					('CI-LS-FAC-UN','CI-LS-FAC-UN',NULL,NULL,NULL),
					('PC-LS-OR-FAC','PC-LS-OR-FAC',NULL,NULL,NULL),
					('PC-LS-OR-TTY','PC-LS-OR-TTY',NULL,NULL,NULL)
					---New accounts for Interim_Ceded_Re_Closed_YOA 
			) AS Source([PK_Account],[AccountName],[Level1Group],[Level2Group],[Level3Group])
ON    (tgt.[BK_Account] = Source.PK_Account)
   
	 WHEN MATCHED
 AND (
	  ISNULL(Source.[AccountName],'')<> ISNULL(tgt.[AccountName],'') or
	  ISNULL(Source.[Level1Group],'')<> tgt.[Level1Group] or
	  ISNULL(Source.[Level2Group],'')<> tgt.[Level2Group] or
	  ISNULL(Source.[Level3Group],'')<> tgt.[Level3Group]	
	  
 )
    THEN UPDATE SET 
                    [AccountName] = Source.[AccountName], 
                    [Level1Group] = Source.[Level1Group],
					[Level2Group] = Source.[Level2Group],
					[Level3Group] = Source.[Level3Group]
    WHEN NOT MATCHED BY TARGET
    THEN
      INSERT([BK_Account],[AccountName],[Level1Group],[Level2Group],[Level3Group])
      VALUES(Source.[PK_Account],  Source.[AccountName],  Source.[Level1Group],  Source.[Level2Group],  Source.[Level3Group]);

