﻿/*==========================================================================================================
Post Deployment script to Update RIFlag field from Dim.Account table.
Their is no specific rule to generate RIFlag, These are provided by Emily. 
If any Account is Added Emily should provide RI Flag for it and Developer should add it in this script.

Intial Version of script added by EB
============================================================================================================*/
UPDATE A SET A.RIFlag=Script.RIFlag
FROM TechnicalHub.dim.ACCOUNT A
JOIN
(
SELECT 'NA'			BKAccunt,'NotApplicable' AName,'U' RIFlag UNION
SELECT 'Unknown'	BKAccunt,'Unknown' AName,'U' RIFlag UNION
SELECT 'GPE-RP-P'	BKAccunt,'Reinstatement Premium - Gross - Policy' AName,'I' RIFlag UNION
SELECT 'GPE-RP-B'	BKAccunt,'Reinstatement Premium - Gross - Binder' AName,'I' RIFlag UNION
SELECT 'C-DI-ATT'	BKAccunt,'Claim Defence Incurred Attritional' AName,'I' RIFlag UNION
SELECT 'C-DI-LL'	BKAccunt,'Claim Defence Incurred Large Loss' AName,'I' RIFlag UNION
SELECT 'C-DP-ATT'	BKAccunt,'Claim Defence Paid Attritional' AName,'I' RIFlag UNION
SELECT 'C-DP-LL'	BKAccunt,'Claim Defence Paid Large Loss' AName,'I' RIFlag UNION
SELECT 'C-FI-ATT'	BKAccunt,'Claim Fees Incurred Attritional' AName,'I' RIFlag UNION
SELECT 'C-FI-LL'	BKAccunt,'Claim Fees Incurred Large Loss' AName,'I' RIFlag UNION
SELECT 'C-FP-ATT'	BKAccunt,'Claim Fees Paid Attritional' AName,'I' RIFlag UNION
SELECT 'C-FP-LL'	BKAccunt,'Claim Fees Paid Large Loss' AName,'I' RIFlag UNION
SELECT 'C-II-ATT'	BKAccunt,'Claim Indemnity Incurred Attritional' AName,'I' RIFlag UNION
SELECT 'C-II-LL'	BKAccunt,'Claim Indemnity Incurred Large Loss' AName,'I' RIFlag UNION
SELECT 'C-IP-ATT'	BKAccunt,'Claim Indemnity Paid Attritional' AName,'I' RIFlag UNION
SELECT 'C-IP-LL'	BKAccunt,'Claim Indemnity Paid Large Loss' AName,'I' RIFlag UNION
SELECT 'BC-AS-RE'   BKAccunt,'BC-AS-RE' AName,'I' RIFlag UNION
SELECT 'BC-LS-OT'	BKAccunt,'Brokerage Cash - Lloyd`s Settled - Other' AName,'I' RIFlag UNION
SELECT 'BC-LS-PC'	BKAccunt,'Brokerage Cash - Lloyd`s Settled - Profit Commission' AName,'I' RIFlag UNION
SELECT 'BC-LS-RT'	BKAccunt,'Brokerage Cash - Lloyd`s Settled - Reinstatement' AName,'I' RIFlag UNION
SELECT 'BC-OS-OT'	BKAccunt,'Brokerage Cash - Other Settled - Other' AName,'I' RIFlag UNION
SELECT 'BC-SD-OT'	BKAccunt,'Brokerage Cash - Settled Direct - Other' AName,'I' RIFlag UNION
SELECT 'BC-SD-PC'	BKAccunt,'Brokerage Cash - Settled Direct - Profit Commission' AName,'I' RIFlag UNION
SELECT 'BC-SD-RT'	BKAccunt,'Brokerage Cash - Settled Direct - Reinstatement' AName,'I' RIFlag UNION
SELECT 'CC-LS-CLM'  BKAccunt,'Claim Cash - Lloyd`s Settled - Claim' AName,'I' RIFlag UNION
SELECT 'CC-LS-TTY'  BKAccunt,'Claim Cash - Lloyd`s Settled - Proportional Treaty Statement' AName,'I' RIFlag UNION
SELECT 'CC-SD-CLM'  BKAccunt,'Claim Cash - Settled Direct - Claim' AName,'I' RIFlag UNION
SELECT 'CC-SD-TTY'  BKAccunt,'Claim Cash - Settled Direct - Proportional Treaty Statement' AName,'I' RIFlag UNION
SELECT 'PC-LS-OT'	BKAccunt,'Premium Cash Gross of Brokerage - Lloyd`s Settled - Other' AName,'I' RIFlag UNION
SELECT 'PC-LS-PC'  BKAccunt,'Premium Cash Gross of Brokerage - Lloyd`s Settled - Profit Commission' AName,'I' RIFlag UNION
SELECT 'PC-LS-RT'  BKAccunt,'Premium Cash Gross of Brokerage - Lloyd`s Settled - Reinstatement' AName,'I' RIFlag UNION
SELECT 'PC-OS-OT'  BKAccunt,'Premium Cash Gross of Brokerage - Other Settled- Other' AName,'I' RIFlag UNION
SELECT 'PC-SD-OT'  BKAccunt,'Premium Cash Gross of Brokerage - Settled Direct - Other' AName,'I' RIFlag UNION
SELECT 'PC-SD-PC'  BKAccunt,'Premium Cash Gross of Brokerage - Settled Direct - Profit Commission' AName,'I' RIFlag UNION
SELECT 'PC-SD-RT'  BKAccunt,'Premium Cash Gross of Brokerage - Settled Direct - Reinstatement' AName,'I' RIFlag UNION
SELECT 'TPC-G-AC'  BKAccunt,'TP Claims Provision Gross Acquisition Costs' AName,'I' RIFlag UNION
SELECT 'TPC-N-AC'  BKAccunt,'TP Claims Provision Net Acquisition Costs' AName,'U' RIFlag UNION
SELECT 'TPC-G-CL'  BKAccunt,'TP Claims Provision Gross Att Claims' AName,'I' RIFlag UNION
SELECT 'TPC-N-CL'  BKAccunt,'TP Claims Provision Net Att Claims' AName,'U' RIFlag UNION
SELECT 'TPC-G-BD'  BKAccunt,'TP Claims Provision Gross Bad Debt' AName,'I' RIFlag UNION
SELECT 'TPC-N-BD'  BKAccunt,'TP Claims Provision Net Bad Debt' AName,'U' RIFlag UNION
SELECT 'TPC-G-EN'  BKAccunt,'TP Claims Provision Gross ENIDs ' AName,'I' RIFlag UNION
SELECT 'TPC-N-EN'  BKAccunt,'TP Claims Provision Net ENIDs ' AName,'U' RIFlag UNION
SELECT 'TPC-G-EX'  BKAccunt,'TP Claims Provision Gross Expenses non ULAE ' AName,'I' RIFlag UNION
SELECT 'TPC-N-EX'  BKAccunt,'TP Claims Provision Net Expenses non ULAE ' AName,'U' RIFlag UNION
SELECT 'TPC-G-EU'  BKAccunt,'TP Claims Provision Gross Expenses ULAE ' AName,'I' RIFlag UNION
SELECT 'TPC-N-EU'  BKAccunt,'TP Claims Provision Net Expenses ULAE ' AName,'U' RIFlag UNION
SELECT 'TPC-G-LL'  BKAccunt,'TP Claims Provision Gross Large Losses' AName,'I' RIFlag UNION
SELECT 'TPC-N-LL'  BKAccunt,'TP Claims Provision Net Large Losses ' AName,'U' RIFlag UNION
SELECT 'TPC-G-PR'  BKAccunt,'TP Claims Provision Gross Premium ' AName,'I' RIFlag UNION
SELECT 'TPC-N-PR'  BKAccunt,'TP Claims Provision Net Premium ' AName,'U' RIFlag UNION
SELECT 'TPI-G-AC'  BKAccunt,'TP Premium Provision Incepted Gross Acquisition Costs ' AName,'I' RIFlag UNION
SELECT 'TPI-N-AC'  BKAccunt,'TP Premium Provision Incepted Net Acquisition Costs ' AName,'U' RIFlag UNION
SELECT 'TPI-G-CL'  BKAccunt,'TP Premium Provision Incepted Gross Att Claims ' AName,'I' RIFlag UNION
SELECT 'TPI-N-CL'  BKAccunt,'TP Premium Provision Incepted Net Att Claims ' AName,'U' RIFlag UNION
SELECT 'TPI-G-BD'  BKAccunt,'TP Premium Provision Incepted Gross Bad Debt ' AName,'I' RIFlag UNION
SELECT 'TPI-N-BD'  BKAccunt,'TP Premium Provision Incepted Net Bad Debt ' AName,'U' RIFlag UNION
SELECT 'TPI-G-CM'  BKAccunt,'TP Premium Provision Incepted Gross Cat Margin' AName,'I' RIFlag UNION
SELECT 'TPI-N-CM'  BKAccunt,'TP Premium Provision Incepted Net Cat Margin ' AName,'U' RIFlag UNION
SELECT 'TPI-G-EN'  BKAccunt,'TP Premium Provision Incepted Gross ENIDs ' AName,'I' RIFlag UNION
SELECT 'TPI-N-EN'  BKAccunt,'TP Premium Provision Incepted Net ENIDs ' AName,'U' RIFlag UNION
SELECT 'TPI-G-EX'  BKAccunt,'TP Premium Provision Incepted Gross Expenses non ULAE ' AName,'I' RIFlag UNION
SELECT 'TPI-N-EX'  BKAccunt,'TP Premium Provision Incepted Net Expenses non ULAE' AName,'U' RIFlag UNION
SELECT 'TPI-G-EU'  BKAccunt,'TP Premium Provision Incepted Gross Expenses ULAE' AName,'I' RIFlag UNION
SELECT 'TPI-N-EU'  BKAccunt,'TP Premium Provision Incepted Net Expenses ULAE ' AName,'U' RIFlag UNION
SELECT 'TPI-G-PR'  BKAccunt,'TP Premium Provision Incepted Gross Premium ' AName,'I' RIFlag UNION
SELECT 'TPI-N-PR'  BKAccunt,'TP Premium Provision Incepted Net Premium ' AName,'U' RIFlag UNION
SELECT 'TPU-G-AC'  BKAccunt,'TP Premium Provision Unincepted Gross Acquisition Costs ' AName,'I' RIFlag UNION
SELECT 'TPU-N-AC'  BKAccunt,'TP Premium Provision Unincepted Net Acquisition Costs ' AName,'U' RIFlag UNION
SELECT 'TPU-G-CL'  BKAccunt,'TP Premium Provision Unincepted Gross Att Claims ' AName,'I' RIFlag UNION
SELECT 'TPU-N-CL'  BKAccunt,'TP Premium Provision Unincepted Net Att Claims ' AName,'U' RIFlag UNION
SELECT 'TPU-G-BD'  BKAccunt,'TP Premium Provision Unincepted Gross Bad Debt ' AName,'I' RIFlag UNION
SELECT 'TPU-N-BD'  BKAccunt,'TP Premium Provision Unincepted Net Bad Debt ' AName,'U' RIFlag UNION
SELECT 'TPU-G-CM'  BKAccunt,'TP Premium Provision Unincepted Gross Cat Margin ' AName,'I' RIFlag UNION
SELECT 'TPU-N-CM'  BKAccunt,'TP Premium Provision Unincepted Net Cat Margin ' AName,'U' RIFlag UNION
SELECT 'TPU-G-EN'  BKAccunt,'TP Premium Provision Unincepted Gross ENIDs' AName,'I' RIFlag UNION
SELECT 'TPU-N-EN'  BKAccunt,'TP Premium Provision Unincepted Net ENIDs ' AName,'U' RIFlag UNION
SELECT 'TPU-G-EX'  BKAccunt,'TP Premium Provision Unincepted Gross Expenses non ULAE ' AName,'I' RIFlag UNION
SELECT 'TPU-N-EX'  BKAccunt,'TP Premium Provision Unincepted Net Expenses non ULAE' AName,'U' RIFlag UNION
SELECT 'TPU-G-EU'  BKAccunt,'TP Premium Provision Unincepted Gross Expenses ULAE' AName,'I' RIFlag UNION
SELECT 'TPU-N-EU'  BKAccunt,'TP Premium Provision Unincepted Net Expenses ULAE ' AName,'U' RIFlag UNION
SELECT 'TPU-G-PR'  BKAccunt,'TP Premium Provision Unincepted Gross Premium ' AName,'I' RIFlag UNION
SELECT 'TPU-N-PR'  BKAccunt,'TP Premium Provision Unincepted Net Premium ' AName,'U' RIFlag UNION
SELECT 'GC-P-AC'	BKAccunt,'Gross Claims Pure Claims Pure Attritional Claims' AName,'I' RIFlag UNION
SELECT 'GC-P-CM'	BKAccunt,'Gross Claims Pure Claims Pure Cat Margin' AName,'I' RIFlag UNION
SELECT 'GC-P-LL'	BKAccunt,'Gross Claims Pure Claims Pure Large Losses' AName,'I' RIFlag UNION
SELECT 'GC-T-AC'	BKAccunt,'Gross Claims Team Claims Team Attritional Claims' AName,'I' RIFlag UNION
SELECT 'GC-T-CM'	BKAccunt,'Gross Claims Team Claims Team Cat Margin' AName,'I' RIFlag UNION
SELECT 'GC-T-LL'	BKAccunt,'Gross Claims Team Claims Team Large Losses' AName,'I' RIFlag UNION
SELECT 'GP-P-PR'	BKAccunt,'Gross Premium Pure Premium Pure Premium' AName,'I' RIFlag UNION
SELECT 'GP-T-PR'	BKAccunt,'Gross Premium Team Premium Team Premium' AName,'I' RIFlag UNION
SELECT 'BC-OS-PC'	BKAccunt,'Brokerage Cash - Other Settled - Profit Commission' AName,'I' RIFlag UNION
SELECT 'BC-OS-RT'	BKAccunt,'Brokerage Cash - Other Settled - Reinstatement' AName,'I' RIFlag UNION
SELECT 'CC-LS-OTH'  BKAccunt,'Claim Cash - Lloyd`s Settled - Other' AName,'I' RIFlag UNION
SELECT 'CC-OS-CLM'  BKAccunt,'Claim Cash - Other Settled - Claim' AName,'I' RIFlag UNION
SELECT 'CC-OS-OT'	BKAccunt,'Gross Claims Cash Other Settled Claims' AName,'I' RIFlag UNION
SELECT 'CC-OS-OTH'  BKAccunt,'Claim Cash - Other Settled - Other' AName,'I' RIFlag UNION
SELECT 'CC-OS-TTY'  BKAccunt,'Claim Cash - Other Settled - Proportional Treaty Statement' AName,'I' RIFlag UNION
SELECT 'CC-SD-OT'	BKAccunt,'Gross Claims Cash Settled Direct Claims' AName,'I' RIFlag UNION
SELECT 'CC-SD-OTH'  BKAccunt,'Claim Cash - Settled Direct - Other' AName,'I' RIFlag UNION
SELECT 'PC-OS-PC'	BKAccunt,'Premium Cash Gross of Brokerage - Other Settled - Profit Commission' AName,'I' RIFlag UNION
SELECT 'PC-OS-RT'	BKAccunt,'Premium Cash Gross of Brokerage - Other Settled - Reinstatement' AName,'I' RIFlag UNION
SELECT 'RC-P-AC'	BKAccunt,'RI Claims Pure Claims Pure Attritional Claims' AName,'O' RIFlag UNION
SELECT 'RC-P-CM'	BKAccunt,'RI Claims Pure Claims Pure Cat Margin' AName,'O' RIFlag UNION
SELECT 'RC-P-LL'	BKAccunt,'RI Claims Pure Claims Pure Large Losses' AName,'O' RIFlag UNION
SELECT 'RC-P-T-TTY'  BKAccunt,'RC-P-T-TTY' AName,'O' RIFlag UNION
SELECT 'RC-T-AC'	BKAccunt,'RI Claims Team Claims Team Attritional Claims' AName,'O' RIFlag UNION
SELECT 'RC-T-CM'	BKAccunt,'RI Claims Team Claims Team Cat Margin' AName,'O' RIFlag UNION
SELECT 'RC-T-LL'	BKAccunt,'RI Claims Team Claims Team Large Losses' AName,'O' RIFlag UNION
SELECT 'RP-P-PR'	BKAccunt,'RI Premium Pure Premium Pure Premium' AName,'O' RIFlag UNION
SELECT 'RP-T-PR'	BKAccunt,'RI Premium Team Premium Team Premium' AName,'O' RIFlag UNION 
SELECT 'BB-NI-A'	BKAccunt,'NULL' AName,'U' RIFlag UNION
SELECT 'BB-NI-P'	BKAccunt,'NULL' AName,'U' RIFlag UNION
SELECT 'BK-CL-B'	BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'BK-CL-N'	BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'BK-CR-B'	BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'BK-CR-N'	BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'BK-DD-B'	BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'BK-DD-N'	BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'BK-DM-B'	BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'BK-DM-N'	BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'BK-DR-B'	BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'BK-DR-N'	BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'BK-PI-B'	BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'BK-PI-N'	BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'BK-PM-B'	BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'BK-PM-N'	BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'BK-RP-B'	BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'BK-RP-N'	BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'BK-TY-B'	BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'BK-TY-N'	BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'BK-X'		BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'CC-LS-UN-FAC'  BKAccunt,'CC-LS-UN-FAC' AName,'O' RIFlag UNION
SELECT 'CC-LS-UN-TTY'  BKAccunt,'CC-LS-UN-TTY' AName,'O' RIFlag UNION
SELECT 'CC-OS-   '		BKAccunt,'NULL' AName,'I' RIFlag UNION
SELECT 'CC-OS-UN-FAC'  BKAccunt,'CC-OS-UN-FAC' AName,'O' RIFlag UNION
SELECT 'CC-OS-UN-TTY'  BKAccunt,'CC-OS-UN-TTY' AName,'O' RIFlag UNION
SELECT 'CC-SD-   '		BKAccunt,'NULL' AName,'I' RIFlag UNION
SELECT 'CC-SD-UN-FAC'  BKAccunt,'CC-SD-UN-FAC' AName,'O' RIFlag UNION
SELECT 'CC-SD-UN-TTY'  BKAccunt,'CC-SD-UN-TTY' AName,'O' RIFlag UNION
SELECT 'C-DO-ATT'		BKAccunt,'Claim Defence Outstanding Attritional' AName,'I' RIFlag UNION
SELECT 'C-DO-LL'		BKAccunt,'Claim Defence Outstanding Large Loss' AName,'I' RIFlag UNION
SELECT 'C-FO-ATT'		BKAccunt,'Claim Fees Outstanding Attritional' AName,'I' RIFlag UNION
SELECT 'C-FO-LL'		BKAccunt,'Claim Fees Outstanding Large Loss' AName,'I' RIFlag UNION
SELECT 'CI-LS-FAC-UN'  BKAccunt,'CI-LS-FAC-UN' AName,'O' RIFlag UNION
SELECT 'CI-LS-TTY-UN'  BKAccunt,'CI-LS-TTY-UN' AName,'O' RIFlag UNION
SELECT 'C-IO-ATT'		BKAccunt,'Claim Indemnity Outstanding Attritional' AName,'I' RIFlag UNION
SELECT 'C-IO-LL'		BKAccunt,'Claim Indemnity Outstanding Large Loss' AName,'I' RIFlag UNION
SELECT 'GC-CP-CL-B'  BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'GC-CP-CL-N'  BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'GC-CP-TY-B'  BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'GC-CP-TY-N'  BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'GC-D-I'		BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'GC-D-P'		BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'GC-F-I'		BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'GC-F-P'		BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'GC-I-I'		BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'GC-I-P'		BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'GPE-RP-C'	BKAccunt,'NULL' AName,'I' RIFlag UNION
SELECT 'GPE-RP-X'  BKAccunt,'NULL' AName,'I' RIFlag UNION
SELECT 'GP-PR-DD-B'  BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'GP-PR-DD-N'  BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'GP-PR-DM-B'  BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'GP-PR-DM-N'  BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'GP-PR-PM-B'  BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'GP-PR-PM-N'  BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'GP-PR-RP-B'  BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'GP-PR-RP-N'  BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'GP-PR-TY-B'  BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'GP-PR-TY-N'  BKAccunt,'' AName,'U' RIFlag UNION
SELECT 'P-AA-B'  BKAccunt,'NULL' AName,'U' RIFlag UNION
SELECT 'P-AC-B'  BKAccunt,'NULL' AName,'I' RIFlag UNION
SELECT 'P-AC-P'  BKAccunt,'NULL' AName,'I' RIFlag UNION
SELECT 'P-AP-B'  BKAccunt,'NULL' AName,'U' RIFlag UNION
SELECT 'P-BA-B'  BKAccunt,'NULL' AName,'U' RIFlag UNION
SELECT 'P-BL-B'  BKAccunt,'NULL' AName,'U' RIFlag UNION
SELECT 'P-BP-B'  BKAccunt,'NULL' AName,'U' RIFlag UNION
SELECT 'PC-AS-RE'  BKAccunt,'PC-AS-RE' AName,'I' RIFlag UNION
SELECT 'PC-ULT-R'  BKAccunt,'PC-ULT-R' AName,'O' RIFlag UNION
SELECT 'PC-LS-PC-FAC'  BKAccunt,'PC-LS-PC-FAC' AName,'O' RIFlag UNION
SELECT 'PC-LS-PC-TTY'  BKAccunt,'PC-LS-PC-TTY' AName,'O' RIFlag UNION
SELECT 'PC-LS-OR-FAC'  BKAccunt,'PC-LS-OR-FAC' AName,'O' RIFlag UNION
SELECT 'PC-LS-OR-TTY'  BKAccunt,'PC-LS-OR-TTY' AName,'O' RIFlag UNION
SELECT 'PC-LS-RP-FAC'  BKAccunt,'PC-LS-RP-FAC' AName,'O' RIFlag UNION
SELECT 'PC-LS-RP-TTY'  BKAccunt,'PC-LS-RP-TTY' AName,'O' RIFlag UNION
SELECT 'PC-LS-RT-FAC'  BKAccunt,'PC-LS-RT-FAC' AName,'O' RIFlag UNION
SELECT 'PC-LS-RT-TTY'  BKAccunt,'PC-LS-RT-TTY' AName,'O' RIFlag UNION
SELECT 'PC-OS-RP-FAC'  BKAccunt,'PC-OS-RP-FAC' AName,'O' RIFlag UNION
SELECT 'PC-OS-RP-TTY'  BKAccunt,'PC-OS-RP-TTY' AName,'O' RIFlag UNION
SELECT 'PC-OS-RT-FAC'  BKAccunt,'PC-OS-RT-FAC' AName,'O' RIFlag UNION
SELECT 'PC-OS-RT-TTY'  BKAccunt,'PC-OS-RT-TTY' AName,'O' RIFlag UNION
SELECT 'PC-SD-RP-FAC'  BKAccunt,'PC-SD-RP-FAC' AName,'O' RIFlag UNION
SELECT 'PC-SD-RP-TTY'  BKAccunt,'PC-SD-RP-TTY' AName,'O' RIFlag UNION
SELECT 'PC-SD-RT-FAC'  BKAccunt,'PC-SD-RT-FAC' AName,'O' RIFlag UNION
SELECT 'PC-SD-RT-TTY'  BKAccunt,'PC-SD-RT-TTY' AName,'O' RIFlag UNION
SELECT 'P-EA-B'  BKAccunt,'NULL' AName,'U' RIFlag UNION
SELECT 'P-EA-P'  BKAccunt,'NULL' AName,'U' RIFlag UNION
SELECT 'P-EP-B'  BKAccunt,'NULL' AName,'U' RIFlag UNION
SELECT 'P-EP-P'  BKAccunt,'NULL' AName,'U' RIFlag UNION
SELECT 'P-GP-B'  BKAccunt,'NULL' AName,'I' RIFlag UNION
SELECT 'P-GP-P'  BKAccunt,'NULL' AName,'I' RIFlag UNION
SELECT 'P-IC-P'  BKAccunt,'NULL' AName,'I' RIFlag UNION
SELECT 'P-LB-B'  BKAccunt,'NULL' AName,'I' RIFlag UNION
SELECT 'P-LB-P'  BKAccunt,'NULL' AName,'I' RIFlag UNION
SELECT 'P-RI-B'  BKAccunt,'NULL' AName,'U' RIFlag UNION
SELECT 'P-RI-P'  BKAccunt,'NULL' AName,'U' RIFlag UNION
SELECT 'P-OR-P-FAC'  BKAccunt,'P-OR-P-FAC' AName,'O' RIFlag UNION
SELECT 'P-OR-P-TTY'  BKAccunt,'P-OR-P-TTY' AName,'O' RIFlag UNION
SELECT 'P-RP-P-FAC'  BKAccunt,'P-RP-P-FAC' AName,'O' RIFlag UNION
SELECT 'P-RP-P-TTY'  BKAccunt,'P-RP-P-TTY' AName,'O' RIFlag UNION
SELECT 'RC-CP-CR-B'  BKAccunt,'' AName,'O' RIFlag UNION
SELECT 'RC-CP-CR-N'  BKAccunt,'' AName,'O'  RIFlag UNION
SELECT 'RCP-LS-OT'  BKAccunt,'NULL' AName,'O' RIFlag UNION
SELECT 'RCP-OS-OT'  BKAccunt,'NULL' AName,'O' RIFlag UNION
SELECT 'RCP-SD-OT'  BKAccunt,'NULL' AName,'O' RIFlag UNION
SELECT 'RPP-LS-OT'  BKAccunt,'NULL' AName,'O' RIFlag UNION
SELECT 'RPP-LS-RT'  BKAccunt,'NULL' AName,'O' RIFlag UNION
SELECT 'RPP-OS-OT'  BKAccunt,'NULL' AName,'O' RIFlag UNION
SELECT 'RPP-OS-RT'  BKAccunt,'NULL' AName,'O' RIFlag UNION
SELECT 'RP-PR-DR-B'  BKAccunt,'' AName,'O' RIFlag UNION
SELECT 'RP-PR-DR-N'  BKAccunt,'' AName,'O' RIFlag UNION
SELECT 'RP-PR-PI-B'  BKAccunt,'' AName,'O' RIFlag UNION
SELECT 'RP-PR-PI-N'  BKAccunt,'' AName,'O' RIFlag UNION
SELECT 'RP-PR-RR-B'  BKAccunt,'' AName,'O' RIFlag UNION
SELECT 'RPP-SD-OT'  BKAccunt,'NULL' AName,'O' RIFlag UNION
SELECT 'RPP-SD-RT'  BKAccunt,'NULL' AName,'O' RIFlag UNION
SELECT 'EX-RB-RC-R'  BKAccunt,'EX-RB-RC-R' AName,'O' RIFlag UNION
SELECT 'EX-RB-RP-R'  BKAccunt,'EX-RB-RP-R' AName,'O' RIFlag UNION
SELECT 'GPE-RP-P'  BKAccunt,'NULL' AName,'I' RIFlag UNION
SELECT 'GP-P-PR'  BKAccunt,'NULL' AName,'I' RIFlag UNION 
SELECT 'GP-T-PR'  BKAccunt,'NULL' AName,'I' RIFlag UNION
SELECT 'RP-ULT-G'    BKAccunt,'RP-ULT-G' AName,'I' RIFlag UNION
SELECT 'RP-ULT-R-TTY'  BKAccunt,'RP-ULT-R-TTY' AName,'O' RIFlag UNION
SELECT 'RP-T-PR'  BKAccunt,'NULL' AName,'O' RIFlag UNION
SELECT 'CC-LS-TTY-UN' BKAccunt,'CC-LS-TTY-UN' AName,'O' RIFlag UNION
SELECT 'CC-LS-FAC-UN' BKAccunt,'CC-LS-FAC-UN' AName,'O' RIFlag UNION
SELECT 'P-EP-P-FAC'  BKAccunt,'P-EP-P-FAC' AName,'O' RIFlag UNION
SELECT 'P-EP-P-TTY'  BKAccunt,'P-EP-P-TTY' AName,'O' RIFlag UNION
SELECT 'EX-AC-O-R'  BKAccunt,'EX-AC-O-R' AName,'I' RIFlag UNION
SELECT 'EX-RI-P-R'  BKAccunt,'EX-RI-P-R' AName,'O' RIFlag UNION
SELECT 'EX-CH-O-R'  BKAccunt,'EX-CH-O-R' AName,'I' RIFlag UNION
SELECT 'EX-AD-P-R'  BKAccunt,'EX-AD-P-R' AName,'I' RIFlag UNION
SELECT 'RC-UL-FAC-UN' BKAccunt,'RC-UL-FAC-UN' AName,'O' RIFlag UNION
SELECT 'RC-UL-TTY-UN' BKAccunt,'RC-UL-TTY-UN' AName,'O' RIFlag UNION
SELECT 'EX-AC-O' BKAccunt,''Aname,'I' RIFlag UNION
SELECT 'EX-AD-P' BKAccunt,''Aname,'I' RIFlag UNION
SELECT 'EX-CH-O' BKAccunt,''Aname,'I' RIFlag UNION
SELECT 'EX-RI-P' BKAccunt,''Aname,'O' RIFlag UNION
SELECT 'RC-P-T-FAC' BKAccunt,''Aname,'O' RIFlag UNION
SELECT 'CC-LS-UN-UNK' BKAccunt,''Aname,'O' RIFlag UNION
SELECT 'CI-LS-UNK-UN' BKAccunt,''Aname,'O' RIFlag UNION
SELECT 'CC-SD-ATT-FAC' BKAccunt,''Aname,'O' RIFlag UNION
SELECT 'CC-SD-LL-FAC' BKAccunt,''Aname,'O' RIFlag UNION
SELECT 'CC-LS-LL-FAC'  BKAccunt,''Aname,'O' RIFlag UNION
SELECT 'CC-OS-ATT-FAC' BKAccunt,''Aname,'O' RIFlag UNION
SELECT 'CC-LS-ATT-FAC' BKAccunt,''Aname,'O' RIFlag UNION
SELECT 'LBSC-LS-PC' BKAccunt,'LBSC-LS-PC'Aname,'I' RIFlag UNION
SELECT 'LBSC-LS-OT' BKAccunt,'LBSC-LS-OT'Aname,'I' RIFlag UNION
SELECT 'LBSC-LS-RT' BKAccunt,'LBSC-LS-RT'Aname,'I' RIFlag UNION
SELECT 'LBSC-OS-OT' BKAccunt,'LBSC-OS-OT'Aname,'I' RIFlag UNION
SELECT 'LBSC-SD-OT' BKAccunt,'LBSC-SD-OT'Aname,'I' RIFlag 
) Script ON Script.BKAccunt=A.BK_Account