﻿MERGE INTO  [dim].[CCY]  AS tgt
USING	(VALUES('OTH','OTHER (Soft)')) as src ([PK_CCY],[CCYName])
ON	  tgt.[BK_CCY] = src.[PK_CCY]
WHEN  NOT MATCHED BY TARGET
THEN INSERT
			([BK_CCY],
			[CCYName]
			)
	Values
	(
	src.[PK_CCY],
	src.[CCYName]
	)
 WHEN MATCHED
 AND (
	  src.[CCYName]<> tgt.[CCYName]	
 )
  THEN UPDATE 
  set 
	   tgt.[CCYName] = src.[CCYName];