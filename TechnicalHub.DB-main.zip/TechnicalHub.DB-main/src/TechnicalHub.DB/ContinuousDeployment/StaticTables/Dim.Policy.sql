﻿MERGE [dim].[Policy]  AS TGT
USING	(VALUES('NOPOLI','NOPOLI','19800101','29991231','1980','UNKNOWN','UNKNOWN','19800101','UNKNOWN','29991231',0)
		) as Src (PK_Policy,BK_PolicyNumber,InceptionDate,ExpiryDate,PolicyYOA,PolicyType, PolicyPattern, BindDate, TypeOfBusiness, MaxEarningDate, IsUSPolicy)
ON	  TGT.[PK_Policy] = Src.[PK_Policy]
WHEN  NOT MATCHED BY TARGET
THEN INSERT
			(PK_Policy,BK_PolicyNumber,InceptionDate,ExpiryDate,PolicyYOA,PolicyType, PolicyPattern, BindDate, TypeOfBusiness, MaxEarningDate, IsUSPolicy
			)
	Values
	(
PK_Policy,BK_PolicyNumber,InceptionDate,ExpiryDate,PolicyYOA,PolicyType, PolicyPattern, BindDate, TypeOfBusiness, MaxEarningDate, IsUSPolicy	)
 WHEN MATCHED
 AND (
 	  src.BK_PolicyNumber<> tgt.BK_PolicyNumber OR
	  src.InceptionDate<> tgt.InceptionDate OR
	  src.ExpiryDate<> tgt.ExpiryDate OR
	  src.PolicyYOA<> tgt.PolicyYOA OR
	  src.PolicyType<> tgt.PolicyType OR
	  src.PolicyPattern<> tgt.PolicyPattern OR
	  src.BindDate<> tgt.BindDate OR
	  src.TypeOfBusiness<> tgt.TypeOfBusiness OR
	  src.MaxEarningDate<> tgt.MaxEarningDate OR
	  src.IsUSPolicy<> tgt.IsUSPolicy 
 )
  THEN UPDATE 
  set 
	   tgt.BK_PolicyNumber = src.BK_PolicyNumber,
	   tgt.InceptionDate = src.InceptionDate,
	   tgt.ExpiryDate = src.ExpiryDate,
	   tgt.PolicyYOA = src.PolicyYOA,
	   tgt.PolicyType = src.PolicyType,
	   tgt.PolicyPattern = src.PolicyPattern,
	   tgt.BindDate = src.BindDate,
	   tgt.TypeOfBusiness = src.TypeOfBusiness,
	   tgt.MaxEarningDate = src.MaxEarningDate,
	   tgt.IsUSPolicy = src.IsUSPolicy;