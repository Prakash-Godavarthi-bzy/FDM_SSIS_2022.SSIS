﻿INSERT		dim.InceptionYear (PK_InceptionYear, InceptionYear)
SELECT		stg.PK_InceptionYear
			,stg.InceptionYear
FROM		(
				SELECT		1900 + t.i,
							CAST(1900 + t.i AS CHAR(4))
				FROM		(SELECT TOP 3000 ROW_NUMBER() OVER (ORDER BY o.object_id) AS i FROM sys.objects o CROSS JOIN sys.objects o2) t
				UNION
				SELECT		-1, 'UNKNOWN'
			) stg (PK_InceptionYear, InceptionYear)
LEFT JOIN	dim.InceptionYear iy ON iy.PK_InceptionYear = stg.PK_InceptionYear
WHERE		iy.PK_InceptionYear IS NULL
--UNION
--SELECT '1900','1900'
 