﻿/*--------------------Script to Delete Additional Unknown Value Start------------------*/
IF  EXISTS (SELECT *
			FROM TECHNICALHUB.dim.TrackingStatus
			WHERE BK_TrackingStatus='Unknown' AND PK_TrackingStatus<>'-1'
			)
BEGIN
DELETE FROM TECHNICALHUB.dim.TrackingStatus
WHERE BK_TrackingStatus='Unknown' AND PK_TrackingStatus<>'-1'
END

IF  EXISTS (SELECT *
			FROM TECHNICALHUB.dim.MovementType
			WHERE BK_MovementType='Unknown' AND PK_MovementType<>'-1'
			)
BEGIN
DELETE FROM TECHNICALHUB.dim.MovementType
WHERE BK_MovementType='Unknown' AND PK_MovementType<>'-1'
END
/*--------------------Script to Delete Additional Unknown Value End------------------*/

