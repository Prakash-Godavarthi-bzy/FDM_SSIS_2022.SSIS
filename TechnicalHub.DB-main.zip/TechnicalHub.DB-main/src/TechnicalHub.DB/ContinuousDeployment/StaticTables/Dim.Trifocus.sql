﻿MERGE INTO [dim].[Trifocus] AS tgt
USING(VALUES
		('33333371','Unknown from IFRS17 load','Softelligence import','',''),
		('3713','Unknown from IFRS17 load','Softelligence import','',''),
		('TRI00006','Unknown from IFRS17 load','Softelligence import','',''),
		('TRI00027','Unknown from IFRS17 load','Softelligence import','',''),
		('TRI00032','Unknown from IFRS17 load','Softelligence import','',''),
		('TRI00062','Unknown from IFRS17 load','Softelligence import','','')
		--('UNK','Unknown from IFRS17 load','Softelligence import','',''),
		--('UNKNOWN','Unknown from IFRS17 load','Softelligence import','','')
		) as src ([PK_Trifocus],[TrifocusName],[TriFocusLevel1],[TriFocusLevel2],[TriFocusLevel3])
ON	  tgt.[BK_TriFocus] = src.[PK_Trifocus]
WHEN  NOT MATCHED BY TARGET
THEN INSERT
			([BK_TriFocus],[TrifocusName],[TriFocusLevel1],[TriFocusLevel2],[TriFocusLevel3]
			)
	Values
	(
	src.[PK_Trifocus],src.[TrifocusName],src.[TriFocusLevel1],src.[TriFocusLevel2],src.[TriFocusLevel3]
	)
 WHEN MATCHED
 AND (
	  src.[TrifocusName]<> tgt.[TrifocusName]	OR
	  src.[TriFocusLevel1]<> tgt.[TriFocusLevel1]	OR
	  src.[TriFocusLevel2]<> tgt.[TriFocusLevel2]	OR
	  src.[TriFocusLevel3]<> tgt.[TriFocusLevel3]	 
 )
  THEN UPDATE 
  set  
	   tgt.[TrifocusName]  = src.[TrifocusName],
	  tgt.[TriFocusLevel1] = src.[TriFocusLevel1]	,
	  tgt.[TriFocusLevel2] = src.[TriFocusLevel2]	,
	  tgt.[TriFocusLevel3] = src.[TriFocusLevel3]	 
	   ;

  