﻿---- =============================================	
---- Author:		Shah Nawaz Ahmed <shahnawaz.ahmed@beazley.com>
---- Create date: 08/08/2024
---- Description:	Created login and user to give access to MDA. Creating the login with SID to avoid orphaning between environments
------			Have pasted the snip of conversation with rod in jira.
---- jira: https://beazley.atlassian.net/browse/I1B-5746
---- =============================================

----:setvar Parameter_MDALogin "cdc_IFRS"
----:setvar Parameter_MDAPassword "12345"
----:setvar Parameter_MDALoginSid "0x"

DECLARE @LoginName NVARCHAR(128) = '$(Parameter_MDALogin)';
DECLARE @Password NVARCHAR(128) = '$(Parameter_MDAPassword)';
DECLARE @SID NVARCHAR(128) = '$(Parameter_MDALoginSid)';

DECLARE @LoginSql NVARCHAR(256);
DECLARE @Sql NVARCHAR(MAX);

IF	NOT EXISTS (SELECT	* FROM	sys.server_principals where	name = @LoginName)
BEGIN

	SET @LoginSql = N'
		 CREATE LOGIN ' + QUOTENAME(@LoginName) + 
		 N' WITH PASSWORD = ' + QUOTENAME(@Password, '''') + 
		 N', SID = ' + @SID + N';';
	EXEC sp_executesql @LoginSql;

	PRINT 'Login ' + @LoginName + ' Created.';
END
ELSE
BEGIN
    PRINT 'Login ' + @LoginName + ' already exists.';
END

USE TechnicalHub;

IF EXISTS (SELECT * FROM sys.database_principals WHERE name = @LoginName)
BEGIN
    -- Check if the user is orphaned (has no associated login)
	DECLARE @UserSid NVARCHAR(128)
	SELECT	@UserSid = sid
	FROM	sys.database_principals
	where	name = 'cdc_IFRS'

    IF (@SID <> @UserSid)
    BEGIN
        -- Drop the orphaned user
        SET @Sql = N'DROP USER ' + QUOTENAME(@LoginName) + ';';
        EXEC sp_executesql @Sql;
        PRINT 'Orphaned user ' + @LoginName + ' dropped.';
    END
END

IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = @LoginName)
BEGIN

    SET @Sql = N'CREATE USER ' + QUOTENAME(@LoginName) + ' FOR LOGIN ' + QUOTENAME(@LoginName) + ';';
    EXEC sp_executesql @Sql;
    PRINT 'User ' + @LoginName + ' Created.';

    -- Assign role to the user
    SET @Sql = N'EXEC sp_addrolemember ''db_datareader'', ' + QUOTENAME(@LoginName, '''') + ';';
    EXEC sp_executesql @Sql;
    PRINT 'User ' + @LoginName + ' assigned to db_datareader role.';
END
ELSE
BEGIN
    PRINT 'User ' + @LoginName + ' already exists.';
END