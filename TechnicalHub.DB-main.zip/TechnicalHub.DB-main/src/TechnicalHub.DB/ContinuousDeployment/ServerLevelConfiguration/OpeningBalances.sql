﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
--		:SETVAR InstanceName "Localhost\SQL2016"
--		:SETVAR SchedulingHubEnvironment "SchedulingHubEnvironment"
--		:SETVAR SSISProxyName "PXY_PH"

		DECLARE @Env2 NVARCHAR(20) = (select	 CAST(reference_id AS varchar) from	SSISDB.internal.environment_references	where environment_name = 'TechnicalHUbEnvironment')
		DECLARE @Command2 NVARCHAR(4000) = '/ISSERVER "\"\SSISDB\TechnicalHub\TechnicalHub.SSIS\FactOpeningBalances.dtsx\"" /SERVER "\"$(TargetInstanceName)\"" /ENVREFERENCE ' + @Env2 + ' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'

		IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'OpeningBalances')
			EXEC msdb.dbo.sp_delete_job @job_name = 'OpeningBalances', @delete_unused_schedule=1
		
		EXEC msdb.dbo.sp_add_job 
			@Start_step_id = 1, 
			@job_name=N'OpeningBalances', 
			@enabled=1, 
			@notify_level_eventlog=0, 
			@notify_level_email=0, 
			@notify_level_netsend=0, 
			@notify_level_page=0, 
			@delete_level=0, 
			@owner_login_name=N'BFL\Beazley_Reader'
		
		EXEC msdb.dbo.sp_add_jobstep
			@job_name=N'OpeningBalances', 
			@step_name=N'Run Opening Balances', 
			@step_id=1, 
			@cmdexec_success_code=0, 
			@on_success_action=1, 
			@on_success_step_id=0, 
			@on_fail_action=2, 
			@on_fail_step_id=0, 
			@retry_attempts=0, 
			@retry_interval=0, 
			@os_run_priority=0, 
			@subsystem=N'SSIS', 
			@Command=@Command2, 
			@database_name=N'master', 
			@flags=0, 
			@proxy_name=N'$(SSISProxyName)'

		EXEC msdb.dbo.sp_add_jobschedule 
				@job_name = 'OpeningBalances', 
				@name=N'Every 60 secs', 
				@enabled=0, 
				@freq_type=4, 
				@freq_interval=1, 
				@freq_subday_type=2, 
				@freq_subday_interval=60, 
				@freq_relative_interval=0, 
				@freq_recurrence_factor=0, 
				@active_start_date=20190417, 
				@active_end_date=99991231, 
				@active_start_time=0, 
				@active_end_time=235959, 
				@schedule_uid=N'b0c7856a-35d2-4d8c-b42e-0ddef43f1101'
		
		EXEC msdb.dbo.sp_add_jobserver 
			@job_name=N'OpeningBalances',
			@server_name = N'(local)'

