﻿/*		
version	   Modified by							Date								Description
---------------------------------------------------------------------------------------------------------------------------------------
 1.0     Lakshman.Akasapu@Beazley.com		30/05/2024				created new Environment Reference Variables IFRS17_MailFrom and IFRS17_MailTo 
																	regarding the ticket :https://beazley.atlassian.net/jira/software/c/projects/I1B/boards/735?search=5553&selectedIssue=I1B-5553&sprints=5993

---------------------------------------------------------------------------------------------------------------------------------------
*/

DECLARE @ServerName_TechnicalHub				NVARCHAR(2000) = '$(TargetInstanceName)'
DECLARE @ServerName_FinanceDataContract			NVARCHAR(2000) = '$(TargetInstanceName)'
DECLARE @ServerName_FinanceLanding				NVARCHAR(2000) = '$(TargetInstanceName)'
DECLARE @ServerName_Orchestram					NVARCHAR(2000) = '$(TargetInstanceName)'
DECLARE @ServerName_FinanceDataMart				NVARCHAR(2000) = '$(Parameter_FinanceDataMart)'
--DECLARE @URL_FDMSharepoint						NVARCHAR(2000) = '$(Parameter_FDMSharepoint)'
DECLARE @ServerName_SMTP						NVARCHAR(2000) = '$(Parameter_SMTP)'
DECLARE @Parameter_OLAP_ServerName				NVARCHAR(2000) = '$(Parameter_OLAP_ServerName)'
DECLARE @Parameter_MetricImportPath				NVARCHAR(2000) = '$(MetricImportPath)'
DECLARE @Parameter_MetricOutputPath				NVARCHAR(2000) = '$(MetricOutputPath)'

DECLARE @IFRS17_MailFrom						NVARCHAR(2000) = '$(Parameter_IFRS17_MailFrom)'
DECLARE @IFRS17_MailTo							NVARCHAR(2000) = '$(Parameter_IFRS17_MailTo)'

DECLARE @ReferenceID INT = 0
WHILE EXISTS	(SELECT	* FROM	ssisdb.catalog.environment_references r WHERE	r.environment_name = 'TechnicalHubEnvironment' AND r.reference_id > @ReferenceID)
BEGIN
	SELECT	@ReferenceID = MIN(reference_id)
	FROM	ssisdb.catalog.environment_references r
	WHERE	r.environment_name = 'TechnicalHubEnvironment'
		AND reference_id > @ReferenceID
	
	EXEC SSISDB.catalog.delete_environment_reference @ReferenceID
END

IF EXISTS (SELECT * FROM SSISDB.catalog.environments WHERE Name = 'TechnicalHubEnvironment')		
	EXEC [SSISDB].[catalog].[delete_environment] @folder_name = 'TechnicalHub', @Environment_Name = 'TechnicalHubEnvironment'

--Clean off any parameters incorrectly set by solidops SSIS deployment
DECLARE @ObjectName VARCHAR(255), @ParameterName VARCHAR(255), @ObjectType INT
WHILE EXISTS (SELECT * FROM	ssisdb.catalog.object_parameters op WHERE	op.referenced_variable_name LIKE 'TechnicalHub.SSIS.%')
BEGIN
	SELECT	TOP 1  
			@ObjectName = op.object_name,
			@ParameterName = op.parameter_name,
			@ObjectType = op.object_type
	FROM	ssisdb.catalog.object_parameters op 
	WHERE	op.referenced_variable_name LIKE 'TechnicalHub.SSIS.%'
	
	EXEC SSISDB.catalog.clear_object_parameter_value @folder_name = N'TechnicalHub'
													,@project_name = N'TechnicalHub.SSIS'
													,@object_type = @ObjectType
													,@object_name = @ObjectName
													,@parameter_name = @ParameterName
END


EXEC [SSISDB].[catalog].[create_environment] @folder_name = 'TechnicalHub', @Environment_Name = 'TechnicalHubEnvironment'

SET @ReferenceID = NULL
EXEC [SSISDB].[catalog].[create_environment_reference] @folder_name = N'TechnicalHub', @project_name = N'TechnicalHub.SSIS', @environment_name = N'TechnicalHubEnvironment', @Reference_type = 'R', @reference_id = @ReferenceID



EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'TechnicalHubEnvironment',			@variable_name=N'ServerName_TechnicalHub',			@sensitive=False, @folder_name=N'TechnicalHub',		@value=@ServerName_TechnicalHub,		@data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'TechnicalHubEnvironment',			@variable_name=N'ServerName_Orchestram',			@sensitive=False, @folder_name=N'TechnicalHub',		@value=@ServerName_Orchestram,			@data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'TechnicalHubEnvironment',			@variable_name=N'ServerName_FinanceDataContract',	@sensitive=False, @folder_name=N'TechnicalHub',		@value=@ServerName_FinanceDataContract, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'TechnicalHubEnvironment',			@variable_name=N'ServerName_FinanceLanding',		@sensitive=False, @folder_name=N'TechnicalHub',		@value=@ServerName_FinanceLanding,		@data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'TechnicalHubEnvironment',			@variable_name=N'ServerName_FinanceDataMart',		@sensitive=False, @folder_name=N'TechnicalHub',		@value=@ServerName_FinanceDataMart,		@data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'TechnicalHubEnvironment',			@variable_name=N'ServerName_SMTP',					@sensitive=False, @folder_name=N'TechnicalHub',		@value=@ServerName_SMTP,				@data_type=N'String'
--EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'TechnicalHubEnvironment',			@variable_name=N'ServerName_FDMTrifocusSharepoint', @sensitive=False, @folder_name=N'TechnicalHub',		@value=@URL_FDMSharepoint,				@data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'TechnicalHubEnvironment',			@variable_name=N'ServerName_OLAP_TechnicalHub',		@sensitive=False, @folder_name=N'TechnicalHub',		@value=@Parameter_OLAP_ServerName,		@data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'TechnicalHubEnvironment',			@variable_name=N'MetricImportPath',					@sensitive=False, @folder_name=N'TechnicalHub',		@value=@Parameter_MetricImportPath,		@data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'TechnicalHubEnvironment',			@variable_name=N'MetricOutputPath',					@sensitive=False, @folder_name=N'TechnicalHub',		@value=@Parameter_MetricOutputPath,		@data_type=N'String'

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_TechnicalHub',			@object_name=N'TechnicalHub.SSIS', @folder_name=N'TechnicalHub', @project_name=N'TechnicalHub.SSIS', @value_type=R, @parameter_value=N'ServerName_TechnicalHub'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_Orchestram',				@object_name=N'TechnicalHub.SSIS', @folder_name=N'TechnicalHub', @project_name=N'TechnicalHub.SSIS', @value_type=R, @parameter_value=N'ServerName_Orchestram'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_FinanceDataContract',	@object_name=N'TechnicalHub.SSIS', @folder_name=N'TechnicalHub', @project_name=N'TechnicalHub.SSIS', @value_type=R, @parameter_value=N'ServerName_FinanceDataContract'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_FinanceLanding',			@object_name=N'TechnicalHub.SSIS', @folder_name=N'TechnicalHub', @project_name=N'TechnicalHub.SSIS', @value_type=R, @parameter_value=N'ServerName_FinanceLanding'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_FinanceDataMart',		@object_name=N'TechnicalHub.SSIS', @folder_name=N'TechnicalHub', @project_name=N'TechnicalHub.SSIS', @value_type=R, @parameter_value=N'ServerName_FinanceDataMart'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_SMTP',					@object_name=N'TechnicalHub.SSIS', @folder_name=N'TechnicalHub', @project_name=N'TechnicalHub.SSIS', @value_type=R, @parameter_value=N'ServerName_SMTP'
--EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_FDMTrifocusSharepoint',	@object_name=N'TechnicalHub.SSIS', @folder_name=N'TechnicalHub', @project_name=N'TechnicalHub.SSIS', @value_type=R, @parameter_value=N'ServerName_FDMTrifocusSharepoint'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ServerName_OLAP_TechnicalHub',		@object_name=N'TechnicalHub.SSIS', @folder_name=N'TechnicalHub', @project_name=N'TechnicalHub.SSIS', @value_type=R, @parameter_value=N'ServerName_OLAP_TechnicalHub'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'MetricImportPath',					@object_name=N'TechnicalHub.SSIS', @folder_name=N'TechnicalHub', @project_name=N'TechnicalHub.SSIS', @value_type=R, @parameter_value=N'MetricImportPath'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'MetricOutputPath',					@object_name=N'TechnicalHub.SSIS', @folder_name=N'TechnicalHub', @project_name=N'TechnicalHub.SSIS', @value_type=R, @parameter_value=N'MetricOutputPath'



EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'TechnicalHubEnvironment',			@variable_name=N'IFRS17_MailFrom',					@sensitive=False, @folder_name=N'TechnicalHub',		@value=@IFRS17_MailFrom,		@data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'TechnicalHubEnvironment',			@variable_name=N'IFRS17_MailTo',					@sensitive=False, @folder_name=N'TechnicalHub',		@value=@IFRS17_MailTo,		@data_type=N'String'

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'IFRS17_MailFrom', @object_name=N'TechnicalHub.SSIS', @folder_name=N'TechnicalHub', @project_name=N'TechnicalHub.SSIS', @value_type=R, @parameter_value=N'IFRS17_MailFrom'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'IFRS17_MailTo', @object_name=N'TechnicalHub.SSIS', @folder_name=N'TechnicalHub', @project_name=N'TechnicalHub.SSIS', @value_type=R, @parameter_value=N'IFRS17_MailTo'
