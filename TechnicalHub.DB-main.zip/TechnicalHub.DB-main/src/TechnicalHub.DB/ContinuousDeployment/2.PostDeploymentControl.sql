﻿/*

	1. Invoke the following procedure to generate your MERGE statements:
		Example: EXEC sp_generate_merge @schema = 'dbo', @table_name ='Table'

	2. Paste it to a new file in the StaticTables folder.

	3. Include it in the list below. Order of the tables in the list depends on your table relationships.
		Begin with the tables at the end of your relationship chain.

*/

	--:r .\StaticTables\StaticTableExample.sql
	
	--:r .\StaticTables\Dim.Scenario.sql
	--:r .\StaticTables\Dim.Account.sql
	--:r .\StaticTables\Dim.Datastage.sql
	--:r .\StaticTables\Dim.Date.sql
	--:r .\StaticTables\Dim.AccountingPeriod.sql
	--:r .\StaticTables\Dim.Basis.sql
	--:r .\StaticTables\Dim.Process.sql
	--:r .\StaticTables\Control.TechHubToFDMMapping.sql
	--:r .\StaticTables\Dim.DataSet.sql
	--:r .\StaticTables\Dim.InceptionYear.sql
	--:r .\StaticTables\Dim.CCY.sql
	--:r .\StaticTables\Dim.Entity.sql
	--:r .\StaticTables\Dim.Trifocus.sql
	--:r .\StaticTables\Dim.YOA.sql
	--:r .\StaticTables\Dim.YOA.sql
	--:r .\StaticTables\Dim.RIPolicyType.sql
	--:r .\StaticTables\Dim.DeltaType.sql

	--:r .\ServerLevelConfiguration\Credential_PXY_FDM.sql
	:r .\ServerLevelConfiguration\EnvironmentVariables.sql
	--:r .\ServerLevelConfiguration\Credential_SSASService.sql
	--:r .\ServerLevelConfiguration\CalculationTreeJob.sql
	--:r .\ServerLevelConfiguration\ControlRunPowerApps.sql
	--:r .\ServerLevelConfiguration\OpeningBalances.sql
	--:r .\StaticTables\DimsStaticScripts.sql
	--:r .\StaticTables\DeleteScripts.sql
	--:r .\StaticTables\Dim.AccountRIFlag.sql

	:r .\ServerLevelConfiguration\MDALogin.sql