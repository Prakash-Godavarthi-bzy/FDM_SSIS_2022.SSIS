﻿
CREATE TABLE [fct].[SideCarPercentages_HISTORY](
	[pk_SideCar] [int] NOT NULL,
	[TriFocus] [varchar](255) NOT NULL,
	[YOA] [int] NOT NULL,
	[STATSCODE] [varchar](25) NOT NULL,
	[PERCENT] [numeric](20, 3) NOT NULL,
	[ValidFrom] [datetime2](7) NOT NULL,
	[ValidTo] [datetime2](7) NOT NULL
) ON [PRIMARY]
GO


