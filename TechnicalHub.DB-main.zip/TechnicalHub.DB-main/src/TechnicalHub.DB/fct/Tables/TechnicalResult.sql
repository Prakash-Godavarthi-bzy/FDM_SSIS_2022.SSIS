﻿	CREATE TABLE [fct].[TechnicalResult] (
    [PK_FTH]                BIGINT           IDENTITY (1, 1) NOT NULL,
    [FK_Batch]              INT              NOT NULL,
    [FK_DataSet]            BIGINT				 NOT NULL,
    [FK_Scenario]           BIGINT				 NOT NULL,
    [FK_Account]            BIGINT				 NOT NULL,
    [FK_AccountingPeriod]   BIGINT              NOT NULL,
    [FK_Basis]              BIGINT				 NOT NULL,
    [FK_DataStage]          INT              NOT NULL,
    [FK_Entity]             BIGINT				 NOT NULL,
    [FK_Policy]             VARCHAR (255)    NOT NULL,
	[FK_PolicySection]		BIGINT				 NOT NULL,
    [FK_Process]            BIGINT				 NOT NULL,
    [FK_Product]            BIGINT				 NOT NULL,
    [FK_Location]           BIGINT	 			 NOT NULL,
    [FK_Trifocus]           BIGINT     NOT NULL,
    [FK_YOA]                BIGINT     NOT NULL,
    [FK_Allocation]         INT              NULL,
    [FK_CCYOriginal]          BIGINT      NOT NULL,
    [FK_CCYSettlement]        BIGINT      NOT NULL,
    [FK_DateDue]               BIGINT           NOT NULL,
    [Value]                 NUMERIC (38, 10) NOT NULL,
    [EarningPercentage]     NUMERIC (38, 10) NULL,
    [Fk_statscode]          VARCHAR (25)     NULL,
    [RowHash]               VARBINARY (8000) NOT NULL,
    [AuditSourceBatchID]    NVARCHAR (510)   NOT NULL,
    [AuditCreateDateTime]   DATETIME2 (7)    NOT NULL DEFAULT (getutcdate()),
    [AuditGenerateDateTime] DATETIME2 (7)   NOT NULL,
    [AuditUserCreate]       NVARCHAR (510)  NOT NULL DEFAULT (suser_sname()),
    [FK_InceptionYear]      INT              NULL,
    [InceptionPeriod]       INT              NULL,
	[FK_CatCode]			BIGINT			NOT NULL,
	[FK_MovementType]		BIGINT			NOT NULL,
	[FK_TrackingStatus]		BIGINT			NOT	NULL,
	[FK_ClaimExposure]		BIGINT			NOT NULL,
	[FK_DateOfFact]			BIGINT			NOT NULL,
	[BusinessKey]			VARCHAR(255)	NOT NULL,
	[FK_InceptionDate]		BIGINT			NOT NULL,
	[FK_RIPolicyType]		BIGINT			NOT NULL,
	[FK_ProgrammeCode]		BIGINT			NOT NULL,
	[Att_Cat]				VARCHAR(1)		NULL,
	[FK_ReservingDataset]	BIGINT			NULL,
	[FK_TriangleGroup]		BIGINT			NULL,
	[FK_SourceEntity]		BIGINT			NULL,
	[FK_DeltaType]			BIGINT			NULL,
	[GroupShare]		    FLOAT					NULL,
	[Intercompany_PrioritySeq] INT					NULL,
    CONSTRAINT [PK_TechnicalResult] PRIMARY KEY NONCLUSTERED ([PK_FTH] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_TechnicalResult_Account] FOREIGN KEY ([FK_Account]) REFERENCES [dim].[Account] ([PK_Account]),
    CONSTRAINT [FK_TechnicalResult_AccountingPeriod] FOREIGN KEY ([FK_AccountingPeriod]) REFERENCES [dim].[AccountingPeriod] ([PK_AccountingPeriod]),
    --CONSTRAINT [FK_TechnicalResult_Allocation] FOREIGN KEY ([FK_Allocation]) REFERENCES [dim].[Allocation] ([pk_Allocation]),
    CONSTRAINT [FK_TechnicalResult_Basis] FOREIGN KEY ([FK_Basis]) REFERENCES [dim].[Basis] ([PK_Basis]),
    CONSTRAINT [FK_TechnicalResult_CCYOriginal] FOREIGN KEY ([FK_CCYOriginal]) REFERENCES [dim].[CCY] ([PK_CCY]),
    CONSTRAINT [FK_TechnicalResult_CCYSettlement] FOREIGN KEY ([FK_CCYSettlement]) REFERENCES [dim].[CCY] ([PK_CCY]),
    CONSTRAINT [FK_TechnicalResult_DataStage] FOREIGN KEY ([FK_DataStage]) REFERENCES [dim].[DataStage] ([PK_DataStage]),
    CONSTRAINT [FK_TechnicalResult_DateDue] FOREIGN KEY ([FK_DateDue]) REFERENCES [dim].[Date] ([PK_Date]),
    CONSTRAINT [FK_TechnicalResult_Entity] FOREIGN KEY ([FK_Entity]) REFERENCES [dim].[Entity] ([PK_Entity]),
    CONSTRAINT [FK_TechnicalResult_Location] FOREIGN KEY ([FK_Location]) REFERENCES [dim].[Location] ([PK_Location]),
    --CONSTRAINT [FK_TechnicalResult_Policy] FOREIGN KEY ([FK_Policy]) REFERENCES [dim].[Policy] ([PK_Policy]),
	CONSTRAINT [FK_TechnicalResult_PolicySection] FOREIGN KEY ([FK_PolicySection]) REFERENCES [dim].[PolicySection] ([PK_PolicySection]),
    CONSTRAINT [FK_TechnicalResult_Process] FOREIGN KEY ([FK_Process]) REFERENCES [dim].[Process] ([PK_Process]),
    CONSTRAINT [FK_TechnicalResult_Product] FOREIGN KEY ([FK_Product]) REFERENCES [dim].[Product] ([PK_Product]),
    CONSTRAINT [FK_TechnicalResult_Scenario] FOREIGN KEY ([FK_Scenario]) REFERENCES [dim].[Scenario] ([PK_Scenario]),
    CONSTRAINT [FK_TechnicalResult_TriFocus] FOREIGN KEY ([FK_Trifocus]) REFERENCES [dim].[TriFocus] ([PK_TriFocus]),
    CONSTRAINT [FK_TechnicalResult_YOA] FOREIGN KEY ([FK_YOA]) REFERENCES [dim].[YOA] ([PK_YOA]),
	CONSTRAINT [FK_TechnicalResult_CatCode] FOREIGN KEY ([FK_CatCode]) REFERENCES [dim].[CatCode] ([PK_CatCode]),
	CONSTRAINT [FK_TechnicalResult_MovementType] FOREIGN KEY ([FK_MovementType]) REFERENCES [dim].[MovementType] ([PK_MovementType]),
	CONSTRAINT [FK_TechnicalResult_TrackingStatus] FOREIGN KEY ([FK_TrackingStatus]) REFERENCES [dim].[TrackingStatus] ([PK_TrackingStatus]),
	CONSTRAINT [FK_TechnicalResult_ClaimExposure] FOREIGN KEY ([FK_ClaimExposure]) REFERENCES [dim].[ClaimExposure] ([PK_ClaimExposure]),
	CONSTRAINT [FK_TechnicalResult_InceptionDate] FOREIGN KEY ([FK_InceptionDate]) REFERENCES [dim].[Date] ([PK_Date]),
	CONSTRAINT [FK_TechnicalResult_DateOfFact] FOREIGN KEY ([FK_DateOfFact]) REFERENCES [dim].[Date] ([PK_Date]),
	CONSTRAINT [FK_TechnicalResult_DataSet] FOREIGN KEY ([FK_DataSet]) REFERENCES [dim].[DataSet] ([PK_DataSet]),
	CONSTRAINT [FK_TechnicalResult_RIPolicyType] FOREIGN KEY ([FK_RIPolicyType]) REFERENCES [dim].[RIPolicyType] ([PK_RIPolicyType]),
	CONSTRAINT [FK_TechnicalResult_ProgrammeCode] FOREIGN KEY ([FK_ProgrammeCode]) REFERENCES [dim].[ProgrammeCode] ([PK_ProgrammeCode]),
	CONSTRAINT [FK_TechnicalResult_ReservingDataSet] FOREIGN KEY ([FK_ReservingDataset]) REFERENCES [dim].[ReservingDataSet] ([PK_ReservingDataSet]),
	CONSTRAINT [FK_TechnicalResult_TriangleGroup] FOREIGN KEY ([FK_TriangleGroup]) REFERENCES [dim].[TriangleGroup] ([PK_TriangleGroup]),
	CONSTRAINT [FK_TechnicalResult_SourceEntity] FOREIGN KEY ([FK_SourceEntity]) REFERENCES [dim].[Entity] ([PK_Entity]),
	CONSTRAINT [FK_TechnicalResult_DeltaType] FOREIGN KEY ([FK_DeltaType]) REFERENCES [dim].[DeltaType] ([PK_DeltaType]),


);






GO

CREATE CLUSTERED COLUMNSTORE INDEX [CIX_FCT_TechnicalResult]
 ON [fct].[TechnicalResult];
GO
CREATE NONCLUSTERED INDEX [IX_TechnicalResult_FK_Account]
ON [fct].[TechnicalResult] ([FK_Account] ASC) WITH (FILLFACTOR = 90);
Go

CREATE NONCLUSTERED INDEX [IX_TechnicalResult_FK_AccountingPeriod]
ON [fct].[TechnicalResult] ([FK_AccountingPeriod] ASC) WITH (FILLFACTOR = 90)   ;
Go

CREATE NONCLUSTERED INDEX [IX_TechnicalResult_FK_DataSet] 
ON [fct].[TechnicalResult] ([FK_DataSet] ASC) WITH (FILLFACTOR = 90);
GO

CREATE NONCLUSTERED INDEX [IX_TechnicalResult_FK_Process] 
ON [fct].[TechnicalResult] ([FK_Process]ASC) WITH (FILLFACTOR = 90);
GO

CREATE NONCLUSTERED INDEX [IX_TechnicalResult_FK_ClaimExposure] 
ON [fct].[TechnicalResult] ([FK_ClaimExposure] ASC) WITH (FILLFACTOR = 90);
GO

CREATE NONCLUSTERED INDEX [IX_TechnicalResult_FK_PolicySection] 
ON [fct].[TechnicalResult] ([FK_PolicySection] ASC) WITH (FILLFACTOR = 90);
