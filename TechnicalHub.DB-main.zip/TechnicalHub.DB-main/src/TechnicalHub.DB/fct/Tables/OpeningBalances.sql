﻿CREATE TABLE [fct].[OpeningBalances] (
    [FK_BatchRun]         INT             NOT NULL,
    [FK_DataSet]          VARCHAR (10)    NOT NULL,
    [TreeNode]            VARCHAR (20)    NOT NULL,
    [FK_AccountingPeriod] VARCHAR (6)     NULL,
    [UnitOfAccount]       VARCHAR (2000)  NOT NULL,
    [BalanceValue]        DECIMAL (18, 5) NOT NULL
);

