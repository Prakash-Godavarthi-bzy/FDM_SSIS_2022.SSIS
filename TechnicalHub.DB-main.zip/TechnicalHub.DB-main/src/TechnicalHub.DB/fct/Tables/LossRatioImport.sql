﻿CREATE TABLE [fct].[LossRatioImport] (
    [LossRatioType]        NVARCHAR (20)   NOT NULL,
    [AccountingYearQuater] NVARCHAR (10)   NULL,
    [Trifocus]             NVARCHAR (100)  NULL,
    [YOA]                  NVARCHAR (128)  NULL,
    [LossRatio]            NUMERIC (18, 5) NULL
);

