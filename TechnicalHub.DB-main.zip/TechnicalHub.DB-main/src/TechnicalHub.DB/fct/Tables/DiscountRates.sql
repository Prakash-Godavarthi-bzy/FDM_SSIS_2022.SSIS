﻿CREATE TABLE [fct].[DiscountRate](
	[PK_DiscountRates] [bigint] IDENTITY(1,1) NOT NULL,
	[FK_Batch] [int] NOT NULL,
	[AsAtDate] [date] NOT NULL,
	[DiscountRateName] [varchar](255) NOT NULL,
	[DiscountRateKey] [varchar](50) NOT NULL,
	[DataSet] [varchar](50) NOT NULL,
	[SettlementCCY] [varchar](3) NOT NULL,
	[CumulativeDevelopmentPercentage] [numeric](19, 6) NOT NULL,
	[DevelopmentYear] [int] NOT NULL,
	[AssumptionDatasetName] [varchar](35) NOT NULL,
	[AuditSourceBatchID] [varchar](510) NOT NULL,
	[AuditCreateDateTime] [datetime2](7) NOT NULL,
	[AuditGenerateDateTime] [datetime2](7) NOT NULL,
	[AuditUserCreate] [varchar](510) NOT NULL,

 CONSTRAINT [PK_DiscountRates] PRIMARY KEY CLUSTERED 
(
	[PK_DiscountRates] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO


