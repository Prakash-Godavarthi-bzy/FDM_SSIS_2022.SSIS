﻿CREATE TABLE [fct].[Pattern] (
    [PK_Pattern]                     BIGINT           IDENTITY (1, 1) NOT NULL,
    [FK_Batch]                       INT              NOT NULL,
    [FK_DataSet]                     BIGINT			  NULL,
    [FK_PatternName]                 BIGINT			  NOT NULL,
    [FK_Trifocus]                    BIGINT			  NOT NULL,
    [FK_YOA]                         BIGINT           NOT NULL,
    [FK_InceptionYear]               INT              NOT NULL,
    [FK_CCYSettlement]               BIGINT		      NOT NULL,
    [FK_AccountingPeriod]            BIGINT           NOT NULL,
    [DevelopmentQuarter]             INT              NOT NULL,
    [PatternScenario]                VARCHAR (10)     NOT NULL,
    [PatternScenarioVersion]         INT              NOT NULL,
    [DevelopmentPercentageIncrement] NUMERIC (38, 10) NOT NULL,
	[DevelopmentPercentageCumulative] NUMERIC (38, 10) NULL,
	[TDH_DatasetName]				 VARCHAR(35) NULL,
    [AuditSourceBatchID]             VARCHAR (510)    NOT NULL,
    [AuditCreateDateTime]            DATETIME2 (7)    NOT NULL DEFAULT (getutcdate()),
    [AuditGenerateDateTime]          DATETIME2 (7)    NOT NULL,
    [AuditUserCreate]                VARCHAR (510)    NOT NULL DEFAULT (suser_sname()),
    CONSTRAINT [PK_Pattern] PRIMARY KEY CLUSTERED ([PK_Pattern] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_Pattern_AccountingPeriod] FOREIGN KEY ([FK_AccountingPeriod]) REFERENCES [dim].[AccountingPeriod] ([PK_AccountingPeriod]),
    CONSTRAINT [FK_Pattern_CCYSettlement] FOREIGN KEY ([FK_CCYSettlement]) REFERENCES [dim].[CCY] ([PK_CCY]),
    CONSTRAINT [FK_Pattern_PatternName] FOREIGN KEY ([FK_PatternName]) REFERENCES [dim].[PatternName] ([PK_PatternName]),
    CONSTRAINT [FK_Pattern_TriFocus] FOREIGN KEY ([FK_Trifocus]) REFERENCES [dim].[TriFocus] ([PK_TriFocus]),
    CONSTRAINT [FK_Pattern_YOA] FOREIGN KEY ([FK_YOA]) REFERENCES [dim].[YOA] ([PK_YOA]),
	CONSTRAINT [FK_Pattern_DataSet] FOREIGN KEY ([FK_DataSet]) REFERENCES [dim].[DataSet] ([PK_DataSet])
);






GO


