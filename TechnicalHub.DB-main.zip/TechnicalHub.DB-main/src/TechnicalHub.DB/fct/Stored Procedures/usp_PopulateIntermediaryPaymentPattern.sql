﻿
-- =============================================
-- Author:		Pooja Khandual
-- Create date: 21 Dec 2020
-- Description:	This stored proc is called to populate the Intermedialy table with the Run ID data from the table stg.MappingTotransformationLog
-- =============================================
--DECLARE @RequestId  Int = 1241
--DELETE FROM fct.IntermediaryAssumptionPaymentPattern WHERE [Pk_RequestId] = 1241
-- TRUNCATE TABLE fct.IntermediaryPaymentPattern
--SELECT COUNT(*) FROM  fct.IntermediaryPaymentPattern
--DROP PROCEDURE fct.usp_PopulateIntermediaryPaymentPattern
-- EXECUTE [fct].[usp_PopulateIntermediaryPaymentPattern] 



CREATE PROCEDURE [fct].[usp_PopulateIntermediaryPaymentPattern] @RequestId INT, @ScheduleRunType Varchar(10)
AS
BEGIN

	SET NOCOUNT ON;
	EXECUTE [fct].[usp_Populate_AllWBCommitted] 'PP'
BEGIN

		WITH UNPIVOT_DATA AS
		(

		SELECT [Pk_RequestId], DatasetName, ColumnName
		FROM [stg].[MappingTotransformationLog] 
		UNPIVOT (
			DatasetName FOR ColumnName IN (
			   [Pattern Scenario]
			  ,[Payment Pattern Claims]
			)
		) unpvt
		WHERE 
		--[Pk_RequestId] > (SELECT MAX([Pk_RequestId]) FROM fct.IntermediaryPaymentPattern)
		[Pk_RequestId]=@RequestId AND
		ScheduleRunType=@ScheduleRunType
		)

		,TABLE_1 AS
		(
		SELECT T1.Pk_RequestId, T2.Pk_AssumptionDatasetNameId, T1.ColumnName,T2.AssumptionPercentageTypeId
		FROM UNPIVOT_DATA T1
		INNER JOIN dim.AssumptionDatasets T2 ON T1.DatasetName = T2.AssumptionDatasetName
		)
		--SELECT * FROM TABLE_1
		----------INSERT PP DATA

		INSERT INTO fct.IntermediaryPaymentPattern
		SELECT  DISTINCT
				  T1.Pk_RequestId
				, T2.Pk_AssumptionDatasetNameId AS DatasetNameId
				, T3.Pk_AssumptionPercentageTypeId AS PercentageTypeId
				, T5.Pk_AssumptionPercentageSubTypeId AS LossType
				, T4.TriFocus AS Trifocus
				, T4.PP_DevelopmentQuarter DevelopmentQuarter
				, CAST(T4.Value AS DECIMAL(38,10)) PaymentPerc
		FROM TABLE_1 T1
		INNER JOIN dim.AssumptionDatasets T2 ON T1.Pk_AssumptionDatasetNameId  = T2.Pk_AssumptionDatasetNameId
		INNER JOIN dim.AssumptionPercentageType T3 ON T1.AssumptionPercentageTypeId = T3.Pk_AssumptionPercentageTypeId
		INNER JOIN ( SELECT Pk_AssumptionDatasetNameId
		                    ,Pk_AssumptionPercentageTypeId
							,PK_LossType
							,TriFocus
							,PP_DevelopmentQuarter
							,[Value]
					FROM FCT.All_WB_Committed
					WHERE WB_TYPE = 'PP'
					UNION ALL
					(SELECT DS.Pk_AssumptionDatasetNameId
					       ,DS.AssumptionPercentageTypeId
						   ,CASE LEFT(FK_PatternName, 1) WHEN 'C' THEN 'PPC' ELSE 'PPP' END AS PK_LossType
						   ,fp.FK_Trifocus
						   ,fp.DevelopmentQuarter
						   ,fp.DevelopmentPercentageCumulative 
				    FROM fct.Pattern fp
					INNER JOIN dim.AssumptionDatasets DS ON fp.TDH_DatasetName = DS.AssumptionDatasetName)
					) T4 ON T2.Pk_AssumptionDatasetNameId = T4.Pk_AssumptionDatasetNameId AND T2.AssumptionPercentageTypeId = T4.Pk_AssumptionPercentageTypeId		INNER JOIN  dim.AssumptionPercentageSubType T5 ON T4.PK_LossType = T5.LossType
		WHERE 
		1 = 1
END



END