

Create Procedure [fct].[usp_Load_WB_Fx Rate V2](@yearMonth Varchar(30),@YearMn Varchar(20))
AS

--eXeC fct.usp_Load_AsumptionDatsets 'january2021'
-- =============================================
-- Author:		Krishna
-- Create date: 25-01-2021
-- Description:	This stored proc inserts data into WB_Fx Rate V2 table
-- =============================================



Begin

Declare @yearandmonthAv varchar(30)
Declare @yearandmonthSp varchar(30)

select @yearandmonthAv='SYS'+' ' +CAst(CAST(RAND(CHECKSUM(NEWID()))*100 as int) as varchar)+' '+@yearMonth+'AGRAvg'
select @yearandmonthSp='SYS'+' ' +CAst(CAST(RAND(CHECKSUM(NEWID()))*100 as int) as varchar)+' '+@yearMonth+'AGRSpot'



Declare @AssDtIDAv int
Declare @AssPTyIDAv int


Declare @AssDtIDSp int
Declare @AssPTyIDSp int



IF EXISTS(SELECT distinct fk_TransactionCurrency
		from fct.FXRate
		where fk_AccountingPeriod=@YearMn
		and fk_TransactionCurrency not in (Select distinct [BK_CCY] from dim.CCY)
		)
	BEGIN


	DROP TABLE IF EXISTS #CCY
			
		SELECT distinct fk_TransactionCurrency into #CCY
		from fct.FXRate
		where fk_AccountingPeriod=@YearMn
		and fk_TransactionCurrency not in (Select distinct [BK_CCY] from dim.CCY)

		INSERT INTO DIM.CCY([BK_CCY],CCYNAME)  (SELECT fk_TransactionCurrency,fk_TransactionCurrency From #CCY)

END


Select @AssDtIDAv= Pk_AssumptionDataSetNameID,@AssPTyIDAv= AssumptionPercentageTypeId From  dim.AssumptionDatasets Where
AssumptionDataSetName=@yearandmonthAv


Select @AssDtIDSp= Pk_AssumptionDataSetNameID,@AssPTyIDSp= AssumptionPercentageTypeId From  dim.AssumptionDatasets Where
AssumptionDataSetName=@yearandmonthSp

INSERT INTO dbo.[WB_Fx Rate V2]
		([FXRate_0],[Pk_AssumptionDatasetNameId_1],[Pk_AssumptionPercentageTypeId_2],[PK_LossType_3]
      ,[PK_ReportingCurrencyCode_4]
      ,[PK_CCY_5]
      ,[MS_AUDIT_TIME_6]
      ,[MS_AUDIT_USER_7]
    --  ,[ValidFrom]
   --   ,[ValidTo]
	  )
SELECT Sum(FXrate),@AssDtIDAv,@AssPTyIDAv,Case when FxRateName ='Average' Then 'FXA' When FXRateName='Spot' Then 'FXS' else NULL end as LOSS_TYPE,fK_ReportingCurrencyCode,fk_TransactionCurrency
		
		,GETDATE()
		,SUSER_SNAME()
		from fct.FXRate
		where fk_AccountingPeriod=@YearMn and FXRateName='Average'
		group by fk_Batch,FXRateName,fk_ReportingCurrencyCode,fk_TransactionCurrency




INSERT INTO dbo.[WB_Fx Rate V2]
		([FXRate_0],[Pk_AssumptionDatasetNameId_1],[Pk_AssumptionPercentageTypeId_2],[PK_LossType_3]
      ,[PK_ReportingCurrencyCode_4]
      ,[PK_CCY_5]
      ,[MS_AUDIT_TIME_6]
      ,[MS_AUDIT_USER_7]
    --  ,[ValidFrom]
   --   ,[ValidTo]
	  )
SELECT Sum(FXrate),@AssDtIDSp,@AssPTyIDSp,Case when FxRateName ='Average' Then 'FXA' When FXRateName='Spot' Then 'FXS' else NULL end as LOSS_TYPE,fK_ReportingCurrencyCode,fk_TransactionCurrency
		
		,GETDATE()
		,SUSER_SNAME()
		from fct.FXRate
		where fk_AccountingPeriod=@YearMn and FXRateName='Spot'
		group by fk_Batch,FXRateName,fk_ReportingCurrencyCode,fk_TransactionCurrency
		

	

End