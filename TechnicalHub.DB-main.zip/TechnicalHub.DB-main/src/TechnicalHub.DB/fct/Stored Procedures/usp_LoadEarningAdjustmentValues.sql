﻿
/*=======================================================================================================

=======================================================================================================*/
CREATE   PROCEDURE [fct].[usp_LoadEarningAdjustmentValues]
AS
BEGIN

;WITH EarnAdjustment AS (
SELECT		tr.FK_Batch			AS FK_Batch
		,		tr.FK_DataSet	AS FK_DataSet
		,		tr.FK_Scenario	AS FK_Scenario
		,		tr.FK_Account	AS FK_Account
		,		ec.pk_Period	AS pk_Period
		,		tr.FK_Basis		AS FK_Basis
		,		tr.FK_DataStage AS FK_DataStage
		,		tr.FK_Entity	AS FK_Entity
		,		tr.FK_Policy	AS FK_Policy
		,		tr.FK_PolicySection AS FK_PolicySection
		,		'IA'			AS BK_Process
		,		tr.FK_Product	AS FK_Product
		,		tr.FK_Location	AS  FK_Location
		,		tr.FK_Trifocus	AS FK_Trifocus
		,		tr.FK_YOA		AS FK_YOA
		,		tr.FK_Allocation AS FK_Allocation
		,		tr.[FK_CCYOriginal]	 AS CCYOriginal
		,		tr.[FK_CCYSettlement] AS CCYSettlement
		,		tr.[FK_DateDue]  AS [FK_DateDue]
		,		CAST(tr.Value * ec.EarningValue AS DECIMAL(18, 4)) AS [Value]
		,		ec.EarningValue	 AS EarningValue
		,		tr.Fk_statscode AS Fk_statscode
		,		tr.RowHash		AS RowHash
		,		tr.AuditSourceBatchID AS AuditSourceBatchID
		,		tr.AuditUserCreate	 AS AuditUserCreate
		,		GETDATE()			 AS AuditCreateDateTime
		,		GETDATE()			AS AuditGenerateDateTime
		,		InceptionPeriod		AS InceptionPeriod
		,		FK_CatCode			AS FK_CatCode
		,		[FK_MovementType]   AS [FK_MovementType]
		,		[FK_TrackingStatus] AS [FK_TrackingStatus]
		,		[FK_ClaimExposure]  AS [FK_ClaimExposure]
		,		[FK_DateOfFact]		AS [FK_DateOfFact]
		,		[BusinessKey]		AS [BusinessKey]
		,		FK_InceptionDate	AS FK_InceptionDate
		FROM	fct.TechnicalResult tr
		LEFT JOIN	Dim.PolicySection PS ON PS.PK_PolicySection=tr.FK_PolicySection		--++
		JOIN	stg.EarningBatchFilter bf		ON	bf.PK_FTH = tr.PK_FTH
		JOIN	stg.EarningPercentage ec		ON	tr.FK_Policy = ec.FK_Policy			----
												--AND   PS.BK_PolicySection=EC.FK_Policy   --++
												AND   PS.BK_PolicySection=EC.FK_PolicySection   --++
												AND ec.FK_earningPAttern = bf.FK_earningPAttern
												AND ec.EarningValue IS NOT NULL
		WHERE	ec.FK_earningPAttern = 'TA'
)
		INSERT	stg.fct_TechnicalResult WITH (TABLOCK)(	FK_Batch, FK_DataSet, FK_Scenario, FK_Account, FK_AccountingPeriod, FK_Basis, FK_DataStage, FK_Entity, FK_Policy,FK_PolicySection
														,FK_Process, FK_Product, FK_Location, FK_Trifocus, FK_YOA, FK_Allocation, [FK_CCYOriginal], [FK_CCYSettlement], [FK_DateDue], Value, EarningPercentage,Fk_statscode,
														RowHash, AuditSourceBatchID, AuditUserCreate, AuditCreateDateTime, AuditGenerateDateTime,
														 InceptionPeriod,FK_CatCode,[FK_MovementType],[FK_TrackingStatus],[FK_ClaimExposure],[FK_DateOfFact],[BusinessKey],FK_InceptionDate
														)
		SELECT	 FK_Batch
		,FK_DataSet
		,FK_Scenario
		,FK_Account
		,pk_Period
		,FK_Basis
		,FK_DataStage
		,FK_Entity
		,FK_Policy
		,FK_PolicySection
		,ISNULL(DP.PK_Process,-1) AS FK_Process
		,FK_Product
		,FK_Location
		,FK_Trifocus
		,FK_YOA
		,FK_Allocation
		,[CCYOriginal]
		,[CCYSettlement]
		,[FK_DateDue]
		,[Value]
		,EarningValue
		,Fk_statscode
		,RowHash
		,EA.AuditSourceBatchID 
		,EA.AuditUserCreate
		,EA.AuditCreateDateTime
		,AuditGenerateDateTime
		,InceptionPeriod
		,FK_CatCode
		,[FK_MovementType]
		,[FK_TrackingStatus]
		,[FK_ClaimExposure]
		,[FK_DateOfFact]
		,[BusinessKey]
		,FK_InceptionDate
FROM	EarnAdjustment EA
LEFT JOIN DIM.Process DP ON DP.BK_Process=EA.BK_Process
		
		RAISERROR('stg.fct_TechnicalResult: %i', 0, 0, @@rowcount) WITH NOWAIT;

		--IF EXISTS	(
		--				SELECT	'earning', tr.FK_Policy, CAST(SUM(tr.Value) AS DECIMAL(18, 2)) FROM	stg.fct_TechnicalResult tr GROUP BY tr.FK_Policy
		--				EXCEPT	
		--				SELECT	'earning', tr.FK_Policy, CAST(SUM(tr.Value) AS DECIMAL(18, 2))
		--				FROM	fct.TechnicalResult tr
		--				JOIN	stg.EarningBatchFilter bf ON bf.PK_FTH = tr.PK_FTH
		--				GROUP BY tr.FK_Policy
		--				UNION	ALL
		--				SELECT	'Premium', tr.FK_Policy, CAST(SUM(tr.Value) AS DECIMAL(18, 2))
		--				FROM	fct.TechnicalResult tr
		--				JOIN	stg.EarningBatchFilter bf ON bf.PK_FTH = tr.PK_FTH
		--				GROUP BY tr.FK_Policy
		--				EXCEPT	
		--				SELECT	'Premium', tr.FK_Policy, CAST(SUM(tr.Value) AS DECIMAL(18, 2)) FROM	stg.fct_TechnicalResult tr GROUP BY tr.FK_Policy
		--				--ORDER BY fk_policy
		--			)
		--RAISERROR	('!!!!!!!!!!!!!!!!!!!!!!!!!!Total premium doesn''t equal total earnings!!!!!!!!!!!!!!!!!!!!!!!!!!', 16, 0)

		EXEC fct.usp_MergeTechnicalResult
END