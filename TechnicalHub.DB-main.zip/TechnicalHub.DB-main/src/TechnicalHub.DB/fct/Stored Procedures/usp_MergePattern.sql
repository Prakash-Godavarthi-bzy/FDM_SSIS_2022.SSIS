﻿/*====================================================================================================
Is:		fct.MergePattern
Does:	Loads fact data from associated staging table
====================================================================================================*/
CREATE PROCEDURE fct.[usp_MergePattern]
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Create new fact records
			INSERT		fct.Pattern WITH (TABLOCK) (FK_Batch, FK_DataSet, FK_PatternName, FK_Trifocus, FK_YOA, FK_InceptionYear, CCYSettlement, FK_AccountingPeriod, DevelopmentQuarter, PatternScenario, PatternScenarioVersion, DevelopmentPercentageIncrement, AuditSourceBatchID, AuditCreateDateTime, AuditGenerateDateTime, AuditUserCreate)
			SELECT		stg.FK_Batch,
						stg.FK_DataSet,
						stg.FK_PatternName,
						stg.FK_Trifocus,
						stg.FK_YOA,
						stg.FK_InceptionYear,
						stg.CCYSettlement,
						stg.FK_AccountingPeriod,
						stg.DevelopmentQuarter,
						stg.PatternScenario,
						stg.PatternScenarioVersion,
						stg.DevelopmentPercentageIncrement,
						stg.AuditSourceBatchID,
						stg.AuditCreateDateTime,
						stg.AuditGenerateDateTime,
						stg.AuditUserCreate
			FROM		stg.fct_Pattern stg	
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END