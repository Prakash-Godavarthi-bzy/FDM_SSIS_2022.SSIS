﻿
-- =============================================
-- Author:		Pooja Khandual
-- Create date: 08-01-2021
-- Description:	This stored proc pulls datasets that have been committed in a run from the Writeback tables into a single repository
-- =============================================
CREATE PROCEDURE [fct].[usp_Populate_AllWBCommitted] @WB_Type Nvarchar(5)
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	SET NOCOUNT ON;

	DROP TABLE IF EXISTS #Dataset_Committed

	BEGIN
	SELECT 
		  T1.Pk_AssumptionDatasetNameId
		  ,T1.AssumptionPercentageTypeId
	      , CASE 
				WHEN T3.AssumptionPercentageType  = 'Discount Rate' THEN 'DR'
				WHEN T3.AssumptionPercentageType  in ('Payment Pattern','Payment Pattern Claims') THEN 'PP'     -- need to change for claims and Premiums
				WHEN T3.AssumptionPercentageType  IN ('FX Rate (Average)','FX Rate (Spot)') THEN 'FX'
				ELSE 'AD'
			END AssumptionDatasetType
	INTO #Dataset_Committed
	FROM dim.AssumptionDatasets T1
	LEFT JOIN [fct].[All_WB_Committed] T2 ON T1.Pk_AssumptionDatasetNameId = T2.Pk_AssumptionDatasetNameId 
										  AND T1.AssumptionPercentageTypeId = T2.Pk_AssumptionPercentageTypeId
	INNER JOIN dIM.AssumptionPercentageType T3 ON T1.AssumptionPercentageTypeId = T3.Pk_AssumptionPercentageTypeId
	WHERE 
	1 = 1
	AND IsDatasetAlreadyUsed = 1
	AND T2.Pk_AssumptionDatasetNameId IS NULL
	

    -- Insert statements for procedure here
   IF @WB_Type = 'FX'
		BEGIN
		INSERT INTO [fct].[All_WB_Committed]([WB_TYPE],[Pk_AssumptionDatasetNameId],[Pk_AssumptionPercentageTypeId],[PK_LossType],[FX_ReportingCurrencyCode_4],[CCY],[Value])
		SELECT  DISTINCT
				  T1.AssumptionDatasetType
				, T1.Pk_AssumptionDatasetNameId
				, T1.AssumptionPercentageTypeId
				, T4.PK_LossType_3 LossType
				, T4.PK_ReportingCurrencyCode_4 AS ReportingCurrency
				, T4.PK_CCY_5 as TransactionCurrency
				, T4.FXRate_0
		FROM #Dataset_Committed T1
		INNER JOIN dim.AssumptionDatasets T2 ON T1.Pk_AssumptionDatasetNameId  = T2.Pk_AssumptionDatasetNameId
		INNER JOIN dim.AssumptionPercentageType T3 ON T1.AssumptionPercentageTypeId = T3.Pk_AssumptionPercentageTypeId
		INNER JOIN dbo.[WB_FX Rate V2] T4 ON T1.Pk_AssumptionDatasetNameId = T4.Pk_AssumptionDatasetNameId_1 AND T1.AssumptionPercentageTypeId= T4.Pk_AssumptionPercentageTypeId_2
		WHERE T1.AssumptionDatasetType = 'FX'

		DELETE WB
		FROM dbo.[WB_FX Rate V2] AS WB
		INNER JOIN #Dataset_Committed AS DC ON WB.Pk_AssumptionDatasetNameId_1 = DC.Pk_AssumptionDatasetNameId
											AND WB.Pk_AssumptionPercentageTypeId_2 = DC.AssumptionPercentageTypeId
		INNER JOIN [fct].[All_WB_Committed] AS  COM ON  WB.Pk_AssumptionDatasetNameId_1= COM.Pk_AssumptionDatasetNameId 
												   AND WB.Pk_AssumptionPercentageTypeId_2 = COM.Pk_AssumptionPercentageTypeId
												   AND WB.PK_LossType_3 = COM.PK_LossType
												   AND WB.PK_CCY_5 = COM.CCY
												   AND WB.PK_ReportingCurrencyCode_4 = COM.FX_ReportingCurrencyCode_4
												   AND COM.WB_TYPE = 'FX'
		WHERE 
		1 = 1
		AND COM.Pk_AssumptionDatasetNameId IS NOT NULL
		AND DC.AssumptionDatasetType = 'FX'

		END

		
   ELSE IF @WB_Type = 'DR'
		BEGIN
		INSERT INTO [fct].[All_WB_Committed]([WB_TYPE],[Pk_AssumptionDatasetNameId],[Pk_AssumptionPercentageTypeId],[PK_LossType],[CCY],[DR_DevelopmentYear],[Value])
		SELECT  DISTINCT
				  T1.AssumptionDatasetType
				, T1.Pk_AssumptionDatasetNameId
				, T1.AssumptionPercentageTypeId
				, T4.PK_LossType_3 LossType
				, T4.PK_CCY_5 
				, T4.DevelopmentYear_4 
				, T4.DiscountRtPerc_0
		FROM #Dataset_Committed T1
		INNER JOIN dim.AssumptionDatasets T2 ON T1.Pk_AssumptionDatasetNameId  = T2.Pk_AssumptionDatasetNameId
		INNER JOIN dim.AssumptionPercentageType T3 ON T1.AssumptionPercentageTypeId = T3.Pk_AssumptionPercentageTypeId
		INNER JOIN dbo.[WB_Discount Rates] T4 ON T1.Pk_AssumptionDatasetNameId = T4.Pk_AssumptionDatasetNameId_1 AND T1.AssumptionPercentageTypeId = T4.Pk_AssumptionPercentageTypeId_2 
		WHERE T1.AssumptionDatasetType = 'DR'


		DELETE WB
		FROM dbo.[WB_Discount Rates] AS WB
		INNER JOIN #Dataset_Committed AS DC ON WB.Pk_AssumptionDatasetNameId_1 = DC.Pk_AssumptionDatasetNameId
											AND WB.Pk_AssumptionPercentageTypeId_2 = DC.AssumptionPercentageTypeId
		INNER JOIN [fct].[All_WB_Committed] AS  COM ON  WB.Pk_AssumptionDatasetNameId_1= COM.Pk_AssumptionDatasetNameId 
												   AND WB.Pk_AssumptionPercentageTypeId_2 = COM.Pk_AssumptionPercentageTypeId
												   AND WB.PK_LossType_3 = COM.PK_LossType
												   AND WB.PK_CCY_5 = COM.CCY
												   AND WB.DevelopmentYear_4 = COM.DR_DevelopmentYear
												   AND COM.WB_TYPE = 'DR'
		WHERE 
		1 = 1
		AND COM.Pk_AssumptionDatasetNameId IS NOT NULL
		AND DC.AssumptionDatasetType = 'DR'

		END

   ELSE IF @WB_Type = 'PP'
		BEGIN
		INSERT INTO [fct].[All_WB_Committed]([WB_TYPE],[Pk_AssumptionDatasetNameId],[Pk_AssumptionPercentageTypeId],[PK_LossType],[TriFocus],PP_DevelopmentQuarter,[Value])
		SELECT  DISTINCT
				  T1.AssumptionDatasetType
				, T1.Pk_AssumptionDatasetNameId
				, T1.AssumptionPercentageTypeId
				, T4.PK_LossType_4
				, T4.PK_TriFocus_1
				, T4.PK_DevelopmentQuarter_5
				, T4.DevelopmentPercentage_0
		FROM #Dataset_Committed T1
		INNER JOIN dim.AssumptionDatasets T2 ON T1.Pk_AssumptionDatasetNameId  = T2.Pk_AssumptionDatasetNameId
		INNER JOIN dim.AssumptionPercentageType T3 ON T1.AssumptionPercentageTypeId = T3.Pk_AssumptionPercentageTypeId
		INNER JOIN dbo.[WB_Payment Patterns] T4 ON T1.Pk_AssumptionDatasetNameId = T4.Pk_AssumptionDatasetNameId_2 AND T1.AssumptionPercentageTypeId = T4.Pk_AssumptionPercentageTypeId_3
		WHERE T1.AssumptionDatasetType = 'PP'


		DELETE WB
		FROM dbo.[WB_Payment Patterns] AS WB
		INNER JOIN #Dataset_Committed AS DC ON WB.Pk_AssumptionDatasetNameId_2 = DC.Pk_AssumptionDatasetNameId
											AND WB.Pk_AssumptionPercentageTypeId_3= DC.AssumptionPercentageTypeId
		INNER JOIN [fct].[All_WB_Committed] AS  COM ON  WB.Pk_AssumptionDatasetNameId_2= COM.Pk_AssumptionDatasetNameId 
												   AND WB.Pk_AssumptionPercentageTypeId_3 = COM.Pk_AssumptionPercentageTypeId
												   AND WB.PK_LossType_4 = COM.PK_LossType
												   AND WB.PK_TriFocus_1 = COM.TriFocus
												   AND WB.PK_DevelopmentQuarter_5 = COM.PP_DevelopmentQuarter
												   AND COM.WB_TYPE = 'PP'
		WHERE 
		1 = 1
		AND COM.Pk_AssumptionDatasetNameId IS NOT NULL
		AND DC.AssumptionDatasetType = 'PP'

		END

   ELSE 
		BEGIN
		INSERT INTO [fct].[All_WB_Committed]([WB_TYPE],[Pk_AssumptionDatasetNameId],[Pk_AssumptionPercentageTypeId],[PK_LossType],YOA,TriFocus,[Value])
		SELECT  DISTINCT
				  T1.AssumptionDatasetType
				, T1.Pk_AssumptionDatasetNameId
				, T1.AssumptionPercentageTypeId
				, T4.PK_LossType_5
				, T4.PK_YOA_3
				, T4.PK_TriFocus_4
				, T4.GeneralPercent_0
		FROM #Dataset_Committed T1
		INNER JOIN dim.AssumptionDatasets T2 ON T1.Pk_AssumptionDatasetNameId  = T2.Pk_AssumptionDatasetNameId
		INNER JOIN dim.AssumptionPercentageType T3 ON T1.AssumptionPercentageTypeId = T3.Pk_AssumptionPercentageTypeId
		INNER JOIN dbo.[WB_AssumptionSetPercent] T4 ON T1.Pk_AssumptionDatasetNameId = T4.Pk_AssumptionDatasetNameId_1 AND T1.AssumptionPercentageTypeId = T4.Pk_AssumptionPercentageTypeId_2
		WHERE T1.AssumptionDatasetType = 'AD'


		DELETE WB
		FROM dbo.WB_AssumptionSetPercent AS WB
		INNER JOIN #Dataset_Committed AS DC ON WB.Pk_AssumptionDatasetNameId_1 = DC.Pk_AssumptionDatasetNameId
											AND WB.Pk_AssumptionPercentageTypeId_2= DC.AssumptionPercentageTypeId
		INNER JOIN [fct].[All_WB_Committed] AS  COM ON  WB.Pk_AssumptionDatasetNameId_1= COM.Pk_AssumptionDatasetNameId 
												   AND WB.Pk_AssumptionPercentageTypeId_2 = COM.Pk_AssumptionPercentageTypeId
												   AND WB.PK_LossType_5 = COM.PK_LossType
												   AND WB.PK_TriFocus_4 = COM.TriFocus
												   AND WB.PK_YOA_3 = COM.YOA
												   AND COM.WB_TYPE = 'AD'
		WHERE 
		1 = 1
		AND COM.Pk_AssumptionDatasetNameId IS NOT NULL
		AND DC.AssumptionDatasetType = 'AD'

		END

    END



END
