﻿
CREATE PROCEDURE [fct].[usp_DeleteCSVBatchRuns] @RunToDelete INT AS

BEGIN
/*
Deletes fact rows for each unpublished run, triggered by a published flag being set.
*/

-- DECLARE VARIABLES
DECLARE @rowstogo INT;

-- UPDATE CSVRUNS TABLE TO REFLECT UNPUBLISHING
UPDATE Control.CSVRuns SET IsPublished = 0 WHERE PK_BatchRun = @RunToDelete;

-- DELETE THE ROWS FROM FACT TABLE

SET @rowstogo = 1;

WHILE @rowstogo > 0
BEGIN

	BEGIN TRANSACTION;

	DELETE TOP (2500)
	fct.OpeningBalances
	WHERE FK_BatchRun =@RunToDelete;

	SET @rowstogo = @@ROWCOUNT;

	COMMIT TRANSACTION;

END;

END;