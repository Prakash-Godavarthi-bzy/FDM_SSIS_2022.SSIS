﻿
/*====================================================================================================
Is:		[fct].[usp_TechnicalResultLTD]
Does:	Updates latest cumulative values with fct data
====================================================================================================*/

--EXEC [fct].[usp_TechnicalResultLTD_V2] 202012
--drop procedure [fct].[usp_TechnicalResultLTD]
CREATE PROCEDURE [fct].[usp_TechnicalResultLTD](@AccPer AS INT = NULL)
AS
BEGIN

   --DECLARE @AccPer AS INT = 201905
	DECLARE @MinAccPer AS INT
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
	IF @Trancount = 0 
	  BEGIN TRAN;
	  Exec IFRS17Datamart.[dbo].[usp_LogIFRS17DataMart]
													@v_ActivityMessage='[fct].[usp_TechnicalResultLTD] Proc Execution Startetd', 
													@v_ActivityStatus =1, --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName='[fct].[usp_TechnicalResultLTD]',
													@v_ActivitySSISExecutionId    = NULL,
													@V_JobId                     =Null
---If @AccPer is Null the LTD table will be truncated and populated with all Accounting Period data. 
---If @AccPer is not null then below process will take place and will append the new Accounting periods into LTD table
		IF @AccPer IS NOT NULL
			BEGIN

-----Truncate the staging tables
				--TRUNCATE TABLE [stg].[fct_TechnicalResultLTD_Step1]
				--TRUNCATE TABLE [stg].[fct_TechnicalResultLTD_Step2]
				DROP TABLE IF EXISTS #Step1
				DROP TABLE IF EXISTS #Step2

------Find the last populated Accounting Period from the LTD table
				SELECT @MinAccPer = COALESCE(MAX(FK_ACCOUNTINGPERIOD), 198001) FROM FCT.TechnicalResultLTD WHERE FK_DataSet <> ('PFT')

				DROP TABLE IF EXISTS #NewData

				SELECT DISTINCT  
					  T2.BK_PolicyNumber
					, T1.FK_Policy
					, T1.FK_Batch
					, T1.FK_Account
					, T1.FK_AccountingPeriod
					, T1.FK_Basis
					, T1.FK_Entity
					, T2.InceptionDate
					, T2.ExpiryDate
					, T1.FK_Process
					, T1.FK_Trifocus
					, T1.FK_YOA
					, T1.[FK_CCYOriginal]
					, T1.[FK_CCYSettlement]
					, T1.Fk_dataset
					, T1.FK_scenario
					, T1.FK_inceptionyear
					, t1.InceptionPeriod
					, T2.policytype
					, T1.[Value]
				INTO #NewData
				FROM FCT.TechnicalResult t1 
				INNER JOIN DIM.[Policy] t2 ON t1.FK_Policy = t2.PK_Policy 
				WHERE 1=1
				AND FK_DataSet <> ('PFT')
				AND FK_Process='IP'
				AND (FK_AccountingPeriod > @MinAccPer  AND FK_AccountingPeriod <= @AccPer) 
				--AND (FK_AccountingPeriod > 201904 AND FK_AccountingPeriod <= 201910)--@AccPer)
				--AND BK_PolicyNumber = 'T9068X18APCS'

				Exec IFRS17Datamart.[dbo].[usp_LogIFRS17DataMart]
													@v_ActivityMessage=' Data Inserted into #NewData From Fct.TechnicalResult ', 
													@v_ActivityStatus =5, --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName='[fct].[usp_TechnicalResultLTD]',
											        @v_ActivitySSISExecutionId    = NULL,
													@V_JobId                     =Null

--select count(*) from #NewData where FK_inceptionyear is null

----All the policies that are there in #Newdata, Get their last cumulative values(if exists) from the LTD table by ordering them and getting roworder = 1

		DROP TABLE IF EXISTS #RowOrder
		SELECT        T1.FK_Account
					, T1.FK_Basis
					, T1.FK_Entity
					, T1.BK_PolicyNumber
					, T1.InceptionDate
					, T1.ExpiryDate
					, T1.FK_Process
					, T1.FK_Trifocus
					, T1.FK_YOA
					, T1.FK_CCYOriginal
					, T1.FK_CCYSettlement 
					, T1.Fk_dataset
					, T1.FK_scenario
					, T1.FK_inceptionyear
					, T1.InceptionPeriod
					, T1.policytype
					, T1.FK_AccountingPeriod
					, T1.[Value]
					,ROW_NUMBER() 
						OVER (PARTITION BY 
						  T1.FK_Account, T1.FK_Basis, T1.FK_Entity, T1.BK_PolicyNumber, T1.InceptionDate, T1.ExpiryDate, T1.FK_Process, T1.FK_Trifocus, T1.FK_YOA
						, T1.FK_CCYOriginal, T1.FK_CCYSettlement, T1.Fk_dataset, T1.FK_scenario, T1.FK_inceptionyear,T1.InceptionPeriod, T1.policytype
						ORDER BY T1.FK_AccountingPeriod DESC
									)	RowOrder
		INTO #RowOrder
		FROM FCT.TechnicalResultLTD T1
		INNER JOIN #NewData T2 ON       T1.FK_Account      = T2.FK_Account
									AND T1.FK_Basis        = T2.FK_Basis
									AND T1.FK_Entity	   = T2.FK_Entity
									AND T1.BK_PolicyNumber = T2.BK_PolicyNumber
									AND T1.InceptionDate   = T2.InceptionDate
									AND T1.ExpiryDate	   = T2.ExpiryDate
									AND T1.FK_Process	   = T2.FK_Process
									AND T1.FK_Trifocus	   = T2.FK_Trifocus
									AND T1.FK_YOA		   = T2.FK_YOA
									AND T1.FK_CCYOriginal	   = T2.[FK_CCYOriginal]
									AND T1.FK_CCYSettlement   = T2.[FK_CCYSettlement]
									AND T1.Fk_dataset	   = T2.Fk_dataset
									AND T1.FK_scenario	   = T2.FK_scenario
									AND T1.FK_inceptionyear= T2.FK_inceptionyear
									AND T1.policytype	   = T2.policytype
									AND T1.InceptionPeriod = T2.InceptionPeriod


--SELECT * FROM #RowOrder

-----------------------Get the last cumulative value (RowOrder = 1) of the policies that have changed
				--INSERT INTO [stg].[fct_TechnicalResultLTD_Step1] ([New_Exe_Policy], [BK_PolicyNumber],	[FK_Account], [FK_AccountingPeriod], [FK_Basis], [FK_Entity], [InceptionDate]
				--,	[ExpiryDate],	[FK_Process],	[FK_Trifocus],	[FK_YOA],	[CCYOriginal],	[CCYSettlement], [Fk_dataset],	[FK_scenario],	[FK_inceptionyear],	[policytype],	
				--[Value]	)
				SELECT DISTINCT
					1.[New_Exe_Policy],
					lc.[BK_PolicyNumber],
					lc.[FK_Account] ,
					lc.[FK_AccountingPeriod],
					lc.[FK_Basis] ,
					lc.[FK_Entity],
					lc.[InceptionDate],
					lc.[ExpiryDate],
					lc.[FK_Process],
					lc.[FK_Trifocus],
					lc.[FK_YOA],
					lc.[FK_CCYOriginal],
					lc.[FK_CCYSettlement],
					lc.[Fk_dataset],
					lc.[FK_scenario],
					lc.[FK_inceptionyear],
					lc.InceptionPeriod,
					lc.[policytype],
					lc.[Value]
					into #Step1
				FROM #RowOrder lc 
				WHERE LC.RowOrder = 1
				Exec IFRS17Datamart.[dbo].[usp_LogIFRS17DataMart]
													@v_ActivityMessage=' Data inserted into #Step1 For RowOrder 1  ',  
													@v_ActivityStatus =5, --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName='[fct].[usp_TechnicalResultLTD]',
												    @v_ActivitySSISExecutionId    = NULL,
													@V_JobId                     =Null

----------------Populate the #Newdata in to stg table to do the LTD calculation later
				INSERT INTO #Step1([New_Exe_Policy], [BK_PolicyNumber],	[FK_Account], [FK_AccountingPeriod], [FK_Basis], [FK_Entity], [InceptionDate],	
				[ExpiryDate],	[FK_Process],	[FK_Trifocus],	[FK_YOA],	[CCYOriginal],	[CCYSettlement], [Fk_dataset],	[FK_scenario],	
				[FK_inceptionyear],	InceptionPeriod,[policytype],	[Value]	)
				SELECT 
					2.[New_Exe_Policy],
					tr.[BK_PolicyNumber],
					TR.[FK_Account] ,
					TR.[FK_AccountingPeriod],
					TR.[FK_Basis] ,
					TR.[FK_Entity],
					tr.[InceptionDate],
					tr.[ExpiryDate],
					TR.[FK_Process],
					TR.[FK_Trifocus],
					TR.[FK_YOA],
					TR.[FK_CCYOriginal],
					TR.[FK_CCYSettlement],
					TR.[Fk_dataset],
					TR.[FK_scenario],
					TR.[FK_inceptionyear],
					TR.InceptionPeriod,
					tr.[policytype],
					TR.[Value]
					FROM #NewData tr 

---- Populate the Life to date values into step2 stg table
				--INSERT INTO [stg].[fct_TechnicalResultLTD_Step2]([New_Exe_Policy],	[BK_PolicyNumber],	[FK_Account], [FK_AccountingPeriod], [FK_Basis], [FK_Entity], [InceptionDate],	
				--ExpiryDate,	[FK_Process],	[FK_Trifocus],	[FK_YOA],	[CCYOriginal],	[CCYSettlement], [Fk_dataset],	[FK_scenario],	[FK_inceptionyear],	[policytype],	[Value])
				SELECT
					  [New_Exe_Policy]
					, BK_PolicyNumber
					, FK_Account
					, FK_AccountingPeriod
					, FK_Basis
					, FK_Entity
					, InceptionDate
					, ExpiryDate
					, FK_Process
					, FK_Trifocus
					, FK_YOA
					, CCYOriginal
					, CCYSettlement
					, Fk_dataset
					, FK_scenario
					, FK_inceptionyear
					, InceptionPeriod
					, policytype
					, SUM(Value)
						OVER( PARTITION BY FK_Account
							, FK_Basis
							, FK_Entity
							, BK_PolicyNumber
							, InceptionDate
							, ExpiryDate
							, FK_Process
							, FK_Trifocus
							, FK_YOA
							, CCYOriginal
							, CCYSettlement 
							, Fk_dataset
							, FK_scenario
							, FK_inceptionyear
							, InceptionPeriod
							, policytype
							ORDER BY FK_AccountingPeriod) AS [Value]
				 INTO #Step2 
 				 FROM #Step1 

				Exec IFRS17Datamart.[dbo].[usp_LogIFRS17DataMart]
													@v_ActivityMessage=' Data inserted into #Step2 of LTD Values.',  
													@v_ActivityStatus =5, --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName='[fct].[usp_TechnicalResultLTD]',
													@v_ActivitySSISExecutionId    = NULL,
													@V_JobId                     =Null


---------------------POPULATE [fct].[TechnicalResultLTD_V2]

				INSERT INTO [fct].[TechnicalResultLTD]
				   ([BK_PolicyNumber],	[FK_Account],	[FK_Basis] ,	[FK_Entity], [InceptionDate],	[ExpiryDate],	[FK_Process], [FK_Trifocus],	[FK_YOA],	[CCYOriginal],	[CCYSettlement],
					[Fk_dataset],	[FK_scenario],	[FK_inceptionyear],InceptionPeriod,	[policytype],	[FK_AccountingPeriod],	[Value]   )
				SELECT DISTINCT
					A.[BK_PolicyNumber],
					[FK_Account] ,
					[FK_Basis] ,
					[FK_Entity],
					[InceptionDate],
					[ExpiryDate],
					[FK_Process],
					[FK_Trifocus],
					[FK_YOA],
					[CCYOriginal],
					[CCYSettlement],
					[Fk_dataset],
					[FK_scenario],
					[FK_inceptionyear],
					InceptionPeriod,
					[policytype],
					[FK_AccountingPeriod],
					[Value]
				FROM #Step2 A 
				WHERE New_Exe_Policy > 1
   		      

			Exec IFRS17Datamart.[dbo].[usp_LogIFRS17DataMart]
													@v_ActivityMessage=' Data inserted into [fct].[TechnicalResultLTD] If Ended.',  
													@v_ActivityStatus =2, --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName='[fct].[usp_TechnicalResultLTD]',
													@v_ActivitySSISExecutionId    = NULL,
													@V_JobId                     =Null

			END
			
      ELSE ---- If @AccPer is Null the LTD table will be truncated and populated with all Accounting Period data. 
			BEGIN
			Exec IFRS17Datamart.[dbo].[usp_LogIFRS17DataMart]
													@v_ActivityMessage='Else Condition Started',  
													@v_ActivityStatus =5, --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName='[fct].[usp_TechnicalResultLTD]',
												    @v_ActivitySSISExecutionId    = NULL,
													@V_JobId                     =Null
			 TRUNCATE TABLE fct.TechnicalResultLTD

			DROP TABLE IF EXISTS #PolicyWithLTD
			SELECT
				DISTINCT 
				 p.BK_PolicyNumber
				, FK_Account
				, FK_AccountingPeriod
				, FK_Basis
				, FK_Entity
				, p.InceptionDate
				, p.ExpiryDate
				, FK_Process
				, FK_Trifocus
				, FK_YOA
				, FK_CCYOriginal
				, FK_CCYSettlement
				, Fk_dataset
				, FK_scenario
				, FK_inceptionyear
				, InceptionPeriod
				, policytype
				, SUM(Value)
					OVER( PARTITION BY FK_Account
						, FK_Basis
						, FK_Entity
						, p.BK_PolicyNumber
						, p.InceptionDate
						, p.ExpiryDate
						, FK_Process
						, FK_Trifocus
						, FK_YOA
						, FK_CCYOriginal
						, FK_CCYSettlement 
						, Fk_dataset
						, FK_scenario
						, FK_inceptionyear
						, InceptionPeriod
						, policytype
						ORDER BY FK_AccountingPeriod) AS [Value]
				INTO #PolicyWithLTD
				FROM [TechnicalHub].[fct].[TechnicalResult] t 
				JOIN Dim.Policy p ON p.PK_Policy =t.FK_Policy
				WHERE 1=1
				AND FK_DataSet <> ('PFT')
				AND FK_Process='IP'


			---FINAL SELECT---
			INSERT INTO fct.TechnicalResultLTD(FK_Account,FK_Basis,BK_PolicyNumber,FK_Entity,InceptionDate , ExpiryDate , FK_Process, FK_Trifocus , FK_YOA , CCYOriginal , CCYSettlement, Fk_dataset, 
						FK_scenario , FK_inceptionyear,InceptionPeriod , policytype , [Value] , FK_AccountingPeriod)
			SELECT  
					  A.FK_Account
					, A.FK_Basis
					, A.BK_PolicyNumber
					, A.FK_Entity
					, A.InceptionDate
					, A.ExpiryDate
					, A.FK_Process
					, A.FK_Trifocus
					, A.FK_YOA
					, A.FK_CCYOriginal
					, A.FK_CCYSettlement
					, A.Fk_dataset
					, A.FK_scenario
					, A.FK_inceptionyear
					, A.InceptionPeriod
					, A.policytype
					, A.[Value]
					, A.FK_AccountingPeriod 
				FROM #PolicyWithLTD A 
			
			--WHERE T.BK_PolicyNumber IN  ('B2026C19BNPA'  ,'B7149F19ANPA')
			--AND T.FK_Entity = '2623'
			--AND T.FK_Account='P-GP-B'

			Exec IFRS17Datamart.[dbo].[usp_LogIFRS17DataMart]
													@v_ActivityMessage=' Data inserted into [fct].[TechnicalResultLTD] for Null Accounting Periods.',  
													@v_ActivityStatus =2, --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName='[fct].[usp_TechnicalResultLTD]',
													@v_ActivitySSISExecutionId    = NULL,
													@V_JobId                     =Null
			END

	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
	Exec IFRS17Datamart.[dbo].[usp_LogIFRS17DataMart]
													@v_ActivityMessage='Catch Block executed',  
													@v_ActivityStatus =4       , --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName='[fct].[usp_TechnicalResultLTD]',
													@v_ActivitySSISExecutionId    = NULL,
													@V_JobId                     =Null
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

DROP TABLE IF EXISTS #NewData;
DROP TABLE IF EXISTS #RowOrder;
DROP TABLE IF EXISTS #PolicyWithLTD;
DROP TABLE IF EXISTS #Step1;
DROP TABLE IF EXISTS #Step2;

END