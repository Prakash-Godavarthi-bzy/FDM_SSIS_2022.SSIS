﻿
-- =============================================
-- Author:		Pooja Khandual
-- Create date: 21 Dec 2020
-- Description:	This stored proc is called to populate the Intermedialy table with the Run ID data from the table stg.MappingTotransformationLog
-- =============================================
--DECLARE @RequestId  Int = 1241
--DELETE FROM fct.IntermediaryAssumptionDiscountRt WHERE [Pk_RequestId] = 1241
-- TRUNCATE TABLE fct.IntermediaryDiscountRt
--SELECT COUNT(*) FROM  fct.IntermediaryDiscountRt
--DROP PROCEDURE fct.usp_PopulateIntermediaryDiscountRt
-- EXECUTE [fct].[usp_PopulateIntermediaryDiscountRt] 

CREATE PROCEDURE [fct].[usp_PopulateIntermediaryDiscountRt] @RequestId INT,@ScheduleRunType Varchar(10)
AS

BEGIN

SET NOCOUNT ON;
EXECUTE [fct].[usp_Populate_AllWBCommitted] 'DR'

		BEGIN

		WITH UNPIVOT_DATA AS
		(

		SELECT [Pk_RequestId], DatasetName, ColumnName
		FROM [stg].[MappingTotransformationLog] 
		UNPIVOT (
			DatasetName FOR ColumnName IN (
			   [Discount Rate Q1]
			  ,[Discount Rate Q2]
			  ,[Discount Rate Q3]
			  ,[Discount Rate Q4]
			  ,[Discount Rate Q5]
			  ,[Discount Rate SM]
			)
		) unpvt
		WHERE 
		--[Pk_RequestId]  > (SELECT MAX([Pk_RequestId]) FROM fct.IntermediaryDiscountRate)
		[Pk_RequestId] =@RequestId AND
		ScheduleRunType=@ScheduleRunType
		)

		,TABLE_1 AS
		(
		SELECT T1.Pk_RequestId, T2.Pk_AssumptionDatasetNameId, T1.ColumnName,T2.AssumptionPercentageTypeId
		FROM UNPIVOT_DATA T1
		INNER JOIN dim.AssumptionDatasets T2 ON T1.DatasetName = T2.AssumptionDatasetName
		)
		--SELECT * FROM TABLE_1
		----------INSERT DiscountRt DATA

		INSERT INTO fct.IntermediaryDiscountRate
		SELECT  DISTINCT
				  T1.Pk_RequestId
				, T2.Pk_AssumptionDatasetNameId AS DatasetNameId
				, T3.Pk_AssumptionPercentageTypeId AS PercentageTypeId
				, T5.Pk_AssumptionPercentageSubTypeId AS LossType
				, T4.CCY AS Currency
				, T4.DR_DevelopmentYear DevelopmentYear
				, CASE WHEN CHARINDEX('Q', T1.ColumnName COLLATE  latin1_general_cs_as) = 0 
					   THEN 'SM' 
					   ELSE SUBSTRING(T1.ColumnName, CHARINDEX('Q', T1.ColumnName COLLATE  latin1_general_cs_as), 2) 
				   END Quarters
				, CAST(T4.[Value] AS DECIMAL(19,10)) DiscountRt
		FROM TABLE_1 T1
		INNER JOIN dim.AssumptionDatasets T2 ON T1.Pk_AssumptionDatasetNameId  = T2.Pk_AssumptionDatasetNameId
		INNER JOIN dim.AssumptionPercentageType T3 ON T1.AssumptionPercentageTypeId = T3.Pk_AssumptionPercentageTypeId
		INNER JOIN ( SELECT Pk_AssumptionDatasetNameId
		                    ,Pk_AssumptionPercentageTypeId
							,PK_LossType
							,CCY
							,DR_DevelopmentYear
							,[Value]
					FROM FCT.All_WB_Committed
					WHERE WB_TYPE = 'DR'
					UNION ALL
					(SELECT DS.Pk_AssumptionDatasetNameId,DS.AssumptionPercentageTypeId, 'DR' as PK_LossType,DR.SettlementCCY,DR.DevelopmentYear,DR.CumulativeDevelopmentPercentage from fct.DiscountRate DR
					Inner Join dim.AssumptionDatasets DS ON DR.AssumptionDatasetName =DS.AssumptionDatasetName)) 
					T4 ON T2.Pk_AssumptionDatasetNameId = T4.Pk_AssumptionDatasetNameId AND T2.AssumptionPercentageTypeId = T4.Pk_AssumptionPercentageTypeId
		INNER JOIN  dim.AssumptionPercentageSubType T5 ON T4.PK_LossType = T5.LossType
		WHERE 
		1 = 1
	END

	

END