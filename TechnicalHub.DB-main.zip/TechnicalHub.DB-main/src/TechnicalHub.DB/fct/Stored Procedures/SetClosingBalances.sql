﻿CREATE PROCEDURE fct.SetClosingBalances @PublishedRun INT
AS
	BEGIN

		--DECLARE VARIABLES
		DECLARE @CurrentTS VARCHAR(20);

		--POPULATE VARIABLES
		SELECT
			@CurrentTS = CONVERT(CHAR(8), GETDATE(), 112)+REPLACE(CONVERT(CHAR(12),GETDATE(),114),':','');

-- Add an Opening Balance control run for set to be duplicated
		INSERT	Control.CSVRuns (FK_DataSet, BatchRunTS, IsPublished, AuthorisedBy)
		VALUES
			(
				'OB'			-- FK_DataSet - varchar(10)
			  , @CurrentTS
			  , 1	-- IsPublished - bit
			  , 'SYS'			-- AuthorisedBy - varchar(50)
			);

-- Create a duplicate set of facts to the Closing Balance run for the new opening balance data run created above'
		WITH MaxRun
		AS (SELECT MAX (PK_BatchRun) PK_BatchRun FROM Control  .CSVRuns)
		INSERT INTO fct.OpeningBalances
			(
				FK_BatchRun
			  , FK_DataSet
			  , TreeNode
			  , FK_AccountingPeriod
			  , UnitOfAccount
			  , BalanceValue
			)
					SELECT
							MR.PK_BatchRun
						  , 'OB'
						  , OB.TreeNode
						  , '2020Q1'
						  , OB.UnitOfAccount
						  , OB.BalanceValue
					FROM	MaxRun MR
						  , fct.OpeningBalances OB
					WHERE
							OB.FK_BatchRun = @PublishedRun;

-- Set the published run to be a Closing Balance run

		UPDATE
			Control.CSVRuns
		SET
			FK_DataSet = 'CB', IsPublished =1, AuthorisedBy = 'SYS_APPROVER'
		WHERE
			PK_BatchRun = @PublishedRun;

		UPDATE 
			fct.OpeningBalances
			SET FK_DataSet = 'CB' WHERE FK_BatchRun = @PublishedRun;

	END;