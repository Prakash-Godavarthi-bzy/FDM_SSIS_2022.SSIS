﻿
/*====================================================================================================
Is:		[fct].[usp_TechnicalResultLTD_V2]
Does:	Updates latest cumulative values with fct data
====================================================================================================*/

--EXEC [fct].[usp_TechnicalResultLTD_PFT] 201906
--DELETE FROM FCT.TechnicalResultLTD_V2 WHERE Fk_dataset = 'PFT'
CREATE PROCEDURE [fct].[usp_TechnicalResultLTD_PFT](@AccPer AS INT = NULL)
AS
BEGIN
	--DECLARE @AccPer AS INT = 201905
	DECLARE @MinAccPer AS INT
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
	IF @Trancount = 0 
	  BEGIN TRAN;

	    Exec IFRS17Datamart.[dbo].[usp_LogIFRS17DataMart]
													@v_ActivityMessage='[fct].[usp_TechnicalResultLTD_PFT] Proc Execution Startetd', 
													@v_ActivityStatus =1, --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName='[fct].[usp_TechnicalResultLTD_PFT]',
													@v_ActivitySSISExecutionId    = NULL,
													@V_JobId                     =Null
		
		IF @AccPer IS NOT NULL
			BEGIN

				SELECT @MinAccPer = COALESCE(MAX(FK_ACCOUNTINGPERIOD), 198001) FROM FCT.TechnicalResultLTD WHERE Fk_dataset = 'PFT'

				DROP TABLE IF EXISTS #NewData

				SELECT DISTINCT  
					  T2.BK_PolicyNumber
					, T3.AsAt BatchDate
					, T1.FK_Account
					, T1.FK_AccountingPeriod
					, T1.FK_Basis
					, T1.FK_Entity
					, T2.InceptionDate
					, T2.ExpiryDate
					, T1.FK_Process
					, T1.FK_Trifocus
					, T1.FK_YOA
					, T1.[FK_CCYOriginal]
					, T1.[FK_CCYSettlement]
					, T1.Fk_dataset
					, T1.FK_scenario
					, T1.FK_inceptionyear
					, T1.InceptionPeriod
					, T2.policytype
					, T1.[Value]
				INTO #NewData
				FROM FCT.TechnicalResult t1 
				INNER JOIN DIM.[Policy] t2 ON t1.FK_Policy = t2.PK_Policy 
				INNER JOIN FinanceDataContract.Inbound.BatchQueue T3 ON T1.FK_Batch = T3.Pk_Batch
				WHERE 1=1
				AND FK_DataSet IN ('PFT')
				AND FK_Process='IP'
				--and FK_YOA = 2020
				AND (T3.AsAt > @MinAccPer  AND T3.AsAt <= @AccPer)
				--AND (FK_AccountingPeriod > 201904 AND FK_AccountingPeriod <= 201910)--@AccPer)
				--AND BK_PolicyNumber = 'T9068X18APCS'

				Exec IFRS17Datamart.[dbo].[usp_LogIFRS17DataMart]
													@v_ActivityMessage=' Data Inserted into #NewData From Fct.TechnicalResult ', 
													@v_ActivityStatus =5, --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName='[fct].[usp_TechnicalResultLTD_PFT]',
											        @v_ActivitySSISExecutionId    = NULL,
													@V_JobId                     =Null

--select count(*) from #NewData where FK_inceptionyear is null

----Get the last cumulative values of the policies received between the accounting periods above

		DROP TABLE IF EXISTS #RowOrder
		SELECT        T1.FK_Account
					, T1.FK_Basis
					, T1.FK_Entity
					, T1.BK_PolicyNumber
					, T1.InceptionDate
					, T1.ExpiryDate
					, T1.FK_Process
					, T1.FK_Trifocus
					, T1.FK_YOA
					, T1.CCYOriginal
					, T1.CCYSettlement 
					, T1.Fk_dataset
					, T1.FK_scenario
					, T1.FK_inceptionyear
					, T1.policytype
					, T1.InceptionPeriod
					, T1.FK_AccountingPeriod
					, T1.[Value]
					,ROW_NUMBER() 
						OVER (PARTITION BY 
						  T1.FK_Account, T1.FK_Basis, T1.FK_Entity, T1.BK_PolicyNumber, T1.InceptionDate, T1.ExpiryDate, T1.FK_Process, T1.FK_Trifocus, T1.FK_YOA
						, T1.CCYOriginal, T1.CCYSettlement, T1.Fk_dataset, T1.FK_scenario, T1.FK_inceptionyear, T1.policytype, T1.InceptionPeriod
						ORDER BY T1.FK_AccountingPeriod DESC
									)	RowOrder
		INTO #RowOrder
		FROM FCT.TechnicalResultLTD T1 
		INNER JOIN #NewData T2 ON       T1.FK_Account      = T2.FK_Account
									AND T1.FK_Basis        = T2.FK_Basis
									AND T1.FK_Entity	   = T2.FK_Entity
									AND T1.BK_PolicyNumber = T2.BK_PolicyNumber
									AND T1.InceptionDate   = T2.InceptionDate
									AND T1.ExpiryDate	   = T2.ExpiryDate
									AND T1.FK_Process	   = T2.FK_Process
									AND T1.FK_Trifocus	   = T2.FK_Trifocus
									AND T1.FK_YOA		   = T2.FK_YOA
									AND T1.CCYOriginal	   = T2.[FK_CCYOriginal]
									AND T1.CCYSettlement   = T2.[FK_CCYSettlement]
									AND T1.Fk_dataset	   = T2.Fk_dataset
									AND T1.FK_scenario	   = T2.FK_scenario
									AND T1.FK_inceptionyear= T2.FK_inceptionyear
									AND T1.policytype	   = T2.policytype
									AND T1.InceptionPeriod = T2.InceptionPeriod
--SELECT * FROM #RowOrder

----------------Get the old policies new values from TR
		DROP TABLE IF EXISTS #Step1
				SELECT 
					2 AS [New_Exe_Policy],
					tr.[BK_PolicyNumber],
					TR.[FK_Account] ,
					TR.BatchDate AS [FK_AccountingPeriod],
					--TR.[FK_AccountingPeriod],
					TR.[FK_AccountingPeriod] AS InceptionPeriod,
					TR.[FK_Basis] ,
					TR.[FK_Entity],
					TR.[InceptionDate],
					TR.[ExpiryDate],
					TR.[FK_Process],
					TR.[FK_Trifocus],
					TR.[FK_YOA],
					TR.[FK_CCYOriginal],
					TR.[FK_CCYSettlement],
					TR.[Fk_dataset],
					TR.[FK_scenario],
					TR.[FK_inceptionyear],
					TR.[policytype],
					TR.[Value]
				INTO #Step1
				FROM #NewData tr 

-----------------------Get the last cumulative value of the policies that have changed
				INSERT INTO #Step1([New_Exe_Policy],	[BK_PolicyNumber],	[FK_Account],[FK_AccountingPeriod], InceptionPeriod, [FK_Basis], [FK_Entity], [InceptionDate],	
				ExpiryDate,	[FK_Process],	[FK_Trifocus],	[FK_YOA],	[FK_CCYOriginal],	[FK_CCYSettlement], [Fk_dataset],	[FK_scenario],	[FK_inceptionyear],	[policytype],	[Value])
				SELECT DISTINCT
					1 AS [New_Exe_Policy],
					lc.[BK_PolicyNumber],
					lc.[FK_Account] ,
					lc.[FK_AccountingPeriod],
					lc.[InceptionPeriod],
					lc.[FK_Basis] ,
					lc.[FK_Entity],
					lc.[InceptionDate],
					lc.[ExpiryDate],
					lc.[FK_Process],
					lc.[FK_Trifocus],
					lc.[FK_YOA],
					lc.[CCYOriginal],
					lc.[CCYSettlement],
					lc.[Fk_dataset],
					lc.[FK_scenario],
					lc.[FK_inceptionyear],
					lc.[policytype],
					lc.[Value]
				FROM #RowOrder lc 
				WHERE LC.RowOrder = 1

				Exec IFRS17Datamart.[dbo].[usp_LogIFRS17DataMart]
													@v_ActivityMessage='cumulative value of the changed policies',  
													@v_ActivityStatus =5, --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName='[fct].[usp_TechnicalResultLTD_PFT]',
												    @v_ActivitySSISExecutionId    = NULL,
													@V_JobId                     =Null
---Calculate Positional Total	
				DROP TABLE IF EXISTS #Step2
				SELECT
					  [New_Exe_Policy]
					, BK_PolicyNumber
					, FK_Account
					, FK_AccountingPeriod
					, InceptionPeriod
					, FK_Basis
					, FK_Entity
					, InceptionDate
					, ExpiryDate
					, FK_Process
					, FK_Trifocus
					, FK_YOA
					, [FK_CCYOriginal]
					, [FK_CCYSettlement]
					, Fk_dataset
					, FK_scenario
					, FK_inceptionyear
					, policytype
					, SUM(Value)
						OVER( PARTITION BY FK_Account
							, FK_Basis
							, FK_Entity
							, BK_PolicyNumber
							, InceptionDate
							, ExpiryDate
							, FK_Process
							, FK_Trifocus
							, FK_YOA
							, [FK_CCYOriginal]
							, [FK_CCYSettlement] 
							, Fk_dataset
							, FK_scenario
							, FK_inceptionyear
							, policytype
							, InceptionPeriod
							ORDER BY FK_AccountingPeriod ) AS [Value]
				INTO #Step2
 				FROM #Step1 T1

				Exec IFRS17Datamart.[dbo].[usp_LogIFRS17DataMart]
													@v_ActivityMessage=' Data inserted into #Step2 of LTD Values.',  
													@v_ActivityStatus =5, --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName='[fct].[usp_TechnicalResultLTD_PFT]',
													@v_ActivitySSISExecutionId    = NULL,
													@V_JobId                     =Null


---------------------POPULATE [fct].[TechnicalResultLTD_V2]

				INSERT INTO [fct].[TechnicalResultLTD]
				   ([BK_PolicyNumber],	[FK_Account],	[FK_Basis] ,	[FK_Entity], [InceptionDate],	[ExpiryDate],	[FK_Process], [FK_Trifocus],	[FK_YOA],	[CCYOriginal],	[CCYSettlement],
					[Fk_dataset],	[FK_scenario],	[FK_inceptionyear],	[policytype],	[FK_AccountingPeriod],InceptionPeriod,	[Value]   )
				SELECT
					[BK_PolicyNumber],
					[FK_Account] ,
					[FK_Basis] ,
					[FK_Entity],
					[InceptionDate],
					[ExpiryDate],
					[FK_Process],
					[FK_Trifocus],
					[FK_YOA],
					[FK_CCYOriginal],
					[FK_CCYSettlement],
					[Fk_dataset],
					[FK_scenario],
					[FK_inceptionyear],
					[policytype],
					FK_AccountingPeriod,
					InceptionPeriod,
					[Value]
				FROM #Step2 
				WHERE New_Exe_Policy > 1

				Exec IFRS17Datamart.[dbo].[usp_LogIFRS17DataMart]
													@v_ActivityMessage=' Data inserted into [fct].[TechnicalResultLTD]',  
													@v_ActivityStatus =2, --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName='[fct].[usp_TechnicalResultLTD_PFT]',
													@v_ActivitySSISExecutionId    = NULL,
													@V_JobId                     =Null

			END

	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

DROP TABLE IF EXISTS #NewData;
DROP TABLE IF EXISTS #RowOrder;
DROP TABLE IF EXISTS #Step1;
DROP TABLE IF EXISTS #Step2;


END