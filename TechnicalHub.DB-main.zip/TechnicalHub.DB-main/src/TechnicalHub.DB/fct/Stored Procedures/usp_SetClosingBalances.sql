﻿


CREATE PROCEDURE [fct].[usp_SetClosingBalances] @PublishedRun INT, @OBAccountingPeriod INT
AS
	BEGIN

		--DECLARE VARIABLES
		DECLARE @CurrentTS VARCHAR(20);
		DECLARE @ReplaceRun INT;

		--POPULATE VARIABLES
		SELECT
			@CurrentTS = CONVERT(CHAR(8), GETDATE(), 112)+REPLACE(CONVERT(CHAR(12),GETDATE(),114),':','');

-- Check if published run for OB already exists - if it does, delete it

		SELECT @ReplaceRun = COALESCE(MAX(CSV.PK_BatchRun),0) FROM fct.OpeningBalances OB JOIN Control.CSVRuns CSV ON CSV.FK_DataSet = OB.FK_DataSet 
		WHERE CSV.FK_DataSet='OB' AND OB.FK_AccountingPeriod = @OBAccountingPeriod AND CSV.IsPublished = 1

		UPDATE Control.CSVRuns SET IsPublished = 0 WHERE PK_BatchRun = @ReplaceRun


-- Add an Opening Balance control run for set to be duplicated
		INSERT	Control.CSVRuns (FK_DataSet, BatchRunTS, IsPublished, AuthorisedBy)
		VALUES
			(
				'OB'			-- FK_DataSet - varchar(10)
			  , @CurrentTS
			  , 1	-- IsPublished - bit
			  , 'SYS'			-- AuthorisedBy - varchar(50)
			);

-- Create a duplicate set of facts to the Closing Balance run for the new opening balance data run created above'
		WITH MaxRun
		AS (SELECT MAX (PK_BatchRun) PK_BatchRun FROM Control  .CSVRuns)
		INSERT INTO fct.OpeningBalances
			(
				FK_BatchRun
			  , FK_DataSet
			  , TreeNode
			  , FK_AccountingPeriod
			  , UnitOfAccount
			  , BalanceValue
			  , FK_YOA	  
			  , InceptionYear
			  , FK_Trifocus
			  , FK_Entity
			  , CCYSettlement
			  , InceptionPeriod
			  ,InceptionStatus
			  ,EarningPeriod
			)
					SELECT
							MR.PK_BatchRun
						  , 'OB'
						  , OB.TreeNode
						  , @OBAccountingPeriod
						  , OB.UnitOfAccount
						  , OB.BalanceValue
						  , OB.FK_YOA	  
						  , OB.InceptionYear
						  , OB.FK_Trifocus
						  , OB.FK_Entity
						  , OB.CCYSettlement
						  , OB.InceptionPeriod
						  ,CASE WHEN OB.InceptionPeriod > @OBAccountingPeriod THEN CAST( 'N' AS NVARCHAR)
							ELSE CAST('Y' AS NVARCHAR)
							END AS InceptionStatus
							,EarningPeriod
					FROM	MaxRun MR
						  , fct.OpeningBalances OB
					WHERE
							OB.FK_BatchRun = @PublishedRun;

-- Set the published run to be a Closing Balance run

		UPDATE
			Control.CSVRuns
		SET
			FK_DataSet = 'CB', IsPublished =1, AuthorisedBy = 'SYS_APPROVER'
		WHERE
			PK_BatchRun = @PublishedRun;

		UPDATE 
			fct.OpeningBalances
			SET FK_DataSet = 'CB' WHERE FK_BatchRun = @PublishedRun;

	END;