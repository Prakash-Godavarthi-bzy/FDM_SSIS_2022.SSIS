﻿CREATE PROC [fct].[usp_LoadTechnicalResult_BICI_BIDAC_BAIC]  
 @p_Dataset		VARCHAR(255) = NULL
,@p_BatchId		VARCHAR(255) = NULL

AS
/*=========================================================================================

This SQL Procedural Object used to generate TechnicalHub data from OutboundTransactions with Rules derived.
This Proc call by SSIS FactTechnicalResult.dtsx of TechnicalHub.SSIS

Modified By:	Entha.Bhargav@beazley.com
Modified Date:		08/01/2024
Description:	 TreatyShare Rules to create additional records from 623 share into BIDAC(8033) of given TreatySharepercentage of [MDS].[TreatyShareGenerationRules]-Populates from Static Script held at FinanceLanding.DB
				https://beazley.atlassian.net/browse/I1B-5083

Modified By:	Entha.Bhargav@beazley.com
Modified Date:		26/02/2024
Description:	 USBESI entity should run by this for Box3-4
				https://beazley.atlassian.net/browse/I1B-5080

Modified By:	Entha.Bhargav@beazley.com
Modified Date:		07/04/2024
Description:	 Remove Treaty Share rules applied part of I1B-5083 as their won't be rules for BICI, BIDAC, BAIC and USBESI

Modified By:	Entha.Bhargav@beazley.com
Modified Date:		21/10/2024
Description:	 Populate FK_SourceEntity field which should write from it's relavent Outbound record, This can be useful to understand original entity as they were confirming between box3-4 layer.
					https://beazley.atlassian.net/browse/I1B-5869
					https://beazley.atlassian.net/browse/I1B-5868

=================================================================================================*/
BEGIN
SET NOCOUNT ON;

DECLARE @Trancount	INT = @@Trancount;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;

	/*======================================================Logging Starts==================================================*/
	--DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'TechnicalHub';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= NULL;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	--DECLARE @ContractType					CHAR(3)			= 'RDEA';
	DECLARE		@p_ParentActivityLogId		BIGINT			= NULL

	DECLARE @v_Dataset varchar(50)=@v_ActivityDatabase
	DECLARE @v_BatchId                   INT             = NULL;
	DECLARE @v_BatchId_Extensions INT;



	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';

	--INSERT INTO [dbo].[Batch]([CreateDate],[DataSet]) 
	--VALUES  (GETDATE(),@v_Dataset);

	--SELECT @v_BatchId = SCOPE_IDENTITY();

	--SET @v_ActivityJobId=@v_BatchId

	/* Log the start of the insert */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'DataContract')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = @p_ActivityName
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'Load into stg.FactTechnicalResult_BICI_BIDAC_BAIC_BESI for BatchId '+@p_BatchId
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

BEGIN TRY
		IF @Trancount = 0 
			BEGIN TRAN;


if object_id('tempdb..#srctxnbbb') is not null drop table #srctxnbbb

SELECT 
		PK_Transaction
		,AsAtPeriod		= BQ.AsAt  
		,[FK_Batch]		= OT.[AuditSourceBatchID] 
		,[FK_DataSet]	= OT.[DataSet]  
		,[FK_Scenario]	= OT.[Scenario]  
		,[FK_Account]	= [Account]  
		,[FK_Basis]		= 'Estimated' 
		,[PK_DataStage]	= 2 
		,[FK_Entity]	= [Entity] 
		,[FK_DeltaType] = DeltaType  
		,BK_PolicySection = '[' + ISNULL(polsec.PolicyReference,[PolicyNumber]) + ']-'+'[' + [PolicyNumber] + ']-[' + CAST(InceptionDate AS NVARCHAR(20)) + ']-[' + CAST([ExpiryDate] AS VARCHAR(20)) + ']-['
							+ CAST(YOA AS VARCHAR(10)) + ']-[' + CASE WHEN [Account] LIKE '%P' THEN 'Policy' ELSE 'Binder' END + ']-[' + [TypeOfBusiness] + ']' 
		,[FK_Process]	= 'IP'
		,[FK_Product]	= -2  
		,[FK_Location]	= CASE WHEN OT.Location='-' THEN 'NA'
							   ELSE CAST(OT.LOCATION  AS VARCHAR(50))
							   END 
		,[FK_Trifocus]	= OT.[TrifocusCode] 
		,[FK_YOA]		= [YOA] 
		,[FK_StatsCode]	= statscode
		,[OriginalCCY]
		,[CCYOriginal]	= [OriginalCCY] 
		,[SettlementCCY]
		,[FK_DueDate]	= CAST(CONVERT(CHAR(10),[DueDate],112) AS INT) 
		,InceptionPeriod	= LEFT(CAST(CONVERT(CHAR(10),InceptionDate,112) AS INT),6)  
		,FK_InceptionYear	= COALESCE(Year(InceptionDate),-1) 
		,[Value]
		,[RowHash]
		,OT.[AuditSourceBatchID]
		,OT.[AuditCreateDateTime]
		,OT.[AuditGenerateDateTime]
		,OT.[AuditUserCreate]
		,OT.[AuditHost]
		,LookUpPolicyNumber	= LEFT([PolicyNumber],6) 
		,DateOfFact			= CASE WHEN Year(DateOfFact)< 1990 THEN CAST('19900101' AS DATE) ELSE  DateOfFact END 
		,FK_DateOfFact		= CASE WHEN Year(DateOfFact)< 1990 THEN '19900101'
								   ELSE  CAST(CONVERT(CHAR(10),DateOfFact,112) AS INT) 
								   END 
		,BusinessKey		= ot.BusinessKey
		,FK_InceptionDate	= CAST(CONVERT(CHAR(10),InceptionDate,112) AS INT) 
		,AccountingPeriod_DOF	= case when ot.DateOfFact<'2019-01-01' then 201812
										else cast (LEFT(CAST(CONVERT(CHAR(10),DateOfFact,112) AS INT),6) as int) 
   									  end 
   		,acc.RIFlag GrossRI --= 'O' then 'O' else 'I' end GrossRI
		,tf.TrifocusName
		,ot.Dataset
	  into #srctxnbbb
FROM [FinanceDataContract].[Outbound].[Transaction] OT
LEFT JOIN [FinanceDataContract].[Outbound].PolicySectionReference as polsec ON	OT.PolicyNumber	=	polsec.SectionReference
LEFT JOIN [FinanceDataContract].Inbound.BatchQueue BQ ON BQ.Pk_Batch=CAST(OT.[AuditSourceBatchID] AS INT)
LEFT JOIN TechnicalHub.dim.Account acc on (acc.BK_Account = OT.Account)
LEFT JOIN FinanceLanding.fdm.DimTrifocus tf on (ISNULL(LTRIM(RTRIM(OT.[TrifocusCode])),1) = tf.trifocusCode)
WHERE (YOA LIKE '[0-9]%' AND YOA>'1992')
AND OT.DataSet =@p_Dataset
AND cast(OT.[AuditSourceBatchID] as int) = @p_BatchId
OPTION (RECOMPILE,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));


IF OBJECT_ID('tempdb..#dataintbbb') IS NOT NULL DROP TABLE #dataintbbb

SELECT d.PK_Transaction
		,FK_Entity
		,PrioritySequence = min(i.PrioritySequence) 
	INTO #dataintbbb
FROM #srctxnbbb d
JOIN FinanceLanding.mds.Intercompany_rules i  ON
(
	(
		i.Dataset = 'All' 
		or
		i.Dataset = d.FK_DataSet
	)
and
	(
		i.GrossRI = 'All' 
		or
		i.GrossRI = d.GrossRI
	)
and
	(
		i.YOA = 0 
		or 
		i.YOA = d.FK_YOA 
	)
and 
	(
		i.Entity = 'All' 
		or
		i.Entity = d.FK_Entity 
	)
and
	(
		i.Trifocus = 'All'
		or 
		(i.Trifocus = 'BICI%' and left(d.TrifocusName, 4) = 'BICI')
		or
		(i.Trifocus = 'BUSA%' and left(d.TrifocusName, 4) = 'BUSA')
		or
		i.Trifocus = d.TrifocusName
	)
and (
		d.DateOfFact BETWEEN i.FromDOF AND ISNULL(CAST(CAST(i.ToDOF AS VARCHAR) AS DATE), CAST('2099-12-31' AS DATE))
	)

	)
	GROUP BY PK_Transaction,FK_Entity

IF OBJECT_ID('tempdb..#dumpbbb') IS NOT NULL DROP TABLE #dumpbbb

SELECT DISTINCT 
		t.PK_Transaction,
		AsAtPeriod,
		FK_Batch,
		FK_DataSet,
		FK_Scenario,
		FK_Account,
		FK_Basis,
		PK_DataStage,
		FK_Entity = LTRIM(RTRIM(ISNULL(cem.ConformedEntityMapping,t.FK_Entity))),
		FK_SourceEntity=t.FK_Entity,
		FK_DeltaType,
		BK_PolicySection,
		FK_Process,
		FK_Product,
		FK_Location,
		FK_Trifocus = 
				CASE 
					WHEN mds_tri.TriFocusCode IS NULL AND CTM.TrifocusCode IS NULL 
					THEN 'Unknown'
					ELSE 
					LTRIM(RTRIM(ISNULL(CTM.ConformedTrifocusMapping,t.FK_Trifocus)))
				END ,
		FK_YOA,
		FK_StatsCode,
		OriginalCCY,
		CCYOriginal,
		SettlementCCY,
		FK_DueDate,
		InceptionPeriod,
		FK_InceptionYear,
		Value,
		RowHash,
		t.AuditSourceBatchID,
		t.AuditCreateDateTime,
		t.AuditGenerateDateTime,
		t.AuditUserCreate,
		t.AuditHost,
		LookUpPolicyNumber,
		DateOfFact,
		FK_DateOfFact,
		BusinessKey,
		FK_InceptionDate,
		AccountingPeriod_DOF,
		t.GrossRI,
		TrifocusName,
		t.Dataset,
		ISNULL(di.PrioritySequence, -1) AS PrioritySequence,
		ISNULL(intc.[Percentage], 1) [Percentage],
		ISNULL(intc.Flag, 'NA') Flag
	INTO #dumpbbb
FROM #srctxnbbb t
LEFT JOIN #dataintbbb di ON (di.PK_Transaction = t.PK_Transaction AND di.FK_Entity = t.FK_Entity)
LEFT JOIN FinanceLanding.mds.Intercompany_rules intc ON (intc.PrioritySequence = di.PrioritySequence)
LEFT JOIN FinanceLanding.mds.ConformedEntityMapping cem ON t.FK_Entity = cem.Entity
LEFT JOIN FinanceLanding.MDS.ConformedTrifocusMapping CTM ON LTRIM(RTRIM(T.FK_Trifocus))=LTRIM(RTRIM(CTM.TrifocusCode))
LEFT JOIN FinanceLanding.mds.TriFocus AS mds_tri ON  LTRIM(RTRIM(T.FK_Trifocus)) = LTRIM(RTRIM(mds_tri.TriFocusCode))


TRUNCATE TABLE stg.FactTechnicalResult_BICI_BIDAC_BAIC

INSERT INTO stg.FactTechnicalResult_BICI_BIDAC_BAIC
SELECT  PK_Transaction,
		AsAtPeriod,
		FK_Batch,
		FK_DataSet,
		FK_Scenario,
		FK_Account,
		FK_Basis,
		PK_DataStage,
		FK_Entity,
		FK_DeltaType,
		BK_PolicySection,
		FK_Process,
		FK_Product,
		FK_Location,
		FK_Trifocus,
		FK_YOA,
		FK_StatsCode,
		OriginalCCY,
		CCYOriginal,
		SettlementCCY,
		FK_DueDate,
		InceptionPeriod,
		FK_InceptionYear,
		Value,
		RowHash,
		AuditSourceBatchID,
		AuditCreateDateTime,
		AuditGenerateDateTime,
		AuditUserCreate,
		AuditHost,
		LookUpPolicyNumber,
		DateOfFact,
		FK_DateOfFact,
		BusinessKey,
		FK_InceptionDate,
		AccountingPeriod_DOF,
		GrossRI,
		TrifocusName,
		PrioritySequence,
		[Percentage],
		Flag,
		FK_SourceEntity
FROM
#dumpbbb



SET   @v_AffectedRows			= @@ROWCOUNT;

		INSERT @Logging
		(
		    ActivityStatus,
		    ActivityName,
		    ActivityMessage,
		    RowsAffected
		)
		SELECT 5,
		       @p_ActivityName,
		       'Inserted ' + CONVERT(VARCHAR, @v_AffectedRows) + ' Rows into stg.FactTechnicalResult_BICI_BIDAC_BAIC table',
		       @v_AffectedRows;
	


		IF @Trancount = 0 
		COMMIT;

			INSERT @Logging
			(
			    ActivityStatus,
			    ActivityName,
			    ActivityMessage
			)
			SELECT 2,
			       @p_ActivityName,
			       'Load into stg.FactTechnicalResult_BICI_BIDAC_BAIC for BatchId ' + @p_BatchId + ' is success';

		EXEC TechnicalHub.log.usp_LogLanding @Input = @Logging;

		END TRY

	BEGIN CATCH

	IF @Trancount = 0  
				ROLLBACK;
					
				
			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

			

		    THROW;

		
	END CATCH;

END



