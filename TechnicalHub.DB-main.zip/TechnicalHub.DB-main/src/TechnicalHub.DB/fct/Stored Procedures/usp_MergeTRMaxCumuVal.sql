﻿
/*====================================================================================================
Is:		[fct].[usp_MergeTRMaxCumuVal]
Does:	Updates latest cumulative values with fct data
====================================================================================================*/
CREATE PROCEDURE [fct].[usp_MergeTRMaxCumuVal]
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		DROP TABLE IF EXISTS #RowOrder
		SELECT        FK_Batch
					, FK_Account
					, FK_Basis
					, FK_Entity
					, BK_PolicyNumber
					, InceptionDate
					, ExpiryDate
					, FK_Process
					, FK_Trifocus
					, FK_YOA
					, CCYOriginal
					, CCYSettlement 
					, Fk_dataset
					, FK_scenario
					, FK_inceptionyear
					, policytype
					, FK_AccountingPeriod
					, PK_AccountingPeriod
					,[Value]
					,ROW_NUMBER() 
						OVER (PARTITION BY 
						  FK_Account
						, FK_Basis
						, FK_Entity
						, BK_PolicyNumber
						, InceptionDate
						, ExpiryDate
						, FK_Process
						, FK_Trifocus
						, FK_YOA
						, CCYOriginal
						, CCYSettlement 
						, Fk_dataset
						, FK_scenario
						, FK_inceptionyear
						, policytype
						ORDER BY PK_AccountingPeriod DESC
									)	RowOrder
		INTO #RowOrder
		FROM FCT.TechnicalResultLTD_V2
		--WHERE BK_PolicyNumber = 'T9068X18APCS'
		----AND FK_Batch = 17
		--AND FK_Account = 'P-GP-P'
		--AND FK_Entity = '2623'
		--ORDER BY FK_AccountingPeriod,PK_AccountingPeriod

----Update the policies that were there in the table already
			UPDATE	lc
			SET		lc.[Value]   = M.[value]
			   	   ,lc.FK_AccountingPeriod = M.FK_AccountingPeriod
				   ,lc.FK_Batch = M.FK_Batch
			--SELECT M.FK_AccountingPeriod,M.[value]
			FROM	
				(
				 SELECT t.*
				 FROM #RowOrder t 
				 WHERE t.RowOrder = 1
				) M
			JOIN	[fct].[TechnicalResultLTD_V2_lastCumuVal] lc	ON	M.BK_PolicyNumber = lc.BK_PolicyNumber
																	AND LC.FK_Account		= M.FK_Account
																	AND LC.FK_Basis			= M.FK_Basis 
																	AND LC.FK_Entity			= M.FK_Entity			
																	AND LC.InceptionDate		= M.InceptionDate		
																	AND LC.ExpiryDate		= M.ExpiryDate		
																	AND LC.FK_Process		= M.FK_Process		
																	AND LC.FK_Trifocus		= M.FK_Trifocus		
																	AND LC.FK_YOA			= M.FK_YOA			
																	AND LC.CCYOriginal		= M.CCYOriginal		
																	AND LC.CCYSettlement		= M.CCYSettlement 	
																	AND LC.Fk_dataset		= M.Fk_dataset		
																	AND LC.FK_scenario		= M.FK_scenario		
																	AND LC.FK_inceptionyear	= M.FK_inceptionyear	
																	AND LC.policytype		= M.policytype			


			--Create new records			
			INSERT INTO [fct].[TechnicalResultLTD_V2_lastCumuVal]
			   (FK_Batch,[BK_PolicyNumber],	[FK_Account] ,	[FK_AccountingPeriod],	[FK_Basis] ,	[FK_Entity],	[InceptionDate],	[ExpiryDate],	[FK_Process],	[FK_Trifocus],	[FK_YOA],	[CCYOriginal],
				[CCYSettlement],	[Fk_dataset],	[FK_scenario],			[FK_inceptionyear],		[policytype],	[Value]	   )
			   SELECT
			    M.FK_Batch,
			    M.[BK_PolicyNumber],
				M.[FK_Account] ,
				M.[FK_AccountingPeriod],
				M.[FK_Basis] ,
				M.[FK_Entity],
				M.[InceptionDate],
				M.[ExpiryDate],
				M.[FK_Process],
				M.[FK_Trifocus],
				M.[FK_YOA],
				M.[CCYOriginal],
				M.[CCYSettlement],
				M.[Fk_dataset],
				M.[FK_scenario],
				M.[FK_inceptionyear],
				M.[policytype],
				M.[Value]
				FROM	
				(SELECT t.*
				 FROM #RowOrder t 
				 WHERE t.RowOrder = 1
				) M
			LEFT JOIN	[fct].[TechnicalResultLTD_V2_lastCumuVal] lc	
																ON	LC.BK_PolicyNumber = M.BK_PolicyNumber
																AND M.FK_Account = LC.FK_Account
																AND LC.FK_AccountingPeriod = M.FK_AccountingPeriod
																AND LC.FK_Basis			= M.FK_Basis 
																AND LC.FK_Entity		= M.FK_Entity			
																AND LC.InceptionDate	= M.InceptionDate		
																AND LC.ExpiryDate		= M.ExpiryDate		
																AND LC.FK_Process		= M.FK_Process		
																AND LC.FK_Trifocus		= M.FK_Trifocus		
																AND LC.FK_YOA			= M.FK_YOA			
																AND LC.CCYOriginal		= M.CCYOriginal		
																AND LC.CCYSettlement	= M.CCYSettlement 	
																AND LC.Fk_dataset		= M.Fk_dataset		
																AND LC.FK_scenario		= M.FK_scenario		
																AND LC.FK_inceptionyear	= M.FK_inceptionyear	
																AND LC.policytype		= M.policytype			
			WHERE LC.BK_PolicyNumber IS NULL		
			
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END