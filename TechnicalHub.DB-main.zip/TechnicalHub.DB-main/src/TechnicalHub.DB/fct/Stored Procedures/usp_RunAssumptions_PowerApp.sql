﻿CREATE PROC [fct].[usp_RunAssumptions_PowerApp]
AS
BEGIN
DECLARE @MaxFXRate INT=(SELECT MAX([Pk_RequestId]) FROM fct.IntermediaryFXRate)
DECLARE @MaxDiscountRate INT=(SELECT MAX([Pk_RequestId]) FROM fct.IntermediaryDiscountRate)
DECLARE @MaxPaymentPattern INT=(SELECT MAX([Pk_RequestId]) FROM fct.IntermediaryPaymentPattern)
DECLARE @MaxntermediaryAssumption INT=(SELECT MAX([Pk_RequestId]) FROM fct.IntermediaryAssumptionPercentages)

EXECUTE [dbo].[usp_UpdateAssumptionDataset] 
EXECUTE [fct].[usp_PopulateIntermediaryDiscountRt] @RequestId=@MaxDiscountRate,@ScheduleRunType='Now'
EXECUTE [fct].[usp_PopulateIntermediaryFXRate] @RequestId=@MaxFXRate,@ScheduleRunType='Now'
EXECUTE [fct].[usp_PopulateIntermediaryPaymentPattern] @RequestId=@MaxPaymentPattern,@ScheduleRunType='Now'
EXECUTE [fct].[usp_PopulateIntermediaryAssumption] @RequestId=@MaxntermediaryAssumption,@ScheduleRunType='Now'
EXECUTE [fct].[MeasureGrpProcessingCall] 

END