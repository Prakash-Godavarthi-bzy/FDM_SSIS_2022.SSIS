﻿-- =============================================
-- Author:		Pooja Khandual
-- Create date: 08 01 2021
-- Description:	This procedure is used to Process the WB Measure groups via Orchestration.
-- =============================================
CREATE PROCEDURE [fct].[MeasureGrpProcessingCall]
AS

UPDATE SchedulingHub.etl.Orchestration
SET		IsEnabled = 0

UPDATE SchedulingHub.etl.ModuleActivity
SET FK_ModuleStatus = 4
WHERE FK_Orchestration = 4
AND FK_Module = 1


UPDATE SchedulingHub.etl.Orchestration
SET		IsEnabled = 1
WHERE	PK_Orchestration = 4

EXEC msdb.dbo.sp_start_job 'SchedulingHub'