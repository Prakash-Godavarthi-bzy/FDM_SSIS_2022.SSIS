﻿/*====================================================================================================
Is:		fct.MergeTechnicalResult
Does:	Loads fact data from associated staging table
====================================================================================================*/
CREATE PROCEDURE [fct].[usp_MergeTechnicalResult]
 @p_FK_Dataset	BIGINT  = NULL
,@p_BatchId		BIGINT	= NULL
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
		
		DECLARE 
				 @p_L_FK_Dataset	BIGINT
				,@p_L_BatchId		BIGINT

		SET @p_L_FK_Dataset = @p_FK_Dataset
		SET @p_L_BatchId = @p_BatchId

			--Create new fact records
			INSERT		fct.TechnicalResult WITH (TABLOCK) (FK_Batch, FK_DataSet, FK_Scenario, FK_Account, FK_AccountingPeriod, FK_Basis, FK_DataStage, FK_Entity
															, FK_Policy, FK_PolicySection,FK_Process, FK_Product, FK_Location, FK_Trifocus, FK_YOA, FK_Allocation,FK_InceptionYear, 
															 [FK_CCYOriginal], [FK_CCYSettlement], [FK_DateDue], Value, EarningPercentage,Fk_statscode, RowHash, AuditSourceBatchID,
															  AuditGenerateDateTime,InceptionPeriod,FK_CatCode,[FK_MovementType],
															  [FK_TrackingStatus],[FK_ClaimExposure],[FK_DateOfFact],[BusinessKey],FK_InceptionDate,FK_RIPolicyType,FK_ProgrammeCode,
															  [Att_Cat],[FK_ReservingDataset],[FK_TriangleGroup],[FK_SourceEntity],[FK_DeltaType],GroupShare,Intercompany_PrioritySeq)
			SELECT		stg.FK_Batch,
						stg.FK_DataSet,
						stg.FK_Scenario,
						stg.FK_Account,
						stg.FK_AccountingPeriod,
						stg.FK_Basis,
						stg.FK_DataStage,
						stg.FK_Entity,
						stg.FK_Policy,
						stg.FK_PolicySection,
						stg.FK_Process,
						stg.FK_Product,
						stg.FK_Location,
						stg.FK_Trifocus,
						stg.FK_YOA,
						stg.FK_Allocation,
						stg.FK_InceptionYear,
						stg.[FK_CCYOriginal],
						stg.[FK_CCYSettlement],
						stg.[FK_DateDue],
						stg.Value,
						stg.EarningPercentage,
						stg.Fk_statscode,
						stg.RowHash,
						stg.AuditSourceBatchID,
						--stg.AuditCreateDateTime,
						stg.AuditGenerateDateTime,
						--stg.AuditUserCreate,
						stg.InceptionPeriod,
						stg.FK_CatCode,
						stg.FK_MovementType,
						stg.FK_TrackingStatus,
						[FK_ClaimExposure],
						[FK_DateOfFact],
						[BusinessKey],
						FK_InceptionDate,
						FK_RIPolicyType,
						FK_ProgrammeCode,
						[Att_Cat],
						[FK_ReservingDataset],
						[FK_TriangleGroup],
						stg.[FK_SourceEntity],
						[FK_DeltaType],
						GroupShare,
						Intercompany_PrioritySeq

			FROM		stg.fct_TechnicalResult stg	

			WHERE FK_DataSet = @p_L_FK_Dataset
			AND AuditSourceBatchID  = @p_L_BatchId


		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END