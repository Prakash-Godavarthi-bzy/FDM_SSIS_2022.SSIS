﻿
-- =============================================
-- Author:		Hemomsu Lakkaraju
-- Create date: 2021-05-24
-- Description:	ULR percentages are calculated based on the 
-- =============================================
CREATE PROCEDURE [fct].[ADMULRImport]
	-- Add the parameters for the stored procedure here
	@AsAt int,
	@FXRate Varchar(35),
	@ULRType varchar(4),
	@AssumptionDatasetID int,
	@AssumptionPercentType Varchar(35)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	--Retriving assumption percent type ID
	DECLARE @AssumptionPercentTypeID Varchar(35)

	SELECT @AssumptionPercentTypeID = Pk_AssumptionPercentageTypeId
	FROM	dim.AssumptionPercentageType
	WHERE	AssumptionPercentageType = @AssumptionPercentType

If @ULRType = 'Pure'
	BEGIN
	
		INSERT    [fct].[All_WB_Committed] WITH (TABLOCK) (WB_TYPE,Pk_AssumptionDatasetNameId,Pk_AssumptionPercentageTypeId,Trifocus,Entity,[Gross/RI Flag],PK_LossType,YOA,Value) 
		SELECT	'AD' WB_TYPE,
				@AssumptionDatasetID Pk_AssumptionDatasetNameId,
				@AssumptionPercentTypeID Pk_AssumptionPercentageTypeId,
				PR.FK_Trifocus Trifocus,
				PR.FK_Entity Entity,
				LEFT(PR.FK_Account,1) [Gross/RI Flag],
				CASE WHEN LEFT(RIGHT(CL.FK_Account,2),1) = 'L' THEN 'LL' ELSE LEFT(RIGHT(CL.FK_Account,2),1) END [Loss Type],
				pr.FK_YOA YOA,
				--PremiumVal,
				--ClaimsValue,
				CASE when PremiumVal = 0 THEN 0 ELSE ClaimsValue/PremiumVal END [Value]
		FROM 
				(
						SELECT		FK_Trifocus,
									FK_YOA,
									FK_Account,
									FK_Entity,
									SUM(Value*[FX Rate (Spot)]) PremiumVal
						FROM		FCT.TechnicalResult tr
						JOIN		DIM.TriFocus DT	
						ON			TR.FK_Trifocus = DT.[BK_TriFocus]
						JOIN		DIM.Account	DA
						ON			TR.FK_Account = DA.[BK_Account]
						JOIN		PWAPS.vwFxRateSetPercent FX
						ON			TR.[FK_CCYSettlement] =FX.PK_CCY_5
						--JOIN        Dim.AccountingPeriod AP							--++
						--ON			TR.FK_AccountingPeriod=AP.PK_AccountingPeriod	--++
						WHERE		FK_DataSet = 'ReservingData'
						AND			FK_AccountingPeriod <= @AsAt						----
						--AND			AP.BK_AccountingPeriod <= @AsAt					--++
						AND			AssumptionDatasetName = @FXRate
						AND			FK_Account LIKE '_P-P-PR'
						GROUP BY	FK_Trifocus,
									FK_YOA,
									FK_Account,
									FK_Entity
						--ORDER BY FK_Trifocus
				) PR
				JOIN
				(
					SELECT		FK_Trifocus,
								FK_YOA,
								FK_Account,
								FK_Entity,
								SUM(Value*[FX Rate (Spot)]) ClaimsValue
					FROM		FCT.TechnicalResult tr
					JOIN		DIM.TriFocus DT	
					ON			TR.FK_Trifocus = DT.[BK_TriFocus]
					JOIN		DIM.Account	DA
					ON			TR.FK_Account = DA.[BK_Account]
					JOIN		PWAPS.vwFxRateSetPercent FX
					ON			TR.[FK_CCYSettlement] =FX.PK_CCY_5
					--JOIN        Dim.AccountingPeriod AP							--++
					--ON			TR.FK_AccountingPeriod=AP.PK_AccountingPeriod	--++
					WHERE		FK_DataSet = 'ReservingData'
					AND			FK_AccountingPeriod <= @AsAt						--
					--AND			AP.BK_AccountingPeriod <= @AsAt					--++
					AND			AssumptionDatasetName = @FXRate
					AND			FK_Account LIKE '%-P-%'
					AND			FK_Account NOT LIKE '%IC'
					AND			FK_Account NOT LIKE '%PR'
					GROUP BY	FK_Trifocus,
								FK_YOA,
								FK_Account,
								FK_Entity
					HAVING sum([Value] *[FX Rate (Spot)])<>0
					--ORDER BY	FK_Trifocus
				) CL 
				 ON		PR.FK_Trifocus = CL.FK_Trifocus
				 AND	PR.FK_Entity = CL.FK_Entity
				 AND	PR.FK_YOA = CL.FK_YOA
				 AND	LEFT(PR.FK_Account,1) =	LEFT(CL.FK_Account,1)
	END
ELSE
	BEGIN
			INSERT    [fct].[All_WB_Committed] WITH (TABLOCK) (WB_TYPE,Pk_AssumptionDatasetNameId,Pk_AssumptionPercentageTypeId,Trifocus,Entity,[Gross/RI Flag],PK_LossType,YOA,Value) 
			SELECT	'AD' WB_TYPE,
					@AssumptionDatasetID Pk_AssumptionDatasetNameId,
					@AssumptionPercentTypeID Pk_AssumptionPercentageTypeId,
					PR.FK_Trifocus Trifocus,
					PR.FK_Entity Entity,
					LEFT(PR.FK_Account,1) [Gross/RI Flag],
					CASE WHEN LEFT(RIGHT(CL.FK_Account,2),1) = 'L' THEN 'LL' ELSE LEFT(RIGHT(CL.FK_Account,2),1) END [Loss Type],
					pr.FK_YOA YOA,
					--PremiumVal,
					--ClaimsValue,
					CASE when PremiumVal = 0 THEN 0 ELSE ClaimsValue/PremiumVal END [Value]
			FROM 
					(
							SELECT		FK_Trifocus,
										FK_YOA,
										FK_Account,
										FK_Entity,
										SUM(Value*[FX Rate (Spot)]) PremiumVal
							FROM		FCT.TechnicalResult tr
							JOIN		DIM.TriFocus DT	
							ON			TR.FK_Trifocus = DT.[BK_TriFocus]
							JOIN		DIM.Account	DA
							ON			TR.FK_Account = DA.[BK_Account]
							JOIN		PWAPS.vwFxRateSetPercent FX
							ON			TR.[FK_CCYSettlement] =FX.PK_CCY_5
							--JOIN        Dim.AccountingPeriod AP							--++
							--ON			TR.FK_AccountingPeriod=AP.PK_AccountingPeriod	--++
							WHERE		FK_DataSet = 'ReservingData'
							AND			FK_AccountingPeriod <= @AsAt                        ----
							--AND			AP.BK_AccountingPeriod <= @AsAt					--++
							AND			AssumptionDatasetName = @FXRate
							AND			FK_Account LIKE '_P-T-PR'
							GROUP BY	FK_Trifocus,
										FK_YOA,
										FK_Account,
										FK_Entity
							--ORDER BY FK_Trifocus
					) PR
					JOIN
					(
						SELECT		FK_Trifocus,
									FK_YOA,
									FK_Account,
									FK_Entity,
									SUM(Value*[FX Rate (Spot)]) ClaimsValue
						FROM		FCT.TechnicalResult tr
						JOIN		DIM.TriFocus DT	
						ON			TR.FK_Trifocus = DT.[BK_TriFocus]
						JOIN		DIM.Account	DA
						ON			TR.FK_Account = DA.[BK_Account]
						JOIN		PWAPS.vwFxRateSetPercent FX
						ON			TR.[FK_CCYSettlement] =FX.PK_CCY_5
						--JOIN        Dim.AccountingPeriod AP							--++
						--ON			TR.FK_AccountingPeriod=AP.PK_AccountingPeriod	--++
						WHERE		FK_DataSet = 'ReservingData'
						AND			FK_AccountingPeriod <= @AsAt						----
					  --AND			AP.BK_AccountingPeriod <= @AsAt						--++
						AND			AssumptionDatasetName = @FXRate
						AND			FK_Account LIKE '%-T-%'
						AND			FK_Account NOT LIKE '%IC'
						AND			FK_Account NOT LIKE '%PR'
						GROUP BY	FK_Trifocus,
									FK_YOA,
									FK_Account,
									FK_Entity
						HAVING sum([Value] *[FX Rate (Spot)])<>0
						--ORDER BY	FK_Trifocus
					) CL 
					 ON		PR.FK_Trifocus = CL.FK_Trifocus
					 AND	PR.FK_Entity = CL.FK_Entity
					 AND	PR.FK_YOA = CL.FK_YOA
					 AND	LEFT(PR.FK_Account,1) =	LEFT(CL.FK_Account,1)
		END

END