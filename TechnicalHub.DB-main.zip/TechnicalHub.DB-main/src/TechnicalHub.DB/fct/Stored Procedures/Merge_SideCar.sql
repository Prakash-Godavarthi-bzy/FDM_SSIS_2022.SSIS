﻿
/*====================================================================================================
Is:		dim.Mergedim.MergeSideCar
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE [dim].[usp_MergeSideCar]
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			UPDATE	dim
			SET		dim.Trifocus = stg.Trifocus,
					dim.YOA = stg.YOA,
					dim.STATSCODE = stg.STATSCODE,
					dim.[PERCENT] = stg.[PERCENT]
			FROM	stg.SideCarPercentages stg	
			JOIN	fct.SideCarPercentages dim	ON	dim.pk_sidecar = stg.pk_sidecar			WHERE	dim.Trifocus <> stg.TriFocus
				OR	dim.YOA <> stg.YOA
				OR	dim.STATSCODE <> stg.STATSCODE
				OR	dim.[PERCENT] <> stg.[PERCENT]
				OR	CAST(IIF(dim.Trifocus IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Trifocus IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.YOA IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.YOA IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.STATSCODE IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.STATSCODE IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.[PERCENT] IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.[PERCENT] IS NULL, 0, 1) AS BIT) = 1 

			--Create new records
			INSERT		fct.SideCarPercentages WITH (TABLOCK) ( Trifocus, YOA, STATSCODE, [PERCENT])
			SELECT		stg.TriFocus, 
						stg.YOA, 
						stg.STATSCODE, 
						stg.[percent]
			FROM		stg.SideCarPercentages stg	
			LEFT JOIN	fct.SideCarPercentages dim	ON	dim.pk_SideCar = stg.pk_SideCar
			WHERE		dim.pk_SideCar IS NULL
					OR	dim.TriFocus <> stg.TriFocus
					OR	dim.YOA <> stg.YOA
					OR	dim.STATSCODE <> stg.STATSCODE
					OR	dim.[PERCENT] <> stg.[PERCENT]
					OR	CAST(IIF(dim.TriFocus IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.TriFocus IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.YOA IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.YOA IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.STATSCODE IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.STATSCODE IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.[PERCENT] IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.[PERCENT] IS NULL, 0, 1) AS BIT) = 1 
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END