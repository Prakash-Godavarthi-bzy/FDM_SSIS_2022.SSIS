﻿

CREATE PROCEDURE [fct].[usp_PopulateIntermediaryAssumption] @RequestId INT,@ScheduleRunType Varchar(10)
AS
BEGIN

	SET NOCOUNT ON;
	EXECUTE [fct].[usp_Populate_AllWBCommitted] 'AD'

	BEGIN
		WITH UNPIVOT_DATA AS
		(

		SELECT [Pk_RequestId]  , DatasetName, ColumnName
		FROM [stg].[MappingTotransformationLog] 
		UNPIVOT (
			DatasetName FOR ColumnName IN (

			   [Pure IELR Q1]
			  ,[Pure IELR Q2]
			  ,[Pure IELR Q3]
			  ,[Pure IELR Q4]
			  ,[Pure IELR Q5]
			  ,[Pure IELR SM]
			  ,[Team IELR Q1]
			  ,[Team IELR Q2]
			  ,[Team IELR Q3]
			  ,[Team IELR Q4]
			  ,[Team IELR Q5]
			  ,[Team IELR SM]
			  ,[ENIDs Q1]
			  ,[ENIDs Q2]
			  ,[ENIDs Q3]
			  ,[ENIDs Q4]
			  ,[ENIDs Q5]
			  ,[ENIDs SM]
			  ,[Admin Expense Q1 (Claims Related)]
			  ,[Admin Expense Q2 (Claims Related)]
			  ,[Admin Expense Q3 (Claims Related)]
			  ,[Admin Expense Q4 (Claims Related)]
			  ,[Admin Expense Q5 (Claims Related)]
			  ,[Admin Expense SM (Claims Related)]
			  ,[Admin Expense Q1 (other)]
			  ,[Admin Expense Q2 (other)]
			  ,[Admin Expense Q3 (other)]
			  ,[Admin Expense Q4 (other)]
			  ,[Admin Expense Q5 (other)]
			  ,[Admin Expense SM (other)]
			  ,[Admin Expense Q1 (Premium Related)]
			  ,[Admin Expense Q2 (Premium Related)]
			  ,[Admin Expense Q3 (Premium Related)]
			  ,[Admin Expense Q4 (Premium Related)]
			  ,[Admin Expense Q5 (Premium Related)]
			  ,[Admin Expense SM (Premium Related)]
			  ,[Claims Handling Expenses Q1]
			  ,[Claims Handling Expenses Q2]
			  ,[Claims Handling Expenses Q3]
			  ,[Claims Handling Expenses Q4]
			  ,[Claims Handling Expenses Q5]
			  ,[Claims Handling Expenses SM]
			  ,[Other Acquisition Expenses Q1] 
			  ,[Other Acquisition Expenses Q2]
			  ,[Other Acquisition Expenses Q3]
			  ,[Other Acquisition Expenses Q4]
			  ,[Other Acquisition Expenses Q5]
			  ,[Other Acquisition Expenses SM]
			  ,[Profit Commission Q1]
			  ,[Profit Commission Q2]
			  ,[Profit Commission Q3]
			  ,[Profit Commission Q4]
			  ,[Profit Commission Q5]
			  ,[Profit Commission SM]
			  ,[Reinstatement Premium Q1]
			  ,[Reinstatement Premium Q2]
			  ,[Reinstatement Premium Q3]
			  ,[Reinstatement Premium Q4]
			  ,[Reinstatement Premium Q5]
			  ,[Reinstatement Premium SM]
			  ,[Discount Rate Q1]
			  ,[Discount Rate Q2]
			  ,[Discount Rate Q3]
			  ,[Discount Rate Q4]
			  ,[Discount Rate Q5]
			  ,[Discount Rate SM]
			  ,[ADM]
			  ,[Payment Pattern Claims]
			  ,[ENIDs UnEarned Q1]
			  ,[ENIDs UnEarned Q2]
			  ,[ENIDs UnEarned Q3]
			  ,[ENIDs UnEarned Q4]
			  ,[ENIDs UnEarned Q5]
			  ,[ENIDs UnEarned SM]
			  ,[Rebates Q1]
			  ,[Rebates Q2]
			  ,[Rebates Q3]
			  ,[Rebates Q4]
			  ,[Rebates Q5]
			  ,[Rebates SM]
			  ,[RICL Q1]
			  ,[RICL Q2]
	          ,[RICL Q3]
	          ,[RICL Q4]
	          ,[RICL Q5]
	          ,[RICL SM]
			  	,[Team ULR(Re) SM]						
	,[Pure ULR(Re) SM]						

	
	,[Pure IELR(Re) Q1] 						
	,[Pure IELR(Re) Q2] 						
	,[Pure IELR(Re) Q3] 						
	,[Pure IELR(Re) Q4] 						
	,[Pure IELR(Re) Q5] 						
	,[Pure IELR(Re)  SM] 						
	
	
	,[Team IELR(Re) Q1] 						
	,[Team IELR(Re) Q2] 						
	,[Team IELR(Re) Q3] 						
	,[Team IELR(Re) Q4] 						
	,[Team IELR(Re) Q5] 						
	,[Team IELR(Re) SM]						
	
	,[ENIDs Earned(Re) Q1] 					
	,[ENIDs Earned(Re) Q2] 					
	,[ENIDs Earned(Re) Q3] 					
	,[ENIDs Earned(Re) Q4] 					
	,[ENIDs Earned(Re) Q5] 					
	,[ENIDs Earned(Re) SM] 					


	,[Profit Commission(Re) Q1] 				
	,[Profit Commission(Re) Q2] 				
	,[Profit Commission(Re) Q3] 				
	,[Profit Commission(Re) Q4] 				
	,[Profit Commission(Re) Q5] 				
	,[Profit Commission(Re) SM] 				
	
	
	,[Reinstatement Premium(Re) Q1] 			
	,[Reinstatement Premium(Re) Q2] 			
	,[Reinstatement Premium(Re) Q3] 			
	,[Reinstatement Premium(Re) Q4] 			
	,[Reinstatement Premium(Re) Q5] 			
	,[Reinstatement Premium(Re) SM] 			
	
	
	,[Other Acquisition Expenses(Re) Q1] 	
	,[Other Acquisition Expenses(Re) Q2] 	
	,[Other Acquisition Expenses(Re) Q3] 	
	,[Other Acquisition Expenses(Re) Q4] 	
	,[Other Acquisition Expenses(Re) Q5] 	
	,[Other Acquisition Expenses(Re) SM] 

			)
		) unpvt
		WHERE 
		--[Pk_RequestId]  > (SELECT MAX([Pk_RequestId]) FROM fct.IntermediaryAssumptionPercentages)
		[Pk_RequestId]=@RequestId AND
		ScheduleRunType=@ScheduleRunType
		)

		,TABLE_1 AS
		(
		SELECT T1.Pk_RequestId, T2.Pk_AssumptionDatasetNameId, T1.ColumnName, T2.AssumptionPercentageTypeId
		FROM UNPIVOT_DATA T1
		INNER JOIN dim.AssumptionDatasets T2 ON T1.DatasetName = T2.AssumptionDatasetName
		)
		--SELECT * FROM TABLE_1
		------INSERT ------------------------


		INSERT INTO fct.IntermediaryAssumptionPercentages
		SELECT  DISTINCT
				  T1.Pk_RequestId
				, T4.YOA
				, T4.TriFocus
				, T2.Pk_AssumptionDatasetNameId AS DatasetNameId
				, T3.Pk_AssumptionPercentageTypeId AS PercentageTypeId
				, T5.Pk_AssumptionPercentageSubTypeId AS LossType
				, CASE WHEN T1.ColumnName = 'ADM' 
					   THEN 'AD'
					   WHEN CHARINDEX('Q', T1.ColumnName COLLATE  latin1_general_cs_as) = 0 
					   THEN 'SM' 
					   ELSE SUBSTRING(T1.ColumnName, CHARINDEX('Q', T1.ColumnName COLLATE  latin1_general_cs_as), 2) 
				   END Quarters
				, CAST(T4.[Value] AS DECIMAL(19,10)) GeneralPercent
		FROM TABLE_1 T1
		INNER JOIN dim.AssumptionDatasets T2 ON T1.Pk_AssumptionDatasetNameId  = T2.Pk_AssumptionDatasetNameId
		INNER JOIN dim.AssumptionPercentageType T3 ON T1.AssumptionPercentageTypeId = T3.Pk_AssumptionPercentageTypeId
		INNER JOIN FCT.All_WB_Committed T4 ON T2.AssumptionPercentageTypeId = T4.Pk_AssumptionPercentageTypeId AND T2.Pk_AssumptionDatasetNameId = T4.Pk_AssumptionDatasetNameId AND T4.WB_TYPE = 'AD'
		INNER JOIN  dim.AssumptionPercentageSubType T5 ON T4.PK_LossType = T5.LossType
		WHERE T4.[Value] <> 0
    END

	

END