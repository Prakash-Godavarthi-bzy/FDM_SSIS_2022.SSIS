﻿CREATE PROCEDURE fct.DeleteCSVBatchRuns @PublishedRun INT AS

BEGIN
/*
Deletes fact rows for each unpublished run, triggered by a published flag being set.
*/

-- DECLARE VARIABLES
DECLARE @BatchRun INT;
DECLARE @PrevPublished INT;
DECLARE @DeleteBatch INT;

-- POPULATE VARIABLES
SELECT @BatchRun = @PublishedRun
--SELECT @BatchRun  = 10

SELECT @PrevPublished = MAX(CR.PK_BatchRun) 
FROM [Control].CSVRuns CR 
WHERE CR.PK_BatchRun < @BatchRun
AND CR.IsPublished = 1

SELECT @DeleteBatch = @PrevPublished + 1

-- DELETE THE ROWS FROM FACT TABLE

WHILE @DeleteBatch < @BatchRun
BEGIN
	DELETE FROM fct.OpeningBalances WHERE FK_BatchRun = @DeleteBatch

	SET @DeleteBatch = @DeleteBatch + 1
END

END;