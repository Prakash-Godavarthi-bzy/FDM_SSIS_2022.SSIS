﻿
-- =============================================
-- Author:		Pooja Khandual
-- Create date: 21 Dec 2020
-- Description:	This stored proc is called to populate the Intermedialy table with the Run ID data from the table stg.MappingTotransformationLog
-- =============================================
--DECLARE @RequestId  Int = 1241
--DELETE FROM fct.IntermediaryFXRate WHERE [Pk_RequestId] = 1241
-- TRUNCATE TABLE fct.IntermediaryFXRate
-- SELECT * FROM fct.IntermediaryFXRate
--DROP PROCEDURE fct.usp_PopulateIntermediaryFXRate 

CREATE PROCEDURE [fct].[usp_PopulateIntermediaryFXRate] @RequestId INT, @ScheduleRunType varchar(10)
AS
BEGIN

	SET NOCOUNT ON;
	EXECUTE [fct].[usp_Populate_AllWBCommitted] 'FX'
		BEGIN
		WITH UNPIVOT_DATA AS
		(

		SELECT [Pk_RequestId], DatasetName, ColumnName
		FROM [stg].[MappingTotransformationLog] 
		UNPIVOT (
			DatasetName FOR ColumnName IN (
			   [FX Rate Name (Avg)]
			  ,[FX Rate Name (Spot)]
			)
		) unpvt
		WHERE 
		--[Pk_RequestId] > (SELECT MAX([Pk_RequestId]) FROM fct.IntermediaryFXRate)
		[Pk_RequestId]=@RequestId AND
		ScheduleRunType=@ScheduleRunType
		)

		,TABLE_1 AS
		(
		SELECT T1.Pk_RequestId, T2.Pk_AssumptionDatasetNameId, T1.ColumnName,T2.AssumptionPercentageTypeId
		FROM UNPIVOT_DATA T1
		INNER JOIN dim.AssumptionDatasets T2 ON T1.DatasetName = T2.AssumptionDatasetName
		)
		--SELECT * FROM TABLE_1
		----------INSERT FX DATA

		INSERT INTO fct.IntermediaryFXRate
		SELECT  DISTINCT
				  T1.Pk_RequestId
				, T2.Pk_AssumptionDatasetNameId AS DatasetNameId
				, T3.Pk_AssumptionPercentageTypeId AS PercentageTypeId
				, T5.Pk_AssumptionPercentageSubTypeId AS LossType
				, T4.FX_ReportingCurrencyCode_4 AS ReportingCurrency
				, T4.CCY as TransactionCurrency
				, CAST(T4.Value AS DECIMAL(19,10)) FXRate
		FROM TABLE_1 T1
		INNER JOIN dim.AssumptionDatasets T2 ON T1.Pk_AssumptionDatasetNameId  = T2.Pk_AssumptionDatasetNameId
		INNER JOIN dim.AssumptionPercentageType T3 ON T1.AssumptionPercentageTypeId = T3.Pk_AssumptionPercentageTypeId
		INNER JOIN FCT.All_WB_Committed T4 ON T2.AssumptionPercentageTypeId = T4.Pk_AssumptionPercentageTypeId AND T2.Pk_AssumptionDatasetNameId = T4.Pk_AssumptionDatasetNameId  AND T4.WB_TYPE = 'FX'
		INNER JOIN  dim.AssumptionPercentageSubType T5 ON T4.PK_LossType = T5.LossType
		WHERE 
		1 = 1
	END

	

END