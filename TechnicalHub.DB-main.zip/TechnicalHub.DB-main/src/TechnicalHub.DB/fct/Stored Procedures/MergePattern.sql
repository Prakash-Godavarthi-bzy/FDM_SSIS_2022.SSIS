﻿/*====================================================================================================
Is:		fct.MergePattern
Does:	Loads fact data from associated staging table
====================================================================================================*/
CREATE PROCEDURE fct.MergePattern (@Rnd Varchar(30))
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 
		    BEGIN TRAN;
			TRUNCATE TABLE stg.DevQtrs

			DECLARE @max_qtr_num INT
			DECLARE @Dataset Varchar(50)
			SELECT @max_qtr_num = MAX(DevelopmentQuarter)  FROM STG.fct_Pattern

			DECLARE @startnum INT=1
			DECLARE @endnum INT=@max_qtr_num

			;WITH devperiods AS 
				(
				SELECT @startnum AS NUM
				UNION ALL
				SELECT num+1  AS devqtr FROM devperiods WHERE num+1<=@endnum
				)

			INSERT INTO stg.DevQtrs(DevQtr,Defaultvalue)
			SELECT num AS DevQtr
				   , 0 AS defaultvalue 
			FROM devperiods
			OPTION (maxrecursion 10000)

			--Create new fact records
			;WITH  F_Pattern AS(
				SELECT   T3.FK_Batch AS FK_Batch
							,T3.FK_DataSet AS FK_Dataset
							---,TDH_DatasetName='SYS'+' '+@Rnd+' '+'PP_' + CASE WHEN [FK_DataSet] = 'NatCatEarning' THEN 'NatCat' ELSE [FK_DataSet] END + '_' + [PatternScenario] + '_V' + CAST([PatternScenarioVersion] AS CHAR(1)) + CASE LEFT([FK_PatternName],1)  WHEN 'C' THEN '_Claims' WHEN 'P' THEN '_Prem' ELSE '' END
							,TDH_DatasetName='SYS'+' '+@Rnd+' '+'PP_' + CASE WHEN [BK_DataSet] = 'NatCatEarning' THEN 'NatCat' ELSE [BK_DataSet] END + '_' + [PatternScenario] + '_V' + CAST([PatternScenarioVersion] AS CHAR(1)) + CASE LEFT([BK_PatternName],1)  WHEN 'C' THEN '_Claims' WHEN 'P' THEN '_Prem' ELSE '' END
							,T3.FK_PatternName AS FK_PatternName
							,T3.FK_Trifocus AS FK_Trifocus
							,T3.FK_YOA AS FK_YOA
							,T3.FK_InceptionYear AS FK_InceptionYear
							,T3.[FK_CCYSettlement] AS CCYSettlement
						--	,ISNULL(T3.FK_AccountingPeriod, CONVERT(CHAR(6),DATEADD(q, CAST(RIGHT(T3.PatternScenario,1) AS INT)+T3.DevelopmentQuarter-1, DATEADD(DAY,-1,CAST('20'+LEFT(T3.PatternScenario,2)+'0101' AS DATE))),112)) AS FK_AccountingPeriod
							,ISNULL(T3.bK_AccountingPeriod, CONVERT(CHAR(6),DATEADD(q, CAST(RIGHT(T3.PatternScenario,1) AS INT)+T3.DevelopmentQuarter-1, DATEADD(DAY,-1,CAST('20'+LEFT(T3.PatternScenario,2)+'0101' AS DATE))),112)) AS FK_AccountingPeriod
							,T3.DevelopmentQuarter AS DevelopmentQuarter
							,T3.PatternScenario AS PatternScenario
							,T3.PatternScenarioVersion AS PatternScenarioVersion
							,T3.DevelopmentPercentageIncrement AS DevelopmentPercentageIncrement
							,SUM (DevelopmentPercentageIncrement) OVER (PARTITION BY FK_Batch,FK_DataSet,FK_PatternName,PatternScenario,PatternScenarioVersion,FK_Trifocus,FK_YOA,FK_InceptionYear,[FK_CCYSettlement] ORDER BY DevelopmentQuarter) AS DevelopmentPercentageCumulative
							,T3.AuditSourceBatchID AS AuditSourceBatchID
							--,T3.AuditCreateDateTime
							,T3.AuditGenerateDateTime AS AuditGenerateDateTime
							--,T3.AuditUserCreate
					FROM (
							SELECT
								 T2.FK_PatternName
								,T2.FK_Trifocus
								,T2.PatternScenario
								,T2.PatternScenarioVersion
								,T2.FK_YOA
								,T2.FK_InceptionYear
								,T2.[FK_CCYSettlement]
								,T2.FK_Batch
								,T2.FK_DataSet
								,CASE WHEN fp.DevelopmentQuarter IS NULL THEN T2.DevQtr ELSE fp.DevelopmentQuarter END AS DevelopmentQuarter
								,CASE WHEN fp.DevelopmentPercentageIncrement IS NULL THEN T2.Defaultvalue ELSE fp.DevelopmentPercentageIncrement END AS DevelopmentPercentageIncrement
								,T2.AuditSourceBatchID
								,T2.AuditUserCreate
								,T2.AuditCreateDateTime
								,T2.AuditGenerateDateTime
								,FP.FK_AccountingPeriod
								,ap.BK_AccountingPeriod -- ++
								,pn.BK_PatternName --++
								,ds.BK_DataSet --++
							 FROM(
									SELECT A.DevQtr,A.Defaultvalue,T1.* 
									FROM stg.DevQtrs A
									CROSS JOIN (SELECT DISTINCT FK_Batch,FK_DataSet,FK_PatternName,PatternScenario,PatternScenarioVersion,FK_Trifocus,FK_YOA,FK_InceptionYear,[FK_CCYSettlement],  
												f.AuditSourceBatchID, f.AuditUserCreate, MIN(f.AuditCreateDateTime)AuditCreateDateTime, MIN(AuditGenerateDateTime)AuditGenerateDateTime,max(DevelopmentQuarter) MaxDevQtr
													FROM stg.fct_Pattern f
													GROUP BY FK_Batch,FK_DataSet,FK_PatternName,PatternScenario,PatternScenarioVersion,FK_Trifocus,FK_YOA,FK_InceptionYear,
													[FK_CCYSettlement],f.AuditSourceBatchID, f.AuditUserCreate) T1
									WHERE A.DevQtr <= T1.MaxDevQtr
								 ) T2
							 LEFT JOIN stg.fct_Pattern fp ON T2.FK_PatternName = fp.FK_PatternName 
														AND T2.FK_Trifocus = fp.FK_Trifocus 
														AND T2.PatternScenario = Fp.PatternScenario  
														AND T2.PatternScenarioVersion = FP.PatternScenarioVersion
														AND T2.FK_YOA = FP.FK_YOA
														AND T2.FK_InceptionYear = FP.FK_InceptionYear
														AND T2.[FK_CCYSettlement] = FP.[FK_CCYSettlement]
														AND T2.FK_Batch = FP.FK_Batch
														AND T2.FK_DataSet = FP.FK_DataSet
														AND T2.DevQtr = fp.DevelopmentQuarter
							LEFT JOIN TechnicalHub.dim.AccountingPeriod ap on ap.PK_AccountingPeriod=fp.FK_AccountingPeriod --++
							LEFT JOIN TechnicalHub.dim.PatternName as pn ON pn.PK_PatternName = T2.FK_PatternName --++
							LEFT JOIN TechnicalHub.dim.DataSet as ds ON ds.PK_DataSet = T2.FK_DataSet
						) AS T3
						
						LEFT JOIN TechnicalHub.dim.TriFocus TF ON TF.PK_TriFocus=T3.FK_Trifocus
						WHERE TF.BK_Trifocus <>'1'
				)
			INSERT		fct.Pattern WITH (TABLOCK) (FK_Batch, FK_DataSet,TDH_DatasetName, FK_PatternName, FK_Trifocus, FK_YOA, FK_InceptionYear, [FK_CCYSettlement], FK_AccountingPeriod, DevelopmentQuarter, PatternScenario, 
			              PatternScenarioVersion, DevelopmentPercentageIncrement,DevelopmentPercentageCumulative, AuditSourceBatchID, AuditGenerateDateTime)
			
			SELECT	FK_Batch,FK_Dataset,TDH_DatasetName,FK_PatternName,FK_Trifocus,FK_YOA,FK_InceptionYear,[CCYSettlement],AP.PK_AccountingPeriod AS FK_AccountingPeriod
					,DevelopmentQuarter,PatternScenario,PatternScenarioVersion,DevelopmentPercentageIncrement,DevelopmentPercentageCumulative,p.AuditSourceBatchID AS AuditSourceBatchID
					,AuditGenerateDateTime
			FROM F_Pattern P
			LEFT JOIN TechnicalHub.dim.AccountingPeriod AP ON AP.BK_AccountingPeriod=p.FK_AccountingPeriod



		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END