﻿/*==========================================================================================================
Is:		fct.USP_Sidecar
Does:	calculates the Side car premium for Eurobase and USpremium
==========================================================================================================*/

CREATE PROCEDURE Fct.USP_SideCar 
AS
BEGIN

DECLARE		@MAXBATCHid INT
SELECT		@MAXBATCHid = MAX(ISNULL(FK_Batch,0))
FROM		fct.TechnicalResult tr
LEFT JOIN DIM.Entity DE ON DE.PK_Entity=TR.FK_Entity
WHERE		DE.BK_Entity = '6107'

;WITH SCar AS(																
SELECT 
				   tr.[FK_Batch] AS FK_Batch
				  ,tr.[FK_DataSet] AS FK_DataSet
				  ,tr.[FK_Scenario] AS FK_Scenario
				--  ,tr.[FK_Account] AS FK_Account   ----
					,DA.BK_Account as BK_Account     --++
				  ,tr.[FK_AccountingPeriod] AS FK_AccountingPeriod
				  ,tr.[FK_Basis] AS FK_Basis
				  ,tr.[FK_DataStage] AS FK_DataStage
				  ,'6107' AS BK_Entity
				  ,tr.[FK_Policy] AS FK_Policy
				  ,tr.FK_PolicySection AS FK_PolicySection
				  ,tr.FK_Process AS FK_Process
				  ,tr.[FK_Product] AS FK_Product
				  ,tr.[FK_Location]  AS FK_Location
				  ,tr.[FK_Trifocus] AS FK_Trifocus
				  ,tr.[FK_YOA] AS FK_YOA
				  ,tr.[FK_Allocation] AS FK_Allocation
				  ,tr.[FK_CCYOriginal] AS CCYOriginal
				  ,tr.[FK_CCYSettlement] AS CCYSettlement
				  ,tr.[FK_DateDue] AS FK_DateDue
				  ,tr.[Value]*scp.[PERCENT]/100.0000000  AS [Value]
				  ,tr.[EarningPercentage] AS EarningPercentage
				  ,tr.[Fk_statscode] AS Fk_statscode
				  ,tr.[RowHash] AS RowHash
				  ,tr.[AuditSourceBatchID] AS AuditSourceBatchID
				  ,tr.AuditUserCreate AS AuditUserCreate
				  ,getdate() AS AuditCreateDateTime
				  ,getdate() AS AuditGenerateDateTime
				  ,InceptionPeriod
				  ,FK_CatCode
				  ,[FK_MovementType]
				  ,[FK_TrackingStatus]
				  ,[FK_ClaimExposure]
				  ,[FK_DateOfFact]
				  ,[BusinessKey]
				  ,FK_InceptionDate
  FROM				[fct].[TechnicalResult] TR
 LEFT JOIN Dim.YOA Y ON Y.PK_YOA=TR.FK_YOA  --++
 LEFT JOIN Dim.TriFocus TF ON TF.PK_TriFocus=TR.FK_Trifocus
 INNER JOIN			fct.SIDECARPERCENTAGES SCP
		ON			TF.BK_Trifocus = SCP.TriFocus
		 AND                  CAST(Y.BK_YOA AS VARCHAR(10)) = CAST(SCP.YOA AS varchar(10)) --++
		AND			(ISNULL(TR.Fk_statscode,'') = CASE  
					WHEN SCP.statscode = 'SC'  THEN SCP.STATSCODE
					WHEN SCP.STATSCODE = 'ALL' THEN ISNULL(TR.Fk_statscode ,'')
					END  )
LEFT JOIN Dim.Account DA ON DA.PK_Account=TR.FK_Account   --++
LEFT JOIN Dim.Entity DE ON DE.PK_Entity=TR.FK_Entity      --++
WHERE	FK_Batch  in (SELECT PK_Batch FROM [FinanceDataContract].[Inbound].[BatchQueue]	WHERE Status in('Earnings','TechnicalHub') AND DataSet IN ('Eurobase','USPremium','BIDAC','USBAIC','BICI'))

UNION

SELECT 
                              tr.[FK_Batch] AS FK_Batch
                             ,tr.[FK_DataSet] AS FK_DataSet
                             ,tr.[FK_Scenario] AS FK_Scenario
                             --,CASE WHEN tr.[FK_Account] IN('P-GP-P','P-AC-P') THEN 'P-RI-P'
                             --            WHEN tr.[FK_Account] IN('P-GP-B','P-AC-B') THEN 'P-RI-B'
                             --            ELSE tr.[FK_Account] END
							 ,BK_Account=CASE WHEN DA.[BK_Account] IN('P-GP-P','P-AC-P') THEN 'P-RI-P'
                                         WHEN DA.[BK_Account] IN('P-GP-B','P-AC-B') THEN 'P-RI-B'
                                         ELSE DA.[BK_Account] END
                             ,tr.[FK_AccountingPeriod] AS FK_AccountingPeriod
                             ,tr.[FK_Basis] AS FK_Basis
                             ,tr.[FK_DataStage]  AS FK_DataStage
                             --,tr.FK_Entity   AS FK_Entity 
							 ,DE.BK_Entity	 AS BK_Entity						--++
                             ,tr.[FK_Policy] AS FK_Policy
							 ,tr.FK_PolicySection AS FK_PolicySection
                             ,tr.FK_Process AS FK_Process
                             ,tr.[FK_Product] AS FK_Product
                             ,tr.[FK_Location] AS FK_Location
                             ,tr.[FK_Trifocus] AS FK_Trifocus
                             ,tr.[FK_YOA]   AS FK_YOA
                             ,tr.[FK_Allocation] AS FK_Allocation
                             ,tr.[FK_CCYOriginal] AS CCYOriginal
                             ,tr.[FK_CCYSettlement] AS CCYSettlement
                             ,tr.[FK_DateDue] AS FK_DateDue
                             ,tr.[Value]*scp.[PERCENT]/100.0000000  AS [Value]
                             ,tr.[EarningPercentage] AS EarningPercentage
                             ,tr.[Fk_statscode] AS Fk_statscode
                             ,tr.[RowHash]  AS RowHash
                             ,tr.[AuditSourceBatchID] AS AuditSourceBatchID
                             ,tr.AuditUserCreate AS AuditUserCreate
                             ,getdate() AS AuditCreateDateTime
                             ,getdate() AS AuditGenerateDateTime
							 ,InceptionPeriod
							,FK_CatCode
							,[FK_MovementType]
							,[FK_TrackingStatus]
							,[FK_ClaimExposure]
							,[FK_DateOfFact]
							,[BusinessKey]
							,FK_InceptionDate
  FROM                     [fct].[TechnicalResult] TR
   LEFT JOIN Dim.YOA Y ON Y.PK_YOA=TR.FK_YOA    --++
   LEFT JOIN Dim.TriFocus TF ON TF.PK_TriFocus=TR.FK_Trifocus
INNER JOIN                fct.SIDECARPERCENTAGES SCP
              ON                   TF.BK_Trifocus = SCP.TriFocus
               AND                  CAST(Y.BK_YOA AS VARCHAR(10)) = CAST(SCP.YOA AS varchar(10))
              AND                  (ISNULL(TR.Fk_statscode,'') = CASE  
                                  WHEN SCP.statscode = 'SC'  THEN SCP.STATSCODE
                                  WHEN SCP.STATSCODE = 'ALL' THEN ISNULL(TR.Fk_statscode ,'')
                                  END  )
LEFT JOIN Dim.Account DA ON DA.PK_Account=TR.FK_Account   --++
LEFT JOIN Dim.Entity DE ON DE.PK_Entity=TR.FK_Entity      --++

--WHERE  TR.FK_Account  IN ('P-GP-P','P-AC-P','P-GP-B','P-AC-B')  ----
WHERE  DA.BK_Account  IN ('P-GP-P','P-AC-P','P-GP-B','P-AC-B') 
AND 
FK_Batch  in (SELECT PK_Batch FROM [FinanceDataContract].[Inbound].[BatchQueue]   WHERE Status in ('Earnings','TechnicalHub') AND DataSet IN ('Eurobase','USPremium','BIDAC','USBAIC','BICI'))

)

INSERT	stg.fct_TechnicalResult WITH (TABLOCK)(	FK_Batch, FK_DataSet, FK_Scenario, FK_Account, FK_AccountingPeriod, FK_Basis, FK_DataStage, FK_Entity, FK_Policy,FK_PolicySection,
												FK_Process, FK_Product, FK_Location, FK_Trifocus, FK_YOA, FK_Allocation, [FK_CCYOriginal], [FK_CCYSettlement], [FK_DateDue], Value, EarningPercentage
												,Fk_statscode, RowHash, AuditSourceBatchID, AuditUserCreate, AuditCreateDateTime, AuditGenerateDateTime,
												InceptionPeriod,FK_CatCode,[FK_MovementType],[FK_TrackingStatus],[FK_ClaimExposure],[FK_DateOfFact],[BusinessKey],FK_InceptionDate,FK_RIPolicyType,FK_ProgrammeCode
											)
																
SELECT	FK_Batch
		,FK_DataSet
		,FK_Scenario
		,da.PK_Account as FK_Account
		,FK_AccountingPeriod
		,FK_Basis
		,FK_DataStage
		,DE.PK_Entity AS FK_Entity
		,FK_Policy
		,FK_PolicySection 
		,FK_Process
		,FK_Product
		,FK_Location
		,FK_Trifocus
		,FK_YOA
		,FK_Allocation
		,[CCYOriginal]
		,[CCYSettlement]
		,FK_DateDue
		,[Value]
		,EarningPercentage
		,Fk_statscode
		,RowHash
		,SC.AuditSourceBatchID AS AuditSourceBatchID 
		,SC.AuditUserCreate AS AuditUserCreate
		,SC.AuditCreateDateTime AS AuditCreateDateTime
		,AuditGenerateDateTime
		,InceptionPeriod
		,FK_CatCode
		,FK_MovementType
		,FK_TrackingStatus
		,FK_ClaimExposure
		,FK_DateOfFact
		,BusinessKey
		,FK_InceptionDate
		,-2
		,-2
FROM SCar SC
LEFT JOIN dim.Entity DE ON DE.BK_Entity=SC.BK_Entity
LEFT JOIN DIM.Account DA ON DA.BK_Account=SC.BK_Account

RAISERROR('stg.fct_TechnicalResult: %i', 0, 0, @@rowcount) WITH NOWAIT;


END


 

 