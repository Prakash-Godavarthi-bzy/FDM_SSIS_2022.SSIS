﻿
/*====================================================================================================
Is:		[fct].[usp_TechnicalResultLTD_V2]
Does:	Updates latest cumulative values with fct data
====================================================================================================*/

--EXEC [fct].[usp_TechnicalResultLTD_V2] 202012

CREATE PROCEDURE [fct].[usp_TechnicalResultLTD_V2](@AccPer AS INT = NULL)
AS
BEGIN

   --DECLARE @AccPer AS INT = 201905
	DECLARE @MinAccPer AS INT
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
	IF @Trancount = 0 
	  BEGIN TRAN;
	  Exec IFRS17Datamart.[dbo].[usp_LogIFRS17DataMart]
													@v_ActivityMessage='[fct].[usp_TechnicalResultLTD_V2] Proc Execution Startetd', 
													@v_ActivityStatus =1         , --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName='[fct].[usp_TechnicalResultLTD_V2]'
---If @AccPer is Null the LTD table will be truncated and populated with all Accounting Period data. 
---If @AccPer is not null then below process will take place and will append the new Accounting periods into LTD table
		IF @AccPer IS NOT NULL
			BEGIN

-----Truncate the staging tables
				TRUNCATE TABLE [stg].[fct_TechnicalResultLTD_Step1]
				TRUNCATE TABLE [stg].[fct_TechnicalResultLTD_Step2]

------Find the last populated Accounting Period from the LTD table
				SELECT @MinAccPer = COALESCE(MAX(FK_ACCOUNTINGPERIOD), 198001) FROM FCT.TechnicalResultLTD_V2 WHERE Fk_dataset IN ('Eurobase','USPremium')

				DROP TABLE IF EXISTS #NewData

				SELECT DISTINCT  
					  T2.BK_PolicyNumber
					, T1.FK_Policy
					, T1.FK_Batch
					, T1.FK_Account
					, T1.FK_AccountingPeriod
					, T1.FK_Basis
					, T1.FK_Entity
					, T2.InceptionDate
					, T2.ExpiryDate
					, T1.FK_Process
					, T1.FK_Trifocus
					, T1.FK_YOA
					, T1.[FK_CCYOriginal]
					, T1.[FK_CCYSettlement]
					, T1.Fk_dataset
					, T1.FK_scenario
					, T1.FK_inceptionyear
					, T2.policytype
					, T1.[Value]
				INTO #NewData
				FROM FCT.TechnicalResult t1
				INNER JOIN DIM.[Policy] t2 ON t1.FK_Policy = t2.PK_Policy 
				WHERE 1=1
				AND FK_DataSet IN ('Eurobase','USPremium')
				AND FK_Process='IP'
				AND (FK_AccountingPeriod > @MinAccPer  AND FK_AccountingPeriod <= @AccPer)
				--AND (FK_AccountingPeriod > 201904 AND FK_AccountingPeriod <= 201910)--@AccPer)
				--AND BK_PolicyNumber = 'T9068X18APCS'

				Exec IFRS17Datamart.[dbo].[usp_LogIFRS17DataMart]
													@v_ActivityMessage=' Data Inserted into #NewData From Fct.TechnicalResult ', 
													@v_ActivityStatus =5         , --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName='[fct].[usp_TechnicalResultLTD_V2]'

--select count(*) from #NewData where FK_inceptionyear is null

----All the policies that are there in #Newdata, Get their last cumulative values(if exists) from the LTD table by ordering them and getting roworder = 1

		DROP TABLE IF EXISTS #RowOrder
		SELECT        T1.FK_Account
					, T1.FK_Basis
					, T1.FK_Entity
					, T1.BK_PolicyNumber
					, T1.InceptionDate
					, T1.ExpiryDate
					, T1.FK_Process
					, T1.FK_Trifocus
					, T1.FK_YOA
					, T1.CCYOriginal
					, T1.CCYSettlement 
					, T1.Fk_dataset
					, T1.FK_scenario
					, T1.FK_inceptionyear
					, T1.policytype
					, T1.FK_AccountingPeriod
					, T1.[Value]
					,ROW_NUMBER() 
						OVER (PARTITION BY 
						  T1.FK_Account, T1.FK_Basis, T1.FK_Entity, T1.BK_PolicyNumber, T1.InceptionDate, T1.ExpiryDate, T1.FK_Process, T1.FK_Trifocus, T1.FK_YOA
						, T1.CCYOriginal, T1.CCYSettlement, T1.Fk_dataset, T1.FK_scenario, T1.FK_inceptionyear, T1.policytype
						ORDER BY T1.FK_AccountingPeriod DESC
									)	RowOrder
		INTO #RowOrder
		FROM FCT.TechnicalResultLTD_V2 T1
		INNER JOIN #NewData T2 ON       T1.FK_Account      = T2.FK_Account
									AND T1.FK_Basis        = T2.FK_Basis
									AND T1.FK_Entity	   = T2.FK_Entity
									AND T1.BK_PolicyNumber = T2.BK_PolicyNumber
									AND T1.InceptionDate   = T2.InceptionDate
									AND T1.ExpiryDate	   = T2.ExpiryDate
									AND T1.FK_Process	   = T2.FK_Process
									AND T1.FK_Trifocus	   = T2.FK_Trifocus
									AND T1.FK_YOA		   = T2.FK_YOA
									AND T1.CCYOriginal	   = T2.[FK_CCYOriginal]
									AND T1.CCYSettlement   = T2.[FK_CCYSettlement]
									AND T1.Fk_dataset	   = T2.Fk_dataset
									AND T1.FK_scenario	   = T2.FK_scenario
									AND T1.FK_inceptionyear= T2.FK_inceptionyear
									AND T1.policytype	   = T2.policytype


--SELECT * FROM #RowOrder

-----------------------Get the last cumulative value (RowOrder = 1) of the policies that have changed
				INSERT INTO [stg].[fct_TechnicalResultLTD_Step1]([New_Exe_Policy], [BK_PolicyNumber],	[FK_Account], [FK_AccountingPeriod], [FK_Basis], [FK_Entity], [InceptionDate]
				,	[ExpiryDate],	[FK_Process],	[FK_Trifocus],	[FK_YOA],	[CCYOriginal],	[CCYSettlement], [Fk_dataset],	[FK_scenario],	[FK_inceptionyear],	[policytype],	[Value]	)
				SELECT DISTINCT
					1,
					lc.[BK_PolicyNumber],
					lc.[FK_Account] ,
					lc.[FK_AccountingPeriod],
					lc.[FK_Basis] ,
					lc.[FK_Entity],
					lc.[InceptionDate],
					lc.[ExpiryDate],
					lc.[FK_Process],
					lc.[FK_Trifocus],
					lc.[FK_YOA],
					lc.[CCYOriginal],
					lc.[CCYSettlement],
					lc.[Fk_dataset],
					lc.[FK_scenario],
					lc.[FK_inceptionyear],
					lc.[policytype],
					lc.[Value]
				FROM #RowOrder lc
				WHERE LC.RowOrder = 1
				Exec IFRS17Datamart.[dbo].[usp_LogIFRS17DataMart]
													@v_ActivityMessage=' Data inserted into [stg].[fct_TechnicalResultLTD_Step1] For RowOrder 1  ',  
													@v_ActivityStatus =5         , --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName='[fct].[usp_TechnicalResultLTD_V2]'

----------------Populate the #Newdata in to stg table to do the LTD calculation later
				INSERT INTO [stg].[fct_TechnicalResultLTD_Step1]([New_Exe_Policy], [BK_PolicyNumber],	[FK_Account], [FK_AccountingPeriod], [FK_Basis], [FK_Entity], [InceptionDate],	
				[ExpiryDate],	[FK_Process],	[FK_Trifocus],	[FK_YOA],	[CCYOriginal],	[CCYSettlement], [Fk_dataset],	[FK_scenario],	[FK_inceptionyear],	[policytype],	[Value]	)
				SELECT 
					2,
					tr.[BK_PolicyNumber],
					TR.[FK_Account] ,
					TR.[FK_AccountingPeriod],
					TR.[FK_Basis] ,
					TR.[FK_Entity],
					tr.[InceptionDate],
					tr.[ExpiryDate],
					TR.[FK_Process],
					TR.[FK_Trifocus],
					TR.[FK_YOA],
					TR.[FK_CCYOriginal],
					TR.[FK_CCYSettlement],
					TR.[Fk_dataset],
					TR.[FK_scenario],
					TR.[FK_inceptionyear],
					tr.[policytype],
					TR.[Value]
				FROM #NewData tr

--- Below temp table are to figure out if any Policy had change in it attribute like expiry dt, inception dt or value.
				DROP TABLE IF EXISTS #PolicyList
				SELECT Distinct P.BK_PolicyNumber
				INTO #PolicyList
				FROM DIM.[Policy] P
				INNER JOIN #NewData	TR ON P.PK_Policy = TR.FK_Policy


				DROP TABLE IF EXISTS #PolicyWithOutChange
				SELECT P.BK_PolicyNumber
				INTO #PolicyWithOutChange
				FROM DIM.[Policy] P
				INNER JOIN #PolicyList	PL ON P.BK_PolicyNumber = PL.BK_PolicyNumber
				GROUP BY P.BK_PolicyNumber
				HAVING COUNT(*) = 1

				DROP TABLE IF EXISTS #PolicyWithChange
				SELECT P.BK_PolicyNumber
				INTO #PolicyWithChange
				FROM DIM.[Policy] P
				INNER JOIN #PolicyList	PL ON P.BK_PolicyNumber = PL.BK_PolicyNumber
				GROUP BY P.BK_PolicyNumber
				HAVING COUNT(*) > 1

---- Populate the Life to date values into step2 stg table
				INSERT INTO [stg].[fct_TechnicalResultLTD_Step2]([New_Exe_Policy],	[BK_PolicyNumber],	[FK_Account], [FK_AccountingPeriod], [FK_Basis], [FK_Entity], [InceptionDate],	
				ExpiryDate,	[FK_Process],	[FK_Trifocus],	[FK_YOA],	[CCYOriginal],	[CCYSettlement], [Fk_dataset],	[FK_scenario],	[FK_inceptionyear],	[policytype],	[Value])
				SELECT
					  [New_Exe_Policy]
					, BK_PolicyNumber
					, FK_Account
					, FK_AccountingPeriod
					, FK_Basis
					, FK_Entity
					, InceptionDate
					, ExpiryDate
					, FK_Process
					, FK_Trifocus
					, FK_YOA
					, CCYOriginal
					, CCYSettlement
					, Fk_dataset
					, FK_scenario
					, FK_inceptionyear
					, policytype
					, SUM(Value)
						OVER( PARTITION BY FK_Account
							, FK_Basis
							, FK_Entity
							, BK_PolicyNumber
							, InceptionDate
							, ExpiryDate
							, FK_Process
							, FK_Trifocus
							, FK_YOA
							, CCYOriginal
							, CCYSettlement 
							, Fk_dataset
							, FK_scenario
							, FK_inceptionyear
							, policytype
							ORDER BY FK_AccountingPeriod) AS [Value]
 				FROM [stg].[fct_TechnicalResultLTD_Step1]

				Exec IFRS17Datamart.[dbo].[usp_LogIFRS17DataMart]
													@v_ActivityMessage=' Data inserted into [stg].[fct_TechnicalResultLTD_Step2]  of LTD Values.',  
													@v_ActivityStatus =5         , --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName='[fct].[usp_TechnicalResultLTD_V2]'


---------------------POPULATE [fct].[TechnicalResultLTD_V2]

				INSERT INTO [fct].[TechnicalResultLTD_V2]
				   ([BK_PolicyNumber],	[FK_Account],	[FK_Basis] ,	[FK_Entity], [InceptionDate],	[ExpiryDate],	[FK_Process], [FK_Trifocus],	[FK_YOA],	[CCYOriginal],	[CCYSettlement],
					[Fk_dataset],	[FK_scenario],	[FK_inceptionyear],	[policytype],	[FK_AccountingPeriod],	[Value]   )
				SELECT
					[BK_PolicyNumber],
					[FK_Account] ,
					[FK_Basis] ,
					[FK_Entity],
					[InceptionDate],
					[ExpiryDate],
					[FK_Process],
					[FK_Trifocus],
					[FK_YOA],
					[CCYOriginal],
					[CCYSettlement],
					[Fk_dataset],
					[FK_scenario],
					[FK_inceptionyear],
					[policytype],
					[FK_AccountingPeriod],
					[Value]
				FROM
				(SELECT DISTINCT
					A.[BK_PolicyNumber],
					[FK_Account] ,
					[FK_Basis] ,
					[FK_Entity],
					[InceptionDate],
					[ExpiryDate],
					[FK_Process],
					[FK_Trifocus],
					[FK_YOA],
					[CCYOriginal],
					[CCYSettlement],
					[Fk_dataset],
					[FK_scenario],
					[FK_inceptionyear],
					[policytype],
					[FK_AccountingPeriod],
					[Value]
				FROM [stg].[fct_TechnicalResultLTD_Step2] A
				INNER JOIN #PolicyWithOutChange B ON A.BK_PolicyNumber = B.BK_PolicyNumber
				WHERE New_Exe_Policy > 1

				UNION ALL

				SELECT DISTINCT
					A.[BK_PolicyNumber],
					[FK_Account] ,
					[FK_Basis] ,
					[FK_Entity],
					[InceptionDate],
					[ExpiryDate],
					[FK_Process],
					[FK_Trifocus],
					[FK_YOA],
					[CCYOriginal],
					[CCYSettlement],
					[Fk_dataset],
					[FK_scenario],
					[FK_inceptionyear],
					[policytype],
					[FK_AccountingPeriod],
					[Value]
				FROM [stg].[fct_TechnicalResultLTD_Step2] A
				INNER JOIN #PolicyWithChange B ON A.BK_PolicyNumber = B.BK_PolicyNumber
				WHERE New_Exe_Policy > 1
				AND A.[Value] <> 0
			)T

			Exec IFRS17Datamart.[dbo].[usp_LogIFRS17DataMart]
													@v_ActivityMessage=' Data inserted into [fct].[TechnicalResultLTD_V2] If Ended.',  
													@v_ActivityStatus =2         , --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName='[fct].[usp_TechnicalResultLTD_V2]'

			END
			
      ELSE ---- If @AccPer is Null the LTD table will be truncated and populated with all Accounting Period data. 
			BEGIN
			Exec IFRS17Datamart.[dbo].[usp_LogIFRS17DataMart]
													@v_ActivityMessage='Else Condition Started',  
													@v_ActivityStatus =5         , --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName='[fct].[usp_TechnicalResultLTD_V2]'
			 TRUNCATE TABLE fct.TechnicalResultLTD_V4

				DROP TABLE IF EXISTS #PoliciesList
				SELECT Distinct P.BK_PolicyNumber
				INTO #PoliciesList
				FROM DIM.[Policy] P
				INNER JOIN [TechnicalHub].[fct].[TechnicalResult]	TR ON P.PK_Policy = TR.FK_Policy
				WHERE TR.FK_DataSet IN ('Eurobase','USPremium')
				AND TR.FK_Process='IP'

				DROP TABLE IF EXISTS #PoliciesWithOutChange
				SELECT P.BK_PolicyNumber
				INTO #PoliciesWithOutChange
				FROM DIM.[Policy] P
				INNER JOIN #PoliciesList	PL ON P.BK_PolicyNumber = PL.BK_PolicyNumber
				GROUP BY P.BK_PolicyNumber
				HAVING COUNT(*) = 1

				DROP TABLE IF EXISTS #PoliciesWithChange
				SELECT P.BK_PolicyNumber
				INTO #PoliciesWithChange
				FROM DIM.[Policy] P
				INNER JOIN #PoliciesList	PL ON P.BK_PolicyNumber = PL.BK_PolicyNumber
				GROUP BY P.BK_PolicyNumber
				HAVING COUNT(*) > 1

			DROP TABLE IF EXISTS #PolicyWithLTD
			SELECT
				DISTINCT 
				 p.BK_PolicyNumber
				, FK_Account
				, FK_AccountingPeriod
				, FK_Basis
				, FK_Entity
				, p.InceptionDate
				, p.ExpiryDate
				, FK_Process
				, FK_Trifocus
				, FK_YOA
				, FK_CCYOriginal
				, FK_CCYSettlement
				, Fk_dataset
				, FK_scenario
				, FK_inceptionyear
				, policytype
				, SUM(Value)
					OVER( PARTITION BY FK_Account
						, FK_Basis
						, FK_Entity
						, p.BK_PolicyNumber
						, p.InceptionDate
						, p.ExpiryDate
						, FK_Process
						, FK_Trifocus
						, FK_YOA
						, FK_CCYOriginal
						, FK_CCYSettlement 
						, Fk_dataset
						, FK_scenario
						, FK_inceptionyear
						, policytype
						ORDER BY FK_AccountingPeriod) AS [Value]
				INTO #PolicyWithLTD
				FROM [TechnicalHub].[fct].[TechnicalResult] t
				JOIN Dim.Policy p ON p.PK_Policy =t.FK_Policy
				WHERE 1=1
				AND FK_DataSet IN ('Eurobase','USPremium')
				AND FK_Process='IP'


			---FINAL SELECT---
			INSERT INTO fct.TechnicalResultLTD_V4(FK_Account,FK_Basis,BK_PolicyNumber,FK_Entity,InceptionDate , ExpiryDate , FK_Process, FK_Trifocus , FK_YOA , CCYOriginal , CCYSettlement, Fk_dataset, 
						FK_scenario , FK_inceptionyear , policytype , [Value] , FK_AccountingPeriod)
			SELECT   T.FK_Account
				   , T.FK_Basis
				   , T.BK_PolicyNumber
				   , T.FK_Entity
				   , T.InceptionDate
				   , T.ExpiryDate
				   , T.FK_Process
				   , T.FK_Trifocus
				   , T.FK_YOA
				   , T.FK_CCYOriginal
				   , T.FK_CCYSettlement
				   , Fk_dataset
				   , FK_scenario
				   , FK_inceptionyear
				   , policytype
				   , T.[Value]
				   , T.FK_AccountingPeriod
			FROM 
			(
				SELECT  
					  A.FK_Account
					, A.FK_Basis
					, A.BK_PolicyNumber
					, A.FK_Entity
					, A.InceptionDate
					, A.ExpiryDate
					, A.FK_Process
					, A.FK_Trifocus
					, A.FK_YOA
					, A.FK_CCYOriginal
					, A.FK_CCYSettlement
					, A.Fk_dataset
					, A.FK_scenario
					, A.FK_inceptionyear
					, A.policytype
					, A.[Value]
					, A.FK_AccountingPeriod 
				FROM #PolicyWithLTD A
				INNER JOIN #PoliciesWithOutChange B ON A.BK_PolicyNumber = B.BK_PolicyNumber

				UNION ALL

				SELECT  
					  A.FK_Account
					, A.FK_Basis
					, A.BK_PolicyNumber
					, A.FK_Entity
					, A.InceptionDate
					, A.ExpiryDate
					, A.FK_Process
					, A.FK_Trifocus
					, A.FK_YOA
					, A.FK_CCYOriginal
					, A.FK_CCYSettlement
					, A.Fk_dataset
					, A.FK_scenario
					, A.FK_inceptionyear
					, A.policytype
					, A.[Value]
					, A.FK_AccountingPeriod 
				FROM  #PolicyWithLTD A
				INNER JOIN #PoliciesWithChange B ON A.BK_PolicyNumber = B.BK_PolicyNumber
				WHERE [Value] <> 0
			) T
			--WHERE T.BK_PolicyNumber IN  ('B2026C19BNPA'  ,'B7149F19ANPA')
			--AND T.FK_Entity = '2623'
			--AND T.FK_Account='P-GP-B'

			Exec IFRS17Datamart.[dbo].[usp_LogIFRS17DataMart]
													@v_ActivityMessage=' Data inserted into [fct].[TechnicalResultLTD_V2] for Null Accounting Periods.',  
													@v_ActivityStatus =2         , --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName='[fct].[usp_TechnicalResultLTD_V2]'
			END

	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
	Exec IFRS17Datamart.[dbo].[usp_LogIFRS17DataMart]
													@v_ActivityMessage='Catch Block executed',  
													@v_ActivityStatus =4       , --1 started 2 succeded 3 stopped 4 errored 5 information 
													@v_ActivityName='[fct].[usp_TechnicalResultLTD_V2]'
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

DROP TABLE IF EXISTS #NewData;
DROP TABLE IF EXISTS #RowOrder;
DROP TABLE IF EXISTS #PolicyList;
DROP TABLE IF EXISTS #PolicyWithOutChange;
DROP TABLE IF EXISTS #PolicyWithChange;
DROP TABLE IF EXISTS #PoliciesList;
DROP TABLE IF EXISTS #PoliciesWithOutChange;
DROP TABLE IF EXISTS #PoliciesWithChange;
DROP TABLE IF EXISTS #PolicyWithLTD;

END