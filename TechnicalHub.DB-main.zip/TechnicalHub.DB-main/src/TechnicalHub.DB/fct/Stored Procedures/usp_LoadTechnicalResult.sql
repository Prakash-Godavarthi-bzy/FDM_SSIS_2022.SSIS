﻿CREATE PROC [fct].[usp_LoadTechnicalResult]  
 @p_Dataset		VARCHAR(255) = NULL
,@p_BatchId		VARCHAR(255) = NULL
AS
/*=========================================================================================
This SQL Procedural Object used to generate TechnicalHub data from OutboundTransactions with Rules derived.
This Proc call by SSIS FactTechnicalResult_IFRS17.dtsx of TechnicalHub.SSIS
This is In general object for all daa


Modified By:	Entha.Bhargav@beazley.com
Modified Date:		08/01/2024
Description:	 TreatyShare Rules to create additional records from 623 share into BIDAC(8033) of given TreatySharepercentage of [MDS].[TreatyShareGenerationRules]-Populates from Static Script held at FinanceLanding.DB
				https://beazley.atlassian.net/browse/I1B-5083

Modified By:	Nithin.Dumpeti@beazley.com
Modified Date:		08/03/2024
Description:	 duplication occurs in [Outbound].PolicySectionReference for SectionReference. filtering out duplicates by loading into #plosec with the latest FK_Batch
				https://beazley.atlassian.net/browse/I1B-5341

Modified By:	Entha.Bhargav@beazley.com
Modified Date:	07/04/2024
Description:	Remove the TreatyShare rule applied part of 5083. Which was applied Post InterCompany rules.

				5422 change intended to apply Treaty Share new records generation before InterCompany rules
				TreatyShare Rules to create additional records from 623 share into BIDAC(8033) of given TreatySharepercentage of [MDS].[TreatyShareGenerationRules]-Populates from Static Script held at FinanceLanding.DB
				https://beazley.atlassian.net/browse/I1B-5422

Modified By:	venkat.yerravati@beazley.com
Modified Date:		24/06/2024
Description:	 FAC Programme Mapping - RI Spend fallback to be used
				https://beazley.atlassian.net/browse/I1B-5613


=================================================================================================*/

BEGIN
SET NOCOUNT ON;

DECLARE @Trancount	INT = @@Trancount;
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID);
	DECLARE @Logging log.utt_ActivityLog;

	/*======================================================Logging Starts==================================================*/
	--DECLARE @Trancount	INT = @@Trancount;
	DECLARE @v_ErrorMessage NVARCHAR(4000);

	DECLARE @v_RC							INT;
	DECLARE @v_ActivityLogTag				BIGINT;
	DECLARE @v_ActivitySource				SMALLINT;
	DECLARE @v_ActivityType					SMALLINT;
	DECLARE @v_ActivityStatusStart			SMALLINT;
	DECLARE @v_ActivityStatusStop			SMALLINT;
	DECLARE @v_ActivityStatusFail			SMALLINT;
	DECLARE @v_ActivityHost					VARCHAR(100);
	DECLARE @v_ActivityDatabase				VARCHAR(100)    = 'TechnicalHub';
	DECLARE @v_ActivityName					VARCHAR(100);
	DECLARE @v_ActivityDateTime				DATETIME2(2);
	DECLARE @v_ActivityMessage				NVARCHAR(4000);
	DECLARE @v_ActivityErrorCode			NVARCHAR(50);
	DECLARE @v_ActivityLogIdIn				BIGINT;
	DECLARE @v_ActivityLogIdOut				BIGINT;
	DECLARE @v_ActivityJobId				VARCHAR(50)		= NULL;
	DECLARE @v_ActivitySSISExecutionId		VARCHAR(50)		= NULL;
	DECLARE @v_AffectedRows					INT
	--DECLARE @ContractType					CHAR(3)			= 'RDEA';
	DECLARE		@p_ParentActivityLogId		BIGINT			= NULL

	DECLARE @v_Dataset varchar(50)=@v_ActivityDatabase
	DECLARE @v_BatchId                   INT             = NULL;
	DECLARE @v_BatchId_Extensions INT;



	SELECT @v_ActivityStatusStart = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'STARTED';

	SELECT @v_ActivityStatusStop = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'SUCCEEDED';

	SELECT @v_ActivityStatusFail = PK_ActivityStatus 
	FROM Orchestram.Log.ActivityStatus	
	WHERE ActivityStatus = 'ERRORED';

	--INSERT INTO [dbo].[Batch]([CreateDate],[DataSet]) 
	--VALUES  (GETDATE(),@v_Dataset);

	--SELECT @v_BatchId = SCOPE_IDENTITY();

	--SET @v_ActivityJobId=@v_BatchId

	/* Log the start of the insert */
	SELECT   
		@v_ActivityLogTag		        = NULL
	   ,@v_ActivitySource				= (SELECT PK_ActivitySource FROM Orchestram.Log.ActivitySource	WHERE ActivitySource	= 'DataContract')
	   ,@v_ActivityType				    = (SELECT PK_ActivityType	
										FROM Orchestram.Log.ActivityType	
										WHERE ActivityType = CASE 
																WHEN @p_ParentActivityLogId IS NULL 
																	THEN 'Manual process' 
																	ELSE 'Automated process' 
																END)
	   ,@v_ActivityHost				    = @@SERVERNAME
	   ,@v_ActivityName				    = @p_ActivityName
	   ,@v_ActivityDateTime			    = GETUTCDATE()
	   ,@v_ActivityMessage			 	= 'Load into stg.FactTechnicalResult_Results for BatchId '+@p_BatchId
	   ,@v_ActivityErrorCode			= NULL
	   ,@v_AffectedRows				    = 0;

	EXECUTE @v_RC = Orchestram.Log.usp_ActivityLog
				 @p_ParentActivityLogId
				,@v_ActivityLogTag
				,@v_ActivitySource
				,@v_ActivityType
				,@v_ActivityStatusStart
				,@v_ActivityHost
				,@v_ActivityDatabase
				,@v_ActivityJobId
				,@v_ActivitySSISExecutionId
				,@v_ActivityName
				,@v_ActivityDateTime
				,@v_ActivityMessage
				,@v_ActivityErrorCode
				,@v_AffectedRows
				,@v_ActivityLogIdIn OUTPUT;

	SELECT @v_ActivityLogTag = @v_ActivityLogIdIn;

BEGIN TRY
		IF @Trancount = 0 
			BEGIN TRAN;

if object_id('tempdb..#polsec') is not null drop table #polsec

select PolicyReference,SectionReference into #polsec 
from
(
select PolicyReference,SectionReference, rank() over(partition by sectionreference order by fk_batch desc) rnk
FROM [FinanceDataContract].Outbound.PolicySectionReference
)psr 
where rnk = 1 

if object_id('tempdb..#srctxn') is not null drop table #srctxn

SELECT  
			OT.PK_Transaction,
			OT.Dataset,
			OT.[AuditSourceBatchID] AS [FK_Batch]
			,LTRIM(RTRIM(COALESCE(tce.BeazleyCatCode,re.BeazleyCatCode))) As BeazleyCatCode
			,LTRIM(RTRIM(CAST(COALESCE(tce.IsLargeLossClaim,re.IsLargeLoss) AS VARCHAR(5))))  As LargeLoss
			,LTRIM(RTRIM(Tce.MovementType))AS MovementType
			,LTRIM(RTRIM(Tce.TransactionTrackingStatus)) AS TrackingStatus,
			DataSet AS [FK_DataSet],
			[Scenario] AS [FK_Scenario],
			[Account] AS [FK_Account],
			CASE WHEN OT.Dataset='LPSO' Then 'Booked'
			ELSE 'Estimated' END [FK_Basis],
			2 AS [PK_DataStage],
			OT.Entity as FK_SourceEntity,
			OT.DeltaType as FK_DeltaType,
			CAST(ISNULL(S.SyndSplitEntity,OT.Entity) AS VARCHAR(25)) AS [FK_Entity],
			BK_PolicySection = +'[' + ISNULL(polsec.PolicyReference,[PolicyNumber]) + ']-'+'[' + [PolicyNumber] + ']-[' + CAST(InceptionDate AS NVARCHAR(20)) + ']-[' + CAST([ExpiryDate] AS VARCHAR(20)) + ']-['+ CAST(YOA AS VARCHAR(10)) + ']-[' + CASE WHEN [Account] LIKE '%P' THEN 'Policy' ELSE 'Binder' END + ']-[' + [TypeOfBusiness] + ']' 
			,CAST('IP' AS VARCHAR(2)) AS [FK_Process],
			-2 AS [PK_Product],
			CASE WHEN OT.Location='-' THEN 'NA'
			ELSE OT.LOCATION 
			END AS [BK_Location],
			ISNULL(LTRIM(RTRIM(OT.[TrifocusCode])),1) AS [FK_Trifocus],
			[YOA] AS [FK_YOA],
			statscode as [FK_StatsCode], 
			[OriginalCCY],
			[OriginalCCY] AS [CCYOriginal],
			[SettlementCCY],
			CAST(CONVERT(CHAR(10),[DueDate],112) AS INT) AS [FK_DueDate],
			LEFT(CAST(CONVERT(CHAR(10),InceptionDate,112) AS INT),6) AS InceptionPeriod,
			COALESCE(YEAR(InceptionDate),lcc
			.EventYear,-1) AS FK_InceptionYear,
			cast(OT.[Value] * isnull(cast(S.SyndSplitPercentage as numeric(19, 4)), 1.00) as numeric(19, 4)) AS ValueSett,
			OT.[RowHash],
			OT.[AuditSourceBatchID],
			OT.[AuditCreateDateTime],
			OT.[AuditGenerateDateTime],
			OT.[AuditUserCreate],
			OT.[AuditHost],
			LEFT([PolicyNumber],6) LookUpPolicyNumber,
			CASE WHEN Year(DateOfFact)< 1990 THEN CAST('19900101' AS DATE) ELSE  DateOfFact END DateOfFact,
			CASE WHEN Year(DateOfFact)< 1990 THEN '19900101'
				 ELSE  CAST(CONVERT(CHAR(10),DateOfFact,112) AS INT) END FK_DateOfFact,
			ot.BusinessKey  AS BusinessKey,
			--tce.ExposureReference AS ExposureReference,
			CAST(CONVERT(CHAR(10),InceptionDate,112) AS INT) AS FK_InceptionDate,
			ExposureReference = ISNULL(+'[' + [ExposureReference] +']-['+ISNULL(SCMReference,'')+']-['+ISNULL(ClaimReference,'')+']-['+ISNULL(tce.[BeazleyCatCode],'')+']-['+CAST(ISNULL([DateOfLoss],'') AS VARCHAR(20)) +']','Unknown'),
			BK_RIPolicyType=LTRIM(RTRIM(ISNULL(cri.Confirmed_RIPolicyType,RE.RIPolicyType))),
			--BK_ProgrammeCode=LTRIM(RTRIM(ISNULL(RE.ProgrammeCode,trre.Special))),
			BK_ProgrammeCode=CASE WHEN UPPER(LTRIM(RTRIM(RE.RIPolicyType))) = 'FAC' AND
			DATASET NOT IN ('BICI_RI_Incurred','BICI_RI_Ultimate_Premium','BICI_RI_Paid','BICI_Earned_Agresso','BICI RI Ultimate Claim')
			THEN LTRIM(RTRIM(isnull(TPM.RIProgramme,re.ProgrammeCode)))
			ELSE LTRIM(RTRIM(ISNULL(RE.ProgrammeCode,trre.Special)))
			END,
			Att_Cat = CASE trre.att_cat WHEN 'Attritional' THEN 'A'
							  WHEN 'Catastrophe' THEN 'C'
							  ELSE NULL
			END,
			trre.Datasetname AS FK_ReservingDataset,
			trre.Datasetgroup AS ReservingDatasetGroup,
			trre.trianglegroup  AS FK_TriangleGroup,
			FK_Allocation,
			--case when isnull(e.ProgrammeCode, eres.special) is not null or
			acc.RIFlag GrossRI, --= 'O' then 'O' else 'I' end GrossRI
			tf.TrifocusName
INTO		 #srctxn
FROM		FinanceDataContract.[Outbound].[Transaction] OT
			LEFT JOIN FinanceDataContract.[Outbound].[Transaction_Claim_Extensions_Bridge] eb
					on eb.RowHash_Transaction = OT.RowHash
			LEFT JOIN FinanceDataContract.[Outbound].[Transaction_Claim_Extensions] tce
					on tce.RowHash_Transaction_Claim_Extensions = eb.RowHash_Transaction_Claim_Extensions
			LEFT JOIN #polsec as polsec
			ON		OT.PolicyNumber	=	polsec.SectionReference
			LEFT JOIN FinanceDataContract.Outbound.Transaction_ReInsurance_Extensions_Bridge REB
					ON REB.RowHash_Transaction=OT.RowHash
			LEFT JOIN FinanceDataContract.Outbound.Transaction_ReInsurance_Extensions RE
					ON RE.RowHash_Transaction_ReInsurance_Extensions=REB.RowHash_Transaction_ReInsurance_Extensions
			LEFT JOIN FinanceDataContract.Outbound.Transaction_Reserving_ReInsurance_Extensions_Bridge AS trreb
					ON ot.RowHash = trreb.RowHash_Transaction
			LEFT JOIN FinanceDataContract.Outbound.Transaction_Reserving_ReInsurance_Extensions AS trre
					ON trreb.RowHash_Transaction_Reserving_ReInsurance_Extensions = trre.RowHash_Transaction_Reserving_ReInsurance_Extensions
			LEFT JOIN FinanceLanding.fdm.SyndicateSplitsbyYOA S
					ON S.SyndSplitSource= OT.Entity and S.SyndSplitYOA=OT.YOA
					and ot.Dataset NOT IN ('AgressoARUS','AgressoARBIDAC','EPI Reinstatement Eurobase','RI LPSO TTY')
			LEFT JOIN FinanceLanding.[MDS].[FACPrgTrifocusMapping] TPM
			       ON LTRIM(RTRIM(TPM.TrifocusCode)) = LTRIM(RTRIM(OT.[TrifocusCode]))
			LEFT JOIN FinanceLanding.mds.RITypeMapping cri 
			       ON RE.RIPolicyType = cri.RIPolicyType
			LEFT JOIN TechnicalHub.dim.Account acc on (acc.BK_Account = OT.Account)
			LEFT JOIN FinanceLanding.fdm.DimTrifocus tf on (ISNULL(LTRIM(RTRIM(OT.[TrifocusCode])),1) = tf.trifocusCode)
			LEFT JOIN TechnicalHub.dim.CatCode lcc ON lcc.BeazleyCatCode = tce.BeazleyCatCode AND lcc.EventYear IS NOT NULL
			
WHERE		1=1
			AND (YOA LIKE '[0-9]%' AND YOA>'1992')-- OR TRY_CAST(OT.YOA as varchar (10)) IN ('CALX','NOYOA'))
			AND DataSet= @p_Dataset
			--AND OT.ENTITY <> '6107'
			AND OT.AuditSourceBatchID = @p_BatchId

OPTION (RECOMPILE,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));


--TreatyShare Rules to create additional records from 623 share into BIDAC(8033) of TreatySharepercentage
--https://beazley.atlassian.net/browse/I1B-5422

if object_id('tempdb..#srctxn_TreatyShare') is not null drop table #srctxn_TreatyShare
SELECT  
			PK_Transaction,
			t.Dataset,
			[FK_Batch],
			BeazleyCatCode,
			LargeLoss,
			MovementType,
			TrackingStatus,
			[FK_DataSet],
			[FK_Scenario],
			[FK_Account],
			[FK_Basis],
			1 AS [PK_DataStage],
			FK_SourceEntity,
			FK_DeltaType,
			r.ToEntity [FK_Entity],
			BK_PolicySection,
			CAST('IP' AS VARCHAR(2)) AS [FK_Process],
			[PK_Product],
			[BK_Location],
			[FK_Trifocus],
			[FK_YOA],
			[FK_StatsCode], 
			[OriginalCCY],
			[CCYOriginal],
			[SettlementCCY],
			[FK_DueDate],
			InceptionPeriod,
			FK_InceptionYear,
			cast(ValueSett * ISNULL(cast(r.CedePercentage as numeric(19,4)),1.0000)	as numeric(19,4)) as ValueSett, 
			[RowHash],
			[AuditSourceBatchID],
			[AuditCreateDateTime],
			t.[AuditGenerateDateTime],
			t.[AuditUserCreate],
			[AuditHost],
			LookUpPolicyNumber,
			DateOfFact,
			FK_DateOfFact,
			BusinessKey,
			FK_InceptionDate,
			ExposureReference,
			BK_RIPolicyType,
			BK_ProgrammeCode,
			Att_Cat,
			FK_ReservingDataset,
			ReservingDatasetGroup,
			FK_TriangleGroup,
			FK_Allocation,
			--case when isnull(e.ProgrammeCode, eres.special) is not null or
			GrossRI, --= 'O' then 'O' else 'I' end GrossRI
			TrifocusName
INTO		 #srctxn_TreatyShare
from	#srctxn t
INNER JOIN   FinanceLanding.[MDS].[TreatyShareGenerationRules] R ON R.Dataset=t.Dataset 
																AND r.YOA=t.FK_YOA 
																AND r.TriFocusCode=t.FK_Trifocus 
																AND r.FromEntity=t.FK_Entity




--Preparea data for combined TreatyShare 8033 split data and Non-Share in General Data
if object_id('tempdb..#Finaldata') is not null drop table #Finaldata

select	 PK_Transaction
		,Dataset
		,FK_Batch
		,BeazleyCatCode
		,LargeLoss
		,MovementType
		,TrackingStatus
		,FK_DataSet
		,FK_Scenario
		,FK_Account
		,FK_Basis
		,PK_DataStage
		,FK_SourceEntity
		,FK_DeltaType
		,FK_Entity
		,BK_PolicySection
		,FK_Process
		,PK_Product
		,BK_Location
		,FK_Trifocus
		,FK_YOA
		,FK_StatsCode
		,OriginalCCY
		,CCYOriginal
		,SettlementCCY
		,FK_DueDate
		,InceptionPeriod
		,FK_InceptionYear
		,ValueSett
		,RowHash
		,AuditSourceBatchID
		,AuditCreateDateTime
		,AuditGenerateDateTime
		,AuditUserCreate
		,AuditHost
		,LookUpPolicyNumber
		,DateOfFact
		,FK_DateOfFact
		,BusinessKey
		,FK_InceptionDate
		,ExposureReference
		,BK_RIPolicyType
		,BK_ProgrammeCode
		,Att_Cat
		,FK_ReservingDataset
		,ReservingDatasetGroup
		,FK_TriangleGroup
		,FK_Allocation
		,GrossRI
		,TrifocusName
		
into #Finaldata

from #srctxn 

union all 

select  PK_Transaction
		,Dataset
		,FK_Batch
		,BeazleyCatCode
		,LargeLoss
		,MovementType
		,TrackingStatus
		,FK_DataSet
		,FK_Scenario
		,FK_Account
		,FK_Basis
		,PK_DataStage
		,FK_SourceEntity
		,FK_DeltaType
		,FK_Entity
		,BK_PolicySection
		,FK_Process
		,PK_Product
		,BK_Location
		,FK_Trifocus
		,FK_YOA
		,FK_StatsCode
		,OriginalCCY
		,CCYOriginal
		,SettlementCCY
		,FK_DueDate
		,InceptionPeriod
		,FK_InceptionYear
		,ValueSett
		,RowHash
		,AuditSourceBatchID
		,AuditCreateDateTime
		,AuditGenerateDateTime
		,AuditUserCreate
		,AuditHost
		,LookUpPolicyNumber
		,DateOfFact
		,FK_DateOfFact
		,BusinessKey
		,FK_InceptionDate
		,ExposureReference
		,BK_RIPolicyType
		,BK_ProgrammeCode
		,Att_Cat
		,FK_ReservingDataset
		,ReservingDatasetGroup
		,FK_TriangleGroup
		,FK_Allocation
		,GrossRI
		,TrifocusName
from	#srctxn_TreatyShare



if object_id('tempdb..#dataint') is not null drop table #dataint

select	d.PK_Transaction, 
		FK_Entity,
		min(i.PrioritySequence) PrioritySequence
into	#dataint --

from	#Finaldata d
join	FinanceLanding.mds.Intercompany_rules i   on
			(
			
					(
					i.Dataset = 'All' 
					or
					i.Dataset = d.Dataset
					)
				and
					(
					i.GrossRI = 'All' 
					or
					i.GrossRI = d.GrossRI
					)
				and
					(
					i.YOA = 0 
					or 
					i.YOA = d.FK_YOA 
					)
				and 
					(
					i.Entity = 'All' 
					or
					i.Entity = d.FK_Entity 
					)
				and
					(
					i.Trifocus = 'All'
					or 
					(i.Trifocus = 'BICI%' and left(d.TrifocusName, 4) = 'BICI')
					or
					(i.Trifocus = 'BUSA%' and left(d.TrifocusName, 4) = 'BUSA')
					or
					i.Trifocus = d.TrifocusName
					)
				and
					(
					i.Programme = 'All' 
					or
					i.Programme = d.BK_ProgrammeCode
					)
				and (
					d.DateOfFact between i.FromDOF and isnull(cast(cast(i.ToDOF as varchar) as date), cast('2099-12-31' as date))
					)
			)

GROUP BY	PK_Transaction
			,FK_Entity

if object_id('tempdb..#dump') is not null drop table #dump

SELECT DISTINCT 
			t.PK_Transaction,
			t.Dataset	,
			FK_Batch	,
			BeazleyCatCode	,
			LargeLoss	,
			MovementType	,
			TrackingStatus	,
			FK_DataSet	,
			FK_Scenario	,
			FK_Account	,
			FK_Basis	,
			PK_DataStage	,
			FK_SourceEntity	,
			FK_DeltaType	,
			FK_Entity	= LTRIM(RTRIM(ISNULL(cem.ConformedEntityMapping,t.FK_Entity))),
			--FK_Entity = t.FK_Entity,
			BK_PolicySection	,
			FK_Process	,
			PK_Product	,
			BK_Location	,
			FK_Trifocus = 
					CASE 
						WHEN mds_tri.TriFocusCode IS NULL AND CTM.TrifocusCode IS NULL 
						THEN 'Unknown'
						ELSE 
						LTRIM(RTRIM(ISNULL(CTM.ConformedTrifocusMapping,t.FK_Trifocus)))
					END ,
			FK_YOA	,
			FK_StatsCode	,
			OriginalCCY	,
			CCYOriginal	,
			SettlementCCY	,
			FK_DueDate	,
			InceptionPeriod	,
			FK_InceptionYear	,
			ValueSett	,
			RowHash	,
			t.AuditSourceBatchID	,
			t.AuditCreateDateTime	,
			t.AuditGenerateDateTime	,
			t.AuditUserCreate	,
			t.AuditHost	,
			LookUpPolicyNumber	,
			DateOfFact	,
			FK_DateOfFact	,
			BusinessKey	,
			FK_InceptionDate	,
			ExposureReference	,
			BK_RIPolicyType	,
			BK_ProgrammeCode	,
			Att_Cat	,
			FK_ReservingDataset	,
			ReservingDatasetGroup	,
			FK_TriangleGroup	,
			FK_Allocation	,
			t.GrossRI	,
			TrifocusName	,
			isnull(di.PrioritySequence, -1) as PrioritySequence,
			isnull(intc.[Percentage], 1) [Percentage],
			isnull(intc.Flag, 'NA') Flag
into		#dump
from		#Finaldata t
left join	#dataint di 
							on (di.PK_Transaction = t.PK_Transaction AND di.FK_Entity = t.FK_Entity)
left join	FinanceLanding.mds.Intercompany_rules intc 
							on (intc.PrioritySequence = di.PrioritySequence)
LEFT JOIN	FinanceLanding.mds.ConformedEntityMapping cem
							ON t.FK_Entity = cem.Entity
LEFT JOIN	FinanceLanding.MDS.ConformedTrifocusMapping CTM
							ON LTRIM(RTRIM(T.FK_Trifocus))=LTRIM(RTRIM(CTM.TrifocusCode))
LEFT JOIN	FinanceLanding.mds.TriFocus as mds_tri
							ON  LTRIM(RTRIM(T.FK_Trifocus)) = LTRIM(RTRIM(mds_tri.TriFocusCode))
	  


TRUNCATE TABLE stg.FactTechnicalResult_Results

INSERT INTO stg.FactTechnicalResult_Results
SELECT		PK_Transaction	,
			Dataset	,
			FK_Batch	,
			BeazleyCatCode	,
			LargeLoss	,
			MovementType	,
			TrackingStatus	,
			FK_DataSet	,
			FK_Scenario	,
			FK_Account	,
			FK_Basis	,
			PK_DataStage	,
			FK_SourceEntity	,
			FK_DeltaType	,
			FK_Entity	,
			BK_PolicySection	,
			FK_Process	,
			PK_Product	,
			BK_Location	,
			FK_Trifocus	,
			FK_YOA	,
			FK_StatsCode	,
			OriginalCCY	,
			CCYOriginal	,
			SettlementCCY	,
			FK_DueDate	,
			InceptionPeriod	,
			FK_InceptionYear	,
			ValueSett	,
			RowHash	,
			AuditSourceBatchID	,
			AuditCreateDateTime	,
			AuditGenerateDateTime	,
			AuditUserCreate	,
			AuditHost	,
			LookUpPolicyNumber	,
			DateOfFact	,
			FK_DateOfFact	,
			BusinessKey	,
			FK_InceptionDate	,
			ExposureReference	,
			BK_RIPolicyType	,
			BK_ProgrammeCode	,
			Att_Cat	,
			FK_ReservingDataset	,
			ReservingDatasetGroup	,
			FK_TriangleGroup	,
			FK_Allocation	,
			GrossRI	,
			TrifocusName	,
			PrioritySequence	,
			[Percentage]	,
			Flag	
FROM		#dump


  set   @v_AffectedRows			= @@ROWCOUNT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage,RowsAffected)
		SELECT 5, @p_ActivityName, 'Inserted ' +CONVERT(VARCHAR,@v_AffectedRows)+' Rows into stg.FactTechnicalResult_Results table',@v_AffectedRows;
	


		IF @Trancount = 0 
		COMMIT;

		INSERT	@Logging(ActivityStatus, ActivityName, ActivityMessage)
		SELECT 2, @p_ActivityName, 'Load into stg.FactTechnicalResult_Results for BatchId '+@p_BatchId +' is success';

		EXEC TechnicalHub.log.usp_LogLanding @Input = @Logging;

		END TRY

	BEGIN CATCH

	IF @Trancount = 0  
				ROLLBACK;
					
				
			SELECT   @v_ActivityDateTime				= GETUTCDATE()
					,@v_ActivityLogTag					= @v_ActivityLogIdIn
					,@v_ActivityMessage					= ERROR_MESSAGE()
					,@v_ActivityErrorCode				= ERROR_NUMBER();

			EXECUTE  @v_RC = Orchestram.Log.usp_ActivityLog
					 @p_ParentActivityLogId
					,@v_ActivityLogTag
					,@v_ActivitySource
					,@v_ActivityType
					,@v_ActivityStatusFail
					,@v_ActivityHost
					,@v_ActivityDatabase
					,@v_ActivityJobId
					,@v_ActivitySSISExecutionId
					,@v_ActivityName
					,@v_ActivityDateTime
					,@v_ActivityMessage
					,@v_ActivityErrorCode
					,@v_AffectedRows
					,@v_ActivityLogIdIn OUTPUT;

			

		    THROW;

		
	END CATCH;

END



