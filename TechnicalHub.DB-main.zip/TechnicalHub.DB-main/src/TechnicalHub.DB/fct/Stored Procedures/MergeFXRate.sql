﻿/*====================================================================================================
Is:		fct.MergeFXRate
Does:	Loads fact data from associated staging table
====================================================================================================*/

CREATE PROCEDURE fct.usp_MergeFXRate
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

			----Create new fact records
			INSERT INTO fct.FXRate WITH (TABLOCK)
			(
				 fk_Batch
				,fk_AccountingPeriod
				,FXRateName
				,fk_TransactionCurrency
				,FK_ReportingCurrencyCode
				,FXRate
				,FK_RateCode
			)
			SELECT
				 fk_Batch
				,fk_AccountingPeriod
				,FXRateName
				,fk_TransactionCurrency
				,fK_ReportingCurrencyCode
				,FXRate
				,fK_RateCode
			FROM stg.fct_FXRate ;

		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END