﻿CREATE VIEW fct.vwEarningPatternAttritional AS
WITH cteEarning (FK_Scenario,FK_AccountingPeriod, FK_Trifocus, FK_YOA, USDValue)
AS (SELECT tr.FK_Scenario,
			tr.FK_AccountingPeriod,		--
			--AP.BK_AccountingPeriod,   --++
           tr.FK_Trifocus,
           tr.FK_YOA, 
		  -- Y.BK_YOA,					--++
           USDValue = SUM(tr.Value / fx.FXRate)
    FROM fct.TechnicalResult tr
	--JOIN Dim.AccountingPeriod AP ON AP.PK_AccountingPeriod=TR.FK_AccountingPeriod --++
	--JOIN fct.FXRate fx ON AP.BK_AccountingPeriod=fx.fk_AccountingPeriod			--++
		--					AND tr.CCYSettlement = fx.fk_TransactionCurrency		--++
		-- JOIN dim.YOA Y ON Y.PK_YOA=TR.FK_YOA										--++
        JOIN fct.FXRate fx															--
            ON tr.FK_AccountingPeriod = fx.fk_AccountingPeriod						--
               AND tr.[FK_CCYSettlement] = fx.fk_TransactionCurrency						--
    WHERE tr.FK_Account LIKE 'P-EP-%'
          AND fx.FXRateName = 'Average'
          AND fx.fK_RateCode = 'AGR'
          AND fx.fK_ReportingCurrencyCode = 'USD'
    GROUP BY tr.FK_Scenario,tr.FK_AccountingPeriod,									--
			--AP.BK_AccountingPeriod												--++
             tr.FK_Trifocus,
             tr.FK_YOA																--
			--Y.BK_YOA																--++
)
SELECT FK_EarningCategory=1,ce.FK_Scenario,
		ce.FK_AccountingPeriod,
	   ce.FK_Trifocus,
       ce.FK_YOA,
       EarningPercent = ce.USDValue / CASE
                                          WHEN cet.USDValueTot = 0 THEN
                                              1
                                          ELSE
                                              cet.USDValueTot
                                      END,
       cet.USDValueTot
FROM cteEarning ce
    JOIN
    (
        SELECT ce.FK_Scenario, ce.FK_Trifocus,
               ce.FK_YOA,
               USDValueTot = SUM(ce.USDValue)
        FROM cteEarning ce
        GROUP BY ce.FK_Scenario, ce.FK_Trifocus,
                 ce.FK_YOA
    ) cet
        ON ce.FK_Scenario=cet.FK_Scenario 
		AND ce.FK_Trifocus = cet.FK_Trifocus
           AND ce.FK_YOA = cet.FK_YOA

UNION
--only to tidy up to 100% - a bit of a hack
SELECT FK_EarningCategory=1,ce.FK_Scenario,
		FK_AccountingPeriod = MAX(ce.FK_AccountingPeriod),
	   ce.FK_Trifocus,
       ce.FK_YOA,
       EarningPercent = 1-SUM(ce.USDValue / CASE
                                          WHEN cet.USDValueTot = 0 THEN
                                              1
                                          ELSE
                                              cet.USDValueTot
                                      END) 
		,MIN(cet.USDValueTot)
FROM cteEarning ce
    JOIN
    (
        SELECT ce.FK_Scenario, ce.FK_Trifocus,
               ce.FK_YOA,
               USDValueTot = SUM(ce.USDValue)
        FROM cteEarning ce
        GROUP BY ce.FK_Scenario, ce.FK_Trifocus,
                 ce.FK_YOA
    ) cet
        ON ce.FK_Scenario=cet.FK_Scenario AND ce.FK_Trifocus = cet.FK_Trifocus
           AND ce.FK_YOA = cet.FK_YOA
GROUP BY 
	ce.FK_Scenario, ce.FK_Trifocus,
    ce.FK_YOA
;