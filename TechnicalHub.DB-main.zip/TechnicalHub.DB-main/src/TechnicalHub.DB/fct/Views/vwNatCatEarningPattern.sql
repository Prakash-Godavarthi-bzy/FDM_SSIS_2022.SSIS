﻿
CREATE   VIEW [fct].[vwNatCatEarningPattern] AS 
WITH FOP AS (SELECT PK_Pattern
				  , TrifocusCode
				  , YOA
				  , InceptionYear
				  , SettlementCCY
				  , DevelopmentPercentageIncrement
				  , DevelopmentQuarter
				FROM stg.NatCatEarning WHERE DataSet = 'NatCatEarning')

SELECT
		FK_EarningCategory	= 3
	  , FK_Scenario			= 'A'
	  , FK_AccountingPeriod = CONVERT(CHAR(6), DATEADD(MONTH, (3 * FOP.DevelopmentQuarter)-1, CAST(FOP.YOA + '0101' AS DATE)), 112)
	  , FK_Trifocus			= FOP.TrifocusCode
	  , FK_YOA				= FOP.YOA
	  , EarningPercent		= FOP.DevelopmentPercentageIncrement * -1
FROM 	FOP
;