﻿CREATE VIEW [fct].[vw_Validation] AS

WITH MonthChange ([BK_PolicyNumber],PeriodOrder,fk_accountingperiod,PolicyType,PolicyDuration,fk_trifocus,PeriodChange,NoOfChanges) AS
(SELECT DISTINCT
	p.[BK_PolicyNumber]
	,PeriodOrder = ROW_NUMBER() OVER(PARTITION BY p.[BK_PolicyNumber] ORDER BY tr.fk_accountingperiod ASC)	--
	,tr.fk_accountingperiod																					--
  --,PeriodOrder = ROW_NUMBER() OVER(PARTITION BY p.[BK_PolicyNumber] ORDER BY AP.BK_AccountingPeriod ASC)	--++
  --,AP.BK_AccountingPeriod																					--++
	,p.PolicyType
	,PolicyDuration = datediff(d,p.InceptionDate, p.ExpiryDate) 
	,tr.FK_Trifocus
	,PeriodChange = sum(tr.Value)
	,NoOfChanges = count(distinct  p.[BK_PolicyNumber])
FROM
	dim.Policy p 
	join fct.TechnicalResult tr on p.PK_Policy = tr.FK_Policy 
	join dim.Account a on tr.FK_Account = a.[BK_Account]
	--JOIN dim.AccountingPeriod AP ON Tr.FK_AccountingPeriod=AP.PK_AccountingPeriod  --++
WHERE 
	1=1
	and a.Level2Group = 'Gross'
	and tr.FK_DataSet = 'Eurobase'
GROUP BY
	p.[BK_PolicyNumber]
	,tr.fk_accountingperiod
	--,AP.BK_AccountingPeriod														--++
	,p.PolicyType
	,datediff(d,p.InceptionDate, p.ExpiryDate)
	,tr.fk_trifocus
)

select 
	pk_Validation = ROW_NUMBER() OVER(ORDER BY mcc.[BK_PolicyNumber] ,mcc.fk_accountingperiod asc)
	,mcc.[BK_PolicyNumber] 
	,mcc.fk_accountingperiod
	,CurrentPolicyType = mcc.PolicyType
	,CurrentPolicyDuration = mcc.policyduration
	,CurrentTriFocus = mcc.fk_trifocus
	,CurrentPeriodChange = mcc.PeriodChange
	,PriorPeriod = mcp.fk_accountingperiod
	,PriorPolicyType = mcp.PolicyType
	,PriorPolicyDuration = mcp.policyduration
	,PriorTriFocus = mcp.fk_trifocus
	,ValidationType = CASE 
		WHEN abs(mcc.PeriodChange)>=1000000 THEN 1
		WHEN mcc.PolicyType <> mcp.PolicyType THEN 2
		WHEN mcc.policyduration <> mcp.policyduration THEN 3
		WHEN (mcc.fk_trifocus <> mcp.fk_trifocus) AND (right(mcc.[BK_PolicyNumber] ,2) <> 'BR') AND (left(mcc.[BK_PolicyNumber] ,6) <> 'B7945V') THEN 4
		ELSE  ''
	END
from 
	MonthChange mcc left outer join
	MonthChange mcp on mcc.[BK_PolicyNumber] = mcp.[BK_PolicyNumber] and mcp.PeriodOrder = mcc.PeriodOrder-1
where 
	mcc.PeriodOrder >= 1
	and
	(
		mcc.policyduration <> mcp.policyduration
		OR ((mcc.fk_trifocus <> mcp.fk_trifocus) AND (right(mcc.[BK_PolicyNumber] ,2) <> 'BR') AND (left(mcc.[BK_PolicyNumber] ,6) <> 'B7945V'))
		OR mcc.PolicyType <> mcp.PolicyType
		OR abs(mcc.PeriodChange)>=1000000
	)