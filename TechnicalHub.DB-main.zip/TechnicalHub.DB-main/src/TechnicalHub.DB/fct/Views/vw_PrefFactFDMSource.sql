﻿CREATE VIEW [fct].[vw_PrefFactFDMSource]
  AS
  SELECT             
                           M.FDM_FK_Account
                           ,M.FDM_FK_Process
                           ,F.[DataSet] 
                           ,F.[TriFocus]
                           ,F.[Entity]
                           ,F.[CCYSettlement]
                            ,F.[Location]
                           ,F.[YOA]
                           ,F.[AccountingPeriod]
                           ,F.[Product]
                           ,F.[Policy]
                           ,F.[InceptionDate]
                           ,F.[ExpiryDate]
                           ,F.[Value]*M.[Multiplier]  AS [Value]
  
  FROM               stg.TechnicalResult_FDM F 
  INNER JOIN		[Control].[TechhubToFDMmapping] M 
  ON                 M.TechHUb_FK_Process=F.[Process]
  AND                M.TechHUb_FK_Account=F.[Account]
  AND                M.[TechHUb_FK_DataSet]=F.[DataSet]