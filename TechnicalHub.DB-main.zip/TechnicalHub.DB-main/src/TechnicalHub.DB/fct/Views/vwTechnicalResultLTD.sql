﻿CREATE VIEW [fct].[vwTechnicalResultLTD] AS

WITH CTE AS (
	SELECT
		DISTINCT FK_Account
		, FK_AccountingPeriod
		, FK_Basis
		, FK_Entity
		, p.BK_PolicyNumber
		, p.InceptionDate
		, p.ExpiryDate
		, FK_Process
		, FK_Trifocus
		, FK_YOA
		, CCYOriginal
		, CCYSettlement
		, SUM(Value)
		OVER( PARTITION BY FK_Account
		, FK_Basis
		, FK_Entity
		, p.BK_PolicyNumber
		, p.InceptionDate
		, p.ExpiryDate
		, FK_Process
		, FK_Trifocus
		, FK_YOA
		, CCYOriginal
		, CCYSettlement ORDER BY FK_AccountingPeriod) AS [Value]

		FROM [fct].[TechnicalResult] t
		JOIN Dim.Policy p ON p.PK_Policy =t.FK_Policy
		WHERE 1=1
		AND FK_DataSet IN( 'Eurobase','USPremium')
		--AND FK_Trifocus = '10'
		AND FK_Process='IP'
		--AND FK_Policy = '[J5476H04ANPA]-[Apr 19 2004 12:00AM]-[Apr 18 2005 12:00AM]-[2004]-[Policy]-[N]'
		--AND FK_Entity = '2623'
		--AND FK_Account='P-GP-P'
)

SELECT FK_Account
	, FK_AccountingPeriod
	, FK_Basis
	, FK_Entity
	, BK_PolicyNumber
	, InceptionDate
	, ExpiryDate
	, FK_Process
	, FK_Trifocus
	, FK_YOA
	, CCYOriginal
	, CCYSettlement
	,[Value]
	,PK_AccountingPeriod
FROM CTE
CROSS APPLY (SELECT PK_AccountingPeriod 
			 FROM Dim.AccountingPeriod 
			 WHERE AccountingMonth <>0 AND AccountingMonth<>13) AS A
WHERE PK_AccountingPeriod BETWEEN FK_AccountingPeriod AND CONVERT(CHAR(6), GETDATE(), 112)+5




GO

