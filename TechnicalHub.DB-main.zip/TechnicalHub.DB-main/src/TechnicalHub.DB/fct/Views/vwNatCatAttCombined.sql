﻿CREATE VIEW fct.vwNatCatAttCombined AS
WITH COMBO AS 
(SELECT
		FK_EarningCategory	= 4
	  , FK_Scenario			= 'A'
	  , FK_AccountingPeriod = CEP.FK_AccountingPeriod
	  , FK_Trifocus			= CEP.FK_Trifocus
	  , FK_YOA				= CEP.FK_YOA
	  , EarningPercent		= CEP.EarningPercent
FROM	fct.vwNatCatEarningPattern CEP
UNION
SELECT 4
	 , EPA.FK_Scenario
	 , EPA.FK_AccountingPeriod
	 , EPA.FK_Trifocus
	 , EPA.FK_YOA
	 , EPA.EarningPercent
FROM fct.vwEarningPatternAttritional EPA
WHERE NOT EXISTS (SELECT 1 FROM fct.vwNatCatEarningPattern CEP WHERE EPA.FK_Trifocus = CEP.FK_Trifocus AND EPA.FK_YOA = CEP.FK_YOA)
)
SELECT
		COMBO.FK_EarningCategory
	  , COMBO.FK_Scenario
	  , COMBO.FK_AccountingPeriod
	  , COMBO.FK_Trifocus
	  , COMBO.FK_YOA
	  , COMBO.EarningPercent
FROM 	COMBO
;