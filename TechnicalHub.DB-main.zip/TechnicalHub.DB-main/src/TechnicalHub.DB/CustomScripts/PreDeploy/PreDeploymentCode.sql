﻿/*
This will be executed during the pre-deployment phase.
Use it to apply scripts for all actions that cannot be easily and 
consistently done using just the database project.

Note that the pre-deployment scripts are just prepended to the
generated script.

!!!Make sure your scripts are idempotent(repeatable)!!!

Example invocation:
EXEC sp_execute_script @sql = 'UPDATE Table....', @author = 'Your Name'
*/



DECLARE @Trancount INT = @@Trancount

BEGIN TRY;
	
	IF @Trancount = 0 BEGIN TRAN;


IF EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_CATALOG = 'TechnicalHub' AND TABLE_SCHEMA='dbo' and TABLE_NAME ='ADMTechnicalResult')
BEGIN
DROP TABLE TechnicalHub.DBO.ADMTechnicalResult
END

IF EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_CATALOG = 'TechnicalHub' AND TABLE_SCHEMA='dbo' and TABLE_NAME ='PFTTechnicalResult')
BEGIN
DROP TABLE TechnicalHub.DBO.PFTTechnicalResult
END

IF EXISTS(SELECT DISTINCT 1 FROM SYS.PROCEDURES WHERE NAME ='usp_PFTTechResultSource')
BEGIN
DROP PROCEDURE dbo.usp_PFTTechResultSource
END


IF EXISTS(SELECT DISTINCT 1 FROM SYS.PROCEDURES WHERE NAME ='usp_ADMTechResultSource')
BEGIN
DROP PROCEDURE dbo.usp_ADMTechResultSource
END


IF EXISTS(SELECT * FROM TechnicalHub.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'dbo' and TABLE_NAME = 'RIPercentage' and COLUMN_NAME = 'GrossGrossUltimates')
BEGIN
ALTER TABLE TechnicalHub.[dbo].[RIPercentage]
DROP COLUMN [GrossGrossUltimates]
END

IF EXISTS(SELECT * FROM TechnicalHub.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'dbo' and TABLE_NAME = 'RIPercentage' and COLUMN_NAME = 'GN_RI%')
BEGIN
ALTER TABLE TechnicalHub.[dbo].[RIPercentage]
DROP COLUMN [GN_RI%]
END

IF EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_CATALOG = 'TechnicalHub' AND TABLE_SCHEMA='IFRS17' and TABLE_NAME ='FCT_TechnicalResult_1')
BEGIN
DROP TABLE TechnicalHub.IFRS17.FCT_TechnicalResult_1
END

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_CATALOG = 'TechnicalHub' AND TABLE_SCHEMA='IFRS17' and TABLE_NAME ='FCT_TechnicalResult' and COLUMN_NAME='AuditCreateDateTime')
BEGIN
ALTER TABLE TechnicalHub.IFRS17.FCT_TechnicalResult
ADD AuditCreateDateTime DATETIME  DEFAULT '1980-01-01' WITH VALUES
END

/*
/*===================================================================
Modified By:	Entha.Bhargav@beazley.com
Modified Date:		21/10/2024
Description:	 Populate FK_SourceEntity field which should write from it's relavent Outbound record, This can be useful to understand original entity as they were confirming between box3-4 layer.
					https://beazley.atlassian.net/browse/I1B-5869
					https://beazley.atlassian.net/browse/I1B-5868

=====================================================================*/
IF NOT EXISTS(	SELECT 1 
			FROM INFORMATION_SCHEMA.COLUMNS 
			WHERE TABLE_CATALOG = 'TechnicalHub' 
					AND TABLE_SCHEMA='stg'
					and TABLE_NAME ='FactTechnicalResult_USPremium' 
					and COLUMN_NAME='FK_SourceEntity'
			)
BEGIN
ALTER TABLE  TechnicalHub.stg.FactTechnicalResult_USPremium ADD  [FK_SourceEntity] [varchar](25)  NULL
END

IF NOT EXISTS(	SELECT 1 
			FROM INFORMATION_SCHEMA.COLUMNS 
			WHERE TABLE_CATALOG = 'TechnicalHub' 
					AND TABLE_SCHEMA='stg'
					and TABLE_NAME ='FactTechnicalResult_PFT' 
					and COLUMN_NAME='FK_SourceEntity'
			)
BEGIN
ALTER TABLE  TechnicalHub.stg.FactTechnicalResult_PFT  ADD  [FK_SourceEntity] [varchar](25)  NULL
END

IF NOT EXISTS(	SELECT 1 
			FROM INFORMATION_SCHEMA.COLUMNS 
			WHERE TABLE_CATALOG = 'TechnicalHub' 
					AND TABLE_SCHEMA='stg'
					and TABLE_NAME ='FactTechnicalResult_BICI_BIDAC_BAIC' 
					and COLUMN_NAME='FK_SourceEntity'
			)
BEGIN
ALTER TABLE  TechnicalHub.stg.FactTechnicalResult_BICI_BIDAC_BAIC ADD  [FK_SourceEntity] [varchar](25)  NULL
END

*/

------------------------
IF @Trancount = 0 COMMIT;

END TRY

BEGIN CATCH;

	IF @Trancount = 0 
		ROLLBACK;

	THROW;

END CATCH;


