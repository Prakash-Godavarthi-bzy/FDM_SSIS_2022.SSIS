﻿MERGE [dim].[DeltaType]  AS TGT
USING	(VALUES('New','New'),('Adjustment','Adjustment'),('Reversal','Reversal'),('Restatement','Restatement')) as Src ([BK_DeltaType],[DeltaType])
ON	  TGT.[BK_DeltaType] = Src.[BK_DeltaType]
WHEN  NOT MATCHED BY TARGET
THEN INSERT
			([BK_DeltaType],
			[DeltaType]
			)
	Values
	(
	src.[BK_DeltaType],
	src.[DeltaType]
	)
 WHEN MATCHED
 AND (
	  src.[DeltaType]<> tgt.[DeltaType]
 )
  THEN UPDATE 
  set 
	   tgt.[DeltaType]= src.[DeltaType];