﻿MERGE [dim].[Scenario] AS TGT
USING	(VALUES('A','Actual'),
		('B','Budget'),
		('F','Forecast'),
		('BP','Business Plan')) as Src ([PK_Scenario],[ScenarioName])
ON	  TGT.[BK_Scenario] = Src.[PK_Scenario]
WHEN  NOT MATCHED BY TARGET
THEN INSERT
			([BK_Scenario],
			[ScenarioName]
			)
	Values
	(
	src.[PK_Scenario],
	src.[ScenarioName]
	)
 WHEN MATCHED
 AND (
	  src.[ScenarioName]<> tgt.[ScenarioName]	
 )
  THEN UPDATE 
  set  
		
	   tgt.[ScenarioName] = src.[ScenarioName];

  GO
  
DECLARE @Cunt_S INT
SELECT @CUNT_S=COUNT(*) FROM TechnicalHub.[dim].[Scenario]
WHERE PK_Scenario IN (-1,-2)

IF @CUNT_S=0
BEGIN
SET IDENTITY_INSERT TechnicalHub.[dim].[Scenario] ON
INSERT INTO TechnicalHub.[Dim].[Scenario](PK_Scenario,BK_Scenario,ScenarioName) 
		VALUES
		(-1 
		,'Unknown'
		,'Unknown'
		),

		(-2 
		,'N/A'
		,'NotApplicable'
		)
SET IDENTITY_INSERT TechnicalHub.[dim].[Scenario] OFF
END