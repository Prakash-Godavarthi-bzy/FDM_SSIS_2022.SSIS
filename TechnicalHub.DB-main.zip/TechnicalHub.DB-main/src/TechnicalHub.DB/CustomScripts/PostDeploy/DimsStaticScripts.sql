﻿--see the guide in 2.PostDeployment.StaticTablesList.sql

DECLARE @Cunt_Basis INT
SELECT @Cunt_Basis=COUNT(*) FROM TechnicalHub.[dim].Basis
WHERE PK_Basis IN (-1,-2)

IF @CUNT_Basis=0

BEGIN

SET IDENTITY_INSERT TechnicalHub.[dim].[Basis] ON
INSERT INTO TechnicalHub.[Dim].[Basis](PK_Basis,BK_Basis,BasisName) 
		VALUES
		(-1 
		,'Unknown'
		,'Unknown'
		),
		(-2 
		,'N/A'
		,'NotApplicable'
		)
SET IDENTITY_INSERT TechnicalHub.[dim].[Basis] OFF

END

GO

DECLARE @Cunt_DS INT
SELECT @CUNT_DS=COUNT(*) FROM TechnicalHub.[dim].DataSet
WHERE PK_DataSet IN (-1,-2)

IF @CUNT_DS=0

BEGIN

SET IDENTITY_INSERT TechnicalHub.[dim].[DataSet] ON
INSERT INTO TechnicalHub.[Dim].[DataSet](PK_DataSet,BK_DataSet,SourceSystem) 
		VALUES
		(-1 
		,'Unknown'
		,'Unknown'
		),
		(-2 
		,'N/A'
		,'NotApplicable'
		)
SET IDENTITY_INSERT TechnicalHub.[dim].[DataSet] OFF

END

GO

DECLARE @Cunt_P INT
SELECT @CUNT_P= COUNT(*) FROM TechnicalHub.[dim].Process
WHERE PK_Process IN (-1,-2)

IF @CUNT_P=0
BEGIN
SET IDENTITY_INSERT TechnicalHub.[dim].[Process] ON
INSERT INTO TechnicalHub.[Dim].[Process]
           ([PK_Process]
           ,[BK_Process]
           ,[ProcessName]
           ,[AuditSourceBatchID]) 
    VALUES
    (-1 
    ,'Unknown'
    ,'Unknown'
    ,-1
    ),
    (-2 
    ,'N/A'
    ,'NotApplicable'
    ,-2
    )
SET IDENTITY_INSERT TechnicalHub.[dim].[Process] OFF

END

GO

DECLARE @Cunt_A INT
SELECT @CUNT_A= COUNT(*) FROM TechnicalHub.[dim].Account
WHERE PK_Account IN (-1,-2)

IF @CUNT_A=0
BEGIN
SET IDENTITY_INSERT TechnicalHub.[dim].[Account] ON
INSERT INTO TechnicalHub.[Dim].[Account]
           ([PK_Account]
           ,[BK_Account]
           ,[AccountName]
           )
    VALUES
    (-1 
    ,'Unknown'
    ,'Unknown'
    ),
    (-2 
    ,'N/A'
    ,'NotApplicable'
    )
SET IDENTITY_INSERT TechnicalHub.[dim].[Account] OFF

END

GO

IF EXISTS (SELECT * FROM sys.tables where name = 'Entity' AND schema_id = SCHEMA_ID('DIM'))
	DELETE 
	FROM	DIM.Entity
	WHERE	[BK_Entity] IN ('SIIADJUSBI','SIIADJCONS')

GO

DECLARE @Cunt_In INT
SELECT @CUNT_In= COUNT(*) FROM TechnicalHub.[dim].InceptionYear
WHERE PK_InceptionYear IN (1900)

IF @CUNT_In=0
BEGIN

INSERT INTO TechnicalHub.[Dim].[InceptionYear]
           (PK_InceptionYear, InceptionYear
           )
    VALUES
    (1900
	,'1900'
    )

END