﻿TRUNCATE TABLE [stg].[dim_AccountingPeriod]


DECLARE @APStart DATE = '1985-01-01'
DECLARE @APYearsAhead INT = CAST('#{AccountPeriodYearsAhead}' AS INT)

-- DELETE EXCESS ROWS WHILE RESPECTING REFERENTIAL INTEGRITY
DELETE FROM dim.AccountingPeriod WHERE AccountingYear > YEAR(GETDATE()) + @APYearsAhead
AND [BK_AccountingPeriod] > (SELECT MAX(FK_AccountingPeriod) FROM (SELECT MAX(FK_AccountingPeriod) FK_AccountingPeriod FROM fct.TechnicalResult UNION SELECT MAX(FK_AccountingPeriod) FROM fct.Pattern) c) 


;WITH cte AS 
(

SELECT @APStart AS Date_
UNION ALL
SELECT DATEADD(MM,1,Date_)  
FROM cte
WHERE Date_ < CAST(DateAdd(year,@APYearsAhead,DATEADD (MM, -1, DATEADD(yy, DATEDIFF(yy, 0, GETDATE())+1, 0)))as date)
)


INSERT INTO [stg].[dim_AccountingPeriod]
( 
       [BK_AccountingPeriod],  
    [AccountingPeriodName],
    [AccountingYear],      
    [AccountingYearName],  
    [AccountingMonth],    
    [AccountingMonthName]
)

SELECT SUBSTRING(convert(varchar(10),date_,112),1,6),
          SUBSTRING(convert(varchar(10),date_,112),1,6),
              Year(date_),
              Year(date_),
               Month(date_),
                SUBSTRING(convert(varchar(10),date_,112),5,2)
FROM cte OPTION (maxrecursion 0)

INSERT INTO [stg].[dim_AccountingPeriod]
( 
       [BK_AccountingPeriod],  
    [AccountingPeriodName],
    [AccountingYear],      
    [AccountingYearName],  
    [AccountingMonth],    
    [AccountingMonthName]
)
select [BK_AccountingPeriod]-1,	AccountingPeriodName-1,	AccountingYear,	AccountingYearName,	AccountingMonth-1,	'00' AS  AccountingMonthName
from [stg].[dim_AccountingPeriod]
WHERE AccountingMonth = 1
UNION
select [BK_AccountingPeriod]+1,	AccountingPeriodName+1,	AccountingYear,	AccountingYearName,	AccountingMonth+1,	'13' AS AccountingMonthName
from  [stg].[dim_AccountingPeriod]
WHERE AccountingMonth = 12
UNION 
SELECT CAST('198000' as int) PK_AccountingPeriod,CAST('198000' AS varchar(6)) AccountingPeriodName, CAST('1980' AS INT) AccountingYear,
CAST('1980' AS varchar(4)) AccountingYearName, CAST('00' AS INT) AccountingMonth,'00' AccountingMonthName
UNION 
SELECT CAST('198001' as int) PK_AccountingPeriod,CAST('198001' AS varchar(6)) AccountingPeriodName, CAST('1980' AS INT) AccountingYear,
CAST('1980' AS varchar(4)) AccountingYearName, CAST('01' AS INT) AccountingMonth,'01' AccountingMonthName
	

Exec [dim].[usp_MergeAccountingPeriod]

DECLARE @CuntAp INT
SELECT @CUNTAp=COUNT(*) FROM TechnicalHub.dim.AccountingPeriod
WHERE PK_AccountingPeriod IN (-1)

IF @CUNTAp=0

BEGIN

SET IDENTITY_INSERT TechnicalHub.dim.AccountingPeriod ON
INSERT INTO TechnicalHub.dim.AccountingPeriod(PK_AccountingPeriod,BK_AccountingPeriod) 
		VALUES
		(-1,999912)
		
SET IDENTITY_INSERT TechnicalHub.dim.AccountingPeriod OFF

END