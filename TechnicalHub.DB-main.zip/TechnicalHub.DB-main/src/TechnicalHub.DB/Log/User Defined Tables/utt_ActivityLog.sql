CREATE TYPE [log].[utt_ActivityLog] AS TABLE(
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[LogDate] [datetime2](0) NULL DEFAULT (getdate()),
	[ActivityName] [varchar](50) NULL DEFAULT (object_name(@@procid)),
	[RowsAffected] [int] NULL DEFAULT (@@rowcount),
	[ActivityStatus] [int] NULL,
	[ActivitySSISExecutionId] [int] NULL,
	[ActivityMessage] [varchar](4000) NULL,
	PRIMARY KEY CLUSTERED 
(
	[ID] ASC
))