
CREATE	PROCEDURE [log].[usp_LogLanding]	@Input log.utt_ActivityLog READONLY
AS
BEGIN

	/*
       =========================================================================================================
                                         Insert into Log table
       =========================================================================================================
*/

	INSERT	[Orchestram].[Log].[ActivityLog](	FK_ParentActivityLog, FK_ActivityLogTag, FK_ActivitySource, FK_ActivityType, FK_ActivityStatus, ActivityHost
													, ActivityDatabase, ActivityJobId, ActivitySSISExecutionId, ActivityName, ActivityDateTime, ActivityMessage, AffectedRows)
	SELECT	NULL
	,		NULL
	,		2
	,		1
	,		ActivityStatus
	,		@@SERVERNAME
	,		'TechnicalHub'
	,		NULL
	,		ActivitySSISExecutionId
	,		ISNULL(ActivityName, 'TechnicalHub Activity')
	,		GETDATE()
	,		ActivityMessage
	,		RowsAffected
	FROM	@Input


END;



