﻿CREATE TYPE dim.[utt_UpdateAccountingPeriod] AS TABLE
(
	PK_Process VARCHAR(10),
	CurrentAccountingPeriod INT
)
