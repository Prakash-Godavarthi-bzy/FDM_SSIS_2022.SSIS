﻿CREATE TABLE [dim].[Scenario_History] (
	[PK_Scenario]	BIGINT NOT NULL,
    [BK_Scenario]  VARCHAR (10)  NOT NULL,
    [ScenarioName] VARCHAR (50)  NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    [ValidFrom]    DATETIME2 (7) NOT NULL,
    [ValidTo]      DATETIME2 (7) NOT NULL
);




GO
CREATE CLUSTERED INDEX [ix_Scenario_History]
    ON [dim].[Scenario_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

