﻿CREATE TABLE [dim].[ProgrammeCode_History] (
	[PK_ProgrammeCode]   BIGINT NOT NULL,
    [BK_ProgrammeCode]  VARCHAR (100)  NOT NULL,
    [ProgrammeCode]      VARCHAR (100) NULL,
	[Retro_Reinsurance_Ind] [char](2) NULL,
    [AuditSourceBatchID] [varchar](255)  NULL,
    [AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    [ValidFrom]   DATETIME2 (7)  NOT NULL,
    [ValidTo]     DATETIME2 (7)  NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_ProgrammeCode_History]
    ON [dim].[ProgrammeCode_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

