﻿CREATE TABLE [dim].[Location_History] (
	[PK_Location]	BIGINT			NOT NULL,
    [BK_Location]  VARCHAR (50)  NOT NULL,
    [LocationName] VARCHAR (50)  NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    [ValidFrom]    DATETIME2 (7) NOT NULL,
    [ValidTo]      DATETIME2 (7) NOT NULL
);




GO
CREATE CLUSTERED INDEX [ix_Location_History]
    ON [dim].[Location_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

