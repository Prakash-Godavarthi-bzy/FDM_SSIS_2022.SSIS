﻿CREATE TABLE [dim].[Account_History] (
    [PK_Account]  VARCHAR (10)   NOT NULL,
    [AccountName] VARCHAR (100) NULL,
    [Level1Group] VARCHAR (100) NULL,
    [Level2Group] VARCHAR (100) NULL,
    [Level3Group] VARCHAR (100) NULL,
    [ValidFrom]   DATETIME2 (7)  NOT NULL,
    [ValidTo]     DATETIME2 (7)  NOT NULL
);




GO
CREATE CLUSTERED INDEX [ix_Account_History]
    ON [dim].[Account_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

