﻿CREATE TABLE [dim].[TriangleGroup_History](
	[PK_TriangleGroup] [bigint] NOT NULL,
	[BK_TriangleGroup] [varchar](100) NOT NULL,
	[TriangleGroup] [varchar](100) NULL,
	[AuditSourceBatchID] [varchar](255) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
	[ValidFrom] [datetime2](7) NOT NULL,
	[ValidTo] [datetime2](7) NOT NULL
) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [ix_TriangleGroup_History]
    ON [dim].[TriangleGroup_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);
