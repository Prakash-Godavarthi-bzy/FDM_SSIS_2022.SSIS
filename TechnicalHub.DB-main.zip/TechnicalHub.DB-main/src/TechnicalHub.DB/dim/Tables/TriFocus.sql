﻿CREATE TABLE [dim].[TriFocus] (
    [PK_TriFocus]    BIGINT  NOT NULL IDENTITY(1,1),
	[BK_TriFocus]    VARCHAR (25)  NOT NULL,
    [TriFocusName]   VARCHAR (50)  NULL,
    [TriFocusLevel1] VARCHAR (50)  NULL,
    [TriFocusLevel2] VARCHAR (100)  NULL,
    [TriFocusLevel3] VARCHAR (100)  NULL, 
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    [ValidFrom] DATETIME2  GENERATED ALWAYS AS ROW START NOT NULL, 
    [ValidTo] DATETIME2  GENERATED ALWAYS AS ROW END NOT NULL, 
	PERIOD FOR SYSTEM_TIME (ValidFrom,ValidTo),
    CONSTRAINT [PK_TriFocus] PRIMARY KEY ([PK_TriFocus])
)WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = [dim].[TriFocus_History]));

