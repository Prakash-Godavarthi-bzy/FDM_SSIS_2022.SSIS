﻿CREATE TABLE [dim].[Metric_History] (
    [PK_Metric]        VARCHAR (25)   NOT NULL,
    [MetricName]       VARCHAR (255)  NULL,
    [FK_MetricParent]  VARCHAR (25)   NULL,
    [Operator]         VARCHAR (1)    NULL,
    [MDX]              VARCHAR (1000) NULL,
    [SortOrder]        INT            NULL,
    [PropertiesFormat] VARCHAR (1000) NULL,
    [Description]      VARCHAR (1000) NULL,
    [BusinessCode]     VARCHAR (10)   NULL,
    [Finalised]        VARCHAR (10)   NULL,
    [Release]          VARCHAR (10)   NULL,
    [Sourced]          VARCHAR (10)   NULL,
    [Notes]            VARCHAR (1000) NULL,
    [ValidFrom]        DATETIME2 (7)  NOT NULL,
    [ValidTo]          DATETIME2 (7)  NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_Metric_History]
    ON [dim].[Metric_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

