﻿CREATE TABLE [dim].[ClaimExposure_History](
	[PK_ClaimExposure]		[bigint]  NOT NULL,
	[BK_ClaimExposure]		[varchar] (255) NOT NULL,
	[ClaimExposure]			[varchar] (255)	NOT NULL,
	[SCMClaimReference]		[varchar] (255) NULL,
	[ClaimReference]		[varchar] (255) NULL,
	[BeazleyCatCode]		[varchar] (255) NULL,
	[DateOfLoss]			[DATE]			NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
	[ValidFrom]				[datetime2] (7)  NOT NULL,
	[ValidTo]				[datetime2] (7) NOT NULL
);