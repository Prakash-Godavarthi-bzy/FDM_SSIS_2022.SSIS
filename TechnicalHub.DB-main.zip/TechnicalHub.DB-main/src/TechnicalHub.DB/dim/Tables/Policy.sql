﻿CREATE TABLE [dim].[Policy] (
    [PK_Policy]       VARCHAR (118)                               NOT NULL,
    [BK_PolicyNumber] VARCHAR (25)                                NULL,
	[SectionReference] VARCHAR (25)                               NULL,
    [InceptionDate]   DATETIME                                    NULL,
    [ExpiryDate]      DATETIME                                    NULL,
    [PolicyYOA]       INT                                         NULL,
    [PolicyType]      VARCHAR (50)                                NULL,
    [PolicyPattern]   VARCHAR (10)                                NULL,
    [BindDate]        DATE                                        NULL,
    [TypeOfBusiness]  VARCHAR (10)                                NULL,
    [MaxEarningDate]  DATE                                        NULL,
    [ValidFrom]       DATETIME2 (7) GENERATED ALWAYS AS ROW START NOT NULL,
    [ValidTo]         DATETIME2 (7) GENERATED ALWAYS AS ROW END   NOT NULL,
    [IsUSPolicy]      BIT                                         DEFAULT(0),
    CONSTRAINT [PK_Policy] PRIMARY KEY CLUSTERED ([PK_Policy] ASC) WITH (FILLFACTOR = 90),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[dim].[Policy_History], DATA_CONSISTENCY_CHECK=ON));





