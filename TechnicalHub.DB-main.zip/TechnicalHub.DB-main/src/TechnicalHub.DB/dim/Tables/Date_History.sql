﻿CREATE TABLE [dim].[Date_History] (
	[PK_Date]			BIGINT NOT NULL,
    [BK_Date]     INT           NOT NULL,
    [Date]        DATE          NULL,
    [DateName]    VARCHAR (50)  NULL,
    [Year]        INT           NULL,
    [Month]       INT           NULL,
    [Day]         INT           NULL,
    [PERIOD]      INT           NULL,
    [MonthName]   VARCHAR (50)  NULL,
    [Quarter]     INT           NULL,
    [QuarterName] VARCHAR (50)  NULL,
    [DaysInMonth] INT           NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    [ValidFrom]   DATETIME2 (7) NOT NULL,
    [ValidTo]     DATETIME2 (7) NOT NULL
);




GO
CREATE CLUSTERED INDEX [ix_Date_History]
    ON [dim].[Date_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

