﻿CREATE TABLE [dim].[Allocation] (
    [pk_Allocation]           INT                                         IDENTITY (1, 1) NOT NULL,
    [ValidFrom]               DATETIME2 (7) GENERATED ALWAYS AS ROW START NOT NULL,
    [ValidTo]                 DATETIME2 (7) GENERATED ALWAYS AS ROW END   NOT NULL,
    [Account]                 INT                                         NOT NULL,
    [EntityCode]              VARCHAR (50)                                NOT NULL,
    [TrifocusCodeFrom]        VARCHAR (25)                                NULL,
    [TrifocusCodeTo]          VARCHAR (25)                                NULL,
    [YOAFrom]                 INT                                         NULL,
    [YOATo]                   INT                                         NULL,
    [DestinationAccount]      INT                                         NOT NULL,
    [DestinationEntity]       VARCHAR (50)                                NOT NULL,
    [DestinationTrifocusCode] VARCHAR (25)                                NULL,
    [AllocationPercentage]    DECIMAL (28, 8)                             NOT NULL,
    CONSTRAINT [pk_Allocation] PRIMARY KEY CLUSTERED ([pk_Allocation] ASC),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[dim].[Allocation_History], DATA_CONSISTENCY_CHECK=ON));

