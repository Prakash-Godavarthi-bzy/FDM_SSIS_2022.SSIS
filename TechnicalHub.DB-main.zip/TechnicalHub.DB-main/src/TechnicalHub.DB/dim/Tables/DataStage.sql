﻿CREATE TABLE [dim].[DataStage] (
    [PK_DataStage]  INT            NOT NULL,
    [DataStageName] VARCHAR (50)   NULL, 
    [ValidFrom] DATETIME2 GENERATED ALWAYS AS ROW START NOT NULL, 
    [ValidTo] DATETIME2 GENERATED ALWAYS AS ROW END NOT NULL, 
	PERIOD FOR SYSTEM_TIME (ValidFrom,ValidTo),
    CONSTRAINT [PK_DataStage] PRIMARY KEY ([PK_DataStage])
)WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = [dim].[DataStage_History]));

