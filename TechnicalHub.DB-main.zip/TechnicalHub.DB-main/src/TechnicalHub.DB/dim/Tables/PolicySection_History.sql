﻿CREATE TABLE [dim].[PolicySection_History] (
    [PK_PolicySection] [BIGINT]  NOT NULL,
	[BK_PolicySection] [varchar](255) NOT NULL,
	[PolicyReference] [varchar](50) NULL,
	[SectionReference] [varchar](100) NULL,
	[InceptionDate] [datetime] NULL,
	[ExpiryDate] [datetime] NULL,
	[PolicyYOA] [int] NULL,
	[PolicyType] [varchar](50) NULL,
	[BindDate] [date] NULL,
	[TypeOfBusiness] [varchar](10) NULL,
	[MaxEarningDate] [date] NULL,
	[IsUSPolicy] [bit] NULL DEFAULT(0),
	[PolicyClaimBasis] [varchar](10) NULL,
	[PolicyMOPCode] [varchar](10) NULL,
	[PolicyCobCode] [Varchar](10) NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
	[ValidFrom] [datetime2](7) NOT NULL,
	[ValidTo] [datetime2](7)  NOT NULL
);

GO
CREATE CLUSTERED INDEX [ix_PolicySection_History]
    ON [dim].[PolicySection_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

