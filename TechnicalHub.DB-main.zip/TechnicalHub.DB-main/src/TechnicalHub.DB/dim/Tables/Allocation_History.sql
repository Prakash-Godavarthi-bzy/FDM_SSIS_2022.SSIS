﻿CREATE TABLE [dim].[Allocation_History] (
    [pk_Allocation]           INT             NOT NULL,
    [ValidFrom]               DATETIME2 (7)   NOT NULL,
    [ValidTo]                 DATETIME2 (7)   NOT NULL,
    [Account]                 INT             NOT NULL,
    [EntityCode]              VARCHAR (50)    NOT NULL,
    [TrifocusCodeFrom]        VARCHAR (25)    NULL,
    [TrifocusCodeTo]          VARCHAR (25)    NULL,
    [YOAFrom]                 INT             NULL,
    [YOATo]                   INT             NULL,
    [DestinationAccount]      INT             NOT NULL,
    [DestinationEntity]       VARCHAR (50)    NOT NULL,
    [DestinationTrifocusCode] VARCHAR (25)    NULL,
    [AllocationPercentage]    DECIMAL (28, 8) NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_Allocation_History]
    ON [dim].[Allocation_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

