﻿CREATE TABLE [dim].[DeltaType_History] (
	[PK_DeltaType]	BIGINT NOT NULL ,
    [BK_DeltaType]  VARCHAR (20)   NOT NULL,
    [DeltaType] VARCHAR (100) NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    [ValidFrom] DATETIME2 (7)  NOT NULL,
    [ValidTo]   DATETIME2 (7)  NOT NULL
);
GO
CREATE CLUSTERED INDEX [ix_DeltaType_History]
    ON [dim].[DeltaType_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);