﻿CREATE TABLE [dim].[PolicySection] (
    [PK_PolicySection] [BIGINT] IDENTITY(1,1) NOT NULL,
	[BK_PolicySection] [varchar](255) NOT NULL,
	[PolicyReference] [varchar](50) NULL,
	[SectionReference] [varchar](100) NULL,
	[InceptionDate] [datetime] NULL,
	[ExpiryDate] [datetime] NULL,
	[PolicyYOA] [int] NULL,
	[PolicyType] [varchar](50) NULL,
	[BindDate] [date] NULL,
	[TypeOfBusiness] [varchar](10) NULL,
	[MaxEarningDate] [date] NULL,
	[IsUSPolicy] [bit] NULL DEFAULT(0),
	[PolicyClaimBasis] [varchar](10) NULL,
	[PolicyMOPCode] [varchar](10) NULL,
	[PolicyCobCode] [Varchar](10) NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
	[ValidFrom] [datetime2](7) GENERATED ALWAYS AS ROW START NOT NULL,
	[ValidTo] [datetime2](7) GENERATED ALWAYS AS ROW END NOT NULL,
 CONSTRAINT [PK_PolicySection] PRIMARY KEY CLUSTERED 
(
	[PK_PolicySection] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY],
	PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
) 
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[dim].[PolicySection_History], DATA_CONSISTENCY_CHECK=ON));






