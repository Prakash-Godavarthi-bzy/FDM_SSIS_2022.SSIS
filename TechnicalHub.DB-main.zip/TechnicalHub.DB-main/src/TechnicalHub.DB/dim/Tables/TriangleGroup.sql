﻿CREATE TABLE [dim].[TriangleGroup](
	[PK_TriangleGroup] [bigint] IDENTITY(1,1) NOT NULL,
	[BK_TriangleGroup] [varchar](100) NOT NULL,
	[TriangleGroup] [varchar](100) NULL,
	[AuditSourceBatchID] [varchar](255) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
	[ValidFrom] [datetime2](7) GENERATED ALWAYS AS ROW START NOT NULL,
	[ValidTo] [datetime2](7) GENERATED ALWAYS AS ROW END NOT NULL,
 CONSTRAINT [PK_TriangleGroup] PRIMARY KEY CLUSTERED ([PK_TriangleGroup] ASC),
PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON ( HISTORY_TABLE = [dim].[TriangleGroup_History], DATA_CONSISTENCY_CHECK=ON));
GO
