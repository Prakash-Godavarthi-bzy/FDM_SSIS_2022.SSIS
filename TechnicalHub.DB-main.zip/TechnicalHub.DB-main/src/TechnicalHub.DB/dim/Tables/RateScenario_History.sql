﻿CREATE TABLE dim.RateScenario_History
(
	PK_RateCode			NVARCHAR(255)	NOT NULL ,
	RateName			NVARCHAR(255)	NULL ,
	RateGroup			NVARCHAR(255)	NULL ,
	Locked				NCHAR(1)		NULL ,
	SortOrder			INT				NULL ,
	ValidFrom			DATETIME2		NOT NULL , 
    ValidTo				DATETIME2		NOT NULL
);
GO

CREATE CLUSTERED INDEX ix_RateScenario_History
    ON dim.RateScenario_History([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);
