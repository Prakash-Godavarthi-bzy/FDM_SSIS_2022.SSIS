﻿CREATE TABLE [dim].[Entity] (
	[PK_Entity]	 BIGINT NOT NULL IDENTITY(1,1),
    [BK_Entity]  VARCHAR (25)  NOT NULL,
    [Entity]     VARCHAR (50)  NULL,
    [EntityName] VARCHAR (50)  NULL,
    [Platform]   VARCHAR (10)  NULL, 
    [EntityLevel1] VARCHAR(50) NULL, 
    [EntityLevel2] VARCHAR(50) NULL, 
    [EntityLevel3] VARCHAR(50) NULL, 
    [EntityLevel4] VARCHAR(50) NULL, 
    [EntityLevel5] VARCHAR(50) NULL, 
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
	[ValidFrom] DATETIME2 GENERATED ALWAYS AS ROW START NOT NULL, 
    [ValidTo] DATETIME2 GENERATED ALWAYS AS ROW END  NOT NULL, 
	PERIOD FOR SYSTEM_TIME (ValidFrom,ValidTo),
    CONSTRAINT [PK_Entity] PRIMARY KEY ([PK_Entity])
)WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = [dim].[Entity_History]));

