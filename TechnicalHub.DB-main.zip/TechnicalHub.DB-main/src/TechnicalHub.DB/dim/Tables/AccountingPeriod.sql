﻿CREATE TABLE [dim].[AccountingPeriod] (
	[PK_AccountingPeriod]	BIGINT NOT NULL IDENTITY(1,1),
    [BK_AccountingPeriod]  INT         NOT NULL,
    [AccountingPeriodName] VARCHAR (6) NULL,
    [AccountingYear]       INT         NULL,
    [AccountingYearName]   VARCHAR (4) NULL,
    [AccountingMonth]      INT         NULL,
    [AccountingMonthName]  VARCHAR (2) NULL, 
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
	[ValidFrom] DATETIME2 GENERATED ALWAYS AS ROW START NOT NULL, 
    [ValidTo] DATETIME2 GENERATED ALWAYS AS ROW END  NOT NULL, 
	PERIOD FOR SYSTEM_TIME (ValidFrom,ValidTo),
    CONSTRAINT [PK_AccountingPeriod] PRIMARY KEY ([PK_AccountingPeriod])
)WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = [dim].[AccountingPeriod_History]));

