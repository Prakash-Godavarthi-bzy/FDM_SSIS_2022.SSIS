﻿CREATE TABLE [dim].[Process_History] (
	[PK_Process]				BIGINT		NOT NULL,
    [BK_Process]              VARCHAR (10)  NOT NULL,
    [ProcessName]             VARCHAR (50)  NULL,
    [ProcessLevel1]           VARCHAR (50)  NULL,
    [ProcessLevel2]           VARCHAR (50)  NULL,
    [ProcessLevel3]           VARCHAR (50)  NULL,
    [CurrentAccountingPeriod] INT           NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    [ValidFrom]               DATETIME2 (7) NOT NULL,
    [ValidTo]                 DATETIME2 (7) NOT NULL
);




GO
CREATE CLUSTERED INDEX [ix_Process_History]
    ON [dim].[Process_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

