﻿CREATE TABLE [dim].[DataStage_History] (
    [PK_DataStage]  INT           NOT NULL,
    [DataStageName] VARCHAR (50)  NULL,
    [ValidFrom]     DATETIME2 (7) NOT NULL,
    [ValidTo]       DATETIME2 (7) NOT NULL
);




GO
CREATE CLUSTERED INDEX [ix_DataStage_History]
    ON [dim].[DataStage_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

