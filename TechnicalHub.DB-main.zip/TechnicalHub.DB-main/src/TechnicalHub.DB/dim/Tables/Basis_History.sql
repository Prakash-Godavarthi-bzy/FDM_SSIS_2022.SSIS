﻿CREATE TABLE [dim].[Basis_History] (
	[PK_Basis]	BIGINT NOT NULL ,
    [BK_Basis]  VARCHAR (10)   NOT NULL,
    [BasisName] VARCHAR (100) NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    [ValidFrom] DATETIME2 (7)  NOT NULL,
    [ValidTo]   DATETIME2 (7)  NOT NULL
);




GO
CREATE CLUSTERED INDEX [ix_Basis_History]
    ON [dim].[Basis_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

