﻿CREATE TABLE [dim].[Entity_History] (
	[PK_Entity]		BIGINT			 NOT NULL,
    [BK_Entity]    VARCHAR (25)  NOT NULL,
    [Entity]       VARCHAR (50)  NULL,
    [EntityName]   VARCHAR (50)  NULL,
    [Platform]     VARCHAR (10)  NULL,
    [EntityLevel1] VARCHAR (50)  NULL,
    [EntityLevel2] VARCHAR (50)  NULL,
    [EntityLevel3] VARCHAR (50)  NULL,
    [EntityLevel4] VARCHAR (50)  NULL,
    [EntityLevel5] VARCHAR (50)  NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    [ValidFrom]    DATETIME2 (7) NOT NULL,
    [ValidTo]      DATETIME2 (7) NOT NULL
);




GO
CREATE CLUSTERED INDEX [ix_Entity_History]
    ON [dim].[Entity_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

