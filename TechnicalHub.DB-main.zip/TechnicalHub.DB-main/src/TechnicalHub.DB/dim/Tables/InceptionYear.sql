﻿CREATE TABLE [dim].[InceptionYear] (
    [PK_InceptionYear] INT      NOT NULL,
    [InceptionYear]    VARCHAR (20) NOT NULL,
    CONSTRAINT [PK_InceptionYear] PRIMARY KEY CLUSTERED ([PK_InceptionYear] ASC)
);

