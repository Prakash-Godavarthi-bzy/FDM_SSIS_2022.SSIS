﻿/*====================================================================================================
Is:		dim.Mergedim.MergeBasis
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE dim.usp_MergeBasis
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			UPDATE	dim
			SET		dim.BasisName = stg.BasisName
			FROM	stg.dim_Basis stg	
			JOIN	dim.Basis dim	ON	dim.[BK_Basis] = stg.[BK_Basis]			WHERE	dim.BasisName <> stg.BasisName
				OR	CAST(IIF(dim.BasisName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.BasisName IS NULL, 0, 1) AS BIT) = 1 

			--Create new records
			INSERT		dim.Basis WITH (TABLOCK) ([BK_Basis], BasisName)
			SELECT		stg.[BK_Basis], 
						stg.BasisName
			FROM		stg.dim_Basis stg	
			LEFT JOIN	dim.Basis dim	ON	dim.[BK_Basis] = stg.[BK_Basis]
			WHERE		dim.[BK_Basis] IS NULL
					OR	dim.BasisName <> stg.BasisName
					OR	CAST(IIF(dim.BasisName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.BasisName IS NULL, 0, 1) AS BIT) = 1 
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END