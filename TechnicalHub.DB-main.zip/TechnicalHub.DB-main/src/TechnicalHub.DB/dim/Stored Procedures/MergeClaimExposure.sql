﻿/*====================================================================================================
Is:		dim.Mergedim.MergeClaimExposure
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE [dim].[usp_MergeClaimExposure]
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
				
			 MERGE [dim].[ClaimExposure]
                AS     TARGET
                USING  (SELECT	 [BK_ClaimExposure]
								,[SCMClaimReference]
								,[ClaimExposure]
								,[ClaimReference]
								,[BeazleyCatCode]
								,[DateOfLoss]
								,[AuditSourceBatchID]
								,[AuditCreateDateTime]
					   FROM [stg].[dim_ClaimExposure]
					) AS SOURCE
                ON TARGET.BK_ClaimExposure = SOURCE.BK_ClaimExposure --BK is concatinated column
				-- ON TARGET.ClaimExposure = SOURCE.ClaimExposure --ClaimExposure is ClaimID

                WHEN NOT MATCHED BY TARGET 
                                        THEN INSERT  (			 [BK_ClaimExposure]
																,[ClaimExposure]
																,[SCMClaimReference]
																,[ClaimReference]
																,[BeazleyCatCode]
																,[DateOfLoss]
																,[AuditSourceBatchID]
																,[AuditCreateDateTime]

                                                        )
                                                VALUES (
                                                                SOURCE.[BK_ClaimExposure],
																SOURCE.[ClaimExposure],
																SOURCE.[SCMClaimReference],
																SOURCE.[ClaimReference],
																SOURCE.[BeazleyCatCode],
																SOURCE.[DateOfLoss],
                                                                SOURCE.[AuditSourceBatchID],
                                                                SOURCE.[AuditCreateDateTime]
                                                                )
  
                WHEN MATCHED 
                AND (
                    isnull(SOURCE.[BK_ClaimExposure],'') <> isnull(TARGET.[BK_ClaimExposure],'') OR
					isnull(SOURCE.[ClaimExposure],'') <> isnull(TARGET.[ClaimExposure],'') OR
					isnull(SOURCE.[SCMClaimReference],'') <> isnull(TARGET.[SCMClaimReference],'') OR
					isnull(SOURCE.[ClaimReference],'') <> isnull(TARGET.[ClaimReference],'') OR
					isnull(SOURCE.[BeazleyCatCode],'') <> isnull(TARGET.[BeazleyCatCode],'') OR
					isnull(SOURCE.[DateOfLoss],'') <> isnull(TARGET.[DateOfLoss],'') 
                                    )
				THEN UPDATE SET TARGET.[SCMClaimReference]	= SOURCE.[SCMClaimReference],
								TARGET.[ClaimExposure]		= SOURCE.[ClaimExposure],
								TARGET.[ClaimReference]		= SOURCE.[ClaimReference],
								TARGET.[BeazleyCatCode]		= SOURCE.[BeazleyCatCode],
								TARGET.[DateOfLoss]			= SOURCE.[DateOfLoss],
                                --TARGET.[AuditSourceBatchID]	= SOURCE.[AuditSourceBatchID],
								TARGET.[AuditCreateDateTime] = SOURCE.[AuditCreateDateTime]
								;
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END