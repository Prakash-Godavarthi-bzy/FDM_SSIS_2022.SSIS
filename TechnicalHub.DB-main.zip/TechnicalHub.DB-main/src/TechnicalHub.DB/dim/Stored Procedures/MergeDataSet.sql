﻿/*====================================================================================================
Is:		dim.Mergedim.MergeSourceSystem
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE [dim].[usp_MergeSourceSystem]
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Create new records
			INSERT		dim.DataSet WITH (TABLOCK) ([BK_DataSet])
			SELECT		stg.[BK_Dataset]
			FROM		stg.[dim_DataSet] stg	
			LEFT JOIN	dim.DataSet dim	ON	dim.[BK_DataSet] = stg.[BK_Dataset]
			WHERE		dim.[BK_DataSet] IS NULL
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END