﻿/*====================================================================================================
Is:		dim.Mergedim.MergeScenario
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE dim.usp_MergeScenario
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			UPDATE	dim
			SET		dim.ScenarioName = stg.ScenarioName
			FROM	stg.dim_Scenario stg	
			JOIN	dim.Scenario dim	ON	dim.[BK_Scenario] = stg.[BK_Scenario]			WHERE	dim.ScenarioName <> stg.ScenarioName
				OR	CAST(IIF(dim.ScenarioName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.ScenarioName IS NULL, 0, 1) AS BIT) = 1 

			--Create new records
			INSERT		dim.Scenario WITH (TABLOCK) ([BK_Scenario], ScenarioName)
			SELECT		stg.[BK_Scenario], 
						stg.ScenarioName
			FROM		stg.dim_Scenario stg	
			LEFT JOIN	dim.Scenario dim	ON	dim.[BK_Scenario] = stg.[BK_Scenario]
			WHERE		dim.[BK_Scenario] IS NULL
					OR	dim.ScenarioName <> stg.ScenarioName
					OR	CAST(IIF(dim.ScenarioName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.ScenarioName IS NULL, 0, 1) AS BIT) = 1 
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END