﻿/*====================================================================================================
Is:		dim.Mergedim.MergePatternName
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE dim.MergePatternName
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			/*--Overwrite SCD 1 data columns. */
			UPDATE	dim
			SET		dim.PatternName = stg.PatternName
			FROM	stg.dim_PatternName stg	
			JOIN	dim.PatternName dim	ON	dim.BK_PatternName = stg.BK_PatternName
			WHERE	dim.PatternName <> stg.PatternName
				OR	CAST(IIF(dim.PatternName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.PatternName IS NULL, 0, 1) AS BIT) = 1 
			
			--Create new records
			INSERT		dim.PatternName WITH (TABLOCK) (BK_PatternName, PatternName)
			SELECT		stg.BK_PatternName, 
						stg.PatternName
						
			FROM		stg.dim_PatternName stg	
			LEFT JOIN	dim.PatternName dim	ON	dim.PK_PatternName = stg.PK_PatternName
			WHERE		dim.PK_PatternName IS NULL
					OR	dim.PatternName <> stg.PatternName
					OR CAST(IIF(dim.PatternName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.PatternName IS NULL, 0, 1) AS BIT) = 1 

		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END