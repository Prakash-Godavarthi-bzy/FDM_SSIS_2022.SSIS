﻿/*====================================================================================================
Is:		dim.Mergedim.MergeMovementType
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE [dim].[usp_MergeTrackingStatus]
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			/*
			--Create new records
			INSERT		dim.TrackingStatus WITH (TABLOCK) (BK_TrackingStatus,TrackingStatus)
			SELECT		stg.BK_TrackingStatus,
						stg.TrackingStatus
			FROM		stg.dim_TrackingStatus stg	
			LEFT JOIN	dim.TrackingStatus dim	ON	dim.BK_TrackingStatus = stg.BK_TrackingStatus
			WHERE		dim.BK_TrackingStatus IS NULL

			*/

			MERGE [dim].[TrackingStatus]
                AS     TARGET
                USING  (SELECT       
										BK_TrackingStatus,
										TrackingStatus,
										AuditSourceBatchID,
                                        [AuditCreateDateTime],
                                        --[AuditGenerateDateTime]
                                        [AuditUserCreate]
                                        --[AuditHost]
                            FROM   [stg].[dim_TrackingStatus]) AS SOURCE
                ON TARGET.BK_TrackingStatus = SOURCE.BK_TrackingStatus --BK

                WHEN NOT MATCHED BY TARGET 
                                        THEN INSERT  (				[BK_TrackingStatus],
																	[TrackingStatus],
																	[AuditSourceBatchID],
																	[AuditCreateDateTime]

                                                        )
                                                VALUES (
                                                                    SOURCE.[BK_TrackingStatus],
																	SOURCE.[TrackingStatus],
                                                                    SOURCE.[AuditSourceBatchID],
                                                                    SOURCE.[AuditCreateDateTime]
                                                                )
  
                WHEN MATCHED 
                AND (
                    isnull(SOURCE.[TrackingStatus],'') <> isnull(TARGET.[TrackingStatus],'') OR
                    isnull(SOURCE.[AuditSourceBatchID],'') <> isnull(TARGET.[AuditSourceBatchID],'') OR
					isnull(SOURCE.[AuditCreateDateTime],'') <> isnull(TARGET.[AuditCreateDateTime],'') OR
					isnull(SOURCE.[AuditUserCreate],'') <> isnull(TARGET.[AuditUserCreate],'')
                                    )
THEN UPDATE SET TARGET.[TrackingStatus] = SOURCE.[TrackingStatus],
                                        TARGET.[AuditSourceBatchID] = SOURCE.[AuditSourceBatchID],
										TARGET.[AuditCreateDateTime] = SOURCE.[AuditCreateDateTime],
										TARGET.[AuditUserCreate] = SOURCE.[AuditUserCreate];
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END
GO

