﻿/*====================================================================================================
Is:		dim.Mergedim.MergeAllocation
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE dim.usp_MergeAllocation
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			UPDATE	dim
			SET		dim.AllocationPercentage = stg.AllocationPercentage
			FROM	stg.dim_Allocation stg	
			JOIN	dim.Allocation dim	ON	dim.pk_Allocation = stg.pk_Allocation
										AND dim.Account = stg.Account
										AND dim.EntityCode = stg.EntityCode
										AND dim.TrifocusCodeFrom = stg.TrifocusCodeFrom
										AND dim.TrifocusCodeTo = stg.TrifocusCodeTo
										AND dim.YOAFrom = stg.YOAFrom
										AND dim.YOATo = stg.YOATo
										AND dim.DestinationAccount = stg.DestinationAccount
										AND dim.DestinationEntity = stg.DestinationEntity
										AND dim.DestinationTrifocusCode = stg.DestinationTrifocusCode			WHERE	dim.AllocationPercentage <> stg.AllocationPercentage
				OR	CAST(IIF(dim.AllocationPercentage IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.AllocationPercentage IS NULL, 0, 1) AS BIT) = 1 

			--Create new records
			INSERT		dim.Allocation WITH (TABLOCK) (Account, EntityCode, TrifocusCodeFrom, TrifocusCodeTo, YOAFrom, YOATo, DestinationAccount, DestinationEntity, DestinationTrifocusCode, AllocationPercentage)
			SELECT		stg.Account, 
						stg.EntityCode, 
						stg.TrifocusCodeFrom, 
						stg.TrifocusCodeTo, 
						stg.YOAFrom, 
						stg.YOATo, 
						stg.DestinationAccount, 
						stg.DestinationEntity, 
						stg.DestinationTrifocusCode, 
						stg.AllocationPercentage
			FROM		stg.dim_Allocation stg	
			LEFT JOIN	dim.Allocation dim	ON	dim.pk_Allocation = stg.pk_Allocation
											AND dim.Account = stg.Account
											AND dim.EntityCode = stg.EntityCode
											AND dim.TrifocusCodeFrom = stg.TrifocusCodeFrom
											AND dim.TrifocusCodeTo = stg.TrifocusCodeTo
											AND dim.YOAFrom = stg.YOAFrom
											AND dim.YOATo = stg.YOATo
											AND dim.DestinationAccount = stg.DestinationAccount
											AND dim.DestinationEntity = stg.DestinationEntity
											AND dim.DestinationTrifocusCode = stg.DestinationTrifocusCode
			WHERE		dim.pk_Allocation IS NULL
					OR	dim.AllocationPercentage <> stg.AllocationPercentage
					OR	CAST(IIF(dim.AllocationPercentage IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.AllocationPercentage IS NULL, 0, 1) AS BIT) = 1 
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END