﻿/*====================================================================================================
Is:		dim.Mergedim.MergeRIPolicyType
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE [dim].[usp_MergeRIPolicyType]
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			UPDATE	dim
			SET		dim.RIPolicyType = stg.RIPolicyType
			FROM	stg.dim_RIPolicyType stg	
			JOIN	dim.RIPolicyType dim	ON	dim.[BK_RIPolicyType] = stg.[BK_RIPolicyType]
			WHERE	dim.RIPolicyType <> stg.RIPolicyType
				OR	CAST(IIF(dim.RIPolicyType IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.RIPolicyType IS NULL, 0, 1) AS BIT) = 1 

			--Create new records
			INSERT		dim.RIPolicyType WITH (TABLOCK) ([BK_RIPolicyType], RIPolicyType)
			SELECT		stg.[BK_RIPolicyType], 
						stg.RIPolicyType
			FROM		stg.dim_RIPolicyType stg	
			LEFT JOIN	dim.RIPolicyType dim	ON	dim.[BK_RIPolicyType] = stg.[BK_RIPolicyType]
			WHERE		dim.[BK_RIPolicyType] IS NULL
					OR	dim.RIPolicyType <> stg.RIPolicyType
					OR	CAST(IIF(dim.RIPolicyType IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.RIPolicyType IS NULL, 0, 1) AS BIT) = 1 
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END