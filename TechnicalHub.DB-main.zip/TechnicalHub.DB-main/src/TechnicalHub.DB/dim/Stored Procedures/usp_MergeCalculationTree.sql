﻿
/*====================================================================================================
Is:		Merge Dim Calculation Tree
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE [dim].[usp_MergeCalculationTree]
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

			--Overwrite SCD 1 data columns.
			WITH TARGET AS 
			(
			SELECT * FROM Dim.CalculationTree
			WHERE LEFT(PK_CalculationTree,5) IN (SELECT DISTINCT LEFT(PK_CalculationTree,5) FROM stg.dim_CalculationTree)
			)
			
			MERGE	INTO TARGET
			USING	Stg.dim_CalculationTree SOURCE 
			ON			(TARGET.[PK_CalculationTree] = SOURCE.[PK_CalculationTree])
			/*Updating Records*/
				WHEN MATCHED 
						AND	TARGET.[BusinessCode]				<> SOURCE.[BusinessCode]				
						OR	TARGET.[CalculationTreeName]		<> SOURCE.[CalculationTreeName]		
						OR	TARGET.[FK_CalculationTreeParent]	<> SOURCE.[FK_CalculationTreeParent]	
						OR	TARGET.[Operator]					<> SOURCE.[Operator]					
						OR	TARGET.[MDX]						<> SOURCE.[MDX]				
						OR	TARGET.[SortOrder]					<> SOURCE.[SortOrder]			
						OR	TARGET.[PropertiesFormat]			<> SOURCE.[PropertiesFormat]	
						OR	TARGET.[Description]				<> SOURCE.[Description]		
						OR	TARGET.[Finalised]					<> SOURCE.[Finalised]			
						OR	TARGET.[Release]					<> SOURCE.[Release]			
						OR	TARGET.[Sourced]					<> SOURCE.[Sourced]			
						OR	TARGET.[Item_URN]					<> SOURCE.[Item_URN]			
						OR	TARGET.[SME/DataSteward]			<> SOURCE.[SME/DataSteward]	
						OR	TARGET.[Notes]						<> SOURCE.[Notes]				
						OR	CAST(IIF(TARGET.[BusinessCode]				IS NULL, 0, 1) AS BIT) ^ CAST(IIF(Source.[BusinessCode]				IS NULL, 0, 1) AS BIT)		= 1
						OR	CAST(IIF(TARGET.[CalculationTreeName]		IS NULL, 0, 1) AS BIT) ^ CAST(IIF(Source.[CalculationTreeName]		IS NULL, 0, 1) AS BIT)		= 1
						OR	CAST(IIF(TARGET.[FK_CalculationTreeParent]	IS NULL, 0, 1) AS BIT) ^ CAST(IIF(Source.[FK_CalculationTreeParent]	IS NULL, 0, 1) AS BIT)		= 1
						OR	CAST(IIF(TARGET.[Operator]					IS NULL, 0, 1) AS BIT) ^ CAST(IIF(Source.[Operator]					IS NULL, 0, 1) AS BIT)		= 1
						OR	CAST(IIF(TARGET.[MDX]						IS NULL, 0, 1) AS BIT) ^ CAST(IIF(Source.[MDX]						IS NULL, 0, 1) AS BIT)		= 1
						OR	CAST(IIF(TARGET.[SortOrder]					IS NULL, 0, 1) AS BIT) ^ CAST(IIF(Source.[SortOrder]				IS NULL, 0, 1) AS BIT)		= 1
						OR	CAST(IIF(TARGET.[PropertiesFormat]			IS NULL, 0, 1) AS BIT) ^ CAST(IIF(Source.[PropertiesFormat]			IS NULL, 0, 1) AS BIT)		= 1
						OR	CAST(IIF(TARGET.[Description]				IS NULL, 0, 1) AS BIT) ^ CAST(IIF(Source.[Description]				IS NULL, 0, 1) AS BIT)		= 1
						OR	CAST(IIF(TARGET.[Finalised]					IS NULL, 0, 1) AS BIT) ^ CAST(IIF(Source.[Finalised]				IS NULL, 0, 1) AS BIT)		= 1
						OR	CAST(IIF(TARGET.[Release]					IS NULL, 0, 1) AS BIT) ^ CAST(IIF(Source.[Release]					IS NULL, 0, 1) AS BIT)		= 1
						OR	CAST(IIF(TARGET.[Sourced]					IS NULL, 0, 1) AS BIT) ^ CAST(IIF(Source.[Sourced]					IS NULL, 0, 1) AS BIT)		= 1
						OR	CAST(IIF(TARGET.[Item_URN]					IS NULL, 0, 1) AS BIT) ^ CAST(IIF(Source.[Item_URN]					IS NULL, 0, 1) AS BIT)		= 1
						OR	CAST(IIF(TARGET.[SME/DataSteward]			IS NULL, 0, 1) AS BIT) ^ CAST(IIF(Source.[SME/DataSteward]			IS NULL, 0, 1) AS BIT)		= 1
						OR	CAST(IIF(TARGET.[Notes]						IS NULL, 0, 1) AS BIT) ^ CAST(IIF(Source.[Notes]					IS NULL, 0, 1) AS BIT)		= 1
					 THEN  UPDATE SET
							 TARGET.[BusinessCode]				=	SOURCE.[BusinessCode]			
							,TARGET.[CalculationTreeName]		=	SOURCE.[CalculationTreeName]
							,TARGET.[FK_CalculationTreeParent]	=	SOURCE.[FK_CalculationTreeParent]
							,TARGET.[Operator]					=	SOURCE.[Operator]
							,TARGET.[MDX]						=	SOURCE.[MDX]
							,TARGET.[SortOrder]					=	SOURCE.[SortOrder]
							,TARGET.[PropertiesFormat]			=	SOURCE.[PropertiesFormat]
							,TARGET.[Description]				=	SOURCE.[Description]
							,TARGET.[Finalised]					=	SOURCE.[Finalised]
							,TARGET.[Release]					=	SOURCE.[Release]
							,TARGET.[Sourced]					=	SOURCE.[Sourced]
							,TARGET.[Item_URN]					=	SOURCE.[Item_URN]
							,TARGET.[SME/DataSteward]			=	SOURCE.[SME/DataSteward]
							,TARGET.[Notes]						=	SOURCE.[Notes]
				/*Inserting Records when not matched by target*/	
				WHEN NOT MATCHED BY TARGET
							THEN INSERT ( [PK_CalculationTree]
										 ,[BusinessCode]
										 ,[CalculationTreeName]
										 ,[FK_CalculationTreeParent]
										 ,[Operator]
										 ,[MDX]
										 ,[SortOrder]
										 ,[PropertiesFormat]
										 ,[Description]
										 ,[Finalised]
										 ,[Release]
										 ,[Sourced]
										 ,[Item_URN]
										 ,[SME/DataSteward]
										 ,[Notes])
								VALUES	(	 SOURCE.[PK_CalculationTree]
											,SOURCE.[BusinessCode]
											,SOURCE.[CalculationTreeName]
											,SOURCE.[FK_CalculationTreeParent]
											,SOURCE.[Operator]
											,SOURCE.[MDX]
											,SOURCE.[SortOrder]
											,SOURCE.[PropertiesFormat]
											,SOURCE.[Description]
											,SOURCE.[Finalised]
											,SOURCE.[Release]
											,SOURCE.[Sourced]
											,SOURCE.[Item_URN]
											,SOURCE.[SME/DataSteward]
											,SOURCE.[Notes])
					/*Deleting Records when not matched by source*/
					WHEN NOT MATCHED BY SOURCE 
								THEN DELETE;

			
		IF @Trancount = 0 COMMIT;

		TRUNCATE TABLE stg.dim_CalculationTree;

	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END