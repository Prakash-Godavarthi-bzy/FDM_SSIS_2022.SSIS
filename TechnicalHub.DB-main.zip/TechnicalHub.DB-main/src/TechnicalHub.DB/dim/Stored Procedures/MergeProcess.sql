﻿/*====================================================================================================
Is:		dim.Mergedim.MergeProcess
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE dim.usp_MergeProcess
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			UPDATE	dim
			SET		dim.ProcessName = stg.ProcessName,
					dim.ProcessLevel1 = stg.ProcessLevel1,
					dim.ProcessLevel2 = stg.ProcessLevel2,
					dim.ProcessLevel3 = stg.ProcessLevel3,
					dim.CurrentAccountingPeriod = stg.CurrentAccountingPeriod
			FROM	stg.dim_Process stg	
			JOIN	dim.Process dim	ON	dim.[BK_Process] = stg.[BK_Process]			WHERE	dim.ProcessName <> stg.ProcessName
				OR	dim.ProcessLevel1 <> stg.ProcessLevel1
				OR	dim.ProcessLevel2 <> stg.ProcessLevel2
				OR	dim.ProcessLevel3 <> stg.ProcessLevel3
				OR	dim.CurrentAccountingPeriod <> stg.CurrentAccountingPeriod
				OR	CAST(IIF(dim.ProcessName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.ProcessName IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.ProcessLevel1 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.ProcessLevel1 IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.ProcessLevel2 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.ProcessLevel2 IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.ProcessLevel3 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.ProcessLevel3 IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.CurrentAccountingPeriod IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.CurrentAccountingPeriod IS NULL, 0, 1) AS BIT) = 1 

			--Create new records
			INSERT		dim.Process WITH (TABLOCK) ([BK_Process], ProcessName, ProcessLevel1, ProcessLevel2, ProcessLevel3, CurrentAccountingPeriod)
			SELECT		stg.[BK_Process], 
						stg.ProcessName, 
						stg.ProcessLevel1, 
						stg.ProcessLevel2, 
						stg.ProcessLevel3, 
						stg.CurrentAccountingPeriod
			FROM		stg.dim_Process stg	
			LEFT JOIN	dim.Process dim	ON	dim.[BK_Process] = stg.[BK_Process]
			WHERE		dim.[BK_Process] IS NULL
					OR	dim.ProcessName <> stg.ProcessName
					OR	dim.ProcessLevel1 <> stg.ProcessLevel1
					OR	dim.ProcessLevel2 <> stg.ProcessLevel2
					OR	dim.ProcessLevel3 <> stg.ProcessLevel3
					OR	dim.CurrentAccountingPeriod <> stg.CurrentAccountingPeriod
					OR	CAST(IIF(dim.ProcessName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.ProcessName IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.ProcessLevel1 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.ProcessLevel1 IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.ProcessLevel2 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.ProcessLevel2 IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.ProcessLevel3 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.ProcessLevel3 IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.CurrentAccountingPeriod IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.CurrentAccountingPeriod IS NULL, 0, 1) AS BIT) = 1 
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END