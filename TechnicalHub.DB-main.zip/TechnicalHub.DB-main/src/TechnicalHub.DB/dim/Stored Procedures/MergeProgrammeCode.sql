﻿/*====================================================================================================
Is:		[usp_MergeProgrammeCode]
Does:	Updates SCD values with staged data

Modified by : Venkat.yerravati@beazley.com
Modified Date : 15/10/2024
Description : Added [Retro_Reinsurance_Ind] column https://beazley.atlassian.net/browse/I1B-2892
====================================================================================================*/
CREATE PROCEDURE [dim].[usp_MergeProgrammeCode]
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			UPDATE	dim
			SET		dim.ProgrammeCode = stg.ProgrammeCode,DIM.Retro_Reinsurance_Ind=STG.[Retro_Reinsurance_Ind]
			FROM	stg.dim_ProgrammeCode stg	
			JOIN	dim.ProgrammeCode dim	ON	dim.[BK_ProgrammeCode] = stg.[BK_ProgrammeCode]			WHERE	dim.ProgrammeCode <> stg.ProgrammeCode or dim.Retro_Reinsurance_Ind is null
				OR	CAST(IIF(dim.ProgrammeCode IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.ProgrammeCode IS NULL, 0, 1) AS BIT) = 1 

			UPDATE dim
			SET dim.Retro_Reinsurance_Ind = 'N'
			FROM dim.ProgrammeCode dim
			LEFT JOIN stg.dim_ProgrammeCode stg ON dim.[BK_ProgrammeCode] = stg.[BK_ProgrammeCode]
			WHERE stg.[BK_ProgrammeCode] IS NULL;


			--Create new records
			INSERT		dim.ProgrammeCode WITH (TABLOCK) ([BK_ProgrammeCode], ProgrammeCode,Retro_Reinsurance_Ind)
			SELECT		stg.[BK_ProgrammeCode], 
						stg.ProgrammeCode,
						stg.Retro_Reinsurance_Ind
			FROM		stg.dim_ProgrammeCode stg	
			LEFT JOIN	dim.ProgrammeCode dim	ON	dim.[BK_ProgrammeCode] = stg.[BK_ProgrammeCode]
			WHERE		dim.[BK_ProgrammeCode] IS NULL
					OR	dim.ProgrammeCode <> stg.ProgrammeCode
					OR	CAST(IIF(dim.ProgrammeCode IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.ProgrammeCode IS NULL, 0, 1) AS BIT) = 1 
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END
