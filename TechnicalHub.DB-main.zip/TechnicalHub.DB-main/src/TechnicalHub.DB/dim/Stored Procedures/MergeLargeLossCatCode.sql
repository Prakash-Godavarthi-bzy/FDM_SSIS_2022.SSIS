﻿/*====================================================================================================
Is:           dim.Mergedim.MergeDataStage
Does:  Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE dim.usp_MergeLargeLossCatCode
AS
BEGIN
DECLARE @Trancount INT = @@Trancount
BEGIN TRY
        IF @Trancount = 0 BEGIN TRAN;

                MERGE [dim].[LargeLossCatCode]
                AS     TARGET
                USING  (SELECT			[PK_CatCode],
										[BeazleyCatCode],
                                        [MarketCatCode],
                                        [BeazleyCatDesription],
                                        [BeazleySpecial],
                                        [EventYear],
                                        [BeazleyEventName],
                                        [LargeLossIndicator],
                                        [AuditSourceBatchID],
                                        --[AuditCreateDateTime],
                                        [AuditGenerateDateTime]
                                        --[AuditUserCreate],
                                        --[AuditHost]
                            FROM   [stg].[dim_LargeLossCatCode]) AS SOURCE
                ON TARGET.PK_CatCode = SOURCE.PK_CatCode

                WHEN NOT MATCHED BY TARGET 
                                        THEN INSERT  (       [PK_CatCode],
																[BeazleyCatCode],
                                                                    [MarketCatCode],
                                                                    [BeazleyCatDesription],
                                                                    [BeazleySpecial],
                                                                    [EventYear],
                                                                    [BeazleyEventName],
                                                                    [LargeLossIndicator],
                                                                    [AuditSourceBatchID],
                                                                    --[AuditCreateDateTime],
                                                                    [AuditGenerateDateTime]
                                                                    --[AuditUserCreate],
                                                                    --[AuditHost]

                                                        )
                                                VALUES (
                                                                    SOURCE.[PK_CatCode],
																	SOURCE.[BeazleyCatCode],
                                                                    SOURCE.[MarketCatCode],
                                                                    SOURCE.[BeazleyCatDesription],
                                                                    SOURCE.[BeazleySpecial],
                                                                    SOURCE.[EventYear],
                                                                    SOURCE.[BeazleyEventName],
                                                                    SOURCE.[LargeLossIndicator],
                                                                    SOURCE.[AuditSourceBatchID],
                                                                    --SOURCE.[AuditCreateDateTime],
																	SOURCE.[AuditGenerateDateTime]
                                                                    --SOURCE.[AuditUserCreate],
                                                                    --SOURCE.[AuditHost]
                                                                )
  
                WHEN MATCHED 
                AND (
				isnull(SOURCE.[BeazleyCatCode],'') <> isnull(TARGET.[BeazleyCatCode],'') OR
                    isnull(SOURCE.[MarketCatCode],'') <> isnull(TARGET.[MarketCatCode],'') OR
                    isnull(SOURCE.[BeazleyCatDesription],'') <> isnull(TARGET.[BeazleyCatDesription],'') OR
                    isnull(SOURCE.[BeazleySpecial],'') <> isnull(TARGET.[BeazleySpecial],'') OR
                                    isnull(SOURCE.[EventYear],'') <> isnull(TARGET.[EventYear],'') OR
                                    isnull(SOURCE.[BeazleyEventName],'') <> isnull(TARGET.[BeazleyEventName],'') OR
                                    isnull(SOURCE.[LargeLossIndicator],'') <> isnull(TARGET.[LargeLossIndicator],'') OR
                                    isnull(SOURCE.[AuditSourceBatchID],'') <> isnull(TARGET.[AuditSourceBatchID],'') 
                                    )
THEN UPDATE SET TARGET.[BeazleyCatCode] = SOURCE.[BeazleyCatCode],
										TARGET.[MarketCatCode] = SOURCE.[MarketCatCode],
                                        TARGET.[BeazleyCatDesription] = SOURCE.[BeazleyCatDesription],
                                        TARGET.[BeazleySpecial] = SOURCE.[BeazleySpecial],
                                        TARGET.[EventYear] = SOURCE.[EventYear],
                                        TARGET.[BeazleyEventName] = SOURCE.[BeazleyEventName],
                                        TARGET.[LargeLossIndicator] = SOURCE.[LargeLossIndicator],
                                        TARGET.[AuditSourceBatchID] = SOURCE.[AuditSourceBatchID];
                          
                         
        IF @Trancount = 0 COMMIT;
END TRY
BEGIN CATCH
        IF @Trancount = 0 ROLLBACK;
        THROW;
END CATCH
END
