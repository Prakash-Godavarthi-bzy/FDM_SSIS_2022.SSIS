﻿/*====================================================================================================
Is:		dim.Mergedim.MergeCCY
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE dim.usp_MergeCCY
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			UPDATE	dim
			SET		dim.CCYName = stg.CCYName
			FROM	stg.dim_CCY stg	
			JOIN	dim.CCY dim	ON	dim.[BK_CCY] = stg.[BK_CCY]			WHERE	dim.CCYName <> stg.CCYName
				OR	CAST(IIF(dim.CCYName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.CCYName IS NULL, 0, 1) AS BIT) = 1 

			--Create new records
			INSERT		dim.CCY WITH (TABLOCK) ([BK_CCY], CCYName)
			SELECT		stg.[BK_CCY], 
						stg.CCYName
			FROM		stg.dim_CCY stg	
			LEFT JOIN	dim.CCY dim	ON	dim.[BK_CCY] = stg.[BK_CCY]
			WHERE		dim.[BK_CCY] IS NULL
					OR	dim.CCYName <> stg.CCYName
					OR	CAST(IIF(dim.CCYName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.CCYName IS NULL, 0, 1) AS BIT) = 1 
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END