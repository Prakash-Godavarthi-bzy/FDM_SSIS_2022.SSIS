﻿/*====================================================================================================
Is:		dim.Mergedim.MergeYOA
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE [dim].[usp_MergeYOA]
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Create new records
			INSERT		dim.YOA WITH (TABLOCK) ([BK_YOA])
			SELECT		stg.[BK_YOA]
			FROM		stg.dim_YOA stg	
			LEFT JOIN	dim.YOA dim	ON	dim.[BK_YOA] = stg.[BK_YOA]
			WHERE		dim.[BK_YOA] IS NULL
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END