﻿/*====================================================================================================
Is:		dim.Mergedim.MergeProduct
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE dim.usp_MergeProduct
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			UPDATE	dim
			SET		dim.ProductName = stg.ProductName
			FROM	stg.dim_Product stg	
			JOIN	dim.Product dim	ON	dim.[BK_Product] = stg.[BK_Product]			WHERE	dim.ProductName <> stg.ProductName
				OR	CAST(IIF(dim.ProductName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.ProductName IS NULL, 0, 1) AS BIT) = 1 

			--Create new records
			INSERT		dim.Product WITH (TABLOCK) ([BK_Product], ProductName)
			SELECT		stg.[BK_Product], 
						stg.ProductName
			FROM		stg.dim_Product stg	
			LEFT JOIN	dim.Product dim	ON	dim.[BK_Product] = stg.[BK_Product]
			WHERE		dim.[BK_Product] IS NULL
					OR	dim.ProductName <> stg.ProductName
					OR	CAST(IIF(dim.ProductName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.ProductName IS NULL, 0, 1) AS BIT) = 1 
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END