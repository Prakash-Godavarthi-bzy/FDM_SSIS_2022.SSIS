﻿/*====================================================================================================
Is:		dim.Mergedim.MergeLocation
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE dim.usp_MergeLocation
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			UPDATE	dim
			SET		dim.LocationName = stg.LocationName
			FROM	stg.dim_Location stg	
			JOIN	dim.Location dim	ON	dim.[BK_Location] = stg.[BK_Location]			WHERE	dim.LocationName <> stg.LocationName
				OR	CAST(IIF(dim.LocationName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.LocationName IS NULL, 0, 1) AS BIT) = 1 

			--Create new records
			INSERT		dim.Location WITH (TABLOCK) ([BK_Location], LocationName)
			SELECT		stg.[BK_Location], 
						stg.LocationName
			FROM		stg.dim_Location stg	
			LEFT JOIN	dim.Location dim	ON	dim.[BK_Location] = stg.[BK_Location]
			WHERE		dim.[BK_Location] IS NULL
					OR	dim.LocationName <> stg.LocationName
					OR	CAST(IIF(dim.LocationName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.LocationName IS NULL, 0, 1) AS BIT) = 1 
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END