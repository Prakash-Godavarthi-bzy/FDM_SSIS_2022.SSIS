﻿
	/*====================================================================================================
Is:           dim.usp_MergeCatCode
Does:  Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE [dim].[usp_MergeCatCode]
AS
BEGIN
DECLARE @Trancount INT = @@Trancount
BEGIN TRY
        IF @Trancount = 0 BEGIN TRAN;

                MERGE [dim].[CatCode]
                AS     TARGET
                USING  (SELECT       distinct
										[BK_CatCode],
										[BeazleyCatCode],
                                        [MarketCatCode],
                                        [BeazleyCatDesription],
                                        [BeazleySpecial],
                                        [EventYear],
                                        [BeazleyEventName],
                                        [LargeLossIndicator],
										[EventDate]
                            FROM   [stg].[dim_CatCode]) AS SOURCE
                ON TARGET.BK_CatCode = SOURCE.BK_CatCode --BK

                WHEN NOT MATCHED BY TARGET 
                                        THEN INSERT  (				[BK_CatCode],
																	[BeazleyCatCode],
                                                                    [MarketCatCode],
                                                                    [BeazleyCatDesription],
                                                                    [BeazleySpecial],
                                                                    [EventYear],
                                                                    [BeazleyEventName],
                                                                    [LargeLossIndicator],
																	[EventDate],
                                                                    [AuditSourceBatchID],
                                                                    [AuditGenerateDateTime]
                                                                  
                                                        )
                                                VALUES (
                                                                    SOURCE.[BK_CatCode],
																	SOURCE.[BeazleyCatCode],
                                                                    SOURCE.[MarketCatCode],
                                                                    SOURCE.[BeazleyCatDesription],
                                                                    SOURCE.[BeazleySpecial],
                                                                    SOURCE.[EventYear],
                                                                    SOURCE.[BeazleyEventName],
                                                                    SOURCE.[LargeLossIndicator],
																	SOURCE.[EventDate],
                                                                    1 ,
                                                                    --SOURCE.[AuditCreateDateTime],
																	getdate()
                                                                    --SOURCE.[AuditUserCreate],
                                                                    --SOURCE.[AuditHost]
                                                                )
  
                WHEN MATCHED 
                AND (
					isnull(SOURCE.BeazleyCatCode,'') <> isnull(TARGET.BeazleyCatCode,'') OR
                    isnull(SOURCE.[MarketCatCode],'') <> isnull(TARGET.[MarketCatCode],'') OR
                    isnull(SOURCE.[BeazleyCatDesription],'') <> isnull(TARGET.[BeazleyCatDesription],'') OR
                    isnull(SOURCE.[BeazleySpecial],'') <> isnull(TARGET.[BeazleySpecial],'') OR
                    isnull(SOURCE.[EventYear],'') <> isnull(TARGET.[EventYear],'') OR
                    isnull(SOURCE.[BeazleyEventName],'') <> isnull(TARGET.[BeazleyEventName],'') OR
                    isnull(SOURCE.[LargeLossIndicator],'') <> isnull(TARGET.[LargeLossIndicator],'') OR
					isnull(SOURCE.[EventDate],'') <> isnull(TARGET.[EventDate],'') 
                                    )
THEN UPDATE SET		TARGET.BeazleyCatCode = SOURCE.BeazleyCatCode,					
										TARGET.[MarketCatCode] = SOURCE.[MarketCatCode],
                                        TARGET.[BeazleyCatDesription] = SOURCE.[BeazleyCatDesription],
                                        TARGET.[BeazleySpecial] = SOURCE.[BeazleySpecial],
                                        TARGET.[EventYear] = SOURCE.[EventYear],
                                        TARGET.[BeazleyEventName] = SOURCE.[BeazleyEventName],
                                        TARGET.[LargeLossIndicator] = SOURCE.[LargeLossIndicator],
										 TARGET.[EventDate] = SOURCE.[EventDate];
                          
                         
        IF @Trancount = 0 COMMIT;
END TRY
BEGIN CATCH
        IF @Trancount = 0 ROLLBACK;
        THROW;
END CATCH
END