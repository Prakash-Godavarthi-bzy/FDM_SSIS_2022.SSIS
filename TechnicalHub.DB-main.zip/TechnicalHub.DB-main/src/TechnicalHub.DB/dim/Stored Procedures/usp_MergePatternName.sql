﻿/*====================================================================================================
Is:		dim.Mergedim.MergePatternName
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE dim.[usp_MergePatternName]
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			UPDATE	dim
			SET		dim.SourceTable = stg.SourceTable,
					dim.PatternNames = stg.PatternNames,
					dim.PatternRef = stg.PatternRef
			FROM	stg.dim_PatternName stg	
			JOIN	dim.PatternName dim	ON	dim.PK_PatternName = stg.PK_PatternName			WHERE	dim.SourceTable <> stg.SourceTable
				OR	dim.PatternNames <> stg.PatternNames
				OR	dim.PatternRef <> stg.PatternRef
				OR	CAST(IIF(dim.SourceTable IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.SourceTable IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.PatternNames IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.PatternNames IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.PatternRef IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.PatternRef IS NULL, 0, 1) AS BIT) = 1 

			--Create new records
			INSERT		dim.PatternName WITH (TABLOCK) (PK_PatternName, SourceTable, PatternNames, PatternRef)
			SELECT		stg.PK_PatternName, 
						stg.SourceTable, 
						stg.PatternNames, 
						stg.PatternRef
			FROM		stg.dim_PatternName stg	
			LEFT JOIN	dim.PatternName dim	ON	dim.PK_PatternName = stg.PK_PatternName
			WHERE		dim.PK_PatternName IS NULL
					OR	dim.SourceTable <> stg.SourceTable
					OR	dim.PatternNames <> stg.PatternNames
					OR	dim.PatternRef <> stg.PatternRef
					OR	CAST(IIF(dim.SourceTable IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.SourceTable IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.PatternNames IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.PatternNames IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.PatternRef IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.PatternRef IS NULL, 0, 1) AS BIT) = 1 
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END