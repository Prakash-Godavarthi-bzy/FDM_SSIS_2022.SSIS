﻿/*====================================================================================================
Is:		dim.Mergedim.MergeAccount
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE dim.usp_MergeAccount
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			/*
			UPDATE	dim
			SET		dim.AccountName = stg.AccountName,
					dim.Level1Group = stg.Level1Group,
					dim.Level2Group = stg.Level2Group,
					dim.Level3Group = stg.Level3Group
			FROM	stg.dim_Account stg	
			JOIN	dim.Account dim	ON	dim.[BK_Account] = stg.[BK_Account]			WHERE	dim.AccountName <> stg.AccountName
				OR	dim.Level1Group <> stg.Level1Group
				OR	dim.Level2Group <> stg.Level2Group
				OR	dim.Level3Group <> stg.Level3Group
				OR	CAST(IIF(dim.AccountName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.AccountName IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.Level1Group IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Level1Group IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.Level2Group IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Level2Group IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.Level3Group IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Level3Group IS NULL, 0, 1) AS BIT) = 1 

			--Create new records
			INSERT		dim.Account WITH (TABLOCK) ([BK_Account], AccountName, Level1Group, Level2Group, Level3Group)
			SELECT		stg.[BK_Account], 
						stg.AccountName, 
						stg.Level1Group, 
						stg.Level2Group, 
						stg.Level3Group
			FROM		stg.dim_Account stg	
			LEFT JOIN	dim.Account dim	ON	dim.[BK_Account] = stg.[BK_Account]
			WHERE		dim.[BK_Account] IS NULL
					OR	dim.AccountName <> stg.AccountName
					OR	dim.Level1Group <> stg.Level1Group
					OR	dim.Level2Group <> stg.Level2Group
					OR	dim.Level3Group <> stg.Level3Group
					OR	CAST(IIF(dim.AccountName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.AccountName IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.Level1Group IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Level1Group IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.Level2Group IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Level2Group IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.Level3Group IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Level3Group IS NULL, 0, 1) AS BIT) = 1 
					*/
						
			--Overwrite SCD 1 data columns.
			UPDATE	dim
			SET		dim.AccountName = stg.AccountName
					--dim.RIflag      = stg.RIflag
			FROM	stg.dim_Account stg	
			JOIN	dim.Account dim	ON	dim.BK_Account = stg.BK_Account			WHERE	dim.AccountName <> stg.AccountName
				--OR  dim.RIFlag <> stg.RIFlag 

				OR	CAST(IIF(dim.AccountName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.AccountName IS NULL, 0, 1) AS BIT) = 1 
			--	OR	CAST(IIF(dim.RIFlag IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.RIFlag IS NULL, 0, 1) AS BIT) = 1 
			

			--Create new records
			INSERT		dim.Account WITH (TABLOCK) (BK_Account, AccountName, RIFlag)
			SELECT		stg.BK_Account, 
						stg.AccountName,
						stg.RIFlag
						
			FROM		stg.dim_Account stg	
			LEFT JOIN	dim.Account dim	ON	dim.BK_Account = stg.BK_Account
			WHERE		dim.PK_Account IS NULL
					OR	dim.AccountName <> stg.AccountName
				--	OR dim.RIFlag <> stg.RIFlag

					OR	CAST(IIF(dim.AccountName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.AccountName IS NULL, 0, 1) AS BIT) = 1 

		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END