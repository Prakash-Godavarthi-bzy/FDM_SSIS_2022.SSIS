﻿CREATE PROCEDURE dim.usp_UpdateAccountingPeriod @Update dim.utt_UpdateAccountingPeriod READONLY
AS
BEGIN
	UPDATE	tgt
	SET		tgt.CurrentAccountingPeriod = src.CurrentAccountingPeriod
	FROM	dim.Process tgt
	JOIN	@Update src ON src.PK_Process = tgt.[BK_Process]
END
