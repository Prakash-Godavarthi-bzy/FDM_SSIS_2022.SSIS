﻿/*====================================================================================================
Is:		dim.Mergedim.MergeReservingDataset
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE [dim].[usp_MergeReservingDataset]
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			UPDATE	dim
			SET		dim.[ReservingDataSetName]  = stg.[ReservingDataSetName],
					dim.[ReservingDataSetGroup] = stg.[ReservingDataSetGroup]
			FROM	stg.dim_ReservingDataset stg	
			JOIN	dim.ReservingDataset dim	ON	dim.[BK_ReservingDataset] = stg.[BK_ReservingDataset]			WHERE	dim.[ReservingDataSetName] <> stg.[ReservingDataSetName]
				OR	CAST(IIF(dim.[ReservingDataSetName] IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.[ReservingDataSetName] IS NULL, 0, 1) AS BIT) = 1 

			--Create new records
			INSERT		dim.ReservingDataset WITH (TABLOCK) ([BK_ReservingDataset], [ReservingDataSetName],[ReservingDataSetGroup])
			SELECT		stg.[BK_ReservingDataset], 
						stg.[ReservingDataSetName],
						stg.[ReservingDataSetGroup]
			FROM		stg.dim_ReservingDataset stg	
			LEFT JOIN	dim.ReservingDataset dim	ON	dim.[BK_ReservingDataset] = stg.[BK_ReservingDataset]
			WHERE		dim.[BK_ReservingDataset] IS NULL
					OR	dim.[ReservingDataSetName] <> stg.[ReservingDataSetName]
					OR  dim.[ReservingDataSetGroup] <> stg.[ReservingDataSetGroup]
					OR	CAST(IIF(dim.[ReservingDataSetName] IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.[ReservingDataSetName] IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.[ReservingDataSetGroup] IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.[ReservingDataSetGroup] IS NULL, 0, 1) AS BIT) = 1
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END