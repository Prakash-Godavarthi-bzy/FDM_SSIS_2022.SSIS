﻿-- =============================================
-- Author:		Hemomsu Lakkaraju
-- Create date: 07 Dec 2020
-- Description:	This procedure is used to Process the Assumption Dataset Dimension via Orchestration.
-- =============================================
CREATE PROCEDURE [dim].[AssumptionDatasetProcessingCall]
AS
select 1
/*
UPDATE SchedulingHub.etl.Orchestration
SET		IsEnabled = 0

UPDATE SchedulingHub.etl.Orchestration
SET		IsEnabled = 1
WHERE	PK_Orchestration = 4

EXEC msdb.dbo.sp_start_job 'SchedulingHub'*/
