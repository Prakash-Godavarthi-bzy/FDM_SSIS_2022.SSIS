﻿/*====================================================================================================
Is:		dim.Mergedim.MergeEntity
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE dim.usp_MergeEntity
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			UPDATE	dim
			SET		dim.Entity = stg.Entity,
					dim.EntityName = stg.EntityName,
					dim.Platform = stg.Platform,
					dim.EntityLevel1 = stg.EntityLevel1,
					dim.EntityLevel2 = stg.EntityLevel2,
					dim.EntityLevel3 = stg.EntityLevel3,
					dim.EntityLevel4 = stg.EntityLevel4,
					dim.EntityLevel5 = stg.EntityLevel5
			FROM	stg.dim_Entity stg	
			JOIN	dim.Entity dim	ON	dim.[BK_Entity] = stg.[BK_Entity]			WHERE	dim.Entity <> stg.Entity
				OR	dim.EntityName <> stg.EntityName
				OR	dim.Platform <> stg.Platform
				OR	dim.EntityLevel1 <> stg.EntityLevel1
				OR	dim.EntityLevel2 <> stg.EntityLevel2
				OR	dim.EntityLevel3 <> stg.EntityLevel3
				OR	dim.EntityLevel4 <> stg.EntityLevel4
				OR	dim.EntityLevel5 <> stg.EntityLevel5
				OR	CAST(IIF(dim.Entity IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Entity IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.EntityName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.EntityName IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.Platform IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Platform IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.EntityLevel1 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.EntityLevel1 IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.EntityLevel2 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.EntityLevel2 IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.EntityLevel3 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.EntityLevel3 IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.EntityLevel4 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.EntityLevel4 IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.EntityLevel5 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.EntityLevel5 IS NULL, 0, 1) AS BIT) = 1 

			--Create new records
			INSERT		dim.Entity WITH (TABLOCK) ([BK_Entity], Entity, EntityName, Platform, EntityLevel1, EntityLevel2, EntityLevel3, EntityLevel4, EntityLevel5)
			SELECT		stg.[BK_Entity], 
						stg.Entity, 
						stg.EntityName, 
						stg.Platform, 
						stg.EntityLevel1, 
						stg.EntityLevel2, 
						stg.EntityLevel3, 
						stg.EntityLevel4, 
						stg.EntityLevel5
			FROM		stg.dim_Entity stg	
			LEFT JOIN	dim.Entity dim	ON	dim.[BK_Entity] = stg.[BK_Entity]
			WHERE		dim.[BK_Entity] IS NULL
					OR	dim.Entity <> stg.Entity
					OR	dim.EntityName <> stg.EntityName
					OR	dim.Platform <> stg.Platform
					OR	dim.EntityLevel1 <> stg.EntityLevel1
					OR	dim.EntityLevel2 <> stg.EntityLevel2
					OR	dim.EntityLevel3 <> stg.EntityLevel3
					OR	dim.EntityLevel4 <> stg.EntityLevel4
					OR	dim.EntityLevel5 <> stg.EntityLevel5
					OR	CAST(IIF(dim.Entity IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Entity IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.EntityName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.EntityName IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.Platform IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Platform IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.EntityLevel1 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.EntityLevel1 IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.EntityLevel2 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.EntityLevel2 IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.EntityLevel3 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.EntityLevel3 IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.EntityLevel4 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.EntityLevel4 IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.EntityLevel5 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.EntityLevel5 IS NULL, 0, 1) AS BIT) = 1 
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END