﻿CREATE PROCEDURE [Dim].[MergeAccountsBR1]
AS
MERGE dim.Account AS target
USING (SELECT DISTINCT OT.Account AS PK_Account, 'Data Contract' as SourceSystem FROM FinanceDataContract.Outbound.[Transaction] OT) AS source
ON target.[BK_Account] = source.PK_Account
WHEN NOT MATCHED THEN 
INSERT ([BK_Account], AccountName, Level1Group)
VALUES (source.PK_Account,source.PK_Account, source.SourceSystem);