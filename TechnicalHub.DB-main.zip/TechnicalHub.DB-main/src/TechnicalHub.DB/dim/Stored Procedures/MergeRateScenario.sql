﻿/*====================================================================================================
Is:		dim.usp_MergeRateScenario
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE dim.usp_MergeRateScenario
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount ;
	BEGIN TRY
		IF @Trancount = 0 
		
		BEGIN TRAN;

			--Overwrite SCD 1 data columns.
			UPDATE	dim
			SET		 dim.RateName	= stg.RateName
					,dim.RateGroup	= stg.RateGroup
					,dim.Locked		= stg.Locked
					,dim.SortOrder	= stg.SortOrder
			FROM	stg.dim_RateScenario stg	
			JOIN	dim.RateScenario dim	ON	dim.PK_RateCode = stg.PK_RateCode
			WHERE
				   dim.RateName		<> stg.RateName
				OR dim.RateGroup	<> stg.RateGroup
				OR dim.Locked		<> stg.Locked
				OR dim.SortOrder	<> stg.SortOrder
				OR	CAST(IIF(dim.RateName	IS NULL, 0, 1) AS BIT)	^ CAST(IIF(stg.RateName		IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.RateGroup	IS NULL, 0, 1) AS BIT)	^ CAST(IIF(stg.RateGroup	IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.Locked		IS NULL, 0, 1) AS BIT)	^ CAST(IIF(stg.Locked		IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.SortOrder	IS NULL, 0, 1) AS BIT)	^ CAST(IIF(stg.SortOrder	IS NULL, 0, 1) AS BIT) = 1 
			;				

			--Create new records
			INSERT INTO dim.RateScenario WITH (TABLOCK) 
			(
				  PK_RateCode		
				 ,RateName		
				 ,RateGroup		
				 ,Locked			
				 ,SortOrder		
			)
			SELECT		
				  stg.PK_RateCode		
				 ,stg.RateName		
				 ,stg.RateGroup		
				 ,stg.Locked			
				 ,stg.SortOrder	
			FROM		stg.dim_RateScenario stg	
			LEFT JOIN	dim.RateScenario dim
				ON dim.PK_RateCode = stg.PK_RateCode
			WHERE		dim.PK_RateCode IS NULL
					OR	dim.RateName <> stg.RateName
					OR	dim.RateGroup <> stg.RateGroup
					OR	dim.Locked <> stg.Locked
					OR	dim.SortOrder <> stg.SortOrder
					OR	CAST(IIF(dim.RateName	IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.RateName	IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.RateGroup	IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.RateGroup IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.Locked		IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Locked	IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.SortOrder	IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.SortOrder IS NULL, 0, 1) AS BIT) = 1 
			;

		IF @Trancount = 0 
			COMMIT;
	END TRY

	BEGIN CATCH;
		IF @Trancount = 0 
			ROLLBACK;
		THROW;
	END CATCH
END
