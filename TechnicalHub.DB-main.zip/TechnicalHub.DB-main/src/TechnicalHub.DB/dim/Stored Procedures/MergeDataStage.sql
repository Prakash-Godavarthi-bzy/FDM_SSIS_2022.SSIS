﻿/*====================================================================================================
Is:		dim.Mergedim.MergeDataStage
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE dim.usp_MergeDataStage
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			UPDATE	dim
			SET		dim.DataStageName = stg.DataStageName
			FROM	stg.dim_DataStage stg	
			JOIN	dim.DataStage dim	ON	dim.PK_DataStage = stg.PK_DataStage			WHERE	dim.DataStageName <> stg.DataStageName
				OR	CAST(IIF(dim.DataStageName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.DataStageName IS NULL, 0, 1) AS BIT) = 1 

			--Create new records
			INSERT		dim.DataStage WITH (TABLOCK) (PK_DataStage, DataStageName)
			SELECT		stg.PK_DataStage, 
						stg.DataStageName
			FROM		stg.dim_DataStage stg	
			LEFT JOIN	dim.DataStage dim	ON	dim.PK_DataStage = stg.PK_DataStage
			WHERE		dim.PK_DataStage IS NULL
					OR	dim.DataStageName <> stg.DataStageName
					OR	CAST(IIF(dim.DataStageName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.DataStageName IS NULL, 0, 1) AS BIT) = 1 
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END