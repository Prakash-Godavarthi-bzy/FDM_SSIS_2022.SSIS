﻿/*====================================================================================================
Is:		dim.Mergedim.MergeMovementType
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE [dim].[usp_MergeMovementType]
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
				/*
			--Create new records
			INSERT		dim.MovementType WITH (TABLOCK) (BK_MovementType,MovementType)
			SELECT		stg.BK_MovementType,
						stg.MovementType
			FROM		stg.dim_MovementType stg	
			LEFT JOIN	dim.MovementType dim	ON	dim.BK_MovementType = stg.BK_MovementType
			WHERE		dim.BK_MovementType IS NULL
			*/

			
			 MERGE [dim].[MovementType]
                AS     TARGET
                USING  (SELECT       
										BK_MovementType,
										MovementType,
										AuditSourceBatchID,
                                        [AuditCreateDateTime],
                                        [AuditUserCreate]
                                        --[AuditHost]
                            FROM   [stg].[dim_MovementType]) AS SOURCE
                ON TARGET.BK_MovementType = SOURCE.BK_MovementType --BK

                WHEN NOT MATCHED BY TARGET 
                                        THEN INSERT  (				[BK_MovementType],
																	[MovementType],
																	[AuditSourceBatchID],
																	[AuditCreateDateTime]

                                                        )
                                                VALUES (
                                                                    SOURCE.[BK_MovementType],
																	SOURCE.[MovementType],
                                                                    SOURCE.[AuditSourceBatchID],
                                                                    SOURCE.[AuditCreateDateTime]
                                                                )
  
                WHEN MATCHED 
                AND (
                    isnull(SOURCE.[MovementType],'') <> isnull(TARGET.[MovementType],'') OR
                    isnull(SOURCE.[AuditSourceBatchID],'') <> isnull(TARGET.[AuditSourceBatchID],'') OR
					isnull(SOURCE.[AuditCreateDateTime],'') <> isnull(TARGET.[AuditCreateDateTime],'') OR
					isnull(SOURCE.[AuditUserCreate],'') <> isnull(TARGET.[AuditUserCreate],'')
                                    )
THEN UPDATE SET TARGET.[MovementType] = SOURCE.[MovementType],
                                        TARGET.[AuditSourceBatchID] = SOURCE.[AuditSourceBatchID],
										TARGET.[AuditCreateDateTime] = SOURCE.[AuditCreateDateTime],
										TARGET.[AuditUserCreate] = SOURCE.[AuditUserCreate];
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END
GO


