﻿CREATE PROCEDURE [dim].[MergeDatasetBR1]
AS
MERGE dim.DataSet AS target
USING ( SELECT src.*,ds.GrossRI
FROM
		(SELECT DISTINCT OT.Dataset AS PK_DataSet, 'DataContract' as SourceSystem FROM FinanceDataContract.Outbound.[Transaction] OT
		UNION
		SELECT 'PFT_Forecast','TechnicalHub' as SourceSystem --Added the dataset for 3706
		UNION
		SELECT 'ReservingData_TOPUP','TechnicalHub' as SourceSystem --Added the dataset for 3664
		UNION
		SELECT DISTINCT P.Dataset AS PK_DataSet, 'DataContract' as SourceSystem FROM FinanceDataContract.Outbound.[Pattern] P) AS src
		LEFT JOIN FinanceLanding.MDS.Dataset AS ds
		ON src.PK_DataSet = ds.bk_Dataset) source
ON target.[BK_DataSet] = source.PK_DataSet

WHEN MATCHED AND (source.GrossRI <> target.GrossRI OR target.GrossRI is NULL)
THEN Update SET Target.GrossRI = Source.GrossRI

WHEN NOT MATCHED THEN 
INSERT ([BK_DataSet], SourceSystem,GrossRI)
VALUES (source.PK_DataSet, source.SourceSystem,source.GrossRI);
