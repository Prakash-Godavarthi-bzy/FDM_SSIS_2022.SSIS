﻿/*====================================================================================================
Is:		dim.Mergedim.MergeAccountingPeriod
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE dim.usp_MergeAccountingPeriod
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			UPDATE	dim
			SET		dim.AccountingPeriodName = stg.AccountingPeriodName,
					dim.AccountingYear = stg.AccountingYear,
					dim.AccountingYearName = stg.AccountingYearName,
					dim.AccountingMonth = stg.AccountingMonth,
					dim.AccountingMonthName = stg.AccountingMonthName
			FROM	stg.dim_AccountingPeriod stg	
			JOIN	dim.AccountingPeriod dim	ON	dim.[BK_AccountingPeriod] = stg.[BK_AccountingPeriod]			WHERE	dim.AccountingPeriodName <> stg.AccountingPeriodName
				OR	dim.AccountingYear <> stg.AccountingYear
				OR	dim.AccountingYearName <> stg.AccountingYearName
				OR	dim.AccountingMonth <> stg.AccountingMonth
				OR	dim.AccountingMonthName <> stg.AccountingMonthName
				OR	CAST(IIF(dim.AccountingPeriodName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.AccountingPeriodName IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.AccountingYear IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.AccountingYear IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.AccountingYearName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.AccountingYearName IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.AccountingMonth IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.AccountingMonth IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.AccountingMonthName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.AccountingMonthName IS NULL, 0, 1) AS BIT) = 1 

			--Create new records
			INSERT		dim.AccountingPeriod WITH (TABLOCK) ([BK_AccountingPeriod], AccountingPeriodName, AccountingYear, AccountingYearName, AccountingMonth, AccountingMonthName)
			SELECT		stg.[BK_AccountingPeriod], 
						stg.AccountingPeriodName, 
						stg.AccountingYear, 
						stg.AccountingYearName, 
						stg.AccountingMonth, 
						stg.AccountingMonthName
			FROM		stg.dim_AccountingPeriod stg	
			LEFT JOIN	dim.AccountingPeriod dim	ON	dim.[BK_AccountingPeriod] = stg.[BK_AccountingPeriod]
			WHERE		dim.[BK_AccountingPeriod] IS NULL
					OR	dim.AccountingPeriodName <> stg.AccountingPeriodName
					OR	dim.AccountingYear <> stg.AccountingYear
					OR	dim.AccountingYearName <> stg.AccountingYearName
					OR	dim.AccountingMonth <> stg.AccountingMonth
					OR	dim.AccountingMonthName <> stg.AccountingMonthName
					OR	CAST(IIF(dim.AccountingPeriodName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.AccountingPeriodName IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.AccountingYear IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.AccountingYear IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.AccountingYearName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.AccountingYearName IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.AccountingMonth IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.AccountingMonth IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.AccountingMonthName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.AccountingMonthName IS NULL, 0, 1) AS BIT) = 1 
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END