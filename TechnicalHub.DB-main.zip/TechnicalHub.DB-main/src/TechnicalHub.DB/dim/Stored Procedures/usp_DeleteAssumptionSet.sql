﻿
CREATE PROCEDURE [dim].[usp_DeleteAssumptionSet] @AssumptionDataSetID int
AS
BEGIN
	Delete From fct.All_WB_Committed Where Pk_AssumptionDatasetNameId =  @AssumptionDataSetID
	Delete From dim.AssumptionDatasets Where Pk_AssumptionDatasetNameId =@AssumptionDataSetID
END