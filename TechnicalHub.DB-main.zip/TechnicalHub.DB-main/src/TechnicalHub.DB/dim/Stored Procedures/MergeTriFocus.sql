﻿/*====================================================================================================
Is:		dim.Mergedim.MergeTriFocus
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE dim.usp_MergeTriFocus
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			UPDATE	dim
			SET		dim.TriFocusName = stg.TriFocusName,
					dim.TriFocusLevel1 = stg.TriFocusLevel1,
					dim.TriFocusLevel2 = stg.TriFocusLevel2,
					dim.TriFocusLevel3 = stg.TriFocusLevel3
			FROM	stg.dim_TriFocus stg	
			JOIN	dim.TriFocus dim	ON	dim.[BK_TriFocus] = stg.[BK_TriFocus]			WHERE	dim.TriFocusName <> stg.TriFocusName
				OR	dim.TriFocusLevel1 <> stg.TriFocusLevel1
				OR	dim.TriFocusLevel2 <> stg.TriFocusLevel2
				OR	dim.TriFocusLevel3 <> stg.TriFocusLevel3
				OR	CAST(IIF(dim.TriFocusName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.TriFocusName IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.TriFocusLevel1 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.TriFocusLevel1 IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.TriFocusLevel2 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.TriFocusLevel2 IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.TriFocusLevel3 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.TriFocusLevel3 IS NULL, 0, 1) AS BIT) = 1 

			--Create new records
			INSERT		dim.TriFocus WITH (TABLOCK) ([BK_TriFocus], TriFocusName, TriFocusLevel1, TriFocusLevel2, TriFocusLevel3)
			SELECT		stg.[BK_TriFocus], 
						stg.TriFocusName, 
						stg.TriFocusLevel1, 
						stg.TriFocusLevel2, 
						stg.TriFocusLevel3
			FROM		stg.dim_TriFocus stg	
			LEFT JOIN	dim.TriFocus dim	ON	dim.[BK_TriFocus] = stg.[BK_TriFocus]
			WHERE		dim.[BK_TriFocus] IS NULL
					OR	dim.TriFocusName <> stg.TriFocusName
					OR	dim.TriFocusLevel1 <> stg.TriFocusLevel1
					OR	dim.TriFocusLevel2 <> stg.TriFocusLevel2
					OR	dim.TriFocusLevel3 <> stg.TriFocusLevel3
					OR	CAST(IIF(dim.TriFocusName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.TriFocusName IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.TriFocusLevel1 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.TriFocusLevel1 IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.TriFocusLevel2 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.TriFocusLevel2 IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.TriFocusLevel3 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.TriFocusLevel3 IS NULL, 0, 1) AS BIT) = 1 
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END