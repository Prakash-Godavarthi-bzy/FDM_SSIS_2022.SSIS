SELECT TOP 100 * FROM FDM_PROCESS.Admin.RunProcessLog ORDER BY 1 DESC
SELECT TOP 100 * FROM FDM_PROCESS.Admin.RunProcessLog WHERE EndTime IS NULL ORDER BY 1 DESC
SELECT TOP 100 * FROM FDM_PROCESS.Admin.RunProcessLog WHERE Module LIKE '%Overse%' ORDER BY 1 DESC
SELECT TOP 100 * FROM FDM_PROCESS.Admin.RunProcessLog WHERE Module = 'Expenses 2022 A0-A3 test' ORDER BY 1 DESC
SELECT TOP 100 * FROM FDM_PROCESS.Admin.RunProcessLog WHERE Module = 'Expenses 2022 A0-A3 v2' ORDER BY 1 DESC
SELECT TOP 100 * FROM FDM_PROCESS.Admin.RunProcessLog WHERE Module = 'Expenses 2022 A0-A3 V3' ORDER BY 1 DESC
SELECT TOP 100 * FROM FDM_PROCESS.Admin.RunProcessLog WHERE Module = 'Expenses 2022 A0-A3 v4' ORDER BY 1 DESC
SELECT TOP 100 * FROM FDM_PROCESS.Admin.RunProcessLog WHERE Module LIKE 'prm%' ORDER BY 1 DESC
SELECT TOP 100 *,DATEDIFF(HH,StartTime,EndTime) FROM FDM_PROCESS.Admin.RunProcessLog WHERE fk_RunProcessConfig IN (3,13,14) AND  Module = 'Expenses 2022 A0-A3 Sys' ORDER BY 1
SELECT TOP 100 * FROM FDM_PROCESS.Admin.RunProcessLog WHERE fk_RunProcessConfig IN (13,14) AND Module LIKE '%Expenses 2022 A0-A3 V%' ORDER BY 1 DESC
	SELECT * FROM dbo.AllocationEngineLog (NOLOCK) WHERE BatchID = 545394 order by 2
	SELECT * FROM FDM_PROCESS

	SELECT * FROM [dbo].[DimFXRate]
	SELECT * INTO staging_agresso.dbo.FactFXRate FROM [dbo].[FactFXRate] -- 348118
	SELECT * FROM [dbo].[FactFXRate] WHERE fk_AccountingPeriod = 202209 -- 348118
	--DELETE FROM [dbo].[FactFXRate]
	--SP_DEPENDS '[FactFXRate]'

	SELECT SUM(cur_amount) 
	 FROM dbo.Vw_FactFDMExternal
	 WHERE fk_AccountingPeriod<= 202209 
	   AND fk_YOA = 2022
	   AND fk_Entity = 153 
	   AND fk_Account = 1152102

	   SELECT SUM(cur_amount) 
	 FROM dbo.Vw_FactFDMExternal
	 WHERE fk_AccountingPeriod<= 202209 
	   AND fk_YOA = 2022
	   AND fk_Entity = 153


	   SELECT * 
	 FROM dbo.Vw_FactFDMExternal
	 WHERE fk_AccountingPeriod<= 202209 
	   AND fk_YOA = 2022
	   AND fk_Entity = 153

	   SELECT * FROM [staging_agresso].dbo.[StageBIDACLRClaims]

	SELECT TOP 100 * FROM FDM_PROCESS.Admin.RunProcessLog WHERE Module = 'Expenses 2022 A0-A3 test' ORDER BY 1 DESC

	--DROP TABLE staging_agresso.dbo.FactFXRate

	--20220919_101819_TUMMS_EXPENSES 2022 A0-A3 V2_202204_ACTUAL_ID545394.XLSX

	SELECT AllocationCode,COUNT(1) 
	  FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) 
	 WHERE AllocationGroup = 'Expenses 2022 A0-A3 test'
	   --AND AllocationCode = 'A1'
	   GROUP BY AllocationCode


	   SELECT * FROM dbo.FactFDMExternal_Current WHERE RunProcessLogID = 543702
	   
	   SELECT fk_AccountingPeriod ,RunProcessLogID,COUNT(1)
	     FROM dbo.vw_FactFDMExternal A
	    INNER JOIN dbo.DimAccount DA
		   ON A.fk_Account = DA.pk_Account
	    WHERE DA.AccountCode = 'PF00001' --AND RunProcessLogID = 533483-- 543702
		 GROUP BY fk_AccountingPeriod ,RunProcessLogID
		 ORDER By RunProcessLogID DESC

		 SELECT * 
	     FROM dbo.FactFDMExternal_Current A
	    INNER JOIN dbo.DimAccount DA
		   ON A.fk_Account = DA.pk_Account
	    WHERE DA.AccountCode = 'PF00001' AND RunProcessLogID = 543702

	  -- SELECT * FROM 

	   SELECT isnull(MAX(fk_accountingperiod),190001) PFMaxPeriod from dbo.vw_FactFDMExternal f
		INNER JOIN DimAccount da on f.fk_Account = da.pk_Account
		WHERE da.AccountCode = 'PF00001'
		--543740
	   --UPDATE FDM_PROCESS.Admin.RunProcessLog 
	   --   SET EndTime = GETDATE()
		  --  , [Status] = 'Failed'
	   -- WHERE Module = 'Expenses 2022 A0-A3 v4'

--2022-08-08 13:52:07.813

--Expenses 2022 A0-A3 Sys

	/*****************************************************************************************/
	  SELECT AllocationGroup,BatchID,AllocationCode,ChangeType,COUNT(1)
			 , cast(SUM(AllocationPercent) as decimal(18,4))
	    FROM dbo.DimAllocationRules
	   WHERE BatchID IN (545384,545385,545386,545387,545389,545390)
	   --(544432,544431,544430,544428,544427,544426)
		--(543850,543849,543848,543847,543845,543844)
	   --(543682,543683,543684,543685,543686,543687)
		--(542699,542698,542697,542696,542695,542694)
	     --AND AllocationCode = 'A1'
	   GROUP BY AllocationGroup,BatchID,AllocationCode,ChangeType
	   ORDER BY AllocationCode,ChangeType

		SELECT AllocationGroup,BatchID,AllocationCode,ChangeType,COUNT(1)
		 , cast(SUM(AllocationPercent) as decimal(18,4))
	    FROM dbo.DimAllocationRules
	   WHERE BatchID IN (545384,545385,545386,545387,545389,545390)
	   --(544432,544431,544430,544428,544427,544426)
		--(543850,543849,543848,543847,543845,543844)
	   --(543682,543683,543684,543685,543686,543687)
		--(542699,542698,542697,542696,542695,542694)
	     AND ChangeType != 'Deleted'
		 AND AllocationPercent > 0
		 --AND AllocationCode = 'A1'
	   GROUP BY AllocationGroup,BatchID,AllocationCode,ChangeType
	   ORDER BY AllocationGroup,AllocationCode,ChangeType

		SELECT AllocationGroup,BatchID,AllocationCode,ChangeType,COUNT(1)
		 , cast(SUM(AllocationPercent) as decimal(18,4))
	    FROM dbo.DimAllocationRules
	   WHERE BatchID IN (545384,545385,545386,545387,545389,545390)
	   --(544432,544431,544430,544428,544427,544426)
		--(543850,543849,543848,543847,543845,543844)
	   --(543682,543683,543684,543685,543686,543687)
		--(542699,542698,542697,542696,542695,542694)
	     AND ChangeType != 'Deleted'
		 AND AllocationPercent < 0
		 --AND AllocationCode = 'A1'
	   GROUP BY AllocationGroup,BatchID,AllocationCode,ChangeType
	   ORDER BY AllocationGroup,AllocationCode,ChangeType	

	   --------------------------------------------------
	   SELECT DISTINCT [AllocationGroup],
		[AllocationCode],[dbo].[usf_getTriggerChangedStatus] (AllocationGroup,AllocationCode) 
	  FROM [staging_agresso].[dbo].[AllocationsToRun] A   
	  ORDER BY AllocationGroup,AllocationCode

	--SELECT DISTINCT A.[AllocationGroup],
	--	A.[AllocationCode],B.TriggersStatus 
	--  FROM [staging_agresso].[dbo].[AllocationsToRun] A   
	--  CROSS APPLY [dbo].[usf_getTriggerChangedStatusTVF] (A.AllocationGroup,A.AllocationCode) B
	--  ORDER BY A.AllocationGroup,A.AllocationCode

	  SELECT * FROM [staging_agresso].[dbo].[AllocationsToRun] 
	   ---------------------------------------------------
	   SELECT * FROM dbo.DimAllocationRules WHERE AllocationGroup= 'Expenses 2022 A0-A3 Sys' AND IsCurrent = 1 
	   SELECT * FROM dbo.DimAllocationRules WHERE AllocationGroup= 'Expenses 2022 A0-A3 V3' AND ChangeType LIKE 'Percent%'

	   DECLARE @CurrentVerison AS INT
		,@newVersion AS INT
		,@TriggersChanged AS INT = 0
		,@AllocationGroup VARCHAR(255) = 'Expenses 2022 A0-A3 test'
		, @AllocationCode VARCHAR(255) = ''

		--SELECT	@CurrentVerison = MAX(b.AllocationGroupVersionCode)--MAX(AllocationGroupCodeVersion)
		-- FROM	BriExpensesTransactionDetailsV4 b
		-- JOIN	DimAllocationRules a 
		-- --ON		a.PK_AllocationRules = b.FK_AllocationRules
		-- ON		a.PK_Alt_AllocationRules = b.FK_AllocationRules
		-- WHERE	a.AllocationGroup = @AllocationGroup
		-- AND	a.AllocationCode = @AllocationCode
		 


		-- SELECT	@newVersion =MAX(a.AllocationGroupCodeVersion)
		-- FROM	DimAllocationRules a 
		-- WHERE	a.AllocationGroup = @AllocationGroup
		-- AND	a.AllocationCode = @AllocationCode
		-- --AND AllocationGroupCodeSubVersion = 1

		-- SELECT @CurrentVerison,@newVersion

		-- IF( @newVersion<>ISNULL(@CurrentVerison,0))
		--	BEGIN
		--		SET @TriggersChanged = 1
		--	END
		--SELECT @TriggersChanged,@CurrentVerison,@newVersion

	IF(@AllocationCode ='')
		BEGIN
		 SELECT	@CurrentVerison = MAX(AllocationGroupCodeVersion)
		 FROM	BriExpensesTransactionDetailsV4 b
		 JOIN	DimAllocationRules a 
		 --ON		a.PK_AllocationRules = b.FK_AllocationRules
		 ON		a.PK_Alt_AllocationRules = b.FK_AllocationRules
		 WHERE	a.AllocationGroup = @AllocationGroup


		 SELECT	@newVersion =MAX(a.AllocationGroupCodeVersion)
		 FROM	DimAllocationRules a 
		 WHERE	a.AllocationGroup = @AllocationGroup

		 IF( @newVersion<>ISNULL(@CurrentVerison,0))
			BEGIN
				SET @TriggersChanged = 1
			END
		END
	ELSE IF (@AllocationCode <>'')
		BEGIN
		 SELECT	@CurrentVerison = MAX(AllocationGroupCodeVersion)
		 FROM	BriExpensesTransactionDetailsV4 b
		 JOIN	DimAllocationRules a 
		 --ON		a.PK_AllocationRules = b.FK_AllocationRules
		 ON		a.PK_Alt_AllocationRules = b.FK_AllocationRules
		 WHERE	a.AllocationGroup = @AllocationGroup
		 AND	a.AllocationCode = @AllocationCode


		 SELECT	@newVersion =MAX(a.AllocationGroupCodeVersion)
		 FROM	DimAllocationRules a 
		 WHERE	a.AllocationGroup = @AllocationGroup
		 AND	a.AllocationCode = @AllocationCode

			 IF( @newVersion<>ISNULL(@CurrentVerison,0))
			 BEGIN
				SET @TriggersChanged = 1
			END
		END
	SELECT @TriggersChanged,@CurrentVerison,@newVersion

		----------------------------------------------------------

		SELECT	AllocationCode,MAX(a.AllocationGroupCodeVersion)
		 FROM	DimAllocationRules a 
		 WHERE	a.AllocationGroup = 'Expenses 2022 A0-A3 v4'
		 GROUP BY AllocationCode
		 ORDER BY AllocationGroupCodeVersion DESC

		SELECT AllocationCode,COUNT(1) BriCount 
		  FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) 
		 WHERE AllocationGroup = 'Expenses 2022 A0-A3 v4'
		 GROUP BY AllocationCode
	/******************************************************************************************/
	SELECT * FROM dbo.FACTAllocationsV1_Current WHERE BatchID = 524700
	   AND CombinationID = 18832740
	
	SELECT * FROM dbo.FACTAllocationsV1_Current WHERE BatchID = 534922
	   AND CombinationID = 18832740 --AND fk_TriFocus = 342
	   AND fk_Account = 51305 

	SELECT * FROM dbo.FACTAllocationsV1_Current WHERE BatchID = 534922
	   AND CombinationID = 18832740 --AND fk_TriFocus = 342
	   AND fk_Account = 51305 


	   SELECT * FROM dbo.DimAllocationRules WHERE PK_Alt_AllocationRules = 4536763
	   SELECT * FROM dbo.BriExpensesTransactionDetailsV4_Stage

	   SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) 
		 WHERE AllocationGroup = 'Expenses 2022 A0-A3 v3'
		   AND AllocationCode = 'A1'
		   AND CombinationID = 18832740

		SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) 
		 WHERE AllocationGroup = 'Expenses 2022 A0-A3 v3'
		   AND AllocationCode = 'A1'
		   AND FK_AllocationRules = -4536763--4562594 --4536763
		   AND CombinationID = 18832740 -- 4536763
		   
		SELECT SUM(AllocationPercent) FROM BriExpensesTransactionDetailsV4 WHERE FK_AllocationRules = 4562594   

		SELECT * FROM dbo.DimAllocationCombinations WHERE CombinationID = 18832740
		SELECT *  FROM dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE CombinationID = 18832740 AND AllocationGroup = 'Expenses 2022 A0-A3 Sys' ORDER BY TriFocusDest --46
		SELECT * INTO #tempV3 FROM dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE CombinationID = 18832740 AND AllocationGroup = 'Expenses 2022 A0-A3 V3' ORDER BY TriFocusDest --46
		SELECT * INTO #tempV4 FROM dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE CombinationID = 18832740 AND AllocationGroup = 'Expenses 2022 A0-A3 V4' ORDER BY TriFocusDest -- 63
--		18832740
--18832742
--18832743

	SELECT * FROM #tempV3 ORDER BY TriFocusDest
	SELECT * FROM #tempV4 ORDER BY TriFocusDest 

	SELECT A.* FROM #tempV4 A
	  LEFT JOIN  #tempV3 B
	    ON A.TriFocusDest = B.TriFocusDest
     WHERE B.TriFocusDest IS NULL

	 SELECT B.* FROM #tempV4 A
	  INNER JOIN  #tempV3 B
	    ON A.TriFocusDest = B.TriFocusDest
     --WHERE B.TriFocusDest IS NULL
	
		
		SELECT * FROM dbo.DimAllocationRules 
		 WHERE AllocationGroup = 'Expenses 2022 A0-A3 V3' 
		  AND IsCurrent = 1
		  AND PK_Alt_AllocationRules = 4570955
		  --AND PK_Alt_AllocationRules IN (SELECT FK_AllocationRules FROM dbo.BriExpensesTransactionDetailsV4 WHERE CombinationID = 18832740)
		
		SELECT * FROM dbo.DimAllocationRules 
		 WHERE AllocationGroup = 'Expenses 2022 A0-A3 V3' 
		  AND IsCurrent = 1 AND AllocationCode = 'A1'
		  AND EntityFrom = 'USBUSA' AND EntityTo = 'USBUSA' AND EntityDest = 'USBUSA'
		  AND AccountDest = 51305

		SELECT CombinationID,SUM(AllocationPercent) 
		  FROM dbo.BriExpensesTransactionDetailsV4 (NOLOCK)
		 WHERE AllocationGroup = 'Expenses 2022 A0-A3 V3'
		   AND AllocationCode = 'A1'
		GROUP BY CombinationID
		HAVING SUM(AllocationPercent) > 0.1 OR SUM(AllocationPercent) <-0.1
		ORDER BY CombinationID

		SELECT CombinationID,SUM(AllocationPercent) 
		  FROM dbo.BriExpensesTransactionDetailsV4 (NOLOCK)
		 WHERE AllocationGroup = 'Expenses 2022 A0-A3 V4'
		   AND AllocationCode = 'A1'
		GROUP BY CombinationID
		HAVING SUM(AllocationPercent) > 0.1 OR SUM(AllocationPercent) <-0.1
		ORDER BY CombinationID

	--84.52100000
	--SELECT * FROM
	SELECT * FROM dbo.DimTransactionDetailsV1_History WHERE CombinationID = 18832740
	SELECT * FROM dbo.FactFDM WHERE pk_FactFDM IN (SELECT pk_FactFDM FROM dbo.DimTransactionDetailsV1_History WHERE CombinationID = 18832740
	)

	SELECT * FROM dbo.DimTrifocus --WHERE TrifocusName = 'Unknown'
	SELECT DP.ProcessCode,DE.EntityCode,FACT.fk_YOA, FACT.currency
		--,FK_AllocationRules
			, cast(SUM(FACT.cur_amount) as decimal(18,4))--, FACT.*
			, cast(SUM(FACT.value) as decimal(18,4))
			, cast(SUM(FACT.value_2) as decimal(18,4))
	     FROM dbo.FACTAllocationsV1_Current FACT
	    INNER JOIN dbo.DimProcess DP
		   ON FACT.fk_Process = DP.pk_Process
		INNER JOIN dbo.DimEntity DE
		   ON FACT.fk_Entity = DE.pk_Entity		
	    WHERE BatchID = 534922--399729--399060--399000--398973--398957--398853--393382
		  --AND DP.ProcessCode = 'A0.3'
		  --AND Fact.AllocationCOde = 'I1'
		 GROUP BY DP.ProcessCode,DE.EntityCode,FACT.fk_YOA
			 , FACT.currency --,FK_AllocationRules
		 HAVING (cast(SUM(FACT.cur_amount) as decimal(18,4)) < -1 OR cast(SUM(FACT.cur_amount) as decimal(18,4)) > 1)
		 ORDER BY DP.ProcessCode,DE.EntityCode, FACT.currency--,FK_AllocationRules

		 SELECT * FROM FDM_DB.dbo.OverseasandASLConfig WHERE Syndicate = 3623 AND GL = 75668

		 ---------------------------------------------------------------------
		 SELECT * from FDM_DB.dbo.FactFDMExternal_Current where currency='HKD'
			and fk_Account=75668
			and fk_AccountingPeriod=202209


			SELECT * from FDM_DB.dbo.FactFDMExternal_History where currency='HKD'
			and fk_Account=75668
			and fk_AccountingPeriod=202209


			SELECT * FROM FDM_DB.dbo.OverseasandASLConfig WHERE Syndicate = 3623 AND GL = 75668