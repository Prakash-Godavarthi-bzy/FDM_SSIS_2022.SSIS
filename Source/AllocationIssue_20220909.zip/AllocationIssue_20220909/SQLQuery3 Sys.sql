--SELECT * FROM staging_agresso.FDMOutput.FDMQueries WHERE FDMProcess = 'BID Earnings' ORDER BY FDMSubProcess
--SELECT * FROM SSISDB.[internal].[object_parameters] WHERE project_id = 2 and parameter_name like '%mds%' ORDER BY project_version_lsn DESC
	SELECT TOP 100 * FROM FDM_PROCESS.Admin.RunProcessLog WHERE fk_RunProcessConfig IN (13,14) AND Module LIKE '%Expenses 2022 A0-A3%' ORDER BY 1 DESC
	SELECT TOP 100 * FROM FDM_PROCESS.Admin.RunProcessLog ORDER BY 1 DESC
	SELECT * FROM dbo.AllocationEngineLog WHERE BatchID = 540540
	
	SELECT DP.ProcessCode,DE.EntityCode,FACT.fk_YOA, FACT.currency
		--,FK_AllocationRules
			, cast(SUM(FACT.cur_amount) as decimal(18,4))--, FACT.*
			, cast(SUM(FACT.value) as decimal(18,4))
			, cast(SUM(FACT.value_2) as decimal(18,4))
	     FROM dbo.FACTAllocationsV1_Current FACT
	    INNER JOIN dbo.DimProcess DP
		   ON FACT.fk_Process = DP.pk_Process
		INNER JOIN dbo.DimEntity DE
		   ON FACT.fk_Entity = DE.pk_Entity		
	    WHERE BatchID = 540522--399729--399060--399000--398973--398957--398853--393382
		  --AND DP.ProcessCode = 'A0.3'
		  --AND Fact.AllocationCOde = 'I1'
		 GROUP BY DP.ProcessCode,DE.EntityCode,FACT.fk_YOA
			 , FACT.currency --,FK_AllocationRules
		 HAVING (cast(SUM(FACT.cur_amount) as decimal(18,4)) < -1 OR cast(SUM(FACT.cur_amount) as decimal(18,4)) > 1)
		 ORDER BY DP.ProcessCode,DE.EntityCode, FACT.currency--,FK_AllocationRules
	
	--SELECT * FROM FDM_PROCESS.Admin.RunProcessLog 
	--WHERE Year(CreatedDate) = 2022 
	--AND MONTH(CreatedDate) = 6 
	--AND fk_RunProcessConfig NOT IN (-1,14,42)	  
	--ORDER BY RunProcessLogID

--	SELECT [FDMTrifocusCode] AS [TRIFOCUSCode]
--      ,UPPER(RTRIM(LTRIM([SourceSystemTrifocus]))) AS [TRIFOCUSNAME]
--  FROM FDM_DB.[dbo].[TrifocusMapping]
--  WHERE SourceSystem = 'Eurobase'

SELECT * FROM staging_agresso.[dbo].[SideCarAgreement] ORDER BY YOA DESC

--SELECT * FROM FDM_PROCESS.Admin.RunProcessConfig
--SELECT * FROM FDM_PROCESS.Admin.RunProcessConfig WHERE ModuleName LIKE '%BIEPI%' OR FolderName LIKE '%BIEPI%'
--SELECT * FROM FDM_PROCESS.Admin.RunProcessConfig WHERE ModuleName LIKE '%RI SPEND%' OR FolderName LIKE '%RI SPEND%'
--SELECT * FROM FDM_PROCESS.Admin.RunProcessConfig WHERE ModuleName LIKE '%EIC Investment Allocations%' OR FolderName LIKE '%EIC Investment Allocations%'
--SELECT * FROM FDM_PROCESS.Admin.RunProcessConfig WHERE ModuleName LIKE '%Eurobase EPI Adjustments%' OR FolderName LIKE '%Eurobase EPI Adjustments%'
--SELECT * FROM FDM_PROCESS.Admin.RunProcessConfig WHERE ModuleName LIKE '%EurobaseEPI%' OR FolderName LIKE '%EurobaseEPI%'
--SELECT * FROM FDM_PROCESS.Admin.RunProcessConfig WHERE ModuleName LIKE '%US Premium Tax Rates%' OR FolderName LIKE '%US Premium Tax Rates%'
--SELECT * FROM FDM_PROCESS.Admin.RunProcessConfig WHERE ModuleName LIKE '%TDMUS%' OR FolderName LIKE '%TDMUS%'
--SELECT * FROM FDM_PROCESS.Admin.RunProcessConfig WHERE ModuleName LIKE '%TDMBIDAC%' OR FolderName LIKE '%TDMBIDAC%'
--SELECT * FROM FDM_PROCESS.Admin.RunProcessConfig WHERE ModuleName LIKE '%PFT%' OR FolderName LIKE '%PFT%'
--SELECT * FROM FDM_PROCESS.Admin.RunProcessConfig WHERE ModuleName LIKE '%EurobaseEPI%' OR FolderName LIKE '%EurobaseEPI%'
--SELECT * FROM FDM_PROCESS.Admin.RunProcessConfig WHERE ModuleName LIKE '%EurobaseEPI%' OR FolderName LIKE '%EurobaseEPI%'


	SELECT * FROM FDM_DB.dbo.FactFDMExternal_Current WHERE RunProcessLogID = 526823
	SELECT * FROM FDM_DB.dbo.FactFDMExternal_History WHERE RunProcessLogID = 526823 AND fk_Process != 135 -- 3336
	--fk_Process - 135,136
	-- 235,236
	SELECT * FROM dbo.DimProcess

	UPDATE FDM_DB.dbo.FactFDMExternal_History 
	   SET fk_Process = 235
	 WHERE RunProcessLogID = 526823 
	   AND fk_Process = 135 -- 3328

	UPDATE FDM_DB.dbo.FactFDMExternal_History 
	   SET fk_Process = 236
	 WHERE RunProcessLogID = 526823 
	   AND fk_Process = 136 -- 8

	   SELECT     fk_Account, fk_AccountingPeriod, fk_BusinessPlan, fk_ClaimExposure, fk_DataStage, fk_Entity, fk_Expense, fk_Holding, fk_LloydsClassifications, fk_Office,
											fk_PolicySection, fk_Process, fk_Product, fk_Project, fk_RIPolicy,1 AS fk_Location, fk_Scenario, fk_SourceSystem, fk_TriFocus, fk_YOA, [Value], pk_FactFDMExternal as pk_FactFDM, value_3, value_2,
											value_1, cur_amount, currency, fk_User, fk_client,[tax_code]
											,[tax_system], Dim2,[bk_TransactionID],[fk_special],[fk_classofbusiness], - 1 AS fk_AllocationRules, - 1 AS CombinationID, fk_DimEarnings,fk_PolicySectionv2 , fk_TargetEntity, fk_TargetPeriod ,-1 AS pk_ARAP
											FROM         FactFDMExternal_Current where fk_Account IN (1000012,
											1000013,
											1000014,
											1000015,
											1000016,
											1000017)


	UPDATE FDM_DB.dbo.FactFDMExternal_History 
	   SET fk_Process = 135
	 WHERE RunProcessLogID = 526823 
	   AND fk_Process = 235 -- 3328

	UPDATE FDM_DB.dbo.FactFDMExternal_History 
	   SET fk_Process = 136
	 WHERE RunProcessLogID = 526823 
	   AND fk_Process = 236 -- 8