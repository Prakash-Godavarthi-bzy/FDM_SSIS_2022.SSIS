		--Bridge - yes
		SELECT * FROM dbo.DimAllocationRules 
		 WHERE AllocationGroup = 'Expenses 2023 A0-A3 v3' 
		  AND IsCurrent = 1
		  AND PK_Alt_AllocationRules = 4840590 

		SELECT * FROM dbo.DimAllocationRules WHERE AllocationGroup = 'Expenses 2023 A0-A3 v3' AND AllocationCode = 'A1'
	       AND AccountFrom = 50000 AND AccountTo = 51699 AND AccountDest = '51305'
		   AND TrifocusFrom = 'Z150' AND TrifocusTo = 'Z150' AND TrifocusDest = '668'--'920'--'704'
		   AND EntityFrom = 'USBUSA' AND EntityTo = 'USBUSA' AND EntityDest = 'USBUSA'
		   ORDER BY AllocationGroupCodeVersion

		SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE FK_AllocationRules = 4840590 AND CombinationID = 18832740
	
	---------------------------------------------------------------------------
		--Bridge - NO
		SELECT * FROM dbo.DimAllocationRules 
		 WHERE AllocationGroup = 'Expenses 2022 A0-A3 V2' 
		  AND IsCurrent = 1
		  AND PK_Alt_AllocationRules = 4847329 

		SELECT * FROM dbo.DimAllocationRules WHERE AllocationGroup = 'Expenses 2023 A0-A3 V3' --AND AllocationCode = 'A1'
	       AND AccountFrom = 50930 AND AccountTo = 51699 AND AccountDest = '51305'
		   AND TrifocusFrom = 'Z150' AND TrifocusTo = 'Z150' AND TrifocusDest = '920'--'704'
		   AND EntityFrom = 'USBUSA' AND EntityTo = 'USBUSA' AND EntityDest = 'USBUSA'
		   ORDER BY AllocationGroupCodeVersion

		SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE FK_AllocationRules = 4847329 AND CombinationID = 20289641
		SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE CombinationID = 20289641 AND AllocationGroup = 'Expenses 2023 A0-A3 v3' AND AllocationCode = 'A1'
		SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE CombinationID = 20289568 AND AllocationGroup = 'Expenses 2023 A0-A3 v3'
		
		SELECT * FROM FDM_DB.[dbo].[DimAllocationCombinations] (NOLOCK) WHERE CombinationID = 20289641
		SELECT * FROM dbo.DimTransactionDetailsV1_Current WHERE CombinationID = 20289641
		SELECT * FROM dbo.DimTransactionDetailsV1_Current WHERE CombinationID = 20289568--20289641
		--SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE FK_AllocationRules = 4455362 AND CombinationID = 18832740
	
	--Bridge - NO
		SELECT * FROM dbo.DimAllocationRules 
		 WHERE AllocationGroup = 'Expenses 2023 A0-A3 v3' 
		  AND IsCurrent = 1
		  AND PK_Alt_AllocationRules = 4847330 

		SELECT * FROM dbo.DimAllocationRules WHERE AllocationGroup = 'Expenses 2023 A0-A3 v3' --AND AllocationCode = 'A1'
	       AND AccountFrom = 50000 AND AccountTo = 51699 AND AccountDest = '51305'
		   AND TrifocusFrom = 'Z150' AND TrifocusTo = 'Z150' AND TrifocusDest = ''--'704'
		   AND EntityFrom = 'USBUSA' AND EntityTo = 'USBUSA' AND EntityDest = 'USBUSA'
		   ORDER BY AllocationGroupCodeVersion

		SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE FK_AllocationRules = 4847330 AND CombinationID = 18832740
		SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE FK_AllocationRules = 4460530 AND CombinationID = 18832740

		
	/********************************************************************/
		SELECT AllocationCode,CombinationID,SUM(AllocationPercent) 
		  FROM dbo.BriExpensesTransactionDetailsV4 (NOLOCK)
		 WHERE AllocationGroup = 'Expenses 2023 A0-A3 v3'
		   --AND AllocationCode = 'A1'
		GROUP BY AllocationCode,CombinationID
		HAVING SUM(AllocationPercent) > 0.1 OR SUM(AllocationPercent) <-0.1
		ORDER BY AllocationCode,CombinationID


		SELECT AllocationCode,max(AllocationGroupCodeVersion),MAX(AllocationGroupCodeSubVersion) FROM dbo.DimAllocationRules 
		 WHERE AllocationGroup = 'Expenses 2022 A0-A3' AND IsCurrent =1
		 GROUP BY AllocationCode
		 ORDER BY AllocationCode

		SELECT TOP 100 * FROM FDM_PROCESS.Admin.RunProcessLog 
		 WHERE fk_RunProcessConfig IN (13,14) 
		   AND Module LIKE '%Expenses 2022 A0-A3%' 

		   ---------------------------------------------------------------
		   SELECT * FROM dbo.DimAllocationRules 
		 WHERE AllocationGroup = 'Expenses 2022 A0-A3 V2' 
		  AND IsCurrent = 1
		  AND PK_Alt_AllocationRules = 4847329 

		SELECT * FROM dbo.DimAllocationRules WHERE AllocationGroup = 'Expenses 2022 A0-A3 V2' AND AllocationCode = 'A1' AND IsCurrent = 1
	       AND AccountFrom = 50000 AND AccountTo = 51699 AND AccountDest = '51314'
		   AND TrifocusFrom = 'Z110' AND TrifocusTo = 'Z110' --AND TrifocusDest = '949'--'704'
		   AND EntityFrom = 'BBML' AND EntityTo = 'BBML' AND EntityDest = 'BBML'
		   ORDER BY TrifocusDest

		SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE CombinationID = 18682901 
		  AND AllocationGroup = 'Expenses 2022 A0-A3 V2' AND AllocationCode = 'A1'
		  ORDER BY TrifocusDest

		SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE FK_AllocationRules = 3969386 AND CombinationID = 18682901
		SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE FK_AllocationRules = 3974504 AND CombinationID = 18682901
		SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE CombinationID = 18682901 AND AllocationGroup = 'Expenses 2022 A0-A3 V2'
		
		--SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE FK_AllocationRules = 4455362 AND CombinationID = 18832740
	
		SELECT * FROM dbo.DimAllocationRules WHERE AllocationGroup = 'Expenses 2022 A0-A3 V2' AND AllocationCode = 'A1'
		   AND PK_Alt_AllocationRules IN (3989157,3989026) AND IsCurrent = 1
		   --ORDER BY 