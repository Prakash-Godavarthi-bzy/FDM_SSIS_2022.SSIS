--SELECT TOP 100 * FROM FDM_PROCESS.Admin.RunProcessLog ORDER BY 1 DESC
--SELECT TOP 100 * FROM FDM_PROCESS.Admin.RunProcessLog WHERE fk_RunProcessConfig != -1 ORDER BY 1 DESC
--SELECT TOP 100 * FROM FDM_PROCESS.Admin.RunProcessLog WHERE Module = 'Overnight' ORDER BY 5 DESC
--SELECT TOP 100 * FROM FDM_PROCESS.Admin.RunProcessLog WHERE LastInsertedAgrtid IS NOT NULL ORDER BY 1 DESC
	
	SELECT TOP 100 * FROM FDM_PROCESS.Admin.RunProcessLog WHERE Module = 'Expenses 2022 A0-A3 v4' ORDER BY 1 DESC
	SELECT TOP 100 * FROM FDM_PROCESS.Admin.RunProcessLog WHERE Module = 'Expenses 2022 A0-A3 v5' ORDER BY 1 DESC
	SELECT * FROM FDM_PROCESS.Admin.RunProcessLog WHERE fk_RunProcessConfig IN (3,13,14) AND Module = 'Expenses 2023 A0-A3 v3' ORDER BY 1 DESC

	SELECT TOP 100 * FROM FDM_PROCESS.Admin.RunProcessLog WHERE Module LIKE '%MI PFT PUBLISH%' ORDER BY 1 DESC
	SELECT [RC03FileLocation]
  FROM [CAMT].[Config]
  WHERE [ServerName]= 'UKPRDB051\UKAC01'

	SELECT * FROM FDm_DB.dbo.AllocationEngineLog WHERE BatchID = 553349

	select sum(cur_amount) from FDM_DB.dbo.VW_FACTAllocationV1_Total
	where BatchID=555454 and fk_Account=51301
	and fk_Scenario=8 and EntityDest='USBUSA' and ProcessDest='A1'
	and fk_TriFocus=317

	SELECT TOP 100 * FROM FDM_DB.dbo.vw_DimTransactionDetailsV1 WHERE pk_FactFDM IN (463329728,463329801)
	SELECT * from FDM_DB.dbo.FactFDM(nolock) where pk_FactFDM IN (463329728,463329801)
	SELECT TOP 100 * FROM FDM_DB.dbo.DimAllocationCombinations WHERE CombinationID IN (16473119,18954566)

	SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE CombinationID = 16473119
		AND AllocationGroup = 'Expenses 2022 A0-A3 V4' AND TriFocusDest = 'Z100'
	SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE CombinationID = 18954566
		AND AllocationGroup = 'Expenses 2022 A0-A3 V4' AND TriFocusDest = 'Z100'

		SELECT * FROM dbo.DimAllocationRules WHERE PK_Alt_AllocationRules = 4839445--4778721

		SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE FK_AllocationRules = 4839445--4778721
		AND AllocationGroup = 'Expenses 2022 A0-A3 V4' AND CombinationID IN (18954566,16473119)

		SELECT * FROM staging_agresso.[dbo].[PremiumForecastPremiumStage]

		select f.* INTO #temp_Prevero 
		 from FDM_DB.dbo.FactFDM(nolock) f
		join FDM_DB.dbo.DimEntity e on f.fk_Entity=e.pk_Entity
		join FDM_DB.dbo.DimTrifocus t on f.fk_TriFocus=t.pk_Trifocus
		where Description='Prevero Data Upload - F4 2022'
		and e.EntityCode='USBUSA' and t.TrifocusCode='z100'

		SELECT * FROM #temp_Prevero

	--UPDATE FDM_PROCESS.Admin.RunProcessLog
	--   SET EndTime = GETDATE()
	--     , [Status] = 'Failed'
	--	 --, LastInsertedAgrtid = 442095232
	-- WHERE RunProcessLogID = 553335
   
   SELECT * FROM FDM_DB.dbo.DimAllocationRules WHERE AllocationGroup = 'Expenses 2022 A0-A3 Dev V5' AND AccountDest  = '51301'
     AND AllocationCode = 'A1' AND EntityDest = 'USBUSA'

	 SELECT * FROM FDM_DB.dbo.DimAllocationRules WHERE PK_Alt_AllocationRules = 4689994
	 SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE FK_AllocationRules = 4689994
		AND AllocationGroup = 'Expenses 2022 A0-A3 Dev V5'
	
	SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE CombinationID = 18954566--16473119
		AND AllocationGroup = 'Expenses 2022 A0-A3 Dev V5' AND TriFocusDest = 'Z100'

	SELECT * FROM FDM_DB.dbo.DimAllocationRules WHERE AllocationGroup = 'Expenses 2022 A0-A3 V4'
	SELECT * FROM FDM_PROCESS.Admin.RunProcessLog WHERE Module = 'Expenses 2022 A0-A3 V4' ORDER BY 1 DESC

	SELECT [dbo].[usf_getTriggerChangedStatus] ('Expenses 2022 A0-A3 v4','A1')
	-----------------------------------------
		SELECT AllocationGroup,BatchID,AllocationCode,ChangeType,COUNT(1)
			 , cast(SUM(AllocationPercent) as decimal(18,4))
	    FROM dbo.DimAllocationRules
	   WHERE BatchID IN (553341,553340,553339,553338,553337,553336)
	   --(553317,553316,553315,553314,553313,553312)	   
	     --AND AllocationCode = 'A1'
	   GROUP BY AllocationGroup,BatchID,AllocationCode,ChangeType
	   ORDER BY AllocationCode,ChangeType
	   
		SELECT AllocationGroup,BatchID,AllocationCode,ChangeType,COUNT(1)
		 , cast(SUM(AllocationPercent) as decimal(18,4))
	    FROM dbo.DimAllocationRules
	   WHERE BatchID IN (553341,553340,553339,553338,553337,553336)   
	     AND ChangeType != 'Deleted'
		 AND AllocationPercent > 0
		 --AND AllocationCode = 'A1'
	   GROUP BY AllocationGroup,BatchID,AllocationCode,ChangeType
	   ORDER BY AllocationGroup,AllocationCode,ChangeType

		SELECT AllocationGroup,BatchID,AllocationCode,ChangeType,COUNT(1)
		 , cast(SUM(AllocationPercent) as decimal(18,4))
	    FROM dbo.DimAllocationRules
	   WHERE BatchID IN (553341,553340,553339,553338,553337,553336)  
	     AND ChangeType != 'Deleted'
		 AND AllocationPercent < 0
		 --AND AllocationCode = 'A1'
	   GROUP BY AllocationGroup,BatchID,AllocationCode,ChangeType
	   ORDER BY AllocationGroup,AllocationCode,ChangeType	

	   SELECT AllocationCode,CombinationID,SUM(AllocationPercent) 
		  FROM dbo.BriExpensesTransactionDetailsV4 (NOLOCK)
		 WHERE AllocationGroup = 'Expenses 2022 A0-A3 V4'
		   --AND AllocationCode = 'A1'
		GROUP BY AllocationCode,CombinationID
		HAVING SUM(AllocationPercent) > 0.1 OR SUM(AllocationPercent) <-0.1
		ORDER BY AllocationCode,CombinationID

		/********************************************************************/		

		SELECT DP.ProcessCode,DE.EntityCode,FACT.fk_YOA, FACT.currency	
			, cast(SUM(FACT.cur_amount) as decimal(18,4))--, FACT.*
			, cast(SUM(FACT.value) as decimal(18,4))
			, cast(SUM(FACT.value_2) as decimal(18,4))
	     FROM dbo.FACTAllocationsV1_Current FACT
	    INNER JOIN dbo.DimProcess DP
		   ON FACT.fk_Process = DP.pk_Process
		INNER JOIN dbo.DimEntity DE
		   ON FACT.fk_Entity = DE.pk_Entity		
	    WHERE BatchID = 620830
		 GROUP BY DP.ProcessCode,DE.EntityCode,FACT.fk_YOA
			 , FACT.currency --,FK_AllocationRules
		 HAVING (cast(SUM(FACT.cur_amount) as decimal(18,4)) < -1 OR cast(SUM(FACT.cur_amount) as decimal(18,4)) > 1)
		 ORDER BY DP.ProcessCode,DE.EntityCode, FACT.currency

	/*****************************************************************************************/

	   
	   -----------------------------------------------------

	   SELECT TOP 100 * FROM FDM_DB.dbo.vw_DimTransactionDetailsV1 WHERE pk_FactFDM IN (463329728,463329801)
	select * from FDM_DB.dbo.FactFDM(nolock) where pk_FactFDM IN (463329728,463329801)
	SELECT TOP 100 * FROM FDM_DB.dbo.DimAllocationCombinations WHERE CombinationID IN (16473119,18954566)
	SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE CombinationID = 16473119
		AND AllocationGroup = 'Expenses 2022 A0-A3 V4' AND TriFocusDest = 'Z100'
	SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE CombinationID = 18954566
		AND AllocationGroup = 'Expenses 2022 A0-A3 V4' AND TriFocusDest = 'Z100'