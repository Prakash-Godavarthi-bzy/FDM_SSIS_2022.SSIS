	SELECT TOP 100 * FROM FDM_PROCESS.Admin.RunProcessLog WHERE Module = 'Expenses 2023 A0-A3 v3' ORDER BY 1 DESC
	/********************************************************************/
		SELECT AllocationCode,CombinationID,SUM(AllocationPercent) 
		  FROM dbo.BriExpensesTransactionDetailsV4 (NOLOCK)
		 WHERE AllocationGroup = 'Expenses 2023 A0-A3 v3'
		   --AND AllocationCode = 'A1'
		GROUP BY AllocationCode,CombinationID
		HAVING SUM(AllocationPercent) > 0.1 OR SUM(AllocationPercent) <-0.1
		ORDER BY AllocationCode,CombinationID

	/***************************************************************************/
		--Bridge - yes
		SELECT * FROM dbo.DimAllocationRules 
		 WHERE AllocationGroup = 'Expenses 2023 A0-A3 v3' 
		  AND IsCurrent = 1
		  AND PK_Alt_AllocationRules = 4565775 

		SELECT * FROM dbo.DimAllocationRules WHERE AllocationGroup = 'Expenses 2023 A0-A3 v3' AND AllocationCode = 'A1'
	       AND AccountFrom = 50000 AND AccountTo = 51699 AND AccountDest = '51305'
		   AND TrifocusFrom = 'Z150' AND TrifocusTo = 'Z150' AND TrifocusDest = '668'--'920'--'704'
		   AND EntityFrom = 'USBUSA' AND EntityTo = 'USBUSA' AND EntityDest = 'USBUSA'
		   ORDER BY AllocationGroupCodeVersion

		SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE FK_AllocationRules = 4565775 AND CombinationID = 18832740
	
	---------------------------------------------------------------------------
		--Bridge - NO
		SELECT * FROM dbo.DimAllocationRules 
		 WHERE AllocationGroup = 'Expenses 2023 A0-A3 v3' 
		  AND IsCurrent = 1
		  AND PK_Alt_AllocationRules = 4562594 

		SELECT * FROM dbo.DimAllocationRules WHERE AllocationGroup = 'Expenses 2023 A0-A3 v3' --AND AllocationCode = 'A1'
	       AND AccountFrom = 50000 AND AccountTo = 51699 AND AccountDest = '51305'
		   AND TrifocusFrom = 'Z150' AND TrifocusTo = 'Z150' AND TrifocusDest = '920'--'704'
		   AND EntityFrom = 'USBUSA' AND EntityTo = 'USBUSA' AND EntityDest = 'USBUSA'
		   ORDER BY AllocationGroupCodeVersion

		SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE FK_AllocationRules = 4562594 AND CombinationID = 18832740
		
		SELECT * FROM FDM_DB.dbo.DimAllocationCombinations (NOLOCK) WHERE CombinationID = 20289641
	
	--Bridge - NO
		SELECT * FROM dbo.DimAllocationRules 
		 WHERE AllocationGroup = 'Expenses 2023 A0-A3 v3' 
		  AND IsCurrent = 1
		  AND PK_Alt_AllocationRules = 4535148 

		SELECT * FROM dbo.DimAllocationRules WHERE AllocationGroup = 'Expenses 2023 A0-A3 v3' --AND AllocationCode = 'A1'
	       AND AccountFrom = 50000 AND AccountTo = 51699 AND AccountDest = '51305'
		   AND TrifocusFrom = 'Z150' AND TrifocusTo = 'Z150' AND TrifocusDest = ''--'704'
		   AND EntityFrom = 'USBUSA' AND EntityTo = 'USBUSA' AND EntityDest = 'USBUSA'
		   ORDER BY AllocationGroupCodeVersion

		SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE FK_AllocationRules = 4535148 AND CombinationID = 18832740
		--SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE FK_AllocationRules = 4760152 AND CombinationID = 18832740

		

		
	/********************************************************************/		

		SELECT DP.ProcessCode,DE.EntityCode,FACT.fk_YOA, FACT.currency	
			, cast(SUM(FACT.cur_amount) as decimal(18,4))--, FACT.*
			, cast(SUM(FACT.value) as decimal(18,4))
			, cast(SUM(FACT.value_2) as decimal(18,4))
	     FROM dbo.FACTAllocationsV1_Current FACT
	    INNER JOIN dbo.DimProcess DP
		   ON FACT.fk_Process = DP.pk_Process
		INNER JOIN dbo.DimEntity DE
		   ON FACT.fk_Entity = DE.pk_Entity		
	    WHERE BatchID = 630505--630492--630483--630456--630463
		 GROUP BY DP.ProcessCode,DE.EntityCode,FACT.fk_YOA
			 , FACT.currency --,FK_AllocationRules
		 HAVING (cast(SUM(FACT.cur_amount) as decimal(18,4)) < -1 OR cast(SUM(FACT.cur_amount) as decimal(18,4)) > 1)
		 ORDER BY DP.ProcessCode,DE.EntityCode, FACT.currency

	/*****************************************************************************************/
	  SELECT AllocationGroup,BatchID,AllocationCode,ChangeType,COUNT(1)
			 , cast(SUM(AllocationPercent) as decimal(18,4))
	    FROM dbo.DimAllocationRules
	   WHERE BatchID IN (630481,630480,630479,630478,630477,630476)	   
	     --AND AllocationCode = 'A1'
	   GROUP BY AllocationGroup,BatchID,AllocationCode,ChangeType
	   ORDER BY AllocationCode,ChangeType
	   
		SELECT AllocationGroup,BatchID,AllocationCode,ChangeType,COUNT(1)
		 , cast(SUM(AllocationPercent) as decimal(18,4))
	    FROM dbo.DimAllocationRules
	   WHERE BatchID IN (630481,630480,630479,630478,630477,630476)	   
	     AND ChangeType != 'Deleted'
		 AND AllocationPercent > 0
		 --AND AllocationCode = 'A1'
	   GROUP BY AllocationGroup,BatchID,AllocationCode,ChangeType
	   ORDER BY AllocationGroup,AllocationCode,ChangeType

		SELECT AllocationGroup,BatchID,AllocationCode,ChangeType,COUNT(1)
		 , cast(SUM(AllocationPercent) as decimal(18,4))
	    FROM dbo.DimAllocationRules
	   WHERE BatchID IN (630481,630480,630479,630478,630477,630476)	   
	     AND ChangeType != 'Deleted'
		 AND AllocationPercent < 0
		 --AND AllocationCode = 'A1'
	   GROUP BY AllocationGroup,BatchID,AllocationCode,ChangeType
	   ORDER BY AllocationGroup,AllocationCode,ChangeType	


	   ---------------------------------------------------------------------------

	   SELECT * FROM dbo.DimAllocationRules WHERE AllocationGroup = 'Expenses 2023 A0-A3 v3' AND AllocationCode = 'A1' AND BatchID = 630066 AND StepCode = 79 AND ChangeType != 'No Change'
	   SELECT * FROM dbo.DimAllocationRules WHERE AllocationGroup = 'Expenses 2023 A0-A3 v3' AND AllocationCode = 'A1' AND AllocationGroupCodeVersion = 4 AND StepCode = 79
	   AND ChangeType = 'Deleted'

	   	SELECT * FROM FDM_PROCESS.Admin.RunProcessLog WHERE fk_RunProcessConfig IN (3,13,14) AND Module = 'Expenses 2023 A0-A3 v3' ORDER BY 1 DESC
	SELECT * FROM FDM_PROCESS.Admin.RunProcessLog WHERE fk_RunProcessConfig IN (3,13,14) ORDER BY 1 DESC
	SELECT * FROM FDM_DB.dbo.AllocationEngineLog WHERE BatchID = 630483
	SELECT * FROM FDM_DB.dbo.AllocationEngineLog WHERE BatchID = 630470
	SELECT * FROM FDM_DB.dbo.AllocationEngineLog WHERE BatchID = 630467

	SELECT * FROM FDM_DB.dbo.AllocationEngineLog WHERE BatchID = 630492

	--20289641,20289568
	SELECT * FROM FDM_DB.dbo.DimAllocationCombinations (NOLOCK) WHERE CombinationID IN (20289641,20289568)

	SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE CombinationID = 20289641 AND AllocationCode = 'A1' AND AllocationGroup = 'Expenses 2023 A0-A3 v3'
	SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE CombinationID = 20289568 AND AllocationCode = 'A1' AND AllocationGroup = 'Expenses 2023 A0-A3 v3'
	SELECT * FROM dbo.DimAllocationRules WHERE AllocationGroup = 'Expenses 2023 A0-A3 v3' AND AllocationCode = 'A1' AND PK_Alt_AllocationRules IN ( 5848887,5823589) ORDER BY PK_Alt_AllocationRules,AllocationGroupCodeVersion-- AND BatchID = 630479

	SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE CombinationID = 20289641 AND AllocationCode = 'A1' AND AllocationGroup = 'Expenses 2023 A0-A3 v8' --AND FK_AllocationRules = 4562594 
	SELECT * FROM FDM_DB.dbo.BriExpensesTransactionDetailsV4 (NOLOCK) WHERE CombinationID = 20289568 AND AllocationCode = 'A1' AND AllocationGroup = 'Expenses 2023 A0-A3 v8' --AND FK_AllocationRules = 4562594 
	SELECT * FROM dbo.DimAllocationRules WHERE AllocationGroup = 'Expenses 2023 A0-A3 v8' AND AllocationCode = 'A1' AND PK_Alt_AllocationRules IN ( 5848887,5823589)-- AND BatchID = 630479
	
	SELECT * FROM dbo.DimTransactionDetailsV1_Current WHERE CombinationID = 20289641

	 SELECT * FROM dbo.DimAllocationRules WHERE AllocationGroup = 'Expenses 2023 A0-A3 v3' AND AllocationCode = 'A1' AND AllocationGroupCodeVersion = 4

	SELECT * FROM dbo.DimAllocationRules WHERE AllocationGroup = 'Expenses 2023 A0-A3 v3' AND AllocationCode = 'A1' AND BatchID = 630479
	 AND ChangeType = 'Deleted'

	 SELECT * FROM dbo.DimAllocationRules WHERE AllocationGroup = 'Expenses 2023 A0-A3 v3' AND AllocationCode = 'A1' AND BatchID = 630066 AND StepCode = 79 AND ChangeType != 'No Change'
	 SELECT * FROM dbo.DimAllocationRules WHERE AllocationGroup = 'Expenses 2023 A0-A3 v3' AND AllocationCode = 'A1' AND BatchID = 630479 AND StepCode = 79 AND ChangeType != 'No Change'
	 

	 

	 