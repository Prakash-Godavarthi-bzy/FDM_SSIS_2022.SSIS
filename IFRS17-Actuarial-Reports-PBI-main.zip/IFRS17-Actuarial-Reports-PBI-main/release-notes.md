## New
- update `build.ps1` to support multiple OD channel release

## Fixes 
