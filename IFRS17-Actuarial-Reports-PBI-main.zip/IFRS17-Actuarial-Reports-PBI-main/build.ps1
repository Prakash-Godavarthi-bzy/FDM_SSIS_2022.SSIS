Param
	(
		[switch]
		$Install,
		[switch]
		$Update,
		[switch]
		$Build,
		[switch]
		$Test,
		[switch]
		$Pack,
		[switch]
		$Publish,
		[switch]
		$Release
	) 

 
$SOURCE_NAME = "jfrog_nuget"
$AUTH_FILE_PATH = "nuget.config"
$nuget_file_content = @"
<?xml version="1.0" encoding="utf-8"?>
<configuration>
  <packageSources>
  </packageSources>
</configuration>
"@
$nuget_deployments_server = $env:Artifactory_NuGetDeployments_URL
$nuget_server = $env:Artifactory_SaaS+"/artifactory/api/nuget/v2/nuget-local"
$nuget_deployments_api_key = $env:Artifactory_NuGet_API_Key
$nuget_api_key = $env:Artifactory_NuGet_API_Key

Function Register-Nuget-Server {
	Param(
		[string]
		$NugetPath = "C:\ProgramData\chocolatey\lib\NuGet.CommandLine\tools\NuGet.exe",
		[string]
		$source_name = $SOURCE_NAME,
		[string]
		$source_url = $nuget_server,
		[string]
		$nuget_username = $env:artifactorysaas_username,
		[string]
		$nuget_passwd = $env:artifactorysaas_reference_token,
		[string]
		$ConfigFilePath = $AUTH_FILE_PATH
	)

	$ScriptBlockContent = {
		& $NugetPath sources add -name $source_name -source $source_url -username $nuget_username -password $nuget_passwd -configfile $ConfigFilePath
	}
	if (!(Test-Path -Path $ConfigFilePath -PathType Leaf)) {
		New-Item -Path $ConfigFilePath -ItemType "file" -Force
		Set-Content -Path $ConfigFilePath -Value $nuget_file_content -Encoding UTF8
	}
	Write-Host "Register nuget server"
	Invoke-Command -ScriptBlock $ScriptBlockContent -ArgumentList $($NugetPath, $source_name, $source_url, $nuget_username, $nuget_passwd, $ConfigFilePath) -Verbose

}

Function Unregister-Nuget-Server {
	Param(
		[string]
		$NugetPath = "C:\ProgramData\chocolatey\lib\NuGet.CommandLine\tools\NuGet.exe",
		[string]
		$source_name = $SOURCE_NAME,
		[string]
		$ConfigFilePath = $AUTH_FILE_PATH
	)

	$ScriptBlockContent = {
		& $NugetPath sources remove -name $source_name -configfile $ConfigFilePath
	}
	Write-Host "Unregister nuget server"
	Invoke-Command -ScriptBlock $ScriptBlockContent -ArgumentList $($NugetPath, $source_name, $ConfigFilePath) -Verbose
}




Function NuGet-Install {
	Param(
		[string]
		$OutDir=".",
		[string]
		$NugetPath = "C:\ProgramData\chocolatey\lib\NuGet.CommandLine\tools\NuGet.exe"
 		[string]
   		$AUTH_FILE_PATH = $AUTH_FILE_PATH
	)

	$ScriptBlockContent = {
		& $NugetPath install -ExcludeVersion -OutputDir $OutDir -configfile $AUTH_FILE_PATH
	}

	Invoke-Command -ScriptBlock $ScriptBlockContent -ArgumentList $($NugetPath, $Source, $ApiKey, $Path, $AUTH_FILE_PATH) -Verbose
}

if ($Install -or $Pack) {
	Register-Nuget-Server
}

}

function Choco-Install {
	choco install OctopusTools -y --version 4.9.1
}

function Add-OctopusDeployRelease {
	[CmdletBinding()]
	Param(
		[Parameter(Mandatory=$true)]
        [string]
		$ProjectName, 
		[Parameter(Mandatory=$true)]
		[string]
		$Version, 
		[Parameter(Mandatory=$true)]
		[string]
		$Packageversion, 
		[Parameter(Mandatory=$true)]
		[string]
		$OctopusDeployServer,
		[Parameter(Mandatory=$true)]
		[string]
		$OctopusDeployAPIKey,
		[string]
		$OctoLocation = "C:\ProgramData\chocolatey\lib\OctopusTools\tools\octo.exe",
		[switch]
		$LocalBuild,
		[string]
		$OctopusChannel
	)

	Write-Host @"
			Options:
				ProjectName = $ProjectName
				Version = $Version
				PackageVersion = $Packageversion
				OctopusDeployServer = $OctopusDeployServer
				OctopusChannel = $OctopusChannel
"@

	# Check for octo.exe
	If (Test-Path $OctoLocation) {
		Write-Host "octo.exe found: $OctoLocation"
	} Else {
		Write-Warning "octo.exe not found at $OctoLocation"
		[Environment]::Exit(1)
	}
	
	Create-Release-Notes -Version $Version
		
	If ($LocalBuild) {
		Write-Warning "Local build - octopus release not created"
	} Else {

		$ScriptBlockContent = $null
		if($OctopusChannel) {
			$ScriptBlockContent = {
				& $OctoLocation create-release --project `"$ProjectName`" --version $Version --packageVersion $PackageVersion --server $OctopusDeployServer --apiKey $OctopusDeployAPIKey --releasenotesfile ".\release-notes.md" --channel $OctopusChannel
			}
		} else {
			$ScriptBlockContent = {
				& $OctoLocation create-release --project `"$ProjectName`" --version $Version --packageVersion $PackageVersion --server $OctopusDeployServer --apiKey $OctopusDeployAPIKey --releasenotesfile ".\release-notes.md"
			}
		}

		

		Invoke-Command -ScriptBlock $ScriptBlockContent -ArgumentList $($OctoLocation, $ProjectName, $Version, $PackageVersion, $OctopusDeployServer,  $OctopusDeployAPIKey) -Verbose | Tee-Object -Variable result
		
		If($result) {
			$message =  $result | Out-String

			If (-Not $message.Contains("created successfully!")) {
				Write-Error $message

				# stop build process
				[Environment]::Exit(1)
			}
		}
	}
}
	

#Install dependencies	
$modulePath = ".\BuildTools.DB"
If (-Not (Test-Path $modulePath)) {
	# TODO: find NuGet proper location
	NuGet-Install
}
	
# Import dependencies	
Import-Module "$modulePath\buildtoolsdb-helpers.ps1"

# print all variables
# Get-Childitem -Path Env:* | Sort-Object Name

# set env variables
$octopus_server = $env:Octopus_Server
$octopus_api_key = $env:Octopus_API_Key
$version = $env:BUILD_NUMBER
$projectName = $env:db_project_name
$buildAgent = $env:BUILD_AGENT
$branch = $env:Branch_Name
$multipleChannels = $env:Multiple_Channels
$channels = $null

$sonar_url = $env:Sonar_Url

# set variables
$src = ""
If (Test-Path "src") {
	$src = "src"
}

if(!($projectName)) {
	$projectName = (Get-Item .).BaseName
	Write-Verbose "Project name: $projectName"
}

$buildOutputPath = "BuildOutput"
$packagePath = "$src\$projectName.nuspec"
$packagePaths = @()


if($multipleChannels) {
	$channels = $multipleChannels -Split ";"
}

$outDir = "$buildOutputPath\$projectName\"
$config = "Release"
$localBuild = $false
$pullRequestNo = $null
$preview = $true
#$preview = $false
$prereleaseTag = $false

If (-Not $version) {
	$version = "1.0.0"
}
  
# init, build and validate, publish

If(-Not $buildAgent) {
	$localBuild = $true
}

If($branch) {
	If($branch.EndsWith("/merge")) {
		$pullRequestNo = $branch.Split('/')[0]
	} Else {
		$preview = $false
	}
}

# Install dependencies
If ($Install) {
	Choco-Install
}

	
# Build project
If ($Build) {
	# clean build output
	If(Test-Path $buildOutputPath) {
	  Remove-Item -Force -Recurse $buildOutputPath
	}

	# Build project
	Write-Host "##teamcity[blockOpened name='Build-Project' description=' $projectName']"
	
	if ((Test-Path "$src\template-powerbi-reports.nuspec") -and ($projectName -ne "template-powerbi-reports")) {
		Write-Error "template-powerbi-reports.nuspec has not been configured"
	}


	

	Write-Host "##teamcity[blockClosed name='Build-Project']"
}

$packageFiles = Get-ChildItem -Path "$src\" -Include "*.nuspec" -Recurse

	
if($packageFiles) {
	if($packageFiles.Length -eq 0) {
		Write-Error "no *.nuspec files configured for this repository."
	}
} else {
	Write-Error "no files found"
}

foreach ($item in $packageFiles) {
	
	$packagePaths += "$src\$($item.Name)"
	Write-Host "Found nuspec $($item.Name)"
}



foreach ($path in $packagePaths) {
	$projName = $path -replace ".nuspec", "" 
	$projName = $projName -replace "$src\\", ""
	
	if($projectName -eq "template-powerbi-reports") {
		# default octopus deploy project
		$projName = "SolidOps.PBI.Reports"
	}
	
	Write-Host "Nuspec project: $projName"

	# Pack and publish package
	If ($Pack) {
		Write-Host "##teamcity[blockOpened name='Pack-Project' description='Pack project']"
  		Pack-Project-Saas -Path $packagePath -Version $version -ProjectName $projectName -OutDir $outDir -Configfile $AUTH_FILE_PATH
		
		Write-Host "##teamcity[blockClosed name='Pack-Project']"
	}

	# Publish Nuget
	If ($Publish -And -Not $preview) {
		
		Write-Host "##teamcity[blockOpened name='Publish-Project $projName' description='Publish project $$projName.$version.nupkg']"
		$nupkg = "$outDir$projName.$version.nupkg"
		Write-Host "Nuget pgk path: $nupkg"

		Publish-Package -Path $nupkg -Source $nuget_deployments_server"/"$projectName -ApiKey $nuget_deployments_api_key
		Write-Host "##teamcity[blockClosed name='Publish-Project']"
	}

	# Create Octopus Deploy new release
	If ($Release) {
		If ($preview) {
			Create-Release-Notes -Version $version
		} Else {
			# replace alpha if pre-release build
			#$releaseNumber = $version.Replace("-alpha", "")
			
			$packageVersion = $version.Split("-")[0]
			Write-Host "##teamcity[blockOpened name='Octopus-Release' description='Release project']"

			if($version.Split("-")[1])
			{
				$packageVersion = $version
				$prereleaseTag = $true
			}

			$octopusOptions = @{
				ProjectName = $projName
				Version = $version
				PackageVersion = $packageVersion
				OctopusDeployServer = $octopus_server
				OctopusDeployAPIKey = $octopus_api_key
				OctopusChannel = $null
			}

			#Create-Octopus-Release @octopusOptions
			# create default release
			Add-OctopusDeployRelease @octopusOptions

			if(($channels) -and (-not $prereleaseTag)) {
				Write-Host "Create release for multiple channels"
				foreach ($channel in $channels) {
					Write-Host "##teamcity[blockOpened name='Octopus-Release Channel $($channel)']"
					$octopusOptions.OctopusChannel = $channel
					$octopusOptions.Version = $version + "-" + $channel
					Add-OctopusDeployRelease @octopusOptions
					Write-Host "##teamcity[blockClosed name='Octopus-Release Channel $($channel)']"
				}
			}
			
			
			Write-Host "##teamcity[blockClosed name='Octopus-Release']"
		}
	}

 if ($Install -or $Pack) {
	Unregister-Nuget-Server -source_name $SOURCE_NAME -ConfigFilePath $AUTH_FILE_PATH
}

}
