Param
	(
		[switch]
		$Install,
		[switch]
		$Update,
		[switch]
		$Build,
		[switch]
		$Test,
		[switch]
		$Pack,
		[switch]
		$Publish,
		[switch]
		$Release, #creates a new Octopus Deploy release for the Project
		[switch]
		$Vsix	
	) 

Function NuGet-Install {
	Param(
		[string]
		$OutDir=".",
		[string]
		$NugetPath = "C:\ProgramData\chocolatey\lib\NuGet.CommandLine\tools\NuGet.exe"
	)

	$ScriptBlockContent = {
		& $NugetPath install -ExcludeVersion -OutputDir $OutDir
	}

	Invoke-Command -ScriptBlock $ScriptBlockContent -ArgumentList $($NugetPath, $Source, $ApiKey, $Path) -Verbose
}

Function NuGet-Install2 {
	Param(
		[string]
		$OutDir="src\packages",
		[string]
		$pkg,
		[string]
		$version,
		[string]
		$NugetPath = "C:\ProgramData\chocolatey\lib\NuGet.CommandLine\tools\NuGet.exe"
	)

	$ScriptBlockContent = {
		& $NugetPath install $pkg -Version $version -OutputDir $OutDir
	}

	Invoke-Command -ScriptBlock $ScriptBlockContent -ArgumentList $($NugetPath, $pkg, $version, $OutDir) -Verbose
}

Function NuGet-Restore {
	Param(
		[string]
		$path="src",
		[string]
		$NugetPath = "C:\ProgramData\chocolatey\lib\NuGet.CommandLine\tools\NuGet.exe"
	)

	$ScriptBlockContent = {
		& $NugetPath restore $path
	}

	Invoke-Command -ScriptBlock $ScriptBlockContent -ArgumentList $($NugetPath, $path) -Verbose
}

Function Build-CSProj {
	Param(
		[Parameter(Mandatory=$true,
        Position=0,
        HelpMessage='ProjectName must be set to the name of a project folder')]
		[string]
		$ProjectName, 
		
		[string]
		$Config = "Release", 
		
		[switch]
		$LocalBuild,
		
		[string]
		$MsBuildPath = "C:\Program Files (x86)\Microsoft Visual Studio\2017\BuildTools\MSBuild\15.0\bin\MSBuild.exe"
	)

	$target = "src\$ProjectName\$ProjectName.csproj"
	
	$ScriptBlockContent = {
		  & $MsBuildPath $target /p:Configuration=$Config
	}

	If ($LocalBuild) {
		NuGet-Restore 
		Invoke-Command -ScriptBlock $ScriptBlockContent -ArgumentList $($MsBuildPath, $target, $Config) -Verbose 
	}
	Else {
		NuGet-Restore
		Invoke-Command -ScriptBlock $ScriptBlockContent -ArgumentList $($MsBuildPath, $target, $Config) -Verbose | Tee-Object -Variable result
	}
	
	If($result) {
		$message =  $result | Out-String

		# TODO: find a better way to track this
		If ($result.Contains("Build FAILED.")) {
			Write-Error $message

			# stop build process
			[Environment]::Exit(1)
		}
	} 
}


#Install dependencies	
$modulePath = ".\BuildTools.DB"
If (-Not (Test-Path $modulePath)) {
	# TODO: find NuGet proper location
	NuGet-Install
}
	
# Import dependencies	
Import-Module "$modulePath\buildtoolsdb-helpers.ps1"

# print all variables
# Get-Childitem -Path Env:* | Sort-Object Name

# set env variables
$nuget_deployments_server = $env:Nuget_Deployments_Server
$nuget_server = $env:NuGet_URL
$nuget_deployments_api_key = $env:Nuget_Deployments_Api_Key
$nuget_api_key = $env:NuGet_API_Key
$octopus_server = $env:Octopus_Server
$octopus_api_key = $env:Octopus_API_Key
$version = $env:BUILD_NUMBER
$projectName = $env:db_project_name
$buildAgent = $env:BUILD_AGENT
$branch = $env:Branch_Name
$ghe_token = $env:GITHUB_ENTERPRISE_TOKEN

$sonar_url = $env:Sonar_Url
$gitOrganization = $env:Git_Organization
$gitRepository = $env:Git_Repository
$gitEndpoint = $env:Git_Endpoint

# set variables
$src = ""
If (Test-Path "src") {
	$src = "src\"
}

$buildOutputPath = "BuildOutput"
$packagePath = "$src\$projectName.nuspec"
$outDir = "$buildOutputPath\$projectName\"
$vsixOutDir = "$buildOutputPath\$projectName.Installer\"
$config = "Release"
$localBuild = $false
$pullRequestNo = $null
$preview = $true

If (-Not $version) {
	$version = "1.0.0"
}
  
# init, build and validate, publish

If(-Not $buildAgent) {
	$localBuild = $true
}

If($branch) {
	If($branch.EndsWith("/merge")) {
		$pullRequestNo = $branch.Split('/')[0]
	} Else {
		$preview = $false
	}
}

# Install dependencies
If ($Install) {
	# TODO: check depedencies
	# Choco-Project
}

	
# Build project
If ($Build) {
	# clean build output
	If(Test-Path $buildOutputPath) {
	  Remove-Item -Force -Recurse $buildOutputPath
	}

	NuGet-Install2 -pkg "System.Security.Cryptography.Cng" -version "4.4.0"

	# Build project
	Write-Host "##teamcity[blockOpened name='Build-Project' description='$projectName']"
	#$msBuildPath = "C:\Program Files (x86)\Microsoft Visual Studio\2019\BuildTools\MSBuild\Current\Bin\msbuild.exe"
	$projName = "Beazley.PowerBI.DataGateway.Automation"
	Build-CSProj -ProjectName $projName -LocalBuild:$localBuild #-MsBuildPath $msBuildPath
	Write-Host "##teamcity[blockClosed name='Build-Project']"


}

# Pack and publish package
If ($Pack) {
	Write-Host "##teamcity[blockOpened name='Pack-Project' description='Pack project']"
	Pack-Project -Path $packagePath -Version $version -ProjectName $projectName -OutDir $outDir
	Write-Host "##teamcity[blockClosed name='Pack-Project']"

	If($Vsix){
	Write-Host "##teamcity[blockOpened name='Pack-Project' description='Pack project']"
	Pack-Project -Path $vsixPackagePath -Version $version -ProjectName "$projectName.Installer" -OutDir $vsixOutDir
	Write-Host "##teamcity[blockClosed name='Pack-Project']"
	}
}

# Publish Nuget
If ($Publish) {
	Write-Host "##teamcity[blockOpened name='Publish-Project' description='Publish project']"
	Publish-Package -Path $outDir -Source $nuget_server -ApiKey $nuget_api_key
	Write-Host "##teamcity[blockClosed name='Publish-Project']"
}

# Create Octopus Deploy new release
If ($Release) {
	If ($preview) {
		$result = Create-Release-Notes -Version $version
	} Else {
		# replace alpha if pre-release build
		#$releaseNumber = $version.Replace("-alpha", "")
		$packageVersion = $version.Split("-")[0]
		Write-Host "##teamcity[blockOpened name='Octopus-Release' description='Release project']"

        if($version.Split("-")[1])
	    {
	        $packageVersion = $version
	    }

		$octopusOptions = @{
			ProjectName = $projectName
			Version = $version
			PackageVersion = $packageVersion
			OctopusDeployServer = $octopus_server
			OctopusDeployAPIKey = $octopus_api_key
		}
		Create-Octopus-Release @octopusOptions
		
		Write-Host "##teamcity[blockClosed name='Octopus-Release']"
	}
} 