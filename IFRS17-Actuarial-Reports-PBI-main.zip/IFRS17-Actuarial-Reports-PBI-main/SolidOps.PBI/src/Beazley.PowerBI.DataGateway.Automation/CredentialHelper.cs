﻿using Microsoft.PowerBI.Api.Extensions;
using Microsoft.PowerBI.Api.Extensions.Models.Credentials;
using Microsoft.PowerBI.Api.Models;
using Microsoft.PowerBI.Api.Models.Credentials;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beazley.PowerBI.DataGateway.Automation
{
    public class CredentialHelper
    {
        public CredentialHelper()
        {

        }

        public CredentialDetails GetEncryptedCredentialsEncryptor(string userName, string password, ICredentialsEncryptor credentialsEncryptor)
        {
            var credentials = new WindowsCredentials(userName, password);

            var credentialDetails = new CredentialDetails(
                credentials,
                PrivacyLevel.Organizational,
                EncryptedConnection.Encrypted,
                credentialsEncryptor);

            return credentialDetails;
        }

        public CredentialDetails GetEncryptedCredentials(string userName, string password, string exponent, string modulus)
        {
            var credentials = new WindowsCredentials(userName, password);

            var gateway = new GatewayPublicKey(exponent, modulus);
            var credentialsEncryptor = new AsymmetricKeyEncryptor(gateway);

            var credentialDetails = new CredentialDetails(
                credentials,
                PrivacyLevel.Organizational,
                EncryptedConnection.Encrypted,
                credentialsEncryptor);

            return credentialDetails;
        }
    }
}
