[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12;

# docs https://docs.microsoft.com/en-us/rest/api/power-bi/gateways


$User = $OctopusParameters['param.pbi.username']
$Pass = $OctopusParameters['param.pbi.password']
$OnPremiseDataGateway = $OctopusParameters['param.pbi.datagateway.name']
$Server = $OctopusParameters['param.pbi.datasource.server']
$Database = $OctopusParameters['param.pbi.datasource.database']
$DSUser = $OctopusParameters['param.pbi.datasource.username']
$DSPass = $OctopusParameters['param.pbi.datasource.password']
$DSName = $OctopusParameters['param.pbi.datasource.name']
$Users = $OctopusParameters['param.pbi.datasource.users']
$TeamName = $OctopusParameters['param.pbi.team.name']
$DSType = $OctopusParameters['param.pbi.datasource.type']

$ClientId = $OctopusParameters["param.pbi.client.id"]
$Resource = $OctopusParameters["param.pbi.client.resource"]
$SSOType = $OctopusParameters["param.pbi.client.SingleSignonType"]


$OctoEnv = $OctopusParameters['Octopus.Environment.Name']
$installPathKey = "Octopus.Action[$($InstallStepName)].Output.Package.InstallationDirectoryPath"
$FolderLocation = $OctopusParameters[$installPathKey]
$rootPath = "$FolderLocation\lib"

Load-Module "MicrosoftPowerBIMgmt"
Load-Assemblies -rootPath $rootPath
Load-Module "AzureAD"

Connect-PBI -user $User -pass $Pass 

Connect-AAD -user $User -pass $Pass

# Get Gateway
$gateway = Get-Gateway -gatewayName $OnPremiseDataGateway 
$gatewayId = $gateway.id

# Set data source name ENV + DS name

$EnvCode = $OctopusParameters['pbi.environment'] #Get-EnvironmentCode -env $OctoEnv
Write-Verbose "Environment code: $EnvCode" 



Write-Verbose "Data source username: $DSUser"

$credentialDetails = Get-CredentialDetails `
                           -user $DSUser `
                           -pass $DSPass `
                           -exponent $gateway.publicKey.exponent `
                           -modulus $gateway.publicKey.modulus

$token = Get-MicrosoftToken2 -user $User -pass $Pass -clientId $ClientId -resource $Resource
$accessToken = $token.access_token

Write-Verbose "Data source name: $DSName"

# ex: UK123\\TST -> UK123\TST
$Server = $Server -Replace "\\\\", "\"
try {
    $dsId = Set-Datasource -gatewayId $gatewayId `
        -credentials $credentialDetails.Credentials `
        -server $Server `
        -database $Database `
        -datasourceType $DSType `
        -envCode $EnvCode `
        -team $TeamName `
        -users $Users `
        -accessToken $accessToken `
        -datasourceNameBase $DSName
        

    $datasourceId = "$dsId"

    if($DSType -eq 'AnalysisServices') {
        Set-DatasourcePrincipals -gatewayId $gatewayId -datasourceId $datasourceId -pbiUsername $User -dsUsername $DSUser
    }

    if($DSType -eq "Sql") {
        if ($SSOType) {
            Update-DatasourceSSO -gatewayId $gatewayId -datasourceId $datasourceId -singleSignonType $SSOType
        }
    }
} catch {
    $message = $_
    Fail-Step $message
}



