[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$UserType = $env:USER_TYPE
$TenantId = $env:TENANTID #clientid 
$ApplicationId = $env:APPLICATIONID #$User 
$ClientSecret = $env:CLIENTSECRET #$Pass
$DataGatewayName = $env:DATA_GATEWAY_NAME
$DataGatewayId = $env:DATA_GATEWAY_ID
$reportType = $env:REPORT_TYPE
$NUGET_PKG_VERSION = $env:NUGET_PKG_VERSION
$TEAM_NAME = $env:TEAM_NAME
$REPO_NAME = $env:REPO_NAME

Start-Transcript -Path "D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\DatasetsUpdate-Logs.txt"

Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.psm1
Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.Reports.psm1
Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.Datasets.psm1
Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.Gateway.psm1

Install-Module MicrosoftPowerBIMgmt -force -AllowClobber
Import-Module MicrosoftPowerBIMgmt

$envCode = $env:PBI_ENV
$WORKSPACE_NAME = $env:WORKSPACE_NAME
$WorkspaceName = $WORKSPACE_NAME + "-" + $envCode 

write-host $WorkspaceName
$FolderLocation = "C:\Program Files\PackageManagement\NuGet\Packages\$REPO_NAME.$NUGET_PKG_VERSION"
 
Connect-PBI -user $ApplicationId -pass $ClientSecret -userType $UserType -tenantId $TenantId 

Get-EnvironmentCode -env $envCode

Set-TeamName -team $TEAM_NAME

#try { 
    Set-DatasetsV2 -workspaceName $WorkspaceName `
        -path $FolderLocation `
        -gatewayName $DataGatewayName `
        -user $ApplicationId `
        -pass $ClientSecret `
        -reportType $reportType `
        -userType $UserType

#} catch {
#    $message = $_
#    Fail-Step $message
#}
Stop-Transcript
