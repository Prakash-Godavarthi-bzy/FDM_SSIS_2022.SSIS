[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$User = "CoE-PowerBIMigration-PBI-DEV-001" #$env:POWER_BI_USERNAME
$UserType = $env:USER_TYPE
$TenantId = $env:TENANTID #clientid
$ApplicationId = $env:APPLICATIONID #$User
$ClientSecret = $env:CLIENTSECRET #$Pass
$DataGatewayName = $env:DATA_GATEWAY_NAME
$DataGatewayId = $env:DATA_GATEWAY_ID
$reportType = $env:REPORT_TYPE
$NUGET_PKG_VERSION = $env:NUGET_PKG_VERSION
$REPO_NAME = $env:REPO_NAME

Start-Transcript -Path "D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\ReportsUpload-Logs.txt"

Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.psm1
Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.Reports.psm1
Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.Datasets.psm1

Install-Module MicrosoftPowerBIMgmt -force -AllowClobber
Import-Module MicrosoftPowerBIMgmt

$envCode = $env:PBI_ENV
$WORKSPACE_NAME = $env:WORKSPACE_NAME
$WorkspaceName = $WORKSPACE_NAME + "-" + $envCode

$FolderLocation = "C:\Program Files\PackageManagement\NuGet\Packages\$REPO_NAME.$NUGET_PKG_VERSION"

Connect-PBI -user $ApplicationId -pass $ClientSecret -userType $UserType -tenantId $TenantId  

# try {
    Add-Reports -workspaceName $WorkspaceName `
        -path $FolderLocation `
        -gatewayName $DataGatewayName `
        -configuredBy $User `
        -reportType $reportType
# }
# catch {
#     $message = $_

#     $formatstring = "{5} `n" +
#                 "{0} : {1}`n{2}`n" +
#                 "    + CategoryInfo          : {3}`n" +
#                 "    + FullyQualifiedErrorId : {4}`n"
#     $fields = $_.InvocationInfo.MyCommand.Name,
#             $_.ErrorDetails.Message,
#             $_.InvocationInfo.PositionMessage,
#             $_.CategoryInfo.ToString(),
#             $_.FullyQualifiedErrorId,
#             $_.Message

#     $formatstring -f $fields
    
    
    
#     Write-Warning ($formatstring -f $fields)

#     $callStack = $message.ScriptStackTrace
#     Write-Warning $callStack

#     Fail-Step $message

    
# }

Stop-Transcript