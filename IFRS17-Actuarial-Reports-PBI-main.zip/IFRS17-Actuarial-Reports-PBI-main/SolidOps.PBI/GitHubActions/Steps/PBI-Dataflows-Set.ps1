[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$SP_USER_TYPE = $env:SP_USER_TYPE
$TenantId = $env:TENANTID #clientid
$ApplicationId = $env:APPLICATIONID #$User
$ClientSecret = $env:CLIENTSECRET #$Pass
$DataGatewayName = $env:DATA_GATEWAY_NAME
$DataGatewayId = $env:DATA_GATEWAY_ID
$NUGET_PKG_VERSION = $env:NUGET_PKG_VERSION
$POWER_BI_USERNAME = $env:POWER_BI_USERNAME
$POWER_BI_PASSWORD = $env:POWER_BI_PASSWORD
$REPO_NAME = $env:REPO_NAME

Start-Transcript -Path "D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\DataflowsSet-Logs.txt"

Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.psm1
Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.Imports.psm1

Install-Module MicrosoftPowerBIMgmt -force -AllowClobber
Import-Module MicrosoftPowerBIMgmt

$envCode = $env:PBI_ENV
$WORKSPACE_NAME = $env:WORKSPACE_NAME
$WorkspaceName = $WORKSPACE_NAME + "-" + $envCode

$FolderLocation = "C:\Program Files\PackageManagement\NuGet\Packages\$REPO_NAME.$NUGET_PKG_VERSION"

Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.UIAutomation.psm1
Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.Dataflows.psm1
 
#try { 
    Connect-PBI -user $POWER_BI_USERNAME -pass $POWER_BI_PASSWORD -userType $SP_USER_TYPE

    # Set-PowerBIDataflows -workspaceName $WorkspaceName `
    #     -path $FolderLocation `
    #     -gatewayName $DataGatewayName `
    #     -gatewayId $DataGatewayId `
    #     -user $ApplicationId `
    #     -pass $ClientSecret `
    #     -flag $True `
    #     -verbose

#} catch {
#    $message = $_
#    Resolve-PowerBIError -Last

#    Fail-Step $message
#}
Stop-Transcript