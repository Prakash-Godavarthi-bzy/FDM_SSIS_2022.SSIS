[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Invoke-SqlScript {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][String]$ServerInstance,
        [Parameter(Mandatory = $true)][String]$Database,
        [Parameter(Mandatory = $true)][String]$FullName
    )
    
    Write-Verbose "[Invoke-SqlScript] [$FullName] to '$ServerInstance[$Database]' begin"

    $outFile = "exec-$FullName-output.txt"
    
    try {
        # -ConnectionTimeout 300
        Invoke-SQLCMD -Inputfile $FullName -ServerInstance $ServerInstance -Database $Database -OutputSqlErrors $true -ErrorAction Stop -Verbose 4>&1 > $outFile
        foreach ($line in Get-Content $outFile) { Write-Verbose $line }
        Write-Information "[Invoke-SqlScript] [$FullName] to '$ServerInstance[$Database]' end"
        New-OctopusArtifact $outFile
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        Write-Verbose "Instance: $ServerInstance, Database: $Database, File: $FullName" "Host" $Indent
        Write-Error "ERROR $FullName - $ErrorMessage"
    }
}


function Invoke-LoginScript {
    [CmdletBinding()]
    param (
        # Username 
        [Parameter(Mandatory=$true)]
        [string]
        $Username,
        [Parameter(Mandatory=$true)]
        [string]
        $PreScript,
        [Parameter(Mandatory=$true)]
        [string]
        $PostScript,
        [Parameter(Mandatory = $true)]
        [String]
        $Server,
        [Parameter(Mandatory = $true)]
        [String]
        $Database
    )
   

    $script = $PreScript
    $script += @" 

    SET @user_name = '$UsernameScript'
"@
    $script += $PostScript

    $scriptPath = "Login_$UsernameScript.sql"
    New-Item $scriptPath
    Set-Content $scriptPath $script

    New-OctopusArtifact $scriptPath

    Invoke-SqlScript -ServerInstance $Server -Database $Database -FullName $scriptPath

}

function Invoke-UserScript {
    [CmdletBinding()]
    param (
        # Username 
        [Parameter(Mandatory=$true)]
        [string]
        $Username,
        [Parameter(Mandatory=$true)]
        [string]
        $PreScript,
        [Parameter(Mandatory=$true)]
        [string]
        $MidScript,
        [Parameter(Mandatory=$true)]
        [string]
        $PostScript,
        [Parameter(Mandatory = $true)]
        [String]
        $Server,
        [Parameter(Mandatory = $true)]
        [String]
        $Database
    )
   

    $script = $PreScript
    $script += @" 

    SET @user_name = '$UsernameScript'
"@
    $script += $MidScript
    $script += @"

    INSERT @T (Code) VALUES ('ALTER ROLE [db_datareader] ADD MEMBER ['+@user_name+']')
"@
    $script += $PostScript

    $scriptPath = "User_$UsernameScript.sql"
    New-Item $scriptPath
    Set-Content $scriptPath $script

    New-OctopusArtifact $scriptPath

    Invoke-SqlScript -ServerInstance $Server -Database $Database -FullName $scriptPath

}


Load-Module "SqlServer"

$Server = $OctopusParameters['param.pbi.datasource.server']
$Database = $OctopusParameters['param.pbi.datasource.database']
$UsernameScript = $OctopusParameters['param.pbi.datasource.scripts.username']
$LoginPreScript = $OctopusParameters['param.pbi.datasource.scripts.login_pre']
$LoginPostScript = $OctopusParameters['param.pbi.datasource.scripts.login_post']
$UserPreScript = $OctopusParameters['param.pbi.datasource.scripts.user_pre']
$UserMidScript = $OctopusParameters['param.pbi.datasource.scripts.user_mid']
$UserPostScript = $OctopusParameters['param.pbi.datasource.scripts.user_post']

Invoke-LoginScript -Username $UsernameScript `
    -PreScript $LoginPreScript `
    -PostScript $LoginPostScript `
    -Server $Server `
    -Database $Database

Invoke-UserScript -Username $UsernameScript `
    -PreScript $UserPreScript `
    -MidScript $UserMidScript `
    -PostScript $UserPostScript `
    -Server $Server `
    -Database $Database




# generate sql script