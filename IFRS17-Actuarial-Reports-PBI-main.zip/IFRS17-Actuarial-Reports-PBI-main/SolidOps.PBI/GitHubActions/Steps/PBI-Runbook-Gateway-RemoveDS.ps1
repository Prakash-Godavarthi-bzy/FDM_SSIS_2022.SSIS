[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12;

# docs https://docs.microsoft.com/en-us/rest/api/power-bi/gateways

$OnPremiseDataGateway = $OctopusParameters['param.pbi.datagateway.name']
$DSName = $OctopusParameters['param.pbi.datasource.name']
$TeamName = $OctopusParameters['param.pbi.team.name']
$EnvCode = $OctopusParameters['pbi.environment']
$User = $OctopusParameters['param.pbi.username']
$Pass = $OctopusParameters['param.pbi.password']

Load-Module "MicrosoftPowerBIMgmt"


Connect-PBI -user $User -pass $Pass 

# Get Gateway
$gateway = Get-Gateway -gatewayName $OnPremiseDataGateway 
$gatewayId = $gateway.id

$fqdnDSName = $DSName + "-FQDN"

# Set data source name ENV + DS name

Write-Verbose "Environment code:    $EnvCode" 
Write-Verbose "Data source name:    $DSName"
Write-Verbose "FQDN:                $DSName"

try {
    Remove-Datasource -gatewayId $gatewayId `
        -envCode $EnvCode `
        -team $TeamName `
        -datasourceNameBase $DSName

    Remove-Datasource -gatewayId $gatewayId `
        -envCode $EnvCode `
        -team $TeamName `
        -datasourceNameBase $fqdnDSName

} catch {
    $message = $_
    Fail-Step $message
}



