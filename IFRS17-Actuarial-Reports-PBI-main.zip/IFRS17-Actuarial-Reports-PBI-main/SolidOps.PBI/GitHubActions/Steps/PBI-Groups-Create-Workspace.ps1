[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
 
$UserType = $env:USER_TYPE
$ClientId = $env:MICROSOFT_GRAPH_CLIENT_ID
$Resource = $env:MICROSOFT_GRAPH_RESOURCE
$NUGET_PKG_VERSION = $env:NUGET_PKG_VERSION
$TenantId = $env:TENANTID #clientid
$ClientSecret = $env:CLIENTSECRET #$Pass
$ApplicationId = $env:APPLICATIONID #$User
$REPO_NAME = $env:REPO_NAME

Start-Transcript -Path "D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\CreateWorkspace-Logs.txt"

$envCode = $env:PBI_ENV
$WORKSPACE_NAME = $env:WORKSPACE_NAME
$WorkspaceName = $WORKSPACE_NAME + "-" + $envCode

$FolderLocation = "C:\Program Files\PackageManagement\NuGet\Packages\$REPO_NAME.$NUGET_PKG_VERSION"

Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.psm1
Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.Workspaces.psm1

Load-Module AzureAD
Load-Module Az.Accounts
Load-Module Microsoft.Graph.Groups

Import-Module Microsoft.Graph.Groups
Install-Module MicrosoftPowerBIMgmt -force -AllowClobber
Import-Module MicrosoftPowerBIMgmt

Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\AzureAD.psm1
Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.Workspaces.psm1
Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.UIAutomation.psm1

Connect-PBI -user $ApplicationId -pass $ClientSecret -userType $UserType -tenantId $TenantId 

# create workspace if it does not exist 
$workspace = Add-Workspace -name $WorkspaceName 
$workspaceId = $workspace.Id
 
Connect-AAD -user $ApplicationId -pass $ClientSecret -userType $UserType -tenantId $TenantId
Add-WorkspaceUsers -id $workspaceId -path $FolderLocation -envCode $envCode 

$grantType = "password"
if($UserType -eq "ServiceAccount") {
    $grantType = "password"
} elseif ($UserType -eq "ServicePrincipal") {
    $grantType = "client_credentials" 
} 

# $token = Get-MicrosoftToken2 -user $ApplicationId -pass $ClientSecret -clientId $ClientId -resource $Resource -grantType $grantType 
# Set-WorkspaceContactList -workspaceId $workspaceId -path $FolderLocation -envCode $envCode -accessToken $token.access_token

Stop-Transcript 
