[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Load-Module "MicrosoftPowerBIMgmt"
Load-Module "AzureAD"

$User = $OctopusParameters['param.pbi.username']
$Pass = $OctopusParameters['param.pbi.password']
$WorkspaceName = $OctopusParameters['param.pbi.workspace']

$owners = $OctopusParameters['param.pbi.workspace.owners']
$developers = $OctopusParameters['param.pbi.workspace.developers']

$installPathKey = "Octopus.Action[$($InstallStepName)].Output.Package.InstallationDirectoryPath"
$FolderLocation = $OctopusParameters[$installPathKey]


Connect-PBI -user $User -pass $Pass 
Connect-AAD -user $User -pass $Pass

$global:SolidOpsSession.Developers = $developers


Set-DataflowsRefreshSettings -workspaceName $WorkspaceName -path $FolderLocation -contacts $owners

