[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12


$pbigUsername = $OctopusParameters['param.pbi.datasource.username']
$pbigGroupName = $OctopusParameters['param.pbi.datasource.adgroup']
$DSType = $OctopusParameters['param.pbi.datasource.type']
$database = $OctopusParameters['param.pbi.datasource.database']



$variablesList = @(
    "pbi.datasource.username",
    "pbi.datasource.password",
    "pbi.team.name",
    #"pbi.datasource.adgroup.email.cc",
    "pbi.team.owners"

)

try {
    Invoke-ValidateConfig -appParameters $OctopusParameters -variableChecks $variablesList
}
catch {
    $message = $_
    Fail-Step $message
}

