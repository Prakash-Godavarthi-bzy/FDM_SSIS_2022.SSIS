[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$UserType = $env:USER_TYPE
$TenantId = $env:TENANTID #clientid
$envCode = $env:POWER_BI_ENV
$ClientSecret = $env:CLIENTSECRET #$Pass
$ApplicationId = $env:APPLICATIONID #$User
$ClientId = $env:MICROSOFT_GRAPH_CLIENT_ID
$Resource = $env:MICROSOFT_GRAPH_RESOURCE
$NUGET_PKG_VERSION = $env:NUGET_PKG_VERSION

$POWER_BI_USERNAME = $env:POWER_BI_USERNAME
$POWER_BI_PASSWORD = $env:POWER_BI_PASSWORD

$FolderLocation = "C:\Program Files\PackageManagement\NuGet\Packages\template-powerbi-reports.0.1.14.3"

Import-Module D:\a\CoE-PowerBIMigration-PBI\CoE-PowerBIMigration-PBI\SolidOps.PBI\OctopusDeploy\Modules\SolidOps.PBI.psm1


#Install-Module AzureAD
Load-Module AzureAD
#Import-Module AzureAD
Import-Module D:\a\CoE-PowerBIMigration-PBI\CoE-PowerBIMigration-PBI\SolidOps.PBI\OctopusDeploy\Modules\AzureAD.psm1
Import-Module D:\a\CoE-PowerBIMigration-PBI\CoE-PowerBIMigration-PBI\SolidOps.PBI\OctopusDeploy\Modules\SolidOps.PBI.Workspaces.psm1

# Get group permissions
$groupConfig = Get-WorkspaceConfig -Path $FolderLocation
# $grantType = "password"
# if($UserType -eq "ServiceAccount") {
#     $grantType = "password"
# } elseif ($UserType -eq "ServicePrincipal") {
#     $grantType = "client_credentials"
# } 

# $securedPassword = ConvertTo-SecureString $POWER_BI_PASSWORD -AsPlainText -Force
# $pbiServiceAccountCred = New-Object System.Management.Automation.PSCredential ($POWER_BI_USERNAME, $securedPassword)
# Connect-AzureAD -Credential $pbiServiceAccountCred

#Connect-AAD -user $POWER_BI_USERNAME -pass $POWER_BI_PASSWORD -userType $UserType #-tenantId $TenantId

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$securedPassword = ConvertTo-SecureString $POWER_BI_PASSWORD -AsPlainText -Force
$pbiServiceAccountCred = New-Object System.Management.Automation.PSCredential ($POWER_BI_USERNAME, $securedPassword)
Connect-AzureAD -Credential $pbiServiceAccountCred

Set-AzureADGroups -groupConfig $groupConfig `
    -envCode $envCode `
    -user $POWER_BI_USERNAME `
    -pass $POWER_BI_PASSWORD `
    -clientId $ClientId `
    -resource $Resource `
    -grantType $grantType
