[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$UserType = $env:USER_TYPE
$TenantId = $env:TENANTID #clientid
$ApplicationId = $env:APPLICATIONID #$User
$ClientSecret = $env:CLIENTSECRET #$Pass
$DataGatewayName = $env:DATA_GATEWAY_NAME
$NUGET_PKG_VERSION = $env:NUGET_PKG_VERSION
$owners = $env:OWNER_NAME
# $developers = $env:WORKSPACE_DEVELOPERS
$REPO_NAME = $env:REPO_NAME

Start-Transcript -Path "D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\DatasetsContactList-Logs.txt"
 
$envCode = $env:PBI_ENV
$WORKSPACE_NAME = $env:WORKSPACE_NAME
$WorkspaceName = $WORKSPACE_NAME + "-" + $envCode 
$FolderLocation = "C:\Program Files\PackageManagement\NuGet\Packages\$REPO_NAME.$NUGET_PKG_VERSION"

Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.psm1
Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.Datasets.psm1

Load-Module AzureAD
Load-Module Az.Accounts

Load-Module Microsoft.Graph.Groups 
Import-Module Microsoft.Graph.Groups
Install-Module MicrosoftPowerBIMgmt -force -AllowClobber
Import-Module MicrosoftPowerBIMgmt

Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\AzureAD.psm1
Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.Reports.psm1
Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.UIAutomation.psm1

Connect-PBI -user $ApplicationId -pass $ClientSecret -userType $UserType -tenantId $TenantId 
Connect-AAD -user $ApplicationId -pass $ClientSecret -userType $UserType -tenantId $TenantId

$global:SolidOpsSession.Developers = $developers

#Set-DatasetsRefreshSettings -workspaceName $WorkspaceName -path $FolderLocation -contacts $owners -verbose

#Update-Datasets -workspaceName $WorkspaceName -path $FolderLocation -gatewayName $DataGatewayName -user $User -pass $Pass
Stop-Transcript