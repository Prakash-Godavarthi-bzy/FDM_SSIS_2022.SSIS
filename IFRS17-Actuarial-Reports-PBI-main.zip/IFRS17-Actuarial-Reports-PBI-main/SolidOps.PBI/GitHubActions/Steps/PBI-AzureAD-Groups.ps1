$User = $OctopusParameters["param.pbi.username"]
$Pass = $OctopusParameters["param.pbi.password"]
$ClientId = $OctopusParameters["param.pbi.client.id"]
$Resource = $OctopusParameters["param.pbi.client.resource"]
#$Owners = $OctopusParameters["param.pbi.team.owners"]

$OctoEnv = $OctopusParameters['Octopus.Environment.Name']
$installPathKey = "Octopus.Action[$($InstallStepName)].Output.Package.InstallationDirectoryPath"
$FolderLocation = $OctopusParameters[$installPathKey]

Load-Module "AzureAD"

Connect-AAD -user $User -pass $Pass

# Get environment code
#$envCode = Get-EnvironmentCode -env $OctoEnv
$envCode = $OctopusParameters['pbi.environment']

# Get group permissions
$groupConfig = Get-WorkspaceConfig -Path $FolderLocation

Set-AzureADGroups -groupConfig $groupConfig `
    -envCode $envCode `
    -user $User `
    -pass $Pass `
    -clientId $ClientId `
    -resource $Resource
