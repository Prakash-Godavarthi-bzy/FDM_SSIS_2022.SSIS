[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Load-Module "MicrosoftPowerBIMgmt"

$User = $OctopusParameters['param.pbi.username']
$Pass = $OctopusParameters['param.pbi.password']
$DataGatewayName = $OctopusParameters['param.pbi.datagateway.name']
$WorkspaceName = $OctopusParameters['param.pbi.workspace']
$_GatewayOnly = $OctopusParameters['param.pbi.gatewayOnly']
$ObjectType = $OctopusParameters['param.pbi.objectType']

[bool]$GatewayOnly = $false; 
if (-not [bool]::TryParse($_GatewayOnly, [ref]$GatewayOnly)) {
    # Set the default to use here (when the value cannot be parsed as boolean)
    $GatewayOnly = $true;
}

if ($GatewayOnly) {
    Write-Host "Gateway only: false"
} else {
    Write-Host "Gateway only: true"
}

$installPathKey = "Octopus.Action[$($InstallStepName)].Output.Package.InstallationDirectoryPath"
$FolderLocation = $OctopusParameters[$installPathKey]


Connect-PBI -user $User -pass $Pass 

try {
    if($ObjectType -eq "Dataset") {
        Set-DatasetsV2 -workspaceName $WorkspaceName `
            -path $FolderLocation `
            -gatewayName $DataGatewayName `
            -user $User `
            -pass $Pass `
            -reportType 'PowerBIReport' `
            -gatewayOnly $GatewayOnly
    } elseif ($ObjectType -eq "Dataflow") {
        Set-PowerBIDataflows -workspaceName $WorkspaceName `
            -path $FolderLocation `
            -gatewayName $DataGatewayName `
            -gatewayId $DataGatewayId `
            -user $User `
            -pass $Pass `
            -gatewayOnly $GatewayOnly
    } else {
        Write-Error "Object type $($ObjectType) not implemented"
    }
} catch {
    $message = $_
    Fail-Step $message
}


