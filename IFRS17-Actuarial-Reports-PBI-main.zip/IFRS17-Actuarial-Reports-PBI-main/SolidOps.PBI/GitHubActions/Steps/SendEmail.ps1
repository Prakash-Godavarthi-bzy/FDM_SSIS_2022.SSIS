[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

$NUGET_PKG_VERSION = $env:NUGET_PKG_VERSION
$POWER_BI_USERNAME = $env:POWER_BI_USERNAME
$InstallNuget_Outcome = $env:InstallNuget_Outcome
$CreateAADGroup_OutCome = $env:CreateAADGroup_OutCome
$CreateWorkspace_Outcome = $env:CreateWorkspace_Outcome
$DataflowsSet_Outcome = $env:DataflowsSet_Outcome
$ReportsUpload_Outcome = $env:ReportsUpload_Outcome
$DatasetsUpdate_Outcome = $env:DatasetsUpdate_Outcome
$DatasetsContactList_Outcome = $env:DatasetsContactList_Outcome
$CreateChangeRequest_OutCome = $env:CreateChangeRequest_OutCome
$Committer = $env:Committer
$Username = $env:Username
$Run_id = $env:Run_id
$Github_Actor = $env:Github_Actor
$GithubUser_Email = $env:GithubUser_Email
$Current_Job = $env:Current_Job
$GitHubPackageLink = $env:GitHubPackageLink
$DeployStatus = $env:DeployStatus

$NugetInstallErrorLogs = $env:NugetInstallErrorLogs
$CreateAADGroupErrorLogs = $env:CreateAADGroupErrorLogs
$CreateWorkspaceErrorLogs = $env:CreateWorkspaceErrorLogs
$DataflowsSetErrorLogs = $env:DataflowsSetErrorLogs
$ReportsUploadErrorLogs = $env:ReportsUploadErrorLogs
$DatasetsUpdateErrorLogs = $env:DatasetsUpdateErrorLogs
$DatasetsContactListErrorLogs = $env:DatasetsContactListErrorLogs

#--GitHub Environment Variables to be replaced in HTML file
$PROJECT_NAME = $env:PROJECT_NAME
$PBI_ENV = $env:PBI_ENV
$WORKSPACE_OWNERS = $env:WORKSPACE_OWNERS
$Github_Actor=$Github_Actor
$dateCreated=Get-Date
$gitHubPackageURL="https://nuget.pkg.github.com/Beazley/download/$PROJECT_NAME/$NUGET_PKG_VERSION/$PROJECT_NAME.$NUGET_PKG_VERSION.nupkg"
$deploymentLogUrl="https://github.com/beazley/$PROJECT_NAME/actions/runs/$Run_id"

#--Octopus Variables in HTML file
$octProjectName="Project_Name"
$octReleaseNumber="Release_Number"
$octEnvName="Environment_Name"
$octReleaseNotes1="Release_Notes"
#$mailTo1="Octopus.Deployment.CreatedBy.EmailAddress"
#$mailTo2="#{Octopus.Deployment.CreatedBy.EmailAddress}"
$displayName1="CommitterName"
$displayEmail="CommitterEmail"
$date="Deployment_Created"
$octLogs="GitHubAction_Link"

#--PBI Step Names for Deployment process to pass into HTML file
$step="Install nuget package"
$step1="Install nuget package" + "<em> version " + $NUGET_PKG_VERSION + "</em>"
$step2="PBI - Create or update AAD Groups"
$step3="PBI - Create or update workspace"
$step4="PBI - Upload dataflows"
$step5="PBI - Upload reports"
$step6="PBI - Update datasets"
$step7="PBI - Datasets - Update contact list"
$step8="ServiceNow - Create a change request"
$step9="Deployment Status Email (success or failure)"

#--Release Notes from GitHub repository release-notes.md
#$releaseNotes= Get-Content "D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\release-notes.md"
$path = "D:\actions-runner\_work\$PROJECT_NAME\$PROJECT_NAME\Email-HTML.html"

#--Release Notes Draft
Install-Module -Name MarkdownToHTML -RequiredVersion '2.7.1'
$releasenotesmd = "D:\actions-runner\_work\$PROJECT_NAME\$PROJECT_NAME\release-notes.md"
Convert-MarkdownToHTML -Path $releasenotesmd -SiteDirectory HTML

$pathtoHTML = Get-ChildItem -Path D:\actions-runner\_work\$PROJECT_NAME -Filter release-notes.html -Recurse | %{$_.FullName} 
$releaseNotesFile = Get-Content $pathtoHTML
$pattern = "<body>(.*?)</body>"
$releaseNotes = [regex]::Match($releaseNotesFile,$pattern).Groups[1].Value
(Get-Content -path $path -Raw).replace("ReleaseNotes", $releaseNotes) | Set-Content -Path $path

#--Replacing Octopus variables with GitHub Environment Variables in HTML file
(Get-Content -path $path -Raw).replace($octProjectName, $PROJECT_NAME) | Set-Content -Path $path
(Get-Content -path $path -Raw).replace($octReleaseNumber, $NUGET_PKG_VERSION) | Set-Content -Path $path
(Get-Content -path $path -Raw).replace($octEnvName, $PBI_ENV) | Set-Content -Path $path
(Get-Content -path $path -Raw).replace($octReleaseNotes1, $releaseNotes) | Set-Content -Path $path
#(Get-Content -path $path -Raw).replace($mailTo1, $WORKSPACE_OWNERS) | Set-Content -Path $path
#(Get-Content -path $path -Raw).replace($mailTo2, "testemail.com") | Set-Content -Path $path
(Get-Content -path $path -Raw).replace($displayName1, $Github_Actor) | Set-Content -Path $path
(Get-Content -path $path -Raw).replace($displayEmail, $GithubUser_Email) | Set-Content -Path $path
(Get-Content -path $path -Raw).replace($date, $dateCreated) | Set-Content -Path $path

#Replacing Github Packages Link 
(Get-Content -path $path -Raw).replace("GitHubURL", $GitHubPackageLink) | Set-Content -Path $path

#--Passing Step list for Deployment Process into HTML file
(Get-Content -path $path -Raw).replace("step1", $step1 + " ") | Set-Content -Path $path
#(Get-Content -path $path -Raw).replace("<a href=gitHubPackageURL></a>", "<a href=$gitHubPackageURL></a>") | Set-Content -Path $path
(Get-Content -path $path -Raw).replace("step2", $step2) | Set-Content -Path $path
(Get-Content -path $path -Raw).replace("step3", $step3) | Set-Content -Path $path
(Get-Content -path $path -Raw).replace("step4", $step4) | Set-Content -Path $path
(Get-Content -path $path -Raw).replace("step5", $step5) | Set-Content -Path $path
(Get-Content -path $path -Raw).replace("step6", $step6) | Set-Content -Path $path
(Get-Content -path $path -Raw).replace("step7", $step7) | Set-Content -Path $path
(Get-Content -path $path -Raw).replace("step8", $step8) | Set-Content -Path $path
(Get-Content -path $path -Raw).replace("step9", $step9) | Set-Content -Path $path

#--Passing GitHub action deployment logs
(Get-Content -path $path -Raw).replace($octLogs, $deploymentLogUrl) | Set-Content -Path $path

#--Passing Steps with Status for Deployment Process into HTML file
(Get-Content -path $path -Raw).replace("NugetPackage", $step + " - " + $InstallNuget_Outcome + "<br>" + $NugetInstallErrorLogs) | Set-Content -Path $path
(Get-Content -path $path -Raw).replace("CreateAADGroup", $step2 + " - " + $CreateAADGroup_OutCome + "<br>" + $CreateAADGroupErrorLogs) | Set-Content -Path $path
(Get-Content -path $path -Raw).replace("CreateWorkspace", $step3 + " - " + $CreateWorkspace_Outcome + "<br>" + $CreateWorkspaceErrorLogs) | Set-Content -Path $path
(Get-Content -path $path -Raw).replace("DataflowsSet", $step4 + " - " + $DataflowsSet_Outcome + "<br>" + $DataflowsSetErrorLogs) | Set-Content -Path $path
(Get-Content -path $path -Raw).replace("ReportsUpload", $step5 + " - " + $ReportsUpload_Outcome + "<br>" + $ReportsUploadErrorLogs) | Set-Content -Path $path
(Get-Content -path $path -Raw).replace("DatasetsUpdate", $step6 + " - " + $DatasetsUpdate_Outcome + "<br>" + $DatasetsUpdateErrorLogs) | Set-Content -Path $path
(Get-Content -path $path -Raw).replace("DatasetsContactList", $step7 + " - " + $DatasetsContactList_Outcome + "<br>" + $DatasetsContactListErrorLogs) | Set-Content -Path $path
(Get-Content -path $path -Raw).replace("Service-Now", $step8 + " - " + $CreateChangeRequest_OutCome) | Set-Content -Path $path
(Get-Content -path $path -Raw).replace("EmailNotification", $step9 + " - " + $Current_Job) | Set-Content -Path $path

#Merged changes into main branch by
(Get-Content -path $path -Raw).replace("CommitterName", $Committer) | Set-Content -Path $path

#--Fetching the updated email content to verify
Get-Content $path

$subject = $PROJECT_NAME + " " + $NUGET_PKG_VERSION  + " to " + $PBI_ENV + " " +  $DeployStatus
$subject = $subject -replace [Environment]::NewLine,""
write-host "Email Subject:" $subject
$emailFrom = $POWER_BI_USERNAME
$Owners_List = $WORKSPACE_OWNERS.Replace(";"," ")

# Define email parameters
[String]$html = Get-Content -Path $path
$smtpServer = "smtprelay.bfl.local" #prod
#$smtpServer = "testrelay.bfl.local" #test 
$smtpPort = 25
$smtpFrom = $emailFrom
#$smtpTo = "tibi.thomas@beazley.com"
$smtpTo = $Owners_List
$messageSubject = $subject
$messageBody = $html

# Create email object
$email = @{
    To = $smtpTo
    From = $smtpFrom
    Subject = $messageSubject
    Body = $messageBody
    SmtpServer = $smtpServer
    Port = $smtpPort
    BodyAsHtml = $true
    #UseSsl = $true
}

# Send the email using the relay
Send-MailMessage @email -verbose