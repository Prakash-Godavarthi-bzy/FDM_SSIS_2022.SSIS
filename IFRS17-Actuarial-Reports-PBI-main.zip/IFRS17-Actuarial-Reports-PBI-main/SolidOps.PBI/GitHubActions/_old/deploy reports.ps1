function Import-PBIXToPowerBI{    
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$true)]$localPath, #path to (unencrypted!) PBIX file
        [Parameter(Mandatory=$true)]$graphToken, #token for the PowerBI API: https://docs.microsoft.com/en-us/power-bi/developer/walkthrough-push-data-get-token
        $groupId=$Null, #if a GUID of a O365 group / PowerBI workspace is supplied, import will be processed there
        $reportName=$Null, #optional, if not used, filename is used as report name
        $importMode="CreateOrOverwrite", #valid values: https://docs.microsoft.com/en-us/rest/api/power-bi/imports/postimportingroup#importconflicthandlermode
        [Switch]$wait #if supplied, waits for the import to complete by polling the API periodically, then returns importState value ("Succeeded" if completed correctly). Otherwise, just returns the import job ID
    )

    if(!$ReportName){
        $ReportName = (Get-Item -LiteralPath $localPath).BaseName
    }

    if($groupId){
        $uri = "https://api.powerbi.com/v1.0/myorg/groups/$groupId/imports"
    }else{
        $uri = "https://api.powerbi.com/v1.0/myorg/imports"
    }
    
    $boundary = "---------------------------" + (Get-Date).Ticks.ToString("x")
    $boundarybytes = [System.Text.Encoding]::ASCII.GetBytes("`r`n--" + $boundary + "`r`n")
    $request = [System.Net.WebRequest]::Create(($uri + "?datasetDisplayName=$ReportName&nameConflict=$importMode"))
    $request.ContentType = "multipart/form-data; boundary=" + $boundary
    $request.Method = "POST"
    $request.KeepAlive = $true
    $request.Headers.Add("Authorization", "$graphToken")
    $rs = $request.GetRequestStream()
    $rs.Write($boundarybytes, 0, $boundarybytes.Length);
    $header = "Content-Disposition: form-data; filename=`"temp.pbix`"`r`nContent-Type: application / octet - stream`r`n`r`n"
    $headerbytes = [System.Text.Encoding]::UTF8.GetBytes($header)
    $rs.Write($headerbytes, 0, $headerbytes.Length);
    $fileContent = [System.IO.File]::ReadAllBytes($localPath)
    $rs.Write($fileContent,0,$fileContent.Length)
    $trailer = [System.Text.Encoding]::ASCII.GetBytes("`r`n--" + $boundary + "--`r`n");
    $rs.Write($trailer, 0, $trailer.Length);
    $rs.Flush()
    $rs.Close()
    $response = $request.GetResponse()
    $stream = $response.GetResponseStream()
    $streamReader = [System.IO.StreamReader]($stream)
    $content = $streamReader.ReadToEnd() | convertfrom-json
    $jobId = $content.id
    $streamReader.Close()
    $response.Close()
    $header = @{
        'Authorization' = $graphToken}
    if($wait){
        while($true){
            $res = Invoke-RestMethod -Method GET -uri "$uri/$jobId" -UseBasicParsing -Headers $header
            if($res.ImportState -ne "Publishing"){
                Return $res.ImportState
            }
            Sleep -s 5
        }
    }else{
        Write-Output $($content.id)
    }    
}

function RefreshSchedule ([string]$GroupID, [string]$DataSetID, $bodyJson)
{
    $UserAccessToken = Get-PowerBIAccessToken
    $bearer = $UserAccessToken.Authorization.ToString()

    $headers = @{
        'Authorization' = "$bearer"
    }

    $url = [string]::Format("https://api.powerbi.com/v1.0/myorg/groups/{0}/datasets/{1}/refreshSchedule", $GroupID, $DataSetID);
    $rs = Invoke-WebRequest -Uri $url -Method PATCH -Headers $headers -ContentType "application/json" -Body $bodyJson -UseBasicParsing
}

#$hide = Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force

#if (!(Get-Module MicrosoftPowerBIMgmt)){
#	Install-Module -Name MicrosoftPowerBI#Mgmt -Force
#}

Import-Module MicrosoftPowerBIMgmt

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12;

$User = $OctopusParameters['Username']
$Pass = $OctopusParameters['Password']
$installPathKey = ("Octopus.Action[{0}].Output.Package.InstallationDirectoryPath" -f $installPackageStep)
$FolderLocation = $OctopusParameters[$InstallPathKey]
$DestinationWorkspaceName = $OctopusParameters['WorkspaceName']
$ReportsPath = $FolderLocation + "\" + $OctopusParameters['ReportsFolder']
if($OctopusParameters['ReportMapping']){
	$ReportMapping = ($OctopusParameters['ReportMapping'] | ConvertFrom-Json)
}
$ReportSuffix = $OctopusParameters['ReportSuffix']
$RefreshSchPath = $FolderLocation + "\" + $OctopusParameters['RefreshSchedulersFolder']

$securedPassword = ConvertTo-SecureString $Pass -AsPlainText -Force
$pbiServiceAccountCred = New-Object System.Management.Automation.PSCredential ($User, $securedPassword)

Connect-PowerBIServiceAccount -Credential $pbiServiceAccountCred

$destinationWorkspace = Get-PowerBIWorkspace -Name $DestinationWorkspaceName;
$groupId = $destinationWorkspace.Id
$UserAccessToken = Get-PowerBIAccessToken
$bearer = $UserAccessToken.Authorization.ToString()

if ($destinationWorkspace) {
    foreach ($File in (Get-ChildItem $ReportsPath\*.pbix)) {
        Write-Output "Processing $($File.FullName)"
        
        # For each file, either use the mapping, append suffix or use the basename by default
        # Implies that if you want to mix suffix and mapping across all reports, mapping entries must include suffix in the mapping output
        $ReportName = $null
        if($ReportMapping."$($File.BaseName)") {
        	$ReportName = $ReportMapping."$($File.BaseName)"
        } elseif($ReportSuffix) {
        	$ReportName = $File.BaseName + $reportSuffix
        }
        
        Write-Output "$($File.BaseName) name calculated as $ReportName"
        Import-PBIXToPowerBI -localPath "$($File.FullName)" -reportname $ReportName -groupId $groupId -graphToken $bearer -wait
        
        $rsPath = $RefreshSchPath + "\" + "$($File.BaseName)" + ".json"
        
        if(Test-Path $rsPath)
        {
        	# refresh schedule file must have the same basename as report
        	Write-Output "Adding refresh schedule"
			$dsId = (Get-PowerBIDataset -WorkspaceId $groupId.Guid | Where Name -eq "$($File.BaseName)").Id.Guid
        	RefreshSchedule -GroupID $groupId.Guid -DataSetID $dsId -bodyJson (Get-Content $rsPath)
        }
    }
}
else 
{
    Write-Error [string]::Format("Destination workspace ""{0}"" not found!", $DestinationWorkspaceName)
}
