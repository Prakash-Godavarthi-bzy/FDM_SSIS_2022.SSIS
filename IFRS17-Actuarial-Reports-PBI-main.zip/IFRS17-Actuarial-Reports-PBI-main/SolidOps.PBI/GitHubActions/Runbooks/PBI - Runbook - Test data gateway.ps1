[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12;

function Load-Module ($m) {

    # If module is imported say that and do nothing
    if (Get-Module | Where-Object {$_.Name -eq $m}) {
        Write-Verbose "Module $m is already imported."
    }
    else {

        # If module is not imported, but available on disk then import
        if (Get-Module -ListAvailable | Where-Object {$_.Name -eq $m}) {
            Import-Module $m -Verbose
        }
        else {

            # If module is not imported, not available on disk, but is in online gallery then install and import
            if (Find-Module -Name $m | Where-Object {$_.Name -eq $m}) {
                Install-Module -Name $m -Force -Verbose -Scope CurrentUser
                Import-Module $m -Verbose
            }
            else {

                # If module is not imported, not available and not in online gallery then abort
                Write-Verbose "Module $m not imported, not available and not in online gallery, exiting."
                EXIT 1
            }
        }
    }
}

function Connect-PBI {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$user,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$pass
    )

    # Connect to PBI
    $securedPassword = ConvertTo-SecureString $Pass -AsPlainText -Force
    $pbiServiceAccountCred = New-Object System.Management.Automation.PSCredential ($User, $securedPassword)
    Connect-PowerBIServiceAccount -Credential $pbiServiceAccountCred
    Write-Verbose "Connected $user to Power BI Service"
}

function Get-DatasetGateway {
    [CmdletBinding()]
    Param (
        # Dataset id
        [Parameter(Mandatory=$true)]
        [string]
        $id,    
        # Workspace ID
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        # gateway name
        [Parameter(Mandatory=$true)]
        [string]
        $name
    )

    $url = "https://api.powerbi.com/v1.0/myorg/groups/$($workspaceId)/datasets/$($id)/Default.DiscoverGateways"
    Write-Verbose $url
    $accessToken = Get-PowerBIAccessToken
    $bearer = $accessToken.Authorization.ToString()

    $headers = @{
        'Authorization' = "$bearer" 
    }
    $gateways = Invoke-RestMethod -Uri $url -Method GET -Headers $headers
    $gatewas
    $gateway = $gateways.value | Where-Object {$_.name -eq $name}
    $gateway
    # Get gatewayID based on OD parameter with gateway name
    if($($gateway.id)) {
        Write-Verbose "Gateway Id : $($gateway.id)"
    } else {
        Write-Error "Gateway not found or missing permissions."
        #exit
    }

    return $gateway
}

function Get-Gateway {
    [CmdletBinding()]
    param (
        # Gateway name
        [Parameter(Mandatory=$true)]
        [string]
        $gatewayName     
    )
    # GET https://api.powerbi.com/v1.0/myorg/gateways

    $url = "gateways"
    $gateways = Invoke-PowerBIRestMethod -Url $url -Method GET
    Write-Verbose $gateways
    $gateway = $gateways.value | Where-Object {$_.name -eq $gatewayName}
    Write-Verbose $gateway
    # Get gatewayID based on OD parameter with gateway name
    if($($gateway.id)) {
        Write-Verbose "[Get-Gateway] Gateway Id : $($gateway.id)"
    } else {
        throw "[Get-Gateway] Gateway not found or missing permissions."
    }

    return $gateway
    
}

function Get-Gateway2 {
    [CmdletBinding()]
    param (
        # Gateway name
        [Parameter(Mandatory=$true)]
        [string]
        $gatewayName     
    )
    # GET https://api.powerbi.com/v1.0/myorg/gateways

    $accessToken = Get-PowerBIAccessToken
    $bearer = $accessToken.Authorization.ToString()

    $headers = @{
        'Authorization' = "$bearer" 
    }
    $url = "https://api.powerbi.com/v1.0/myorg/gateways"

    $gateways = Invoke-RestMethod -Uri $url -Method GET -Headers $headers
    Write-Verbose $gateways
    $gateway = $gateways.value | Where-Object {$_.name -eq $gatewayName}
    Write-Verbose $gateway
    # Get gatewayID based on OD parameter with gateway name
    if($($gateway.id)) {
        Write-Verbose "[Get-Gateway] Gateway Id : $($gateway.id)"
    } else {
        throw "[Get-Gateway] Gateway not found or missing permissions."
    }

    return $gateway
    
}

Load-Module "MicrosoftPowerBIMgmt"

$User = $OctopusParameters['pbi.username']
$Pass = $OctopusParameters['pbi.password']
$DataGatewayName = $OctopusParameters['pbi.datagateway.name']
$WorkspaceName = $OctopusParameters['pbi.workspace']


Connect-PBI -user $User -pass $Pass 

Get-Gateway2 -gatewayName $DataGatewayName
Get-Gateway -gatewayName $DataGatewayName


#Get-DatasetGateway -id "e90b889e-39b5-4ae6-b14c-00bee63c3158" -workspaceId "234f1bbd-39be-40bb-9de1-17565a74b133" -name $DataGatewayName -Verbose