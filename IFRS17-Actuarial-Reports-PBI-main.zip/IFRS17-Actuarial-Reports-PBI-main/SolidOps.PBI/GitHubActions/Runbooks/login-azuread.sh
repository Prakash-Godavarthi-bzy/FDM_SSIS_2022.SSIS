$POWER_BI_USERNAME = $env:POWER_BI_USERNAME
$POWER_BI_PASSWORD = $env:POWER_BI_PASSWORD

secure_password=$(echo -n "$POWER_BI_PASSWORD" | iconv -t utf16le | base64 -w 0)

# Log in using the service principal credentials
pwsh -Command "Connect-AzureAD -user $POWER_BI_USERNAME -pass $POWER_BI_PASSWORD -Credential (New-Object PSCredential $POWER_BI_USERNAME, (ConvertTo-SecureString $secure_password -AsPlainText -Force))"

# Display information about the authenticated account
pwsh -Command "Get-AzureADTenantDetail"