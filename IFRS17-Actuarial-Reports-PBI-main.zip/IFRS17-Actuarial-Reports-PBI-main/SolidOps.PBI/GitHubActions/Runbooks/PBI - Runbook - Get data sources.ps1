[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12;

$User = $OctopusParameters['pbi.username']
$Pass = $OctopusParameters['pbi.password']

$GatewayName = $OctopusParameters['pbi.datagateway.name']

Connect-PBI -user $User -pass $Pass 

$gateway = Get-Gateway -gatewayName $GatewayName
$gatewayId = "$($gateway.id)"
Write-Verbose $gatewayId

$ds = Get-Datasources -gatewayId $gatewayId
$ds.value | Select-Object datasourceName,connectionDetails | Format-List
#$ds.value | Format-List