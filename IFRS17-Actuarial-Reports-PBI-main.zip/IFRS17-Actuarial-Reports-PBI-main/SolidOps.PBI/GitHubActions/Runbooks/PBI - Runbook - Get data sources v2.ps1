function Get-DataSourcesv2 {#([string]$id) {
    param(
       # GatewayId
       [Parameter(Mandatory=$true)]
       [string]
       $gatewayId
    )
    # Get data sources 
    # GET https://api.powerbi.com/v1.0/myorg/gateways/{gatewayId}/datasources

    #$url = "https://api.powerbi.com/v1.0/myorg/gateways/$gatewayId/datasources"
    $url = "https://api.powerbi.com/v2.0/myorg/gateways/$gatewayId/datasources"

    $url = "https://api.powerbi.com/v2.0/myorg/me/gatewayclusters/$gatewayId/datasources"
    $accessToken = Get-PowerBIAccessToken
    $bearer = $accessToken.Authorization.ToString()

    $headers = @{
        'Authorization' = "$bearer"
    }

    Write-Verbose "[Get-DataSources] URL $url"
    $dataSources = Invoke-RestMethod -Uri $url -Method GET -Headers $headers
    Write-Verbose "[Get-DataSources] finished"
    return $dataSources
}

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12;

$User = $OctopusParameters['pbi.username']
$Pass = $OctopusParameters['pbi.password']

$GatewayName = $OctopusParameters['pbi.datagateway.name']

Connect-PBI -user $User -pass $Pass 

$gateway = Get-Gateway -gatewayName $GatewayName
$gatewayId = "$($gateway.id)"
Write-Verbose $gatewayId

$ds = Get-DataSourcesv2 -gatewayId $gatewayId
$ds.value | Select-Object datasourceName,credentialDetails | Format-List
#$ds.value | Format-List