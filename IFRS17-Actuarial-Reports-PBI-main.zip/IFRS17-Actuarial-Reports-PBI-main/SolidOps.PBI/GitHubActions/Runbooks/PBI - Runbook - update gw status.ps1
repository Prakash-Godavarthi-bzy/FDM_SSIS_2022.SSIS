[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12;

$User = $OctopusParameters['pbi.username']
$Pass = $OctopusParameters['pbi.password']

Connect-PBI -user $User -pass $Pass 


$url = "https://api.powerbi.com/v2.0/myorg/me/gatewayClusters/fecdd2f3-8289-4747-9fd0-7dcfaed1cf94/status"

$statusBody = Invoke-SolidOpsPBIRestMethod -url $url -method Get

$rows = @()

$gatewayId = "fecdd2f3-8289-4747-9fd0-7dcfaed1cf94"
$clusterStatus = $statusBody.clusterStatus
$lastStatusOn = Get-Date -format "dd/MM/yyyy HH:mm:ss" 

<#
NodeStatus
MemberGatewayName
ErrorCode
ErrorMessage
LastStatusOn
#>
if($statusBody.memberGatewayErrorMessages.Count -gt 0) {
    foreach ($member in $statusBody.memberGatewayErrorMessages) {
        $rows += @{
            GatewayClusterID = $gatewayId
            ClusterStatus = $clusterStatus
            NodeStatus = "Error"
            MemberGatewayName = $member.memberGatewayName
            ErrorCode = $member.errorCode
            ErrorMessage = $member.errorMessage
            LastStatusOn = $lastStatusOn
        }
    }

} else {
    $rows += @{
        GatewayClusterID = $gatewayId
        ClusterStatus = $clusterStatus
        NodeStatus = "Live"
        MemberGatewayName = $null
        ErrorCode = $null
        ErrorMessage = $null
        LastStatusOn = $lastStatusOn
    }
}

$body = @{
	rows = $rows
}

# POST https://api.powerbi.com/v1.0/myorg/groups/{groupId}/datasets/{datasetId}/tables/{tableName}/rows
$url = "https://api.powerbi.com/v1.0/myorg/groups/a2ba36a0-dd33-47d1-bb70-cd6640997e2a/datasets/6fc1d49c-32c2-4a7a-a4ec-c3977a137c08/tables/Gateway/rows"

Invoke-SolidOpsPBIRestMethod -url $url -method Post -postBody $body