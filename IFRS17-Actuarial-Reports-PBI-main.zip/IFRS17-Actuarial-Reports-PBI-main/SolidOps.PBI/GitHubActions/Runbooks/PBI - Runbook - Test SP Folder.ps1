
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$user = $OctopusParameters["pbi.username"]
$pass = $OctopusParameters["pbi.password"]

$clientId = $OctopusParameters["pbi.client.sharepoint.id"]
$resource =  $OctopusParameters["pbi.client.sharepoint.resource"]

#$token = Get-MicrosoftToken -user $user -pass $pass -resource $datasource.connectionDetails.path
$token = Get-MicrosoftToken2 -user $user -pass $pass -clientId $clientId -resource $resource
Write-Host $token.access_token
