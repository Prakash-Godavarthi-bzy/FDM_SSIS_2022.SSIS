$pbigName = $env:pbigName
$groupName =  $env:groupName
$groups = Get-ADGroupMember -Identity $groupName  | Select-Object name
if ($groups.Length -eq 0) {
	Write-Warning "[SolidOps.PBI.AD] Empty group list. Check permissions for the OD tentacle service account"
}

$member = $groups | Where-Object { $_.name -eq $pbigName }

if ($null -eq $member) {
    Write-Error "$pbigName not found in group $groupName"
} else {
    Write-Information "$pbigName found in group $groupName"
    Write-Verbose "$pbigName found in group $groupName"
}
