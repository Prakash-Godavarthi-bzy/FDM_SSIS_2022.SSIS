#Load-Module "SqlServer" 


<#
$Server = $OctopusParameters['pbi.datasource.server']
$Database = $OctopusParameters['pbi.datasource.database']
$User = $OctopusParameters['pbi.datasource.username']
$Password = $OctopusParameters['pbi.datasource.password']

Load-Module "Invoke-SqlCmd2"
#>

<#
$securedPassword = ConvertTo-SecureString '$($Password)' -AsPlainText -Force
$cred = New-Object System.Management.Automation.PSCredential ($User, $securedPassword)

$cmd = Invoke-Sqlcmd2 -Query "SELECT GETDATE() AS TimeOfQuery;" -ServerInstance $Server -As PSObject -Credential $cred
Write-Host "command: "
Write-Host $cmd
#>

<#
$securedPassword = ConvertTo-SecureString '$Password' -AsPlainText -Force
$creds = New-Object System.Management.Automation.PSCredential ($User, $securedPassword)

#$creds = New-Object System.Management.Automation.PSCredential $User,$Password
$pwd = $($Creds.GetNetworkCredential().Password)
$uid = $($creds.GetNetworkCredential().UserName)

#$cmd = Invoke-Sqlcmd -Query "SELECT GETDATE() AS TimeOfQuery;" -ServerInstance $Server -Username $User -Password $pwd
#Write-Host "command: "
#Write-Host $cmd
#>
<#
Try {
    
    $connectionString = "Server=$Server;Database=$Database;Integrated Security=true;User Id='$User';Password='$Password';"
    Write-Host "Conn: $connectionString"
    $connection = New-Object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString = $connectionString
    $connection.Open()
    $connection.Close()

} catch {
    Write-Error $_ 
}#>