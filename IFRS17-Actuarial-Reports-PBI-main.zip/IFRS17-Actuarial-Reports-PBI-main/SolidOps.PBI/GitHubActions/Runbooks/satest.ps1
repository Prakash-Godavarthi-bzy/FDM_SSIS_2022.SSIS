#!/usr/bin/env pwsh
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
#Install-Module PowerShellGet -SkipPublisherCheck -Repository 'PSGallery' -Force -Verbose
#Register-PSRepository -Default -Verbose
#Set-PSRepository -Name "PSGallery" -InstallationPolicy Trusted

$POWER_BI_USERNAME = $env:POWER_BI_USERNAME
$PBI_PASSWORD = $env:PBI_PASSWORD

 #Import-Module /runner/_work/CoE-PowerBIMigration-PBI/CoE-PowerBIMigration-PBI/SolidOps.PBI/OctopusDeploy/Modules/SolidOps.PBI.psm1
 Install-Module -Name AzureAD -Force -Scope CurrentUser -Repository 'PSGallery' -verbose
 #Install-Module -Name AzureAD -Force 
 #Import-Module AzureAD

#  Find-Module -Name AzureAD | Where-Object { $_.Name -eq "AzureAD" }
 #ls /home/runner/.local/share/powershell/Modules/AzureAD/2.0.2.182/
#  Import-Module /home/runner/.local/share/powershell/Modules/AzureAD/2.0.2.182/AzureAD.psd1

# Install-Module Az.Accounts -Force -Scope CurrentUser -Repository 'PSGallery' -verbose
# Import-Module Az.Accounts

# Install-Module -Name AzureADPreview -Force -Scope CurrentUser -Repository 'PSGallery' -verbose
# Import-Module  -Name AzureADPreview 

# Install-Module -Name AzureAD.Standard.Preview -RequiredVersion 0.0.0.10 -Force 
# Get-Module -Name AzureAD.Standard.Preview | Where-Object { $_.Name -eq "AzureAD.Standard.Preview" } | Import-Module -Name AzureAD.Standard.Preview
 
 #Import-Module /runner/_work/CoE-PowerBIMigration-PBI/CoE-PowerBIMigration-PBI/SolidOps.PBI/OctopusDeploy/Modules/AzureAD.psm1

$securedPassword = ConvertTo-SecureString $PBI_PASSWORD -AsPlainText -Force
$pbiServiceAccountCred = New-Object System.Management.Automation.PSCredential ($POWER_BI_USERNAME, $securedPassword)
Connect-AzureAD -Credential $pbiServiceAccountCred -verbose

# Set-AzureADGroups -groupConfig $groupConfig `
#     -envCode $envCode `
#     -user $POWER_BI_USERNAME `
#     -pass $POWER_BI_PASSWORD `
#     -clientId $ClientId `
#     -resource $Resource `
#     -grantType $grantType
