[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$UserType = $env:USER_TYPE
$envCode = $env:PBI_ENV
$ClientId = $env:MICROSOFT_GRAPH_CLIENT_ID
$Resource = $env:MICROSOFT_GRAPH_RESOURCE
$NUGET_PKG_VERSION = $env:NUGET_PKG_VERSION
$POWER_BI_USERNAME = $env:POWER_BI_USERNAME
$POWER_BI_PASSWORD = $env:POWER_BI_PASSWORD
$REPO_NAME = $env:REPO_NAME

Start-Transcript -Path "D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\CreateAADGroup-Logs.txt"

$TenantId = $env:TENANTID #clientid 
$ClientSecret = $env:CLIENTSECRET #$Pass
$ApplicationId = $env:APPLICATIONID #$User

$FolderLocation = "C:\Program Files\PackageManagement\NuGet\Packages\$REPO_NAME.$NUGET_PKG_VERSION"

Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.psm1

try {
   Load-Module AzureAD
   Load-Module Az.Accounts
}
catch {  
   Import-Module AzureAD 
   Import-Module Az.Accounts
}

Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\AzureAD.psm1
Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.Workspaces.psm1

# Get group permissions
$groupConfig = Get-WorkspaceConfig -Path $FolderLocation
$grantType = "password"
if($UserType -eq "ServiceAccount") {
    $grantType = "password"
} elseif ($UserType -eq "ServicePrincipal") {
    $grantType = "client_credentials" 
} 

Connect-AAD -user $ApplicationId -pass $ClientSecret -userType $UserType -tenantId $TenantId

Import-Module D:\actions-runner\_work\$REPO_NAME\$REPO_NAME\SolidOps.PBI\GitHubActions\Modules\SolidOps.PBI.psm1

Set-AzureADGroups -groupConfig $groupConfig `
    -envCode $envCode `
    -user $ApplicationId `
    -pass $ClientSecret `
    -clientId $ClientId `
    -resource $Resource `
    -grantType $grantType

Stop-Transcript