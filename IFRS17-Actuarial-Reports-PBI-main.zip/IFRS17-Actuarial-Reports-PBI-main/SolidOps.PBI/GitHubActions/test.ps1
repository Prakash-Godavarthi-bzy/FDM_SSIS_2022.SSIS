[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Replace-Tokens
{
  param(
		[string]$inputFile,
		[string]$outputFile,
		[string]$token,
		[string]$tokenValue
	)

	(Get-Content $inputFile) | foreach-object { $_ -replace $token, $tokenValue } | Set-Content $outputFile
	Write-Host "Processed: " + $inputFile
}

$OctopusParameters = @{
    'Octopus.Action[Install nuget package].Output.Package.InstallationDirectoryPath' = 'C:\git\poc-DM-PBI\src'
    'param.pbi.workspace' = 'PoC DM - SYS'
    #'param.pbi.workspace' = 'PoC DM - SYS'
    'param.pbi.report.suffix' = ' - SYS'
    #'param.pbi.parameters.ODSServer' = 'UKDVDB123\\SYS'
    #'param.pbi.parameters.ODSDatabase' = 'BeazleyIntelligenceODS'
    #'param.pbi.parameters.GPData.path' = 'https://sys.api.crm11.dynamics.com/api/data/v9.1/'
    #'param.pbi.parameters.GPData.resource' = 'https://sys.api.crm11.dynamics.com/'
    #'param.pbi.datagateway.name' = 'Beazley On Premises Data Gateway'
    'param.pbi.datagateway.id' = 'fecdd2f3-8289-4747-9fd0-7dcfaed1cf94'
    'Octopus.Environment.Name' = 'System Test'
    #'param.pbi.parameters.DataContractServer' = 'DBS-ulw-BeazleyIntelligenceDataContract-SYS,13232'
    #'param.pbi.parameters.DataContractDatabase' = 'BeazleyIntelligenceDataContract'
}

$InstallStepName = "Install nuget package"

$dir = $OctopusParameters['Octopus.Action[Install nuget package].Output.Package.InstallationDirectoryPath']
$workspacePath = "$dir\Config\workspace.json"
$reportsPath = "$dir\Config\reports.json"

if($false) {
    foreach ($key in $OctopusParameters.Keys) {
        $token = "#{$key}"    
        $value = $OctopusParameters[$key]
        Write-Host "$token = $value"
        Replace-Tokens -inputFile $workspacePath -outputFile $workspacePath -token $token -tokenValue $value
        Replace-Tokens -inputFile $reportsPath -outputFile $reportsPath -token $token -tokenValue $value
    }
}

Import-Module '.\Modules\SolidOps.PBI.psm1'
Import-Module '.\Modules\SolidOps.PBI.Dataflows.psm1'
Import-Module '.\Modules\SolidOps.PBI.Reports.psm1'
#Import-Module '.\Steps\PBI-Reports-Upload.ps1'

Connect-PBI
#New-PaginatedReport -filePath 'C:\git\poc-DM-PBI\src\Paginated\FTS\FTS-corepolicyview.rdl' `
    #-workspaceId 'a2ba36a0-dd33-47d1-bb70-cd6640997e2a' -Verbose

   

    $workspaceId = 'a2ba36a0-dd33-47d1-bb70-cd6640997e2a'
    $filePath = 'C:\git\poc-DM-PBI\src\Paginated\FTS\FTS-corepolicyview.rdl'
    $fileName = 'FTS-corepolicyview.rdl'
    
    New-PowerBIReport -Path $filePath `
    -Name $reportName `
    -WorkspaceId $workspaceId `
    -ConflictAction Abort

 # Get file content and create body
 $fileName = [IO.Path]::GetFileName($filePath)
 $boundary = [guid]::NewGuid().ToString()
$fileBytes = [System.IO.File]::ReadAllBytes($filePath)
$encoding = [System.Text.Encoding]::GetEncoding("iso-8859-1")
#$encoding = [System.Text.Encoding]::GetEncoding("utf-8")
$fileBody = $encoding.GetString($fileBytes)
#$fileBody = Get-Content -Path $filePath -Encoding UTF8

 $url = "https://api.powerbi.com/v1.0/myorg/groups/$workspaceId/imports?datasetDisplayName=$fileName&nameConflict=Abort"

 $body = @"
--$boundary 
Content-Disposition: form-data; name="$($fileName)"; filename="$($fileName)"
Content-Type: application/rdl

$($fileBody)
--$boundary--
"@

 $response = Invoke-SolidOpsPBIRestMethod -url $url -method Post -postBody $body -contentType "multipart/form-data; boundary=--$boundary" -Verbose

$response

#Import-Module '.\SolidOps.PBI.Reports.psm1'
#Import-Module '.\SolidOps.PBI.Datasets.psm1'
#Import-Module '.\Reports\PBI-Reports-Create.ps1'

#Load-Module "AzureAD"
#Import-Module '.\create-datasource.ps1'
#Import-Module '.\PBI - Create Report.ps1'
#Import-Module '.\PBI - Runbook - Test Dynamics Connection.ps1'

#Import-Module '.\PBI - Create Workspace.ps1'


#Import-Module '.\gateway-status.ps1'



#Import-Module '.\test-refresh-token.ps1'

