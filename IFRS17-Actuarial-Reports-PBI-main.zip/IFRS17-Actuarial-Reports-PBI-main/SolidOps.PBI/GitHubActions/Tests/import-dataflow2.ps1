[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
function Add-PowerBIImport {
    [CmdletBinding()]
    param (
         # report item
         [Parameter(Mandatory = $true)]
         $item,
         # workspace object
         [Parameter(Mandatory = $true)]
         [string]
         $workspaceId
    )
    #2021: https://stackoverflow.com/questions/68677742/multipart-form-data-file-upload-with-powershell

    Write-Verbose "[Add-PowerBIImport] begin"
    $path = "$($item.FullName)"

    $model = "model.json"
    Write-Verbose "model: $model"

    $url = "https://api.powerbi.com/v1.0/myorg/groups/$($workspaceId)/imports?datasetDisplayName=$($model)"
    Write-Host "url: $url"
    
    # $boundary = [System.Guid]::NewGuid().ToString()
    # $FilePath = $path
    # $TheFile = [System.IO.File]::ReadAllBytes($FilePath)
    # $TheFileContent = $enc.GetString($TheFile)
    
    # $LF = "`r`n"
    # $bodyLines = (
    #     "--$boundary",
    #     "Content-Disposition: form-data; name=`"Description`"$LF",
    #     "This is a file I'm uploading",
    #     "--$boundary",
    #     "Content-Disposition: form-data; name=`"`"; filename=`"model.json`"",
    #     "Content-Type: application/json$LF",
    #     $TheFileContent,
    #     "--$boundary--$LF"
    # ) -join $LF

    $accessToken = Get-PowerBIAccessToken
    $bearer = $accessToken.Authorization.ToString()

    $headers = @{
        Authorization = $bearer
    }

    $response = Invoke-RestMethod -Uri $url `
        -Method Post `
        -InFile $path `
        -ContentType "multipart/form-data" `
        -Headers $headers

    # $response = Invoke-RestMethod $url `
    #     -Method POST `
    #     -ContentType "multipart/form-data; boundary=`"$boundary`"" `
    #     -Body $bodyLines `
    #     -Headers $headers

    #$importJob = $response | ConvertFrom-Json

    Write-Host $response
}


function Get-ImportStatus {
    [CmdletBinding()]
    param (
        # workspace object
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceId,
        # workspace object
        [Parameter(Mandatory = $true)]
        [string]
        $importId
    )
    
    # https://api.powerbi.com/v1.0/myorg/groups/f612dd43-675a-42dc-a661-7577ba675870/imports/013a43e1-eab1-4861-8e0f-ea3250399b58

    $url = "https://api.powerbi.com/v1.0/myorg/groups/$($workspaceId)/imports/$($importId)"
    
    $importState = "Publishing"
    $status = $null
    $counter = 0
    
    <#
    {
        "error": {
            "code": "PackageNotFoundError",
            "pbi.error": {
                "code": "PackageNotFoundError",
                "parameters": {},
                "details": []
            }
        }
    }
    #>

    while ($importState -eq "Publishing") {
        $status = Invoke-RestMethod -url $url `
            -method Get 

        $statusJson = $status | ConvertTo-Json
        Write-Verbose "status $($importId): $($statusJson)"
        $importState = $status.importState
        if ($importState -eq "Failed") {
            Write-Error $status
        } 

        if ($importState -eq "Succeeded") {
            return $status
        } 

        if ($importState -ne "Succeeded") {
            $counter++
            Start-Sleep -s 10
        }

        if($counter -gt 6) {
            $importState = "unknown"
            Write-Warning "[Get-ImportStatus] unknown import state $($importState) for $importId in workspace $workspaceId"
            Write-Verbose $status
            Write-Error $importState
        }
    }

    return $null

    
}

function Add-Import {
    [CmdletBinding()]
    param (
         # report item
         [Parameter(Mandatory = $true)]
         [string]
         $path,
         # workspace object
         [Parameter(Mandatory = $true)]
         [string]
         $workspaceId,
         [ValidateSet('Abort', 'CreateOrOverwrite', 'GenerateUniqueName', 'Ignore', 'Overwrite')]
         [string]
         $nameConflict = "Ignore"
    )
    
    $ErrorActionPreference = 'Stop'

    $model = "model.json"
    Write-Verbose "model: $model"

    $url = "https://api.powerbi.com/v1.0/myorg/groups/$($workspaceId)/imports?datasetDisplayName=$($model)&nameConflict=$($nameConflict)"
    Write-Host "url: $url"

    $fieldName = 'file'
    $filePath = $path

    $accessToken = Get-PowerBIAccessToken
    $bearer = $accessToken.Authorization.ToString()

    Try {
        Add-Type -AssemblyName 'System.Net.Http'

        $client = New-Object System.Net.Http.HttpClient
        $client.DefaultRequestHeaders.Add("Authorization", $bearer)

        $content = New-Object System.Net.Http.MultipartFormDataContent
        $fileStream = [System.IO.File]::OpenRead($filePath)
        $fileName = [System.IO.Path]::GetFileName($filePath)
        $fileContent = New-Object System.Net.Http.StreamContent($fileStream)
        $content.Add($fileContent, $fieldName, $fileName)

        $result = $client.PostAsync($url, $content).Result
        #$code = $result.EnsureSuccessStatusCode()

        Write-Verbose "Success"
        $result = $result.Content.ReadAsStringAsync().GetAwaiter().GetResult()
        Write-Verbose $result
        $resultJson = $result | ConvertFrom-Json
        
        #{"error":{"code":"Conflict","message":"Dataflow 'Environments' already exists"}}
        if($resultJson.error) {
            $message = $resultJson.error.code + ": " + $resultJson.error
            Write-Error $message
        }

        $importId = $resultJson.id
        Write-Verbose "Job Id: $importId"
        return $importId
    }
    Catch {
        Write-Error $_
        exit 1
    }
    Finally {
        if ($null -ne $client) { $client.Dispose() }
        if ($null -ne $content) { $content.Dispose() }
        if ($null -ne $fileStream) { $fileStream.Dispose() }
        if ($null -ne $fileContent) { $fileContent.Dispose() }
    }
}

$path = "C:\git\DM-DataGovernance-PBI\src\Dataflows\Environments.json"
$item = Get-Item "C:\git\DM-DataGovernance-PBI\src\Dataflows\Environments.json"
$workspaceId = "f612dd43-675a-42dc-a661-7577ba675870"

Write-Host -ForegroundColor White "Connect to PowerBI service";
Login-PowerBIServiceAccount
Write-Host -ForegroundColor White "Connected to PowerBI service";

#Add-PowerBIImport -item $item -workspaceId $workspaceId
$importId = Add-Import -item $item -workspaceId $workspaceId

Write-Host $importId