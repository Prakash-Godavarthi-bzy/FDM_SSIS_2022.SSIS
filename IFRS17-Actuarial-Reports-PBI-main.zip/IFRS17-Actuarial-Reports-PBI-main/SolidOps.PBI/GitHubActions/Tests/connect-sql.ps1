
$User = $OctopusParameters['pbi.datasource.username']
$Pass = $OctopusParameters['pbi.datasource.password']
$Database = $OctopusParameters['pbi.datasource.database']
$Server = $OctopusParameters['pbi.datasource.server']

$SQLCommand = "SELECT 1"
$SQLCommand = $SQLCommand -replace "'","''"

$MyCommand = '
$Connection = New-Object System.Data.SqlClient.SQLConnection
$Connection.ConnectionString = ''Data Source=' + $Server + ';Integrated Security=' + $true + ';Initial Catalog=' + $Database + '''

$Command = New-Object System.Data.SqlClient.SqlCommand(''' + $SQLCommand + ''',$Connection)
$Connection.Open()

$Adapter = New-Object System.Data.SqlClient.SqlDataAdapter $Command
$Dataset = New-Object System.Data.DataSet
$Adapter.Fill($Dataset) | Out-Null

$Connection.Close()
$Dataset.Tables'


$ProcessStartInfo = New-Object System.Diagnostics.ProcessStartInfo
$ProcessStartInfo.CreateNoWindow = $true
$ProcessStartInfo.UseShellExecute = $false
$ProcessStartInfo.RedirectStandardOutput = $true
$ProcessStartInfo.RedirectStandardError = $true
$ProcessStartInfo.FileName = 'powershell.exe'
$ProcessStartInfo.Arguments = @("-Command",$MyCommand)
$ProcessStartInfo.UserName = $User
#$ProcessStartInfo.Domain = $Domain
$ProcessStartInfo.Password = $Pass
$Process = New-Object System.Diagnostics.Process
$Process.StartInfo = $ProcessStartInfo
[void]$Process.Start()
$StandardOutput = $Process.StandardOutput.ReadToEnd()
$StandardError = $Process.StandardError.ReadToEnd()
$Process.WaitForExit()

if ($Process.ExitCode -eq 1) {

    throw $StandardError

}
else {

    Write-Output $StandardOutput

}