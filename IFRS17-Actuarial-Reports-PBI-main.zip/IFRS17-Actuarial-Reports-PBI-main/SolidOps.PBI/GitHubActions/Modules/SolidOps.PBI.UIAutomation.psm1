

[Flags()]
enum Weekdays
{
    Sunday = 1
    Monday = 2
    Tuesday = 4
    Wednesday = 8
    Thursday = 16
    Friday = 32
    Saturday = 64
}

function Get-UIWeekdays {
    [CmdletBinding()]
    param (
        # weekDays
        [Parameter(Mandatory=$true)]
        [string]
        $weekDays
    )

    Write-Verbose "Week days: $weekDays"
   
    $days = $weekDays -Split ' '
    $flagInt = 0

    foreach ($day in $days) {
        Write-Verbose "Processing $day"

        #$x = [Int]([Weekdays]$day)
        #Write-Verbose "Day: $x"

        $flagInt +=  [Int]([Weekdays]$day)
    }

    return $flagInt
   
}



function Set-DatasetRefreshContactList {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        # Reports path
        [Parameter(Mandatory=$true)]
        [string]
        $datasetId,
        # developers; workspace owners
        #[Parameter(Mandatory=$true)]
        $contacts
    )


    $devs = $global:SolidOpsSession.Developers
    $contactArray = $contacts.Split(";")
    $devArray = $devs.Split(";")

    $contactList = @()

    foreach ($dev in $devArray) {
        $dev = Set-CleanEmail -email $dev -functionName "Set-DatasetRefreshContactList" -variableName "pbi.workspace.developers"
        if($dev) {
            $dev = $dev.trim()
            $contact = $contactList | Where-Object {$_.emailAddress -eq $dev}


            if($contact) {
                Write-Verbose "[Set-DatasetRefreshContactList] $dev (dev) already a contact"
            } else {
                $developer = Get-AzureADUser -Filter "userPrincipalName eq '$dev'"
                if($developer) {
                    $contactList += @{
                        displayName         = $developer.displayName
                        objectId            = $developer.objectId
                        userPrincipalName   = $condevelopertact.userPrincipalName
                        isSecurityGroup     = $false
                        objectType          = 1
                        groupType           = 0
                        addAppId            = $null
                        emailAddress        = $developer.mail
                    }
                } else {
                    Write-Warning "[Set-DatasetRefreshContactList] $dev not found as valid AD user"
                }
            }

        } 

    }

    foreach ($c in $contactArray) {
        $c = Set-CleanEmail -email $c -functionName "Set-DatasetRefreshContactList" -variableName "pbi.workspace.owners"
        if($c) {
            $contact = $contactList | Where-Object {$_.emailAddress -eq $c}

            if($contact) {
                Write-Verbose "[Set-DatasetRefreshContactList] $c (contact) already a contact"
            } else {
                Write-Verbose "[Set-DatasetRefreshContactList] Contact: $c"
                $developer = Get-AzureADUser -Filter "userPrincipalName eq '$c'"
                if($developer) {
                    $contactList += @{
                        displayName         = $developer.displayName
                        objectId            = $developer.objectId
                        userPrincipalName   = $condevelopertact.userPrincipalName
                        isSecurityGroup     = $false
                        objectType          = 1
                        groupType           = 0
                        addAppId            = $null
                        emailAddress        = $developer.mail
                    }
                } else {
                    Write-Warning "[SolidOps.PBI.Datasets] $c not found as valid AD user"
                }
            }

        } 
        
    }

    $folderResponse = Get-PowerBIFolder -workspaceId $workspaceId
    $folderId = $folderResponse.id

    # powerbi/metadata/settings?folderId=338438

    $domain = $global:SolidOpsSession.BaseUIDomain
    $url = "$domain/powerbi/metadata/settings?folderId=$folderId"
    $additionalHeaders = @{
        'Accept' = 'application/xml'
    }
    $settingsXML = Invoke-SolidOpsPBIRestMethod -url $url -method Get -additionalHeaders $additionalHeaders

    #$settingsXML

    #Write-Verbose "JSON: $settingsXML"

    #$folderSettings = $settingsXML | ConvertFrom-XML 
    #$folderSettings = $settingsXML #| ConvertFrom-Json


    # all datasets

    $models = $settingsXML.SettingsMetadata.datasetModels.Model
    $model = $models | Where-Object {$_.dbName -eq $datasetId }
    if(-not $model) {
       
        Write-Error "[SolidOps.PBI.Datasets] Could not find model with dbName $datasetId"
        return
    }

    Write-Verbose "Model $($model.dbName) found"

    # POST https://wabi-north-europe-redirect.analysis.windows.net/powerbi/metadata/models/13441964/refreshschedule

    $rs = $model.refreshSchedule
    $weekDays = 1
    $modelId = $model.id
    if($rs.refreshEnabled -and $rs.weekDays) {
        if($rs.weekDays -ne '') {
            $weekDays = Get-UIWeekdays -weekDays $rs.weekDays
        }
    }

    Write-Verbose "Weekdays flag $($weekDays)"

    $postModel = @{
        executionTime = $null
        executionTimeHourly = $rs.executionTimeHourly
        importAndRefreshBehavior = 2 #GetDataOnRefresh
        isDaily = [bool]$rs.isDaily
        localTimeZoneId = $rs.localTimeZoneId
        refreshContacts = $contactList
        #refreshEnabled = $rs.refreshEnabled
        refreshFrequency = $null
        #refreshNotificationEnabled = $rs.refreshEnabled
        #weekDays = [Int]$weekDays
    }

    if($rs.refreshEnabled -and $rs.weekDays) {
        if($rs.weekDays -ne '') {
            $postModel.Add("refreshEnabled", $true)
            $postModel.Add("refreshNotificationEnabled", $true)
            $postModel.Add("weekDays", [Int]$weekDays)
        } else {
            $postModel.Add("refreshEnabled", $false)
        }
    } else {
        $postModel.Add("refreshEnabled", $false)
    }

    $urlRefreshNotification = "$domain/powerbi/metadata/models/$modelId/refreshschedule"
    Invoke-SolidOpsPBIRestMethod -url $urlRefreshNotification -method 'Post' -postBody $postModel


    Write-Verbose "[Set-DatasetRefreshContactList] Model $($model.dbName) contact list updated"
    
    <#
        executionTime: null
            executionTimeHourly: "[\"8:30:00\"]"
            importAndRefreshBehavior: 2
            isDaily: true
            localTimeZoneId: "UTC"
            refreshContacts: 
                aadAppId: null
                displayName: "Alexandru Chiraples"
                emailAddress: "Alexandru.Chiraples@beazley.com"
                groupType: 0
                isSecurityGroup: false
                objectId: "56f98633-5106-4f78-82e9-702c94f67241"
                objectType: 1
                userAdditionalDetailsForAutoComplete: "alexandru.chiraples@beazley.com"
                userPrincipalName: "alexandru.chiraples@beazley.com"
            refreshEnabled: true
            refreshFrequency: null
            refreshNotificationEnabled: true
            weekDays: 127
    #>
    
    
}

function Get-PowerBIFolder {
    [CmdletBinding()]
    param (
        # Workspace id
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId
    )
    
    $baseDomain = $global:SolidOpsSession.BaseUIDomain
    $folderUrl = "$($baseDomain)/metadata/folders/$workspaceId"
    #$folderUrl = "$($baseDomain)/groups/$workspaceId"
    $folderResponse = Invoke-SolidOpsPBIRestMethod -url $folderUrl -method Get -verbose
    
    return $folderResponse
}

function Set-PowerBIFolder {
    [CmdletBinding()]
    param (
         # Workspace id
         [Parameter(Mandatory=$true)]
         [string]
         $workspaceId,
         # Folder request
         [Parameter(Mandatory=$true)]
         $folderRequest
    )

    Write-Verbose "[Set-PowerBIFolder] begin $workspaceId"
    $baseDomain = $global:SolidOpsSession.BaseUIDomain
    $folderUrl = "$($baseDomain)/metadata/folders/$workspaceId"
    Invoke-SolidOpsPBIRestMethod -url $folderUrl -method Put -postBody $folderRequest
    Write-Verbose "[Set-PowerBIFolder] end $workspaceId"
}


function Invoke-TakeOverDataflow {
    [CmdletBinding()]
    param (
        # Workspace id
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        # dataflow id
        [Parameter(Mandatory=$true)]
        [string]
        $dataflowId
    )
    
    # https://wabi-north-europe-redirect.analysis.windows.net/metadata/dataflows/b0a3ffab-cb31-4927-be96-546bcfcfb263/takeover?folderId=338423

    $folder = Get-PowerBIFolder -workspaceId $workspaceId
    $folderId = $folder.id

    Write-Verbose "[Invoke-TakeOverDataflow] begin $dataflowId"
    $baseDomain = $global:SolidOpsSession.BaseUIDomain
    $url = "$($baseDomain)/metadata/dataflows/$dataflowId/takeover?folderId=$folderId"
    $postBody = @{
        isallowNativeQueriesChecked = $false
    }
    Invoke-SolidOpsPBIRestMethod -url $url -method Post -postBody $postBody
    Write-Verbose "[Invoke-TakeOverDataflow] end $workspaceId"

    
}

function Get-RefreshContactList {
    [CmdletBinding()]
    param (
        
    )
    
    $devs = $global:SolidOpsSession.Developers
    $contactArray = $contacts.Split(";")
    $devArray = $devs.Split(";")

    $contactList = @()

    foreach ($dev in $devArray) {
        $dev = Set-CleanEmail -email $dev -functionName "Set-DatasetRefreshContactList" -variableName "pbi.workspace.developers"
        if($dev) {
            $dev = $dev.trim()
            $contact = $contactList | Where-Object {$_.emailAddress -eq $dev}

            if($contact) {
                Write-Verbose "[Set-DatasetRefreshContactList] $dev (dev) already a contact"
            } else {
                $developer = Get-AzureADUser -Filter "userPrincipalName eq '$dev'"
                if($developer) {
                    $contactList += @{
                        displayName         = $developer.displayName
                        objectId            = $developer.objectId
                        userPrincipalName   = $condevelopertact.userPrincipalName
                        isSecurityGroup     = $false
                        objectType          = 1
                        groupType           = 0
                        addAppId            = $null
                        emailAddress        = $developer.mail
                    }
                } else {
                    Write-Warning "[Set-DatasetRefreshContactList] $dev not found as valid AD user"
                }
            }
        } 

    }

    foreach ($c in $contactArray) {
        $c = Set-CleanEmail -email $c -functionName "Set-DatasetRefreshContactList" -variableName "pbi.workspace.owners"
        if($c) {
            $contact = $contactList | Where-Object {$_.emailAddress -eq $c}

            if($contact) {
                Write-Verbose "[Set-DatasetRefreshContactList] $c (contact) already a contact"
            } else {
                Write-Verbose "[Set-DatasetRefreshContactList] Contact: $c"
                $developer = Get-AzureADUser -Filter "userPrincipalName eq '$c'"
                if($developer) {
                    $contactList += @{
                        displayName         = $developer.displayName
                        objectId            = $developer.objectId
                        userPrincipalName   = $condevelopertact.userPrincipalName
                        isSecurityGroup     = $false
                        objectType          = 1
                        groupType           = 0
                        addAppId            = $null
                        emailAddress        = $developer.mail
                    }
                } else {
                    Write-Warning "[SolidOps.PBI.Datasets] $c not found as valid AD user"
                }
            }
        } 
        
    }

    return $contactList
}

function Set-DataflowRefreshContactList {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        # Reports path
        [Parameter(Mandatory=$true)]
        [string]
        $dataflowId,
        # developers; workspace owners
        #[Parameter(Mandatory=$true)]
        $contacts
    )

    Write-Verbose "[Set-DataflowRefreshContactList] begin"

    $folderResponse = Get-PowerBIFolder -workspaceId $workspaceId
    $folderId = $folderResponse.id

    $domain = $global:SolidOpsSession.BaseUIDomain

    $url = "$domain/metadata/dataflows/$folderId/extendedSettings"
    $settings = Invoke-SolidOpsPBIRestMethod -url $url -method Get
    Write-Verbose $settings
    
    $df = $settings.cdsaModels | Where-Object { $_.objectId -eq $dataflowId }
    if($null -eq $df) {
        Write-Error "[Set-DataflowRefreshContactList] could not find dataflow $dataflowId settings for $workspaceId"
    }

    $contactList = Get-RefreshContactList

    $postModel = @{
        schedule = $df.schedule
        notifyOnFailure = $true
        notifyContacts = $contactList
    }

    $urlRefreshNotification = "$domain/metadata/dataflows/settings/$dataflowId/scheduleV2"
    Invoke-SolidOpsPBIRestMethod -url $urlRefreshNotification -method 'Post' -postBody $postModel
    
    Write-Verbose "[Set-DataflowRefreshContactList] end"
}


function Invoke-DatasourceSkipTestConnection {
    [CmdletBinding()]
    param (
        # Gateway Id
        [Parameter(Mandatory=$true)]
        [string]
        $gatewayId,
        # Datasource
        [Parameter(Mandatory=$true)]
        [string]
        $datasourceId
    )

    $domain = $global:SolidOpsSession.BaseUIDomain
    
    # PUT https://wabi-north-europe-redirect.analysis.windows.net/metadata/datamovement/gateways/1f64b140-3082-47bc-bc03-ca0735a627aa/dataSources/88e8ace8-9520-4811-be5e-2b7ad5c6b628/credentials?api-version=10.0
    #{"credentials":"{\"credentialData\":[]}","credentialType":2,"encryptedConnection":2,"privacyLevel":2,"encryptionAlgorithm":"none","skipTestConnection":true}
    $postModel = @{
        credentials = @{
            credentialsData = @()
        } | ConvertTo-Json -Compress
        credentialType = 2
        encryptedConnection = 2
        privacyLevel = 2
        encryptionAlgorithm = "none"
        skipTestConnection = $true
    }

    $urlRefreshNotification = "$domain/metadata/datamovement/gateways/$($gatewayId)/dataSources/$($datasourceId)/credentials?api-version=10.0"
    Invoke-SolidOpsPBIRestMethod -url $urlRefreshNotification -method Put -postBody $postModel
}

function Invoke-ChangeLiveConnectionDataSource {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $pbixPath,
        [Parameter(Mandatory=$true)]
        [string]
        $oldDatasourceId,
        [Parameter(Mandatory=$true)]
        [string]
        $newDatasourceId
    )
    
    
}