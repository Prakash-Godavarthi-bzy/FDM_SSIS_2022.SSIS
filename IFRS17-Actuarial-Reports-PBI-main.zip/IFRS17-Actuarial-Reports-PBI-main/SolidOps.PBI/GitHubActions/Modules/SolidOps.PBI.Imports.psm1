function Get-PowerBIItemName {
    [CmdletBinding()]
    param (
        # file object
        [Parameter(Mandatory=$true)]
        $item
    )

    Write-Verbose "[Get-PowerBIItemName] $($item.BaseName)"
    
    $name = [System.Web.HttpUtility]::UrlDecode($item.BaseName)

    return $name
}

function Add-PowerBIImport {
    [CmdletBinding()]
    param (
         # report item
         [Parameter(Mandatory = $true)]
         $item,
         # workspace object
         [Parameter(Mandatory = $true)]
         [string]
         $workspaceId,
         # https://docs.microsoft.com/en-us/rest/api/power-bi/imports/post-import-in-group#importconflicthandlermode
        [ValidateSet('Abort', 'CreateOrOverwrite', 'GenerateUniqueName', 'Ignore', 'Overwrite')]
         [string]
         $nameConflict = "Ignore"
    )

    
    
    $path = "$($item.FullName)"

    $itemName = Get-PowerBIItemName -item $item
    
    $importId = Add-Import -path $path -workspaceId $workspaceId -nameConflict $nameConflict
    
    Write-Verbose $importId

    $status = Get-ImportStatus -workspaceId $workspaceId -importId $importId
    if($status) {
        # https://docs.microsoft.com/en-us/power-bi/transform-model/dataflows/dataflows-features-limitations#api-considerations
        Write-Verbose "[Add-PowerBIImport] dataflow $itemName import Succeeded"

        $obj = $status.dataflows | Where-Object {$_.name -eq $itemName}
        if($obj) {
            Write-Verbose $obj

            $objectId = $obj.objectId
            Write-Verbose "[Add-PowerBIImport] found dataflow $($itemName) : $($objectId)"
            
            return $objectId
        } else {
            Write-Error "[Add-PowerBIImport] dataflow $($itemName) not found"
        }
        

    } else {
        Write-Error "[Add-PowerBIImport] dataflow $itemName import unknown"
    }
}

function Add-Import {
    [CmdletBinding()]
    param (
         # report item
         [Parameter(Mandatory = $true)]
         [string]
         $path,
         # workspace object
         [Parameter(Mandatory = $true)]
         [string]
         $workspaceId,
         [ValidateSet('Abort', 'CreateOrOverwrite', 'GenerateUniqueName', 'Ignore', 'Overwrite')]
         [string]
         $nameConflict = "Ignore"
    )
    
    $ErrorActionPreference = 'Stop'

    $model = "model.json"
    Write-Verbose "model: $model"

    $url = "https://api.powerbi.com/v1.0/myorg/groups/$($workspaceId)/imports?datasetDisplayName=$($model)&nameConflict=$($nameConflict)"
    #Write-Host "url: $url"

    $fieldName = 'file'
    $filePath = $path

    $accessToken = Get-PowerBIAccessToken
    $bearer = $accessToken.Authorization.ToString()

    Try {
        Add-Type -AssemblyName 'System.Net.Http'

        $client = New-Object System.Net.Http.HttpClient
        $client.DefaultRequestHeaders.Add("Authorization", $bearer)

        $content = New-Object System.Net.Http.MultipartFormDataContent
        $fileStream = [System.IO.File]::OpenRead($filePath)
        $fileName = [System.IO.Path]::GetFileName($filePath)
        $fileContent = New-Object System.Net.Http.StreamContent($fileStream)
        $content.Add($fileContent, $fieldName, $fileName)

        $result = $client.PostAsync($url, $content).Result
        #$code = $result.EnsureSuccessStatusCode()

        Write-Verbose "Success"
        $result = $result.Content.ReadAsStringAsync().GetAwaiter().GetResult()
        Write-Verbose $result
        $resultJson = $result | ConvertFrom-Json
        #write-host "1.filename" $fileName
        #write-host "2.filecontent:" $fileContent
        #write-host "3.resultjson:" $resultJson
        #{"error":{"code":"Conflict","message":"Dataflow 'Environments' already exists"}}
        if($resultJson.error) {
            $message = $resultJson.error.code + ": " + $resultJson.error
            Write-Error $message
        }

        $importId = $resultJson.id
        Write-Verbose "Job Id: $importId"
        return $importId
    }
    Catch {
        Write-Error $_
        exit 1
    }
    Finally {
        if ($null -ne $client) { $client.Dispose() }
        if ($null -ne $content) { $content.Dispose() }
        if ($null -ne $fileStream) { $fileStream.Dispose() }
        if ($null -ne $fileContent) { $fileContent.Dispose() }
    }
}

function Get-ImportStatus {
    [CmdletBinding()]
    param (
        # workspace object
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceId,
        # workspace object
        [Parameter(Mandatory = $true)]
        [string]
        $importId
    )
    
    # https://api.powerbi.com/v1.0/myorg/groups/f612dd43-675a-42dc-a661-7577ba675870/imports/013a43e1-eab1-4861-8e0f-ea3250399b58

    $url = "https://api.powerbi.com/v1.0/myorg/groups/$($workspaceId)/imports/$($importId)"
    #write-host "IMPORT URL" $url
    $importState = "Publishing"
    $status = $null
    $counter = 0
    
    <#
    {
        "error": {
            "code": "PackageNotFoundError",
            "pbi.error": {
                "code": "PackageNotFoundError",
                "parameters": {},
                "details": []
            }
        }
    }
    #>

    while ($importState -eq "Publishing") {
        $status = Invoke-SolidOpsPBIRestMethod -url $url `
            -method Get 

        $statusJson = $status | ConvertTo-Json
        Write-Verbose "status $($importId): $($statusJson)"
        $importState = $status.importState
        if ($importState -eq "Failed") {
            Write-Error $status
        } 

        if ($importState -eq "Succeeded") {
            return $status
        } 

        if ($importState -ne "Succeeded") {
            $counter++
            Start-Sleep -s 10
        }

        if($counter -gt 6) {
            $importState = "unknown"
            Write-Warning "[Get-ImportStatus] unknown import state $($importState) for $importId in workspace $workspaceId"
            Write-Verbose $status
            Write-Error $importState
        }
    }

    return $null

    
}