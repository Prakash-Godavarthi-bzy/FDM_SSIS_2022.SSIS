
function Get-ReportName {
    [CmdletBinding()]
    param (
         # report item
         [Parameter(Mandatory = $true)]
         $item,
         $reportSettings
    )
    
    $reportName = [System.Web.HttpUtility]::UrlDecode($item.Name)

    if ($reportSettings) {
        if($reportSettings.reportName) {
            $reportName = $reportSettings.reportName
        }

        # if($reportSettings.reportSuffix) {
        #     $reportName = $reportName + $reportSettings.reportSuffix
        # }
    }

    return $reportName
}

function Get-ReportConfig {
    [CmdletBinding()]
    param (
        # octopus deploy package path. Searching for Config\reports.json
        [string]
        $path
    )
    
    begin {
        $reportJsonPath = "$path\Config\reports.json"

        If (-Not (Test-Path $reportJsonPath)) {
            Write-Error "$reportJsonPath does not exist"
            exit
        }
    }
    
    process {
        $reportConfig = Get-Content -Raw -Path $reportJsonPath | ConvertFrom-Json
        return $reportConfig
    }
    
    end {
        
    }
}

function Set-PaginatedReportDatasource {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $reportId,
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceId,
        # target dataset id
        [Parameter(Mandatory = $true)]
        [string]
        $tDatasetId,
        [Parameter(Mandatory = $true)]
        [string]
        $tWorkspaceId
    )
    
    $gUrl = "https://api.powerbi.com/v1.0/myorg/groups/$workspaceId/reports/$reportId/datasources"
    $response = Invoke-SolidOpsPBIRestMethod -url $gUrl -method Get 
    
    $updateDetails = @()
    
    foreach ($ds in $response.value) {
        $updateDetails += @{
            datasourceName = $ds.name
            connectionDetails = @{
                server = "pbiazure://api.powerbi.com/"
                database = "sobe_wowvirtualserver-$($tDatasetId)"
            }
        }
    }

    $body = @{
        updateDetails = $updateDetails
    }
    
    $url = "https://api.powerbi.com/v1.0/myorg/groups/$workspaceId/reports/$reportId/Default.UpdateDatasources"


    Invoke-SolidOpsPBIRestMethod -url $url -method Post -postBody $body

}

function Switch-CompositeReportSource {
    [CmdletBinding()]
    param (
        # Workspace id
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        [Parameter(Mandatory=$true)]
        [string]
        $reportId,
        [Parameter(Mandatory=$true)]
        [string]
        $reportName,
        [Parameter(Mandatory=$true)]
        [string]
        $path
    )
    
    $swReportName = "switch-" + $reportName

    Write-Verbose "[Switch-CompositeReportSource] publishing $swReportName from $path"
    $response = New-PowerBIReport -Path $path `
        -Name $swReportName `
        -WorkspaceId $workspaceId `
        -ConflictAction CreateOrOverwrite


    $swReport = Get-PowerBIReport -Id $response.Id -WorkspaceId $workspaceId

    $datasetId = $swReport.DatasetId

    Write-Verbose "[Switch-CompositeReportSource] rebind $reportName to dataset $datasetId configured in $swReportName"
    Invoke-RebindReport -workspaceId $workspaceId -reportId $reportId -datasetId $datasetId

    Write-Verbose "[Switch-CompositeReportSource] remove $swReportName with id $($response.Id)"
    Remove-PowerBIReport -Id $response.Id -WorkspaceId $workspaceId
}

function Add-Report {
    [CmdletBinding()]
    param (
        # report item
        [Parameter(Mandatory = $true)]
        $item,
        # workspace object
        [Parameter(Mandatory = $true)]
        $workspace,
        [Parameter(Mandatory = $true)]
        $reportSettings,
        # configuredBy
        [Parameter(Mandatory = $false)]
        [string]
        $configuredBy,
        [string]
        $reportType = "PowerBIReport"
    )
    
        Write-Verbose "[Add-Report] begin"
        #$reportMapping = $reportMappingJson | ConvertFrom-Json
        
        Write-Verbose "[Add-Report] process"
        Write-Verbose "Processing $($item.FullName)"

        $reportName = Get-ReportName -item $item -reportSettings $reportSettings

        try {
            $workspaceId = $workspace.Id
            $repName = "$($item.BaseName)"
            Write-Verbose "[Add-Report] Get reports for $workspaceId with name $repName"
            $report = Get-PowerBIReport -Name $repName -WorkspaceId $workspaceId
            #write-host "Our report" $report
            $itemName = Get-ReportName -item $item
            $compositeReport = Find-SingleCompositeReport -report $reportSettings -fileName $itemName

            $conflictAction = "Abort"
            $liveConnection = $false

            if ($report) {
                if($compositeReport) {
                    if($reportType -eq "PowerBIReport") {
                        if($compositeReport.composite) {
                            Write-Verbose "[Add-Report] Report $repName has a local model. Process datasources in Datasets step"
                        } else {
                            $liveConnection = $true
                            Write-Verbose "[Add-Report] Report $repName connected using Live Connection to shared dataset."
                            $jsonComposite = $compositeReport | ConvertTo-JSON
                            Write-Verbose "JSON: $jsonComposite"
                            
                            Switch-CompositeReportSource -workspaceId $workspaceId `
                                -reportId $report.Id `
                                -reportName $reportName `
                                -path $item.FullName
                        
                            Write-Verbose "[Add-Report] Switched dataset for $repName"
                        }
                    } else {
                        # paginated report
                        $conflictAction = "Overwrite"
                    }
                }

                Write-Verbose "[Add-Report] Report $repName already exists. Check ownership"
                $datasetId = $report.DatasetId
                #write-host "datasetId" $datasetId
                if($datasetId) {
                    # Dependency on SolidOps.PBI.Datasets
                    Set-DatasetOwnership -workspaceId $workspaceId -datasetId $datasetId -configuredBy $configuredBy -verbose

                    # if($reportSettings.refreshSchedule) {
                    #     if ($reportSettings.refreshSchedule.value.enabled) {
                    #         if (-not $liveConnection) {
                    #             write-host "REFRESH VALUE" $reportSettings.refreshSchedule.value.enabled
                    #             write-host "LIVE CONNECTION"  $liveConnection                      
                    #             Write-Verbose "[Add-Report] disable scheduled refresh for dataset $repName"

                    #             $reportSettings = @{
                    #                 refreshSchedule = @{
                    #                     value = @{
                    #                         enabled = $false
                    #                     }
                    #                 }
                    #             }

                                Set-DatasetRefreshSchedule -id $datasetId -workspaceId $workspaceId -reportSettings $reportSettings
                            }
                #         }
                #     }
                # }
            }

            $response = $null
            Write-Verbose "[Add-Report] Adding report $reportName"

            $reportId = $null
            if($reportType -eq "PowerBIReport") {
                try {
                    $response = New-PowerBIReport -Path $item.FullName `
                        -Name $reportName `
                        -WorkspaceId $workspaceId `
                        -ConflictAction CreateOrOverwrite
                    $reportId = $response.Id
                } catch {
                    $message = $_.ToString()
                    
                    if($message -match "Sequence contains more than one element") {
                        Write-Warning "[Add-Report] found error Sequence contains more than one element. If multiple reports are connected to this dataset, ignore error"
                        $newReport = Get-PowerBIReport -Name $repName -WorkspaceId $workspaceId
                        $reportId = $newReport.Id
                    } else {
                        throw $_
                    }
                }

            } elseif ($reportType -eq "PaginatedReport") {
                $response = New-PowerBIReport -Path $item.FullName `
                    -Name $reportName `
                    -WorkspaceId $workspaceId `
                    -ConflictAction $conflictAction

                    $reportId = $response.Id
            }

            if($compositeReport) {
                if($compositeReport.composite) {
                    Write-Verbose "[Add-Report] Dataset using DirectQuery, composite models v2. Processed in datasets"
                } else {
                    $cdatasetName = $compositeReport.datasource.name;
                    $cWorkspace = $compositeReport.datasource.workspaceName;
                    
                    Write-Verbose "[Add-Report] dataset name for shared model: $cdatasetName"

                    $cWorkspaceId = (Get-PowerBIWorkspace -Name $cWorkspace).Id

                    $dsId = Get-DatasetByName -workspaceId $cWorkspaceId -datasetName $cdatasetName

                    if($reportType -eq "PaginatedReport") {
                        Set-PaginatedReportDatasource -workspaceId $workspaceId -reportId $reportId -tDatasetId $dsId -tWorkspaceId $cWorkspaceId
                    } else {
                        Invoke-RebindReport -workspaceId $workspaceId -reportId $reportId -datasetId $dsId
                    }
                }

            } else {
                # do nothing, not composite report
            }

            Write-Verbose "Published: $($item.FullName)"
            Write-Verbose "Id:          $($response.Id)"
            Write-Verbose "EmbedUrl:    $($response.EmbedUrl)"
            Write-Verbose "DatasetId:   $($response.DatasetId)"
            Write-Verbose "Name:        $($response.Name)"
            Write-Verbose "WebUrl:      $($response.WebUrl)"
            return $response
        }
        catch {
            Write-Verbose "[Add-Report] Server response start $workspaceId"
            Write-Verbose "[Add-Report] Path:       $($item.FullName)"
            Write-Verbose "[Add-Report] Name:       $reportName"
            Write-Verbose "[Add-Report] Workspace:   $workspaceId"

            
            Write-Verbose $_
            Write-Verbose $_.ErrorCategory
            Write-Verbose $_.ScriptStackTrace
            

            $x = Resolve-PowerBIError -Last
            if ($x.Response -match "The import was not successful for import ID") {
                Write-Warning "Import failed. Retrieving status"
                $found = $x.Response -match '[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}'
                if($found) {
                    $importId = $Matches[0]
                
                    $import = Get-PowerBIImport -Id $importId
                    if($import.Error.Code -eq 'FailedToRefreshPackageAfterImportError') {
                        Write-Warning "[SolidOps.PBI.Reports] FailedToRefreshPackageAfterImportError found for report $reportName. Dataset will be refreshed after updating parameters"
                    } else {
                        Write-Error "[SolidOps.PBI.Reports] Import error $($import.Error.Code) for report $reportName"
                    }
                } else {
                    Write-Error "[SolidOps.PBI.Reports] Could not retrieve Import ID. $($x.Response)"
                }
            } else {
                Write-Error $x.Response
            }
            
            #Write-Error $_
        }
        
        
        Write-Verbose "[Add-Report] end"
}

function Get-ReportFolder {
    [CmdletBinding()]
    param (
        # Report folder
        [Parameter(Mandatory = $true)]
        [string]
        $path,
        [Parameter(Mandatory = $true)]
        $reportConfig,
        [Parameter(Mandatory = $true)]
        [string]
        $reportType
    )
    
    $reportFolderLocation = $null

    if($reportType -eq "PaginatedReport") {
        $reportFolderLocation = "Paginated"
    } else {
        $reportFolderLocation = $($reportConfig.reportsFolder)
    }

    $reportFolder = "$($path)\$($reportFolderLocation)"
    
    return $reportFolder
}

function Get-ReportItems {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $reportFolder,
        [Parameter(Mandatory = $true)]
        [string]
        $reportType
    )
   
    $reportList = $null

    if($reportType -eq "PowerBIReport") {
        $reportList = Get-ChildItem $reportFolder\*.pbix
    } else {
        $reportList = Get-ChildItem $reportFolder\*.rdl
    }

    return $reportList
}

function Add-Reports {
    [CmdletBinding()]
    param (
        # Report folder
        [Parameter(Mandatory = $true)]
        [string]
        $path,
        # Workspace name
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceName,
        [Parameter(Mandatory = $true)]
        [string]
        $gatewayName,
        # configuredBy
        [Parameter(Mandatory = $false)]
        [string]
        $configuredBy,
        [string]
        $reportType = "PowerBIReport"
    )
    
    
    Write-Verbose "[Add-Reports] begin"
    
    $destinationWorkspace = Get-PowerBIWorkspace -Name $workspaceName;
    if ($null -eq $destinationWorkspace) {
        Write-Error "[SolidOps.PBI.Reports] $workspaceName does not exist or insufficient permissions"
        #exit
    }

    $reportConfig = Get-ReportConfig -path $path
   
    $reportFolder = Get-ReportFolder -path $path -reportConfig $reportConfig -reportType $reportType
   
    Write-Verbose "[Add-Reports] process"
    
    if(-not (Test-Path $reportFolder)) {
        Write-Warning "[SolidOps.PBI.Reports] Could not find $($reportConfig.reportsFolder). Reports will not be imported"
        return
    }

    $reports = $reportConfig.reports

    $reportList = Get-ReportItems -reportFolder $reportFolder -reportType $reportType

    foreach ($item in $reportList) {
        $itemName = Get-ReportName -item $item
        Write-Verbose "[Add-Reports] Processing report $itemName"
        $reportSettings = $reports | Where-Object fileName -eq $itemName 
        if($reportSettings) {
            $newReport = Add-Report -item $item `
                -workspace $destinationWorkspace `
                -reportSettings $reportSettings `
                -configuredBy $configuredBy `
                -reportType $reportType

            Write-Information "[Add-Reports] Uploaded report $itemName with id $($newReport.Id)"
        } else {
            Write-Warning "[SolidOps.PBI.Reports] Report $itemName not configured for deployment"
        }
        
        

    }    

    Write-Verbose "[Add-Reports] end"
    
}


function Invoke-RebindReport {
    [CmdletBinding()]
    param (
        # Report ID
        [Parameter(Mandatory=$true)]
        [string]
        $reportId,
        # Workspace ID
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        # dataset Id
        [Parameter(Mandatory=$true)]
        [string]
        $datasetId
    )
    
    $url = "https://api.powerbi.com/v1.0/myorg/groups/$workspaceId/reports/$reportId/Rebind"
    $body = @{
        "datasetId" = $datasetId
    }

    Invoke-SolidOpsPBIRestMethod -url $url -method Post -postBody $body

}

function Get-ReportDatasources {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        $reportConfig
    )
    
    $names = $null
    Write-Verbose "[Get-ReportDatasources] begin"
    if($reportConfig.datasources) {
        $dsNames = $reportConfig.datasources | Get-Member -MemberType Properties | Select-Object Name

        $names = $dsNames
    }

    

    Write-Verbose "[Get-ReportDatasources] end"

    return $names
   
}

function Select-ReportDatasources {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        $reportConfig
    )
    
    Write-Verbose "[Select-ReportDatasources] begin"

    $reportDatasources = @()

    
    if($reportConfig.datasources) {
        
        $datasources = Get-ReportDatasources -reportConfig $reportConfig
        foreach ($ds in $datasources) {
            
            $dsName = $ds.Name

            $reportDatasources += @{
                fileName = $reportConfig.fileName
                composite = $reportConfig.composite
                datasource = @{
                    name = $dsName
                    config = $reportConfig.datasources.$dsName
                }
            }
            
            
        }
    }

    $reportDatasourcesJson = $reportDatasources | ConvertTo-Json -Depth 4
    Write-Verbose "Report datasource json $($reportDatasourcesJson)"

    Write-Verbose "[Select-ReportDatasources] end"

    return $reportDatasources
}

function Select-CompositeReports {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        $reports
    )
    
    Write-Verbose "[Select-CompositeReports] begin"

    $compositeReports = @()

    foreach ($report in $reports) {
        if($report.datasources) {
            
            $datasources = Get-ReportDatasources -reportConfig $report
            foreach ($ds in $datasources) {
                
                $dsName = $ds.Name
               
                if(($report.datasources.$dsName.datasourceType -eq "PBI") -or ($report.datasources.$dsName.datasourceKind -eq "PBI"))  {
                    $compositeReports += @{
                        fileName = $report.fileName
                        composite = $report.composite
                        datasource = @{
                            name = $dsName
                            workspaceName = $report.datasources.$dsName.workspaceName
                        }
                    }
                }
                
            }
        }
    }

    $compositeReportsJson = $compositeReports | ConvertTo-Json -Depth 4
    Write-Verbose "compositeReportsJson $($compositeReportsJson)"

    Write-Verbose "[Select-CompositeReports] end"

    return $compositeReports
    
}

function Select-CompositeReport {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        $report
    )

    $compositeReport = $null
    
    $datasources = Get-ReportDatasources -reportConfig $report
    foreach ($ds in $datasources) {
        
        $dsName = $ds.Name
        
        if(($report.datasources.$dsName.datasourceType -eq "PBI") -or ($report.datasources.$dsName.datasourceKind -eq "PBI"))  {
            $compositeReport = @{
                fileName = $report.fileName
                composite = $report.composite
                datasource = @{
                    name = $dsName
                    workspaceName = $report.datasources.$dsName.workspaceName
                }
            }
        }
        
    }

    return $compositeReport
}

function Find-SingleCompositeReport {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        $fileName,
        [Parameter(Mandatory=$true)]
        $report
    )
    
    $compositeReport = Select-CompositeReport -report $report

    return $compositeReport
   
}

function Find-CompositeReport {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        $fileName,
        [Parameter(Mandatory=$true)]
        $reports
    )
    
    $compositeReports = Select-CompositeReports -reports $reports

    $compositeReport = $compositeReports | Where-Object { $_.fileName -eq  $fileName }

    return $compositeReport
}