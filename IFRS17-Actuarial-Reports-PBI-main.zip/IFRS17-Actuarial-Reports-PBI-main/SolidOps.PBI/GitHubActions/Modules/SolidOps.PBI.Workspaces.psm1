#region PowerBI Workspaces

function Add-Workspace {
    [CmdletBinding()]
    param (
        # @orkspace name
        [Parameter(Mandatory=$true)]
        [string]
        $name    
    )
    
    $workspace = Get-PowerBIWorkspace -Name $name
    if($workspace) {
        Write-Verbose "Workspace $name already exists"
        return $workspace
    } else {
        Write-Verbose "Workspace $name does not exist. Create it"

        try {
            $ws = New-PowerBIWorkspace -Name $name
        return $ws
        }
        catch {
            Resolve-PowerBIError
    
            Write-Error "[Add-Workspace] Error creating workspace $($name): $($_)"
        }

        
    }
}

function Get-WorkspaceConfig {
    [CmdletBinding()]
    param (
        # octopus deploy package path. Searching for Config\workspace.json
        [string]
        $path
    )
    
    Write-Verbose "[Get-WorkspaceConfig] begin"

    $workspaceJsonPath = "$path\Config\workspace.json"
    Write-Verbose "Retrieving data from $workspaceJsonPath"

    If (-Not (Test-Path $workspaceJsonPath)) {
        Write-Error "$workspaceJsonPath does not exist"
        exit
    }
    
    Get-Content -Raw -Path $workspaceJsonPath

    $workspaceConfig = Get-Content -Raw -Path $workspaceJsonPath | ConvertFrom-Json
    
    Write-Verbose "[Get-WorkspaceConfig] end"
    
    return $workspaceConfig
}

function Get-WorkspaceUsers {
    [CmdletBinding()]
    param (
        # workspace id
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId
    )
    
    $url = "groups/$workspaceId/users"
    $response = Invoke-PowerBIRestMethod -Url $url -Method Get

    return $response | ConvertFrom-Json
}

function Set-WorkspaceUser {
    [CmdletBinding()]
    param (
        # workspace id
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        [Parameter(Mandatory=$true)]
        $user
    )
    #PUT https://api.powerbi.com/v1.0/myorg/groups/{groupId}/users
    $url = "groups/$workspaceId/users"

    $postParams = @{
        "groupUserAccessRight" = $user.accessRight
        "principalType" = $user.principalType
    };

    if($user.principalType -eq 'User') {
        $postParams += @{
            "emailAddress" =  $user.user 
        }   
    } else {
        $postParams += @{
            "identifier" =  $user.user 
        }      
    }

    $jsonPostBody = $postParams | ConvertTo-JSON

    $method = 'Put'
    $found = $null

    $users = Get-WorkspaceUsers -workspaceId $workspaceId
    $found = $users.value | Where-Object { $_.identifier -eq $user.user }

    if($null -eq $found) {
        $method = 'Post'
    }

    $parms = @{
        'Url' = $url
        'ContentType' = "application/json"
        'Body' = $jsonPostBody
        'Method' = $method
    }


    try {
        Write-Verbose "Url: $url"
        Write-Verbose "Json: $jsonPostBody"
        Invoke-PowerBIRestMethod @parms
    }
    catch {
        Write-Verbose "[Set-WorkspaceUser] Server request url"
        Write-Verbose $url
        Write-Verbose "[Set-WorkspaceUser] Server request post data"
        Write-Verbose $jsonPostBody

        Write-Verbose "[Add-DataSource] Server response stream"
        
        $errorJson = $_ | ConvertTo-Json
        Write-Verbose $errorJson


        Resolve-PowerBIError

        Write-Error $_ 
    }
}

function Get-OwnerContactList {
    [CmdletBinding()]
    param (
        # workspace config
        [Parameter(Mandatory=$true)]
        $workspaceConfig,
        # env code
        [Parameter(Mandatory=$true)]
        [string]
        $envCode,
        # $token.access_token for MS Graph
        [Parameter(Mandatory=$true)]
        [string]
        $accessToken
    )
    
    Write-Verbose "[Get-OwnerContactList] begin"

    $adminGroups = @()
    foreach ($user in $workspaceConfig.permissions) {
        if($user.accessRight -eq "Admin" -and $user.principalType -eq "Group") {
            Write-Verbose "[Set-WorkspaceContactList] Process group id for $($user.user)"
            $groupName = Get-AzureADGroupDisplayName -groupName $user.user -envCode $envCode
            $groupId = Get-AzureADGroupByName -displayName $groupName
            $adminGroups += $groupId
        }
    }

    $adminGroupsString = [string]::Join(";", $adminGroups)
    Write-Verbose "[Set-WorkspaceContactList] Process contact list from $adminGroupsString"

    # Get contacts
    $contactArray = @()
    foreach ($groupId in $adminGroups) {
        $ownerResponse = Invoke-GraphRestMethod -url "groups/$groupId/owners" -method Get -accessToken $accessToken 
       
        $contactArray += $ownerResponse.value
    }

    $contactList = $contactArray | Sort-Object -Property userPrincipalName -Unique

    $contacts = @()
    foreach ($contact in $contactList) {
        Write-Verbose "Processing contact $($contact.displayName)"
        $contacts += @{
            displayName         = $contact.displayName
            objectId            = $contact.id
            userPrincipalName   = $contact.userPrincipalName
            isSecurityGroup     = $false
            objectType          = 1
            groupType           = 0
            addAppId            = $null
            emailAddress        = $contact.mail
        }
    }

    Write-Verbose "[Get-OwnerContactList] end"

    return $contacts
}



function Set-WorkspaceContactList {
    [CmdletBinding()]
    param (
        # Workspace id
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        # workspace config path
        [Parameter(Mandatory=$true)]
        [string]
        $path,
        # environment name
        [string]
        $env,
        [string]
        $envCode,
        # $token.access_token for MS Graph
        [Parameter(Mandatory=$true)]
        [string]
        $accessToken
    )
    
    Write-Verbose "[Set-WorkspaceContactList] begin"

    $config = Get-WorkspaceConfig -path $path
    if($env) {
        $envCode = Get-EnvironmentCode -env $env
        Write-Verbose "$env code: $envCode"
    } elseif($envCode) {
        Write-Verbose "$env code: $envCode"
    } else {
        Write-Error "[SolidOps.PBI.Workspaces] missing env or envCode value"
    }

    $contacts = Get-OwnerContactList -workspaceConfig $config -envCode $envCode -accessToken $accessToken

    $folderResponse = Get-PowerBIFolder -workspaceId $workspaceId
    Write-Verbose "Folder json $folderResponse"

    $folderRequest = @{
        displayName = $folderResponse.displayName
        isServiceApp = $false
        contacts = $contacts
        datasetStorageMode = $folderResponse.defaultDatasetStorageMode
    }

    Set-PowerBIFolder -workspaceId $workspaceId -folderRequest $folderRequest
    
    Write-Verbose "[Set-WorkspaceContactList] end"
}

function Add-WorkspaceUsers {
    [CmdletBinding()]
    param (
        # Workspace id
        [Parameter(Mandatory=$true)]
        [string]
        $id,
        # nuget install folder
        [Parameter(Mandatory=$true)]
        [string]
        $path,
        # environment name
        [string]
        $env,
        # environment Code
        [string]
        $envCode
    )
    Write-Verbose  "[Add-WorkspaceUsers] begin"
    
    $config = Get-WorkspaceConfig -path $path
    if($env) {
        $envCode = Get-EnvironmentCode -env $env
        Write-Verbose "$env code: $envCode"
    } elseif($envCode) {
        Write-Verbose "$env code: $envCode"
    } else {
        Write-Error "[SolidOps.PBI.Workspaces] missing env or envCode value"
    }

    if($config.permissions.psobject.Properties.name -match $envCode) {
        Write-Error "[SolidOps.PBI.Workspaces] $envCode users configured for workspace $id. Update workspace.json file to latest config version" 
        return
    } 
    

    Write-Verbose "[Add-WorkspaceUsers] process users"
    foreach ($user in $config.permissions) {
        Write-Verbose "Processing user $($user.user) of type $($user.principalType)"

        if($user.principalType -eq "Group") {
            $displayName =  Get-AzureADGroupDisplayName -groupName $user.user -envCode $envCode
            $groupId = Get-AzureADGroupByName -displayName $displayName

            if($null -eq $groupId) {
                Write-Error "[SolidOps.PBI.Workspaces] Could not find group $displayName"
                return
            }

            $user.user = $groupId
        } else {
            Write-Warning "[SolidOps.PBI.Workspaces] Use of email addresses is not recommended in workspaces.json"
        }

        Set-WorkspaceUser -workspaceId $id -user $user
    }


    Write-Verbose  "[Add-WorkspaceUsers] end"
}
#endregion
