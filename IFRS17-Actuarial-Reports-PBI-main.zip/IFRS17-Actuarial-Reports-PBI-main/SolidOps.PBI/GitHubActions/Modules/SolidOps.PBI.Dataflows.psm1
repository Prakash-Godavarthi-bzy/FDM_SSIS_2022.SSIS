function Add-PowerBIDataFlowRest {
    [CmdletBinding()]
    [CmdletBinding()]
    param (
         # report item
         [Parameter(Mandatory = $true)]
         $item,
         # workspace object
         [Parameter(Mandatory = $true)]
         [string]
         $workspaceId
    )
    
    

        $itemName = Get-PowerBIDataflowName -item $item
        $model = "$itemName.json"

        $url = "https://api.powerbi.com/v1.0/myorg/groups/$workspaceId/imports?datasetDisplayName=$model&nameConflict=CreateOrOverwrite"

        $boundary = [System.Guid]::NewGuid().ToString("N")
        $LF = [System.Environment]::NewLine

        $boundary = [System.Guid]::NewGuid().ToString("N")
        $LF = [System.Environment]::NewLine

        $dataflowJSON = ""

        if(Test-Path $item.FullName) {
            $dataflowJSON = Get-Content $item.FullName -Raw
        } else {
            Write-Error "[Add-PowerBIDataflow] could not find file $($item.FullName)"
        }

        $postBody = (
            "--$boundary",
            "Content-Disposition: form-data; name=$model.json; filename=$model.json",
            "Content-Type: application/json$LF",
            $dataflowJSON,
            "--$boundary--$LF"
        ) -join $LF

        $headers = @{
            'Content-Type'  = "multipart/form-data; boundary=--$boundary"
        }

        Invoke-SolidOpsPBIRestMethod -url $url `
            -method Post `
            -postBody $postBody `
            -additionalHeaders $headers `
            -contentType "multipart/form-data"

        

        # TODO: write import via rest api
        
        # $response = New-PowerBIReport -Path $item.FullName `
        #     -Name $model `
        #     -WorkspaceId $workspaceId `
        #     -ConflictAction CreateOrOverwrite

        #Write-Verbose "Id:          $($response.Id)"
        #Write-Verbose "EmbedUrl:    $($response.EmbedUrl)"
       # Write-Verbose "DatasetId:   $($response.DatasetId)"
        # Write-Verbose "Name:        $($response.Name)"
        # Write-Verbose "WebUrl:      $($response.WebUrl)"
        #return $response
    
}



function Add-PowerBIDataflow {
    [CmdletBinding()]
    param (
         # report item
         [Parameter(Mandatory = $true)]
         $item,
         # workspace object
         [Parameter(Mandatory = $true)]
         [string]
         $workspaceId
    )
    
    

    $itemName = Get-PowerBIDataflowName -item $item
    $model = "$itemName.json"

    # TODO: write import via rest api
    try {
        $path = "$($item.FullName)"
        # Write-Verbose "New-PowerBIReport -Path $path -Name $model -WorkspaceId $workspaceId -ConflictAction CreateOrOverwrite"
        # This will throw an error. Ignore
        $response = New-PowerBIReport -Path $path `
            -Name $model `
            -WorkspaceId $workspaceId `
            -ConflictAction Abort `
            -ErrorAction SilentlyContinue `
            -ErrorVariable ProcessError

        if($ProcessError.Exception.Message -match "Sequence contains no elements") {
            Write-Warning "[SolidOps.PBI.Dataflows] Sequence contains no elements error. Import successfull, ignore this error"
        } else {
            $message = $ProcessError | ConvertTo-Json
            Write-Verbose $message
            throw $ProcessError
        }

        Write-Verbose "Id:          $($response.Id)"
        Write-Verbose "EmbedUrl:    $($response.EmbedUrl)"
        Write-Verbose "DatasetId:   $($response.DatasetId)"
        Write-Verbose "Name:        $($response.Name)"
        Write-Verbose "WebUrl:      $($response.WebUrl)"
        
        return $response
    }
    catch {
        Write-Verbose "[Add-PowerBIDataflow] Server response start $workspaceId"
        Write-Verbose "[Add-PowerBIDataflow] Path:       $($item.FullName)"
        Write-Verbose "[Add-PowerBIDataflow] Name:       $model"
        Write-Verbose "[Add-PowerBIDataflow] Workspace:    $workspaceId"
        
        Resolve-PowerBIError -Last
        
        Write-Error $_
    }
    
}

function Add-PowerBIDataflowGateway {
    [CmdletBinding()]
    param (
        # gateway name
        [Parameter(Mandatory=$true)]
        [string]
        $gatewayName,
        # dataflow id
        [Parameter(Mandatory=$true)]
        [string]
        $dataflowId,
        [string]
        $gatewayId,
        # baseUrl
        [string]
        $baseUrl = "https://wabi-north-europe-redirect.analysis.windows.net"

    )

    if($baseUrl -eq "https://wabi-north-europe-redirect.analysis.windows.net") {
        Write-Warning "[Add-DataflowGateway] Use of $baseUrl"
    }

    if(-not $gatewayId) {
        $gateway = Get-Gateway -gatewayName $gatewayName
        $gatewayId = $gateway.id
        #write-host "1.gateway:" $gateway
        #write-host "2.gatewayId:" $gatewayId
    }
    

    
    $url = "$baseUrl/metadata/dataflows/settings/$dataflowId/bind"
    #write-host "3.url:" $url
    $postBody = @{
        "gatewayObjectId" = $gatewayId 
    };
    #write-host "4.postbody:" $postBody
    Invoke-SolidOpsPBIRestMethod -Url $url `
         -method Post `
         -postBody $postBody `
         -verbose
}

function Set-PowerBIDataflowName {
    [CmdletBinding()]
    param (
        # workspace id
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceId,  
        # dataflow id
        [Parameter(Mandatory=$true)]
        [string]
        $dataflowId,
        [Parameter(Mandatory=$true)]
        [string]
        $name
    )

    $url = "https://api.powerbi.com/v1.0/myorg/groups/$workspaceId/dataflows/$dataflowId"
    $postBody = @{
        name = $name
    }

    Invoke-SolidOpsPBIRestMethod -url $url -method Patch -postBody $postBody
    
}

function Remove-PowerBIDataflow {
    [CmdletBinding()]
    param (
        # workspace id
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceId,  
        # dataflow id
        [Parameter(Mandatory=$true)]
        [string]
        $dataflowId
        
    )
    
    Write-Verbose "[Remove-PowerBIDataflow] begin"
    $url = "https://api.powerbi.com/v1.0/myorg/groups/$workspaceId/dataflows/$dataflowId"

    Invoke-SolidOpsPBIRestMethod -url $url -method Delete

    Write-Verbose "[Remove-PowerBIDataflow] dataflow deleted. sleep 15 seconds"
    
    Start-Sleep -s 5

    Write-Verbose "[Remove-PowerBIDataflow] end"
}

function Add-PowerBIDatafowRefreshSchedule {
    [CmdletBinding()]
    param (
        # Workspace ID
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,     
        # Dataset id
        [Parameter(Mandatory=$true)]
        [string]
        $dataflowId,    
        [Parameter(Mandatory=$true)]
        $dataflowSettings
    )

    if($dataflowSettings.refreshSchedule) {
        $url = "https://api.powerbi.com/v1.0/myorg/groups/$($workspaceId)/dataflows/$($dataflowId)/refreshSchedule"
        $postBody = $null
        if($dataflowSettings.refreshSchedule.value.enabled) {
            $postBody =  $dataflowSettings.refreshSchedule
        } else {
            Write-Verbose "[Add-PowerBIDatafowRefreshSchedule] found disabled refresh schedule for dataflow $dataflowId. Prepare custom post body. Microsoft bug: 'Refresh schedule time zone id is not valid'"
            $postBody = @{
                value = @{
                    enabled = $false
                    days = @("Sunday")
                    times = @("00:00")
                    localTimeZoneId = "UTC"
                }
                
            }
        }

        Invoke-SolidOpsPBIRestMethod -url $url -method Patch -postBody $postBody
    } else {
        Write-Warning "[SolidOps.PBI.Dataflows] Refresh schedule not configured for $($dataflowSettings.fileName)"
    }
}

function Invoke-PowerBIDataflowRefresh {
    [CmdletBinding()]
    param (
        # workspace id
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceId,
        # dataflow id
        [Parameter(Mandatory=$true)]
        [string]
        $dataflowId
    )
    
    $url = "https://api.powerbi.com/v1.0/myorg/groups/$workspaceId/dataflows/$dataflowId/refreshes"

    $postBody = @{
        notifyOption = "MailOnFailure"
    }
    

    Invoke-SolidOpsPBIRestMethod -url $url -method Post -postBody $postBody
    
}

function Format-Json {
    param
    (
        [Parameter(Mandatory, ValueFromPipeline)]
        [String]
        $json
    ) 

    $indent = 0;
    $result = ($json -Split '\n' |
            ForEach-Object {
                if ($_ -match '[\}\]]') {
                    # This line contains ] or }, decrement the indentation level
                    $indent--
                }
                $line = (' ' * $indent * 2) + $_.TrimStart().Replace(': ', ': ')
                if ($_ -match '[\{\[]') {
                    # This line contains [ or {, increment the indentation level
                    $indent++
                }
                $line
            }) -Join "`n"
    
    # Unescape Html characters (<>&')
    $result.Replace('\u0027', "'").Replace('\u003c', "<").Replace('\u003e', ">").Replace('\u0026', "&")
    
}

function Set-DataflowDefinition {
    [CmdletBinding()]
    param (
        # File item
        [Parameter(Mandatory=$true)]
        $item,
        [Parameter(Mandatory=$true)]
        $dataflowSettings,
        [bool]
        $revert = $false
    )

    Write-Verbose "[Set-DataflowDefinition] begin"

    $flowDef = @{
        allowNativeQueries = $false
    }

    $dataflowDefinition = Get-Content -Path $item.FullName -Raw | ConvertFrom-Json

    $bearer = $global:SolidOpsSession.AuthToken
    $paramOverwrite = @{
        access_token = $bearer -Replace "Bearer "
    }

    if($revert) {
        $dataflowDefinition.'pbi:mashup'.'allowNativeQueries'= $true
    } else {

        # set allow native queries to false
        if ($dataflowDefinition.'pbi:mashup'.'allowNativeQueries')
        {
            $dataflowDefinition.'pbi:mashup'.'allowNativeQueries'= $false
            $flowDef.allowNativeQueries = $true
        } 

        # remove partitions
        forEach ($entity in $dataflowDefinition.entities) {
            if (Get-Member -InputObject $entity -Name "partitions" -MemberType Properties) {
                $entity.partitions = @()
            }
        }

        #update parameters

        $document = $dataflowDefinition.'pbi:mashup'.'document'
        if($document) {
            foreach ($param in $dataflowSettings.parameters.psobject.properties) {
                #https://github.com/marclelijveld/Power-BI-Automation/blob/master/PowerBI_MoveDataflows.ps1
                <#
                Server = \\"[0-9a-zA-Z\\]*"
                Year_MIN = \\"[0-9a-zA-Z\\]*"
                #>
                if(-not $param) {
                    Write-Error "[SolidOps.PBI.Dataflows] parameter is null. Check dataflows.json for valid syntax"
                } 

                Write-Verbose "[Set-DataflowDefinition] Processing parameter $($param.Name)"

                $keyName = $param.Name
                $keyValue = $param.Value

                
                #$pattern = '"[0-9a-zA-Z\\\s]*"'
                #$pattern = '\\[0-9a-zA-Z.\\\s"]*\\"'
                #$pattern = '\\"[0-9a-zA-Z.\\\s]*\\"'
                #$pattern = '"[0-9a-zA-Z.\\\s]*"'
                $pattern = '"[0-9a-zA-Z._\-\\\s]*"'
                if($keyValue.StartsWith("http")) {
                    # set url pattern
                    Write-Verbose "[Set-DataflowDefinition] Found http pattern for $keyName"
                    $pattern = '"(http|ftp|https):\/\/([\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:\/~+#-]*[\w@?^=%&\/~+#-])"'
                    
                }

                $searchText = "$keyName = $pattern"
                Write-Verbose "[Set-DataflowDefinition] Searching for $searchText to replace with $keyValue"

                $found = $document -match $searchText
                if($found) {
                    Write-Verbose "[Set-DataflowDefinition] Parameter $keyName found"
                    $searchValue = $Matches[0]

                    #fix backslash in value
                    $searchValue = $searchValue -replace "\\", "\\"
                    
                    if($paramOverwrite) {
                        if($paramOverwrite[$keyName]) {
                            Write-Verbose "Found parameter $($keyName) to overwrite"
                            $keyValue = $paramOverwrite[$keyName]
                        }
                    } 

                    $replaceValue = $searchValue -replace "$pattern", "`"$keyValue`""
    
                    Write-Verbose "[Set-DataflowDefinition] Replacing $searchValue with $replaceValue"

                    $document = $document -replace $searchValue, $replaceValue
                } else {
                    Write-Warning "[SolidOps.PBI.Dataflows] $($item.Name) - parameter $keyName not found in dataflow definition"
                }
            }
        } else {
            Write-Error "[SolidOps.PBI.Dataflows] Could not find 'pbi:mashup.document in $($item.FullName)"
        }
    }
    
    $dataflowDefinition.'pbi:mashup'.'document' = $document #| ConvertTo-Json -Depth 4

    $dataflowJSON = $dataflowDefinition | ConvertTo-Json -Depth 10 | Format-Json
    
    Set-Content -Path $item.FullName -Value $dataflowJSON

    Write-Verbose "[Set-DataflowDefinition] end"
    return $flowDef
}



function Set-PowerBIDataflowSettings {
    [CmdletBinding()]
    param (
         # workspace id
         [Parameter(Mandatory = $true)]
         [string]
         $workspaceId,
         # dataflow id
         [Parameter(Mandatory=$true)]
         [string]
         $dataflowId,
         # dataflow id
         [Parameter(Mandatory=$true)]
         $updateRequest
    )
    
    Write-Verbose "[Set-PowerBIDataflowSettings] begin"

    $url = "https://api.powerbi.com/v1.0/myorg/groups/$workspaceId/dataflows/$dataflowId"
    $postBody = $updateRequest

    Invoke-SolidOpsPBIRestMethod -url $url -method Patch -postBody $postBody
    Write-Verbose "[Set-PowerBIDataflowSettings] dataflow updated. sleep 5 seconds"
    Start-Sleep -s 5
    
    Write-Verbose "[Set-PowerBIDataflowSettings] end"
}

function Get-DataflowDatasources {
    [CmdletBinding()]
    param (
        # workspace id
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceId,
        # dataflow id
        [Parameter(Mandatory=$true)]
        [string]
        $dataflowId
    )
    
    $url = "https://api.powerbi.com/v1.0/myorg/groups/$workspaceId/dataflows/$dataflowId/datasources"

    
    $datasources = Invoke-SolidOpsPBIRestMethod -url $url -method Get
    return $datasources
    
}

function Set-DataflowGateway {
    [CmdletBinding()]
    param (
        # gateway name
        [Parameter(Mandatory=$true)]
        [string]
        $gatewayName,
        # dataflow id
        [Parameter(Mandatory=$true)]
        [string]
        $dataflowId,
        # workspace Id
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        [string]
        $gatewayId,
       
        [Parameter(Mandatory = $true)]
        $dataflowSettings,
        # PBI user
        [string]
        $user,
        # PBI password
        [string]
        $pass
    )
    
    Write-Verbose "[Set-DataflowGateway] bind $dataflowName to $gatewayName"
    Add-PowerBIDataflowGateway -dataflowId $dataflowId -gatewayName $gatewayName -gatewayId $gatewayId

    Write-Verbose "[Set-DataflowGateway] set dataflow datasoruces"
    $datasources =  Get-DataflowDatasources -dataflowId $dataflowId -workspaceId $workspaceId
    #$datasourceList = $datasources | ConvertFrom-Json

    Set-CloudDatasource -datasourceList $datasources `
        -jsonSettings $dataflowSettings `
        -user $user `
        -pass $pass
}

function Set-PowerBIDataflow {
    [CmdletBinding()]
    param (
        # report item
        [Parameter(Mandatory = $true)]
        $item,
        # workspace object
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceId,
        # gateway name
        [Parameter(Mandatory = $true)]
        [string]
        $gatewayName,
        [string]
        $gatewayId,
        [Parameter(Mandatory = $true)]
        $dataflowSettings,
        # PBI user
        [string]
        $user,
        # PBI password
        [string]
        $pass,
        $flag = $false
    )
    Write-Verbose "[Set-PowerBIDataflow] begin" 

    $dataflowName = Get-PowerBIDataflowName -item $item

    Write-Verbose "[Set-PowerBIDataflow] Set dataflow definition $dataflowName"
    $flowDef = Set-DataflowDefinition -item $item -dataflowSettings $dataflowSettings
    $dataflowId = Find-PowerBIDataflow -workspaceId $workspaceId -name $dataflowName

    $nameConflict = "Ignore"
        
    if($dataflowId) {
        # $nameConflict = "CreateOrOverwrite"
        Invoke-TakeOverDataflow -workspaceId $workspaceId -dataflowId $dataflowId
        
    } else {
        $dataflowId = $null
    }


    if($flag) {
        if ($dataflowId) {
            Remove-PowerBIDataflow -workspaceId $workspaceId -dataflowId $dataflowId
        }
        
        $dataflowId = Add-PowerBIImport -item $item -workspaceId $workspaceId -nameConflict $nameConflict
        Write-Verbose "[Set-PowerBIDataflow] Dataflow $dataflowId imported with $nameConflict"

        $updateRequest = @{
            allowNativeQueries = $true
        }
        
        Set-PowerBIDataflowSettings -dataflowId $dataflowId -workspaceId $workspaceId -updateRequest $updateRequest

    } else {
       
        #$dataflow = Get-PowerBIDataflow -Name $dataflowName  -WorkspaceId $workspaceId

        $prevDataflowName = "$dataflowName - SolidOpsTMP"
        if($dataflowId) {
            Write-Verbose "[Set-PowerBIDataflow] dataflow $dataflowName already exists. 1) Rename existing one to - TMP, 2) deploy the new one, 3) delete the - TMP" 
            
            $prevDataflow = Find-PowerBIDataflow -name $prevDataflowName  -workspaceId $workspaceId
            
            if($prevDataflow) {
                Write-Verbose "[Set-PowerBIDataflow] dataflow $prevDataflowName already exists. take over and remove it" 
                Invoke-TakeOverDataflow -workspaceId $workspaceId -dataflowId $prevDataflow
                Remove-PowerBIDataflow -workspaceId $workspaceId -dataflowId $prevDataflow
            }

            Write-Verbose "[Set-PowerBIDataflow] changing dataflow name from $dataflowName to $prevDataflowName"
            Invoke-TakeOverDataflow -workspaceId $workspaceId -dataflowId $dataflow
            Set-PowerBIDataflowName -workspaceId $workspaceId -dataflowId $dataflow -name $prevDataflowName
        }
        Add-PowerBIDataflow -item $item -workspaceId $workspaceId
        $dataflowId = Find-PowerBIDataflow -name $dataflowName -workspaceId $workspaceId
        Set-PowerBIDataflowSettings -dataflowId $dataflowId -workspaceId $workspaceId -updateRequest $flowDef


        Write-Verbose "[Set-PowerBIDataflow] Remove $prevDataflowName if exists"
        $prevDataflow = Find-PowerBIDataflow -Name $prevDataflowName  -WorkspaceId $workspaceId
        if($prevDataflow) {
            Remove-PowerBIDataflow -workspaceId $workspaceId -dataflowId $prevDataflow
        }
    }


    Write-Verbose "[Set-PowerBIDataflow] bind $dataflowName to $gatewayName"
    #Add-PowerBIDataflowGateway -dataflowId $dataflow.Id -gatewayName $gatewayName -gatewayId $gatewayId
    Set-DataflowGateway -dataflowId $dataflowId `
        -workspaceId $workspaceId `
        -gatewayName $gatewayName `
        -gatewayId $gatewayId `
        -dataflowSettings $dataflowSettings `
        -user $user `
        -pass $pass


    Invoke-PowerBIDataflowRefresh -workspaceId $workspaceId -dataflowId $dataflowId

    Write-Verbose "[Set-PowerBIDataflow] add refresh schedule"
    Add-PowerBIDatafowRefreshSchedule -workspaceId $workspaceId -dataflowId $dataflowId -dataflowSettings $dataflowSettings

    Write-Verbose "[Set-PowerBIDataflow] end"    

    return $dataflow
}

function Get-PowerBIDataflowName {
    [CmdletBinding()]
    param (
        # file object
        [Parameter(Mandatory=$true)]
        $item
    )

    Write-Verbose "[Get-PowerBIDataflowName] $($item.BaseName)"
    
    $name = [System.Web.HttpUtility]::UrlDecode($item.BaseName)

    return $name
}

function Get-DataflowConfig {
    [CmdletBinding()]
    param (
        # octopus deploy package path. Searching for Config\reports.json
        [Parameter(Mandatory=$true)]
        [string]
        $path,
        [string]
        $configPath = "\Config"
    )
    
    
        $dataflowJsonPath = "$($path)$($configPath)\dataflows.json"

        If (-Not (Test-Path $dataflowJsonPath)) {
            Write-Error "$dataflowJsonPath does not exist"
        }
    
        $dataflowJSON = Get-Content -Raw -Path $dataflowJsonPath
        $dataflowConfig = $dataflowJSON | ConvertFrom-Json
        return $dataflowConfig

}

function Set-PowerBIDataflows {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $path,
        # Workspace name
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceName,
        [Parameter(Mandatory = $true)]
        [string]
        $gatewayName,
        [string]
        $gatewayId,
        # PBI user
        [string]
        $user,
        # PBI password
        [string]
        $pass,
        [bool]
        $gatewayOnly = $false,
        [bool]
        $flag = $false
    )

    # TODO: remove config path
    $dataflowConfig = Get-DataflowConfig -path $path #-configPath ""
    $dataflows = $dataflowConfig.dataflows
    $destinationWorkspace = Get-PowerBIWorkspace -Name $workspaceName
    if ($null -eq $destinationWorkspace) {
        Write-Error "[SolidOps.PBI.Dataflows] $workspaceName does not exist or insufficient permissions"
    }

    $workspaceId = $destinationWorkspace.Id

    $dataflowFolder = "$path\$($dataflowConfig.dataflowsFolder)"
    if(-not (Test-Path $dataflowFolder)) {
        Write-Warning "[SolidOps.PBI.Dataflows] Could not find $($dataflowConfig.dataflowsFolder). Dataflows will not be imported"
        return
    }

    $dataflowList = Get-ChildItem $dataflowFolder\*.json
    foreach ($item in $dataflowList) {
        $itemName = Get-PowerBIDataflowName -item $item
        $model = "$itemName.json"
        $dataflowSettings = $dataflows | Where-Object fileName -eq $model 
        if($dataflowSettings) {
            if($gatewayOnly) {
                $itemName = Get-PowerBIDataflowName -item $item

                $dataflow = Find-PowerBIDataflow -name $itemName  -workspaceId $workspaceId
                if($dataflow) {
                    Invoke-TakeOverDataflow -workspaceId $workspaceId -dataflowId $dataflow  
                    
                    Write-Verbose "[Set-PowerBIDataflow] Set dataflow parameters $dataflowName"
                    $flowDef = Set-DataflowDefinition -item $item -dataflowSettings $dataflowSettings
                    Set-PowerBIDataflowSettings -dataflowId $dataflow -workspaceId $workspaceId -updateRequest $flowDef
                                    
                    Set-DataflowGateway -dataflowId $dataflow `
                        -workspaceId $workspaceId `
                        -gatewayName $gatewayName `
                        -gatewayId $gatewayId `
                        -dataflowSettings $dataflowSettings `
                        -user $user `
                        -pass $pass

                    Write-Verbose "[Set-PowerBIDataflows] update data gateway data sources connection for $itemName"
                } else {
                    Write-Warning "[SolidOps.PBI.Dataflows] could not find dataflow $itemName"
                }
            } else {
                $newDataflow = Set-PowerBIDataflow -item $item `
                    -workspaceId $workspaceId `
                    -gatewayName $gatewayName `
                    -gatewayId $gatewayId `
                    -dataflowSettings $dataflowSettings `
                    -user $user `
                    -pass $pass `
                    -flag $flag

                Write-Verbose "[Set-PowerBIDataflows] created dataflow $itemName with id $($newDataflow.Id)"
            }
        } else {
            Write-Warning "[SolidOps.PBI.Dataflows] Dataflow $itemName not configured for deployment"
        }

        
    }
    
}

function Find-PowerBIDataflow {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        [Parameter(Mandatory=$true)]
        [string]
        $name
    )
    
    $dataflows = Get-PowerBIDataflows -workspaceId $workspaceId
    $dataflow = $dataflows.value | Where-Object { $_.name -eq $name }
    if($dataflow) {
        return $dataflow.objectId
    } else {
        return $null
    }
    #return $dataflow
}

function Get-PowerBIDataflows {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId
    )
    
    Write-Verbose "[Get-PowerBIDataflows] get dataflows for workspace $workspaceId"
    $url = "https://api.powerbi.com/v1.0/myorg/groups/$workspaceId/dataflows"
    $dataflows = Invoke-SolidOpsPBIRestMethod -url $url -method Get
    return $dataflows
}

function Set-DataflowsRefreshSettings {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceName,
        # Reports path
        [Parameter(Mandatory=$true)]
        [string]
        $path,
        [Parameter(Mandatory=$true)]
        [string]
        $contacts
    )

    $dataflowConfig = Get-DataflowConfig -path $path

    $workspace = Get-Workspace -workspaceName $workspaceName
    $workspaceId = $workspace.id

    $dataflows = $dataflowConfig.dataflows

    $pbiDataflows = Get-PowerBIDataflows -workspaceId $workspaceId

    foreach ($dataflow in $dataflows) {
        Write-Verbose "Dataflows"
        $df = $pbiDataflows.value | Where-Object { $_.name -eq $dataflow.name }
        if($df) {
            
            $dataflowId = $df.objectId
            Set-DataflowRefreshContactList -workspaceId $workspaceId -dataflowId $dataflowId -contacts $contacts
        } else {
            Write-Warning "[Set-DataflowsRefreshSettings] dataflow $($dataflow.name) not found in workspace $workspaceId. Please check if it has been already deployed."
        }
    }
}

