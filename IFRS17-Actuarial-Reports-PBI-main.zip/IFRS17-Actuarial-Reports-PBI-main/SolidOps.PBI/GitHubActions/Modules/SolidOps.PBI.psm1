$global:SolidOpsSession = [ordered]@{
    User                = $null
    Pass                = $null
    EnvCode             = $null
    AuthToken           = $null
    WorkspaceConfig     = $null
    ReportsConfig       = $null
    DataflowsConfig     = $null
    Workspace           = $null
    Developers          = "alexandru.chiraples@beazley.com"
    BaseUIDomain        = "https://wabi-north-europe-redirect.analysis.windows.net"
    #https://WABI-UK-SOUTH-api.analysis.windows.net
    #BaseUIDomain        = "https://app.powerbi.com"
    TeamName            = $null
    UserType            = $null
    TenantId            = $null
}

#region General
 
<#
.Synopsis
    Load module
.Description
    Install-Module if it does not exist. Import-Module
.Example
    PS C:\> Load-Module "MicrosoftPowerBIMgmt"
.Parameter moduleName
    Module name
#>
function Load-Module {
    Param (
        # Module name
        [Parameter(Mandatory=$true)]
        [string]
        $moduleName
    )

    # If module is imported say that and do nothing
    if (Get-Module | Where-Object { $_.Name -eq $moduleName }) {
        Write-Verbose "Module $moduleName is already imported."
    }
    else {

        # If module is not imported, but available on disk then import
        if (Get-Module -ListAvailable | Where-Object { $_.Name -eq $moduleName }) {
            Import-Module $moduleName 
        }
        else {

            # If module is not imported, not available on disk, but is in online gallery then install and import
            if (Find-Module -Name $moduleName | Where-Object { $_.Name -eq $moduleName }) {
                Install-Module -Name $moduleName -Force -Scope CurrentUser -Repository 'PSGallery'
                Import-Module $moduleName 
            }
            else {

                # If module is not imported, not available and not in online gallery then abort
                Write-Error "[SolidOps.PBI] Module $moduleName not imported, not available and not in online gallery, exiting."
                EXIT 1
            }
        }
    }
}



<#
.Synopsis
    Get environment code
    TODO: Make use of Environment & Helpers library set
.Description
    Get environment code based on Octopus Environment name
.Example
    PS C:\> Get-EnvironmentCode 'System Test'
.Parameter env
    Environment name
#>
function Get-EnvironmentCode {
    [CmdletBinding()]
    param (
        # Environment name
        [Parameter(Mandatory=$true)]
        [string]
        $env
    )

    $code = "NA"
    switch ($env) {
        "Development" { 
            $code = "DEV";
            break
        }
        "SYS" {
            $code = "SYS";
            break
        }
        "UAT" {
            $code = "UAT";
            break
        }
        "PRD" {
            $code = "PRD";
            break
        }
        Default {
            throw "[SolidOps.PBI] No matching environment for $env"
        }
    }
    
    $global:SolidOpsSession.EnvCode = $code

    return $code
    
}

function Set-TeamName {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $teamName
    )
    
    $global:SolidOpsSession.TeamName = $teamName
   
}

<#
.Synopsis
    Connect to power bi
.Description
    Support for interactive login and credentials
    TODO: applicationId and secret
.Example
    PS C:\> Load-Assemblies 'C:\Package\SolidOps.PBI\lib'
.Parameter rootPath
    Root path to assemblies
#>
function Connect-PBI {
    [CmdletBinding()]
    Param(
        [string]$user,
        [string]$pass,
        [string]$userType = "ServiceAccount",
        [string]$tenantId
    )
    if(($user) -and ($pass)) {
        
        # Connect to PBI using specified credentials
        $securedPassword = ConvertTo-SecureString $Pass -AsPlainText -Force
        $pbiServiceAccountCred = New-Object System.Management.Automation.PSCredential ($User, $securedPassword)
        if($userType -eq "ServiceAccount") {
            Write-Verbose "Connected using service account"
            Connect-PowerBIServiceAccount -Credential $pbiServiceAccountCred
        } else {
            Write-Warning "Connected using service principal"
            Connect-PowerBIServiceAccount -Tenant $tenantId -Credential $pbiServiceAccountCred -ServicePrincipal
        }


        $global:SolidOpsSession.User = $user
        $global:SolidOpsSession.Pass = $pass
        $global:SolidOpsSession.UserType = $userType
        $global:SolidOpsSession.TenantId = $tenantId

        $accessToken = Get-PowerBIAccessToken
        $bearer = $accessToken.Authorization.ToString()
        $global:SolidOpsSession.AuthToken = $bearer

        Write-Verbose "Connected $user to Power BI Service"
    } else {
        Write-Warning "No credentials specified for the PBI Service. Proceed with interactive login"
        # connect to PBI using interactive login
        Connect-PowerBIServiceAccount
        Write-Verbose "Connected to Power BI Service using specified user"
    }
}

#endregion

#region Encryption


<#
.Synopsis
    Load assemblies required to encrypt credentials
.Description
    
.Example
    PS C:\> Load-Assemblies 'C:\Package\SolidOps.PBI\lib'
.Parameter rootPath
    Root path to assemblies
#>
function Load-Assemblies {
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $rootPath
    )
    # Newtonsoft.Json.dll already loaded
    #$dllNewton = "$rootPath\Newtonsoft.Json.dll"
    #Add-Type -Path $dllNewton

    # Load specific Cryptography version
    $dllCrypto = "$rootPath\System.Security.Cryptography.Cng.dll"
    Add-Type -Path $dllCrypto

    # Microsoft.Rest.ClientRuntime.dll already loaded
    # $dllRest = "$libPath\Microsoft.Rest.ClientRuntime.dll"
    # Add-Type -Path $dllRest

    $dllPath = "$rootPath\Microsoft.PowerBI.Api.dll"
    Add-Type -Path $dllPath 

    # Load the credential helper
    $dllHelper = "$rootPath\Beazley.PowerBI.DataGateway.Automation.dll"
    Add-Type -Path $dllHelper
}

function Get-CredentialDetails([string]$user, [string]$pass, [string]$exponent, [string]$modulus) {
    $credHelper = New-Object Beazley.PowerBI.DataGateway.Automation.CredentialHelper
    return $credHelper.GetEncryptedCredentials($user, $pass, $exponent, $modulus)
}

#endregion

<#
.Synopsis
    Get Gateway
.Description
    Get gateway using name
.Example
    
.Parameter gatewayName
    gateway name
#>
function Get-Gateway {
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $gatewayName
    )

    # GET https://api.powerbi.com/v1.0/myorg/gateways
    $url = "https://api.powerbi.com/v1.0/myorg/gateways"
    
    
    $bearer = $global:SolidOpsSession.AuthToken

    $headers = @{
        'Authorization' = "$bearer" 
    }
    $gateways = Invoke-RestMethod -Uri $url -Method GET -Headers $headers
    $gatewayRestMethod = $gateways | ConvertTo-Json
    #write-host "Original Gateways:" $gatewayRestMethod
    $gateway = $gateways.value | Where-Object {$_.name -eq $gatewayName}
    #write-host "Multiple Gateways" $gateways
    #write-host "Single Gateway" $gateway

    # Get gatewayID based on OD parameter with gateway name
    if($($gateway.id)) {
        Write-Verbose "Gateway Id : $($gateway.id)"
    } else {
        throw "[SolidOps.PBI] Gateway not found or missing permissions."
    }

    return $gateway
}


# TODO: refactor and use version 2 of this function
function Get-MicrosoftToken {
    [CmdletBinding()]
    param (
        # username
        [Parameter(Mandatory = $true)]
        [string]
        $user,
        # password
        [Parameter(Mandatory = $true)]
        [string]
        $pass,
        # resource
        [Parameter(Mandatory = $true)]
        [string]
        $resource,
        $scope
    )

    <#
    client_id	2ad88395-b77d-4561-9441-d0e40824f9bc	Default Client Id which is setup against Dynamics 365 Online instances.
    resource	https://authenticatedemo.crm6.dynamics.com/	Dynamics 365 Online Instance URL
    username	john@authenticatedemo.onmicrosoft.com	Active CRM Users username
    password	Passw0123	Active CRM Users password
    grant_type	password	
    Password set as a grant type

    #>
    
    $postParams = @{
        client_id  = "2ad88395-b77d-4561-9441-d0e40824f9bc"
        resource   = $resource
        username   = $user
        password   = $pass
        grant_type = "password"
    }

    if($scope) {
        $postParams += @{ scope = $scope}
    }
    
    # TODO: use tenant id 
    <#
        POST /{tenant}/oauth2/v2.0/token HTTP/1.1
        Host: https://login.microsoftonline.com
        Content-Type: application/x-www-form-urlencoded
    #>

    $jsonPostBody = $postParams 
    $url = "https://login.microsoftonline.com/common/oauth2/token"
    
    try {
        $response = Invoke-RestMethod -Uri $url `
            -Body $jsonPostBody `
            -ContentType "application/x-www-form-urlencoded" `
            -Headers $headers `
            -Method POST
        
        return $response 
            # $access_token = $response.access_token
            # return $access_token
    
    }
    catch {
        $jsonPostBody
    
        Write-Error $_ 
        
    
        Write-Verbose "[] Server response start"
        
        $_.Exception.ErrorDetails | ConvertTo-Json
        $_.Exception.Response | ConvertTo-Json
        Write-Verbose "[] Server response end"
    
    }
}


function Get-MicrosoftToken2 {
    [CmdletBinding()]
    param (
        # username
        [Parameter(Mandatory = $true)]
        [string]
        $user,
        # password
        [Parameter(Mandatory = $true)]
        [string]
        $pass,
        # resource
        [Parameter(Mandatory = $true)]
        [string]
        $resource,
        [Parameter(Mandatory = $true)]
        [string]
        $clientId,
        $scope,
        [string]$grantType ="password"
    )

    Write-Verbose "[Get-MicrosoftToken2] Begin process for user $user, client $clientId and resource $resource"
    $postParams = $null
    $url = $null
    $_scope = $scope
    if($grantType -eq "password") {
        $url = "https://login.microsoftonline.com/beazley.onmicrosoft.com/oauth2/token"
        $postParams = @{
            client_id  = $clientId
            resource   = $resource
            username   = $user
            password   = $pass
            grant_type = $grantType
        } 
    } elseif($grantType -eq "client_credentials") {
        Write-Warning "client_credentials flow"
        $url = "https://login.microsoftonline.com/beazley.onmicrosoft.com/oauth2/v2.0/token"
        if($_scope) {
            $_scope = "$($_scope)/.default"
        } else {
            if ($resource) {
                $_scope = "$($resource)/.default"
            }
        }
        $postParams = @{
            client_id  = $user
            client_secret = $pass
            grant_type = $grantType
        } 
    } else {
        Write-Error "Grant type $grantType not support"
    }

    if($_scope) {
        $postParams += @{ scope = $_scope}
    }
    
    # TODO: use tenant id 
    <#
        POST /{tenant}/oauth2/v2.0/token HTTP/1.1
        Host: https://login.microsoftonline.com
        Content-Type: application/x-www-form-urlencoded
    #>

    $jsonPostBody = $postParams 
    
    try {
        $response = Invoke-RestMethod -Uri $url `
            -Body $jsonPostBody `
            -ContentType "application/x-www-form-urlencoded" `
            -Headers $headers `
            -Method POST
        
        return $response 
            # $access_token = $response.access_token
            # return $access_token
    
    }
    catch {
        $jsonPostBody
    
        Write-Error $_ 
        
    
        Write-Verbose "[] Server response start"
        
        $_.Exception.ErrorDetails | ConvertTo-Json
        $_.Exception.Response | ConvertTo-Json
        Write-Verbose "[] Server response end"
    
    }
}



function Invoke-SolidOpsPBIRestMethod {
    [CmdletBinding()]
    param (
        # url
        [Parameter(Mandatory=$true)]
        [string]
        $url,
        # Method
        [Parameter(Mandatory=$true)]
        [ValidateSet("Get", "Post", "Delete", "Put", "Patch")]
        $method,
        $additionalHeaders,
        $postBody,
        $contentType = "application/json",
        $usePBIToken = $true
    )

    $uri = "$url"

    $accessToken = Get-PowerBIAccessToken
    $bearer = $accessToken.Authorization.ToString()

    $headers = @{}

    if($usePBIToken) {
        $headers += @{
            'Authorization' = "$bearer" 
        }
    }

    if($additionalHeaders) {
        $headers = $headers + $additionalHeaders
    }

    $parms = @{
        'Uri' = $uri
        'Method' = $method
        'Headers' = $headers
    }

    if($postBody) {
        if($contentType -eq "application/json") {
            $postBody = $postBody | ConvertTo-Json -Depth 4
        }
        
        $parms += @{ 'Body' = $postBody }
        $parms += @{ 'ContentType' = $contentType }
    }


    try {
        $response = Invoke-RestMethod @parms

        return $response
    }
    catch {
        Write-Verbose "[Invoke-SolidOpsPBIRestMethod] URL: $uri"
        if ($postBody) {
            $paramJson = $postBody | ConvertTo-Json -Depth 4
            Write-Verbose "[Invoke-SolidOpsPBIRestMethod] Post body: $paramJson"
        } else {
            if($method -eq 'Put' -or $method -eq 'Post') {
                Write-Warning "[SolidOps.PBI] [Invoke-SolidOpsPBIRestMethod] Post body missing"
            }
        }

        Write-Verbose "[Invoke-SolidOpsPBIRestMethod] Server response stream"
        if($_.Exception) {

            if($_.Exception.Response) {

                    
                $respStream = $_.Exception.Response.GetResponseStream()
                $reader = New-Object System.IO.StreamReader($respStream)
                $respBody = $reader.ReadToEnd()

                if($respBody) {
                    $respBodyJson = $respBody | ConvertFrom-Json

                    Write-Warning $respBodyJson
                   
                    if($respBodyJson.error) {
                        $errJson = $respBodyJson.error
                        if($errJson.code) {
                            $errorCode = $errJson.code
                            $message = ""
                            if($errJson.{pbi.error}) {
                                $err = $errJson.{pbi.error}
                                Write-Verbose "found pbi.error"
                                # set error code
                                if($err.code) {
                                    if ($err.code -ne $errorCode) {
                                       $errorCode = $errorCode + " -> " + $err.code
                                    }
                                }

                                # set error message
                                if($err.message) {
                                    $message = $err.message
                                }
                                if($err.details) {
                                    foreach ($detailMsg in $err.details) {
                                     
                                        if($detailMsg.message) {
                                            $message = $message + " - " + $detailMsg.code + ":" + $detailMsg.message + "|"
                                        } else {
                                            if($detailMsg.detail) {
                                                if($detailMsg.code -eq "DM_ErrorDetailNameCode_UnderlyingErrorMessage") {
                                                    $message = $message + " - " + $detailMsg.detail.value
                                                }
                                            } 
                                        } 

                                    }
                                }

                            } else {
                                if($errJson.message) {
                                    $message = $errJson.message
                                }

                                if($errJson.details) {
                                    foreach ($detailMsg in $errJson.details) {
                                        $message = $message + " - " + $detailMsg.message   
                                    }
                                    
                                }
                            }
                            Write-Warning $respBody

                            $errorMessage = $errorCode
                            if($message -ne "") {
                                $errorMessage = "$($errorCode): $($message)"
                            }
                            Write-Error "[SolidOps.PBI] $($errorMessage)" 
                        }
                    }

                    
                } else {
                    Write-Warning "Could not read response body"
                }
                
                Write-Warning $respBody

                

                $exResponse = $_.Exception.Response | ConvertTo-Json
                Write-Verbose "Exception response: $exResponse"

            } else {
                Write-Warning "Missing $_.Exception.Response"
            }

            Write-Verbose "[Invoke-SolidOpsPBIRestMethod] Server response start"
            $errorDetails = $_.Exception.Details | ConvertTo-Json
            Write-Verbose "Error details: $errorDetails"
            
            

        } else {
            Write-Warning "Missing $_.Exception"
        }
        #$exResponse2 = $_.Exception | ConvertTo-Json
        #Write-Verbose "Exception: $exResponse2"

        Write-Verbose "[Invoke-SolidOpsPBIRestMethod] Server response end"

        Write-Error $_ 
    }
}

<#
 
    .COPYRIGHT
    Copyright (c) Office Center Hønefoss AS. All rights reserved. Licensed under the MIT license.
    See https://github.com/officecenter/Autotask/blob/master/LICENSE.md for license information.
 
#>

Function ConvertFrom-XML {
    <#
        .SYNOPSIS
        This function converts an array of XML elements to a custom psobject for easier parsing and coding.
        .DESCRIPTION
        The function an array of XML elements and recursively converts each element to a custom PowerShell
        object. Each XML property is converted to an object property with a value of datetime, double,
        integer or string.
        .INPUTS
        [System.XML.XmlElement []]
        .OUTPUTS
        [System.Object[]]
        .EXAMPLE
        $Element | ConvertTo-PSObject
        Converts variable $Element with must contain 1 or more Xml.XmlElements to custom PSobjects with the
        same content.
        .NOTES
        NAME: ConvertTo-PSObject
         
    #>
    [cmdletbinding()]
    Param
    (
      [Parameter(
        Mandatory = $True,
        ValueFromPipeLine = $True,
        ParameterSetName = 'Input_Object'
      )]
      [Xml.XmlElement[]]
      $InputObject
    )
  
    Begin {
      $Result = @()
  
      # Set up TimeZone offset handling
      If (-not($script:ESTzone)) {
        $script:ESTzone = [System.TimeZoneInfo]::FindSystemTimeZoneById("Eastern Standard Time")
      }
      
      If (-not($script:ESToffset)) {
        $Now = Get-Date
        $ESTtime = [System.TimeZoneInfo]::ConvertTimeFromUtc($Now.ToUniversalTime(), $ESTzone)
  
        $script:ESToffset = (New-TimeSpan -Start $Now -End $ESTtime).TotalHours 
      }
    }
    Process {
          
      Foreach ($Element in $InputObject) {
        # Get properties
        $Properties = $Element | Get-Member -MemberType Property 
      
        # Create a new, empty object
        $Object = New-Object -TypeName PSObject
      
        # Loop through all properties and add a member for each
        Foreach ($Property in $Properties) {
          # We are accessing property values by dynamic naming. It is a lot easier
          # to reference dynamic property names with a string variable
          $PropertyName = $Property.Name
              
          # Extract/create a value based on the property definition string
          Switch -Wildcard ($Property.Definition) {
              
            # Most properties are returned as strings. We will use a few tests to
            # try to recognise other value types
            'string*' {
              # Test if it is a date first
              Try {
                # If it isn't a date we'll get an exception
                [DateTime]$DateTime = $Element.$PropertyName
                    
                # If we are here, then we have a date.
                $Value = $DateTime.AddHours($script:ESToffset)
              }
              Catch {
                # This isn't a date. We'll use a regex to avoid turning integers into doubles
                Switch -regex ($Element.$PropertyName) { 
                  '^\d+\.\d{4}$' { 
                    [Double]$Double = $Element.$PropertyName
                    $Value = $Double
                  }
                      
                  '^\d+$' { 
                    [Int]$Integer = $Element.$PropertyName
                    $Value = $Integer
                  }
                  Default 
                  {$Value = $Element.$PropertyName}
                }
              }
              Add-Member -InputObject $Object -MemberType NoteProperty -Name $PropertyName -Value $Value                                              
            }
                
            # For properties that are XML elements; recurse
            'System.Xml.XmlElement*' {
              # A bit of recursive magic here...
              $Value = $Element.$PropertyName | ConvertFrom-XML
              Add-Member -InputObject $Object -MemberType NoteProperty -Name $PropertyName -Value $Value                              
            }
                
            # Arrays. Loop through elements and perform recursive magic
            'System.Object*' {
              $Value = @()
              Foreach ($Item in $Element.$PropertyName) 
              {$Value += $Item | ConvertFrom-XML}
              Add-Member -InputObject $Object -MemberType NoteProperty -Name $PropertyName -Value $Value                              
            }
                
            # Blatant misuse of the default clause for saving a bit of typing...
          }
        }
      }
  
      $Result += $Object
    }
  
    End {
      Return $Result
    }
  }

  function Set-CleanEmail {
    [CmdletBinding()]
    param (
        # email
        [string]
        $email,
        [Parameter(Mandatory=$true)]
        [string]
        $functionName,
        # od variable
        [Parameter(Mandatory=$true)]
        [string]
        $variableName
    )
    
    $newEmail = $null
    if($email) {
        $newEmail = $email.Trim()
        if($newEmail.Length -ne $email.Length) {
            Write-Warning "[$($functionName)] additional white space ' ' found in $($variableName)"
        }

    } else {
        Write-Warning "[$($functionName)] trailing ; found in variable $($variableName)"
    }

    return $newEmail
    
}

function Test-MissingVariable {
    [CmdletBinding()]
    param (
        $appParameters,
        $varName
    )
    #Write-Verbose "[Test-MissingVariable] begin"

    if($appParameters[$varName]) {
        $varValue = $appParameters[$varName]
        if(-not $varValue -or $varValue -match $varName -or $varValue.StartsWith("#{")) {
            Write-Verbose "[Test-MissingVariable] Variable $varName configured with $varValue"
            return $true
        } else {
            #Write-Verbose "[Test-MissingVariable] Variable $varName configured with $varValue"
            return $false
        }
    } else {
        Write-Verbose "[Test-MissingVariable] Variable $varName not configured"
        return $true
    }

    Write-Verbose "[Test-MissingVariable] end"
}

function Invoke-ValidateConfig {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        $appParameters,
        [Parameter(Mandatory=$true)]
        $variableChecks
    )
    $vars = ""
    $checks = ""

    $valid = $true

    #$variableChecks = $variables -Split ";"

    foreach ($varName in $variableChecks) {
        $result = Test-MissingVariable -varName $varName -appParameters $appParameters
        
        if($result) {
            $vars += "$($varName), "
            $varValue = $appParameters[$varName]
            
            if($varValue.StartsWith("#{")) {
                $checks += "- variable $($varValue) referenced in $($varName) does not exist for the selected environment `n"
            } else {
                $checks += "- variable $($varName) has been created and configured properly `n"
            }

            $valid = $false
        } else {
            Write-Verbose "[Invoke-ValidateConfig] Variable $($varName) configured."
        }
    }

    if($valid) {
        return;
    } else {
        $vars = $vars.Substring(0, $vars.Length - 2)

        $checks = "- you have included your <team>-SolidOps.PBI Variable Set in Project -> Variables -> Library sets `n" + $checks
        $checks = "Please check if: `n" + $checks
        $message = "[SolidOps.PBI] The following variables have not been configured: $($vars)"
        $fullStack = $message + " `n" + $checks
        Write-Warning $fullStack
        Fail-Step $message
    }
}