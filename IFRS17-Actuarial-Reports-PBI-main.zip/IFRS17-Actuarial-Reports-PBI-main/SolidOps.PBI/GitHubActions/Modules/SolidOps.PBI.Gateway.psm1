#region PowerBI Data Gateway



<#
.Synopsis
    Get datasource name
.Description
    Get dbname - envcode
.Example
    
.Parameter dbName
    databasase name

.Parameter envCode
    environment code

.Parameter team
    Team name. Ex: DM, Drake
#>
function Get-DataSourceName {
    [CmdletBinding()]
    Param(
        # data source name - default db name
        [Parameter(Mandatory=$true)]
        [string]
        $dbName,
        [Parameter(Mandatory=$true)]
        [string]
        $envCode,
        [Parameter(Mandatory=$true)]
        [string]
        $team
    )
    return "$($team)-$($dbName)-$($envCode)"
}

<#
.Synopsis
    Get datasource list
.Description
    
.Example
    
.Parameter gatewayId
    Gateway Id
#>
function Get-DataSources {#([string]$id) {
    param(
       # GatewayId
       [Parameter(Mandatory=$true)]
       [string]
       $gatewayId
    )
    # Get data sources 
    # GET https://api.powerbi.com/v1.0/myorg/gateways/{gatewayId}/datasources

    $url = "https://api.powerbi.com/v1.0/myorg/gateways/$gatewayId/datasources"

    $accessToken = Get-PowerBIAccessToken
    $bearer = $accessToken.Authorization.ToString()

    $headers = @{
        'Authorization' = "$bearer"
    }

    Write-Verbose "[Get-DataSources] URL $url"
    $dataSources = Invoke-RestMethod -Uri $url -Method GET -Headers $headers
    Write-Verbose "[Get-DataSources] finished"
    return $dataSources
}

<#
.Synopsis
    Get datasource list
.Description
    
.Example
    
.Parameter gatewayId
    Gateway Id
#>
function Get-Datasource {
    param(
        # GatewayId
        [Parameter(Mandatory=$true)]
        [string]
        $gatewayId,
        # Datasource Name
        [Parameter(Mandatory=$true)]
        [string]
        $datasourceName
    )

    $dataSources = Get-DataSources -gatewayId $gatewayId
	
    # return data source 
    $ds = $dataSources.value | Where-Object {$_.datasourceName -eq $datasourceName}
    if ($null -eq $ds) {
        Write-Verbose "[Get-DataSource] could not find $datasourceName"
    } 
    return $ds
}

function Update-DatasourceSSO {
    [CmdletBinding()]
    param (
        # Gateway ID
        [Parameter(Mandatory=$true)]
        [string]
        $gatewayId,   
        # Datasource ID
        [Parameter(Mandatory=$true)]
        [string]
        $datasourceId,
        $singleSignonType = "1"
        
    )

    Write-Verbose "[Update-DatasourceSSO] begin for datasource id $datasourceId"
    Write-Warning "[SolidOps.PBI.Gateway] Experimental API https://api.powerbi.com/v2.0/myorg/me"
    $url = "https://api.powerbi.com/v2.0/myorg/me/gatewayclusters/$($gatewayId)/datasources/$($datasourceId)"

    $accessToken = Get-PowerBIAccessToken
    $bearer = $accessToken.Authorization.ToString()

    $headers = @{
        'Authorization' = "$bearer"
    }

    $postParams = @{
        'singleSignonType' = "$singleSignonType"
    }

    $jsonPostBody = $postParams | ConvertTo-Json

    try {
        Invoke-RestMethod -Uri $url `
                -Body $jsonPostBody `
                -ContentType "application/json" `
                -Headers $headers `
                -Method PATCH
    } 
    catch {
        Write-Warning "[SolidOps.PBI] Could not update SSO for $datasourceId"
        Write-Verbose "Url: $url"
        Write-Verbose "[Update-DatasourceSSO] Server request post data"
        Write-Verbose $jsonPostBody

        Write-Verbose "[Update-DatasourceSSO] Server response stream"
        $respStream = $_.Exception.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($respStream)
        $respBody = $reader.ReadToEnd() #| ConvertFrom-Json
        Write-Verbose $respBody

        Write-Error $_
        Write-Verbose "[Update-DatasourceSSO] Server response start"
    }

    Write-Verbose "[Update-DatasourceSSO] end"

}

function Set-DatasourceUsers {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$false)]
        [string]
        $Users,
        [Parameter(Mandatory=$true)]
        [string]
        $gatewayId,
        [Parameter(Mandatory=$true)]
        [string]
        $datasourceId,
        [Parameter(Mandatory=$true)]
        [string]
        $accessToken
    )
    
    Write-Verbose "Adding users: $Users"
    # add ds users, one post per user
    if($users) {
        if ($Users -eq '') {
            Write-Error "pbi.datasource.users empty"
        } 
        
        if ($Users -ne '#{pbi.datasource.users}') {
            Write-Error "pbi.datasource.users not initialized"
        }
        
        $userList = $Users
        if($Users.StartsWith("App.PowerBI")) {
            # security group
            $userList = ""
            $groupId = Get-AzureADGroupByName -displayName $Users

            $members = Get-AzureADGroupMembers -groupId $groupId -accessToken $accessToken
            foreach ($item in $members.value) {
                $userList += $item.mail + ";"
            }

        }

        # if string not empty
        Add-DataSourceUsers -gatewayId $gatewayId -datasourceId $datasourceId -users $userList -env $EnvCode
    } else {
        Write-Verbose "[Add-DataSourceUsers] Users have not been defined"
        Write-Verbose "Users value: $Users"
    }
}

function Set-Datasource {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $gatewayId, 
        [Parameter(Mandatory=$true)]
        [string]
        $credentials,
        [Parameter(Mandatory=$true)]
        [string]
        $server, 
        [Parameter(Mandatory=$true)]
        [string]
        $database,
        [string]
        $privacyLevel = 'Organizational',
        [string]
        [ValidateSet('SQL', 'AnalysisServices', 'OleDb')]
        $datasourceType = 'SQL',
        [Parameter(Mandatory=$true)]
        [string]
        $envCode,
        [Parameter(Mandatory=$true)]
        [string]
        $team,
        $users,
        [Parameter(Mandatory=$true)]
        [string]
        $accessToken,
        [Parameter(Mandatory=$true)]
        [string]
        $datasourceNameBase
    )
    
    if($null -eq $datasourceNameBase) {
        $datasourceNameBase = $database
    }

    $dsFqdn = $null

    if($datasourceType -eq "SqlFQDN") {
        $domain = 'bfl.local'
        if(-not $server.Contains($domain))  {
            Write-Verbose "[Set-Datasource] $server does not contain $domain"
            $sp = $server.Split(',')
            $sp2 = $sp[0].Split('\')
            
            $fqdnServer = $sp2[0] + "." + $domain
            if($sp2.Count -gt 1) {
            	$fqdnServer += "\" + $sp2[1]
            }
            if($sp.Count -gt 1) {
                $fqdnServer += "," + $sp[1]
            }
            
            $fqdnDbName = $datasourceNameBase + "-FQDN"
            $fqdnDatasourceName = Get-DataSourceName  -dbName $fqdnDbName -envCode $envCode -team $team
            

            Write-Verbose "[Set-Datasource] Adding datasource $fqdnDatasourceName for $fqdnServer"

            $dsFqdn = Add-Datasource -gatewayId $gatewayId `
                -datasourceName $fqdnDatasourceName `
                -credentials $credentials `
                -server $fqdnServer `
                -database $database `
                -datasourceType $datasourceType

            Write-Verbose "$dsFqdn"

            $datasourceId2 = "$dsFqdn"

            Set-DatasourceUsers -Users $users `
                -gatewayId $gatewayId `
                -datasourceId $datasourceId2 `
                -accessToken $accessToken

            Write-Verbose "[Set-Datasource] finished setting up $dsFqdn"
        }

    }

    $datasourceName = Get-DataSourceName -dbName $datasourceNameBase -envCode $envCode -team $team
    Write-Verbose "[Set-Datasource] Data source name: $datasourceName" 
    

    $dsId = Add-Datasource -gatewayId $gatewayId `
        -datasourceName $datasourceName `
        -credentials $credentials `
        -server $server `
        -database $database `
        -datasourceType $datasourceType


    $datasourceId = "$dsId"
    Set-DatasourceUsers -Users $users -gatewayId $gatewayId -datasourceId $datasourceId -accessToken $accessToken

    return $datasourceId
}

function Add-Datasource {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$true)]
        [string]$datasourceName, 
        [Parameter(Mandatory=$true)]
        [string]$gatewayId, 
        [Parameter(Mandatory=$true)]
        [string]$credentials,
        [Parameter(Mandatory=$true)]
        [string]
        $server, 
        [Parameter(Mandatory=$true)]
        [string]
        $database,
        [string]
        $privacyLevel = 'Organizational',
        [string]
        [ValidateSet('SQL', 'AnalysisServices', 'OleDb')]
        $datasourceType = 'SQL'
    ) 
    $ds = Get-Datasource -gatewayId $gatewayId -datasourceName $datasourceName

    $url = "https://api.powerbi.com/v1.0/myorg/gateways/$($gatewayId)/datasources"
    $accessToken = Get-PowerBIAccessToken
    $bearer = $accessToken.Authorization.ToString()

    $headers = @{
        'Authorization' = "$bearer"
    }

    $datasourceId = ""
    if($null -eq $ds) {
        Write-Verbose "[Add-DataSource] Data source $datasourceName not found. Creating a new data source"
        # https://docs.microsoft.com/en-us/power-bi/developer/automation/configure-credentials?tabs=sdk3
    
        $connDetails = $null
        if($datasourceType -eq 'OleDb') {
            $connDetails = @{
                "connectionString" = "provider=MSOLAP;initial catalog=$database;data source=$server" 
            }
        } else {
            $connDetails = @{
                "server" = $server
                "database" = $database
            }
        }
    
        $postParams = @{
            "dataSourceType" = $datasourceType
            "connectionDetails" = $connDetails | ConvertTo-Json -Compress
            "datasourceName" =  $datasourceName
            "credentialDetails" = @{
                "credentialType" = "Windows"
                "credentials" = $credentials 
                "encryptedConnection" = "Encrypted"
                "encryptionAlgorithm" = "RSA-OAEP"
                "privacyLevel" = $privacyLevel
            }
        }
    
        # https://community.powerbi.com/t5/Developer/Power-BI-REST-API-via-Powershell-Create-Datasource/m-p/511934
    
        $jsonPostBody = $postParams | ConvertTo-Json -Depth 4 
        # $jsonPostBody
    
        $addDs = Invoke-SolidOpsPBIRestMethod -url $url `
            -method POST `
            -postBody $postParams

        $datasourceId = $addDs.id
        
        
        
    } else {
        Write-Verbose "[Add-DataSource] Data source $datasourceName found. Update datasource credentials"
        # add dataset id to url
        $url += "/$($ds.id)"

        $postParams = @{
            "credentialDetails" = @{
                "credentialType" = "Windows"
                "credentials" = $credentials 
                "encryptedConnection" = "Encrypted"
                "encryptionAlgorithm" = "RSA-OAEP"
                "privacyLevel" = $privacyLevel
            }
        }

        # $jsonPostBody = $postParams | ConvertTo-Json -Depth 4 

        Invoke-SolidOpsPBIRestMethod -url $url `
            -method Patch `
            -postBody $postParams

        Write-Verbose "[Add-DataSource] Data source $datasourceName credentials updated"
        $datasourceId = $ds.id
    }

    if($datasourceType -eq 'Sql') {
        Update-DatasourceSSO -gatewayId $gatewayId -datasourceId $datasourceId
    }

    return $datasourceId
    
}

function Set-DatasourcePrincipals {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $gatewayId, 
        # datasource id
        [Parameter(Mandatory=$true)]
        [string]
        $datasourceId,
        [Parameter(Mandatory=$true)]
        [string]
        $pbiUsername,
        [Parameter(Mandatory=$true)]
        [string]
        $dsUsername
    )


    $url = "https://api.powerbi.com/v2.0/myorg/me/gatewayclusters/$($gatewayId)/datasources/$($datasourceId)"

    $accessToken = Get-PowerBIAccessToken
    $bearer = $accessToken.Authorization.ToString()

    $headers = @{
        'Authorization' = "$bearer"
    }
    
    $dsUPN = @{
        "dataSourceAnnotationUPNMapping" = @{
            "connectionStringPropertyName" = 0
            "mappingRules" = @(
                @{
                    "algorithm" = 1
                    "searchString" = $pbiUsername
                    "replacementString" = $dsUsername
                }
            )
        }
    }

    $postParams = @{
        "datasourceAnnotation" = $dsUPN | ConvertTo-Json -Depth 4 -Compress
    }

    $jsonPostBody = $postParams | ConvertTo-Json -Depth 4

    try {
        Invoke-RestMethod -Uri $url `
                -Body $jsonPostBody `
                -ContentType "application/json" `
                -Headers $headers `
                -Method Patch
    }
    catch {
        Write-Warning "[SolidOps.PBI.Gateway] Could not add annotation"
        Write-Verbose "Url: $url"
        Write-Verbose "[Set-DatasourcePrincipals] Server request post data"
        Write-Verbose $jsonPostBody

        Write-Verbose "[Set-DatasourcePrincipals] Server response stream"
        $respStream = $_.Exception.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($respStream)
        $respBody = $reader.ReadToEnd() #| ConvertFrom-Json
        $respBody;
        Write-Verbose $respBody

        $rsp = $_.Response
       #([System.IO.StreamReader]$_.Exception.Response.GetResponseStream()).ReadToEnd() 

        Write-Verbose "[Set-DatasourcePrincipals] Server response start"
        

        Write-Verbose $_.Exception.Response | ConvertTo-Json
        
        Write-Verbose "[Set-DatasourcePrincipals] Server response end"

        Write-Error $_ 
    }
}

function Add-DataSourceUser {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $gatewayId,
        [Parameter(Mandatory=$true)]
        [string]
        $datasourceId,
        [Parameter(Mandatory=$true)]
        [string]
        $email,
        [Parameter(Mandatory=$true)]
        [string]
        $env
    )
    
    # POST https://api.powerbi.com/v1.0/myorg/gateways/{gatewayId}/datasources/{datasourceId}/users
    Write-Verbose "[Add-DataSourceUser] start"
    if($env -eq 'PRD') { 
        Write-Error "Additional users are not eligible for Production environment"
        exit
    }

    if($env -eq 'UAT') { 
        Write-Error "Additional users are not eligible for User Acceptance Testing environment"
        exit
    }

    if($email.StartsWith("App.PowerBI")) { 
        Write-Error "Security groups cannot be added to data source users."
        exit
    }


    $postParams = @{
        #emailAddress = $email
        datasourceAccessRight = "Read"
        #emailAddress = $email
    }

    if ($email -contains "@") {
        $postParams += @{
            emailAddress = $email
        }
    } else {
        # identifier
        $postParams += @{
            identifier = $email
        }
    }

    


    #$jsonPostBody = $user | ConvertTo-Json

    $url = "https://api.powerbi.com/v1.0/myorg/gateways/$($gatewayId)/datasources/$($datasourceId)/users"
    # $accessToken = Get-PowerBIAccessToken
    # $bearer = $accessToken.Authorization.ToString()

    # $headers = @{
    #     'Authorization' = "$bearer"
    # }

    # try {
        Write-Verbose "[Add-DataSourceUser] proces"

        Invoke-SolidOpsPBIRestMethod -url $url `
            -method POST `
            -postBody $postParams

        # Invoke-RestMethod -Uri $url `
        #         -Body $jsonPostBody `
        #         -ContentType "application/json" `
        #         -Headers $headers `
        #         -Method POST
        Write-Verbose "Added $email to data source"
    # }
    # catch {
    #     Write-Warning "Could not add $email to data source users"
    #     Write-Verbose "[Add-DataSourceUser] Server request post data"
    #     Write-Verbose $jsonPostBody

    #     Write-Verbose "[Update-DatasourceSSO] Server response stream"
    #     $respStream = $_.Exception.Response.GetResponseStream()
    #     $reader = New-Object System.IO.StreamReader($respStream)
    #     $respBody = $reader.ReadToEnd() #| ConvertFrom-Json
    #     Write-Verbose $respBody

    #     Write-Verbose "[Add-DataSourceUser] Server response start"
    #     $_.Exception.Response | ConvertTo-Json
    #     Write-Verbose "[Add-DataSourceUser] Server response end"

    #     Write-Error $_ 
    # }

    Write-Verbose "[Add-DataSourceUser] end"
}

function Add-DataSourceUsers {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $gatewayId,
        [Parameter(Mandatory=$true)]
        [string]
        $datasourceId,
        [Parameter(Mandatory=$true)]
        [string]
        $users,
        [Parameter(Mandatory=$true)]
        [string]
        $env
    )
    
    
        Write-Verbose "[Add-DataSourceUsers] begin"
        if ($env -eq 'PRD') {
            Write-Warning "Additional users are not eligible for Production environment"
            exit
        }

        $url = "https://api.powerbi.com/v1.0/myorg/gateways/$($gatewayId)/datasources/$($datasourceId)/users"
        $accessToken = Get-PowerBIAccessToken
        $bearer = $accessToken.Authorization.ToString()

        $headers = @{
            'Authorization' = "$bearer"
        }

        Write-Verbose "URL: $url"

    
        Write-Verbose "[Add-DataSourceUsers] process" 
        $dsUserList = Invoke-RestMethod -Uri $url -Method GET -Headers $headers
        
        $userArray = $users.Split(";")
        foreach ($item in $userArray) {
            $item = Set-CleanEmail -email $item -functionName "Add-DataSourceUsers" -variableName "pbi.datasource.users"
            if($item) {
                Write-Verbose "Searching for $item in data source users"
                $user = $dsUserList.value | Where-Object { $_.emailAddress -eq $item }
                
                if($null -eq $user) {
                    Write-Verbose "User $item not found. Add user to datasource"
                    Add-DataSourceUser -gatewayId $gatewayId -datasourceId $datasourceId -email $item -env $env
                } else {
                    Write-Verbose "User $item already configured for datasource"
                }
            }
        }

  
        Write-Verbose "[Add-DataSourceUsers] end"
}

#endregion

function Set-CloudDataGateway {
    [CmdletBinding()]
    param (
        # Gateway id
        [Parameter(Mandatory=$true)]
        [string]
        $gatewayId,
        [Parameter(Mandatory=$true)]
        [string]
        $datasourceId,
        # Oauth2 token
        [Parameter(Mandatory=$true)]
        $token,
        [ValidateSet('Anonymous', 'OAuth2', 'Key')]
        $credentialType = "OAuth2",
        [ValidateSet('None', 'Private', 'Organizational')]
        $privacyLevel = "None"
    )

    Write-Verbose "[Update-CloudDataGateway] begin"

    # PATCH https://api.powerbi.com/v1.0/myorg/gateways/{gatewayId}/datasources/{datasourceId}
    $url = "https://api.powerbi.com/v1.0/myorg/gateways/$($gatewayId)/datasources/$($datasourceId)"

    $credentials = $null
    if($credentialType -eq "Anonymous") {
        # https://docs.microsoft.com/en-us/rest/api/power-bi/gateways/update-datasource#anonymous-credentials-example
        # If the url does not work by pasting it in the browser, you will need to skip test connection"
        $credentials = @{
            credentialsData = $null
        } | ConvertTo-Json -Compress
    } elseif ($credentialType -eq "Key") {
        # https://learn.microsoft.com/en-us/rest/api/power-bi/gateways/update-datasource#key-credentials-example
        $credentials = @{
            credentialData = @(@{
                name  = "key"
                value = $token
            }) 
        } | ConvertTo-Json -Compress
    } else {
        # OAuth2
        $credentials = @{
            credentialData = @(@{
                name  = "accessToken"
                value = $token.access_token
            }) 
        } | ConvertTo-Json -Compress
    }

    $postParams = @{ 
        "credentialDetails" = @{
            "credentialType"      = $credentialType
            "credentials"         = $credentials 
            "encryptedConnection" = "NotEncrypted"
            "encryptionAlgorithm" = "None"
            "privacyLevel"        = $privacyLevel
        }    
    }

    $jsonPostBody = $postParams | ConvertTo-Json -Depth 4 

    $accessToken = Get-PowerBIAccessToken
    $bearer = $accessToken.Authorization.ToString()

    $headers = @{
        'Authorization' = "$bearer" 
    }

    try {
        # Invoke-PowerBIRestMethod not available for Gateway operations
        $response = Invoke-RestMethod -Uri $url `
            -Headers $headers `
            -Body $jsonPostBody `
            -ContentType "application/json" `
            -Method PATCH
        
        Write-Verbose "[Update-CloudDataGateway] end"

        return $response
    }
    catch {
        Write-Warning "[Update-CloudDataGateway] Could not update cloud datasource"
        Write-Verbose $jsonPostBody
        Write-Verbose $url
        
    
        Write-Verbose "[Update-CloudDataGateway] Server response stream"
        $respStream = $_.Exception.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($respStream)
        $respBody = $reader.ReadToEnd() #| ConvertFrom-Json
        $respBody;
        Write-Verbose $respBody

        Write-Verbose "[Update-CloudDataGateway] Server response start"
        
        $_.Exception.ErrorDetails | ConvertTo-Json
        $_.Exception.Response | ConvertTo-Json
        Write-Verbose "[Update-CloudDataGateway] Server response end"
    
        Write-Error $_
    }
    
}

function Set-CloudDatasource {
    [CmdletBinding()]
    param (
        # datasourceList
        [Parameter(Mandatory=$true)]
        $datasourceList,
        # report settings / dataflow settings
        [Parameter(Mandatory=$true)]
        $jsonSettings,
        # PBI user
        [string]
        $user,
        # PBI password
        [string]
        $pass,
        $objectId,
        $objectType = "Dataflows",
        $workspaceId,
        $userType = "ServiceAccount"
    )

    $grantType = "password"
    if($userType -eq "ServicePrincipal") {
        $grantType = "client_credentials"
    }
    
    #TODO: refactor name
    $reportDatasources = Select-ReportDatasources -reportConfig $jsonSettings
    
    foreach ($datasource in $datasourceList.value) {
        Write-Verbose "[Set-CloudDatasource] processing datasource $($datasource.datasourceType) - $($datasource.datasourceId)"
        $dsType = $null
        if(($datasource.datasourceType -eq "SharePointList")) {
            if($objectType -eq "Dataflows") {
                $url = $datasource.connectionDetails.sharePointSiteUrl
            } else {
                $url = $datasource.connectionDetails.url
            }
            
            Write-Verbose "[Set-CloudDatasource] found connection details url: $url"
            $reportDatasource = $reportDatasources | Where-Object {$_.datasource.name -eq $url }
            
            if(-not $reportDatasource) {
                # check configuration for $url without /
                $url = $url.Substring(0, $url.Length - 1)
                $reportDatasource = $reportDatasources | Where-Object {$_.datasource.name -eq $url }
                if($reportDatasource) {
                    Write-Warning "[SolidOps.PBI.Gateway] Url parameter does not have a trailing /. Retrieved datasource configuration by searching without /"
                }
                $url = $url + "/"
            }

            if($reportDatasource) {
                $clientId = $reportDatasource.datasource.config.clientId
                $resource = $reportDatasource.datasource.config.resource

                #$token = Get-MicrosoftToken -user $user -pass $pass -resource $datasource.connectionDetails.path
                $token = Get-MicrosoftToken2 -user $user -pass $pass -clientId $clientId -resource $resource -grantType $grantType

                Set-CloudDataGateway -gatewayId $datasource.gatewayId -datasourceId $datasource.datasourceId -token $token
                Write-Verbose "[Set-CloudDatasource] Update accessToken for $($resource) in $($reportDatasource.datasource.name)"
            } else {
                
            }

        } elseif($datasource.datasourceType -eq "AzureBlobs") {
            # "datasourceType": "AzureBlobs",
            # "connectionDetails": {
            #     "account": "dmdatagovernancedeva906",
            #     "domain": "blob.core.windows.net"
            # },
            # "datasourceId": "c540be12-185c-4ca2-b665-46776f3fa393",
            # "gatewayId": "1f64b140-3082-47bc-bc03-ca0735a627aa"
            $url =  $datasource.connectionDetails.account
            $reportDatasource = $reportDatasources | Where-Object {$_.datasource.name -eq $url }
            if($reportDatasource) {
                $token = $reportDatasource.datasource.config.accessKey
                Set-CloudDataGateway -gatewayId $datasource.gatewayId `
                    -datasourceId $datasource.datasourceId `
                    -token $token `
                    -credentialType "Key"
            }

            else {
                Write-Warning "[SolidOps.PBI.Gateway] Could not find datasource configuration for url $url"
            }
            

        } elseif($datasource.datasourceType -eq "Extension") {
           
            $url = $datasource.connectionDetails.path
            if($url -eq "PowerBI" -or $url -eq "PowerPlatformDataflows") {
                Write-Verbose "[Set-CloudDatasource] processing PowerBI/PowerPlatform datasource"

                $token_auth = Get-PowerBIAccessToken
                $token = @{
                    access_token = $token_auth.Authorization -Replace "Bearer "
                }
                Set-CloudDataGateway -gatewayId $datasource.gatewayId -datasourceId $datasource.datasourceId -token $token -privacyLevel "Organizational"
                Write-Verbose "[Set-CloudDatasource] Update accessToken for $($url) in $($datasource.datasourceId)"
                #Write-Verbose "Do nothing for Power BI"
            } else {
                if($url) {
                    Write-Verbose "processing connectionDetails.path $url"
                } else {
                    if($datasource.connectionDetails.extensionDataSourceKind) {
                        if($datasource.connectionDetails.extensionDataSourceKind -eq 'Cds') {
                            $url = $datasource.connectionDetails.extensionDataSourcePath
                        }
                    }
                }

                # process Cds connector
                if($url) {
                    $reportDatasource = $reportDatasources | Where-Object {$_.datasource.name -eq $url }
                    if($reportDatasource) {
                        $clientId = $reportDatasource.datasource.config.clientId
                        $resource = $reportDatasource.datasource.config.resource
                        
                        #$token = Get-MicrosoftToken -user $user -pass $pass -resource $datasource.connectionDetails.path
                        # TODO: remove get microsoft token - Dynamics 365 scenario
                        $token = Get-MicrosoftToken -user $user -pass $pass -resource $resource

                        Set-CloudDataGateway -gatewayId $datasource.gatewayId -datasourceId $datasource.datasourceId -token $token
                        Write-Verbose "[Set-CloudDatasource] Update accessToken for $($resource) in $($reportDatasource.datasource.name)"
                    } else {
                        Write-Warning "[Set-CloudDatasource] Could not find datasource configuration for url $url"
                    }
                } else {
                    $jsonDs = $datasource | ConvertTo-Json
                    Write-Warning "[SolidOps.PBI.Gateway] datasource extension type not implemented"
                    Write-Verbose "[Set-CloudDatasource] json: $jsonDs"

                }
                
            }

        } elseif ($datasource.datasourceType -eq "Web") {
            $url = $datasource.connectionDetails.Url

            
            

            #if($dsType -eq "SharePointFolder")
            if($url.StartsWith("https://beazley.sharepoint.com")) # sharepoint site
            {
                Write-Debug "Processing $url format"
                if ($url.EndsWith("_api/Web")) {
                    $url = $url.Replace("_api/Web", "")
                }
                Write-Debug "Finished processing $url format"
            }

            $reportDatasource = $reportDatasources | Where-Object {$_.datasource.name -eq $url }

            if(-not $reportDatasource) {
                # check configuration for $url without /
                if($url.EndsWith("/")) {
                    $url = $url.Substring(0, $url.Length - 1)
                    $reportDatasource = $reportDatasources | Where-Object {$_.datasource.name -eq $url }
                    if($reportDatasource) {
                        Write-Warning "[SolidOps.PBI.Gateway] Url parameter does not have a trailing /. Retrieved datasource configuration by searching without /"
                    }
                    $url = $url + "/"
                }
            }

            
            if($reportDatasource) {
                
                $dsType = $reportDatasource.datasource.config.datasourceType

                Write-Verbose "Datasource type: $dsType"

                if($dsType -eq "SharePointFolder") {
                    $clientId = $reportDatasource.datasource.config.clientId
                    $resource = $reportDatasource.datasource.config.resource

                    $token = Get-MicrosoftToken2 -user $user -pass $pass -clientId $clientId -resource $resource

                    Set-CloudDataGateway -gatewayId $datasource.gatewayId -datasourceId $datasource.datasourceId -token $token #-credentialType "Anonymous"
                    Write-Verbose "[Set-CloudDatasource] $dsType : Update to credential type OAuth2 for $($resource) in $($reportDatasource.datasource.name)."
                    Write-Verbose "[Set-CloudDatasource] Only one datasource supported for $dsType. exit method"
                    return
                } elseif ($dsType -eq "access_token") {
                    $clientId = $reportDatasource.datasource.config.clientId
                    $resource = $reportDatasource.datasource.config.resource
                    $token = $null
                    if($clientId) { 
                        # defined OAuth2 app for power bi publisher account
                        $token = Get-MicrosoftToken2 -user $user -pass $pass -clientId $clientId -resource $resource
                        Write-Verbose "[Set-CloudDatasource] $dsType : Updating to credential type OAuth2 for $($resource) in $($reportDatasource.datasource.name)."
                        Set-CloudDataGateway -gatewayId $datasource.gatewayId -datasourceId $datasource.datasourceId -token $token #-credentialType "Anonymous"
                    } else {
                        # power bi token
                        Write-Verbose "[SolidOps.PBI.Gateway] token already processed in $($objectType) parameters before upload. Set datasource $($datasource.datasourceId) skip test connection"
                        Invoke-DatasourceSkipTestConnection -gatewayId $datasource.gatewayId -datasourceId $datasource.datasourceId
              
                        Write-Verbose "[Set-CloudDatasource] $dsType : Update to credential type access_token for $($resource) in $($reportDatasource.datasource.name)."
                    }
                } else {
                     # TODO: use report get datasoruces
                    if($jsonSettings.datasources) {
                        if($jsonSettings.datasources | Get-Member $url){ 
                            $webUser = $jsonSettings.datasources.$url.username
                            $webPass = $jsonSettings.datasources.$url.password

                            Write-Verbose "Set credentials using $webUser"
                            
                            Set-WebDatasource -user $webUser `
                                -pass $webPass `
                                -url $url `
                                -gatewayId $datasource.gatewayId `
                                -datasourceId $datasource.datasourceId 

                            Write-Verbose "[Set-CloudDatasource] Set credentials for $($datasource.connectionDetails.Url) in dataset $($dataset.Name)"
                        } else {
                            Write-Error "[SolidOps.PBI.Gateway] Datasource $url has not been configured in reports.json for dataset id $datasetId" -ErrorAction Stop
                        }
                    } else {
                        Write-Warning "[SolidOps.PBI.Gateway] found datasourceType Web for $($dataset.Name) but no datasource settings in reports.json"
                    }
                }
            } else {
                Write-Warning "[SolidOps.PBI.Gateway] Could not find datasource configuration for url $url"
            }
        } elseif ($datasource.datasourceType -eq "AnalysisServices" -or $datasource.datasourceType -eq "Sql") {
           Write-Verbose "[SolidOps.PBI.Gateway] datasource type $($datasource.datasourceType) is processed on-premises or in set dataset datasources"
        } else {
            Write-Warning "[SolidOps.PBI.Gateway] datasource type $($datasource.datasourceType) not implemented"
        }
    }
}

function Remove-Datasource {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]$datasourceNameBase, 
        [Parameter(Mandatory=$true)]
        [string]$gatewayId,
        [Parameter(Mandatory=$true)]
        [string]
        $envCode,
        [Parameter(Mandatory=$true)]
        [string]
        $team
    )

    $datasourceName = Get-DataSourceName -dbName $datasourceNameBase -envCode $envCode -team $team
    Write-Verbose "[Remove-Datasource] Data source name: $datasourceName" 

    $ds = Get-Datasource -gatewayId $gatewayId -datasourceName $datasourceName
    if($ds) {
        #DELETE https://api.powerbi.com/v1.0/myorg/gateways/{gatewayId}/datasources/{datasourceId}
        Write-Verbose "[Remove-Datasource] found datasource $datasourceName"

        $datasourceId = $ds.id
        if($datasourceId) {
            $url = "https://api.powerbi.com/v1.0/myorg/gateways/$($gatewayId)/datasources/$($datasourceId)"
            Write-Verbose "URL: $url"
            Invoke-SolidOpsPBIRestMethod -Url $url -Method DELETE
        } else {
            Write-Error "[SolidOps.PBI.Gateway] Error retrieving daatsource id for $datasourceName"
        }
    } else {
        Write-Warning "[Remove-Datasource] datasource $datasourceName not found in gateway $gatewayId"
    }
    
}
