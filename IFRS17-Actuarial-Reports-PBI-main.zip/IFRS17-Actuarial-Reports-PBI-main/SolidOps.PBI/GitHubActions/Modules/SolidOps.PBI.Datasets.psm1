function Update-OnPremiseDataGateway {
    [CmdletBinding()]
    param (
        # gateway name
        [Parameter(Mandatory=$true)]
        [string]
        $gatewayName,
        # workspace id
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        # workspace id
        [Parameter(Mandatory=$true)]
        [string]
        $datasetId,
        [Parameter(Mandatory=$true)]
        $datasourceList
    )

    $gateway = Get-Gateway -gatewayName $gatewayName

    $datasourceIds = @()

    $notFound = $false
    $server = $null
    $database = $null
    $team = $global:SolidOpsSession.TeamName
    $envCode = $global:SolidOpsSession.EnvCode

    $dsList =  $datasourceList | ConvertTo-Json
    $gatewayDsList = Get-DataSources -gatewayId $gateway.Id
    $gatewayDsListJson = $gatewayDsList | ConvertTo-Json
    #write-host "dsList:" $dsList
    #write-host "gatewayDsList:" $gatewayDsList
    #write-host "gatewayDsListJson:" $gatewayDsListJson

    foreach ($datasource in $datasourceList.value) {
        Write-Verbose "[Update-OnPremiseDataGateway] processing datasource $($datasource.datasourceType) - $($datasource.datasourceId)"

        if($datasource.datasourceType -eq "AnalysisServices" -or $datasource.datasourceType -eq "Sql") {
            $server = $datasource.connectionDetails.server
            $database = $datasource.connectionDetails.database

            if(-not $server.StartsWith("powerbi")) {
                $gwDs = $gatewayDsList.value | Where-Object {
                        ($_.connectionDetails | ConvertFrom-Json).server -eq $server -and 
                        ($_.connectionDetails | ConvertFrom-Json).database -eq $database }
                        #$_.datasourceName.StartsWith($team) -and $_.datasourceName.EndsWith($envCode)}

                if(-not $gwDs) {
                    $notFound = $true

                } else {
                    $gwDatasource = $gwDs | Where-Object {
                        $_.datasourceName.StartsWith($team) -and $_.datasourceName.EndsWith($envCode)
                    }

                    if(-not $gwDatasource) {
                        $notFound = $true
                    } 
                    
                }


                $datasourceIds += $datasource.datasourceId

                if ($notFound) {
                    Write-Verbose $dsList
                    Write-Error "[Update-OnPremiseDataGateway] could not find data source for $($server) - $($database)"
                    

                } else {
                    Write-Verbose "[Update-OnPremiseDataGateway] processed datasource $($server) - $($database)"
                }
            } else {
                Write-Verbose "[Update-OnPremiseDataGateway] datasource $($server) should be processed in Cloud datasources"
            }

        }
    
        if($datasource.datasourceType -eq "OleDb")
        {
            $datasourceIds += $datasource.datasourceId
        }
        
        

        $server = $null
        $database = $null
    }

#     if ($notFound) {
#         Write-Error @"
# [SolidOps.PBI] Could not find gateway datasource for server $($server), database $($database), Team $($team) on environment $($envCode). 
# Check if datasource has been created using the SolidOps.PBI process for Team $($team) on environmnent $($envCode)
# "@
#         #exit
#     }
    
    # bind to gateway
    # POST https://api.powerbi.com/v1.0/myorg/groups/{groupId}/datasets/{datasetId}/Default.BindToGateway
    $url = "https://api.powerbi.com/v1.0/myorg/groups/$($workspaceId)/datasets/$($datasetId)/Default.BindToGateway"
    
    $postParams = @{
        "gatewayObjectId" = $gateway.id 
    };
    Write-Verbose "GatewayID: $($gateway.id)"

    # TODO: implement datasourceIds

    $jsonPostBody = $postParams | ConvertTo-JSON

    Invoke-SolidOpsPBIRestMethod -url $url `
            -method Post `
            -postBody $postParams

   
}


function Get-DatasetGateway {
    [CmdletBinding()]
    Param (
        # Dataset id
        [Parameter(Mandatory=$true)]
        [string]
        $datasetId,    
        # Workspace ID
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        # gateway name
        [Parameter(Mandatory=$true)]
        [string]
        $name
    )

    # GET https://api.powerbi.com/v1.0/myorg/groups/{groupId}/datasets/{datasetId}/Default.DiscoverGateways
    $url = "groups/$($workspaceId)/datasets/$($datasetId)/Default.DiscoverGateways"
    $gateways = Invoke-PowerBIRestMethod -Url $url -Method GET -Headers $headers
    $gateway = $gateways.value | Where-Object {$_.name -eq $name}

    # Get gatewayID based on OD parameter with gateway name
    if($($gateway.id)) {
        Write-Verbose "[Get-DatasetGateway] Gateway Id : $($gateway.id)"
    } else {
        Write-Error "[Get-DatasetGateway] Gateway not found or missing permissions."
    }

    return $gateway
}

function Get-DatasetDatasources {
    [CmdletBinding()]
    param (
         # Dataset id
         [Parameter(Mandatory=$true)]
         [string]
         $datasetId,    
         # Workspace ID
         [Parameter(Mandatory=$true)]
         [string]
         $workspaceId
    )
    
     #GET https://api.powerbi.com/v1.0/myorg/groups/{groupId}/datasets/{datasetId}/datasources
     #$url = "groups/$($workspaceId)/datasets/$($datasetId)/datasources"

    #$datasources = Invoke-PowerBIRestMethod -Url $url -Method GET

    $url = "https://api.powerbi.com/v1.0/myorg/groups/$($workspaceId)/datasets/$($datasetId)/datasources"
    $datasources = Invoke-SolidOpsPBIRestMethod -Url $url -Method GET
    return $datasources

}

function Set-WebDatasource {
    [CmdletBinding()]
    param (
        # Parameter help description
        [Parameter(Mandatory=$true)]
        [string]
        $user,
        [Parameter(Mandatory=$true)]
        [string]
        $pass,
        [Parameter(Mandatory=$true)]
        [string]
        $url,
        [Parameter(Mandatory=$true)]
        [string]
        $gatewayId,
        [Parameter(Mandatory=$true)]
        [string]
        $datasourceId
    )
    
    $url = "https://api.powerbi.com/v1.0/myorg/gateways/$gatewayId/datasources/$datasourceId"

    $credentials = @{
        credentialData = @(
            @{
                name  = "username"
                value = $user
            },
            @{
                name = "password"
                value = $pass
            }) 
    } | ConvertTo-Json -Compress

    $postParams = @{ 
        "credentialDetails" = @{
            "credentialType"      = "Basic"
            "credentials"         = $credentials 
            "encryptedConnection" = "NotEncrypted"
            "encryptionAlgorithm" = "None"
            "privacyLevel"        = "Organizational"
        }    
    }

    #$jsonPostBody = $postParams | ConvertTo-Json -Depth 4 


    Invoke-SolidOpsPBIRestMethod -url $url -method Patch -postBody $postParams
    
}

function Get-DatasetParameters {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $datasetId,
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId
    )
    
    try {
        Write-Verbose "[Get-DatasetParameters] begin"
        $url = "groups/$($workspaceId)/datasets/$($datasetId)/parameters"
        $response = Invoke-PowerBIRestMethod -Url $url `
                -Method GET `
                -ContentType "application/json"
        #Write-Verbose "Parameters $response"
        Write-Verbose "[Get-DatasetParameters] end"
        return $response | ConvertFrom-Json
        
    }
    catch {
        Write-Warning "[SolidOps.PBI.Datasets] Could not get parameters for $datasetId "
        Write-Verbose "[Get-DatasetParameters] Server request data"
        Write-Verbose "Url: $url"

        Resolve-PowerBIError

        Write-Error $_ 
    }

}

function Set-DatasetOverwiteParams {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $datasetId,
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        [Parameter(Mandatory=$true)]
        $reportSettings
    )
    
    $bearer = $global:SolidOpsSession.AuthToken
    $paramOverwrite = @{
        access_token = $bearer -Replace "Bearer "
    }
    
    
    $dsParameters = Get-DatasetParameters -datasetId $datasetId -workspaceId $workspaceId

    #Write-Verbose "[Update-DataSetParameters] for $($reportSettings.fileName)"

    $updateParamsObject = @{
        updateDetails = @()
    }

    $paramUpdated = $false

    foreach ($param in $dsParameters.value) {
        $paramName = $param.name
        $newParamValue = $null

        if($paramOverwrite) {
            if($paramOverwrite[$paramName]) {
                Write-Verbose "Found parameter $($paramName) to overwrite"
                $newParamValue = $paramOverwrite[$paramName]
            }
        } 

        if (($null -ne $newParamValue) -and ($newParamValue -ne "")) {
            $updateParamsObject.updateDetails += @{name = $paramName; newValue = $newParamValue }
            $paramUpdated = $true 
        } 
        
    }
    if($paramUpdated) {
        Invoke-UpdateDatasetParameters `
            -updateParamsObject $updateParamsObject `
            -workspaceId $workspaceId `
            -datasetId $datasetId
    } else {
        Write-Verbose "[SolidOps.PBI.Datasets] No paramteres updated for $($reportSettings.fileName)"
    }
}

function Update-DatasetParameters {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $datasetId,
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        [Parameter(Mandatory=$true)]
        $reportSettings

    )

    # TODO: integrate with Set-DatasetOverwiteParams

    $bearer = $global:SolidOpsSession.AuthToken
    $paramOverwrite = @{
        access_token = $bearer -Replace "Bearer "
    }
    
    
    $dsParameters = Get-DatasetParameters -datasetId $datasetId -workspaceId $workspaceId

    #Write-Verbose "[Update-DataSetParameters] for $($reportSettings.fileName)"

    $updateParamsObject = @{
        updateDetails = @()
    }

    $paramUpdated = $false

    foreach ($param in $dsParameters.value) {
        $paramName = $param.name
        $newParamValue = $reportSettings.parameters.$paramName

        if($paramOverwrite) {
            if($paramOverwrite[$paramName]) {
                Write-Verbose "Found parameter $($paramName) to overwrite"
                $newParamValue = $paramOverwrite[$paramName]
            }
        } 

        if (($null -ne $newParamValue) -and ($newParamValue -ne "")) {
            $updateParamsObject.updateDetails += @{name = $paramName; newValue = $newParamValue }
            $paramUpdated = $true 
        } else {
            Write-Warning "[SolidOps.PBI.Datasets] Parameter $paramName for report $($reportSettings.fileName) has not been configured in Octopus Deploy variables. Parameter value is null"
        }
        
    }
    if($paramUpdated) {
        Invoke-UpdateDatasetParameters `
            -updateParamsObject $updateParamsObject `
            -workspaceId $workspaceId `
            -datasetId $datasetId
    } else {
        Write-Warning "[SolidOps.PBI.Datasets] No paramteres updated for $($reportSettings.fileName)"
    }
}

function Invoke-UpdateDatasetParameters {
    [CmdletBinding()]
    param (
        # parameters to update
        [Parameter(Mandatory=$true)]
        $updateParamsObject,
        $workspaceId,
        $datasetId
    )
    $url = "https://api.powerbi.com/v1.0/myorg/groups/$($workspaceId)/datasets/$($datasetId)/Default.UpdateParameters"
    #$jsonPostBody = $updateParamsObject | ConvertTo-Json
    
    try {
        Invoke-SolidOpsPBIRestMethod -url $url `
            -postBody $updateParamsObject `
            -contentType "application/json" `
            -method POST

    }
    catch {
        Write-Warning "[SolidOps.PBI.Datasets] Could not update parameters for $($reportSettings.fileName) "
        Write-Verbose "[Update-DataSetParameters] Server request post data"
        Write-Verbose $url
        Write-Verbose $jsonPostBody

        Resolve-PowerBIError

        Write-Error $_ 
    }
}

function Get-DatasetRefreshHistory {
    [CmdletBinding()]
    param (
        # workspace id
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        # dataset id
        [Parameter(Mandatory=$true)]
        [string]
        $datasetId,
        [int]
        $top = 1

    )
    
    begin {
       Write-Verbose "[Get-DatasetRefreshHistory] begin for dataset $datasetId" 
    }
    
    process {
        try {
            # GET https://api.powerbi.com/v1.0/myorg/groups/{groupId}/datasets/{datasetId}/refreshes?$top={$top}
            $url = "groups/$($workspaceId)/datasets/$($datasetId)/refreshes?`$top=$($top)"

            $refresh = Invoke-PowerBIRestMethod -Url $url `
                -Method GET `
                -ContentType "application/json"

            #Write-Verbose $refresh

            $refreshResponse = $refresh | ConvertFrom-Json
            return $refreshResponse
                
        }
        catch {
            Write-Warning "[Get-DatasetRefreshHistory] failed for $datasetId"
            Write-Verbose "Url:         $url"
            Write-Verbose "WorkspaceId: $workspaceId"
            Write-Verbose "DatasetId:   $datasetId"
            Write-Verbose "Top:         $top"
            


            Resolve-PowerBIError
            Write-Error $_
        }
    }
    
    end {
        Write-Verbose "[Get-DatasetRefreshHistory] end for dataset $datasetId" 
    }
}

function Set-DatasetRefreshSchedule {
    [CmdletBinding()]
    param (
         # Dataset id
         [Parameter(Mandatory=$true)]
         [string]
         $id,    
         # Workspace ID 
         [Parameter(Mandatory=$true)]
         [string]
         $workspaceId,
         [Parameter(Mandatory=$true)]
         $reportSettings
    )

    if($reportSettings.refreshSchedule) {
        [String]$jsonPostBody =  $reportSettings.refreshSchedule | ConvertTo-Json 
        #write-host "REPORT SETTINGS" $jsonPostBody
        $url = "groups/$($workspaceId)/datasets/$($id)/refreshSchedule"
        #write-host "REFRESH URL" $url
        try {
            Invoke-PowerBIRestMethod -Url $url `
                -Method PATCH `
                -ContentType "application/json" `
                -Body $jsonPostBody
        }
        catch {
            Write-Warning "[SolidOps.PBI.Reports] Could not add refresh schedule"
            Write-Verbose "Url:             $url"
            Write-Verbose "JsonPostBody:    $jsonPostBody"

            Resolve-PowerBIError
            Write-Error $_ 
            #exit
        }
    } else {
        Write-Warning "[SolidOps.PBI.Reports] Refresh schedule not configured for $($reportSettings.fileName)"
    }
  
}

function Invoke-TakeDatasetOwnership {
    [CmdletBinding()]
    param (
        # workspace Id
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        # dataset Id
        [Parameter(Mandatory=$true)]
        [string]
        $datasetId
    )
    
    $url = "groups/$($workspaceId)/datasets/$($datasetId)/Default.TakeOver"

    try {
        Invoke-PowerBIRestMethod -Url $url `
            -Method Post `
            -ContentType "application/json" 
    }
    catch {
        Write-Warning "[SolidOps.PBI.Datasets] Could not take dataset ownership for $datasetId"
        Write-Verbose "Url: $url"

        Resolve-PowerBIError
        Write-Error $_ 
    }
}

function Set-DatasetOwnership {
    [CmdletBinding()]
    param (
        # workspace id
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        # dataset id
        [Parameter(Mandatory=$true)]
        [string]
        $datasetId,
        # username - configuredBy
        [Parameter(Mandatory=$false)]
        [string]
        $configuredBy

    )
    
    if($configuredBy) {

        $dataset = Get-PowerBIDataset -WorkspaceId $workspaceId -Id $datasetId

        if(-not $dataset) {
            Write-Error "[SolidOps.PBI.Datasets] Could not find dataset $datasetId in workspace $workspaceId"
            return
        }

        if($dataset.ConfiguredBy -ne $configuredBy) {
            Write-Verbose "[Set-DatasetOwnership] Dataset $datasetId configured by $($dataset.ConfiguredBy). Take ownership"
            Invoke-TakeDatasetOwnership -workspaceId $workspaceId -datasetId $datasetId -verbose
        } else {
            Write-Verbose "[Set-DatasetOwnership] Dataset $datasetId configured by $($dataset.ConfiguredBy). Take no action"
        }
    } else {
        Write-Warning "[SolidOps.PBI.Datasets] Missing configuredBy parameter. Update step PBI - Reports - Create to latest version"
    }


}

function Add-DatasetRefreshTrigger {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $id,    
        # Workspace ID
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId
    )

    Write-Verbose "[Add-DatasetRefreshTrigger] Trigger refresh for $id"

    $url = "groups/$($workspaceId)/datasets/$($id)/refreshes"

    try {
        Invoke-PowerBIRestMethod -Url $url -Method POST 
    }
    catch {
        Write-Warning "[SolidOps.PBI.Reports] Could not trigger a refresh for dataset $id in workspace $workspaceId"
        Write-Verbose "Url: $url"
        
        Resolve-PowerBIError
        Write-Error $_ 
    }

    Write-Verbose "[Add-DatasetRefreshTrigger] end"
}

function Get-PackagedReports {
    [CmdletBinding()]
    param (
         # Reports path
         [Parameter(Mandatory=$true)]
         [string]
         $path,
         # Report
         [Parameter(Mandatory=$true)]
         $reportsFolder
    )
    
    $reportFolder = "$($path)\$($reportsFolder)"

    if(-not (Test-Path $reportFolder)) {
        Write-Warning "[SolidOps.PBI.Datasets] Could not find $($reportsFolder). Datasets will not be imported"
        return
    }

    $reportList = Get-ChildItem $reportFolder\*.pbix

    return $reportList
}

function Get-Workspace {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceName
    )
    
    $url = 'https://api.powerbi.com/v1.0/myorg/groups?$filter=name eq '
    $url += "'$workspaceName'"

    Write-Verbose $url

    $workspaceResponse = Invoke-SolidOpsPBIRestMethod -url $url -method Get

    return $workspaceResponse.value
}


function Get-DatasetByName {
    [CmdletBinding()]
    param (
        # workspace id
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        [Parameter(Mandatory=$true)]
        [string]
        $datasetName
    )
    
    $datasets = Get-Datasets -workspaceId $workspaceId
    $ds = $datasets | Where-Object { $_.name -eq $datasetName }

    return $ds.Id
}

function Get-Datasets {
    [CmdletBinding()]
    param (
          # workspace id
          [Parameter(Mandatory=$true)]
          [string]
          $workspaceId
    )
    
    $url = "https://api.powerbi.com/v1.0/myorg/groups/$workspaceId/datasets"

    $datasets = Invoke-SolidOpsPBIRestMethod -url $url -method Get

    return $datasets.value

}

function Set-DatasetsRefreshSettings {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceName,
        # Reports path
        [Parameter(Mandatory=$true)]
        [string]
        $path,
        [Parameter(Mandatory=$true)]
        [string]
        $contacts
    )

    $reportConfig = Get-ReportConfig -path $path
    
    $reportList = Get-PackagedReports -path $path -reportsFolder $reportConfig.reportsFolder

    $reports = $reportConfig.reports

    $workspace = Get-Workspace -workspaceName $workspaceName
    $workspaceId = $workspace.id    

    $datasets = Get-Datasets -workspaceId $workspaceId

    foreach ($item in $reportlist) {
        $itemName = Get-ReportName -item $item

        $compositeReport = Find-CompositeReport -fileName $itemName -reports $reports

        if($compositeReport) {
            Write-Verbose "[Set-DatasetsRefreshSettings] $itemName using Live Connection or Direct Query."
            
        } else {
            $reportSettings = $reports | Where-Object fileName -eq $itemName 
            if($reportSettings) {
                $dsName = $item.name.Substring(0, $item.name.LastIndexOf('.')).split('\')[-1]
                $dataset = $datasets | Where-Object name -eq $dsName
                if($dataset) {
                    $datasetId = $dataset.id
                    Set-DatasetRefreshContactList -workspaceId $workspaceId -datasetId $datasetId -contacts $contacts

                } else {
                    Write-Error "[SolidOps.PBI.Datasets] could not find dataset $($reportSettings.name) in workspace $workspaceName"
                    return
                }
                
            } else {
                Write-Warning "[SolidOps.PBI.Datasets] Dataset for report $itemName not configured for deployment"
            }

        }
    }
}

function Set-DatasetGateway {
    [CmdletBinding()]
    Param (
        # Dataset id
        [Parameter(Mandatory=$true)]
        [string]
        $datasetId,    
        # Workspace ID
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        # gateway name
        [Parameter(Mandatory=$true)]
        [string]
        $name,
        # dataset config
        [Parameter(Mandatory=$true)]
        $reportSettings,
        # PBI user
        [string]
        $user,
        # PBI password
        [string]
        $pass,
        [string]
        $userType = "ServiceAccount"
    )

   
    
    $dataset = Get-PowerBIDataset -WorkspaceId $workspaceId -Id $datasetId
    
    $datasources = Get-DatasetDatasources -datasetId $datasetId -workspaceId $workspaceId

    if($dataset.IsOnPremGatewayRequired) {
        Write-Verbose "[Set-DatasetGateway] bind $($dataset.Name) to $gatewayName"
        Update-OnPremiseDataGateway -gatewayName $name `
                -workspaceId $workspaceId `
                -datasetId $datasetId `
                -datasourceList $datasources

        Write-Verbose "[Set-DatasetGateway] Dataset $datasetId bound to gateway"
    } else {
        Write-Verbose "[Set-DatasetGateway] $($dataset.Name) does not require on prem gateway"
    }

   
    #$datasourceList = $datasources | ConvertFrom-Json

    Set-CloudDatasource -datasourceList $datasources `
        -jsonSettings $reportSettings `
        -user $user `
        -pass $pass `
        -objectId $datasetId `
        -objectType "Dataset" `
        -workspaceId $workspaceId `
        -userType $userType
        
    
}

function Test-DatasetRefreshStatus {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        $reportSettings,
        # Report id
        [Parameter(Mandatory=$true)]
        [string]
        $datasetId,
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId
    )
    
    # check for refresh history if refresh is enabled
    if($reportSettings.refreshSchedule) {
        if ($reportSettings.refreshSchedule.value.enabled) {
            $wait = $true
            $waitX = 0
            $waitMax = 30 #seconds
            Write-Verbose "[Set-Dataset] Check refresh status on dataset $datasetId"
            while ($wait) {
                $lastRefresh = Get-DatasetRefreshHistory -workspaceId $workspaceId -datasetId $datasetId
                if($lastRefresh) {
                    if($lastRefresh.value.status -eq 'Unknown') {
                        if($waitX -eq 0) {
                            Write-Warning "[SolidOps.PBI.Datasets] found refresh in progress for dataset $datasetId. `
                            The process will evaluate the status every 5 seconds for the next $waitMax seconds. `
                            If refresh status in progress after $waitMax seconds since initial check the update dataset might fail"
                        }
                        Write-Verbose "[Update-Dataset] Status $($lastRefresh.value.status) started at $($lastRefresh.value.startTime). Wait 5 seconds"
                        
                        Start-Sleep -s 5
                        $waitX += 5  
                        if($waitX -gt $waitMax) { # 2 minutes have passed
                            $wait = $false
                        }
                    } else {
                        $wait = $false
                    }
                } else {
                    $wait = $false
                }

                Write-Verbose "[Update-Dataset] Found status $($lastRefresh.value.status) for dataset $datasetId"
                if($wait -eq $false) {
                    if($lastRefresh.value.status -eq 'Unknown') {
                        Write-Warning "[SolidOps.PBI.Datasets] Refresh in progress. Dataset $datasetId update might fail with timeout errors"
                    } else {
                        Write-Verbose "[Update-Dataset] Refresh status $($lastRefresh.value.status) eligible for updating dataset $datasetId"
                    }
                    
                }
            }
        } else {
            Write-Verbose "[Update-Dataset] refresh schedule disabled for $($reportSettings.name)"
        }
    } else {
        Write-Warning "[Update-Dataset] refresh schedule configuration missing for $($reportSettings.name)"
    }
}

function Set-PushDatasets {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $path,
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceId
    )
    
    # docs: https://docs.microsoft.com/en-us/rest/api/power-bi/push-datasets
    $datasetFolder = "$path\Datasets"

    if(-not (Test-Path $datasetFolder)) {
        Write-Information "[SolidOps.PBI.Dataflows] Could not find datasets. Push Datasets will not be imported"
        return
    }

    $datasetList = Get-ChildItem $datasetFolder\*.json

    foreach ($item in $datasetList) {
        $dsDef = Get-Content -Path $item.FullName -Raw | ConvertFrom-Json
        $dsName = $dsDef.name

        
        $ds = Get-DatasetByName -workspaceId $workspaceId -datasetName $dsName

        if($ds) {
            Write-Verbose "[Set-PushDatasets] dataset $dsName found. update tables"
            foreach ($dsTable in $dsDef.tables) {
                $tableName = $($dsTable.name)
                Write-Verbose "[Set-PushDatasets] updating table $tableName in dataset $dsName"
                
                # PUT https://api.powerbi.com/v1.0/myorg/groups/{groupId}/datasets/{datasetId}/tables/{tableName}
                $url = "https://api.powerbi.com/v1.0/myorg/groups/$workspaceId/datasets/$ds/tables/$tableName"

                Invoke-SolidOpsPBIRestMethod -url $url -method Put -postBody $dsTable
            }

        } else {
            Write-Verbose "[Set-PushDatasets] dataset $dsName not found. Create it"
            $url = "https://api.powerbi.com/v1.0/myorg/groups/$workspaceId/datasets?defaultRetentionPolicy=basicFIFO"
            Invoke-SolidOpsPBIRestMethod -url $url -method Post -postBody $dsDef
        }
    }
    
}


function Get-ReportIdFromWorkspace {
    [CmdletBinding()]
    param (
        # Workspace Id
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        [Parameter(Mandatory=$true)]
        $reportItem

    )
    
    $repName = "$($reportItem.BaseName)"

    $report = Get-PowerBIReport -Name $repName -WorkspaceId $workspaceId    
    
    if(-not $report) {
        Write-Error "[SolidOps.PBI.Datasets] Could not find report $repName in workspace $workspaceId"
    } else {
        $m = $report | Measure-Object
        if($m.Count -gt 1) {
            Write-Warning "[Set-ReportDatasets] $($m.Count) reports found with name $repName"
        }
    }

    $reportId = $report.Id | Select-Object -first 1

    return $reportId
}

function Invoke-DefaultUpdateDatasources {
    [CmdletBinding()]
    param (
        # PBI datasource
        [Parameter(Mandatory=$true)]
        $dsDatasource,
        # configured datasource
        [Parameter(Mandatory=$true)]
        $ds
    )

    $updateDetails = @(@{
        datasourceSelector = @{
            datasourceType = "AnalysisServices"
            connectionDetails = $dsDatasource.connectionDetails
        }
        connectionDetails = @{
            server = "powerbi://api.powerbi.com/v1.0/myorg/$($ds.datasource.workspaceName)"
            database = $ds.datasource.name
        }
    })

    $url = "https://api.powerbi.com/v1.0/myorg/groups/$($workspaceId)/datasets/$($datasetId)/Default.UpdateDatasources"

    $postBody = @{
        updateDetails = $updateDetails
    }

    Write-Verbose "[Set-DatasetDatasources] update datasource $($datasource.workspaceName) $($dsDatasource.connectionDetails.database)"

    Invoke-SolidOpsPBIRestMethod -url $url -method Post -postBody $postBody
   
}

function Set-DatasetDatasources {
    [CmdletBinding()]
    param (
        # workspace id
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        # dataset id
        [Parameter(Mandatory=$true)]
        [string]
        $datasetId,
        # datasources
        [Parameter(Mandatory=$true)]
        $datasources
    )
    
    Write-Verbose "[Set-DatasetDatasources] begin"

    $extingDs = Get-DatasetDatasources -workspaceId $workspaceId -datasetId $datasetId

    foreach ($dsDatasource in $extingDs.value) {
        if($dsDatasource.datasourceType -eq "AnalysisServices") {
            if($dsDatasource.connectionDetails) {
                $ds = $datasources | Where-Object { $_.datasource.name -eq $dsDatasource.connectionDetails.database }
                if($ds) {
                    Invoke-DefaultUpdateDatasources -ds $ds -dsDatasource $dsDatasource
                } else {
                    Write-Warning "[SolidOps.PBI.Datasets] Dataset $($datasetId) does not have a connection to $($dsDatasource.connectionDetails.database). Check reports.json configuration and datasource configuration"
                }
            } else {
                Write-Warning "[SolidOps.PBI] $($dsDatasource.datasourceId) datasource missing connectionDetails for datasetId $datasetId"
            }
        } else {
            Write-Verbose "Datasource type $($dsDatasource.datasourceType) for dataset id $datasetId should be processed in set cloud / on-prem gateway"
        }
    }

    Write-Verbose "[Set-DatasetDatasources] end"
}


function Set-Dataset {
    [CmdletBinding()]
    param (
        # Report id
        [Parameter(Mandatory=$true)]
        [string]
        $reportId,
        [Parameter(Mandatory=$true)]
        [string]
        $workspaceId,
        [Parameter(Mandatory=$true)]
        $reportSettings,
        [Parameter(Mandatory=$true)]
        [string]
        $gatewayName,
        [string]
        $user,
        [string]
        $pass,
        [string]
        $userType = "ServiceAccount"
    )
    

    Write-Verbose "[Set-Dataset] Get report $reportId in workspace $workspaceId"
    $report = Get-PowerBIReport -Id $reportId -WorkspaceId $workspaceId
    $datasetId = $report.DatasetId

    if($datasetId) {
        # test if any dataset refresh is running
        Test-DatasetRefreshStatus -datasetId $datasetId -workspaceId $workspaceId -reportSettings $reportSettings

        # update dataset parameters
        Update-DatasetParameters -datasetId $datasetId -workspaceId $workspaceId -reportSettings $reportSettings
        #write-host "datasetId:" $datasetId
        #write-host "workspaceId:" $workspaceId
        #write-host "gatewayName:" $gatewayName
        #write-host "reportSettings:" $reportSettings
        #write-host "userType:" $userType

        Set-DatasetGateway -datasetId $datasetId `
            -workspaceId $workspaceId `
            -name $gatewayName `
            -reportSettings $reportSettings `
            -user $user `
            -pass $pass `
            -userType $userType -verbose

        # update refresh schedule if configured
        if($reportSettings.refreshSchedule) {
            if ($reportSettings.refreshSchedule.value.enabled) {
                # update dataset refresh schedule
                Set-DatasetRefreshSchedule -id $datasetId -workspaceId $workspaceId -reportSettings $reportSettings

                # trigger dataset refresh - disable trigger refresh, do it manually
                # Add-DatasetRefreshTrigger -id $datasetId -workspaceId $workspaceId
            } else {
                Write-Verbose "[SolidOps.PBI.Reports] Refresh schedule disabled for $($reportSettings.fileName)"    
            }
        } else {
            Write-Warning "[SolidOps.PBI.Reports] Refresh schedule not configured for $($reportSettings.fileName)"
        }
    } else {
        Write-Verbose "[Set-Dataset] Report $reportId does not have a local dataset"
    }

}

function Set-ReportDatasets {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $path,
        # Workspace name
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceId,
        [Parameter(Mandatory = $true)]
        [string]
        $gatewayName,
        [string]
        $user,
        [string]
        $pass,
        [string]
        $reportType = "PowerBIReport",
        [bool]
        $gatewayOnly = $false,
        [string]
        $userType = "ServiceAccount"
    )
    
    $reportConfig = Get-ReportConfig -path $path
    
    $reportFolder = Get-ReportFolder -path $path -reportConfig $reportConfig -reportType $reportType

    if(-not (Test-Path $reportFolder)) {
        Write-Warning "[SolidOps.PBI.Datasets] Could not find report folder. Report datasets will not be imported"
        return
    }

    $reports = $reportConfig.reports

    $compositeReports = Select-CompositeReports -reports $reports
    

    Write-Verbose "[Set-ReportDatasets] begin process"
    
    $reportList = Get-ReportItems -reportFolder $reportFolder -reportType $reportType
    
    $datasets = Get-Datasets -workspaceId $workspaceId

               
    foreach ($item in $reportList) {
        $itemName = Get-ReportName -item $item
        Write-Verbose "[Set-ReportDatasets] Processing report $itemName"
        $reportSettings = $reports | Where-Object fileName -eq $itemName 
        if($reportSettings) {
            $reportSettingsJson = $reportSettings | ConvertTo-Json
            Write-Verbose "Report settings $reportSettingsJson"

            $reportId = Get-ReportIdFromWorkspace -workspaceId $workspaceId -reportItem $item

            #$newReport = Add-Report -item $item -workspace $destinationWorkspace -reportSettings $reportSettings 
            
            Write-Verbose "[Set-ReportDatasets] Begin updating dataset for report $itemName"

            $compositeReport = $compositeReports | Where-Object { $_.fileName -eq  $itemName }
            if($compositeReport) {
                if($compositeReport.composite) {
                    Write-Verbose "[Set-DatasetsRefreshSettings] $itemName using Direct Query. Change datasources"
                    $dsName = $item.name.Substring(0, $item.name.LastIndexOf('.')).split('\')[-1]
                    $dataset = $datasets | Where-Object name -eq $dsName
                    if($dataset) {
                        $datasetId = $dataset.id
                        Invoke-TakeDatasetOwnership -workspaceId $workspaceId -datasetId $datasetId
                        Set-DatasetDatasources -workspaceId $workspaceId `
                            -datasetId $datasetId `
                            -datasources $compositeReport
    
                    } else {
                        Write-Error "[SolidOps.PBI.Datasets] could not find dataset $($item.name) in workspace $workspaceName"
                    }
                    
                } else {
                    Write-Verbose "[Set-ReportsDatasets] $itemName using Live connection. Already processed in reports step"
                    $compositeReportJson = $compositeReport | ConvertTo-Json -Depth 4
                    Write-Verbose "compositeReportJson: $($compositeReportJson)"
                    Write-Verbose "compositeReport.composite $($compositeReport.composite)"
                }

            }
            
            if($gatewayOnly) {
                $dsName = $item.name.Substring(0, $item.name.LastIndexOf('.')).split('\')[-1]
                $dataset = $datasets | Where-Object name -eq $dsName
                if($dataset) {
                    $datasetId = $dataset.id

                    Invoke-TakeDatasetOwnership -workspaceId $workspaceId -datasetId $datasetId
                    
                    # check access_token parameters
                    Set-DatasetOverwiteParams -datasetId $datasetId `
                        -workspaceId $workspaceId `
                        -reportSettings $reportSettings
                    
                    Set-DatasetGateway -datasetId $datasetId `
                        -workspaceId $workspaceId `
                        -reportSettings $reportSettings `
                        -name $gatewayName `
                        -user $user `
                        -pass $pass `
                        -userType $userType
                } else {
                    Write-Warning "[SolidOps.PBI.Datasets] could not find dataset with name $dsName"
                }
                
            } else {

                Set-Dataset -reportId $reportId `
                    -workspaceId $workspaceId `
                    -reportSettings $reportSettings `
                    -gatewayName $gatewayName `
                    -user $user `
                    -pass $pass `
                    -userType $userType 
            }
            
            Write-Verbose "[Set-ReportDatasets] Finish updating dataset for report $itemName"
        } else {
            Write-Warning "[SolidOps.PBI.Datasets] Dataset for report $itemName not configured for deployment"
        }
    }    
}

function Set-DatasetsV2 {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $path,
        # Workspace name
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceName,
        [Parameter(Mandatory = $true)]
        [string]
        $gatewayName,
        [string]
        $user,
        [string]
        $pass,
        [string]
        $reportType = "PowerBIReport",
        [bool]
        $gatewayOnly = $false,
        [string]
        $userType = "ServiceAccount"
    )
    
    Write-Verbose "[Set-Datasets] begin"
    $destinationWorkspace = Get-PowerBIWorkspace -Name $workspaceName;
    if ($null -eq $destinationWorkspace) {
        Write-Error "[SolidOps.PBI.Datasets] $workspaceName does not exist or insufficient permissions"
        #exit
    }

    $workspaceId = $destinationWorkspace.Id
    Set-ReportDatasets -path $path `
        -workspaceId $workspaceId `
        -gatewayName $gatewayName `
        -user $user `
        -pass $pass `
        -reportType $reportType `
        -gatewayOnly $gatewayOnly `
        -userType $userType
    
    Set-PushDatasets -path $path `
        -workspaceId $workspaceId
}
