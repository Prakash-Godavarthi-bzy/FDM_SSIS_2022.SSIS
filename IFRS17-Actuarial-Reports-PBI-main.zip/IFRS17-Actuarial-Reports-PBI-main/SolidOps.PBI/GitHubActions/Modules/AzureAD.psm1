function Connect-AAD {
    [CmdletBinding()]
    Param(
        [string]$user,
        [string]$pass,
        [string]$userType = "ServiceAccount",
        [string]$tenantId
    )
    if(($user) -and ($pass)) {
        if($userType -eq "ServiceAccount") {
            Write-Host "Connecting Service account"
            # Connect to PBI using specified credentials
            $securedPassword = ConvertTo-SecureString $Pass -AsPlainText -Force
            $pbiServiceAccountCred = New-Object System.Management.Automation.PSCredential ($User, $securedPassword)
            Connect-AzureAD -Credential $pbiServiceAccountCred
            Write-Host "Connected $user to Azure AD"
        } elseif ($userType -eq "ServicePrincipal") {
            Write-Host "Connecting Service Principal"
            $azureAplicationId =$user
            $azureTenantId= $tenantId
            $azurePassword = ConvertTo-SecureString $pass -AsPlainText -Force
            $psCred = New-Object System.Management.Automation.PSCredential($azureAplicationId , $azurePassword)
            Connect-AzAccount -Credential $psCred -TenantId $azureTenantId -ServicePrincipal

            $context = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.DefaultContext
            $aadToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://graph.windows.net").AccessToken
            Connect-AzureAD -AadAccessToken $aadToken -AccountId $context.Account.Id -TenantId $context.tenant.id


            Connect-MgGraph -ClientSecretCredential $psCred -TenantId $azureTenantId

            Write-Warning "Connected $user using client secret"
        } else {
            Write-Error "Unsupported UserType: $($userType)"
        }
    
    } else {
        Write-Warning "No credentials specified for the Azure AD Service. Proceed with interactive login"
        if(-not $user) {
            Write-Warning "Missing user"
        }
        if (-not $pass) {
            Write-Warning "Missing password"
        }
        # connect to PBI using interactive login
        #Connect-PowerBIServiceAccount

        # connect to AAD using interactive login
        Connect-AzureAD
        Write-Verbose "Connected to Azure AD Service using specified user"
    }
}

function Invoke-GraphRestMethod {
    [CmdletBinding()]
    param (
        # url
        [Parameter(Mandatory=$true)]
        [string]
        $url,
        # access token
        [Parameter(Mandatory=$true)]
        [string]
        $accessToken,
        # Method
        [Parameter(Mandatory=$true)]
        [ValidateSet("Get", "Post")]
        $method,
        $postBody,
        $contentType = "application/json"
    )

    $uri = "https://graph.microsoft.com/beta/$url"

    $headers = @{
        'Authorization' = "Bearer $accessToken" 
    }

    $parms = @{
        'Uri' = $uri
        'Method' = $method
        'Headers' = $headers
    }

    if($postBody) {
        $parms += @{ 'Body' = $postBody | ConvertTo-Json }
        $parms += @{ 'ContentType' = $contentType }
    }


    try {
        $response = Invoke-RestMethod @parms

        return $response
    }
    catch {
        Write-Verbose "[Invoke-GraphRestMethod] URL: $uri"
        if ($postBody) {
            Write-Verbose "[Invoke-GraphRestMethod] Post body:"
            $paramJson = $postBody | ConvertTo-Json
            Write-Verbose $paramJson
        }

        Write-Verbose "[Invoke-GraphRestMethod] Server response stream"
        $respStream = $_.Exception.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($respStream)
        $respBody = $reader.ReadToEnd() #| ConvertFrom-Json
        $respBody;
        Write-Verbose $respBody

        Write-Verbose "[Invoke-GraphRestMethod] Server response start"
        
        $_.Exception.ErrorDetails | ConvertTo-Json
        $_.Exception.Response | ConvertTo-Json
        Write-Verbose "[Invoke-GraphRestMethod] Server response end"

        Write-Error $_ 
    }
}

function Get-AzureADGroupDisplayName {
    [CmdletBinding()]
    param (
        # group name
        [Parameter(Mandatory=$true)]
        [string]
        $groupName,
        # env code
        [Parameter(Mandatory=$true)]
        [string]
        $envCode
    )
    
    if($envCode -ne "PRD") {
        $groupName += ".TST" 
    }
    return $groupName
}


function Get-AzureADGroupByName {
    [CmdletBinding()]
    param (
        # Group name
        [Parameter(Mandatory=$true)]
        [string]
        $displayName
    )
    

    $groups = Get-AzureADGroup -SearchString $displayName
    $groupId = $null

    if ($groups.Length -gt 0) {
        $group = $groups | Where-Object { $_.DisplayName -eq $displayName }
        if($group.Length -gt 0) {
            $groupId = $group.ObjectId | Get-Unique
        }
    }

    return $groupId
}


function Set-AzureADGroup {
    [CmdletBinding()]
    param (
        # Group name
        [Parameter(Mandatory=$true)]
        [string]
        $displayName,
        [string]
        $description
    )

    

    $groupId = Get-AzureADGroupByName -displayName $displayName

    if($null -eq $groupId) {
        Write-Warning "Calling obsolete New-AzureADGroup method"
        $group = New-AzureADGroup -DisplayName $displayName -MailEnabled $false -SecurityEnabled $true -MailNickName "NotSet" -Description $description
        $groupId = $group.ObjectId
        Write-Verbose "Created group $displayName with id $groupId. Wait 60 seconds for changes to propagate"
        Start-Sleep -s 60
    } else {
        Write-Verbose "Group $displayName already exists"
    }

    return $groupId
}

function Set-GraphGroup {
    [CmdletBinding()]
    param (
        # Group name
        [Parameter(Mandatory=$true)]
        [string]
        $displayName,
        [string]
        $description
    )

    $groupId = Get-AzureADGroupByName -displayName $displayName

    if($null -eq $groupId) {
        
        $group = New-MgGroup -DisplayName $displayName  -MailEnabled:$False  -MailNickName 'testgroup' -SecurityEnabled -Description $description
        #$group = New-AzureADGroup -DisplayName $displayName -MailEnabled $false -SecurityEnabled $true -MailNickName "NotSet" -Description $description
        $groupId = $group.Id
        Write-Verbose "Created group $displayName with id $groupId. Wait 60 seconds for changes to propagate"
        Start-Sleep -s 60
    } else {
        Write-Verbose "Group $displayName already exists"
    }

    return $groupId
}

function Get-AzureADGroupMembers {
    [CmdletBinding()]
    param (
        # Group Id
        [Parameter(Mandatory=$true)]
        [string]
        $groupId,
        [Parameter(Mandatory=$true)]
        [string]
        $accessToken
    )
    
    $membersResponse = Invoke-GraphRestMethod -url "groups/$groupId/members" -method Get -accessToken $accessToken
    
    return $membersResponse
}


function Set-AzureADGroupMembers {
    [CmdletBinding()]
    param (
         # Group Id
         [Parameter(Mandatory=$true)]
         [string]
         $groupId,
         # members separated by ;
         [Parameter(Mandatory=$true)]
         [string]
         $members,
         $aadMembers,
         $grantType = "password"
    )
    Write-Verbose "[Set-AzureADGroupMembers] begin"

    $membersArray = $members.Split(";") | Sort-Object -Unique


    foreach ($item in $membersArray) {
        $item = Set-CleanEmail -email $item -functionName "Set-AzureADGroupMembers" -variableName "workspace.json - owners property"
        if($item) {
            $user = Get-AzureADUser -ObjectId $item
            $memberId = $user.ObjectId

            $member = $null
            if($aadMembers) {
                $member = $aadMembers | Where-Object { $_.ObjectId -eq $memberId }
            } 
            
            if($null -eq $member) {
                Write-Verbose "[Set-AzureADGroupMembers] Adding $item  as Member to group $groupId"
                if($grantType -eq "password") {
                    Add-AzureADGroupMember -ObjectId $groupId -RefObjectId $memberId
                    Write-Verbose "[Set-AzureADGroupMembers] Added $item as Member to group $groupId"
                } else {
                    New-MgGroupMember -GroupId $groupId -DirectoryObjectId $memberId
                    Write-Warning "[Set-AzureADGroupMembers] Added $item as Member to group $groupId using new graph method"
                }   
                
                
            } else {
                # Write-Verbose "$item already Member to group $groupId"
            }
        }
    }

    Write-Verbose "[Set-AzureADGroupMembers] end"
}



function Set-AzureADGroupOwners {
    [CmdletBinding()]
    param (
        # Group Id
        [Parameter(Mandatory=$true)]
        [string]
        $groupId,
        # owners separated by ;
        [Parameter(Mandatory=$true)]
        [string]
        $owners,
        [Parameter(Mandatory=$true)]
        [string]
        $accessToken,
        [string]
        $grantType = "password"
    )
    
    $ownersArray = $owners.Split(";") | Sort-Object -Unique

    # $url = "https://graph.microsoft.com/beta/groups/$groupId/owners"
    # $Headers = ${
    #     'Authorization' = "$accessToken" 
    # }
    # Invoke-RestMethod -Method Get -Uri $url -Headers $Headers
    $ownerResponse = Invoke-GraphRestMethod -url "groups/$groupId/owners" -method Get -accessToken $accessToken

    # https://docs.microsoft.com/en-us/powershell/module/azuread/get-azureadgroupowner?view=azureadps-2.0
    #$owners = Get-AzureADGroupOwner -ObjectId $groupId -All $true
    

    foreach ($email in $ownersArray) {
        $email = Set-CleanEmail -email $email -functionName "Set-AzureADGroupOwners" -variableName "workspace.json - owners property"
        if($email) {
            $user = Get-AzureADUser -ObjectId $email
            $ownerId = $user.ObjectId
            
            
            $owner = $ownerResponse.value | Where-Object { $_.id -eq $ownerId }

            if($null -eq $owner) {
                if($grantType -eq "password") {
                    Add-AzureADGroupOwner -ObjectId $groupId -RefObjectId $user.ObjectId
                    Write-Verbose "Added $email as Owner to group $groupId"
                } else {
                    New-MgGroupOwner -GroupId $groupId -DirectoryObjectId $user.ObjectId
                    Write-Warning "Added $email as Owner to group $groupId using New-Mg"
                }
                
            } else {
                Write-Verbose "$email already Owner to group $groupId"
            }
        }
    }

    #return Get-AzureADGroupOwner -ObjectId $groupId
}


function Set-AzureADGroups {
    [CmdletBinding()]
    param (
        # groups
        [Parameter(Mandatory=$true)]
        $groupConfig,
        # environment code
        [Parameter(Mandatory=$true)]
        [string]
        $envCode,
        # username
        [Parameter(Mandatory=$false)]
        [string]
        $user,
        # password
        [Parameter(Mandatory=$false)]
        [string]
        $pass,
        # client id
        [Parameter(Mandatory=$true)]
        [string]
        $clientId,
        # resource
        [Parameter(Mandatory=$true)]
        [string]
        $resource,
        [string]
        $grantType = "password"
    )
    
    $groups = $groupConfig.permissions | Where-Object { $_.principalType -eq "Group" }

    

    foreach ($group in $groups) {
        Write-Verbose "[Set-AzureADGroups] Processing group $($group.user)"
        $displayName = Get-AzureADGroupDisplayName -groupName $group.user -envCode $envCode
        $description = "SolidOps.PBI security group for $displayName"
        $groupId = $null
        if($grantType -eq "password") {
            $groupId = Set-AzureADGroup -displayName $displayName -description $description
        } else {
            $groupId = Set-GraphGroup -displayName $displayName -description $description
        }
        
        Write-Verbose "GroupID $groupId"
        $aadMembers = Get-AzureADGroupMember -ObjectId $groupId -All $true | Select-Object ObjectId,UserPrincipalName

        Write-Host "[Set-AzureADGroups] Processing members for $($group.user)"
        Set-AzureADGroupMembers -members $group.owners -groupId $groupId -aadMembers $aadMembers -grantType $grantType

        if($user -and $pass) {
            $token = Get-MicrosoftToken2 -user $user -pass $pass -clientId $clientId -resource $resource -grantType $grantType

            Write-Host "[Set-AzureADGroups] Processing owners for $($group.user)"
            if($grantType -eq "password") {
                Set-AzureADGroupOwners -owners $group.owners -groupId $groupId -accessToken $token.access_token -grantType $grantType
            } else {
                Write-Warning "Missing permission to add group owners for service principals"
            }
            
        }
        else {
            Write-Warning "[Set-AzureADGroups] missing credentials for setting group owners for $($displayName)"
        }

        

        Write-Verbose "End process for group $($group.user)"
    }
    
}


function Get-GraphBusinessFlowTemplates {
    [CmdletBinding()]
    param (
        # access token
        [Parameter(Mandatory=$true)]
        [string]
        $accessToken
    )

    $url = "businessFlowTemplates"
    
    $response = Invoke-GraphRestMethod -url $url -accessToken $accessToken -method Get

    return $response
}

function Get-GraphAccessReviewGroupTemplate {
    [CmdletBinding()]
    param (
        # access token
        [Parameter(Mandatory=$true)]
        [string]
        $accessToken
    )
    
    $templateName = "Access reviews of memberships of a group"
    $templates = Get-GraphBusinessFlowTemplates -accessToken $accessToken
    
    #Write-Verbose $templates
    
    $template = $templates.value | Where-Object { $_.displayName -eq $templateName} 

    if($template) {
        return $template 
    } else {
        Write-Error "[SolidOps.PBI.AzureAD] Could not find template [$templateName]"
    }
}

function Set-GraphAccessReviewGroup {
    [CmdletBinding()]
    param (
         # access token
         [Parameter(Mandatory=$true)]
         [string]
         $accessToken,
         # Group Id
         [Parameter(Mandatory=$true)]
         [string]
         $groupId
    )
    
    $url = "accessReviews"

    $template = Get-GraphAccessReviewGroupTemplate -accessToken $accessToken

    #TODO
    <#
        start/end date time
        
    #>

    # https://docs.microsoft.com/en-us/graph/api/accessreview-create?view=graph-rest-beta
    $postParams = @{
        displayName = "TestReview"
        startDateTime = "2021-03-05T00:35:53.214Z"
        endDateTime = "2021-04-05T00:35:53.214Z"
        description = "SolidOps.PBI test review"
        businessFlowTemplateId = $template.id
        reviewerType = "entityOwners"
        reviewedEntity = @{
            id = $groupId
        } 
        settings = @{
            mailNotificationsEnabled = $true
            remindersEnabled = $true
            justificationRequiredOnApproval = $true
            autoReviewEnabled = $true
            activityDurationInDays = 30
            autoApplyReviewResultsEnabled = $false
            accessRecommendationsEnabled = $true
            autoReviewSettings = @{
                notReviewedResult = "Recommendation"
            }
            recurrenceSettings = @{
                recurrenceType = "oneTime"
                recurrenceEndType = "endBy"
                durationInDays = 0
                recurrenceCount = 0
            }
        }
    }

    $reponse = Invoke-GraphRestMethod -url $url -accessToken $accessToken -method Post -postBody $postParams

    Write-Verbose $reponse

}
