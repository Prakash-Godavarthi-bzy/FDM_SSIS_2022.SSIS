[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Set-CloudDataGateway {
    [CmdletBinding()]
    param (
        # Gateway id
        [Parameter(Mandatory=$true)]
        [string]
        $gatewayId,
        [Parameter(Mandatory=$true)]
        [string]
        $datasourceId,
        # Oauth2 token
        [Parameter(Mandatory=$true)]
        $token
    )

    Write-Verbose "[Update-CloudDataGateway] begin"

    # PATCH https://api.powerbi.com/v1.0/myorg/gateways/{gatewayId}/datasources/{datasourceId}
    $url = "https://api.powerbi.com/v1.0/myorg/gateways/$($gatewayId)/datasources/$($datasourceId)"

    $credentials = @{
        credentialData = @(@{
            name  = "accessToken"
            value = $token.access_token
        }) 
    } | ConvertTo-Json -Compress

    $postParams = @{ 
        "credentialDetails" = @{
            "credentialType"      = "OAuth2"
            "credentials"         = $credentials 
            "encryptedConnection" = "NotEncrypted"
            "encryptionAlgorithm" = "None"
            "privacyLevel"        = "None"
        }    
    }

    $jsonPostBody = $postParams | ConvertTo-Json -Depth 4 

    $accessToken = Get-PowerBIAccessToken
    $bearer = $accessToken.Authorization.ToString()

    $headers = @{
        'Authorization' = "$bearer" 
    }

    try {
        # Invoke-PowerBIRestMethod not available for Gateway operations
        $response = Invoke-RestMethod -Uri $url `
            -Headers $headers `
            -Body $jsonPostBody `
            -ContentType "application/json" `
            -Method PATCH
        
        Write-Verbose "[Update-CloudDataGateway] end"

        return $response
    }
    catch {
        Write-Warning "[Update-CloudDataGateway] Could not update cloud datasource"
        Write-Verbose $jsonPostBody
        Write-Verbose $url
        
    
        Write-Verbose "[Update-CloudDataGateway] Server response stream"
        $respStream = $_.Exception.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($respStream)
        $respBody = $reader.ReadToEnd() #| ConvertFrom-Json
        $respBody;
        Write-Verbose $respBody

        Write-Verbose "[Update-CloudDataGateway] Server response start"
        
        $_.Exception.ErrorDetails | ConvertTo-Json
        $_.Exception.Response | ConvertTo-Json
        Write-Verbose "[Update-CloudDataGateway] Server response end"
    
        Write-Error $_
    }
    
}

Connect-PowerBIServiceAccount

$token = @{
    access_token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Imwzc1EtNTBjQ0g0eEJWWkxIVEd3blNSNzY4MCIsImtpZCI6Imwzc1EtNTBjQ0g0eEJWWkxIVEd3blNSNzY4MCJ9.eyJhdWQiOiJodHRwczovL2FuYWx5c2lzLndpbmRvd3MubmV0L3Bvd2VyYmkvYXBpIiwiaXNzIjoiaHR0cHM6Ly9zdHMud2luZG93cy5uZXQvOWE1MGViYTgtNzU2OC00NDdhLWJjYjktMjdhMGQ0NjRhYTgwLyIsImlhdCI6MTYzNjAzMjU5OSwibmJmIjoxNjM2MDMyNTk5LCJleHAiOjE2MzYwMzc2OTUsImFjY3QiOjAsImFjciI6IjEiLCJhaW8iOiJBVFFBeS84VEFBQUF5NllnTk5MRUt1SDdRV2xYYi9rVU1uazBicFFUQ3gxWjNURWFsMVN0dVhRVFVNdFdtL2l2Y2t4VzNIckwvYkV3IiwiYW1yIjpbIndpYSJdLCJhcHBpZCI6Ijg3MWMwMTBmLTVlNjEtNGZiMS04M2FjLTk4NjEwYTdlOTExMCIsImFwcGlkYWNyIjoiMiIsImZhbWlseV9uYW1lIjoiQ2hpcmFwbGVzIiwiZ2l2ZW5fbmFtZSI6IkFsZXhhbmRydSIsImluX2NvcnAiOiJ0cnVlIiwiaXBhZGRyIjoiMTk4LjIwNS4xMy4yMSIsIm5hbWUiOiJBbGV4YW5kcnUgQ2hpcmFwbGVzIiwib2lkIjoiNTZmOTg2MzMtNTEwNi00Zjc4LTgyZTktNzAyYzk0ZjY3MjQxIiwib25wcmVtX3NpZCI6IlMtMS01LTIxLTU4NTk0OTM4LTE2MzM2Mjg3ODktODAxNTI2MzczLTExNTg2MiIsInB1aWQiOiIxMDAzMjAwMTAyNDgwMkMxIiwicmgiOiIwLkFVY0FxT3RRbW1oMWVrUzh1U2VnMUdTcWdBOEJISWRoWHJGUGc2eVlZUXAta1JCSEFEZy4iLCJzY3AiOiJ1c2VyX2ltcGVyc29uYXRpb24iLCJzaWduaW5fc3RhdGUiOlsiaW5rbm93bm50d2siXSwic3ViIjoiOTBXR1hLOE1pTGxkTXpRamVSU0hFYTJzVTVkYW9xNWQ1bWFNeS0yWnZDYyIsInRpZCI6IjlhNTBlYmE4LTc1NjgtNDQ3YS1iY2I5LTI3YTBkNDY0YWE4MCIsInVuaXF1ZV9uYW1lIjoiYWxleGFuZHJ1LmNoaXJhcGxlc0BiZWF6bGV5LmNvbSIsInVwbiI6ImFsZXhhbmRydS5jaGlyYXBsZXNAYmVhemxleS5jb20iLCJ1dGkiOiJFUWJ2UEh0NzEwS3owX2x4aEJKdEFBIiwidmVyIjoiMS4wIiwid2lkcyI6WyJiNzlmYmY0ZC0zZWY5LTQ2ODktODE0My03NmIxOTRlODU1MDkiXX0.qVO7pyNOokCRXCV65VZiRxjXMBL5NNPRaKUSYTGHTV_iDjEhtYIuKanPDvzY13C7wu-sCKJEs4dIHPI9lo-0VYH0HQo1-dY6JL79Zi5GwBbDMo7DtbhcVEa5H9uXz5KWPywJEUMvOTZSykI_t54_sL4BIoynzaHX86aGPB6Gq-MQZc985mPR2sfrp7jdxvVhTBFJreua_tr6YPqKT-wqYtVI4Rq3kwbM6JXd8A0hqQk5y8mozezc1a5VEO49UAAIGPwVGWrIhqAHcPF78kZ8Xw9zdOm5ntzdD-Mi-aYuteu8jMKGAZDaQTvzmY2dYFsL2jgSPNGIdYagKf1oGm7Utw"
}
$gatewayId = "1f64b140-3082-47bc-bc03-ca0735a627aa"
$datasourceId = "54045e79-8aa8-4129-8efb-468759df19ee"

Set-CloudDataGateway -gatewayId $gatewayId -datasourceId $datasourceId -token $token