# gh search repos "PBI" --owner=beazley --limit 300

$records = gh search repos "PBI" --owner=beazley --limit 300 --json=name | Out-String | ConvertFrom-Json

$toProcess = @()
foreach ($repo in $records) {
    if($repo.name.StartsWith("DM-")) {
        Write-Host "Process $($repo.name)"
        $toProcess += $repo.name
    } elseif($repo.name.StartsWith("DM.")) {
        Write-Host "Process $($repo.name)"
        $toProcess += $repo.name
    } else {
        Write-Warning "Skip $($repo.name)"
    }
    
}

$gitPath = "C:\git\SolidOps.PBI\GitHub\update"

if(-not (Test-Path $gitPath)) {
    New-Item $gitPath -ItemType Directory
}
Push-Location $gitPath
if (-not (Test-Path "template-powerbi-reports"))
{
    git clone "https://github.com/beazley/template-powerbi-reports.git"
}

Write-Host "----------------"
Write-Host "To be processed: $($toProcess.Count)"
foreach ($item in $toProcess) {
    Write-Host $item
    $gitRepo = "https://github.com/beazley/$($item).git"
    
    if(-not (Test-Path "$($gitPath)\$($item)"))  {
        git clone $gitRepo
        cd $item
        git checkout -b fix/cab
        Copy-Item -Path "$($gitPath)\template-powerbi-reports\src\workspace.json" -Destination "$($gitPath)\$($item)\src" -Force

        git add .
        git commit -m "fix CAB"
        git push --set-upstream origin fix/cab
        Start-Sleep 5
        gh pr create --title "Change for CAB" --body "changed workspace.json AAD group format"
        cd ..
            
    }

    cd $item
    
    cd ..

    

}