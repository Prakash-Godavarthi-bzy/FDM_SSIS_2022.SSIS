$records = gh search repos "PBI" --owner=beazley --limit 500 --json=name | Out-String | ConvertFrom-Json

$toProcess = @()
foreach ($repo in $records) {
    if($repo.name.StartsWith("DM-")) {
        Write-Host "Process $($repo.name)"
        $toProcess += $repo.name
    } elseif($repo.name.StartsWith("DM.")) {
        Write-Host "Process $($repo.name)"
        $toProcess += $repo.name
    } else {
        Write-Warning "Skip $($repo.name)"
    }
    
}

$gitPath = "C:\git\SolidOps.PBI\GitHub\repos.txt"

#$joined = $toProcess -Join ";"

#Add-Content -Path $gitPath -Value $joined

foreach($repoName in $toProcess)
{
    Add-Content -Path $gitPath -Value $repoName
}