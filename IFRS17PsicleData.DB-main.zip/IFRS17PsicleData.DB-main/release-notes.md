﻿Sprint 15.4
- 2024Q1 Hot fix I17-6787
- I17-6092 update
- I17-7275 

Sprint 15.3 
- 2024Q1 bug fixes from 15 , 15.1 and 15.2 release
- Update IFRS17_Master table(I17-7188)

Sprint psicledata

- Adding and updating the Opening Balances tables for the ticket(I17-3093)[for both the Inbound and Results schemas]
- Added the MVP tables in both the Inbound and Reporting schemas(I17-3162)


Altering the datatypes of new OB tables of Results schema
-altered datatype(float not null) to numeric(38,10) null for all 3 new OB tables.


- Added Id columns for MVP tables and changed Open / Closed column to Open_Closed for all inbound tables.

- Dropping all the dbo schema tables

- Amoount Column Constraint changed from Not Null to Null

- Updated the Merge Scripts as per ICE Population

Sprint1

- Sprint0 MVP task bugs are fixed (I17-3333,I17-3332)

Sprint3

-added new AccountMapping rules table and Exceptionreport view for ICE journals.

- Static Mapping tables are created (I17-3025)
- Added Inbound. stg_CSMReleaseBalancesOB,Results.CSMReleaseBalancesOB tables For (I17-3457)

Sprint3

- Updated Column lenghts (I17-3496)

Sprint4

- Invalid data in the tables(I17-3569) 
- Default values added to the tables CSMReleaseOBBalances,Earnings OB,Premium Adjustments,Release Calcs FSC(I17-3636)

Sprint5

- The Closing LC_Adj    and Closing(Inc LC_ADJ) positions should also be excluded in the mappings (I17-3913)
- loading the dummy OBs (I17-3766)
- JournalCreation – Add calculation of Adjustment Journal (I17-3434)
- JournalCreation - Delete zero rows, when calculating YTD values, refresh of static data (I17-3423)
- JournalCreation – Refresh of static data (I17-3992)
- JournalCreation – Add calculation of ReAllocation Journal (I17-3435)
- JournalCreation – Add validation V03 to App (I17-3422)
- JournalCreation – Add validation V01 to App (I17-3420)
- JournalCreation – Add validation V02 to App (I17-3421)
- JournalCreation - Fix accounting date list (I17-4025)

Sprint6
 - JournalCreation - Add tables and procedure for transfer of Agresso reference data (I17-3451)
 - JournalCreation - Add views for applied of fixed and user rules and add procedure for output table generation as source for CSV generation (I17-3452)
 - JournalCreation - Add views for compare Journal data with Agresso reference data, table, procedure and job for run transfer from Agresso reference data (I17-3451)
 - JournalCreation - changes when AssetLiabilityAmount is NULL then it fills up 0 (I17-4310)
 - JournalCreation - change in condition from 0 to 0.00 (I17-4296)
 - JournalCreation - Add currency split on screen so numbers make more sense (I17-4283)
 - FSC_Output table is added in Inbound and Reporting schemas (I17-4298)

 Sprint7
 - JournalCreation - first part of the application optimization (I17-4358) and fixes from related tikets (I17-4351, I17-4380)
 - JournalCreation - fixed up history log (I17-4338)
 - Update Inbound.stg_HistLockRatesOB.YoI datatype to Float
 - Updated the Account column to 25 in Reporting.FSC_Output table
 - JournalCreation - Journal validations check before export to csv  (I17-4512)
 - JournalCreation - Add new fail report for Validation 02  (I17-4434)
 - JournalCreation - Optimize the performance on the journal solution  (I17-4435)
 - JournalCreation - Adding generation of final CSV file for Agresso  (I17-4485)

Sprint7D
 - JournalCreation - fixed typo Liability in ReAllocation validation (I17-4565)
 - JournalCreation - unified calculation of Conv_Amount_disc for closing position (I17-4577)
 - JournalCreation - Adding display other currencies for V01 (I17-4629, I17-4643)
 - JournalCreation - Adding display other currencies for V02 (I17-4630, I17-4631)
 - JournalCreation - Modifying final validation for Check Ref data with Agresso - null values valid, if in user rules (I17-4669)
 - JournalCreation - Modifying the usp_RunPackage procedure - add throw, when job doesnot start (I17-4549)
 - JournalCreation - Journal optimization final validations (I17-4561)
 - JournalCreation - updated static data for Dim.JournalTransactionTypeMapping and Dim.JournalReAllocationMapping (I17-4692)
 - JournalCreation - updated static data for Dim.JournalTransactionTypeMapping and Dim.JournalReAllocationMapping (I17-4692)
 - JournalCreation - Added support for budget runs in YTD calculation (I17-4356)
 - JournalCreation - Changed YTD calculation to handle duplicities in source for Open/Closing position (I17-4685)
 - JournalCreation - Add view for CSV journal export (I17-4585)
 - JournalCreation - Add static data for AccountMappingRules (I17-4679)
 - JournalCreation - Refresh static data for JournalEntitiesMapping (I17-4722)

 Sprint8
 - JournalCreation - added new table for experience journal detail data (I17-4829)
 - JournalCreation - added new procedure for experience journal calculation (I17-4828)
 - JournalCreation - CR add additional mapping attribute CSM_LC(I17-4793)
 - JournalCreation - added new V04 validation objects(I17-4826)
 - JournalCreation - added new display Experience Journal and evaluation(I17-4827)
 - JournalCreation - modification of the original V01 validation procedure usp_V01Validation and addition V01 validation exclude 88888(I17-4831)
 - JournalCreation - Appended experience journal and filtered out temp accounts (I17-4830)
 - JournalCreation - refresh static data for journal transaction type mapping (I17-4862)
 - JournalCreation - Added new table and calculation procedure for experience journal(I17-4828)
 - JournalCreation - added new filtration rules - exclude LC components for calculation AssetLiabilityAmount(I17-4875)
 - JournalCreation - Rename DB objects(I17-4876)
 - JournalCreation - applied new rules to exclude rows from mapping rules dataset (I17-4863)
 - JournalCreation - change Overview Fail report for approval (I17-4898)
 - JournalCreation - fixed duplicate values in V02 Overview Failed values (I17-4918)
 - JournalCreation - Apply filter balance not in CSM_LC (I17-4921)
 - JournalCreation - refresh static data for account mapping rules (I17-4812)

 Sprint (15)2024Q1  
 - JournalCreation - Added QTD journal creation option.
 - JournalCreation - Updated Entity and trifocus default values as per 6092.
 - Calc UI - Added two procedures for ICE status checks.

Sprint 15.2(2024Q1 bug fixes)
 - Predeployment script altered indexes back to columnstore
 - i17-7207 bug fix
