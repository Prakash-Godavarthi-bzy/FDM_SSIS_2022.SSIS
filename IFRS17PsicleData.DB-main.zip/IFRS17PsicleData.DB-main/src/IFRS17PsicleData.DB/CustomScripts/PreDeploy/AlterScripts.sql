﻿

--IF Exists (SELECT 1 FROM sys.tables where name ='AccountMappingRules'  AND schema_id = SCHEMA_ID('Dim'))
--BEGIN
--  TRUNCATE TABLE [Dim].[AccountMappingRules];
--END;


/* Static data refresh - Dim.JournalReAllocationMapping */
IF EXISTS (SELECT 1 FROM sys.tables where name = 'JournalReAllocationMapping' AND schema_id = SCHEMA_ID('Dim'))
BEGIN
  TRUNCATE TABLE Dim.JournalReAllocationMapping;
END;


/* Static data refresh - Dim.JournalEntitiesMapping */
IF EXISTS (SELECT 1 FROM sys.tables where name = 'JournalEntitiesMapping' AND schema_id = SCHEMA_ID('Dim'))
BEGIN
  TRUNCATE TABLE Dim.JournalEntitiesMapping;
END;


IF Exists (SELECT 1 FROM sys.tables where name ='JournalTransactionTypeMapping'  AND schema_id = SCHEMA_ID('Dim'))
BEGIN
TRUNCATE TABLE Dim.JournalTransactionTypeMapping;
END;

IF Exists (SELECT 1 FROM sys.tables where name ='JournalReallocationSelectionList'  AND schema_id = SCHEMA_ID('Dim'))
BEGIN
TRUNCATE TABLE Dim.JournalReallocationSelectionList;
END;



IF EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='JournalOutputAdjustmentReAllocationJournalOutput'  AND TABLE_SCHEMA = 'Reporting')
BEGIN
	DROP VIEW IF EXISTS PWAPS.vw_JournalExportCSV;
	DROP VIEW IF EXISTS PWAPS.vw_VersionList;
	DROP PROCEDURE IF EXISTS Reporting.usp_MergeJournalOutputAdjustmentReAllocationJournalOutput;
	EXEC sp_rename 'Reporting.JournalOutputAdjustmentReAllocationJournalOutput', 'JournalOutputFinal';
	EXEC sp_rename 'Reporting.JournalOutputFinal.cci_JournalOutputAdjustmentReAllocationJournalOutput', 'cci_JournalOutputFinal', 'INDEX';  
END





IF EXISTS (SELECT DISTINCT 1 FROM sys.all_objects WHERE [type] = 'P' AND schema_id = 5 AND [name] = 'usp_MergeUndiscCSMWalkBalancesOB') 
BEGIN DROP PROCEDURE INBOUND.usp_MergeUndiscCSMWalkBalancesOB END




-------Sprint14---------- THIS CODE WAS CHANGED BACK TO COLUMNSTORE AS PWAPS WAS NOT PERFORMING WITH ROWSTORE
IF ISNULL((select 1 from sys.indexes where [name] = 'cci_CSM_Post_LCAdjustments'), 0) <> 1
	BEGIN
		CREATE CLUSTERED COLUMNSTORE INDEX [cci_CSM_Post_LCAdjustments] ON [Reporting].[CSM_Post_LCAdjustments] WITH (DROP_EXISTING = OFF, MAXDOP=1)
	END
ELSE
	BEGIN
		IF ISNULL((select 1 from sys.indexes where [name] = 'cci_CSM_Post_LCAdjustments'  and [type] = 5), 0) = 0
			BEGIN
			CREATE CLUSTERED COLUMNSTORE INDEX [cci_CSM_Post_LCAdjustments] ON [Reporting].[CSM_Post_LCAdjustments] WITH (DROP_EXISTING = ON, MAXDOP=1)
			END
	END



IF ISNULL((select 1 from sys.indexes where [name] = 'cci_LIC_DiscountedData'), 0) <> 1
	BEGIN
		CREATE CLUSTERED COLUMNSTORE INDEX [cci_LIC_DiscountedData] ON [Reporting].[LIC_DiscountedData] WITH (DROP_EXISTING = OFF, MAXDOP=1)
	END
ELSE
	BEGIN
		IF ISNULL((select 1 from sys.indexes where [name] = 'cci_LIC_DiscountedData'  and [type] = 5), 0) = 0
			BEGIN
			CREATE CLUSTERED COLUMNSTORE INDEX [cci_LIC_DiscountedData] ON [Reporting].[LIC_DiscountedData] WITH (DROP_EXISTING = ON, MAXDOP=1)
			END
	END



IF ISNULL((select 1 from sys.indexes where [name] = 'cci_LRC_Post_BBNIAdjustments'), 0) <> 1
	BEGIN
		CREATE CLUSTERED COLUMNSTORE INDEX [cci_LRC_Post_BBNIAdjustments] ON [Reporting].[LRC_Post_BBNIAdjustments] WITH (DROP_EXISTING = OFF, MAXDOP=1)
	END
ELSE
	BEGIN
		IF ISNULL((select 1 from sys.indexes where [name] = 'cci_LRC_Post_BBNIAdjustments'  and [type] = 5), 0) = 0
			BEGIN
			CREATE CLUSTERED COLUMNSTORE INDEX [cci_LRC_Post_BBNIAdjustments] ON [Reporting].[LRC_Post_BBNIAdjustments] WITH (DROP_EXISTING = ON, MAXDOP=1)
			END
	END



--IF EXISTS (select 1 from sys.indexes where type in (5, 6) and name = 'cci_JournalInputDataYTD')
--BEGIN
--CREATE CLUSTERED INDEX [cci_JournalInputDataYTD] ON [Reporting].[JournalInputDataYTD] ([RunIDs] ASC)
--WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = ON, ONLINE = OFF, ALLOW_ROW_LOCKS = ON,  ALLOW_PAGE_LOCKS = ON)

--CREATE CLUSTERED COLUMNSTORE INDEX [cci_JournalInputDataYTD] ON [Reporting].[JournalInputDataYTD] WITH (DROP_EXISTING = ON, MAXDOP=1)
--END


IF EXISTS (SELECT DISTINCT 1 from INFORMATION_SCHEMA.COLUMNS where TABLE_SCHEMA ='Inbound' and TABLE_NAME ='stg_IFRS17_MasterTable' )
BEGIN
ALTER TABLE [Inbound].[stg_IFRS17_MasterTable] ALTER COLUMN [Quarter] varchar(255) null
END

IF EXISTS (SELECT DISTINCT 1 from INFORMATION_SCHEMA.COLUMNS where TABLE_SCHEMA ='Reporting' and TABLE_NAME ='IFRS17_MasterTable')
BEGIN
ALTER TABLE [Reporting].[IFRS17_MasterTable] ALTER COLUMN [Quarter] varchar(25) null
END

IF NOT EXISTS (SELECT DISTINCT 1 from INFORMATION_SCHEMA.COLUMNS where TABLE_SCHEMA ='Reporting' and TABLE_NAME ='JournalOutputLCAdjMovement' And COLUMN_NAME='JournalType')
BEGIN
Alter table [Reporting].[JournalOutputLCAdjMovement] Add [JournalType] Varchar(100) NULL
END;

IF NOT EXISTS (SELECT DISTINCT 1 from INFORMATION_SCHEMA.COLUMNS where TABLE_SCHEMA ='Reporting' and TABLE_NAME ='JournalOutputAdjustment' And COLUMN_NAME='JournalType')
BEGIN
Alter table [Reporting].[JournalOutputAdjustment] Add [JournalType] Varchar(100) NULL
END;

IF NOT EXISTS (SELECT DISTINCT 1 from INFORMATION_SCHEMA.COLUMNS where TABLE_SCHEMA ='Reporting' and TABLE_NAME ='JournalInputDataYTD' And COLUMN_NAME='JournalType')
BEGIN
Alter table [Reporting].[JournalInputDataYTD] Add [JournalType] Varchar(100) NULL
END;


IF EXISTS (SELECT DISTINCT 1 from INFORMATION_SCHEMA.COLUMNS where TABLE_SCHEMA ='Inbound' and TABLE_NAME ='stg_IFRS17_MasterTable' And COLUMN_NAME='Open/Closed')
BEGIN
DROP TABLE [Inbound].[stg_IFRS17_MasterTable]
END

IF EXISTS (SELECT DISTINCT 1 from INFORMATION_SCHEMA.COLUMNS where TABLE_SCHEMA ='Reporting' and TABLE_NAME ='IFRS17_MasterTable' And COLUMN_NAME='Open/Closed')
BEGIN
DROP TABLE [Reporting].[IFRS17_MasterTable]
END


IF EXISTS (SELECT 1 from sys.all_objects WHERE  [name] = 'udf_ReallocationAsstLiabPreQtr_RunIds' AND [schema_id] = '7')
BEGIN
DROP FUNCTION [PWAPS].[udf_ReallocationAsstLiabPreQtr_RunIds]
END

--Added a condition for table exists

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='PWAPS' AND TABLE_NAME='JournalAuditLog')
BEGIN

IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='JournalAuditLog' AND TABLE_SCHEMA='PWAPS' AND COLUMN_NAME='JournalOutputFinal')
BEGIN
ALTER TABLE [PWAPS].[JournalAuditLog] ADD JournalOutputFinal VARCHAR(10) NOT NULL DEFAULT 'Pending'
END
 
IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='JournalAuditLog' AND TABLE_SCHEMA='PWAPS' AND COLUMN_NAME='JournalOutputRowCount')
BEGIN
ALTER TABLE [PWAPS].[JournalAuditLog] ADD JournalOutputRowCount BIGINT NOT NULL DEFAULT 0
END

/*=====================================================

Sprint 17 Hotfix update for I17-7768 - Added new audit 
column in table for journal app
=====================================================*/

IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='JournalAuditLog' AND TABLE_SCHEMA='PWAPS' AND COLUMN_NAME='CSM_Disc_Expr_Adj')
BEGIN
ALTER TABLE [PWAPS].[JournalAuditLog] ADD CSM_Disc_Expr_Adj VARCHAR(10) NOT NULL DEFAULT 'Pending'
END


END


 -- Inbound Table
 IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'Inbound' AND TABLE_NAME = 'stg_CSM_ExperienceAdjustments' AND COLUMN_NAME='IFIE/Locked_CSM_to_Current_diff')
 BEGIN 

 EXEC sp_rename 'Inbound.stg_CSM_ExperienceAdjustments.[IFIE/Locked_CSM_to_Current_diff]','IFIE_Locked_CSM_to_Current_diff','COLUMN';

 END

 IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'Inbound' AND TABLE_NAME = 'stg_CSM_ExperienceAdjustments' AND COLUMN_NAME='Conv_IFIE/Locked_CSM_to_Current_diff')
 BEGIN 

 EXEC sp_rename 'Inbound.stg_CSM_ExperienceAdjustments.[Conv_IFIE/Locked_CSM_to_Current_diff]','Conv_IFIE_Locked_CSM_to_Current_diff','COLUMN';

 END

 -- Reporting Table

 IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'Reporting' AND TABLE_NAME = 'CSM_ExperienceAdjustments' AND COLUMN_NAME='IFIE/Locked_CSM_to_Current_diff')
 BEGIN 

 EXEC sp_rename 'Reporting.CSM_ExperienceAdjustments.[IFIE/Locked_CSM_to_Current_diff]','IFIE_Locked_CSM_to_Current_diff','COLUMN';

 END

 IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'Reporting' AND TABLE_NAME = 'CSM_ExperienceAdjustments' AND COLUMN_NAME='Conv_IFIE/Locked_CSM_to_Current_diff')
 BEGIN 

 EXEC sp_rename 'Reporting.CSM_ExperienceAdjustments.[Conv_IFIE/Locked_CSM_to_Current_diff]','Conv_IFIE_Locked_CSM_to_Current_diff','COLUMN';

 END

 -- Renaming Incepted_Status

 IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'Inbound' AND TABLE_NAME = 'stg_CSM_ExperienceAdjustments' AND COLUMN_NAME='Incepted_Status')
 BEGIN 

 EXEC sp_rename 'Inbound.stg_CSM_ExperienceAdjustments.[Incepted_Status]','Incpeted_Status','COLUMN';

 END

 IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'Reporting' AND TABLE_NAME = 'CSM_ExperienceAdjustments' AND COLUMN_NAME='Incepted_Status')
 BEGIN 

 EXEC sp_rename 'Reporting.CSM_ExperienceAdjustments.[Incepted_Status]','Incpeted_Status','COLUMN';

 END

