﻿



--declare
--    @pRunIDs VARCHAR(50) = 'Actual_36_37_38_39',     /* RunIDs */
--    @pAccDate DATE      = '2020-12-31'     /* Accounting DATE */

CREATE FUNCTION [PWAPS].[udf_GetUnBalancedJournalOutputFinal] (
    @pRunIDs VARCHAR(50),     /* RunIDs */
    @pAccDate DATE           /* Accounting DATE */
)

RETURNS TABLE
AS
RETURN

SELECT RunIDs, AccountingDate, RI_Flag, Balance, Position, 'N' IsBalanced, SUM(Amount) UnbalancedAmount
FROM
(

SELECT RunIDs, AccountingDate, RI_Flag, Balance, Position, SUM(Amount) Amount
FROM Reporting.JournalOutputAdjustment
WHERE AccountingDate = @pAccDate
AND RunIDs = @pRunIDs
AND AccountCode <> '88888'
GROUP BY RunIDs, AccountingDate, RI_Flag, Balance, Position

UNION ALL

SELECT RunIDs, AccountingDate, RI_Flag, Balance, Position, SUM(Amount) Amount
FROM Reporting.ReAllocationJournalOutput
WHERE AccountingDate = @pAccDate
AND RunIDs = @pRunIDs
AND AccountCode <> '88888'
GROUP BY RunIDs, AccountingDate, RI_Flag, Balance, Position

) A
GROUP BY RunIDs, AccountingDate, RI_Flag, Balance, Position
HAVING SUM(Amount) <> 0


