﻿CREATE   procedure [PWAPS].[usp_ICEExceptionReport] (
    @runID1 INT,
    @runID2 INT,
    @runID3 INT,
    @runID4 INT,
    @statement VARCHAR(10)
)
AS

WITH AccMapRules AS (
    SELECT DISTINCT Statement, RI_Flag, Balance, Position, CSM_LC, AccountCode_disc_NegativeAmount, AccountCode_disc_PositiveAmount, AccountCode_undisc_NegativeAmount,
           AccountCode_undisc_PositiveAmount, Transactiontype_Undisc_Amount, Transactiontype_disc_Amount, CONCAT(Statement,CSM_LC,RI_Flag,Position,Balance) AS JournalDescription, SD.VersionID AS VersionID
      FROM Dim.AccountMappingRules DA  
      LEFT JOIN (SELECT JournalDescription, MAX(VersionID) AS VersionID 
                   FROM Dim.AccountMappingRules 
                  GROUP BY JournalDescription
                ) SD ON DA.JournalDescription=SD.JournalDescription AND DA.VersionID=SD.VersionID
     WHERE SD.VersionID IS NOT NULL),
     BaseData AS (SELECT  
                    src.FocusGroup,
                    src.Entity,
                    src.[Tri Focus Code] AS TriFocusCode,
                    src.[IFRS17 Tri Focus Code] AS IFRS17TriFocusCode,
                    src.Programme,
                    src.RI_Flag,
                    src.YOA,
                    src.YOI,
                    src.QOI_End_Date,
                    src.CCY,
                    src.[Incepted Status] AS InceptedStatus,
                    src.Statement,
                    src.Balance,
                    src.Position,
                    src.UOA,
                    CAST(NULL as varchar) AS CSM_LC
            FROM Reporting.LRC_Post_BBNIAdjustments src
           WHERE @statement = 'LRC'
             AND src.Statement = 'LRC'
             AND src.Balance <> 'CSM_LC'
             AND src.Statement = @statement
             AND RunID in (@runID1, @runID2, @runID3, @runID4)
             AND (src.Position NOT LIKE '%Open%' AND src.Position NOT LIKE '%Closing%')
         GROUP BY src.FocusGroup, src.Entity, src.[Tri Focus Code], src.[IFRS17 Tri Focus Code], src.Programme, src.RI_Flag, src.YOA, src.YOI,
                  src.QOI_End_Date, src.CCY, src.[Incepted Status], src.Statement, src.Balance, src.Position, src.UOA
         HAVING ROUND(SUM(src.Amount), 2) + ROUND(SUM(src.Amount_disc), 2) <> 0
          UNION ALL
          SELECT    src.FocusGroup,
                    src.Entity,
                    src.[Tri Focus Code] AS TriFocusCode,
                    src.[IFRS17 Tri Focus Code] AS IFRS17TriFocusCode,
                    src.Programme,
                    src.RI_Flag,
                    src.YOA,
                    src.YOI,
                    src.QOI_End_Date,
                    src.CCY,
                    src.[Incepted Status] AS InceptedStatus,
                    src.Statement,
                    src.Balance,
                    src.Position,
                    src.UOA,
                    CASE WHEN src.CSM_LC = 'LC' THEN 'LC' ELSE 'CSM' END CSM_LC
            FROM Reporting.CSM_Post_LCAdjustments src
           WHERE @statement = 'CSM'
             AND src.Statement = 'CSM'
             AND( src.Balance <> 'CSM_LC' OR (src.ri_flag = 'O' AND src.Balance = 'CSM_LC' AND src.Position LIKE '%LC_Adj'))
             AND src.Statement = @statement
             AND RunID in (@runID1, @runID2, @runID3, @runID4)
             AND (src.Position NOT LIKE '%Open%' AND src.Position NOT LIKE '%Closing%')
        GROUP BY src.FocusGroup, src.Entity, src.[Tri Focus Code], src.[IFRS17 Tri Focus Code], src.Programme, src.RI_Flag, src.YOA, src.YOI,
                  src.QOI_End_Date, src.CCY, src.[Incepted Status], src.Statement, src.Balance, src.Position, src.UOA, CSM_LC
         HAVING ROUND(SUM(src.Amount), 2) + ROUND(SUM(src.Amount_disc), 2) <> 0
          UNION ALL
          SELECT    src.FocusGroup,
                    src.Entity,
                    src.[Tri Focus Code] AS TriFocusCode,
                    src.[IFRS17 Tri Focus Code] AS IFRS17TriFocusCode,
                    src.Programme,
                    src.RI_Flag,
                    src.YOA,
                    src.YOI,
                    src.QOI_End_Date,
                    src.CCY,
                    src.[Incepted Status] AS InceptedStatus,
                    src.Statement,
                    src.Balance,
                    src.Position,
                    src.UOA,
                    CAST(NULL as varchar) AS CSM_LC
            FROM Reporting.LIC_DiscountedData src
           WHERE @statement = 'LIC'
             AND src.Statement = 'LIC'
             AND src.Balance <> 'CSM_LC'
             AND src.Statement = @statement
             AND RunID in (@runID1, @runID2, @runID3, @runID4)
             AND (src.Position NOT LIKE '%Open%' AND src.Position NOT LIKE '%Closing%')
			 AND src.Position NOT IN ('NFNChgO', 'NFNChgV')
        GROUP BY src.FocusGroup, src.Entity, src.[Tri Focus Code], src.[IFRS17 Tri Focus Code], src.Programme, src.RI_Flag, src.YOA, src.YOI,
                  src.QOI_End_Date, src.CCY, src.[Incepted Status], src.Statement, src.Balance, src.Position, src.UOA
         HAVING ROUND(SUM(src.Amount), 2) + ROUND(SUM(src.Amount_disc), 2) <> 0
    )
SELECT src.*,
        ISNULL(amrDisc.AccountCode_disc_NegativeAmount,'Missing Mapping') AS AccountCode_disc_NegativeAmount,
	    ISNULL(amrDisc.AccountCode_disc_PositiveAmount,'Missing Mapping') AS AccountCode_disc_PositiveAmount,
        ISNULL(amrUndisc.AccountCode_undisc_NegativeAmount,'Missing Mapping')AS AccountCode_undisc_NegativeAmount,
        ISNULL(amrUndisc.AccountCode_undisc_PositiveAmount,'Missing Mapping') AS AccountCode_undisc_PositiveAmount
  FROM (SELECT DISTINCT base.[Statement], 
                base.RI_Flag, 
                base.Balance, 
                base.Position, 
				base.CSM_LC,
                CONCAT(base.Statement, base.CSM_LC, base.RI_Flag, base.Balance, base.Position) AS JournalDescription,
                jttmUndisc.[Transaction Type] AS TransactionType_Undisc,
                jttmDisc.[Transaction Type] AS TransactionType_Disc
            FROM BaseData base
            LEFT JOIN Dim.JournalTransactionTypeMapping jttmDisc ON (base.Statement = jttmDisc.Statement AND base.Position = jttmDisc.Position AND jttmDisc.[Discounted(Y/N)] = 'Y')
            LEFT JOIN Dim.JournalTransactionTypeMapping jttmUndisc ON (base.Statement = jttmUndisc.Statement AND base.Position = jttmUndisc.Position AND jttmUndisc.[Discounted(Y/N)] = 'N')
        ) src
    LEFT JOIN AccMapRules amrUndisc ON (src.Statement = amrUndisc.Statement AND ISNULL(src.CSM_LC, 'blank') = ISNULL(amrUndisc.CSM_LC, 'blank') AND src.Balance = amrUndisc.Balance AND src.RI_Flag = amrUndisc.RI_Flag 
                                        AND src.Position = amrUndisc.Position AND src.TransactionType_Undisc = amrUndisc.Transactiontype_Undisc_Amount)
    LEFT JOIN AccMapRules amrDisc ON (src.Statement = amrDisc.Statement AND ISNULL(src.CSM_LC, 'blank') = ISNULL(amrDisc.CSM_LC, 'blank') AND src.Balance = amrDisc.Balance AND src.RI_Flag = amrDisc.RI_Flag 
                                      AND src.Position = amrDisc.Position AND src.TransactionType_Disc = amrDisc.Transactiontype_disc_Amount)
  OPTION (RECOMPILE)
;
GO

