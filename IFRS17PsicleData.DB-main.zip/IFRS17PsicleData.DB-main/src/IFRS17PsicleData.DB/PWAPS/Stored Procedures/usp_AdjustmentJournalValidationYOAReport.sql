﻿
CREATE   PROCEDURE [PWAPS].[usp_AdjustmentJournalValidationYOAReport] (
    @pRunIDs VARCHAR(50),     /* RunIDs */
    @pAccDate DATE           /* Accounting DATE */
)
AS

drop table if exists #journalExperienceExcl, #journalTMPExcl, #reallocExcl, #grossupExcl


SELECT 
	RunIDs
	,AccountingDate
	,CASE 
		WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) THEN 'Positive + Negative'
		ELSE AccountSign
	END AccountSign
	,YOA
	,ISNULL(SUM(pvt.CAD), 0) AS CAD
	,ISNULL(SUM(pvt.USD), 0) AS USD
	,ISNULL(SUM(pvt.GBP), 0) AS GBP
	,ISNULL(SUM(pvt.EUR), 0) AS EUR
    ,ISNULL(SUM(pvt.Other), 0) AS Other
INTO #journalExperienceExcl
FROM (
SELECT RunIDs
	,AccountingDate
	,YOA
	,CASE WHEN CCY IN ('CAD','USD','GBP','EUR') THEN CCY ELSE 'Other' END AS CCY
	,AccountSign
	,Amount
FROM [Reporting].[JournalOutputExperience]
where RunIDs = @pRunIDs
and AccountingDate = @pAccDate
and AccountCode <> '88888'
) s
PIVOT(SUM(amount) FOR CCY IN (
		CAD
		,USD
		,GBP
		,EUR
        ,Other
		)) AS pvt
GROUP BY ROLLUP(RunIDs, AccountingDate, YOA, AccountSign)
having (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0) OR (GROUPING(AccountSign) = 0 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0)
order by YOA Desc, AccountSign Asc


SELECT 
	RunIDs
	,AccountingDate
	,CASE 
		WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) THEN 'Positive + Negative'
		ELSE AccountSign
	END AccountSign
	,YOA
	,ISNULL(SUM(pvt.CAD), 0) AS CAD
	,ISNULL(SUM(pvt.USD), 0) AS USD
	,ISNULL(SUM(pvt.GBP), 0) AS GBP
	,ISNULL(SUM(pvt.EUR), 0) AS EUR
    ,ISNULL(SUM(pvt.Other), 0) AS Other
INTO #journalTMPExcl
FROM (
SELECT RunIDs
	,AccountingDate
	,YOA
	,CASE WHEN CCY IN ('CAD','USD','GBP','EUR') THEN CCY ELSE 'Other' END AS CCY
	,AccountSign
	,Amount
FROM [Reporting].[JournalOutputAdjustment]
where RunIDs = @pRunIDs
and AccountingDate = @pAccDate
and AccountCode <> '88888'
) s
PIVOT(SUM(amount) FOR CCY IN (
		CAD
		,USD
		,GBP
		,EUR
        ,Other
		)) AS pvt
GROUP BY ROLLUP(RunIDs, AccountingDate, YOA, AccountSign)
having (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0) OR (GROUPING(AccountSign) = 0 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0)
order by YOA Desc, AccountSign Asc



SELECT RunIDs
	,AccountingDate
	,CASE 
		WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) THEN 'Positive + Negative'
		ELSE AccountSign
	END AccountSign
	,YOA
	,ISNULL(SUM(pvt.CAD), 0) AS CAD
	,ISNULL(SUM(pvt.USD), 0) AS USD
	,ISNULL(SUM(pvt.GBP), 0) AS GBP
	,ISNULL(SUM(pvt.EUR), 0) AS EUR
    ,ISNULL(SUM(pvt.Other), 0) AS Other
INTO #reallocExcl
FROM (
	SELECT RunIDs
		,AccountingDate
		,YOA
		,CASE WHEN CCY IN ('CAD','USD','GBP','EUR') THEN CCY ELSE 'Other' END AS CCY
		,AccountSign
		,Amount
	FROM [Reporting].[ReAllocationJournalOutput]
	where RunIDs = @pRunIDs
	and AccountingDate = @pAccDate
	and AccountCode <> '88888'
) s
PIVOT(SUM(amount) FOR CCY IN (
			CAD
			,USD
			,GBP
			,EUR
            ,Other
			)) AS pvt
GROUP BY ROLLUP(RunIDs, AccountingDate, YOA, AccountSign)
having (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0) OR (GROUPING(AccountSign) = 0 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0)
order by YOA Desc, AccountSign Asc
-----------------GrossUP Calculation-----------------
SELECT 
	RunIDs
	,AccountingDate
	,CASE 
		WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) THEN 'Positive + Negative'
		ELSE AccountSign
	END AccountSign
	,YOA
	,ISNULL(SUM(pvt.CAD), 0) AS CAD
	,ISNULL(SUM(pvt.USD), 0) AS USD
	,ISNULL(SUM(pvt.GBP), 0) AS GBP
	,ISNULL(SUM(pvt.EUR), 0) AS EUR
    ,ISNULL(SUM(pvt.Other), 0) AS Other
INTO #grossupExcl
FROM (
SELECT RunIDs
	,AccountingDate
	,YOA
	,CASE WHEN CCY IN ('CAD','USD','GBP','EUR') THEN CCY ELSE 'Other' END AS CCY
	,AccountSign
	,Amount
FROM [Reporting].[JournalOutputGrossUP]
where RunIDs = @pRunIDs
and AccountingDate = @pAccDate
and AccountCode <> '88888'
) s
PIVOT(SUM(amount) FOR CCY IN (
		CAD
		,USD
		,GBP
		,EUR
        ,Other
		)) AS pvt
GROUP BY ROLLUP(RunIDs, AccountingDate, YOA, AccountSign)
having (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0) OR (GROUPING(AccountSign) = 0 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0)
order by YOA Desc, AccountSign Asc

--------------------

SELECT 
	sub.*
	, CASE
		WHEN AccountSign = 'Positive + Negative' THEN
			CASE
				WHEN CAD + USD + GBP + EUR + Other <> 0.00
				THEN 'Fail'
				ELSE 'Pass'
			END 
	 END Status
FROM (
	SELECT
		RunIDs,
		AccountingDate,
		AccountSign,
		YOA,
		SUM(CAD) AS CAD,
		SUM(USD) AS USD,
		SUM(GBP) AS GBP,
		SUM(EUR) AS EUR,
		SUM(Other) AS Other
	FROM (
		SELECT *
		FROM #journalTMPExcl journal
		UNION ALL
		SELECT * FROM #reallocExcl realloc
		UNION ALL
		SELECT * FROM #journalExperienceExcl experexcl
		UNION ALL
		SELECT * FROM #grossupExcl grossupexcl
	)sub
	GROUP BY RunIDs, AccountingDate, YOA, AccountSign
) sub
order by YOA Desc, AccountSign Asc

drop table if exists #journalExperienceExcl, #journalTMPExcl, #reallocExcl, #grossupExcl