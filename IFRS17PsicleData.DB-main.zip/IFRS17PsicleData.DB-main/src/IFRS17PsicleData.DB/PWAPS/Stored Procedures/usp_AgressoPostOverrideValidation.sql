﻿


CREATE PROCEDURE [PWAPS].[usp_AgressoPostOverrideValidation](

@pRunIDs VARCHAR(50),@pAccDate DATE)
AS
BEGIN
SELECT
CASE 
	WHEN EXISTS(SELECT 1 FROM PWAPS.vw_JournalOutputFinal where RunIDs = @pRunIDs and AccountingDate = @pAccDate AND dim_7='Unknown') THEN 0 
	WHEN EXISTS(SELECT 1 FROM PWAPS.vw_JournalOutputFinal where RunIDs = @pRunIDs and AccountingDate = @pAccDate AND client='No Entity') THEN 0 
	ELSE 1 
END isValid
END