﻿


CREATE       procedure [PWAPS].[usp_AdjstJournalReAllocationValidationReport] (
    @pRunIDs VARCHAR(50),     /* RunIDs */
    @pAccDate DATE           /* Accounting DATE */
)
AS


drop table if exists #journalExperience, #journalExperienceExcl, #journalTMP, #journalTMPExcl, #realloc, #reallocExcl, #JournalReAllocExperExcl,#GrossUp,#GrossUPExcl


SELECT 
	RunIDs
	,AccountingDate
	,CASE 
		WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) THEN 'Positive + Negative'
		ELSE AccountSign
	END AccountSign
	,ISNULL(SUM(pvt.CAD), 0) AS CAD
	,ISNULL(SUM(pvt.USD), 0) AS USD
	,ISNULL(SUM(pvt.GBP), 0) AS GBP
	,ISNULL(SUM(pvt.EUR), 0) AS EUR
    ,ISNULL(SUM(pvt.Other), 0) AS Other
	,CASE 
		WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) THEN
		CASE 
			WHEN ISNULL(SUM(pvt.CAD), 0) + ISNULL(SUM(pvt.USD), 0) + ISNULL(SUM(pvt.GBP), 0) + ISNULL(SUM(pvt.EUR), 0) + ISNULL(SUM(pvt.Other), 0) <> 0
				THEN 'Fail'
			ELSE 'Pass'
		END 
	END Status
	, 'ExperienceJournal' AS CalcType
INTO #journalExperience
FROM (
SELECT RunIDs
	,AccountingDate
	,CASE WHEN CCY IN ('CAD','USD','GBP','EUR') THEN CCY ELSE 'Other' END AS CCY
	,AccountSign
	,Amount
FROM [Reporting].[JournalOutputExperience]
where RunIDs = @pRunIDs
and AccountingDate = @pAccDate
) s
PIVOT(SUM(amount) FOR CCY IN (
		CAD
		,USD
		,GBP
		,EUR
        ,Other
		)) AS pvt
group by ROLLUP(RunIDs, AccountingDate, AccountSign)
having (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0 ) OR (GROUPING(AccountSign) = 0 AND GROUPING(AccountingDate) = 0);


SELECT 
	RunIDs
	,AccountingDate
	,CASE 
		WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) THEN 'Positive + Negative'
		ELSE AccountSign
	END AccountSign
	,ISNULL(SUM(pvt.CAD), 0) AS CAD
	,ISNULL(SUM(pvt.USD), 0) AS USD
	,ISNULL(SUM(pvt.GBP), 0) AS GBP
	,ISNULL(SUM(pvt.EUR), 0) AS EUR
    ,ISNULL(SUM(pvt.Other), 0) AS Other
	,CASE 
		WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) THEN
		CASE 
			WHEN ISNULL(SUM(pvt.CAD), 0) + ISNULL(SUM(pvt.USD), 0) + ISNULL(SUM(pvt.GBP), 0) + ISNULL(SUM(pvt.EUR), 0) + ISNULL(SUM(pvt.Other), 0) <> 0
				THEN 'Fail'
			ELSE 'Pass'
		END 
	END Status
	, 'ExperienceJournal' AS CalcType
INTO #journalExperienceExcl
FROM (
SELECT RunIDs
	,AccountingDate
	,CASE WHEN CCY IN ('CAD','USD','GBP','EUR') THEN CCY ELSE 'Other' END AS CCY
	,AccountSign
	,Amount
FROM [Reporting].[JournalOutputExperience]
where RunIDs = @pRunIDs
and AccountingDate = @pAccDate
and AccountCode <> '88888'
) s
PIVOT(SUM(amount) FOR CCY IN (
		CAD
		,USD
		,GBP
		,EUR
        ,Other
		)) AS pvt
group by ROLLUP(RunIDs, AccountingDate, AccountSign)
having (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0 ) OR (GROUPING(AccountSign) = 0 AND GROUPING(AccountingDate) = 0);


SELECT 
	RunIDs
	,AccountingDate
	,CASE 
		WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) THEN 'Positive + Negative'
		ELSE AccountSign
	END AccountSign
	,ISNULL(SUM(pvt.CAD), 0) AS CAD
	,ISNULL(SUM(pvt.USD), 0) AS USD
	,ISNULL(SUM(pvt.GBP), 0) AS GBP
	,ISNULL(SUM(pvt.EUR), 0) AS EUR
    ,ISNULL(SUM(pvt.Other), 0) AS Other
	,CASE 
		WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) THEN
		CASE 
			WHEN ISNULL(SUM(pvt.CAD), 0) + ISNULL(SUM(pvt.USD), 0) + ISNULL(SUM(pvt.GBP), 0) + ISNULL(SUM(pvt.EUR), 0) + ISNULL(SUM(pvt.Other), 0) <> 0
				THEN 'Fail'
			ELSE 'Pass'
		END 
	END Status
	, 'Journal' AS CalcType
INTO #journalTMP
FROM (
SELECT RunIDs
	,AccountingDate
	,CASE WHEN CCY IN ('CAD','USD','GBP','EUR') THEN CCY ELSE 'Other' END AS CCY
	,AccountSign
	,Amount
FROM [Reporting].[JournalOutputAdjustment]
where RunIDs = @pRunIDs
and AccountingDate = @pAccDate
) s
PIVOT(SUM(amount) FOR CCY IN (
		CAD
		,USD
		,GBP
		,EUR
        ,Other
		)) AS pvt
group by ROLLUP(RunIDs, AccountingDate, AccountSign)
having (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) OR (GROUPING(AccountSign) = 0 AND GROUPING(AccountingDate) = 0);

SELECT 
	RunIDs
	,AccountingDate
	,CASE 
		WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) THEN 'Positive + Negative'
		ELSE AccountSign
	END AccountSign
	,ISNULL(SUM(pvt.CAD), 0) AS CAD
	,ISNULL(SUM(pvt.USD), 0) AS USD
	,ISNULL(SUM(pvt.GBP), 0) AS GBP
	,ISNULL(SUM(pvt.EUR), 0) AS EUR
    ,ISNULL(SUM(pvt.Other), 0) AS Other
	,CASE 
		WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) THEN
		CASE 
			WHEN ISNULL(SUM(pvt.CAD), 0) + ISNULL(SUM(pvt.USD), 0) + ISNULL(SUM(pvt.GBP), 0) + ISNULL(SUM(pvt.EUR), 0) + ISNULL(SUM(pvt.Other), 0) <> 0
				THEN 'Fail'
			ELSE 'Pass'
		END 
	END Status
	, 'Journal' AS CalcType
INTO #journalTMPExcl
FROM (
SELECT RunIDs
	,AccountingDate
	,CASE WHEN CCY IN ('CAD','USD','GBP','EUR') THEN CCY ELSE 'Other' END AS CCY
	,AccountSign
	,Amount
FROM [Reporting].[JournalOutputAdjustment]
where RunIDs = @pRunIDs
and AccountingDate = @pAccDate
and AccountCode <> '88888'
) s
PIVOT(SUM(amount) FOR CCY IN (
		CAD
		,USD
		,GBP
		,EUR
        ,Other
		)) AS pvt
group by ROLLUP(RunIDs, AccountingDate, AccountSign)
having (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) OR (GROUPING(AccountSign) = 0 AND GROUPING(AccountingDate) = 0);


SELECT RunIDs
		,AccountingDate
		,CASE 
			WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) THEN 'Positive + Negative'
			ELSE AccountSign
		END AccountSign
		,ISNULL(SUM(pvt.CAD), 0) AS CAD
		,ISNULL(SUM(pvt.USD), 0) AS USD
		,ISNULL(SUM(pvt.GBP), 0) AS GBP
		,ISNULL(SUM(pvt.EUR), 0) AS EUR
        ,ISNULL(SUM(pvt.Other), 0) AS Other
	INTO #realloc
	FROM (
		SELECT RunIDs
			,AccountingDate
			,CASE WHEN CCY IN ('CAD','USD','GBP','EUR') THEN CCY ELSE 'Other' END AS CCY
			,AccountSign
			,Amount
		FROM [Reporting].[ReAllocationJournalOutput]
		where RunIDs = @pRunIDs
		and AccountingDate = @pAccDate
	) s
	PIVOT(SUM(amount) FOR CCY IN (
				CAD
				,USD
				,GBP
				,EUR
                ,Other
				)) AS pvt
	group by ROLLUP(RunIDs, AccountingDate, AccountSign)
	having (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) OR (GROUPING(AccountSign) = 0 AND GROUPING(AccountingDate) = 0);


	SELECT RunIDs
		,AccountingDate
		,CASE 
			WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) THEN 'Positive + Negative'
			ELSE AccountSign
		END AccountSign
		,ISNULL(SUM(pvt.CAD), 0) AS CAD
		,ISNULL(SUM(pvt.USD), 0) AS USD
		,ISNULL(SUM(pvt.GBP), 0) AS GBP
		,ISNULL(SUM(pvt.EUR), 0) AS EUR
        ,ISNULL(SUM(pvt.Other), 0) AS Other
	INTO #reallocExcl
	FROM (
		SELECT RunIDs
			,AccountingDate
			,CASE WHEN CCY IN ('CAD','USD','GBP','EUR') THEN CCY ELSE 'Other' END AS CCY
			,AccountSign
			,Amount
		FROM [Reporting].[ReAllocationJournalOutput]
		where RunIDs = @pRunIDs
		and AccountingDate = @pAccDate
		and AccountCode <> '88888'
	) s
	PIVOT(SUM(amount) FOR CCY IN (
				CAD
				,USD
				,GBP
				,EUR
                ,Other
				)) AS pvt
	group by ROLLUP(RunIDs, AccountingDate, AccountSign)
	having (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) OR (GROUPING(AccountSign) = 0 AND GROUPING(AccountingDate) = 0);

	SELECT RunIDs,AccountingDate
		,CASE 
			WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) THEN 'Positive + Negative'
			ELSE AccountSign
		END AccountSign
		,ISNULL(SUM(pvt.CAD), 0) AS CAD
		,ISNULL(SUM(pvt.USD), 0) AS USD
		,ISNULL(SUM(pvt.GBP), 0) AS GBP
		,ISNULL(SUM(pvt.EUR), 0) AS EUR
        ,ISNULL(SUM(pvt.Other), 0) AS Other
	INTO #GrossUPExcl
	FROM (
		SELECT RunIDs
			,AccountingDate
			,CASE WHEN CCY IN ('CAD','USD','GBP','EUR') THEN CCY ELSE 'Other' END AS CCY
			,AccountSign
			,Amount
		FROM [Reporting].[JournalOutputGrossUp]
		where RunIDs = @pRunIDs
		and AccountingDate = @pAccDate
		and AccountCode <> '88888'
	) s
	PIVOT(SUM(amount) FOR CCY IN (
				CAD
				,USD
				,GBP
				,EUR
                ,Other
				)) AS pvt
	group by ROLLUP(RunIDs, AccountingDate, AccountSign)
	having (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) OR (GROUPING(AccountSign) = 0 AND GROUPING(AccountingDate) = 0);

	SELECT RunIDs
		,AccountingDate
		,CASE 
			WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) THEN 'Positive + Negative'
			ELSE AccountSign
		END AccountSign
		,ISNULL(SUM(pvt.CAD), 0) AS CAD
		,ISNULL(SUM(pvt.USD), 0) AS USD
		,ISNULL(SUM(pvt.GBP), 0) AS GBP
		,ISNULL(SUM(pvt.EUR), 0) AS EUR
        ,ISNULL(SUM(pvt.Other), 0) AS Other
	INTO #GrossUp
	FROM (
		SELECT RunIDs
			,AccountingDate
			,CASE WHEN CCY IN ('CAD','USD','GBP','EUR') THEN CCY ELSE 'Other' END AS CCY
			,AccountSign
			,Amount
		FROM [Reporting].[JournalOutputGrossUp]
		where RunIDs = @pRunIDs
		and AccountingDate = @pAccDate
	) K
	PIVOT(SUM(amount) FOR CCY IN (
				CAD
				,USD
				,GBP
				,EUR
                ,Other
				)) AS pvt
	group by ROLLUP(RunIDs, AccountingDate, AccountSign)
	having (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) OR (GROUPING(AccountSign) = 0 AND GROUPING(AccountingDate) = 0);




SELECT
	COALESCE(journal.RunIDs, realloc.RunIDs, experexcl.RunIDs,GrossUPExcl.RunIDs) AS RunIDs
	,COALESCE(journal.AccountingDate, realloc.AccountingDate, experexcl.AccountingDate,GrossUPExcl.AccountingDate) AS AccountingDate
	,COALESCE(journal.AccountSign, realloc.AccountSign, experexcl.AccountSign,GrossUPExcl.Accountsign) AS AccountSign
	,ISNULL(journal.CAD, 0) + ISNULL(realloc.CAD, 0) + ISNULL(experexcl.CAD, 0) + ISNULL(GrossUPExcl.CAD,0) as CAD
	,ISNULL(journal.USD, 0) + ISNULL(realloc.USD, 0) + ISNULL(experexcl.USD, 0)+ ISNULL(GrossUPExcl.USD,0) as USD
	,ISNULL(journal.GBP, 0) + ISNULL(realloc.GBP, 0) + ISNULL(experexcl.GBP, 0) + ISNULL(GrossUPExcl.GBP,0) as GBP
	,ISNULL(journal.EUR, 0) + ISNULL(realloc.EUR, 0) + ISNULL(experexcl.EUR, 0) +ISNULL(GrossUPExcl.EUR,0) as EUR
    ,ISNULL(journal.Other, 0) + ISNULL(realloc.Other, 0) + ISNULL(experexcl.Other, 0) + ISNULL(GrossUPExcl.Other,0) as Other
	,CASE 
		WHEN COALESCE(journal.AccountSign, realloc.AccountSign, experexcl.AccountSign) = 'Positive + Negative' THEN
		CASE 
			WHEN (ISNULL(journal.CAD, 0) + ISNULL(realloc.CAD, 0) + ISNULL(journal.USD, 0) + ISNULL(realloc.USD, 0) + ISNULL(journal.GBP, 0) + ISNULL(realloc.GBP, 0) + 
			ISNULL(journal.EUR, 0) + ISNULL(realloc.EUR, 0) + ISNULL(journal.Other, 0) + ISNULL(realloc.Other, 0) + ISNULL(experexcl.CAD, 0) + ISNULL(experexcl.USD, 0) + ISNULL(experexcl.GBP, 0) + 
			ISNULL(experexcl.EUR, 0) + ISNULL(experexcl.Other, 0) + ISNULL(GrossUPExcl.CAD,0)+ISNULL(GrossUPExcl.USD,0)+ISNULL(GrossUPExcl.GBP,0)+ISNULL(GrossUPExcl.Other,0)) <> 0
			THEN 'Fail'
			ELSE 'Pass'
		END
	END Status
	, 'JournalReAllocationExperienceExcl' AS CalcType
INTO #JournalReAllocExperExcl
FROM #journalTMPExcl journal
FULL OUTER JOIN #reallocExcl realloc
	ON journal.RunIDs = realloc.RunIDs
	AND journal.AccountingDate = realloc.AccountingDate
	AND journal.AccountSign = realloc.AccountSign
FULL OUTER JOIN #journalExperienceExcl experexcl
	ON journal.RunIDs = experexcl.RunIDs
	AND journal.AccountingDate = experexcl.AccountingDate
	AND journal.AccountSign = experexcl.AccountSign
FULL OUTER JOIN #GrossUPExcl GrossUPExcl
 On journal.RunIDs = GrossUPExcl.RunIDs
	AND journal.AccountingDate = GrossUPExcl.AccountingDate
	AND journal.AccountSign = GrossUPExcl.AccountSign

SELECT
	COALESCE(journal.RunIDs, realloc.RunIDs, exper.RunIDs,GrossUp.RunIDs) AS RunIDs
	,COALESCE(journal.AccountingDate, realloc.AccountingDate, exper.AccountingDate,GrossUP.AccountingDate) AS AccountingDate
	,COALESCE(journal.AccountSign, realloc.AccountSign, exper.AccountSign) AS AccountSign
	,ISNULL(journal.CAD, 0) + ISNULL(realloc.CAD, 0) + ISNULL(exper.CAD, 0)+  ISNULL(GrossUP.CAD, 0) as CAD
	,ISNULL(journal.USD, 0) + ISNULL(realloc.USD, 0) + ISNULL(exper.USD, 0) + ISNULL(GrossUP.USD, 0) as USD
	,ISNULL(journal.GBP, 0) + ISNULL(realloc.GBP, 0) + ISNULL(exper.GBP, 0) + ISNULL(GrossUP.GBP, 0) as GBP
	,ISNULL(journal.EUR, 0) + ISNULL(realloc.EUR, 0) + ISNULL(exper.EUR, 0) + ISNULL(GrossUP.EUR, 0) as EUR
    ,ISNULL(journal.Other, 0) + ISNULL(realloc.Other, 0) + ISNULL(exper.Other, 0) + ISNULL(GrossUP.Other, 0) as Other
	,CASE 
		WHEN COALESCE(journal.AccountSign, realloc.AccountSign, exper.AccountSign) = 'Positive + Negative' THEN
		CASE 
			WHEN (ISNULL(journal.CAD, 0) + ISNULL(realloc.CAD, 0) + ISNULL(journal.USD, 0) + ISNULL(realloc.USD, 0) + ISNULL(journal.GBP, 0) + ISNULL(realloc.GBP, 0) + 
			ISNULL(journal.EUR, 0) + ISNULL(realloc.EUR, 0) + ISNULL(journal.Other, 0) + ISNULL(realloc.Other, 0) + ISNULL(exper.CAD, 0) + ISNULL(exper.USD, 0) + ISNULL(exper.GBP, 0) + 
			ISNULL(exper.EUR, 0) + ISNULL(exper.Other, 0)+  ISNULL(GrossUP.CAD, 0) + ISNULL(GrossUP.USD, 0)+ ISNULL(GrossUP.GBP, 0) +  ISNULL(GrossUP.EUR, 0) +  ISNULL(GrossUP.Other, 0) ) <> 0
			THEN 'Fail'
			ELSE 'Pass'
		END
	END Status
	, 'JournalReAllocationExperience' AS CalcType
FROM #journalTMP journal
FULL OUTER JOIN #realloc realloc
	ON journal.RunIDs = realloc.RunIDs
	AND journal.AccountingDate = realloc.AccountingDate
	AND journal.AccountSign = realloc.AccountSign
FULL OUTER JOIN #journalExperience exper
	ON journal.RunIDs = exper.RunIDs
	AND journal.AccountingDate = exper.AccountingDate
	AND journal.AccountSign = exper.AccountSign
FULL OUTER JOIN #GrossUp GrossUP
	ON journal.RunIDs = GrossUP.RunIDs
	AND journal.AccountingDate = GrossUP.AccountingDate
	AND journal.AccountSign = GrossUP.AccountSign
UNION ALL
select * from #journalTMP
UNION ALL
select * from #JournalReAllocExperExcl
ORDER BY CalcType, AccountSign


drop table if exists #journalExperience, #journalExperienceExcl, #journalTMP, #journalTMPExcl, #realloc, #reallocExcl, #JournalReAllocExperExcl