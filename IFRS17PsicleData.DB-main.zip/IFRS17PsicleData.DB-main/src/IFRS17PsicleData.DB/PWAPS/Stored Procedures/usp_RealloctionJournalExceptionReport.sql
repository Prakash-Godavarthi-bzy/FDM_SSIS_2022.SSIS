﻿
--DECLARE  @pAccDate DATE = '2020-09-30',        
-- @pRunIDs Varchar(50)	= 'Actual_4474_4476_4477_0',
-- @pUser VARCHAR(25) = 'Pooja Khandual'

CREATE PROCEDURE [PWAPS].[usp_RealloctionJournalExceptionReport]
(
 @pAccDate DATE,             /* Accounting DATE */
 @pRunIDs Varchar(50),		 /* Selected RunId*/
 @pUser VARCHAR(25)

)
AS

BEGIN
  DECLARE @Trancount INT = @@Trancount,
          @createDatetime DATETIME2(7) = GETDATE();  
  
  BEGIN TRY
    IF @Trancount = 0 BEGIN TRAN;

    IF @pAccDate IS NULL THROW 51001, 'The accounting DATE has to be set.', 1;  
    IF @pRunIDs IS NULL THROW 51001, 'Run IDs must be set.', 1;  

    print 'processing - deleting existing rows in target table'

    /* Delete ROWS for User/RunIDs that already exists in target table */
    DELETE FROM PWAPS.ReallocationExceptions
     WHERE RunIDs = @pRunIDs
       AND AccountingDate = @pAccDate;

    print 'processing - inserting rows to target table'
/*Identify the rows where accountcodes starts with 77 and 87 based on ri_flag and assetliabilitytype*/

		DROP TABLE IF EXISTS #FirstSet
		SELECT T1.* ,CASE WHEN (AssetLiabilityType = 'Asset'AND RI_Flag = 'I')
							  THEN CASE WHEN (LEFT(T1.AccountCode_Undisc_Pos, 2) = 87 OR LEFT(T1.AccountCode_Disc_Pos, 2) = 87	) THEN 'ExceptionPos'
										WHEN (LEFT(T1.AccountCode_Undisc_Neg, 2) = 87 OR LEFT(T1.AccountCode_Disc_Neg, 2) = 87	) THEN 'ExceptionNeg'
										ELSE 'NoException'
								   END 
						  WHEN (AssetLiabilityType = 'Liability'AND RI_Flag = 'O')
								THEN CASE WHEN (LEFT(T1.AccountCode_Undisc_Pos, 2) = 77 OR LEFT(T1.AccountCode_Disc_Pos, 2) = 77	) THEN 'ExceptionPos'
										  WHEN (LEFT(T1.AccountCode_Undisc_Neg, 2) = 77 OR LEFT(T1.AccountCode_Disc_Neg, 2) = 77	) THEN 'ExceptionNeg'
										  ELSE 'NoException'
									   END 
						 ELSE 	'NoException'
					 END	Chk1 
		INTO #FirstSet
		FROM Reporting.JournalInputDataYTD T1
		WHERE T1.RunIDs = @pRunIDs
		AND T1.AccountingDate = @pAccDate
		AND ((AssetLiabilityType = 'Liability'AND RI_Flag = 'O')
				OR
			(AssetLiabilityType = 'Asset'AND RI_Flag = 'I'))
		AND (T1.Position not like '%Open%' and T1.Position not like '%Closing%')  
		AND (T1.AccountCode_ReAlloc_Pos is not null 
			 and T1.AccountCode_ReAlloc_Neg is not null 
			)
		AND Balance <> 'CSM_LC'
		AND (CSM_LC is null or CSM_LC = 'CSM')


		/*Now pick only the ones which have a positive or negative exception account codes and chk if they have been reversed out in the reallocation codes*/

		DROP TABLE IF EXISTS #FinalSet
		SELECT * , CASE WHEN T1.Chk1 = 'ExceptionPos' AND T1.AccountCode_Undisc_Pos = T1.AccountCode_Disc_Pos AND T1.AccountCode_Disc_Pos <> T1.AccountCode_ReAlloc_Neg   THEN 'Exception'
						WHEN T1.Chk1 = 'ExceptionNeg' AND T1.AccountCode_Undisc_Neg = T1.AccountCode_Disc_Neg AND T1.AccountCode_Disc_Neg <> T1.AccountCode_ReAlloc_Pos   THEN 'Exception'
						ELSE 'NoException'
				   END Chk2 
		INTO #FinalSet
		FROM #FirstSet T1
		WHERE Chk1 <> 'NoException'


		/*List out the final exception rows on higher granularity*/
		INSERT INTO PWAPS.ReallocationExceptions (RunIDs, AccountingDate,[Statement], RI_Flag, Balance, AccountCode_Undisc_Pos, AccountCode_Undisc_Neg, AccountCode_Disc_Pos, AccountCode_Disc_Neg, AccountCode_ReAlloc_Pos, AccountCode_ReAlloc_Neg)
		SELECT DISTINCT RunIDs, CAST(AccountingDate AS varchar(10)) AccountingDate,[Statement], RI_Flag, Balance, AccountCode_Undisc_Pos, AccountCode_Undisc_Neg, AccountCode_Disc_Pos, AccountCode_Disc_Neg, AccountCode_ReAlloc_Pos, AccountCode_ReAlloc_Neg
		FROM #FinalSet
		WHERE Chk2 = 'Exception';

    IF @Trancount = 0 COMMIT;
    END TRY
    BEGIN CATCH
        IF @Trancount = 0 ROLLBACK;
        THROW;
    END CATCH

END;