﻿

CREATE PROCEDURE PWAPS.usp_ICE_FinalStatusCheck (@RUNID INT )
AS
BEGIN
DECLARE  @Counter INT ,
        @MaxCounter INT, 
        @SqlString NVARCHAR(MAX),
        @tables VARCHAR(MAX),
        @cnt INT,
        @failuretables VARCHAR(MAX)

 

DROP TABLE IF EXISTS #RunCode
    CREATE TABLE #RunCode
    (
    Id INT IDENTITY(1,1)
    ,SelectCode Varchar(255)
    )

 

DROP TABLE IF EXISTS #OutputData
    CREATE TABLE #OutputData
    (
    RunID INT,
    SchemaName varchar(50),
    TableName VARCHAR(255),
    TotalRows INT
    )

 

INSERT INTO #RunCode(SelectCode)
SELECT DISTINCT 'SELECT RunID AS RunID, '+''''+TABLE_SCHEMA+'''' + ' AS SchemaName, ' +''''+TABLE_NAME+'''' + ' AS TableName, COUNT(*) AS Total_Rows FROM ' + CONCAT(TABLE_SCHEMA,'.', TABLE_NAME)  +' WHERE RunID = '+ CAST(@RUNID AS VARCHAR(50))  +' GROUP BY RunID' as code
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA IN ('INBOUND','RESULTS', 'REPORTING') 
AND TABLE_NAME NOT IN ('stg_Agresso_uviattrvalues','stg_PaymentPatternOB','Agresso_uviattrvalues','PaymentPatternOB','stg_IFRS17_MasterTable','IFRS17_MasterTable','Reserving_data')
AND TABLE_NAME NOT LIKE '%Journal%'

 

 

SELECT @counter = MIN(Id), @MaxCounter = MAX(Id) FROM #RunCode

 


WHILE (@counter <= @MaxCounter)
    BEGIN
        SET @sqlstring = (SELECT  SelectCode  FROM #RunCode WHERE Id =   @counter)

 

        INSERT INTO #OutputData(RunID, SchemaName,TableName, TotalRows)
        EXEC sp_executesql @sqlstring

 

        SET @counter = @counter + 1
    END
DROP TABLE IF EXISTS #Results
    CREATE TABLE #Results
    (
    RunID INT,
    InboundTableName varchar(255),
    InboundTotalRows INT,
    FinalTable  varchar(255),
    FinalTotalRows INT,
    ICESuccessCheck varchar(10)
    )


 

    INSERT INTO #Results
    SELECT RunID, InboundTableName, InboundTotalRows, FinalTable ,FinalTotalRows, CASE WHEN InboundTotalRows = FinalTotalRows THEN 'PASS' ELSE 'FAIL' END ICESuccessCheck
    FROM
    (
    SELECT A.RunID, A.TableName as InboundTableName, A.TotalRows  InboundTotalRows, B.FinalTable, B.FinalTotalRows  
    FROM #OutputData A
    LEFT JOIN 
            (SELECT RunID,TableName AS FinalTable ,CONCAT('STG_',TableName) AS MatchInboundName, TotalRows FinalTotalRows  
             FROM #OutputData WHERE SchemaName <> 'INBOUND') B ON a.TableName = b.MatchInboundName
    WHERE SchemaName = 'INBOUND'
    )C

 


IF EXISTS(SELECT DISTINCT 1  FROM #Results WHERE ICESuccessCheck='FAIL')
	BEGIN
   		SELECT  @failuretables=  COALESCE(@failuretables+',','')+substring(InboundTableName,5,len(InboundTableName) )  FROM #Results WHERE ICESuccessCheck='FAIL'
   		UPDATE [$(IFRS17DataMart)].PWAPS.IFRS17CalcUI_RunLog
            SET ICEStatus='Merge Failed',
                [Not_Populated_Tables(ICE)]= CONCAT((CASE WHEN [Not_Populated_Tables(ICE)] IS NULL THEN '' ELSE CONCAT([Not_Populated_Tables(ICE)],' - ') END),@failuretables)
				
            WHERE Pk_RequestId=@RUNID
	END
ELSE
	BEGIN
		BEGIN
            UPDATE [$(IFRS17DataMart)].PWAPS.IFRS17CalcUI_RunLog
            SET ICEStatus='Success',
                [Not_Populated_Tables(ICE)]= CASE WHEN InboundStatus='Success' THEN 'All Tables Populated' ELSE [Not_Populated_Tables(ICE)] END
            WHERE Pk_RequestId=@RUNID
		END
		BEGIN
			INSERT INTO [$(IFRS17DataMart)].rpt.CanonicalBR2RunDetails(RunID, ReportingPeriod, UserName, RunStatus,[ICE Available], CanonicalStatus )
			SELECT Pk_RequestId, [Reporting Period], [User Name], ICEStatus,'Y','N' 
			FROM [$(IFRS17DataMart)].PWAPS.IFRS17CalcUI_RunLog T1
			LEFT JOIN  [$(IFRS17DataMart)].rpt.CanonicalBR2RunDetails T2 ON T1.Pk_RequestId = T2.RunID
			WHERE Pk_RequestId = @RUNID 
			AND T2.RunID IS NULL

		END


    END
    
END