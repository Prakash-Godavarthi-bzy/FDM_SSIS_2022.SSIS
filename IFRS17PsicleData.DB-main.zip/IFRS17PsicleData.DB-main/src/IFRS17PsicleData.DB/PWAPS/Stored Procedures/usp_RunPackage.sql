﻿CREATE   PROCEDURE [PWAPS].[usp_RunPackage](
	@pJobName VARCHAR (150),
	@pUser VARCHAR(25),        /* User requesting this action (for audit) */
	@RunIDs VARCHAR(50) = NULL,
	@AccountingDate VARCHAR(10) = NULL,
	@version INT = NULL
)
AS
BEGIN
	DECLARE @createDatetime DATETIME2(7) = GETDATE();

	BEGIN TRY
		IF @pUser is NULL set @pUser = 'Unknown'

		MERGE INTO [PWAPS].[RunScheduleJob] AS tgt
		USING (VALUES (@pJobName, 0, @RunIDs, @AccountingDate, @version, @pUser, @createDatetime)
		) AS src (NewJobName, NewRunStatusFlag, NewRunIDs, NewAccountingDate, NewVersion, NewAuditUser, NewAuditCreateDatetime)
		ON tgt.JobName = @pJobName
		WHEN MATCHED THEN
		UPDATE SET RunStatusFlag = 1, RunIDs = @RunIDs, AccountingDate = @AccountingDate, version = @version, AuditUser = @pUser, AuditCreateDatetime = @createDatetime
		WHEN NOT MATCHED BY TARGET THEN
		INSERT(JobName, RunStatusFlag, RunIDs, AccountingDate, version, AuditUser, AuditCreateDatetime) VALUES(NewJobName, NewRunStatusFlag, NewRunIDs, NewAccountingDate, NewVersion, NewAuditUser, NewAuditCreateDatetime);


	END TRY
    BEGIN CATCH
        THROW
    END CATCH
END