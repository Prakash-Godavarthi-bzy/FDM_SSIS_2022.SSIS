﻿CREATE PROCEDURE PWAPS.usp_ICE_InboundStatusCheck (@RUNID INT )
AS
BEGIN
DECLARE
        @Counter INT ,
        @MaxCounter INT, 
        @SqlString NVARCHAR(MAX),
        @tables VARCHAR(MAX),
		@failuretablesIn VARCHAR(MAX)


 

DROP TABLE IF EXISTS #RunCode
    CREATE TABLE #RunCode
    (
    Id INT IDENTITY(1,1)
    ,SelectCode Varchar(255)
	,Tablenamess varchar(255)
    )

 

DROP TABLE IF EXISTS #OutputData
    CREATE TABLE #OutputData
    (
    RunID INT,
    SchemaName varchar(50),
    TableName VARCHAR(255),
    TotalRows INT
    )

 

INSERT INTO #RunCode(SelectCode,Tablenamess)
SELECT DISTINCT 'SELECT RunID AS RunID, '+''''+TABLE_SCHEMA+'''' + ' AS SchemaName, ' +''''+TABLE_NAME+'''' + ' AS TableName, COUNT(*) AS Total_Rows FROM ' + CONCAT(TABLE_SCHEMA,'.', TABLE_NAME)  +' WHERE RunID = '+ CAST(@RUNID AS VARCHAR(50))  +' GROUP BY RunID' as code,TABLE_NAME
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA IN ('INBOUND')
AND TABLE_NAME NOT IN ('stg_Agresso_uviattrvalues','stg_PaymentPatternOB','stg_IFRS17_MasterTable')

 

 

SELECT @counter = MIN(Id), @MaxCounter = MAX(Id) FROM #RunCode

 


WHILE (@counter <= @MaxCounter)
    BEGIN
        SET @sqlstring = (SELECT  SelectCode  FROM #RunCode WHERE Id =   @counter)

 

        INSERT INTO #OutputData(RunID, SchemaName,TableName, TotalRows)
        EXEC sp_executesql @sqlstring

 

        SET @counter = @counter + 1
    END



--declare 	@failuretablesIn VARCHAR(MAX)
	IF EXISTS(SELECT  Tablenamess   FROM #RunCode WHERE Tablenamess like 'stg_%' AND Tablenamess NOT IN(select tablename from #OutputData))
--	print @failuretablesIn 

	BEGIN
		SELECT  @failuretablesIn=  COALESCE(@failuretablesIn+',','')+ Tablenamess   FROM #RunCode WHERE Tablenamess like 'stg_%' AND Tablenamess NOT IN(select tablename from #OutputData)

           		UPDATE [$(IFRS17DataMart)].PWAPS.IFRS17CalcUI_RunLog
           		SET InboundStatus='Inbound table(s) have not been populated',
                [Not_Populated_Tables(ICE)]=@failuretablesIn
           		WHERE Pk_RequestId=@RUNID

     INSERT INTO [$(IFRS17DataMart)].[Control].[ActivityLog](FK_ActivityStatus,ActivityHost,ActivityDatabase,ActivityName,ActivityMessage,PK_RequestID)

  SELECT 4,@@SERVERNAME,'[$(IFRS17DataMart)]','ControlRunPowerApps','The following Inbound table(s) have not been populated by ICE, please contact IFRS17 support',@RUNID
	END
	ELSE
		BEGIN
			UPDATE [$(IFRS17DataMart)].PWAPS.IFRS17CalcUI_RunLog
           	SET InboundStatus='Success'
           	WHERE Pk_RequestId=@RUNID
		END
END