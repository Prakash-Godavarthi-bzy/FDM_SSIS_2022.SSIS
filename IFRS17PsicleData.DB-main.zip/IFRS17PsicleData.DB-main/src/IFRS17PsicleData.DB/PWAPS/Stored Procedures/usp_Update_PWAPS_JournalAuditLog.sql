﻿CREATE PROCEDURE [PWAPS].[usp_Update_PWAPS_JournalAuditLog]

	@AuditRowID		BIGINT,
	@ColumnName		VARCHAR(25),
	@UpdateValue	NVARCHAR(MAX)
	
AS
BEGIN
DECLARE @SQLQuery NVARCHAR(255)= 'UPDATE [PWAPS].[JournalAuditLog]  SET	['+@ColumnName+']='+''''+@UpdateValue+''''+	' WHERE [PK_JournalAuditLogID]='+CAST(@AuditRowID AS NVARCHAR(10))
--print @SQLQuery
EXECUTE sp_executesql @SQLQuery
END