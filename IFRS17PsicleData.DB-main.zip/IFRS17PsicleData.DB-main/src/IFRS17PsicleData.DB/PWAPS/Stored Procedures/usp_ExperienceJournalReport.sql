﻿--declare
--    @pRunIDs VARCHAR(50) = 'Actual_92_93_94_95',     /* RunIDs */
--    @pAccDate DATE      = '2021-12-31'     /* Accounting DATE */

CREATE   PROCEDURE [PWAPS].[usp_ExperienceJournalReport] (
    @pRunIDs VARCHAR(50),     /* RunIDs */
    @pAccDate DATE           /* Accounting DATE */
)
AS

 

drop table if exists #ytd

select 
    ytd.RunIDs,
    ytd.AccountingDate,
    ytd.RI_Flag,
    ytd.Balance,
    ytd.Position,
    ytd.Statement,
    ytd.CSM_LC,
    CONCAT(ytd.Statement, ytd.CSM_LC) as StatementGroup,
    ytd.JournalDescription,
    COALESCE(exprType.ExprType, 'IFIE') as ExprType,
    CASE 
     WHEN exprType.exprType is null  and ytd.Position in ('NFNChgO','NFNChgV') And ytd.Balance in ('Pr','Br','OAE') THEN ytd.Disc
	 WHEN exprType.ExprType='EXPR' And  ytd.Position in ('NFNChgO','NFNChgV') And ytd.Balance in ('Pr','Br','OAE') THEN  ytd.Amount--EXPR
	 ELSE ytd.Amount_disc
    END as Amt
into #ytd
from [Reporting].[JournalInputDataYTD] ytd
left join (
			select 'Pr' as Balance, 'NFNChgV' as Position, 'EXPR' as ExprType
			union all
			select 'Br', 'NFNChgV', 'EXPR'
			union all
			select 'OAE', 'NFNChgV', 'EXPR'
			union all
			select 'Pr', 'NFNChgO', 'EXPR'
			union all
			select 'Br', 'NFNChgO', 'EXPR'
			union all
			select 'OAE', 'NFNChgO', 'EXPR'
			union all
			select 'Pr', 'NFNChgV', NULL
			union all
			select 'Br', 'NFNChgV', NULL
			union all
			select 'OAE', 'NFNChgV', NULL
			union all
			select 'Pr', 'NFNChgO', NULL
			union all
			select 'Br', 'NFNChgO', NULL
			union all
			select 'OAE', 'NFNChgO', NULL
			) exprType on (ytd.Position = exprType.Position and ytd.Balance = exprType.Balance)
where ytd.RunIDs = @pRunIDs
and ytd.AccountingDate = @pAccDate
and ytd.Statement in ('CSM', 'LRC')
and ytd.Balance not in('CSM_LC')
and (ytd.Position not like '%Open%' and ytd.Position not like '%Closing%');

 
select
    ytd.*,
    expj.AccountCodePositiveVE,
    expj.AccountCodeNegativeVE,
    expj.ID,
	chk.IsBalanced
from (
    select
        RunIDs,
        AccountingDate,
        RI_Flag,
        Balance,
        Position,
        ExprType,
        ISNULL(SUM(pvt.CSMCSM), 0) as CSMCSM,
        ISNULL(SUM(pvt.CSMLC), 0) as CSMLC,
        ISNULL(SUM(pvt.LRC),0) as LRC,
        ISNULL(SUM(pvt.CSMCSM), 0) + ISNULL(SUM(pvt.CSMLC), 0) - ISNULL(SUM(pvt.LRC), 0) as ExperienceTriggerAmt
    from #ytd
    PIVOT(SUM(amt) FOR StatementGroup IN (
                CSMCSM,
                CSMLC,
                LRC
                )) AS pvt
    GROUP BY RunIDs, AccountingDate, RI_Flag, Balance, Position, ExprType
)ytd
left join PWAPS.ExperienceJournal expj
    on ytd.RunIDs = expj.RunIDs
    and ytd.AccountingDate = expj.AccountingDate
    and ytd.RI_Flag = expj.RI_Flag
    and ytd.Balance = expj.Balance
    and ytd.Position = expj.Position
    and ytd.ExprType = expj.ExprType
left join PWAPS.udf_GetUnBalancedJournalOutputFinal(@pRunIDs,@pAccDate) chk     on ytd.RunIDs = chk.RunIDs
   																				and ytd.AccountingDate = chk.AccountingDate
   																				and ytd.RI_Flag = chk.RI_Flag
   																				and ytd.Balance = chk.Balance
   																				and ytd.Position = chk.Position
where 
1 = 1
AND chk.IsBalanced = 'N'
order by ytd.RI_Flag, ytd.Balance, ytd.Position