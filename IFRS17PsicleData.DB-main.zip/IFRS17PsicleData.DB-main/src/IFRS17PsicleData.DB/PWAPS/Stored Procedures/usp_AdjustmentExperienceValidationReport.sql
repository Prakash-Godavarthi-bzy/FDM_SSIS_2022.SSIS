﻿/*=============================================================================
Author			: Jaswanth Reddy Yamasani
Creation Date	: 1 October 2024
Description		: This SPROC gets triggered via IFRS17 Journcal Creation 
				  application in the V05 Journal screen to validate the
				  CSM locked to Current Disc rates.
				  For further information please refer the below ticket -
				  https://beazley.atlassian.net/browse/I17-7768

==============================================================================*/
CREATE       procedure [PWAPS].[usp_AdjustmentExperienceValidationReport] (
    @pRunIDs VARCHAR(50),     /* RunIDs */
    @pAccDate DATE           /* Accounting DATE */
)
AS

BEGIN
 
drop table if exists #journalCSMExperienceDiscAdj
 
SELECT 
	RunIDs
	,AccountingDate
	,CASE 
		WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) THEN 'Positive + Negative'
		ELSE AccountSign
	END AccountSign
	,ISNULL(SUM(pvt.CAD), 0) AS CAD
	,ISNULL(SUM(pvt.USD), 0) AS USD
	,ISNULL(SUM(pvt.GBP), 0) AS GBP
	,ISNULL(SUM(pvt.EUR), 0) AS EUR
    ,ISNULL(SUM(pvt.Other), 0) AS Other
	,CASE 
		WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0) THEN
		CASE 
			WHEN ISNULL(SUM(pvt.CAD), 0) + ISNULL(SUM(pvt.USD), 0) + ISNULL(SUM(pvt.GBP), 0) + ISNULL(SUM(pvt.EUR), 0) + ISNULL(SUM(pvt.Other), 0) <> 0
				THEN 'Fail'
			ELSE 'Pass'
		END 
	END Status
	, 'CSMExperienceDiscAdjJournal' AS CalcType
INTO #journalCSMExperienceDiscAdj
FROM (
SELECT RunIDs
	,AccountingDate
	,CASE WHEN CCY IN ('CAD','USD','GBP','EUR') THEN CCY ELSE 'Other' END AS CCY
	,AccountSign
	,Amount
FROM [Reporting].JournalOutputLockedCSMtoCurrent
where RunIDs = @pRunIDs
and AccountingDate = @pAccDate
) s
PIVOT(SUM(Amount) FOR CCY IN (
		CAD
		,USD
		,GBP
		,EUR
        ,Other
		)) AS pvt
group by ROLLUP(RunIDs, AccountingDate, AccountSign)
having (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0 ) OR (GROUPING(AccountSign) = 0 AND GROUPING(AccountingDate) = 0);
 
 
select * from #journalCSMExperienceDiscAdj

END