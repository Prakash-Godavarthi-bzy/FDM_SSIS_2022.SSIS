﻿CREATE     procedure [PWAPS].[usp_AgressoValidation] (
    @pRunIDs VARCHAR(50),     /* RunIDs */
    @pAccDate DATE           /* Accounting DATE */
)
AS

SELECT	CASE WHEN Flag = 1 THEN 0 ELSE 0 END isValid
FROM	(
			SELECT 1 AS Flag FROM [PWAPS].[vw_AgressoCompareACCOUNT] 
			where RunIDs = @pRunIDs and AccountingDate = @pAccDate
			UNION
			SELECT 1 AS Flag FROM [PWAPS].[vw_AgressoCompareCOSTC] 
			where RunIDs = @pRunIDs and AccountingDate = @pAccDate
			UNION
			SELECT 1 AS Flag FROM [PWAPS].[vw_AgressoCompareIFRSPROG] 
			where RunIDs = @pRunIDs and AccountingDate = @pAccDate
			UNION
			SELECT 1 AS Flag FROM [PWAPS].[vw_AgressoCompareTARGET] 
			where RunIDs = @pRunIDs and AccountingDate = @pAccDate
		)A