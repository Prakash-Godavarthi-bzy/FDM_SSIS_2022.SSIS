﻿


CREATE       procedure [PWAPS].[usp_AdjustmentJournalValidationPAccNAccDetailReport] (
    @pRunIDs VARCHAR(50),     /* RunIDs */
    @pAccDate DATE,           /* Accounting DATE */
	@DiscUndiscType VARCHAR(10),
	@YOA VARCHAR(4),
	@Statement VARCHAR(50),
	@AgressoIFRS17ClientCode VARCHAR(4)
)
AS
	

drop table if exists #journalExperienceExcl, #journalTMPExcl, #reallocExcl, #journalTMPExcl2, #grossupExcl3

IF @Statement = 'LIC'
BEGIN
	SELECT 
		RunIDs
		,AccountingDate
		,AgressoIFRS17ClientCode
		,Statement
		,YOA
		,TransactionType
		,CASE 
			WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0 AND GROUPING(TransactionType) = 0 AND GROUPING(YOA) = 0 AND GROUPING(AgressoIFRS17ClientCode) = 0 AND GROUPING(Statement) = 0) THEN 'Positive + Negative'
			ELSE AccountSign
		END AccountSign
		,ISNULL(SUM(pvt.CAD), 0) AS CAD
		,ISNULL(SUM(pvt.USD), 0) AS USD
		,ISNULL(SUM(pvt.GBP), 0) AS GBP
		,ISNULL(SUM(pvt.EUR), 0) AS EUR
		,ISNULL(SUM(pvt.Other), 0) AS Other
	INTO #journalTMPExcl
	FROM (
	SELECT RunIDs
		,AccountingDate
		,YOA
		,AgressoIFRS17ClientCode
		,Statement
		,TransactionType
		,CASE WHEN CCY IN ('CAD','USD','GBP','EUR') THEN CCY ELSE 'Other' END AS CCY
		,AccountSign
		,Amount
	FROM [Reporting].[JournalOutputAdjustment]
	where RunIDs = @pRunIDs
	and AccountingDate = @pAccDate
	AND DiscUndiscType = @DiscUndiscType
	AND YOA = @YOA
	AND Statement = @Statement
	AND ISNULL(AgressoIFRS17ClientCode, 'None') = ISNULL(@AgressoIFRS17ClientCode, 'None')
	and AccountCode <> '88888'
	) s
	PIVOT(SUM(amount) FOR CCY IN (
			CAD
			,USD
			,GBP
			,EUR
			,Other
			)) AS pvt
	GROUP BY ROLLUP(RunIDs, AccountingDate, AgressoIFRS17ClientCode, Statement, YOA, TransactionType, AccountSign)
	having (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0 AND GROUPING(TransactionType) = 0 AND GROUPING(YOA) = 0 AND GROUPING(AgressoIFRS17ClientCode) = 0 AND GROUPING(Statement) = 0) OR 
	(GROUPING(AccountSign) = 0 AND GROUPING(TransactionType) = 0 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0 AND GROUPING(YOA) = 0 AND GROUPING(AgressoIFRS17ClientCode) = 0 AND GROUPING(Statement) = 0)


	SELECT 
		sub.*
		, CASE
			WHEN AccountSign = 'Positive + Negative' THEN
				CASE
					WHEN CAD + USD + GBP + EUR + Other <> 0.00
					THEN 'Fail'
					ELSE 'Pass'
				END 
		 END Status
	FROM (
		SELECT
			RunIDs,
			AccountingDate,
			AgressoIFRS17ClientCode,
			Statement,
			YOA,
			TransactionType,
			AccountSign,
			SUM(CAD) AS CAD,
			SUM(USD) AS USD,
			SUM(GBP) AS GBP,
			SUM(EUR) AS EUR,
			SUM(Other) AS Other
		FROM #journalTMPExcl journal
		GROUP BY RunIDs, AccountingDate, AgressoIFRS17ClientCode, Statement, YOA, TransactionType, AccountSign
	) sub
	order by YOA Desc, AccountSign Asc

END;

IF @Statement = 'LRC, CSM, EXPR, IFIE, GrossUp'
BEGIN
	SELECT 
		RunIDs
		,AccountingDate
		,AgressoIFRS17ClientCode
		,'LRC, CSM, EXPR, IFIE, GrossUp' as Statement
		,YOA
		,TransactionType
		,CASE 
			WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0 AND GROUPING(TransactionType) = 0 AND GROUPING(YOA) = 0 AND GROUPING(AgressoIFRS17ClientCode) = 0) THEN 'Positive + Negative'
			ELSE AccountSign
		END AccountSign
		,ISNULL(SUM(pvt.CAD), 0) AS CAD
		,ISNULL(SUM(pvt.USD), 0) AS USD
		,ISNULL(SUM(pvt.GBP), 0) AS GBP
		,ISNULL(SUM(pvt.EUR), 0) AS EUR
		,ISNULL(SUM(pvt.Other), 0) AS Other
	INTO #journalTMPExcl2
	FROM (
		SELECT RunIDs
			,AccountingDate
			,YOA
			,AgressoIFRS17ClientCode
			--,Statement
			,TransactionType
			,CASE WHEN CCY IN ('CAD','USD','GBP','EUR') THEN CCY ELSE 'Other' END AS CCY
			,AccountSign
			,Amount
		FROM [Reporting].[JournalOutputAdjustment]
		where RunIDs = @pRunIDs
		and AccountingDate = @pAccDate
		AND DiscUndiscType = @DiscUndiscType
		AND YOA = @YOA
		AND Statement in( 'LRC', 'CSM')
		AND ISNULL(AgressoIFRS17ClientCode, 'None') = ISNULL(@AgressoIFRS17ClientCode, 'None')
		and AccountCode <> '88888'
	) s
	PIVOT(SUM(amount) FOR CCY IN (
			CAD
			,USD
			,GBP
			,EUR
			,Other
			)) AS pvt
	GROUP BY ROLLUP(RunIDs, AccountingDate, AgressoIFRS17ClientCode, YOA, TransactionType, AccountSign)
	having (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0 AND GROUPING(TransactionType) = 0 AND GROUPING(YOA) = 0 AND GROUPING(AgressoIFRS17ClientCode) = 0) OR 
	(GROUPING(AccountSign) = 0 AND GROUPING(TransactionType) = 0 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0 AND GROUPING(YOA) = 0 AND GROUPING(AgressoIFRS17ClientCode) = 0 )

	SELECT 
		RunIDs
		,AccountingDate
		,AgressoIFRS17ClientCode
		,'LRC, CSM, EXPR, IFIE, GrossUp' as Statement
		,YOA
		,TransactionType
		,CASE 
			WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0 AND GROUPING(TransactionType) = 0 AND GROUPING(YOA) = 0 AND GROUPING(AgressoIFRS17ClientCode) = 0 ) THEN 'Positive + Negative'
			ELSE AccountSign
		END AccountSign
		,ISNULL(SUM(pvt.CAD), 0) AS CAD
		,ISNULL(SUM(pvt.USD), 0) AS USD
		,ISNULL(SUM(pvt.GBP), 0) AS GBP
		,ISNULL(SUM(pvt.EUR), 0) AS EUR
		,ISNULL(SUM(pvt.Other), 0) AS Other
	INTO #journalExperienceExcl
	FROM (
		SELECT RunIDs
			,AccountingDate
			,YOA
			,AgressoIFRS17ClientCode
			--,Statement
			,TransactionType
			,CASE WHEN CCY IN ('CAD','USD','GBP','EUR') THEN CCY ELSE 'Other' END AS CCY
			,AccountSign
			,Amount
		FROM [Reporting].[JournalOutputExperience]
		where RunIDs = @pRunIDs
		and AccountingDate = @pAccDate
		AND DiscUndiscType = @DiscUndiscType
		AND YOA = @YOA
		AND Statement in('EXPR', 'IFIE')
		AND ISNULL(AgressoIFRS17ClientCode, 'None') = ISNULL(@AgressoIFRS17ClientCode, 'None')
		and AccountCode <> '88888'
	) s
	PIVOT(SUM(amount) FOR CCY IN (
			CAD
			,USD
			,GBP
			,EUR
			,Other
			)) AS pvt
	GROUP BY ROLLUP(RunIDs, AccountingDate, AgressoIFRS17ClientCode, YOA, TransactionType, AccountSign)
	having (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0 AND GROUPING(TransactionType) = 0 AND GROUPING(YOA) = 0 AND GROUPING(AgressoIFRS17ClientCode) = 0 ) OR 
	(GROUPING(AccountSign) = 0 AND GROUPING(TransactionType) = 0 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0 AND GROUPING(YOA) = 0 AND GROUPING(AgressoIFRS17ClientCode) = 0 )

---------------------
SELECT 
		RunIDs
		,AccountingDate
		,AgressoIFRS17ClientCode
		,'LRC, CSM, EXPR, IFIE, GrossUp' as Statement
		,YOA
		,TransactionType
		,CASE 
			WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0 AND GROUPING(TransactionType) = 0 AND GROUPING(YOA) = 0 AND GROUPING(AgressoIFRS17ClientCode) = 0 ) THEN 'Positive + Negative'
			ELSE AccountSign
		END AccountSign
		,ISNULL(SUM(pvt.CAD), 0) AS CAD
		,ISNULL(SUM(pvt.USD), 0) AS USD
		,ISNULL(SUM(pvt.GBP), 0) AS GBP
		,ISNULL(SUM(pvt.EUR), 0) AS EUR
		,ISNULL(SUM(pvt.Other), 0) AS Other
	INTO #grossupExcl3
	FROM (
		SELECT RunIDs
			,AccountingDate
			,YOA
			,AgressoIFRS17ClientCode
			--,Statement
			,TransactionType
			,CASE WHEN CCY IN ('CAD','USD','GBP','EUR') THEN CCY ELSE 'Other' END AS CCY
			,AccountSign
			,Amount
		FROM [Reporting].[JournalOutputGrossUp]
		where RunIDs = @pRunIDs
		and AccountingDate = @pAccDate
		AND DiscUndiscType = @DiscUndiscType
		AND   Statement ='CSM'
		AND YOA = @YOA
		----AND   Statement ='CSM'
		AND ISNULL(AgressoIFRS17ClientCode, 'None') = ISNULL(@AgressoIFRS17ClientCode, 'None')
		and AccountCode <> '88888'
	) s
	PIVOT(SUM(amount) FOR CCY IN (
			CAD
			,USD
			,GBP
			,EUR
			,Other
			)) AS pvt
	GROUP BY ROLLUP(RunIDs, AccountingDate, AgressoIFRS17ClientCode, YOA, TransactionType, AccountSign)
	having (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0 AND GROUPING(TransactionType) = 0 AND GROUPING(YOA) = 0 AND GROUPING(AgressoIFRS17ClientCode) = 0 ) OR 
	(GROUPING(AccountSign) = 0 AND GROUPING(TransactionType) = 0 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0 AND GROUPING(YOA) = 0 AND GROUPING(AgressoIFRS17ClientCode) = 0 )
-----------


	SELECT
		sub.*
		, CASE
			WHEN AccountSign = 'Positive + Negative' THEN
				CASE
					WHEN CAD + USD + GBP + EUR + Other <> 0.00
					THEN 'Fail'
					ELSE 'Pass'
				END 
		 END Status
	FROM (
		SELECT
			RunIDs,
			AccountingDate,
			AgressoIFRS17ClientCode,
			Statement,
			YOA,
			TransactionType,
			AccountSign,
			SUM(CAD) AS CAD,
			SUM(USD) AS USD,
			SUM(GBP) AS GBP,
			SUM(EUR) AS EUR,
			SUM(Other) AS Other
		FROM (
			SELECT * FROM #journalTMPExcl2 journal
			UNION ALL
			SELECT * FROM #journalExperienceExcl experexcl
			UNION ALL
			SELECT * FROM #grossupExcl3 grossup
		)sub
		GROUP BY RunIDs, AccountingDate, AgressoIFRS17ClientCode, Statement, YOA, TransactionType, AccountSign
	) sub
	order by YOA Desc, AccountSign Asc


END;

IF @Statement = 'Realloc'
BEGIN
	SELECT RunIDs
		,AccountingDate
		,AgressoIFRS17ClientCode
		,Statement
		,YOA
		,TransactionType
		,CASE 
			WHEN (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0 AND GROUPING(TransactionType) = 0 AND GROUPING(YOA) = 0 AND GROUPING(AgressoIFRS17ClientCode) = 0 AND GROUPING(Statement) = 0) THEN 'Positive + Negative'
			ELSE AccountSign
		END AccountSign
		,ISNULL(SUM(pvt.CAD), 0) AS CAD
		,ISNULL(SUM(pvt.USD), 0) AS USD
		,ISNULL(SUM(pvt.GBP), 0) AS GBP
		,ISNULL(SUM(pvt.EUR), 0) AS EUR
		,ISNULL(SUM(pvt.Other), 0) AS Other
	INTO #reallocExcl
	FROM (
		SELECT RunIDs
			,AccountingDate
			,YOA
			,AgressoIFRS17ClientCode
			,Statement
			,TransactionType
			,CASE WHEN CCY IN ('CAD','USD','GBP','EUR') THEN CCY ELSE 'Other' END AS CCY
			,AccountSign
			,Amount
		FROM [Reporting].[ReAllocationJournalOutput]
		where RunIDs = @pRunIDs
		and AccountingDate = @pAccDate
		AND DiscUndiscType = @DiscUndiscType
		AND YOA = @YOA
		AND Statement = 'Ra alloc'
		AND ISNULL(AgressoIFRS17ClientCode, 'None') = ISNULL(@AgressoIFRS17ClientCode, 'None')
		and AccountCode <> '88888'
	) s
	PIVOT(SUM(amount) FOR CCY IN (
				CAD
				,USD
				,GBP
				,EUR
				,Other
				)) AS pvt
	GROUP BY ROLLUP(RunIDs, AccountingDate, AgressoIFRS17ClientCode, Statement, YOA, TransactionType, AccountSign)
	having (GROUPING(AccountSign) = 1 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0 AND GROUPING(TransactionType) = 0 AND GROUPING(YOA) = 0 AND GROUPING(AgressoIFRS17ClientCode) = 0 AND GROUPING(Statement) = 0) OR 
	(GROUPING(AccountSign) = 0 AND GROUPING(TransactionType) = 0 AND GROUPING(AccountingDate) = 0 AND GROUPING(RunIDs) = 0 AND GROUPING(YOA) = 0 AND GROUPING(YOA) = 0 AND GROUPING(AgressoIFRS17ClientCode) = 0 AND GROUPING(Statement) = 0)


	SELECT 
		sub.*
		, CASE
			WHEN AccountSign = 'Positive + Negative' THEN
				CASE
					WHEN CAD + USD + GBP + EUR + Other <> 0.00
					THEN 'Fail'
					ELSE 'Pass'
				END 
		 END Status
	FROM (
		SELECT
			RunIDs,
			AccountingDate,
			AgressoIFRS17ClientCode,
			Statement,
			YOA,
			TransactionType,
			AccountSign,
			SUM(CAD) AS CAD,
			SUM(USD) AS USD,
			SUM(GBP) AS GBP,
			SUM(EUR) AS EUR,
			SUM(Other) AS Other
		FROM #reallocExcl realloc
		GROUP BY RunIDs, AccountingDate, AgressoIFRS17ClientCode, Statement, YOA, TransactionType, AccountSign
	) sub
	order by YOA Desc, AccountSign Asc

END;

drop table if exists #journalExperienceExcl, #journalTMPExcl, #reallocExcl, #journalTMPExcl2, #grossupExcl3
