﻿CREATE     procedure [PWAPS].[usp_AdjustmentJournalOutputYTDFailReport] (
    @pRunIDs VARCHAR(50),     /* RunIDs */
    @pAccDate DATE          /* Accounting DATE */
)
AS

DROP TABLE IF EXISTS #YTDTemp, #JournalTemp;
SELECT RunIDs
	,AccountingDate
	,AgressoIFRS17ClientCode
	,Statement
	,RI_Flag
	,CCY
	,SUM(Amount) as Amount
	,SUM(Disc) as Disc
INTO #YTDTemp
FROM Reporting.JournalInputDataYTD
WHERE RunIDs = @pRunIDs
AND AccountingDate = @pAccDate
--AND Balance not in('CSM_LC')
AND( Balance <> 'CSM_LC' OR (ri_flag = 'O' AND Balance = 'CSM_LC' AND Position LIKE '%LC_Adj'))
AND (Position NOT LIKE '%Open%' AND Position NOT LIKE '%Closing%')
GROUP BY RunIDs
	,AccountingDate
	,AgressoIFRS17ClientCode
	,Statement
	,RI_Flag
	,CCY

SELECT RunIDs
	,TRY_CONVERT(VARCHAR(10), AccountingDate, 23) AS AccountingDate
	,DiscUndiscType
	,AgressoIFRS17ClientCode
	,Statement
	,RI_Flag
	,SUM(Amount) AS Amount
	,CCY
INTO #JournalTemp
FROM [Reporting].[JournalOutputAdjustment]
WHERE RunIDs = @pRunIDs
AND AccountingDate = @pAccDate
AND AccountSign = 'Positive'
--AND Balance not in('CSM_LC')
AND( Balance <> 'CSM_LC' OR (ri_flag = 'O' AND Balance = 'CSM_LC' AND Position LIKE '%LC_Adj'))
GROUP BY RunIDs
	,AccountingDate
	,DiscUndiscType
	,AgressoIFRS17ClientCode
	,Statement
	,RI_Flag
	,CCY




SELECT 
	base.RunIDs,
	base.AccountingDate,
	base.DiscUndiscType,
	SUBSTRING(map.[IFRS17 Entity Name], 1, CHARINDEX ('_', map.[IFRS17 Entity Name] ) - 1) AS AgressoIFRS17ClientName,
	base.AgressoIFRS17ClientCode,
	base.Statement,
	base.RI_Flag,
	base.CCY,
	base.JournalOutputAmt,
	base.YTDAmt,
	base.TotalAmt,
	base.Status,
	act.UserApprovedCheck,
	act.AuthorityApprovedCheck,
	act.ApprovedUser,
	act.AuthorityUser,
	act.ID
FROM (
	SELECT COALESCE(journal.RunIDs, ytd.RunIDs) AS RunIDs
		,COALESCE(journal.AccountingDate, ytd.AccountingDate) AS AccountingDate
		,COALESCE(journal.DiscUndiscType, ytd.DiscUndiscType) AS DiscUndiscType
		,COALESCE(journal.AgressoIFRS17ClientCode, ytd.AgressoIFRS17ClientCode) AS AgressoIFRS17ClientCode
		,COALESCE(journal.Statement, ytd.Statement) AS Statement
		,COALESCE(journal.RI_Flag, ytd.RI_Flag) AS RI_Flag
		,COALESCE(journal.CCY, ytd.CCY) AS CCY
		,ISNULL(journal.JournalOutputAmt, 0) AS JournalOutputAmt
		,ISNULL(ytd.YTDAmt, 0) AS YTDAmt
		,ISNULL(ytd.YTDAmt, 0) - ISNULL(journal.JournalOutputAmt, 0) AS TotalAmt
		,CASE 
			WHEN ISNULL(ytd.YTDAmt, 0) - ISNULL(journal.JournalOutputAmt, 0) = 0
				THEN 'Pass'
			ELSE 'Fail'
		END Status
	FROM (
		SELECT RunIDs
			,AccountingDate
			,DiscUndiscType
			,AgressoIFRS17ClientCode
			,Statement
			,RI_Flag
			,Amount AS JournalOutputAmt
			,CCY
		FROM #JournalTemp
	) journal
	FULL OUTER JOIN (
		SELECT RunIDs
			,AccountingDate
			,'Undisc' AS DiscUndiscType
			,AgressoIFRS17ClientCode
			,Statement
			,RI_Flag
			,Amount AS YTDAmt
			,CCY
		FROM #YTDTemp
		
		UNION ALL
		
		SELECT RunIDs
			,TRY_CONVERT(VARCHAR(10), AccountingDate, 23) AS AccountingDate
			,'Disc' AS DiscUndiscType
			,AgressoIFRS17ClientCode
			,Statement
			,RI_Flag
			,Disc AS YTDAmt
			,CCY
		FROM #YTDTemp
		) ytd ON ISNULL(journal.RunIDs, 'Unknown') = ISNULL(ytd.RunIDs, 'Unknown')
		AND ISNULL(journal.AccountingDate, '1900-01-01') = ISNULL(ytd.AccountingDate, '1900-01-01')
		AND ISNULL(journal.DiscUndiscType, 'Unknown') = ISNULL(ytd.DiscUndiscType, 'Unknown')
		AND ISNULL(journal.AgressoIFRS17ClientCode, 'None') = ISNULL(ytd.AgressoIFRS17ClientCode, 'None')
		AND ISNULL(journal.Statement, 'Unknown') = ISNULL(ytd.Statement, 'Unknown')
		AND ISNULL(journal.RI_Flag, 'Un') = ISNULL(ytd.RI_Flag, 'Un')
		AND ISNULL(journal.CCY, 'Unknown') = ISNULL(ytd.CCY, 'Unknown')
) base
LEFT JOIN (
	SELECT 
		[Agresso IFRS17 Client Code], [IFRS17 Entity Name] 
	FROM Dim.JournalEntitiesMapping 
	GROUP BY [Agresso IFRS17 Client Code], [IFRS17 Entity Name]
) map 
	ON ISNULL(base.AgressoIFRS17ClientCode, 'Unknown') = ISNULL(map.[Agresso IFRS17 Client Code], 'Unknown')
LEFT JOIN [PWAPS].[JournalOutputAdjustmentYTDActual] act ON ISNULL(base.RunIDs, 'Unknown') = ISNULL(act.RunIDs, 'Unknown')
	AND ISNULL(base.AccountingDate, '1900-01-01') = ISNULL(act.AccountingDate, '1900-01-01')
	AND ISNULL(base.DiscUndiscType, 'Unknown') = ISNULL(act.DiscUndiscType, 'Unknown')
	AND ISNULL(base.AgressoIFRS17ClientCode, 'None') = ISNULL(act.AgressoIFRS17ClientCode, 'None')
	AND ISNULL(base.Statement, 'Unknown') = ISNULL(act.Statement, 'Unknown')
	AND ISNULL(base.CCY, 'Unknown') = ISNULL(act.CCY, 'Unknown')
	AND ISNULL(base.RI_Flag, 'Un') = ISNULL(act.RI_Flag, 'Un')
where base.Status = 'Fail'
order by base.DiscUndiscType, base.CCY, base.AgressoIFRS17ClientCode, base.Statement, base.RI_Flag;


DROP TABLE IF EXISTS #YTDTemp, #JournalTemp;