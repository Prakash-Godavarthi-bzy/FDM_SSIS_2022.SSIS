﻿CREATE     procedure [PWAPS].[usp_V01Validation] (
    @pRunIDs VARCHAR(50),     /* RunIDs */
    @pAccDate DATE           /* Accounting DATE */
)
AS
DROP TABLE IF EXISTS #TEMP_AdjstJournalReAllocationValidationReport;
CREATE TABLE #TEMP_AdjstJournalReAllocationValidationReport(
	RunIDs varchar(50),
	AccountingDate varchar(10),
	AccountSign varchar(50),
	CAD numeric(18,2),
	USD numeric(18,2),
	GBP numeric(18,2),
	EUR numeric(18,2),
	Other numeric(18,2),
	Status varchar(10),
	CalcType varchar(50)
);
INSERT INTO #TEMP_AdjstJournalReAllocationValidationReport
exec [PWAPS].[usp_AdjstJournalReAllocationValidationReport] @pRunIDs, @pAccDate

SELECT
CASE 
	WHEN EXISTS(SELECT 1 FROM #TEMP_AdjstJournalReAllocationValidationReport
				WHERE AccountSign = 'Positive + Negative' AND Status = 'Fail'
				AND CalcType in('Journal', 'JournalReAllocationExperience')) THEN 0 
	ELSE 1 
END isValid;

DROP TABLE IF EXISTS #TEMP_AdjstJournalReAllocationValidationReport;
