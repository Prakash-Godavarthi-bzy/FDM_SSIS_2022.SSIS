﻿CREATE       procedure [PWAPS].[usp_V01ValidationExcl] (
    @pRunIDs VARCHAR(50),     /* RunIDs */
    @pAccDate DATE           /* Accounting DATE */
)
AS
DROP TABLE IF EXISTS #TEMP_AdjstJournalReAllocationValidationReportExcl;
CREATE TABLE #TEMP_AdjstJournalReAllocationValidationReportExcl(
	RunIDs varchar(50),
	AccountingDate varchar(10),
	AccountSign varchar(50),
	CAD numeric(18,2),
	USD numeric(18,2),
	GBP numeric(18,2),
	EUR numeric(18,2),
	Other numeric(18,2),
	Status varchar(10),
	CalcType varchar(50)
);
INSERT INTO #TEMP_AdjstJournalReAllocationValidationReportExcl
exec [PWAPS].[usp_AdjstJournalReAllocationValidationReport] @pRunIDs, @pAccDate

SELECT
CASE 
	WHEN EXISTS(SELECT 1 FROM #TEMP_AdjstJournalReAllocationValidationReportExcl
				WHERE AccountSign = 'Positive + Negative' AND Status = 'Fail'
				AND CalcType = 'JournalReAllocationExperienceExcl') THEN 0 
	ELSE 1 
END isValid;

DROP TABLE IF EXISTS #TEMP_AdjstJournalReAllocationValidationReport;
