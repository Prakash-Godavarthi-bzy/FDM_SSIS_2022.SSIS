﻿
CREATE   Procedure [PWAPS].[usp_AdjustmentJournalOutputYTDTotalReport] (
    @pRunIDs VARCHAR(50),     /* RunIDs */
    @pAccDate DATE           /* Accounting DATE */
)
AS

DROP TABLE IF EXISTS #YTDTemp, #JournalTemp, #SubTemp;

SELECT RunIDs
	,AccountingDate
	,'Ice output Position <> closing or opening' AS ResultType
	,Amount
	,Disc
	,Case When CCY in ('USD','GBP','CAD','EUR') Then CCY Else 'Other' End as CCY 
INTO #YTDTemp
FROM Reporting.JournalInputDataYTD
WHERE RunIDs = @pRunIDs
AND AccountingDate = @pAccDate
--AND Balance not in('CSM_LC')
AND( Balance <> 'CSM_LC' OR (ri_flag = 'O' AND Balance = 'CSM_LC' AND Position LIKE '%LC_Adj'))
AND (Position NOT LIKE '%Open%' AND Position NOT LIKE '%Closing%');


SELECT RunIDs
		,AccountingDate
		,DiscUndiscType
		,'Journal + account' AS ResultType
		,Amount
		,Case When CCY in ('USD','GBP','CAD','EUR') Then CCY Else 'Other' End as CCY 
INTO #JournalTemp
FROM [Reporting].[JournalOutputAdjustment]
WHERE RunIDs = @pRunIDs
AND AccountingDate = @pAccDate
AND AccountSign = 'Positive'
--AND Balance not in('CSM_LC')
AND( Balance <> 'CSM_LC' OR (ri_flag = 'O' AND Balance = 'CSM_LC' AND Position LIKE '%LC_Adj'))
;


SELECT *
INTO #SubTemp
FROM (
	SELECT *
	FROM #JournalTemp
	
	UNION ALL
	
	SELECT 
		RunIDs,
		AccountingDate,
		'Disc' as DiscUndiscType,
		ResultType,
		Disc as Amount,
		CCY
	FROM #YTDTemp
	
	UNION ALL
	
	SELECT 
		RunIDs,
		AccountingDate,
		'Undisc' as DiscUndiscType,
		ResultType,
		Amount,
		CCY
	FROM #YTDTemp

) sub
PIVOT(SUM(Amount) FOR CCY IN (
CAD
,USD
,GBP
,EUR
,Other
)) AS pvt;


select
	RunIDs,
	AccountingDate,
	DiscUndiscType,
	ResultType,
	NULL AS Status,
	ISNULL(CAD, 0) as CAD,
	ISNULL(USD, 0) as USD,
	ISNULL(GBP, 0) as GBP,
	ISNULL(EUR, 0) as EUR,
	ISNULL(Other, 0) as Other
from #SubTemp

UNION ALL

SELECT COALESCE(journal.RunIDs, ytd.RunIDs) AS RunIDs
		,COALESCE(journal.AccountingDate, ytd.AccountingDate) AS AccountingDate
		,COALESCE(journal.DiscUndiscType, ytd.DiscUndiscType) AS DiscUndiscType
		,'Difference Journal vs ICE' AS ResultType
		,CASE
			WHEN ISNULL(journal.CAD, 0) - ISNULL(ytd.CAD, 0) = 0 AND ISNULL(journal.USD, 0) - ISNULL(ytd.USD, 0) = 0 
			AND ISNULL(journal.GBP, 0) - ISNULL(ytd.GBP, 0) = 0 AND ISNULL(journal.EUR, 0) - ISNULL(ytd.EUR, 0) = 0 
			AND ISNULL(journal.Other, 0) - ISNULL(ytd.Other, 0) = 0 
			THEN 'Pass'
			ELSE 'Fail'
		END Status
		,ISNULL(journal.CAD, 0) - ISNULL(ytd.CAD, 0) AS CAD
		,ISNULL(journal.USD, 0) - ISNULL(ytd.USD, 0) AS USD
		,ISNULL(journal.GBP, 0) - ISNULL(ytd.GBP, 0) AS GBP
		,ISNULL(journal.EUR, 0) - ISNULL(ytd.EUR, 0) AS EUR
		,ISNULL(journal.Other,0) - ISNULL(ytd.Other, 0) AS Other
from (
	select
		* 
	from #SubTemp
	where ResultType = 'Journal + account'
)journal
FULL OUTER JOIN (
	select
		* 
	from #SubTemp
	where ResultType = 'Ice output Position <> closing or opening'
)ytd
	ON journal.RunIDs = ytd.RunIDs
	AND journal.AccountingDate = ytd.AccountingDate
	AND journal.DiscUndiscType = ytd.DiscUndiscType
order by DiscUndiscType, ResultType;

DROP TABLE IF EXISTS #YTDTemp, #JournalTemp, #SubTemp;