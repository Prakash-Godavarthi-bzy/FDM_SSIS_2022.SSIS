﻿CREATE     procedure [PWAPS].[usp_V02Validation] (
    @pRunIDs VARCHAR(50),     /* RunIDs */
    @pAccDate DATE           /* Accounting DATE */
)
AS
DROP TABLE IF EXISTS #TEMP_AdjustmentJournalOutputYTDFailReport
CREATE TABLE #TEMP_AdjustmentJournalOutputYTDFailReport(
	RunIDs varchar(50),
	AccountingDate varchar(10),
	DiscUndiscType varchar(20),
	AgressoIFRS17ClientName varchar(255),
	AgressoIFRS17ClientCode varchar(10),
	Statement varchar(50),
	RI_Flag varchar(10),
	CCY varchar(10),
	JournalOutputAmt numeric(18,2),
	YTDAmt numeric(18,2),
	TotalAmt numeric(18,2),
	Status varchar(10),
	UserApprovedCheck bit,
	AuthorityApprovedCheck bit,
	ApprovedUser varchar(25),
	AuthorityUser varchar(25),
	ID bigint
);
INSERT INTO #TEMP_AdjustmentJournalOutputYTDFailReport
exec [PWAPS].[usp_AdjustmentJournalOutputYTDFailReport] @pRunIDs, @pAccDate;


SELECT
CASE 
	WHEN NOT EXISTS(SELECT * FROM #TEMP_AdjustmentJournalOutputYTDFailReport) THEN 1 
	ELSE 0 
END isValid,
CASE 
	WHEN NOT EXISTS(SELECT * FROM #TEMP_AdjustmentJournalOutputYTDFailReport where AuthorityApprovedCheck is null or AuthorityApprovedCheck = 0) THEN 1 
	ELSE 0 
END isValidOverride;


DROP TABLE IF EXISTS #TEMP_AdjustmentJournalOutputYTDFailReport;