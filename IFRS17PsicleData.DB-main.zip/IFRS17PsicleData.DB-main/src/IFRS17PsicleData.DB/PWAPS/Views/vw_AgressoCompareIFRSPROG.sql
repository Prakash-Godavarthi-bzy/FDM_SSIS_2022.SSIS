﻿CREATE    VIEW [PWAPS].[vw_AgressoCompareIFRSPROG]
AS
SELECT 
	ifrsprog.RunIDs, ifrsprog.AccountingDate, ifrsprog.dim_2 as value, 'IFRSPROG' as type, count(*) cnt 
FROM (
	SELECT 
		vw.RunIDs, vw.AccountingDate, vw.account, vw.dim_2
	FROM [PWAPS].[vw_JournalOutputFinal] vw
	LEFT JOIN Reporting.Agresso_uviattrvalues tgt
		on vw.dim_2 = tgt.AttributeCode and tgt.DimensionName = 'IFRSPROG'
	WHERE tgt.AttributeCode is null
)  ifrsprog
LEFT JOIN PWAPS.MetadataRulesGAAP programme
	on ifrsprog.account = programme.AccountCode and programme.Attribute = 'Programme'
WHERE (programme.AccountCode is null
or programme.TransformationType <> 'Blanked')
GROUP BY ifrsprog.RunIDs, ifrsprog.AccountingDate, ifrsprog.dim_2