﻿

CREATE VIEW [PWAPS].[vw_AdjustmentJournalValidation_V03_Portfoliocheck]
AS

With pvttemptable(RunIDs,AccountingDate,Portfolio,Programme,Position,CSM,LIC,LRC)
AS 
(
Select  
		pvt.RunIDs,
		try_convert(varchar, pvt.AccountingDate, 23),
		pvt.Portfolio,
		pvt.Programme,
		pvt.Position,
		pvt.CSM as [CSM Conv_Disc_Amount],
		pvt.LIC as [LIC Conv_Disc_Amount],
		pvt.LRC as [LRC Conv_Disc_Amount]	
from 
(
  Select  [RunIDs],[AccountingDate],Portfolio,CASE Programme WHEN 'GROSS' THEN 'GROSS' ELSE 'RI' END as Programme,
          CASE WHEN [Statement] = 'CSM' AND Programme <> 'GROSS' AND [Position] = 'Closing(Inc LC_ADJ)' THEN 'Closing' ELSE [Position] END AS [Position] ,[Statement],[Conv_Amount_disc] 
  from Reporting.JournalInputDataYTD
  Where   
  ((Position = 'Closing' AND Balance <> 'CSM_LC' and RI_Flag = 'I'  ) /*PK - 250923 Updated the condition for CR I17-5744 */
	OR
	(Position = 'Closing(Inc LC_ADJ)' AND Balance = 'CSM_LC' and RI_Flag = 'O' AND [STATEMENT] = 'CSM')
	OR
	(Position = 'Closing' AND Balance <> 'CSM_LC' and RI_Flag = 'O' AND [STATEMENT] <> 'CSM')
	)
  and (CSM_LC is null or CSM_LC = 'CSM')
)sr
Pivot
(
 Sum(Conv_Amount_disc) for statement in 
 (
	[CSM] ,
	[LIC],
    [LRC]
 ) 
)as pvt
)

Select	RunIds,AccountingDate,Portfolio ,Programme,Position,
		[CSM] as [CSM Conv_Disc_Amount],
		[LIC] as [LIC Conv_Disc_Amount],
		[LRC] as [LRC Conv_Disc_Amount],
		ISNULL(LIC,0)+ISNULL(LRC,0) - ISNULL(CSM,0) as [LIC+LRC-CSM],
CASE  WHEN ISNULL(LIC,0)+ISNULL(LRC,0) - ISNULL(CSM,0)>0 THEN 'Asset' 
	  Else 'Liability' 
End as [Check Asst/Liab]
from pvttemptable