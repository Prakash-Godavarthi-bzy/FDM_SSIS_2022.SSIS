﻿

CREATE    VIEW [PWAPS].[vw_DistinctListValue]
AS
 SELECT DISTINCT ISNULL(SUBSTRING(map.[IFRS17 Entity Name], 1, CHARINDEX ('_', map.[IFRS17 Entity Name] ) - 1), 'None')  AS ListName
       ,AgressoIFRS17ClientCode AS ListValue
       ,'AgressoIFRS17ClientCode' AS ListType
FROM (select distinct AgressoIFRS17ClientCode from Reporting.JournalInputDataYTD) ytd
LEFT JOIN Dim.JournalEntitiesMapping map
ON ytd.AgressoIFRS17ClientCode = map.[Agresso IFRS17 Client Code]


UNION ALL

SELECT cast(YOA AS VARCHAR(4)) AS ListName
         ,cast(YOA AS VARCHAR(4)) AS ListValue
         ,'YOA' AS ListType
  FROM (select distinct YOA from Reporting.JournalInputDataYTD) src

UNION ALL

SELECT DISTINCT RI_Flag AS ListName
         ,RI_Flag AS ListValue
         ,'RI_Flag' AS ListType
  FROM Reporting.JournalInputDataYTD

UNION ALL

SELECT DISTINCT CCY AS ListName
         ,CCY AS ListValue
         ,'CCY' AS ListType
FROM Reporting.JournalInputDataYTD

UNION ALL

select listName, listValue, ListType
  from (SELECT AccountCode_undisc_NegativeAmount AS ListName
                 ,AccountCode_undisc_NegativeAmount AS ListValue
                 ,'AccountCode' AS ListType
          FROM Dim.AccountMappingRules
        union 
        SELECT AccountCode_undisc_PositiveAmount AS ListName
                 ,AccountCode_undisc_PositiveAmount AS ListValue
                 ,'AccountCode' AS ListType
          FROM Dim.AccountMappingRules
        union 
        SELECT AccountCode_disc_NegativeAmount AS ListName
                 ,AccountCode_disc_NegativeAmount AS ListValue
                 ,'AccountCode' AS ListType
          FROM Dim.AccountMappingRules
        union 
        SELECT AccountCode_disc_PositiveAmount AS ListName
                 ,AccountCode_disc_PositiveAmount AS ListValue
                 ,'AccountCode' AS ListType
          FROM Dim.AccountMappingRules
       ) src
where ListValue not like '%Missing Mapping%'