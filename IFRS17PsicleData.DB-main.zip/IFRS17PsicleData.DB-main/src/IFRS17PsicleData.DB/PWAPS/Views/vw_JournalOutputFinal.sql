﻿CREATE VIEW [PWAPS].[vw_JournalOutputFinal]
AS

SELECT A.RunIDs
, A.AccountingDate
, A.client
, A.dim_7
, A.dim_2
, A.dim_3
, A.account
, A.dim_4
, A.dim_5
, A.dim_6
, A.voucher_type
, case when A.dim_1 like 'Unknown' then 'NOTRIFOC' else A.dim_1 end as dim_1 
, A.[description]
, A.currency
, A.voucher_date
, A.trans_date
, A.cur_amount
FROM
(

SELECT 
	joa.RunIDs,
	joa.AccountingDate,
	joa.AgressoIFRS17ClientCode as client,
	joa.AgressoEntityCode as dim_7,
	CASE 
		WHEN Programme.ID is not null THEN Programme.TransformationValue
		ELSE CASE WHEN CAST(joa.Programme AS VARCHAR) <> 'GROSS' THEN 'RI' ELSE CAST(joa.Programme AS VARCHAR) END
	END dim_2,
	CASE WHEN CAST(joa.YOI AS VARCHAR) = '9999' THEN 'NOIFRSYOI' ELSE CAST(joa.YOI AS VARCHAR) END dim_3,
	joa.AccountCode as account,
	CASE WHEN CAST(joa.YOA AS VARCHAR) = '9999' THEN 'NOYOA' ELSE CAST(joa.YOA AS VARCHAR) END dim_4,
	--UOA as dim_5,
	'' as dim_5,
	CASE 
		WHEN portfolio.ID is not null THEN portfolio.TransformationValue
		WHEN joa.RI_Flag='O' THEN 'R' 
		ELSE joa.RI_Flag
	END dim_6,
	joa.TransactionType as voucher_type,
	CASE 
		WHEN trifocus.ID is not null THEN trifocus.TransformationValue
		ELSE joa.TriFocusCode
	END dim_1, --dim_1
	joa.JournalDescription as description,
	joa.CCY as currency,
	joa.AccountingDate as voucher_date,
	joa.AccountingDate as trans_date,
	joa.Amount as cur_amount 
FROM Reporting.JournalOutputAdjustment joa
left join PWAPS.MetadataRulesGAAP portfolio
	on joa.AccountCode = portfolio.AccountCode and portfolio.Attribute = 'Portfolio'
left join PWAPS.MetadataRulesGAAP programme
	on joa.AccountCode = programme.AccountCode and programme.Attribute = 'Programme'
left join PWAPS.MetadataRulesGAAP trifocus
	on joa.AccountCode = trifocus.AccountCode and trifocus.Attribute = 'Trifocus'
WHERE joa.Amount <> 0
  

UNION ALL

SELECT 
	joa.RunIDs,
	joa.AccountingDate,
	joa.AgressoIFRS17ClientCode as client,
	joa.AgressoEntityCode as dim_7,
	CASE 
		WHEN Programme.ID is not null THEN Programme.TransformationValue
		ELSE CASE WHEN CAST(joa.Programme AS VARCHAR) <> 'GROSS' THEN 'RI' ELSE CAST(joa.Programme AS VARCHAR) END
	END dim_2,
	CASE WHEN CAST(joa.YOI AS VARCHAR) = '9999' THEN 'NOIFRSYOI' ELSE CAST(joa.YOI AS VARCHAR) END dim_3,
	joa.AccountCode as account,
	CASE WHEN CAST(joa.YOA AS VARCHAR) = '9999' THEN 'NOYOA' ELSE CAST(joa.YOA AS VARCHAR) END dim_4,
	--UOA as dim_5,
	'' as dim_5,
	CASE 
		WHEN portfolio.ID is not null THEN portfolio.TransformationValue
		WHEN joa.RI_Flag='O' THEN 'R' 
		ELSE joa.RI_Flag
	END dim_6,
	joa.TransactionType as voucher_type,
	CASE 
		WHEN trifocus.ID is not null THEN trifocus.TransformationValue
		ELSE joa.TriFocusCode
	END dim_1, --dim_1
	joa.JournalDescription as description,
	joa.CCY as currency,
	joa.AccountingDate as voucher_date,
	joa.AccountingDate as trans_date,
	joa.Amount as cur_amount 
FROM Reporting.ReAllocationJournalOutput joa
left join PWAPS.MetadataRulesGAAP portfolio
	on joa.AccountCode = portfolio.AccountCode and portfolio.Attribute = 'Portfolio'
left join PWAPS.MetadataRulesGAAP programme
	on joa.AccountCode = programme.AccountCode and programme.Attribute = 'Programme'
left join PWAPS.MetadataRulesGAAP trifocus
	on joa.AccountCode = trifocus.AccountCode and trifocus.Attribute = 'Trifocus'
WHERE joa.Amount <> 0

UNION ALL

SELECT 
	joa.RunIDs,
	joa.AccountingDate,
	joa.AgressoIFRS17ClientCode as client,
	joa.AgressoEntityCode as dim_7,
	CASE 
		WHEN Programme.ID is not null THEN Programme.TransformationValue
		ELSE CASE WHEN CAST(joa.Programme AS VARCHAR) <> 'GROSS' THEN 'RI' ELSE CAST(joa.Programme AS VARCHAR) END
	END dim_2,
	CASE WHEN CAST(joa.YOI AS VARCHAR) = '9999' THEN 'NOIFRSYOI' ELSE CAST(joa.YOI AS VARCHAR) END dim_3,
	joa.AccountCode as account,
	CASE WHEN CAST(joa.YOA AS VARCHAR) = '9999' THEN 'NOYOA' ELSE CAST(joa.YOA AS VARCHAR) END dim_4,
	--UOA as dim_5,
	'' as dim_5,
	CASE 
		WHEN portfolio.ID is not null THEN portfolio.TransformationValue
		WHEN joa.RI_Flag='O' THEN 'R' 
		ELSE joa.RI_Flag
	END dim_6,
	joa.TransactionType as voucher_type,
	CASE 
		WHEN trifocus.ID is not null THEN trifocus.TransformationValue
		ELSE joa.TriFocusCode
	END dim_1, --dim_1
	joa.JournalDescription as description,
	joa.CCY as currency,
	joa.AccountingDate as voucher_date,
	joa.AccountingDate as trans_date,
	joa.Amount as cur_amount 
FROM Reporting.JournalOutputExperience joa
left join PWAPS.MetadataRulesGAAP portfolio
	on joa.AccountCode = portfolio.AccountCode and portfolio.Attribute = 'Portfolio'
left join PWAPS.MetadataRulesGAAP programme
	on joa.AccountCode = programme.AccountCode and programme.Attribute = 'Programme'
left join PWAPS.MetadataRulesGAAP trifocus
	on joa.AccountCode = trifocus.AccountCode and trifocus.Attribute = 'Trifocus'
WHERE joa.Amount <> 0

UNION ALL


SELECT 
	joa.RunIDs,
	joa.AccountingDate,
	joa.AgressoIFRS17ClientCode as client,
	joa.AgressoEntityCode as dim_7,
	CASE 
		WHEN Programme.ID is not null THEN Programme.TransformationValue
		ELSE CASE WHEN CAST(joa.Programme AS VARCHAR) <> 'GROSS' THEN 'RI' ELSE CAST(joa.Programme AS VARCHAR) END
	END dim_2,
	CASE WHEN CAST(joa.YOI AS VARCHAR) = '9999' THEN 'NOIFRSYOI' ELSE CAST(joa.YOI AS VARCHAR) END dim_3,
	joa.AccountCode as account,
	CASE WHEN CAST(joa.YOA AS VARCHAR) = '9999' THEN 'NOYOA' ELSE CAST(joa.YOA AS VARCHAR) END dim_4,
	--UOA as dim_5,
	'' as dim_5,
	CASE 
		WHEN portfolio.ID is not null THEN portfolio.TransformationValue
		WHEN joa.RI_Flag='O' THEN 'R' 
		ELSE joa.RI_Flag
	END dim_6,
	joa.TransactionType as voucher_type,
	CASE 
		WHEN trifocus.ID is not null THEN trifocus.TransformationValue
		ELSE joa.TriFocusCode
	END dim_1, --dim_1
	joa.JournalDescription as description,
	joa.CCY as currency,
	joa.AccountingDate as voucher_date,
	joa.AccountingDate as trans_date,
	joa.Amount as cur_amount 
FROM Reporting.JournalOutputGrossUp joa
left join PWAPS.MetadataRulesGAAP portfolio
	on joa.AccountCode = portfolio.AccountCode and portfolio.Attribute = 'Portfolio'
left join PWAPS.MetadataRulesGAAP programme
	on joa.AccountCode = programme.AccountCode and programme.Attribute = 'Programme'
left join PWAPS.MetadataRulesGAAP trifocus
	on joa.AccountCode = trifocus.AccountCode and trifocus.Attribute = 'Trifocus'
WHERE joa.Amount <> 0

UNION ALL

SELECT 
	jlc.RunIDs,
	jlc.AccountingDate,
	jlc.AgressoIFRS17ClientCode as client,
	jlc.AgressoEntityCode as dim_7,
	CASE 
		WHEN Programme.ID is not null THEN Programme.TransformationValue
		ELSE CASE WHEN CAST(jlc.Programme AS VARCHAR) <> 'GROSS' THEN 'RI' ELSE CAST(jlc.Programme AS VARCHAR) END
	END dim_2,
	CASE WHEN CAST(jlc.YOI AS VARCHAR) = '9999' THEN 'NOIFRSYOI' ELSE CAST(jlc.YOI AS VARCHAR) END dim_3,
	jlc.AccountCode as account,
	CASE WHEN CAST(jlc.YOA AS VARCHAR) = '9999' THEN 'NOYOA' ELSE CAST(jlc.YOA AS VARCHAR) END dim_4,
	--UOA as dim_5,
	'' as dim_5,
	CASE 
		WHEN portfolio.ID is not null THEN portfolio.TransformationValue
		WHEN jlc.RI_Flag='O' THEN 'R' 
		ELSE jlc.RI_Flag
	END dim_6,
	jlc.TransactionType as voucher_type,
	CASE 
		WHEN trifocus.ID is not null THEN trifocus.TransformationValue
		ELSE jlc.TriFocusCode
	END dim_1, --dim_1
	jlc.JournalDescription as description,
	jlc.CCY as currency,
	jlc.AccountingDate as voucher_date,
	jlc.AccountingDate as trans_date,
	jlc.Amount as cur_amount 
FROM Reporting.JournalOutputLCAdjMovement jlc
left join PWAPS.MetadataRulesGAAP portfolio
	on jlc.AccountCode = portfolio.AccountCode and portfolio.Attribute = 'Portfolio'
left join PWAPS.MetadataRulesGAAP programme
	on jlc.AccountCode = programme.AccountCode and programme.Attribute = 'Programme'
left join PWAPS.MetadataRulesGAAP trifocus
	on jlc.AccountCode = trifocus.AccountCode and trifocus.Attribute = 'Trifocus'
WHERE jlc.Amount <> 0
) A
GO
