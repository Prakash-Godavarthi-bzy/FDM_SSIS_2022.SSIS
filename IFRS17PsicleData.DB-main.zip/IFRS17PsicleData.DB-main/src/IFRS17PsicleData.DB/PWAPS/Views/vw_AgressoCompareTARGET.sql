﻿CREATE   VIEW [PWAPS].[vw_AgressoCompareTARGET]
AS
select 
	vw.RunIDs, vw.AccountingDate, vw.dim_7 as value, 'TARGET' as type, count(*) cnt 
from [PWAPS].[vw_JournalOutputFinal] vw
left join Reporting.Agresso_uviattrvalues tgt
	on vw.dim_7 = tgt.AttributeCode and tgt.DimensionName = 'TARGET'
left join Dim.JournalEntitiesMapping jem on (vw.client = jem.[Agresso IFRS17 Client Code])
WHERE (tgt.AttributeCode is null and (jem.[Entity Code] <> '8033' or jem.[Entity Code] is null)) /* 8033 entity is not reported as missing value */
group by vw.RunIDs, vw.AccountingDate, vw.dim_7