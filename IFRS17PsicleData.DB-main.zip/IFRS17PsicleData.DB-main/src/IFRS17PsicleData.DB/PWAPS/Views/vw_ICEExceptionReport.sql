﻿Create View PWAPS.vw_ICEExceptionReport
AS
SELECT A.RunID, A.[Statement], A.RI_Flag, A.Balance, A.Position, A.[Journal Description],
MAX(Discounted) AS Discounted
					,IsNUll(DA.AccountCode_disc_NegativeAmount,'Missing Mapping') As AccountCode_disc_NegativeAmount,
					 IsNULL(DA.AccountCode_undisc_PositiveAmount,'Missing Mapping') As AccountCode_disc_PositiveAmount,
MAX(Undiscounted) AS Undiscounted,
	IsNUll(DA.AccountCode_undisc_NegativeAmount,'Missing Mapping')As AccountCode_undisc_NegativeAmount,
	IsNull(Da.AccountCode_undisc_PositiveAmount,'Missing Mapping') As AccountCode_undisc_PositiveAmount
FROM
(Select  Distinct  CSM.RunID ,
                CSM.Statement,
                CSM.RI_Flag,
                CSM.Balance,
                TT.Position,
                CONCAT(CSM.Statement,
                CSM.RI_Flag,
                CSM.Balance,
                TT.Position) AS [Journal Description],
                [Transaction Type]   as Discounted
                ,Null As Undiscounted
    from Reporting.CSM_Post_LCAdjustments CSM
    Inner join dim.JournalTransactionTypeMapping  TT on  CSM.Statement=TT.[Statement] And CSM.Position=TT.Position and [Discounted(Y/N)]='Y'
    UNION ALL
    Select  Distinct
                 CSM1.RunID
                ,CSM1.Statement
                ,CSM1.RI_Flag
                ,CSM1.Balance
                ,TT.Position
                ,CONCAT(CSM1.Statement,
                        CSM1.RI_Flag,
                        CSM1.Balance,
                        TT.Position) AS [Journal Description]
                , NULL Discounted
                ,[Transaction Type]   as Undiscounted
    from Reporting.CSM_Post_LCAdjustments CSM1
    Inner join dim.JournalTransactionTypeMapping  TT on  CSM1.Statement=TT.[Statement] And CSM1.Position=TT.Position and [Discounted(Y/N)]='N'
	UNION ALL
	Select  Distinct  LIC.RunID ,
                LIC.Statement,
                LIC.RI_Flag,
                LIC.Balance,
                TT.Position,
                CONCAT(LIC.Statement,
                LIC.RI_Flag,
                LIC.Balance,
                TT.Position) AS [Journal Description],
                [Transaction Type]   as Discounted
                ,Null As Undiscounted
    from Reporting.LIC_DiscountedData LIC
    Inner join dim.JournalTransactionTypeMapping  TT on  LIC.Statement=TT.[Statement] And LIC.Position=TT.Position and TT.[Discounted(Y/N)]='Y'
	UNION ALL
		Select  Distinct  LIC1.RunID ,
                LIC1.Statement,
                LIC1.RI_Flag,
                LIC1.Balance,
                TT.Position,
                CONCAT(LIC1.Statement,
                LIC1.RI_Flag,
                LIC1.Balance,
                TT.Position) AS [Journal Description],
				 null As discounted,
                [Transaction Type]   as  Undiscounted           
    from Reporting.LIC_DiscountedData LIC1
    Inner join dim.JournalTransactionTypeMapping  TT on  LIC1.Statement=TT.[Statement] And LIC1.Position=TT.Position and TT.[Discounted(Y/N)]='N'
	UNION ALL
		Select  Distinct  LRC.RunID ,
                LRC.Statement,
                LRC.RI_Flag,
                LRC.Balance,
                TT.Position,
                CONCAT(LRC.Statement,
                LRC.RI_Flag,
                LRC.Balance,
                TT.Position) AS [Journal Description],
                [Transaction Type]   as Discounted
                ,null As Undiscounted
    from Reporting.LRC_Post_BBNIAdjustments LRC
    Inner join dim.JournalTransactionTypeMapping  TT on  LRC.Statement=TT.[Statement] And LRC.Position=TT.Position and [Discounted(Y/N)]='Y'
	UNION ALL
		Select  Distinct  LRC1.RunID ,
                LRC1.Statement,
                LRC1.RI_Flag,
                LRC1.Balance,
                TT.Position,
                CONCAT(LRC1.Statement,
                LRC1.RI_Flag,
                LRC1.Balance,
                TT.Position) AS [Journal Description],
				  null As discounted,
                [Transaction Type]   as Undiscounted             
    from Reporting.LRC_Post_BBNIAdjustments LRC1
    Inner join dim.JournalTransactionTypeMapping  TT on  LRC1.Statement=TT.[Statement] And LRC1.Position=TT.Position and [Discounted(Y/N)]='N'
)A
left join Dim.AccountMappingRules DA On a.Statement=DA.Statement And a.Position=DA.Position And a.RI_Flag=DA.RI_Flag And a.Balance=DA.Balanace
GROUP  BY A.RunID, A.[Statement], A.RI_Flag, A.Balance, A.Position, A.[Journal Description],
DA.AccountCode_disc_NegativeAmount,Da.AccountCode_disc_PositiveAmount,Da.AccountCode_undisc_PositiveAmount,Da.AccountCode_undisc_NegativeAmount
ORDER BY 1,2,3,4,5,6 OFFSET 0 ROWS