﻿CREATE      VIEW [PWAPS].[vw_CombinationJournalExportGroups]
AS
select 
	distinct RunIDs, AccountingDate, version, SplitGroup
from PWAPS.vw_JournalExportCSV