﻿

--Create view with schemabinding.
CREATE     VIEW [PWAPS].[vw_CombinationList]
WITH SCHEMABINDING
AS
SELECT CONVERT(VARCHAR(10), AccountingDate, 126) AS AccountingDate, 
       RunIDs, 
       cntBIG 
  FROM (SELECT AccountingDate , RunIDs, COUNT_BIG(*) AS cntBIG 
          FROM Reporting.JournalInputDataYTD
        GROUP BY AccountingDate, RunIDs
       ) SRC


