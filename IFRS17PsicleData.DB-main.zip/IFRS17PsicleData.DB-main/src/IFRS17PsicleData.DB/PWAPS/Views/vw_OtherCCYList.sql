﻿CREATE      VIEW [PWAPS].[vw_OtherCCYList]
WITH SCHEMABINDING
AS
select
	RunIDs,
	AccountingDate,
	STRING_AGG(s.CCY, ', ') as Other
from (
	select distinct RunIDs, AccountingDate, CCY 
	FROM Reporting.JournalInputDataYTD
	where CCY NOT IN ('CAD','USD','GBP','EUR')
)s
GROUP BY RunIDs, AccountingDate