﻿
CREATE VIEW [PWAPS].[vw_GetRunIDCSMWalkBalancesOB]
	AS 

SELECT Distinct T1.RunID as Pk_RequestId
FROM Results.UndiscCSMWalkBalancesOB T1  
