﻿
CREATE     VIEW [PWAPS].[vw_AgressoCompareCOSTC]
AS
SELECT costc.RunIDs, costc.AccountingDate, costc.dim_1 as value, 'COSTC' as type, count(*) cnt  
FROM (
	select 
		vw.RunIDs, vw.AccountingDate, vw.account, vw.dim_1
	from [PWAPS].[vw_JournalOutputFinal] vw
	left join Reporting.Agresso_uviattrvalues tgt
		on vw.dim_1 = tgt.AttributeCode and tgt.DimensionName = 'COSTC'
	WHERE tgt.AttributeCode is null
) costc
left join PWAPS.MetadataRulesGAAP trifocus
	on costc.account = trifocus.AccountCode and trifocus.Attribute = 'Trifocus'
where (trifocus.AccountCode is null
or trifocus.TransformationType <> 'Blanked')
Group by costc.RunIDs, costc.AccountingDate, costc.dim_1