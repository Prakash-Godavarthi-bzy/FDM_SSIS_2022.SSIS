﻿

CREATE    VIEW [PWAPS].[vw_VersionList]
AS
SELECT 
 DISTINCT	RunIDs,[version],convert(varchar(10), AccountingDate, 23)as AccountingDate, Concat(version, ' (', AuditUser, ')') as VersionName
FROM (SELECT AccountingDate , RunIDs, version, AuditUser
          FROM [Reporting].[JournalOutputFinal]
        GROUP BY AccountingDate, RunIDs, version, AuditUser
       ) SRC