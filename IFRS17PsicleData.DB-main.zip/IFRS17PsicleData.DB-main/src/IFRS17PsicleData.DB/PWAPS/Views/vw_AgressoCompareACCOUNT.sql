﻿
CREATE   VIEW [PWAPS].[vw_AgressoCompareACCOUNT]
AS
select 
	vw.RunIDs, vw.AccountingDate, vw.account as value, 'ACCOUNT' as type, count(*) cnt 
from [PWAPS].[vw_JournalOutputFinal] vw
left join Reporting.Agresso_uviattrvalues tgt
	on vw.account = tgt.AttributeCode and tgt.DimensionName = 'ACCOUNT'
WHERE tgt.AttributeCode is null
group by vw.RunIDs, vw.AccountingDate, vw.account