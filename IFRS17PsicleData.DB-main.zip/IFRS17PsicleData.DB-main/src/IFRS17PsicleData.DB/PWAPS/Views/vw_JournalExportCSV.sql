﻿
CREATE VIEW [PWAPS].[vw_JournalExportCSV] AS
select CASE WHEN src.voucher_type = 'JV' AND [Description] like 'LC_mvt%'
			THEN 'LC_mvt_adj'
			ELSE 
				case when client in ('IA', 'IL')
					then 
						case when client = 'IA'
							then 
								concat_ws ('_', 
									client ,
								   case
									 when currency in ('CAD', 'EUR', 'USD','GBP') then currency
									 else 'Other'
								   end,
								   case
									 when currency in ('USD') and voucher_type in ('X3') then voucher_type
									 else 'Other'
								   end,
								   case 
									 when dim_4 <= 2019 then '19'
									 when dim_4 in (2020,2021,2022) then '202122' 
									 when dim_4 >= 2023 then '23'
									 else 'Other'
								   end) 
							 else 
								concat_ws ('_', client ,   'Other',	   'Other',
								   case 
									 when dim_4 <= 2022 then '22'
									 when dim_4 >= 2023 then '23'
									 else 'Other'
								   end) 
							end
					else 
						case when client = 'IC' then  concat_ws ('_',  client,  'Other',   'Other',   'All') 
							 else concat_ws ('_',  'Other',  'Other',   'Other',   'All') 
						end
					end
	   END as SplitGroup,
       src.*
  from Reporting.[JournalOutputFinal] src
;