﻿
CREATE FUNCTION PWAPS.udf_ReallocationAsstLiabCurrQtr (@pAccDate DATE, @RunId Varchar(50), @pJournalType VARCHAR(5))

RETURNS TABLE
AS
RETURN

With CurrQtrPvtTempTable(RunIDs,AccountingDate,Portfolio,Programme,Position,CSM,LIC,LRC)
AS 
(
Select  
		pvt.RunIDs,
		try_convert(varchar, pvt.AccountingDate, 23),
		pvt.Portfolio,
		pvt.Programme,
		pvt.Position,
		pvt.CSM as [CSM Conv_Disc_Amount],
		pvt.LIC as [LIC Conv_Disc_Amount],
		pvt.LRC as [LRC Conv_Disc_Amount]	
from 
(
  Select  [RunIDs],[AccountingDate],Portfolio,CASE Programme WHEN 'GROSS' THEN 'GROSS' ELSE 'RI' END as Programme,
          CASE WHEN [Statement] = 'CSM' AND Programme <> 'GROSS' AND [Position] = 'Closing(Inc LC_ADJ)' THEN 'Closing' ELSE [Position] END AS [Position] ,[Statement],[Conv_Amount_disc] 
  from Reporting.JournalInputDataYTD
  Where  
  1 = 1
  AND RUNIDS = @RunId
  AND ACCOUNTINGDATE = @pAccDate
  AND((Position = 'Closing' AND Balance <> 'CSM_LC' and RI_Flag = 'I'  ) /*PK - 250923 Updated the condition for CR I17-5744 */
	OR
	(Position = 'Closing(Inc LC_ADJ)' AND Balance = 'CSM_LC' and RI_Flag = 'O' AND [STATEMENT] = 'CSM')
	OR
	(Position = 'Closing' AND Balance <> 'CSM_LC' and RI_Flag = 'O' AND [STATEMENT] <> 'CSM')
	)
  and (CSM_LC is null or CSM_LC = 'CSM')
)sr
Pivot
(
 Sum(Conv_Amount_disc) for statement in 
 (
	[CSM] ,
	[LIC],
    [LRC]
 ) 
)as pvt
),
 PreQtrPvtTempTable(RunIDs,AccountingDate,Portfolio,Programme,Position,CSM,LIC,LRC)
AS 
(
Select  
		pvt.RunIDs,
		try_convert(varchar, pvt.AccountingDate, 23),
		pvt.Portfolio,
		pvt.Programme,
		pvt.Position,
		pvt.CSM as [CSM Conv_Disc_Amount],
		pvt.LIC as [LIC Conv_Disc_Amount],
		pvt.LRC as [LRC Conv_Disc_Amount]	
from 
(
  Select  [RunIDs],[AccountingDate],Portfolio,CASE Programme WHEN 'GROSS' THEN 'GROSS' ELSE 'RI' END as Programme,
          CASE WHEN [Statement] = 'CSM' AND Programme <> 'GROSS' AND [Position] = 'Closing(Inc LC_ADJ)' THEN 'Closing' ELSE [Position] END AS [Position] ,[Statement],[Conv_Amount_disc] 
  from Reporting.JournalInputDataYTD T1
  INNER JOIN PWAPS.udf_ReallocationAsstLiabPreQtr_RunIds (@pAccDate, @RunId , @pJournalType )T2 ON T1.RunIDs = T2.PreQtrRunId AND T1.AccountingDate = T2.PreQtrAccDt
  Where  
  1 = 1
  AND((Position = 'Closing' AND Balance <> 'CSM_LC' and RI_Flag = 'I'  ) /*PK - 250923 Updated the condition for CR I17-5744 */
	OR
	(Position = 'Closing(Inc LC_ADJ)' AND Balance = 'CSM_LC' and RI_Flag = 'O' AND [STATEMENT] = 'CSM')
	OR
	(Position = 'Closing' AND Balance <> 'CSM_LC' and RI_Flag = 'O' AND [STATEMENT] <> 'CSM')
	)
  and (CSM_LC is null or CSM_LC = 'CSM')
)sr
Pivot
(
 Sum(Conv_Amount_disc) for statement in 
 (
	[CSM] ,
	[LIC],
    [LRC]
 ) 
)as pvt
), 
CurrQtrPvtFinalTable AS
(

Select	RunIds,AccountingDate,Portfolio ,Programme,Position,
		[CSM] as [CSM Conv_Disc_Amount],
		[LIC] as [LIC Conv_Disc_Amount],
		[LRC] as [LRC Conv_Disc_Amount],
		ISNULL(LIC,0)+ISNULL(LRC,0) - ISNULL(CSM,0) as [LIC+LRC-CSM],
CASE  WHEN ISNULL(LIC,0)+ISNULL(LRC,0) - ISNULL(CSM,0)>0 THEN 'Asset' 
	  Else 'Liability' 
End as [CurrCheck Asst/Liab]
from CurrQtrPvtTempTable
),
PreQtrPvtFinalTable AS
(

Select	RunIds,AccountingDate,Portfolio ,Programme,Position,
		[CSM] as [CSM Conv_Disc_Amount],
		[LIC] as [LIC Conv_Disc_Amount],
		[LRC] as [LRC Conv_Disc_Amount],
		ISNULL(LIC,0)+ISNULL(LRC,0) - ISNULL(CSM,0) as [LIC+LRC-CSM],
CASE  WHEN ISNULL(LIC,0)+ISNULL(LRC,0) - ISNULL(CSM,0)>0 THEN 'Asset' 
	  Else 'Liability' 
End as [PreCheck Asst/Liab]
from PreQtrPvtTempTable
)

SELECT T1.RunIds, T1.AccountingDate, T1.Portfolio, T1.Programme, T1.Position, T1.[CurrCheck Asst/Liab] as CurrentQtrAsstLiabChk , T2.[PreCheck Asst/Liab] as PreviousQtrAsstLiabChk
, CASE WHEN T1.Programme = 'GROSS'
	   THEN CASE WHEN T1.[CurrCheck Asst/Liab] = 'Asset'	 and ISNULL([PreCheck Asst/Liab],'Liability') = 'Asset' THEN 'TYPE3'
				 WHEN T1.[CurrCheck Asst/Liab] = 'Asset'	 and ISNULL([PreCheck Asst/Liab],'Liability') = 'Liability' THEN 'TYPE4'
				 WHEN T1.[CurrCheck Asst/Liab] = 'Liability' and ISNULL([PreCheck Asst/Liab],'Liability') = 'Asset' THEN 'TYPE2'
				 WHEN T1.[CurrCheck Asst/Liab] = 'Liability' and ISNULL([PreCheck Asst/Liab],'Liability') = 'Liability' THEN 'TYPE1'
				 ELSE 'TYPE5'
			END
	   ELSE CASE WHEN T1.[CurrCheck Asst/Liab] = 'Asset'	 and ISNULL([PreCheck Asst/Liab],'Asset') = 'Asset' THEN 'TYPE3'
				 WHEN T1.[CurrCheck Asst/Liab] = 'Asset'	 and ISNULL([PreCheck Asst/Liab],'Asset') = 'Liability' THEN 'TYPE4'
				 WHEN T1.[CurrCheck Asst/Liab] = 'Liability' and ISNULL([PreCheck Asst/Liab],'Asset') = 'Asset' THEN 'TYPE2'
				 WHEN T1.[CurrCheck Asst/Liab] = 'Liability' and ISNULL([PreCheck Asst/Liab],'Asset') = 'Liability' THEN 'TYPE1'
				 ELSE 'TYPE5'
			END
	  END ComparisionChk
FROM CurrQtrPvtFinalTable  T1
LEFT JOIN PreQtrPvtFinalTable T2 ON T1.Portfolio = T2.Portfolio
											AND T1.Programme = T2.Programme
											AND T1.Position = T2.Position