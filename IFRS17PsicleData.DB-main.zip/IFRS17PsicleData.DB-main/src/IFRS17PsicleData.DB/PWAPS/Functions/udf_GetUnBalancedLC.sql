﻿--DECLARE
--@pQ1 INT = 4,               
--@pQ2 INT = 5,               
--@pQ3 INT = 6,               
--@pQ4 INT = 7,   
--@pStatement VARCHAR(25) = 'CSM',
--@pAccDate DATE = '2019-12-31',         
--@pUser VARCHAR(25) = 'Pooja Khandual',     
--@pRunType VARCHAR(25)   = 'Actual',
--@pQ4_PY int = 3;

--DROP FUNCTION [PWAPS].[udf_GetUnBalancedLC]

----SELECT sum(amount_diff) FROM [PWAPS].[udf_GetUnBalancedLC](3,4,0,0,0,'2019-03-31') --ORDER BY RI_Flag,UOA, Balance

----SELECT sum(amount_diff) FROM [PWAPS].[udf_GetUnBalancedLC_V2](3,4,0,0,0,'2019-03-31') --ORDER BY RI_Flag,UOA, Balance



CREATE FUNCTION [PWAPS].[udf_GetUnBalancedLC] (
        @pQ4_PY INT,              /* RunID for 4th Quarter-PreviousYear for YTD run and for QTD it will be the previous quarter Run ID */
        @pQ1 INT,                 /* RunID for 1st Quarter */
        @pQ2 INT,                 /* RunID for 2nd Quarter */
        @pQ3 INT,                 /* RunID for 3rd Quarter */
        @pQ4 INT,                 /* RunID for 4th Quarter */
        @pAccDate DATE,           /* Accounting DATE */
		@pJournalType Varchar(100) /* journal type i.e QTD Jurnal/YTD Journal*/

)

RETURNS TABLE
AS
RETURN

WITH UnbalancedLC AS
(		SELECT 
		RI_Flag, UOA,Balance, YOA, YOI, [Tri Focus Code],[IFRS17 Tri Focus Code], Entity,CCY,FocusGroup, Programme,	
		A.Q1_PY_Q4ClosedAmount, A.Q1_CY_Q1OpenAmount, A.Q2_CY_Q1ClosedAmount, A.Q2_CY_Q2OpenAmount, A.Q3_CY_Q2ClosedAmount, A.Q3_CY_Q3OpenAmount, A.Q4_CY_Q3ClosedAmount, A.Q4_CY_Q4OpenAmount

		FROM
		(
		SELECT 	RI_Flag, UOA,Balance, YOA, YOI, [Tri Focus Code],[IFRS17 Tri Focus Code], Entity,CCY,FocusGroup, Programme
				,SUM(
						CASE WHEN @pQ4_PY IS NOT NULL 
						   THEN CASE WHEN RunID = @pQ4_PY  AND  Position LIKE '%Closing%'
									THEN ROUND(Amount_disc, 2)
									ELSE 0
								END
						   ELSE 0
						END) Q1_PY_Q4ClosedAmount /* For YTD run, this value will have Q4 previous year closed amount. For QTD, it will have previous quarter closed amount*/
				,SUM(
						CASE WHEN @pQ1 IS NOT NULL 
						 THEN CASE WHEN RunID = @pQ1 AND  Position LIKE '%Open%'
									THEN ROUND(Amount_disc, 2)
									ELSE 0
								END
						 ELSE 0
						END)Q1_CY_Q1OpenAmount
				,SUM(
						CASE WHEN @pQ1 IS NOT NULL 
						   THEN CASE WHEN RunID = @pQ1 AND  Position LIKE '%Closing%'
									THEN ROUND(Amount_disc, 2)
									ELSE 0
								END
						   ELSE 0
						END) Q2_CY_Q1ClosedAmount
				,SUM(
						CASE WHEN @pQ2 IS NOT NULL 
						 THEN CASE WHEN RunID = @pQ2 AND  Position LIKE '%Open%'
									THEN ROUND(Amount_disc, 2)
									ELSE 0
								END
						 ELSE 0
						END)Q2_CY_Q2OpenAmount
				,SUM(
						CASE WHEN @pQ2 IS NOT NULL 
						   THEN CASE WHEN RunID = @pQ2 AND  Position LIKE '%Closing%'
									THEN ROUND(Amount_disc, 2)
									ELSE 0
								END
						   ELSE 0
						END)Q3_CY_Q2ClosedAmount
				,SUM(
						CASE WHEN @pQ3 IS NOT NULL 
						 THEN CASE WHEN RunID = @pQ3 AND  Position LIKE '%Open%'
									THEN ROUND(Amount_disc, 2)
									ELSE 0
								END
						 ELSE 0
						END) Q3_CY_Q3OpenAmount
				,SUM(
						 CASE WHEN @pQ3 IS NOT NULL 
						   THEN CASE WHEN RunID = @pQ3 AND  Position LIKE '%Closing%'
									THEN ROUND(Amount_disc, 2)
									ELSE 0
								END
						   ELSE 0
						END)Q4_CY_Q3ClosedAmount
				,SUM(
						CASE WHEN @pQ4 IS NOT NULL 
						 THEN CASE WHEN RunID = @pQ4 AND  Position LIKE '%Open%'
									THEN ROUND(Amount_disc, 2)
									ELSE 0
								END
						 ELSE 0
						END) Q4_CY_Q4OpenAmount
		FROM Reporting.CSM_Post_LCAdjustments T1
		WHERE RunID IN (@pQ1, @pQ2, @pQ3, @pQ4, @pQ4_PY)
		AND CSM_LC = 'LC'
		AND Balance <> 'CSM_LC'
		AND (Position LIKE '%Open%' OR Position LIKE '%Closing%')
		GROUP BY RI_Flag, UOA,Balance, YOA, YOI, [Tri Focus Code],[IFRS17 Tri Focus Code], Entity,CCY,FocusGroup, Programme
		)A
)

SELECT RI_Flag, UOA,Balance, YOA, YOI, [Tri Focus Code],[IFRS17 Tri Focus Code], Entity,CCY,FocusGroup, Programme ,
CASE WHEN @pJournalType = 'YTD'
		THEN CASE DATEPART(QUARTER, @pAccDate) 
				WHEN  1 THEN (Q1_PY_Q4ClosedAmount - Q1_CY_Q1OpenAmount)
				WHEN  2 THEN (Q1_PY_Q4ClosedAmount - Q1_CY_Q1OpenAmount) + (Q2_CY_Q1ClosedAmount - Q2_CY_Q2OpenAmount)
				WHEN  3 THEN (Q1_PY_Q4ClosedAmount - Q1_CY_Q1OpenAmount) + (Q2_CY_Q1ClosedAmount - Q2_CY_Q2OpenAmount) + (Q3_CY_Q2ClosedAmount - Q3_CY_Q3OpenAmount)
				WHEN  4 THEN (Q1_PY_Q4ClosedAmount - Q1_CY_Q1OpenAmount) + (Q2_CY_Q1ClosedAmount - Q2_CY_Q2OpenAmount) + (Q3_CY_Q2ClosedAmount - Q3_CY_Q3OpenAmount) + (Q4_CY_Q3ClosedAmount - Q4_CY_Q4OpenAmount)
			 END
		ELSE CASE DATEPART(QUARTER, @pAccDate) 
				WHEN  1 THEN (Q1_PY_Q4ClosedAmount - Q1_CY_Q1OpenAmount)
				WHEN  2 THEN (Q1_PY_Q4ClosedAmount - Q2_CY_Q2OpenAmount)
				WHEN  3 THEN (Q1_PY_Q4ClosedAmount - Q3_CY_Q3OpenAmount)
				WHEN  4 THEN (Q1_PY_Q4ClosedAmount - Q4_CY_Q4OpenAmount)
			 END

END Amount_Diff
FROM UnbalancedLC
WHERE
CASE WHEN @pJournalType = 'YTD'
		THEN CASE DATEPART(QUARTER, @pAccDate) 
				WHEN  1 THEN (Q1_PY_Q4ClosedAmount - Q1_CY_Q1OpenAmount)
				WHEN  2 THEN (Q1_PY_Q4ClosedAmount - Q1_CY_Q1OpenAmount) + (Q2_CY_Q1ClosedAmount - Q2_CY_Q2OpenAmount)
				WHEN  3 THEN (Q1_PY_Q4ClosedAmount - Q1_CY_Q1OpenAmount) + (Q2_CY_Q1ClosedAmount - Q2_CY_Q2OpenAmount) + (Q3_CY_Q2ClosedAmount - Q3_CY_Q3OpenAmount)
				WHEN  4 THEN (Q1_PY_Q4ClosedAmount - Q1_CY_Q1OpenAmount) + (Q2_CY_Q1ClosedAmount - Q2_CY_Q2OpenAmount) + (Q3_CY_Q2ClosedAmount - Q3_CY_Q3OpenAmount) + (Q4_CY_Q3ClosedAmount - Q4_CY_Q4OpenAmount)
			 END
		ELSE CASE DATEPART(QUARTER, @pAccDate) 
				WHEN  1 THEN (Q1_PY_Q4ClosedAmount - Q1_CY_Q1OpenAmount)
				WHEN  2 THEN (Q1_PY_Q4ClosedAmount - Q2_CY_Q2OpenAmount)
				WHEN  3 THEN (Q1_PY_Q4ClosedAmount - Q3_CY_Q3OpenAmount)
				WHEN  4 THEN (Q1_PY_Q4ClosedAmount - Q4_CY_Q4OpenAmount)
			 END
END <> 0