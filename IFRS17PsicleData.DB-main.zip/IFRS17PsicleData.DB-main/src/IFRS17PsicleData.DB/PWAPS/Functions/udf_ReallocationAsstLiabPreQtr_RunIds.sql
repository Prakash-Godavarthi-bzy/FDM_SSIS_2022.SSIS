﻿
--declare
--  @pAccDate DATE = '2024-06-30'
--, @RunId Varchar(50) = 'Actual_118_119_0_0'
--, @pJournalType Varchar(5) = 'ytd'

CREATE FUNCTION [PWAPS].[udf_ReallocationAsstLiabPreQtr_RunIds] (@pAccDate DATE, @RunId Varchar(50), @pJournalType Varchar(5))

RETURNS TABLE
AS
RETURN

WITH RunIDList AS
	(
	 SELECT DISTINCT RunIDs, AccountingDate
 	 FROM Reporting.JournalInputDataYTD
	 )

SELECT CASE WHEN @pJournalType = 'YTD'
			THEN
				--CASE DATEPART(QUARTER,@pAccDate)
				--			WHEN 4 THEN CONCAT(LEFT(@RunId, LEN(@RunId)-CHARINDEX('_',REVERSE(@RunId))), '_0')
				--			WHEN 3 THEN CONCAT(LEFT(@RunId, LEN(LEFT(@RunId, LEN(@RunId)-CHARINDEX('_',REVERSE(@RunId))))-CHARINDEX('_',REVERSE(LEFT(@RunId, LEN(@RunId)-CHARINDEX('_',REVERSE(@RunId)))))), '_0_0')
				--			WHEN 2 THEN CONCAT(
				--								LEFT(LEFT(@RunId, LEN(LEFT(@RunId, LEN(@RunId)-CHARINDEX('_',REVERSE(@RunId))))-CHARINDEX('_',REVERSE(LEFT(@RunId, LEN(@RunId)-CHARINDEX('_',REVERSE(@RunId))))))
				--									, LEN(LEFT(@RunId, LEN(LEFT(@RunId, LEN(@RunId)-CHARINDEX('_',REVERSE(@RunId))))-CHARINDEX('_',REVERSE(LEFT(@RunId, LEN(@RunId)-CHARINDEX('_',REVERSE(@RunId)))))))-CHARINDEX('_',REVERSE(LEFT(@RunId, LEN(LEFT(@RunId, LEN(@RunId)-CHARINDEX('_',REVERSE(@RunId))))-CHARINDEX('_',REVERSE(LEFT(@RunId, LEN(@RunId)-CHARINDEX('_',REVERSE(@RunId)))))))))
				--								, '_0_0_0'
				--								)
				--			WHEN 1 THEN 
							(SELECT MAX(RunIDs)
											FROM RunIDList
											WHERE RIGHT(RunIDs, (CHARINDEX('_',REVERSE(RunIDs))-1)) = (SELECT  [Opening Balances Id] 
																									FROM [$(IFRS17DataMart)].PWAPS.IFRS17CalcUI_RunLog
																									WHERE Pk_RequestId = LEFT(RIGHT(@RunId, LEN(@RunId) - CHARINDEX('_',@RunId)), CHARINDEX('_',RIGHT(@RunId, LEN(@RunId) - CHARINDEX('_',@RunId)))-1)))
						    --ELSE 'ACTUAL_0_0_0_0'
				--END 
			ELSE
				CASE DATEPART(QUARTER,@pAccDate)
					  WHEN 4 THEN (SELECT MAX(RunIDs)
								   FROM RunIDList
								   WHERE AccountingDate = CAST(DATEADD(dd, -1, DATEADD(qq, DATEDIFF(qq, 0, @pAccDate), 0)) AS DATE)
								   AND RIGHT(LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))
												,
											 CHARINDEX('_',
															 REVERSE(
																	LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))
																	)
														)-1
											 ) = (SELECT  [Opening Balances Id] 
												  FROM [$(IFRS17DataMart)].PWAPS.IFRS17CalcUI_RunLog
												  WHERE Pk_RequestId =  RIGHT( @RunId, CHARINDEX('_',REVERSE(@RunId))-1))
								 )
					  WHEN 3 THEN (SELECT MAX(RunIDs)
								   FROM RunIDList
								   WHERE AccountingDate = CAST(DATEADD(dd, -1, DATEADD(qq, DATEDIFF(qq, 0, @pAccDate), 0)) AS DATE)
								   AND 	RIGHT(
											LEFT(
												LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))
												,LEN(LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))) 
														-
														CHARINDEX('_',
																		REVERSE(
																			LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))
																			)
																)
												)
   										,CHARINDEX('_'
													,REVERSE
														(
											/**/	     LEFT(
															LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))
															,LEN(LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))) 
																	-
																	CHARINDEX('_',
																					REVERSE(
																						LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))
																						)
																			)
											/**/				)
															)
													)-1
										) = (SELECT  [Opening Balances Id] 
												  FROM [$(IFRS17DataMart)].PWAPS.IFRS17CalcUI_RunLog
												  WHERE Pk_RequestId =  RIGHT(LEFT( @RunId, (LEN(@RunId)- CHARINDEX('_',REVERSE(@RunId)))), (CHARINDEX('_',REVERSE(LEFT( @RunId, (LEN(@RunId)- CHARINDEX('_',REVERSE(@RunId))))))-1))
										    )
								 )
					 WHEN 2 THEN (SELECT MAX(RunIDs)
								   FROM RunIDList
								   WHERE AccountingDate = CAST(DATEADD(dd, -1, DATEADD(qq, DATEDIFF(qq, 0, @pAccDate), 0)) AS DATE)
								   AND 	RIGHT(
												LEFT(
													LEFT(
														LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))
														,LEN(LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))) 
																-
																CHARINDEX('_',
																				REVERSE(
																					LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))
																					)
																		)
														)
   												,LEN(LEFT(
														LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))
														,LEN(LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))) 
																-
																CHARINDEX('_',
																				REVERSE(
																					LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))
																					)
																		)
														))
														-
														CHARINDEX('_'
																	,REVERSE
																		(
															/**/	     LEFT(
																			LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))
																			,LEN(LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))) 
																					-
																					CHARINDEX('_',
																									REVERSE(
																										LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))
																										)
																							)
															/**/				)
																			)
																	)
												)					
												,CHARINDEX('_'
													,REVERSE(
																LEFT(
																	LEFT(
																		LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))
																		,LEN(LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))) 
																				-
																				CHARINDEX('_',
																								REVERSE(
																									LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))
																									)
																						)
																		)
   																,LEN(LEFT(
																		LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))
																		,LEN(LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))) 
																				-
																				CHARINDEX('_',
																								REVERSE(
																									LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))
																									)
																						)
																		))
																		-
																		CHARINDEX('_'
																					,REVERSE
																						(
																			/**/	     LEFT(
																							LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))
																							,LEN(LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))) 
																									-
																									CHARINDEX('_',
																													REVERSE(
																														LEFT(RunIDs,LEN(RunIDs)-CHARINDEX('_',REVERSE(RunIDs)))
																														)
																											)
																			/**/				)
																							)
																					)
																)
															)
													)-1	) = (SELECT  [Opening Balances Id] 
															 FROM [$(IFRS17DataMart)].PWAPS.IFRS17CalcUI_RunLog
															 WHERE Pk_RequestId =  RIGHT(LEFT(LEFT( @RunId, (LEN(@RunId)- CHARINDEX('_',REVERSE(@RunId)))), (LEN(LEFT( @RunId, (LEN(@RunId)- CHARINDEX('_',REVERSE(@RunId))))) - (CHARINDEX('_',REVERSE(LEFT( @RunId, (LEN(@RunId)- CHARINDEX('_',REVERSE(@RunId)))))))))
																						,CHARINDEX('_', REVERSE(LEFT(LEFT( @RunId, (LEN(@RunId)- CHARINDEX('_',REVERSE(@RunId)))), (LEN(LEFT( @RunId, (LEN(@RunId)- CHARINDEX('_',REVERSE(@RunId))))) - (CHARINDEX('_',REVERSE(LEFT( @RunId, (LEN(@RunId)- CHARINDEX('_',REVERSE(@RunId)))))))))))-1)
															)
													 )
					WHEN 1  THEN    (SELECT MAX(RunIDs)
											FROM RunIDList
											WHERE RIGHT(RunIDs, CHARINDEX('_',REVERSE(RunIDs))-1)
														=  
														(SELECT  [Opening Balances Id] 
														FROM [$(IFRS17DataMart)].PWAPS.IFRS17CalcUI_RunLog
														WHERE Pk_RequestId =  LEFT(RIGHT(@RunId, (LEN(@RunId)-CHARINDEX('_',(@RunId)))) ,CHARINDEX('_',RIGHT(@RunId, (LEN(@RunId)-CHARINDEX('_',(@RunId)))))-1))
									)
					ELSE 'ACTUAL_0_0_0_0'
				END

		END AS PreQtrRunId
,  CASE WHEN  @pJournalType = 'YTD' 
		THEN CAST(DATEADD(DAY,-1,DATEADD(YEAR,DATEDIFF(YEAR,0,@pAccDate),0)) AS DATE)
		ELSE CAST(DATEADD(dd, -1, DATEADD(qq, DATEDIFF(qq, 0, @pAccDate), 0)) AS DATE) 
	END as PreQtrAccDt