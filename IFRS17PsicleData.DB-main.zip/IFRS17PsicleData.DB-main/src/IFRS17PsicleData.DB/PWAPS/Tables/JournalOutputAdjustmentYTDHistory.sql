﻿CREATE TABLE [PWAPS].[JournalOutputAdjustmentYTDHistory] (
    [ID]                      BIGINT        NOT NULL,
    [RunIDs]                  VARCHAR (50)  NULL,
    [AccountingDate]          DATE          NULL,
    [DiscUndiscType]          VARCHAR (20)  NULL,
    [AgressoIFRS17ClientCode] VARCHAR (255) NULL,
    [Statement]               VARCHAR (50)  NOT NULL,
    [RI_Flag]                 VARCHAR (2)   NULL,
    [CCY]                     VARCHAR (10)  NULL,
    [UserApprovedCheck]       BIT           NULL,
    [AuthorityApprovedCheck]  BIT           NULL,
    [ApprovedUser]            VARCHAR (25)  NULL,
    [AuthorityUser]           VARCHAR (25)  NULL,
    [AuditUser]               VARCHAR (25)  NULL,
    [AuditCreateDatetime]     DATETIME2 (7) NULL,
    [ValidFrom]               DATETIME2 (7) NOT NULL,
    [ValidTo]                 DATETIME2 (7) NOT NULL
);




GO
CREATE CLUSTERED INDEX [ix_JournalOutputAdjustmentYTDHistory]
    ON [PWAPS].[JournalOutputAdjustmentYTDHistory]([ValidTo] ASC, [ValidFrom] ASC);

