﻿CREATE TABLE [PWAPS].[JournalAuditLog] (
    [PK_JournalAuditLogID]  BIGINT         IDENTITY (1, 1) NOT NULL,
    [RunIDs]                VARCHAR (100)  NOT NULL,
    [Statement]             VARCHAR (10)   NOT NULL,
    [AccountingDate]        DATE           NOT NULL,
    [InitiatedUser]         VARCHAR (100)  NOT NULL,
    [RunType]               VARCHAR (25)   NOT NULL,
    [JournalType]           VARCHAR (10)   NOT NULL,
    [GenerateYTD]           VARCHAR (10)   NOT NULL,
    [GenerateCSMLC]         VARCHAR (10)   NOT NULL,
    [AdjustmentJournal]     VARCHAR (10)   NOT NULL,
    [GrossUpJournal]        VARCHAR (10)   NOT NULL,
    [ExperienceJournal]     VARCHAR (10)   NOT NULL,
    [JournalReAllocation]   VARCHAR (10)   NOT NULL,
    [ErrorDetails]          NVARCHAR (MAX) NULL,
    [AuditCreateDate]       DATETIME       DEFAULT (getdate()) NULL,
    [ValidityFlag]          BIT            NOT NULL,
    [JournalOutputFinal]    VARCHAR (10)   DEFAULT ('Pending') NOT NULL,
    [JournalOutputRowCount] BIGINT         DEFAULT ((0)) NOT NULL,
    [CSM_Disc_Expr_Adj]     VARCHAR (10)   DEFAULT ('Pending') NOT NULL,
    PRIMARY KEY CLUSTERED ([PK_JournalAuditLogID] ASC) WITH (FILLFACTOR = 90)
);



