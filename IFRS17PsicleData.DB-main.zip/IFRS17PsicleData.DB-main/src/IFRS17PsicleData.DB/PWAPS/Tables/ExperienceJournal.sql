﻿CREATE TABLE [PWAPS].[ExperienceJournal] (
    [ID]                    BIGINT        IDENTITY (1, 1) NOT NULL,
    [RunIDs]                VARCHAR (50)  NULL,
    [AccountingDate]        DATE          NULL,
    [RI_Flag]               VARCHAR (2)   NULL,
    [Balance]               VARCHAR (50)  NOT NULL,
    [Position]              VARCHAR (50)  NOT NULL,
    [AccountCodePositiveVE] VARCHAR (25)  NULL,
    [AccountCodeNegativeVE] VARCHAR (25)  NULL,
    [AuditUser]             VARCHAR (25)  NULL,
    [AuditCreateDatetime]   DATETIME2 (7) NULL,
    [ExprType]              VARCHAR (50)  NULL,
    CONSTRAINT [PK_ExperienceJournal_ID] PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);



