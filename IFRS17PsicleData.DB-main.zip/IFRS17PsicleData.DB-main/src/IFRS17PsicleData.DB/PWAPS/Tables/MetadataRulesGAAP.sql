﻿CREATE TABLE [PWAPS].[MetadataRulesGAAP] (
    [ID]                  INT           IDENTITY (1, 1) NOT NULL,
    [AccountCode]         VARCHAR (25)  NULL,
    [Attribute]           VARCHAR (100) NULL,
    [TransformationType]  VARCHAR (100) NULL,
    [TransformationValue] VARCHAR (512) NULL,
    [AuditUser]           VARCHAR (25)  NULL,
    [AuditCreateDatetime] DATETIME2 (7) NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);

