﻿CREATE TABLE [PWAPS].[ReallocationExceptions] (
    [RunIDs]                  VARCHAR (50) NULL,
    [AccountingDate]          VARCHAR (10) NULL,
    [Statement]               VARCHAR (50) NOT NULL,
    [RI_Flag]                 VARCHAR (2)  NULL,
    [Balance]                 VARCHAR (50) NOT NULL,
    [AccountCode_Undisc_Pos]  VARCHAR (25) NULL,
    [AccountCode_Undisc_Neg]  VARCHAR (25) NULL,
    [AccountCode_Disc_Pos]    VARCHAR (25) NULL,
    [AccountCode_Disc_Neg]    VARCHAR (25) NULL,
    [AccountCode_ReAlloc_Pos] VARCHAR (25) NULL,
    [AccountCode_ReAlloc_Neg] VARCHAR (25) NULL
);

