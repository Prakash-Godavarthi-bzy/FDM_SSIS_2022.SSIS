﻿CREATE TABLE [PWAPS].[RunScheduleJob] (
    [JobName]             VARCHAR (150) NOT NULL,
    [RunStatusFlag]       TINYINT       NOT NULL,
    [RunIDs]              VARCHAR (50)  NULL,
    [AccountingDate]      VARCHAR (10)  NULL,
    [version]             INT           NULL,
    [AuditUser]           VARCHAR (25)  NULL,
    [AuditCreateDatetime] DATETIME2 (7) NULL
);



