﻿
CREATE PROCEDURE [Inbound].[usp_MergeOpenUoAOB]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO [Results].[OpenUoAOB](
		       RunID
			  ,[TFYOI]
			  ,[Entity]
			  ,FocusGroup
			  ,[UOA]
			  ,[YOI]
			  ,[Programme]
			  ,[Tri focus code]
			  ,[Tri focus]
			  ,[TFUOA]
			  ,[Onerosity]
			  ,[CSM_LC]
			  )
		SELECT 
		       T1.[RunId]
			  ,T1.[TFYOI]
			  ,T1.[Entity]
			  ,T1.[Focus_Group]
			  ,T1.UoA
			  ,T1.YoI
			  ,T1.[Programme]
			  ,T1.[Tri Focus Code]
			  ,T1.[trifocus]
			  ,T1.[TFUOA]
			  ,T1.[Onerosity]
			  ,T1.[CSM_LC]
		FROM [Inbound].[stg_OpenUoAOB] T1
		--LEFT JOIN [Results].[OpenUoAOB] T2 ON T1.[RunId]= T2.RunID
		--WHERE T1.RunID NOT IN (SELECT DISTINCT RunID FROM [Results].OpenUoAOB)
		LEFT JOIN (SELECT DISTINCT RunID FROM [Results].OpenUoAOB) T2 ON T1.RunID=T2.RunID
	    WHERE T2.RunID IS NULL
		

	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END
GO