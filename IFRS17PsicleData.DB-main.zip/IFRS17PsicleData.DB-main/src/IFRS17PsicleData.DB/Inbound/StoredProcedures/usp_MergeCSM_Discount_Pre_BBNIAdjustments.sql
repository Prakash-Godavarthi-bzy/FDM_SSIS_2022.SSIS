CREATE PROCEDURE [Inbound].[usp_MergeCSM_Discount_Pre_BBNIAdjustments]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO [Reporting].[CSM_Discount_Pre_BBNIAdjustments](
			 [RunID]
			,[Entity]
			,[Tri Focus Code]
			,[IFRS17 Tri Focus Code]
			,[Programme]
			,[RI_Flag]
			,[YOA]
			,[YOI]
			,[QOI_End_Date]
			,[CCY]
			,[Incepted Status]
			,[Statement]
			,[Balance]
			,[Position]
			,[Amount]
			,[Amount_disc]
			,[Conv_Amount]
			,[Conv_Amount_disc]
			  )
		SELECT 

			 T1. [RunID]
			,T1.[Entity]
			,T1.[Tri Focus Code]
			,T1.[IFRS17 Tri Focus Code]
			,T1.[Programme]
			,T1.[RI_Flag]
			,T1.[YoA]
			,T1.[YoI]
			,T1.[QOI_END_DATE]
			,T1.[CCY]
			,T1.[Incepted Status]
			,T1.[Statement]
			,T1.[Balance]
			,T1.[Position]
			,T1.[Amount]
			,T1.[Amount_disc]
			,T1.[Conv_Amount]
			,T1.[Conv_Amount_disc]
	  
		FROM [Inbound].[stg_CSM_Discount_Pre_BBNIAdjustments] T1
		
		--WHERE T1.RunID NOT IN (SELECT DISTINCT RunID FROM [Reporting].[CSM_Discount_Pre_BBNIAdjustments])
		LEFT JOIN (SELECT DISTINCT RunID FROM [Reporting].[CSM_Discount_Pre_BBNIAdjustments]) T2 ON T1.RunID=T2.RunID
	    WHERE T2.RunID IS NULL
		
		
	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END


