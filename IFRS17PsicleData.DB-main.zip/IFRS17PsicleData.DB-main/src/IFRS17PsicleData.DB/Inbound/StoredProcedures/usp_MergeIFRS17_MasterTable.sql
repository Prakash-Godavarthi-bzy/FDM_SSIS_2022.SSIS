CREATE PROCEDURE [Inbound].[usp_MergeIFRS17_MasterTable]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

	INSERT INTO [Reporting].[IFRS17_MasterTable](
			 
			RunID
           ,[Reporting Period]
           ,Tag   
           ,Entity  
           ,[Tri Focus Code] 
           ,[IFRS17 Tri Focus Code]   
           ,[Focus Group]
           ,Division    
           ,Programme  
           ,[RI_Flag] 
           ,YoA 
           ,YoI 
           ,[QOI_END_DATE]  
           ,CCY 
           ,[Incepted Status]  
           ,Account   
           ,Prem_type    
           ,DataSet   
           ,[Statement]  
           ,Balance 
           ,Position  
           ,RecognitionType
           ,[OpenClosed] 
           ,Assumption
           ,LossType 
           ,[Quarter]
           ,LookupField   
           ,Amount 
           ,Amount_disc  
           ,Conv_Amount  
           ,Conv_Amount_disc
			
			  )
		SELECT 
		    T1.RunID
           ,T1.[Reporting Period]
           ,T1.Tag   
           ,T1.Entity  
           ,T1.[Tri Focus Code] 
           ,T1.[IFRS17 Tri Focus Code]   
           ,T1.[Focus Group]
           ,T1.Division    
           ,T1.Programme  
           ,T1.[RI_Flag] 
           ,T1.YoA 
           ,T1.YoI 
           ,T1.[QOI_END_DATE]  
           ,T1.CCY 
           ,T1.[Incepted Status]  
           ,T1.Account   
           ,T1.Prem_type    
           ,T1.DataSet   
           ,T1.[Statement]  
           ,T1.Balance 
           ,T1.Position  
           ,T1.RecognitionType
           ,T1.[OpenClosed] 
           ,T1.Assumption
           ,T1.LossType 
           ,T1.[Quarter]
           ,T1.LookupField   
           ,T1.Amount 
           ,T1.Amount_disc  
           ,T1.Conv_Amount  
           ,T1.Conv_Amount_disc
			
  
		FROM [Inbound].[stg_IFRS17_MasterTable] T1
		LEFT JOIN (SELECT DISTINCT RunID FROM [Reporting].[IFRS17_MasterTable]) T2 ON T1.RunID = T2.RunID
		WHERE T2.RunID IS NULL

		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END
