
CREATE PROCEDURE [Inbound].[usp_MergePremiumAdjustments]
AS                        

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO [Results].[PremiumAdjustments](
			   [RunID]
			  ,[Entity]
			  ,[Tri Focus Code]
			  ,[IFRS17 TrifocusCode]  
			  ,[Account]
			  ,[Programme]
			  ,[RI_Flag]
			  ,[YOA]
			  ,[YOI]
			  ,[QOI_End_Date]
			  ,[RecognitionType]
			  ,[CCY]
			  ,[Incepted Status]
			  ,[Open / Closed]
			  ,[Amount]

			  )
		SELECT 
			   T1.[RunID]
			  ,T1.[Entity]
			  ,T1.[Tri Focus Code]
			  ,T1.[IFRS17 Tri Focus Code]
			  ,T1.[Account]
			  ,T1.[Programme]
			  ,T1.[RI_Flag]
			  ,T1.[YoA]
			  ,T1.[YoI]
			  ,T1.[QOI_END_DATE]
			  ,T1.[RecognitionType]
			  ,T1.[CCY]
			  ,T1.[Incepted Status]
			  ,T1.[Open_Closed]
			  ,T1.[Amount]
			  
		FROM [Inbound].[stg_PremiumAdjustments] T1
		
		--WHERE T1.RunID NOT IN (SELECT DISTINCT RunID FROM [Results].[PremiumAdjustments])
		LEFT JOIN (SELECT DISTINCT RunID FROM [Results].[PremiumAdjustments]) T2 ON T1.RunID=T2.RunID
	    WHERE T2.RunID IS NULL
		
		
	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END