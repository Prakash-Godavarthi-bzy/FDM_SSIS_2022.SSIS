CREATE PROCEDURE [Inbound].[usp_MergeLRC_UndiscountedData]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO [Reporting].[LRC_UndiscountedData](
                 [RunID]					
				,[Entity]
				,[Tri Focus Code]
				,[IFRS17 Tri Focus Code]
				,[Programme]
				,[RI_Flag]
				,[YOA]
				,[YOI]
				,[QOI_End_Date]
				,[CCY]
				,[Incepted Status]
				,[Statement]
				,[Position]
				,[Balance]
				,[Amount]	
				,[Unadjusted_Amount]
			  )
		SELECT 
			     T1.[RunID]					
			    ,T1.[Entity]
				,T1.[Tri Focus Code]
				,T1.[IFRS17 Tri Focus Code]
				,T1.[Programme]
				,T1.[RI_Flag]
				,T1.[YoA]
				,T1.[YoI]
				,T1.[QOI_END_DATE]
				,T1.[CCY]
				,T1.[Incepted Status]
				,T1.[Statement]
				,T1.[Position]
				,T1.[Balance]
				,T1.[Amount]	
				,T1.[Unadjusted_Amount]
		FROM [Inbound].[stg_LRC_UndiscountedData] T1
		--WHERE T1.RunID NOT IN (SELECT DISTINCT RunID FROM [Reporting].[LRC_UndiscountedData])
		LEFT JOIN (SELECT DISTINCT RunID FROM [Reporting].[LRC_UndiscountedData]) T2 ON T1.RunID=T2.RunID
	    WHERE T2.RunID IS NULL

	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END




