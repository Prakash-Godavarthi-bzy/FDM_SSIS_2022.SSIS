﻿

CREATE PROCEDURE [Inbound].[usp_MergeYieldCurveOB]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO [Results].[YieldCurveOB]
			  ([OBFlag]
			  ,RunID
			  ,[Asat]
			  ,[CCY]
			  ,[Qtr]
			  ,[Rate]
			  
			  )
		SELECT 
			   T1.[OBFlag]
			  ,T1.RunID
			  ,T1.Asat--DATEFROMPARTS(RIGHT(T1.[Asat],4),SUBSTRING(T1.[Asat], 4,2) ,LEFT(T1.[Asat],2))
			  ----,CONVERT(INT,CONCAT(RIGHT(T1.[Asat],4)  ,RIGHT('00'+SUBSTRING(T1.[Asat], 4,2),2))) AS [Asat]
			  ,T1.[CCY]
			  ,T1.[Qtr]
			  ,T1.[Rate]
			  
		FROM [Inbound].[stg_YieldCurveOB] T1
		--LEFT JOIN [Results].[YieldCurveOB] T2 ON T1.RunID = T2.RunID
		--WHERE T1.RunID NOT IN (SELECT DISTINCT RunID FROM [Results].[YieldCurveOB])
		LEFT JOIN (SELECT DISTINCT RunID FROM [Results].[YieldCurveOB]) T2 ON T1.RunID=T2.RunID
	    WHERE T2.RunID IS NULL

	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END