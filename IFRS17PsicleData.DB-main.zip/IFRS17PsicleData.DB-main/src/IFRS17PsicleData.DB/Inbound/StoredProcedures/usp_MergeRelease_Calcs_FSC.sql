
CREATE PROCEDURE [Inbound].[usp_MergeRelease_Calcs_FSC]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO [Results].[Release_Calcs_FSC](
			   [RunID]
			  ,[Entity]
			  ,[Tri focus code]
			  ,[IFRS17 TrifocusCode]
			  ,[Account]
			  ,[Programme]
			  ,[RI_Flag]
			  ,[YOA]
			  ,[YOI]
			  ,[QOI_End_Date]
			  ,[RecognitionType]
			  ,[CCY]
			  ,[Incepted Status]
			  ,[Open / Closed]
			  ,[Closing balances of release remaining Att]
			  ,[Closing balances of release remaining Cat]

			  )
		SELECT 
			   T1.[RunID]
			  ,T1.[Entity]
			  ,T1.[Tri Focus Code]
			  ,T1.[IFRS17 Tri Focus Code]
			  ,T1.[Account]
			  ,T1.[Programme]
			  ,T1.[RI_Flag]
			  ,T1.[YoA]
			  ,T1.[YoI]
			  ,T1.[QOI_END_DATE]
			  ,T1.[RecognitionType]
			  ,T1.[CCY]
			  ,T1.[Incepted Status]
			  ,T1.[Open_Closed]
			  ,T1.[Closing balances of release remaining Att]
			  ,T1.[Closing balances of release remaining Cat]

			  
		FROM [Inbound].[stg_Release_Calcs_FSC] T1
		
		--WHERE T1.RunID NOT IN (SELECT DISTINCT RunID FROM [Results].[Release_Calcs_FSC])
		LEFT JOIN (SELECT DISTINCT RunID FROM [Results].[Release_Calcs_FSC]) T2 ON T1.RunID=T2.RunID
	    WHERE T2.RunID IS NULL
		
		
	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END