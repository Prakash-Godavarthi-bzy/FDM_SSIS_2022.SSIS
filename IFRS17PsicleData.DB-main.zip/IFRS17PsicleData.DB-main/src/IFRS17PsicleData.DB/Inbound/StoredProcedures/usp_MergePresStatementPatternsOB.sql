﻿
CREATE PROCEDURE [Inbound].[usp_MergePresStatementPatternsOB]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO [Results].[PresStatementPatternsOB](
			   [RunID]
			  ,[Entity]
			  ,[Tri focus code]
			  ,[IFRS17 Tri focus code]
			  ,[Account]
			  ,[Programme]
			  ,[RI_Flag]
			  ,[YOI]
			  ,[CCY]
			  ,[Qtr]
			  ,[Perc]
			  )
		SELECT 
			   T1.[RunID]
			  ,T1.[Entity]
			  ,T1.[Tri Focus]
			  ,T1.[IFRS17 Tri Focus Code]
			  ,T1.[Account]
			  ,T1.[Programme]
			  ,T1.[RI_Flag]
			  ,T1.[YOI]
			  ,T1.[CCY]
			  ,T1.[Qtr]
			  ,T1.[Perc]
		FROM [Inbound].[stg_PresStatementPatternsOB] T1
		--LEFT JOIN [Results].[PresStatementPatternsOB] T2 ON T1.[RunID]= T2.[RunID]
		--WHERE T1.RunID NOT IN (SELECT DISTINCT RunID FROM [Results].[PresStatementPatternsOB])
		LEFT JOIN (SELECT DISTINCT RunID FROM [Results].[PresStatementPatternsOB]) T2 ON T1.RunID=T2.RunID
	    WHERE T2.RunID IS NULL



	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END