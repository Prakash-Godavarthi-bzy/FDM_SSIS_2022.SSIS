CREATE PROCEDURE [Inbound].[usp_MergeCSM_CloseUOAPostSub]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO [Reporting].[CSM_CloseUOAPostSub](
			   [RunID]					
			  ,[TFYOI]					
			  ,[Entity]				
			  ,[FocusGroup]			
			  ,[UOA]					
			  ,[YOI]					
			  ,[Programme]				
			  ,[IFRS17 Tri Focus Code] 
			  ,[Trifocus]				
			  ,[TFUOA]					
			  ,[Onerosity]				
			  ,[CSM_LC]						  
			  )
		SELECT 
			   T1.[RunID]					
			  ,T1.[TFYOI]					
			  ,T1.[Entity]				
			  ,T1.[Focus_Group]			
			  ,T1.[UoA]					
			  ,T1.[YoI]					
			  ,T1.[Programme]				
			  ,T1.[IFRS17 Tri Focus Code] 
			  ,T1.[trifocus]				
			  ,T1.[TFUOA]					
			  ,T1.[Onerosity]				
			  ,T1.[CSM_LC]				
			  
		FROM [Inbound].[stg_CSM_CloseUOAPostSub] T1		
		--WHERE T2.RunID NOT IN (SELECT DISTINCT RunID FROM [Reporting].[CSM_CloseUOAPostSub])
		LEFT JOIN (SELECT DISTINCT RunID FROM [Reporting].[CSM_CloseUOAPostSub]) T2 ON T1.RunID=T2.RunID
	    WHERE T2.RunID IS NULL
		
		
	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END



