﻿

CREATE PROCEDURE [Inbound].[usp_MergeHistLockRatesOB]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO [Results].HistLockRatesOB
			  (
			  RunID
			 ,YOI
			 ,[Programme]
			 ,[FocusGroup]
			 ,[CCY]
			 ,[Qtr]
			 ,[Rate]
			  )
		SELECT 
			   T1.RunID
			  ,T1.YoI
			  ,T1.[Programme]
			  ,T1.[FocusGroup]
			  ,T1.[CCY]
			  ,T1.[Qtr]
			  ,CASE WHEN T1.[Rate] IS NULL THEN 0 ELSE T1.[Rate] END
			  
		FROM [Inbound].[stg_HistLockRatesOB] T1
		--LEFT JOIN [Results].HistLockRatesOB T2 ON T1.RunID = T2.RunID
		--WHERE T1.RunID NOT IN (SELECT DISTINCT RunID FROM [Results].HistLockRatesOB)
		LEFT JOIN (SELECT DISTINCT RunID FROM [Results].HistLockRatesOB) T2 ON T1.RunID=T2.RunID
	    WHERE T2.RunID IS NULL

		
	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END