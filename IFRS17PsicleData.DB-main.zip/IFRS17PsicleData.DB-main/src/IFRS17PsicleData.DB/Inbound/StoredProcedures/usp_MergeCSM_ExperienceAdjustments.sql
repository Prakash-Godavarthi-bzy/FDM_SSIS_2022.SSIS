﻿CREATE PROCEDURE [Inbound].[usp_MergeCSM_ExperienceAdjustments]
AS
 
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
 
		INSERT INTO [Reporting].[CSM_ExperienceAdjustments](
			   [RunID]
			  ,[Entity]
			  ,[TriFocusCode]
			  ,[IFRS17TriFocusCode]
			  ,[Balance]
			  ,[Programme]
			  ,[RI_Flag]
			  ,[YoA]
			  ,[YoI]
			  ,[QOI_END_DATE]
			  ,[CCY]
			  ,[Incpeted_Status]
			  ,[Position]
			  ,[UoA]
			  ,[Focus_Group]
			  ,[Undisc_CSM]
			  ,[Undisc_LRC]
			  ,[Disc_locked_CSM]
			  ,[Disc_current_CSM]
			  ,[Disc_LRC]
			  ,[Undisc_Exp_Adj]
			  ,[Disc_current_exp_adj]
			  ,[IFIE_Locked_CSM_to_Current_diff]
			  ,[Conv_Undisc_CSM]
			  ,[Conv_Undisc_LRC]
			  ,[Conv_Disc_locked_CSM]
			  ,[Conv_Disc_Current_CSM]
			  ,[Conv_Disc_LRC]
			  ,[Conv_Undisc_exp_adj]
			  ,[Conv_Disc_current_exp_adj]
			  ,[Conv_IFIE_Locked_CSM_to_Current_diff]
			  )
		SELECT 
				T1.[RunID]
			  ,T1.[Entity]
			  ,T1.[TriFocusCode]
			  ,T1.[IFRS17TriFocusCode]
			  ,T1.[Balance]
			  ,T1.[Programme]
			  ,T1.[RI_Flag]
			  ,T1.[YoA]
			  ,T1.[YoI]
			  ,T1.[QOI_END_DATE]
			  ,T1.[CCY]
			  ,T1.[Incpeted_Status]
			  ,T1.[Position]
			  ,T1.[UoA]
			  ,T1.[Focus_Group]
			  ,T1.[Undisc_CSM]
			  ,T1.[Undisc_LRC]
			  ,T1.[Disc_locked_CSM]
			  ,T1.[Disc_current_CSM]
			  ,T1.[Disc_LRC]
			  ,T1.[Undisc_Exp_Adj]
			  ,T1.[Disc_current_exp_adj]
			  ,T1.[IFIE_Locked_CSM_to_Current_diff]
			  ,T1.[Conv_Undisc_CSM]
			  ,T1.[Conv_Undisc_LRC]
			  ,T1.[Conv_Disc_locked_CSM]
			  ,T1.[Conv_Disc_Current_CSM]
			  ,T1.[Conv_Disc_LRC]
			  ,T1.[Conv_Undisc_exp_adj]
			  ,T1.[Conv_Disc_current_exp_adj]
			  ,T1.[Conv_IFIE_Locked_CSM_to_Current_diff]
					FROM [Inbound].[stg_CSM_ExperienceAdjustments] T1		
					--WHERE T1.RunID NOT IN (SELECT DISTINCT RunID FROM [Reporting].[CSM_Discount_Post_BBNIAdjustments])
					LEFT JOIN (SELECT DISTINCT RunID FROM [Reporting].[CSM_ExperienceAdjustments]) T2 ON T1.RunID=T2.RunID
					WHERE T2.RunID IS NULL

	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
 
END
