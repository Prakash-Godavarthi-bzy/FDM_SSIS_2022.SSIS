﻿
CREATE PROCEDURE [Inbound].[usp_MergeOpenClosedOB]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO [Results].[OpenClosedOB]
			  (
			  [RunID]
			 ,[Programme]
			 ,[Tri focus code]
			 ,[YOA]
			 ,[Open/Closed Derivation])
		SELECT 
			   T1.RunID
			  ,T1.[Programme]
			  ,T1.Trifocus
			  ,T1.[YOA]
			  ,T1.[Open_Closed derivation]
		FROM [Inbound].[stg_OpenClosedOB] T1
		--LEFT JOIN [Results].[OpenClosedOB] T2 ON T1.RunID = T2.[RunID]
		--WHERE T1.RunID NOT IN (SELECT DISTINCT RunID FROM [Results].OpenClosedOB)
		LEFT JOIN (SELECT DISTINCT RunID FROM [Results].OpenClosedOB) T2 ON T1.RunID=T2.RunID
	    WHERE T2.RunID IS NULL
	
		
	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END