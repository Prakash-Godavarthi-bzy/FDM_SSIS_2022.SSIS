﻿
CREATE PROCEDURE [Inbound].[usp_MergeUndiscCSMWalkBalancesOB]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO [Results].[UndiscCSMWalkBalancesOB]
			  ([RunID]
			  ,[Entity]
			  ,[Tri focus code]
			  ,[IFRS17 Tri focus code]
			  ,[Programme]
			  ,[RI_Flag]
			  ,YOA
			  ,YOI
			  ,QOI_End_Date
			  ,[CCY]
			  ,[InceptedStatus]
			  ,[Amount]
			  ,[Statement]
			  ,[Position]
			  ,[Balance]
			  ,Amount_disc
			  )
		SELECT 
			   T1.[RunID]
			  ,T1.[Entity]
			  ,T1.[Tri Focus Code]
			  ,T1.[IFRS17 Tri Focus Code]
			  ,T1.[Programme]
			  ,T1.[RI_Flag]
			  ,T1.[YoA]
			  ,T1.[YoI]
			  ,T1.[QOI_END_DATE]
			  ,T1.[CCY]
			  ,T1.[Incepted Status]
			  ,T1.[Amount]
			  ,T1.[Statement]
			  ,T1.[Position]
			  ,T1.[Balance]
			  ,T1.Amount_disc
		FROM [Inbound].[stg_UndiscCSMWalkBalancesOB] T1
	    --WHERE T1.RunID NOT IN (SELECT DISTINCT RunID FROM [Results].[UndiscCSMWalkBalancesOB])
		LEFT JOIN (SELECT DISTINCT RunID FROM [Results].[UndiscCSMWalkBalancesOB]) T2 ON T1.RunID=T2.RunID
	    WHERE T2.RunID IS NULL


	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END