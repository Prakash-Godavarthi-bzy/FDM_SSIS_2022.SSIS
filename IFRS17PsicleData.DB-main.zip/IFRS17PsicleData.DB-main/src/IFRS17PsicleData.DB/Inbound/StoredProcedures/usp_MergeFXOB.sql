﻿--USE [IFRS17PsicleData]
--GO

--/****** Object:  StoredProcedure [Inbound].[usp_MergeFXOB]    Script Date: 25/05/2022 11:55:05 ******/
--SET ANSI_NULLS OFF
--GO

--SET QUOTED_IDENTIFIER OFF
--GO

CREATE PROCEDURE [Inbound].[usp_MergeFXOB]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO [Results].[FXOB]
			  ([OBFlag]
			  ,[RunID]
			  ,[FXRatetype]
			  ,[CCY]
			  ,[RepCCY]
			  ,[FXRate]
			  
			  )
		SELECT 
			   T1.[OBFlag]
			  ,T1.[RunID]
			  ,T1.[FXRatetype]
			  ,T1.[CCY]
			  ,T1.[RepCCY]
			  ,T1.[FXRate]
			  
		FROM [Inbound].[stg_FXOB] T1
		--LEFT JOIN [Results].[FXOB] T2 ON T1.RunID = T2.RunID
		--WHERE T1.RunID NOT IN (SELECT DISTINCT RunID FROM [Results].FXOB)	
		LEFT JOIN (SELECT DISTINCT RunID FROM [Results].[FXOB]) T2 ON T1.RunID=T2.RunID
	    WHERE T2.RunID IS NULL

	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END