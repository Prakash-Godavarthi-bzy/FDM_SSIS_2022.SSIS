﻿
CREATE PROCEDURE [Inbound].[usp_MergeAgresso_uviattrvalues]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

        DELETE FROM [Reporting].[Agresso_uviattrvalues];

		INSERT INTO [Reporting].[Agresso_uviattrvalues](
			 [DimensionID], 
             [DimensionName], 
             [Description], 
             [AttributeCode], 
             [AttributeName], 
             [Status]
           )
		SELECT 
			 T1.[DimensionID]
			,T1.[DimensionName]
			,T1.[Description]
			,T1.[AttributeCode]
			,T1.[AttributeName]
			,T1.[Status]
		FROM [Inbound].[stg_Agresso_uviattrvalues] T1

	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END