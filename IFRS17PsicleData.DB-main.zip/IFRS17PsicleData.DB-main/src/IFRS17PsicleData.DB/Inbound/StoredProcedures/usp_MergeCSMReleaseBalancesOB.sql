﻿CREATE PROCEDURE [Inbound].[usp_MergeCSMReleaseBalancesOB]
AS
                                       
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO [Results].[CSMReleaseBalancesOB](
			   [RunID]
			  ,[Entity]
			  ,[Tri focus code]
			  ,[IFRS17 Tri focus Code]  
			  ,[Account]
			  ,[Programme]
			  ,[RI_Flag]
			  ,[YOI]
			  ,[RecognitionType]
			  ,[CCY]
			  ,[Open_Closed]
			  ,[Quarter]
			  ,[Value]
			  )
		SELECT 
			   T1.[RunID]
			  ,T1.[Entity]
			  ,T1.[Tri Focus Code]
			  ,T1.[IFRS17 Tri Focus Code]
			  ,T1.[Account]
			  ,T1.[Programme]
			  ,T1.[RI_Flag]
			  ,T1.[YoI]
			  ,T1.[RecognitionType]
			  ,T1.[CCY]
			  ,T1.[Open_Closed]
			  ,T1.[Quarter]
			  ,T1.[Value]
			  
		FROM [Inbound].[stg_CSMReleaseBalancesOB] T1
		
		--WHERE T1.RunID NOT IN (SELECT DISTINCT RunID FROM [Results].[CSMReleaseBalancesOB])
		LEFT JOIN (SELECT DISTINCT RunID FROM [Results].[CSMReleaseBalancesOB]) T2 ON T1.RunID=T2.RunID
	    WHERE T2.RunID IS NULL
		
		
	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END