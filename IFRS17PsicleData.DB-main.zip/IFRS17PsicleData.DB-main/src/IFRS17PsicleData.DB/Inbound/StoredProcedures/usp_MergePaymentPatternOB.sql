﻿
CREATE PROCEDURE [Inbound].[usp_MergePaymentPatternOB]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO [Results].[PaymentPatternOB](
			   [OBFlag]
			  ,[RunID]
			  ,Pat_Type
			  ,Loss_Type
			  ,[Tri focus code]
			  ,[RI_Flag]
			  ,[Programme]
			  ,YOA
			  ,[Qtr]
			  ,[Perc]
			
			  )
		SELECT 
			   T1.[OBFlag]
			  ,T1.[RunID]
			  ,T1.[Pat_type]
			  ,T1.[Loss_type]
			  ,T1.[Tri Focus Code]
			  ,T1.[RI flag]
			  ,T1.[Programme]
			  ,T1.[YoA]
			  ,T1.[Qtr]
			  ,T1.[Perc]
	
		FROM [Inbound].[stg_PaymentPatternOB] T1
		--LEFT JOIN [Results].[PaymentPatternOB] T2 ON T1.[RunID]= T2.[RunID]
		--WHERE T1.RunID NOT IN (SELECT DISTINCT RunID FROM [Results].[PaymentPatternOB])
		LEFT JOIN (SELECT DISTINCT RunID FROM [Results].[PaymentPatternOB]) T2 ON T1.RunID=T2.RunID
	    WHERE T2.RunID IS NULL
		

	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END
GO

----exec [Inbound].[usp_MergePaymentPatternOB]