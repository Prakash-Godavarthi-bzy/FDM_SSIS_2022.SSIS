﻿CREATE PROCEDURE [Inbound].[usp_MergeLIC_DiscountedData]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO [Reporting].[LIC_DiscountedData](
                [RunID]					
			   ,[Entity]
			   ,[FocusGroup]
			   ,[Portfolio]
			   ,[Tri Focus Code]		
			   ,[IFRS17 Tri Focus Code]	
			   ,[Programme]				
			   ,[RI_Flag]				
			   ,[YOA]					
			   ,[YOI]					
			   ,[QOI_End_Date]			
			   ,[CCY]					
			   ,[Incepted Status]		
			   ,[Statement]				
			   ,[Balance]				
			   ,[Position]				
			   ,[UOA]					
			   ,[Amount]				
			   ,[Amount_disc]			
			   ,[Conv_Amount]			
			   ,[Conv_Amount_disc]		
			  )
		SELECT 
			  T1.[RunID] 
			 ,T1.[Entity]
			 ,T1.[Focus_Group]
			,ISNULL(
				CASE WHEN T1.RI_Flag = 'O' THEN T1.Programme
					 ELSE CASE WHEN (UOA = '0' OR UOA IS NULL OR UOA = '' OR PATINDEX('%Unknown%' ,UOA) > 0 )	
								THEN 
								CASE WHEN Focus_Group LIKE 'TFP %' OR Focus_Group LIKE 'TFS %' 
										 THEN  RIGHT(Focus_Group, LEN(Focus_Group)-4) 
										 ELSE Focus_Group 
									END
								ELSE CASE WHEN CHARINDEX('_',UOA) = 0 
											THEN  LEFT(UOA, LEN(UOA)-4)
											ELSE CASE WHEN CHARINDEX('_',REVERSE(UOA)) IN ( 2 ,7)	
													  THEN 
														   CASE WHEN UOA LIKE 'NO%' 
																THEN LEFT(UOA, LEN(UOA)-7)
																ELSE 
																 RIGHT(LEFT(UOA, LEN(UOA)-7) ,LEN(LEFT(UOA, LEN(UOA)-7))-4)
															END
													   WHEN CHARINDEX('_',REVERSE(UOA)) = 8	THEN  LEFT(UOA, LEN(UOA)-12) 
														ELSE NULL 
												  END
									   END
						    END
			     END,RIGHT(Focus_Group, LEN(Focus_Group)-4))
			 ,T1.[Tri Focus Code]		
			 ,T1.[IFRS17 Tri Focus Code]	
			 ,T1.[Programme]				
			 ,T1.[RI_Flag]				
			 ,T1.[YoA]					
			 ,T1.[YoI]					
			 ,T1.[QOI_END_DATE]			
			 ,T1.[CCY]					
			 ,T1.[Incepted Status]		
			 ,T1.[Statement]				
			 ,T1.[Balance]				
			 ,T1.[Position]				
			 ,T1.[UoA]					
			 ,T1.[Amount]				
			 ,T1.[Amount_disc]			
			 ,T1.[Conv_Amount]			
			 ,T1.[Conv_Amount_disc]		

		FROM [Inbound].[stg_LIC_DiscountedData] T1
		--WHERE T1.RunID NOT IN (SELECT DISTINCT RunID FROM [Reporting].[LIC_DiscountedData])
		LEFT JOIN (SELECT DISTINCT RunID FROM [Reporting].[LIC_DiscountedData]) T2 ON T1.RunID=T2.RunID
	    WHERE T2.RunID IS NULL

	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END



