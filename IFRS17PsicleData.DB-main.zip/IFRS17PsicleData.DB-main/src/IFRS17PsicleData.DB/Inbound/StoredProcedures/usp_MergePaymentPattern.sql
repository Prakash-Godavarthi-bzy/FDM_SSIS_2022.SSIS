﻿CREATE PROCEDURE [Inbound].[usp_MergePaymentPattern]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO [Reporting].[PaymentPattern](
			 
			 [RunID]
			,[Tri Focus Code]
			,[Qtr]
			,[ObjectName]
			,[Perc]
			,[RI_Flag]
			,[OBFlag]
			  )
		SELECT 

			 T1.[RunID]
			,T1.[Tri Focus Code]
			,T1.[Qtr]
			,T1.[ObjectName]
			,T1.[Perc]
			,T1.[RI_Flag]
		    ,T1.[OBFlag]
  		FROM [Inbound].[stg_PaymentPattern] T1
		--WHERE T1.RunID NOT IN (SELECT DISTINCT RunID FROM [Reporting].[PaymentPattern])
		LEFT JOIN (SELECT DISTINCT RunID FROM [Reporting].[PaymentPattern]) T2 ON T1.RunID=T2.RunID
	    WHERE T2.RunID IS NULL
		
		
	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END