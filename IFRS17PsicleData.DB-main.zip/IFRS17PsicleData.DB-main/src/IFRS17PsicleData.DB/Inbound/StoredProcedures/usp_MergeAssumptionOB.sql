﻿
--USE [IFRS17PsicleData]
--GO

--/****** Object:  StoredProcedure [Inbound].[usp_MergeAssumptionOB]    Script Date: 25/05/2022 11:52:06 ******/
--SET ANSI_NULLS OFF
--GO

--SET QUOTED_IDENTIFIER OFF
--GO

CREATE PROCEDURE [Inbound].[usp_MergeAssumptionOB]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO [Results].AssumptionOB(
               [RunID]
			  ,[Entity]
			  ,[Tri Focus Code]
			  ,[Programme]
			  ,[RI_Flag]
			  ,[Assumption]
			  ,Loss_Type
			  ,YOA
			  ,[Qtr]
			  ,[Perc]
			  )
		SELECT 
			   T1.[RunID]
			  ,CASE WHEN T1.[Entity] IS NULL THEN 'No Entity' ELSE T1.[Entity] END
			  ,CAST(T1.[Tri Focus Code] AS VARCHAR(10))
			  ,T1.[Programme]
			  ,T1.[RI_Flag]
			  ,T1.[Assumption]
			  ,CASE WHEN T1.[Loss_type] IS NULL THEN 'NA' ELSE T1.[Loss_type] END
			  ,CASE WHEN T1.[YoA] IS NULL THEN 0 ELSE T1.[YoA] END
			  ,T1.[Qtr]
			  ,T1.[Perc]

		FROM [Inbound].[stg_AssumptionOB] T1
		LEFT JOIN (SELECT DISTINCT RunID FROM [Results].AssumptionOB) T2 ON T1.RunID=T2.RunID
	    WHERE T2.RunID IS NULL

	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END