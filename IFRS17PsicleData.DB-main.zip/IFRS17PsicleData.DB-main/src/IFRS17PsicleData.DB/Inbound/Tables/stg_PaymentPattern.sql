﻿CREATE TABLE [Inbound].[stg_PaymentPattern] (
    [Id]                  BIGINT        IDENTITY (1, 1) NOT NULL,
    [RunID]               FLOAT            NULL,
    [Tri Focus Code]      VARCHAR (255)   NULL,
    [Qtr]                 FLOAT    NULL,
    [ObjectName]          VARCHAR (255)    NULL,
    [Perc]                FLOAT     NULL,
    [RI_Flag]             VARCHAR (255)    NULL,
	[OBFlag]              FLOAT            NULL,
    [AuditCreateDateTime] DATETIME2 (7)  Default(getdate()) NOT NULL ,
    [AuditUser]     VARCHAR (255) Default(suser_sname()) NOT NULL
);

