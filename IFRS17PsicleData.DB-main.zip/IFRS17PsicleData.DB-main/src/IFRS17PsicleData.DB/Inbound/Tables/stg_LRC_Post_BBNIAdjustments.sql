CREATE TABLE [Inbound].[stg_LRC_Post_BBNIAdjustments](
	[Id]  BIGINT IDENTITY (1, 1) NOT NULL,
	[RunID] [float] NULL,
	[Entity] [varchar](255) NULL,
	[Focus_Group] [varchar](255) NULL,
	[Tri Focus Code] [varchar](255) NULL,
	[IFRS17 Tri Focus Code] [varchar](255) NULL,
	[Programme] [varchar](255) NULL,
	[RI_Flag] [varchar](255) NULL,
	[YoA] [float] NULL,
	[YoI] [float] NULL,
	[QOI_END_DATE] [datetime] NULL,
	[CCY] [varchar](255) NULL,
	[Incepted Status] [varchar](255) NULL,
	[Statement] [varchar](255) NULL,
	[Balance] [varchar](255) NULL,
	[Position] [varchar](255) NULL,
	[UoA] [varchar](255) NULL,
	[Amount] [float] NULL,
	[Amount_disc] [float] NULL,
	[Conv_Amount] [float] NULL,
	[Conv_Amount_disc] [float] NULL,
	[AuditUser] [varchar](255) Default(suser_sname()) NOT NULL,
	[AuditCreateDatetime] [datetime2](7) Default(getdate()) NOT NULL
);


