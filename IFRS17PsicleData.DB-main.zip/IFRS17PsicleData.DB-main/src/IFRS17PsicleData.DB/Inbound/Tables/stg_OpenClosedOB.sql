create table Inbound.stg_OpenClosedOB
(
[Id]						BIGINT IDENTITY (1, 1) NOT NULL,
[RunID]						FLOAT  null,
Programme					varchar(255) null,
[Trifocus]					varchar(255)  null,
YOA							float  null,
[Open_Closed derivation]	varchar(255)  null,
[AuditUser]				[varchar](255) Default(suser_sname()) NOT NULL,
[AuditCreateDatetime]	[datetime2](7) Default(getdate()) NOT NULL 
)