create table Inbound.stg_AssumptionOB
(
[Id]  BIGINT IDENTITY (1, 1) NOT NULL,
RunID				float  null,
Entity				varchar(255)  null,
[Tri Focus Code]	varchar(255) null,
Programme			varchar(255)  null,
RI_Flag				varchar(255)  null,
Assumption			varchar(255)  null,
Loss_type			varchar(255)  null,
YoA					float  null,
Qtr					varchar(255)  null,
Perc				float  null,
[AuditUser] [varchar](255) Default(suser_sname()) NOT NULL,
[AuditCreateDatetime] [datetime2](7) Default(getdate()) NOT NULL
)