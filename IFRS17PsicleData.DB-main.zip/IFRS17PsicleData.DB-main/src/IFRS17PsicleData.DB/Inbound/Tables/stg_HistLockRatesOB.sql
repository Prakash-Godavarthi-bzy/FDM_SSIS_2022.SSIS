create table Inbound.stg_HistLockRatesOB
(
[Id]					BIGINT IDENTITY (1, 1) NOT NULL,
RunID					float  null,
YoI						float null,
Programme				varchar(255)  null,
FocusGroup				varchar(255)  null,
CCY						varchar(255)  null,
Qtr						float  null,
Rate					float  null,
[AuditUser]				[varchar](255) Default(suser_sname()) NOT NULL,
[AuditCreateDatetime]	[datetime2](7) Default(getdate()) NOT NULL
)