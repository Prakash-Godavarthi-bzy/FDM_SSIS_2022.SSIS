﻿CREATE TABLE [Inbound].[Stg_FSC_Output] (
    [Id]                    BIGINT        IDENTITY (1, 1) NOT NULL,
    [RunID]                 FLOAT (53)    NULL,
    [Entity]                VARCHAR (255) NULL,
    [Tri Focus Code]        VARCHAR (255) NULL,
    [IFRS17 Tri Focus Code] VARCHAR (255) NULL,
    [Account]               VARCHAR (255) NULL,
    [Programme]             VARCHAR (255) NULL,
    [RI_Flag]               VARCHAR (255) NULL,
    [YoA]                   FLOAT (53)    NULL,
    [YoI]                   FLOAT (53)    NULL,
    [QOI_END_DATE]          DATETIME      NULL,
    [RecognitionType]       VARCHAR (255) NULL,
    [CCY]                   VARCHAR (255) NULL,
    [Incepted Status]       VARCHAR (255) NULL,
    [Open_Closed]           VARCHAR (255) NULL,
    [Value]                 FLOAT (53)    NULL,
    [AuditUser]             VARCHAR (255) DEFAULT (suser_sname()) NOT NULL,
    [AuditCreateDatetime]   DATETIME2 (7) DEFAULT (getdate()) NOT NULL
);

