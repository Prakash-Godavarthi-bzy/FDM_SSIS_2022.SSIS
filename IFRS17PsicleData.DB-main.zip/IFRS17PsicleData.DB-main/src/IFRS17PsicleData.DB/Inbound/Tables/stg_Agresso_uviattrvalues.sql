﻿CREATE TABLE [Inbound].[stg_Agresso_uviattrvalues] (
    [Id]                  BIGINT        IDENTITY (1, 1) NOT NULL,
    [DimensionID]         VARCHAR (4)   NOT NULL,
    [DimensionName]       VARCHAR (25)  NOT NULL,
    [Description]         VARCHAR (255) NOT NULL,
    [AttributeCode]       VARCHAR (25)  NOT NULL,
    [AttributeName]       VARCHAR (255) NOT NULL,
    [Status]              VARCHAR (6)   NOT NULL,
    [AuditUser]           VARCHAR (255) DEFAULT (suser_sname()) NOT NULL,
    [AuditCreateDatetime] DATETIME2 (7) DEFAULT (getdate()) NOT NULL
);

