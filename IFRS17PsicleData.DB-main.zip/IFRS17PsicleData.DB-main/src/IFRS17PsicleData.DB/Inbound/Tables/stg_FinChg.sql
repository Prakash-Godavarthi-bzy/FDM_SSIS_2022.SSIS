﻿CREATE TABLE [Inbound].[stg_FinChg] (
    [Id]                    BIGINT        IDENTITY (1, 1) NOT NULL,
    [RunID]                 FLOAT         NULL,
    [Entity]                VARCHAR (255)     NULL,
    [Tri Focus Code]        VARCHAR (255)     NULL,
    [IFRS17 Tri Focus Code] VARCHAR (255)     NULL,
    [Programme]             VARCHAR (255)     NULL,
    [RI_Flag]               VARCHAR (255)     NULL,
    [YoA]                   FLOAT             NULL,
    [YoI]                   FLOAT             NULL,
    [QOI_END_DATE]          DATETIME          NULL,
    [CCY]                   VARCHAR (255)     NULL,
    [Incepted Status]       VARCHAR (255)      NULL,
    [Statement]             VARCHAR (255)     NULL,
    [Position]              VARCHAR (255)     NULL,
    [Balance]               VARCHAR (255)     NULL,
    [Amount]                FLOAT NULL,
    [Amount_Disc]           FLOAT NULL,
    [FinChg]                VARCHAR (255)    NULL,
    [AuditCreateDateTime]   DATETIME2 (7)    Default(getdate()) NOT NULL ,
    [AuditUser]       VARCHAR (255)   Default(suser_sname()) NOT NULL
);

