create table Inbound.stg_OpenUoAOB
(
[Id]				BIGINT IDENTITY (1, 1) NOT NULL,
RunId				float  null,
TFYOI				varchar(255)  null,
Entity				varchar(255)  null,
Focus_Group			varchar(255) null,
UoA					varchar(255) null,
YoI					float  null,
Programme			varchar(255) null,
[Tri Focus Code]	varchar(255)  null,
trifocus			varchar(255)  null,
TFUOA				varchar(255)  null,
Onerosity			varchar(255) null,
[CSM_LC]			varchar(255)  null,
[AuditUser]				[varchar](255) Default(suser_sname()) NOT NULL,
[AuditCreateDatetime]	[datetime2](7) Default(getdate()) NOT NULL 
)