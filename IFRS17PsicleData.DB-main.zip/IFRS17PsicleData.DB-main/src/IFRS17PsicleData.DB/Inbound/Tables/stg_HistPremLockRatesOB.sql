create table Inbound.stg_HistPremLockRatesOB
(
[Id]					BIGINT IDENTITY (1, 1) NOT NULL,
RunID					float  null,
QOI_END_DATE			datetime null,
Programme				varchar(255) null,
FocusGroup				varchar(255) null,
CCY						varchar(255)  null,
[Sum of Amount]			float  null,
[AuditUser]				[varchar](255) Default(suser_sname()) NOT NULL,
[AuditCreateDatetime]	[datetime2](7) Default(getdate()) NOT NULL 
)