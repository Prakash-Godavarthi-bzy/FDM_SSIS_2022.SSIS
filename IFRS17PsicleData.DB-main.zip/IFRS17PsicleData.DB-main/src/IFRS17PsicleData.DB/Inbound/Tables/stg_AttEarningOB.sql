Create Table Inbound.[stg_AttEarningOB]
(
 ID					[BigInt] identity(1,1),
[RunID]				[float] NULL,
[Pat_type]			[varchar](255) NULL,
[Tri Focus Code]	[varchar](255) NULL,
[Programme]			[varchar](255) NULL,
[YOI]				[float] NULL,
[QOI]				[datetime] NULL,
[CCY]				[varchar](255) NULL,
[Qtr]				[datetime] NULL,
[Perc]				[float] NULL, 
[AuditUser] [varchar](255) DEFAULT (suser_sname()) NOT NULL,
[AuditCreateDatetime] [datetime2](7) DEFAULT (getdate())NOT NULL
	)


	

	



