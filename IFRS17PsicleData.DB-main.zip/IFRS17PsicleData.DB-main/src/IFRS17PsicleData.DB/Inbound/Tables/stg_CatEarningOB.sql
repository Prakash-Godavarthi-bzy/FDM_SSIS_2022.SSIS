Create Table Inbound.[stg_CatEarningOB]
	(
	 ID								[BigInt] identity(1,1),
	[RunID]							[float] NULL,
	[Tri Focus Code]				[varchar](255) NULL,
	[YOA]							[float] NULL,
	[Open_Closed derivation]		[varchar](255) NULL,
	[CCY]							[varchar](255) NULL,
	[QOI_END_DATE]					[datetime] NULL,
	[Qtr]							[datetime] NULL,
	[YOI]							[float] NULL,
	[Account]						[varchar](255) NULL,
	[Amount_cum]					[float] NULL, 
	[AuditUser]						[varchar](255) DEFAULT (suser_sname()) NOT NULL,
	[AuditCreateDatetime]			[datetime2](7) DEFAULT (getdate()) NOT NULL
	)