create table Inbound.stg_UndiscLRCWalkBalancesOB
(
[Id]					BIGINT IDENTITY (1, 1) NOT NULL,
RunID					float  null,
Entity					varchar(255)  null,
[Tri Focus Code]		varchar(255)  null,
[IFRS17 Tri Focus Code] varchar(255)  null,
Account					varchar(255)  null,
Programme				varchar(255) null,
RI_Flag					varchar(255) null,
YoA						float  null,
YoI						float  null,
QOI_END_DATE			datetime null,
CCY						varchar(255)  null,
[Incepted Status]		varchar(255)  null,
Amount					float  null,
Statement				varchar(255)  null,
Position				varchar(255)  null,
Balance					varchar(255)  null,
[AuditUser]				[varchar](255) Default(suser_sname()) NOT NULL,
[AuditCreateDatetime]	[datetime2](7) Default(getdate()) NOT NULL
)