CREATE TABLE [Inbound].[stg_Onerosity](
	[Id]  BIGINT IDENTITY (1, 1) NOT NULL,
	[RunID] [float] NULL,
	[TFYOI] [varchar](255) NULL,
	[Entity] [varchar](255) NULL,
	[Focus_Group] [varchar](255) NULL,
	[UoA] [varchar](255) NULL,
	[YoI] [float] NULL,
	[Programme] [varchar](255) NULL,
	[Tri Focus Code] [varchar](255) NULL,
	[trifocus] [varchar](255) NULL,
	[TFUOA] [varchar](255) NULL,
	[Onerosity] [varchar](255) NULL,
	[CSM_LC] [varchar](255) NULL,
	[AuditUser] [varchar](255) Default(suser_sname()) NOT NULL,
	[AuditCreateDatetime] [datetime2](7) Default(getdate()) NOT NULL
);


