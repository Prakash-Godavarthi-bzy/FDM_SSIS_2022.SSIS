﻿CREATE TABLE [Inbound].[stg_CSMReleaseBalancesOB] (
    [Id]                    BIGINT        IDENTITY (1, 1) NOT NULL,
    [RunID]                 FLOAT (53)    NULL,
    [Entity]                VARCHAR (255) NULL,
    [Tri Focus Code]        VARCHAR (255) NULL,
    [IFRS17 Tri Focus Code] VARCHAR (255) NULL,
    [Account]               VARCHAR (255) NULL,
    [Programme]             VARCHAR (255) NULL,
    [RI_Flag]               VARCHAR (255) NULL,
    [YoI]                   FLOAT (53)    NULL,
    [RecognitionType]       VARCHAR (255) NULL,
    [CCY]                   VARCHAR (255) NULL,
    [Open_Closed]           VARCHAR (255) NULL,
    [Quarter]               [datetime] NULL ,
    [Value]                 FLOAT (53)    NULL,
    [AuditUser] [varchar](255) Default(suser_sname()) NOT NULL,
	[AuditCreateDatetime] [datetime2](7) Default(getdate()) NOT NULL
);

