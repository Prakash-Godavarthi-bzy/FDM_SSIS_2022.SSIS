create table Inbound.stg_FXOB
(
[Id]					BIGINT IDENTITY (1, 1) NOT NULL,
 OBFlag					float  null,
 RunID					float  null,
 FXRatetype				varchar(255)  null,
 CCY					varchar(255)  null,
 RepCCY					varchar(255)  null,
 FXRate					float  null,
[AuditUser]				[varchar](255) Default(suser_sname()) NOT NULL,
[AuditCreateDatetime]	[datetime2](7) Default(getdate()) NOT NULL
 )