﻿CREATE TABLE [Inbound].[stg_LIC_UndiscountedData] (
    [Id]                  BIGINT        IDENTITY (1, 1) NOT NULL,
    [RunID]               FLOAT (53)    NULL,
    [Entity]              VARCHAR (255) NULL,
    [Tri Focus Code]      VARCHAR (255) NULL,
	[IFRS17 Tri Focus Code] VARCHAR(255) NULL,
    [Programme]           VARCHAR (255) NULL,
    [RI_Flag]             VARCHAR (255) NULL,
    [YoA]                 FLOAT (53)    NULL,
    [YoI]                 FLOAT (53)    NULL,
    [QOI_END_DATE]        DATETIME      NULL,
    [CCY]                 VARCHAR (255) NULL,
    [Incepted Status]     VARCHAR (255) NULL,
    [Amount]              FLOAT   NULL,
    [Statement]           VARCHAR (255) NULL,
    [Position]            VARCHAR (255) NULL,
    [Balance]             VARCHAR (255) NULL,
    [Account]             VARCHAR (255) NULL,
	[Unadjusted_Amount]   FLOAT    NULL,
    [AuditUser]           VARCHAR (255) DEFAULT (suser_sname()) NOT NULL,
    [AuditCreateDatetime] DATETIME2 (7) DEFAULT (getdate()) NOT NULL
);


