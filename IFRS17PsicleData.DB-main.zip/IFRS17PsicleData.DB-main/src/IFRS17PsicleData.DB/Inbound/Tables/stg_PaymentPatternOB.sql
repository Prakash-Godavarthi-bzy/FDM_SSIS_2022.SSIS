create table Inbound.stg_PaymentPatternOB
(
[Id]				BIGINT IDENTITY (1, 1) NOT NULL,
OBFlag				float  null,
RunID				float  null,
Pat_type			varchar(255)  null,
Loss_type			varchar(255)  null,
[Tri Focus Code]	varchar(255) null,
[RI flag]			varchar(255),
Programme			varchar(255),
YoA					float  null,
Qtr					float  null,
Perc				float  null,
[AuditUser]				[varchar](255) Default(suser_sname()) NOT NULL,
[AuditCreateDatetime]	[datetime2](7) Default(getdate()) NOT NULL
)