CREATE TABLE Results.OpenUoAOB
(
[Id]  				BIGINT IDENTITY (1, 1) NOT NULL,
RunID 				int not null,
TFYOI 				varchar(100)  null,
Entity 				varchar(20) not null,
FocusGroup 			varchar(100)  null,
UOA 				varchar(100)  null,
YOI 				int  null,
Programme 			varchar(100) null,
[Tri focus code] 	varchar(25) not null,
[Tri focus] 		varchar(50) null,
TFUOA 				varchar(200)  null,
Onerosity 			char(2)  null,
[CSM_LC] 			varchar(10)  null,
[AuditCreateDateTime] DATETIME2(7) DEFAULT Getdate() NOT NULL,
[AuditUSerCreate] NVARCHAR(510) DEFAULT suser_sname() NOT NULL
);
GO
	CREATE CLUSTERED INDEX [cix_OpenUoAOB] ON [Results].[OpenUoAOB] (RunID) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]

