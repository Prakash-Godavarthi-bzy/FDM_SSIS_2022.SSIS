﻿CREATE TABLE [Results].[FXOB] (
    [Id]         BIGINT       IDENTITY (1, 1) NOT NULL,
    [OBFlag]     INT          NOT NULL,
    [RunID]      INT          NOT NULL,
    [FXRatetype] CHAR (3)     NOT NULL,
    [CCY]        VARCHAR (10) NOT NULL,
    [RepCCY]     VARCHAR (10) NOT NULL,
    [FXRate]     NUMERIC (38, 12) NOT NULL,
	[AuditCreateDateTime] DATETIME2(7) DEFAULT (getdate())  NOT NULL ,
	[AuditUserCreate]     NVARCHAR (510)  DEFAULT (suser_sname())NOT NULL
);

GO
CREATE CLUSTERED INDEX [cix_FXOB] ON [Results].[FXOB] (RunID) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]



