﻿CREATE TABLE [Results].[AssumptionOB] (
    [Id]             BIGINT        IDENTITY (1, 1) NOT NULL,
    [RunID]          INT           NOT NULL,
    [Entity]         VARCHAR (20)  NOT NULL,
    [Tri Focus Code] VARCHAR (25)  NULL,
    [Programme]      VARCHAR (100) NULL,
    [RI_Flag]        VARCHAR (2)   NULL,
    [Assumption]     VARCHAR (15)  NOT NULL,
    [Loss_Type]      VARCHAR (2)   NOT NULL,
    [YOA]            INT           NOT NULL,
    [Qtr]           VARCHAR (2)   NOT NULL,
    [Perc]          NUMERIC (38, 12) NOT NULL,
	[AuditCreateDateTime] DATETIME2(7) DEFAULT (getdate())  NOT NULL ,
	[AuditUserCreate]     NVARCHAR (510)  DEFAULT (suser_sname())NOT NULL
);

GO
CREATE CLUSTERED INDEX [cix_AssumptionOB] ON [Results].[AssumptionOB] (RunID) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
