﻿CREATE TABLE [Results].[CatEarningOB] (
    [Id]                     BIGINT           IDENTITY (1, 1) NOT NULL,
    [RunID]                  INT              NOT NULL,
    [Tri focus code]         VARCHAR (25)     NOT NULL,
    [YOA]                    INT              NOT NULL,
    [Open/Closed derivation] VARCHAR (10)     NULL,
    [CCY]                    VARCHAR (10)     NOT NULL,
    [QOI_End_Date]           DATETIME        NULL,
    [Qtr]                    DATETIME         NOT NULL,
    [YOI]                    INT              NULL,
    [Account]                VARCHAR (255)    NULL,
    [Amount_Cum]             NUMERIC (38, 12) NOT NULL,
    [AuditCreateDateTime]    DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]        NVARCHAR (510)   DEFAULT (suser_sname()) NOT NULL
);

GO
	CREATE CLUSTERED INDEX [cix_CatEarningOB] ON [Results].[CatEarningOB] (RunID) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]

