CREATE TABLE Results.PremiumAdjustments (
RunID 					int not null,
Entity 					varchar(20) not null,
[Tri focus code] 		varchar(25) not null,
[IFRS17 TrifocusCode] 	varchar(25)  null,
Account 				varchar(15) not null,
Programme 				varchar(100) null,
RI_Flag 				varchar(2) null,
YOA 					int not null,
YOI 					int  null,
[QOI_End_Date] 			date  null,
RecognitionType 		char(2)  not null,
CCY 					VARCHAR(10) not null,
[Incepted Status] 		char(1)  null,
[Open / Closed] 		varchar(10)  null,
Amount 					numeric(38,10) null,
[AuditCreateDateTime] DATETIME2(7) DEFAULT Getdate() NOT NULL,
[AuditUSerCreate] NVARCHAR(510) DEFAULT suser_sname() NOT NULL
);
GO
CREATE CLUSTERED INDEX [cix_PremiumAdjustments] ON [Results].[PremiumAdjustments] (RunID) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
