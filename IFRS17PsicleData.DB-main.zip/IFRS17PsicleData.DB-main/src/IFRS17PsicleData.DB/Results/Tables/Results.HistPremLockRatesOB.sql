﻿CREATE TABLE [Results].[HistPremLockRatesOB] (
    [Id]           BIGINT        IDENTITY (1, 1) NOT NULL,
    [RunID]        INT           NOT NULL,
    [QOI_End_Date] DATE          NULL,
    [Programme]    VARCHAR (100) NULL,
    [FocusGroup]   VARCHAR (100) NULL,
    [CCY]          VARCHAR (10)  NOT NULL,
    [Amount]      NUMERIC (38, 12) NOT NULL,
	[AuditCreateDateTime] DATETIME2(7) DEFAULT (getdate())  NOT NULL ,
	[AuditUserCreate]     NVARCHAR (510)  DEFAULT (suser_sname())NOT NULL
);
GO
CREATE CLUSTERED INDEX [cix_HistPremLockRatesOB] ON [Results].[HistPremLockRatesOB] (RunID) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]

