
CREATE TABLE Results.OpenClosedOB
(
[Id]  						BIGINT IDENTITY (1, 1) NOT NULL,
[RunID] 					int not null,
Programme 					varchar(100) null,
[Tri focus code] 			varchar(25) not null,
YOA 						int not null,
[Open/Closed Derivation] varchar(10)  null,
[AuditCreateDateTime] DATETIME2(7) DEFAULT Getdate() NOT NULL,
[AuditUSerCreate] NVARCHAR(510) DEFAULT suser_sname() NOT NULL
);
GO
CREATE CLUSTERED INDEX [cix_OpenClosedOB] ON [Results].[OpenClosedOB] (RunID) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
