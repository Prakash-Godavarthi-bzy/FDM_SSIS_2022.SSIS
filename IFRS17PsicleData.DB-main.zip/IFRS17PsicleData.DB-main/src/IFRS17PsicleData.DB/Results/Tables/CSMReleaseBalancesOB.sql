﻿CREATE TABLE [Results].[CSMReleaseBalancesOB] (
    [Id]                    BIGINT        IDENTITY (1, 1) NOT NULL,
    [RunID]                 INT           NULL,
    [Entity]                VARCHAR (20)  NOT NULL,
    [Tri focus code]        VARCHAR (10)  NOT NULL,
    [IFRS17 Tri Focus Code] VARCHAR (10)  NULL,
    [Account]               VARCHAR (15)  NOT NULL,
    [Programme]             VARCHAR (100) NULL,
    [RI_Flag]               VARCHAR (2)   NULL,
    [YoI]                   INT           NULL,
    [RecognitionType]       CHAR (2)      NOT NULL,
    [CCY]                   CHAR (3)      NOT NULL,
    [Open_Closed]           VARCHAR (10)  NULL,
    [Quarter]               DATETIME      NULL,
    [Value]                 FLOAT (53)    NOT NULL
);



