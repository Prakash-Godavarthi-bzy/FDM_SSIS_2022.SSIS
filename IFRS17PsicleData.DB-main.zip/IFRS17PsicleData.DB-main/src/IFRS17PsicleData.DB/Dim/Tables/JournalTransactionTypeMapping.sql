﻿CREATE TABLE [Dim].[JournalTransactionTypeMapping] (
    [Id]  BIGINT IDENTITY (1, 1) NOT NULL,
    [Statement]        VARCHAR (255) NULL,
    [Discounted(Y/N)]  VARCHAR (1)   NULL,
    [Position]         VARCHAR (255) NULL,
    [Transaction Type] VARCHAR (255) NULL
);

