﻿CREATE TABLE [Dim].[JournalReAllocationMapping] (
    [PK_Id]  BIGINT IDENTITY (1, 1) NOT NULL,
    [ID]                                  VARCHAR (255) NULL,
    [Re Allocation Positive Account Code] VARCHAR (255) NULL,
    [Re Allocation Negative Account Code] VARCHAR (255) NULL
);

