﻿CREATE TABLE [Dim].[AccountMappingRules] (
    [ID]                                BIGINT        IDENTITY (1, 1) NOT NULL,
    [VersionID]                         INT           NULL,
    [Statement]                         VARCHAR (3)   NULL,
    [RI_Flag]                           CHAR (3)      NULL,
    [Balance]                           VARCHAR (10)  NULL,
    [Position]                          VARCHAR (50)  NULL,
    [JournalDescription]                VARCHAR (100) NULL,
    [Transactiontype_Undisc_Amount]     VARCHAR (3)   NULL,
    [AccountCode_undisc_PositiveAmount] VARCHAR (25)  NULL,
    [AccountCode_undisc_NegativeAmount] VARCHAR (25)  NULL,
    [Transactiontype_disc_Amount]       VARCHAR (3)   NULL,
    [AccountCode_disc_PositiveAmount]   VARCHAR (25)  NULL,
    [AccountCode_disc_NegativeAmount]   VARCHAR (25)  NULL,
    [AuditUser]                         VARCHAR (25)  DEFAULT (suser_sname()) NULL,
    [AuditCreateDatetime]               DATETIME2 (7) DEFAULT (getdate()) NULL,
    [CSM_LC]                            VARCHAR (10)  NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);





