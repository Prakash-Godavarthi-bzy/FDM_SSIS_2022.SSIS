﻿CREATE TABLE [Dim].[JournalReAllocationSelectionList] (
    [Id]                  INT           NOT NULL,
    [RI_Flag]             VARCHAR (1)   NULL,
    [Scenario]            VARCHAR (5)   NULL,
    [ScenarioDescription] VARCHAR (25)  NULL,
    [Statement]           VARCHAR (3)   NULL,
    [Position]            VARCHAR (50)  NULL,
    [AuditUser]           VARCHAR (255) NOT NULL,
    [AuditCreateDateTime] DATETIME2 (7) NOT NULL
);

