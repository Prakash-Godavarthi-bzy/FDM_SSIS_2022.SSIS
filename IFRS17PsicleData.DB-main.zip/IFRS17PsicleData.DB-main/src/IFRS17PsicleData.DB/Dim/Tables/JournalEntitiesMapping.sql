﻿CREATE TABLE [Dim].[JournalEntitiesMapping] (
    [Id]  BIGINT IDENTITY (1, 1) NOT NULL,
    [Entity Code]                VARCHAR (255) NULL,
    [Agresso Entity Code]        VARCHAR (255) NULL,
    [Agresso IFRS17 Client Code] VARCHAR (255) NULL,
    [IFRS17 Entity Name]         VARCHAR (255) NULL,
    [Budget Entity]              VARCHAR (255) NULL
);

