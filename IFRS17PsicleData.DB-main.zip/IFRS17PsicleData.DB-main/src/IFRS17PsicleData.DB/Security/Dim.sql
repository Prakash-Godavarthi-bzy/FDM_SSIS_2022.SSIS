﻿CREATE SCHEMA [Dim]
    AUTHORIZATION [dbo];









