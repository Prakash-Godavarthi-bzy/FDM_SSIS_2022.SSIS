﻿CREATE TABLE [Reporting].[JournalInputDataYTD] (
    [RunIDs]                  VARCHAR (50)    NULL,
    [AccountingDate]          DATE            NULL,
    [FocusGroup]              VARCHAR (100)   NULL,
    [Entity]                  VARCHAR (20)    NOT NULL,
    [TriFocusCode]            VARCHAR (25)    NOT NULL,
    [IFRS17TriFocusCode]      VARCHAR (25)    NULL,
    [Programme]               VARCHAR (100)   NULL,
    [RI_Flag]                 VARCHAR (2)     NULL,
    [YOA]                     INT             NOT NULL,
    [YOI]                     INT             NULL,
    [QOI_End_Date]            DATE            NULL,
    [CCY]                     VARCHAR (10)    NOT NULL,
    [InceptedStatus]          CHAR (1)        NULL,
    [Statement]               VARCHAR (50)    NOT NULL,
    [Balance]                 VARCHAR (50)    NOT NULL,
    [Position]                VARCHAR (50)    NOT NULL,
    [UOA]                     VARCHAR (100)   NULL,
    [CSM_LC]                  VARCHAR (10)    NULL,
    [Amount]                  NUMERIC (18, 2) NULL,
    [Amount_disc]             NUMERIC (18, 2) NULL,
    [Conv_Amount]             NUMERIC (18, 2) NULL,
    [Conv_Amount_disc]        NUMERIC (18, 2) NULL,
    [AgressoEntityCode]       VARCHAR (255)   NULL,
    [AgressoIFRS17ClientCode] VARCHAR (255)   NULL,
    [Disc]                    NUMERIC (18, 2) NULL,
    [TransactionType_Undisc]  VARCHAR (3)     NULL,
    [TransactionType_Disc]    VARCHAR (3)     NULL,
    [AccountCode_Undisc_Pos]  VARCHAR (25)    NULL,
    [AccountCode_Undisc_Neg]  VARCHAR (25)    NULL,
    [AccountCode_Disc_Pos]    VARCHAR (25)    NULL,
    [AccountCode_Disc_Neg]    VARCHAR (25)    NULL,
    [JournalDescription]      VARCHAR (100)   NULL,
    [AssetLiabilityAmount]    NUMERIC (18, 2) NULL,
    [AssetLiabilityType]      VARCHAR (25)    NULL,
    [ReAllocationID]          VARCHAR (255)   NULL,
    [AccountCode_ReAlloc_Pos] VARCHAR (25)    NULL,
    [AccountCode_ReAlloc_Neg] VARCHAR (25)    NULL,
    [AuditUser]               VARCHAR (25)    NULL,
    [AuditCreateDatetime]     DATETIME2 (7)   NULL,
    [Portfolio]               VARCHAR (100)   NULL,
    [JournalType]             VARCHAR (100)   NULL
);




GO
CREATE CLUSTERED COLUMNSTORE INDEX [cci_JournalInputDataYTD]   ON [Reporting].[JournalInputDataYTD] WITH (MAXDOP = 1);






