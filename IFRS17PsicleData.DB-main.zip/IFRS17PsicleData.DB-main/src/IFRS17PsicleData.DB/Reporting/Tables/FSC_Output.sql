﻿CREATE TABLE [Reporting].[FSC_Output] (
    [Id]                  BIGINT           IDENTITY (1, 1) NOT NULL,
    [RunID]               INT              NOT NULL,
    [Entity]              VARCHAR (20)     NOT NULL,
    [Tri focus code]      VARCHAR (25)     NOT NULL,
    [IFRS17 TrifocusCode] VARCHAR (25)     NULL,
    [Account]             VARCHAR (25)     NULL,
    [Programme]           VARCHAR (100)    NULL,
    [RI_Flag]             VARCHAR (2)      NULL,
    [YOA]                 INT              NOT NULL,
    [YOI]                 INT              NULL,
    [QOI_End_Date]        DATE             NULL,
    [RecognitionType]     CHAR (2)         NOT NULL,
    [CCY]                 VARCHAR (10)     NOT NULL,
    [Incepted Status]     CHAR (1)         NULL,
    [Open / Closed]       VARCHAR (10)     NULL,
    [Value]               NUMERIC (38, 10) NULL,
	[AuditCreateDateTime] DATETIME2(7) DEFAULT (getdate())  NOT NULL ,
	[AuditUserCreate]     NVARCHAR (510)  DEFAULT (suser_sname())NOT NULL
);
GO
CREATE CLUSTERED INDEX [cix_FSC_Output] ON [Reporting].[FSC_Output] (RunID) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]



