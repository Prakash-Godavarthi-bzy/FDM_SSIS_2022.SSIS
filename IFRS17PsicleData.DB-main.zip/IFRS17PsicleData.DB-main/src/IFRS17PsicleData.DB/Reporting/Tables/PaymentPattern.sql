﻿CREATE TABLE [Reporting].[PaymentPattern] (
    [Id]                  BIGINT        IDENTITY (1, 1) NOT NULL,
    [RunID]               INT            NOT NULL,
    [Tri Focus Code]      VARCHAR (25)   NOT NULL,
    [Qtr]                 INT     NULL,
    [ObjectName]          VARCHAR (3)    NULL,
    [Perc]                NUMERIC(38,12)     NULL,
    [RI_Flag]             VARCHAR (2)    NULL,
	[OBFlag]              INT            NULL,
    [AuditCreateDateTime] DATETIME2 (7)  Default(getdate()) NOT NULL ,
    [AuditUserCreate]     NVARCHAR (510) Default(suser_sname()) NOT NULL
);
GO
CREATE CLUSTERED INDEX [cix_PaymentPattern] ON [Reporting].[PaymentPattern] (RunID) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]

