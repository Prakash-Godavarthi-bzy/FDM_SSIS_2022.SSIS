﻿CREATE TABLE [Reporting].[LRC_Post_BBNIAdjustments] (
    [Id]                    BIGINT           IDENTITY (1, 1) NOT NULL,
    [RunID]                 INT              NOT NULL,
    [Entity]                VARCHAR (20)     NOT NULL,
    [FocusGroup]            VARCHAR (100)    NULL,
    [Tri Focus Code]        VARCHAR (25)     NOT NULL,
    [IFRS17 Tri Focus Code] VARCHAR (25)     NULL,
    [Programme]             VARCHAR (100)    NULL,
    [RI_Flag]               VARCHAR (2)      NULL,
    [YOA]                   INT              NOT NULL,
    [YOI]                   INT              NULL,
    [QOI_End_Date]          DATE             NULL,
    [CCY]                   VARCHAR (10)     NOT NULL,
    [Incepted Status]       CHAR (1)         NULL,
    [Statement]             VARCHAR (50)     NOT NULL,
    [Balance]               VARCHAR (50)     NOT NULL,
    [Position]              VARCHAR (50)     NOT NULL,
    [UOA]                   VARCHAR (100)    NULL,
    [Amount]                NUMERIC (38, 12) NULL,
    [Amount_disc]           NUMERIC (38, 12) NULL,
    [Conv_Amount]           NUMERIC (38, 12) NULL,
    [Conv_Amount_disc]      NUMERIC (38, 12) NULL,
	 [Portfolio]             VARCHAR (100)    NULL,
    [AuditCreateDateTime]   DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]       NVARCHAR (510)   DEFAULT (suser_sname()) NOT NULL
   
);
GO

CREATE CLUSTERED COLUMNSTORE INDEX [cci_LRC_Post_BBNIAdjustments] ON [Reporting].[LRC_Post_BBNIAdjustments] WITH (MAXDOP=1)

