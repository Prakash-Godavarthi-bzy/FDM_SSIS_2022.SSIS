﻿CREATE TABLE [Reporting].[FinChg] (
    [Id]                    BIGINT        IDENTITY (1, 1) NOT NULL,
    [RunID]                 INT              NOT NULL,
    [Entity]                VARCHAR (20)     NOT NULL,
    [Tri Focus Code]        VARCHAR (25)     NOT NULL,
    [IFRS17 Tri Focus Code] VARCHAR (25)     NULL,
    [Programme]             VARCHAR (100)    NULL,
    [RI_Flag]               VARCHAR (2)      NULL,
    [YoA]                   INT              NOT NULL,
    [YoI]                   INT              NULL,
    [QOI_END_DATE]          DATE             NULL,
    [CCY]                   VARCHAR (10)     NOT NULL,
    [Incepted Status]       VARCHAR (1)      NULL,
    [Statement]             VARCHAR (50)     NOT NULL,
    [Position]              VARCHAR (50)     NOT NULL,
    [Balance]               VARCHAR (50)     NOT NULL,
    [Amount]                NUMERIC (38, 12) NULL,
    [Amount_Disc]           NUMERIC (38, 12) NULL,
    [FinChg]                VARCHAR (200)    NULL,
    [AuditCreateDateTime]   DATETIME2 (7)    Default(getdate()) NOT NULL ,
    [AuditUserCreate]       NVARCHAR (510)   Default(suser_sname()) NOT NULL
);
GO
CREATE CLUSTERED INDEX [cix_FinChg] ON [Reporting].[FinChg] (RunID) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]

