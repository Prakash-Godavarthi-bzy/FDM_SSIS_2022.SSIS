﻿CREATE TABLE [Reporting].[JournalOutputFinal] (
    [RunIDs]              VARCHAR (50)    NULL,
    [AccountingDate]      VARCHAR (10)    NULL,
    [version]             INT             NOT NULL,
    [client]              VARCHAR (255)   NULL,
    [dim_7]               VARCHAR (255)   NULL,
    [dim_2]               VARCHAR (100)   NULL,
    [dim_3]               VARCHAR (10)    NULL,
    [account]             VARCHAR (25)    NULL,
    [dim_4]               VARCHAR (10)    NOT NULL,
    [dim_5]               VARCHAR (2)     NULL,
    [dim_6]               VARCHAR (2)     NULL,
    [voucher_type]        VARCHAR (3)     NULL,
    [dim_1]               VARCHAR (25)    NULL,
    [description]         VARCHAR (100)   NULL,
    [currency]            VARCHAR (10)    NOT NULL,
    [voucher_date]        DATE            NULL,
    [trans_date]          DATE            NULL,
    [cur_amount]          NUMERIC (18, 2) NULL,
    [AuditUser]           VARCHAR (25)    NULL,
    [AuditCreateDatetime] DATETIME2 (7)   NULL
);




GO
CREATE CLUSTERED COLUMNSTORE INDEX [cci_JournalOutputFinal]
    ON [Reporting].[JournalOutputFinal];

