﻿CREATE TABLE [Reporting].[ReAllocationJournalOutput] (
    [AccountSign]             VARCHAR (20)    NULL,
    [DiscUndiscType]          VARCHAR (20)    NULL,
    [RunIDs]                  VARCHAR (50)    NULL,
    [AccountingDate]          DATE            NULL,
    [FocusGroup]              VARCHAR (100)   NULL,
    [TriFocusCode]            VARCHAR (25)    NOT NULL,
    [IFRS17TriFocusCode]      VARCHAR (25)    NULL,
    [RI_Flag]                 VARCHAR (2)     NULL,
    [Programme]               VARCHAR (100)   NULL,
    [YOA]                     INT             NOT NULL,
    [YOI]                     INT             NULL,
    [CCY]                     VARCHAR (10)    NOT NULL,
    [Statement]               VARCHAR (50)    NOT NULL,
    [Balance]                 VARCHAR (50)    NOT NULL,
    [Position]                VARCHAR (50)    NOT NULL,
    [UOA]                     VARCHAR (100)   NULL,
    [Amount]                  NUMERIC (18, 2) NULL,
    [AgressoEntityCode]       VARCHAR (255)   NULL,
    [AgressoIFRS17ClientCode] VARCHAR (255)   NULL,
    [TransactionType]         VARCHAR (3)     NULL,
    [AccountCode]             VARCHAR (25)    NULL,
    [JournalDescription]      VARCHAR (100)   NULL,
    [AuditUser]               VARCHAR (25)    NULL,
    [AuditCreateDatetime]     DATETIME2 (7)   NULL
);




GO
CREATE CLUSTERED COLUMNSTORE INDEX [cci_ReAllocationJournalOutput]
    ON [Reporting].[ReAllocationJournalOutput];

