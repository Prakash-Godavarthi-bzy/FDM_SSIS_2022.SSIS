﻿CREATE TABLE [Reporting].[CSM_CloseUOAPostSub] (
    [Id]                    BIGINT        IDENTITY (1, 1) NOT NULL,
    [RunID]                 INT           NOT NULL,
    [TFYOI]                 VARCHAR (100) NULL,
    [Entity]                VARCHAR (20)  NOT NULL,
    [FocusGroup]            VARCHAR (100) NULL,
    [UOA]                   VARCHAR (100) NULL,
    [YOI]                   INT           NULL,
    [Programme]             VARCHAR (100) NULL,
    [IFRS17 Tri Focus Code] VARCHAR (25)  NULL,
    [Trifocus]              VARCHAR (100) NULL,
    [TFUOA]                 VARCHAR (100) NULL,
    [Onerosity]             CHAR (2)      NULL,
    [CSM_LC]                VARCHAR (10)  NULL,
	[AuditCreateDateTime] DATETIME2(7) DEFAULT (getdate())  NOT NULL ,
	[AuditUserCreate]     NVARCHAR (510)  DEFAULT (suser_sname())NOT NULL
);
GO
CREATE CLUSTERED INDEX [cix_CSM_CloseUOAPostSub] ON [Reporting].[CSM_CloseUOAPostSub] (RunID) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]




