﻿/*=============================================================================
Author			: Hemomsu Subodh Lakkaraju
Creation Date	: 1 October 2024
Description		: This SPROC gets triggered via IFRS17 Journcal Creation 
				  application in the experience journal screen to populate the
				  CSM locked to Current Disc rates.
				  For further information please refer the below ticket -
				  https://beazley.atlassian.net/browse/I17-7768

Updated on  : 16 jan 2025
Description : Change transaction type to X3 for all values https://beazley.atlassian.net/browse/I17-8129
==============================================================================*/
CREATE	PROCEDURE [Reporting].[usp_MergeJournalOutputLockedCSMtoCurrent]  (
        @pAccDate DATE,           /* Accounting DATE */
        @pRunIDs VARCHAR(50),              /* RunIDs */
        @pUser VARCHAR(25)        /* User requesting this action (for audit) */
      )
AS

BEGIN
  DECLARE @Trancount INT = @@Trancount,
          @createDatetime DATETIME2(7) = GETDATE();  

		/*Inserted next 5 lines by Sainath to update Journal Audit Log table as InProgress*/
		UPDATE	[PWAPS].[JournalAuditLog]
		SET		[CSM_Disc_Expr_Adj] = 'InProgress'
		WHERE	RunIDs=@pRunIDs				AND
				AccountingDate=@pAccDate	AND
				ValidityFlag=1
  
  BEGIN TRY
    IF @Trancount = 0 BEGIN TRAN;

    IF @pAccDate IS NULL THROW 51001, 'The accounting DATE has to be set.', 1;  
    IF @pRunIDs IS NULL THROW 51001, 'Run IDs must be set.', 1;  

    IF @pUser IS NULL SET @pUser = 'Unknown'

    print 'processing - deleting existing rows in target table'

    /* Delete ROWS for User/RunIDs that already exists in target table */
    DELETE FROM [Reporting].[JournalOutputLockedCSMtoCurrent]
     WHERE RunIDs = @pRunIDs
       AND AccountingDate = @pAccDate;

    /* Deriving RunID's based on user input runID*/

	--DECLARE @DRunID VARCHAR(50) 
	

	--SELECT   @DRunID


	print 'processing - inserting rows to target table'
	

    /* Call SPs to Populate data */



	INSERT INTO Reporting.JournalOutputLockedCSMtoCurrent
	(
		[AccountSign]
      ,[DiscUndiscType]
      ,[RunIDs]
      ,[AccountingDate]
      ,[FocusGroup]
      ,[TriFocusCode]
      ,[IFRS17TriFocusCode]
      ,[RI_Flag]
      ,[Programme]
      ,[YOA]
      ,[YOI]
      ,[CCY]
      ,[Statement]
      ,[Balance]
      ,[Position]
      ,[UOA]
      ,[Amount]
      ,[AgressoEntityCode]
      ,[AgressoIFRS17ClientCode]
      ,[TransactionType]
      ,[AccountCode]
      ,[JournalDescription]
      ,[AuditUser]
      ,[AuditCreateDatetime]
	  )
	  SELECT			
				RT.AccountSign,
				RT.DiscUndiscType,
				@pRunIDs,
				@pAccDate AccountingDate,
				Focus_Group,
				TriFocusCode,
				IFRS17TriFocusCode,
				RI_Flag,
				Programme,
				YoA,
				YoI,
				CCY,
				CASE WHEN AccountSign = 'Positive' THEN 'EXPR' --x2
					 WHEN AccountSign = 'Negative' THEN 'IFIE' --x3
					 ELSE 'UNK'
					 END [Statement],
				Balance,
				Position,
				UoA,
				CASE	WHEN AccountSign = 'Positive' THEN SUM(Disc_current_exp_adj)
						WHEN AccountSign = 'Negative' THEN SUM(Disc_current_exp_adj)*-1 
						END AS Amount,
				CASE	WHEN CEA.Entity LIKE 'No Entity' THEN ''
						ELSE  jem.[Agresso Entity Code]
				END		AS AgressoEntityCode,
				CASE	WHEN CEA.Entity LIKE 'No Entity'  THEN 'IA'
						ELSE jem.[Agresso IFRS17 Client Code]
				END		AgressoIFRS17ClientCode,
				CASE	WHEN RT.AccountSign = 'Positive' THEN 'X3'
						WHEN RT.AccountSign = 'Negative' THEN 'X3'
						ELSE ' '
						END TransactionType,
				CASE	-- Balance PR Mapping for NfnChgO / NfNchngV
						WHEN AccountSign = 'Positive' AND RI_Flag = 'I' AND Balance = 'Pr' AND Position = 'NFNChgV' THEN 40120
						WHEN AccountSign = 'Negative' AND RI_Flag = 'I' AND Balance = 'Pr' AND Position = 'NFNChgV' THEN 40500
						WHEN AccountSign = 'Positive' AND RI_Flag = 'I' AND Balance = 'Pr' AND Position = 'NFNChgO' THEN 40120
						WHEN AccountSign = 'Negative' AND RI_Flag = 'I' AND Balance = 'Pr' AND Position = 'NFNChgO' THEN 40500

						WHEN AccountSign = 'Positive' AND RI_Flag = 'O' AND Balance = 'Pr' AND Position = 'NFNChgV' THEN 40320
						WHEN AccountSign = 'Negative' AND RI_Flag = 'O' AND Balance = 'Pr' AND Position = 'NFNChgV' THEN 40511
						WHEN AccountSign = 'Positive' AND RI_Flag = 'O' AND Balance = 'Pr' AND Position = 'NFNChgO' THEN 40320
						WHEN AccountSign = 'Negative' AND RI_Flag = 'O' AND Balance = 'Pr' AND Position = 'NFNChgO' THEN 40511
						-- Balance BR Mapping for NfnChgO / NfNchngV
						WHEN AccountSign = 'Positive' AND RI_Flag = 'I' AND Balance = 'Br' AND Position = 'NFNChgV' THEN 40236
						WHEN AccountSign = 'Negative' AND RI_Flag = 'I' AND Balance = 'Br' AND Position = 'NFNChgV' THEN 40500
						WHEN AccountSign = 'Positive' AND RI_Flag = 'I' AND Balance = 'Br' AND Position = 'NFNChgO' THEN 40236
						WHEN AccountSign = 'Negative' AND RI_Flag = 'I' AND Balance = 'Br' AND Position = 'NFNChgO' THEN 40500

						WHEN AccountSign = 'Positive' AND RI_Flag = 'O' AND Balance = 'Br' AND Position = 'NFNChgV' THEN 40320
						WHEN AccountSign = 'Negative' AND RI_Flag = 'O' AND Balance = 'Br' AND Position = 'NFNChgV' THEN 40511
						WHEN AccountSign = 'Positive' AND RI_Flag = 'O' AND Balance = 'Br' AND Position = 'NFNChgO' THEN 40320
						WHEN AccountSign = 'Negative' AND RI_Flag = 'O' AND Balance = 'Br' AND Position = 'NFNChgO' THEN 40511
						-- Balance OAE Mapping for NfnChgO / NfNchngV
						WHEN AccountSign = 'Negative' AND RI_Flag = 'I' AND Balance = 'OAE' AND Position = 'NFNChgV' THEN 40500
						WHEN AccountSign = 'Positive' AND RI_Flag = 'I' AND Balance = 'OAE' AND Position = 'NFNChgO' THEN 40237
						WHEN AccountSign = 'Positive' AND RI_Flag = 'I' AND Balance = 'OAE' AND Position = 'NFNChgV' THEN 40237
						WHEN AccountSign = 'Negative' AND RI_Flag = 'I' AND Balance = 'OAE' AND Position = 'NFNChgO' THEN 40500
						ELSE ''
						END [AccountCode],
					CONCAT('Lck',CASE WHEN AccountSign = 'Positive' THEN 'EXPR'
					 WHEN AccountSign = 'Negative' THEN 'IFIE' 
					 ELSE 'UNK'
					 END,'_',RI_Flag,Balance,Position),
					@pUser,
					GETDATE()
FROM			Reporting.CSM_ExperienceAdjustments CEA
CROSS			APPLY (
					SELECT 'Positive' AccountSign, 'Disc' DiscUndiscType
					UNION ALL
					SELECT 'Negative', 'Disc'

				) RT
LEFT JOIN 
				(
					SELECT		[Entity Code],[Agresso Entity Code],[Agresso IFRS17 Client Code]
					FROM		DIM.JournalEntitiesMapping
				) JEM
ON				CEA.Entity = JEM.[Entity Code]
WHERE			RunID IN (	SELECT		 value
							FROM		string_split(@PRunIDs,'_')
							WHERE		VALUE not LIKE '[a-z]%'
						)
AND				Balance in ('OAE','Pr','Br')
and				Position in ('NFNChgV' ,'NFNChgO')
GROUP			BY RT.AccountSign,
				RT.DiscUndiscType,
				Focus_Group,
				TriFocusCode,
				IFRS17TriFocusCode,
				RI_Flag,
				Programme,
				YoA,
				YoI,
				CCY,
				CASE WHEN AccountSign = 'Positive' THEN 'EXPR' --x2
					 WHEN AccountSign = 'Negative' THEN 'IFIE' --x3
					 ELSE 'UNK'
					 END ,
				Balance,
				Position,
				UoA,
				CASE	WHEN CEA.Entity LIKE 'No Entity' THEN ''
						ELSE  jem.[Agresso Entity Code]
				END		,
				CASE	WHEN CEA.Entity LIKE 'No Entity'  THEN 'IA'
						ELSE jem.[Agresso IFRS17 Client Code]
				END		,
				CASE	WHEN RT.AccountSign = 'Positive' THEN 'X3'
						WHEN RT.AccountSign = 'Negative' THEN 'X3'
						ELSE ' '
						END ,
				CASE	-- Balance PR Mapping for NfnChgO / NfNchngV
						WHEN AccountSign = 'Positive' AND RI_Flag = 'I' AND Balance = 'Pr' AND Position = 'NFNChgV' THEN 40120
						WHEN AccountSign = 'Negative' AND RI_Flag = 'I' AND Balance = 'Pr' AND Position = 'NFNChgV' THEN 40500
						WHEN AccountSign = 'Positive' AND RI_Flag = 'I' AND Balance = 'Pr' AND Position = 'NFNChgO' THEN 40120
						WHEN AccountSign = 'Negative' AND RI_Flag = 'I' AND Balance = 'Pr' AND Position = 'NFNChgO' THEN 40500

						WHEN AccountSign = 'Positive' AND RI_Flag = 'O' AND Balance = 'Pr' AND Position = 'NFNChgV' THEN 40320
						WHEN AccountSign = 'Negative' AND RI_Flag = 'O' AND Balance = 'Pr' AND Position = 'NFNChgV' THEN 40511
						WHEN AccountSign = 'Positive' AND RI_Flag = 'O' AND Balance = 'Pr' AND Position = 'NFNChgO' THEN 40320
						WHEN AccountSign = 'Negative' AND RI_Flag = 'O' AND Balance = 'Pr' AND Position = 'NFNChgO' THEN 40511
						-- Balance BR Mapping for NfnChgO / NfNchngV
						WHEN AccountSign = 'Positive' AND RI_Flag = 'I' AND Balance = 'Br' AND Position = 'NFNChgV' THEN 40236
						WHEN AccountSign = 'Negative' AND RI_Flag = 'I' AND Balance = 'Br' AND Position = 'NFNChgV' THEN 40500
						WHEN AccountSign = 'Positive' AND RI_Flag = 'I' AND Balance = 'Br' AND Position = 'NFNChgO' THEN 40236
						WHEN AccountSign = 'Negative' AND RI_Flag = 'I' AND Balance = 'Br' AND Position = 'NFNChgO' THEN 40500

						WHEN AccountSign = 'Positive' AND RI_Flag = 'O' AND Balance = 'Br' AND Position = 'NFNChgV' THEN 40320
						WHEN AccountSign = 'Negative' AND RI_Flag = 'O' AND Balance = 'Br' AND Position = 'NFNChgV' THEN 40511
						WHEN AccountSign = 'Positive' AND RI_Flag = 'O' AND Balance = 'Br' AND Position = 'NFNChgO' THEN 40320
						WHEN AccountSign = 'Negative' AND RI_Flag = 'O' AND Balance = 'Br' AND Position = 'NFNChgO' THEN 40511
						-- Balance OAE Mapping for NfnChgO / NfNchngV
						WHEN AccountSign = 'Negative' AND RI_Flag = 'I' AND Balance = 'OAE' AND Position = 'NFNChgV' THEN 40500
						WHEN AccountSign = 'Positive' AND RI_Flag = 'I' AND Balance = 'OAE' AND Position = 'NFNChgO' THEN 40237
						WHEN AccountSign = 'Positive' AND RI_Flag = 'I' AND Balance = 'OAE' AND Position = 'NFNChgV' THEN 40237
						WHEN AccountSign = 'Negative' AND RI_Flag = 'I' AND Balance = 'OAE' AND Position = 'NFNChgO' THEN 40500
						ELSE ''
						END ,
					CONCAT('Lck',CASE WHEN AccountSign = 'Positive' THEN 'EXPR'
					 WHEN AccountSign = 'Negative' THEN 'IFIE' 
					 ELSE 'UNK'
					 END,'_',RI_Flag,Balance,Position)



    IF @Trancount = 0 COMMIT;
	/*Inserted next 5 lines by Sainath to update Journal Audit Log table as Success*/
		UPDATE	[PWAPS].[JournalAuditLog]
		SET		[CSM_Disc_Expr_Adj] = 'Success'
		WHERE	RunIDs=@pRunIDs				AND
				AccountingDate=@pAccDate	AND
				ValidityFlag=1
    END TRY
    BEGIN CATCH
        IF @Trancount = 0 ROLLBACK;
        THROW;
		/*Inserted next 5 lines by Sainath to update Journal Audit Log table as Failed*/
		UPDATE	[PWAPS].[JournalAuditLog]
		SET		[CSM_Disc_Expr_Adj] = 'Failed'
		WHERE	RunIDs=@pRunIDs				AND
				AccountingDate=@pAccDate	AND
				ValidityFlag=1
    END CATCH

END;