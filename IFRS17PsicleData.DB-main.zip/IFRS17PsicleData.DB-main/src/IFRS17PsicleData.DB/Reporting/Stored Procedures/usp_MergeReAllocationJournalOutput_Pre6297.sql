﻿/*
CREATE PROCEDURE [Reporting].[usp_MergeReAllocationJournalOutput] 

(
 @pAccDate DATE,             /* Accounting DATE */
 @RunId Varchar(50),		 /* Selected RunId*/
 @pUser VARCHAR(25)			/* User requesting this action (for audit) */
  
)
AS
BEGIN
  DECLARE @Trancount INT = @@Trancount,
   @createDatetime DATETIME2(7) = GETDATE()
	BEGIN TRY
		IF @Trancount = 0 
	   BEGIN TRAN;
			/*Added as part of cleanup duplicate regarding ticket #4386*/
	        DELETE FROM [Reporting].[ReAllocationJournalOutput]
			WHERE AccountingDate = @pAccDate
            AND RunIDs = @RunId;

	INSERT INTO [Reporting].[ReAllocationJournalOutput]
           ([AccountSign], [DiscUndiscType], [RunIDs], [AccountingDate], [FocusGroup], [TriFocusCode], [IFRS17TriFocusCode], [RI_Flag], [Programme], 
            [YOA], [YOI], [CCY], [Statement], [Balance], [Position], [UOA], [Amount],[AgressoEntityCode], [AgressoIFRS17ClientCode], [TransactionType], [AccountCode], 
            [JournalDescription], [AuditUser], [AuditCreateDatetime])

	SELECT A.AccountSign, A.DiscUndiscType, A.RunIDs, A.AccountingDate, A.Portfolio, A.TriFocusCode, A.IFRS17TriFocusCode, A.RI_Flag, A.Programme, A.YOA, A.YOI, A.CCY,'Ra alloc' AS [Statement]
	, A.Balance, A.Position, A.UOA, A.Amount, A.AgressoEntityCode, A.AgressoIFRS17ClientCode, 'X7' AS [TransactionType], A.AccountCode, A.JournalDescription,       @pUser,    @createDatetime
	FROM
	(
	SELECT RowTypes.AccountSign,
           RowTypes.DiscUndiscType,
           src.RunIDs, 
           src.AccountingDate, 
           src.Portfolio,
           src.TriFocusCode,
           src.IFRS17TriFocusCode,
           src.RI_Flag,
           src.Programme,
           src.YOA,--9999, --'NOYOA'  /*Changed the Default Value Back to Mapping From Source as per #4868 */
           src.YOI,--9999, --'NOIFRSYOI' /*Changed the Default Value Back to Mapping From Source as per #4868 */
           src.CCY,
            
           src.Balance,  --'Ra alloc'  /* Changed the default value to relevant value as per #5120 */
           src.Position, --'Ra alloc'  /* Changed the default value to relevant value as per #5120 */
           src.UOA,
           case
             when RowTypes.AccountSign = 'Positive' and RowTypes.DiscUndiscType = 'Undisc' then src.Amount
             when RowTypes.AccountSign = 'Negative' and RowTypes.DiscUndiscType = 'Undisc' then src.Amount*(-1)
             when RowTypes.AccountSign = 'Positive' and RowTypes.DiscUndiscType = 'Disc' then src.Disc
             when RowTypes.AccountSign = 'Negative' and RowTypes.DiscUndiscType = 'Disc' then src.Disc*(-1)          
           end as Amount,
		   src.AgressoEntityCode,
           src.AgressoIFRS17ClientCode, 
           /*case
             when RowTypes.DiscUndiscType = 'Disc' then src.TransactionType_Disc
             when RowTypes.DiscUndiscType = 'Undisc' then src.TransactionType_Undisc
           end as TransactionType,*/
           case
             when RowTypes.AccountSign = 'Positive' and RowTypes.DiscUndiscType = 'Undisc' then src.AccountCode_ReAlloc_Pos
             when RowTypes.AccountSign = 'Negative' and RowTypes.DiscUndiscType = 'Undisc' then src.AccountCode_ReAlloc_Neg
             when RowTypes.AccountSign = 'Positive' and RowTypes.DiscUndiscType = 'Disc' then src.AccountCode_ReAlloc_Pos
             when RowTypes.AccountSign = 'Negative' and RowTypes.DiscUndiscType = 'Disc' then src.AccountCode_ReAlloc_Neg
           end as AccountCode,
           CONCAT('Ra alloc','_',src.RI_Flag,src.Balance,src.Position) AS JournalDescription /* suffix Included as per #5120 */
      FROM Reporting.JournalInputDataYTD src
      CROSS JOIN (
            SELECT 'Positive' AccountSign, 'Undisc' as DiscUndiscType
            UNION ALL
            SELECT 'Negative', 'Undisc'
            UNION ALL
            SELECT 'Positive', 'Disc'
            UNION ALL
            SELECT 'Negative', 'Disc'
      ) RowTypes
    where 
	(src.Position = 'Closing')  
      and case
             when RowTypes.AccountSign = 'Positive' and RowTypes.DiscUndiscType = 'Undisc' then src.AccountCode_ReAlloc_Pos
             when RowTypes.AccountSign = 'Negative' and RowTypes.DiscUndiscType = 'Undisc' then src.AccountCode_ReAlloc_Neg
             when RowTypes.AccountSign = 'Positive' and RowTypes.DiscUndiscType = 'Disc' then src.AccountCode_ReAlloc_Pos
             when RowTypes.AccountSign = 'Negative' and RowTypes.DiscUndiscType = 'Disc' then src.AccountCode_ReAlloc_Neg
           end is not null
    /* SET PARAMS AS YOU NEED */
      and AccountingDate = @pAccDate
	  and RunIDs = @RunId
	  and AssetLiabilityType='Asset'
	  and RI_Flag = 'I'
	  and Balance <> 'CSM_LC'
	  and (CSM_LC is null or CSM_LC = 'CSM')

	  UNION ALL

	  SELECT RowTypes.AccountSign,
           RowTypes.DiscUndiscType,
           src.RunIDs, 
           src.AccountingDate, 
           src.Portfolio,
           src.TriFocusCode,
           src.IFRS17TriFocusCode,
           src.RI_Flag,
           src.Programme,
           src.YOA,--9999, --'NOYOA'  /*Changed the Default Value Back to Mapping From Source as per #4868 */
           src.YOI,--9999, --'NOIFRSYOI' /*Changed the Default Value Back to Mapping From Source as per #4868 */
           src.CCY,
           src.Balance,  --'Ra alloc'  /* Changed the default value to relevant value as per #5120 */
           src.Position, --'Ra alloc'  /* Changed the default value to relevant value as per #5120 */
           src.UOA,
           case
             when RowTypes.AccountSign = 'Positive' and RowTypes.DiscUndiscType = 'Undisc' then src.Amount
             when RowTypes.AccountSign = 'Negative' and RowTypes.DiscUndiscType = 'Undisc' then src.Amount*(-1)
             when RowTypes.AccountSign = 'Positive' and RowTypes.DiscUndiscType = 'Disc' then src.Disc
             when RowTypes.AccountSign = 'Negative' and RowTypes.DiscUndiscType = 'Disc' then src.Disc*(-1)          
           end as Amount,
		   src.AgressoEntityCode,
           src.AgressoIFRS17ClientCode, 
           /*case
             when RowTypes.DiscUndiscType = 'Disc' then src.TransactionType_Disc
             when RowTypes.DiscUndiscType = 'Undisc' then src.TransactionType_Undisc
           end as TransactionType,*/
           case
             when RowTypes.AccountSign = 'Positive' and RowTypes.DiscUndiscType = 'Undisc' then src.AccountCode_ReAlloc_Pos
             when RowTypes.AccountSign = 'Negative' and RowTypes.DiscUndiscType = 'Undisc' then src.AccountCode_ReAlloc_Neg
             when RowTypes.AccountSign = 'Positive' and RowTypes.DiscUndiscType = 'Disc' then src.AccountCode_ReAlloc_Pos
             when RowTypes.AccountSign = 'Negative' and RowTypes.DiscUndiscType = 'Disc' then src.AccountCode_ReAlloc_Neg
           end as AccountCode,
           CONCAT('Ra alloc','_',src.RI_Flag,src.Balance,src.Position) AS JournalDescription /* suffix Included as per #5120 */
      FROM Reporting.JournalInputDataYTD src
      CROSS JOIN (
            SELECT 'Positive' AccountSign, 'Undisc' as DiscUndiscType
            UNION ALL
            SELECT 'Negative', 'Undisc'
            UNION ALL
            SELECT 'Positive', 'Disc'
            UNION ALL
            SELECT 'Negative', 'Disc'
      ) RowTypes
    where 
	 case
             when RowTypes.AccountSign = 'Positive' and RowTypes.DiscUndiscType = 'Undisc' then src.AccountCode_ReAlloc_Pos
             when RowTypes.AccountSign = 'Negative' and RowTypes.DiscUndiscType = 'Undisc' then src.AccountCode_ReAlloc_Neg
             when RowTypes.AccountSign = 'Positive' and RowTypes.DiscUndiscType = 'Disc' then src.AccountCode_ReAlloc_Pos
             when RowTypes.AccountSign = 'Negative' and RowTypes.DiscUndiscType = 'Disc' then src.AccountCode_ReAlloc_Neg
           end is not null
    /* SET PARAMS AS YOU NEED */
      and AccountingDate = @pAccDate
	  and RunIDs = @RunId
	  and AssetLiabilityType = 'Liability'
	  and RI_Flag = 'O'
	   /*PK - 250923 Added below condition for CR I17-5744 */
	  and (([STATEMENT] = 'CSM'  and Position = 'Closing' AND Balance <> 'CSM_LC'  and CSM_LC = 'CSM')
	    OR
	    ( [STATEMENT] <> 'CSM' and Position = 'Closing' AND Balance <> 'CSM_LC' AND CSM_LC is null ))
	  )A  
      ;

		IF @Trancount = 0 COMMIT;
    END TRY
    
	BEGIN CATCH
        IF @Trancount = 0 ROLLBACK;
        THROW;
    END CATCH

END
*/