﻿CREATE PROCEDURE [Reporting].[usp_MergeJournalOutputFinal] (
        @pRunIDs VARCHAR(50),     /* RunIDs */
        @pAccDate DATE,           /* Accounting DATE */
        @pUser VARCHAR(25)        /* User requesting this action (for audit) */
      )
AS

BEGIN
  DECLARE @Trancount INT = @@Trancount,
          @createDatetime DATETIME2(7) = GETDATE(),
		  @LastVersion INT = 0,
          @RowCount BIGINT = 0;

          		/*  Update script Added by Sainath to log Audit information  */
		UPDATE [PWAPS].[JournalAuditLog]
		SET		[JournalOutputFinal]	=	'InProgress',
				[JournalOutputRowCount] =	0
		WHERE	[RunIDs]			=	@pRunIDs		AND
				[AccountingDate]	=	@pAccDate		AND
				[ValidityFlag]		=	1
  
  BEGIN TRY
    IF @Trancount = 0 BEGIN TRAN;

    IF @pAccDate is NULL THROW 51001, 'The accounting DATE has to be set.', 1;  
    IF @pRunIDs is NULL THROW 51001, 'Run IDs must be set.', 1;  

    IF @pUser is NULL set @pUser = 'Unknown'

	print 'processing - get last version RunIDs'

	SELECT @LastVersion = ISNULL(MAX(version), 0) + 1 FROM [Reporting].[JournalOutputFinal]
	WHERE RunIDs = @pRunIDs
    AND AccountingDate = @pAccDate;

    print 'processing - inserting rows to target table without zero values'

	/*Inclusion of JournalOutputLockedCSMtoCurrent into output table*/
	
	DROP TABLE IF EXISTS #JournalOutputLockedCSMtoCurrent;

		SELECT	RunIDs,
		AccountingDate,
		AgressoIFRS17ClientCode	AS client,
		AgressoEntityCode			AS		dim_7,
		CASE
			WHEN	PR.ID	IS	NOT NULL	THEN	PR.TransformationValue
			ELSE	CASE
						WHEN	CAST(JO.Programme AS VARCHAR)	<>		'GROSS'		THEN	'RI'
						ELSE	CAST(JO.Programme AS VARCHAR)
						END
			END		dim_2,
		CASE
			WHEN	CAST(JO.YOI AS VARCHAR)	= '9999'	THEN	'NOIFRSYOI'
			ELSE	CAST(JO.YOI AS VARCHAR)
			END		dim_3,
		JO.AccountCode				AS		account,
		CASE
			WHEN	CAST(JO.YOA AS VARCHAR) = '9999'	THEN	'NOYOA'
			ELSE	CAST(JO.YOA AS VARCHAR)
			END		dim_4,
		''	AS		dim_5,
		CASE
			WHEN PF.ID is not null THEN PF.TransformationValue
			WHEN JO.RI_Flag	=	'O'		THEN	'R'
			ELSE JO.RI_Flag
			END		dim_6,
		JO.TransactionType			AS		voucher_type,
		CASE	WHEN	TR.ID	IS	NOT	NULL	AND		TR.TransformationValue <> 'Unknown'		THEN	TR.TransformationValue
				WHEN	JO.TriFocusCode <> 'Unknown'	THEN	JO.TriFocusCode
				ELSE	'NOTRIFOC'
				END		dim_1,
		JO.JournalDescription		AS		description,
		JO.CCY						AS		currency,
		JO.AccountingDate			AS		voucher_date,
		JO.AccountingDate			AS		trans_date,
		JO.Amount					AS		cur_amount
		INTO	#JournalOutputLockedCSMtoCurrent
		FROM	Reporting.JournalOutputLockedCSMtoCurrent	JO
		LEFT JOIN PWAPS.MetadataRulesGAAP PF
			ON JO.AccountCode = PF.AccountCode and PF.Attribute = 'Portfolio'
		LEFT JOIN PWAPS.MetadataRulesGAAP PR
			ON JO.AccountCode = PR.AccountCode and PR.Attribute = 'Programme'
		LEFT JOIN PWAPS.MetadataRulesGAAP TR
			ON JO.AccountCode = TR.AccountCode and TR.Attribute = 'Trifocus'
		WHERE	JO.Amount <> 0
		AND		JO.RunIDs = @pRunIDs
		AND		JO.AccountingDate = @pAccDate
		AND		JO.AccountCode not in ('88888')

	/*Inclusion of JournalOutputLockedCSMtoCurrent into output table*/

    /* Insert data to target table without zero values*/
	INSERT INTO [Reporting].[JournalOutputFinal]
           ([RunIDs]
		   ,[AccountingDate]
		   ,[version]
           ,[client]
           ,[dim_7]
           ,[dim_2]
           ,[dim_3]
           ,[account]
           ,[dim_4]
           ,[dim_5]
           ,[dim_6]
           ,[voucher_type]
           ,[dim_1]
           ,[description]
           ,[currency]
           ,[voucher_date]
           ,[trans_date]
           ,[cur_amount]
           ,[AuditUser]
           ,[AuditCreateDatetime])
    
(	select 
		RunIDs
      ,AccountingDate
      ,@LastVersion as version
      ,client
      ,dim_7
      ,dim_2
      ,dim_3
      ,account
      ,dim_4
      ,dim_5
      ,dim_6
      ,voucher_type
      ,dim_1 
      ,description
      ,currency
      ,voucher_date
      ,trans_date
      ,ROUND(SUM(cur_amount), 2) as cur_amount
      ,@pUser as AuditUser
      ,@createDatetime as AuditCreateDatetime
	from [PWAPS].[vw_JournalOutputFinal]
	where cur_amount <> 0
	and RunIDs = @pRunIDs
	and AccountingDate = @pAccDate
	AND account not in ('88888')
	GROUP BY RunIDs
      ,AccountingDate
	  ,client
      ,dim_7
      ,dim_2
      ,dim_3
      ,account
      ,dim_4
      ,dim_5
      ,dim_6
      ,voucher_type
      ,dim_1
      ,description
      ,currency
      ,voucher_date
      ,trans_date
	HAVING ROUND(SUM(cur_amount), 2) <> 0

/*Combined JournalOutputLockedCSMtoCurrent table to journal final output by Sainath*/
UNION ALL

	select 
		RunIDs
      ,AccountingDate
      ,@LastVersion as version
      ,client
      ,dim_7
      ,dim_2
      ,dim_3
      ,account
      ,dim_4
      ,dim_5
      ,dim_6
      ,voucher_type
      ,dim_1 
      ,description
      ,currency
      ,voucher_date
      ,trans_date
      ,ROUND(SUM(cur_amount), 2) as cur_amount
      ,@pUser as AuditUser
      ,@createDatetime as AuditCreateDatetime
	from #JournalOutputLockedCSMtoCurrent
	GROUP BY RunIDs
      ,AccountingDate
	  ,client
      ,dim_7
      ,dim_2
      ,dim_3
      ,account
      ,dim_4
      ,dim_5
      ,dim_6
      ,voucher_type
      ,dim_1
      ,description
      ,currency
      ,voucher_date
      ,trans_date
	HAVING ROUND(SUM(cur_amount), 2) <> 0

/*Combined JournalOutputLockedCSMtoCurrent table to journal final output by Sainath*/

)

    SET @RowCount = @@ROWCOUNT;
    IF @Trancount = 0 COMMIT;

    	/*  Update script Added by Sainath to log Audit information  */

	UPDATE [PWAPS].[JournalAuditLog]
	SET		[JournalOutputFinal]					=	'Success' ,
			[JournalOutputRowCount]	=	@RowCount
	WHERE	RunIDs			=	@pRunIDs		AND
			AccountingDate	=	@pAccDate		AND
			ValidityFlag	=	1

    END TRY
    BEGIN CATCH
        IF @Trancount = 0 ROLLBACK;
        THROW;

        /*  Update script Added by Sainath to log Audit information  */

		UPDATE [PWAPS].[JournalAuditLog]
		SET		[JournalOutputFinal]					=	'Failed'
		WHERE	RunIDs			=	@pRunIDs		AND
				AccountingDate	=	@pAccDate		AND
				ValidityFlag	=	1;

    END CATCH

END;