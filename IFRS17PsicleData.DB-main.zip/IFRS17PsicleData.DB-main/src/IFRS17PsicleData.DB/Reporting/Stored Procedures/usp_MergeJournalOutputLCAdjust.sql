﻿


----DECLARE
----@pQ1 INT = 4,               
----@pQ2 INT = 5,               
----@pQ3 INT = 0,               
----@pQ4 INT = 0,               
----@pStatement VARCHAR(25) = 'CSM',
----@pAccDate DATE = '2019-06-30'  ,       
----@pUser VARCHAR(25) = 'Pooja Khandual',     
----@pRunType VARCHAR(25)   = 'Actual'




CREATE   PROCEDURE [Reporting].[usp_MergeJournalOutputLCAdjust] (
        @pQ1 INT,                 /* RunID for 1st Quarter */
        @pQ2 INT,                 /* RunID for 2nd Quarter */
        @pQ3 INT,                 /* RunID for 3rd Quarter */
        @pQ4 INT,                 /* RunID for 4th Quarter */
        @pStatement VARCHAR(25),  /* Statement type, must be LIC, LRC or CSM */
        @pAccDate DATE,           /* Accounting DATE */
        @pUser VARCHAR(25),       /* User requesting this action (for audit) */
        @pRunType VARCHAR(25),     /* Run type - i.e. Actual, forecast (Fx) or budget (Bx) */
		@pJournalType Varchar(100), /* journal type i.e QTD Jurnal/YTD Journal*/
		@pPK_JournalAuditLogID BIGINT/*Introduced by Sainath to update Journal Audit Table*/
      )
AS

BEGIN


  DECLARE @Trancount INT = @@Trancount,
          @createDatetime DATETIME2(7) = GETDATE(),
          @runIDs VARCHAR(50),
          @pQ4_PY int = 0,
		  @pQTD_RunID int = 0;

		  /*Inserted next 3 lines by Sainath to update Journal Audit Log table as InProgress*/
		UPDATE	[PWAPS].[JournalAuditLog]
		SET		GenerateCSMLC = 'InProgress'
		WHERE	PK_JournalAuditLogID =	@pPK_JournalAuditLogID

  BEGIN TRY
    IF @Trancount = 0 
	BEGIN TRAN;
		IF  @pStatement = 'CSM'
			BEGIN

				IF @pUser is NULL set @pUser = 'Unknown'

				SET @runIDs = CONCAT_WS ('_', @pRunType, ISNULL(@pQ1, 0), ISNULL(@pQ2, 0), ISNULL(@pQ3, 0), ISNULL(@pQ4, 0));

				IF @pJournalType = 'YTD'
						SET @pQ4_PY = (SELECT [Opening Balances Id] FROM IFRS17DataMart.PWAPS.IFRS17CalcUI_RunLog WHERE Pk_RequestId =  @pQ1)
				ELSE
						SET @pQTD_RunID = case 
											   when ISNULL(@pQ4, 0) > 0 then @pQ4 
											   when ISNULL(@pQ3, 0) > 0 then @pQ3 
											   when ISNULL(@pQ2, 0) > 0 then @pQ2 
											   when ISNULL(@pQ1, 0) > 0 then @pQ1 
											 end;
						SELECT @pQ4_PY = [Opening Balances Id] FROM IFRS17DataMart.PWAPS.IFRS17CalcUI_RunLog WHERE Pk_RequestId = @pQTD_RunID;
		
				BEGIN
				print 'processing - deleting existing rows in target table'

				/* Delete ROWS for User/RunIDs that already exists in target table */
				DELETE FROM [Reporting].[JournalOutputLCAdjMovement]
				 WHERE [Statement] = @pStatement
				   AND RunIDs = @runIDs
				   AND AccountingDate = @pAccDate;


				print 'processing - inserting rows to target table'
	

				INSERT INTO [Reporting].[JournalOutputLCAdjMovement]
						   ([AccountSign], [DiscUndiscType],[JournalType], [RunIDs], [AccountingDate], [FocusGroup], [TriFocusCode], [IFRS17TriFocusCode], [RI_Flag], [Programme], 
							[YOA], [YOI], [CCY], [Statement], [Balance], [Position], [UOA], [Amount], [AgressoEntityCode], [AgressoIFRS17ClientCode], [TransactionType], [AccountCode], 
							[JournalDescription], [AuditUser], [AuditCreateDatetime])

					SELECT RowTypes.AccountSign
					, NULL AS DiscUndiscType
					,@pJournalType
					, @runIDs as RunIDs
					, @pAccDate as AccountingDate
					, src.FocusGroup
					, src.[Tri Focus Code]	AS TriFocusCode
					, src.[IFRS17 Tri Focus Code] AS	IFRS17TriFocusCode
					, src.RI_Flag
					, src.Programme
					, src.YOA
					, src.YOI
					, src.CCY
					, src.[Statement]
					, src.Balance
					, 'LCmvmnt' as Position
					, src.UOA
					, case
						when RowTypes.AccountSign = 'Positive' then src.Amount_Diff
						when RowTypes.AccountSign = 'Negative' then src.Amount_Diff * (-1)
					  end as Amount
					, CASE
						 WHEN @pRunType = 'Actual' then src.[Agresso Entity Code]
						 ELSE @pRunType
					   END AS   AgressoEntityCode
					, src.[Agresso IFRS17 Client Code]   AgressoIFRS17ClientCode, 
					'X8' AS TransactionType,
					case
						when RowTypes.AccountSign = 'Positive' then '40220'
						when RowTypes.AccountSign = 'Negative' then '87110'
					end as AccountCode
					, ConCat('LC_mvt_',CONCAT([Statement],CSM_LC,RI_Flag,'mvmnt',Balance)) As JournalDescription
					, @pUser AS AuditUser
					, @createDatetime AS AuditCreateDatetime
					FROM
					(
					SELECT RI_Flag, UOA,Balance, YOA, YOI, [Tri Focus Code],[IFRS17 Tri Focus Code], CCY,FocusGroup, Programme,'LC' AS CSM_LC, 'CSM' AS [Statement]	
						, jem.[Agresso Entity Code], jem.[Agresso IFRS17 Client Code], SUM(Amount_Diff) AS Amount_Diff
					FROM (SELECT RI_Flag, UOA,Balance, YOA, YOI, [Tri Focus Code],[IFRS17 Tri Focus Code], Entity,CCY,FocusGroup, Programme, Amount_Diff 
							FROM [PWAPS].[udf_GetUnBalancedLC](@pQ4_PY,@pQ1, @pQ2, @pQ3, @pQ4,@pAccDate,@pJournalType)) T1
						  LEFT JOIN Dim.JournalEntitiesMapping jem ON T1.Entity = jem.[Entity Code]	
					GROUP BY RI_Flag, UOA,Balance, YOA, YOI, [Tri Focus Code],[IFRS17 Tri Focus Code], CCY,FocusGroup, Programme,jem.[Agresso Entity Code], jem.[Agresso IFRS17 Client Code]
					) src
					CROSS JOIN (
								SELECT 'Positive' AccountSign
								UNION ALL
								SELECT 'Negative'
								) RowTypes;
			END
		END
    IF @Trancount = 0 COMMIT;
	  /*Inserted next 3 lines by Sainath to update Journal Audit Log table as Success*/
		UPDATE	[PWAPS].[JournalAuditLog]
		SET		GenerateCSMLC = 'Success'
		WHERE	PK_JournalAuditLogID =	@pPK_JournalAuditLogID
    END TRY
    BEGIN CATCH
        IF @Trancount = 0 ROLLBACK;
        THROW;
		  /*Inserted next 3 lines by Sainath to update Journal Audit Log table as Failed*/
		UPDATE	[PWAPS].[JournalAuditLog]
		SET		GenerateCSMLC = 'Failed'
		WHERE	PK_JournalAuditLogID =	@pPK_JournalAuditLogID
    END CATCH
    

    
END


