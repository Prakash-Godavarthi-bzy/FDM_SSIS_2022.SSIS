﻿


CREATE PROCEDURE [Reporting].[usp_MergeJournalOutputAdjustment] (
        @pRunIDs VARCHAR(50),              /* RunIDs */
        @pStatement VARCHAR(25),  /* Statement type, must be LIC, LRC or CSM */
        @pAccDate DATE,           /* Accounting DATE */
        @pUser VARCHAR(25)        /* User requesting this action (for audit) */,
		@pJournalType VARCHAR(100) /*JournalType QTD Journal/YTD Journal*/,
		@pPK_JournalAuditLogID BIGINT/*Introduced by Sainath to update Journal Audit Table*/
      )
AS

BEGIN
  DECLARE @Trancount INT = @@Trancount,
          @createDatetime DATETIME2(7) = GETDATE();  

	/*Inserted next 3 lines by Sainath to update Journal Audit Log table as InProgress*/
		UPDATE	[PWAPS].[JournalAuditLog]
		SET		AdjustmentJournal = 'InProgress'
		WHERE	PK_JournalAuditLogID =	@pPK_JournalAuditLogID
  
  BEGIN TRY
    IF @Trancount = 0 BEGIN TRAN;

    IF @pStatement NOT IN ('LIC', 'LRC', 'CSM') THROW 51000, 'The statement must be set to LIC, LRC or CSM.', 1;  
    IF @pAccDate is NULL THROW 51001, 'The accounting DATE has to be set.', 1;  
    IF @pRunIDs is NULL THROW 51001, 'Run IDs must be set.', 1;  

    IF @pUser is NULL set @pUser = 'Unknown'

    print 'processing - deleting existing rows in target table'

    /* Delete ROWS for User/RunIDs that already exists in target table */
    DELETE FROM [Reporting].[JournalOutputAdjustment]
     WHERE Statement = @pStatement
       AND RunIDs = @pRunIDs
       AND AccountingDate = @pAccDate;

    print 'processing - inserting rows to target table'

    /* Insert data to target table */

    INSERT INTO [Reporting].[JournalOutputAdjustment]
               ([AccountSign], [DiscUndiscType], [JournalType],[RunIDs], [AccountingDate], [FocusGroup], [TriFocusCode], [IFRS17TriFocusCode], [RI_Flag], [Programme], 
                [YOA], [YOI], [CCY], [Statement], [Balance], [Position], [UOA], [Amount], [AgressoEntityCode], [AgressoIFRS17ClientCode], [TransactionType], [AccountCode], 
                [JournalDescription], [AuditUser], [AuditCreateDatetime])
        SELECT RowTypes.AccountSign,
               RowTypes.DiscUndiscType,
			  @pJournalType,
               src.RunIDs, 
               src.AccountingDate, 
               src.FocusGroup,
               src.TriFocusCode,
               src.IFRS17TriFocusCode,
               src.RI_Flag,
               src.Programme,
               src.YOA, 
               src.YOI,
               src.CCY,
               src.Statement, 
               src.Balance,
               src.Position,
               src.UOA,
               CASE
                 WHEN RowTypes.AccountSign = 'Positive' AND RowTypes.DiscUndiscType = 'Undisc' THEN src.Amount
                 WHEN RowTypes.AccountSign = 'Negative' AND RowTypes.DiscUndiscType = 'Undisc' THEN src.Amount*(-1)
                 WHEN RowTypes.AccountSign = 'Positive' AND RowTypes.DiscUndiscType = 'Disc' THEN src.Disc
                 WHEN RowTypes.AccountSign = 'Negative' AND RowTypes.DiscUndiscType = 'Disc' THEN src.Disc*(-1)          
               END as Amount,
               src.AgressoEntityCode,
               src.AgressoIFRS17ClientCode, 
               CASE
                 WHEN RowTypes.DiscUndiscType = 'Disc' THEN src.TransactionType_Disc
                 WHEN RowTypes.DiscUndiscType = 'Undisc' THEN src.TransactionType_Undisc
               END as TransactionType,
               CASE
                 WHEN RowTypes.AccountSign = 'Positive' AND RowTypes.DiscUndiscType = 'Undisc' THEN src.AccountCode_Undisc_Pos
                 WHEN RowTypes.AccountSign = 'Negative' AND RowTypes.DiscUndiscType = 'Undisc' THEN src.AccountCode_Undisc_Neg
                 WHEN RowTypes.AccountSign = 'Positive' AND RowTypes.DiscUndiscType = 'Disc' THEN src.AccountCode_Disc_Pos
                 WHEN RowTypes.AccountSign = 'Negative' AND RowTypes.DiscUndiscType = 'Disc' THEN src.AccountCode_Disc_Neg
               END as AccountCode,
               src.JournalDescription,
               @pUser,
               @createDatetime
          FROM (SELECT src.RunIDs, /* SUM to required grain */
                       src.AccountingDate, 
                       src.FocusGroup,
                       src.TriFocusCode,
                       src.IFRS17TriFocusCode,
                       src.RI_Flag,
                       src.Programme,
                       src.YOA, 
                       src.YOI,
                       src.CCY,
                       src.Statement, 
                       src.Balance,
                       src.Position,
                       src.UOA,
                       src.AgressoEntityCode,
                       src.AgressoIFRS17ClientCode, 
                       src.TransactionType_Disc,
                       src.TransactionType_Undisc,
                       src.JournalDescription,
                       src.AccountCode_Undisc_Pos,
                       src.AccountCode_Undisc_Neg,
                       src.AccountCode_Disc_Pos,
                       src.AccountCode_Disc_Neg,
                       sum(src.Amount) as Amount,
                       sum(src.Amount_disc) as Amount_disc,
                       sum(src.Disc) as Disc
                  FROM Reporting.JournalInputDataYTD src
                 WHERE AccountingDate = @pAccDate
                   AND Statement = @pStatement
                   AND RunIDs = @pRunIDs
                GROUP BY src.RunIDs,
                         src.AccountingDate, 
                         src.FocusGroup,
                         src.TriFocusCode,
                         src.IFRS17TriFocusCode,
                         src.RI_Flag,
                         src.Programme,
                         src.YOA, 
                         src.YOI,
                         src.CCY,
                         src.Statement, 
                         src.Balance,
                         src.Position,
                         src.UOA,
                         src.AgressoEntityCode,
                         src.AgressoIFRS17ClientCode, 
                         src.TransactionType_Disc,
                         src.TransactionType_Undisc,
                         src.JournalDescription,
                         src.AccountCode_Undisc_Pos,
                         src.AccountCode_Undisc_Neg,
                         src.AccountCode_Disc_Pos,
                         src.AccountCode_Disc_Neg
               ) src
          CROSS JOIN (
                SELECT 'Positive' AccountSign, 'Undisc' as DiscUndiscType
                UNION ALL
                SELECT 'Negative', 'Undisc'
                UNION ALL
                SELECT 'Positive', 'Disc'
                UNION ALL
                SELECT 'Negative', 'Disc'
          ) RowTypes
        WHERE (src.Position not like '%Open%' and src.Position not like '%Closing%')
          AND COALESCE(CASE
                 WHEN RowTypes.AccountSign = 'Positive' AND RowTypes.DiscUndiscType = 'Undisc' THEN NULLIF(src.AccountCode_Undisc_Pos, '')
                 WHEN RowTypes.AccountSign = 'Negative' AND RowTypes.DiscUndiscType = 'Undisc' THEN NULLIF(src.AccountCode_Undisc_Neg, '')
                 WHEN RowTypes.AccountSign = 'Positive' AND RowTypes.DiscUndiscType = 'Disc' THEN NULLIF(src.AccountCode_Disc_Pos, '')
                 WHEN RowTypes.AccountSign = 'Negative' AND RowTypes.DiscUndiscType = 'Disc' THEN NULLIF(src.AccountCode_Disc_Neg, '')
               END, 'Missing Mapping') <> 'Missing Mapping'
          ;

    IF @Trancount = 0 COMMIT;

	/*Inserted next 3 lines by Sainath to update Journal Audit Log table as Success*/
		UPDATE	[PWAPS].[JournalAuditLog]
		SET		AdjustmentJournal = 'Success'
		WHERE	PK_JournalAuditLogID =	@pPK_JournalAuditLogID

    END TRY
    BEGIN CATCH
        IF @Trancount = 0 ROLLBACK;
        THROW;
	
	/*Inserted next 3 lines by Sainath to update Journal Audit Log table as Failed*/
		UPDATE	[PWAPS].[JournalAuditLog]
		SET		AdjustmentJournal = 'Failed'
		WHERE	PK_JournalAuditLogID =	@pPK_JournalAuditLogID

    END CATCH

END;

