﻿

--DECLARE
--@pAccDate DATE = '2021-12-31',           /* Accounting DATE */
--@pRunIDs VARCHAR(50) = 'Actual_40_48_49_50',              /* RunIDs */
--@pUser VARCHAR(25)  ='Pooja Khandual'



CREATE   PROCEDURE [Reporting].[usp_PopulateExperienceJournalIFIE_EXPR] (
        @pAccDate DATE,           /* Accounting DATE */
        @pRunIDs VARCHAR(50),              /* RunIDs */
        @pUser VARCHAR(25)        /* User requesting this action (for audit) */
      )
AS

BEGIN
  DECLARE @Trancount INT = @@Trancount,
          @createDatetime DATETIME2(7) = GETDATE();  
  
  BEGIN TRY
    IF @Trancount = 0 BEGIN TRAN;

    IF @pAccDate IS NULL THROW 51001, 'The accounting DATE has to be set.', 1;  
    IF @pRunIDs IS NULL THROW 51001, 'Run IDs must be set.', 1;  

    IF @pUser IS NULL SET @pUser = 'Unknown'



DROP TABLE IF EXISTS #ExpJouList
SELECT T1.RunIDs, T1.AccountingDate, T1.RI_Flag, T1.Balance, T1.Position, T1.ExprType,T1.AccountCodePositiveVE, T1.AccountCodeNegativeVE
INTO #ExpJouList
FROM PWAPS.ExperienceJournal T1
INNER JOIN PWAPS.udf_GetUnBalancedJournalOutputFinal(@pRunIDs,@pAccDate) T2 ON T1.RunIDs = T2.RunIDs AND T1.RI_Flag = T2.RI_Flag AND T1.Balance = T2.Balance AND T1.Position = T2.Position
WHERE T1.AccountingDate = @pAccDate
AND T1.RunIDs = @pRunIDs
AND CONCAT(T1.Balance, T1.Position) IN ('PrNFNChgV','PrNFNChgO','BrNFNChgV','BrNFNChgO','OAENFNChgV','OAENFNChgO')

DROP TABLE IF EXISTS #DATA1
SELECT *
INTO #DATA1
FROM 
(
SELECT			src.RunIDs,
                src.AccountingDate, 
                src.FocusGroup,
                src.TriFocusCode,
                src.IFRS17TriFocusCode,
                src.RI_Flag,
                src.Programme,
                src.YOA, 
                src.YOI,
                src.CCY,
                src.Balance,
                src.Position,
                src.UOA,
                src.AgressoEntityCode,
                src.AgressoIFRS17ClientCode, 
                src.TransactionType_Disc,
                src.TransactionType_Undisc,
                src.JournalDescription,
                src.AccountCode_Undisc_Pos,
                src.AccountCode_Undisc_Neg,
                src.AccountCode_Disc_Pos,
                src.AccountCode_Disc_Neg,
               SUM(CASE WHEN src.statement = 'CSM' THEN src.Amount ELSE 0 END) - SUM(CASE WHEN statement = 'LRC' THEN src.Amount ELSE 0 END) AS Amount,---Round
               SUM(CASE WHEN src.statement = 'CSM' THEN src.Amount_disc ELSE 0 END) - SUM(CASE WHEN statement = 'LRC' THEN src.Amount_disc ELSE 0 END) AS Amount_disc,--Round
               SUM(CASE WHEN src.statement = 'CSM' THEN src.Disc ELSE 0 END) - SUM(CASE WHEN statement = 'LRC' THEN src.Disc ELSE 0 END) AS Disc         --Round     
          FROM [Reporting].[JournalInputDataYTD] src
         WHERE AccountingDate = @pAccDate
           AND RunIDs = @pRunIDs
           AND Statement in ('CSM', 'LRC')
		   AND CONCAT(Balance, Position) in ('PrNFNChgV','PrNFNChgO','BrNFNChgV','BrNFNChgO','OAENFNChgV','OAENFNChgO')
        GROUP BY src.RunIDs,
                src.AccountingDate, 
                src.FocusGroup,
                src.TriFocusCode,
                src.IFRS17TriFocusCode,
                src.RI_Flag,
                src.Programme,
                src.YOA, 
                src.YOI,
                src.CCY,
                src.Balance,
                src.Position,
                src.UOA,
                src.AgressoEntityCode,
                src.AgressoIFRS17ClientCode, 
                src.TransactionType_Disc,
                src.TransactionType_Undisc,
                src.JournalDescription,
                src.AccountCode_Undisc_Pos,
                src.AccountCode_Undisc_Neg,
                src.AccountCode_Disc_Pos,
                src.AccountCode_Disc_Neg
)SRC
CROSS JOIN (
			SELECT 'Positive' AccountSign, 'Undisc' as DiscUndiscType
			UNION ALL
			SELECT 'Negative', 'Undisc'
			UNION ALL
			SELECT 'Positive', 'Disc'
			UNION ALL
			SELECT 'Negative', 'Disc'
			) RowTypes
WHERE (src.Position not like '%Open%' and src.Position not like '%Closing%')
AND COALESCE(CASE
			WHEN RowTypes.AccountSign = 'Positive' AND RowTypes.DiscUndiscType = 'Undisc' THEN NULLIF(src.AccountCode_Undisc_Pos, '')
			WHEN RowTypes.AccountSign = 'Negative' AND RowTypes.DiscUndiscType = 'Undisc' THEN NULLIF(src.AccountCode_Undisc_Neg, '')
			WHEN RowTypes.AccountSign = 'Positive' AND RowTypes.DiscUndiscType = 'Disc' THEN NULLIF(src.AccountCode_Disc_Pos, '')
			WHEN RowTypes.AccountSign = 'Negative' AND RowTypes.DiscUndiscType = 'Disc' THEN NULLIF(src.AccountCode_Disc_Neg, '')
			END, 'Missing Mapping') <> 'Missing Mapping'





DROP TABLE IF EXISTS #DATA2
SELECT
       src.AccountSign, 
       src.DiscUndiscType,
       src.RunIDs,
       src.AccountingDate,
       src.FocusGroup,
       src.TriFocusCode,
       src.IFRS17TriFocusCode,
       src.RI_Flag,
       src.Programme,
       src.YOA,
       src.YOI,
       src.CCY,
       CASE 
		   WHEN src.AccountSign = 'Positive' AND SRC.DiscUndiscType = 'Undisc' THEN 'EXPR'
		   WHEN src.AccountSign = 'Negative' AND SRC.DiscUndiscType = 'Undisc'	THEN 'EXPR'
		   WHEN src.AccountSign = 'Positive' AND SRC.DiscUndiscType = 'Disc'  	THEN 'IFIE'
		   WHEN src.AccountSign = 'Negative' AND SRC.DiscUndiscType = 'Disc'  	THEN 'IFIE'
	  END AS Statement,
       src.Balance,
       src.Position,
       src.UOA,
       CASE
         WHEN src.AccountSign = 'Positive' AND src.DiscUndiscType = 'Undisc' THEN src.Amount
         WHEN src.AccountSign = 'Negative' AND src.DiscUndiscType = 'Undisc' THEN src.Amount*(-1)
         WHEN src.AccountSign = 'Positive' AND src.DiscUndiscType = 'Disc'   THEN src.Disc
         WHEN src.AccountSign = 'Negative' AND src.DiscUndiscType = 'Disc'   THEN src.Disc*(-1)        
       END AS Amount,
       src.AgressoEntityCode,
       src.AgressoIFRS17ClientCode,
		CASE
			WHEN src.DiscUndiscType = 'Disc' THEN src.TransactionType_Disc
			WHEN src.DiscUndiscType = 'Undisc' THEN src.TransactionType_Undisc
		END as TransactionType
INTO #DATA2
from #DATA1 SRC


INSERT INTO [Reporting].[JournalOutputExperience]
            ([AccountSign], [DiscUndiscType], [RunIDs], [AccountingDate], [FocusGroup], [TriFocusCode], [IFRS17TriFocusCode], [RI_Flag], [Programme], 
            [YOA], [YOI], [CCY], [Statement], [Balance], [Position], [UOA], [Amount], [AgressoEntityCode], [AgressoIFRS17ClientCode], [TransactionType], [AccountCode], 
            [JournalDescription], [AuditUser], [AuditCreateDatetime])
SELECT src.AccountSign, 
       src.DiscUndiscType,
       src.RunIDs,
       src.AccountingDate,
       src.FocusGroup,
       src.TriFocusCode,
       src.IFRS17TriFocusCode,
       src.RI_Flag,
       src.Programme,
       src.YOA,
       src.YOI,
       src.CCY,
       src.[Statement],
       src.Balance,
       src.Position,
       src.UOA,
       src.Amount,
       src.AgressoEntityCode,
       src.AgressoIFRS17Clientcode,
	   src.TransactionType,
       CASE
         WHEN src.AccountSign = 'Positive' THEN ExprAccMap.AccountCodePositiveVE
         WHEN src.AccountSign = 'Negative' THEN ExprAccMap.AccountCodeNegativeVE
       END AS Accountcode,
       CONCAT(src.[Statement],'_', src.RI_Flag, src.Balance, src.Position) AS JournalDescription,
	   @pUser AS AuditUser,
       @createDatetime AS AuditCreateDatetime

FROM #DATA2 src
INNER JOIN   #ExpJouList ExprAccMap ON (SRC.RunIDs = ExprAccMap.RunIDs and SRC.AccountingDate = ExprAccMap.AccountingDate and	src.Balance = ExprAccMap.Balance 
			AND src.Position = ExprAccMap.Position AND src.RI_Flag = ExprAccMap.RI_Flag AND src.[Statement] = ExprAccMap.ExprType)

	;

    IF @Trancount = 0 COMMIT;
    END TRY
    BEGIN CATCH
        IF @Trancount = 0 ROLLBACK;
        THROW;
    END CATCH

END;