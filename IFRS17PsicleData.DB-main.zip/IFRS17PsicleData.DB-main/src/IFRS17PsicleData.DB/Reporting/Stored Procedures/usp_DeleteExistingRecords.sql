﻿CREATE PROCEDURE [Reporting].[usp_DeleteExistingRecords] (
        @pAccDate DATE,           /* Accounting DATE */
        @pRunIDs VARCHAR(50)            /* RunIDs */
		)
AS
 
BEGIN
  DECLARE @Trancount INT = @@Trancount;

  BEGIN TRY
        IF @Trancount = 0 BEGIN TRAN;
    /* Delete ROWS for User/RunIDs that already exists in target table */

    DELETE FROM [Reporting].[ReAllocationJournalOutput]
     WHERE RunIDs = @pRunIDs
       AND AccountingDate = @pAccDate;
 
	DELETE FROM [Reporting].[JournalOutputExperience]
	 WHERE RunIDs=@pRunIDs
       AND AccountingDate= @pAccDate;
 
        IF @Trancount = 0 COMMIT;
  END TRY

  BEGIN CATCH
        IF @Trancount = 0 ROLLBACK;
        THROW;
  END CATCH

END;