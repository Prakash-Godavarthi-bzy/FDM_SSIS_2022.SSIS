﻿--DECLARE
--@pQ1 INT = 0,               
--@pQ2 INT = 64,               
--@pQ3 INT = 0,               
--@pQ4 INT = 0,               
--@pStatement VARCHAR(25) = 'LRC',
--@pAccDate DATE = '2023-06-30',         
--@pUser VARCHAR(25) = 'Pooja Khandual',     
--@pRunType VARCHAR(25)   = 'Actual',
--@pJournalType VARCHAR(100) = 'QTD'




CREATE PROCEDURE [Reporting].[usp_MergeJournalInputDataYTD] 
(
        @pQ1 INT,                 /* RunID for 1st Quarter */
        @pQ2 INT,                 /* RunID for 2nd Quarter */
        @pQ3 INT,                 /* RunID for 3rd Quarter */
        @pQ4 INT,                 /* RunID for 4th Quarter */
        @pStatement VARCHAR(25),  /* Statement type, must be LIC, LRC or CSM */
        @pAccDate DATE,           /* Accounting DATE */
        @pUser VARCHAR(25),       /* User requesting this action (for audit) */
        @pRunType VARCHAR(25)     /* Run type - i.e. Actual, forecast (Fx) or budget (Bx) */,
		@pJournalType VARCHAR(100) /*Journal Type -i.e QTD Journal,YTD Journal*/,
		@pPK_JournalAuditLogID BIGINT/*Introduced by Sainath to update Journal Audit Table*/
      )
AS

BEGIN

/*		Calling UDT table to log Activities within SPROC		*/
		
		
/*		End of Declaratiion										*/

	/*Inserted next 3 lines by Sainath to update Journal Audit Log table as InProgress*/
		UPDATE	[PWAPS].[JournalAuditLog]
		SET		GenerateYTD = 'InProgress'
		WHERE	PK_JournalAuditLogID =	@pPK_JournalAuditLogID

  DECLARE @Trancount INT = @@Trancount,
          @createDatetime DATETIME2(7) = GETDATE(),
          @runIDs VARCHAR(50),
          @LastRunID int = 0;
      

  BEGIN TRY
    IF @Trancount = 0 BEGIN TRAN;
		DECLARE @LogTable PWAPS.utt_ActivityLog
		DECLARE @ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID)
		DECLARE @ExecutionSequence INT = 0
		INSERT @LogTable(ActivityName, ActivityStatus, ActivityMessage) SELECT @ActivityName, 5, 'Execution for SPROC [usp_MergeJournalInputDataYTD] has started'

    IF @pStatement not in ('LIC', 'LRC', 'CSM') THROW 51000, 'The statement must be set to LIC, LRC or CSM.', 1;  
    IF @pAccDate is NULL THROW 51001, 'The accounting DATE has to be set.', 1;  
    IF @pRunType is NULL THROW 51002, 'The RunType has to be set.', 1;  
	
    IF @pUser is NULL set @pUser = 'Unknown'

	--INSERT @LogTable(ActivityName, ActivityStatus, ActivityMessage) SELECT @ActivityName, 4, 'Execution stopped due to the following '+Coalesce(@pStatement,@pAccDate,@pRunType)

    set @runIDs = CONCAT_WS ('_', @pRunType, ISNULL(@pQ1, 0), ISNULL(@pQ2, 0), ISNULL(@pQ3, 0), ISNULL(@pQ4, 0));

    SET @LastRunID = case 
                       when ISNULL(@pQ4, 0) > 0 then @pQ4 
                       when ISNULL(@pQ3, 0) > 0 then @pQ3 
                       when ISNULL(@pQ2, 0) > 0 then @pQ2 
                       when ISNULL(@pQ1, 0) > 0 then @pQ1 
                     end;

    /* Create working table with YTD values
            1.	For Position = opening:  use Amount of Q1 (do not sum the values)
            2.	For Position = closing: use Amount of last selected Quarter (do not sum the values)
            3.	For all other “dimensionality”: sum Amounts FROM Q1 to last selected Quarter (standard YTD calculation)
    */
    print concat(FORMAT (getdate(), 'hh:mm:ss'), ' - processing - base columns')
	INSERT @LogTable(ActivityName, ActivityStatus, ActivityMessage) SELECT @ActivityName, 5, concat(FORMAT (getdate(), 'hh:mm:ss'), ' - processing - base columns')

	--RAISERROR(N'Starting ytd',0,0) with nowait;

    DROP TABLE IF EXISTS #work_YTD_base; 
    create table #work_YTD_base (
        Amount	numeric(18,2),
        Conv_Amount	numeric(18,2),
        Amount_disc	numeric(18,2),
        Conv_Amount_disc	numeric(18,2),
        FocusGroup	varchar(100),
		Portfolio varchar(100),
        Entity	varchar(20),
        TriFocusCode	varchar(25),
        IFRS17TriFocusCode	varchar(25),
        Programme	varchar(100),
        RI_Flag	varchar(2),
        YOA	int,
        YOI	int,
        QOI_End_Date	date,
        CCY	varchar(10),
        InceptedStatus	char(1),
        Statement	varchar(50),
        Balance	varchar(50),
        Position	varchar(50),
        UOA	varchar(100),
        CSM_LC	varchar(10),
        RunIDs	varchar(50),
        AccountingDate	date,
        AuditUser	varchar(25),
        AuditCreateDatetime	datetime2(7)
    );



if @pStatement = 'LIC' 
begin
	INSERT @LogTable(ActivityName, ActivityStatus, ActivityMessage) SELECT @ActivityName, 5, @pStatement+' Process has started'

	--RAISERROR(N'in lic',0,0) with nowait;
 INSERT INTO #work_YTD_base (Amount, Amount_disc, Conv_Amount, Conv_Amount_disc, FocusGroup, Portfolio, Entity, TriFocusCode, IFRS17TriFocusCode, Programme, RI_Flag, YOA, YOI, QOI_End_Date, CCY, InceptedStatus, Statement, Balance, Position, UOA, CSM_LC, RunIDs, AccountingDate, AuditUser, AuditCreateDatetime)
 SELECT 
		ROUND(SUM(CASE @pJournalType
						WHEN 'YTD'
						THEN case 
								when src.Position like '%Open%'  and src.RunID <> @pQ1 then 0 
								when src.Position like '%Closing%' and src.RunID <> @LastRunID then 0
								else src.Amount 
							  end
						ELSE src.Amount 
				 END ), 2) AS Amount,
		ROUND(SUM(CASE @pJournalType
						WHEN 'YTD'
						THEN case 
								when src.Position like '%Open%'  and src.RunID <> @pQ1 then 0 
								when src.Position like '%Closing%' and src.RunID <> @LastRunID then 0
								else src.Amount_disc
							 end
						ELSE src.Amount_disc
				END ), 2) AS Amount_disc,
		ROUND(SUM(CASE @pJournalType
						WHEN 'YTD'
						THEN case 
								when src.Position like '%Open%'  and src.RunID <> @pQ1 then 0 
								when src.Position like '%Closing%' and src.RunID <> @LastRunID then 0
			                    else src.Conv_Amount
		                     end
						ELSE src.Conv_Amount
				  END), 2) AS Conv_Amount,
		ROUND(SUM(CASE @pJournalType
						WHEN 'YTD'
						THEN case 
								when src.Position like '%Open%'  and src.RunID <> @pQ1 then 0 
								when src.Position like '%Closing%' and src.RunID <> @LastRunID then 0
								else src.Conv_Amount_disc
							end
						ELSE src.Conv_Amount_disc
				 END), 2) AS Conv_Amount_disc,
        src.FocusGroup,
		src.Portfolio,
        src.Entity,
        src.TriFocusCode,
        src.IFRS17TriFocusCode,
        src.Programme,
        src.RI_Flag,
        src.YOA,
        src.YOI,
        src.QOI_End_Date,
        src.CCY,
        src.InceptedStatus,
        src.[Statement],
        src.Balance,
        src.Position,
        src.UOA,
        src.CSM_LC,
        @runIDs AS RunIDs,
        @pAccDate AS AccountingDate,
        @pUser AS AuditUser,
        @createDatetime AS AuditCreateDatetime
 FROM (
		 SELECT RunID,FocusGroup,	Entity,	[Tri Focus Code] AS TriFocusCode,	[IFRS17 Tri Focus Code] AS IFRS17TriFocusCode,	Programme,	RI_Flag,	YOA,	YOI,	QOI_End_Date,	CCY, [Incepted Status] AS InceptedStatus,
			[Statement],	Balance,	Position, UOA, Portfolio, Amount  ,Amount_disc  ,Conv_Amount  ,Conv_Amount_disc, NULL AS CSM_LC
		FROM Reporting.LIC_DiscountedData
		WHERE RunID IN (@pQ1, @pQ2, @pQ3, @pQ4)
		AND	Position NOT IN ('NFNChgO','NFNChgv')
	
	)src
 GROUP BY src.FocusGroup, src.Portfolio, src.Entity, src.TriFocusCode, src.IFRS17TriFocusCode, src.Programme, src.RI_Flag, src.YOA, src.YOI,
          src.QOI_End_Date, src.CCY, src.InceptedStatus, src.Statement, src.Balance, src.Position, src.UOA, src.CSM_LC
 HAVING ROUND(SUM(CASE @pJournalType
						WHEN 'YTD'
						THEN case 
								when src.Position like '%Open%'  and src.RunID <> @pQ1 then 0 
								when src.Position like '%Closing%' and src.RunID <> @LastRunID then 0
								else src.Amount 
							  end
						ELSE src.Amount 
				 END ), 2) + 
        ROUND(SUM(CASE @pJournalType
						WHEN 'YTD'
						THEN case 
								when src.Position like '%Open%'  and src.RunID <> @pQ1 then 0 
								when src.Position like '%Closing%' and src.RunID <> @LastRunID then 0
								else src.Amount_disc
							 end
						ELSE src.Amount_disc
				END ), 2) <> 0;
end; /* LIC */

else if @pStatement = 'LRC' 
begin
	INSERT @LogTable(ActivityName, ActivityStatus, ActivityMessage) SELECT @ActivityName, 5, @pStatement+' Process has started'


	--RAISERROR(N'in lrc',0,0) with nowait;
 INSERT INTO #work_YTD_base (Amount, Amount_disc, Conv_Amount, Conv_Amount_disc, FocusGroup, Portfolio, Entity, TriFocusCode, IFRS17TriFocusCode, Programme, RI_Flag, YOA, YOI, QOI_End_Date, CCY, InceptedStatus, Statement, Balance, Position, UOA, CSM_LC, RunIDs, AccountingDate, AuditUser, AuditCreateDatetime)
 SELECT ROUND(SUM(CASE @pJournalType
						WHEN 'YTD'
						THEN case 
								when src.Position like '%Open%'  and src.RunID <> @pQ1 then 0 
								when src.Position like '%Closing%' and src.RunID <> @LastRunID then 0
								else src.Amount 
							  end
						ELSE src.Amount 
				 END ), 2) AS Amount,
		ROUND(SUM(CASE @pJournalType
						WHEN 'YTD'
						THEN case 
								when src.Position like '%Open%'  and src.RunID <> @pQ1 then 0 
								when src.Position like '%Closing%' and src.RunID <> @LastRunID then 0
								else src.Amount_disc
							 end
						ELSE src.Amount_disc
				END ), 2) AS Amount_disc,
		ROUND(SUM(CASE @pJournalType
						WHEN 'YTD'
						THEN case 
								when src.Position like '%Open%'  and src.RunID <> @pQ1 then 0 
								when src.Position like '%Closing%' and src.RunID <> @LastRunID then 0
			                    else src.Conv_Amount
		                     end
						ELSE src.Conv_Amount
				  END), 2) AS Conv_Amount,
		ROUND(SUM(CASE @pJournalType
						WHEN 'YTD'
						THEN case 
								when src.Position like '%Open%'  and src.RunID <> @pQ1 then 0 
								when src.Position like '%Closing%' and src.RunID <> @LastRunID then 0
								else src.Conv_Amount_disc
							end
						ELSE src.Conv_Amount_disc
				 END), 2) AS Conv_Amount_disc,
        src.FocusGroup,
		src.Portfolio,
        src.Entity,
        src.TriFocusCode,
        src.IFRS17TriFocusCode,
        src.Programme,
        src.RI_Flag,
        src.YOA,
        src.YOI,
        src.QOI_End_Date,
        src.CCY,
        src.InceptedStatus,
        src.Statement,
        src.Balance,
        src.Position,
        src.UOA,
        src.CSM_LC,
        @runIDs AS RunIDs,
        @pAccDate AS AccountingDate,
        @pUser AS AuditUser,
        @createDatetime AS AuditCreateDatetime
   FROM 
		 (SELECT RunID,FocusGroup,	Entity,	[Tri Focus Code] AS TriFocusCode,	[IFRS17 Tri Focus Code] AS IFRS17TriFocusCode,	Programme,	RI_Flag,	YOA,	YOI,	QOI_End_Date,	CCY, [Incepted Status] AS InceptedStatus,
			[Statement],	Balance,	Position, UOA,Portfolio, Amount  ,Amount_disc  ,Conv_Amount  ,Conv_Amount_disc, NULL AS CSM_LC
		FROM Reporting.LRC_Post_BBNIAdjustments  
		WHERE RunID IN (@pQ1, @pQ2, @pQ3, @pQ4)
		)  src
   group by src.FocusGroup,src.Portfolio, src.Entity, src.TriFocusCode, src.IFRS17TriFocusCode, src.Programme, src.RI_Flag, src.YOA, src.YOI,
          src.QOI_End_Date, src.CCY, src.InceptedStatus, src.Statement, src.Balance, src.Position, src.UOA, src.CSM_LC
   HAVING ROUND(SUM(CASE @pJournalType
						WHEN 'YTD'
						THEN case 
								when src.Position like '%Open%'  and src.RunID <> @pQ1 then 0 
								when src.Position like '%Closing%' and src.RunID <> @LastRunID then 0
								else src.Amount 
							  end
						ELSE src.Amount 
				 END ), 2) + 
        ROUND(SUM(CASE @pJournalType
						WHEN 'YTD'
						THEN case 
								when src.Position like '%Open%'  and src.RunID <> @pQ1 then 0 
								when src.Position like '%Closing%' and src.RunID <> @LastRunID then 0
								else src.Amount_disc
							 end
						ELSE src.Amount_disc
				END ), 2) <> 0;

end; /* LRC */

else if @pStatement = 'CSM' 
begin
	INSERT @LogTable(ActivityName, ActivityStatus, ActivityMessage) SELECT @ActivityName, 5, @pStatement+' Process has started'


	--RAISERROR(N'in csm',0,0) with nowait;
 INSERT INTO #work_YTD_base (Amount, Amount_disc, Conv_Amount, Conv_Amount_disc, FocusGroup, Portfolio, Entity, TriFocusCode, IFRS17TriFocusCode, Programme, RI_Flag, YOA, YOI, QOI_End_Date, CCY, InceptedStatus, Statement, Balance, Position, UOA, CSM_LC, RunIDs, AccountingDate, AuditUser, AuditCreateDatetime)
 SELECT ROUND(SUM(CASE @pJournalType
						WHEN 'YTD'
						THEN case 
								when src.Position like '%Open%'  and src.RunID <> @pQ1 then 0 
								when src.Position like '%Closing%' and src.RunID <> @LastRunID then 0
								else src.Amount 
							  end
						ELSE src.Amount 
				 END ), 2) AS Amount,
		ROUND(SUM(CASE @pJournalType
						WHEN 'YTD'
						THEN case 
								when src.Position like '%Open%'  and src.RunID <> @pQ1 then 0 
								when src.Position like '%Closing%' and src.RunID <> @LastRunID then 0
								else src.Amount_disc
							 end
						ELSE src.Amount_disc
				END ), 2) AS Amount_disc,
		ROUND(SUM(CASE @pJournalType
						WHEN 'YTD'
						THEN case 
								when src.Position like '%Open%'  and src.RunID <> @pQ1 then 0 
								when src.Position like '%Closing%' and src.RunID <> @LastRunID then 0
			                    else src.Conv_Amount
		                     end
						ELSE src.Conv_Amount
				  END), 2) AS Conv_Amount,
		ROUND(SUM(CASE @pJournalType
						WHEN 'YTD'
						THEN case 
								when src.Position like '%Open%'  and src.RunID <> @pQ1 then 0 
								when src.Position like '%Closing%' and src.RunID <> @LastRunID then 0
								else src.Conv_Amount_disc
							end
						ELSE src.Conv_Amount_disc
				 END), 2) AS Conv_Amount_disc,
        src.FocusGroup,
		src.Portfolio,
        src.Entity,
        src.TriFocusCode,
        src.IFRS17TriFocusCode,
        src.Programme,
        src.RI_Flag,
        src.YOA,
        src.YOI,
        src.QOI_End_Date,
        src.CCY,
        src.InceptedStatus,
        src.Statement,
        src.Balance,
        src.Position,
        src.UOA,
        CSM_LC,
        @runIDs AS RunIDs,
        @pAccDate AS AccountingDate,
        @pUser AS AuditUser,
        @createDatetime AS AuditCreateDatetime
    FROM 
	(
	SELECT RunID,FocusGroup,	Entity,	[Tri Focus Code] AS TriFocusCode,	[IFRS17 Tri Focus Code] AS IFRS17TriFocusCode,	Programme,	RI_Flag,	YOA,	YOI,	QOI_End_Date,	CCY, [Incepted Status] AS InceptedStatus,
		[Statement],	Balance,	Position, UOA, Portfolio, Amount  ,Amount_disc  ,Conv_Amount  ,Conv_Amount_disc, CASE WHEN CSM_LC = 'LC' THEN 'LC' ELSE 'CSM' END CSM_LC
	FROM Reporting.CSM_Post_LCAdjustments  
	WHERE RunID IN (@pQ1, @pQ2, @pQ3, @pQ4)	
	)src
	group by src.FocusGroup,src.Portfolio, src.Entity, src.TriFocusCode, src.IFRS17TriFocusCode, src.Programme, src.RI_Flag, src.YOA, src.YOI,
          src.QOI_End_Date, src.CCY, src.InceptedStatus, src.Statement, src.Balance, src.Position, src.UOA, src.CSM_LC
	HAVING ROUND(SUM(CASE @pJournalType
						WHEN 'YTD'
						THEN case 
								when src.Position like '%Open%'  and src.RunID <> @pQ1 then 0 
								when src.Position like '%Closing%' and src.RunID <> @LastRunID then 0
								else src.Amount 
							  end
						ELSE src.Amount 
				 END ), 2) + 
           ROUND(SUM(CASE @pJournalType
						WHEN 'YTD'
						THEN case 
								when src.Position like '%Open%'  and src.RunID <> @pQ1 then 0 
								when src.Position like '%Closing%' and src.RunID <> @LastRunID then 0
								else src.Amount_disc
							 end
						ELSE src.Amount_disc
				END ), 2) <> 0;

end; /* CSM */



    /* Chandra */
	--RAISERROR(N'processing - prepare account mapping table',0,0) with nowait;
    print concat(FORMAT (getdate(), 'hh:mm:ss'), ' - processing - prepare account mapping table')
	INSERT @LogTable(ActivityName, ActivityStatus, ActivityMessage) SELECT @ActivityName, 5,concat(FORMAT (getdate(), 'hh:mm:ss'), ' - processing - prepare account mapping table')

    DROP TABLE IF EXISTS #work_AccMapping;

    Select Distinct Statement, RI_Flag, Balance, Position, CSM_LC, AccountCode_disc_NegativeAmount, AccountCode_disc_PositiveAmount, AccountCode_undisc_NegativeAmount,
           AccountCode_undisc_PositiveAmount, Transactiontype_Undisc_Amount, Transactiontype_disc_Amount, CONCAT(Statement,CSM_LC,RI_Flag,Position,Balance) AS JournalDescription, SD.VersionID AS VersionID
      INTO #work_AccMapping
      from Dim.AccountMappingRules DA  
      Left join (select JournalDescription, MAx(VersionID) As VersionID 
                   from Dim.AccountMappingRules 
                  Group by JournalDescription
                ) SD ON DA.JournalDescription=SD.JournalDescription And DA.VersionID=SD.VersionID
     where SD.VersionID IS NOT NULL;

	--RAISERROR(N'processing - additional columns',0,0) with nowait;

    print concat(FORMAT (getdate(), 'hh:mm:ss'), ' - processing - additional columns')
		INSERT @LogTable(ActivityName, ActivityStatus, ActivityMessage) SELECT @ActivityName, 5,concat(FORMAT (getdate(), 'hh:mm:ss'), ' - processing - additional columns')

    DROP TABLE IF EXISTS #work_YTD_base_add_jttm;
    SELECT base.*, 
           base.Amount_disc - base.Amount AS Disc,
           CONCAT(base.Statement, base.CSM_LC, base.RI_Flag, base.Balance, base.Position) AS JournalDescription,
           CASE WHEN base.Entity LIKE 'No Entity' /* PK 02042024 Added as per story I17-7275*/
				THEN ''
				ELSE CASE WHEN @pRunType = 'Actual' then jem.[Agresso Entity Code]
						  ELSE @pRunType
					 END
           END AS AgressoEntityCode,
           CASE WHEN base.Entity LIKE 'No Entity'   /* PK 29022024 Added condition as per story I17-6092*/
				THEN 'IA'
				ELSE jem.[Agresso IFRS17 Client Code]
			END AS AgressoIFRS17ClientCode,
           jttmUndisc.[Transaction Type] AS TransactionType_Undisc,
           jttmDisc.[Transaction Type] AS TransactionType_Disc
      INTO #work_YTD_base_add_jttm
      FROM #work_YTD_base base
      LEFT JOIN Dim.JournalEntitiesMapping jem ON (base.Entity = jem.[Entity Code])
      LEFT JOIN Dim.JournalTransactionTypeMapping jttmDisc ON (base.Statement = jttmDisc.Statement and base.Position = jttmDisc.Position and jttmDisc.[Discounted(Y/N)] = 'Y')
      LEFT JOIN Dim.JournalTransactionTypeMapping jttmUndisc ON (base.Statement = jttmUndisc.Statement and base.Position = jttmUndisc.Position and jttmUndisc.[Discounted(Y/N)] = 'N')
      ;


    DROP TABLE IF EXISTS #work_YTD_base_add;
    SELECT base.*, 
           amrUndisc.AccountCode_undisc_PositiveAmount AS AccountCode_Undisc_Pos,
           amrUndisc.AccountCode_undisc_NegativeAmount AS AccountCode_Undisc_Neg,
           amrDisc.AccountCode_disc_PositiveAmount AS AccountCode_Disc_Pos,
           amrDisc.AccountCode_disc_NegativeAmount AS AccountCode_Disc_Neg
      INTO #work_YTD_base_add
      FROM #work_YTD_base_add_jttm base
      LEFT JOIN #work_AccMapping amrUndisc ON (base.Statement = amrUndisc.Statement and ISNULL(base.CSM_LC, 'blank') = ISNULL(amrUndisc.CSM_LC, 'blank') and base.Balance = amrUndisc.Balance and base.RI_Flag = amrUndisc.RI_Flag 
                                                 and base.Position = amrUndisc.Position and base.TransactionType_Undisc = amrUndisc.Transactiontype_Undisc_Amount)
      LEFT JOIN #work_AccMapping amrDisc ON (base.Statement = amrDisc.Statement and ISNULL(base.CSM_LC, 'blank') = ISNULL(amrDisc.CSM_LC, 'blank') and base.Balance = amrDisc.Balance and base.RI_Flag = amrDisc.RI_Flag 
                                                 and base.Position = amrDisc.Position and base.TransactionType_Disc = amrDisc.Transactiontype_disc_Amount)
      ;

	--RAISERROR(N'processing - re-allocation columns',0,0) with nowait;
    print concat(FORMAT (getdate(), 'hh:mm:ss'), ' - processing - re-allocation columns')
			INSERT @LogTable(ActivityName, ActivityStatus, ActivityMessage) SELECT @ActivityName, 5,concat(FORMAT (getdate(), 'hh:mm:ss'), ' - processing - re-allocation columns')

    /* Michal */


    DROP TABLE IF EXISTS #work_YTD_base_realloc;
  
    SELECT 
                    base.*,
                    AssetLiabilityAmount,
                    CASE WHEN AssetLiabilityAmount > 0.00 THEN 'Asset' ELSE 'Liability' END AssetLiabilityType,
                    CONCAT(base.Statement, base.RI_Flag, base.Balance) AS ReAllocationID,
                    --CASE WHEN AssetLiabilityAmount > 0.00 THEN jram.[Re Allocation Positive Account Code] END AccountCode_ReAlloc_Pos,
                    --CASE WHEN AssetLiabilityAmount > 0.00 THEN jram.[Re Allocation Negative Account Code] END AccountCode_ReAlloc_Neg
					jram.[Re Allocation Positive Account Code] AS AccountCode_ReAlloc_Pos,
					jram.[Re Allocation Negative Account Code] AS AccountCode_ReAlloc_Neg

    INTO #work_YTD_base_realloc
    FROM #work_YTD_base_add base
    LEFT JOIN (
					SELECT 
							@RunIDs as RunIDs,
							ISNULL(lic.LIC_Close_Amt, 0) + ISNULL(lrc.LRC_Close_Amt, 0) - ISNULL(csm.CSM_Close_Amt, 0) as AssetLiabilityAmount,
							COALESCE(csm.Programme, lic.Programme, lrc.Programme) as Programme,
							COALESCE(csm.Portfolio, lic.Portfolio, lrc.Portfolio) as Portfolio
					FROM (
								SELECT 
									RunID,
									sum(Conv_Amount_disc) as CSM_Close_Amt,
									CASE Programme WHEN 'GROSS' THEN 'GROSS' ELSE 'RI' END as Programme, 
									Portfolio, 
									Position
								FROM (select RunId, FocusGroup, Entity, [Tri Focus Code], [IFRS17 Tri Focus Code], Programme, RI_Flag, YOA, YOI,
												QOI_End_Date, CCY, [Incepted Status], Statement, Balance, 
												CASE WHEN (Position = 'Closing(Inc LC_ADJ)' AND Balance = 'CSM_LC' and RI_Flag = 'O') THEN 'Closing' ELSE Position END Position, UOA, CSM_LC, Portfolio,
												round(sum(Conv_Amount_disc),2) as Conv_Amount_disc,
												round(sum(Amount),2) as Amount,
												round(sum(Amount_disc),2) as Amount_disc
										from Reporting.CSM_Post_LCAdjustments
										WHERE RunID in (@LastRunID)
											AND Statement = 'CSM' 
											AND ((Position = 'Closing' AND Balance <> 'CSM_LC' and RI_Flag = 'I') /*PK - 250923 Updated the condition for CR I17-5744 */
													OR
												(Position = 'Closing(Inc LC_ADJ)' AND Balance = 'CSM_LC' and RI_Flag = 'O'))
											AND (CSM_LC <> 'LC' OR CSM_LC IS NULL)
										group by RunId, FocusGroup, Entity, [Tri Focus Code], [IFRS17 Tri Focus Code], Programme, RI_Flag, YOA, YOI,
												QOI_End_Date, CCY, [Incepted Status], Statement, Balance, 
												CASE WHEN (Position = 'Closing(Inc LC_ADJ)' AND Balance = 'CSM_LC' and RI_Flag = 'O') THEN 'Closing' ELSE Position END, UOA, CSM_LC,Portfolio
									) CSM
										WHERE (Amount + Amount_disc) <> 0
										GROUP BY RunID, CASE Programme WHEN 'GROSS' THEN 'GROSS' ELSE 'RI' END, Portfolio, Position
						)csm
					FULL OUTER JOIN 
						(
								SELECT
										RunID,
										sum(Conv_Amount_disc) LIC_Close_Amt,
										CASE Programme WHEN 'GROSS' THEN 'GROSS' ELSE 'RI' END as Programme, 
										Portfolio,
										Position
								FROM (select RunID,FocusGroup, Entity, [Tri Focus Code], [IFRS17 Tri Focus Code], Programme, RI_Flag, YOA, YOI,
											QOI_End_Date, CCY, [Incepted Status], Statement, Balance, Position, UOA, Portfolio,
											round(sum(Conv_Amount_disc),2) as Conv_Amount_disc,
											round(sum(Amount),2) as Amount,
											round(sum(Amount_disc),2) as Amount_disc
										from Reporting.LIC_DiscountedData
										WHERE RunID in (@LastRunID)
											AND Statement = 'LIC' 
											AND Position = 'Closing'
										group by RunID,FocusGroup, Entity, [Tri Focus Code], [IFRS17 Tri Focus Code], Programme, RI_Flag, YOA, YOI,
												QOI_End_Date, CCY, [Incepted Status], Statement, Balance, Position, UOA,Portfolio
										) LIC
								WHERE (Amount + Amount_disc) <> 0
								GROUP BY RunID, CASE Programme WHEN 'GROSS' THEN 'GROSS' ELSE 'RI' END,Position,Portfolio
							)lic   ON csm.Programme = lic.Programme AND  csm.Portfolio = lic.Portfolio
					FULL OUTER JOIN 
						(
								SELECT
											RunID,
											sum(Conv_Amount_disc) LRC_Close_Amt,
											CASE Programme WHEN 'GROSS' THEN 'GROSS' ELSE 'RI' END as Programme, 
											Portfolio,
											Position
								FROM (select RunID,FocusGroup, Entity, [Tri Focus Code], [IFRS17 Tri Focus Code], Programme, RI_Flag, YOA, YOI,
											QOI_End_Date, CCY, [Incepted Status], Statement, Balance, Position,  UOA, Portfolio,
											round(sum(Conv_Amount_disc),2) as Conv_Amount_disc,
											round(sum(Amount),2) as Amount,
											round(sum(Amount_disc),2) as Amount_disc
									from Reporting.LRC_Post_BBNIAdjustments
									WHERE RunID in (@LastRunID)
										AND Statement = 'LRC' 
										AND Position = 'Closing'
									group by RunID,FocusGroup, Entity,[Tri Focus Code], [IFRS17 Tri Focus Code], Programme, RI_Flag, YOA, YOI,
											QOI_End_Date, CCY, [Incepted Status], Statement, Balance, Position, UOA , Portfolio
									) LRC
								WHERE (Amount + Amount_disc) <> 0
								GROUP BY RunID, CASE Programme WHEN 'GROSS' THEN 'GROSS' ELSE 'RI' END, Position,Portfolio
						)LRC   ON COALESCE(csm.Programme, lic.Programme) = lrc.Programme and COALESCE(csm.Portfolio, lic.Portfolio) = lrc.Portfolio

		) reallo        ON base.RunIDs = reallo.RunIDs
                    AND CASE base.Programme WHEN 'GROSS' THEN 'GROSS' ELSE 'RI' END = reallo.Programme
                    AND base.Portfolio = reallo.Portfolio
    LEFT JOIN Dim.[JournalReAllocationMapping] jram    ON CONCAT(base.Statement, base.RI_Flag, base.Balance) = jram.ID;

	--RAISERROR(N'processing - deleting existing rows in target table',0,0) with nowait;
    print concat(FORMAT (getdate(), 'hh:mm:ss'), ' - processing - deleting existing rows in target table')
	INSERT @LogTable(ActivityName, ActivityStatus, ActivityMessage) SELECT @ActivityName, 5,concat(FORMAT (getdate(), 'hh:mm:ss'), ' - processing - deleting existing rows in target table')


    /* Delete ROWS for AccDate/Statement/RunIDs that already exists in target table */
    DELETE FROM [Reporting].[JournalInputDataYTD]
     WHERE AccountingDate = @pAccDate
       AND [Statement] = @pStatement
       AND RunIDs = @runIDs


	--RAISERROR(N'processing - inserting rows to target table',0,0) with nowait;
    print concat(FORMAT (getdate(), 'hh:mm:ss'), ' - processing - inserting rows to target table')
  
	INSERT @LogTable(ActivityName, ActivityStatus, ActivityMessage) SELECT @ActivityName, 5,concat(FORMAT (getdate(), 'hh:mm:ss'), ' - processing - inserting rows to target table')
    /* Insert data to target table */
    INSERT INTO [Reporting].[JournalInputDataYTD]
           ([RunIDs], [AccountingDate], [JournalType],[FocusGroup],[Portfolio], [Entity], [TriFocusCode], [IFRS17TriFocusCode], [Programme], [RI_Flag], [YOA], [YOI], [QOI_End_Date], [CCY], 
            [InceptedStatus], [Statement], [Balance], [Position], [UOA], [CSM_LC], [Amount], [Amount_disc], [Conv_Amount], [Conv_Amount_disc], [AgressoEntityCode], 
            [AgressoIFRS17ClientCode], [Disc], [TransactionType_Undisc], [TransactionType_Disc], [AccountCode_Undisc_Pos], [AccountCode_Undisc_Neg], [AccountCode_Disc_Pos], 
            [AccountCode_Disc_Neg], [JournalDescription], [AssetLiabilityAmount], [AssetLiabilityType], [ReAllocationID], [AccountCode_ReAlloc_Pos], [AccountCode_ReAlloc_Neg], 
            [AuditUser], [AuditCreateDatetime])
    SELECT [RunIDs], [AccountingDate],@pJournalType , [FocusGroup],[Portfolio], [Entity], [TriFocusCode], [IFRS17TriFocusCode], [Programme], [RI_Flag], [YOA], [YOI], [QOI_End_Date], [CCY], 
           [InceptedStatus], [Statement], [Balance], [Position], [UOA], [CSM_LC], [Amount], [Amount_disc], [Conv_Amount], [Conv_Amount_disc], [AgressoEntityCode], 
           [AgressoIFRS17ClientCode], [Disc], [TransactionType_Undisc], [TransactionType_Disc], [AccountCode_Undisc_Pos], [AccountCode_Undisc_Neg], 
           [AccountCode_Disc_Pos], [AccountCode_Disc_Neg], [JournalDescription], ISNULL([AssetLiabilityAmount], 0.00) , [AssetLiabilityType], [ReAllocationID], 
           [AccountCode_ReAlloc_Pos], [AccountCode_ReAlloc_Neg], [AuditUser], [AuditCreateDatetime]
      FROM #work_YTD_base_realloc;

	--RAISERROR(N'processing - FINISHED',0,0) with nowait;

    print concat(FORMAT (getdate(), 'hh:mm:ss'), ' - processing FINISHED')
   	INSERT @LogTable(ActivityName, ActivityStatus, ActivityMessage) SELECT @ActivityName, 5,concat(FORMAT (getdate(), 'hh:mm:ss'), ' - processing FINISHED')
	--SELECT * FROM @LogTable
	INSERT @LogTable(ActivityName, ActivityStatus, ActivityMessage) SELECT @ActivityName, 5, 'End of SPROC'
	EXEC [dbo].[usp_LogIFRS17PscileData] @Input = @LogTable

    IF @Trancount = 0 COMMIT;

		/*Inserted next 3 lines by Sainath to update Journal Audit Log table as Success*/
		UPDATE	[PWAPS].[JournalAuditLog]
		SET		GenerateYTD = 'Success'
		WHERE	PK_JournalAuditLogID =	@pPK_JournalAuditLogID

    END TRY
    BEGIN CATCH
        IF @Trancount = 0 ROLLBACK;
		INSERT @LogTable(ActivityName, ActivityStatus, ActivityMessage) SELECT @ActivityName, 4, ERROR_MESSAGE()
		EXEC [dbo].[usp_LogIFRS17PscileData] @Input = @LogTable;
        THROW;
		/*Inserted next 3 lines by Sainath to update Journal Audit Log table as Failed*/
		UPDATE	[PWAPS].[JournalAuditLog]
		SET		GenerateYTD = 'Failed'
		WHERE	PK_JournalAuditLogID =	@pPK_JournalAuditLogID

    END CATCH
    
    DROP TABLE IF EXISTS #work_YTD_base;
	DROP TABLE IF EXISTS #work_YTD_base_add_jttm;
    DROP TABLE IF EXISTS #work_YTD_base_add;
    DROP TABLE IF EXISTS #work_YTD_base_realloc;

    
END
GO
