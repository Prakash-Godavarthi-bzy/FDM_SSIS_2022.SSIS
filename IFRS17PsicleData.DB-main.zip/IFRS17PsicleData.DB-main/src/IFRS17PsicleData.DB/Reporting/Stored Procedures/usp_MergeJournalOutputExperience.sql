﻿

CREATE   PROCEDURE [Reporting].[usp_MergeJournalOutputExperience] (
        @pAccDate DATE,           /* Accounting DATE */
        @pRunIDs VARCHAR(50),              /* RunIDs */
        @pUser VARCHAR(25)        /* User requesting this action (for audit) */
      )
AS

BEGIN
  DECLARE @Trancount INT = @@Trancount,
          @createDatetime DATETIME2(7) = GETDATE();  

		/*Inserted next 5 lines by Sainath to update Journal Audit Log table as InProgress*/
		UPDATE	[PWAPS].[JournalAuditLog]
		SET		ExperienceJournal = 'InProgress'
		WHERE	RunIDs=@pRunIDs				AND
				AccountingDate=@pAccDate	AND
				ValidityFlag=1
  
  BEGIN TRY
    IF @Trancount = 0 BEGIN TRAN;

    IF @pAccDate IS NULL THROW 51001, 'The accounting DATE has to be set.', 1;  
    IF @pRunIDs IS NULL THROW 51001, 'Run IDs must be set.', 1;  

    IF @pUser IS NULL SET @pUser = 'Unknown'

    print 'processing - deleting existing rows in target table'

    /* Delete ROWS for User/RunIDs that already exists in target table */
    DELETE FROM [Reporting].[JournalOutputExperience]
     WHERE RunIDs = @pRunIDs
       AND AccountingDate = @pAccDate;

    print 'processing - inserting rows to target table'

    /* Call SPs to Populate data */

	EXECUTE [Reporting].[usp_PopulateExperienceJournalIFIE_EXPR] @pAccDate, @pRunIDs, @pUser

	EXECUTE [Reporting].[usp_PopulateExperienceJournalOnlyIFIE] @pAccDate, @pRunIDs, @pUser

;

    IF @Trancount = 0 COMMIT;
	/*Inserted next 5 lines by Sainath to update Journal Audit Log table as Success*/
		UPDATE	[PWAPS].[JournalAuditLog]
		SET		ExperienceJournal = 'Success'
		WHERE	RunIDs=@pRunIDs				AND
				AccountingDate=@pAccDate	AND
				ValidityFlag=1
    END TRY
    BEGIN CATCH
        IF @Trancount = 0 ROLLBACK;
        THROW;
		/*Inserted next 5 lines by Sainath to update Journal Audit Log table as Failed*/
		UPDATE	[PWAPS].[JournalAuditLog]
		SET		ExperienceJournal = 'Failed'
		WHERE	RunIDs=@pRunIDs				AND
				AccountingDate=@pAccDate	AND
				ValidityFlag=1
    END CATCH

END;