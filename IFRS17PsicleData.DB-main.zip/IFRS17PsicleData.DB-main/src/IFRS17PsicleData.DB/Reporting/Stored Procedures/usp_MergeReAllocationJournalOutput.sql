﻿CREATE PROCEDURE [Reporting].[usp_MergeReAllocationJournalOutput] 

(
 @pAccDate DATE,             /* Accounting DATE */
 @RunId Varchar(50),		 /* Selected RunId*/
 @pUser VARCHAR(25)			/* User requesting this action (for audit) */
  
)
AS
BEGIN
  DECLARE @Trancount INT = @@Trancount,
   @createDatetime DATETIME2(7) = GETDATE(),
   @JournalType Varchar(3)
		/*Inserted next 5 lines by Sainath to update Journal Audit Log table as InProgress*/
		UPDATE	[PWAPS].[JournalAuditLog]
		SET		JournalReAllocation = 'InProgress'
		WHERE	RunIDs=@RunId				AND
				AccountingDate=@pAccDate	AND
				ValidityFlag=1
	BEGIN TRY
		IF @Trancount = 0 
	   BEGIN TRAN;
			/*Added as part of cleanup duplicate regarding ticket #4386*/
			DELETE FROM [Reporting].[ReAllocationJournalOutput]
		    WHERE AccountingDate = @pAccDate
            AND RunIDs = @RunId;

            SET @JournalType = (SELECT MAX(ISNULL(JournalType, 'YTD')) FROM Reporting.JournalInputDataYTD WHERE RunIDs = @RunId)

			DROP TABLE IF EXISTS #AssetLiabilityCheck
			SELECT RunIds, AccountingDate, Portfolio, Programme, CASE Programme WHEN 'RI' THEN 'O' WHEN 'GROSS' THEN 'I' END RI_Flag, ComparisionChk
			INTO #AssetLiabilityCheck
			FROM PWAPS.udf_ReallocationAsstLiabCurrQtr(@pAccDate, @RunId, @JournalType )


			DROP TABLE IF EXISTS #FullList
			SELECT T1.*, T2.[STATEMENT],T2.POSITION
			INTO #FullList
			FROM #AssetLiabilityCheck T1
			INNER JOIN [Dim].[JournalReAllocationSelectionList] T2 ON T1.RI_Flag = T2.RI_Flag 
																AND T1.ComparisionChk = T2.Scenario
			WHERE T2.POSITION <> 'NA'


			DROP TABLE IF EXISTS #SelectedJournalYTD
			SELECT src.*, t2.ComparisionChk
			INTO #SelectedJournalYTD
			FROM Reporting.JournalInputDataYTD src
			INNER JOIN #FullList T2 ON src.RunIDs = T2.RunIds AND src.RI_Flag = T2.RI_Flag 
												  AND src.Portfolio = T2.Portfolio AND SRC.[Statement] = T2.[Statement]
												  AND  SRC.position = T2.position


			DROP TABLE IF EXISTS #BaseData
				SELECT RowTypes.AccountSign,
					   RowTypes.DiscUndiscType,
					   src.RunIDs, 
					   src.AccountingDate, 
					   src.Portfolio,
					   src.TriFocusCode,
					   src.IFRS17TriFocusCode,
					   src.RI_Flag,
					   src.Programme,
					   src.YOA,--9999, --'NOYOA'  /*Changed the Default Value Back to Mapping From Source as per #4868 */
					   src.YOI,--9999, --'NOIFRSYOI' /*Changed the Default Value Back to Mapping From Source as per #4868 */
					   src.CCY,
					   src.Balance,  --'Ra alloc'  /* Changed the default value to relevant value as per #5120 */
					   src.Position, --'Ra alloc'  /* Changed the default value to relevant value as per #5120 */
					   src.UOA,
					   src.CSM_LC,
					   src.[STATEMENT],
					   case
						 when RowTypes.AccountSign = 'Positive' and RowTypes.DiscUndiscType = 'Undisc' then src.Amount
						 when RowTypes.AccountSign = 'Negative' and RowTypes.DiscUndiscType = 'Undisc' then src.Amount*(-1)
						 when RowTypes.AccountSign = 'Positive' and RowTypes.DiscUndiscType = 'Disc' then src.Disc
						 when RowTypes.AccountSign = 'Negative' and RowTypes.DiscUndiscType = 'Disc' then src.Disc*(-1)          
					   end as Amount,
					   src.AgressoEntityCode,
					   src.AgressoIFRS17ClientCode, 
					   case
						 when RowTypes.AccountSign = 'Positive' and RowTypes.DiscUndiscType = 'Undisc' then src.AccountCode_ReAlloc_Pos
						 when RowTypes.AccountSign = 'Negative' and RowTypes.DiscUndiscType = 'Undisc' then src.AccountCode_ReAlloc_Neg
						 when RowTypes.AccountSign = 'Positive' and RowTypes.DiscUndiscType = 'Disc' then src.AccountCode_ReAlloc_Pos
						 when RowTypes.AccountSign = 'Negative' and RowTypes.DiscUndiscType = 'Disc' then src.AccountCode_ReAlloc_Neg
					   end as AccountCode,
					   CONCAT('Ra alloc','_',src.RI_Flag,src.Balance,src.Position) AS JournalDescription, /* suffix Included as per #5120 */
					  src.ComparisionChk
				  INTO #BaseData
				  FROM #SelectedJournalYTD src
				  CROSS JOIN (
						SELECT 'Positive' AccountSign, 'Undisc' as DiscUndiscType
						UNION ALL
						SELECT 'Negative', 'Undisc'
						UNION ALL
						SELECT 'Positive', 'Disc'
						UNION ALL
						SELECT 'Negative', 'Disc'
				  ) RowTypes
				  WHERE case
						 when RowTypes.AccountSign = 'Positive' and RowTypes.DiscUndiscType = 'Undisc' then src.AccountCode_ReAlloc_Pos
						 when RowTypes.AccountSign = 'Negative' and RowTypes.DiscUndiscType = 'Undisc' then src.AccountCode_ReAlloc_Neg
						 when RowTypes.AccountSign = 'Positive' and RowTypes.DiscUndiscType = 'Disc' then src.AccountCode_ReAlloc_Pos
						 when RowTypes.AccountSign = 'Negative' and RowTypes.DiscUndiscType = 'Disc' then src.AccountCode_ReAlloc_Neg
					   end is not null



			INSERT INTO [Reporting].[ReAllocationJournalOutput]
			   ([AccountSign], [DiscUndiscType], [RunIDs], [AccountingDate], [FocusGroup], [TriFocusCode], [IFRS17TriFocusCode], [RI_Flag], [Programme], 
				[YOA], [YOI], [CCY], [Statement], [Balance], [Position], [UOA], [Amount],[AgressoEntityCode], [AgressoIFRS17ClientCode], [TransactionType], [AccountCode], 
				[JournalDescription], [AuditUser], [AuditCreateDatetime])

			SELECT A.AccountSign, A.DiscUndiscType, A.RunIDs, A.AccountingDate, A.Portfolio, A.TriFocusCode, A.IFRS17TriFocusCode, A.RI_Flag, A.Programme, A.YOA, A.YOI, A.CCY,'Ra alloc' AS [Statement]
			, A.Balance, A.Position, A.UOA, A.Amount, A.AgressoEntityCode, A.AgressoIFRS17ClientCode, 'X7' AS [TransactionType], A.AccountCode,REPLACE( A.JournalDescription,'(Inc LC_ADJ)','x'),       @pUser,    @createDatetime
			FROM
			(
			   SELECT src.AccountSign,
					   src.DiscUndiscType,
					   src.RunIDs, 
					   src.AccountingDate, 
					   src.Portfolio,
					   src.TriFocusCode,
					   src.IFRS17TriFocusCode,
					   src.RI_Flag,
					   src.Programme,
					   src.YOA,--9999, --'NOYOA'  /*Changed the Default Value Back to Mapping From Source as per #4868 */
					   src.YOI,--9999, --'NOIFRSYOI' /*Changed the Default Value Back to Mapping From Source as per #4868 */
					   src.CCY,
					   src.Balance,  --'Ra alloc'  /* Changed the default value to relevant value as per #5120 */
					   src.Position, --'Ra alloc'  /* Changed the default value to relevant value as per #5120 */
					   src.UOA,
					   --src.Amount,
					   src.AgressoEntityCode,
					   src.AgressoIFRS17ClientCode, 
					   src.AccountCode,
					   src.JournalDescription,
					   CASE WHEN RI_Flag = 'O'
							   THEN CASE COMPARISIONCHK
										WHEN 'TYPE1' THEN CASE WHEN (STATEMENT = 'CSM' AND Balance = 'CSM_LC') OR [STATEMENT] <> 'CSM'
															   THEN AMOUNT
															   ELSE 0
														  END
										WHEN 'TYPE2' THEN 
														 CASE WHEN [STATEMENT] <> 'CSM' 
																THEN CASE WHEN (POSITION = 'Closing' AND BALANCE <> 'CSM_LC' AND CSM_LC IS NULL)
																			THEN AMOUNT
																			ELSE 0
																		END
																ELSE CASE WHEN (Position = 'Closing(Inc LC_ADJ)' AND Balance = 'CSM_LC'  and CSM_LC = 'CSM')
																			THEN AMOUNT
																			ELSE 0
																	 END
														 END
										WHEN 'TYPE4' THEN 
														 CASE WHEN [STATEMENT] <> 'CSM' 
																THEN CASE WHEN (POSITION = 'Open' AND BALANCE <> 'CSM_LC' AND CSM_LC IS NULL)
																			THEN AMOUNT * -1
																			ELSE 0
																		END
																ELSE CASE WHEN (Position = 'Open(Inc LC_ADJ)' AND Balance = 'CSM_LC'  and CSM_LC = 'CSM')
																			THEN AMOUNT * -1
																			ELSE 0
																	 END
															END

									END
								ELSE
									CASE COMPARISIONCHK
											WHEN 'TYPE2' THEN 
                                                CASE WHEN [STATEMENT] <> 'CSM' 
                                                     THEN CASE WHEN (POSITION = 'Open' AND BALANCE <> 'CSM_LC' AND (CSM_LC IS NULL or CSM_LC<>'LC'))
                                                               THEN AMOUNT * -1
                                                               ELSE 0
                                                           END
                                                     ELSE CASE WHEN (Position = 'Open'AND BALANCE <> 'CSM_LC' and CSM_LC<>'LC')
                                                                THEN AMOUNT * -1
                                                                ELSE 0
                                                            END
                                                 END
											 WHEN 'TYPE3' THEN 
                                                    CASE WHEN (STATEMENT = 'CSM' AND Balance <> 'CSM_LC' and CSM_LC<>'LC') 
                                                                    OR ([STATEMENT] <> 'CSM' and  BALANCE <> 'CSM_LC' AND (CSM_LC IS NULL or CSM_LC<>'LC'))
                                                                    THEN AMOUNT
                                                                    ELSE 0
                                                    END
                
											 WHEN 'TYPE4' THEN 
                                                    CASE WHEN (STATEMENT = 'CSM' AND Balance <> 'CSM_LC' and CSM_LC<>'LC') 
                                                                    OR ([STATEMENT] <> 'CSM' and  BALANCE <> 'CSM_LC' AND (CSM_LC IS NULL or CSM_LC<>'LC'))
                                                                    THEN AMOUNT
                                                                    ELSE 0
                                                    END
                
									END
						   END Amount
				FROM #BaseData src
			)A




		IF @Trancount = 0 COMMIT;

		/*Inserted next 5 lines by Sainath to update Journal Audit Log table as Success*/
		UPDATE	[PWAPS].[JournalAuditLog]
		SET		JournalReAllocation = 'Success'
		WHERE	RunIDs=@RunId				AND
				AccountingDate=@pAccDate	AND
				ValidityFlag=1
    END TRY
    
	BEGIN CATCH
        IF @Trancount = 0 ROLLBACK;
        THROW;
		/*Inserted next 5 lines by Sainath to update Journal Audit Log table as Failed*/
		UPDATE	[PWAPS].[JournalAuditLog]
		SET		JournalReAllocation = 'Failed'
		WHERE	RunIDs=@RunId				AND
				AccountingDate=@pAccDate	AND
				ValidityFlag=1
    END CATCH

END