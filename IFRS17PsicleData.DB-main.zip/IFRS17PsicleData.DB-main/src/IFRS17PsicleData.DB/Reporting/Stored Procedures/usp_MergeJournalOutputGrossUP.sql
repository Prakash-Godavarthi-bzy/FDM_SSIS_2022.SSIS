﻿

--DECLARE
--@pRunIDs VARCHAR(50) = 'Actual_92_93_94_95',     /* RunIDs */
--@pAccDate DATE      = '2021-12-31',     /* Accounting DATE */
--@pStatement VARCHAR(25) = 'CSM',
--@pUser VARCHAR(25) = 'Pooja Khandual'
----,@createDatetime DATETIME2(7) = GETDATE()


CREATE PROCEDURE [Reporting].[usp_MergeJournalOutputGrossUP] (
        @pRunIDs VARCHAR(50),              /* RunIDs */
        @pStatement VARCHAR(25),  /* Statement type, must be LIC, LRC or CSM */
        @pAccDate DATE,           /* Accounting DATE */
        @pUser VARCHAR(25),        /* User requesting this action (for audit) */
		@pPK_JournalAuditLogID BIGINT/*Introduced by Sainath to update Journal Audit Table*/
      )
AS

BEGIN
  DECLARE @Trancount INT = @@Trancount,
          @createDatetime DATETIME2(7) = GETDATE() ;	
		 --@pRunIDs VARCHAR(50)='Actual_4261_0_0_0',              /* RunIDs */
   --     @pStatement VARCHAR(25)='RIP',  /* Statement type, must be LIC, LRC or CSM */
   --     @pAccDate DATE='2019-03-31',           /* Accounting DATE */
   --     @pUser VARCHAR(25)='Gita Halai'

/*Inserted next 3 lines by Sainath to update Journal Audit Log table as InProgress*/
		UPDATE	[PWAPS].[JournalAuditLog]
		SET		GrossUpJournal = 'InProgress'
		WHERE	PK_JournalAuditLogID =	@pPK_JournalAuditLogID
  
  
 
  BEGIN TRY

    IF @Trancount = 0 BEGIN TRAN;
	   If @pStatement='CSM' 
	   Begin

    
    IF @pUser is NULL set @pUser = 'Unknown'

    print 'processing - deleting existing rows in target table'

    /* Delete ROWS for User/RunIDs that already exists in target table */
    DELETE FROM [Reporting].[JournalOutputGrossUp]
     WHERE Statement = @pStatement
       AND RunIDs = @pRunIDs
       AND AccountingDate = @pAccDate;


    print 'processing - inserting rows to target table'



    /* Insert data to target table */

    INSERT INTO [Reporting].[JournalOutputGrossUp]
               ([AccountSign], [DiscUndiscType], [RunIDs], [AccountingDate], [FocusGroup], [TriFocusCode], [IFRS17TriFocusCode], [RI_Flag], [Programme], 
                [YOA], [YOI], [CCY], [Statement], [Balance], [Position], [UOA], [Amount], [AgressoEntityCode], [AgressoIFRS17ClientCode], [TransactionType], [AccountCode], 
                [JournalDescription], [AuditUser], [AuditCreateDatetime])
SELECT RowTypes.AccountSign,
               RowTypes.DiscUndiscType,
               src.RunIDs, 
               src.AccountingDate, 
               src.FocusGroup,
               src.TriFocusCode,
               src.IFRS17TriFocusCode,
               src.RI_Flag,
               src.Programme,
               src.YOA, 
               src.YOI,
               src.CCY,
               src.Statement, 
               src.Balance,
               src.Position,
               src.UOA,
               CASE
                 WHEN RowTypes.AccountSign = 'Positive' AND RowTypes.DiscUndiscType = 'Undisc' THEN src.Amount
                 WHEN RowTypes.AccountSign = 'Negative' AND RowTypes.DiscUndiscType = 'Undisc' THEN src.Amount*(-1)
                 WHEN RowTypes.AccountSign = 'Positive' AND RowTypes.DiscUndiscType = 'Disc' THEN src.Disc
                 WHEN RowTypes.AccountSign = 'Negative' AND RowTypes.DiscUndiscType = 'Disc' THEN src.Disc*(-1)          
               END as Amount,
               src.AgressoEntityCode,
               src.AgressoIFRS17ClientCode, 
               CASE
                 WHEN RowTypes.DiscUndiscType = 'Disc' THEN src.TransactionType_Disc
                 WHEN RowTypes.DiscUndiscType = 'Undisc' THEN src.TransactionType_Undisc
               END as TransactionType,
               CASE
                 WHEN RowTypes.AccountSign = 'Positive' AND RowTypes.DiscUndiscType = 'Undisc' THEN src.AccountCode_Undisc_Pos
                 WHEN RowTypes.AccountSign = 'Negative' AND RowTypes.DiscUndiscType = 'Undisc' THEN src.AccountCode_Undisc_Neg
                 WHEN RowTypes.AccountSign = 'Positive' AND RowTypes.DiscUndiscType = 'Disc' THEN src.AccountCode_Disc_Pos
                 WHEN RowTypes.AccountSign = 'Negative' AND RowTypes.DiscUndiscType = 'Disc' THEN src.AccountCode_Disc_Neg
               END as AccountCode,
               ConCat('GrossUP_',src.JournalDescription) As JournalDescription,
               @pUser,
               @createDatetime
			  
         FROM (
		  SELECT src.RunIDs, /* SUM to required grain */
                       src.AccountingDate, 
                       src.FocusGroup,
                       src.TriFocusCode,
                       src.IFRS17TriFocusCode,
                       src.RI_Flag,
                       src.Programme,
                       src.YOA, 
                       src.YOI,
                       src.CCY,
                       GR.Statement, 
                       GR.Balance,
                       GR.Position,
                       src.UOA,
                       src.AgressoEntityCode,
                       src.AgressoIFRS17ClientCode, 
                       GR.TransactionType_Disc,
                       GR.TransactionType_Undisc,
                       GR.JournalDescription,
                       GR.AccountCode_Undisc_Pos,
                       GR.AccountCode_Undisc_Neg,
                       GR.AccountCode_Disc_Pos,
                       GR.AccountCode_Disc_Neg,
                       sum(src.Amount) as Amount,
                       sum(src.Amount_disc) as Amount_disc,
                       sum(src.Disc) as Disc
                  FROM Reporting.JournalInputDataYTD src
				  INNER JOIN	
						(
						SELECT  'CSM' As Statement,'I'As RIFlag,'Br' As Balance,'Release' As Position,'CSMCSMIBrRelease' As JournalDescription,'X5' as TransactionType_Undisc,'40206' As AccountCode_Undisc_Pos,'40135' As AccountCode_Undisc_Neg,'X3' As TransactionType_Disc,'40206' As AccountCode_Disc_Pos,'40135' As AccountCode_Disc_Neg,'CSM' As CSM_LC
						UNION ALL
						SELECT  'CSM' As Statement,'I'As RIFlag,'OAE' As Balance,'Release' As Position,'CSMCSMIOAERelease' As JournalDescription,'X5' as TransactionType_Undisc,'40207' As AccountCode_Undisc_Pos,'40135' As AccountCode_Undisc_Neg,'X3' As TransactionType_Disc,'40207' As AccountCode_Disc_Pos,'40135' As AccountCode_Disc_Neg,'CSM' As CSM_LC
						UNION ALL
						SELECT  'CSM' As Statement,'I'As RIFlag,'Br' As Balance,'Release' As Position,'CSMLCIBrRelease' As JournalDescription,'X5' as TransactionType_Undisc,'40206' As AccountCode_Undisc_Pos,'40135' As AccountCode_Undisc_Neg,'X3' As TransactionType_Disc,'40206' As AccountCode_Disc_Pos,'40135' As AccountCode_Disc_Neg,'LC' As CSM_LC
						UNION ALL
						SELECT  'CSM' As Statement,'I'As RIFlag,'OAE' As Balance,'Release' As Position,'CSMLCIOAERelease' As JournalDescription,'X5' as TransactionType_Undisc,'40207' As AccountCode_Undisc_Pos,'40135' As AccountCode_Undisc_Neg,'X3' As TransactionType_Disc,'40207' As AccountCode_Disc_Pos,'40135' As AccountCode_Disc_Neg,'LC' As CSM_LC
						) GR  On  src.[Statement] = GR.[Statement] And src.RI_Flag = GR.RIFlag And src.Balance = GR.Balance And src.Position = GR.Position	And src.JournalDescription = GR.JournalDescription
				   WHERE AccountingDate = @pAccDate
                   AND GR.Statement = @pStatement
                   AND RunIDs = @pRunIDs
                GROUP BY src.RunIDs,
                         src.AccountingDate, 
                         src.FocusGroup,
                         src.TriFocusCode,
                         src.IFRS17TriFocusCode,
                         src.RI_Flag,
                         src.Programme,
                         src.YOA, 
                         src.YOI,
                         src.CCY,
                         GR.Statement, 
                         GR.Balance,
                         GR.Position,
                         src.UOA,
                         src.AgressoEntityCode,
                         src.AgressoIFRS17ClientCode, 
                         GR.TransactionType_Disc,
                         GR.TransactionType_Undisc,
                         GR.JournalDescription,
                         GR.AccountCode_Undisc_Pos,
                         GR.AccountCode_Undisc_Neg,
                         GR.AccountCode_Disc_Pos,
                         GR.AccountCode_Disc_Neg
               ) src
          CROSS JOIN (
                SELECT 'Positive' AccountSign, 'Undisc' as DiscUndiscType
                UNION ALL
                SELECT 'Negative', 'Undisc'
                UNION ALL
                SELECT 'Positive', 'Disc'
                UNION ALL
                SELECT 'Negative', 'Disc'
          ) RowTypes
        WHERE (src.Position not like '%Open%' and src.Position not like '%Closing%')
          AND COALESCE(CASE
                 WHEN RowTypes.AccountSign = 'Positive' AND RowTypes.DiscUndiscType = 'Undisc' THEN NULLIF(src.AccountCode_Undisc_Pos, '')
                 WHEN RowTypes.AccountSign = 'Negative' AND RowTypes.DiscUndiscType = 'Undisc' THEN NULLIF(src.AccountCode_Undisc_Neg, '')
                 WHEN RowTypes.AccountSign = 'Positive' AND RowTypes.DiscUndiscType = 'Disc' THEN NULLIF(src.AccountCode_Disc_Pos, '')
                 WHEN RowTypes.AccountSign = 'Negative' AND RowTypes.DiscUndiscType = 'Disc' THEN NULLIF(src.AccountCode_Disc_Neg, '')
               END, 'Missing Mapping') <> 'Missing Mapping'
          ;
		  END
		  IF @pStatement NOT IN ('LIC', 'LRC', 'CSM') THROW 51000, 'The statement must be set to LIC, LRC or CSM.', 1;  
    IF @pAccDate is NULL THROW 51001, 'The accounting DATE has to be set.', 1;  
    IF @pRunIDs is NULL THROW 51001, 'Run IDs must be set.', 1;  

    IF @Trancount = 0 COMMIT;

	/*Inserted next 3 lines by Sainath to update Journal Audit Log table as Success*/
		UPDATE	[PWAPS].[JournalAuditLog]
		SET		GrossUpJournal = 'Success'
		WHERE	PK_JournalAuditLogID =	@pPK_JournalAuditLogID
    END TRY
    BEGIN CATCH
	If @Trancount=0 RollBACK;

      DECLARE @ErrorMessage NVARCHAR(4000);

    DECLARE @ErrorSeverity INT;

    DECLARE @ErrorState INT;

 

    SELECT

        @ErrorMessage = ERROR_MESSAGE(),

        @ErrorSeverity = ERROR_SEVERITY(),

        @ErrorState = ERROR_STATE();

 

    -- Use RAISERROR inside the CATCH block to return error

    -- information about the original error that caused

    -- execution to jump to the CATCH block.

    RAISERROR (@ErrorMessage, -- Message text.

               @ErrorSeverity, -- Severity.

               @ErrorState -- State.

               );
	/*Inserted next 3 lines by Sainath to update Journal Audit Log table as Failed*/
		UPDATE	[PWAPS].[JournalAuditLog]
		SET		GrossUpJournal = 'Failed'
		WHERE	PK_JournalAuditLogID =	@pPK_JournalAuditLogID

    END CATCH


END;