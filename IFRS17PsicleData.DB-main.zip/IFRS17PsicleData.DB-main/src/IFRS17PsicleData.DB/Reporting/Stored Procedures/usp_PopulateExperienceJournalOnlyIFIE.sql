﻿


--DECLARE
--@pAccDate DATE = '2021-12-31',           /* Accounting DATE */
--@pRunIDs VARCHAR(50) = 'Actual_40_48_49_50',              /* RunIDs */
--@pUser VARCHAR(25)  ='Pooja Khandual'



CREATE   PROCEDURE [Reporting].[usp_PopulateExperienceJournalOnlyIFIE] (
        @pAccDate DATE,           /* Accounting DATE */
        @pRunIDs VARCHAR(50),              /* RunIDs */
        @pUser VARCHAR(25)        /* User requesting this action (for audit) */
      )
AS

BEGIN
  DECLARE @Trancount INT = @@Trancount,
          @createDatetime DATETIME2(7) = GETDATE();  
  
  BEGIN TRY
    IF @Trancount = 0 BEGIN TRAN;

    IF @pAccDate IS NULL THROW 51001, 'The accounting DATE has to be set.', 1;  
    IF @pRunIDs IS NULL THROW 51001, 'Run IDs must be set.', 1;  

    IF @pUser IS NULL SET @pUser = 'Unknown'


DROP TABLE IF EXISTS #ExpJouList
SELECT T1.RunIDs, T1.AccountingDate, T1.RI_Flag, T1.Balance, T1.Position, T1.ExprType,T1.AccountCodePositiveVE, T1.AccountCodeNegativeVE
INTO #ExpJouList
FROM PWAPS.ExperienceJournal T1
INNER JOIN PWAPS.udf_GetUnBalancedJournalOutputFinal(@pRunIDs,@pAccDate) T2 ON T1.RunIDs = T2.RunIDs AND T1.RI_Flag = T2.RI_Flag AND T1.Balance = T2.Balance AND T1.Position = T2.Position
WHERE T1.AccountingDate = @pAccDate
AND T1.RunIDs = @pRunIDs
AND CONCAT(T1.Balance, T1.Position) NOT in ('PrNFNChgV','PrNFNChgO','BrNFNChgV','BrNFNChgO','OAENFNChgV','OAENFNChgO')


DROP TABLE IF EXISTS #CSMData
	SELECT RowTypes.AccountSign,
		RowTypes.DiscUndiscType,
		src.RunIDs, 
		src.AccountingDate, 
		src.FocusGroup,
		src.TriFocusCode,
		src.IFRS17TriFocusCode,
		src.RI_Flag,
		src.Programme,
		src.YOA, 
		src.YOI,
		src.CCY,
		src.Statement, 
		src.Balance,
		src.Position,
		src.UOA,
		CASE
			WHEN RowTypes.AccountSign = 'Positive'  AND RowTypes.DiscUndiscType = 'UnDisc' THEN src.Amount
			WHEN RowTypes.AccountSign = 'Negative'  AND RowTypes.DiscUndiscType = 'UnDisc' THEN src.Amount *(-1)
			WHEN RowTypes.AccountSign = 'Positive' AND RowTypes.DiscUndiscType = 'Disc' THEN src.Disc 
			WHEN RowTypes.AccountSign = 'Negative' AND RowTypes.DiscUndiscType = 'Disc' THEN src.Disc  *(-1)      
		END as Amount,
		src.AgressoEntityCode,
		src.AgressoIFRS17ClientCode, 
		CASE
			WHEN RowTypes.DiscUndiscType = 'Disc' THEN src.TransactionType_Disc
			WHEN RowTypes.DiscUndiscType = 'Undisc' THEN src.TransactionType_Undisc
		END as TransactionType,
        CASE
            WHEN RowTypes.AccountSign = 'Positive' THEN src.AccountCodePositiveVE 
            WHEN RowTypes.AccountSign = 'Negative' THEN src.AccountCodeNegativeVE
        END as AccountCode,
		CONCAT('IFIE','_', src.RI_Flag, src.Balance, src.Position) AS  JournalDescription
	INTO #CSMData
	FROM (SELECT src.RunIDs, /* SUM to required grain */
				src.AccountingDate, 
				src.FocusGroup,
				src.TriFocusCode,
				src.IFRS17TriFocusCode,
				src.RI_Flag,
				src.Programme,
				'IFIE' AS [Statement], 
				src.YOA, 
				src.YOI,
				src.CCY,
				src.Balance,
				src.Position,
				src.UOA,
				src.AgressoEntityCode,
				src.AgressoIFRS17ClientCode, 
				src.TransactionType_Disc,
				src.TransactionType_Undisc,
				src.JournalDescription,
                src.AccountCode_Undisc_Pos,
                src.AccountCode_Undisc_Neg,
                src.AccountCode_Disc_Pos,
                src.AccountCode_Disc_Neg,
				T2.AccountCodePositiveVE,
				T2.AccountCodeNegativeVE,
				sum(src.Amount) as Amount,
				sum(src.Amount_disc) as Amount_disc,
				sum(src.Disc) as Disc    
			FROM Reporting.JournalInputDataYTD src
			INNER JOIN #ExpJouList T2 ON src.RunIDs = T2.RunIDs AND src.AccountingDate = T2.AccountingDate AND src.RI_Flag = T2.RI_Flag AND src.Balance = T2.Balance AND src.Position = T2.Position
			WHERE  [Statement] = 'CSM'
			GROUP BY src.RunIDs,
					src.AccountingDate, 
					src.FocusGroup,
					src.TriFocusCode,
					src.IFRS17TriFocusCode,
					src.RI_Flag,
					src.Programme,
					src.YOA, 
					src.YOI,
					src.CCY,
					src.Balance,
					src.Position,
					src.UOA,
					src.AgressoEntityCode,
					src.AgressoIFRS17ClientCode, 
					src.TransactionType_Disc,
					src.TransactionType_Undisc,
					src.JournalDescription,
                    src.AccountCode_Undisc_Pos,
                    src.AccountCode_Undisc_Neg,
                    src.AccountCode_Disc_Pos,
                    src.AccountCode_Disc_Neg,
					T2.AccountCodePositiveVE,
					T2.AccountCodeNegativeVE
		) src
	CROSS JOIN (
				SELECT 'Positive' AccountSign, 'Undisc' as DiscUndiscType
				UNION ALL
				SELECT 'Negative', 'Undisc'
				UNION ALL
				SELECT 'Positive', 'Disc'
				UNION ALL
				SELECT 'Negative', 'Disc'
				) RowTypes
WHERE (src.Position not like '%Open%' and src.Position not like '%Closing%')
AND COALESCE(CASE
			WHEN RowTypes.AccountSign = 'Positive' AND RowTypes.DiscUndiscType = 'Undisc' THEN NULLIF(src.AccountCode_Undisc_Pos, '')
			WHEN RowTypes.AccountSign = 'Negative' AND RowTypes.DiscUndiscType = 'Undisc' THEN NULLIF(src.AccountCode_Undisc_Neg, '')
			WHEN RowTypes.AccountSign = 'Positive' AND RowTypes.DiscUndiscType = 'Disc' THEN NULLIF(src.AccountCode_Disc_Pos, '')
			WHEN RowTypes.AccountSign = 'Negative' AND RowTypes.DiscUndiscType = 'Disc' THEN NULLIF(src.AccountCode_Disc_Neg, '')
			END, 'Missing Mapping') <> 'Missing Mapping'



DROP TABLE IF EXISTS #LRCData
	SELECT RowTypes.AccountSign,
		RowTypes.DiscUndiscType,
		src.RunIDs, 
		src.AccountingDate, 
		src.FocusGroup,
		src.TriFocusCode,
		src.IFRS17TriFocusCode,
		src.RI_Flag,
		src.Programme,
		src.YOA, 
		src.YOI,
		src.CCY,
		'IFIE' AS [Statement], 
		src.Balance,
		src.Position,
		src.UOA,
		CASE
			WHEN RowTypes.AccountSign = 'Positive'  AND RowTypes.DiscUndiscType = 'UnDisc' THEN src.Amount
			WHEN RowTypes.AccountSign = 'Negative'  AND RowTypes.DiscUndiscType = 'UnDisc' THEN src.Amount *(-1)
			WHEN RowTypes.AccountSign = 'Positive' AND RowTypes.DiscUndiscType = 'Disc' THEN src.Disc 
			WHEN RowTypes.AccountSign = 'Negative' AND RowTypes.DiscUndiscType = 'Disc' THEN src.Disc  *(-1)      
		END as Amount,
		src.AgressoEntityCode,
		src.AgressoIFRS17ClientCode, 
		CASE
			WHEN RowTypes.DiscUndiscType = 'Disc' THEN src.TransactionType_Disc
			WHEN RowTypes.DiscUndiscType = 'Undisc' THEN src.TransactionType_Undisc
		END as TransactionType,
        CASE
            WHEN RowTypes.AccountSign = 'Positive' THEN src.AccountCodePositiveVE 
            WHEN RowTypes.AccountSign = 'Negative' THEN src.AccountCodeNegativeVE
        END as AccountCode,
		CONCAT('IFIE','_', src.RI_Flag, src.Balance, src.Position) AS  JournalDescription
	INTO #LRCData
	FROM (SELECT src.RunIDs, /* SUM to required grain */
				src.AccountingDate, 
				src.FocusGroup,
				src.TriFocusCode,
				src.IFRS17TriFocusCode,
				src.RI_Flag,
				src.Programme,
				src.YOA, 
				src.YOI,
				src.CCY,
				src.Balance,
				src.Position,
				src.UOA,
				src.AgressoEntityCode,
				src.AgressoIFRS17ClientCode, 
				src.TransactionType_Disc,
				src.TransactionType_Undisc,
				src.JournalDescription,
                src.AccountCode_Undisc_Pos,
                src.AccountCode_Undisc_Neg,
                src.AccountCode_Disc_Pos,
                src.AccountCode_Disc_Neg,
				T2.AccountCodePositiveVE,
				T2.AccountCodeNegativeVE,
				sum(src.Amount) as Amount,
				sum(src.Amount_disc) as Amount_disc,
				sum(src.Disc) as Disc    
			FROM Reporting.JournalInputDataYTD src
			INNER JOIN #ExpJouList T2 ON src.RunIDs = T2.RunIDs AND src.AccountingDate = T2.AccountingDate AND src.RI_Flag = T2.RI_Flag AND src.Balance = T2.Balance AND src.Position = T2.Position
			WHERE  [Statement] = 'LRC'
			GROUP BY src.RunIDs,
					src.AccountingDate, 
					src.FocusGroup,
					src.TriFocusCode,
					src.IFRS17TriFocusCode,
					src.RI_Flag,
					src.Programme,
					src.Statement, 
					src.YOA, 
					src.YOI,
					src.CCY,
					src.Balance,
					src.Position,
					src.UOA,
					src.AgressoEntityCode,
					src.AgressoIFRS17ClientCode, 
					src.TransactionType_Disc,
					src.TransactionType_Undisc,
					src.JournalDescription,
					src.AccountCode_Undisc_Pos,
					src.AccountCode_Undisc_Neg,
					src.AccountCode_Disc_Pos,
					src.AccountCode_Disc_Neg,
					T2.AccountCodePositiveVE,
					T2.AccountCodeNegativeVE
		) src
	CROSS JOIN (
				SELECT 'Positive' AccountSign, 'Undisc' as DiscUndiscType
				UNION ALL
				SELECT 'Negative', 'Undisc'
				UNION ALL
				SELECT 'Positive', 'Disc'
				UNION ALL
				SELECT 'Negative', 'Disc'
				) RowTypes
WHERE (src.Position not like '%Open%' and src.Position not like '%Closing%')
AND COALESCE(CASE
			WHEN RowTypes.AccountSign = 'Positive' AND RowTypes.DiscUndiscType = 'Undisc' THEN NULLIF(src.AccountCode_Undisc_Pos, '')
			WHEN RowTypes.AccountSign = 'Negative' AND RowTypes.DiscUndiscType = 'Undisc' THEN NULLIF(src.AccountCode_Undisc_Neg, '')
			WHEN RowTypes.AccountSign = 'Positive' AND RowTypes.DiscUndiscType = 'Disc' THEN NULLIF(src.AccountCode_Disc_Pos, '')
			WHEN RowTypes.AccountSign = 'Negative' AND RowTypes.DiscUndiscType = 'Disc' THEN NULLIF(src.AccountCode_Disc_Neg, '')
			END, 'Missing Mapping') <> 'Missing Mapping'



DROP TABLE IF EXISTS #FinalIFIEData
	SELECT [AccountSign], [DiscUndiscType], [RunIDs], [AccountingDate], [FocusGroup], [TriFocusCode], [IFRS17TriFocusCode], [RI_Flag], [Programme], 
                [YOA], [YOI], [CCY], [Statement], [Balance], [Position], [UOA], [AgressoEntityCode], [AgressoIFRS17ClientCode], [TransactionType], [AccountCode], 
                [JournalDescription], (SUM(CSMAmount)- SUM(LRCAmount)) Amount

	INTO #FinalIFIEData
	FROM 
	(
	SELECT [AccountSign], [DiscUndiscType], [RunIDs], [AccountingDate], [FocusGroup], [TriFocusCode], [IFRS17TriFocusCode], [RI_Flag], [Programme], 
                [YOA], [YOI], [CCY], [Statement], [Balance], [Position], [UOA], [AgressoEntityCode], [AgressoIFRS17ClientCode], [TransactionType], [AccountCode], 
                [JournalDescription], SUM([Amount])CSMAmount , 0 AS LRCAmount
	FROM #CSMData
	GROUP BY [AccountSign], [DiscUndiscType], [RunIDs], [AccountingDate], [FocusGroup], [TriFocusCode], [IFRS17TriFocusCode], [RI_Flag], [Programme], 
                [YOA], [YOI], [CCY], [Statement], [Balance], [Position], [UOA], [AgressoEntityCode], [AgressoIFRS17ClientCode], [TransactionType], [AccountCode], 
                [JournalDescription]

	UNION ALL
	SELECT [AccountSign], [DiscUndiscType], [RunIDs], [AccountingDate], [FocusGroup], [TriFocusCode], [IFRS17TriFocusCode], [RI_Flag], [Programme], 
                [YOA], [YOI], [CCY], [Statement], [Balance], [Position], [UOA], [AgressoEntityCode], [AgressoIFRS17ClientCode], [TransactionType], [AccountCode], 
                [JournalDescription],	 0 AS CSMAmount,   SUM(AMOUNT) LRCAmount
	FROM #LRCData
	GROUP BY [AccountSign], [DiscUndiscType], [RunIDs], [AccountingDate], [FocusGroup], [TriFocusCode], [IFRS17TriFocusCode], [RI_Flag], [Programme], 
                [YOA], [YOI], [CCY], [Statement], [Balance], [Position], [UOA], [AgressoEntityCode], [AgressoIFRS17ClientCode], [TransactionType], [AccountCode], 
                [JournalDescription]
)A
GROUP BY [AccountSign], [DiscUndiscType], [RunIDs], [AccountingDate], [FocusGroup], [TriFocusCode], [IFRS17TriFocusCode], [RI_Flag], [Programme], 
                [YOA], [YOI], [CCY], [Statement], [Balance], [Position], [UOA], [AgressoEntityCode], [AgressoIFRS17ClientCode], [TransactionType], [AccountCode], 
                [JournalDescription]


/*----------Final Insert---------------*/

   INSERT INTO [Reporting].[JournalOutputExperience]
               ([AccountSign], [DiscUndiscType], [RunIDs], [AccountingDate], [FocusGroup], [TriFocusCode], [IFRS17TriFocusCode], [RI_Flag], [Programme], 
                [YOA], [YOI], [CCY], [Statement], [Balance], [Position], [UOA], [Amount], [AgressoEntityCode], [AgressoIFRS17ClientCode], [TransactionType], [AccountCode], 
                [JournalDescription], [AuditUser], [AuditCreateDatetime])

    SELECT      [AccountSign], [DiscUndiscType], [RunIDs], [AccountingDate], [FocusGroup], [TriFocusCode], [IFRS17TriFocusCode], [RI_Flag], [Programme], 
                [YOA], [YOI], [CCY], [Statement], [Balance], [Position], [UOA], [Amount], [AgressoEntityCode], [AgressoIFRS17ClientCode], [TransactionType], [AccountCode], 
                [JournalDescription],@pUser, @createDatetime
    FROM #FinalIFIEData
	;

    IF @Trancount = 0 COMMIT;
    END TRY
    BEGIN CATCH
        IF @Trancount = 0 ROLLBACK;
        THROW;
    END CATCH

END;