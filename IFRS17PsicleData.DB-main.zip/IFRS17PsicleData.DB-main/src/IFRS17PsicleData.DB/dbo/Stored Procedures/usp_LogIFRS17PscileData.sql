﻿CREATE PROCEDURE [dbo].[usp_LogIFRS17PscileData]	@Input pwaps.utt_ActivityLog READONLY
AS
BEGIN

	/*
       =========================================================================================================
                                         Insert into Log table
       =========================================================================================================
*/

	INSERT	[$(IFRS17DataMart)].Control.[ActivityLog](FK_ActivityStatus, ActivityHost
													, ActivityDatabase, ActivityJobId, ActivitySSISExecutionId, ActivityName, ActivityDateTime, ActivityMessage)
	SELECT	
			ActivityStatus
	,		@@SERVERNAME
	,		DB_NAME()
	,		NULL
	,		ActivitySSISExecutionId
	,		ISNULL(ActivityName, 'IFRS17PscileData Activity')
	,		GETDATE()
	,		ActivityMessage
	--,		RowsAffected
	FROM	@Input
	end