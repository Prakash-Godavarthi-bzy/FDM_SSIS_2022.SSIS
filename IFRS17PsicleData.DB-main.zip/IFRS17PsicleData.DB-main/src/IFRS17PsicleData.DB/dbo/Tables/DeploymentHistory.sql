﻿CREATE TABLE [dbo].[DeploymentHistory] (
    [ID]                 INT            IDENTITY (1, 1) NOT NULL,
    [Release_Version_No] VARCHAR (50)   NULL,
    [DateofDeployment]   DATETIME       NULL,
    [Component]          VARCHAR (250)  NULL,
    [ServerName]         VARCHAR (50)   NULL,
    [ReleaseNotes]       NVARCHAR (MAX) NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);

