Canonical Release - https://beazley.atlassian.net/wiki/spaces/IDR/pages/4243456979/Release+1.8.14+-+IFRS17+Canonical
