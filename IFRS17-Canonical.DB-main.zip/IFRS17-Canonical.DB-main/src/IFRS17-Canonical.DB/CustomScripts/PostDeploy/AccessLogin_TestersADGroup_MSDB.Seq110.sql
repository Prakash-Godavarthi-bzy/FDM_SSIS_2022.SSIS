﻿USE [msdb]
GO

DECLARE @LoginName NVARCHAR(255) = N'BFL\App.IFRS17.Testers'
DECLARE @SQL NVARCHAR(MAX)
DECLARE @Env NVARCHAR(MAX) = '#{Environment}'

IF @Env = 'Development' OR @Env = 'SystemTest'
BEGIN
	IF NOT EXISTS    
	    ( SELECT    NAME FROM    sys.database_principals WHERE NAME = @LoginName)
	    BEGIN
	        SET    @SQL = 'CREATE USER ['+@LoginName+'] FOR LOGIN ['+@LoginName+']'
	        EXEC sp_executesql @SQL
	
			SET        @SQL = 'ALTER ROLE [sqlagentOperatorRole] ADD MEMBER ['+@LoginName+']'
			EXEC sp_executesql @SQL
	    END
END