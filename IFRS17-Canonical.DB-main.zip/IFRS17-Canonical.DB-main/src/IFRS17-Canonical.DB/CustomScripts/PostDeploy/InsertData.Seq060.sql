﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

-- Insert DataSource
MERGE	[dim].[DataSource] AS [Target]
USING	(
		SELECT	[PK_DataSourceID], [DataSource]
		FROM	(VALUES	
						(1,'FDM')
						,(2,'TechnicalHub')
						,(3,'IFRS17DataMart')
						,(4,'PostPreprocessing')
						,(5,'IDS')
						,(6,'ICE')
				) AS v([PK_DataSourceID], [DataSource])
		) AS [Source]
		ON		[Source].[PK_DataSourceID] = [Target].[PK_DataSourceID]
		WHEN NOT MATCHED BY Target THEN
			INSERT (
						[PK_DataSourceID]
						,[DataSource]
					)
			VALUES	(
						[Source].[PK_DataSourceID]
						,[Source].[DataSource]
					)
		WHEN MATCHED THEN UPDATE SET
			[Target].[DataSource] = [Source].[DataSource]
;

-- Insert Settlement currencies
MERGE	[dim].[CurrencySettlement] AS [Target]
USING	(
		SELECT	[CurrencyCode]
		FROM	(VALUES	
						('EUR')
						,('USD')
						,('GBP')
						,('CAD')
				) AS v([CurrencyCode])
		) AS [Source]
		ON		[Source].[CurrencyCode] = [Target].[CurrencyCode]
		WHEN NOT MATCHED BY Target THEN
			INSERT (
						[CurrencyCode]
					)
			VALUES	(
						[Source].[CurrencyCode]
					)
;

GO

