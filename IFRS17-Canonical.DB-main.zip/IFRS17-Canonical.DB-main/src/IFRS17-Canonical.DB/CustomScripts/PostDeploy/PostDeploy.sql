﻿MERGE Dim.InceptionPeriod AS Target
USING (
			SELECT	DISTINCT MOI AS PK_MOIID,MOI,CAST(MOI AS varchar(6))  InceptionPeriod
			FROM	fact.TechnicalHub_fct_VW_TechnicalResult
			WHERE	MOI IS NOT NULL
		)	AS Source
ON Source.PK_MOIID = Target.PK_MOIID
WHEN NOT MATCHED BY Target THEN
    INSERT (PK_MOIID,MOI, InceptionPeriod) 
    VALUES (Source.PK_MOIID,Source.MOI, Source.InceptionPeriod);