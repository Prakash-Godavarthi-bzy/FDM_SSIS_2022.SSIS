﻿DECLARE @LoginName NVARCHAR(255) = N'BFL\App.IFRS17.Developers'
DECLARE @SQL NVARCHAR(MAX)
DECLARE @Env NVARCHAR(MAX) = '#{Environment}'

IF NOT EXISTS    
    ( SELECT    NAME FROM    sys.database_principals WHERE NAME = @LoginName)
    BEGIN
        SET    @SQL = 'CREATE USER ['+@LoginName+'] FOR LOGIN ['+@LoginName+']'
        EXEC sp_executesql @SQL
    END

IF @Env = 'Development'
BEGIN
    SET        @SQL = 'ALTER SERVER ROLE [sysadmin] ADD MEMBER ['+@LoginName+']'
    EXEC sp_executesql @SQL
END
ELSE IF @Env = 'SystemTest'
BEGIN 
    SET        @SQL = 'ALTER ROLE [db_datareader] ADD MEMBER ['+@LoginName+']'
    EXEC sp_executesql @SQL
    SET        @SQL = 'ALTER ROLE [db_datawriter] ADD MEMBER ['+@LoginName+']'
    EXEC sp_executesql @SQL
END 
ELSE IF @Env = 'UserAcceptanceTest'
BEGIN 
    SET        @SQL = 'ALTER ROLE [db_datareader] ADD MEMBER ['+@LoginName+']'
    EXEC sp_executesql @SQL
END 
ELSE IF @Env = 'Production'
BEGIN 
    SET        @SQL = 'ALTER ROLE [db_datareader] ADD MEMBER ['+@LoginName+']'
    EXEC sp_executesql @SQL
END