﻿/* Access to BFL\App.IFRS17.Analysts */
DECLARE @LoginName NVARCHAR(255) = N'BFL\App.IFRS17.Analysts'
DECLARE @SQL NVARCHAR(MAX)

IF NOT EXISTS
    (    select loginname from master.dbo.syslogins WHERE loginname = @LoginName)
    BEGIN
            SET @SQL = 'CREATE LOGIN ['+@LoginName+'] FROM WINDOWS;'
            EXEC sp_executesql @SQL
    END
ELSE
    PRINT 'Login already exists '+ @LoginName