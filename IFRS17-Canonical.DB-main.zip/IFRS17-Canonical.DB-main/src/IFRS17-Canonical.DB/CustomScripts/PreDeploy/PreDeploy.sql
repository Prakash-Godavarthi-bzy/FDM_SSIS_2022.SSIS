﻿/* The script below will delete any tables with tmp as their schema. */
DECLARE @TableName NVARCHAR(128);
DECLARE @DropTableSQL NVARCHAR(MAX) = '';

SELECT	TABLE_NAME INTO #TablesToDrop
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA LIKE 'tmp' and TABLE_TYPE = 'BASE TABLE'

SELECT	TABLE_NAME FROM	#TablesToDrop

WHILE EXISTS (SELECT * FROM #TablesToDrop)
BEGIN
    SELECT TOP 1 @TableName = TABLE_NAME FROM #TablesToDrop;

    SET @DropTableSQL = 'DROP TABLE ' +  'tmp.' + QUOTENAME(@TableName) + ';';

    EXEC sp_executesql @DropTableSQL;

    DELETE FROM #TablesToDrop WHERE TABLE_NAME = @TableName;
END

DROP TABLE #TablesToDrop;

/* Adding column GroupShareValue */

IF NOT EXISTS (
  SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'fact'
  AND TABLE_NAME = 'FDM_DB_dbo_FactFDM'
  AND COLUMN_NAME = 'GroupShareValue'
)
BEGIN
	ALTER TABLE [fact].[FDM_DB_dbo_FactFDM]
	ADD [GroupShareValue] NUMERIC (38, 10) NULL
END
ELSE
BEGIN
	ALTER TABLE [fact].[FDM_DB_dbo_FactFDM]
	ALTER COLUMN [GroupShareValue] NUMERIC (38, 10) NULL
END

/* Altering FDM fact table to add column Dataset */

IF NOT EXISTS (
  SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'fact'
  AND TABLE_NAME = 'FDM_DB_dbo_FactFDM'
  AND COLUMN_NAME = 'Dataset'
)
BEGIN
	ALTER TABLE [fact].[FDM_DB_dbo_FactFDM]
	ADD [Dataset] VARCHAR(256) 
END

IF NOT EXISTS (
  SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'fact'
  AND TABLE_NAME = 'FDM_DB_dbo_FACTAllocationsV1_Current'
  AND COLUMN_NAME = 'Dataset'
)
BEGIN
	ALTER TABLE [fact].[FDM_DB_dbo_FACTAllocationsV1_Current]
	ADD [Dataset] VARCHAR(256) 
END

IF NOT EXISTS (
  SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'fact'
  AND TABLE_NAME = 'FDM_DB_dbo_FACTAllocationsV1_History'
  AND COLUMN_NAME = 'Dataset'
)
BEGIN
	ALTER TABLE [fact].[FDM_DB_dbo_FACTAllocationsV1_History]
	ADD [Dataset] VARCHAR(256) 
END

IF NOT EXISTS (
  SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'fact'
  AND TABLE_NAME = 'FDM_DB_dbo_FactFDMExternal_Current'
  AND COLUMN_NAME = 'Dataset'
)
BEGIN
	ALTER TABLE [fact].[FDM_DB_dbo_FactFDMExternal_Current]
	ADD [Dataset] VARCHAR(256) 
END

IF NOT EXISTS (
  SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'fact'
  AND TABLE_NAME = 'FDM_DB_dbo_FactFDMExternal_History'
  AND COLUMN_NAME = 'Dataset'
)
BEGIN
	ALTER TABLE [fact].[FDM_DB_dbo_FactFDMExternal_History]
	ADD [Dataset] VARCHAR(256) 
END

/*Altering IFRS17PsicleData fact table to add column Programme */
IF NOT EXISTS (
  SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'fact'
  AND TABLE_NAME = 'IFRS17PsicleData_Reporting_CSM_Post_LCAdjustments'
  AND COLUMN_NAME = 'Programme'
)
BEGIN
	ALTER TABLE [fact].[IFRS17PsicleData_Reporting_CSM_Post_LCAdjustments]
	ADD [Programme] varchar(100) 
END

IF NOT EXISTS (
  SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'fact'
  AND TABLE_NAME = 'IFRS17PsicleData_Results_PresStatementPatternsOB'
  AND COLUMN_NAME = 'Programme'
)
BEGIN
	ALTER TABLE [fact].[IFRS17PsicleData_Results_PresStatementPatternsOB]
	ADD [Programme] varchar(100) 
END

--IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[fact].[IFRS17PsicleData_Reporting_CSM_Extract]') AND type in (N'U'))
--DROP TABLE [fact].[IFRS17PsicleData_Reporting_CSM_Extract]
--GO


IF EXISTS (SELECT  1
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA = 'FACT'
AND		TABLE_NAME = 'IFRS17PsicleData_Results_PresStatementPatternsOB')
BEGIN
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'IFRS17PsicleData_Results_PresStatementPatternsOB' AND name = 'NCI_Fact_IFRS17PsicleData_Results_PresStatementPatternsOB_Fk_RunID_Fk_EntityID_FK_TrifocusID_YOI' )
	BEGIN
		CREATE NONCLUSTERED INDEX [NCI_Fact_IFRS17PsicleData_Results_PresStatementPatternsOB_Fk_RunID_Fk_EntityID_FK_TrifocusID_YOI]
		ON [fact].[IFRS17PsicleData_Results_PresStatementPatternsOB] ([FK_RunID],[FK_EntityID],[FK_TrifocusID],[FK_TrifocusIFRS17ID],[FK_CCYSettlementID],[RIFlag],[YOI])
		INCLUDE ([QOIEndDate],[Amount]) WITH (DROP_EXISTING = OFF)
	END
END


IF EXISTS (SELECT  1
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA = 'FACT'
AND		TABLE_NAME = 'IFRS17PsicleData_Reporting_CSM_Post_LCAdjustments')
BEGIN
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'IFRS17PsicleData_Reporting_CSM_Post_LCAdjustments' AND name = 'NCI_Fact_IFRS17PsicleData_Reporting_CSM_Post_LCAdjustments_FK_RunID_CSMLC' )
	BEGIN
		CREATE NONCLUSTERED INDEX [NCI_Fact_IFRS17PsicleData_Reporting_CSM_Post_LCAdjustments_FK_RunID_CSMLC] ON [fact].[IFRS17PsicleData_Reporting_CSM_Post_LCAdjustments]
		(
			[FK_RunID] ASC,
			[CSMLC] ASC
		)
		INCLUDE([FK_EntityID],[FK_TrifocusID],[FK_TrifocusIFRS17ID],[FK_CCYSettlementID],[RIFlag],[FK_YOAID],[YOI],[FK_StatementID],[FK_BalanceID],[FK_PositionID],[Amount],[AmountDiscounted]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [INDEXES]

	END
END

IF NOT EXISTS (
					SELECT 1
					FROM	INFORMATION_SCHEMA.TABLES
					WHERE	TABLE_SCHEMA = 'DIM'
					AND		TABLE_NAME = 'InceptionPeriod'
	)
	BEGIN

			CREATE TABLE [dim].[InceptionPeriod] (
			[PK_MOIID]        INT         NOT NULL,
			[MOI]             INT         NULL,
			[InceptionPeriod] VARCHAR (6) NULL,
			CONSTRAINT [PK_MOIID] PRIMARY KEY CLUSTERED ([PK_MOIID] ASC) WITH (FILLFACTOR = 90) ON [DATA]
		) ON [DATA];




			MERGE Dim.InceptionPeriod AS Target
			USING (
						SELECT	DISTINCT MOI AS PK_MOIID,MOI,CAST(MOI AS varchar(6))  InceptionPeriod
						FROM	fact.TechnicalHub_fct_VW_TechnicalResult
						WHERE	MOI IS NOT NULL
					)	AS Source
			ON Source.PK_MOIID = Target.PK_MOIID
			WHEN NOT MATCHED BY Target THEN
				INSERT (PK_MOIID,MOI, InceptionPeriod) 
				VALUES (Source.PK_MOIID,Source.MOI, Source.InceptionPeriod);
	END

	IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'IFRS17PsicleData_Reporting_CSM_Extract' AND TABLE_SCHEMA = 'FACT')
	BEGIN
	IF NOT EXISTS (
				SELECT	1
				FROM	INFORMATION_SCHEMA.COLUMNS
				WHERE	TABLE_SCHEMA = 'FACT'
				AND		TABLE_NAME = 'IFRS17PsicleData_Reporting_CSM_Extract'
				AND		COLUMN_NAME = 'FK_RIPolicyID'
				)
	BEGIN
			ALTER TABLE [fact].[IFRS17PsicleData_Reporting_CSM_Extract]
			ADD			FK_RIPolicyID [INT] NULL
	END
	END
--IF EXISTS (SELECT  1
--FROM	INFORMATION_SCHEMA.TABLES
--WHERE	TABLE_SCHEMA = 'FACT'
--AND		TABLE_NAME = 'IFRS17PsicleData_Reporting_CSM_Extract')
--BEGIN
--	IF EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'IFRS17PsicleData_Reporting_CSM_Extract' AND name = 'CCI_IFRS17PsicleData_Reporting_CSM_Extract' )
--	BEGIN
--		DROP INDEX [CCI_IFRS17PsicleData_Reporting_CSM_Extract] ON [fact].[IFRS17PsicleData_Reporting_CSM_Extract]

--	END
--END

--IF EXISTS (SELECT  1
--FROM	INFORMATION_SCHEMA.TABLES
--WHERE	TABLE_SCHEMA = 'FACT'
--AND		TABLE_NAME = 'IFRS17PsicleData_Reporting_CSM_Extract')
--BEGIN
--	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'IFRS17PsicleData_Reporting_CSM_Extract' AND name = 'CCI_IFRS17PsicleData_Reporting_CSM_Extract' )
--	BEGIN
--			CREATE CLUSTERED COLUMNSTORE INDEX [CCI_IFRS17PsicleData_Reporting_CSM_Extract] 
--			ON [fact].[IFRS17PsicleData_Reporting_CSM_Extract] WITH (DROP_EXISTING = OFF, COMPRESSION_DELAY = 0) ON [INDEXES]

--	END
--END

IF NOT EXISTS (
  SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'fact'
  AND TABLE_NAME = 'IFRS17PsicleData_Reporting_CSM_Extract'
  AND COLUMN_NAME = 'FXRate'
)
BEGIN
	ALTER TABLE [fact].[IFRS17PsicleData_Reporting_CSM_Extract]
	ADD [FXRate] numeric(28,8)
END

IF NOT EXISTS (
  SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'fact'
  AND TABLE_NAME = 'IFRS17PsicleData_Reporting_CSM_Extract'
  AND COLUMN_NAME = 'Calc_FXRateAmount'
)
BEGIN
	ALTER TABLE [fact].[IFRS17PsicleData_Reporting_CSM_Extract]
	ADD [Calc_FXRateAmount] numeric(38,6)
END

IF NOT EXISTS (
  SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'fact'
  AND TABLE_NAME = 'IFRS17PsicleData_Reporting_CSM_Extract'
  AND COLUMN_NAME = 'Calc_FXRateAmountDisc'
)
BEGIN
	ALTER TABLE [fact].[IFRS17PsicleData_Reporting_CSM_Extract]
	ADD [Calc_FXRateAmountDisc] numeric(38,6)
END

--Added ALter script to increase data type size to 128
IF EXISTS (SELECT	1
FROM	INFORMATION_SCHEMA.COLUMNS
WHERE	TABLE_SCHEMA = 'Dim'
AND		TABLE_NAME = 'Position'
AND		COLUMN_NAME = 'Position'
AND		CHARACTER_MAXIMUM_LENGTH = 32
		)
BEGIN
		ALTER TABLE		Dim.Position
		ALTER COLUMN	[Position] VARCHAR(128) NOT NULL
END
 
/**/

IF NOT EXISTS (
  SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'fact'
  AND TABLE_NAME = 'IFRS17PsicleData_Results_PresStatementPatternsOB'
  AND COLUMN_NAME = 'FXRate'
)
BEGIN
	ALTER TABLE [fact].[IFRS17PsicleData_Results_PresStatementPatternsOB]
	ADD [FXRate] numeric(28,8)
END

IF NOT EXISTS (
  SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'fact'
  AND TABLE_NAME = 'IFRS17PsicleData_Results_PresStatementPatternsOB'
  AND COLUMN_NAME = 'Calc_FXRateAmount'
)
BEGIN
	ALTER TABLE [fact].[IFRS17PsicleData_Results_PresStatementPatternsOB]
	ADD [Calc_FXRateAmount] numeric(38,6)
END

/**/

IF NOT EXISTS (
  SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'fact'
  AND TABLE_NAME = 'IFRS17PsicleData_Reporting_CSM_Post_LCAdjustments'
  AND COLUMN_NAME = 'FXRate'
)
BEGIN
	ALTER TABLE [fact].[IFRS17PsicleData_Reporting_CSM_Post_LCAdjustments]
	ADD [FXRate] numeric(28,8)
END

IF NOT EXISTS (
  SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'fact'
  AND TABLE_NAME = 'IFRS17PsicleData_Reporting_CSM_Post_LCAdjustments'
  AND COLUMN_NAME = 'Calc_FXRateAmount'
)
BEGIN
	ALTER TABLE [fact].[IFRS17PsicleData_Reporting_CSM_Post_LCAdjustments]
	ADD [Calc_FXRateAmount] numeric(38,6)
END

IF NOT EXISTS (
  SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'fact'
  AND TABLE_NAME = 'IFRS17PsicleData_Reporting_CSM_Post_LCAdjustments'
  AND COLUMN_NAME = 'Calc_FXRateAmountDisc'
)
BEGIN
	ALTER TABLE [fact].[IFRS17PsicleData_Reporting_CSM_Post_LCAdjustments]
	ADD [Calc_FXRateAmountDisc] numeric(38,6)
END

/**/
IF NOT EXISTS (
  SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'fact'
  AND TABLE_NAME = 'IFRS17Psicledata_Reporting_CSM_Discount_Post_BBNIAdjustments'
  AND COLUMN_NAME = 'FXRate'
)
BEGIN
	ALTER TABLE [fact].[IFRS17Psicledata_Reporting_CSM_Discount_Post_BBNIAdjustments]
	ADD [FXRate] numeric(28,8)
END

IF NOT EXISTS (
  SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'fact'
  AND TABLE_NAME = 'IFRS17Psicledata_Reporting_CSM_Discount_Post_BBNIAdjustments'
  AND COLUMN_NAME = 'Calc_FXRateAmount'
)
BEGIN
	ALTER TABLE [fact].[IFRS17Psicledata_Reporting_CSM_Discount_Post_BBNIAdjustments]
	ADD [Calc_FXRateAmount] numeric(38,6)
END

IF NOT EXISTS (
  SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'fact'
  AND TABLE_NAME = 'IFRS17Psicledata_Reporting_CSM_Discount_Post_BBNIAdjustments'
  AND COLUMN_NAME = 'Calc_FXRateAmountDisc'
)
BEGIN
	ALTER TABLE [fact].[IFRS17Psicledata_Reporting_CSM_Discount_Post_BBNIAdjustments]
	ADD [Calc_FXRateAmountDisc] numeric(38,6)
END

/* deleting Jobs with deleting underscore */

IF EXISTS (SELECT	1
FROM msdb.dbo.sysjobs
WHERE	name = N'Canonical_Data_Import')
BEGIN 
EXEC msdb.dbo.sp_delete_job 
	@job_name = N'Canonical_Data_Import' ;  
END

IF EXISTS (SELECT	1
FROM msdb.dbo.sysjobs
WHERE	name = N'Canonical_Import_IFRS17DataMart')
BEGIN 
EXEC msdb.dbo.sp_delete_job  
    @job_name = N'Canonical_Import_IFRS17DataMart' ;  
END

IF EXISTS (SELECT	1
FROM msdb.dbo.sysjobs
WHERE	name = N'Canonical_Import_IFRS17PsicleData')
BEGIN 
EXEC msdb.dbo.sp_delete_job  
    @job_name = N'Canonical_Import_IFRS17PsicleData' ;  
END


/**/
--IF EXISTS (SELECT  1
--FROM	INFORMATION_SCHEMA.TABLES
--WHERE	TABLE_SCHEMA = 'FACT'
--AND		TABLE_NAME = 'IFRS17PsicleData_Reporting_CSM_Extract')
--BEGIN
--	TRUNCATE TABLE fact.IFRS17PsicleData_Reporting_CSM_Extract
--END

IF EXISTS (SELECT  1
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA = 'FACT'
AND		TABLE_NAME = 'IFRS17PsicleData_Reporting_CSM_Extract')
BEGIN
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'IFRS17PsicleData_Reporting_CSM_Extract' AND name = 'NCI_Fact_CSM_Extract_RunID_RIFlag_TrifocusID_Fk_CCYSettlementID_Calc_AmountDisc' )
	BEGIN
		CREATE NONCLUSTERED INDEX [NCI_Fact_CSM_Extract_RunID_RIFlag_TrifocusID_Fk_CCYSettlementID_Calc_AmountDisc]
		ON [fact].[IFRS17PsicleData_Reporting_CSM_Extract] ([FK_RunID],[RIFlag])
		INCLUDE ([FK_TrifocusID],[FK_CCYSettlementID],[Calc_AmountDisc]) WITH (DROP_EXISTING = OFF)
	END
END

IF EXISTS (SELECT  1
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA = 'FACT'
AND		TABLE_NAME = 'IFRS17PsicleData_Reporting_CSM_Extract')
BEGIN
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'IFRS17PsicleData_Reporting_CSM_Extract' AND name = 'NCI_Fact_CSM_Extract_RunID_RIFlag_TrifocusID_Fk_CCYSettlementID_Calc_Amount' )
	BEGIN
		CREATE NONCLUSTERED INDEX [NCI_Fact_CSM_Extract_RunID_RIFlag_TrifocusID_Fk_CCYSettlementID_Calc_Amount]
		ON [fact].[IFRS17PsicleData_Reporting_CSM_Extract] ([FK_RunID],[RIFlag])
		INCLUDE ([FK_TrifocusID],[FK_CCYSettlementID],[Calc_Amount]) WITH (DROP_EXISTING = OFF)
	END
END

IF EXISTS (SELECT  1
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA = 'FACT'
AND		TABLE_NAME = 'IFRS17PsicleData_Reporting_CSM_Extract')
BEGIN
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'IFRS17PsicleData_Reporting_CSM_Extract' AND name = 'NCI_Fact_CSM_Extract_RunID_RIFlag_TrifocusID_Fk_CCYSettlementID_AmountDiscounted' )
	BEGIN
		CREATE NONCLUSTERED INDEX [NCI_Fact_CSM_Extract_RunID_RIFlag_TrifocusID_Fk_CCYSettlementID_AmountDiscounted]
		ON [fact].[IFRS17PsicleData_Reporting_CSM_Extract] ([FK_RunID],[RIFlag])
		INCLUDE ([FK_TrifocusID],[FK_CCYSettlementID],[AmountDiscounted]) WITH (DROP_EXISTING = OFF)
	END
END

IF EXISTS (SELECT  1
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA = 'FACT'
AND		TABLE_NAME = 'IFRS17PsicleData_Reporting_CSM_Extract')
BEGIN
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'IFRS17PsicleData_Reporting_CSM_Extract' AND name = 'NCI_Fact_CSM_Extract_RunID_RIFlag_TrifocusID_Fk_CCYSettlementID_Amount' )
	BEGIN
		CREATE NONCLUSTERED INDEX [NCI_Fact_CSM_Extract_RunID_RIFlag_TrifocusID_Fk_CCYSettlementID_Amount]
		ON [fact].[IFRS17PsicleData_Reporting_CSM_Extract] ([FK_RunID],[RIFlag])
		INCLUDE ([FK_TrifocusID],[FK_CCYSettlementID],[Amount]) WITH (DROP_EXISTING = OFF)
	END
END
/* 
		Date:		15-02-2024
		Purpose:	https://beazley.atlassian.net/browse/PBI-499
*/

--IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'TechnicalHub_fct_VW_TechnicalResult' AND TABLE_SCHEMA = 'FACT')
--BEGIN
--IF NOT EXISTS (
--			SELECT	1
--			FROM	INFORMATION_SCHEMA.COLUMNS
--			WHERE	TABLE_SCHEMA = 'FACT'
--			AND		TABLE_NAME = 'TechnicalHub_fct_VW_TechnicalResult'
--			AND		COLUMN_NAME = 'FK_ProgrammeCode'
--			)
--BEGIN
--		TRUNCATE TABLE [fact].[TechnicalHub_fct_VW_TechnicalResult]

--		ALTER TABLE [fact].[TechnicalHub_fct_VW_TechnicalResult]
--		ADD			[FK_ProgrammeCode]      VARCHAR (100)    NOT NULL
--END
--END

IF EXISTS (SELECT  1
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA = 'FACT'
AND		TABLE_NAME = 'FDM_DB_dbo_FactFDMExternal_History')
BEGIN
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'FDM_DB_dbo_FactFDMExternal_History' AND name = 'Fact_FDM_DB_dbo_FactFDMExternal_History_YOA_Entity_SourceKey_Account_ConformedEntity' )
	BEGIN
		CREATE NONCLUSTERED INDEX [Fact_FDM_DB_dbo_FactFDMExternal_History_YOA_Entity_SourceKey_Account_ConformedEntity]
		ON [fact].[FDM_DB_dbo_FactFDMExternal_History]([FK_YOAID] )
		INCLUDE([FK_AccountID], [FK_EntityID], [SourceKey], [Fk_ConformedEntityID])  WITH (DROP_EXISTING = OFF)
	END
END

IF NOT EXISTS (
  SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'fact'
  AND TABLE_NAME = 'IFRS17PsicleData_Results_PresStatementPatternsOB'
  AND COLUMN_NAME = 'Programme'
)
BEGIN
	ALTER TABLE [fact].[IFRS17PsicleData_Results_PresStatementPatternsOB]
	ALTER COLUMN [Programme] VARCHAR(128) NULL
END

/*Remove this code in next release*/
--IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'IFRS17PsicleData_Results_PresStatementPatternsOB' AND TABLE_SCHEMA = 'FACT')
--BEGIN
--	TRUNCATE TABLE FACT.IFRS17PsicleData_Results_PresStatementPatternsOB
--END

/**/

--IF NOT EXISTS (
--  SELECT *
--  FROM INFORMATION_SCHEMA.COLUMNS
--  WHERE TABLE_SCHEMA = 'fact'
--  AND TABLE_NAME = 'Aggregate_Reporting_LRC_Post_BBNIAdjustments'
--  AND COLUMN_NAME = 'InceptedStatus'
--)
--BEGIN
--	TRUNCATE TABLE [fact].[Aggregate_Reporting_LRC_Post_BBNIAdjustments]

--	ALTER TABLE [fact].[Aggregate_Reporting_LRC_Post_BBNIAdjustments]
--	ADD [InceptedStatus] char(1) NULL
--END

--IF NOT EXISTS (
--  SELECT *
--  FROM INFORMATION_SCHEMA.COLUMNS
--  WHERE TABLE_SCHEMA = 'fact'
--  AND TABLE_NAME = 'Aggregate_Reporting_CSM_Post_LCAdjustments'
--  AND COLUMN_NAME = 'InceptedStatus'
--)
--BEGIN
--	TRUNCATE TABLE [fact].[Aggregate_Reporting_CSM_Post_LCAdjustments]

--	ALTER TABLE [fact].[Aggregate_Reporting_CSM_Post_LCAdjustments]
--	ADD [InceptedStatus] char(1) NOT NULL
--END

--IF EXISTS (
--  SELECT *
--  FROM INFORMATION_SCHEMA.COLUMNS
--  WHERE TABLE_SCHEMA = 'fact'
--  AND TABLE_NAME = 'Aggregate_Reporting_CSM_LRC_LIC'
--)
--BEGIN
--	TRUNCATE TABLE [fact].[Aggregate_Reporting_CSM_LRC_LIC]
--END

--IF EXISTS (
--  SELECT *
--  FROM INFORMATION_SCHEMA.COLUMNS
--  WHERE TABLE_SCHEMA = 'fact'
--  AND TABLE_NAME = 'Agg_IFRS17PsicleData_Reporting_LIC_DiscountedData'
--)
--BEGIN
--	TRUNCATE TABLE [fact].[Agg_IFRS17PsicleData_Reporting_LIC_DiscountedData]
--END

--IF EXISTS (
--  SELECT *
--  FROM INFORMATION_SCHEMA.COLUMNS
--  WHERE TABLE_SCHEMA = 'dim'
--  AND TABLE_NAME = 'TrifocusMapping'
--)
--BEGIN
--	DELETE FROM dim.TrifocusMapping 
--	DBCC CHECKIDENT ('dim.TrifocusMapping',reseed,0)
--END

IF EXISTS (SELECT  1
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA = 'dim'
AND		TABLE_NAME = 'TrifocusMapping')
BEGIN
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'TrifocusMapping' AND name = 'NCI_TrifocusMapping_DivisionID_Trifocus_RunID_FocusGroup' )
	BEGIN
		CREATE NONCLUSTERED INDEX [NCI_TrifocusMapping_DivisionID_Trifocus_RunID_FocusGroup]
		ON [dim].[TrifocusMapping]([FK_DivisionID] ASC)
		INCLUDE([TrifocusCode], [FK_RunID], [FK_FocusGroupID]) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
		ON [DATA]
	END
END

IF EXISTS (SELECT  1
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA = 'dim'
AND		TABLE_NAME = 'TrifocusMapping')
BEGIN
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'TrifocusMapping' AND name = 'NCI_TrifocusMapping_TrifocusCode_RunID' )
	BEGIN
		CREATE NONCLUSTERED INDEX [NCI_TrifocusMapping_TrifocusCode_RunID]
    ON [dim].[TrifocusMapping]([TrifocusCode] ASC, [FK_RunID] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [DATA]
	END
END

IF EXISTS (SELECT  1
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA = 'fact'
AND		TABLE_NAME = 'Aggregate_Reporting_CSM_Post_LCAdjustments')
BEGIN
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'Aggregate_Reporting_CSM_Post_LCAdjustments' AND name = 'fact_Aggregate_Reporting_CSM_Post_LCAdjustments_CSMLC' )
	BEGIN
	CREATE NONCLUSTERED INDEX [fact_Aggregate_Reporting_CSM_Post_LCAdjustments_CSMLC]
    ON [fact].[Aggregate_Reporting_CSM_Post_LCAdjustments]([CSMLC] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [DATA]
	END
END

IF EXISTS (SELECT  1
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA = 'fact'
AND		TABLE_NAME = 'Aggregate_Reporting_CSM_Post_LCAdjustments')
BEGIN
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'Aggregate_Reporting_CSM_Post_LCAdjustments' AND name = 'Agg_IFRS17PsicleData_PositionID' )
	BEGIN
	CREATE NONCLUSTERED INDEX [Agg_IFRS17PsicleData_PositionID]
    ON [fact].[Aggregate_Reporting_CSM_Post_LCAdjustments]([FK_PositionID] ASC)
    INCLUDE([FK_RunID], [FK_EntityID], [FK_TrifocusID], [FK_RIPolicyID], [RIFlag], [FK_YOAID], [YOI], [FK_CCYSettlementID], [FK_StatementID], [FK_BalanceID], [Amount], [AmountDiscounted], [ConvertedAmount], [ConvertedAmountDiscounted], [CSMLC]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90);

	END
END

IF EXISTS (SELECT  1
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA = 'fact'
AND		TABLE_NAME = 'Aggregate_Reporting_LRC_Post_BBNIAdjustments')
BEGIN
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'Aggregate_Reporting_LRC_Post_BBNIAdjustments' AND name = 'Fact_Agg_IFRS17PsicleData_PositionID' )
	BEGIN
	CREATE NONCLUSTERED INDEX [Fact_Agg_IFRS17PsicleData_PositionID]
    ON [fact].[Aggregate_Reporting_LRC_Post_BBNIAdjustments]([FK_PositionID] ASC)
    INCLUDE([FK_RunID], [FK_EntityID], [FK_TrifocusID], [FK_RIPolicyID], [RIFlag], [FK_YOAID], [YOI], [FK_CCYSettlementID], [FK_StatementID], [FK_BalanceID], [Amount], [AmountDiscounted], [ConvertedAmount], [ConvertedAmountDiscounted]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90);

	END
END


IF EXISTS (SELECT  1
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA = 'fact'
AND		TABLE_NAME = 'IFRS17PsicleData_Reporting_CSM_Post_LCAdjustments')
BEGIN
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'IFRS17PsicleData_Reporting_CSM_Post_LCAdjustments' AND name = 'NCI_Fact_IFRS17PsicleData_Reporting_CSM_Post_LCAdjustments_RunID_CSMLC_EntityID' )
	BEGIN
	CREATE NONCLUSTERED INDEX [NCI_Fact_IFRS17PsicleData_Reporting_CSM_Post_LCAdjustments_RunID_CSMLC_EntityID]
    ON [fact].[IFRS17PsicleData_Reporting_CSM_Post_LCAdjustments]([FK_RunID] ASC, [CSMLC] ASC)
    INCLUDE([FK_EntityID], [FK_TrifocusID], [FK_RIPolicyID], [RIFlag], [FK_YOAID], [YOI], [FK_CCYSettlementID], [FK_StatementID], [FK_BalanceID], [FK_PositionID], [InceptedStatus], [Amount], [AmountDiscounted], [ConvertedAmount], [ConvertedAmountDiscounted]) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES]
	END
END

IF EXISTS (SELECT  1
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA = 'Mapping'
AND		TABLE_NAME = 'IFRS17DataMart_RunHierarchy')
BEGIN
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'IFRS17DataMart_RunHierarchy' AND name = 'Mapping_RunHirerachy_ParentRequestID' )
	BEGIN
	CREATE NONCLUSTERED INDEX [Mapping_RunHirerachy_ParentRequestID]
    ON [Mapping].[IFRS17DataMart_RunHierarchy]([ParentRequestID] DESC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [DATA]
	END
END

/* Date: 11-03-2024 */

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'NCI_Fact_CSM_Extract_RunID_RIFlag_TrifocusID_Fk_CCYSettlementID_Amount' AND object_id = OBJECT_ID('fact.IFRS17PsicleData_Reporting_CSM_Extract'))
BEGIN
	DROP INDEX NCI_Fact_CSM_Extract_RunID_RIFlag_TrifocusID_Fk_CCYSettlementID_Amount ON [fact].[IFRS17PsicleData_Reporting_CSM_Extract];
END;

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'NCI_Fact_CSM_Extract_RunID_RIFlag_TrifocusID_Fk_CCYSettlementID_AmountDiscounted' AND object_id = OBJECT_ID('fact.IFRS17PsicleData_Reporting_CSM_Extract'))
BEGIN
	DROP INDEX NCI_Fact_CSM_Extract_RunID_RIFlag_TrifocusID_Fk_CCYSettlementID_AmountDiscounted ON [fact].[IFRS17PsicleData_Reporting_CSM_Extract];
END;

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'NCI_Fact_CSM_Extract_RunID_RIFlag_TrifocusID_Fk_CCYSettlementID_Calc_Amount' AND object_id = OBJECT_ID('fact.IFRS17PsicleData_Reporting_CSM_Extract'))
BEGIN
	DROP INDEX NCI_Fact_CSM_Extract_RunID_RIFlag_TrifocusID_Fk_CCYSettlementID_Calc_Amount ON [fact].[IFRS17PsicleData_Reporting_CSM_Extract];
END;

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'NCI_Fact_CSM_Extract_RunID_RIFlag_TrifocusID_Fk_CCYSettlementID_Calc_AmountDisc' AND object_id = OBJECT_ID('fact.IFRS17PsicleData_Reporting_CSM_Extract'))
BEGIN
	DROP INDEX NCI_Fact_CSM_Extract_RunID_RIFlag_TrifocusID_Fk_CCYSettlementID_Calc_AmountDisc ON [fact].[IFRS17PsicleData_Reporting_CSM_Extract];
END;


IF EXISTS (SELECT  1
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA = 'fact'
AND		TABLE_NAME = 'IFRS17PsicleData_Reporting_CSM_Extract')
BEGIN
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'IFRS17PsicleData_Reporting_CSM_Extract' AND name = 'NCI_IFRS17PsicleData_Reporting_CSM_Extract_RunID_OtherColumns' )
	BEGIN
		CREATE NONCLUSTERED INDEX [NCI_IFRS17PsicleData_Reporting_CSM_Extract_RunID_OtherColumns]
		ON [fact].[IFRS17PsicleData_Reporting_CSM_Extract]([FK_RunID] ASC, [FK_TrifocusID] ASC)
		INCLUDE([Position], [FK_EntityID], [FK_CCYSettlementID], [RIFlag], [YOI], [FK_YOAID], [Year_QOIEndDate], [Amount], [AmountDiscounted], [Percentage], [Calc_Amount], [Calc_AmountDisc], [QOIDate], [Year], [NOY], [FXRate]) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
		ON [INDEXES];
	END
END

IF EXISTS (SELECT  1
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA = 'fact'
AND		TABLE_NAME = 'IFRS17PsicleData_Reporting_CSM_Extract')
BEGIN
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'IFRS17PsicleData_Reporting_CSM_Extract' AND name = 'NCI_Fact_CSM_Extract_RunID_RIFlag_TrifocusID_Fk_CCYSettlementID_Amount_AmountDisc_Calc_Amount_Calc_AmountDisc' )
	BEGIN
		CREATE NONCLUSTERED INDEX [NCI_Fact_CSM_Extract_RunID_RIFlag_TrifocusID_Fk_CCYSettlementID_Amount_AmountDisc_Calc_Amount_Calc_AmountDisc]
		ON [fact].[IFRS17PsicleData_Reporting_CSM_Extract]([FK_RunID] ASC, [RIFlag] ASC)
		INCLUDE([FK_TrifocusID], [FK_CCYSettlementID], [Amount], [AmountDiscounted], [Calc_Amount], [Calc_AmountDisc]) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
		ON [INDEXES];
	END
END
/*HL Change to include Ceded Pecenatages*/
IF NOT EXISTS (
				SELECT 1
				FROM	INFORMATION_SCHEMA.COLUMNS
				WHERE	TABLE_SCHEMA = 'FACT'
				AND		TABLE_NAME = 'FDM_DB_dbo_FactFDMExternal_Current'
				AND		COLUMN_NAME = 'CededValue'
		)
BEGIN
			ALTER TABLE fact.FDM_DB_dbo_FactFDMExternal_Current
			ADD		CededValue NUMERIC(38,5)

END


IF NOT EXISTS (
				SELECT 1
				FROM	INFORMATION_SCHEMA.COLUMNS
				WHERE	TABLE_SCHEMA = 'FACT'
				AND		TABLE_NAME = 'FDM_DB_dbo_FactFDMExternal_History'
				AND		COLUMN_NAME = 'CededValue'
		)
BEGIN
			ALTER TABLE fact.FDM_DB_dbo_FactFDMExternal_History
			ADD		CededValue NUMERIC(38,5)

END

/* CSMl LC Bugs FFixes*/
--Tables Changes
IF NOT EXISTS	(	SELECT	1
				FROM	INFORMATION_SCHEMA.COLUMNS
				WHERE	TABLE_SCHEMA = 'FACT'
				AND		TABLE_NAME = 'Aggregate_Reporting_CSM_Post_LCAdjustments'
				AND		COLUMN_NAME = 'Fk_TrifocusMappingID'
			)
BEGIN
ALTER	TABLE FACT.Aggregate_Reporting_CSM_Post_LCAdjustments
ADD		Fk_TrifocusMappingID 	BIGINT NULL
END 


IF NOT EXISTS	(	SELECT	1
				FROM	INFORMATION_SCHEMA.COLUMNS
				WHERE	TABLE_SCHEMA = 'FACT'
				AND		TABLE_NAME = 'Aggregate_Reporting_LRC_Post_BBNIAdjustments'
				AND		COLUMN_NAME = 'Fk_TrifocusMappingID'
			)
BEGIN
ALTER	TABLE FACT.Aggregate_Reporting_LRC_Post_BBNIAdjustments
ADD		Fk_TrifocusMappingID 	BIGINT NULL
END 
--Drop Indexex which are no Longer required
IF EXISTS (SELECT  1
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA = 'fact'
AND		TABLE_NAME = 'Aggregate_Reporting_CSM_Post_LCAdjustments')
BEGIN
IF EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'Aggregate_Reporting_CSM_Post_LCAdjustments' AND name = 'NCI_Agg_CSM_Post_LCAdjustments_FK_EntityID_FK_YOAID' )
	BEGIN
		DROP INDEX [NCI_Agg_CSM_Post_LCAdjustments_FK_EntityID_FK_YOAID] ON [fact].[Aggregate_Reporting_CSM_Post_LCAdjustments]
	END
END

--Alter Index
IF EXISTS (SELECT  1
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA = 'fact'
AND		TABLE_NAME = 'Aggregate_Reporting_CSM_Post_LCAdjustments')
BEGIN
IF  EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'Aggregate_Reporting_CSM_Post_LCAdjustments' AND name = 'Agg_IFRS17PsicleData_PositionID' )
	BEGIN
		DROP INDEX [Agg_IFRS17PsicleData_PositionID] ON [fact].[Aggregate_Reporting_CSM_Post_LCAdjustments]
		

		CREATE NONCLUSTERED INDEX [Agg_IFRS17PsicleData_PositionID] ON [fact].[Aggregate_Reporting_CSM_Post_LCAdjustments]
		(
			[FK_PositionID] ASC
		)
		INCLUDE([FK_RunID],[Fk_TrifocusMappingID],[FK_EntityID],[FK_TrifocusID],[FK_RIPolicyID],[RIFlag],[FK_YOAID],[YOI],[FK_CCYSettlementID],[FK_StatementID],[FK_BalanceID],[Amount],[AmountDiscounted],[ConvertedAmount],[ConvertedAmountDiscounted],[CSMLC]) 
		WITH (FILLFACTOR = 90, DROP_EXISTING = OFF) ON [INDEXES]
		
		END
END;

IF EXISTS (SELECT  1
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA = 'fact'
AND		TABLE_NAME = 'Aggregate_Reporting_CSM_Post_LCAdjustments')
BEGIN
IF  EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'Aggregate_Reporting_CSM_Post_LCAdjustments' AND name = 'NCI_fact_agg_CSM_Post_LC_Adj_PositionID_CSMLC' )
	BEGIN
			DROP INDEX [fact_Aggregate_Reporting_CSM_Post_LCAdjustments_CSMLC] ON [fact].[Aggregate_Reporting_CSM_Post_LCAdjustments]

			CREATE NONCLUSTERED INDEX [fact_Aggregate_Reporting_CSM_Post_LCAdjustments_CSMLC] ON [fact].[Aggregate_Reporting_CSM_Post_LCAdjustments]
			(
				[CSMLC] ASC
			) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
			ON [INDEXES];
		
	END
END;

--New indexes for CSM LC Bugs
IF EXISTS (SELECT  1
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA = 'fact'
AND		TABLE_NAME = 'Aggregate_Reporting_CSM_Post_LCAdjustments')
BEGIN
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'Aggregate_Reporting_CSM_Post_LCAdjustments' AND name = 'NCI_fact_agg_CSM_Post_LC_Adj_PositionID_CSMLC' )
	BEGIN

		CREATE NONCLUSTERED INDEX [NCI_fact_agg_CSM_Post_LC_Adj_PositionID_CSMLC] ON [fact].[Aggregate_Reporting_CSM_Post_LCAdjustments]
		(
			[FK_PositionID] ASC,
			[CSMLC] ASC
		)
		INCLUDE([FK_RunID],[FK_BalanceID],[ConvertedAmountDiscounted],[Fk_TrifocusMappingID],[RIFlag]) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
		ON [INDEXES];
	END
END


IF EXISTS (SELECT  1
FROM	INFORMATION_SCHEMA.TABLES
WHERE	TABLE_SCHEMA = 'fact'
AND		TABLE_NAME = 'Aggregate_Reporting_CSM_Post_LCAdjustments')
BEGIN
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE OBJECT_NAME(object_id) = 'Aggregate_Reporting_CSM_Post_LCAdjustments' AND name = 'NCI_fact_agg_CSM_Post_LC_Adj_PositionID_CSMLC_RiFlag' )
	BEGIN

		CREATE NONCLUSTERED INDEX [NCI_fact_agg_CSM_Post_LC_Adj_PositionID_CSMLC_RiFlag] ON [fact].[Aggregate_Reporting_CSM_Post_LCAdjustments]
		(
			[RIFlag] ASC,
			[FK_PositionID] ASC,
			[CSMLC] ASC
		)
		INCLUDE([FK_RunID],[FK_BalanceID],[ConvertedAmountDiscounted],[Fk_TrifocusMappingID]) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
		ON [INDEXES];
	END
END

/*Net Liabilities DataModel Change */

IF NOT EXISTS	(	SELECT	1
				FROM	INFORMATION_SCHEMA.COLUMNS
				WHERE	TABLE_SCHEMA = 'FACT'
				AND		TABLE_NAME = 'Agg_IFRS17PsicleData_Reporting_LIC_DiscountedData'
				AND		COLUMN_NAME = 'Fk_TrifocusMappingID'
			)
BEGIN
ALTER	TABLE FACT.Agg_IFRS17PsicleData_Reporting_LIC_DiscountedData
ADD		Fk_TrifocusMappingID 	BIGINT NULL
END 


IF NOT EXISTS	(	SELECT	1
				FROM	INFORMATION_SCHEMA.COLUMNS
				WHERE	TABLE_SCHEMA = 'FACT'
				AND		TABLE_NAME = 'Aggregate_Reporting_CSM_LRC_LIC'
				AND		COLUMN_NAME = 'Fk_TrifocusMappingID'
			)
BEGIN
ALTER	TABLE FACT.Aggregate_Reporting_CSM_LRC_LIC
ADD		Fk_TrifocusMappingID 	BIGINT NULL
END 

IF NOT EXISTS	(	SELECT	1
				FROM	INFORMATION_SCHEMA.COLUMNS
				WHERE	TABLE_SCHEMA = 'FACT'
				AND		TABLE_NAME = 'Agg_IFRS17PsicleData_Reporting_LIC_DiscountedData'
				AND		COLUMN_NAME = 'InceptedStatus'
			)
BEGIN
ALTER	TABLE FACT.Agg_IFRS17PsicleData_Reporting_LIC_DiscountedData
ADD		InceptedStatus 	CHAR(1) NULL
END 



/* GAAP to Box 4 Incremental Changes HL 20240916 */
IF NOT EXISTS (SELECT		1
				FROM		INFORMATION_SCHEMA.COLUMNS
				WHERE		COLUMN_NAME = 'Bk_TransactionID'
			)
BEGIN
			ALTER	TABLE fact.FDM_DB_dbo_FactFDM
			ADD		Bk_TransactionID bigint NULL
END


IF NOT EXISTS (SELECT		1
				FROM		INFORMATION_SCHEMA.COLUMNS
				WHERE		COLUMN_NAME = 'FK_BatchID'
				AND			TABLE_SCHEMA = 'FACT'
				AND			TABLE_NAME = 'FDM_DB_dbo_FACTAllocationsV1_Current'
			)
BEGIN
			ALTER	TABLE fact.FDM_DB_dbo_FACTAllocationsV1_Current
			ADD		FK_BatchID INT NULL
END


IF NOT EXISTS (SELECT		1
				FROM		INFORMATION_SCHEMA.COLUMNS
				WHERE		COLUMN_NAME = 'FK_BatchID'
				AND			TABLE_SCHEMA = 'FACT'
				AND			TABLE_NAME = 'FDM_DB_dbo_FACTAllocationsV1_History'
			)
BEGIN
			ALTER	TABLE fact.FDM_DB_dbo_FACTAllocationsV1_History
			ADD		FK_BatchID INT NULL
END


IF NOT EXISTS (SELECT		1
				FROM		INFORMATION_SCHEMA.COLUMNS
				WHERE		COLUMN_NAME = 'RunProcessLogID'
				AND			TABLE_SCHEMA = 'FACT'
				AND			TABLE_NAME = 'FDM_DB_dbo_FactFDMExternal_Current'
			)
BEGIN
			ALTER	TABLE fact.FDM_DB_dbo_FactFDMExternal_Current
			ADD		RunProcessLogID INT NULL
END


IF NOT EXISTS (SELECT		1
				FROM		INFORMATION_SCHEMA.COLUMNS
				WHERE		COLUMN_NAME = 'RunProcessLogID'
				AND			TABLE_SCHEMA = 'FACT'
				AND			TABLE_NAME = 'FDM_DB_dbo_FactFDMExternal_History'
			)
BEGIN
			ALTER	TABLE fact.FDM_DB_dbo_FactFDMExternal_History
			ADD		RunProcessLogID INT NULL
END

IF NOT EXISTS (SELECT		*
				FROM		INFORMATION_SCHEMA.COLUMNS
				WHERE		COLUMN_NAME = 'Fk_datastageID'
				AND			TABLE_SCHEMA = 'FACT'
				AND			TABLE_NAME = 'Aggregate_TechnicalHub_fct_VW_TechnicalResult'
			)
BEGIN
			ALTER	TABLE fact.Aggregate_TechnicalHub_fct_VW_TechnicalResult
			ADD		Fk_datastageID bigint NULL
END

/*Indexes Updation */

--Fact FDM 

IF EXISTS (	SELECT		1
			FROM		sys.indexes
			WHERE		name = 'NCI_FactFDM_FK_AccountingPeriodID_SourceKey_Hash'
		)
BEGIN

DROP INDEX [NCI_FactFDM_FK_AccountingPeriodID_SourceKey_Hash] ON [fact].[FDM_DB_dbo_FactFDM]

END


IF NOT EXISTS (	SELECT		1
			FROM		sys.indexes
			WHERE		name = 'NCI_FactFDM_FK_AccountingPeriodID_SourceKey_Hash_BkTransactionID'
		)
BEGIN

CREATE NONCLUSTERED INDEX [NCI_FactFDM_FK_AccountingPeriodID_SourceKey_Hash_BkTransactionID] ON [fact].[FDM_DB_dbo_FactFDM]
(
	[FK_AccountingPeriodID] ASC,
	[SourceKey] ASC,
	[Hash] ASC
)
INCLUDE([Bk_TransactionID]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [INDEXES]

END

--Fact FDM external History
IF EXISTS (	SELECT		1
			FROM		sys.indexes
			WHERE		name = 'NCI_FactFDMExternal_History_FK_AccountingPeriodID_SourceKey_Hash'
		)
BEGIN

DROP INDEX [NCI_FactFDMExternal_History_FK_AccountingPeriodID_SourceKey_Hash] ON [fact].[FDM_DB_dbo_FactFDMExternal_History]

END

IF EXISTS (	SELECT		1
			FROM		sys.indexes
			WHERE		name = 'NCI_FactFDMExternal_History_SourceKey_Hash'
		)
BEGIN

DROP INDEX [NCI_FactFDMExternal_History_SourceKey_Hash] ON [fact].[FDM_DB_dbo_FactFDMExternal_History]

END

IF NOT EXISTS (	SELECT		1
			FROM		sys.indexes
			WHERE		name = 'NCI_FactFDMExternal_History_SourceKey_Hash_RunProcessLogID'
		)
BEGIN

CREATE NONCLUSTERED INDEX [NCI_FactFDMExternal_History_SourceKey_Hash_RunProcessLogID] ON [fact].[FDM_DB_dbo_FactFDMExternal_History]
(
	[SourceKey] ASC,
	[Hash] ASC
)
INCLUDE([RunProcessLogID])WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [INDEXES]


END

-- Fact FDM external Current
IF EXISTS (	SELECT		1
			FROM		sys.indexes
			WHERE		name = 'NCI_FactFDMExternal_Current_SourceKey_Hash'
		)
BEGIN

DROP INDEX [NCI_FactFDMExternal_Current_SourceKey_Hash] ON [fact].[FDM_DB_dbo_FactFDMExternal_Current]

END


IF NOT EXISTS (	SELECT		1
			FROM		sys.indexes
			WHERE		name = 'NCI_FactFDMExternal_Current_SourceKey_Hash_RunProcessLogID'
		)
BEGIN
CREATE NONCLUSTERED INDEX [NCI_FactFDMExternal_Current_SourceKey_Hash_RunProcessLogID] ON [fact].[FDM_DB_dbo_FactFDMExternal_Current]
(
	[SourceKey] ASC,
	[Hash] ASC
)
INCLUDE([RunProcessLogID])WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [INDEXES]


END


--Fact FDM Allocations V1 Current

IF EXISTS (	SELECT		1
			FROM		sys.indexes
			WHERE		name = 'NCI_FACTAllocationsV1_Current_SourceKey_Hash'
		)
BEGIN

DROP INDEX [NCI_FactFDMExternal_Current_SourceKey_Hash] ON [fact].[FDM_DB_dbo_FactFDMExternal_Current]

END


IF NOT EXISTS (	SELECT		1
			FROM		sys.indexes
			WHERE		name = 'NCI_FACTAllocationsV1_Current_SourceKey_Hash_BatchID'
		)
BEGIN
CREATE NONCLUSTERED INDEX [NCI_FACTAllocationsV1_Current_SourceKey_Hash_BatchID] ON [fact].[FDM_DB_dbo_FACTAllocationsV1_Current]
(
	[SourceKey] ASC,
	[Hash] ASC
)
INCLUDE(Fk_BatchID)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [INDEXES]


END


--Fact FDM Allocations V1 Current

IF EXISTS (	SELECT		1
			FROM		sys.indexes
			WHERE		name = 'NCI_FACTAllocationsV1_History_SourceKey_Hash'
		)
BEGIN

DROP INDEX [NCI_FACTAllocationsV1_History_SourceKey_Hash] ON [fact].[FDM_DB_dbo_FACTAllocationsV1_History]

END


IF NOT EXISTS (	SELECT		1
			FROM		sys.indexes
			WHERE		name = 'NCI_FACTAllocationsV1_History_SourceKey_Hash_BatchID'
		)
BEGIN
CREATE NONCLUSTERED INDEX [NCI_FACTAllocationsV1_History_SourceKey_Hash_BatchID] ON [fact].[FDM_DB_dbo_FACTAllocationsV1_History]
(
	[SourceKey] ASC,
	[Hash] ASC
)
INCLUDE(Fk_BatchID)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [INDEXES]


END