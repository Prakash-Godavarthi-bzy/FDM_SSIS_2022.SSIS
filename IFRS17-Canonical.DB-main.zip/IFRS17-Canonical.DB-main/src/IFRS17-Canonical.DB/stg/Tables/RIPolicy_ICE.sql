﻿CREATE TABLE [stg].[RIPolicy_ICE] (
    [SourceKey]       VARCHAR (128)  NOT NULL,
    [RIProgrammeName] VARCHAR (64)   NULL,
    [Hash]            VARBINARY (64) NOT NULL
) ON [STAGE];

