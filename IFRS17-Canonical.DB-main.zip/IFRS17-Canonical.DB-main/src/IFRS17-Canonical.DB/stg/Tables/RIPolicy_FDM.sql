﻿CREATE TABLE [stg].[RIPolicy_FDM] (
    [SourceKey]        VARCHAR (128)  NOT NULL,
    [RIPolicyTypeCode] VARCHAR (16)   NULL,
    [RIProgrammeName]  VARCHAR (64)   NULL,
    [RIAdjustment]     VARCHAR (8)    NULL,
    [RIPolicyNumber]   VARCHAR (128)  NULL,
    [Hash]             VARBINARY (64) NOT NULL
) ON [STAGE];





