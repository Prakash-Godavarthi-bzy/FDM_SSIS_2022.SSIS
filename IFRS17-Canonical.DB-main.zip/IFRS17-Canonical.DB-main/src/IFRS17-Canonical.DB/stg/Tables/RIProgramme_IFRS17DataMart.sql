﻿CREATE TABLE [stg].[RIProgramme_IFRS17DataMart] (
    [SourceKey]     VARCHAR (128)  NOT NULL,
    [ProgrammeName] VARCHAR (64)   NULL,
    [Hash]          VARBINARY (64) NOT NULL
);

