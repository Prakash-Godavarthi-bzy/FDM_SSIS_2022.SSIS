﻿CREATE TABLE [stg].[Run_ICE] (
    [RunID]           INT            NOT NULL,
    [RunType]         VARCHAR (25)   NOT NULL,
    [RunDescription]  VARCHAR (500)  NULL,
    [ReportingPeriod] INT            NULL,
    [Hash]            VARBINARY (64) NOT NULL,
    [SourceKey]       VARCHAR (128)  NOT NULL
) ON [STAGE];



