﻿CREATE TABLE [stg].[ConformedEntity_TechnicalHub] (
    [FK_EntityID]          INT            NOT NULL,
    [EntityCode]           VARCHAR (50)   NOT NULL,
    [FK_ConformedEntityID] INT            NOT NULL,
    [ConformedEntityCode]  VARCHAR (50)   NULL,
    [Hash]                 VARBINARY (64) NOT NULL
);

