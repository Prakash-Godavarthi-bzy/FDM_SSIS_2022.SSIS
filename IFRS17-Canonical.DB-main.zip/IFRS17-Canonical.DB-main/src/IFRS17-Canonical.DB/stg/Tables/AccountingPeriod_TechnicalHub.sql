﻿CREATE TABLE [stg].[AccountingPeriod_TechnicalHub] (
    [PK_AccountingPeriodID] INT NOT NULL
) ON [STAGE];

