﻿CREATE TABLE [stg].[Intercompany_Rules] (
    [Dataset]          VARCHAR (25)   NOT NULL,
    [GrossRI]          VARCHAR (3)    NOT NULL,
    [YOA]              VARCHAR (10)   NOT NULL,
    [Entity]           VARCHAR (10)   NOT NULL,
    [Trifocus]         VARCHAR (25)   NOT NULL,
    [Programme]        VARCHAR (100)  NOT NULL,
    [Percentage]       FLOAT (53)     NOT NULL,
    [Flag]             VARCHAR (20)   NOT NULL,
    [PrioritySequence] INT            NOT NULL,
    [FromDOF]          DATE           NULL,
    [ToDOF]            DATE           NULL,
    [Hash]             VARBINARY (64) NOT NULL
);

