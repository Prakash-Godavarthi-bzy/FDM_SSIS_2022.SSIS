﻿CREATE TABLE [stg].[AccountIFRS17_IFRS17DataMart] (
    [AccountKey]  VARCHAR (16)   NOT NULL,
    [AccountName] VARCHAR (100)  NULL,
    [Level1Group] VARCHAR (64)   NULL,
    [Level2Group] VARCHAR (64)   NULL,
    [Level3Group] VARCHAR (64)   NULL,
    [RIFlag]      VARCHAR (2)    NULL,
    [Hash]        VARBINARY (64) NOT NULL,
    [SourceKey]   VARCHAR (128)  NOT NULL
) ON [DATA];

