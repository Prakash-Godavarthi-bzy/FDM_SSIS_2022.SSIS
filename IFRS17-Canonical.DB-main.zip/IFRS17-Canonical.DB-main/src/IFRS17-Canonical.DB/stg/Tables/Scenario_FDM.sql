﻿CREATE TABLE [stg].[Scenario_FDM] (
    [ScenarioCode]  VARCHAR (16)   NOT NULL,
    [ScenarioName]  VARCHAR (32)   NULL,
    [ScenarioType]  VARCHAR (16)   NULL,
    [SortOrder]     INT            NULL,
    [FriendlyName]  VARCHAR (32)   NULL,
    [CurrentPeriod] INT            NULL,
    [Hash]          VARBINARY (64) NOT NULL,
    [SourceKey]     VARCHAR (128)  NULL
) ON [STAGE];

