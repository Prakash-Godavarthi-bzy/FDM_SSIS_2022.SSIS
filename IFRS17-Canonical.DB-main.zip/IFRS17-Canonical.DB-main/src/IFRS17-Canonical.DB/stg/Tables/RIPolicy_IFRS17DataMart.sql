﻿CREATE TABLE [stg].[RIPolicy_IFRS17DataMart] (
    [SourceKey]        VARCHAR (128)  NOT NULL,
    [RIPolicyTypeCode] VARCHAR (16)   NULL,
    [RIProgrammeName]  VARCHAR (64)   NULL,
    [RIPolicyNumber]   VARCHAR (128)  NULL,
    [Hash]             VARBINARY (64) NOT NULL
) ON [STAGE];



