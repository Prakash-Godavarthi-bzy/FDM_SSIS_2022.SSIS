﻿CREATE TABLE [stg].[RateScenario_FDM] (
    [SourceKey] VARCHAR (128)  NOT NULL,
    [RateCode]  VARCHAR (128)  NOT NULL,
    [RateName]  VARCHAR (128)  NOT NULL,
    [RateGroup] VARCHAR (128)  NOT NULL,
    [Locked]    VARCHAR (1)    NOT NULL,
    [SortOrder] INT            NULL,
    [Hash]      VARBINARY (64) NOT NULL
) ON [STAGE];

