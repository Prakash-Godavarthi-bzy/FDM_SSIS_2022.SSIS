﻿CREATE TABLE [stg].[Entity_ICE] (
    [EntityCode] VARCHAR (16)   NOT NULL,
    [Hash]       VARBINARY (64) NOT NULL,
    [SourceKey]  VARCHAR (128)  NULL
) ON [STAGE];

