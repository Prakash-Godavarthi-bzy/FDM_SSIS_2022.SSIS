﻿CREATE TABLE [stg].[AccountingPeriod_ICE] (
    [PK_AccountingPeriodID] INT NOT NULL
) ON [STAGE];

