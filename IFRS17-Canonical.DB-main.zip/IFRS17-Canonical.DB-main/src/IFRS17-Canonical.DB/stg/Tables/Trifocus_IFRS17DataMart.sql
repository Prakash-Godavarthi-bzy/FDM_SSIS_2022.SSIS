﻿CREATE TABLE [stg].[Trifocus_IFRS17DataMart] (
    [SourceKey]      VARCHAR (128)  NOT NULL,
    [TrifocusCode]   VARCHAR (16)   NOT NULL,
    [TriFocusName]   NVARCHAR (64)  NOT NULL,
    [TriFocusLevel1] NVARCHAR (64)  NULL,
    [TriFocusLevel2] NVARCHAR (64)  NULL,
    [TriFocusLevel3] NVARCHAR (64)  NULL,
    [Hash]           VARBINARY (64) NOT NULL
) ON [STAGE];

