﻿CREATE TABLE [stg].[AccountICE_ICE] (
    [AccountICE] VARCHAR (16)   NOT NULL,
    [Hash]       VARBINARY (64) NOT NULL,
    [SourceKey]  VARCHAR (128)  NULL
) ON [STAGE];

