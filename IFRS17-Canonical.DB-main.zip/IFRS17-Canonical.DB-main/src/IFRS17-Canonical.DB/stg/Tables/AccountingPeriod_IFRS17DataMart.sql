﻿CREATE TABLE [stg].[AccountingPeriod_IFRS17DataMart] (
    [PK_AccountingPeriodID] INT NOT NULL
) ON [STAGE];

