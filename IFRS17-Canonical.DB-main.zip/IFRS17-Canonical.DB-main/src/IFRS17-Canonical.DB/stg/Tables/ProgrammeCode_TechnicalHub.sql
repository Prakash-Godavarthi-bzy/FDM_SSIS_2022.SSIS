﻿CREATE TABLE [stg].[ProgrammeCode_TechnicalHub] (
    [SourceKey]     BIGINT         NOT NULL,
    [ProgrammeCode] VARCHAR (100)  NULL,
    [Hash]          VARBINARY (64) NOT NULL
);

