﻿CREATE TABLE [stg].[ConformedTrifocus_TechnicalHub] (
    [Fk_TrifocusID]          INT            NULL,
    [TrifocusCode]           VARCHAR (50)   NOT NULL,
    [Fk_ConformedTrifocusID] INT            NULL,
    [ConformedTrifocusCode]  VARCHAR (50)   NULL,
    [Hash]                   VARBINARY (64) NOT NULL
);

