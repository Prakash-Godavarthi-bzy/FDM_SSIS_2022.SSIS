﻿CREATE TABLE [stg].[Trifocus_FDM] (
    [TrifocusCode]      VARCHAR (16)   NOT NULL,
    [TriFocusName]      NVARCHAR (64)  NOT NULL,
    [TrifocusGroup]     VARCHAR (8)    NULL,
    [IsUSTrifocus]      BIT            NULL,
    [IsKrReTrifocus]    BIT            NULL,
    [IsUSSyndTrifocus]  BIT            NULL,
    [IsSLInternational] BIT            NULL,
    [status]            VARCHAR (8)    NULL,
    [TrifocusTypeCode]  CHAR (1)       NULL,
    [TrifocusTypeDesc]  VARCHAR (16)   NULL,
    [Hash]              VARBINARY (64) NOT NULL,
    [SourceKey]         VARCHAR (128)  NULL
) ON [STAGE];

