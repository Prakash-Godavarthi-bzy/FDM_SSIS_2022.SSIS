﻿CREATE TABLE [stg].[Position_ICE] (
    [Position]  VARCHAR (32)   NOT NULL,
    [Hash]      VARBINARY (64) NOT NULL,
    [SourceKey] VARCHAR (128)  NULL
) ON [STAGE];

