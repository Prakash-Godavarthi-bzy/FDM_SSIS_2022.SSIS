﻿CREATE TABLE [stg].[DataStage_FDM] (
    [DataStage] VARCHAR (64)   NULL,
    [Hash]      VARBINARY (64) NULL,
    [SourceKey] VARCHAR (128)  NULL
) ON [STAGE];

