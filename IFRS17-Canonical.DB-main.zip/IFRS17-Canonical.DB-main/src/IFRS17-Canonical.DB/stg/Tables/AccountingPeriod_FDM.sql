﻿CREATE TABLE [stg].[AccountingPeriod_FDM] (
    [PK_AccountingPeriodID] INT NOT NULL
) ON [STAGE];

