﻿CREATE TABLE [stg].[PolicySection_FDM] (
    [PolicyReference]  VARCHAR (32)   NOT NULL,
    [SectionReference] VARCHAR (32)   NULL,
    [InceptionDate]    DATE           NULL,
    [ExpiryDate]       DATE           NULL,
    [BindDate]         DATE           NULL,
    [PolicyType]       VARCHAR (10)   NULL,
    [Hash]             VARBINARY (64) NOT NULL,
    [SourceKey]        VARCHAR (128)  NULL
) ON [STAGE];

