﻿CREATE TABLE [stg].[Process_FDM] (
    [ProcessCode]     CHAR (2)       NULL,
    [ProcessName]     VARCHAR (64)   NULL,
    [FK_ScenarioID]   SMALLINT       NULL,
    [ProcessCategory] CHAR (2)       NOT NULL,
    [Hash]            VARBINARY (64) NOT NULL,
    [SourceKey]       VARCHAR (128)  NULL
) ON [STAGE];

