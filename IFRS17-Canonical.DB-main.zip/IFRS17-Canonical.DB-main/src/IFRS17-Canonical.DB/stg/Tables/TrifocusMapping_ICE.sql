﻿CREATE TABLE [stg].[TrifocusMapping_ICE] (
    [TrifocusCode] VARCHAR (16)   NOT NULL,
    [Hash]         VARBINARY (64) NOT NULL,
    [SourceKey]    VARCHAR (128)  NULL,
    [RunID]        BIGINT         NOT NULL,
    [TrifocuSName] NVARCHAR (64)  NULL,
    [FocusGroup]   NVARCHAR (64)  NULL,
    [Division]     NVARCHAR (64)  NULL
) ON [STAGE];

