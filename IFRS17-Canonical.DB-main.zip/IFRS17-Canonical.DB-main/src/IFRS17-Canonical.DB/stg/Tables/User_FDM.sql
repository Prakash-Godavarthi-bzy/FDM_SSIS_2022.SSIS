﻿CREATE TABLE [stg].[User_FDM] (
    [User]      VARCHAR (12)   NOT NULL,
    [UserName]  VARCHAR (64)   NOT NULL,
    [Hash]      VARBINARY (64) NOT NULL,
    [SourceKey] VARCHAR (128)  NULL
) ON [STAGE];

