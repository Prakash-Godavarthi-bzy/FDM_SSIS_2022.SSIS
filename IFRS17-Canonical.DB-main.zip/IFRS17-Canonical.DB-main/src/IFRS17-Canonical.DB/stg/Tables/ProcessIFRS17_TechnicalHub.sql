﻿CREATE TABLE [stg].[ProcessIFRS17_TechnicalHub] (
    [ProcessCode]             VARCHAR (10)   NOT NULL,
    [ProcessName]             VARCHAR (32)   NULL,
    [ProcessLevel1]           VARCHAR (32)   NULL,
    [ProcessLevel2]           VARCHAR (32)   NULL,
    [ProcessLevel3]           VARCHAR (32)   NULL,
    [CurrentAccountingPeriod] INT            NULL,
    [Hash]                    VARBINARY (64) NOT NULL,
    [SourceKey]               VARCHAR (128)  NULL
) ON [STAGE];

