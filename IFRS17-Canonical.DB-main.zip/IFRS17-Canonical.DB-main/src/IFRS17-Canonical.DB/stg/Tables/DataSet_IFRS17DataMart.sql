﻿CREATE TABLE [stg].[DataSet_IFRS17DataMart] (
    [DataSet]      VARCHAR (64)   NULL,
    [SourceSystem] VARCHAR (32)   NULL,
    [GrossRI]      VARCHAR (16)   NULL,
    [Hash]         VARBINARY (64) NOT NULL,
    [SourceKey]    VARCHAR (128)  NULL
) ON [STAGE];

