﻿CREATE TABLE [stg].[UnitOfAccount_ICE] (
    [UnitOfAccount] VARCHAR (64)   NOT NULL,
    [Hash]          VARBINARY (64) NOT NULL,
    [SourceKey]     VARCHAR (128)  NULL
) ON [STAGE];

