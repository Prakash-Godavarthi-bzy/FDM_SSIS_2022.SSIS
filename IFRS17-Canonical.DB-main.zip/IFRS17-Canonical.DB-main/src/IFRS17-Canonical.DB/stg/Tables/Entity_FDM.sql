﻿CREATE TABLE [stg].[Entity_FDM] (
    [EntityCode]              VARCHAR (16)   NOT NULL,
    [EntityName]              NVARCHAR (64)  NOT NULL,
    [Platform]                VARCHAR (5)    NULL,
    [Status]                  CHAR (1)       NULL,
    [FK_FunctionalCurrencyID] BIGINT         NULL,
    [ExcludeFromFXCalcs]      BIT            NULL,
    [TargetEntityIdentifier]  BIT            NULL,
    [Hash]                    VARBINARY (64) NOT NULL,
    [SourceKey]               VARCHAR (128)  NULL
) ON [STAGE];

