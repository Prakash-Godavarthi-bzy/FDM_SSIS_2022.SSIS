﻿CREATE TABLE [stg].[ReportingCurrency_FDM] (
    [ReportingCurrencyCode] VARCHAR (16)   NOT NULL,
    [ReportingCurrencyName] VARCHAR (128)  NOT NULL,
    [Hash]                  VARBINARY (64) NOT NULL,
    [SourceKey]             VARCHAR (128)  NULL
) ON [STAGE];

