﻿CREATE TABLE [stg].[Account_FDM] (
    [AccountCode]        NVARCHAR (16)  NULL,
    [AccountName]        NVARCHAR (128) NULL,
    [AccountGroup]       NVARCHAR (128) NULL,
    [AccountIsMoney]     BIT            NULL,
    [AccountIsSnapshot]  BIT            NULL,
    [FormatString]       NVARCHAR (16)  NULL,
    [ExcludeFromFXCalcs] BIT            NULL,
    [Closed]             BIT            NULL,
    [Hash]               VARBINARY (64) NOT NULL,
    [SourceKey]          VARCHAR (128)  NULL
) ON [STAGE];

