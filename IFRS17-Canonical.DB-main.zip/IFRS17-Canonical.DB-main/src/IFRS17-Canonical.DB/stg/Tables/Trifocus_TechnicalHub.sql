﻿CREATE TABLE [stg].[Trifocus_TechnicalHub] (
    [TrifocusCode]   VARCHAR (16)   NOT NULL,
    [TriFocusName]   NVARCHAR (64)  NOT NULL,
    [TriFocusLevel1] NVARCHAR (64)  NULL,
    [TriFocusLevel2] NVARCHAR (64)  NULL,
    [TriFocusLevel3] NVARCHAR (64)  NULL,
    [Hash]           VARBINARY (64) NOT NULL,
    [SourceKey]      VARCHAR (128)  NULL
) ON [STAGE];

