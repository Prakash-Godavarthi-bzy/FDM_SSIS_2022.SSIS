﻿CREATE TABLE [stg].[SourceSystem_FDM] (
    [SourceSystem] VARCHAR (48)   NOT NULL,
    [Hash]         VARBINARY (64) NOT NULL,
    [SourceKey]    VARCHAR (128)  NULL
) ON [STAGE];

