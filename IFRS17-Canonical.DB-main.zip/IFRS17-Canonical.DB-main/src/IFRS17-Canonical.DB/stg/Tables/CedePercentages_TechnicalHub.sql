﻿CREATE TABLE [stg].[CedePercentages_TechnicalHub] (
    [YOA]             VARCHAR (16)    NULL,
    [SourceProgramme] VARCHAR (250)   NULL,
    [CedePercentage]  NUMERIC (19, 8) NULL,
    [EntityCode]      VARCHAR (50)    NULL,
    [Hash]            VARBINARY (64)  NOT NULL
) ON [STAGE];

