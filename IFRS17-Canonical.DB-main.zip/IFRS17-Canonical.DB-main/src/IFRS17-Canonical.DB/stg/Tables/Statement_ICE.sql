﻿CREATE TABLE [stg].[Statement_ICE] (
    [Statement] VARCHAR (16)   NOT NULL,
    [Hash]      VARBINARY (64) NOT NULL,
    [SourceKey] VARCHAR (128)  NULL
) ON [STAGE];

