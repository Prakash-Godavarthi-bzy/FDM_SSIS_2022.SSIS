﻿CREATE TABLE [stg].[YOA_FDM] (
    [YOA]       VARCHAR (8)    NULL,
    [Hash]      VARBINARY (64) NOT NULL,
    [SourceKey] VARCHAR (128)  NULL
) ON [STAGE];

