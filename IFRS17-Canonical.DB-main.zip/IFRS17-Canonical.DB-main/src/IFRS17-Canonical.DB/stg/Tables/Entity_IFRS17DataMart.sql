﻿CREATE TABLE [stg].[Entity_IFRS17DataMart] (
    [EntityCode]   VARCHAR (16)   NOT NULL,
    [EntityName]   NVARCHAR (64)  NOT NULL,
    [Platform]     VARCHAR (5)    NULL,
    [EntityLevel1] NVARCHAR (32)  NULL,
    [EntityLevel2] NVARCHAR (32)  NULL,
    [EntityLevel3] NVARCHAR (32)  NULL,
    [EntityLevel4] NVARCHAR (32)  NULL,
    [EntityLevel5] NVARCHAR (32)  NULL,
    [Hash]         VARBINARY (64) NOT NULL,
    [SourceKey]    VARCHAR (128)  NOT NULL
) ON [STAGE];

