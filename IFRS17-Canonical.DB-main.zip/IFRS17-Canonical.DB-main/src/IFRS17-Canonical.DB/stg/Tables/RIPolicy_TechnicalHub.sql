﻿CREATE TABLE [stg].[RIPolicy_TechnicalHub] (
    [SourceKey]        VARCHAR (128)  NULL,
    [RIPolicyTypeCode] VARCHAR (16)   NULL,
    [RIPolicyTypeName] VARCHAR (32)   NULL,
    [RIProgrammeCode]  VARCHAR (16)   NULL,
    [RIProgrammeName]  VARCHAR (64)   NULL,
    [Hash]             VARBINARY (64) NOT NULL,
    [RIPolicyNumber]   VARCHAR (128)  NULL
) ON [STAGE];



