﻿CREATE TABLE [stg].[Currency_TechnicalHub] (
    [CurrencyCode] CHAR (3)       NULL,
    [CurrencyName] VARCHAR (16)   NULL,
    [Hash]         VARBINARY (64) NOT NULL,
    [SourceKey]    VARCHAR (128)  NULL
) ON [STAGE];

