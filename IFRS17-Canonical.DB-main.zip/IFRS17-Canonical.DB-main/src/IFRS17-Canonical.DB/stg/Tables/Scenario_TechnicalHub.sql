﻿CREATE TABLE [stg].[Scenario_TechnicalHub] (
    [ScenarioCode] VARCHAR (16)   NOT NULL,
    [ScenarioName] VARCHAR (32)   NULL,
    [Hash]         VARBINARY (64) NOT NULL,
    [SourceKey]    VARCHAR (128)  NULL
) ON [STAGE];

