﻿
/*

Author:		Michael Sode
Date:		16 June 2022
Purpose:	Gives us some dimension precedence meta data as a starting point. Assumes [meta].[DimensionPrecedence] is an empty table
			The meta data should then be refined with consideration to how best source dimension attributes.
			This SP only considers the data sources known at the time of writing.

*/
CREATE PROCEDURE [meta].[usp_PopulateDimensionMeta]
AS
BEGIN

INSERT INTO [meta].[DimensionPrecedence]
(
[Dimension]
,[Column]
,[DataSource]
,[Precedence]
)
SELECT	[TABLE_NAME]
		,[COLUMN_NAME]
		,'FDM'
		,1
FROM	INFORMATION_SCHEMA.COLUMNS c
WHERE	c.TABLE_SCHEMA = 'dim'
AND		LEFT(c.COLUMN_NAME,3) <> 'PK_'
UNION
SELECT	[TABLE_NAME]
		,[COLUMN_NAME]
		,'IFRS17DataMart'
		,3
FROM	INFORMATION_SCHEMA.COLUMNS c
WHERE	c.TABLE_SCHEMA = 'dim'
AND		LEFT(c.COLUMN_NAME,3) <> 'PK_'
UNION
SELECT	[TABLE_NAME]
		,[COLUMN_NAME]
		,'TechnicalHub'
		,2
FROM	INFORMATION_SCHEMA.COLUMNS c
WHERE	c.TABLE_SCHEMA = 'dim'
AND		LEFT(c.COLUMN_NAME,3) <> 'PK_'
;


END