﻿INSERT [tmp].[FieldLabel2AccountMapping] ([FieldLabel], [Account]) VALUES (N'ADMIN_CASH', N'Admin Expense (premium related)')
GO
INSERT [tmp].[FieldLabel2AccountMapping] ([FieldLabel], [Account]) VALUES (N'BKG_BINDER', N'Brokerage Binder Adjusted')
GO
INSERT [tmp].[FieldLabel2AccountMapping] ([FieldLabel], [Account]) VALUES (N'BKG_CASH', N'Brokerage Cash')
GO
INSERT [tmp].[FieldLabel2AccountMapping] ([FieldLabel], [Account]) VALUES (N'BKG_NONBINDER', N'Brokerage Policy')
GO
INSERT [tmp].[FieldLabel2AccountMapping] ([FieldLabel], [Account]) VALUES (N'FSC_BKG', N'Brokerage_Future Service')
GO
INSERT [tmp].[FieldLabel2AccountMapping] ([FieldLabel], [Account]) VALUES (N'CHE_CASH', N'Claims Handling Expense')
GO
INSERT [tmp].[FieldLabel2AccountMapping] ([FieldLabel], [Account]) VALUES (N'ULT_PURE_LL', N'Claims Ultimate')
GO
INSERT [tmp].[FieldLabel2AccountMapping] ([FieldLabel], [Account]) VALUES (N'ULT_TEAM_LL', N'Claims Ultimate')
GO
INSERT [tmp].[FieldLabel2AccountMapping] ([FieldLabel], [Account]) VALUES (N'PREM_BINDER', N'Gross Premium Binder Adjusted')
GO
INSERT [tmp].[FieldLabel2AccountMapping] ([FieldLabel], [Account]) VALUES (N'PREM_BINDER_UNCAPPED', N'Gross Premium Binder Adjusted')
GO
INSERT [tmp].[FieldLabel2AccountMapping] ([FieldLabel], [Account]) VALUES (N'PREM_CASH', N'Gross Premium Cash')
GO
INSERT [tmp].[FieldLabel2AccountMapping] ([FieldLabel], [Account]) VALUES (N'PREM_NONBINDER', N'Gross Premium Policy')
GO
INSERT [tmp].[FieldLabel2AccountMapping] ([FieldLabel], [Account]) VALUES (N'PREM_TEAM', N'Gross Premium Ultimate Policy')
GO
INSERT [tmp].[FieldLabel2AccountMapping] ([FieldLabel], [Account]) VALUES (N'FSC_PREM', N'Gross Premium_Future Service')
GO
INSERT [tmp].[FieldLabel2AccountMapping] ([FieldLabel], [Account]) VALUES (N'OAE_CASH', N'Other Acquisition Expense')
GO
INSERT [tmp].[FieldLabel2AccountMapping] ([FieldLabel], [Account]) VALUES (N'PAID_ATT', N'Paid Claims')
GO
INSERT [tmp].[FieldLabel2AccountMapping] ([FieldLabel], [Account]) VALUES (N'PAID_LL', N'Paid Claims')
GO
INSERT [tmp].[FieldLabel2AccountMapping] ([FieldLabel], [Account]) VALUES (N'PC_CASH', N'Profit Commission Cash')
GO
INSERT [tmp].[FieldLabel2AccountMapping] ([FieldLabel], [Account]) VALUES (N'RIP_CASH', N'Reinstatement Premium Cash')
GO
INSERT [tmp].[FieldLabel2AccountMapping] ([FieldLabel], [Account]) VALUES (N'RIP_NONBINDER', N'Reinstatement Premium Policy')
GO
INSERT [tmp].[FieldLabel2AccountMapping] ([FieldLabel], [Account]) VALUES (N'FSC_RIP', N'Reinstatement Premium_Future Service')
GO
