﻿CREATE SCHEMA [fact]
    AUTHORIZATION [dbo];

























