﻿CREATE SCHEMA [meta]
    AUTHORIZATION [dbo];











GO
