﻿CREATE SCHEMA [stg]
    AUTHORIZATION [dbo];















