﻿CREATE SCHEMA [dim]
    AUTHORIZATION [dbo];





















