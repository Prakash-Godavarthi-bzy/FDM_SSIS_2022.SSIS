﻿CREATE   PROCEDURE [dbo].[usp_InsertFDMGroupSharePercentages] 
(
	@Entity VARCHAR(16),
	@YOA varchar(16),
	@GroupSharePercentage [numeric](38, 10)
)
AS 
BEGIN
		INSERT INTO Dim.FDMGroupShare
		SELECT	(	SELECT	 PK_EntityID
					FROM	DIM.DimEntity
					WHERE	EntityCode = @Entity
				) Fk_EntityID 
				,FK_YOAID
				,YOA
				,@GroupSharePercentage
				FROM (
					SELECT	PK_YOAID AS FK_YOAID,
							YOA
					FROM	Dim.YOA
					WHERE	FK_DataSourceID = 1 AND YOA = @YOA 
				) A
END