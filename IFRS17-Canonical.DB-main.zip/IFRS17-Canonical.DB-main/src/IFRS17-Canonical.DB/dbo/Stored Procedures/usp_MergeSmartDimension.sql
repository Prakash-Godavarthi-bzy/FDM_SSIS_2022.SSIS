﻿


/*

Author:		Michael Sode
Date:		20 Sep 2022
Purpose:	Merges a smart keyed dimension between the [dim] schema and [stg] schema.

*/
CREATE PROCEDURE [dbo].[usp_MergeSmartDimension] @Dimension SYSNAME, @DataSource VARCHAR(128), @ExecutionInstanceGUID VARCHAR(128)
AS
BEGIN

-- Log our Dimension merge
INSERT INTO [meta].[LogDimensions]
(
	[Dimension]
	,[DataSource]
	,[ExecutionInstanceGUID]
)
VALUES (@Dimension, @DataSource, @ExecutionInstanceGUID)


SET NOCOUNT ON;

DECLARE @sql NVARCHAR(MAX);

DECLARE @Column AS SYSNAME =	(
								SELECT	c.[COLUMN_NAME]
								FROM	[INFORMATION_SCHEMA].[COLUMNS] c
								WHERE	c.[TABLE_NAME] = @Dimension + '_' + @DataSource
								AND		c.[TABLE_SCHEMA] = 'stg'
								);

-- PRINT @Column + char(10);

-- Build a MERGE statement
SET @sql = '
MERGE	[dim].[' + @Dimension + '] AS Target
USING	[stg].[' + @Dimension + '_' + @DataSource + '] AS Source
ON		Source.[' + @Column + '] = Target.[' + @Column + ']
WHEN NOT MATCHED BY TARGET THEN
INSERT ([' + @Column + '])
VALUES ([Source].[' + @Column + ']);' + CHAR(10);

-- PRINT @sql;

EXEC sp_executesql @sql;

RETURN 0;

END