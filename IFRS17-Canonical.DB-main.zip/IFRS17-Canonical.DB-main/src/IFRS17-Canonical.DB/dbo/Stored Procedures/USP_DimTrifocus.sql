﻿CREATE PROCEDURE [dbo].[USP_DimTrifocus]
AS
BEGIN
MERGE  [DIM].[DimTrifocus] AS TARGET
USING	(
SELECT 
		MIN([PK_TrifocusID])  AS PK_TriFocusID
		,CASE
			WHEN LTRIM(RTRIM([TrifocusCode])) = 'UNK' THEN 'Unk'
			WHEN LTRIM(RTRIM([TrifocusCode])) = 'UNKNOWN' THEN 'Unknown'
			ELSE LTRIM(RTRIM([TrifocusCode]))
		 END AS TrifocusCode
		,MAX(LTRIM(RTRIM([TriFocusName]		)))	AS TrifocusName
		,MAX(LTRIM(RTRIM([TriFocusLevel1]	)))	AS TrifocusLevel1
		,MAX(LTRIM(RTRIM([TriFocusLevel2]	)))	AS TrifocusLevel2
		,MAX(LTRIM(RTRIM([TriFocusLevel3]	)))	AS TrifocusLevel3
		,MAX(LTRIM(RTRIM([TrifocusGroup]	)))	AS TrifocusGroup
		,MAX(CAST([IsUSTrifocus]	AS INT)	)	AS [IsUSTrifocus]
		,MAX(CAST([IsKrReTrifocus] AS INT)	)	AS [IsKrReTrifocus]
		,MAX(CAST([IsUSSyndTrifocus]  AS INT)	) AS [IsUSSyndTrifocus]
		,MAX(CAST([IsSLInternational] AS INT))	AS [IsSLInternational]
		,MAX([status]			)	AS [Status]
		,MAX([TrifocusTypeCode]	) AS [TrifocusTypeCode]
		,MAX([TrifocusTypeDesc]	) AS [TrifocusTypeDesc]
FROM DIM.Trifocus
GROUP BY TrifocusCode) AS SOURCE
ON		TARGET.TrifocusCode = SOURCE.TrifocusCode
WHEN NOT MATCHED BY TARGET THEN
		INSERT	([PK_TrifocusID]
      ,[TrifocusCode]
      ,[TriFocusName]
      ,[TriFocusLevel1]
      ,[TriFocusLevel2]
      ,[TriFocusLevel3]
      ,[TrifocusGroup]
      ,[IsUSTrifocus]
      ,[IsKrReTrifocus]
      ,[IsUSSyndTrifocus]
      ,[IsSLInternational]
      ,[status]
      ,[TrifocusTypeCode]
      ,[TrifocusTypeDesc]) 
		VALUES (   SOURCE.[PK_TrifocusID]
				  ,SOURCE.[TrifocusCode]
				  ,SOURCE.[TriFocusName]
				  ,SOURCE.[TriFocusLevel1]
				  ,SOURCE.[TriFocusLevel2]
				  ,SOURCE.[TriFocusLevel3]
				  ,SOURCE.[TrifocusGroup]
				  ,SOURCE.[IsUSTrifocus]
				  ,SOURCE.[IsKrReTrifocus]
				  ,SOURCE.[IsUSSyndTrifocus]
				  ,SOURCE.[IsSLInternational]
				  ,SOURCE.[status]
				  ,SOURCE.[TrifocusTypeCode]
				  ,SOURCE.[TrifocusTypeDesc]
				)
WHEN MATCHED THEN UPDATE  SET
	TARGET.[TriFocusName] = SOURCE.[TriFocusName]
	,TARGET.[TriFocusLevel1] = SOURCE.[TriFocusLevel1]
	,TARGET.[TriFocusLevel2] = SOURCE.[TriFocusLevel2]
	,TARGET.[TriFocusLevel3] = SOURCE.[TriFocusLevel3]
	,TARGET.[TrifocusGroup] = SOURCE.[TrifocusGroup]
	,TARGET.[IsUSTrifocus] = SOURCE.[IsUSTrifocus]
	,TARGET.[IsKrReTrifocus] = SOURCE.[IsKrReTrifocus]
	,TARGET.[IsUSSyndTrifocus] = SOURCE.[IsUSSyndTrifocus]
	,TARGET.[IsSLInternational] = SOURCE.[IsSLInternational]
	,TARGET.[status] = SOURCE.[status]
	,TARGET.[TrifocusTypeCode] = SOURCE.[TrifocusTypeCode]
	,TARGET.[TrifocusTypeDesc] = SOURCE.[TrifocusTypeDesc];
END