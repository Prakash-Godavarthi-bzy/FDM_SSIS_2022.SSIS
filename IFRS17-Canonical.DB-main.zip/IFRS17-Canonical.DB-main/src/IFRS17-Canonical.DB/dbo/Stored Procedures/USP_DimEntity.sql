﻿CREATE PROCEDURE [dbo].[USP_DimEntity]
AS
BEGIN
MERGE [dim].[DimEntity] AS TARGET
USING (
SELECT min(LTRIM(RTRIM([PK_EntityID]))) PK_EntityID
      ,LTRIM(RTRIM([EntityCode])) EntityCode
      ,max(LTRIM(RTRIM([EntityName]))) EntityName
      ,max(LTRIM(RTRIM([Platform]))) [Platform]
      ,max(LTRIM(RTRIM([EntityLevel1]))) EntityLevel1
      ,max(LTRIM(RTRIM([EntityLevel2]))) EntityLevel2
      ,max(LTRIM(RTRIM([EntityLevel3]))) EntityLevel3
      ,max(LTRIM(RTRIM([EntityLevel4]))) EntityLevel4
      ,max(LTRIM(RTRIM([EntityLevel5]))) EntityLevel5
      ,max(LTRIM(RTRIM([Status]))) [Status]
      ,max(LTRIM(RTRIM([FK_FunctionalCurrencyID]))) FK_FunctionalCurrencyID
      ,max(cast(LTRIM(RTRIM([ExcludeFromFXCalcs])) as int)) ExcludeFromFXCalcs
      ,max(cast(LTRIM(RTRIM([TargetEntityIdentifier])) as int)) [TargetEntityIdentifier]
  FROM [dim].[Entity]
  group by EntityCode ) AS SOURCE
ON TARGET.EntityCode = SOURCE.EntityCode
WHEN NOT MATCHED BY TARGET THEN
INSERT ([PK_EntityID]
      ,[EntityCode]
      ,[EntityName]
      ,[Platform]
      ,[EntityLevel1]
      ,[EntityLevel2]
      ,[EntityLevel3]
      ,[EntityLevel4]
      ,[EntityLevel5]
      ,[Status]
      ,[FK_FunctionalCurrencyID]
      ,[ExcludeFromFXCalcs]
      ,[TargetEntityIdentifier])
	  VALUES (SOURCE.[PK_EntityID]
      ,SOURCE.[EntityCode]
      ,SOURCE.[EntityName]
      ,SOURCE.[Platform]
      ,SOURCE.[EntityLevel1]
      ,SOURCE.[EntityLevel2]
      ,SOURCE.[EntityLevel3]
      ,SOURCE.[EntityLevel4]
      ,SOURCE.[EntityLevel5]
      ,SOURCE.[Status]
      ,SOURCE.[FK_FunctionalCurrencyID]
      ,SOURCE.[ExcludeFromFXCalcs]
      ,SOURCE.[TargetEntityIdentifier]
	  )
WHEN MATCHED THEN UPDATE  SET
	TARGET.[EntityName] = SOURCE.[EntityName]
     ,TARGET.[Platform] = SOURCE.[Platform]
     ,TARGET.[EntityLevel1] = SOURCE.[EntityLevel1]
     ,TARGET.[EntityLevel2] = SOURCE.[EntityLevel2]
     ,TARGET.[EntityLevel3] = SOURCE.[EntityLevel3]
     ,TARGET.[EntityLevel4] = SOURCE.[EntityLevel4]
     ,TARGET.[EntityLevel5] = SOURCE.[EntityLevel5]
     ,TARGET.[Status] = SOURCE.[Status]
     ,TARGET.[FK_FunctionalCurrencyID] = SOURCE.[FK_FunctionalCurrencyID]
     ,TARGET.[ExcludeFromFXCalcs] = SOURCE.[ExcludeFromFXCalcs]
     ,TARGET.[TargetEntityIdentifier] = SOURCE.[TargetEntityIdentifier];
END