﻿CREATE PROCEDURE [dbo].[USP_DimCurrency]
AS
BEGIN
MERGE [dim].[DimCurrency] AS TARGET
USING (
SELECT  MIN(LTRIM(RTRIM([PK_CurrencyID]))) AS [PK_CurrencyID]
      ,LTRIM(RTRIM([CurrencyCode])) CurrencyCode
      ,MAX(LTRIM(RTRIM([CurrencyName]))) AS [CurrencyName]
  FROM [dim].[Currency]
  GROUP BY CurrencyCode	) AS SOURCE
  ON  TARGET.CurrencyCode = SOURCE.CurrencyCode
WHEN NOT MATCHED BY TARGET THEN
INSERT ([PK_CurrencyID]
      ,[CurrencyCode]
      ,[CurrencyName])
	  VALUES(SOURCE.[PK_CurrencyID]
      ,SOURCE.[CurrencyCode]
      ,SOURCE.[CurrencyName])
WHEN MATCHED THEN UPDATE  SET
TARGET.[CurrencyName] = SOURCE.[CurrencyName];
END
