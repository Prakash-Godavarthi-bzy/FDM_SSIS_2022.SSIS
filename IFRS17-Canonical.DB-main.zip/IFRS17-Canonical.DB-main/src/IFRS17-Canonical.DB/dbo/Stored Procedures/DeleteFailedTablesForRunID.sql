﻿CREATE PROCEDURE [dbo].[DeleteFailedTablesForRunID]
    @pk_MasterRunID INT  
AS
BEGIN

  IF EXISTS (
    SELECT *
    FROM meta.MasterRunLogs
    WHERE  Pk_MasterRunID = @pk_MasterRunID AND Status = 'Failed'
  )
  BEGIN
    SET NOCOUNT ON;

    DECLARE @BatchSize INT = 100000;
    DECLARE @TableName NVARCHAR(255);
    DECLARE @SQL NVARCHAR(MAX);  
    DECLARE @RunID INT;

    CREATE TABLE #FailedTables (
      TableName NVARCHAR(255)
      ,RunID int
    );


    INSERT INTO #FailedTables (RunID,TableName)
    SELECT RunID,PackageName
    FROM meta.ChildRunLogs
    WHERE Status = 'Failed' and Fk_MasterRunID = @pk_MasterRunID;

    WHILE EXISTS (SELECT 1 FROM #FailedTables)
    BEGIN

      SELECT TOP 1 @TableName = TableName, @RunID = RunID
      FROM #FailedTables;
		

      SET @SQL = 'DECLARE @RowCount INT = 1;
      WHILE @RowCount > 0
      BEGIN
        DELETE TOP ('+CAST(@BatchSize AS NVARCHAR)+') f
        FROM  '+@TableName+' f
        JOIN  dim.Run dr
        ON    dr.PK_RunID = FK_RunID
        WHERE  dr.RunID = '+CAST(@RunID AS NVARCHAR)+';
        SET @RowCount = @@ROWCOUNT;
      END';
      --PRINT @SQL;
      EXEC sp_executesql @SQL;

      DELETE FROM #FailedTables WHERE TableName = @TableName AND RunID = @RunID;
    END

    DROP TABLE #FailedTables;
  END
END