﻿

/*

Author:		Michael Sode
Date:		16 Jun 2022
Purpose:	Merges a dimension between the [dim] schema and [stg] schema based on defined precedence rules.
			The resulting merged dimension will always look the same regardless of the order in which data sources are loaded.
			This ensures that we properly support different load schedules for different data sources.
TODO:		Consider multiple runs. Will need to reference the DateTime of the contribution.
TODO:		Need to cater for smart keyed dimensions

*/
CREATE PROCEDURE [dbo].[usp_MergeDimension] @Dimension SYSNAME, @DataSource VARCHAR(128), @ExecutionInstanceGUID VARCHAR(128),@KeyAttribute VARCHAR(128)
AS
BEGIN

/*
-- TODO: Remove
DECLARE @Dimension SYSNAME = 'Currency';
DECLARE @KeyAttribute SYSNAME = 'CurrencyCode';
DECLARE @DataSource VARCHAR(128) = 'TechnicalHub';
DECLARE @ExecutionInstanceGUID VARCHAR(128) = 'xxxxx';
*/

-- Log our Dimension merge
INSERT INTO [meta].[LogDimensions]
(
	[Dimension]
	,[DataSource]
	,[ExecutionInstanceGUID]
)
VALUES (@Dimension, @DataSource, @ExecutionInstanceGUID)


SET NOCOUNT ON;

DECLARE @sql NVARCHAR(MAX);
DECLARE @DataSourceID TINYINT = (SELECT [PK_DataSourceID] FROM [dim].[DataSource] d WHERE d.[DataSource] = @DataSource);

DECLARE @SerialColumns AS VARCHAR(MAX) =	'[' + (
											SELECT	STRING_AGG(c.[COLUMN_NAME], '], [') AS Result
											FROM	[INFORMATION_SCHEMA].[COLUMNS] c
											WHERE	c.[TABLE_NAME] = @Dimension + '_' + @DataSource
											AND		c.[TABLE_SCHEMA] = 'stg'
											AND		c.[COLUMN_NAME] NOT LIKE('PK_%')
											) + ']';

-- PRINT @SerialColumns + char(10);

DECLARE @SerialColumnsUpdate AS VARCHAR(MAX) =	(
											SELECT	STRING_AGG('Target.[' + c.[COLUMN_NAME] + '] = Source.[' + c.[COLUMN_NAME] + ']' + CHAR(10), '		,') AS Result
											FROM	[INFORMATION_SCHEMA].[COLUMNS] c
											WHERE	c.[TABLE_NAME] = @Dimension + '_' + @DataSource
											AND		c.[TABLE_SCHEMA] = 'stg'
											AND		c.[COLUMN_NAME] NOT LIKE('PK_%')
											AND		C.COLUMN_NAME <> @KeyAttribute
											);

-- PRINT @SerialColumnsUpdate + char(10);

-- Build a MERGE statement
SET @sql = '
MERGE	[dim].[' + @Dimension + '] AS Target
USING	[stg].[' + @Dimension + '_' + @DataSource + '] AS Source
ON		' + CAST(@DataSourceID AS VARCHAR) + ' = Target.[FK_DataSourceID]
AND		ISNULL(Source.['+@KeyAttribute+'],''Unknown'') = ISNULL(Target.['+@KeyAttribute+'],''Unknown'')
WHEN NOT MATCHED BY TARGET THEN
INSERT ([FK_DataSourceID], ' + @SerialColumns + ')
VALUES (' + CAST(@DataSourceID AS VARCHAR) + ', ' + @SerialColumns + ')
WHEN MATCHED AND FK_DataSourceID = '+CAST(@DataSourceID AS VARCHAR)+' THEN UPDATE SET
		' + @SerialColumnsUpdate + ';' + CHAR(10);

PRINT @sql;

EXEC sp_executesql @sql;

RETURN 0;

END
