﻿CREATE TABLE [fact].[Agg_IFRS17PsicleData_Reporting_LIC_DiscountedData] (
    [FK_RunID]             BIGINT           NOT NULL,
    [FK_EntityID]          BIGINT           NOT NULL,
    [FK_TrifocusID]        BIGINT           NOT NULL,
    [FK_RIPolicyID]        INT              NULL,
    [RIFlag]               CHAR (1)         NOT NULL,
    [FK_YOAID]             SMALLINT         NULL,
    [YOI]                  SMALLINT         NULL,
    [FK_CCYSettlementID]   BIGINT           NOT NULL,
    [FK_StatementID]       SMALLINT         NOT NULL,
    [FK_BalanceID]         SMALLINT         NOT NULL,
    [FK_PositionID]        SMALLINT         NOT NULL,
    [Amount]               NUMERIC (38, 10) NULL,
    [Amount_disc]          NUMERIC (38, 10) NULL,
    [Conv_Amount]          NUMERIC (38, 10) NULL,
    [Conv_Amount_disc]     NUMERIC (38, 10) NULL,
    [FK_TrifocusMappingID] BIGINT           NULL,
    [InceptedStatus]       CHAR (1)         NULL
);




GO
CREATE COLUMNSTORE INDEX [NCI_Agg_LIC_DiscountedData_FK_EntityID_FK_YOAID]
    ON [fact].[Agg_IFRS17PsicleData_Reporting_LIC_DiscountedData]([FK_EntityID], [FK_YOAID]) WITH (DROP_EXISTING = OFF);

