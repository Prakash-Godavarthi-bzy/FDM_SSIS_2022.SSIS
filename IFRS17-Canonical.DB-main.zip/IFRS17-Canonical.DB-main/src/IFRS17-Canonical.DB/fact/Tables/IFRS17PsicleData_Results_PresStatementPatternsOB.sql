﻿CREATE TABLE [fact].[IFRS17PsicleData_Results_PresStatementPatternsOB] (
    [FK_RunID]            BIGINT           NULL,
    [FK_EntityID]         BIGINT           NOT NULL,
    [FK_TrifocusID]       BIGINT           NOT NULL,
    [FK_TrifocusIFRS17ID] BIGINT           NULL,
    [FK_RIPolicyID]       INT              NULL,
    [FK_CCYSettlementID]  BIGINT           NOT NULL,
    [RIFlag]              CHAR (1)         NOT NULL,
    [YOI]                 SMALLINT         NULL,
    [QOIEndDate]          DATE             NOT NULL,
    [Amount]              NUMERIC (38, 10) NULL,
    [FK_AccountICEID]     SMALLINT         NULL,
    [Hash]                VARBINARY (64)   NOT NULL,
    [SourceKey]           BIGINT           NOT NULL,
    [Programme]           VARCHAR (128)    NULL,
    [FXRate]              NUMERIC (28, 8)  NULL,
    [Calc_FXRateAmount]   NUMERIC (38, 6)  NULL,
    CONSTRAINT [FK_IFRS17PsicleData_Results_PresStatementPatternsOB_AccountICEID] FOREIGN KEY ([FK_AccountICEID]) REFERENCES [dim].[AccountICE] ([PK_AccountICEID]),
    CONSTRAINT [FK_IFRS17PsicleData_Results_PresStatementPatternsOB_CCYSettlementID] FOREIGN KEY ([FK_CCYSettlementID]) REFERENCES [dim].[Currency] ([PK_CurrencyID]),
    CONSTRAINT [FK_IFRS17PsicleData_Results_PresStatementPatternsOB_EntityID] FOREIGN KEY ([FK_EntityID]) REFERENCES [dim].[Entity] ([PK_EntityID]),
    CONSTRAINT [FK_IFRS17PsicleData_Results_PresStatementPatternsOB_RIPolicyID] FOREIGN KEY ([FK_RIPolicyID]) REFERENCES [dim].[RIPolicy] ([PK_RIPolicyID]),
    CONSTRAINT [FK_IFRS17PsicleData_Results_PresStatementPatternsOB_Run] FOREIGN KEY ([FK_RunID]) REFERENCES [dim].[Run] ([PK_RunID]),
    CONSTRAINT [FK_IFRS17PsicleData_Results_PresStatementPatternsOB_TrifocusID] FOREIGN KEY ([FK_TrifocusID]) REFERENCES [dim].[Trifocus] ([PK_TrifocusID]),
    CONSTRAINT [FK_IFRS17PsicleData_Results_PresStatementPatternsOB_TrifocusIFRS17ID] FOREIGN KEY ([FK_TrifocusIFRS17ID]) REFERENCES [dim].[Trifocus] ([PK_TrifocusID])
) ON [INDEXES];








GO
CREATE CLUSTERED COLUMNSTORE INDEX [CCI_IFRS17PsicleData_Results_PresStatementPatternsOB]
    ON [fact].[IFRS17PsicleData_Results_PresStatementPatternsOB] WITH (DROP_EXISTING = OFF)
    ON [INDEXES];




GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Settlement Currency', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17PsicleData_Results_PresStatementPatternsOB', @level2type = N'COLUMN', @level2name = N'FK_CCYSettlementID';


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Trifocus IFRS17', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17PsicleData_Results_PresStatementPatternsOB', @level2type = N'COLUMN', @level2name = N'FK_TrifocusIFRS17ID';


GO
EXECUTE sp_addextendedproperty @name = N'source_table', @value = N'PresStatementPatternsOB', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17PsicleData_Results_PresStatementPatternsOB';


GO
EXECUTE sp_addextendedproperty @name = N'source_schema', @value = N'Results', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17PsicleData_Results_PresStatementPatternsOB';


GO
EXECUTE sp_addextendedproperty @name = N'source_catalogue', @value = N'IFRS17PsicleData', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17PsicleData_Results_PresStatementPatternsOB';


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'ICE CSM', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17PsicleData_Results_PresStatementPatternsOB';


GO
EXECUTE sp_addextendedproperty @name = N'dictionary', @value = N'N/A', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17PsicleData_Results_PresStatementPatternsOB';


GO
EXECUTE sp_addextendedproperty @name = N'definition', @value = N'ICE Pre-Statement Patterns OB fact table', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17PsicleData_Results_PresStatementPatternsOB';


GO
EXECUTE sp_addextendedproperty @name = N'canonical', @value = N'N/A', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17PsicleData_Results_PresStatementPatternsOB';


GO
CREATE NONCLUSTERED INDEX [NCI_Fact_IFRS17PsicleData_Results_PresStatementPatternsOB_Fk_RunID_Fk_EntityID_FK_TrifocusID_YOI]
    ON [fact].[IFRS17PsicleData_Results_PresStatementPatternsOB]([FK_RunID] ASC, [FK_EntityID] ASC, [FK_TrifocusID] ASC, [FK_TrifocusIFRS17ID] ASC, [FK_CCYSettlementID] ASC, [RIFlag] ASC, [YOI] ASC)
    INCLUDE([QOIEndDate], [Amount]) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];

