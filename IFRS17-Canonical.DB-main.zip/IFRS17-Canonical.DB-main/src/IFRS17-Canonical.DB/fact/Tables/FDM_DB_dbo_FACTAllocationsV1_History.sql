CREATE TABLE [fact].[FDM_DB_dbo_FACTAllocationsV1_History] (
    [FK_AccountID]           SMALLINT         NOT NULL,
    [FK_AccountingPeriodID]  INT              NOT NULL,
    [FK_DataStageID]         BIGINT           NOT NULL,
    [FK_EntityID]            BIGINT           NOT NULL,
    [FK_CCYOriginalID]       BIGINT           NULL,
    [FK_CCYSettlementID]     BIGINT           NULL,
    [FK_PolicySectionID]     BIGINT           NULL,
    [FK_ProcessID]           SMALLINT         NOT NULL,
    [FK_ScenarioID]          SMALLINT         NOT NULL,
    [FK_SourceSystemID]      SMALLINT         NOT NULL,
    [FK_TrifocusID]          BIGINT           NOT NULL,
    [FK_YOAID]               SMALLINT         NULL,
    [FK_UserID]              SMALLINT         NOT NULL,
    [FK_RIPolicyID]          INT              NOT NULL,
    [Value]                  NUMERIC (35, 10) NULL,
    [cur_amount]             NUMERIC (35, 10) NULL,
    [value_1]                NUMERIC (35, 10) NULL,
    [value_2]                NUMERIC (35, 10) NULL,
    [value_3]                NUMERIC (35, 10) NULL,
    [Hash]                   VARBINARY (64)   NOT NULL,
    [SourceKey]              BIGINT           NOT NULL,
    [Fk_ConformedEntityID]   INT              NULL,
    [Fk_ConformedTrifocusID] INT              NULL,
    [Dataset]                VARCHAR (256)    NULL,
    [FK_BatchID]             INT              NULL,
    CONSTRAINT [FK_FDM_DB_dbo_FACTAllocationsV1_History_AccountID] FOREIGN KEY ([FK_AccountID]) REFERENCES [dim].[Account] ([PK_AccountID]),
    CONSTRAINT [FK_FDM_DB_dbo_FACTAllocationsV1_History_AccountingPeriodID] FOREIGN KEY ([FK_AccountingPeriodID]) REFERENCES [dim].[AccountingPeriod] ([PK_AccountingPeriodID]),
    CONSTRAINT [FK_FDM_DB_dbo_FACTAllocationsV1_History_CCYOriginalID] FOREIGN KEY ([FK_CCYOriginalID]) REFERENCES [dim].[Currency] ([PK_CurrencyID]),
    CONSTRAINT [FK_FDM_DB_dbo_FACTAllocationsV1_History_CCYSettlementID] FOREIGN KEY ([FK_CCYSettlementID]) REFERENCES [dim].[Currency] ([PK_CurrencyID]),
    CONSTRAINT [FK_FDM_DB_dbo_FACTAllocationsV1_History_DataStageID] FOREIGN KEY ([FK_DataStageID]) REFERENCES [dim].[DataStage] ([PK_DataStageID]),
    CONSTRAINT [FK_FDM_DB_dbo_FACTAllocationsV1_History_EntityID] FOREIGN KEY ([FK_EntityID]) REFERENCES [dim].[Entity] ([PK_EntityID]),
    CONSTRAINT [FK_FDM_DB_dbo_FACTAllocationsV1_History_PolicySectionID] FOREIGN KEY ([FK_PolicySectionID]) REFERENCES [dim].[PolicySection] ([PK_PolicySectionID]),
    CONSTRAINT [FK_FDM_DB_dbo_FACTAllocationsV1_History_ProcessID] FOREIGN KEY ([FK_ProcessID]) REFERENCES [dim].[Process] ([PK_ProcessID]),
    CONSTRAINT [FK_FDM_DB_dbo_FACTAllocationsV1_History_RIPolicyID] FOREIGN KEY ([FK_RIPolicyID]) REFERENCES [dim].[RIPolicy] ([PK_RIPolicyID]),
    CONSTRAINT [FK_FDM_DB_dbo_FACTAllocationsV1_History_ScenarioID] FOREIGN KEY ([FK_ScenarioID]) REFERENCES [dim].[Scenario] ([PK_ScenarioID]),
    CONSTRAINT [FK_FDM_DB_dbo_FACTAllocationsV1_History_SourceSystemID] FOREIGN KEY ([FK_SourceSystemID]) REFERENCES [dim].[SourceSystem] ([PK_SourceSystemID]),
    CONSTRAINT [FK_FDM_DB_dbo_FACTAllocationsV1_History_TrifocusID] FOREIGN KEY ([FK_TrifocusID]) REFERENCES [dim].[Trifocus] ([PK_TrifocusID]),
    CONSTRAINT [FK_FDM_DB_dbo_FACTAllocationsV1_History_UserID] FOREIGN KEY ([FK_UserID]) REFERENCES [dim].[User] ([PK_UserID]),
    CONSTRAINT [FK_FDM_DB_dbo_FACTAllocationsV1_History_YOAID] FOREIGN KEY ([FK_YOAID]) REFERENCES [dim].[YOA] ([PK_YOAID])
) ON [INDEXES];












GO
CREATE CLUSTERED COLUMNSTORE INDEX [CCI_FDM_DB_dbo_FACTAllocationsV1_History]
    ON [fact].[FDM_DB_dbo_FACTAllocationsV1_History]
    ON [INDEXES];










GO
CREATE NONCLUSTERED INDEX [NCI_FACTAllocationsV1_History_SourceKey_Hash_BatchID]
    ON [fact].[FDM_DB_dbo_FACTAllocationsV1_History]([SourceKey] ASC, [Hash] ASC)
    INCLUDE([FK_BatchID]) WITH (FILLFACTOR = 90)
    ON [INDEXES];

