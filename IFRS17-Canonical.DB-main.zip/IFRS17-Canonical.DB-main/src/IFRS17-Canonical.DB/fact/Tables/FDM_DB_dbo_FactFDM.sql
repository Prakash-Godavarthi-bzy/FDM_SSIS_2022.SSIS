CREATE TABLE [fact].[FDM_DB_dbo_FactFDM] (
    [FK_EntityID]            BIGINT           NOT NULL,
    [FK_TrifocusID]          BIGINT           NOT NULL,
    [FK_CCYOriginalID]       BIGINT           NULL,
    [FK_CCYSettlementID]     BIGINT           NULL,
    [FK_DataStageID]         BIGINT           NOT NULL,
    [FK_PolicySectionID]     BIGINT           NULL,
    [FK_ScenarioID]          SMALLINT         NOT NULL,
    [FK_SourceSystemID]      SMALLINT         NOT NULL,
    [FK_ProcessID]           SMALLINT         NOT NULL,
    [FK_UserID]              SMALLINT         NOT NULL,
    [FK_AccountID]           SMALLINT         NOT NULL,
    [FK_YOAID]               SMALLINT         NULL,
    [FK_AccountingPeriodID]  INT              NULL,
    [FK_RIPolicyID]          INT              NOT NULL,
    [Cur_Amount]             NUMERIC (38, 10) NULL,
    [Value]                  NUMERIC (38, 10) NULL,
    [Value_1]                NUMERIC (38, 10) NULL,
    [Value_2]                NUMERIC (38, 10) NULL,
    [Value_3]                NUMERIC (38, 10) NULL,
    [Hash]                   VARBINARY (64)   NOT NULL,
    [SourceKey]              BIGINT           NULL,
    [Fk_ConformedEntityID]   INT              NULL,
    [Fk_ConformedTrifocusID] INT              NULL,
    [GroupShareValue]        NUMERIC (38, 10) NULL,
    [Dataset]                VARCHAR (256)    NULL,
    [Bk_TransactionID]       BIGINT           NULL,
    CONSTRAINT [FK_FDM_DB_dbo_FactFDM_AccountID] FOREIGN KEY ([FK_AccountID]) REFERENCES [dim].[Account] ([PK_AccountID]),
    CONSTRAINT [FK_FDM_DB_dbo_FactFDM_AccountingPeriodID] FOREIGN KEY ([FK_AccountingPeriodID]) REFERENCES [dim].[AccountingPeriod] ([PK_AccountingPeriodID]),
    CONSTRAINT [FK_FDM_DB_dbo_FactFDM_CCYOriginalID] FOREIGN KEY ([FK_CCYOriginalID]) REFERENCES [dim].[Currency] ([PK_CurrencyID]),
    CONSTRAINT [FK_FDM_DB_dbo_FactFDM_CCYSettlementID] FOREIGN KEY ([FK_CCYSettlementID]) REFERENCES [dim].[Currency] ([PK_CurrencyID]),
    CONSTRAINT [FK_FDM_DB_dbo_FactFDM_DataStageID] FOREIGN KEY ([FK_DataStageID]) REFERENCES [dim].[DataStage] ([PK_DataStageID]),
    CONSTRAINT [FK_FDM_DB_dbo_FactFDM_EntityID] FOREIGN KEY ([FK_EntityID]) REFERENCES [dim].[Entity] ([PK_EntityID]),
    CONSTRAINT [FK_FDM_DB_dbo_FactFDM_PolicySectionID] FOREIGN KEY ([FK_PolicySectionID]) REFERENCES [dim].[PolicySection] ([PK_PolicySectionID]),
    CONSTRAINT [FK_FDM_DB_dbo_FactFDM_ProcessID] FOREIGN KEY ([FK_ProcessID]) REFERENCES [dim].[Process] ([PK_ProcessID]),
    CONSTRAINT [FK_FDM_DB_dbo_FactFDM_RIPolicyID] FOREIGN KEY ([FK_RIPolicyID]) REFERENCES [dim].[RIPolicy] ([PK_RIPolicyID]),
    CONSTRAINT [FK_FDM_DB_dbo_FactFDM_ScenarioID] FOREIGN KEY ([FK_ScenarioID]) REFERENCES [dim].[Scenario] ([PK_ScenarioID]),
    CONSTRAINT [FK_FDM_DB_dbo_FactFDM_SourceSystemID] FOREIGN KEY ([FK_SourceSystemID]) REFERENCES [dim].[SourceSystem] ([PK_SourceSystemID]),
    CONSTRAINT [FK_FDM_DB_dbo_FactFDM_TrifocusID] FOREIGN KEY ([FK_TrifocusID]) REFERENCES [dim].[Trifocus] ([PK_TrifocusID]),
    CONSTRAINT [FK_FDM_DB_dbo_FactFDM_UserID] FOREIGN KEY ([FK_UserID]) REFERENCES [dim].[User] ([PK_UserID]),
    CONSTRAINT [FK_FDM_DB_dbo_FactFDM_YOAID] FOREIGN KEY ([FK_YOAID]) REFERENCES [dim].[YOA] ([PK_YOAID])
) ON [INDEXES];
















GO
CREATE CLUSTERED COLUMNSTORE INDEX [CCI_FDM_DB_dbo_FactFDM]
    ON [fact].[FDM_DB_dbo_FactFDM]
    ON [INDEXES];











GO
EXECUTE sp_addextendedproperty @name = N'GrowthProxy', @value = N'yyyymm', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'FDM_DB_dbo_FactFDM', @level2type = N'COLUMN', @level2name = N'FK_AccountingPeriodID';


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Settlement Currency', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'FDM_DB_dbo_FactFDM', @level2type = N'COLUMN', @level2name = N'FK_CCYSettlementID';


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Original Currency', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'FDM_DB_dbo_FactFDM', @level2type = N'COLUMN', @level2name = N'FK_CCYOriginalID';


GO
EXECUTE sp_addextendedproperty @name = N'dictionary', @value = N'EX001', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'FDM_DB_dbo_FactFDM', @level2type = N'COLUMN', @level2name = N'FK_EntityID';


GO
EXECUTE sp_addextendedproperty @name = N'definition', @value = N'This is where a non-dictionary definition goes', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'FDM_DB_dbo_FactFDM', @level2type = N'COLUMN', @level2name = N'FK_EntityID';


GO
EXECUTE sp_addextendedproperty @name = N'canonical', @value = N'Yes', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'FDM_DB_dbo_FactFDM', @level2type = N'COLUMN', @level2name = N'FK_EntityID';


GO
EXECUTE sp_addextendedproperty @name = N'source_table', @value = N'FactFDM', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'FDM_DB_dbo_FactFDM';


GO
EXECUTE sp_addextendedproperty @name = N'source_schema', @value = N'dbo', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'FDM_DB_dbo_FactFDM';


GO
EXECUTE sp_addextendedproperty @name = N'source_catalogue', @value = N'FDM_DB', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'FDM_DB_dbo_FactFDM';


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'FDM', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'FDM_DB_dbo_FactFDM';


GO
EXECUTE sp_addextendedproperty @name = N'dictionary', @value = N'N/A', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'FDM_DB_dbo_FactFDM';


GO
EXECUTE sp_addextendedproperty @name = N'definition', @value = N'This is the primary FDM fact table', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'FDM_DB_dbo_FactFDM';


GO
EXECUTE sp_addextendedproperty @name = N'canonical', @value = N'N/A', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'FDM_DB_dbo_FactFDM';


GO
CREATE NONCLUSTERED INDEX [NCI_FactFDM_Test]
    ON [fact].[FDM_DB_dbo_FactFDM]([FK_AccountingPeriodID] ASC, [Hash] ASC, [SourceKey] ASC)
    INCLUDE([Bk_TransactionID]) WITH (FILLFACTOR = 90)
    ON [INDEXES];


GO
CREATE NONCLUSTERED INDEX [NCI_FactFDM_FK_AccountingPeriodID_SourceKey_Hash_BkTransactionID]
    ON [fact].[FDM_DB_dbo_FactFDM]([FK_AccountingPeriodID] ASC, [SourceKey] ASC, [Hash] ASC)
    INCLUDE([Bk_TransactionID]) WITH (FILLFACTOR = 90)
    ON [INDEXES];

