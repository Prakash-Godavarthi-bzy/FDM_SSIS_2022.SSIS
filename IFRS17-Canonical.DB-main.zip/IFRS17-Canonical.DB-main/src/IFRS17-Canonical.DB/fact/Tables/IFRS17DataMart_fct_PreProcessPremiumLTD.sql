﻿CREATE TABLE [fact].[IFRS17DataMart_fct_PreProcessPremiumLTD] (
    [FK_AccountIFRS17ID]      SMALLINT         NOT NULL,
    [FK_ProcessIFRS17ID]      SMALLINT         NOT NULL,
    [Basis]                   VARCHAR (32)     NOT NULL,
    [PolicyNumber]            VARCHAR (50)     NULL,
    [TypeOfBusiness]          CHAR (1)         NOT NULL,
    [InceptionDate]           DATE             NULL,
    [ExpiryDate]              DATE             NULL,
    [FK_EntityID]             BIGINT           NOT NULL,
    [FK_TrifocusID]           BIGINT           NOT NULL,
    [FK_YOAID]                SMALLINT         NOT NULL,
    [FK_CurrencyOriginalID]   BIGINT           NOT NULL,
    [FK_CurrencySettlementID] BIGINT           NOT NULL,
    [FK_DatasetID]            BIGINT           NULL,
    [FK_ScenarioID]           SMALLINT         NOT NULL,
    [YOI]                     SMALLINT         NULL,
    [InceptionPeriod]         INT              NULL,
    [FK_AccountingPeriodID]   INT              NULL,
    [RIFlag]                  CHAR (1)         NULL,
    [FK_RIPolicyID]           INT              NULL,
    [ClaimBasis]              VARCHAR (50)     NULL,
    [MOPCode]                 VARCHAR (10)     NULL,
    [Value]                   NUMERIC (38, 10) NULL,
    [Hash]                    VARBINARY (64)   NOT NULL,
    [SourceKey]               BIGINT           NOT NULL,
    CONSTRAINT [FK_IFRS17DataMart_fct_PreProcessPremiumLTD_AccountIFRS17ID] FOREIGN KEY ([FK_AccountIFRS17ID]) REFERENCES [dim].[AccountIFRS17] ([PK_AccountIFRS17ID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_PreProcessPremiumLTD_AccountingPeriodID] FOREIGN KEY ([FK_AccountingPeriodID]) REFERENCES [dim].[AccountingPeriod] ([PK_AccountingPeriodID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_PreProcessPremiumLTD_CurrencyOriginalID] FOREIGN KEY ([FK_CurrencyOriginalID]) REFERENCES [dim].[Currency] ([PK_CurrencyID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_PreProcessPremiumLTD_CurrencySettlementID] FOREIGN KEY ([FK_CurrencySettlementID]) REFERENCES [dim].[Currency] ([PK_CurrencyID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_PreProcessPremiumLTD_DataSetID] FOREIGN KEY ([FK_DatasetID]) REFERENCES [dim].[DataSet] ([PK_DataSetID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_PreProcessPremiumLTD_EntityID] FOREIGN KEY ([FK_EntityID]) REFERENCES [dim].[Entity] ([PK_EntityID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_PreProcessPremiumLTD_ProcessIFRS17ID] FOREIGN KEY ([FK_ProcessIFRS17ID]) REFERENCES [dim].[ProcessIFRS17] ([PK_ProcessIFRS17ID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_PreProcessPremiumLTD_RIPolicyID] FOREIGN KEY ([FK_RIPolicyID]) REFERENCES [dim].[RIPolicy] ([PK_RIPolicyID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_PreProcessPremiumLTD_ScenarioID] FOREIGN KEY ([FK_ScenarioID]) REFERENCES [dim].[Scenario] ([PK_ScenarioID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_PreProcessPremiumLTD_TrifocusID] FOREIGN KEY ([FK_TrifocusID]) REFERENCES [dim].[Trifocus] ([PK_TrifocusID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_PreProcessPremiumLTD_YOAID] FOREIGN KEY ([FK_YOAID]) REFERENCES [dim].[YOA] ([PK_YOAID])
) ON [INDEXES];












GO
EXECUTE sp_addextendedproperty @name = N'GrowthProxy', @value = N'yyyymm', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17DataMart_fct_PreProcessPremiumLTD', @level2type = N'COLUMN', @level2name = N'FK_AccountingPeriodID';


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Settlement Currency', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17DataMart_fct_PreProcessPremiumLTD', @level2type = N'COLUMN', @level2name = N'FK_CurrencySettlementID';


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Original Currency', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17DataMart_fct_PreProcessPremiumLTD', @level2type = N'COLUMN', @level2name = N'FK_CurrencyOriginalID';


GO
EXECUTE sp_addextendedproperty @name = N'definition', @value = N'This is where a non-dictionary definition goes', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17DataMart_fct_PreProcessPremiumLTD', @level2type = N'COLUMN', @level2name = N'FK_EntityID';


GO
EXECUTE sp_addextendedproperty @name = N'canonical', @value = N'Yes', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17DataMart_fct_PreProcessPremiumLTD', @level2type = N'COLUMN', @level2name = N'FK_EntityID';


GO
EXECUTE sp_addextendedproperty @name = N'source_table', @value = N'PreProcessPremiumLTD', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17DataMart_fct_PreProcessPremiumLTD';


GO
EXECUTE sp_addextendedproperty @name = N'source_schema', @value = N'fct', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17DataMart_fct_PreProcessPremiumLTD';


GO
EXECUTE sp_addextendedproperty @name = N'source_catalogue', @value = N'IFRS17DataMart', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17DataMart_fct_PreProcessPremiumLTD';


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'IFRS17DataMart Pre-Processing Premium', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17DataMart_fct_PreProcessPremiumLTD';


GO
EXECUTE sp_addextendedproperty @name = N'dictionary', @value = N'N/A', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17DataMart_fct_PreProcessPremiumLTD';


GO
EXECUTE sp_addextendedproperty @name = N'definition', @value = N'This is the IFRS17 Data Mart fact table for preprocessing', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17DataMart_fct_PreProcessPremiumLTD';


GO
EXECUTE sp_addextendedproperty @name = N'canonical', @value = N'N/A', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17DataMart_fct_PreProcessPremiumLTD';


GO
CREATE CLUSTERED COLUMNSTORE INDEX [CCI_IFRS17DataMart_fct_PreProcessPremiumLTD]
    ON [fact].[IFRS17DataMart_fct_PreProcessPremiumLTD] WITH (DROP_EXISTING = OFF)
    ON [INDEXES];




GO
CREATE NONCLUSTERED INDEX [idx_IFRS17DataMart_fct_PreProcessPremiumLTD_FK_AccountingPeriodID]
    ON [fact].[IFRS17DataMart_fct_PreProcessPremiumLTD]([FK_AccountingPeriodID] ASC)
    INCLUDE([PolicyNumber]) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];


GO
CREATE NONCLUSTERED INDEX [NCI_IFRS17DataMart_fct_PreProcessPremiumLTD_SourceKey_Hash]
    ON [fact].[IFRS17DataMart_fct_PreProcessPremiumLTD]([SourceKey] ASC, [Hash] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];

