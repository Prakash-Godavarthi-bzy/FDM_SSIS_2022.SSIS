﻿CREATE TABLE [fact].[IFRS17PsicleData_Agr_CSMDisclosure_Exceptions] (
    [Fk_PositionID]    SMALLINT       NOT NULL,
    [Fk_BalanceID]     SMALLINT       NOT NULL,
    [FK_CurrencyID]    BIGINT         NOT NULL,
    [FK_EntityID]      BIGINT         NOT NULL,
    [FK_TrifocusID]    BIGINT         NOT NULL,
    [RIFlag]           VARCHAR (1)    NOT NULL,
    [FK_RunID]         BIGINT         NOT NULL,
    [GHID]             NVARCHAR (500) NOT NULL,
    [Amount]           NUMERIC (19)   NULL,
    [AmountDiscounted] NUMERIC (19)   NULL,
    CONSTRAINT [FK_IFRS17PsicleData_CSMDisc_BalanceID] FOREIGN KEY ([Fk_BalanceID]) REFERENCES [dim].[Balance] ([PK_BalanceID]),
    CONSTRAINT [FK_IFRS17PsicleData_CSMDisc_CurrencyID] FOREIGN KEY ([FK_CurrencyID]) REFERENCES [dim].[Currency] ([PK_CurrencyID]),
    CONSTRAINT [FK_IFRS17PsicleData_CSMDisc_EntityID] FOREIGN KEY ([FK_EntityID]) REFERENCES [dim].[Entity] ([PK_EntityID]),
    CONSTRAINT [FK_IFRS17PsicleData_CSMDisc_PositionID] FOREIGN KEY ([Fk_PositionID]) REFERENCES [dim].[Position] ([PK_PositionID]),
    CONSTRAINT [FK_IFRS17PsicleData_CSMDisc_RunID] FOREIGN KEY ([FK_RunID]) REFERENCES [dim].[Run] ([PK_RunID]),
    CONSTRAINT [FK_IFRS17PsicleData_CSMDisc_TrifocusID] FOREIGN KEY ([FK_TrifocusID]) REFERENCES [dim].[Trifocus] ([PK_TrifocusID])
) ON [INDEXES];


GO
CREATE CLUSTERED COLUMNSTORE INDEX [CCI_IFRS17PsicleData_Agr_CSMDisclosure_Exceptions]
    ON [fact].[IFRS17PsicleData_Agr_CSMDisclosure_Exceptions]
    ON [INDEXES];

