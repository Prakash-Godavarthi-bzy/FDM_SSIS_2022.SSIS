﻿CREATE TABLE [fact].[IFRS17PsicleData_Reporting_LIC_UndiscountedData] (
    [FK_RunID]            BIGINT           NOT NULL,
    [FK_EntityID]         BIGINT           NOT NULL,
    [FK_FocusGroupID]     SMALLINT         NULL,
    [FK_TrifocusID]       BIGINT           NOT NULL,
    [FK_TrifocusIFRS17ID] BIGINT           NULL,
    [FK_RIPolicyID]       INT              NULL,
    [FK_CCYSettlementID]  BIGINT           NOT NULL,
    [RIFlag]              CHAR (1)         NOT NULL,
    [FK_YOAID]            SMALLINT         NULL,
    [YOI]                 SMALLINT         NULL,
    [QOIEndDate]          DATE             NOT NULL,
    [InceptedStatus]      CHAR (1)         NOT NULL,
    [FK_StatementID]      SMALLINT         NOT NULL,
    [FK_BalanceID]        SMALLINT         NULL,
    [FK_PositionID]       SMALLINT         NULL,
    [Amount]              NUMERIC (38, 10) NULL,
    [FK_AccountICEID]     SMALLINT         NULL,
    [Hash]                VARBINARY (64)   NOT NULL,
    [SourceKey]           BIGINT           NOT NULL,
    CONSTRAINT [FK_IFRS17PsicleData_Reporting_LIC_UndiscountedData_AccountICEID] FOREIGN KEY ([FK_AccountICEID]) REFERENCES [dim].[AccountICE] ([PK_AccountICEID]),
    CONSTRAINT [FK_IFRS17PsicleData_Reporting_LIC_UndiscountedData_BalanceID] FOREIGN KEY ([FK_BalanceID]) REFERENCES [dim].[Balance] ([PK_BalanceID]),
    CONSTRAINT [FK_IFRS17PsicleData_Reporting_LIC_UndiscountedData_CCYSettlementID] FOREIGN KEY ([FK_CCYSettlementID]) REFERENCES [dim].[Currency] ([PK_CurrencyID]),
    CONSTRAINT [FK_IFRS17PsicleData_Reporting_LIC_UndiscountedData_EntityID] FOREIGN KEY ([FK_EntityID]) REFERENCES [dim].[Entity] ([PK_EntityID]),
    CONSTRAINT [FK_IFRS17PsicleData_Reporting_LIC_UndiscountedData_PositionID] FOREIGN KEY ([FK_PositionID]) REFERENCES [dim].[Position] ([PK_PositionID]),
    CONSTRAINT [FK_IFRS17PsicleData_Reporting_LIC_UndiscountedData_RIPolicyID] FOREIGN KEY ([FK_RIPolicyID]) REFERENCES [dim].[RIPolicy] ([PK_RIPolicyID]),
    CONSTRAINT [FK_IFRS17PsicleData_Reporting_LIC_UndiscountedData_Run] FOREIGN KEY ([FK_RunID]) REFERENCES [dim].[Run] ([PK_RunID]),
    CONSTRAINT [FK_IFRS17PsicleData_Reporting_LIC_UndiscountedData_StatementID] FOREIGN KEY ([FK_StatementID]) REFERENCES [dim].[Statement] ([PK_StatementID]),
    CONSTRAINT [FK_IFRS17PsicleData_Reporting_LIC_UndiscountedData_TrifocusID] FOREIGN KEY ([FK_TrifocusID]) REFERENCES [dim].[Trifocus] ([PK_TrifocusID]),
    CONSTRAINT [FK_IFRS17PsicleData_Reporting_LIC_UndiscountedData_TrifocusIFRS17ID] FOREIGN KEY ([FK_TrifocusIFRS17ID]) REFERENCES [dim].[Trifocus] ([PK_TrifocusID]),
    CONSTRAINT [FK_IFRS17PsicleData_Reporting_LIC_UndiscountedData_YOAID] FOREIGN KEY ([FK_YOAID]) REFERENCES [dim].[YOA] ([PK_YOAID])
) ON [INDEXES];








GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Settlement Currency', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17PsicleData_Reporting_LIC_UndiscountedData', @level2type = N'COLUMN', @level2name = N'FK_CCYSettlementID';


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Trifocus IFRS17', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17PsicleData_Reporting_LIC_UndiscountedData', @level2type = N'COLUMN', @level2name = N'FK_TrifocusIFRS17ID';


GO
EXECUTE sp_addextendedproperty @name = N'source_table', @value = N'LIC_UndiscountedData', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17PsicleData_Reporting_LIC_UndiscountedData';


GO
EXECUTE sp_addextendedproperty @name = N'source_schema', @value = N'Reporting', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17PsicleData_Reporting_LIC_UndiscountedData';


GO
EXECUTE sp_addextendedproperty @name = N'source_catalogue', @value = N'IFRS17PsicleData', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17PsicleData_Reporting_LIC_UndiscountedData';


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'ICE CSM', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17PsicleData_Reporting_LIC_UndiscountedData';


GO
EXECUTE sp_addextendedproperty @name = N'dictionary', @value = N'N/A', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17PsicleData_Reporting_LIC_UndiscountedData';


GO
EXECUTE sp_addextendedproperty @name = N'definition', @value = N'ICE CSM output fact table', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17PsicleData_Reporting_LIC_UndiscountedData';


GO
EXECUTE sp_addextendedproperty @name = N'canonical', @value = N'N/A', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17PsicleData_Reporting_LIC_UndiscountedData';


GO
CREATE CLUSTERED COLUMNSTORE INDEX [CCI_IFRS17PsicleData_Reporting_LIC_UndiscountedData]
    ON [fact].[IFRS17PsicleData_Reporting_LIC_UndiscountedData] WITH (DROP_EXISTING = OFF)
    ON [INDEXES];

