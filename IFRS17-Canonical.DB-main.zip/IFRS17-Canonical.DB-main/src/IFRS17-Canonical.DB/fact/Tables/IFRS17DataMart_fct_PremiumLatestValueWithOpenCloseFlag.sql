﻿CREATE TABLE [fact].[IFRS17DataMart_fct_PremiumLatestValueWithOpenCloseFlag] (
    [SourceKey]               BIGINT           NOT NULL,
    [FK_CurrencyOriginalID]   BIGINT           NOT NULL,
    [FK_CurrencySettlementID] BIGINT           NOT NULL,
    [FK_EntityID]             BIGINT           NOT NULL,
    [FK_ScenarioID]           SMALLINT         NOT NULL,
    [FK_RIPolicyID]           INT              NULL,
    [FK_TrifocusID]           BIGINT           NOT NULL,
    [FK_AccountIFRS17ID]      SMALLINT         NOT NULL,
    [FK_DataSetID]            BIGINT           NOT NULL,
    [FK_ProcessIFRS17ID]      SMALLINT         NOT NULL,
    [FK_YOAID]                SMALLINT         NOT NULL,
    [FK_Basis]                VARCHAR (32)     NOT NULL,
    [BK_PolicyNumber]         VARCHAR (50)     NULL,
    [PolicyType]              VARCHAR (128)    NULL,
    [TypeOfBusiness]          VARCHAR (128)    NULL,
    [InceptionDate]           DATE             NULL,
    [ExpiryDate]              DATE             NULL,
    [YOI]                     SMALLINT         NULL,
    [InceptionPeriod]         INT              NULL,
    [Value]                   NUMERIC (38, 10) NULL,
    [FK_AccountingPeriodID]   INT              NULL,
    [RI Flag]                 VARCHAR (1)      NULL,
    [Claim_Basis]             VARCHAR (128)    NULL,
    [RI_Policy_Type]          VARCHAR (128)    NULL,
    [MOPCode]                 VARCHAR (128)    NULL,
    [Open_Cls_Flag]           VARCHAR (128)    NULL,
    [Hash]                    BINARY (64)      NOT NULL,
    CONSTRAINT [FK_IFRS17DataMart_fct_PremiumLatestValueWithOpenCloseFlag_AccountIFRS17ID] FOREIGN KEY ([FK_AccountIFRS17ID]) REFERENCES [dim].[AccountIFRS17] ([PK_AccountIFRS17ID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_PremiumLatestValueWithOpenCloseFlag_AccountingPeriodID] FOREIGN KEY ([FK_AccountingPeriodID]) REFERENCES [dim].[AccountingPeriod] ([PK_AccountingPeriodID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_PremiumLatestValueWithOpenCloseFlag_CurrencyOriginalID] FOREIGN KEY ([FK_CurrencyOriginalID]) REFERENCES [dim].[Currency] ([PK_CurrencyID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_PremiumLatestValueWithOpenCloseFlag_CurrencySettlementID] FOREIGN KEY ([FK_CurrencySettlementID]) REFERENCES [dim].[Currency] ([PK_CurrencyID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_PremiumLatestValueWithOpenCloseFlag_DataSetID] FOREIGN KEY ([FK_DataSetID]) REFERENCES [dim].[DataSet] ([PK_DataSetID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_PremiumLatestValueWithOpenCloseFlag_EntityID] FOREIGN KEY ([FK_EntityID]) REFERENCES [dim].[Entity] ([PK_EntityID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_PremiumLatestValueWithOpenCloseFlag_ProcessIFRS17ID] FOREIGN KEY ([FK_ProcessIFRS17ID]) REFERENCES [dim].[ProcessIFRS17] ([PK_ProcessIFRS17ID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_PremiumLatestValueWithOpenCloseFlag_RIPolicyID] FOREIGN KEY ([FK_RIPolicyID]) REFERENCES [dim].[RIPolicy] ([PK_RIPolicyID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_PremiumLatestValueWithOpenCloseFlag_ScenarioID] FOREIGN KEY ([FK_ScenarioID]) REFERENCES [dim].[Scenario] ([PK_ScenarioID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_PremiumLatestValueWithOpenCloseFlag_TrifocusID] FOREIGN KEY ([FK_TrifocusID]) REFERENCES [dim].[Trifocus] ([PK_TrifocusID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_PremiumLatestValueWithOpenCloseFlag_YOAID] FOREIGN KEY ([FK_YOAID]) REFERENCES [dim].[YOA] ([PK_YOAID])
) ON [INDEXES];




GO
CREATE CLUSTERED COLUMNSTORE INDEX [CCI_IFRS17DataMart_fct_PremiumLatestValueWithOpenCloseFlag]
    ON [fact].[IFRS17DataMart_fct_PremiumLatestValueWithOpenCloseFlag] WITH (DROP_EXISTING = OFF)
    ON [INDEXES];


GO
CREATE NONCLUSTERED INDEX [NCI_IFRS17DataMart_fct_PremiumLatestValueWithOpenCloseFlag_FK_AccountingPeriodID_SourceKey_Hash]
    ON [fact].[IFRS17DataMart_fct_PremiumLatestValueWithOpenCloseFlag]([FK_AccountingPeriodID] ASC, [SourceKey] ASC, [Hash] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];

