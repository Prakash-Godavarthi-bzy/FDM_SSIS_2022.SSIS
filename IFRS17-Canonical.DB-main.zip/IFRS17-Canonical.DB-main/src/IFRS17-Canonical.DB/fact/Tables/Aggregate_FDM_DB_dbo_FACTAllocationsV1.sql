﻿CREATE TABLE [fact].[Aggregate_FDM_DB_dbo_FACTAllocationsV1] (
    [FK_AccountID]          SMALLINT         NULL,
    [FK_AccountingPeriodID] INT              NULL,
    [FK_CCYOriginalID]      BIGINT           NULL,
    [FK_DataStageID]        BIGINT           NULL,
    [Fk_EntityID]           BIGINT           NULL,
    [FK_PolicySectionID]    BIGINT           NULL,
    [FK_ProcessID]          SMALLINT         NULL,
    [FK_RIPolicyID]         INT              NULL,
    [FK_ScenarioID]         SMALLINT         NULL,
    [FK_SourceSystemID]     INT              NULL,
    [Fk_TrifocusID]         BIGINT           NULL,
    [FK_YOAID]              SMALLINT         NULL,
    [cur_amount]            NUMERIC (38, 10) NULL
);


GO
CREATE COLUMNSTORE INDEX [NCI_Agg_FACTAllocationsV1_FK_AccountingPeriodID_FK_YOAID]
    ON [fact].[Aggregate_FDM_DB_dbo_FACTAllocationsV1]([FK_AccountingPeriodID], [FK_YOAID]) WITH (DROP_EXISTING = OFF);

