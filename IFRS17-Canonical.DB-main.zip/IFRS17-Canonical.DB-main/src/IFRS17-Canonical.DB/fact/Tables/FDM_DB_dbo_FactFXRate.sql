﻿CREATE TABLE [fact].[FDM_DB_dbo_FactFXRate] (
    [PK_FXRateID]              BIGINT          IDENTITY (1, 1) NOT NULL,
    [fk_AccountingPeriodID]    INT             NOT NULL,
    [fk_FXRateID]              BIGINT          NOT NULL,
    [fk_TransactionCurrencyID] INT             NOT NULL,
    [fk_ReportingCurrencyID]   SMALLINT        NOT NULL,
    [FXRate]                   NUMERIC (28, 8) NULL,
    [fk_RateScenarioID]        SMALLINT        NOT NULL,
    [Hash]                     VARBINARY (64)  NOT NULL,
    PRIMARY KEY CLUSTERED ([PK_FXRateID] ASC) WITH (FILLFACTOR = 90) ON [INDEXES],
    CONSTRAINT [FK_FDM_DB_dbo_FactFXRate_AccountingPeriodID] FOREIGN KEY ([fk_AccountingPeriodID]) REFERENCES [dim].[AccountingPeriod] ([PK_AccountingPeriodID]),
    CONSTRAINT [FK_FDM_DB_dbo_FactFXRate_CCYOriginalID] FOREIGN KEY ([fk_TransactionCurrencyID]) REFERENCES [dim].[DimCurrency] ([PK_CurrencyID]),
    CONSTRAINT [FK_FDM_DB_dbo_FactFXRate_FXRateID] FOREIGN KEY ([fk_FXRateID]) REFERENCES [dim].[FXRateName] ([PK_FXRateNameID]),
    CONSTRAINT [FK_FDM_DB_dbo_FactFXRate_RateScenarioID] FOREIGN KEY ([fk_RateScenarioID]) REFERENCES [dim].[RateScenario] ([PK_RateScenarioID]),
    CONSTRAINT [FK_FDM_DB_dbo_FactFXRate_ReportingCurrencyID] FOREIGN KEY ([fk_ReportingCurrencyID]) REFERENCES [dim].[ReportingCurrency] ([PK_ReportingCurrencyID])
) ON [INDEXES];


GO
CREATE NONCLUSTERED INDEX [NCI_FDM_DB_dbo_FactFXRate_ReportingCurrencyID_AccountingPeriodID_FXRateID_TransactionCurrencyID_FXRate_RateScenarioID]
    ON [fact].[FDM_DB_dbo_FactFXRate]([fk_ReportingCurrencyID] ASC)
    INCLUDE([fk_AccountingPeriodID], [fk_FXRateID], [fk_TransactionCurrencyID], [FXRate], [fk_RateScenarioID]) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];


GO
CREATE NONCLUSTERED INDEX [NCI_FDM_DB_dbo_FactFXRate_ReportingCurrencyID_AccountingPeriodID_FXRateID_TransactionCurrencyID_FXRate]
    ON [fact].[FDM_DB_dbo_FactFXRate]([fk_ReportingCurrencyID] ASC)
    INCLUDE([fk_AccountingPeriodID], [fk_FXRateID], [fk_TransactionCurrencyID], [FXRate]) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];


GO
CREATE NONCLUSTERED INDEX [NCI_FactFXRate_FK_AccountingPeriodID_FXRateID_Hash]
    ON [fact].[FDM_DB_dbo_FactFXRate]([fk_AccountingPeriodID] ASC, [PK_FXRateID] ASC, [Hash] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];

