﻿CREATE TABLE [fact].[IFRS17PsicleData_Reporting_CSM_Extract] (
    [FK_RunID]              BIGINT           NOT NULL,
    [Position]              VARCHAR (32)     NOT NULL,
    [FK_EntityID]           BIGINT           NOT NULL,
    [FK_TrifocusID]         BIGINT           NOT NULL,
    [FK_CCYSettlementID]    BIGINT           NOT NULL,
    [FK_StatementID]        SMALLINT         NOT NULL,
    [FK_BalanceID]          SMALLINT         NULL,
    [FK_PositionID]         SMALLINT         NULL,
    [RIFlag]                CHAR (1)         NOT NULL,
    [YOI]                   SMALLINT         NULL,
    [FK_YOAID]              SMALLINT         NULL,
    [Year_QOIEndDate]       INT              NULL,
    [Amount]                NUMERIC (38, 10) NULL,
    [AmountDiscounted]      NUMERIC (38, 10) NULL,
    [Percentage]            NUMERIC (38, 10) NULL,
    [Calc_Amount]           NUMERIC (38, 6)  NULL,
    [Calc_AmountDisc]       NUMERIC (38, 6)  NULL,
    [QOIDate]               INT              NULL,
    [Year]                  INT              NULL,
    [NOY]                   VARCHAR (4)      NULL,
    [FXRate]                NUMERIC (28, 8)  NULL,
    [Calc_FXRateAmount]     NUMERIC (38, 6)  NULL,
    [Calc_FXRateAmountDisc] NUMERIC (38, 6)  NULL,
    [FK_RIPolicyID]         INT              NULL
) ON [INDEXES];






GO
CREATE CLUSTERED COLUMNSTORE INDEX [CCI_IFRS17PsicleData_Reporting_CSM_Extract]
    ON [fact].[IFRS17PsicleData_Reporting_CSM_Extract] WITH (DROP_EXISTING = OFF)
    ON [INDEXES];


GO
CREATE NONCLUSTERED INDEX [NCI_IFRS17PsicleData_Reporting_CSM_Extract_RunID_OtherColumns]
    ON [fact].[IFRS17PsicleData_Reporting_CSM_Extract]([FK_RunID] ASC, [FK_TrifocusID] ASC)
    INCLUDE([Position], [FK_EntityID], [FK_CCYSettlementID], [RIFlag], [YOI], [FK_YOAID], [Year_QOIEndDate], [Amount], [AmountDiscounted], [Percentage], [Calc_Amount], [Calc_AmountDisc], [QOIDate], [Year], [NOY], [FXRate]) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];


GO
CREATE NONCLUSTERED INDEX [NCI_Fact_CSM_Extract_RunID_RIFlag_TrifocusID_Fk_CCYSettlementID_Amount_AmountDisc_Calc_Amount_Calc_AmountDisc]
    ON [fact].[IFRS17PsicleData_Reporting_CSM_Extract]([FK_RunID] ASC, [RIFlag] ASC)
    INCLUDE([FK_TrifocusID], [FK_CCYSettlementID], [Amount], [AmountDiscounted], [Calc_Amount], [Calc_AmountDisc]) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];

