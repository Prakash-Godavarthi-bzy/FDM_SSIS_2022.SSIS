﻿CREATE TABLE [fact].[IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders] (
    [FK_EntityID]             BIGINT           NOT NULL,
    [FK_YOAID]                SMALLINT         NOT NULL,
    [FK_CurrencySettlementID] BIGINT           NOT NULL,
    [PolicyNumber]            VARCHAR (50)     NULL,
    [FK_DatasetID]            BIGINT           NULL,
    [FK_TrifocusID]           BIGINT           NOT NULL,
    [FK_ScenarioID]           SMALLINT         NOT NULL,
    [FK_AccountIFRS17ID]      SMALLINT         NOT NULL,
    [FK_AccountingPeriodID]   INT              NULL,
    [FK_CurrencyOriginalID]   BIGINT           NOT NULL,
    [InceptionDate]           DATE             NULL,
    [ExpiryDate]              DATE             NULL,
    [InceptionQuarter]        INT              NULL,
    [FK_TrifocusIFRS17ID]     BIGINT           NOT NULL,
    [FK_RIPolicyID]           INT              NULL,
    [RIFlag]                  CHAR (1)         NULL,
    [EarnedQuarter]           INT              NULL,
    [AdjTotEarnDaysV3]        NUMERIC (38, 12) NULL,
    [Earned]                  NUMERIC (38, 12) NULL,
    [YOI]                     SMALLINT         NULL,
    [Value]                   NUMERIC (38, 10) NULL,
    [Hash]                    VARBINARY (64)   NOT NULL,
    [SourceKey]               BIGINT           NOT NULL,
    CONSTRAINT [FK_IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders_AccountIFRS17ID] FOREIGN KEY ([FK_AccountIFRS17ID]) REFERENCES [dim].[AccountIFRS17] ([PK_AccountIFRS17ID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders_AccountingPeriodID] FOREIGN KEY ([FK_AccountingPeriodID]) REFERENCES [dim].[AccountingPeriod] ([PK_AccountingPeriodID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders_CurrencyOriginalID] FOREIGN KEY ([FK_CurrencyOriginalID]) REFERENCES [dim].[Currency] ([PK_CurrencyID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders_CurrencySettlementID] FOREIGN KEY ([FK_CurrencySettlementID]) REFERENCES [dim].[Currency] ([PK_CurrencyID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders_DataSetID] FOREIGN KEY ([FK_DatasetID]) REFERENCES [dim].[DataSet] ([PK_DataSetID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders_EntityID] FOREIGN KEY ([FK_EntityID]) REFERENCES [dim].[Entity] ([PK_EntityID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders_RIPolicyID] FOREIGN KEY ([FK_RIPolicyID]) REFERENCES [dim].[RIPolicy] ([PK_RIPolicyID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders_ScenarioID] FOREIGN KEY ([FK_ScenarioID]) REFERENCES [dim].[Scenario] ([PK_ScenarioID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders_TrifocusID] FOREIGN KEY ([FK_TrifocusID]) REFERENCES [dim].[Trifocus] ([PK_TrifocusID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders_TrifocusIFRS17ID] FOREIGN KEY ([FK_TrifocusIFRS17ID]) REFERENCES [dim].[Trifocus] ([PK_TrifocusID]),
    CONSTRAINT [FK_IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders_YOAID] FOREIGN KEY ([FK_YOAID]) REFERENCES [dim].[YOA] ([PK_YOAID])
) ON [INDEXES];






GO
CREATE CLUSTERED COLUMNSTORE INDEX [CCI_IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders]
    ON [fact].[IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders] WITH (DROP_EXISTING = OFF)
    ON [INDEXES];




GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Trifocus IFRS17', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders', @level2type = N'COLUMN', @level2name = N'FK_TrifocusIFRS17ID';


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Original Currency', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders', @level2type = N'COLUMN', @level2name = N'FK_CurrencyOriginalID';


GO
EXECUTE sp_addextendedproperty @name = N'GrowthProxy', @value = N'yyyymm', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders', @level2type = N'COLUMN', @level2name = N'FK_AccountingPeriodID';


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Settlement Currency', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders', @level2type = N'COLUMN', @level2name = N'FK_CurrencySettlementID';


GO
EXECUTE sp_addextendedproperty @name = N'source_table', @value = N'ActualWrittenPremiumByEarnQtr_Binders', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders';


GO
EXECUTE sp_addextendedproperty @name = N'source_schema', @value = N'fct', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders';


GO
EXECUTE sp_addextendedproperty @name = N'source_catalogue', @value = N'IFRS17DataMart', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders';


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'IFRS17DataMart Actual Written Premium By Earn Qtr (Binders)', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders';


GO
EXECUTE sp_addextendedproperty @name = N'canonical', @value = N'N/A', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders';


GO
CREATE NONCLUSTERED INDEX [NCI_IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders_FK_AccountingPeriodID_SourceKey_Hash]
    ON [fact].[IFRS17DataMart_fct_ActualWrittenPremiumByEarnQtr_Binders]([FK_AccountingPeriodID] ASC, [SourceKey] ASC, [Hash] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];

