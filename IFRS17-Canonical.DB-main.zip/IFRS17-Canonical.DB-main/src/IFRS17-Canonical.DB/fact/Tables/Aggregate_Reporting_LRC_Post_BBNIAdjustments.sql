﻿CREATE TABLE [fact].[Aggregate_Reporting_LRC_Post_BBNIAdjustments] (
    [FK_RunID]                  BIGINT           NOT NULL,
    [FK_EntityID]               BIGINT           NOT NULL,
    [FK_TrifocusID]             BIGINT           NOT NULL,
    [FK_RIPolicyID]             INT              NULL,
    [RIFlag]                    CHAR (1)         NOT NULL,
    [FK_YOAID]                  SMALLINT         NULL,
    [YOI]                       SMALLINT         NULL,
    [FK_CCYSettlementID]        BIGINT           NOT NULL,
    [FK_StatementID]            SMALLINT         NOT NULL,
    [FK_BalanceID]              SMALLINT         NOT NULL,
    [FK_PositionID]             SMALLINT         NOT NULL,
    [Amount]                    NUMERIC (38, 10) NULL,
    [AmountDiscounted]          NUMERIC (38, 10) NULL,
    [ConvertedAmount]           NUMERIC (38, 10) NULL,
    [ConvertedAmountDiscounted] NUMERIC (38, 10) NULL,
    [InceptedStatus]            CHAR (1)         NULL,
    [Fk_TrifocusMappingID]      BIGINT           NULL
);








GO
CREATE COLUMNSTORE INDEX [NCI_Agg_LRC_Post_BBNIAdjustments_FK_EntityID_FK_YOAID]
    ON [fact].[Aggregate_Reporting_LRC_Post_BBNIAdjustments]([FK_EntityID], [FK_YOAID]) WITH (DROP_EXISTING = OFF);


GO
CREATE NONCLUSTERED INDEX [Fact_Agg_IFRS17PsicleData_PositionID]
    ON [fact].[Aggregate_Reporting_LRC_Post_BBNIAdjustments]([FK_PositionID] ASC)
    INCLUDE([FK_RunID], [FK_EntityID], [FK_TrifocusID], [FK_RIPolicyID], [RIFlag], [FK_YOAID], [YOI], [FK_CCYSettlementID], [FK_StatementID], [FK_BalanceID], [Amount], [AmountDiscounted], [ConvertedAmount], [ConvertedAmountDiscounted]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90);


GO
