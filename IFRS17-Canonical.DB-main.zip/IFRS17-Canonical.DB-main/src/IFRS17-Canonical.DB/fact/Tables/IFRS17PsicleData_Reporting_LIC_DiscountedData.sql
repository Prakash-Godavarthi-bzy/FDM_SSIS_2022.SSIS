﻿CREATE TABLE [fact].[IFRS17PsicleData_Reporting_LIC_DiscountedData] (
    [FK_RunID]            BIGINT           NOT NULL,
    [FK_EntityID]         BIGINT           NOT NULL,
    [FK_FocusGroupID]     SMALLINT         NULL,
    [FK_TrifocusID]       BIGINT           NOT NULL,
    [FK_TrifocusIFRS17ID] BIGINT           NULL,
    [FK_RIPolicyID]       INT              NULL,
    [FK_CCYSettlementID]  BIGINT           NOT NULL,
    [RIFlag]              CHAR (1)         NOT NULL,
    [FK_YOAID]            SMALLINT         NULL,
    [YOI]                 SMALLINT         NULL,
    [QOIEndDate]          DATE             NOT NULL,
    [InceptedStatus]      CHAR (1)         NOT NULL,
    [FK_StatementID]      SMALLINT         NOT NULL,
    [FK_BalanceID]        SMALLINT         NULL,
    [FK_PositionID]       SMALLINT         NULL,
    [Amount]              NUMERIC (38, 10) NULL,
    [Amount_disc]         NUMERIC (38, 10) NULL,
    [Conv_Amount]         NUMERIC (38, 10) NULL,
    [Conv_Amount_disc]    NUMERIC (38, 10) NULL,
    [FK_UnitofAccountID]  SMALLINT         NULL,
    [Hash]                VARBINARY (64)   NOT NULL,
    [SourceKey]           BIGINT           NOT NULL
) ON [INDEXES];


GO
CREATE CLUSTERED COLUMNSTORE INDEX [CCI_IFRS17PsicleData_Reporting_LIC_DiscountedData]
    ON [fact].[IFRS17PsicleData_Reporting_LIC_DiscountedData] WITH (DROP_EXISTING = OFF)
    ON [INDEXES];

