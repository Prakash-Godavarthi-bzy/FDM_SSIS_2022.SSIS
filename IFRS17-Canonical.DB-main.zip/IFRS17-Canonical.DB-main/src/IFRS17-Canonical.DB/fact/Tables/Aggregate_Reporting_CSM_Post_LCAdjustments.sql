CREATE TABLE [fact].[Aggregate_Reporting_CSM_Post_LCAdjustments] (
    [FK_RunID]                  BIGINT           NOT NULL,
    [FK_EntityID]               BIGINT           NOT NULL,
    [FK_TrifocusID]             BIGINT           NOT NULL,
    [FK_RIPolicyID]             INT              NULL,
    [RIFlag]                    CHAR (1)         NOT NULL,
    [FK_YOAID]                  SMALLINT         NULL,
    [YOI]                       SMALLINT         NULL,
    [FK_CCYSettlementID]        BIGINT           NOT NULL,
    [FK_StatementID]            SMALLINT         NOT NULL,
    [FK_BalanceID]              SMALLINT         NOT NULL,
    [FK_PositionID]             SMALLINT         NOT NULL,
    [Amount]                    NUMERIC (38, 10) NULL,
    [AmountDiscounted]          NUMERIC (38, 10) NULL,
    [ConvertedAmount]           NUMERIC (38, 10) NULL,
    [ConvertedAmountDiscounted] NUMERIC (38, 10) NULL,
    [CSMLC]                     VARCHAR (10)     NULL,
    [InceptedStatus]            CHAR (1)         NOT NULL,
    [Fk_TrifocusMappingID]      BIGINT           NULL
);







GO
		CREATE NONCLUSTERED INDEX [Agg_IFRS17PsicleData_PositionID] ON [fact].[Aggregate_Reporting_CSM_Post_LCAdjustments]
		(
			[FK_PositionID] ASC
		)
		INCLUDE([FK_RunID],[Fk_TrifocusMappingID],[FK_EntityID],[FK_TrifocusID],[FK_RIPolicyID],[RIFlag],[FK_YOAID],[YOI],[FK_CCYSettlementID],[FK_StatementID],[FK_BalanceID],[Amount],[AmountDiscounted],[ConvertedAmount],[ConvertedAmountDiscounted],[CSMLC]) 
		WITH (FILLFACTOR = 90, DROP_EXISTING = OFF) ON [INDEXES]

GO
CREATE NONCLUSTERED INDEX [NCI_fact_agg_CSM_Post_LC_Adj_PositionID_CSMLC] ON [fact].[Aggregate_Reporting_CSM_Post_LCAdjustments]
		(
			[FK_PositionID] ASC,
			[CSMLC] ASC
		)
		INCLUDE([FK_RunID],[FK_BalanceID],[ConvertedAmountDiscounted],[Fk_TrifocusMappingID],[RIFlag]) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
		ON [INDEXES];

GO
CREATE NONCLUSTERED INDEX [NCI_fact_agg_CSM_Post_LC_Adj_PositionID_CSMLC_RiFlag] ON [fact].[Aggregate_Reporting_CSM_Post_LCAdjustments]
		(
			[RIFlag] ASC,
			[FK_PositionID] ASC,
			[CSMLC] ASC
		)
		INCLUDE([FK_RunID],[FK_BalanceID],[ConvertedAmountDiscounted],[Fk_TrifocusMappingID]) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
		ON [INDEXES];
GO
CREATE NONCLUSTERED INDEX [fact_Aggregate_Reporting_CSM_Post_LCAdjustments_CSMLC] ON [fact].[Aggregate_Reporting_CSM_Post_LCAdjustments]
(
	[CSMLC] ASC
) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
		ON [INDEXES];