﻿CREATE TABLE [fact].[Aggregate_Reporting_CSM_LRC_LIC] (
    [FK_RunID]                  BIGINT           NOT NULL,
    [FK_EntityID]               BIGINT           NOT NULL,
    [FK_TrifocusID]             BIGINT           NOT NULL,
    [FK_RIPolicyID]             INT              NULL,
    [RIFlag]                    CHAR (1)         NOT NULL,
    [FK_YOAID]                  SMALLINT         NULL,
    [YOI]                       SMALLINT         NULL,
    [FK_CCYSettlementID]        BIGINT           NOT NULL,
    [FK_StatementID]            SMALLINT         NOT NULL,
    [FK_BalanceID]              SMALLINT         NOT NULL,
    [FK_PositionID]             SMALLINT         NOT NULL,
    [Amount]                    NUMERIC (38, 10) NULL,
    [AmountDiscounted]          NUMERIC (38, 10) NULL,
    [ConvertedAmount]           NUMERIC (38, 10) NULL,
    [ConvertedAmountDiscounted] NUMERIC (38, 10) NULL,
    [CSMLC]                     VARCHAR (10)     NULL,
    [FK_TrifocusMappingID]      BIGINT           NULL
) ON [INDEXES];




GO
CREATE CLUSTERED COLUMNSTORE INDEX [CCI_Aggregate_Reporting_CSM_LRC_LIC]
    ON [fact].[Aggregate_Reporting_CSM_LRC_LIC]
    ON [INDEXES];



