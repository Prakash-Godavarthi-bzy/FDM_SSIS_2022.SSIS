﻿CREATE TABLE [fact].[TechnicalHub_fct_TechnicalResult] (
    [FK_EntityID]            BIGINT           NOT NULL,
    [FK_TrifocusID]          BIGINT           NOT NULL,
    [FK_RIPolicyID]          INT              NULL,
    [FK_CCYOriginalID]       BIGINT           NOT NULL,
    [FK_CCYSettlementID]     BIGINT           NOT NULL,
    [FK_DatasetID]           BIGINT           NULL,
    [FK_DataStageID]         BIGINT           NOT NULL,
    [FK_PolicySectionID]     BIGINT           NULL,
    [FK_ScenarioID]          SMALLINT         NOT NULL,
    [FK_ProcessIFRS17ID]     SMALLINT         NOT NULL,
    [FK_AccountIFRS17ID]     SMALLINT         NOT NULL,
    [FK_YOAID]               SMALLINT         NULL,
    [FK_AccountingPeriodID]  INT              NULL,
    [YOI]                    SMALLINT         NULL,
    [MOI]                    INT              NULL,
    [Value]                  NUMERIC (38, 10) NULL,
    [GroupShare]             NUMERIC (38, 12) NULL,
    [Hash]                   VARBINARY (64)   NOT NULL,
    [SourceKey]              BIGINT           NOT NULL,
    [Fk_ConformedEntityID]   INT              NULL,
    [Fk_ConformedTRifocusID] INT              NULL,
    CONSTRAINT [FK_TechnicalHub_fct_TechnicalResult_AccountIFRS17ID] FOREIGN KEY ([FK_AccountIFRS17ID]) REFERENCES [dim].[AccountIFRS17] ([PK_AccountIFRS17ID]),
    CONSTRAINT [FK_TechnicalHub_fct_TechnicalResult_AccountingPeriodID] FOREIGN KEY ([FK_AccountingPeriodID]) REFERENCES [dim].[AccountingPeriod] ([PK_AccountingPeriodID]),
    CONSTRAINT [FK_TechnicalHub_fct_TechnicalResult_CCYOriginalID] FOREIGN KEY ([FK_CCYOriginalID]) REFERENCES [dim].[Currency] ([PK_CurrencyID]),
    CONSTRAINT [FK_TechnicalHub_fct_TechnicalResult_CCYSettlementID] FOREIGN KEY ([FK_CCYSettlementID]) REFERENCES [dim].[Currency] ([PK_CurrencyID]),
    CONSTRAINT [FK_TechnicalHub_fct_TechnicalResult_DataSetID] FOREIGN KEY ([FK_DatasetID]) REFERENCES [dim].[DataSet] ([PK_DataSetID]),
    CONSTRAINT [FK_TechnicalHub_fct_TechnicalResult_DataStageID] FOREIGN KEY ([FK_DataStageID]) REFERENCES [dim].[DataStage] ([PK_DataStageID]),
    CONSTRAINT [FK_TechnicalHub_fct_TechnicalResult_EntityID] FOREIGN KEY ([FK_EntityID]) REFERENCES [dim].[Entity] ([PK_EntityID]),
    CONSTRAINT [FK_TechnicalHub_fct_TechnicalResult_ProcessIFRS17ID] FOREIGN KEY ([FK_ProcessIFRS17ID]) REFERENCES [dim].[ProcessIFRS17] ([PK_ProcessIFRS17ID]),
    CONSTRAINT [FK_TechnicalHub_fct_TechnicalResult_RIPolicyTypeID] FOREIGN KEY ([FK_RIPolicyID]) REFERENCES [dim].[RIPolicy] ([PK_RIPolicyID]),
    CONSTRAINT [FK_TechnicalHub_fct_TechnicalResult_ScenarioID] FOREIGN KEY ([FK_ScenarioID]) REFERENCES [dim].[Scenario] ([PK_ScenarioID]),
    CONSTRAINT [FK_TechnicalHub_fct_TechnicalResult_TrifocusID] FOREIGN KEY ([FK_TrifocusID]) REFERENCES [dim].[Trifocus] ([PK_TrifocusID]),
    CONSTRAINT [FK_TechnicalHub_fct_TechnicalResult_YOAID] FOREIGN KEY ([FK_YOAID]) REFERENCES [dim].[YOA] ([PK_YOAID])
) ON [INDEXES];










GO



GO
EXECUTE sp_addextendedproperty @name = N'GrowthProxy', @value = N'yyyymm', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'TechnicalHub_fct_TechnicalResult', @level2type = N'COLUMN', @level2name = N'FK_AccountingPeriodID';


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Settlement Currency', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'TechnicalHub_fct_TechnicalResult', @level2type = N'COLUMN', @level2name = N'FK_CCYSettlementID';


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Original Currency', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'TechnicalHub_fct_TechnicalResult', @level2type = N'COLUMN', @level2name = N'FK_CCYOriginalID';


GO
EXECUTE sp_addextendedproperty @name = N'dictionary', @value = N'EX001', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'TechnicalHub_fct_TechnicalResult', @level2type = N'COLUMN', @level2name = N'FK_EntityID';


GO
EXECUTE sp_addextendedproperty @name = N'definition', @value = N'This is where a non-dictionary definition goes', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'TechnicalHub_fct_TechnicalResult', @level2type = N'COLUMN', @level2name = N'FK_EntityID';


GO
EXECUTE sp_addextendedproperty @name = N'canonical', @value = N'Yes', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'TechnicalHub_fct_TechnicalResult', @level2type = N'COLUMN', @level2name = N'FK_EntityID';


GO
EXECUTE sp_addextendedproperty @name = N'source_table', @value = N'TechnicalResult', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'TechnicalHub_fct_TechnicalResult';


GO
EXECUTE sp_addextendedproperty @name = N'source_schema', @value = N'fct', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'TechnicalHub_fct_TechnicalResult';


GO
EXECUTE sp_addextendedproperty @name = N'source_catalogue', @value = N'TechnicalHub', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'TechnicalHub_fct_TechnicalResult';


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'TechnicalHub', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'TechnicalHub_fct_TechnicalResult';


GO
EXECUTE sp_addextendedproperty @name = N'dictionary', @value = N'N/A', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'TechnicalHub_fct_TechnicalResult';


GO
EXECUTE sp_addextendedproperty @name = N'definition', @value = N'This is the TechnicalHub primary  fact table', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'TechnicalHub_fct_TechnicalResult';


GO
EXECUTE sp_addextendedproperty @name = N'canonical', @value = N'N/A', @level0type = N'SCHEMA', @level0name = N'fact', @level1type = N'TABLE', @level1name = N'TechnicalHub_fct_TechnicalResult';


GO
CREATE CLUSTERED COLUMNSTORE INDEX [CCI_TechnicalHub_fct_TechnicalResult]
    ON [fact].[TechnicalHub_fct_TechnicalResult] WITH (DROP_EXISTING = OFF)
    ON [INDEXES];




GO
CREATE NONCLUSTERED INDEX [TechnicalHub_fct_TechnicalResult_YOA]
    ON [fact].[TechnicalHub_fct_TechnicalResult]([FK_YOAID] ASC)
    INCLUDE([Hash], [SourceKey]) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];

