﻿CREATE TABLE [fact].[Aggregate_TechnicalHub_fct_VW_TechnicalResult] (
    [FK_AccountIFRS17ID]    SMALLINT         NULL,
    [FK_AccountingPeriodID] INT              NULL,
    [FK_CCYSettlementID]    BIGINT           NULL,
    [FK_DatasetID]          BIGINT           NULL,
    [FK_EntityID]           BIGINT           NULL,
    [MOI]                   INT              NULL,
    [FK_PolicySectionID]    BIGINT           NULL,
    [FK_RIPolicyID]         INT              NULL,
    [FK_TrifocusID]         BIGINT           NULL,
    [FK_YOAID]              SMALLINT         NULL,
    [Value]                 NUMERIC (38, 10) NULL,
    [FK_ProgrammeCode]      VARCHAR (100)    NULL,
    [FK_DataStageID]        BIGINT           NULL
);




GO
CREATE COLUMNSTORE INDEX [NCI_Agg_VW_TechnicalResult_FK_AccountingPeriodID_FK_YOAID]
    ON [fact].[Aggregate_TechnicalHub_fct_VW_TechnicalResult]([FK_AccountingPeriodID], [FK_YOAID]) WITH (DROP_EXISTING = OFF);

