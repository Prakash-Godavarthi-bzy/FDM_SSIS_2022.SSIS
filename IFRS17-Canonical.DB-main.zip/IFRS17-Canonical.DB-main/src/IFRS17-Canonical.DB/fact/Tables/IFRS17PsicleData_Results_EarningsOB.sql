﻿CREATE TABLE [fact].[IFRS17PsicleData_Results_EarningsOB] (
    [FK_RunID]            BIGINT           NULL,
    [FK_EntityID]         BIGINT           NOT NULL,
    [FK_TrifocusID]       BIGINT           NOT NULL,
    [FK_TrifocusIFRS17ID] BIGINT           NULL,
    [FK_AccountICEID]     SMALLINT         NULL,
    [FK_CCYSettlementID]  BIGINT           NOT NULL,
    [RIFlag]              CHAR (1)         NOT NULL,
    [YOI]                 SMALLINT         NULL,
    [QOIEndDate]          DATE             NOT NULL,
    [Value]               NUMERIC (38, 10) NULL,
    [FK_YOAID]            SMALLINT         NULL,
    [Programme]           VARCHAR (128)    NULL,
    [RecoginitionType]    VARCHAR (2)      NULL,
    [InceptedStatus]      VARCHAR (1)      NULL,
    [OpenCloseFlag]       VARCHAR (10)     NULL,
    [Hash]                VARBINARY (64)   NOT NULL
) ON [INDEXES];

