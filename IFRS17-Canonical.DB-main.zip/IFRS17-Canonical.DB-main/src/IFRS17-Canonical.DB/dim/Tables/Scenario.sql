﻿CREATE TABLE [dim].[Scenario] (
    [PK_ScenarioID]   SMALLINT       IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID] TINYINT        NOT NULL,
    [SourceKey]       VARCHAR (128)  NOT NULL,
    [ScenarioCode]    VARCHAR (16)   NOT NULL,
    [ScenarioName]    VARCHAR (32)   NULL,
    [ScenarioType]    VARCHAR (16)   NULL,
    [SortOrder]       INT            NULL,
    [FriendlyName]    VARCHAR (32)   NULL,
    [CurrentPeriod]   INT            NULL,
    [Hash]            VARBINARY (64) NOT NULL,
    CONSTRAINT [PK_ScenarioID] PRIMARY KEY CLUSTERED ([PK_ScenarioID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_Scenario_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];








GO
CREATE UNIQUE NONCLUSTERED INDEX [NCI_Scenario]
    ON [dim].[Scenario]([FK_DataSourceID] ASC, [SourceKey] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];




GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Scenario', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'Scenario';

