CREATE TABLE [dim].[AccountIFRS17] (
    [PK_AccountIFRS17ID] SMALLINT       IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID]    TINYINT        NOT NULL,
    [SourceKey]          VARCHAR (128)  NOT NULL,
    [AccountKey]         VARCHAR (16)   NOT NULL,
    [AccountName]        VARCHAR (100)  NULL,
    [Level1Group]        VARCHAR (64)   NULL,
    [Level2Group]        VARCHAR (64)   NULL,
    [Level3Group]        VARCHAR (64)   NULL,
    [RIFlag]             VARCHAR (2)    NULL,
    [Hash]               VARBINARY (64) NOT NULL,
    CONSTRAINT [PK_AccountIFRS17ID] PRIMARY KEY CLUSTERED ([PK_AccountIFRS17ID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_AccountIFRS17_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];



GO
CREATE UNIQUE NONCLUSTERED INDEX [NCI_AccountIFRS17]
    ON [dim].[AccountIFRS17]([FK_DataSourceID] ASC, [SourceKey] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];

GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Account (IFRS17)', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'AccountIFRS17';


GO
EXECUTE sp_addextendedproperty @name = N'business_key', @value = N'True', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'AccountIFRS17', @level2type = N'COLUMN', @level2name = N'AccountKey';

