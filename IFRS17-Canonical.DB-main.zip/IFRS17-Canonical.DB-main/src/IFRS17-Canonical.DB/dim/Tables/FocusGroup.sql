﻿CREATE TABLE [dim].[FocusGroup] (
    [PK_FocusGroupID] BIGINT         IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID] TINYINT        NOT NULL,
    [SourceKey]       VARCHAR (128)  NULL,
    [FocusGroupName]  VARCHAR (128)  NULL,
    [Hash]            VARBINARY (64) NOT NULL,
    CONSTRAINT [PK_FocusGroupID] PRIMARY KEY CLUSTERED ([PK_FocusGroupID] ASC) WITH (FILLFACTOR = 90) ON [DATA]
) ON [DATA];


GO
CREATE UNIQUE NONCLUSTERED INDEX [NCI_FocusGroup]
    ON [dim].[FocusGroup]([FK_DataSourceID] ASC, [SourceKey] ASC) WITH (FILLFACTOR = 90)
    ON [INDEXES];

