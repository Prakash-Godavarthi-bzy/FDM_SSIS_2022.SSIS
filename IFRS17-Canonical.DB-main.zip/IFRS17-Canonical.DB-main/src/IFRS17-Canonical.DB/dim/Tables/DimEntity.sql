﻿CREATE TABLE [dim].[DimEntity] (
    [PK_EntityID]             INT           NOT NULL,
    [EntityCode]              VARCHAR (16)  NOT NULL,
    [EntityName]              NVARCHAR (64) NULL,
    [Platform]                VARCHAR (5)   NULL,
    [EntityLevel1]            NVARCHAR (32) NULL,
    [EntityLevel2]            NVARCHAR (32) NULL,
    [EntityLevel3]            NVARCHAR (32) NULL,
    [EntityLevel4]            NVARCHAR (32) NULL,
    [EntityLevel5]            NVARCHAR (32) NULL,
    [Status]                  CHAR (1)      NULL,
    [FK_FunctionalCurrencyID] BIGINT        NULL,
    [ExcludeFromFXCalcs]      BIT           NULL,
    [TargetEntityIdentifier]  BIT           NULL,
    PRIMARY KEY CLUSTERED ([PK_EntityID] ASC) WITH (FILLFACTOR = 90)
);

