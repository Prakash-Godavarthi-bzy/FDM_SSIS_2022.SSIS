﻿CREATE TABLE [dim].[ReportingCurrency] (
    [PK_ReportingCurrencyID] SMALLINT       IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID]        TINYINT        NOT NULL,
    [SourceKey]              VARCHAR (128)  NOT NULL,
    [ReportingCurrencyCode]  VARCHAR (16)   NOT NULL,
    [ReportingCurrencyName]  VARCHAR (128)  NOT NULL,
    [Hash]                   VARBINARY (64) NOT NULL,
    CONSTRAINT [PK_ReportingCurrencyID] PRIMARY KEY CLUSTERED ([PK_ReportingCurrencyID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_ReportingCurrency_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];

