﻿CREATE TABLE [dim].[Trifocus] (
    [PK_TrifocusID]     BIGINT         IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID]   TINYINT        NOT NULL,
    [SourceKey]         VARCHAR (128)  NOT NULL,
    [TrifocusCode]      VARCHAR (16)   NOT NULL,
    [TriFocusName]      NVARCHAR (64)  NULL,
    [TriFocusLevel1]    NVARCHAR (64)  NULL,
    [TriFocusLevel2]    NVARCHAR (64)  NULL,
    [TriFocusLevel3]    NVARCHAR (64)  NULL,
    [TrifocusGroup]     VARCHAR (8)    NULL,
    [IsUSTrifocus]      BIT            NULL,
    [IsKrReTrifocus]    BIT            NULL,
    [IsUSSyndTrifocus]  BIT            NULL,
    [IsSLInternational] BIT            NULL,
    [status]            VARCHAR (8)    NULL,
    [TrifocusTypeCode]  CHAR (1)       NULL,
    [TrifocusTypeDesc]  VARCHAR (16)   NULL,
    [Hash]              VARBINARY (64) NOT NULL,
    CONSTRAINT [PK_TrifocusID] PRIMARY KEY CLUSTERED ([PK_TrifocusID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_Trifocus_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];










GO
CREATE UNIQUE NONCLUSTERED INDEX [NCI_Trifocus]
    ON [dim].[Trifocus]([FK_DataSourceID] ASC, [SourceKey] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];




GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Trifocus', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'Trifocus';

