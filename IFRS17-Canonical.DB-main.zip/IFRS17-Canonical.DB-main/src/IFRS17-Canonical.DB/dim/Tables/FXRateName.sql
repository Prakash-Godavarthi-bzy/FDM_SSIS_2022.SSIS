﻿CREATE TABLE [dim].[FXRateName] (
    [PK_FXRateNameID] BIGINT         IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID] TINYINT        NOT NULL,
    [SourceKey]       VARCHAR (128)  NOT NULL,
    [FXRateName]      VARCHAR (64)   NULL,
    [Hash]            VARBINARY (64) NOT NULL,
    CONSTRAINT [PK_FXRateID] PRIMARY KEY CLUSTERED ([PK_FXRateNameID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_FXRateName_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];

