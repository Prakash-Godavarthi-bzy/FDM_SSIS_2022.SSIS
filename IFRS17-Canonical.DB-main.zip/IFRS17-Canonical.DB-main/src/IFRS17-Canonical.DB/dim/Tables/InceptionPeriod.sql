﻿CREATE TABLE [dim].[InceptionPeriod] (
    [PK_MOIID]        INT         NOT NULL,
    [MOI]             INT         NULL,
    [InceptionPeriod] VARCHAR (6) NULL,
    CONSTRAINT [PK_MOIID] PRIMARY KEY CLUSTERED ([PK_MOIID] ASC) WITH (FILLFACTOR = 90) ON [DATA]
) ON [DATA];

