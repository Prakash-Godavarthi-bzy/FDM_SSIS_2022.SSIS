﻿CREATE TABLE [dim].[DataSet] (
    [PK_DataSetID]    BIGINT         IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID] TINYINT        NOT NULL,
    [SourceKey]       VARCHAR (128)  NOT NULL,
    [DataSet]         VARCHAR (64)   NULL,
    [SourceSystem]    VARCHAR (32)   NULL,
    [GrossRI]         VARCHAR (16)   NULL,
    [Hash]            VARBINARY (64) NOT NULL,
    CONSTRAINT [PK_DataSetID] PRIMARY KEY CLUSTERED ([PK_DataSetID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_DataSet_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];






GO
CREATE UNIQUE NONCLUSTERED INDEX [NCI_DataSet]
    ON [dim].[DataSet]([FK_DataSourceID] ASC, [SourceKey] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];






GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Data Set', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'DataSet';

