﻿CREATE TABLE [dim].[PolicySection] (
    [PK_PolicySectionID] BIGINT         IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID]    TINYINT        NOT NULL,
    [SourceKey]          VARCHAR (128)  NULL,
    [PolicyReference]    VARCHAR (32)   NOT NULL,
    [SectionReference]   VARCHAR (32)   NULL,
    [InceptionDate]      DATE           NULL,
    [ExpiryDate]         DATE           NULL,
    [BindDate]           DATE           NULL,
    [PolicyType]         VARCHAR (10)   NULL,
    [FDMKey]             BIGINT         NULL,
    [Hash]               VARBINARY (64) NOT NULL,
    CONSTRAINT [PK_PolicySectionID] PRIMARY KEY CLUSTERED ([PK_PolicySectionID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_PolicySection_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];






GO
CREATE UNIQUE NONCLUSTERED INDEX [NCI_PolicySection]
    ON [dim].[PolicySection]([FK_DataSourceID] ASC, [SourceKey] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];




GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Policy Section', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'PolicySection';

