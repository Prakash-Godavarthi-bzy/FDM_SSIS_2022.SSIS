﻿CREATE TABLE [dim].[Run] (
    [PK_RunID]        BIGINT         IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID] TINYINT        NOT NULL,
    [SourceKey]       VARCHAR (128)  NOT NULL,
    [RunID]           BIGINT         NOT NULL,
    [RunType]         VARCHAR (25)   NOT NULL,
    [RunDescription]  VARCHAR (500)  NULL,
    [ReportingPeriod] INT            NULL,
    [Hash]            VARBINARY (64) NOT NULL,
    CONSTRAINT [PK_RunID] PRIMARY KEY CLUSTERED ([PK_RunID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_Run_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];




GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Psicle Run', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'Run';

