﻿CREATE TABLE [dim].[YOA] (
    [PK_YOAID]        SMALLINT       IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID] TINYINT        NOT NULL,
    [SourceKey]       VARCHAR (128)  NOT NULL,
    [YOA]             VARCHAR (8)    NULL,
    [Hash]            VARBINARY (64) NOT NULL,
    CONSTRAINT [PK_YOAID] PRIMARY KEY CLUSTERED ([PK_YOAID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_YOA_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];


GO
CREATE UNIQUE NONCLUSTERED INDEX [NCI_YOA]
    ON [dim].[YOA]([FK_DataSourceID] ASC, [SourceKey] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'YOA', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'YOA';

