﻿CREATE TABLE [dim].[RIPolicy] (
    [PK_RIPolicyID]    INT            IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID]  TINYINT        NOT NULL,
    [SourceKey]        VARCHAR (128)  NULL,
    [RIPolicyTypeCode] VARCHAR (16)   NULL,
    [RIPolicyTypeName] VARCHAR (32)   NULL,
    [RIProgrammeCode]  VARCHAR (16)   NULL,
    [RIProgrammeName]  VARCHAR (64)   NULL,
    [RIAdjustment]     VARCHAR (8)    NULL,
    [Hash]             VARBINARY (64) NOT NULL,
    [RIPolicyNumber]   VARCHAR (128)  NULL,
    CONSTRAINT [PK_RIPolicyID] PRIMARY KEY CLUSTERED ([PK_RIPolicyID] ASC) WITH (FILLFACTOR = 90) ON [DATA]
) ON [DATA];








GO
CREATE UNIQUE NONCLUSTERED INDEX [NCI_RIPolicy]
    ON [dim].[RIPolicy]([FK_DataSourceID] ASC, [SourceKey] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];


GO
CREATE NONCLUSTERED INDEX [NCI_RIPolicy_FK_DataSourceID_Hash]
    ON [dim].[RIPolicy]([FK_DataSourceID] ASC, [Hash] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];

