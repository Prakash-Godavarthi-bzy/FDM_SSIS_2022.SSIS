﻿CREATE TABLE [dim].[SourceSystem] (
    [PK_SourceSystemID] SMALLINT     IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID] TINYINT NOT NULL,
    [SourceKey]       VARCHAR (128)  NOT NULL,
    [SourceSystem]      VARCHAR (48) NOT NULL,
    [Hash]      VARBINARY (64)  NOT NULL,
    CONSTRAINT [PK_SourceSystemID] PRIMARY KEY CLUSTERED ([PK_SourceSystemID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_SourceSystem_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];

GO
CREATE UNIQUE NONCLUSTERED INDEX [NCI_SourceSystem]
    ON [dim].[SourceSystem]([FK_DataSourceID] ASC, [SourceKey] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];

GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Source System', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'SourceSystem';

