﻿CREATE TABLE [dim].[FXRateSelector] (
    [FXRate] NUMERIC (7, 4) NULL
);

