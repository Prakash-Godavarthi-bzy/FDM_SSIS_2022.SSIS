﻿CREATE TABLE [dim].[CedePercentages] (
    [PK_CedePercentagesID] SMALLINT        IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID]      TINYINT         NOT NULL,
    [YOA]                  VARCHAR (16)    NULL,
    [SourceProgramme]      VARCHAR (250)   NULL,
    [CedePercentage]       NUMERIC (19, 8) NULL,
    [EntityCode]           VARCHAR (50)    NULL,
    [Hash]                 VARBINARY (64)  NOT NULL,
    CONSTRAINT [PK_CedePercentagesID] PRIMARY KEY CLUSTERED ([PK_CedePercentagesID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_CedePercentage_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];

