﻿CREATE TABLE [dim].[AssumptionDataset] (
    [PK_AssumptionDatasetNameID]   INT            IDENTITY (1, 1) NOT NULL,
    [AssumptionDatasetName]        NVARCHAR (35)  NULL,
    [AssumptionDatasetDescription] NVARCHAR (255) NULL,
    [AssumptionPercentageTypeID]   INT            NULL,
    [IsDatasetAlreadyUsed]         INT            NULL,
    [CreatedDt]                    DATETIME       NULL,
    [CreatedBy]                    NVARCHAR (150) NULL,
    [UpdatedDt]                    DATETIME       NULL,
    [UpdatedBy]                    NVARCHAR (150) NULL,
    CONSTRAINT [PK_AssumptionDatasetNameID] PRIMARY KEY CLUSTERED ([PK_AssumptionDatasetNameID] ASC) WITH (FILLFACTOR = 90) ON [DATA]
) ON [DATA];


GO
CREATE UNIQUE NONCLUSTERED INDEX [NCI_AssumptionDataset]
    ON [dim].[AssumptionDataset]([AssumptionDatasetName] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Assumption Dataset', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'AssumptionDataset';

