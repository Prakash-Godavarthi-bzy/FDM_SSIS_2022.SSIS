﻿CREATE TABLE [dim].[RateScenario] (
    [PK_RateScenarioID] SMALLINT       IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID]   TINYINT        NOT NULL,
    [SourceKey]         VARCHAR (128)  NOT NULL,
    [RateCode]          VARCHAR (128)  NOT NULL,
    [RateName]          VARCHAR (128)  NOT NULL,
    [RateGroup]         VARCHAR (128)  NOT NULL,
    [Locked]            VARCHAR (1)    NOT NULL,
    [SortOrder]         INT            NULL,
    [Hash]              VARBINARY (64) NOT NULL,
    CONSTRAINT [PK_RateScenarioID] PRIMARY KEY CLUSTERED ([PK_RateScenarioID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_RateScenario_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];

