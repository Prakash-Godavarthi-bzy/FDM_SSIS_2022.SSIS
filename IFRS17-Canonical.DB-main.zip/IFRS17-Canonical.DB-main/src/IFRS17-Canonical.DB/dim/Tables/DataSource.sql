﻿CREATE TABLE [dim].[DataSource] (
    [PK_DataSourceID] TINYINT NOT NULL,
    [DataSource]      VARCHAR (48) NOT NULL,
    CONSTRAINT [PK_DataSourceID] PRIMARY KEY CLUSTERED ([PK_DataSourceID] ASC) WITH (FILLFACTOR = 90) ON [DATA]
) ON [DATA];

GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Data Source', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'DataSource';
