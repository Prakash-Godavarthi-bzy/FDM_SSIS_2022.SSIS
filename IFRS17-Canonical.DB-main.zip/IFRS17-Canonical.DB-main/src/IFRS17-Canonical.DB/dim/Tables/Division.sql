﻿CREATE TABLE [dim].[Division] (
    [PK_DivisionID]   BIGINT         IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID] TINYINT        NOT NULL,
    [DivisionName]    VARCHAR (50)   NULL,
    [Hash]            VARBINARY (64) NOT NULL,
    CONSTRAINT [PK_DivisionID] PRIMARY KEY CLUSTERED ([PK_DivisionID] ASC) WITH (FILLFACTOR = 90) ON [DATA]
) ON [DATA];

