﻿CREATE TABLE [dim].[Currency] (
    [PK_CurrencyID]   BIGINT         IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID] TINYINT        NOT NULL,
    [SourceKey]       VARCHAR (128)  NOT NULL,
    [CurrencyCode]    CHAR (3)       NULL,
    [CurrencyName]    VARCHAR (16)   NULL,
    [Hash]            VARBINARY (64) NOT NULL,
    CONSTRAINT [PK_CurrencyID] PRIMARY KEY CLUSTERED ([PK_CurrencyID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_Currency_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];




GO
CREATE UNIQUE NONCLUSTERED INDEX [NCI_Currency]
    ON [dim].[Currency]([FK_DataSourceID] ASC, [SourceKey] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];







GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Currency', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'Currency';

