﻿CREATE TABLE [dim].[RIProgramme] (
    [PK_RIProgrammeID] BIGINT         IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID]  TINYINT        NOT NULL,
    [SourceKey]        VARCHAR (128)  NOT NULL,
    [ProgrammeName]    VARCHAR (64)   NULL,
    [Hash]             VARBINARY (64) NOT NULL,
    PRIMARY KEY CLUSTERED ([PK_RIProgrammeID] ASC) WITH (FILLFACTOR = 90)
);

