﻿CREATE TABLE [dim].[FDMGroupShare] (
    [Pk_GroupShareID]      INT              IDENTITY (1, 1) NOT NULL,
    [FK_EntityID]          INT              NOT NULL,
    [FK_YOAID]             SMALLINT         NOT NULL,
    [YOA]                  VARCHAR (128)    NOT NULL,
    [GroupSharePercentage] NUMERIC (38, 10) NOT NULL,
    CONSTRAINT [Pk_GroupShareID] PRIMARY KEY CLUSTERED ([Pk_GroupShareID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_FDMGroupShare_EntityID] FOREIGN KEY ([FK_EntityID]) REFERENCES [dim].[DimEntity] ([PK_EntityID]),
    CONSTRAINT [FK_FDMGroupShare_YOAID] FOREIGN KEY ([FK_YOAID]) REFERENCES [dim].[YOA] ([PK_YOAID])
) ON [DATA];






GO
CREATE NONCLUSTERED INDEX [NCI_FDMGroupShare]
    ON [dim].[FDMGroupShare]([FK_EntityID] ASC, [FK_YOAID] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];

