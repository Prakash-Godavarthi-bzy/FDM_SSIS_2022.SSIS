﻿CREATE TABLE [dim].[Position] (
    [PK_PositionID]   SMALLINT       IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID] TINYINT        NOT NULL,
    [SourceKey]       VARCHAR (128)  NOT NULL,
    [Position]        VARCHAR (128)   NOT NULL,
    [Hash]            VARBINARY (64) NOT NULL,
    CONSTRAINT [PK_PositionID] PRIMARY KEY CLUSTERED ([PK_PositionID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_Position_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Position', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'Position';

