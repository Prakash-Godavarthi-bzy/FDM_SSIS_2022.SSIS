﻿CREATE TABLE [dim].[ProcessIFRS17] (
    [PK_ProcessIFRS17ID]      SMALLINT       IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID]         TINYINT        NOT NULL,
    [SourceKey]               VARCHAR (128)  NOT NULL,
    [ProcessCode]             VARCHAR (10)   NOT NULL,
    [ProcessName]             VARCHAR (32)   NULL,
    [ProcessLevel1]           VARCHAR (32)   NULL,
    [ProcessLevel2]           VARCHAR (32)   NULL,
    [ProcessLevel3]           VARCHAR (32)   NULL,
    [CurrentAccountingPeriod] INT            NULL,
    [Hash]                    VARBINARY (64) NOT NULL,
    CONSTRAINT [PK_ProcessIFRS17ID] PRIMARY KEY CLUSTERED ([PK_ProcessIFRS17ID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_ProcessIFRS17_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];






GO
CREATE UNIQUE NONCLUSTERED INDEX [NCI_ProcessIFRS17]
    ON [dim].[ProcessIFRS17]([FK_DataSourceID] ASC, [SourceKey] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];




GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Process (TechnicalHub)', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'ProcessIFRS17';

