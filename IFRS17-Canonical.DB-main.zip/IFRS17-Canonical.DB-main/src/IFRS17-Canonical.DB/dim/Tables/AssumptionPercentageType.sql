﻿CREATE TABLE [dim].[AssumptionPercentageType] (
    [PK_AssumptionPercentageTypeID] SMALLINT       IDENTITY (1, 1) NOT NULL,
    [AssumptionPercentageType]      NVARCHAR (35)  NULL,
    [HelpLink]                      NVARCHAR (255) NULL,
    CONSTRAINT [PK_AssumptionPercentageTypeID] PRIMARY KEY CLUSTERED ([PK_AssumptionPercentageTypeID] ASC) WITH (FILLFACTOR = 90) ON [DATA]
) ON [DATA];


GO
CREATE UNIQUE NONCLUSTERED INDEX [NCI_AssumptionPercentageType]
    ON [dim].[AssumptionPercentageType]([AssumptionPercentageType] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Assumption Type', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'AssumptionPercentageType';

