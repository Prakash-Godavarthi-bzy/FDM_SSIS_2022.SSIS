﻿CREATE TABLE [dim].[UnitOfAccount] (
    [PK_UnitOfAccountID] SMALLINT       IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID]    TINYINT        NOT NULL,
    [SourceKey]          VARCHAR (128)  NOT NULL,
    [UnitOfAccount]      VARCHAR (64)   NOT NULL,
    [Hash]               VARBINARY (64) NOT NULL,
    CONSTRAINT [PK_UnitOfAccountID] PRIMARY KEY CLUSTERED ([PK_UnitOfAccountID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_UnitOfAccount_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'UnitOfAccount', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'UnitOfAccount';

