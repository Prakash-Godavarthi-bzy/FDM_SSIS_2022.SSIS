﻿CREATE TABLE [dim].[Statement] (
    [PK_StatementID]  SMALLINT       IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID] TINYINT        NOT NULL,
    [SourceKey]       VARCHAR (128)  NOT NULL,
    [Statement]       VARCHAR (16)   NOT NULL,
    [Hash]            VARBINARY (64) NOT NULL,
    CONSTRAINT [PK_StatementID] PRIMARY KEY CLUSTERED ([PK_StatementID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_Statement_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Statement', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'Statement';

