﻿CREATE TABLE [dim].[DimCurrency] (
    [PK_CurrencyID] INT           NOT NULL,
    [CurrencyCode]  VARCHAR (254) NULL,
    [CurrencyName]  VARCHAR (16)  NULL,
    PRIMARY KEY CLUSTERED ([PK_CurrencyID] ASC) WITH (FILLFACTOR = 90)
);

