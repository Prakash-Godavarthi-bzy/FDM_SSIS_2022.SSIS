﻿CREATE TABLE [dim].[DataStage] (
    [PK_DataStageID]  BIGINT         IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID] TINYINT        NOT NULL,
    [SourceKey]       VARCHAR (128)  NOT NULL,
    [DataStage]       VARCHAR (64)   NULL,
    [Hash]            VARBINARY (64) NULL,
    CONSTRAINT [PK_DataStageID] PRIMARY KEY CLUSTERED ([PK_DataStageID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_DataStage_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];




GO
CREATE UNIQUE NONCLUSTERED INDEX [NCI_DataStage]
    ON [dim].[DataStage]([FK_DataSourceID] ASC, [SourceKey] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Data Stage', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'DataStage';

