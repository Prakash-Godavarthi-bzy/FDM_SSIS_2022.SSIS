﻿CREATE TABLE [dim].[AccountingPeriod] (
    [PK_AccountingPeriodID]        INT NOT NULL,
    [AccountingPeriod]             AS  (CONVERT([char](6),[PK_AccountingPeriodID])) PERSISTED,
    [AccountingYear]               AS  (CONVERT([smallint],floor([PK_AccountingPeriodID]/(100)))) PERSISTED,
    [AccountingMonth]              AS  (CONVERT([tinyint],[PK_AccountingPeriodID]%(100))) PERSISTED,
    [AccountingMonthName]          AS  (right('00'+CONVERT([varchar],[PK_AccountingPeriodID]%(100)),(2))) PERSISTED,
    [AccountingQuarter]            AS  ((CONVERT([char](4),floor([PK_AccountingPeriodID]/(100)))+CONVERT([char](1),'Q'))+CONVERT([char](1),ceiling(([PK_AccountingPeriodID]%(100))/(3.0)))) PERSISTED,
    [AccountingHalf]               AS  ((CONVERT([char](4),floor([PK_AccountingPeriodID]/(100)))+CONVERT([char](1),'H'))+CONVERT([char](1),ceiling(([PK_AccountingPeriodID]%(100))/(6.0)))) PERSISTED,
    [AccountingQuarterLastPeriod] AS  (CONVERT([char](6),floor([PK_AccountingPeriodID]/(100))*(100)+((case when [PK_AccountingPeriodID]%(100)>(12) then (12) when [PK_AccountingPeriodID]%(100)=(0) then (1) else [PK_AccountingPeriodID]%(100) end+(2))/(3))*(3))) PERSISTED,
    CONSTRAINT [PK_AccountingPeriodID] PRIMARY KEY CLUSTERED ([PK_AccountingPeriodID] ASC) WITH (FILLFACTOR = 90) ON [DATA]
) ON [DATA];













GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Accounting Period', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'AccountingPeriod';


GO
EXECUTE sp_addextendedproperty @name = N'GrowthProxy', @value = N'yyyymm', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'AccountingPeriod', @level2type = N'COLUMN', @level2name = N'PK_AccountingPeriodID';

