﻿CREATE TABLE [dim].[ProgrammeCode] (
    [PK_ProgrammeCode] INT            IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID]  TINYINT        NOT NULL,
    [SourceKey]        BIGINT         NOT NULL,
    [ProgrammeCode]    VARCHAR (100)  NULL,
    [Hash]             VARBINARY (64) NOT NULL,
    CONSTRAINT [FK_ProgrammeCode_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
);

