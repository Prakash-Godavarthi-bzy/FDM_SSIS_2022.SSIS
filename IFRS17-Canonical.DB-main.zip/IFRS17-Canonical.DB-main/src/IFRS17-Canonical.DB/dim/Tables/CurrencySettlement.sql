﻿CREATE TABLE [dim].[CurrencySettlement] (
    [PK_CurrencySettlementID] BIGINT   IDENTITY (1, 1) NOT NULL,
    [CurrencyCode]            CHAR (3) NULL,
    CONSTRAINT [PK_CurrencySettlementID] PRIMARY KEY CLUSTERED ([PK_CurrencySettlementID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [UC_CurrencySettlement_CurrencyCode] UNIQUE NONCLUSTERED ([CurrencyCode] ASC) WITH (FILLFACTOR = 90) ON [INDEXES]
) ON [DATA];



