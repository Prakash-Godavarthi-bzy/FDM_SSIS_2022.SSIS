﻿CREATE TABLE [dim].[TrifocusMapping] (
    [Pk_TrifocusMappingID] BIGINT         IDENTITY (1, 1) NOT NULL,
    [SourceKey]            VARCHAR (128)  NULL,
    [FK_DataSourceID]      TINYINT        NOT NULL,
    [Fk_TrifocusID]        SMALLINT       NULL,
    [TrifocusCode]         VARCHAR (16)   NOT NULL,
    [TrifocusName]         NVARCHAR (64)  NULL,
    [FK_RunID]             BIGINT         NOT NULL,
    [FK_FocusGroupID]      BIGINT         NULL,
    [FK_DivisionID]        BIGINT         NULL,
    [Hash]                 VARBINARY (64) NOT NULL,
    CONSTRAINT [Pk_TrifocusMappingID] PRIMARY KEY CLUSTERED ([Pk_TrifocusMappingID] ASC) WITH (FILLFACTOR = 90) ON [DATA]
) ON [DATA];






GO
CREATE NONCLUSTERED INDEX [NCI_TrifocusMapping_TrifocusCode_RunID]
    ON [dim].[TrifocusMapping]([TrifocusCode] ASC, [FK_RunID] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90)
    ON [DATA];


GO
CREATE NONCLUSTERED INDEX [NCI_TrifocusMapping_DivisionID_Trifocus_RunID_FocusGroup]
    ON [dim].[TrifocusMapping]([FK_DivisionID] ASC)
    INCLUDE([TrifocusCode], [FK_RunID], [FK_FocusGroupID]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90)
    ON [DATA];


GO


