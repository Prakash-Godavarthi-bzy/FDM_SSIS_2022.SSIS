﻿CREATE TABLE [dim].[AccountICE] (
    [PK_AccountICEID] SMALLINT       IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID] TINYINT        NOT NULL,
    [SourceKey]       VARCHAR (128)  NOT NULL,
    [AccountICE]      VARCHAR (16)   NULL,
    [Hash]            VARBINARY (64) NOT NULL,
    CONSTRAINT [PK_AccountICEID] PRIMARY KEY CLUSTERED ([PK_AccountICEID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_AccountICE_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];


GO
EXECUTE sp_addextendedproperty @name = N'business_key', @value = N'True', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'AccountICE', @level2type = N'COLUMN', @level2name = N'AccountICE';


GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Account (ICE)', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'AccountICE';

