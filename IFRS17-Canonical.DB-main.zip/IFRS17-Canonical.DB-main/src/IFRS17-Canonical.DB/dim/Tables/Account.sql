﻿CREATE TABLE [dim].[Account] (
    [PK_AccountID]       SMALLINT       IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID] TINYINT NOT NULL,
    [SourceKey]          VARCHAR (128)  NOT NULL,
    [AccountCode]        NVARCHAR (16)  NULL,
    [AccountName]        NVARCHAR (128) NULL,
    [AccountGroup]       NVARCHAR (128) NULL,
    [AccountIsMoney]     BIT            NULL,
    [AccountIsSnapshot]  BIT            NULL,
    [FormatString]       NVARCHAR (16)  NULL,
    [ExcludeFromFXCalcs] BIT            NULL,
    [Closed]             BIT            NULL,
    [Hash]      VARBINARY (64)  NOT NULL,
    CONSTRAINT [PK_AccountID] PRIMARY KEY CLUSTERED ([PK_AccountID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_Account_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];



GO
CREATE UNIQUE NONCLUSTERED INDEX [NCI_Account]
    ON [dim].[Account]([FK_DataSourceID] ASC, [SourceKey] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];




GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Account (GAAP)', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'Account';


GO
EXECUTE sp_addextendedproperty @name = N'business_key', @value = N'True', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'Account', @level2type = N'COLUMN', @level2name = N'AccountCode';

