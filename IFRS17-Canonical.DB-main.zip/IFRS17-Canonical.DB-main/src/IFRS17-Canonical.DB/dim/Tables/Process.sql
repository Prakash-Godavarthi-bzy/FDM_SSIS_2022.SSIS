﻿CREATE TABLE [dim].[Process] (
    [PK_ProcessID]    SMALLINT     IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID] TINYINT NOT NULL,
    [SourceKey]       VARCHAR (128)  NOT NULL,
    [ProcessCode]     CHAR (2)     NULL,
    [ProcessName]     VARCHAR (64) NULL,
    [FK_ScenarioID]   SMALLINT     NULL,
    [ProcessCategory] CHAR (2)     NOT NULL,
    [Hash]      VARBINARY (64)  NOT NULL,
    CONSTRAINT [PK_ProcessID] PRIMARY KEY CLUSTERED ([PK_ProcessID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_Process_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];

GO
CREATE UNIQUE NONCLUSTERED INDEX [NCI_Process]
    ON [dim].[Process]([FK_DataSourceID] ASC, [SourceKey] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];

GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Process', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'Process';

