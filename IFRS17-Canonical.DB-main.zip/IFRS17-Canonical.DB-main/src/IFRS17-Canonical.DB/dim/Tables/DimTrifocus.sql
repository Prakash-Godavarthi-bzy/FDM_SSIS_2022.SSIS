﻿CREATE TABLE [dim].[DimTrifocus] (
    [PK_TrifocusID]     INT           NOT NULL,
    [TrifocusCode]      VARCHAR (16)  NOT NULL,
    [TriFocusName]      NVARCHAR (64) NULL,
    [TriFocusLevel1]    NVARCHAR (64) NULL,
    [TriFocusLevel2]    NVARCHAR (64) NULL,
    [TriFocusLevel3]    NVARCHAR (64) NULL,
    [TrifocusGroup]     VARCHAR (8)   NULL,
    [IsUSTrifocus]      BIT           NULL,
    [IsKrReTrifocus]    BIT           NULL,
    [IsUSSyndTrifocus]  BIT           NULL,
    [IsSLInternational] BIT           NULL,
    [status]            VARCHAR (8)   NULL,
    [TrifocusTypeCode]  CHAR (1)      NULL,
    [TrifocusTypeDesc]  VARCHAR (16)  NULL,
    PRIMARY KEY CLUSTERED ([PK_TrifocusID] ASC) WITH (FILLFACTOR = 90)
);

