﻿CREATE TABLE [dim].[Entity] (
    [PK_EntityID]             BIGINT         IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID]         TINYINT        NOT NULL,
    [SourceKey]               VARCHAR (128)  NOT NULL,
    [EntityCode]              VARCHAR (16)   NOT NULL,
    [EntityName]              NVARCHAR (64)  NULL,
    [Platform]                VARCHAR (5)    NULL,
    [EntityLevel1]            NVARCHAR (32)  NULL,
    [EntityLevel2]            NVARCHAR (32)  NULL,
    [EntityLevel3]            NVARCHAR (32)  NULL,
    [EntityLevel4]            NVARCHAR (32)  NULL,
    [EntityLevel5]            NVARCHAR (32)  NULL,
    [Status]                  CHAR (1)       NULL,
    [FK_FunctionalCurrencyID] BIGINT         NULL,
    [ExcludeFromFXCalcs]      BIT            NULL,
    [TargetEntityIdentifier]  BIT            NULL,
    [Hash]                    VARBINARY (64) NOT NULL,
    CONSTRAINT [PK_EntityID] PRIMARY KEY CLUSTERED ([PK_EntityID] ASC) WITH (FILLFACTOR = 90) ON [DATA],
    CONSTRAINT [FK_Entity_DataSourceID] FOREIGN KEY ([FK_DataSourceID]) REFERENCES [dim].[DataSource] ([PK_DataSourceID])
) ON [DATA];










GO
CREATE UNIQUE NONCLUSTERED INDEX [NCI_Entity]
    ON [dim].[Entity]([FK_DataSourceID] ASC, [SourceKey] ASC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [INDEXES];




GO
EXECUTE sp_addextendedproperty @name = N'nice_name', @value = N'Entity', @level0type = N'SCHEMA', @level0name = N'dim', @level1type = N'TABLE', @level1name = N'Entity';

