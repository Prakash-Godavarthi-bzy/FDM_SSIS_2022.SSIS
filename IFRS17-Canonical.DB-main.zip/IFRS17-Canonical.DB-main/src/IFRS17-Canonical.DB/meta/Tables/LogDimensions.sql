﻿CREATE TABLE [meta].[LogDimensions] (
    [PK_LogID]              INT           IDENTITY (1, 1) NOT NULL,
    [Dimension]             [sysname]     NOT NULL,
    [DataSource]            VARCHAR (128) NULL,
    [ExecutionInstanceGUID] VARCHAR (128) NULL,
    [DateTime]              DATETIME      DEFAULT (getdate()) NULL
) ON [META];

