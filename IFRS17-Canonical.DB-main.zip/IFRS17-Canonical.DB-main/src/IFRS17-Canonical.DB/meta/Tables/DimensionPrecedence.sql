﻿CREATE TABLE [meta].[DimensionPrecedence] (
    [PK_DimensionPrecedence] INT           IDENTITY (1, 1) NOT NULL,
    [Dimension]              [sysname]     NOT NULL,
    [Column]                 [sysname]     NOT NULL,
    [DataSource]             VARCHAR (128) NOT NULL,
    [Precedence]             TINYINT       NOT NULL,
    CONSTRAINT [PK_DimensionPrecedence] PRIMARY KEY CLUSTERED ([PK_DimensionPrecedence] ASC) WITH (FILLFACTOR = 90) ON [INDEXES]
) ON [INDEXES];




GO


