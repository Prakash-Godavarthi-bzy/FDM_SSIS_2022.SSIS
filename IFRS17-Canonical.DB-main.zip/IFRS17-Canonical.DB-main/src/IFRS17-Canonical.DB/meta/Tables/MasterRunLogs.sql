﻿CREATE TABLE [meta].[MasterRunLogs] (
    [Pk_MasterRunID]    INT           IDENTITY (1, 1) NOT NULL,
    [ExecutionID]       INT           NULL,
    [MasterPackageName] VARCHAR (128) NOT NULL,
    [Status]            VARCHAR (12)  DEFAULT ('Pending') NULL,
    [StartTime]         DATETIME2 (7) DEFAULT (getdate()) NULL,
    [EndTime]           DATETIME2 (7) NULL,
    CONSTRAINT [Pk_MasterRunID] PRIMARY KEY CLUSTERED ([Pk_MasterRunID] ASC) WITH (FILLFACTOR = 90)
);

