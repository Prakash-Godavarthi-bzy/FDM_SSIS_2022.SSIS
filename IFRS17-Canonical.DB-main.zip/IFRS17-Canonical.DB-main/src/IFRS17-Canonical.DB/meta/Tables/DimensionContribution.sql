﻿CREATE TABLE [meta].[DimensionContribution] (
    [PK_DimensionContribution] BIGINT        IDENTITY (1, 1) NOT NULL,
    [FK_DimensionPrecedence]   INT           NOT NULL,
    [ExecutionGUID]            VARCHAR (128) NOT NULL,
    [DateTime]                 DATETIME      NOT NULL,
    CONSTRAINT [PK_DimensionContribution] PRIMARY KEY CLUSTERED ([PK_DimensionContribution] ASC) WITH (FILLFACTOR = 90) ON [INDEXES]
) ON [INDEXES];



