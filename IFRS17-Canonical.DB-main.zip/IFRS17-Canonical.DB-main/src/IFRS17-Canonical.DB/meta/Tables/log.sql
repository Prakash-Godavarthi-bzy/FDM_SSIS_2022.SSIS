﻿CREATE TABLE [meta].[log] (
    [Task]   VARCHAR (128) NOT NULL,
    [Start]  DATETIME      NOT NULL,
    [Finish] DATETIME      NULL
);



