﻿CREATE TABLE [meta].[ChildRunLogs] (
    [Pk_RunID]       INT           IDENTITY (1, 1) NOT NULL,
    [RunID]          INT           NOT NULL,
    [PackageName]    VARCHAR (128) NOT NULL,
    [Status]         VARCHAR (12)  DEFAULT ('Pending') NULL,
    [ErrorMessage]   VARCHAR (MAX) NULL,
    [StartTime]      DATETIME2 (7) DEFAULT (getdate()) NULL,
    [EndTime]        DATETIME2 (7) NULL,
    [Fk_MasterRunID] INT           NULL,
    CONSTRAINT [Fk_MasterRunID] FOREIGN KEY ([Fk_MasterRunID]) REFERENCES [meta].[MasterRunLogs] ([Pk_MasterRunID])
);

