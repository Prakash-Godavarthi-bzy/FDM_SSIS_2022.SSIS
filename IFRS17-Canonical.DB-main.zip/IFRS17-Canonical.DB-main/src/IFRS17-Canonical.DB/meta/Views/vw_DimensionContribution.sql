﻿/*

Author:		Michael Sode
Date:		16 June 2022
Purpose:	The contribution state for dimension attributes.
			Rules stored in [meta].[DimensionPrecedence] determine how dimension attributes are updated from various data sources.
			This allows us to build up the richest and best described dimensnion members with consideration to the different data sources.

*/
CREATE VIEW meta.vw_DimensionContribution
AS

SELECT	*
FROM	[meta].[DimensionContribution] dc
JOIN	[meta].[DimensionPrecedence] dp
ON		dc.FK_DimensionPrecedence = dp.PK_DimensionPrecedence;