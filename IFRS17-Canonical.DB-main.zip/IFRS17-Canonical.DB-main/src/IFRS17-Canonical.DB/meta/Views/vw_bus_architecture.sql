﻿
/*

Author:		Michael Sode
Date:		16 June 2022
Purpose:	Returns attributes for a bus architecture including nice names from extended attributes.
			Uses the following extended attributes;
			source_catalogue: Applies to tables and is the database from which the table is populated
			source_schema:  Applies to tables and is the schema from which the table is populated
			source_table:  Applies to tables and is the table from which the table is populated
			nice_name: Applies to tables and columns and is the nice name to use in reports

*/
CREATE VIEW [meta].[vw_bus_architecture]
AS

SELECT	fk.name AS ForeignKeyName
		,oc.name AS FactTable
		,oref.name AS DimTable
		,CAST(xdatabase.value AS SYSNAME) AS FactDatabaseName
		,CAST(xschema.value AS SYSNAME) AS FactSchemaName
		,CAST(xtable.value AS SYSNAME) AS FactTableName

		,CAST(xfnn.value AS SYSNAME) AS FactNiceName
		,CAST(xdnn.value AS SYSNAME) AS DimNiceName

		,fkc.name AS FKColumnName
		,CAST(xffknn.value AS SYSNAME) AS DimRoleNiceName
		-- ,c.constraint_column_id
		-- ,fkc.*
FROM	sys.foreign_keys fk
JOIN	sys.tables ft
ON		ft.object_id = fk.parent_object_id
JOIN	sys.objects oc
ON		oc.object_id = fk.parent_object_id
JOIN	sys.objects oref
ON		oref.object_id = fk.referenced_object_id

LEFT OUTER JOIN	sys.extended_properties xdatabase
ON		xdatabase.major_id = oc.object_id
AND		xdatabase.minor_id = 0
AND		xdatabase.name = 'source_catalogue'
LEFT OUTER JOIN	sys.extended_properties xschema
ON		xschema.major_id = oc.object_id
AND		xschema.minor_id = 0
AND		xschema.name = 'source_schema'
LEFT OUTER JOIN	sys.extended_properties xtable
ON		xtable.major_id = oc.object_id
AND		xtable.minor_id = 0
AND		xtable.name = 'source_table'

LEFT OUTER JOIN	sys.extended_properties xfnn
ON		xfnn.major_id = oc.object_id
AND		xfnn.minor_id = 0
AND		xfnn.name = 'nice_name'

LEFT OUTER JOIN	sys.extended_properties xdnn
ON		xdnn.major_id = oref.object_id
AND		xdnn.minor_id = 0
AND		xdnn.name = 'nice_name'

-- Get the FK column so we can get extended properties
LEFT OUTER JOIN	sys.foreign_key_columns c
ON		c.constraint_object_id = fk.object_id

LEFT OUTER JOIN	sys.columns fkc
ON		fkc.column_id = c.parent_column_id
AND		fkc.object_id = ft.object_id

LEFT OUTER JOIN	sys.extended_properties xffknn
ON		xffknn.major_id = fkc.object_id
AND		xffknn.minor_id = fkc.column_id
AND		xffknn.name = 'nice_name'

WHERE	fk.type_desc = 'FOREIGN_KEY_CONSTRAINT'
AND		oref.name != 'DataSource'