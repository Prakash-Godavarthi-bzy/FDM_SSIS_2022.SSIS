﻿
/*

Author:		Michael Sode
Date:		16 June 2022
Purpose:	Calcuates the estimated growth of the DB over time based on data volumes by a temporal or proxy attribute (such as accounting period).
			Tables with no temporal attribute may have a growth correlation to a table that does have a temporal attribute (eg; A policy dimension will have a correlation to a fact table referencing it)
			The sizing includes heaps, clustered and non-clustered indexes.
*/
CREATE PROCEDURE [meta].[usp_GrowthCalculate]
AS
BEGIN

	-- The number of months to sample to estimate growth
	DECLARE @SamplePeriodMonths INT = 12;

	DECLARE @Growth TABLE
	(  
	SchemaName SYSNAME
	,TableName SYSNAME
	,ColumnName SYSNAME
	,Type VARCHAR(100)
	);

	-- Use extended properties for the column in each table to use as a proxy to estimate growth (where applicable)
	-- This should be a column that is temporal or a reasonable proxy for temporality; ie; a data column or something like an accounting period
	INSERT INTO @Growth (
	SchemaName
	,TableName
	,ColumnName
	,Type
	)
	SELECT	s.name AS SchemaName
			,t.name AS TableName
			,c.name AS ColumnName
			,CAST(x.value AS VARCHAR(100)) AS Type
	FROM	sys.extended_properties x
	JOIN	sys.columns c
	ON		c.object_id = x.major_id
	AND		c.column_id = x.minor_id
	JOIN	sys.tables t
	ON		t.object_id = x.major_id
	JOIN	sys.schemas s
	ON		s.schema_id = t.schema_id
	WHERE	x.name = 'GrowthProxy';



	DECLARE @Indirect TABLE
	(
	SchemaName SYSNAME
	,TableName SYSNAME
	,IndirectSchemaName SYSNAME
	,IndirectTableName SYSNAME
	,Correlation NUMERIC(10,8)
	);

	/*
	INSERT INTO @Indirect (
	SchemaName
	,TableName
	,IndirectSchemaName
	,IndirectTableName
	,Correlation
	)
	*/

	/*
	-- For TechnicalHub
	VALUES('dim','PolicySection','fct','TechnicalResult',1)
	,('dim','PolicySection_History','fct','TechnicalResult',1)
	,('dim','Policy','fct','TechnicalResult',1)
	,('dim','Policy_History','fct','TechnicalResult',1)
	;
	*/

	-- For FDM
	-- VALUES ('dbo','DimPolicySectionV2','dbo','FactFDM',1);


	/*
	-- For IFRS17DataMart
	VALUES('Dim','Policy','fct','TechnicalResult_ADM',1)
	,('Dim','PolicySection','stg','fct_TechnicalResult',1)
	,('stg','dim_PolicySection','stg','fct_TechnicalResult',1)
	;
	*/

	DECLARE @Monthly TABLE
	(
	SchemaName SYSNAME
	,TableName SYSNAME
	,[RowCount] BIGINT
	);

	/*
	-- TechnicalHub
	-- Adhoc inserts for stuff that is harder to automate
	INSERT INTO @monthly
	(
	SchemaName
	,TableName
	,[RowCount]
	)
	VALUES ('fct','TechnicalResult',(SELECT COUNT(*) FROM fct.TechnicalResult f JOIN dim.YOA d ON d.PK_YOA = f.FK_YOA WHERE d.BK_YOA = '2018'));
	*/

	DECLARE @SchemaName SYSNAME
	,@TableName SYSNAME
	,@ColumnName SYSNAME
	,@Type VARCHAR(100)

	DECLARE @From NVARCHAR(MAX)
	,@To NVARCHAR(MAX)
	,@Result BIGINT;

	DECLARE @sql NVARCHAR(MAX);

	DECLARE GrowthCursor CURSOR FOR
	SELECT	SchemaName
			,TableName
			,ColumnName
			,Type
	FROM	@growth;

	OPEN GrowthCursor;

	FETCH NEXT FROM GrowthCursor INTO @SchemaName, @TableName, @ColumnName, @Type;

	WHILE @@FETCH_STATUS = 0
	BEGIN
	IF @Type = 'yyyymm'
	BEGIN
	-- Get max period
	SET @sql = N'SELECT @to = MAX([' + @ColumnName + ']) FROM [' + @SchemaName + '].[' + @TableName + '];';
	EXECUTE sp_executesql @sql, N'@to NVARCHAR(MAX) OUTPUT', @To = @To OUTPUT;

	-- Get min period
	SET @From = CONVERT(CHAR(6),DATEADD(MONTH,-@SamplePeriodMonths,DATEFROMPARTS(SUBSTRING(@To,1,4),SUBSTRING(@To,5,2),01)), 112);

	SET @sql = N'SELECT @Result = COUNT(*) FROM [' + @schemaName + '].[' + @TableName + '] WHERE [' + @ColumnName + '] BETWEEN ''' + @From + ''' AND ''' + @To + ''';';
	EXECUTE sp_executesql @sql, N'@result BIGINT OUTPUT', @Result = @Result OUTPUT;

	INSERT INTO @Monthly (SchemaName, TableName, [RowCount])
	SELECT @SchemaName, @tableName, (@result / @samplePeriodMonths);
	END

	IF @Type = 'yyyy'
	BEGIN
	-- Get max period
	SET @sql = N'SELECT @to = MAX([' + @ColumnName + ']) FROM [' + @SchemaName + '].[' + @TableName + '];';
	EXECUTE sp_executesql @sql, N'@to NVARCHAR(MAX) OUTPUT', @To = @To OUTPUT;

	-- Get min period
	SET @From = @To - 1;

	SET @sql = N'SELECT @Result = COUNT(*) FROM [' + @schemaName + '].[' + @TableName + '] WHERE [' + @ColumnName + '] = ' + @From + ';';
	EXECUTE sp_executesql @sql, N'@result BIGINT OUTPUT', @Result = @Result OUTPUT;

	INSERT INTO @Monthly (SchemaName, TableName, [RowCount])
	SELECT @SchemaName, @tableName, (@result / 12);
	END

	FETCH NEXT FROM growthcursor INTO @SchemaName, @tableName, @columnName, @Type;
	END;

	DEALLOCATE growthcursor;

	WITH cte
	AS (
	SELECT	s.name AS SCHEMANAME
	,t.name AS TABLENAME
	,i.type_desc
	,SUM(a.total_pages) AS pages
	,MAX(p.rows) AS RowCounts
	,ISNULL(((SUM(a.total_pages) * 8.0) / 1024.0) / NULLIF(MAX(p.rows),0),0) AS TotalSpacePerRowMB
	,(SUM(a.total_pages) * 8) / 1024.0 AS TotalSpaceMB
	,(SUM(a.used_pages) * 8) / 1024.0 AS UsedSpaceMB
	,(SUM(a.data_pages) * 8) / 1024.0 AS DataSpaceMB
	FROM	sys.tables t
	JOIN	sys.schemas s
	ON		s.schema_id = t.schema_id
	JOIN	sys.indexes i 
	ON		t.OBJECT_ID = i.object_id
	JOIN	sys.partitions p 
	ON		i.object_id = p.OBJECT_ID 
	AND		i.index_id = p.index_id
	JOIN	sys.allocation_units a
	ON		p.partition_id = a.container_id
	WHERE	i.OBJECT_ID > 255
	GROUP BY s.name
			,t.NAME
			,i.type_desc
	),
	GrowthCalcs
	AS (
	SELECT	m2.*
			,CASE WHEN c2.RowCounts = 0 THEN 0 ELSE m2.[RowCount] / CAST(c2.RowCounts AS NUMERIC) END AS GrowthRate
	FROM	@Monthly m2
	JOIN	cte c2
	ON		c2.SCHEMANAME = m2.SCHEMANAME
	AND		c2.TABLENAME = m2.TABLENAME
	AND		c2.type_desc IN('HEAP','CLUSTERED','CLUSTERED COLUMNSTORE')
	)
	,GrowthIncIndirect
	AS (
	SELECT	g.SchemaName
			,g.TableName
			,g.GrowthRate
	FROM	GrowthCalcs g
	UNION
	SELECT	i.SchemaName
			,i.TableName
			,g2.GrowthRate
	FROM	GrowthCalcs g2
	JOIN	@Indirect i
	ON		i.IndirectSchemaName = g2.SchemaName
	AND		i.IndirectTableName = g2.TableName
	)
	/*
	select * from GrowthCalcs;

	select * from @monthly;
	*/

	SELECT	c.SCHEMANAME
			,c.TABLENAME
			,c.type_desc
			,c.RowCounts
			,c.TotalSpaceMB
			,ISNULL(gi.GrowthRate,0) AS GrowthRateMth
			,c.TotalSpaceMB * (1 + (ISNULL(gi.GrowthRate,0) * 3)) AS forcast3mth
			,c.TotalSpaceMB * (1 + (ISNULL(gi.GrowthRate,0) * 6)) AS forcast6mth
			,c.TotalSpaceMB * (1 + (ISNULL(gi.GrowthRate,0) * 12)) AS forcast12mth
	FROM	cte c
	LEFT OUTER JOIN GrowthIncIndirect gi
	ON		gi.SchemaName = c.SCHEMANAME
	AND		gi.TableName = c.TABLENAME
	ORDER BY c.TotalSpaceMB DESC;

END