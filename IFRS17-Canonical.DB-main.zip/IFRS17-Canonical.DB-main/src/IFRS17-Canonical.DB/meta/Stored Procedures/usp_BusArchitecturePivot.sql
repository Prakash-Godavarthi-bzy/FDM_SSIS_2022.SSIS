﻿/*

Author:		Michael Sode
Date:		17 Jun 2022
Purpose:	Pivots the bus architecture.

*/
CREATE PROCEDURE meta.usp_BusArchitecturePivot
AS
BEGIN

	DECLARE @Columns as VARCHAR(MAX)

	SELECT	@Columns = COALESCE(@Columns + ', ','') + QUOTENAME([FactNiceName])
	FROM	(
				SELECT DISTINCT [FactNiceName] 
				FROM [meta].[vw_bus_architecture]
			) AS B
	ORDER BY B.[FactNiceName]

	DECLARE @SQL as VARCHAR(MAX)
	SET @SQL = 'SELECT [Dim], ' + @Columns + ' 
	FROM
	(
	 select [DimNiceName] + CASE WHEN [DimRoleNiceName] IS NULL THEN '''' ELSE '' ['' + [DimRoleNiceName] + '']'' END AS Dim,[FactNiceName],''X'' AS included from [meta].[vw_bus_architecture]
	) as PivotData
	PIVOT
	(
	   MAX(included)
	   FOR [FactNiceName] IN (' + @Columns + ')
	) AS PivotResult
	ORDER BY [Dim];'

	EXEC(@SQL);

END