﻿CREATE TABLE [Mapping].[ConformedTrifocus_TechnicalHub] (
    [PK_TrifocusMappingID]   INT            IDENTITY (1, 1) NOT NULL,
    [FK_DataSourceID]        TINYINT        NOT NULL,
    [Fk_TrifocusID]          INT            NULL,
    [TrifocusCode]           VARCHAR (50)   NOT NULL,
    [Fk_ConformedTrifocusID] INT            NULL,
    [ConformedTrifocusCode]  VARCHAR (50)   NULL,
    [Hash]                   VARBINARY (64) NOT NULL
);

