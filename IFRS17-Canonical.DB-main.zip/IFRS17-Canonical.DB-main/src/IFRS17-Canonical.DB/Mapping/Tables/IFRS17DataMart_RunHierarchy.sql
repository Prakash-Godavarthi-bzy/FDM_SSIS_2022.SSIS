﻿CREATE TABLE [Mapping].[IFRS17DataMart_RunHierarchy] (
    [Pk_RequestId]         INT NULL,
    [ReportingPeriod]      INT NULL,
    [OpeningBalanceID]     INT NULL,
    [OpeningBalancePeriod] INT NULL,
    [ParentRequestID]      INT NULL
);




GO
CREATE NONCLUSTERED INDEX [Mapping_RunHirerachy_ParentRequestID]
    ON [Mapping].[IFRS17DataMart_RunHierarchy]([ParentRequestID] DESC) WITH (FILLFACTOR = 90, DROP_EXISTING = OFF)
    ON [DATA];

