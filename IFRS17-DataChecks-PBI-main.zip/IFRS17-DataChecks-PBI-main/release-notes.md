## New


## Fixes 
- Enable scheduled refresh
- Fix slicer selection problem