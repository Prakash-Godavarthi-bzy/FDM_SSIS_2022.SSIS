﻿--:setvar InstanceName "UKDVDB149"

/*
	Change log. Please add comments to help us developers make sure we don't miss changes before we check in code.

	Author:			nithin.dumpeti@beazley.com
	Description:	Orchestration15 is beign used by users (triggered from powerapps)
														

*/
/*
	Change Version	: v1.2	 
	Sprint			: BR1 Q3 24 Committed
	Author		    : Shah Nawaz Ahmed    <shahnawaz.ahmed@beazley.com>
	Modify Date	    : 12/07/2024
	Description		: https://beazley.atlassian.net/browse/I1B-5622   
									Changed ModuleHierarchy for RIPsEventAlloc, USPremium, NatCatEarning, ResDataRIAttClmAllocPase2, Load RIPercentage, USBAIC and added new DS PolicySectionReference
*/

declare @IFRS17_InstanceName_DL nvarchar(129) = '$(InstanceName)'



--select @IFRS17_InstanceName_Pre

/*
	-- to delete everything and start again. The merge statement can fail when changes break referential entrigity, 
	-- so the data needs to be deleted and re-stated.
declare @IFRS17_Orchestration_Pre int = 15

delete etl.ModuleActivity
where FK_Orchestration = @IFRS17_Orchestration_DL

delete etl.ModuleHierarchy
where FK_Orchestration = @IFRS17_Orchestration_DL

delete etl.Module
where FK_Orchestration = @IFRS17_Orchestration_DL

delete etl.Orchestration
where PK_Orchestration = @IFRS17_Orchestration_DL

*/

-- static variables
declare @IFRS17_Orchestration_DL int = 15
declare @IFRS17_Orchestration_IsEnabledDL int = 1
declare @IFRS17_RunTimeExecutionPriorityOrderDL int = 1

Delete from etl.ModuleHierarchy 
where FK_Orchestration=@IFRS17_Orchestration_DL

Delete from etl.ModuleActivity 
where FK_Orchestration=@IFRS17_Orchestration_DL

Delete From etl.Module 
where FK_Orchestration=@IFRS17_Orchestration_DL




  --orchestration select * from etl.Orchestration
			MERGE 
			INTO	etl.Orchestration AS Target
			USING	(VALUES(@IFRS17_Orchestration_DL, 'BR1Orchestration',@IFRS17_Orchestration_IsEnabledDL)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled)
			ON		(Target.PK_Orchestration = Source.PK_Orchestration)
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(PK_Orchestration,OrchestrationName,IsEnabled)
					VALUES(Source.PK_Orchestration,  Source.OrchestrationName,  Source.IsEnabled)
			WHEN	MATCHED
			THEN	UPDATE SET	Target.ORchestrationName = Source.OrchestrationName,
								Target.IsEnabled = Source.Isenabled;

			-- code to uncomment when priority column can be released.
			--MERGE 
			--INTO	etl.Orchestration AS Target
			--USING	(VALUES(@IFRS17_Orchestration_Pre, 'IFRS17',@IFRS17_Orchestration_IsEnabledPre,@IFRS17_RunTimeExecutionPriorityOrder)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled,RunTimeExecutionPriorityOrder)
			--ON		(Target.PK_Orchestration = Source.PK_Orchestration)
			--WHEN	NOT MATCHED BY TARGET
			--THEN	INSERT(PK_Orchestration,OrchestrationName,IsEnabled,RunTimeExecutionPriorityOrder)
			--		VALUES(Source.PK_Orchestration,  Source.OrchestrationName,  Source.IsEnabled, Source.RunTimeExecutionPriorityOrder)
			--WHEN	MATCHED
			--THEN	UPDATE SET	Target.ORchestrationName = Source.OrchestrationName,
			--					Target.IsEnabled = Source.Isenabled,
			--					Target.RunTimeExecutionPriorityOrder = Source.RunTimeExecutionPriorityOrder;

--module select * from etl.Module 

declare @FK_ModuleType_SPDL int = (select PK_ModuleType from [etl].[ModuleType] where ModuleType = 'SPROC')
declare @FK_ModuleType_SSISDL int = (select PK_ModuleType from [etl].[ModuleType] where ModuleType = 'SSIS')

			MERGE --@IFRS17_Orchestration_Pre
			INTO	etl.Module AS Target
			USING	(
						VALUES	--Level 1 Landing Tactical/BR1/GAAP 1*15=1-15
								(@IFRS17_Orchestration_DL,1,'EIOPA ToLanding',@FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_EIOPAToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,2,'NatCatEarning ToLanding',@FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_NatCatEarningToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,3,'Paid Rebates Landing',@FK_ModuleType_SSISDL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_PaidRebatesToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,4,'Ultimate Rebates Landing',@FK_ModuleType_SSISDL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_UltimateRebatesToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,5,'BeazleyRIMI to Landing',@FK_ModuleType_SSISDL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BeazleyMIReinsuranceToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,6,'LPSO ToLanding',@FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_EurobaseToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,7,'MDS ToLanding',@FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_MDSToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,8,'FDM ToLanding',@FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_FDMToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,9,'ADM ToLanding',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADMToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,10,'ADM DFM PaymentPatterns',@FK_ModuleType_SSISDL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADM_DFM_PaymentPattern_ToLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,11,'ADM Reserving Data PaymentPatterns',@FK_ModuleType_SSISDL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADM_ResDat_PaymentPattern_ToLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,12,'ADM S2 Technical Provision PaymentPatterns',@FK_ModuleType_SSISDL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADM_S2_TPOutput_PaymentPattern_ToLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,13,'CededRe to Landing',@FK_ModuleType_SSISDL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_CededReAccToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,14,'SyndicateSplit Landing',@FK_ModuleType_SSISDL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''SyndicateSplit.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,15,'BICC ToLanding',@FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BICCToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),

								--Level 2 Landing Tactical/BR1/GAAP Loads
								(@IFRS17_Orchestration_DL,16,'Ult Profit Commission Landing',@FK_ModuleType_SSISDL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_UltimateProfitCommissionToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,17,'BusinessPlanning Landing',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BusinessPlanLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
							    (@IFRS17_Orchestration_DL,18,'BICI_RI_Ultimate_Premium Landing',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BICIRI_Ultimate.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,19,'ResDataEventAlloc Landing',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADMResDataAllocToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
							    (@IFRS17_Orchestration_DL,20,'UltimateRIPsEventAlloc Landing',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_UltimateRIPsEventToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,21,'BusinessPlanningRI Landing',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BusinessPlanLandingRI.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),							    
								(@IFRS17_Orchestration_DL,22,'AgressoAR Landing Landing',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_AgressoToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),							    
								(@IFRS17_Orchestration_DL,23,'TDMBICIClaims Landing',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_TDMBICIClaimsToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),							    
								(@IFRS17_Orchestration_DL,24,'AEA_ExpensesActuals Landing',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_AExpensesActualLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),							    
								(@IFRS17_Orchestration_DL,25,'BICI_RI_Ultimate_Claim Landing',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BICIRI_Claim.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),							    
								(@IFRS17_Orchestration_DL,26,'EB Trifocus',@FK_ModuleType_SSISDL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FDMTrifocusCode.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),								
								(@IFRS17_Orchestration_DL,27,'EurobaseEPIReInstatement Landing',@FK_ModuleType_SSISDL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_EurobaseEPIReinstatement.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),								
								(@IFRS17_Orchestration_DL,28,'BICI ORC TACTICAL Landing',@FK_ModuleType_SSISDL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BICI_Orc_Tactical.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),								
							    (@IFRS17_Orchestration_DL,29,'BICI_RIIncurred Landing',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BICIRI_Incurred.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,30,'EarnedRIP_RISpendBESI Landing',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_Earned_RIP_RISpendBESI.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),

								--Level 3  Landing Tactical/BR1/GAAP 3*15=31-45
								(@IFRS17_Orchestration_DL,31,'Eurobase',@FK_ModuleType_SSISDL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''EurobaseTacticalLoad.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,32,'US Premium',@FK_ModuleType_SSISDL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''USPremium.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,33,'PFT Forecast',@FK_ModuleType_SSISDL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''PremiumForecastLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,34,'BICI Landing',@FK_ModuleType_SSISDL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BICILanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,35,'BIDAC Landing',@FK_ModuleType_SSISDL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BIDACLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,36,'USBAIC Landing',@FK_ModuleType_SSISDL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_USBAICLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,37,'ResDataRIAttClmAlloc Landing Phase1',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''ADMResDataAttClmAllocPhase1.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,38,'ResDataRIAttClmAlloc Landing Phase2',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''ADMResDataAttClmAllocPhase2.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,39,'BICIRI_Earned Landing',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName =''IFRS17_BICIRI_EarnedPremium.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,40,'ADM_RRDataLargeLosses',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''ADMReinsuranceReservingData_LargeLosses.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,41,'BICI_RIPaid Landing',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName =''IFRS17_BICIRI_Paid.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,42,'SPA_MUNQQS_ORC_Tactical Landing',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_SPA_MUNQQS_ORC_Tactical.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,43,'USBESI Landing',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_PyramidToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,44,'Reinsurance overriding commission BESI Landing',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_RISpendBESI_ORCFileTolanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,45,'Obligated Premium RISpend BESI landing',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ObligatedPremiumRISpendBESI.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),

								--Level 4  Landing Tactical/BR1/GAAP 4*15=46-60
								(@IFRS17_Orchestration_DL,46,'NCB Landing',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_NoClaimBonusLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_DL,47,'FACPrgogrammes Landing',  @FK_ModuleType_SSISDL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_FACPrgogrammes.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_DL,'SchedulingHub',NULL,NULL),

								--Level 5  Tactical Landing to Inbound 
								(@IFRS17_Orchestration_DL,61,'BICI_RI_Ultimate_Claim LandingToInbound',@FK_ModuleType_SPDL,'EXEC [BICIRI].[usp_LandingInboundWorkflow_BICI_RI_Ultimate_Claim]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_DL,62,'BuinsessPlan LandingToInbound',@FK_ModuleType_SPDL,'EXEC [BP].[usp_LandingInboundWorkflow_BusinessPlan]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_DL,63,'TDMBICIClaims LandingToInbound',@FK_ModuleType_SPDL,'EXEC [TDM].[usp_LandingInboundWorkflow_BICIClaims]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_DL,64,'AEA_ExpensesActual LandingToInbound',@FK_ModuleType_SPDL,'EXEC [Agresso].[usp_LandingToInboundToOutboundWorkflow_AgressoExpensesActual]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_DL,65,'BICI_RI_Ultimate_Premium LandingToInbound',@FK_ModuleType_SPDL,'EXEC [BICIRI].[usp_LandingInboundWorkflow_BICI_RI_Ultimate_Premium]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_DL,66,'ResDataEventAlloc LandingToInboundToOutbound',@FK_ModuleType_SPDL,'EXEC [ADM].[usp_LandingToInboundToOutbound_ResDataEventAlloc]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_DL,67,'UltimateRIPsEventAlloc LandingToInboundToOutbound',@FK_ModuleType_SPDL,'EXEC [Ultrea].[usp_LandingToInboundToOutbound_RIPsEventAlloc]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_DL,68,'BuinsessPlanRI LandingToInbound',@FK_ModuleType_SPDL,'EXEC [BP].[usp_LandingInboundWorkflow_BusinessPlanRI]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_DL,69,'BICIRI_Earned LandingToInboundToOutbound',@FK_ModuleType_SPDL,'EXEC [Agresso].[usp_LandingToInboundToOutboundWorkflow_BICIRI_EarnedPremium]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
                                (@IFRS17_Orchestration_DL,70,'ResDataRIAttClmAllocPhase1 LandingProc',@FK_ModuleType_SPDL,'EXEC [ADMRI].[ResDataAttClmAllocLandingPhase1]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
                                (@IFRS17_Orchestration_DL,71,'BICI_RIIncurred LandingToInbound',@FK_ModuleType_SPDL,'EXEC [Agresso].[usp_LandingToInboundToOutboundWorkflow_BICIRI_Incurred]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
                                (@IFRS17_Orchestration_DL,72,'BICI_RIPaid LandingToInboundToOutbound',@FK_ModuleType_SPDL,'EXEC  [Agresso].[usp_LandingToInboundToOutboundWorkflow_BICIRI_Paid]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
                                (@IFRS17_Orchestration_DL,73,'ADM_RRDataLargeloses LandingToInboundToOutbound',@FK_ModuleType_SPDL,'EXEC [ADM].[usp_LandingToInboundToOutbound_ReinsuranceReservingDataLargeLosses_ADM]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
                                (@IFRS17_Orchestration_DL,74,'SPA_ObligatedPremium LandingToInboundToOutbound',@FK_ModuleType_SPDL,'EXEC [SPA].[usp_LandingToInboundToOutbound_ObligatedPremium_SPA]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
                                (@IFRS17_Orchestration_DL,75,'ObligatedPremium_MunichQQS LandingToInboundOutbound',@FK_ModuleType_SPDL,'EXEC  [OP].[usp_LandingToInboundToOutbound_ObligatedPremium_MunichQQS]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
                                

								--Level 5 Tactical Landing to Inbound 
								(@IFRS17_Orchestration_DL,76,'ResDataPremiumAlloc LandingToInboundOutbound',@FK_ModuleType_SPDL,'EXEC [ADM].[usp_LandingToInboundToOutbound_ReservingDataPremiumAlloc]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
                                (@IFRS17_Orchestration_DL,77,'EurobaseEPIReInstatement LandingToInbound', @FK_ModuleType_SPDL,'EXEC [Eurobase].[usp_LandingToInboundToOutbound_EPIReinstatement]',@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_DL,78,'EB Landing To Inbound',@FK_ModuleType_SPDL,'EXEC [Eb].[usp_LandingInboundWorkflow_EurobaseTacticalLoad]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_DL,79,'Loading RI_Percentage data', @FK_ModuleType_SPDL,'EXEC [fdm].[usp_LoadtoRI_Percentage]',@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_DL,80,'BICI ORC TACTICAL LandingToInboundToOutBound', @FK_ModuleType_SPDL,'EXEC [Agresso].[usp_LandingToInboundToOutboundWorkflow_BICIRI_Orc_Tactical]',@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_DL,81,'SPA_MUNQQS_ORC_TACTICAL LandingToInboundToOutbound', @FK_ModuleType_SPDL,'EXEC [SPA].[usp_LandingToInboundToOutbound_SPA_MUNQQS_ORC_TACTICAL]',@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
                                (@IFRS17_Orchestration_DL,82,'ResDataRIAttClmAllocPhase2 LandingProc',@FK_ModuleType_SPDL,'EXEC [ADMRI].[ResDataAttClmAllocLandingPhase2]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),


								--Level 6 Tactical Inbound to Outbound 
								(@IFRS17_Orchestration_DL,91,'Inbound To OutBound for Tactical Loads',@FK_ModuleType_SPDL,'EXEC [TL].[usp_InboundOutBoundWorkflow_TacticalLoads]'	,@IFRS17_InstanceName_DL, 'Financedatacontract', NULL, NULL),								
								
								--Level 7 Dependencies Landing to Inbound 
								(@IFRS17_Orchestration_DL,106,'MDS LandingToInbound', @FK_ModuleType_SPDL,'EXEC [MDS].[usp_LandingToInbound]',@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),								
							    (@IFRS17_Orchestration_DL,107,'EIOPA LandingToInbound', @FK_ModuleType_SPDL,'EXEC [XLS].[usp_EIOPALandingToInbound_DiscountRates]',@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL), 
								(@IFRS17_Orchestration_DL,108,'NatCatEarning LandingToInbound', @FK_ModuleType_SPDL,'EXEC [NCME].[usp_NatCatEarningLandingToInbound_Pattern]',@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
							    (@IFRS17_Orchestration_DL,109,'ReInsurance_ContractAttributes LandingToInbound', @FK_ModuleType_SPDL,'EXEC [Eurobase].[usp_LandingToInbound_TreatyReInsurance_ContractAttributes]',@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_DL,110,'ReInsurance QuotaSharePercentage LandingToInbound', @FK_ModuleType_SPDL,'EXEC [fdm].[usp_LandingToInbound_ReInsuranceQuotaSharePercentage]',@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_DL,111,'ReInsurance TrifocusAllocationsTreaty LandingToInbound', @FK_ModuleType_SPDL,'EXEC [fdm].[usp_LandingToInbound_ReInsuranceTrifocusAllocationsTreaty]',@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_DL,112,'RIPercentage LandingtoInbound',@FK_ModuleType_SPDL,'EXEC [fdm].[usp_LandingToInbound_RI_Percentage]',@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_DL,113,'RIPercentage InboundtoOutbound',@FK_ModuleType_SPDL,'EXEC [Inbound].[usp_InboundOutboundWorkflow_RIPercentage]',@IFRS17_InstanceName_DL, 'FinanceDataContract', NULL, NULL),

								--Level 8 Dependencies Inbound to Outbound 
								(@IFRS17_Orchestration_DL,121,'AccountName Transaction InboundToOutbound',@FK_ModuleType_SPDL,'EXEC [Inbound].[usp_InboundOutboundWorkflow_AccountNames]'	,@IFRS17_InstanceName_DL, 'FinanceDataContract', NULL, NULL),																
								(@IFRS17_Orchestration_DL,122,'ReInsurance_ContractAttributes InboundToOutbound', @FK_ModuleType_SPDL,'EXEC [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTreatyContractAttributes]',@IFRS17_InstanceName_DL, 'FinanceDataContract', NULL, NULL),
								(@IFRS17_Orchestration_DL,123,'DataContract ReInsuranceQuotaSharePercentage InboundToOutbound', @FK_ModuleType_SPDL,'EXEC [Inbound].[usp_InboundOutboundWorkflow_ReInsuranceQuotaSharePercentage]',@IFRS17_InstanceName_DL, 'FinanceDataContract', NULL, NULL),
								(@IFRS17_Orchestration_DL,124,'DataContract ReInsuranceTrifocusAllocationsTreaty InboundToOutbound', @FK_ModuleType_SPDL,'EXEC [Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTrifocusAllocationsTreaty]',@IFRS17_InstanceName_DL, 'FinanceDataContract', NULL, NULL),
								(@IFRS17_Orchestration_DL,125,'DataContract RIPercentage InboundToOutbound',@FK_ModuleType_SPDL, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_RIPercentage] '	,@IFRS17_InstanceName_DL, 'FinanceDataContract', NULL, NULL),
								(@IFRS17_Orchestration_DL,126,'DataContract Transactional Datasets InboundToOutbound',@FK_ModuleType_SPDL, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_TransactionalDatasets] @DoNonIFRS17_Tests = 0'	,@IFRS17_InstanceName_DL, 'FinanceDataContract', NULL, NULL),

								--Level 9 Landing to Inbound
								(@IFRS17_Orchestration_DL,136,'ADM Pattern LandingToInbound', @FK_ModuleType_SPDL,'EXEC [ADM].[usp_LandingToInbound_Pattern]',@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),							
								(@IFRS17_Orchestration_DL,137,'Claims_BI_ODS LandingToInboundToOutbound', @FK_ModuleType_SPDL,'EXEC [Claims_BI_ODS].[usp_LandingToInboundToOutbound]',@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_DL,138,'LPSO LandingToInboundToOutbound', @FK_ModuleType_SPDL,'EXEC [Eurobase].[usp_LandingToInboundToOutbound_LPSO]',@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_DL,139,'LPSO LandingToInboundToOutbound Fac ReInsurance', @FK_ModuleType_SPDL,'EXEC [Eurobase].[usp_LandingToInboundToOutbound_FacReInsurance]',@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_DL,140,'BI Policy Section references LandingToInbound', @FK_ModuleType_SPDL,'EXEC [Claims_BI_ODS].[usp_LandingToInbound_PolicySectionReference]',@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								
								--Level 10
								(@IFRS17_Orchestration_DL,151,'DataContract DiscountRates InboundToOutbound',@FK_ModuleType_SPDL, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_DiscountRates]'	,@IFRS17_InstanceName_DL, 'FinanceDataContract', NULL, NULL),
								(@IFRS17_Orchestration_DL,152,'DataContract Pattern InboundToOutbound',@FK_ModuleType_SPDL, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_Pattern]'	,@IFRS17_InstanceName_DL, 'FinanceDataContract', NULL, NULL),
								(@IFRS17_Orchestration_DL,153,'DataContract PolicySectionReference InboundToOutbound',@FK_ModuleType_SPDL, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_PolicySectionReferences]'	,@IFRS17_InstanceName_DL, 'FinanceDataContract', NULL, NULL),
								(@IFRS17_Orchestration_DL,154,'DataContract ClaimExtensions InboundToOutbound',@FK_ModuleType_SPDL, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_ClaimExtensions]'	,@IFRS17_InstanceName_DL, 'FinanceDataContract', NULL, NULL),
								(@IFRS17_Orchestration_DL,155,'DataContract ReInsuranceExtensions InboundToOutbound',@FK_ModuleType_SPDL, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_ReInsuranceExtensions]'	,@IFRS17_InstanceName_DL, 'FinanceDataContract', NULL, NULL),
								
								--Level 11
								(@IFRS17_Orchestration_DL,166,'DataContract ReInsurance Treaty Landing to InboundToOutbound',@FK_ModuleType_SPDL, 'EXEC [Eurobase].[usp_LandingToInboundToOutbound_TreatyReInsurance]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_DL,167,'DataContract Transaction InboundToOutbound',@FK_ModuleType_SPDL,'EXEC [Inbound].[usp_InboundOutboundWorkflow] @DoNonIFRS17_Tests = 0'	,@IFRS17_InstanceName_DL, 'FinanceDataContract', NULL, NULL),
								(@IFRS17_Orchestration_DL,168,'ResDataRIAttClmAlloc InboundToOutbound',@FK_ModuleType_SPDL,'EXEC [ADM].[usp_LandingToInboundToOutbound_ResDataRIAttClmAlloc]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),

							    --Level 12 
								(@IFRS17_Orchestration_DL,181,'UltimateRebates LandingToInboundToOutbound',@FK_ModuleType_SPDL,'EXEC [ultrebsrc].[usp_LandingToInboundToOutbound_UltimateRIRebate]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_DL,182,'ADM LandingToInboundToOutbound', @FK_ModuleType_SPDL,'EXEC [ADM].[usp_LandingToInboundToOutbound]',@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_DL,183,'CededReClaimsIncurred LandingToInboundToOutbound',@FK_ModuleType_SPDL,'EXEC [CededRe].[usp_LandingToInboundToOutbound_CededReClaimsIncurred]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_DL,184,'CededReClosedYOA LandingToInboundToOutbound',@FK_ModuleType_SPDL,'EXEC [CededRe].[usp_LandingToInboundToOutbound_CededReClosedYOA]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_DL,185,'CededReORC LandingToInboundToOutbound',@FK_ModuleType_SPDL,'EXEC [CededRe].[usp_LandingToInboundToOutbound_CededReORC]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_DL,186,'Reinsurance overriding commission LandingToInboundToOutbound',@FK_ModuleType_SPDL,'EXEC [FDM].[usp_LandingToInboundToOutbound_Reinsurance_Overriding_Commission]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_DL,187,'RI_ReInstatementPremiumEarned LandingToInboundToOutbound',@FK_ModuleType_SPDL,'EXEC [fdm].[usp_LandingToInboundToOutbound_RI_Reinstatement_Premium_Earned]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),								
								
								--Level 13
								(@IFRS17_Orchestration_DL,196,'ReInsurance ObligatedPremium Transaction LandingToInboundToOutbound',@FK_ModuleType_SPDL,'EXEC [fdm].[usp_LandingToInboundToOutbound_ObligatedPremium]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_DL,197,'Ultimate Profit Commission LandingToInboundToOutbound',@FK_ModuleType_SPDL,'EXEC [ultpc].[usp_LandingToInboundToOutbound_UltimateProfitCommission]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),															
								(@IFRS17_Orchestration_DL,198,'Signed Profit Commission LandingToInboundToOutbound',@FK_ModuleType_SPDL,'EXEC [ReinsuranceMI].[usp_LandingToInboundToOutbound_SignedProfitCommission]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_DL,199,'AgressoARBIDAC LandingToInboundToOutbound',@FK_ModuleType_SPDL,'EXEC [AgressoAR].[usp_LandingToInboundToOutbound_AgressoARBIDAC]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_DL,200,'AgressoARUS LandingToInboundToOutbound',@FK_ModuleType_SPDL,'EXEC [AgressoAR].[usp_LandingToInboundToOutbound_AgressoARUS]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_DL,201,'RISpecialArrangements Transaction LandingToInboundToOutbound',@FK_ModuleType_SPDL,'EXEC [fdm].[usp_LandingToInboundToOutbound_RISpecialArrangements]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_DL,202,'Paid Rebates LandingToInboundToOutbound', @FK_ModuleType_SPDL,'EXEC [pdrebsrc].[usp_LandingToInboundToOutbound_PaidRebates]',@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),

								--Level 14 GAAP Landing to Inbound
								(@IFRS17_Orchestration_DL,211,'US Landing',@FK_ModuleType_SPDL,'EXEC [us].[usp_LandingInboundWorkflow]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_DL,212,'BICI LandToInbound',@FK_ModuleType_SPDL,'EXEC [US].[usp_BICILandingToInboundWorkflow]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_DL,213,'BIDAC LandToInbound',@FK_ModuleType_SPDL,'EXEC [BIDAC].[usp_LandingInboundWorkflow]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_DL,214,'USBAIC LandToInbound',@FK_ModuleType_SPDL,'EXEC [US].[usp_BAICLandingToInboundWorkflow]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_DL,215,'USBESI LandingToInboundToOutbound',@FK_ModuleType_SPDL,'EXEC [Pyramid].[usp_LandingToInboundToOutboundWorkflow_USBESI]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),								

								--Level 15 GAAP Inbound to Outbound
								(@IFRS17_Orchestration_DL,226,'DataContract',@FK_ModuleType_SPDL,'EXEC [Inbound].[usp_InboundOutboundWorkflow_GAAP]'  ,@IFRS17_InstanceName_DL, 'Financedatacontract', NULL, NULL),								

								--Level 16 PFT Landing to Inbound
								(@IFRS17_Orchestration_DL,241,'PFT Landing',@FK_ModuleType_SPDL,'EXEC [pft].[usp_LandingToInboundToOutboundWorkflow]'	,@IFRS17_InstanceName_DL, 'FinanceLanding', NULL, NULL),								

								--Level 17 PFT Inbound to Outbound 
								(@IFRS17_Orchestration_DL,256,'DataContract',@FK_ModuleType_SPDL,'EXEC [Inbound].[usp_InboundOutboundWorkflow]'	,@IFRS17_InstanceName_DL, 'Financedatacontract', NULL, NULL)																	

								
					)
						AS Source(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.PK_Module = Source.PK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
					VALUES(Source.FK_Orchestration,  Source.PK_module,  Source.ModuleName,  Source.FK_ModuleType,  Source.ModuleRoutine,  Source.DestinationServer,  Source.DestinationDatabase,Source.FK_Schedule,Source.FK_Notification)
			WHEN	MATCHED
			THEN	UPDATE SET		FK_Orchestration	= source.FK_Orchestration, 
									PK_module 			= source.PK_module, 
									ModuleName 			= source.ModuleName, 
									FK_ModuleType 		= source.FK_ModuleType, 
									ModuleRoutine 		= source.ModuleRoutine, 
									DestinationServer	= source.DestinationServer, 
									DestinationDatabase	= source.DestinationDatabase, 
									FK_Schedule 		= source.FK_Schedule, 
									FK_Notification		= source.FK_Notification
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_DL
			THEN	DELETE;




			--ModuleHierarchy select * from etl.ModuleHierarchy
			MERGE 
			INTO	etl.ModuleHierarchy AS Target
			USING	(
						VALUES	--L1
								(@IFRS17_Orchestration_DL,NULL,	1,	1), --EIOPA To Landing
								(@IFRS17_Orchestration_DL,NULL,	2,	1), --NatCatEarning To Landing 
								(@IFRS17_Orchestration_DL,NULL,	3,	1), --Paid Rebates Landing
								(@IFRS17_Orchestration_DL,NULL,	4,	1), --Ultimate Rebates Landing 
								(@IFRS17_Orchestration_DL,NULL,	5,	1), --BeazleyRIMI to Landing
								(@IFRS17_Orchestration_DL,NULL,	6,	1), --LPSO ToLanding 
								(@IFRS17_Orchestration_DL,NULL,	7,	1), --MDS ToLanding
								(@IFRS17_Orchestration_DL,NULL,	8,	1), --FDM ToLanding
								(@IFRS17_Orchestration_DL,NULL,	9,	1), --ADM ToLanding
								(@IFRS17_Orchestration_DL,NULL,	10,	1), --ADM DFM PaymentPatterns
								(@IFRS17_Orchestration_DL,NULL,	11,	1), --ADM Reserving Data PaymentPatterns
								(@IFRS17_Orchestration_DL,NULL,	12,	1), --ADM S2 Technical Provision PaymentPatterns
								(@IFRS17_Orchestration_DL,NULL,	13,	1), --CededRe to Landing
								(@IFRS17_Orchestration_DL,NULL,	14,	1), --SyndicateSplit Landing
								(@IFRS17_Orchestration_DL,NULL,	15,	1), --BICC ToLanding

								--L2
								(@IFRS17_Orchestration_DL,NULL,	16, 2), --Ult Profit Commission Landing
								(@IFRS17_Orchestration_DL,NULL,	17, 2), --BusinessPlanning Landing 
								(@IFRS17_Orchestration_DL,NULL, 18, 2), --BICI_RI_Ultimate_Premium Landing
								(@IFRS17_Orchestration_DL,NULL,	19, 2), --ResDataEventAlloc Landing 
								(@IFRS17_Orchestration_DL,NULL,	20, 2), --UltimateRIPsEventAlloc Landing 
								(@IFRS17_Orchestration_DL,NULL,	21, 2), --BusinessPlanningRI Landing 
								(@IFRS17_Orchestration_DL,NULL,	22, 2), --AgressoAR Landing Landing
								(@IFRS17_Orchestration_DL,NULL,	23, 2), --TDMBICIClaims Landing
								(@IFRS17_Orchestration_DL,NULL,	24, 2), --AEA_ExpensesActuals Landing
								(@IFRS17_Orchestration_DL,NULL,	25, 2), --BICI_RI_Ultimate_Claim Landing
								(@IFRS17_Orchestration_DL,NULL,	26, 2), --EB Trifocus
								(@IFRS17_Orchestration_DL,NULL,	27, 2), --EurobaseEPIReInstatement Landing
								(@IFRS17_Orchestration_DL,NULL,	28, 2), --BICI ORC TACTICAL Landing
								(@IFRS17_Orchestration_DL,NULL,	29, 2), --BICI_RIIncurred Landing
								(@IFRS17_Orchestration_DL,NULL,	30, 2), --EarnedRIP_RISpendBESI Landing

								--L3
								(@IFRS17_Orchestration_DL,NULL,	31, 3), --Eurobase Tactical Landing
								(@IFRS17_Orchestration_DL,NULL,	32, 3), --US Premium Landing
								(@IFRS17_Orchestration_DL,NULL, 33, 3), --PFT Forecast
								(@IFRS17_Orchestration_DL,NULL,	34, 3), --BICI Landing 
								(@IFRS17_Orchestration_DL,NULL,	35, 3), --BIDAC Landing
								(@IFRS17_Orchestration_DL,NULL,	36, 3), --USBAIC Landing 
								(@IFRS17_Orchestration_DL,NULL,	37, 3), --ResDataRIAttClmAlloc Landing Phase1
								(@IFRS17_Orchestration_DL,NULL,	38, 3), --ResDataRIAttClmAlloc Landing Phase2
								(@IFRS17_Orchestration_DL,NULL,	39, 3), --BICI_Earned_Agresso Landing
								(@IFRS17_Orchestration_DL,NULL,	40, 3), --ADM_RRDataLargeLosses
								(@IFRS17_Orchestration_DL,NULL,	41, 3), --BICI_RIPaid Landing
								(@IFRS17_Orchestration_DL,NULL,	42, 3), --ORC MUNQQS Landing
								(@IFRS17_Orchestration_DL,NULL,	43, 3), --USBESI Landing
								(@IFRS17_Orchestration_DL,NULL,	44, 3), --Reinsurance overriding commission BESI landing
								(@IFRS17_Orchestration_DL,NULL,	45, 3), --Obligated Premium RISpend BESI landing

								--L4
								(@IFRS17_Orchestration_DL,NULL,	46, 4),-- NCB Landing
								(@IFRS17_Orchestration_DL,NULL,	47, 4),-- NCB Landing


								/*
								
								1. From Here each Level has a individual dataset tree levels which includes L2I | I2O | L2I2O stored procs
								2. These tree levels inculudes dependecny tables and the L2I | I2O have hierarchy modules which means first runs => LandingPackage--> L2I--> I2O || LandingPackage--> L2I2O

								*/

								--Level 5 ADM-DFMs-1
								(@IFRS17_Orchestration_DL, 9,	136, 5), --ADM DFM Pattern L2I depends on ADM ToLanding
								(@IFRS17_Orchestration_DL, 10,	136, 5), --ADM DFM Pattern L2I depends on ADM DFM Mapping package(ADMDFMS_Mapping)
								(@IFRS17_Orchestration_DL, 136, 152, 5), --Common_Pattern_Proc I2O depends on ADM_DFMS L2I

								--Level 5 PolicySectionReference
								(@IFRS17_Orchestration_DL, 15,	140, 5), --BICC L2I depends on BICC ToLanding

								--Level 6 AgressoARBIDAC-2
								(@IFRS17_Orchestration_DL, 22,	199, 6), -- AgressoARBIDAC L2I2O depends on AgressoAR Landing

								--Level 6 PolicySectionReference
								(@IFRS17_Orchestration_DL, 140,	153, 6), --BICC L2I depends on BICC ToLanding

								--Level 7 AgressoARUS-3
								(@IFRS17_Orchestration_DL, 22,	200, 7), --  AgressoARUS L2I2O depends on AgressoAR Landing

								--Level 8 BICI-4
								(@IFRS17_Orchestration_DL, 7,	212, 8), --  BICI L2I depends on MDS Landing 
								(@IFRS17_Orchestration_DL, 34,	212, 8), --  BICI L2I depends on BICI Landing 
								(@IFRS17_Orchestration_DL, 212,	226, 8), --  Common_GAAP_Proc I2O depends on BICI L2I depends

								--Level 9 BICI RI Ultimate Claim-5
								(@IFRS17_Orchestration_DL, 25,	61, 9), --  BICI_RI_Ultimate_Claim L2I depends on BICI_RI_Ultimate_Claim Landing 
								(@IFRS17_Orchestration_DL, 61,	91, 9), --  Common_Tactical_Proc I2O depends on BICI L2I depends

								--Level 10 BICI TDM-6
								(@IFRS17_Orchestration_DL, 23,	63, 10), --  BICI TDM L2I depends on BICI TDM Landing 
								(@IFRS17_Orchestration_DL, 63,	91, 10), --  Common_Tactical_Proc I2O depends on BICI TDM L2I depends

								--Level 11 BICI_Earned_Agresso-7
								(@IFRS17_Orchestration_DL, 6,	69, 11), --  BICI_Earned_Agresso L2I2O depends on LPSO Landing 
								(@IFRS17_Orchestration_DL, 8,	69, 11), --  BICI_Earned_Agresso L2I2O depends on FDM Landing 
								(@IFRS17_Orchestration_DL, 39,	69, 11), --  BICI_Earned_Agresso L2I2O depends on BICI_Earned_Agresso Landing 

								--Level 12 BICI_ORC_TACTICAL-8
								(@IFRS17_Orchestration_DL, 6,	80, 12), --  BICI_ORC_TACTICAL L2I2O depends on LPSO Landing 
								(@IFRS17_Orchestration_DL, 8,	80, 12), --  BICI_ORC_TACTICAL L2I2O depends on FDM Landing 
								(@IFRS17_Orchestration_DL, 28,	80, 12), --  BICI_ORC_TACTICAL L2I2O depends on BICI_ORC_TACTICAL Landing 

								--Level 13 BICI_RI_Incurred-9
								(@IFRS17_Orchestration_DL, 6,	71, 13), --  BICI_RI_Incurred L2I2O depends on LPSO Landing 
								(@IFRS17_Orchestration_DL, 29,	71, 13), --  BICI_RI_Incurred L2I2O depends on BICI_RIIncurred Landing 

								--Level 14 BICI_RI_Paid-10
								(@IFRS17_Orchestration_DL, 6,	72, 14), --  BICI_RI_Paid L2I2O depends on LPSO Landing 
								(@IFRS17_Orchestration_DL, 41,	72, 14), --  BICI_RI_Paid L2I2O depends on BICI_RI_Paid Landing 

								--Level 15 BICI_RI_Ultimate_Premium-11
								(@IFRS17_Orchestration_DL, 18,	65, 15), --  BICI_RI_Ultimate_Premium L2I2O depends on BICI_RI_Ultimate_Premium Landing 
								(@IFRS17_Orchestration_DL, 65,	91, 15), --  Common_Tactical_Proc I2O depends on BICI_RI_Ultimate_Premium I2O 

								--Level 16 BIDAC-12
								(@IFRS17_Orchestration_DL, 6,	213, 16), --  BIDAC L2I depends on LPSO Landing 
								(@IFRS17_Orchestration_DL, 7,	213, 16), --  BIDAC L2I depends on MDS Landing 
								(@IFRS17_Orchestration_DL, 35,	213, 16), --  BIDAC L2I depends on BIDAC Landing 
								(@IFRS17_Orchestration_DL, 213,	226, 16), --  Common_GAAP_Proc I2O depends on BIDAC L2I  

								--Level 17 BusinessPlan-13
								(@IFRS17_Orchestration_DL, 17,	62, 17), --  BusinessPlan L2I depends on BusinessPlan Landing 
								(@IFRS17_Orchestration_DL, 62,	91, 17), --  Common_Tactical_Proc I2O depends on BusinessPlan L2I  

								--Level 18 BusinessPlanRI-14
								(@IFRS17_Orchestration_DL, 21,	68, 18), --  BusinessPlanRI L2I depends on BusinessPlanRI Landing 
								(@IFRS17_Orchestration_DL, 68,	91, 18), --  Common_Tactical_Proc I2O depends on BusinessPlanRI L2I  

								--Level 19 Ceded_Re_Claims_Incurred-15
								(@IFRS17_Orchestration_DL, 6,	183, 19), --  Ceded_Re_Claims_Incurred L2I2O depends on LPSO Landing 
								(@IFRS17_Orchestration_DL, 8,	183, 19), --  Ceded_Re_Claims_Incurred L2I2O depends on FDM Landing 
								(@IFRS17_Orchestration_DL, 13,	183, 19), --  Ceded_Re_Claims_Incurred L2I2O depends on CededRe Landing 

								--Level 20 Ceded_Re_Closed_YOA-16
								(@IFRS17_Orchestration_DL, 6,	184, 20), --  Ceded_Re_Closed_YOA L2I2O depends on LPSO Landing 
								(@IFRS17_Orchestration_DL, 8,	184, 20), --  Ceded_Re_Closed_YOA L2I2O depends on FDM Landing 
								(@IFRS17_Orchestration_DL, 13,	184, 20), --  Ceded_Re_Closed_YOA L2I2O depends on CededRe Landing 

								--Level 21 Ceded_Re_ORC-17
								(@IFRS17_Orchestration_DL, 6,	185, 21), --  Ceded_Re_ORC L2I2O depends on LPSO Landing 
								(@IFRS17_Orchestration_DL, 8,	185, 21), --  Ceded_Re_ORC L2I2O depends on FDM Landing 
								(@IFRS17_Orchestration_DL, 13,	185, 21), --  Ceded_Re_ORC L2I2O depends on CededRe Landing 

								--Level 22 Claims_BI_ODS-18
								(@IFRS17_Orchestration_DL, 7,	137, 22), --  BICC L2I2O depends on MDS Landing 
								(@IFRS17_Orchestration_DL, 15,	137, 22), --  BICC L2I2O depends on BICC Landing 

								--Level 23 Earned_RIP_RISpend-19
								(@IFRS17_Orchestration_DL, 8,	187, 23), --  Earned_RIP_RISpend L2I2O depends on Earned_RIP_RISpend Landing 
								(@IFRS17_Orchestration_DL, 30,	187, 23), --  Earned_RIP_RISpend L2I2O depends on EarnedRIP_RISpendBESI  Landing

								--Level 24 EPI Reinstatement Eurobase-20
								(@IFRS17_Orchestration_DL, 14,	77, 24), --  EPI Reinstatement Eurobase L2I2O depends on SyndicateSplit Landing 
								(@IFRS17_Orchestration_DL, 27,	77, 24), --  EPI Reinstatement Eurobase L2I2O depends on EurobaseEPIReInstatement Landing 

								--Level 25 Eurobase-21
								(@IFRS17_Orchestration_DL, 31,	78, 25), --  Eurobase L2I depends on Eurobase Tactical Landing 
								(@IFRS17_Orchestration_DL, 78,	91, 25), --  Common_Tactical_Proc I2O depends on Eurobase L2I 

								--Level 25 Expenses Actual-22
								(@IFRS17_Orchestration_DL, 14,	64, 26), --  Expenses Actual L2I2O depends on SyndicateSplit Landing 
								(@IFRS17_Orchestration_DL, 24,	64, 26), --  Expenses Actual L2I2O depends on AEA_ExpensesActuals Landing 

								--Level 26 LPSO-23
								(@IFRS17_Orchestration_DL, 6,	138, 27), -- LPSO L2I2O depends on LPSO Landing 
								(@IFRS17_Orchestration_DL, 7,	138, 27), -- LPSO L2I2O depends on MDS Landing 
								(@IFRS17_Orchestration_DL, 8,	138, 27), -- LPSO L2I2O depends on FDM Landing 

								--Level 27 NatCatEarning-24
								(@IFRS17_Orchestration_DL, 2,	108, 28), -- NatCatEarning L2I depends on NatCatEarning Landing 
								--(@IFRS17_Orchestration_DL, 108,	152, 28), -- Common_Pattern_Proc I2O depends on NatCatEarning L2I

								--Level 28 ObligatedPremium_MunichQQS-25
								(@IFRS17_Orchestration_DL, 8,	75, 29), --  ObligatedPremium_MunichQQS L2I2O depends on FDM Landing 
								(@IFRS17_Orchestration_DL, 9,	75, 29), --  ObligatedPremium_MunichQQS L2I2O depends on ADM Landing 
								(@IFRS17_Orchestration_DL, 108,	152, 29), -- Common_Pattern_Proc I2O depends on NatCatEarning L2I

								--Level 29 ObligatedPremium_RISpend-26
								(@IFRS17_Orchestration_DL, 6,	196, 30), -- ObligatedPremium_RISpend L2I2O depends on LPSO Landing 
								(@IFRS17_Orchestration_DL, 8,	196, 30), -- ObligatedPremium_RISpend L2I2O depends on FDM Landing
								(@IFRS17_Orchestration_DL, 45,	196, 30), -- ObligatedPremium_RISpend L2I2O depends on Obligated Premium RISpend BESI Landing

								--Level 30 ObligatedPremium_SPA-27
								(@IFRS17_Orchestration_DL, 6,	74, 31), --  ObligatedPremium_SPA L2I2O depends on LPSO Landing 
								(@IFRS17_Orchestration_DL, 8,	74, 31), --  ObligatedPremium_SPA L2I2O depends on FDM Landing 
								(@IFRS17_Orchestration_DL, 14,	74, 31), --  ObligatedPremium_SPA L2I2O depends on SyndicateSplit Landing 

								--Level 31 PFT-28
								(@IFRS17_Orchestration_DL, 33,	241, 32), -- PFT L2I2O depends on PFT Landing 

								--Level 32 Reinsurance_Overriding_Commission-29
								(@IFRS17_Orchestration_DL, 6,	186, 33), -- Reinsurance_Overriding_Commission L2I2O depends on LPSO Landing 
								(@IFRS17_Orchestration_DL, 8,	186, 33), -- Reinsurance_Overriding_Commission L2I2O depends on FDM Landing 
								(@IFRS17_Orchestration_DL, 44,	186, 33), -- Reinsurance_Overriding_Commission L2I2O depends on ORC BESI Landing 

								--Level 33 ReinsuranceRebates_Paid-30
								(@IFRS17_Orchestration_DL, 3,	202, 34), -- ReinsuranceRebates_Paid L2I2O depends on Paid Rebates Landing 
								(@IFRS17_Orchestration_DL, 6,	202, 34), -- ReinsuranceRebates_Paid L2I2O depends on LPSO Landing 
								(@IFRS17_Orchestration_DL, 8,	202, 34), -- ReinsuranceRebates_Paid L2I2O depends on FDM Landing 
								(@IFRS17_Orchestration_DL, 9,	202, 34), -- ReinsuranceRebates_Paid L2I2O depends on ADM Landing 
								(@IFRS17_Orchestration_DL, 13,	202, 34), -- ReinsuranceRebates_Paid L2I2O depends on CededRe Landing 

								--Level 34 ReinsuranceRebates_Ultimate-31
								(@IFRS17_Orchestration_DL, 4,	181, 35), -- ReinsuranceRebates_Ultimate L2I2O depends on ReinsuranceRebates_Ultimate Landing 
								(@IFRS17_Orchestration_DL, 6,	181, 35), -- ReinsuranceRebates_Ultimate L2I2O depends on LPSO Landing 
								(@IFRS17_Orchestration_DL, 8,	181, 35), -- ReinsuranceRebates_Ultimate L2I2O depends on FDM Landing 
								(@IFRS17_Orchestration_DL, 9,	181, 35), -- ReinsuranceRebates_Ultimate L2I2O depends on ADM Landing 
								(@IFRS17_Orchestration_DL, 13,	181, 35), -- ReinsuranceRebates_Ultimate L2I2O depends on CededRe Landing 

								--Level 35 ResDataEventAlloc-32
								(@IFRS17_Orchestration_DL, 19,	66, 36), -- ResDataEventAlloc L2I depends on ResDataEventAlloc Landing 
								--(@IFRS17_Orchestration_DL, 66,	91, 36), -- Common_Tactical_Proc I2O depends on ResDataEventAlloc L2I 

								--Level 36 ResDataRIAttClmAlloc_Phase1-33
								(@IFRS17_Orchestration_DL, 9,	70, 37), -- ResDataRIAttClmAllocPhase1 LandingProc depends on ADM Landing 
								(@IFRS17_Orchestration_DL, 37,	70, 37), -- ResDataRIAttClmAllocPhase1 LandingProc depends on ResDataRIAttClmAllocPhase1 

								--Level 36 ResDataRIAttClmAlloc_Phase2-34
								(@IFRS17_Orchestration_DL, 38,	82, 37), -- ResDataRIAttClmAlloc_Phase2 LandingProc depends on ResDataRIAttClmAlloc_Phase2 Landing 
								--(@IFRS17_Orchestration_DL, 82,	168, 37), -- ResDataRIAttClmAlloc I2O depends on ResDataRIAttClmAlloc_Phase2 LandingProc 

								--Level 37 ResDataRILargeLossAlloc-35
								(@IFRS17_Orchestration_DL, 40,	73, 38), -- ResDataRILargeLossAlloc L2I depends on ADM_RRDataLargeLosses Landing 
								--(@IFRS17_Orchestration_DL, 73,	91, 38), -- Common_Tactical_Proc L2I2O depends on ResDataRILargeLossAlloc L2I 
								(@IFRS17_Orchestration_DL, 82,	168, 38), -- ResDataRIAttClmAlloc I2O depends on ResDataRIAttClmAlloc_Phase2 LandingProc 

								--Level 38 ReservingData-36
								(@IFRS17_Orchestration_DL, 7,	182, 39), -- ReservingData L2I2O depends on MDS Landing 
								(@IFRS17_Orchestration_DL, 9,	182, 39), -- ReservingData L2I2O depends on ADM Landing 

								--Level 39 ReservingDataPremiumAlloc-37
								(@IFRS17_Orchestration_DL, 6,	76, 40), -- ReservingDataPremiumAlloc L2I2O depends on LPSO Landing 
								(@IFRS17_Orchestration_DL, 7,	76, 40), -- ReservingDataPremiumAlloc L2I2O depends on MDS Landing 
								(@IFRS17_Orchestration_DL, 8,	76, 40), -- ReservingDataPremiumAlloc L2I2O depends on FDM Landing 
								(@IFRS17_Orchestration_DL, 9,	76, 40), -- ReservingDataPremiumAlloc L2I2O depends on ADM Landing 
								(@IFRS17_Orchestration_DL, 13,	76, 40), -- ReservingDataPremiumAlloc L2I2O depends on CededRe Landing 
								(@IFRS17_Orchestration_DL, 14,	76, 40), -- ReservingDataPremiumAlloc L2I2O depends on SyndicateSplit Landing 

								--Level 40 RI LPSO FAC-38
								(@IFRS17_Orchestration_DL, 6,	139, 41), -- RI LPSO FAC L2I2O depends on LPSO Landing 
								(@IFRS17_Orchestration_DL, 7,	139, 41), -- RI LPSO FAC L2I2O depends on MDS Landing 

								--Level 41 RI LPSO TTY-39
								(@IFRS17_Orchestration_DL, 6,	166, 42), -- RI LPSO TTY L2I2O depends on LPSO Landing 
								(@IFRS17_Orchestration_DL, 7,	166, 42), -- RI LPSO TTY L2I2O depends on MDS Landing 
								(@IFRS17_Orchestration_DL, 8,	166, 42), -- RI LPSO TTY L2I2O depends on FDM Landing 
								(@IFRS17_Orchestration_DL, 9,	166, 42), -- RI LPSO TTY L2I2O depends on ADM Landing 
								(@IFRS17_Orchestration_DL, 13,	166, 42), -- RI LPSO TTY L2I2O depends on CededRe Landing 
								(@IFRS17_Orchestration_DL, 14,	166, 42), -- RI LPSO TTY L2I2O depends on SyndicateSplit Landing 
								(@IFRS17_Orchestration_DL, 47,	166, 42), -- RI LPSO TTY L2I2O depends on FACProg Landing 

								--Level 42 Load RIPercentage-40
								(@IFRS17_Orchestration_DL, 8,	79,	 43), -- Load RIPercentage depends on FDM Landing 
								--(@IFRS17_Orchestration_DL, 79,	112, 43), -- Load RIPercentage L2I depends on Load RIPercentage 

								--Level 43 RIPsEventAlloc-41
								(@IFRS17_Orchestration_DL, 20,	67,	44), -- RIPsEventAlloc depends on UltimateRIPsEventAlloc Landing 
								--(@IFRS17_Orchestration_DL, 67,	91,	44), -- Common_Tactical_Proc I2O depends on RIPsEventAlloc L2I
								(@IFRS17_Orchestration_DL, 79,	112, 44), -- Load RIPercentage L2I depends on Load RIPercentage 

								--Level 44 Signed Profit Commission-42
								(@IFRS17_Orchestration_DL, 5,	198, 45), -- Signed Profit Commission L2I2O depends on BeazleyRIMI Landing 
								(@IFRS17_Orchestration_DL, 6,	198, 45), -- Signed Profit Commission L2I2O depends on LPSO Landing 
								(@IFRS17_Orchestration_DL, 8,	198, 45), -- Signed Profit Commission L2I2O depends on FDM Landing 
								(@IFRS17_Orchestration_DL, 9,	198, 45), -- Signed Profit Commission L2I2O depends on ADM Landing 
								(@IFRS17_Orchestration_DL, 13,	198, 45), -- Signed Profit Commission L2I2O depends on CededRe Landing
								(@IFRS17_Orchestration_DL, 112,	113, 45), -- Load RIPercentage I2O depends on Load RIPercentage 
								(@IFRS17_Orchestration_DL, 67,	91,	45),  -- Common_Tactical_Proc I2O depends on RIPsEventAlloc L2I


								--Level 45 SPA_MUNQQS_ORC_TACTICAL-43
								(@IFRS17_Orchestration_DL, 6,	81, 46), -- SPA_MUNQQS_ORC_TACTICAL L2I2O depends on LPSO Landing 
								(@IFRS17_Orchestration_DL, 7,	81, 46), -- SPA_MUNQQS_ORC_TACTICAL L2I2O depends on MDS Landing 
								(@IFRS17_Orchestration_DL, 8,	81, 46), -- SPA_MUNQQS_ORC_TACTICAL L2I2O depends on FDM Landing 
								(@IFRS17_Orchestration_DL, 33,	81, 46), -- SPA_MUNQQS_ORC_TACTICAL L2I2O depends on PFT Landing
								(@IFRS17_Orchestration_DL, 42,	81, 46), -- SPA_MUNQQS_ORC_TACTICAL L2I2O depends on SPA_MUNQQS_ORC_TACTICAL Landing 

								--Level 46 Ultimate Profit Commission-44
								(@IFRS17_Orchestration_DL, 6,	197, 47), -- Ultimate Profit Commission L2I2O depends on LPSO Landing 
								(@IFRS17_Orchestration_DL, 14,	197, 47), -- Ultimate Profit Commission L2I2O depends on SyndicateSplit Landing
								(@IFRS17_Orchestration_DL, 46,	197, 47), -- Ultimate Profit Commission L2I2O depends on NCB Landing
								(@IFRS17_Orchestration_DL, 16,	197, 47), -- Ultimate Profit Commission L2I2O depends on Ult Profit Commission Landing 

								--Level 47 USBAIC-45
								(@IFRS17_Orchestration_DL, 36,	214, 48), -- USBAIC L2I depends on USBAIC Landing 
								(@IFRS17_Orchestration_DL, 214,	226, 48), -- Common_GAAP_Proc I2O depends on USBAIC L2I

								--Level 47 USBESI-46
								(@IFRS17_Orchestration_DL, 7,	215, 47), -- USBESI L2I2O depends on MDS Landing 
								(@IFRS17_Orchestration_DL, 43,	215, 47), -- USBESI L2I2O depends on USBESI Landing 

								--Level 48 USPremium-47
								(@IFRS17_Orchestration_DL, 7,	211, 48), -- USPremium L2I depends on MDS Landing 
								(@IFRS17_Orchestration_DL, 32,	211, 48), -- USPremium L2I depends on USPremium Landing 
								--(@IFRS17_Orchestration_DL, 211,	226, 48) -- Common_GAAP_Proc I2O depends on USPremium L2I

								--Level 49 Remove Dependency
								(@IFRS17_Orchestration_DL, 214,	226, 49), -- Common_GAAP_Proc I2O depends on USPremium L2I
								(@IFRS17_Orchestration_DL, 211,	226, 49)


					) AS Source(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.FK_ChildModule = Source.FK_ChildModule
				AND Target.FK_ParentModule = Source.FK_ParentModule
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
					VALUES(Source.FK_Orchestration,Source.FK_ParentModule,Source.FK_ChildModule,Source.TreeLevel)
			WHEN	MATCHED
			THEN	UPDATE SET	FK_Orchestration = source.FK_Orchestration, 
								FK_ParentModule = source.FK_ParentModule, 
								FK_ChildModule = source.FK_ChildModule, 
								TreeLevel = source.TreeLevel
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_DL
			THEN	DELETE;



			--ModuleActivity select * from etl.ModuleActivity
			MERGE	etl.ModuleActivity Target
			USING	(
						SELECT	m.FK_Orchestration,
								m.PK_Module,
								1, -- Pending
								'Initialization from deployment' -- run description
						FROM	etl.Module m
						WHERE	m.FK_Orchestration = @IFRS17_Orchestration_DL
					) Source (FK_Orchestration, FK_Module, FK_ModuleStatus,RunDescription)
			ON		Source.FK_Orchestration = Target.FK_Orchestration
				AND	Source.FK_Module = Target.FK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT	(FK_Orchestration, FK_Module, FK_ModuleStatus, RunDescription)
					VALUES	(Source.FK_Orchestration, Source.FK_Module, Source.FK_ModuleStatus, Source.RunDescription)
			WHEN	MATCHED
			THEN	UPDATE	SET	Target.FK_ModuleStatus = Source.FK_ModuleStatus, Target.RunDescription = Source.RunDescription
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_DL
			THEN	DELETE;
