﻿Delete from etl.ModuleHierarchy where FK_Orchestration=1
Delete from etl.ModuleActivity where FK_Orchestration=1
Delete From etl.Module where FK_Orchestration=1

MERGE 
INTO	etl.Orchestration AS Target
USING	(VALUES(1, 'Premiums and IFRS17',0)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled)
ON		(Target.PK_Orchestration = Source.PK_Orchestration)
WHEN	NOT MATCHED BY TARGET
THEN	INSERT(PK_Orchestration,OrchestrationName,IsEnabled)
		VALUES(Source.PK_Orchestration,  Source.OrchestrationName,  Source.IsEnabled)
WHEN	MATCHED
THEN	UPDATE SET	Target.ORchestrationName = Source.OrchestrationName,
					Target.IsEnabled = Source.Isenabled;

MERGE 
INTO	etl.Module AS Target
USING	(
			VALUES	--Level 1
					(1,1,'Eurobase ToLanding',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''EurobaseEPI.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
					(1,2,'EB Trifocus Codes', 1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FDMTrifocusCode.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
					(1,3,'US Premium Tolanding',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''USPremium.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
					(1,4,'PFT Forecast Tolanding',1,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''PremiumForecastLanding.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
					(1,5,'ADM ToLanding',  1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADMToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
					(1,6,'EIOPA ToLanding',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_EIOPAToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
					(1,7,'NatCatEarning ToLanding',1,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_NatCatEarningToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
					(1,8,'BICC ToLanding',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BICCToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
					(1,9,'LPSO ToLanding',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_EurobaseToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
					(1,10,'MDS ToLanding',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_MDSToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
					(1,11,'LossRatio ToLanding',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_LossRatioToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								
					--Level 2
					(1,12,'Eurobase ToInbound', 1,		'EXEC [eb].[USP_LandingInboundWorkflow]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
					(1,13,'MDS LandingToInbound', 1,	'EXEC [MDS].[usp_LandingToInbound]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
					(1,14,'EIOPA LandingToInbound', 1,'EXEC [XLS].[usp_EIOPALandingToInbound_DiscountRates]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
					(1,15,'NatCatEarning LandingToInbound', 1,'EXEC [XLS].[usp_NatCatEarningLandingToInbound_Pattern]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
					(1,16,'ADM Pattern LandingToInbound', 1,'EXEC [ADM].[usp_LandingToInbound_Pattern]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
					(1,17,'LossRatio LandingToInbound', 1,'EXEC [XLS].[usp_LandingToInbound_LossRatio]','$(InstanceName)', 'FinanceLanding', NULL, NULL),

					--Level 3
					(1,18,'ADM LandingToInbound', 1,'EXEC [ADM].[usp_LandingToInbound]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
					(1,19,'BICC LandingToInbound',1,'EXEC [BICC].[usp_LandingToInbound]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
					(1,20,'LPSO LandingToInbound',1,'EXEC [Eurobase].[usp_LandingToInbound]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
					(1,21,'LPSO LandingToInbound EPI',1,'EXEC [Eurobase].[usp_LandingToInbound_EPI]','$(InstanceName)', 'FinanceLanding', NULL, NULL),

					--Level 4
					(1,22,'US Landing', 1,			'EXEC [us].[usp_LandingInboundWorkflow]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
					(1,23,'PFT Landing', 1,			'EXEC [pft].[usp_LandingInboundWorkflow]','$(InstanceName)', 'FinanceLanding', NULL, NULL),

					--Level 5
					(1,24,'DataContract Pattern InboundToOutbound',1, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_Pattern]'	,'$(InstanceName)', 'FinanceDataContract', NULL, NULL),
					(1,25,'DataContract LossRatio InboundToOutbound',1, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_LossRatio]'	,'$(InstanceName)', 'FinanceDataContract', NULL, NULL),
					(1,26,'DataContract ClaimLargeLoss InboundToOutbound',1, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_ClaimLargeLoss]'	,'$(InstanceName)', 'FinanceDataContract', NULL, NULL),
					(1,27,'DataContract DiscountRates InboundToOutbound',1, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_DiscountRates]'	,'$(InstanceName)', 'FinanceDataContract', NULL, NULL),

					--Level 6
					(1,28,'DataContract Transaction',1,			'EXEC [Inbound].[usp_InboundOutboundWorkflow]'	,'$(InstanceName)', 'FinanceDataContract', NULL, NULL),


					--Level 7

					(1,29,'DimTrifocus', 1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTrifocus.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,	 NULL),
					(1,30,'DimEntity',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimEntity.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
					(1,31,'DimYOA',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimYOA.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
					(1,32,'DimCCY',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimCCY.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL), 
					(1,33,'DimProduct',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimProduct.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
					(1,34,'DimLocation',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimLocation.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
					(1,35,'DimPolicy',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPolicy.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
					(1,36,'DimAccount',1,			'EXEC  [Dim].[MergeAccountsBR1]','$(InstanceName)', 'TechnicalHub', NULL, NULL),
					(1,37,'DimDataset',1,			'EXEC  [Dim].[MergeDatasetBR1]','$(InstanceName)', 'TechnicalHub', NULL, NULL),
					(1,38,'DimPatternName',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPatternName.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
					(1,39,'DimLargeLossCatCode',1,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimLargeLossCatCode.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
					(1,43,'DimRateScenario',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimRateScenario.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
					(1,44,'DimReportingCurrency',1,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimReportingCurrency.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
					--Level 8
					(1,40,'Premiums Fact load',1,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactTechnicalResult.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

					--level 9
					(1,41,'IFRS2017TechResult',1,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactTechnicalResult_IFRS2017.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
					(1,42,'Fact Pattern',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactPattern.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
					(1,50,'Fact DiscountRates',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactDiscountRates.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

					--Level 10
					(1,45,'Premium Earnings',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactEarning.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
					--Level 11
					(1,46,'Premium SideCar',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactSideCar.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
					(1,47,'FX Rates',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactFxRates.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

					--Level 12
					(1,48,'Post Initial and Subsequment',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''Post Fact Initial Subsequent.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

					--Level 13
					(1,49,'Cube Process',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''CubeBuild.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL)
		)

			AS Source(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
ON		Target.FK_Orchestration = Source.FK_Orchestration
	AND Target.PK_Module = Source.PK_Module
WHEN	NOT MATCHED BY TARGET
THEN	INSERT(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
		VALUES(Source.FK_Orchestration,  Source.PK_module,  Source.ModuleName,  Source.FK_ModuleType,  Source.ModuleRoutine,  Source.DestinationServer,  Source.DestinationDatabase,Source.FK_Schedule,Source.FK_Notification)
WHEN	MATCHED
THEN	UPDATE SET		FK_Orchestration	= source.FK_Orchestration, 
						PK_module 			= source.PK_module, 
						ModuleName 			= source.ModuleName, 
						FK_ModuleType 		= source.FK_ModuleType, 
						ModuleRoutine 		= source.ModuleRoutine, 
						DestinationServer	= source.DestinationServer, 
						DestinationDatabase	= source.DestinationDatabase, 
						FK_Schedule 		= source.FK_Schedule, 
						FK_Notification		= source.FK_Notification
WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = 1
THEN	DELETE;

MERGE 
INTO	etl.ModuleHierarchy AS Target
USING	(
			VALUES	

				
				--Level 1
				(1, 	NULL,	1,		1),
				(1, 	NULL,	2,		1),
				(1, 	NULL,	3,		1),
				(1, 	NULL,	4,		1),
				(1, 	NULL,	5,		1),
				(1, 	NULL,	6,		1),
				(1, 	NULL,	7,		1),
				(1, 	NULL,	8,		1),
				(1, 	NULL,	9,		1),
				(1, 	NULL,	10,		1),
				(1, 	NULL,	11,		1),
				
				--level 2
				(1, 	2,		12,		2),
				(1, 	1,		12,		2),
				(1, 	3,		12,		2),
				(1, 	4,		12,		2),
				(1, 	5,		12,		2),
				(1, 	6,		12,		2),
				(1, 	7,		12,		2),
				(1, 	8,		12,		2),
				(1, 	9,		12,		2),
				(1, 	10,		12,		2),
				(1, 	11,		12,		2),

				(1, 	2,		13,		2),
				(1, 	1,		13,		2),
				(1, 	3,		13,		2),
				(1, 	4,		13,		2),
				(1, 	5,		13,		2),
				(1, 	6,		13,		2),
				(1, 	7,		13,		2),
				(1, 	8,		13,		2),
				(1, 	9,		13,		2),
				(1, 	10,		13,		2),
				(1, 	11,		13,		2),

				(1, 	2,		14,		2),
				(1, 	1,		14,		2),
				(1, 	3,		14,		2),
				(1, 	4,		14,		2),
				(1, 	5,		14,		2),
				(1, 	6,		14,		2),
				(1, 	7,		14,		2),
				(1, 	8,		14,		2),
				(1, 	9,		14,		2),
				(1, 	10,		14,		2),
				(1, 	11,		14,		2),

				(1, 	2,		15,		2),
				(1, 	1,		15,		2),
				(1, 	3,		15,		2),
				(1, 	4,		15,		2),
				(1, 	5,		15,		2),
				(1, 	6,		15,		2),
				(1, 	7,		15,		2),
				(1, 	8,		15,		2),
				(1, 	9,		15,		2),
				(1, 	10,		15,		2),
				(1, 	11,		15,		2),

				(1, 	2,		16,		2),
				(1, 	1,		16,		2),
				(1, 	3,		16,		2),
				(1, 	4,		16,		2),
				(1, 	5,		16,		2),
				(1, 	6,		16,		2),
				(1, 	7,		16,		2),
				(1, 	8,		16,		2),
				(1, 	9,		16,		2),
				(1, 	10,		16,		2),
				(1, 	11,		16,		2),

				(1, 	2,		17,		2),
				(1, 	1,		17,		2),
				(1, 	3,		17,		2),
				(1, 	4,		17,		2),
				(1, 	5,		17,		2),
				(1, 	6,		17,		2),
				(1, 	7,		17,		2),
				(1, 	8,		17,		2),
				(1, 	9,		17,		2),
				(1, 	10,		17,		2),
				(1, 	11,		17,		2),

				--Level 3
				(1, 	12,		18,		3),
				(1, 	13,		18,		3),
				(1, 	14,		18,		3),
				(1, 	15,		18,		3),
				(1, 	16,		18,		3),
				(1, 	17,		18,		3),

				(1, 	12,		19,		3),
				(1, 	13,		19,		3),
				(1, 	14,		19,		3),
				(1, 	15,		19,		3),
				(1, 	16,		19,		3),
				(1, 	17,		19,		3),
						 
				(1, 	12,		20,		3),
				(1, 	13,		20,		3),
				(1, 	14,		20,		3),
				(1, 	15,		20,		3),
				(1, 	16,		20,		3),
				(1, 	17,		20,		3),

				(1, 	12,		21,		3),
				(1, 	13,		21,		3),
				(1, 	14,		21,		3),
				(1, 	15,		21,		3),
				(1, 	16,		21,		3),
				(1, 	17,		21,		3),

				--Level 4
				(1, 	18,		22,		4),
				(1, 	19,		22,		4),
				(1, 	20,		22,		4),
				(1, 	21,		22,		4),
										
				(1, 	18,		23,		4),
				(1, 	19,		23,		4),
				(1, 	20,		23,		4),
				(1, 	21,		23,		4),
				

				--Level 5

				(1, 	22,		24,		5),
				(1, 	22,		24,		5),
				(1, 	22,		24,		5),
				(1, 	22,		24,		5),
										
				(1, 	23,		24,		5),
				(1, 	23,		24,		5),
				(1, 	23,		24,		5),
				(1, 	23,		24,		5),
				
				(1, 	22,		25,		5),
				(1, 	22,		25,		5),
				(1, 	22,		25,		5),
				(1, 	22,		25,		5),
										
				(1, 	23,		25,		5),
				(1, 	23,		25,		5),
				(1, 	23,		25,		5),
				(1, 	23,		25,		5),


				(1, 	22,		26,		5),
				(1, 	22,		26,		5),
				(1, 	22,		26,		5),
				(1, 	22,		26,		5),
										
				(1, 	23,		26,		5),
				(1, 	23,		26,		5),
				(1, 	23,		26,		5),
				(1, 	23,		26,		5),
				
				(1, 	22,		27,		5),
				(1, 	22,		27,		5),
				(1, 	22,		27,		5),
				(1, 	22,		27,		5),
										
				(1, 	23,		27,		5),
				(1, 	23,		27,		5),
				(1, 	23,		27,		5),
				(1, 	23,		27,		5),

				--Level 6
				(1, 	24,		28,		6),
				(1, 	25,		28,		6),
				(1, 	26,		28,		6),
				(1, 	27,		28,		6),

				--Level 7
				(1, 	28,		29,		7),
				(1, 	28,		30,		7),
				(1, 	28,		31,		7),
				(1, 	28,		32,		7),
				(1, 	28,		33,		7),
				(1, 	28,		34,		7),
				(1, 	28,		35,		7),
				(1, 	28,		36,		7),
				(1, 	28,		37,		7),
				(1, 	28,		38,		7),
				(1, 	28,		39,		7),
				(1, 	28,		43,		7),
				(1, 	28,		44,		7),


				--Level 8
				(1, 	29,		40,		8),
				(1, 	30,		40,		8),
				(1, 	31,		40,		8),
				(1, 	32,		40,		8),
				(1, 	33,		40,		8),
				(1, 	34,		40,		8),
				(1, 	35,		40,		8),
				(1, 	36,		40,		8),
				(1, 	37,		40,		8),
				(1, 	38,		40,		8),
				(1, 	39,		40,		8),
				(1, 	43,		40,		8),
				(1, 	44,		40,		8),

				--level 9
				(1, 	40,		41,		9),
				(1, 	40,		42,		9),
				(1, 	40,		50,		9),

				--Level 10
				(1, 	41,		45,		10),
				(1, 	42,		45,		10),
				(1, 	50,		45,		10),

				--Level 11
				(1, 	45,		46,		10),
				(1, 	45,		47,		10),

				--level 12
				(1, 	46,		48,		11),
				(1, 	47,		48,		11),
				--Level 13
				(1, 	48,		49,		12)
		) AS Source(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
ON		Target.FK_Orchestration = Source.FK_Orchestration
	AND Target.FK_ChildModule = Source.FK_ChildModule
	AND Target.FK_ParentModule = Source.FK_ParentModule
WHEN	NOT MATCHED BY TARGET
THEN	INSERT(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
		VALUES(Source.FK_Orchestration,Source.FK_ParentModule,Source.FK_ChildModule,Source.TreeLevel)
WHEN	MATCHED
THEN	UPDATE SET	FK_Orchestration = source.FK_Orchestration, 
					FK_ParentModule = source.FK_ParentModule, 
					FK_ChildModule = source.FK_ChildModule, 
					TreeLevel = source.TreeLevel
WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = 1
THEN	DELETE;


MERGE	etl.ModuleActivity Target
USING	(
			SELECT	m.FK_Orchestration,
					m.PK_Module,
					1
			FROM	etl.Module m
			WHERE	m.FK_Orchestration = 1
		) Source (FK_Orchestration, FK_Module, FK_ModuleStatus)
ON		Source.FK_Orchestration = Target.FK_Orchestration
	AND	Source.FK_Module = Target.FK_Module
WHEN	NOT MATCHED BY TARGET
THEN	INSERT	(FK_Orchestration, FK_Module, FK_ModuleStatus)
		VALUES	(Source.FK_Orchestration, Source.FK_Module, Source.FK_ModuleStatus)
WHEN	MATCHED
THEN	UPDATE	SET	Target.FK_ModuleStatus = Source.FK_ModuleStatus
WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = 1
THEN	DELETE;


