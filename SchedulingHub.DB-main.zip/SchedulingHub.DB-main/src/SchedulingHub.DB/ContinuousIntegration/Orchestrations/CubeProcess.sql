﻿			MERGE 
			INTO	etl.Orchestration AS Target
			USING	(VALUES(2, 'Cube Process',0)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled)
			ON		(Target.PK_Orchestration = Source.PK_Orchestration)
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(PK_Orchestration,OrchestrationName,IsEnabled)
					VALUES(Source.PK_Orchestration,  Source.OrchestrationName,  Source.IsEnabled)
			WHEN	MATCHED
			THEN	UPDATE SET	Target.ORchestrationName = Source.OrchestrationName,
								Target.IsEnabled = Source.Isenabled;

			MERGE 
			INTO	etl.Module AS Target
			USING	(
						VALUES	--Level 1
								(2,1,'Cube Process',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''CubeBuild.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL)
						)
					
						AS Source(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.PK_Module = Source.PK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
					VALUES(Source.FK_Orchestration,  Source.PK_module,  Source.ModuleName,  Source.FK_ModuleType,  Source.ModuleRoutine,  Source.DestinationServer,  Source.DestinationDatabase,Source.FK_Schedule,Source.FK_Notification)
			WHEN	MATCHED
			THEN	UPDATE SET		FK_Orchestration	= source.FK_Orchestration, 
									PK_module 			= source.PK_module, 
									ModuleName 			= source.ModuleName, 
									FK_ModuleType 		= source.FK_ModuleType, 
									ModuleRoutine 		= source.ModuleRoutine, 
									DestinationServer	= source.DestinationServer, 
									DestinationDatabase	= source.DestinationDatabase, 
									FK_Schedule 		= source.FK_Schedule, 
									FK_Notification		= source.FK_Notification
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = 2
			THEN	DELETE;

			MERGE 
			INTO	etl.ModuleHierarchy AS Target
			USING	(
						VALUES	--L1 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
								(2,	NULL,	1,	1)
					
							

					) AS Source(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.FK_ChildModule = Source.FK_ChildModule
				AND Target.FK_ParentModule = Source.FK_ParentModule
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
					VALUES(Source.FK_Orchestration,Source.FK_ParentModule,Source.FK_ChildModule,Source.TreeLevel)
			WHEN	MATCHED
			THEN	UPDATE SET	FK_Orchestration = source.FK_Orchestration, 
								FK_ParentModule = source.FK_ParentModule, 
								FK_ChildModule = source.FK_ChildModule, 
								TreeLevel = source.TreeLevel
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = 2
			THEN	DELETE;


			MERGE	etl.ModuleActivity Target
			USING	(
						SELECT	m.FK_Orchestration,
								m.PK_Module,
								1
						FROM	etl.Module m
						WHERE	m.FK_Orchestration = 2
					) Source (FK_Orchestration, FK_Module, FK_ModuleStatus)
			ON		Source.FK_Orchestration = Target.FK_Orchestration
				AND	Source.FK_Module = Target.FK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT	(FK_Orchestration, FK_Module, FK_ModuleStatus)
					VALUES	(Source.FK_Orchestration, Source.FK_Module, Source.FK_ModuleStatus)
			WHEN	MATCHED
			THEN	UPDATE	SET	Target.FK_ModuleStatus = Source.FK_ModuleStatus
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = 2
			THEN	DELETE;