﻿
declare @IFRS17_InstanceName_IL nvarchar(129) = '$(InstanceName)'


declare @IFRS17_Orchestration_IL int = 13
declare @IFRS17_Orchestration_IsEnabledIL int = 1
declare @IFRS17_RunTimeExecutionPriorityOrderIL int = 1

Delete from etl.ModuleHierarchy where FK_Orchestration=13
Delete from etl.ModuleActivity where FK_Orchestration=13
Delete From etl.Module where FK_Orchestration=13


  --orchestration select * from etl.Orchestration
			MERGE 
			INTO	etl.Orchestration AS Target
			USING	(VALUES(@IFRS17_Orchestration_IL, 'IFRS17_IL',@IFRS17_Orchestration_IsEnabledIL)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled)
			ON		(Target.PK_Orchestration = Source.PK_Orchestration)
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(PK_Orchestration,OrchestrationName,IsEnabled)
					VALUES(Source.PK_Orchestration,  Source.OrchestrationName,  Source.IsEnabled)
			WHEN	MATCHED
			THEN	UPDATE SET	Target.ORchestrationName = Source.OrchestrationName,
								Target.IsEnabled = Source.Isenabled;



declare @FK_ModuleType_SPIL int = (select PK_ModuleType from [etl].[ModuleType] where ModuleType = 'SPROC')

			MERGE --@IFRS17_Orchestration_IL
			INTO	etl.Module AS Target
			USING	(
						VALUES	--Level 1 1*15=1-15
								(@IFRS17_Orchestration_IL,1,'MDS ToLanding',@FK_ModuleType_SPIL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_MDSToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_IL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_IL,2,'FDM ToLanding',@FK_ModuleType_SPIL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_FDMToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_IL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_IL,3,'ADM ToLanding',  @FK_ModuleType_SPIL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADMToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_IL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_IL,4,'SyndicateSplit Landing',@FK_ModuleType_SPIL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''SyndicateSplit.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_IL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_IL,5,'Eurobase',@FK_ModuleType_SPIL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''EurobaseTacticalLoad.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_IL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_IL,6,'BICI_RIPaid Landing',  @FK_ModuleType_SPIL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName =''IFRS17_BICIRI_Paid.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_IL,'SchedulingHub',NULL,NULL),
							
								
								--Level	2
							    (@IFRS17_Orchestration_IL,31,'AccountName Transaction InboundToOutbound',@FK_ModuleType_SPIL,'EXEC [Inbound].[usp_InboundOutboundWorkflow_AccountNames]'	,@IFRS17_InstanceName_IL, 'FinanceDataContract', NULL, NULL),																
								--Level 3
								(@IFRS17_Orchestration_IL,46,'ADM LandingToInboundToOutbound', @FK_ModuleType_SPIL,'EXEC [ADM].[usp_LandingToInboundToOutbound]',@IFRS17_InstanceName_IL, 'FinanceLanding', NULL, NULL),
								
								  
								--Level 4
								(@IFRS17_Orchestration_IL,61,'BICI_RIPaid LandingToInbound',@FK_ModuleType_SPIL,'EXEC  [BICIRI].[usp_LandingInboundWorkflow_BICI_RI_Paid]'	,@IFRS17_InstanceName_IL, 'FinanceLanding', NULL, NULL),
                                
								--Level 5
								(@IFRS17_Orchestration_IL,76,'EB Landing',@FK_ModuleType_SPIL,'EXEC [Eb].[usp_LandingInboundWorkflow_EurobaseTacticalLoad]'	,@IFRS17_InstanceName_IL, 'FinanceLanding', NULL, NULL),	

								--Level 6
								(@IFRS17_Orchestration_IL,91,'Inbound To OutBound for Tactical Loads',@FK_ModuleType_SPIL,'EXEC [TL].[usp_InboundOutBoundWorkflow_TacticalLoads]'	,@IFRS17_InstanceName_IL, 'Financedatacontract', NULL, NULL),								
								
								
								--Level 7  -166-180
								(@IFRS17_Orchestration_IL,166,'DimTrifocus', @FK_ModuleType_SPIL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTrifocus.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,	 NULL),
								(@IFRS17_Orchestration_IL,167,'DimEntity',@FK_ModuleType_SPIL,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimEntity.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_IL,168,'DimYOA',@FK_ModuleType_SPIL,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimYOA.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_IL,169,'DimCCY',@FK_ModuleType_SPIL,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimCCY.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL), 
								(@IFRS17_Orchestration_IL,170,'DimProduct',@FK_ModuleType_SPIL,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimProduct.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_IL,171,'DimLocation',@FK_ModuleType_SPIL,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimLocation.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								--(@IFRS17_Orchestration_IL,157,'DimPolicy',@FK_ModuleType_SPIL,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPolicy.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_IL,172,'Dummy Load',@FK_ModuleType_SPIL,'SELECT 1'	,@IFRS17_InstanceName_IL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_IL,173,'DimAccount',@FK_ModuleType_SPIL,			'SELECT 1',@IFRS17_InstanceName_IL, 'TechnicalHub', NULL, NULL),
								(@IFRS17_Orchestration_IL,174,'DimDataset',@FK_ModuleType_SPIL,			'EXEC  [Dim].[MergeDatasetBR1]','$(InstanceName)', 'TechnicalHub', NULL, NULL),
								(@IFRS17_Orchestration_IL,175,'DimPatternName',@FK_ModuleType_SPIL,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPatternName.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_IL,176,'DimCatCode',@FK_ModuleType_SPIL,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimCatCode.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_IL,177,'DimMovementType',@FK_ModuleType_SPIL,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimMovementType.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_IL,178,'DimAccountDtsx', @FK_ModuleType_SPIL,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimAccount.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,	 NULL),
								(@IFRS17_Orchestration_IL,179,'DimClaimExposure', @FK_ModuleType_SPIL,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimClaimExposure.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,	 NULL),
								(@IFRS17_Orchestration_IL,180,'DimPolicySection', @FK_ModuleType_SPIL,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPolicySection.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,	 NULL),

								--Level 8 --181-195
								(@IFRS17_Orchestration_IL,181,'DimTrackingStatus',@FK_ModuleType_SPIL,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTrackingStatus.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_IL,182,'DimRIPolicyType',@FK_ModuleType_SPIL,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimRIPolicyType.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_IL,183,'DimProgrammeCode',@FK_ModuleType_SPIL,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimProgrammeCode.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_IL,184,'DimTriangleGroup',@FK_ModuleType_SPIL,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTriangleGroup.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_IL,185,'DimReservingDataSet',@FK_ModuleType_SPIL,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimReservingDataset.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_IL,186,'DimRateScenario',@FK_ModuleType_SPIL,	    'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimRateScenario.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_IL,187,'DimReportingCurrency',@FK_ModuleType_SPIL,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimReportingCurrency.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),

								--Level 9  --196-205
								(@IFRS17_Orchestration_IL,196,'IFRS2017TechResult',@FK_ModuleType_SPIL,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactTechnicalResult_IFRS2017.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_IL,197,'Fact Pattern',@FK_ModuleType_SPIL,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactPattern.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_IL,198,'Fact Discountrates',@FK_ModuleType_SPIL,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactDiscountRates.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_IL,199,'StandAlone Loads',@FK_ModuleType_SPIL,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''StandaloneLoads.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

								--Level 10
								(@IFRS17_Orchestration_IL,206,'Tech Fact',@FK_ModuleType_SPIL,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactTechnicalResult.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

								--Level 11
								(@IFRS17_Orchestration_IL,221,'Earning',@FK_ModuleType_SPIL,		'SELECT 1','$(InstanceName)', 'SchedulingHub', NULL, NULL),

								--Level 12
								(@IFRS17_Orchestration_IL,226,'SideCar',@FK_ModuleType_SPIL,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactSideCar.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_IL,227,'FXRate'	,@FK_ModuleType_SPIL,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactFxRates.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL)

								
					)
						AS Source(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.PK_Module = Source.PK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
					VALUES(Source.FK_Orchestration,  Source.PK_module,  Source.ModuleName,  Source.FK_ModuleType,  Source.ModuleRoutine,  Source.DestinationServer,  Source.DestinationDatabase,Source.FK_Schedule,Source.FK_Notification)
			WHEN	MATCHED
			THEN	UPDATE SET		FK_Orchestration	= source.FK_Orchestration, 
									PK_module 			= source.PK_module, 
									ModuleName 			= source.ModuleName, 
									FK_ModuleType 		= source.FK_ModuleType, 
									ModuleRoutine 		= source.ModuleRoutine, 
									DestinationServer	= source.DestinationServer, 
									DestinationDatabase	= source.DestinationDatabase, 
									FK_Schedule 		= source.FK_Schedule, 
									FK_Notification		= source.FK_Notification
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_IL
			THEN	DELETE;




			--ModuleHierarchy select * from etl.ModuleHierarchy
			MERGE 
			INTO	etl.ModuleHierarchy AS Target
			USING	(
						VALUES	--L1

								(@IFRS17_Orchestration_IL,	NULL,	1,	1), --
								(@IFRS17_Orchestration_IL,	NULL,	2,	1), -- 
								(@IFRS17_Orchestration_IL,	NULL,	3,	1), --
								(@IFRS17_Orchestration_IL,	NULL,	4,	1), -- 
								(@IFRS17_Orchestration_IL,	NULL,   5, 1), --
								(@IFRS17_Orchestration_IL,	NULL,   6, 1), --
								--L2
								(@IFRS17_Orchestration_IL,	1,31, 2), --
								(@IFRS17_Orchestration_IL,	2,31, 2), -- 
								(@IFRS17_Orchestration_IL,	3,31, 2), --
								(@IFRS17_Orchestration_IL,	4,31, 2), -- 
								(@IFRS17_Orchestration_IL,	5,31, 2), --
								(@IFRS17_Orchestration_IL,	6,31, 2), --
								
								
								--L3
								
								(@IFRS17_Orchestration_IL,	31,	46, 3),
								

								
								--L4
								(@IFRS17_Orchestration_IL,	46,	61, 4),
								
								--L5
								(@IFRS17_Orchestration_IL,	61,	76, 5),
						
								
								--L6
								(@IFRS17_Orchestration_IL,	76,	91, 6),
								
								

								--L7 --Dims
							
								(@IFRS17_Orchestration_IL,	91,	166,		7), 
								(@IFRS17_Orchestration_IL,	91,	167,		7),
								(@IFRS17_Orchestration_IL,	91,	168,		7),
								(@IFRS17_Orchestration_IL,	91,	169,		7), 
								(@IFRS17_Orchestration_IL,	91,	170,		7),
								(@IFRS17_Orchestration_IL,	91,	171,		7),
								(@IFRS17_Orchestration_IL,	91,	172,		7), 
								(@IFRS17_Orchestration_IL,	91,	173,		7),
								(@IFRS17_Orchestration_IL,	91,	174,		7),
								(@IFRS17_Orchestration_IL,	91,	175,		7), 
								(@IFRS17_Orchestration_IL,	91,	176,		7),
								(@IFRS17_Orchestration_IL,	91,	177,		7),
								(@IFRS17_Orchestration_IL,	91,	178,		7), 
								(@IFRS17_Orchestration_IL,	91,	179,		7),
								(@IFRS17_Orchestration_IL,	91,	180,		7),

								--L8
								(@IFRS17_Orchestration_IL,		166, 181,		8), 
								(@IFRS17_Orchestration_IL,		167, 181,		8),
								(@IFRS17_Orchestration_IL,		168, 181,		8),
								(@IFRS17_Orchestration_IL,		169, 181,		8), 
								(@IFRS17_Orchestration_IL,		170, 181,		8),
								(@IFRS17_Orchestration_IL,		171, 181,		8),
								(@IFRS17_Orchestration_IL,		172, 181,		8), 
								(@IFRS17_Orchestration_IL,		173, 181,		8),
								(@IFRS17_Orchestration_IL,		174, 181,		8),
								(@IFRS17_Orchestration_IL,		175, 181,		8), 
								(@IFRS17_Orchestration_IL,		176, 181,	    8),
								(@IFRS17_Orchestration_IL,		177, 181,		8),
								(@IFRS17_Orchestration_IL,		178, 181,		8), 
								(@IFRS17_Orchestration_IL,		179, 181,		8),
								(@IFRS17_Orchestration_IL,		180, 181,		8),

								(@IFRS17_Orchestration_IL,		166, 182,		8), 
								(@IFRS17_Orchestration_IL,		167, 182,		8),
								(@IFRS17_Orchestration_IL,		168, 182,		8),
								(@IFRS17_Orchestration_IL,		169, 182,	    8), 
								(@IFRS17_Orchestration_IL,		170, 182,		8),
								(@IFRS17_Orchestration_IL,		171, 182,		8),
								(@IFRS17_Orchestration_IL,		172, 182,		8), 
								(@IFRS17_Orchestration_IL,		173, 182,		8),
								(@IFRS17_Orchestration_IL,		174, 182,		8),
								(@IFRS17_Orchestration_IL,		175, 182,		8), 
								(@IFRS17_Orchestration_IL,		176, 182,		8),
								(@IFRS17_Orchestration_IL,		177, 182,		8),
								(@IFRS17_Orchestration_IL,		178, 182,		8), 
								(@IFRS17_Orchestration_IL,		179, 182,		8),
								(@IFRS17_Orchestration_IL,		180, 182,		8),

								(@IFRS17_Orchestration_IL,		166, 183,	8), 
								(@IFRS17_Orchestration_IL,		167, 183,		8),
								(@IFRS17_Orchestration_IL,		168, 183,		8),
								(@IFRS17_Orchestration_IL,		169, 183,		8), 
								(@IFRS17_Orchestration_IL,		170, 183,		8),
								(@IFRS17_Orchestration_IL,		171, 183,		8),
								(@IFRS17_Orchestration_IL,		172, 183,		8), 
								(@IFRS17_Orchestration_IL,		173, 183,	8),
								(@IFRS17_Orchestration_IL,		174, 183,		8),
								(@IFRS17_Orchestration_IL,		175, 183,		8), 
								(@IFRS17_Orchestration_IL,		176, 183,		8),
								(@IFRS17_Orchestration_IL,		177, 183,		8),
								(@IFRS17_Orchestration_IL,		178, 183,		8), 
								(@IFRS17_Orchestration_IL,		179, 183,		8),
								(@IFRS17_Orchestration_IL,		180, 183,		8),

								(@IFRS17_Orchestration_IL,		166, 184,		8), 
								(@IFRS17_Orchestration_IL,		167, 184,		8),
								(@IFRS17_Orchestration_IL,		168, 184,		8),
								(@IFRS17_Orchestration_IL,		169, 184,		8), 
								(@IFRS17_Orchestration_IL,		170, 184,		8),
								(@IFRS17_Orchestration_IL,		171, 184,		8),
								(@IFRS17_Orchestration_IL,		172, 184,		8), 
								(@IFRS17_Orchestration_IL,		173, 184,		8),
								(@IFRS17_Orchestration_IL,		174, 184,		8),
								(@IFRS17_Orchestration_IL,		175, 184,		8), 
								(@IFRS17_Orchestration_IL,		176, 184,		8),
								(@IFRS17_Orchestration_IL,		177, 184,	    8),
								(@IFRS17_Orchestration_IL,		178, 184,		8), 
								(@IFRS17_Orchestration_IL,		179, 184,		8),
								(@IFRS17_Orchestration_IL,		180, 184,		8),

								(@IFRS17_Orchestration_IL,		166, 185,		8), 
								(@IFRS17_Orchestration_IL,		167, 185,		8),
								(@IFRS17_Orchestration_IL,		168, 185,		8),
								(@IFRS17_Orchestration_IL,		169, 185,		8), 
								(@IFRS17_Orchestration_IL,		170, 185,		8),
								(@IFRS17_Orchestration_IL,		171, 185,		8),
								(@IFRS17_Orchestration_IL,		172, 185,		8), 
								(@IFRS17_Orchestration_IL,		173, 185,		8),
								(@IFRS17_Orchestration_IL,		174, 185,	    8),
								(@IFRS17_Orchestration_IL,		175, 185,		8), 
								(@IFRS17_Orchestration_IL,		176, 185,		8),
								(@IFRS17_Orchestration_IL,		177, 185,		8),
								(@IFRS17_Orchestration_IL,		178, 185,		8), 
								(@IFRS17_Orchestration_IL,		179, 185,		8),
								(@IFRS17_Orchestration_IL,		180, 185,		8),

								(@IFRS17_Orchestration_IL,		166, 186,		8), 
								(@IFRS17_Orchestration_IL,		167, 186,		8),
								(@IFRS17_Orchestration_IL,		168, 186,		8),
								(@IFRS17_Orchestration_IL,		169, 186,	    8), 
								(@IFRS17_Orchestration_IL,		170, 186,		8),
								(@IFRS17_Orchestration_IL,		171, 186,		8),
								(@IFRS17_Orchestration_IL,		172, 186,	8), 
								(@IFRS17_Orchestration_IL,		173, 186,		8),
								(@IFRS17_Orchestration_IL,		174, 186,		8),
								(@IFRS17_Orchestration_IL,		175, 186,		8), 
								(@IFRS17_Orchestration_IL,		176, 186,	    8),
								(@IFRS17_Orchestration_IL,		177, 186,		8),
								(@IFRS17_Orchestration_IL,		178, 186,		8), 
								(@IFRS17_Orchestration_IL,		179, 186,	8),
								(@IFRS17_Orchestration_IL,		180, 186,		8),

								(@IFRS17_Orchestration_IL,		166, 187,		8), 
								(@IFRS17_Orchestration_IL,		167, 187,		8),
								(@IFRS17_Orchestration_IL,		168, 187,		8),
								(@IFRS17_Orchestration_IL,		169, 187,		8), 
								(@IFRS17_Orchestration_IL,		170, 187,		8),
								(@IFRS17_Orchestration_IL,		171, 187,		8),
								(@IFRS17_Orchestration_IL,		172, 187,		8), 
								(@IFRS17_Orchestration_IL,		173, 187,		8),
								(@IFRS17_Orchestration_IL,		174, 187,		8),
								(@IFRS17_Orchestration_IL,		175, 187,		8), 
								(@IFRS17_Orchestration_IL,		176, 187,		8),
								(@IFRS17_Orchestration_IL,		177, 187,		8),
								(@IFRS17_Orchestration_IL,		178, 187,		8), 
								(@IFRS17_Orchestration_IL,		179, 187,		8),
								(@IFRS17_Orchestration_IL,		180, 187,		8),
								
								--L9

								(@IFRS17_Orchestration_IL,	181,	196,		9), 
								(@IFRS17_Orchestration_IL,	182,	196,		9),
								(@IFRS17_Orchestration_IL,	183,	196,		9),
								(@IFRS17_Orchestration_IL,	184,	196,		9), 
								(@IFRS17_Orchestration_IL,	185,	196,		9),
								(@IFRS17_Orchestration_IL,	186,	196,		9),
								(@IFRS17_Orchestration_IL,	187,	196,		9),

								(@IFRS17_Orchestration_IL,	181,	197,		9), 
								(@IFRS17_Orchestration_IL,	182,	197,		9),
								(@IFRS17_Orchestration_IL,	183,	197,		9),
								(@IFRS17_Orchestration_IL,	184,	197,		9), 
								(@IFRS17_Orchestration_IL,	185,	197,		9),
								(@IFRS17_Orchestration_IL,	186,	197,		9),
								(@IFRS17_Orchestration_IL,	187,	197,		9),
								
								(@IFRS17_Orchestration_IL,	181,	198,		9), 
								(@IFRS17_Orchestration_IL,	182,	198,		9),
								(@IFRS17_Orchestration_IL,	183,	198,		9),
								(@IFRS17_Orchestration_IL,	184,	198,		9), 
								(@IFRS17_Orchestration_IL,	185,	198,		9),
								(@IFRS17_Orchestration_IL,	186,	198,		9),
								(@IFRS17_Orchestration_IL,	187,	198,		9),
								
								(@IFRS17_Orchestration_IL,	181,	199,		9), 
								(@IFRS17_Orchestration_IL,	182,	199,		9),
								(@IFRS17_Orchestration_IL,	183,	199,		9),
								(@IFRS17_Orchestration_IL,	184,	199,		9), 
								(@IFRS17_Orchestration_IL,	185,	199,		9),
								(@IFRS17_Orchestration_IL,	186,	199,		9),
								(@IFRS17_Orchestration_IL,	187,	199,		9),



								--L10
								(@IFRS17_Orchestration_IL,	196,	206,		10), 
								(@IFRS17_Orchestration_IL,	197,	206,		10),
								(@IFRS17_Orchestration_IL,	198,	206,		10),
								(@IFRS17_Orchestration_IL,	199,	206,		10), 

								--L11
								(@IFRS17_Orchestration_IL,	206,	221,		11), 

								--L12
								(@IFRS17_Orchestration_IL,	221,	226,		12),
								(@IFRS17_Orchestration_IL,	221,	227,		12)

-- SSIS packages
--IFRS17_ADMToLandingExtract.dtsx -- > [ADM].[usp_LandingToInbound] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow
--								  -- > [ADM].[usp_LandingToInbound_Pattern] --> FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_Pattern			

--IFRS17_AgressoToLandingExtract.dtsx -- on hold

--IFRS17_BICCToLandingExtract.dtsx -- > [BICC].[usp_LandingToInbound] -- > assume FinanceDataContract.Inbound.usp_InboundOutboundWorkflow but unit test has changed or not there. Ciprian will update me.
--IFRS17_EIOPAToLandingExtract.dtsx -- > [XLS].[usp_EIOPALandingToInbound_DiscountRates] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_DiscountRates
--IFRS17_EurobaseToLandingExtract.dtsx -- > [Eurobase].[usp_LandingToInbound_EPI] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow
--										-- > [Eurobase].[usp_LandingToInbound] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow

-- needs to be added
--IFRS17_LossRatioToLandingExtract.dtsx -- > [XLS].[usp_LandingToInbound_LossRatio] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_LossRatio

--IFRS17_MDSToLandingExtract.dtsx -- > [MDS].[usp_LandingToInbound] -- > no outbound required

--check this!
--IFRS17_NatCatEarningToLandingExtract.dtsx -- > [XLS].[usp_NatCatEarningLandingToInbound_Pattern] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_Pattern


					) AS Source(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.FK_ChildModule = Source.FK_ChildModule
				AND Target.FK_ParentModule = Source.FK_ParentModule
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
					VALUES(Source.FK_Orchestration,Source.FK_ParentModule,Source.FK_ChildModule,Source.TreeLevel)
			WHEN	MATCHED
			THEN	UPDATE SET	FK_Orchestration = source.FK_Orchestration, 
								FK_ParentModule = source.FK_ParentModule, 
								FK_ChildModule = source.FK_ChildModule, 
								TreeLevel = source.TreeLevel
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_IL
			THEN	DELETE;




			--ModuleActivity select * from etl.ModuleActivity
			MERGE	etl.ModuleActivity Target
			USING	(
						SELECT	m.FK_Orchestration,
								m.PK_Module,
								1, -- Pending
								'Initialization from deployment' -- run description
						FROM	etl.Module m
						WHERE	m.FK_Orchestration = @IFRS17_Orchestration_IL
					) Source (FK_Orchestration, FK_Module, FK_ModuleStatus,RunDescription)
			ON		Source.FK_Orchestration = Target.FK_Orchestration
				AND	Source.FK_Module = Target.FK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT	(FK_Orchestration, FK_Module, FK_ModuleStatus, RunDescription)
					VALUES	(Source.FK_Orchestration, Source.FK_Module, Source.FK_ModuleStatus, Source.RunDescription)
			WHEN	MATCHED
			THEN	UPDATE	SET	Target.FK_ModuleStatus = Source.FK_ModuleStatus, Target.RunDescription = Source.RunDescription
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_IL
			THEN	DELETE;

			
	





			