--:setvar InstanceName "UKDVDB149"

/*
	Change log. Please add comments to help us developers make sure we don't miss changes before we check in code.

	Author:			mark.baekdal@beazley.com
	Description:	(@IFRS17_Orchestration_PK,99,'DataContract ReInsuranceTrifocusAllocationsTreaty InboundToOutbound',@FK_ModuleType_SP,'EXEC [Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTreatyContractAttributes]'	,@IFRS17_InstanceName, 'FinanceDataContract', NULL, NULL),
					should have been
					(@IFRS17_Orchestration_PK,99,'DataContract ReInsuranceTrifocusAllocationsTreaty InboundToOutbound',@FK_ModuleType_SP,'EXEC [Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTrifocusAllocationsTreaty]'	,@IFRS17_InstanceName, 'FinanceDataContract', NULL, NULL),

					[Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTreatyContractAttributes] is called by [FinanceLanding].[Eurobase].[usp_LandingToInboundToOutbound_TreatyReInsurance].

*/

declare @IFRS17_InstanceName nvarchar(129) = '$(InstanceName)'

--select @IFRS17_InstanceName

/*
	-- to delete everything and start again. The merge statement can fail when changes break referential entrigity, 
	-- so the data needs to be deleted and re-stated.
declare @IFRS17_Orchestration_PK int = 3

delete etl.ModuleActivity
where FK_Orchestration = @IFRS17_Orchestration_PK

delete etl.ModuleHierarchy
where FK_Orchestration = @IFRS17_Orchestration_PK

delete etl.Module
where FK_Orchestration = @IFRS17_Orchestration_PK

delete etl.Orchestration
where PK_Orchestration = @IFRS17_Orchestration_PK

*/

-- static variables
declare @defaultdate varchar(10)='1900-01-01'
declare @IFRS17_Orchestration_PK int = 3
declare @IFRS17_Orchestration_IsEnabled int = 0
declare @IFRS17_RunTimeExecutionPriorityOrder int = 1


Delete from etl.ModuleHierarchy where FK_Orchestration=3
Delete from etl.ModuleActivity where FK_Orchestration=3
Delete From etl.Module where FK_Orchestration=3

  --orchestration select * from etl.Orchestration
			MERGE 
			INTO	etl.Orchestration AS Target
			USING	(VALUES(@IFRS17_Orchestration_PK, 'IFRS17',@IFRS17_Orchestration_IsEnabled)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled)
			ON		(Target.PK_Orchestration = Source.PK_Orchestration)
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(PK_Orchestration,OrchestrationName,IsEnabled)
					VALUES(Source.PK_Orchestration,  Source.OrchestrationName,  Source.IsEnabled)
			WHEN	MATCHED
			THEN	UPDATE SET	Target.ORchestrationName = Source.OrchestrationName,
								Target.IsEnabled = Source.Isenabled;

			-- code to uncomment when priority column can be released.
			--MERGE 
			--INTO	etl.Orchestration AS Target
			--USING	(VALUES(@IFRS17_Orchestration_PK, 'IFRS17',@IFRS17_Orchestration_IsEnabled,@IFRS17_RunTimeExecutionPriorityOrder)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled,RunTimeExecutionPriorityOrder)
			--ON		(Target.PK_Orchestration = Source.PK_Orchestration)
			--WHEN	NOT MATCHED BY TARGET
			--THEN	INSERT(PK_Orchestration,OrchestrationName,IsEnabled,RunTimeExecutionPriorityOrder)
			--		VALUES(Source.PK_Orchestration,  Source.OrchestrationName,  Source.IsEnabled, Source.RunTimeExecutionPriorityOrder)
			--WHEN	MATCHED
			--THEN	UPDATE SET	Target.ORchestrationName = Source.OrchestrationName,
			--					Target.IsEnabled = Source.Isenabled,
			--					Target.RunTimeExecutionPriorityOrder = Source.RunTimeExecutionPriorityOrder;

--module select * from etl.Module 

declare @FK_ModuleType_SP int = (select PK_ModuleType from [etl].[ModuleType] where ModuleType = 'SPROC')

			MERGE 
			INTO	etl.Module AS Target
			USING	(
						VALUES	--Level 1
							    (@IFRS17_Orchestration_PK,10,'ADM ToLanding',  @FK_ModuleType_SP,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADMToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_PK,20,'EIOPA ToLanding',@FK_ModuleType_SP,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_EIOPAToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_PK,30,'NatCatEarning ToLanding',@FK_ModuleType_SP,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_NatCatEarningToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_PK,40,'BICC ToLanding',@FK_ModuleType_SP,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BICCToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_PK,50,'LPSO ToLanding',@FK_ModuleType_SP,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_EurobaseToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_PK,60,'MDS ToLanding',@FK_ModuleType_SP,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_MDSToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_PK,65,'FDM ToLanding',@FK_ModuleType_SP,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_FDMToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName,'SchedulingHub',NULL,NULL),
								-- Loss Ratio needs to be worked on. It may not be required but it's not ready for testing or UAT as it is.
								--(@IFRS17_Orchestration_PK,70,'LossRatio ToLanding',@FK_ModuleType_SP,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_LossRatioToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName,'SchedulingHub',NULL,NULL),								
								(@IFRS17_Orchestration_PK,73,'ADM DFM PaymentPatterns',@FK_ModuleType_SP,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADM_DFM_PaymentPattern_ToLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_PK,76,'ADM Reserving Data PaymentPatterns',@FK_ModuleType_SP,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADM_ResDat_PaymentPattern_ToLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_PK,78,'ADM S2 Technical Provision PaymentPatterns',@FK_ModuleType_SP,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADM_S2_TPOutput_PaymentPattern_ToLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_PK,79,'BeazleyRIMI to Landing',@FK_ModuleType_SP,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BeazleyMIReinsuranceToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_PK,11,'CededRe to Landing',@FK_ModuleType_SP,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_CededReAccToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_PK,12,'Ultimate Rebates Landing',@FK_ModuleType_SP,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_UltimateRebatesToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_PK,13,'Paid Rebates Landing',@FK_ModuleType_SP,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_PaidRebatesToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_PK,14,'Ult Profit Commission Landing',@FK_ModuleType_SP,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_UltimateProfitCommissionToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName,'SchedulingHub',NULL,NULL),
								
								--Level 2
								(@IFRS17_Orchestration_PK,15,'AgressoAR Landing',@FK_ModuleType_SP,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_AgressoToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_PK,16,'SyndicateSplit Landing',@FK_ModuleType_SP,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''SyndicateSplit.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName,'SchedulingHub',NULL,NULL),

								--Level 3 
								(@IFRS17_Orchestration_PK,80,'MDS LandingToInbound', @FK_ModuleType_SP,'EXEC [MDS].[usp_LandingToInbound]',@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),

								--Level 4 
								(@IFRS17_Orchestration_PK,90,'ADM LandingToInboundToOutbound', @FK_ModuleType_SP,'EXEC [ADM].[usp_LandingToInboundToOutbound]',@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_PK,91,'ReInsurance TrifocusAllocationsTreaty LandingToInbound',@FK_ModuleType_SP,'EXEC [fdm].[usp_LandingToInbound_ReInsuranceTrifocusAllocationsTreaty]'	,@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_PK,92,'AccountName Transaction InboundToOutbound',@FK_ModuleType_SP,'EXEC [Inbound].[usp_InboundOutboundWorkflow_AccountNames]'	,@IFRS17_InstanceName, 'FinanceDataContract', NULL, NULL),								
								(@IFRS17_Orchestration_PK,93,'ReInsurance ObligatedPremium Transaction LandingToInboundToOutbound',@FK_ModuleType_SP,'EXEC [fdm].[usp_LandingToInboundToOutbound_ObligatedPremium]'	,@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_PK,94,'ReInsurance QuotaSharePercentage LandingToInbound',@FK_ModuleType_SP,'EXEC [fdm].[usp_LandingToInbound_ReInsuranceQuotaSharePercentage]'	,@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_PK,95,'Claims_BI_ODS LandingToInboundToOutbound', @FK_ModuleType_SP,'EXEC [Claims_BI_ODS].[usp_LandingToInboundToOutbound]',@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_PK,96,'RISpecialArrangements Transaction LandingToInboundToOutbound',@FK_ModuleType_SP,'EXEC [fdm].[usp_LandingToInboundToOutbound_RISpecialArrangements]'	,@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),								
								--(@IFRS17_Orchestration_PK,96,'ReInsurance PremiumAndRecoveries Transaction LandingToInboundToOutbound',@FK_ModuleType_SP,'EXEC [fdm].[usp_LandingToInboundToOutbound_PremiumAndRecoveries]'	,@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),								
													---- Run Only Baseload/day1 for Paid Rebates,Refer Orches 10/15 for Day2/Normal Load
								(@IFRS17_Orchestration_PK,31,'Signed Profit Commission LandingToInboundToOutbound',@FK_ModuleType_SP,'EXEC [ReinsuranceMI].[usp_LandingToInboundToOutbound_SignedProfitCommission]  NULL, NULL,'''+@defaultdate +''''			,@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_PK,32,'CededReClaimsIncurred LandingToInboundToOutbound',@FK_ModuleType_SP,'EXEC [CededRe].[usp_LandingToInboundToOutbound_CededReClaimsIncurred]'	,@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_PK,33,'CededReClosedYOA LandingToInboundToOutbound',@FK_ModuleType_SP,'EXEC [CededRe].[usp_LandingToInboundToOutbound_CededReClosedYOA]'	,@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_PK,34,'CededReORC LandingToInboundToOutbound',@FK_ModuleType_SP,'EXEC [CededRe].[usp_LandingToInboundToOutbound_CededReORC]'	,@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_PK,35,'UltimateRebates LandingToInboundToOutbound',@FK_ModuleType_SP,'EXEC [ultrebsrc].[usp_LandingToInboundToOutbound_UltimateRIRebate]'	,@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_PK,36,'RI_ReInstatementPremiumEarned LandingToInboundToOutbound',@FK_ModuleType_SP,'EXEC [fdm].[usp_LandingToInboundToOutbound_RI_Reinstatement_Premium_Earned]'	,@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_PK,37,'Ultimate Profit Commission LandingToInboundToOutbound',@FK_ModuleType_SP,'EXEC [ultpc].[usp_LandingToInboundToOutbound_UltimateProfitCommission]'	,@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),								
								
								
								--Level 5 
								(@IFRS17_Orchestration_PK,97,'DataContract Transaction InboundToOutbound',@FK_ModuleType_SP,'EXEC [Inbound].[usp_InboundOutboundWorkflow] @DoNonIFRS17_Tests = 0'	,@IFRS17_InstanceName, 'FinanceDataContract', NULL, NULL),
								(@IFRS17_Orchestration_PK,98,'DataContract ReInsuranceQuotaSharePercentage InboundToOutbound',@FK_ModuleType_SP,'EXEC [Inbound].[usp_InboundOutboundWorkflow_ReInsuranceQuotaSharePercentage]'	,@IFRS17_InstanceName, 'FinanceDataContract', NULL, NULL),
								(@IFRS17_Orchestration_PK,99,'DataContract ReInsuranceTrifocusAllocationsTreaty InboundToOutbound',@FK_ModuleType_SP,'EXEC [Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTrifocusAllocationsTreaty]'	,@IFRS17_InstanceName, 'FinanceDataContract', NULL, NULL),
								(@IFRS17_Orchestration_PK,38,'AgressoARBIDAC LandingToInboundToOutbound',@FK_ModuleType_SP,'EXEC [AgressoAR].[usp_LandingToInboundToOutbound_AgressoARBIDAC]'	,@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_PK,51,'Reinsurance overriding commission LandingToInboundToOutbound',@FK_ModuleType_SP,'EXEC [FDM].[usp_LandingToInboundToOutbound_Reinsurance_Overriding_Commission]'	,@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),
												---- Run Only Baseload/day1 for Paid Rebates,Refer Orches 10/15 for Day2/Normal Load
								(@IFRS17_Orchestration_PK,52,'Paid Rebates LandingToInboundToOutbound', @FK_ModuleType_SP,'EXEC [pdrebsrc].[usp_LandingToInboundToOutbound_PaidRebates]  NULL, NULL,'''+@defaultdate +''''		,@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),								(@IFRS17_Orchestration_PK,53,'Loading RI_Percentage data', @FK_ModuleType_SP,'EXEC [fdm].[usp_LoadtoRI_Percentage]',@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),


																
								--Level 6
								(@IFRS17_Orchestration_PK,100,'EIOPA LandingToInbound', @FK_ModuleType_SP,'EXEC [XLS].[usp_EIOPALandingToInbound_DiscountRates]',@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_PK,110,'NatCatEarning LandingToInbound', @FK_ModuleType_SP,'EXEC [NCME].[usp_NatCatEarningLandingToInbound_Pattern]',@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_PK,130,'LPSO LandingToInboundToOutbound', @FK_ModuleType_SP,'EXEC [Eurobase].[usp_LandingToInboundToOutbound_LPSO]',@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_PK,132,'LPSO LandingToInboundToOutbound Fac ReInsurance', @FK_ModuleType_SP,'EXEC [Eurobase].[usp_LandingToInboundToOutbound_FacReInsurance]',@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),
								
								(@IFRS17_Orchestration_PK,140,'ADM Pattern LandingToInbound', @FK_ModuleType_SP,'EXEC [ADM].[usp_LandingToInbound_Pattern]',@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_PK,145,'BI Policy Section references LandingToInbound', @FK_ModuleType_SP,'EXEC [Claims_BI_ODS].[usp_LandingToInbound_PolicySectionReference]',@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),
							--(@IFRS17_Orchestration_PK,150,'LPSO LandingToInbound EPI', @FK_ModuleType_SP,'EXEC [Eurobase].[usp_LandingToInbound_EPI]',@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL), -- Commenting for CR  https://beazley.atlassian.net/browse/I1B-3328 
								(@IFRS17_Orchestration_PK,150,'LPSO LandingToInbound EPI', @FK_ModuleType_SP,'Select 1',@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),
								-- Loss Ratio needs to be worked on. It may not be required but it's not ready for testing or UAT as it is.
								--(@IFRS17_Orchestration_PK,160,'LossRatio LandingToInbound', @FK_ModuleType_SP,'EXEC [XLS].[usp_LandingToInbound_LossRatio]',@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_PK,151,'Paid Rebates LandingToInbound', @FK_ModuleType_SP,'EXEC [pdrebsrc].[usp_LandingToInbound_PaidRebates]',@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_PK,39,'AgressoARUS LandingToInboundToOutbound',@FK_ModuleType_SP,'EXEC [AgressoAR].[usp_LandingToInboundToOutbound_AgressoARUS]'	,@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_PK,152,'RIPercentage LandingtoInbound',@FK_ModuleType_SP,'EXEC [fdm].[usp_LandingToInbound_RI_Percentage]',@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),

								--Level 7
								(@IFRS17_Orchestration_PK,170,'DataContract Transaction InboundToOutbound',@FK_ModuleType_SP,'EXEC [Inbound].[usp_InboundOutboundWorkflow] @DoNonIFRS17_Tests = 0'	,@IFRS17_InstanceName, 'FinanceDataContract', NULL, NULL),

								(@IFRS17_Orchestration_PK,175,'DataContract Transactional Datasets InboundToOutbound',@FK_ModuleType_SP,'EXEC [Inbound].[usp_InboundOutboundWorkflow_TransactionalDatasets] @DoNonIFRS17_Tests = 0'	,@IFRS17_InstanceName, 'FinanceDataContract', NULL, NULL),

								--Level 8
								(@IFRS17_Orchestration_PK,180,'DataContract DiscountRates InboundToOutbound',@FK_ModuleType_SP, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_DiscountRates]'	,@IFRS17_InstanceName, 'FinanceDataContract', NULL, NULL),
								(@IFRS17_Orchestration_PK,190,'DataContract Pattern InboundToOutbound',@FK_ModuleType_SP, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_Pattern]'	,@IFRS17_InstanceName, 'FinanceDataContract', NULL, NULL),
								-- Loss Ratio needs to be worked on. It may not be required but it's not ready for testing or UAT as it is.
								--(@IFRS17_Orchestration_PK,200,'DataContract LossRatio InboundToOutbound',@FK_ModuleType_SP, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_LossRatio]'	,@IFRS17_InstanceName, 'FinanceDataContract', NULL, NULL),
								(@IFRS17_Orchestration_PK,205,'DataContract PolicySectionReference InboundToOutbound',@FK_ModuleType_SP, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_PolicySectionReferences]'	,@IFRS17_InstanceName, 'FinanceDataContract', NULL, NULL),
								--(@IFRS17_Orchestration_PK,210,'DataContract ClaimExtensions InboundToOutbound',@FK_ModuleType_SP, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_ClaimExtensions]'	,@IFRS17_InstanceName, 'FinanceDataContract', NULL, NULL),
								(@IFRS17_Orchestration_PK,211,'DataContract RIPercentage InboundToOutbound',@FK_ModuleType_SP, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_RIPercentage] '	,@IFRS17_InstanceName, 'FinanceDataContract', NULL, NULL),
								
								-- level 9
								(@IFRS17_Orchestration_PK,215,'DataContract ReInsuranceExtensions InboundToOutbound',@FK_ModuleType_SP, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_ReInsuranceExtensions]'	,@IFRS17_InstanceName, 'FinanceDataContract', NULL, NULL),
								(@IFRS17_Orchestration_PK,217,'DataContract ReInsurance Treaty Landing to InboundToOutbound',@FK_ModuleType_SP, 'EXEC [Eurobase].[usp_LandingToInboundToOutbound_TreatyReInsurance] NULL, NULL,'''+@defaultdate +''''		,@IFRS17_InstanceName, 'FinanceLanding', NULL, NULL),

								-- level 10
								(@IFRS17_Orchestration_PK,220,'DimTrifocus', @FK_ModuleType_SP,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTrifocus.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,	 NULL),
								(@IFRS17_Orchestration_PK,230,'DimEntity',@FK_ModuleType_SP,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimEntity.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_PK,240,'DimYOA',@FK_ModuleType_SP,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimYOA.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_PK,250,'DimCCY',@FK_ModuleType_SP,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimCCY.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL), 
								(@IFRS17_Orchestration_PK,260,'DimProduct',@FK_ModuleType_SP,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimProduct.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_PK,270,'DimLocation',@FK_ModuleType_SP,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimLocation.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								--(@IFRS17_Orchestration_PK,280,'DimPolicy',@FK_ModuleType_SP,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPolicy.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_PK,280,'Dummy Load',@FK_ModuleType_SP,			'SELECT 1'	,@IFRS17_InstanceName, 'FinanceDataContract', NULL, NULL),
								(@IFRS17_Orchestration_PK,290,'DimAccount',@FK_ModuleType_SP,			'SELECT 1'	,@IFRS17_InstanceName, 'TechnicalHub', NULL, NULL),
								(@IFRS17_Orchestration_PK,300,'DimDataset',@FK_ModuleType_SP,			'EXEC  [Dim].[MergeDatasetBR1]','$(InstanceName)', 'TechnicalHub', NULL, NULL),
								(@IFRS17_Orchestration_PK,310,'DimPatternName',@FK_ModuleType_SP,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPatternName.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_PK,320,'DimCatCode',@FK_ModuleType_SP,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimCatCode.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_PK,380,'DimMovementType',@FK_ModuleType_SP,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimMovementType.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								--(@IFRS17_Orchestration_PK,390,'DimTrackingStatus',@FK_ModuleType_SP,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTrackingStatus.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_PK,321,'DimAccountDtsx', @FK_ModuleType_SP,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimAccount.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,	 NULL),
								(@IFRS17_Orchestration_PK,322,'DimClaimExposure', @FK_ModuleType_SP,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimClaimExposure.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,	 NULL),
								(@IFRS17_Orchestration_PK,323,'DimPolicySection', @FK_ModuleType_SP,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPolicySection.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,	 NULL),

								--Level 11
								(@IFRS17_Orchestration_PK,390,'DimTrackingStatus',@FK_ModuleType_SP,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTrackingStatus.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_PK,324,'DimRIPolicyType',@FK_ModuleType_SP,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimRIPolicyType.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_PK,325,'DimProgrammeCode',@FK_ModuleType_SP,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimProgrammeCode.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_PK,326,'DimTriangleGroup',@FK_ModuleType_SP,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTriangleGroup.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_PK,327,'DimReservingDataSet',@FK_ModuleType_SP,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimReservingDataset.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),

								--Level 11  --> Level 12
								(@IFRS17_Orchestration_PK,330,'IFRS2017TechResult',@FK_ModuleType_SP,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactTechnicalResult_IFRS2017.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_PK,340,'Fact Pattern',@FK_ModuleType_SP,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactPattern.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_PK,370,'Fact Discountrates',@FK_ModuleType_SP,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactDiscountRates.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_PK,331,'StandAlone Loads',@FK_ModuleType_SP,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''StandaloneLoads.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

								--level 12  --> Level 13
								(@IFRS17_Orchestration_PK,350,'Post Initial and Subsequment',@FK_ModuleType_SP,'SELECT 1 --EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''Post Fact Initial Subsequent.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								
								--level 13  --> Level 14
								(@IFRS17_Orchestration_PK,360,'Cube Proccesing',@FK_ModuleType_SP,'SELECT 1 --EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''CubeBuild.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL)

								
					)
						AS Source(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.PK_Module = Source.PK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
					VALUES(Source.FK_Orchestration,  Source.PK_module,  Source.ModuleName,  Source.FK_ModuleType,  Source.ModuleRoutine,  Source.DestinationServer,  Source.DestinationDatabase,Source.FK_Schedule,Source.FK_Notification)
			WHEN	MATCHED
			THEN	UPDATE SET		FK_Orchestration	= source.FK_Orchestration, 
									PK_module 			= source.PK_module, 
									ModuleName 			= source.ModuleName, 
									FK_ModuleType 		= source.FK_ModuleType, 
									ModuleRoutine 		= source.ModuleRoutine, 
									DestinationServer	= source.DestinationServer, 
									DestinationDatabase	= source.DestinationDatabase, 
									FK_Schedule 		= source.FK_Schedule, 
									FK_Notification		= source.FK_Notification
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_PK
			THEN	DELETE;




			--ModuleHierarchy select * from etl.ModuleHierarchy
			MERGE 
			INTO	etl.ModuleHierarchy AS Target
			USING	(
						VALUES	--L1

								(@IFRS17_Orchestration_PK,	NULL,	10,	1), -- ADM ToLanding
								(@IFRS17_Orchestration_PK,	NULL,	20,	1), -- EIOPA ToLanding
								(@IFRS17_Orchestration_PK,	NULL,	30,	1), -- NatCatEarning ToLanding
								(@IFRS17_Orchestration_PK,	NULL,	40,	1), -- BICC ToLanding
								(@IFRS17_Orchestration_PK,	NULL,	50,	1), -- LPSO ToLanding
								(@IFRS17_Orchestration_PK,	NULL,	60,	1), -- MDS ToLanding
								(@IFRS17_Orchestration_PK,	NULL,	65,	1), -- FDM ToLanding
								-- Loss Ratio needs to be worked on. It may not be required but it's not ready for testing or UAT as it is.
								--(@IFRS17_Orchestration_PK,	NULL,	70,	1), -- LossRatio ToLanding
								(@IFRS17_Orchestration_PK,	NULL,	73,	1), --ADM DFM PaymentPatterns
								(@IFRS17_Orchestration_PK,	NULL,	76,	1), --ADM Reserving Data PaymentPatterns
								(@IFRS17_Orchestration_PK,	NULL,	78,	1), --ADM S2 Technical Provision PaymentPatterns
								(@IFRS17_Orchestration_PK,	NULL,	79,	1), -- Beazley MI to Landing
								(@IFRS17_Orchestration_PK,	NULL,	11,	1), -- CededRI to Landing
								(@IFRS17_Orchestration_PK,	NULL,	12,	1), -- Ultimate Rebates to Landing
								(@IFRS17_Orchestration_PK,	NULL,	13,	1), -- Paid Rebates to Landing
								(@IFRS17_Orchestration_PK,	NULL,	14,	1),-- Ult Profit Commission to Landing

								--L2
								(@IFRS17_Orchestration_PK,	NULL,	15,	2),--AgressoAR
								(@IFRS17_Orchestration_PK,	NULL,	16,	2),--SyndicateSplit


								--L3
								(@IFRS17_Orchestration_PK,	60,	80,	3), -- MDS LandingToInbound

								--L4
								(@IFRS17_Orchestration_PK,	10,	90,		4), -- ADM LandingToInboundToOutbound depends on ADM ToLanding
								(@IFRS17_Orchestration_PK,	73,	90,		4), -- ADM LandingToInboundToOutbound depends ADM DFM PaymentPatterns
								(@IFRS17_Orchestration_PK,	76,	90,		4), -- ADM LandingToInboundToOutbound depends ADM Reserving Data PaymentPatterns
								(@IFRS17_Orchestration_PK,	78,	90,		4), -- ADM LandingToInboundToOutbound depends ADM S2 Technical Provision PaymentPatterns
								(@IFRS17_Orchestration_PK,	65,	91,		4), -- ReInsurance TrifocusAllocationsTreaty LandingToInbound depends on FDM To Landing
								(@IFRS17_Orchestration_PK,	80,	92,		4), -- AccountName Transaction InboundToOutbound depends on MDS LandingToInbound
								(@IFRS17_Orchestration_PK,	65,	93,		4), -- ReInsurance ObligatedPremium Transaction LandingToInboundToOutbound depends on FDM To Landing
								(@IFRS17_Orchestration_PK,	65,	94,		4), -- ReInsurance QuotaSharePercentage LandingToInbound depends on FDM To Landing
								(@IFRS17_Orchestration_PK,	40,	95,		4), -- Claims_BI_ODS LandingToInbound depends on BICC ToLanding
								(@IFRS17_Orchestration_PK,	80,	95,		4), -- Claims_BI_ODS LandingToInbound depends on MDS LandingToInbound
								(@IFRS17_Orchestration_PK,	65,	96,		4), -- ReInsurance Premium and Recoveries LandingToInboundToOutbound depends on FDM To Landing
								(@IFRS17_Orchestration_PK,	79,	31,		4), -- Signed Profit Commission LandingToInboundToOutbound depends on BeazleyReinsuranceMI To Landing
								(@IFRS17_Orchestration_PK,	11,	32,		4), -- CededReClaimsIncurred LandingToInboundToOutbound depends on BeazleyReinsuranceMI To Landing
								(@IFRS17_Orchestration_PK,	11,	33,		4), -- CededReClosedYOA  LandingToInboundToOutbound depends on BeazleyReinsuranceMI To Landing
								(@IFRS17_Orchestration_PK,	11,	34,		4), -- CededReORC LandingToInboundToOutbound depends on BeazleyReinsuranceMI To Landing
								(@IFRS17_Orchestration_PK,	65,	36,		4), -- RI_ReInstatementPremiumEarned LandingToInboundToOutbound depends on FDM To Landing
								(@IFRS17_Orchestration_PK,	14,	37,		4), -- Ultimate Profit Commission LandingToInboundToOutbound depends on ULT Profit Commission To Landing


								--L5
								--(@IFRS17_Orchestration_PK,	95,	97,		5), -- Claims_BI_ODS InboundToOutbound
								(@IFRS17_Orchestration_PK,	94,	98,		5), -- DataContract ReInsuranceQuotaSharePercentage InboundToOutbound depends on ReInsurance QuotaSharePercentage LandingToInbound
								(@IFRS17_Orchestration_PK,	91,	99,		5), -- ReInsuranceTrifocusAllocationsTreaty InboundToOutbound depends on ReInsurance TrifocusAllocationsTreaty LandingToInbound
								(@IFRS17_Orchestration_PK,	12,	35,		5), -- Ult Rebates LandingToInboundToOutbound depends on Ult Rebates To Landing
								(@IFRS17_Orchestration_PK,	15,	38,		5), -- AgressoAR BIDAC LandingToInbound depends on AgressoARBIDAC To Landing
								(@IFRS17_Orchestration_PK,	65,	51,		5), -- Reinsurance Overriding commission LandingToInboundToOutbound depends on FDM To Landing
								(@IFRS17_Orchestration_PK,	13,	52,		5), -- Paid Rebates depends on Paid Rebates to Landing
								(@IFRS17_Orchestration_PK,	NULL,53,		5), -- Paid Rebates depends on Paid Rebates to Landing

								--L6
								(@IFRS17_Orchestration_PK,	20,	100,	6), -- EIOPA LandingToInbound
								(@IFRS17_Orchestration_PK,	30,	110,	6), -- NatCatEarning LandingToInbound
								(@IFRS17_Orchestration_PK,	50,	130,	6), -- LPSO LandingToInbound
								(@IFRS17_Orchestration_PK,	50,	132,	6), -- LPSO LandingToInbound for FAC ReInsurance
								(@IFRS17_Orchestration_PK,	10,	140,	6),	-- ADM Pattern LandingToInbound							
								(@IFRS17_Orchestration_PK,	40,	145,	6),	-- BI Policy Section references LandingToInbound depends on BICC ToLanding							
								(@IFRS17_Orchestration_PK,	50,	150,	6),	-- LPSO LandingToInbound EPI							
								-- Loss Ratio needs to be worked on. It may not be required but it's not ready for testing or UAT as it is.
								--(@IFRS17_Orchestration_PK,	70,	160,	5),	-- LossRatio LandingToInbound
								(@IFRS17_Orchestration_PK,	13,	151,	6),	--Paid rebates LandingToInbound 
								(@IFRS17_Orchestration_PK,	38,	39,		6), -- AgressoAR US LandingToInbound depends on AgressoARUS To Landing
									(@IFRS17_Orchestration_PK,	53,	152,		6), -- AgressoAR US LandingToInbound depends on AgressoARUS To Landing

								--L7
								(@IFRS17_Orchestration_PK,	90,		170,	7), -- DataContract Transaction InboundToOutbound for ADM LandingToInbound
								(@IFRS17_Orchestration_PK,	151,	170,	7), -- DataContract Transaction InboundToOutbound for Paid Rebates LandingToInbound

								
							

								--L8
								(@IFRS17_Orchestration_PK,	100,	180,	8), -- DataContract DiscountRates InboundToOutbound for EIOPA LandingToInbound
								(@IFRS17_Orchestration_PK,	140,	190,	8), -- DataContract Pattern InboundToOutbound for ADM Pattern LandingToInbound
								-- Loss Ratio needs to be worked on. It may not be required but it's not ready for testing or UAT as it is.
								--(@IFRS17_Orchestration_PK,	160,	200,	7),  -- DataContract LossRatio InboundToOutbound for LossRatio LandingToInbound
								(@IFRS17_Orchestration_PK,	145,	205,	8),  -- DataContract PolicySectionReference InboundToOutbound
								--(@IFRS17_Orchestration_PK,	 97,	210,	8),  -- DataContract Claim Extensions InboundToOutbound
								(@IFRS17_Orchestration_PK,	 152,	211,	8),  -- DataContract Claim Extensions InboundToOutbound

								--L9
							--	(@IFRS17_Orchestration_PK,	 132,	215,	9),  -- DataContract ReInsurance Extensions InboundToOutbound depends on LandingToInbound for FAC ReInsurance.
							--	(@IFRS17_Orchestration_PK,	 210,	215,	9),  -- DataContract ReInsurance Extensions InboundToOutbound depends on the claim extensions having run as it loads the cat code table.
							--	(@IFRS17_Orchestration_PK,	 210,	217,	9),  -- DataContract ReInsurance Treaty Landing to InboundToOutbound depends on the claim extensions having run as it loads the cat code table.
								(@IFRS17_Orchestration_PK,	 65,	217,	9),  -- DataContract ReInsurance Treaty Landing to InboundToOutbound depends on FDM ToLanding having run as it loads the allocations.
								(@IFRS17_Orchestration_PK,	 151,	215,	9),  -- DataContract ReInsurance Extensions InboundToOutbound depends on the Landing to Inbound Paid Rebates.

								--L10								
								(@IFRS17_Orchestration_PK,	92,		220,   10),
								(@IFRS17_Orchestration_PK,	92,		230,   10),
								(@IFRS17_Orchestration_PK,	92,		240,   10),
								(@IFRS17_Orchestration_PK,	92,		250,   10),
								(@IFRS17_Orchestration_PK,	92,		260,   10), 
								(@IFRS17_Orchestration_PK,	92,		270,   10),
								(@IFRS17_Orchestration_PK,	92,		280,   10),
								(@IFRS17_Orchestration_PK,	92,		290,   10),
								(@IFRS17_Orchestration_PK,	92,		300,   10),
								(@IFRS17_Orchestration_PK,	92,		310,   10), 
								(@IFRS17_Orchestration_PK,	92,		320,   10),
                                (@IFRS17_Orchestration_PK,  92,		380,   10),
                               -- (@IFRS17_Orchestration_PK,  92,		390,   9),
								(@IFRS17_Orchestration_PK,	92,		321,   10),
                                (@IFRS17_Orchestration_PK,  92,		322,   10),
                                (@IFRS17_Orchestration_PK,  92,		323,   10),

								(@IFRS17_Orchestration_PK,	180,	220,   10),
								(@IFRS17_Orchestration_PK,	180,	230,   10),
								(@IFRS17_Orchestration_PK,	180,	240,   10),
								(@IFRS17_Orchestration_PK,	180,	250,   10),
								(@IFRS17_Orchestration_PK,	180,	260,   10), 
								(@IFRS17_Orchestration_PK,	180,	270,   10),
								(@IFRS17_Orchestration_PK,	180,	280,   10),
								(@IFRS17_Orchestration_PK,	180,	290,   10),
								(@IFRS17_Orchestration_PK,	180,	300,   10),
								(@IFRS17_Orchestration_PK,	180,	310,   10), 
								(@IFRS17_Orchestration_PK,	180,	320,   10),
                                (@IFRS17_Orchestration_PK,  180,    380,   10),
                               -- (@IFRS17_Orchestration_PK,  180,    390,   9),
								(@IFRS17_Orchestration_PK,	180,	321,   10),
                                (@IFRS17_Orchestration_PK,  180,    322,   10),
                                (@IFRS17_Orchestration_PK,  180,    323,   10),

								(@IFRS17_Orchestration_PK,	190,	220,   10),
								(@IFRS17_Orchestration_PK,	190,	230,   10),
								(@IFRS17_Orchestration_PK,	190,	240,   10),
								(@IFRS17_Orchestration_PK,	190,	250,   10),
								(@IFRS17_Orchestration_PK,	190,	260,   10), 
								(@IFRS17_Orchestration_PK,	190,	270,   10),
								(@IFRS17_Orchestration_PK,	190,	280,   10),
								(@IFRS17_Orchestration_PK,	190,	290,   10),
								(@IFRS17_Orchestration_PK,	190,	300,   10),
								(@IFRS17_Orchestration_PK,	190,	310,   10), 
								(@IFRS17_Orchestration_PK,	190,	320,   10),
								(@IFRS17_Orchestration_PK,  190,    380,   10),
                               -- (@IFRS17_Orchestration_PK,  190,    390,   9),
								(@IFRS17_Orchestration_PK,	190,	321,   10),
								(@IFRS17_Orchestration_PK,  190,    322,   10),
                                (@IFRS17_Orchestration_PK,  190,    323,   10),

								-- Loss Ratio needs to be worked on. It may not be required but it's not ready for testing or UAT as it is.
								--(@IFRS17_Orchestration_PK,	200,	220,   9),
								--(@IFRS17_Orchestration_PK,	200,	230,   9),
								--(@IFRS17_Orchestration_PK,	200,	240,   9),
								--(@IFRS17_Orchestration_PK,	200,	250,   9),
								--(@IFRS17_Orchestration_PK,	200,	260,   9), 
								--(@IFRS17_Orchestration_PK,	200,	270,   9),
								--(@IFRS17_Orchestration_PK,	200,	280,   9),
								--(@IFRS17_Orchestration_PK,	200,	290,   9),
								--(@IFRS17_Orchestration_PK,	200,	300,   9),
								--(@IFRS17_Orchestration_PK,	200,	310,   9), 
								--(@IFRS17_Orchestration_PK,	200,	320,   9),
								--(@IFRS17_Orchestration_PK,  200,    380,   9),
        --                        (@IFRS17_Orchestration_PK,  200,    390,   9),

								--(@IFRS17_Orchestration_PK,	210,	220,   10),
								--(@IFRS17_Orchestration_PK,	210,	230,   10),
								--(@IFRS17_Orchestration_PK,	210,	240,   10),
								--(@IFRS17_Orchestration_PK,	210,	250,   10),
								--(@IFRS17_Orchestration_PK,	210,	260,   10), 
								--(@IFRS17_Orchestration_PK,	210,	270,   10),
								--(@IFRS17_Orchestration_PK,	210,	280,   10),
								--(@IFRS17_Orchestration_PK,	210,	290,   10),
								--(@IFRS17_Orchestration_PK,	210,	300,   10),
								--(@IFRS17_Orchestration_PK,	210,	310,   10), 
								--(@IFRS17_Orchestration_PK,	210,	320,   10),
								--(@IFRS17_Orchestration_PK,  210,    380,   10),
                                --(@IFRS17_Orchestration_PK,  210,    390,   9),
								--(@IFRS17_Orchestration_PK,	210,	321,   10),
								--(@IFRS17_Orchestration_PK,  210,    322,   10),
        --                        (@IFRS17_Orchestration_PK,  210,    323,   10),
								
								(@IFRS17_Orchestration_PK,	215,	220,   10),
								(@IFRS17_Orchestration_PK,	215,	230,   10),
								(@IFRS17_Orchestration_PK,	215,	240,   10),
								(@IFRS17_Orchestration_PK,	215,	250,   10),
								(@IFRS17_Orchestration_PK,	215,	260,   10), 
								(@IFRS17_Orchestration_PK,	215,	270,   10),
								(@IFRS17_Orchestration_PK,	215,	280,   10),
								(@IFRS17_Orchestration_PK,	215,	290,   10),
								(@IFRS17_Orchestration_PK,	215,	300,   10),
								(@IFRS17_Orchestration_PK,	215,	310,   10), 
								(@IFRS17_Orchestration_PK,	215,	320,   10),
								(@IFRS17_Orchestration_PK,  215,    380,   10),
                               -- (@IFRS17_Orchestration_PK,  215,    390,   9),
								(@IFRS17_Orchestration_PK,	215,	321,   10),
								(@IFRS17_Orchestration_PK,  215,    322,   10),
                                (@IFRS17_Orchestration_PK,  215,    323,   10),

								(@IFRS17_Orchestration_PK,	217,	220,   10),
								(@IFRS17_Orchestration_PK,	217,	230,   10),
								(@IFRS17_Orchestration_PK,	217,	240,   10),
								(@IFRS17_Orchestration_PK,	217,	250,   10),
								(@IFRS17_Orchestration_PK,	217,	260,   10), 
								(@IFRS17_Orchestration_PK,	217,	270,   10),
								(@IFRS17_Orchestration_PK,	217,	280,   10),
								(@IFRS17_Orchestration_PK,	217,	290,   10),
								(@IFRS17_Orchestration_PK,	217,	300,   10),
								(@IFRS17_Orchestration_PK,	217,	310,   10), 
								(@IFRS17_Orchestration_PK,	217,	320,   10),
								(@IFRS17_Orchestration_PK,  217,    380,   10),
                               -- (@IFRS17_Orchestration_PK,  217,    390,   9),
								(@IFRS17_Orchestration_PK,	217,	321,   10),
								(@IFRS17_Orchestration_PK,  217,    322,   10),
                                (@IFRS17_Orchestration_PK,  217,    323,   10),

								
								--level 11
								(@IFRS17_Orchestration_PK,	220,  390,		11),
								(@IFRS17_Orchestration_PK,	230,  390,		11),
								(@IFRS17_Orchestration_PK,	240,  390,		11),
								(@IFRS17_Orchestration_PK,	250,  390,		11),
								(@IFRS17_Orchestration_PK,	260,  390,		11), 
								(@IFRS17_Orchestration_PK,	270,  390,		11),
								(@IFRS17_Orchestration_PK,	280,  390,		11),
								(@IFRS17_Orchestration_PK,	290,  390,		11),
								(@IFRS17_Orchestration_PK,	300,  390,		11),
								(@IFRS17_Orchestration_PK,	310,  390,		11), 
								(@IFRS17_Orchestration_PK,	320,  390,		11),
								(@IFRS17_Orchestration_PK,  380,  390,      11),
                               -- (@IFRS17_Orchestration_PK,  390,  330,     10),
								(@IFRS17_Orchestration_PK,	321,  390,		11),
								(@IFRS17_Orchestration_PK,  322,  390,      11),
                                (@IFRS17_Orchestration_PK,  323,  390,      11),

								(@IFRS17_Orchestration_PK,	220,  324,		11),
								(@IFRS17_Orchestration_PK,	230,  324,		11),
								(@IFRS17_Orchestration_PK,	240,  324,		11),
								(@IFRS17_Orchestration_PK,	250,  324,		11),
								(@IFRS17_Orchestration_PK,	260,  324,		11), 
								(@IFRS17_Orchestration_PK,	270,  324,		11),
								(@IFRS17_Orchestration_PK,	280,  324,		11),
								(@IFRS17_Orchestration_PK,	290,  324,		11),
								(@IFRS17_Orchestration_PK,	300,  324,		11),
								(@IFRS17_Orchestration_PK,	310,  324,		11), 
								(@IFRS17_Orchestration_PK,	320,  324,		11),
								(@IFRS17_Orchestration_PK,  380,  324,      11),
                               -- (@IFRS17_Orchestration_PK,  390,  330,      10),
								(@IFRS17_Orchestration_PK,	321,  324,		11),
								(@IFRS17_Orchestration_PK,  322,  324,      11),
                                (@IFRS17_Orchestration_PK,  323,  324,      11),

								(@IFRS17_Orchestration_PK,	220,  325,		11),
								(@IFRS17_Orchestration_PK,	230,  325,		11),
								(@IFRS17_Orchestration_PK,	240,  325,		11),
								(@IFRS17_Orchestration_PK,	250,  325,		11),
								(@IFRS17_Orchestration_PK,	260,  325,		11), 
								(@IFRS17_Orchestration_PK,	270,  325,		11),
								(@IFRS17_Orchestration_PK,	280,  325,		11),
								(@IFRS17_Orchestration_PK,	290,  325,		11),
								(@IFRS17_Orchestration_PK,	300,  325,		11),
								(@IFRS17_Orchestration_PK,	310,  325,		11), 
								(@IFRS17_Orchestration_PK,	320,  325,		11),
								(@IFRS17_Orchestration_PK,  380,  325,      11),
                               -- (@IFRS17_Orchestration_PK,  390,  330,     10),
								(@IFRS17_Orchestration_PK,	321,  325,		11),
								(@IFRS17_Orchestration_PK,  322,  325,      11),
                                (@IFRS17_Orchestration_PK,  323,  325,      11),

								(@IFRS17_Orchestration_PK,	220,  326,		11),
								(@IFRS17_Orchestration_PK,	230,  326,		11),
								(@IFRS17_Orchestration_PK,	240,  326,		11),
								(@IFRS17_Orchestration_PK,	250,  326,		11),
								(@IFRS17_Orchestration_PK,	260,  326,		11), 
								(@IFRS17_Orchestration_PK,	270,  326,		11),
								(@IFRS17_Orchestration_PK,	280,  326,		11),
								(@IFRS17_Orchestration_PK,	290,  326,		11),
								(@IFRS17_Orchestration_PK,	300,  326,		11),
								(@IFRS17_Orchestration_PK,	310,  326,		11), 
								(@IFRS17_Orchestration_PK,	320,  326,		11),
								(@IFRS17_Orchestration_PK,  380,  326,      11),
                               -- (@IFRS17_Orchestration_PK,  390,  330,      10),
								(@IFRS17_Orchestration_PK,	321,  326,		11),
								(@IFRS17_Orchestration_PK,  322,  326,      11),
                                (@IFRS17_Orchestration_PK,  323,  326,      11),

								(@IFRS17_Orchestration_PK,	220,  327,		11),
								(@IFRS17_Orchestration_PK,	230,  327,		11),
								(@IFRS17_Orchestration_PK,	240,  327,		11),
								(@IFRS17_Orchestration_PK,	250,  327,		11),
								(@IFRS17_Orchestration_PK,	260,  327,		11), 
								(@IFRS17_Orchestration_PK,	270,  327,		11),
								(@IFRS17_Orchestration_PK,	280,  327,		11),
								(@IFRS17_Orchestration_PK,	290,  327,		11),
								(@IFRS17_Orchestration_PK,	300,  327,		11),
								(@IFRS17_Orchestration_PK,	310,  327,		11), 
								(@IFRS17_Orchestration_PK,	320,  327,		11),
								(@IFRS17_Orchestration_PK,  380,  327,      11),
                               -- (@IFRS17_Orchestration_PK,  390,  330,     10),
								(@IFRS17_Orchestration_PK,	321,  327,		11),
								(@IFRS17_Orchestration_PK,  322,  327,      11),
                                (@IFRS17_Orchestration_PK,  323,  327,      11),
							
								--level 12 new level for dims level 11 has 15 modules already and it meets limitation
								(@IFRS17_Orchestration_PK,	390,  330,		12),
								(@IFRS17_Orchestration_PK,	390,  340,		12),
								(@IFRS17_Orchestration_PK,	390,  370,		12),
								(@IFRS17_Orchestration_PK,	390,  331,		12),

								(@IFRS17_Orchestration_PK,	324,  330,		12),
								(@IFRS17_Orchestration_PK,	324,  340,		12),
								(@IFRS17_Orchestration_PK,	324,  370,		12),
								(@IFRS17_Orchestration_PK,	324,  331,		12),
							
								(@IFRS17_Orchestration_PK,	325,  330,		12),
								(@IFRS17_Orchestration_PK,	325,  340,		12),
								(@IFRS17_Orchestration_PK,	325,  370,		12),
								(@IFRS17_Orchestration_PK,	325,  331,		12),

								(@IFRS17_Orchestration_PK,	326,  330,		12),
								(@IFRS17_Orchestration_PK,	326,  340,		12),
								(@IFRS17_Orchestration_PK,	326,  370,		12),
								(@IFRS17_Orchestration_PK,	326,  331,		12),

								(@IFRS17_Orchestration_PK,	327,  330,		12),
								(@IFRS17_Orchestration_PK,	327,  340,		12),
								(@IFRS17_Orchestration_PK,	327,  370,		12),
								(@IFRS17_Orchestration_PK,	327,  331,		12),
								
								
								
								/*  =====  EB  ==== 
								--Level 10

								(@IFRS17_Orchestration_PK,	220,  330,		10),
								(@IFRS17_Orchestration_PK,	230,  330,		10),
								(@IFRS17_Orchestration_PK,	240,  330,		10),
								(@IFRS17_Orchestration_PK,	250,  330,		10),
								(@IFRS17_Orchestration_PK,	260,  330,		10), 
								(@IFRS17_Orchestration_PK,	270,  330,		10),
								(@IFRS17_Orchestration_PK,	280,  330,		10),
								(@IFRS17_Orchestration_PK,	290,  330,		10),
								(@IFRS17_Orchestration_PK,	300,  330,		10),
								(@IFRS17_Orchestration_PK,	310,  330,		10), 
								(@IFRS17_Orchestration_PK,	320,  330,		10),
								(@IFRS17_Orchestration_PK,  380,  330,      10),
                               -- (@IFRS17_Orchestration_PK,  390,  330,      10),
								(@IFRS17_Orchestration_PK,	321,  330,		10),
								(@IFRS17_Orchestration_PK,  322,  330,      10),
                                (@IFRS17_Orchestration_PK,  323,  330,      10),
								
								(@IFRS17_Orchestration_PK,	220,  340,		10),
								(@IFRS17_Orchestration_PK,	230,  340,		10),
								(@IFRS17_Orchestration_PK,	240,  340,		10),
								(@IFRS17_Orchestration_PK,	250,  340,		10),
								(@IFRS17_Orchestration_PK,	260,  340,		10), 
								(@IFRS17_Orchestration_PK,	270,  340,		10),
								(@IFRS17_Orchestration_PK,	280,  340,		10),
								(@IFRS17_Orchestration_PK,	290,  340,		10),
								(@IFRS17_Orchestration_PK,	300,  340,		10),
								(@IFRS17_Orchestration_PK,	310,  340,		10), 
								(@IFRS17_Orchestration_PK,	320,  340,		10),
								(@IFRS17_Orchestration_PK,  380,  340,      10),
                               -- (@IFRS17_Orchestration_PK,  390,  340,      10),
								(@IFRS17_Orchestration_PK,	321,  340,		10),
								(@IFRS17_Orchestration_PK,  322,  340,      10),
                                (@IFRS17_Orchestration_PK,  323,  340,      10),

								(@IFRS17_Orchestration_PK,	220,  370,		10),
								(@IFRS17_Orchestration_PK,	230,  370,		10),
								(@IFRS17_Orchestration_PK,	240,  370,		10),
								(@IFRS17_Orchestration_PK,	250,  370,		10),
								(@IFRS17_Orchestration_PK,	260,  370,		10), 
								(@IFRS17_Orchestration_PK,	270,  370,		10),
								(@IFRS17_Orchestration_PK,	280,  370,		10),
								(@IFRS17_Orchestration_PK,	290,  370,		10),
								(@IFRS17_Orchestration_PK,	300,  370,		10),
								(@IFRS17_Orchestration_PK,	310,  370,		10), 
								(@IFRS17_Orchestration_PK,	320,  370,		10),
								(@IFRS17_Orchestration_PK,  380,  370,      10),
                                --(@IFRS17_Orchestration_PK,  390,  370,      10),
								(@IFRS17_Orchestration_PK,	321,  370,		10),
								(@IFRS17_Orchestration_PK,  322,  370,      10),
                                (@IFRS17_Orchestration_PK,  323,  370,      10),
								*/
								--level 13
								(@IFRS17_Orchestration_PK,	330,  350,		13), 
								(@IFRS17_Orchestration_PK,	340,  350,		13),
								(@IFRS17_Orchestration_PK,	370,  350,		13),
								(@IFRS17_Orchestration_PK,	331,  350,		13),
								--level 14
								(@IFRS17_Orchestration_PK,	350,  360,		14)
								
								
-- SSIS packages
--IFRS17_ADMToLandingExtract.dtsx -- > [ADM].[usp_LandingToInbound] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow
--								  -- > [ADM].[usp_LandingToInbound_Pattern] --> FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_Pattern			

--IFRS17_AgressoToLandingExtract.dtsx -- on hold

--IFRS17_BICCToLandingExtract.dtsx -- > [BICC].[usp_LandingToInbound] -- > assume FinanceDataContract.Inbound.usp_InboundOutboundWorkflow but unit test has changed or not there. Ciprian will update me.
--IFRS17_EIOPAToLandingExtract.dtsx -- > [XLS].[usp_EIOPALandingToInbound_DiscountRates] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_DiscountRates
--IFRS17_EurobaseToLandingExtract.dtsx -- > [Eurobase].[usp_LandingToInbound_EPI] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow
--										-- > [Eurobase].[usp_LandingToInbound] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow

-- needs to be added
--IFRS17_LossRatioToLandingExtract.dtsx -- > [XLS].[usp_LandingToInbound_LossRatio] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_LossRatio

--IFRS17_MDSToLandingExtract.dtsx -- > [MDS].[usp_LandingToInbound] -- > no outbound required

--check this!
--IFRS17_NatCatEarningToLandingExtract.dtsx -- > [XLS].[usp_NatCatEarningLandingToInbound_Pattern] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_Pattern


					) AS Source(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.FK_ChildModule = Source.FK_ChildModule
				AND Target.FK_ParentModule = Source.FK_ParentModule
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
					VALUES(Source.FK_Orchestration,Source.FK_ParentModule,Source.FK_ChildModule,Source.TreeLevel)
			WHEN	MATCHED
			THEN	UPDATE SET	FK_Orchestration = source.FK_Orchestration, 
								FK_ParentModule = source.FK_ParentModule, 
								FK_ChildModule = source.FK_ChildModule, 
								TreeLevel = source.TreeLevel
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_PK
			THEN	DELETE;






			--ModuleActivity select * from etl.ModuleActivity
			MERGE	etl.ModuleActivity Target
			USING	(
						SELECT	m.FK_Orchestration,
								m.PK_Module,
								1, -- Pending
								'Initialization from deployment' -- run description
						FROM	etl.Module m
						WHERE	m.FK_Orchestration = @IFRS17_Orchestration_PK
					) Source (FK_Orchestration, FK_Module, FK_ModuleStatus,RunDescription)
			ON		Source.FK_Orchestration = Target.FK_Orchestration
				AND	Source.FK_Module = Target.FK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT	(FK_Orchestration, FK_Module, FK_ModuleStatus, RunDescription)
					VALUES	(Source.FK_Orchestration, Source.FK_Module, Source.FK_ModuleStatus, Source.RunDescription)
			WHEN	MATCHED
			THEN	UPDATE	SET	Target.FK_ModuleStatus = Source.FK_ModuleStatus, Target.RunDescription = Source.RunDescription
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_PK
			THEN	DELETE;

