﻿Delete from etl.ModuleHierarchy where FK_Orchestration=11
Delete from etl.ModuleActivity where FK_Orchestration=11
Delete From etl.Module where FK_Orchestration=11




MERGE
INTO etl.Orchestration AS Target
USING (VALUES(11, 'IFRS17_preprocessing_aggregation',0)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled)
ON (Target.PK_Orchestration = Source.PK_Orchestration)
WHEN NOT MATCHED BY TARGET
THEN INSERT(PK_Orchestration,OrchestrationName,IsEnabled)
VALUES(Source.PK_Orchestration, Source.OrchestrationName, Source.IsEnabled)
WHEN MATCHED
THEN UPDATE SET Target.ORchestrationName = Source.OrchestrationName,
Target.IsEnabled = Source.Isenabled;



MERGE
INTO etl.Orchestration AS Target
USING (VALUES(11, 'IFRS17_preprocessing_aggregation',0)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled)
ON (Target.PK_Orchestration = Source.PK_Orchestration)
WHEN NOT MATCHED BY TARGET
THEN INSERT(PK_Orchestration,OrchestrationName,IsEnabled)
VALUES(Source.PK_Orchestration, Source.OrchestrationName, Source.IsEnabled)
WHEN MATCHED
THEN UPDATE SET Target.ORchestrationName = Source.OrchestrationName,
Target.IsEnabled = Source.Isenabled;



MERGE
INTO etl.Module AS Target
USING (
VALUES


--level 1  ( FK_Orchestration,PK_module,ModuleName,FK_ModuleType,ModuleRoutine,DestinationServer,DestinationDatabase,FK_Notification,DefaultResetStatus)

(11,1,'DimAccountingPeriod',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''DimAccountingPeriod.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

(11,2,'DimCCY',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''DimCCY.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

(11,3,'DimDataset',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''DimDataset.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

(11,4,'DimEntity',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''DimEntity.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

(11,5,'DimPolicySection',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''DimPolicySection.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

(11,6,'DimReportingCCY',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''DimReportingCCY.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

(11,7,'DimScenario',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''DimScenario.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

(11,8,'DimTrifocus',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''DimTrifocus.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

(11,9,'DimYOA',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''DimYOA.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

(11,10,'DimDatasetAccountMapping',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''DimDatasetAccountMapping.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

(11,11,'DimAccount',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''DimAccount.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

(11,12,'RIPercentage',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''RIPercentage.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

(11,13,'FXRate',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''FactFxRate.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

---(11,14,'DiscountRate',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''FactDiscountRate.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

(11,14,'Patterns',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''FactPattern.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

--Level 2 ( FK_Orchestration,PK_module,ModuleName,FK_ModuleType,ModuleRoutine,DestinationServer,DestinationDatabase,FK_Notification,DefaultResetStatus)

(11,15,'stgTechnicalHub',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''stgTechnicalHub.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),



--Level 3 ( FK_Orchestration,PK_module,ModuleName,FK_ModuleType,ModuleRoutine,DestinationServer,DestinationDatabase,FK_Notification,DefaultResetStatus)

(11,16,'PreProcessPremium',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''PreProcessPremium_LTDData.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),



--level 4 ( FK_Orchestration,PK_module,ModuleName,FK_ModuleType,ModuleRoutine,DestinationServer,DestinationDatabase,FK_Notification,DefaultResetStatus)

(11,17,'PSicle_API_call',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''Psicle_Api_Call.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),



--Level 5 ( FK_Orchestration,PK_module,ModuleName,FK_ModuleType,ModuleRoutine,DestinationServer,DestinationDatabase,FK_Notification,DefaultResetStatus)

--(11,4,'usp_Merge_StgAggregatePremiumLTD',1, 'EXEC [Inbound].[usp_Merge_StgAggregatePremiumLTD]','$(InstanceName_IDM)', 'IFRS17DataMart', NULL, NULL),
(11,18,'Merge_StgAggregatePremiumLTD',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''Merge_StgAggregatePremiumLTD.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

--Level 6 ( FK_Orchestration,PK_module,ModuleName,FK_ModuleType,ModuleRoutine,DestinationServer,DestinationDatabase,FK_Notification,DefaultResetStatus)

(11,19,'Merge_Staging',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''Merge_Staging.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

--Level 7 ( FK_Orchestration,PK_module,ModuleName,FK_ModuleType,ModuleRoutine,DestinationServer,DestinationDatabase,FK_Notification,DefaultResetStatus) 

(11,20,'Aggr_Premium',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''Aggr_Premium_LTDData.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),



--Level 8 ( FK_Orchestration,PK_module,ModuleName,FK_ModuleType,ModuleRoutine,DestinationServer,DestinationDatabase,FK_Notification,DefaultResetStatus)

(11,21,'Aggr_NonPremium',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''Aggr_NonPremium_LTDData.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

--Level 9 ( FK_Orchestration,PK_module,ModuleName,FK_ModuleType,ModuleRoutine,DestinationServer,DestinationDatabase,FK_Notification,DefaultResetStatus)
(11,22,'ReconPrePostPPPsicle',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''ReconPrePostPPPsicle.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),


--Level 10 ( FK_Orchestration,PK_module,ModuleName,FK_ModuleType,ModuleRoutine,DestinationServer,DestinationDatabase,FK_Notification,DefaultResetStatus)
(11,23,'Merge_StagingOpenClosYOA',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''Merge_StagingOpenClosYOA.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL)

--(11,7,'usp_Merge_StgFSCActual',1, 'EXEC [Inbound].[usp_Merge_StgFSCActual]','$(InstanceName_IDM)', 'IFRS17DataMart', NULL, NULL),
--(11,8,'usp_Merge_StgFSCEPI',1, 'EXEC [Inbound].[usp_Merge_StgFSCEPI]','$(InstanceName_IDM)', 'IFRS17DataMart', NULL, NULL),
--(11,9,'usp_Merge_StgFSCForecast',1, 'EXEC [Inbound].[usp_Merge_StgFSCForecast]','$(InstanceName_IDM)', 'IFRS17DataMart', NULL, NULL),
--(11,10,'usp_Merge_StgFSCPerQOI',1, 'EXEC [Inbound].[usp_Merge_StgFSCPerQOI]','$(InstanceName_IDM)', 'IFRS17DataMart', NULL, NULL),
--(11,11,'usp_Merge_StgFSCPerYOA',1, 'EXEC [Inbound].[usp_Merge_StgFSCPerYOA]','$(InstanceName_IDM)', 'IFRS17DataMart', NULL, NULL),
--(11,12,'usp_Merge_StgIFRS17Trifocus',1, 'EXEC [Inbound].[usp_Merge_StgIFRS17Trifocus]','$(InstanceName_IDM)', 'IFRS17DataMart', NULL, NULL),
--(11,13,'usp_Merge_StgOpenCloseYOA',1, 'EXEC [Inbound].[usp_Merge_StgOpenCloseYOA]','$(InstanceName_IDM)', 'IFRS17DataMart', NULL, NULL)



)

AS Source(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
ON Target.FK_Orchestration = Source.FK_Orchestration
AND Target.PK_Module = Source.PK_Module
WHEN NOT MATCHED BY TARGET
THEN INSERT(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
VALUES(Source.FK_Orchestration, Source.PK_module, Source.ModuleName, Source.FK_ModuleType, Source.ModuleRoutine, Source.DestinationServer, Source.DestinationDatabase,Source.FK_Schedule,Source.FK_Notification)
WHEN MATCHED
THEN UPDATE SET FK_Orchestration = source.FK_Orchestration,
PK_module = source.PK_module,
ModuleName = source.ModuleName,
FK_ModuleType = source.FK_ModuleType,
ModuleRoutine = source.ModuleRoutine,
DestinationServer = source.DestinationServer,
DestinationDatabase = source.DestinationDatabase,
FK_Schedule = source.FK_Schedule,
FK_Notification = source.FK_Notification
WHEN NOT MATCHED BY SOURCE AND target.fk_Orchestration = 11
THEN DELETE;



MERGE
INTO etl.ModuleHierarchy AS Target
USING (
VALUES

--L1 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
(11, NULL, 1, 1),
(11, NULL, 2, 1),
(11, NULL, 3, 1),
(11, NULL, 4, 1),
(11, NULL, 5, 1),
(11, NULL, 6, 1),
(11, NULL, 7, 1),
(11, NULL, 8, 1),
(11, NULL, 9, 1),
(11, NULL, 10, 1),
(11, NULL, 11, 1),
(11, NULL, 12, 1),
(11, NULL, 13, 1),
(11, NULL, 14, 1),
--(11, NULL, 15, 1),

--L2 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
(11, 1, 15, 2),
(11, 2, 15, 2),
(11, 3, 15, 2),
(11, 4, 15, 2),
(11, 5, 15, 2),
(11, 6, 15, 2),
(11, 7, 15, 2),
(11, 8, 15, 2),
(11, 9, 15, 2),
(11, 10,15, 2),
(11, 11,15, 2),
(11, 12,15, 2),
(11, 13,15, 2),
(11, 14,15, 2),
--(11, 15,16, 2),



--L3 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
(11, 15, 16, 3),



--L4 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
(11, 16, 17, 4),



--L5 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
(11, 17, 18, 5),


--L6 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
(11, 18, 19, 6),


--L7 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
(11, 19, 20, 7),


--L8 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
(11, 20, 21, 8),


--L9 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
(11, 21, 22, 9),


--L10 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
(11, 22, 23, 10)




) AS Source(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
ON Target.FK_Orchestration = Source.FK_Orchestration
AND Target.FK_ChildModule = Source.FK_ChildModule
AND Target.FK_ParentModule = Source.FK_ParentModule
WHEN NOT MATCHED BY TARGET
THEN INSERT(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
VALUES(Source.FK_Orchestration,Source.FK_ParentModule,Source.FK_ChildModule,Source.TreeLevel)
WHEN MATCHED
THEN UPDATE SET FK_Orchestration = source.FK_Orchestration,
FK_ParentModule = source.FK_ParentModule,
FK_ChildModule = source.FK_ChildModule,
TreeLevel = source.TreeLevel
WHEN NOT MATCHED BY SOURCE AND target.fk_Orchestration = 11
THEN DELETE;




MERGE etl.ModuleActivity Target
USING (
SELECT m.FK_Orchestration,
m.PK_Module,
1
FROM etl.Module m
WHERE m.FK_Orchestration = 11
) Source (FK_Orchestration, FK_Module, FK_ModuleStatus)
ON Source.FK_Orchestration = Target.FK_Orchestration
AND Source.FK_Module = Target.FK_Module
WHEN NOT MATCHED BY TARGET
THEN INSERT (FK_Orchestration, FK_Module, FK_ModuleStatus)
VALUES (Source.FK_Orchestration, Source.FK_Module, Source.FK_ModuleStatus)
WHEN MATCHED
THEN UPDATE SET Target.FK_ModuleStatus = Source.FK_ModuleStatus
WHEN NOT MATCHED BY SOURCE AND target.fk_Orchestration = 11
THEN DELETE;