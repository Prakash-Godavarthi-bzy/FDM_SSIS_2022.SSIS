﻿--:setvar InstanceName "UKDVDB149"

/*
	Change log. Please add comments to help us developers make sure we don't miss changes before we check in code.

	Author:			mark.baekdal@beazley.com
	Description:	(@IFRS17_Orchestration_RI,99,'DataContract ReInsuranceTrifocusAllocationsTreaty InboundToOutbound',@FK_ModuleType_SPPre,'EXEC [Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTreatyContractAttributes]'	,@IFRS17_InstanceName_Pre_tl, 'FinanceDataContract', NULL, NULL),
					should have been
					(@IFRS17_Orchestration_RI,99,'DataContract ReInsuranceTrifocusAllocationsTreaty InboundToOutbound',@FK_ModuleType_SPPre,'EXEC [Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTrifocusAllocationsTreaty]'	,@IFRS17_InstanceName_Pre_tl, 'FinanceDataContract', NULL, NULL),

					[Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTreatyContractAttributes] is called by [FinanceLanding].[Eurobase].[usp_LandingToInboundToOutbound_TreatyReInsurance].

*/

declare @IFRS17_InstanceName_RI nvarchar(129) = '$(InstanceName)'

--select @IFRS17_InstanceName_Pre

/*
	-- to delete everything and start again. The merge statement can fail when changes break referential entrigity, 
	-- so the data needs to be deleted and re-stated.
declare @IFRS17_Orchestration_RI int = 3

delete etl.ModuleActivity
where FK_Orchestration = @IFRS17_Orchestration_RI

delete etl.ModuleHierarchy
where FK_Orchestration = @IFRS17_Orchestration_RI

delete etl.Module
where FK_Orchestration = @IFRS17_Orchestration_RI

delete etl.Orchestration
where PK_Orchestration = @IFRS17_Orchestration_RI

*/

-- static variables
declare @IFRS17_Orchestration_RI int = 12
declare @IFRS17_Orchestration_IsEnabledRI int = 0
declare @IFRS17_RunTimeExecutionPriorityOrderRI int = 1

Delete from etl.ModuleHierarchy where FK_Orchestration=12
Delete from etl.ModuleActivity where FK_Orchestration=12
Delete From etl.Module where FK_Orchestration=12


  --orchestration select * from etl.Orchestration
			MERGE 
			INTO	etl.Orchestration AS Target
			USING	(VALUES(@IFRS17_Orchestration_RI, 'IFRS17_RI',@IFRS17_Orchestration_IsEnabledRI)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled)
			ON		(Target.PK_Orchestration = Source.PK_Orchestration)
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(PK_Orchestration,OrchestrationName,IsEnabled)
					VALUES(Source.PK_Orchestration,  Source.OrchestrationName,  Source.IsEnabled)
			WHEN	MATCHED
			THEN	UPDATE SET	Target.ORchestrationName = Source.OrchestrationName,
								Target.IsEnabled = Source.Isenabled;

			-- code to uncomment when priority column can be released.
			--MERGE 
			--INTO	etl.Orchestration AS Target
			--USING	(VALUES(@IFRS17_Orchestration_RI, 'IFRS17',@IFRS17_Orchestration_IsEnabledPre,@IFRS17_RunTimeExecutionPriorityOrder)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled,RunTimeExecutionPriorityOrder)
			--ON		(Target.PK_Orchestration = Source.PK_Orchestration)
			--WHEN	NOT MATCHED BY TARGET
			--THEN	INSERT(PK_Orchestration,OrchestrationName,IsEnabled,RunTimeExecutionPriorityOrder)
			--		VALUES(Source.PK_Orchestration,  Source.OrchestrationName,  Source.IsEnabled, Source.RunTimeExecutionPriorityOrder)
			--WHEN	MATCHED
			--THEN	UPDATE SET	Target.ORchestrationName = Source.OrchestrationName,
			--					Target.IsEnabled = Source.Isenabled,
			--					Target.RunTimeExecutionPriorityOrder = Source.RunTimeExecutionPriorityOrder;

--module select * from etl.Module 

declare @FK_ModuleType_SPRI int = (select PK_ModuleType from [etl].[ModuleType] where ModuleType = 'SPROC')

			MERGE --@IFRS17_Orchestration_RI
			INTO	etl.Module AS Target
			USING	(
						VALUES	--Level 1 1*15=1-15
								(@IFRS17_Orchestration_RI,1,'Paid Rebates Landing',@FK_ModuleType_SPRI,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_PaidRebatesToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_RI,2,'Ultimate Rebates Landing',@FK_ModuleType_SPRI,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_UltimateRebatesToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_RI,3,'LPSO ToLanding',@FK_ModuleType_SPRI,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_EurobaseToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_RI,4,'MDS ToLanding',@FK_ModuleType_SPRI,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_MDSToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_RI,5,'FDM ToLanding',@FK_ModuleType_SPRI,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_FDMToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_RI,6,'ADM ToLanding',  @FK_ModuleType_SPRI,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADMToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_RI,7,'ADM DFM PaymentPatterns',@FK_ModuleType_SPRI,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADM_DFM_PaymentPattern_ToLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_RI,8,'ADM Reserving Data PaymentPatterns',@FK_ModuleType_SPRI,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADM_ResDat_PaymentPattern_ToLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_RI,9,'ADM S2 Technical Provision PaymentPatterns',@FK_ModuleType_SPRI,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADM_S2_TPOutput_PaymentPattern_ToLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_RI,10,'CededRe to Landing',@FK_ModuleType_SPRI,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_CededReAccToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_RI,11,'SyndicateSplit Landing',@FK_ModuleType_SPRI,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''SyndicateSplit.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_RI,12,'ADMResDataAttClmAllocPhase2Package',  @FK_ModuleType_SPRI,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''ADMResDataAttClmAllocPhase2.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),

								--Level 2 Landing Tactical Loads 2*15=16-30
								(@IFRS17_Orchestration_RI,16,'BICI_RIEarned Landing',  @FK_ModuleType_SPRI,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName =''IFRS17_BICIRI_EarnedPremium.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),
							    (@IFRS17_Orchestration_RI,17,'BICI_RI_Ultimate_Premium Landing',  @FK_ModuleType_SPRI,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BICIRI_Ultimate.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),
							    (@IFRS17_Orchestration_RI,18,'ADM_RRDataLargeLosses',  @FK_ModuleType_SPRI,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''ADMReinsuranceReservingData_LargeLosses.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),
                                (@IFRS17_Orchestration_RI,19,'ResDataEventAlloc Landing',  @FK_ModuleType_SPRI,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADMResDataAllocToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_RI,20,'BICI_RIPaid Landing',  @FK_ModuleType_SPRI,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName =''IFRS17_BICIRI_Paid.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),
								--I1B-3622 (@IFRS17_Orchestration_RI,21,'SPA_ObligatedPremium',  @FK_ModuleType_SPRI,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_SPAObligatedPremium.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_RI,21,'SPA_ObligatedPremium',  @FK_ModuleType_SPRI,'Select 1',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),
								
								--(@IFRS17_Orchestration_RI,22,'ObligatedPremium_Munich_QQS Landing',  @FK_ModuleType_SPRI,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ObligatedPremium_Munich_QQS.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),
								-- https://beazley.atlassian.net/browse/I1B-3621
								(@IFRS17_Orchestration_RI,22,'Dummy Load',  @FK_ModuleType_SPRI,'Select 1',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),

								(@IFRS17_Orchestration_RI,23,'TDMBICIClaims Landing',  @FK_ModuleType_SPRI,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_TDMBICIClaimsToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),							    
								(@IFRS17_Orchestration_RI,24,'AEA_ExpensesActuals Landing',  @FK_ModuleType_SPRI,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_AExpensesActualLanding.dtsx '', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),							    
								(@IFRS17_Orchestration_RI,25,'BICI_RI_Ultimate_Claim Landing',  @FK_ModuleType_SPRI,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BICIRI_Claim.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),							    
							    (@IFRS17_Orchestration_RI,26,'BICI_RIIncurred Landing',  @FK_ModuleType_SPRI,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BICIRI_Incurred.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_RI,'SchedulingHub',NULL,NULL),

								--Level 3  
									
								(@IFRS17_Orchestration_RI,27,'ADM LandingToInboundToOutbound', @FK_ModuleType_SPRI,'EXEC [ADM].[usp_LandingToInboundToOutbound]',@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),
								
								--Level 4
								(@IFRS17_Orchestration_RI,28,'CededReClaimsIncurred LandingToInboundToOutbound',@FK_ModuleType_SPRI,'EXEC [CededRe].[usp_LandingToInboundToOutbound_CededReClaimsIncurred]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),								
								
								--Level 5
								(@IFRS17_Orchestration_RI,29,'CededReClosedYOA LandingToInboundToOutbound',@FK_ModuleType_SPRI,'EXEC [CededRe].[usp_LandingToInboundToOutbound_CededReClosedYOA]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),
								
								--Level 6
								(@IFRS17_Orchestration_RI,30,'CededReORC LandingToInboundToOutbound',@FK_ModuleType_SPRI,'EXEC [CededRe].[usp_LandingToInboundToOutbound_CededReORC]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),								
								
								--Level 7
								(@IFRS17_Orchestration_RI,31,'Reinsurance overriding commission LandingToInboundToOutbound',@FK_ModuleType_SPRI,'EXEC [FDM].[usp_LandingToInboundToOutbound_Reinsurance_Overriding_Commission]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),
								
								--Level 8
								(@IFRS17_Orchestration_RI,32,'LPSO LandingToInbound Fac ReInsurance', @FK_ModuleType_SPRI,'EXEC [Eurobase].[usp_LandingToInbound_FacReInsurance]',@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),

								--Level 9
								(@IFRS17_Orchestration_RI,33,'DataContract Transaction InboundToOutbound',@FK_ModuleType_SPRI,'EXEC [Inbound].[usp_InboundOutboundWorkflow] @DoNonIFRS17_Tests = 0'	,@IFRS17_InstanceName_RI, 'FinanceDataContract', NULL, NULL),

								--Level 10
								(@IFRS17_Orchestration_RI,34,'DataContract ReInsurance Treaty Landing to InboundToOutbound',@FK_ModuleType_SPRI, 'EXEC [Eurobase].[usp_LandingToInboundToOutbound_TreatyReInsurance]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),

								--Level 11
								(@IFRS17_Orchestration_RI,35,'Paid Rebates LandingToInboundToOutbound', @FK_ModuleType_SPRI,'EXEC [pdrebsrc].[usp_LandingToInboundToOutbound_PaidRebates] ',@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),

								--Level 12
								(@IFRS17_Orchestration_RI,36,'UltimateRebates LandingToInboundToOutbound',@FK_ModuleType_SPRI,'EXEC [ultrebsrc].[usp_LandingToInboundToOutbound_UltimateRIRebate]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),								

								--Level 13
								(@IFRS17_Orchestration_RI,37,'BICI_RI_Ultimate_Claim LandingToInbound',@FK_ModuleType_SPRI,'EXEC [BICIRI].[usp_LandingInboundWorkflow_BICI_RI_Ultimate_Claim]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),								
								
								--Level 14
								(@IFRS17_Orchestration_RI,38,'TDMBICIClaims LandingToInbound',@FK_ModuleType_SPRI,'EXEC [TDM].[usp_LandingInboundWorkflow_BICIClaims]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),								

								--Level 15
								(@IFRS17_Orchestration_RI,39,'AEA_ExpensesActual LandingToInbound',@FK_ModuleType_SPRI,'EXEC [Agresso].[usp_LandingToInboundToOutboundWorkflow_AgressoExpensesActual]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),								

								--Level 16 
								(@IFRS17_Orchestration_RI,40,'BICI_RI_Ultimate_Premium LandingToInbound',@FK_ModuleType_SPRI,'EXEC [BICIRI].[usp_LandingInboundWorkflow_BICI_RI_Ultimate_Premium]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),
								
								--Level 17  
								(@IFRS17_Orchestration_RI,41,'ResDataEventAlloc LandingToInbound',@FK_ModuleType_SPRI,'EXEC [ADM].[usp_LandingInboundWorkflow_ResDataEventAlloc]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),
								
								--Level 18
								(@IFRS17_Orchestration_RI,42,'ADM_RRDataLargeloses LandingToInbound',@FK_ModuleType_SPRI,'EXEC [ADM].[usp_LandingInboundWorkflow_ReinsuranceReservingDataLargeLosses_ADM]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),
								
								--Level 19
								(@IFRS17_Orchestration_RI,43,'BICI_RIEarned LandingToInbound',@FK_ModuleType_SPRI,'EXEC [Agresso].[usp_LandingToInboundToOutboundWorkflow_BICIRI_EarnedPremium]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),
								
								--Level 20--I1B-3624
								--(@IFRS17_Orchestration_RI,44,'BICI_RIIncurred LandingToInbound',@FK_ModuleType_SPRI,'EXEC [BICIRI].[usp_LandingInboundWorkflow_BICI_RI_Incurred]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_RI,44,'BICI_RIIncurred LandingToInboundOutbound',@FK_ModuleType_SPRI,'EXEC [Agresso].[usp_LandingToInboundToOutboundWorkflow_BICIRI_Incurred]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),
								
								--Level 21 -- 4108
								--(@IFRS17_Orchestration_RI,45,'BICI_RIPaid LandingToInbound',@FK_ModuleType_SPRI,'EXEC  [BICIRI].[usp_LandingInboundWorkflow_BICI_RI_Paid]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_RI,45,'BICI_RIPaid LandingToInboundToOutbound',@FK_ModuleType_SPRI,'EXEC  [Agresso].[usp_LandingToInboundToOutboundWorkflow_BICIRI_Paid] '	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),
								
								--Level 22
								--I1B-3622 (@IFRS17_Orchestration_RI,46,'SPA_ObligatedPremium LandingToInbound',@FK_ModuleType_SPRI,'EXEC [SPA].[usp_LandingInboundWorkflow_ObligatedPremium_SPA]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_RI,46,'SPA_ObligatedPremium LandingToInbound',@FK_ModuleType_SPRI,'EXEC [SPA].[usp_LandingToInboundToOutbound_ObligatedPremium_SPA]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),
								
								--Level 23
								--(@IFRS17_Orchestration_RI,47,'ObligatedPremiumnMunich_QQS LandingToInbound',@FK_ModuleType_SPRI,'EXEC  [OP].[usp_LandingInboundWorkflow_ObligatedPremium_Munich_QQS]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),
								-- https://beazley.atlassian.net/browse/I1B-3621
								(@IFRS17_Orchestration_RI,47,'ObligatedPremium_MunichQQS LandingToInboundOutbound',@FK_ModuleType_SPRI,'EXEC  [OP].[usp_LandingToInboundToOutbound_ObligatedPremium_MunichQQS] '	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),

								--Level 24  
								(@IFRS17_Orchestration_RI,48,'RISpecialArrangements Transaction LandingToInboundToOutbound',@FK_ModuleType_SPRI,'EXEC [fdm].[usp_LandingToInboundToOutbound_RISpecialArrangements]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),								

								--Level 25 
								(@IFRS17_Orchestration_RI,49,'RI_ReInstatementPremiumEarned LandingToInboundToOutbound',@FK_ModuleType_SPRI,'EXEC [fdm].[usp_LandingToInboundToOutbound_RI_Reinstatement_Premium_Earned]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),								
								
								--Level 26
								(@IFRS17_Orchestration_RI,50,'ResDataAttClmAllocLandingPhase2Proc',@FK_ModuleType_SPRI,'EXEC [ADMRI].[ResDataAttClmAllocLandingPhase2]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),

								--Level 27 
								(@IFRS17_Orchestration_RI,51,'Inbound To OutBound ResDataAttClmAlloc',@FK_ModuleType_SPRI,'EXEC [ADM].[usp_LandingToInboundToOutbound_ResDataRIAttClmAlloc]'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),								
								
								--Level 28
								(@IFRS17_Orchestration_RI,52,'Loading RI_Percentage data', @FK_ModuleType_SPRI,'EXEC [fdm].[usp_LoadtoRI_Percentage]',@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),

								--Level 29
								(@IFRS17_Orchestration_RI,53,'RIPercentage LandingtoInbound',@FK_ModuleType_SPRI,'EXEC [fdm].[usp_LandingToInbound_RI_Percentage]',@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),

								--Level 30
								(@IFRS17_Orchestration_RI,54,'DataContract RIPercentage InboundToOutbound',@FK_ModuleType_SPRI, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_RIPercentage] '	,@IFRS17_InstanceName_RI, 'FinanceDataContract', NULL, NULL),


								-- Level 31  -166-180
								(@IFRS17_Orchestration_RI,166,'DimTrifocus', @FK_ModuleType_SPRI,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTrifocus.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,	 NULL),
								(@IFRS17_Orchestration_RI,167,'DimEntity',@FK_ModuleType_SPRI,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimEntity.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_RI,168,'DimYOA',@FK_ModuleType_SPRI,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimYOA.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_RI,169,'DimCCY',@FK_ModuleType_SPRI,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimCCY.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL), 
								(@IFRS17_Orchestration_RI,170,'DimProduct',@FK_ModuleType_SPRI,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimProduct.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_RI,171,'DimLocation',@FK_ModuleType_SPRI,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimLocation.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								--(@IFRS17_Orchestration_RI,157,'DimPolicy',@FK_ModuleType_SPPre,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPolicy.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_RI,172,'Dummy Load',@FK_ModuleType_SPRI,'SELECT 1'	,@IFRS17_InstanceName_RI, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_RI,173,'DimAccount',@FK_ModuleType_SPRI,			'SELECT 1'	,@IFRS17_InstanceName_RI, 'TechnicalHub', NULL, NULL),
								(@IFRS17_Orchestration_RI,174,'DimDataset',@FK_ModuleType_SPRI,			'EXEC  [Dim].[MergeDatasetBR1]','$(InstanceName)', 'TechnicalHub', NULL, NULL),
								(@IFRS17_Orchestration_RI,175,'DimPatternName',@FK_ModuleType_SPRI,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPatternName.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_RI,176,'DimCatCode',@FK_ModuleType_SPRI,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimCatCode.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_RI,177,'DimMovementType',@FK_ModuleType_SPRI,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimMovementType.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_RI,178,'DimAccountDtsx', @FK_ModuleType_SPRI,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimAccount.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,	 NULL),
								(@IFRS17_Orchestration_RI,179,'DimClaimExposure', @FK_ModuleType_SPRI,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimClaimExposure.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,	 NULL),
								(@IFRS17_Orchestration_RI,180,'DimPolicySection', @FK_ModuleType_SPRI,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPolicySection.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,	 NULL),

								--Level 32 --181-195
								(@IFRS17_Orchestration_RI,181,'DimTrackingStatus',@FK_ModuleType_SPRI,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTrackingStatus.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_RI,182,'DimRIPolicyType',@FK_ModuleType_SPRI,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimRIPolicyType.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_RI,183,'DimProgrammeCode',@FK_ModuleType_SPRI,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimProgrammeCode.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_RI,184,'DimTriangleGroup',@FK_ModuleType_SPRI,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTriangleGroup.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_RI,185,'DimReservingDataSet',@FK_ModuleType_SPRI,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimReservingDataset.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_RI,186,'DimRateScenario',@FK_ModuleType_SPRI,	    'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimRateScenario.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_RI,187,'DimReportingCurrency',@FK_ModuleType_SPRI,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimReportingCurrency.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),

								--Level 33  --196-205
								(@IFRS17_Orchestration_RI,196,'IFRS2017TechResult',@FK_ModuleType_SPRI,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactTechnicalResult_IFRS2017.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_RI,197,'FXRate'	,@FK_ModuleType_SPRI,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactFxRates.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_RI,198,'StandAlone Loads',@FK_ModuleType_SPRI,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''StandaloneLoads.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL)

								
					)
						AS Source(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.PK_Module = Source.PK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
					VALUES(Source.FK_Orchestration,  Source.PK_module,  Source.ModuleName,  Source.FK_ModuleType,  Source.ModuleRoutine,  Source.DestinationServer,  Source.DestinationDatabase,Source.FK_Schedule,Source.FK_Notification)
			WHEN	MATCHED
			THEN	UPDATE SET		FK_Orchestration	= source.FK_Orchestration, 
									PK_module 			= source.PK_module, 
									ModuleName 			= source.ModuleName, 
									FK_ModuleType 		= source.FK_ModuleType, 
									ModuleRoutine 		= source.ModuleRoutine, 
									DestinationServer	= source.DestinationServer, 
									DestinationDatabase	= source.DestinationDatabase, 
									FK_Schedule 		= source.FK_Schedule, 
									FK_Notification		= source.FK_Notification
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_RI
			THEN	DELETE;




			--ModuleHierarchy select * from etl.ModuleHierarchy
			MERGE 
			INTO	etl.ModuleHierarchy AS Target
			USING	(
						VALUES	--L1

								(@IFRS17_Orchestration_RI,	NULL,	1,	1), --
								(@IFRS17_Orchestration_RI,	NULL,	2,	1), -- 
								(@IFRS17_Orchestration_RI,	NULL,	3,	1), --
								(@IFRS17_Orchestration_RI,	NULL,	4,	1), -- 
								(@IFRS17_Orchestration_RI,	NULL,	5,	1), --
								(@IFRS17_Orchestration_RI,	NULL,	6,	1), -- 
								(@IFRS17_Orchestration_RI,	NULL,	7,	1), --
								(@IFRS17_Orchestration_RI,	NULL,	8,	1), --
								(@IFRS17_Orchestration_RI,	NULL,	9,	1), --
								(@IFRS17_Orchestration_RI,	NULL,	10,	1), --
								(@IFRS17_Orchestration_RI,	NULL,	11,	1), --
								(@IFRS17_Orchestration_RI,	NULL,	12,	1), --
								

								--L2
								(@IFRS17_Orchestration_RI,NULL,	16, 2), --
								(@IFRS17_Orchestration_RI,NULL,	17, 2), -- 
								(@IFRS17_Orchestration_RI,NULL, 18, 2), --
								(@IFRS17_Orchestration_RI,NULL,	19, 2), -- 
								(@IFRS17_Orchestration_RI,NULL,	20, 2), -- 
								(@IFRS17_Orchestration_RI,NULL,	21, 2), -- 
								(@IFRS17_Orchestration_RI,NULL,	22, 2), --
								(@IFRS17_Orchestration_RI,NULL,	23, 2), --
								(@IFRS17_Orchestration_RI,NULL,	24, 2), --
								(@IFRS17_Orchestration_RI,NULL,	25, 2), --
								(@IFRS17_Orchestration_RI,NULL,	26, 2), --

								--L3
								(@IFRS17_Orchestration_RI,	1,	27, 3),
								(@IFRS17_Orchestration_RI,	2,	27, 3),
								(@IFRS17_Orchestration_RI,	3,	27, 3),
								(@IFRS17_Orchestration_RI,	4,	27,	3),
								(@IFRS17_Orchestration_RI,	5,	27, 3),
								(@IFRS17_Orchestration_RI,	6,	27, 3),
								(@IFRS17_Orchestration_RI,	7,	27, 3),
								(@IFRS17_Orchestration_RI,	8,	27, 3),
								(@IFRS17_Orchestration_RI,	9,	27, 3),
								(@IFRS17_Orchestration_RI,	10,	27,	3),
								(@IFRS17_Orchestration_RI,	11,	27, 3),
								(@IFRS17_Orchestration_RI,	12,	27, 3),
								(@IFRS17_Orchestration_RI,	16,	27, 3),
								(@IFRS17_Orchestration_RI,	17,	27, 3),
								(@IFRS17_Orchestration_RI,	18,	27, 3),
								(@IFRS17_Orchestration_RI,	19,	27,	3),
								(@IFRS17_Orchestration_RI,	20,	27, 3),
								(@IFRS17_Orchestration_RI,	21,	27, 3),
								(@IFRS17_Orchestration_RI,	22,	27, 3),
								(@IFRS17_Orchestration_RI,	23,	27, 3),
								(@IFRS17_Orchestration_RI,	24,	27, 3),
								(@IFRS17_Orchestration_RI,	25,	27, 3),
								(@IFRS17_Orchestration_RI,	26,	27, 3),

								--Level 4
								(@IFRS17_Orchestration_RI,	27,	28, 4),

								--Level 5
								(@IFRS17_Orchestration_RI,	28,	29, 5),

								--Level 6
								(@IFRS17_Orchestration_RI,	29,	30, 6),

								--Level 7
								(@IFRS17_Orchestration_RI,	30,	31, 7),
								
								--Level 8
								(@IFRS17_Orchestration_RI,	31,	32, 8),

								--Level 9
								(@IFRS17_Orchestration_RI,	32,	33, 9),

								--Level 10
								(@IFRS17_Orchestration_RI,	33,	34, 10),

								--Level 11
								(@IFRS17_Orchestration_RI,	34,	35, 11),

								--Level 12
								(@IFRS17_Orchestration_RI,	35,	36, 12),

								--Level 13
								(@IFRS17_Orchestration_RI,	36,	37, 13),

								--Level 14
								(@IFRS17_Orchestration_RI,	37,	38, 14),

								--Level 15
								(@IFRS17_Orchestration_RI,	38,	39, 15),

								--Level 16
								(@IFRS17_Orchestration_RI,	39,	40, 16),

								--Level 17
								(@IFRS17_Orchestration_RI,	40,	41, 17),

								--Level 18
								(@IFRS17_Orchestration_RI,	41,	42, 18),

								--Level 19
								(@IFRS17_Orchestration_RI,	42,	43, 19),

								--Level 20
								(@IFRS17_Orchestration_RI,	43,	44, 20),

								--Level 21
								(@IFRS17_Orchestration_RI,	44,	45, 21),

								--Level 22
								(@IFRS17_Orchestration_RI,	45,	46, 22),

								--Level 23
								(@IFRS17_Orchestration_RI,	46,	47, 23),

								--Level 24
								(@IFRS17_Orchestration_RI,	47,	48, 24),

								--Level 25
								(@IFRS17_Orchestration_RI,	48,	49, 25),

								--Level 26
								(@IFRS17_Orchestration_RI,	49,	50, 26),

								--Level 27
								(@IFRS17_Orchestration_RI,	50,	51, 27),

								--Level 28
								(@IFRS17_Orchestration_RI,	51,	52, 28),

								--Level 29
								(@IFRS17_Orchestration_RI,	52,	53, 29),

								--Level 30
								(@IFRS17_Orchestration_RI,	53,	54, 30),

								--L31 --Dims
							
								(@IFRS17_Orchestration_RI,	54,	166,		31), 
								(@IFRS17_Orchestration_RI,	54,	167,		31),
								(@IFRS17_Orchestration_RI,	54,	168,		31),
								(@IFRS17_Orchestration_RI,	54,	169,		31), 
								(@IFRS17_Orchestration_RI,	54,	170,		31),
								(@IFRS17_Orchestration_RI,	54,	171,		31),
								(@IFRS17_Orchestration_RI,	54,	172,		31), 
								(@IFRS17_Orchestration_RI,	54,	173,		31),
								(@IFRS17_Orchestration_RI,	54,	174,		31),
								(@IFRS17_Orchestration_RI,	54,	175,		31), 
								(@IFRS17_Orchestration_RI,	54,	176,		31),
								(@IFRS17_Orchestration_RI,	54,	177,		31),
								(@IFRS17_Orchestration_RI,	54,	178,		31), 
								(@IFRS17_Orchestration_RI,	54,	179,		31),
								(@IFRS17_Orchestration_RI,	54,	180,		31),

								--L32
								(@IFRS17_Orchestration_RI,		166, 181,		32), 
								(@IFRS17_Orchestration_RI,		167, 181,		32),
								(@IFRS17_Orchestration_RI,		168, 181,		32),
								(@IFRS17_Orchestration_RI,		169, 181,		32), 
								(@IFRS17_Orchestration_RI,		170, 181,		32),
								(@IFRS17_Orchestration_RI,		171, 181,		32),
								(@IFRS17_Orchestration_RI,		172, 181,		32), 
								(@IFRS17_Orchestration_RI,		173, 181,		32),
								(@IFRS17_Orchestration_RI,		174, 181,		32),
								(@IFRS17_Orchestration_RI,		175, 181,		32), 
								(@IFRS17_Orchestration_RI,		176, 181,		32),
								(@IFRS17_Orchestration_RI,		177, 181,		32),
								(@IFRS17_Orchestration_RI,		178, 181,		32), 
								(@IFRS17_Orchestration_RI,		179, 181,		32),
								(@IFRS17_Orchestration_RI,		180, 181,		32),

								(@IFRS17_Orchestration_RI,		166, 182,		32), 
								(@IFRS17_Orchestration_RI,		167, 182,		32),
								(@IFRS17_Orchestration_RI,		168, 182,		32),
								(@IFRS17_Orchestration_RI,		169, 182,		32), 
								(@IFRS17_Orchestration_RI,		170, 182,		32),
								(@IFRS17_Orchestration_RI,		171, 182,		32),
								(@IFRS17_Orchestration_RI,		172, 182,		32), 
								(@IFRS17_Orchestration_RI,		173, 182,		32),
								(@IFRS17_Orchestration_RI,		174, 182,		32),
								(@IFRS17_Orchestration_RI,		175, 182,		32), 
								(@IFRS17_Orchestration_RI,		176, 182,		32),
								(@IFRS17_Orchestration_RI,		177, 182,		32),
								(@IFRS17_Orchestration_RI,		178, 182,		32), 
								(@IFRS17_Orchestration_RI,		179, 182,		32),
								(@IFRS17_Orchestration_RI,		180, 182,		32),

								(@IFRS17_Orchestration_RI,		166, 183,		32), 
								(@IFRS17_Orchestration_RI,		167, 183,		32),
								(@IFRS17_Orchestration_RI,		168, 183,		32),
								(@IFRS17_Orchestration_RI,		169, 183,		32), 
								(@IFRS17_Orchestration_RI,		170, 183,		32),
								(@IFRS17_Orchestration_RI,		171, 183,		32),
								(@IFRS17_Orchestration_RI,		172, 183,		32), 
								(@IFRS17_Orchestration_RI,		173, 183,		32),
								(@IFRS17_Orchestration_RI,		174, 183,		32),
								(@IFRS17_Orchestration_RI,		175, 183,		32), 
								(@IFRS17_Orchestration_RI,		176, 183,		32),
								(@IFRS17_Orchestration_RI,		177, 183,		32),
								(@IFRS17_Orchestration_RI,		178, 183,		32), 
								(@IFRS17_Orchestration_RI,		179, 183,		32),
								(@IFRS17_Orchestration_RI,		180, 183,		32),

								(@IFRS17_Orchestration_RI,		166, 184,		32), 
								(@IFRS17_Orchestration_RI,		167, 184,		32),
								(@IFRS17_Orchestration_RI,		168, 184,		32),
								(@IFRS17_Orchestration_RI,		169, 184,		32), 
								(@IFRS17_Orchestration_RI,		170, 184,		32),
								(@IFRS17_Orchestration_RI,		171, 184,		32),
								(@IFRS17_Orchestration_RI,		172, 184,		32), 
								(@IFRS17_Orchestration_RI,		173, 184,		32),
								(@IFRS17_Orchestration_RI,		174, 184,		32),
								(@IFRS17_Orchestration_RI,		175, 184,		32), 
								(@IFRS17_Orchestration_RI,		176, 184,		32),
								(@IFRS17_Orchestration_RI,		177, 184,		32),
								(@IFRS17_Orchestration_RI,		178, 184,		32), 
								(@IFRS17_Orchestration_RI,		179, 184,		32),
								(@IFRS17_Orchestration_RI,		180, 184,		32),

								(@IFRS17_Orchestration_RI,		166, 185,		32), 
								(@IFRS17_Orchestration_RI,		167, 185,		32),
								(@IFRS17_Orchestration_RI,		168, 185,		32),
								(@IFRS17_Orchestration_RI,		169, 185,		32), 
								(@IFRS17_Orchestration_RI,		170, 185,		32),
								(@IFRS17_Orchestration_RI,		171, 185,		32),
								(@IFRS17_Orchestration_RI,		172, 185,		32), 
								(@IFRS17_Orchestration_RI,		173, 185,		32),
								(@IFRS17_Orchestration_RI,		174, 185,		32),
								(@IFRS17_Orchestration_RI,		175, 185,		32), 
								(@IFRS17_Orchestration_RI,		176, 185,		32),
								(@IFRS17_Orchestration_RI,		177, 185,		32),
								(@IFRS17_Orchestration_RI,		178, 185,		32), 
								(@IFRS17_Orchestration_RI,		179, 185,		32),
								(@IFRS17_Orchestration_RI,		180, 185,		32),

								(@IFRS17_Orchestration_RI,		166, 186,		32), 
								(@IFRS17_Orchestration_RI,		167, 186,		32),
								(@IFRS17_Orchestration_RI,		168, 186,		32),
								(@IFRS17_Orchestration_RI,		169, 186,		32), 
								(@IFRS17_Orchestration_RI,		170, 186,		32),
								(@IFRS17_Orchestration_RI,		171, 186,		32),
								(@IFRS17_Orchestration_RI,		172, 186,		32), 
								(@IFRS17_Orchestration_RI,		173, 186,		32),
								(@IFRS17_Orchestration_RI,		174, 186,		32),
								(@IFRS17_Orchestration_RI,		175, 186,		32), 
								(@IFRS17_Orchestration_RI,		176, 186,		32),
								(@IFRS17_Orchestration_RI,		177, 186,		32),
								(@IFRS17_Orchestration_RI,		178, 186,		32), 
								(@IFRS17_Orchestration_RI,		179, 186,		32),
								(@IFRS17_Orchestration_RI,		180, 186,		32),

								(@IFRS17_Orchestration_RI,		166, 187,		32), 
								(@IFRS17_Orchestration_RI,		167, 187,		32),
								(@IFRS17_Orchestration_RI,		168, 187,		32),
								(@IFRS17_Orchestration_RI,		169, 187,		32), 
								(@IFRS17_Orchestration_RI,		170, 187,		32),
								(@IFRS17_Orchestration_RI,		171, 187,		32),
								(@IFRS17_Orchestration_RI,		172, 187,		32), 
								(@IFRS17_Orchestration_RI,		173, 187,		32),
								(@IFRS17_Orchestration_RI,		174, 187,		32),
								(@IFRS17_Orchestration_RI,		175, 187,		32), 
								(@IFRS17_Orchestration_RI,		176, 187,		32),
								(@IFRS17_Orchestration_RI,		177, 187,		32),
								(@IFRS17_Orchestration_RI,		178, 187,		32), 
								(@IFRS17_Orchestration_RI,		179, 187,		32),
								(@IFRS17_Orchestration_RI,		180, 187,		32),
								
								--L33

								(@IFRS17_Orchestration_RI,	181,	196,		33), 
								(@IFRS17_Orchestration_RI,	182,	196,		33),
								(@IFRS17_Orchestration_RI,	183,	196,		33),
								(@IFRS17_Orchestration_RI,	184,	196,		33), 
								(@IFRS17_Orchestration_RI,	185,	196,		33),
								(@IFRS17_Orchestration_RI,	186,	196,		33),
								(@IFRS17_Orchestration_RI,	187,	196,		33),

								(@IFRS17_Orchestration_RI,	181,	197,		33), 
								(@IFRS17_Orchestration_RI,	182,	197,		33),
								(@IFRS17_Orchestration_RI,	183,	197,		33),
								(@IFRS17_Orchestration_RI,	184,	197,		33), 
								(@IFRS17_Orchestration_RI,	185,	197,		33),
								(@IFRS17_Orchestration_RI,	186,	197,		33),
								(@IFRS17_Orchestration_RI,	187,	197,		33),

								(@IFRS17_Orchestration_RI,	181,	198,		33), 
								(@IFRS17_Orchestration_RI,	182,	198,		33),
								(@IFRS17_Orchestration_RI,	183,	198,		33),
								(@IFRS17_Orchestration_RI,	184,	198,		33), 
								(@IFRS17_Orchestration_RI,	185,	198,		33),
								(@IFRS17_Orchestration_RI,	186,	198,		33),
								(@IFRS17_Orchestration_RI,	187,	198,		33)


-- SSIS packages
--IFRS17_ADMToLandingExtract.dtsx -- > [ADM].[usp_LandingToInbound] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow
--								  -- > [ADM].[usp_LandingToInbound_Pattern] --> FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_Pattern			

--IFRS17_AgressoToLandingExtract.dtsx -- on hold

--IFRS17_BICCToLandingExtract.dtsx -- > [BICC].[usp_LandingToInbound] -- > assume FinanceDataContract.Inbound.usp_InboundOutboundWorkflow but unit test has changed or not there. Ciprian will update me.
--IFRS17_EIOPAToLandingExtract.dtsx -- > [XLS].[usp_EIOPALandingToInbound_DiscountRates] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_DiscountRates
--IFRS17_EurobaseToLandingExtract.dtsx -- > [Eurobase].[usp_LandingToInbound_EPI] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow
--										-- > [Eurobase].[usp_LandingToInbound] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow

-- needs to be added
--IFRS17_LossRatioToLandingExtract.dtsx -- > [XLS].[usp_LandingToInbound_LossRatio] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_LossRatio

--IFRS17_MDSToLandingExtract.dtsx -- > [MDS].[usp_LandingToInbound] -- > no outbound required

--check this!
--IFRS17_NatCatEarningToLandingExtract.dtsx -- > [XLS].[usp_NatCatEarningLandingToInbound_Pattern] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_Pattern


					) AS Source(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.FK_ChildModule = Source.FK_ChildModule
				AND Target.FK_ParentModule = Source.FK_ParentModule
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
					VALUES(Source.FK_Orchestration,Source.FK_ParentModule,Source.FK_ChildModule,Source.TreeLevel)
			WHEN	MATCHED
			THEN	UPDATE SET	FK_Orchestration = source.FK_Orchestration, 
								FK_ParentModule = source.FK_ParentModule, 
								FK_ChildModule = source.FK_ChildModule, 
								TreeLevel = source.TreeLevel
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_RI
			THEN	DELETE;






			--ModuleActivity select * from etl.ModuleActivity
			MERGE	etl.ModuleActivity Target
			USING	(
						SELECT	m.FK_Orchestration,
								m.PK_Module,
								1, -- Pending
								'Initialization from deployment' -- run description
						FROM	etl.Module m
						WHERE	m.FK_Orchestration = @IFRS17_Orchestration_RI
					) Source (FK_Orchestration, FK_Module, FK_ModuleStatus,RunDescription)
			ON		Source.FK_Orchestration = Target.FK_Orchestration
				AND	Source.FK_Module = Target.FK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT	(FK_Orchestration, FK_Module, FK_ModuleStatus, RunDescription)
					VALUES	(Source.FK_Orchestration, Source.FK_Module, Source.FK_ModuleStatus, Source.RunDescription)
			WHEN	MATCHED
			THEN	UPDATE	SET	Target.FK_ModuleStatus = Source.FK_ModuleStatus, Target.RunDescription = Source.RunDescription
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_RI
			THEN	DELETE;


