﻿Delete from etl.ModuleHierarchy where FK_Orchestration=8
Delete from etl.ModuleActivity where FK_Orchestration=8
Delete From etl.Module where FK_Orchestration=8
			MERGE 
			INTO	etl.Orchestration AS Target
			USING	(VALUES(8, 'BR1 Load to TechnicalHub',0)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled)
			ON		(Target.PK_Orchestration = Source.PK_Orchestration)
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(PK_Orchestration,OrchestrationName,IsEnabled)
					VALUES(Source.PK_Orchestration,  Source.OrchestrationName,  Source.IsEnabled)
			WHEN	MATCHED
			THEN	UPDATE SET	Target.ORchestrationName = Source.OrchestrationName,
								Target.IsEnabled = Source.Isenabled;

			MERGE 
			INTO	etl.Module AS Target
			USING	(
						VALUES	
															
								--level 1
								(8,1,'DimTrifocus', 1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTrifocus.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,	 NULL),
								(8,2,'DimEntity',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimEntity.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(8,3,'DimYOA',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimYOA.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(8,4,'DimCCY',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimCCY.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL), 
								(8,5,'DimProduct',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimProduct.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(8,6,'DimLocation',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimLocation.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(8,7,'DimPolicy',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPolicy.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(8,8,'DimAccount',1,			'EXEC  [Dim].[MergeAccountsBR1]','$(InstanceName)', 'TechnicalHub', NULL, NULL),
								(8,9,'DimDataset',1,			'EXEC  [Dim].[MergeDatasetBR1]','$(InstanceName)', 'TechnicalHub', NULL, NULL),
								(8,10,'DimPatternName',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPatternName.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(8,12,'DimCatCode',1,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimCatCode.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(8,20,'DimMovementType',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimMovementType.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(8,21,'DimTrackingStatus',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTrackingStatus.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(8,22,'DimAccountdtsx',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimAccount.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(8,23,'DimClaimExposure',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimClaimExposure.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
							--	(8,24,'DimPolicySection',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPolicySection.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),

								--Level 2
								(8,24,'DimPolicySection',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPolicySection.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(8,25,'DimRIPolicyType',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimRIPolicyType.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(8,26,'DimProgrammeCode',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimProgrammeCode.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),

								--Level 2 -->level 3
								(8,13,'IFRS2017TechResult',1,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactTechnicalResult_IFRS2017.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(8,14,'Fact Pattern',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactPattern.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(8,30,'StandAlone Loads',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''StandaloneLoads.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

								--Level 3 --> level 4
								(8,15,'Post Initial and Subsequment',1,'SELECT 1 --EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''Post Fact Initial Subsequent.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

								--level4 -->level5
								(8,16,'Cube Proccesing',1,'SELECT 1 --EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''CubeBuild.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL)

								
							
							
						)
					
						AS Source(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.PK_Module = Source.PK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
					VALUES(Source.FK_Orchestration,  Source.PK_module,  Source.ModuleName,  Source.FK_ModuleType,  Source.ModuleRoutine,  Source.DestinationServer,  Source.DestinationDatabase,Source.FK_Schedule,Source.FK_Notification)
			WHEN	MATCHED
			THEN	UPDATE SET		FK_Orchestration	= source.FK_Orchestration, 
									PK_module 			= source.PK_module, 
									ModuleName 			= source.ModuleName, 
									FK_ModuleType 		= source.FK_ModuleType, 
									ModuleRoutine 		= source.ModuleRoutine, 
									DestinationServer	= source.DestinationServer, 
									DestinationDatabase	= source.DestinationDatabase, 
									FK_Schedule 		= source.FK_Schedule, 
									FK_Notification		= source.FK_Notification
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = 8
			THEN	DELETE;

			MERGE 
			INTO	etl.ModuleHierarchy AS Target
			USING	(
						VALUES	--L1 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
								(8,	NULL,	1,	1), 
								(8,	NULL,	2,	1), 
								(8,	NULL,	3,	1), 
								(8,	NULL,	4,	1), 
								(8,	NULL,	5,	1), 
								(8,	NULL,	6,	1),
								(8,	NULL,	7,	1), 
								(8,	NULL,	8,	1), 
								(8,	NULL,	9,	1), 
								(8,	NULL,	10,	1),
								/*(8,	NULL,	11,	1), */
								(8,	NULL,	12,	1), 
								(8,	NULL,	20,	1), 
								(8,	NULL,	21,	1), 
								(8,	NULL,	22,	1), 
								(8,	NULL,	23,	1), 
								--(8,	NULL,	24,	1), 

								
								--level 2 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
								(8,	1,	24,	2), 
								(8,	2,	24,	2), 
								(8,	3,	24,	2), 
								(8,	4,	24,	2), 
								(8,	5,	24,	2), 
								(8,	6,	24,	2),
								(8,	7,	24,	2), 
								(8,	8,	24,	2), 
								(8,	9,	24,	2), 
								(8,	10,	24,	2),
								/*(8,	11,	24,	2), */
								(8,	12,	24,	2),
								(8,	20,	24,	2),
								(8,	21,	24,	2),
								(8,	22,	24,	2),
								(8,	23,	24,	2),

								(8,	1,	25,	2), 
								(8,	2,	25,	2), 
								(8,	3,	25,	2), 
								(8,	4,	25,	2), 
								(8,	5,	25,	2), 
								(8,	6,	25,	2),
								(8,	7,	25,	2), 
								(8,	8,	25,	2), 
								(8,	9,	25,	2), 
								(8,	10,	25,	2),
								/*(8,	11,	24,	2), */
								(8,	12,	25,	2),
								(8,	20,	25,	2),
								(8,	21,	25,	2),
								(8,	22,	25,	2),
								(8,	23,	25,	2),

								(8,	1,	26,	2), 
								(8,	2,	26,	2), 
								(8,	3,	26,	2), 
								(8,	4,	26,	2), 
								(8,	5,	26,	2), 
								(8,	6,	26,	2),
								(8,	7,	26,	2), 
								(8,	8,	26,	2), 
								(8,	9,	26,	2), 
								(8,	10,	26,	2),
								/*(8,	11,	24,	2), */
								(8,	12,	26,	2),
								(8,	20,	26,	2),
								(8,	21,	26,	2),
								(8,	22,	26,	2),
								(8,	23,	26,	2),

								--level 3
								(8,	24,	13,	3),
								(8,	24,	14,	3),
								(8,	24,	30,	3),
								
								(8,	25,	13,	3),
								(8,	25,	14,	3),
								(8,	25,	30,	3),

								(8,	26,	13,	3),
								(8,	26,	14,	3),
								(8,	26,	30,	3),

								
								
					
								/*--L2 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
								(8,	1,	13,	2), 
								(8,	2,	13,	2), 
								(8,	3,	13,	2), 
								(8,	4,	13,	2), 
								(8,	5,	13,	2), 
								(8,	6,	13,	2),
								(8,	7,	13,	2), 
								(8,	8,	13,	2), 
								(8,	9,	13,	2), 
								(8,	10,	13,	2),
								/*(8,	11,	13,	2), */
								(8,	12,	13,	2),
								(8,	20,	13,	2),
								(8,	21,	13,	2),
								(8,	22,	13,	2),
								(8,	23,	13,	2),
								--(8,	24,	13,	2),

								(8,	1,	14,	2), 
								(8,	2,	14,	2), 
								(8,	3,	14,	2), 
								(8,	4,	14,	2), 
								(8,	5,	14,	2), 
								(8,	6,	14,	2),
								(8,	7,	14,	2), 
								(8,	8,	14,	2), 
								(8,	9,	14,	2), 
								(8,	10,	14,	2),
								/*(8,	11,	14,	2), */
								(8,	12,	14,	2),
								(8,	20,	14,	2),
								(8,	21,	14,	2),
								(8,	22,	14,	2),
								(8,	23,	14,	2),
								--(8,	24,	14,	2),
								 =======   */

								--l4
								(8,	13,	15,	4), 
								(8,	14, 15,	4),
								(8,	30, 15,	4),
								--l5
								(8,	15, 16,	5)
					
					
					) AS Source(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.FK_ChildModule = Source.FK_ChildModule
				AND Target.FK_ParentModule = Source.FK_ParentModule
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
					VALUES(Source.FK_Orchestration,Source.FK_ParentModule,Source.FK_ChildModule,Source.TreeLevel)
			WHEN	MATCHED
			THEN	UPDATE SET	FK_Orchestration = source.FK_Orchestration, 
								FK_ParentModule = source.FK_ParentModule, 
								FK_ChildModule = source.FK_ChildModule, 
								TreeLevel = source.TreeLevel
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = 8
			THEN	DELETE;


			MERGE	etl.ModuleActivity Target
			USING	(
						SELECT	m.FK_Orchestration,
								m.PK_Module,
								1
						FROM	etl.Module m
						WHERE	m.FK_Orchestration = 8
					) Source (FK_Orchestration, FK_Module, FK_ModuleStatus)
			ON		Source.FK_Orchestration = Target.FK_Orchestration
				AND	Source.FK_Module = Target.FK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT	(FK_Orchestration, FK_Module, FK_ModuleStatus)
					VALUES	(Source.FK_Orchestration, Source.FK_Module, Source.FK_ModuleStatus)
			WHEN	MATCHED
			THEN	UPDATE	SET	Target.FK_ModuleStatus = Source.FK_ModuleStatus
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = 8
			THEN	DELETE;