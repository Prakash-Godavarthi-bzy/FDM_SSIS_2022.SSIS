﻿--:setvar InstanceName "UKDVDB149"

/*
	Change log. Please add comments to help us developers make sure we don't miss changes before we check in code.


	Author:			nithin.dumpeti@beazley.com
	Description:	Orchestration18 is used to run only for View To Table

*/

declare @IFRS17_InstanceName_VT nvarchar(129) = '$(InstanceName)'



--select @IFRS17_InstanceName_Pre

/*
	-- to delete everything and start again. The merge statement can fail when changes break referential entrigity, 
	-- so the data needs to be deleted and re-stated.
declare @IFRS17_Orchestration_Pre int = 3

delete etl.ModuleActivity
where FK_Orchestration = @IFRS17_Orchestration_VT

delete etl.ModuleHierarchy
where FK_Orchestration = @IFRS17_Orchestration_VT

delete etl.Module
where FK_Orchestration = @IFRS17_Orchestration_VT

delete etl.Orchestration
where PK_Orchestration = @IFRS17_Orchestration_VT

*/

-- static variables
declare @IFRS17_Orchestration_VT int = 17
declare @IFRS17_Orchestration_IsEnabledVT int = 1
declare @IFRS17_RunTimeExecutionPriorityOrderVT int = 1

Delete from etl.ModuleHierarchy 
where FK_Orchestration=@IFRS17_Orchestration_VT

Delete from etl.ModuleActivity 
where FK_Orchestration=@IFRS17_Orchestration_VT

Delete From etl.Module 
where FK_Orchestration=@IFRS17_Orchestration_VT


  --orchestration select * from etl.Orchestration
			MERGE 
			INTO	etl.Orchestration AS Target
			USING	(VALUES(@IFRS17_Orchestration_VT, 'BR1Orchestration ViewToTable',@IFRS17_Orchestration_IsEnabledVT)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled)
			ON		(Target.PK_Orchestration = Source.PK_Orchestration)
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(PK_Orchestration,OrchestrationName,IsEnabled)
					VALUES(Source.PK_Orchestration,  Source.OrchestrationName,  Source.IsEnabled)
			WHEN	MATCHED
			THEN	UPDATE SET	Target.ORchestrationName = Source.OrchestrationName,
								Target.IsEnabled = Source.Isenabled;



--module select * from etl.Module 

declare @FK_ModuleType_SPVT int = (select PK_ModuleType from [etl].[ModuleType] where ModuleType = 'SPROC')
declare @FK_ModuleType_SSISVT int = (select PK_ModuleType from [etl].[ModuleType] where ModuleType = 'SSIS')

			MERGE --@IFRS17_Orchestration_Pre
			INTO	etl.Module AS Target
			USING	(
						VALUES	--Level 1 ViewToTable 1*15=1-15							
								
								(@IFRS17_Orchestration_VT,1,'ViewToTable',@FK_ModuleType_SSISVT,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17TechnicalResult.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_VT, 'SchedulingHub', NULL, NULL)



								
					)
						AS Source(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.PK_Module = Source.PK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
					VALUES(Source.FK_Orchestration,  Source.PK_module,  Source.ModuleName,  Source.FK_ModuleType,  Source.ModuleRoutine,  Source.DestinationServer,  Source.DestinationDatabase,Source.FK_Schedule,Source.FK_Notification)
			WHEN	MATCHED
			THEN	UPDATE SET		FK_Orchestration	= source.FK_Orchestration, 
									PK_module 			= source.PK_module, 
									ModuleName 			= source.ModuleName, 
									FK_ModuleType 		= source.FK_ModuleType, 
									ModuleRoutine 		= source.ModuleRoutine, 
									DestinationServer	= source.DestinationServer, 
									DestinationDatabase	= source.DestinationDatabase, 
									FK_Schedule 		= source.FK_Schedule, 
									FK_Notification		= source.FK_Notification
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_VT
			THEN	DELETE;




			--ModuleHierarchy select * from etl.ModuleHierarchy
			MERGE 
			INTO	etl.ModuleHierarchy AS Target
			USING	(
						VALUES	
								--L1
								(@IFRS17_Orchestration_VT,	NULL,	1,		1)
								
					) AS Source(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.FK_ChildModule = Source.FK_ChildModule
				AND Target.FK_ParentModule = Source.FK_ParentModule
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
					VALUES(Source.FK_Orchestration,Source.FK_ParentModule,Source.FK_ChildModule,Source.TreeLevel)
			WHEN	MATCHED
			THEN	UPDATE SET	FK_Orchestration = source.FK_Orchestration, 
								FK_ParentModule = source.FK_ParentModule, 
								FK_ChildModule = source.FK_ChildModule, 
								TreeLevel = source.TreeLevel
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_VT
			THEN	DELETE;






			--ModuleActivity select * from etl.ModuleActivity
			MERGE	etl.ModuleActivity Target
			USING	(
						SELECT	m.FK_Orchestration,
								m.PK_Module,
								1, -- Pending
								'Initialization from deployment' -- run description
						FROM	etl.Module m
						WHERE	m.FK_Orchestration = @IFRS17_Orchestration_VT
					) Source (FK_Orchestration, FK_Module, FK_ModuleStatus,RunDescription)
			ON		Source.FK_Orchestration = Target.FK_Orchestration
				AND	Source.FK_Module = Target.FK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT	(FK_Orchestration, FK_Module, FK_ModuleStatus, RunDescription)
					VALUES	(Source.FK_Orchestration, Source.FK_Module, Source.FK_ModuleStatus, Source.RunDescription)
			WHEN	MATCHED
			THEN	UPDATE	SET	Target.FK_ModuleStatus = Source.FK_ModuleStatus, Target.RunDescription = Source.RunDescription
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_VT
			THEN	DELETE;


