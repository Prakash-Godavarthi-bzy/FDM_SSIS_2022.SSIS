﻿--:setvar InstanceName "UKDVDB149"

/*
	Change log. Please add comments to help us developers make sure we don't miss changes before we check in code.

	Author:			mark.baekdal@beazley.com
	Description:	(@IFRS17_Orchestration_TL,99,'DataContract ReInsuranceTrifocusAllocationsTreaty InboundToOutbound',@FK_ModuleType_SPtl,'EXEC [Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTreatyContractAttributes]'	,@IFRS17_InstanceName_tl, 'FinanceDataContract', NULL, NULL),
					should have been
					(@IFRS17_Orchestration_TL,99,'DataContract ReInsuranceTrifocusAllocationsTreaty InboundToOutbound',@FK_ModuleType_SPtl,'EXEC [Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTrifocusAllocationsTreaty]'	,@IFRS17_InstanceName_tl, 'FinanceDataContract', NULL, NULL),

					[Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTreatyContractAttributes] is called by [FinanceLanding].[Eurobase].[usp_LandingToInboundToOutbound_TreatyReInsurance].

	Modified By : Venkat.yerravati@beazley.com
	Modified Date : 19-02-2024
	Changes done : Removed the Proc for SPA_MUNQQS_Tactical Dataset (https://beazley.atlassian.net/browse/I1B-5065)

*/

declare @IFRS17_InstanceName_tl nvarchar(129) = '$(InstanceName)'

--select @IFRS17_InstanceName

/*
	-- to delete everything and start again. The merge statement can fail when changes break referential entrigity, 
	-- so the data needs to be deleted and re-stated.
declare @IFRS17_Orchestration_TL int = 3

delete etl.ModuleActivity
where FK_Orchestration = @IFRS17_Orchestration_TL

delete etl.ModuleHierarchy
where FK_Orchestration = @IFRS17_Orchestration_TL

delete etl.Module
where FK_Orchestration = @IFRS17_Orchestration_TL

delete etl.Orchestration
where PK_Orchestration = @IFRS17_Orchestration_TL

*/

-- static variables
declare @IFRS17_Orchestration_TL int = 9
declare @IFRS17_Orchestration_IsEnabledTL int = 0
declare @IFRS17_RunTimeExecutionPriorityOrderTL int = 1

Delete from etl.ModuleHierarchy where FK_Orchestration=9
Delete from etl.ModuleActivity where FK_Orchestration=9
Delete From etl.Module where FK_Orchestration=9



  --orchestration select * from etl.Orchestration
			MERGE 
			INTO	etl.Orchestration AS Target
			USING	(VALUES(@IFRS17_Orchestration_TL, 'IFRS17_TL',@IFRS17_Orchestration_IsEnabledTL)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled)
			ON		(Target.PK_Orchestration = Source.PK_Orchestration)
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(PK_Orchestration,OrchestrationName,IsEnabled)
					VALUES(Source.PK_Orchestration,  Source.OrchestrationName,  Source.IsEnabled)
			WHEN	MATCHED
			THEN	UPDATE SET	Target.ORchestrationName = Source.OrchestrationName,
								Target.IsEnabled = Source.Isenabled;

			-- code to uncomment when priority column can be released.
			--MERGE 
			--INTO	etl.Orchestration AS Target
			--USING	(VALUES(@IFRS17_Orchestration_TL, 'IFRS17',@IFRS17_Orchestration_IsEnabledTL,@IFRS17_RunTimeExecutionPriorityOrder)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled,RunTimeExecutionPriorityOrder)
			--ON		(Target.PK_Orchestration = Source.PK_Orchestration)
			--WHEN	NOT MATCHED BY TARGET
			--THEN	INSERT(PK_Orchestration,OrchestrationName,IsEnabled,RunTimeExecutionPriorityOrder)
			--		VALUES(Source.PK_Orchestration,  Source.OrchestrationName,  Source.IsEnabled, Source.RunTimeExecutionPriorityOrder)
			--WHEN	MATCHED
			--THEN	UPDATE SET	Target.ORchestrationName = Source.OrchestrationName,
			--					Target.IsEnabled = Source.Isenabled,
			--					Target.RunTimeExecutionPriorityOrder = Source.RunTimeExecutionPriorityOrder;

--module select * from etl.Module 

declare @FK_ModuleType_SPtl int = (select PK_ModuleType from [etl].[ModuleType] where ModuleType = 'SPROC')

			MERGE 
			INTO	etl.Module AS Target
			USING	(
						VALUES	--Level 1
							    (@IFRS17_Orchestration_TL,1,'BusinessPlanning Landing',  @FK_ModuleType_SPtl,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BusinessPlanLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),
							    (@IFRS17_Orchestration_TL,2,'BICI_RI_Ultimate_Premium Landing',  @FK_ModuleType_SPtl,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BICIRI_Ultimate.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_TL,3,'ResDataEventAlloc Landing',  @FK_ModuleType_SPtl,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADMResDataAllocToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),
							    (@IFRS17_Orchestration_TL,4,'UltimateRIPsEventAlloc Landing',  @FK_ModuleType_SPtl,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_UltimateRIPsEventToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),
							    (@IFRS17_Orchestration_TL,5,'BICI_RIIncurred Landing',  @FK_ModuleType_SPtl,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BICIRI_Incurred.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_TL,6,'BusinessPlanningRI Landing',  @FK_ModuleType_SPtl,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BusinessPlanLandingRI.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),
							    (@IFRS17_Orchestration_TL,7,'TDMBICIClaims Landing',  @FK_ModuleType_SPtl,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_TDMBICIClaimsToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_TL,8,'BICI_RIPaid Landing',  @FK_ModuleType_SPtl,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName =''IFRS17_BICIRI_Paid.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_TL,9,'BICI_RIEarned Landing',  @FK_ModuleType_SPtl,'SELECT 1',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_TL,10,'BICI_RI_Ultimate_Claim Landing',  @FK_ModuleType_SPtl,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BICIRI_Claim.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),
								--I1B-3622 (@IFRS17_Orchestration_TL,11,'SPA_ObligatedPremium',  @FK_ModuleType_SPtl,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_SPAObligatedPremium.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_TL,11,'ObligatedPremiumRISpendBESI Landing',  @FK_ModuleType_SPtl,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ObligatedPremiumRISpendBESI.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),

								(@IFRS17_Orchestration_TL,12,'ADM_RRDataLargeLosses',  @FK_ModuleType_SPtl,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''ADMReinsuranceReservingData_LargeLosses.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),
								-- I1B-3628 (@IFRS17_Orchestration_TL,13,'AEA_ExpensesActuals',  @FK_ModuleType_SPtl,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''AgressoExpensesActual.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_TL,13,'AEA_ExpensesActuals',  @FK_ModuleType_SPtl,'SELECT 1',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),

								--(@IFRS17_Orchestration_TL,14,'ObligatedPremium_Munich_QQS Landing',  @FK_ModuleType_SPtl,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ObligatedPremium_Munich_QQS.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),
								--https://beazley.atlassian.net/browse/I1B-3621
								(@IFRS17_Orchestration_TL,14,'RIOverridingCommission Landing',  @FK_ModuleType_SPtl,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_RISpendBESI_ORCFileTolanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),

								(@IFRS17_Orchestration_TL,15,'ResDataRIAttClmAlloc Landing',  @FK_ModuleType_SPtl,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADMResDataUltimateClaims.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),
							
								--Level2
								(@IFRS17_Orchestration_TL,90,'ResDataPremiumAlloc Landing',  @FK_ModuleType_SPtl,'select 1',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_TL,91,'SyndicateSplit Landing',@FK_ModuleType_SPtl,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''SyndicateSplit.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),
							    (@IFRS17_Orchestration_TL,92,'Eurobase Landing',  @FK_ModuleType_SPtl,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''EurobaseTacticalLoad.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_TL,93,'BICI ORC TACTICAL Landing',  @FK_ModuleType_SPtl,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BICI_Orc_Tactical.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_TL,94,'ORC MUNQQS Tactical Landing',  @FK_ModuleType_SPtl,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_SPA_MUNQQS_ORC_Tactical.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_tl,'SchedulingHub',NULL,NULL),

								--Level 3
								(@IFRS17_Orchestration_TL,16,'BuinsessPlan LandingToInbound',@FK_ModuleType_SPtl,'EXEC [BP].[usp_LandingInboundWorkflow_BusinessPlan]'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),		
								--Level 4
								(@IFRS17_Orchestration_TL,17,'BICI_RI_Ultimate_Premium LandingToInbound',@FK_ModuleType_SPtl,'EXEC [BICIRI].[usp_LandingInboundWorkflow_BICI_RI_Ultimate_Premium]'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),
								--Level 5
								(@IFRS17_Orchestration_TL,18,'ResDataEventAlloc LandingToInbound',@FK_ModuleType_SPtl,'EXEC [ADM].[usp_LandingInboundWorkflow_ResDataEventAlloc]'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),
								--Level 6
								(@IFRS17_Orchestration_TL,19,'UltimateRIPsEventAlloc LandingToInbound',@FK_ModuleType_SPtl,'EXEC [Ultrea].[usp_LandingInboundWorkflow_RIPsEventAlloc]'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),
								--Level 7---I1B-3624
								--(@IFRS17_Orchestration_TL,20,'BICI_RIIncurred LandingToInbound',@FK_ModuleType_SPtl,'EXEC [BICIRI].[usp_LandingInboundWorkflow_BICI_RI_Incurred]'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_TL,20,'BICI_RIIncurred LandingToInboundToOutbound',@FK_ModuleType_SPtl,'EXEC [Agresso].[usp_LandingToInboundToOutboundWorkflow_BICIRI_Incurred]'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),
								--Level 8
								(@IFRS17_Orchestration_TL,21,'BuinsessPlanRI LandingToInbound',@FK_ModuleType_SPtl,'EXEC [BP].[usp_LandingInboundWorkflow_BusinessPlanRI]'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),
								--Level 9
								(@IFRS17_Orchestration_TL,22,'TDMBICIClaims LandingToInbound',@FK_ModuleType_SPtl,'EXEC [TDM].[usp_LandingInboundWorkflow_BICIClaims]'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),
								--Level 10--4108
								--(@IFRS17_Orchestration_TL,23,'BICI_RIPaid LandingToInbound',@FK_ModuleType_SPtl,'EXEC  [BICIRI].[usp_LandingInboundWorkflow_BICI_RI_Paid]'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_TL,23,'BICI_RIPaid LandingToInboundToOutbound',@FK_ModuleType_SPtl,'EXEC  [Agresso].[usp_LandingToInboundToOutboundWorkflow_BICIRI_Paid]'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),

								--Level 11
							    (@IFRS17_Orchestration_TL,24,'BICI_RIEarned LandingToInbound',@FK_ModuleType_SPtl,'SELECT 1'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),
								--Level 12
								(@IFRS17_Orchestration_TL,25,'BICI_RI_Ultimate_Claim LandingToInbound',@FK_ModuleType_SPtl,'EXEC [BICIRI].[usp_LandingInboundWorkflow_BICI_RI_Ultimate_Claim]'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),
								--Level 13 
								--I1B-3622 (@IFRS17_Orchestration_TL,26,'SPA_ObligatedPremium LandingToInbound',@FK_ModuleType_SPtl,'EXEC [SPA].[usp_LandingInboundWorkflow_ObligatedPremium_SPA]'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_TL,26,'SPA_ObligatedPremium LandingToInbound',@FK_ModuleType_SPtl,'Select 1'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),

								--Level 14
								(@IFRS17_Orchestration_TL,27,'ADM_RRDataLargeloses LandingToInbound',@FK_ModuleType_SPtl,'EXEC [ADM].[usp_LandingInboundWorkflow_ReinsuranceReservingDataLargeLosses_ADM]'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),
								--Level 15
								--I1b-3628 (@IFRS17_Orchestration_TL,28,'AEA_ExpensesActual LandingToInbound',@FK_ModuleType_SPtl,'EXEC [Agresso].[usp_LandingInboundWorkflow_AgressoExpensesActual]'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_TL,28,'AEA_ExpensesActual LandingToInbound',@FK_ModuleType_SPtl,'SELECT 1'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),
								--Level 16
								--(@IFRS17_Orchestration_TL,29,'ObligatedPremiumnMunich_QQS LandingToInbound',@FK_ModuleType_SPtl,'EXEC  [OP].[usp_LandingInboundWorkflow_ObligatedPremium_Munich_QQS]'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),
								--https://beazley.atlassian.net/browse/I1B-3621
								(@IFRS17_Orchestration_TL,29,'Dummy Load',@FK_ModuleType_SPtl,'Select 1'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),
								
								--Level 17
								(@IFRS17_Orchestration_TL,30,'ResDataRIAttClmAlloc LandingToInbound',@FK_ModuleType_SPtl,'EXEC [ADM].[usp_LandingInboundWorkflow_ResDataRIAttClaims]'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),
								
								--Level 18
								(@IFRS17_Orchestration_TL,116,'ResDataPremiumAlloc LandingToInbound',@FK_ModuleType_SPtl,'select 1',@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),
								--Level 19
								(@IFRS17_Orchestration_TL,117,'EurobaseEPIReInstatement LandingToInboundToOutbound',@FK_ModuleType_SPtl,'SELECT 1',@IFRS17_InstanceName_tl, 'SchedulingHub', NULL, NULL),
								--Level 20
								(@IFRS17_Orchestration_TL,118,'Eurobase LandingToInbound',@FK_ModuleType_SPtl,'EXEC [Eb].[usp_LandingInboundWorkflow_EurobaseTacticalLoad]',@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),
								
								--Level 21
								(@IFRS17_Orchestration_TL,119,'BICI ORC TACTICAL LandingToInboundToOutbound',@FK_ModuleType_SPtl,'EXEC [Agresso].[usp_LandingToInboundToOutboundWorkflow_BICIRI_Orc_Tactical]'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),								

								--Level 22
								--(@IFRS17_Orchestration_TL,120,'SPA MUNQQS ORC TACTICAL Landing To Inbound',@FK_ModuleType_SPtl,'EXEC [SPA].[usp_LandingInboundWorkflow_SPA_MUNQQS_ORC_TACTICAL]'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_TL,120,'Dummy Load',@FK_ModuleType_SPtl,'select 1'	,@IFRS17_InstanceName_tl, 'FinanceLanding', NULL, NULL),								
								--Level 23
								(@IFRS17_Orchestration_TL,31,'Inbound To OutBound for Tactical Loads',@FK_ModuleType_SPtl,'EXEC [TL].[usp_InboundOutBoundWorkflow_TacticalLoads]'	,@IFRS17_InstanceName_tl, 'Financedatacontract', NULL, NULL),								

							
								-- level 24
								(@IFRS17_Orchestration_TL,46,'DimTrifocus', @FK_ModuleType_SPtl,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTrifocus.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,	 NULL),
								(@IFRS17_Orchestration_TL,47,'DimEntity',@FK_ModuleType_SPtl,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimEntity.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_TL,48,'DimYOA',@FK_ModuleType_SPtl,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimYOA.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_TL,49,'DimCCY',@FK_ModuleType_SPtl,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimCCY.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL), 
								(@IFRS17_Orchestration_TL,50,'DimProduct',@FK_ModuleType_SPtl,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimProduct.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_TL,51,'DimLocation',@FK_ModuleType_SPtl,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimLocation.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								--(@IFRS17_Orchestration_TL,52,'DimPolicy',@FK_ModuleType_SPtl,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPolicy.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_TL,52,'Dummy Load',@FK_ModuleType_SPtl,			'SELECT 1'	,@IFRS17_InstanceName_tl, 'FinanceDataContract', NULL, NULL),
								(@IFRS17_Orchestration_TL,53,'DimAccount',@FK_ModuleType_SPtl,			'SELECT 1'	,@IFRS17_InstanceName_tl, 'TechnicalHub', NULL, NULL),
								(@IFRS17_Orchestration_TL,54,'DimDataset',@FK_ModuleType_SPtl,			'EXEC  [Dim].[MergeDatasetBR1]','$(InstanceName)', 'TechnicalHub', NULL, NULL),
								(@IFRS17_Orchestration_TL,55,'DimPatternName',@FK_ModuleType_SPtl,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPatternName.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_TL,56,'DimCatCode',@FK_ModuleType_SPtl,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimCatCode.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_TL,57,'DimMovementType',@FK_ModuleType_SPtl,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimMovementType.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_TL,58,'DimAccountDtsx', @FK_ModuleType_SPtl,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimAccount.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,	 NULL),
								(@IFRS17_Orchestration_TL,59,'DimClaimExposure', @FK_ModuleType_SPtl,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimClaimExposure.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,	 NULL),
								(@IFRS17_Orchestration_TL,60,'DimPolicySection', @FK_ModuleType_SPtl,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPolicySection.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,	 NULL),

								--Level 25
								(@IFRS17_Orchestration_TL,61,'DimTrackingStatus',@FK_ModuleType_SPtl,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTrackingStatus.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_TL,62,'DimRIPolicyType',@FK_ModuleType_SPtl,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimRIPolicyType.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_TL,63,'DimProgrammeCode',@FK_ModuleType_SPtl,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimProgrammeCode.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_TL,64,'DimTriangleGroup',@FK_ModuleType_SPtl,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTriangleGroup.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_TL,65,'DimReservingDataSet',@FK_ModuleType_SPtl,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimReservingDataset.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),

								--Level 26
								(@IFRS17_Orchestration_TL,76,'IFRS2017TechResult',@FK_ModuleType_SPtl,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactTechnicalResult_IFRS2017.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

								--Level 27
								(@IFRS17_Orchestration_TL,80,'Tech Fact',@FK_ModuleType_SPtl,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactTechnicalResult.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

								--Level 28
								(@IFRS17_Orchestration_TL,85,'SideCar',@FK_ModuleType_SPtl,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactSideCar.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL)

								
								
					)
						AS Source(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.PK_Module = Source.PK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
					VALUES(Source.FK_Orchestration,  Source.PK_module,  Source.ModuleName,  Source.FK_ModuleType,  Source.ModuleRoutine,  Source.DestinationServer,  Source.DestinationDatabase,Source.FK_Schedule,Source.FK_Notification)
			WHEN	MATCHED
			THEN	UPDATE SET		FK_Orchestration	= source.FK_Orchestration, 
									PK_module 			= source.PK_module, 
									ModuleName 			= source.ModuleName, 
									FK_ModuleType 		= source.FK_ModuleType, 
									ModuleRoutine 		= source.ModuleRoutine, 
									DestinationServer	= source.DestinationServer, 
									DestinationDatabase	= source.DestinationDatabase, 
									FK_Schedule 		= source.FK_Schedule, 
									FK_Notification		= source.FK_Notification
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_TL
			THEN	DELETE;




			--ModuleHierarchy select * from etl.ModuleHierarchy
			MERGE 
			INTO	etl.ModuleHierarchy AS Target
			USING	(
						VALUES	--L1

								(@IFRS17_Orchestration_TL,	NULL,	1,	1), -- BusinessPlan to Landing
								(@IFRS17_Orchestration_TL,	NULL,	2,	1), --BICI_RI_Ultimate_Premium to Landing
								(@IFRS17_Orchestration_TL,	NULL,	3,	1), --ResDataEventAlloc to Landing
								(@IFRS17_Orchestration_TL,	NULL,	4,	1), --RipsEventAlloc to Landing
								(@IFRS17_Orchestration_TL,	NULL,	5,	1), --BICI_RIIncurred to Landing
								(@IFRS17_Orchestration_TL,	NULL,	6,	1), -- BusinessPlanRI to Landing
								(@IFRS17_Orchestration_TL,	NULL,	7,	1), -- TDMBICIClaims to Landing
								(@IFRS17_Orchestration_TL,	NULL,	8,	1), -- BICI_RIPaid  to Landing
								(@IFRS17_Orchestration_TL,	NULL,	9,	1), -- BICI_RIEarned to Landing
								(@IFRS17_Orchestration_TL,	NULL,	10,	1), --BICI_RI_Ultimate_Claim to Landing
								(@IFRS17_Orchestration_TL,	NULL,	11,	1), --SPA_ObligatedPremium to Landing
								(@IFRS17_Orchestration_TL,	NULL,	12,	1), --ADM_RRDataLargeloses to Landing
								(@IFRS17_Orchestration_TL,	NULL,	13,	1), --AEA_ExpensesActual to Landing
								(@IFRS17_Orchestration_TL,	NULL,	14,	1), --ObligatedPremiumandMunichQQS to Landing
								(@IFRS17_Orchestration_TL,	NULL,	15,	1), --ADMResDataUltClaims to Landing

								--L2
								(@IFRS17_Orchestration_TL,	1,	90,	2), 
								(@IFRS17_Orchestration_TL,	2,	90,	2),
								(@IFRS17_Orchestration_TL,	3,	90,	2), 
								(@IFRS17_Orchestration_TL,	4,	90,	2),
								(@IFRS17_Orchestration_TL,	5,	90,	2), 
								(@IFRS17_Orchestration_TL,	6,	90,	2), 
								(@IFRS17_Orchestration_TL,	7,	90,	2), 
								(@IFRS17_Orchestration_TL,	8,	90,	2), 
								(@IFRS17_Orchestration_TL,	9,	90,	2),
								(@IFRS17_Orchestration_TL,	10,	90,	2), 
								(@IFRS17_Orchestration_TL,	11,	90,	2), 
								(@IFRS17_Orchestration_TL,	12,	90,	2), 
								(@IFRS17_Orchestration_TL,	13,	90,	2), 
								(@IFRS17_Orchestration_TL,	14,	90,	2), 
								(@IFRS17_Orchestration_TL,	15,	90,	2), 

								(@IFRS17_Orchestration_TL,	1,	91,	2), 
								(@IFRS17_Orchestration_TL,	2,	91,	2),
								(@IFRS17_Orchestration_TL,	3,	91,	2), 
								(@IFRS17_Orchestration_TL,	4,	91,	2),
								(@IFRS17_Orchestration_TL,	5,	91,	2), 
								(@IFRS17_Orchestration_TL,	6,	91,	2), 
								(@IFRS17_Orchestration_TL,	7,	91,	2), 
								(@IFRS17_Orchestration_TL,	8,	91,	2), 
								(@IFRS17_Orchestration_TL,	9,	91,	2),
								(@IFRS17_Orchestration_TL,	10,	91,	2), 
								(@IFRS17_Orchestration_TL,	11,	91,	2), 
								(@IFRS17_Orchestration_TL,	12,	91,	2), 
								(@IFRS17_Orchestration_TL,	13,	91,	2), 
								(@IFRS17_Orchestration_TL,	14,	91,	2), 
								(@IFRS17_Orchestration_TL,	15,	91,	2), 

								(@IFRS17_Orchestration_TL,	1,	92,	2), 
								(@IFRS17_Orchestration_TL,	2,	92,	2),
								(@IFRS17_Orchestration_TL,	3,	92,	2), 
								(@IFRS17_Orchestration_TL,	4,	92,	2),
								(@IFRS17_Orchestration_TL,	5,	92,	2), 
								(@IFRS17_Orchestration_TL,	6,	92,	2), 
								(@IFRS17_Orchestration_TL,	7,	92,	2), 
								(@IFRS17_Orchestration_TL,	8,	92,	2), 
								(@IFRS17_Orchestration_TL,	9,	92,	2),
								(@IFRS17_Orchestration_TL,	10,	92,	2), 
								(@IFRS17_Orchestration_TL,	11,	92,	2), 
								(@IFRS17_Orchestration_TL,	12,	92,	2), 
								(@IFRS17_Orchestration_TL,	13,	92,	2), 
								(@IFRS17_Orchestration_TL,	14,	92,	2), 
								(@IFRS17_Orchestration_TL,	15,	92,	2), 

								(@IFRS17_Orchestration_TL,	1,	93,	2), 
								(@IFRS17_Orchestration_TL,	2,	93,	2),
								(@IFRS17_Orchestration_TL,	3,	93,	2), 
								(@IFRS17_Orchestration_TL,	4,	93,	2),
								(@IFRS17_Orchestration_TL,	5,	93,	2), 
								(@IFRS17_Orchestration_TL,	6,	93,	2), 
								(@IFRS17_Orchestration_TL,	7,	93,	2), 
								(@IFRS17_Orchestration_TL,	8,	93,	2), 
								(@IFRS17_Orchestration_TL,	9,	93,	2),
								(@IFRS17_Orchestration_TL,	10,	93,	2), 
								(@IFRS17_Orchestration_TL,	11,	93,	2), 
								(@IFRS17_Orchestration_TL,	12,	93,	2), 
								(@IFRS17_Orchestration_TL,	13,	93,	2), 
								(@IFRS17_Orchestration_TL,	14,	93,	2), 
								(@IFRS17_Orchestration_TL,	15,	93,	2), 

								(@IFRS17_Orchestration_TL,	1,	94,	2), 
								(@IFRS17_Orchestration_TL,	2,	94,	2),
								(@IFRS17_Orchestration_TL,	3,	94,	2), 
								(@IFRS17_Orchestration_TL,	4,	94,	2),
								(@IFRS17_Orchestration_TL,	5,	94,	2), 
								(@IFRS17_Orchestration_TL,	6,	94,	2), 
								(@IFRS17_Orchestration_TL,	7,	94,	2), 
								(@IFRS17_Orchestration_TL,	8,	94,	2), 
								(@IFRS17_Orchestration_TL,	9,	94,	2),
								(@IFRS17_Orchestration_TL,	10,	94,	2), 
								(@IFRS17_Orchestration_TL,	11,	94,	2), 
								(@IFRS17_Orchestration_TL,	12,	94,	2), 
								(@IFRS17_Orchestration_TL,	13,	94,	2), 
								(@IFRS17_Orchestration_TL,	14,	94,	2), 
								(@IFRS17_Orchestration_TL,	15,	94,	2), 

								
								--L3

								(@IFRS17_Orchestration_TL,	90,	16,	3), -- Business Plan Land To Inbound 1
								(@IFRS17_Orchestration_TL,	91,	16,	3), -- Business Plan Land To Inbound 1
								(@IFRS17_Orchestration_TL,	92,	16,	3), -- Business Plan Land To Inbound 1

								--L4

								(@IFRS17_Orchestration_TL,	16,	17,	4), -- BICI_RI_Ultimate_Premium Land To Inbound 1

								--L5

								(@IFRS17_Orchestration_TL,	17,	18,	5), --ResDataEventAlloc Land To Inbound 1

								--L6

								(@IFRS17_Orchestration_TL,	18,	19,	6), --RipsEventAlloc Land To Inbound 1

								--L7

								(@IFRS17_Orchestration_TL,	19,	20,	7), --BICI_RIIncurred Land To Inbound 1

								--L8

								(@IFRS17_Orchestration_TL,	20,	21,	8), -- Business Plan RI Land To Inbound 1

								--L9

								(@IFRS17_Orchestration_TL,	21,	22,	9), --TDMBICIClaims Land To Inbound 1

								--L10

								(@IFRS17_Orchestration_TL,	22,	23,	10), --BICI_RIPaid Land To Inbound 1

								--L11

								(@IFRS17_Orchestration_TL,	23,	24,	11), --BICI_RIEarned Land To Inbound 1

								--L12

								(@IFRS17_Orchestration_TL,	24,	25,	12), -- BICI_RI_Ultimate_Claim Land To Inbound 1

								--L13

								(@IFRS17_Orchestration_TL,	25,	26,	13), -- SAP_ultimatePremium Land To Inbound 1

								--L14

								(@IFRS17_Orchestration_TL,	26,	27,	14), -- ADM_RRDataLargeloses Land To Inbound 1

								--L15

								(@IFRS17_Orchestration_TL,	27,	28,	15), -- AEA_ExpensesActual Land To Inbound 1

								--L16

								(@IFRS17_Orchestration_TL,	28,	29,	16), -- ObligatedPremiummucih Land To Inbound 1

								--L17

								(@IFRS17_Orchestration_TL,	29,	30,	17), -- ResDataRIAttClmAlloc Land To Inbound 1


								
								--L18 

								(@IFRS17_Orchestration_TL,	30,	116, 18),--ResDataPremiumAlloc Land To Inbound 1


							    --L19 

								(@IFRS17_Orchestration_TL,	116, 117, 19),--EurobaseEPIReInstatement Land To Inbound 1


                                --L20 

								(@IFRS17_Orchestration_TL,	117, 118, 20),--Eurobase Land To Inbound 1

								--L21 

								(@IFRS17_Orchestration_TL,	118, 119, 21),--BICI_Orc_Tactical Land To Inbound 1
								(@IFRS17_Orchestration_TL,	93, 119, 21),--BICI_Orc_Tactical InboundToOutBound depends on Biciri orc 

								--L22 

								(@IFRS17_Orchestration_TL,	119, 120, 22),--BICI_Orc_Tactical Land To Inbound 1

								--L23

								(@IFRS17_Orchestration_TL,	120, 31, 23),--Inbound To OutBound for Tactical Loads

								--L24 -- DIMS
								(@IFRS17_Orchestration_TL,	31,	46,		24), 
								(@IFRS17_Orchestration_TL,	31,	47,		24),
								(@IFRS17_Orchestration_TL,	31,	48,		24),
								(@IFRS17_Orchestration_TL,	31,	49,		24), 
								(@IFRS17_Orchestration_TL,	31,	50,		24),
								(@IFRS17_Orchestration_TL,	31,	51,		24),
								(@IFRS17_Orchestration_TL,	31,	52,		24), 
								(@IFRS17_Orchestration_TL,	31,	53,		24),
								(@IFRS17_Orchestration_TL,	31,	54,		24),
								(@IFRS17_Orchestration_TL,	31,	55,		24), 
								(@IFRS17_Orchestration_TL,	31,	56,		24),
								(@IFRS17_Orchestration_TL,	31,	57,		24),
								(@IFRS17_Orchestration_TL,	31,	58,		24), 
								(@IFRS17_Orchestration_TL,	31,	59,		24),
								(@IFRS17_Orchestration_TL,	31,	60,		24),

								--L25
							   (@IFRS17_Orchestration_TL,	46, 61,    25), 
								(@IFRS17_Orchestration_TL,	47, 61,    25),
								(@IFRS17_Orchestration_TL,	48, 61,    25),
								(@IFRS17_Orchestration_TL,	49, 61,    25), 
								(@IFRS17_Orchestration_TL,	50, 61,    25),
								(@IFRS17_Orchestration_TL,	51, 61,    25),
								(@IFRS17_Orchestration_TL,	52, 61,    25), 
								(@IFRS17_Orchestration_TL,	53, 61,    25),
								(@IFRS17_Orchestration_TL,	54, 61,    25),
								(@IFRS17_Orchestration_TL,	55, 61,    25), 
								(@IFRS17_Orchestration_TL,	56, 61,    25),
								(@IFRS17_Orchestration_TL,	57, 61,    25),
								(@IFRS17_Orchestration_TL,	58, 61,    25), 
								(@IFRS17_Orchestration_TL,	59, 61,    25),
								(@IFRS17_Orchestration_TL,	60, 61,    25),

								(@IFRS17_Orchestration_TL,	46, 62,    25), 
								(@IFRS17_Orchestration_TL,	47, 62,    25),
								(@IFRS17_Orchestration_TL,	48, 62,    25),
								(@IFRS17_Orchestration_TL,	49, 62,    25), 
								(@IFRS17_Orchestration_TL,	50, 62,    25),
								(@IFRS17_Orchestration_TL,	51, 62,    25),
								(@IFRS17_Orchestration_TL,	52, 62,    25), 
								(@IFRS17_Orchestration_TL,	53, 62,    25),
								(@IFRS17_Orchestration_TL,	54, 62,    25),
								(@IFRS17_Orchestration_TL,	55, 62,    25), 
								(@IFRS17_Orchestration_TL,	56, 62,    25),
								(@IFRS17_Orchestration_TL,	57, 62,    25),
								(@IFRS17_Orchestration_TL,	58, 62,    25), 
								(@IFRS17_Orchestration_TL,	59, 62,    25),
								(@IFRS17_Orchestration_TL,	60, 62,    25),
																	   
								(@IFRS17_Orchestration_TL,	46, 63,    25), 
								(@IFRS17_Orchestration_TL,	47, 63,    25),
								(@IFRS17_Orchestration_TL,	48, 63,    25),
								(@IFRS17_Orchestration_TL,	49, 63,    25), 
								(@IFRS17_Orchestration_TL,	50, 63,    25),
								(@IFRS17_Orchestration_TL,	51, 63,    25),
								(@IFRS17_Orchestration_TL,	52, 63,    25), 
								(@IFRS17_Orchestration_TL,	53, 63,    25),
								(@IFRS17_Orchestration_TL,	54, 63,    25),
								(@IFRS17_Orchestration_TL,	55, 63,    25), 
								(@IFRS17_Orchestration_TL,	56, 63,    25),
								(@IFRS17_Orchestration_TL,	57, 63,    25),
								(@IFRS17_Orchestration_TL,	58, 63,    25), 
								(@IFRS17_Orchestration_TL,	59, 63,    25),
								(@IFRS17_Orchestration_TL,	60, 63,    25),
																	   
								(@IFRS17_Orchestration_TL,	46, 64,    25), 
								(@IFRS17_Orchestration_TL,	47, 64,    25),
								(@IFRS17_Orchestration_TL,	48, 64,    25),
								(@IFRS17_Orchestration_TL,	49, 64,    25), 
								(@IFRS17_Orchestration_TL,	50, 64,    25),
								(@IFRS17_Orchestration_TL,	51, 64,    25),
								(@IFRS17_Orchestration_TL,	52, 64,    25), 
								(@IFRS17_Orchestration_TL,	53, 64,    25),
								(@IFRS17_Orchestration_TL,	54, 64,    25),
								(@IFRS17_Orchestration_TL,	55, 64,    25), 
								(@IFRS17_Orchestration_TL,	56, 64,    25),
								(@IFRS17_Orchestration_TL,	57, 64,    25),
								(@IFRS17_Orchestration_TL,	58, 64,    25), 
								(@IFRS17_Orchestration_TL,	59, 64,    25),
								(@IFRS17_Orchestration_TL,	60, 64,    25),
																	   
								(@IFRS17_Orchestration_TL,	46, 65,    25), 
								(@IFRS17_Orchestration_TL,	47, 65,    25),
								(@IFRS17_Orchestration_TL,	48, 65,    25),
								(@IFRS17_Orchestration_TL,	49, 65,    25), 
								(@IFRS17_Orchestration_TL,	50, 65,    25),
								(@IFRS17_Orchestration_TL,	51, 65,    25),
								(@IFRS17_Orchestration_TL,	52, 65,    25), 
								(@IFRS17_Orchestration_TL,	53, 65,    25),
								(@IFRS17_Orchestration_TL,	54, 65,    25),
								(@IFRS17_Orchestration_TL,	55, 65,    25), 
								(@IFRS17_Orchestration_TL,	56, 65,    25),
								(@IFRS17_Orchestration_TL,	57, 65,    25),
								(@IFRS17_Orchestration_TL,	58, 65,    25), 
								(@IFRS17_Orchestration_TL,	59, 65,    25),
								(@IFRS17_Orchestration_TL,	60, 65,    25),

								--L26

								(@IFRS17_Orchestration_TL,	61,	76,		26),
								(@IFRS17_Orchestration_TL,	62,	76,		26),
								(@IFRS17_Orchestration_TL,	63,	76,		26), 
								(@IFRS17_Orchestration_TL,	64,	76,		26),
								(@IFRS17_Orchestration_TL,	65,	76,		26),

								--L27
								(@IFRS17_Orchestration_TL,	76,	80,		27),

								--L27
								(@IFRS17_Orchestration_TL,	80,	85,		28)
								

-- SSIS packages
--IFRS17_ADMToLandingExtract.dtsx -- > [ADM].[usp_LandingToInbound] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow
--								  -- > [ADM].[usp_LandingToInbound_Pattern] --> FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_Pattern			

--IFRS17_AgressoToLandingExtract.dtsx -- on hold

--IFRS17_BICCToLandingExtract.dtsx -- > [BICC].[usp_LandingToInbound] -- > assume FinanceDataContract.Inbound.usp_InboundOutboundWorkflow but unit test has changed or not there. Ciprian will update me.
--IFRS17_EIOPAToLandingExtract.dtsx -- > [XLS].[usp_EIOPALandingToInbound_DiscountRates] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_DiscountRates
--IFRS17_EurobaseToLandingExtract.dtsx -- > [Eurobase].[usp_LandingToInbound_EPI] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow
--										-- > [Eurobase].[usp_LandingToInbound] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow

-- needs to be added
--IFRS17_LossRatioToLandingExtract.dtsx -- > [XLS].[usp_LandingToInbound_LossRatio] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_LossRatio

--IFRS17_MDSToLandingExtract.dtsx -- > [MDS].[usp_LandingToInbound] -- > no outbound required

--check this!
--IFRS17_NatCatEarningToLandingExtract.dtsx -- > [XLS].[usp_NatCatEarningLandingToInbound_Pattern] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_Pattern


					) AS Source(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.FK_ChildModule = Source.FK_ChildModule
				AND Target.FK_ParentModule = Source.FK_ParentModule
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
					VALUES(Source.FK_Orchestration,Source.FK_ParentModule,Source.FK_ChildModule,Source.TreeLevel)
			WHEN	MATCHED
			THEN	UPDATE SET	FK_Orchestration = source.FK_Orchestration, 
								FK_ParentModule = source.FK_ParentModule, 
								FK_ChildModule = source.FK_ChildModule, 
								TreeLevel = source.TreeLevel
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_TL
			THEN	DELETE;






			--ModuleActivity select * from etl.ModuleActivity
			MERGE	etl.ModuleActivity Target
			USING	(
						SELECT	m.FK_Orchestration,
								m.PK_Module,
								1, -- Pending
								'Initialization from deployment' -- run description
						FROM	etl.Module m
						WHERE	m.FK_Orchestration = @IFRS17_Orchestration_TL
					) Source (FK_Orchestration, FK_Module, FK_ModuleStatus,RunDescription)
			ON		Source.FK_Orchestration = Target.FK_Orchestration
				AND	Source.FK_Module = Target.FK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT	(FK_Orchestration, FK_Module, FK_ModuleStatus, RunDescription)
					VALUES	(Source.FK_Orchestration, Source.FK_Module, Source.FK_ModuleStatus, Source.RunDescription)
			WHEN	MATCHED
			THEN	UPDATE	SET	Target.FK_ModuleStatus = Source.FK_ModuleStatus, Target.RunDescription = Source.RunDescription
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_TL
			THEN	DELETE;


