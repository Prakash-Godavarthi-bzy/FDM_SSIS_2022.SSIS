/*MERGE
INTO etl.Orchestration AS Target
USING (VALUES(18, 'BR2_IFRS17_ForecastPreProcessing',0)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled)
ON (Target.PK_Orchestration = Source.PK_Orchestration)
WHEN NOT MATCHED BY TARGET
THEN INSERT(PK_Orchestration,OrchestrationName,IsEnabled)
VALUES(Source.PK_Orchestration, Source.OrchestrationName, Source.IsEnabled)
WHEN MATCHED
THEN UPDATE SET Target.ORchestrationName = Source.OrchestrationName,
Target.IsEnabled = Source.Isenabled;




MERGE
INTO etl.Module AS Target
USING (
VALUES

--Level 1( FK_Orchestration,PK_module,ModuleName,FK_ModuleType,ModuleRoutine,DestinationServer,DestinationDatabase,FK_Notification,DefaultResetStatus)

(18,1,'LoadingForecastData',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''LoadingForecastData.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub', NULL, NULL),

--Level 2 ( FK_Orchestration,PK_module,ModuleName,FK_ModuleType,ModuleRoutine,DestinationServer,DestinationDatabase,FK_Notification,DefaultResetStatus)

(18,2,'PSicle_API_call',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''Psicle_Api_Call.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

--level 3 ( FK_Orchestration,PK_module,ModuleName,FK_ModuleType,ModuleRoutine,DestinationServer,DestinationDatabase,FK_Notification,DefaultResetStatus)

(18,3,'Merge_StgAggregatePremiumLTD',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''Merge_StgAggregatePremiumLTD.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

--Level 4 ( FK_Orchestration,PK_module,ModuleName,FK_ModuleType,ModuleRoutine,DestinationServer,DestinationDatabase,FK_Notification,DefaultResetStatus)

(18,4,'Merge_Staging',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''Merge_Staging.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

--Level 5 ( FK_Orchestration,PK_module,ModuleName,FK_ModuleType,ModuleRoutine,DestinationServer,DestinationDatabase,FK_Notification,DefaultResetStatus) 

(18,5,'Aggr_Premium_LTDData',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''Aggr_Premium_LTDData.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

--Level 6 ( FK_Orchestration,PK_module,ModuleName,FK_ModuleType,ModuleRoutine,DestinationServer,DestinationDatabase,FK_Notification,DefaultResetStatus) 

(18,6,'Aggr_NonPremium_LTDDataPBF',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''Aggr_NonPremium_LTDDataPBF.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

--Level 7 ( FK_Orchestration,PK_module,ModuleName,FK_ModuleType,ModuleRoutine,DestinationServer,DestinationDatabase,FK_Notification,DefaultResetStatus) 

(18,7,'Merge_StagingOpenClosYOA',1, 'EXEC [sch].[USP_ExecutePackage] @Parameters =null,@PackageName = ''Merge_StagingOpenClosYOA.dtsx'', @PackageLocation = ''IFRS17DataMart'',@Projectname = ''IFRS17DataMart.SSIS'', @EnvironmentName = ''IFRS17DataMartEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL)





)

AS Source(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
ON Target.FK_Orchestration = Source.FK_Orchestration
AND Target.PK_Module = Source.PK_Module
WHEN NOT MATCHED BY TARGET
THEN INSERT(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
VALUES(Source.FK_Orchestration, Source.PK_module, Source.ModuleName, Source.FK_ModuleType, Source.ModuleRoutine, Source.DestinationServer, Source.DestinationDatabase,Source.FK_Schedule,Source.FK_Notification)
WHEN MATCHED
THEN UPDATE SET FK_Orchestration = source.FK_Orchestration,
PK_module = source.PK_module,
ModuleName = source.ModuleName,
FK_ModuleType = source.FK_ModuleType,
ModuleRoutine = source.ModuleRoutine,
DestinationServer = source.DestinationServer,
DestinationDatabase = source.DestinationDatabase,
FK_Schedule = source.FK_Schedule,
FK_Notification = source.FK_Notification
WHEN NOT MATCHED BY SOURCE AND target.fk_Orchestration = 18
THEN DELETE;





MERGE
INTO etl.ModuleHierarchy AS Target
USING (
VALUES

--L1 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
(18, NULL, 1, 1),

--L2 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
(18, 1, 2, 2),

--L3 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
(18, 2, 3, 3),

--L4 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
(18, 3, 4, 4),

--L5 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
(18, 4, 5, 5),

--L6 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
(18, 5, 6, 6),

--L7 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
(18, 6, 7, 7)


) AS Source(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
ON Target.FK_Orchestration = Source.FK_Orchestration
AND Target.FK_ChildModule = Source.FK_ChildModule
AND Target.FK_ParentModule = Source.FK_ParentModule
WHEN NOT MATCHED BY TARGET
THEN INSERT(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
VALUES(Source.FK_Orchestration,Source.FK_ParentModule,Source.FK_ChildModule,Source.TreeLevel)
WHEN MATCHED
THEN UPDATE SET FK_Orchestration = source.FK_Orchestration,
FK_ParentModule = source.FK_ParentModule,
FK_ChildModule = source.FK_ChildModule,
TreeLevel = source.TreeLevel
WHEN NOT MATCHED BY SOURCE AND target.fk_Orchestration = 18
THEN DELETE;





MERGE etl.ModuleActivity Target
USING (
SELECT m.FK_Orchestration,
m.PK_Module,
1
FROM etl.Module m
WHERE m.FK_Orchestration = 18
) Source (FK_Orchestration, FK_Module, FK_ModuleStatus)
ON Source.FK_Orchestration = Target.FK_Orchestration
AND Source.FK_Module = Target.FK_Module
WHEN NOT MATCHED BY TARGET
THEN INSERT (FK_Orchestration, FK_Module, FK_ModuleStatus)
VALUES (Source.FK_Orchestration, Source.FK_Module, Source.FK_ModuleStatus)
WHEN MATCHED
THEN UPDATE SET Target.FK_ModuleStatus = Source.FK_ModuleStatus
WHEN NOT MATCHED BY SOURCE AND target.fk_Orchestration = 18
THEN DELETE;
*/

