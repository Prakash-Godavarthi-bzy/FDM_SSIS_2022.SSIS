﻿
			MERGE 
			INTO	etl.Orchestration AS Target
			USING	(VALUES(7, 'FDMPostings',0)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled)
			ON		(Target.PK_Orchestration = Source.PK_Orchestration)
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(PK_Orchestration,OrchestrationName,IsEnabled)
					VALUES(Source.PK_Orchestration,  Source.OrchestrationName,  Source.IsEnabled)
			WHEN	MATCHED
			THEN	UPDATE SET	Target.ORchestrationName = Source.OrchestrationName,
								Target.IsEnabled = Source.Isenabled;

			MERGE 
			INTO	etl.Module AS Target
			USING	(
						VALUES	--Level 1
								(7,1,'Eurobase',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''EurobaseEPI.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								(7,2,'EB Trifocus', 1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FDMTrifocusCode.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(7,13,'US Premium',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''USPremium.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								(7,16,'PFT Forecast',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''PremiumForecastLanding.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								(7,20,'ADM',1,					'SELECT 1 --EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADMToLandingExtract.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								(7,21,'EIOPA',1,				'SELECT 1 --EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_EIOPAToLandingExtract.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExcelImport=1, @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								(7,26,'Fake Data',1,				    'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_FakeDataToLanding.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExcelImport=1, @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								--Level 2-7
								(7,3,'EB Landing', 1,			'EXEC [eb].[USP_LandingInboundWorkflow]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								(7,14,'US Landing', 1,			'EXEC [us].[usp_LandingInboundWorkflow]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								(7,17,'PFT Landing', 1,			'EXEC [pft].[usp_LandingInboundWorkflow]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								(7,22,'ADM Landing', 1,			'SELECT 1 --EXEC [ADM].[usp_LandingToInbound_Pattern] NULL,NULL','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								(7,23,'EIOPA Landing', 1,		'SELECT 1 --EXEC [XLS].[usp_EIOPALandingToInbound_Pattern] NULL,NULL','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								(7,27,'Fake Data Landing', 1,	'EXEC [FA].[usp_LandingInboundFakeDataWorkflow]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								--Level 7
								(7,4,'DataContract',1,			'EXEC [Inbound].[usp_InboundOutboundWorkflow]'	,'$(InstanceName)', 'FinanceDataContract', NULL, NULL),
								(7,24,'DataContract_Pattern',1, 'SELECT 1 --EXEC [Inbound].[usp_InboundOutboundWorkflow_Pattern] NULL, NULL'	,'$(InstanceName)', 'FinanceDataContract', NULL, NULL),
								--level 8
								(7,5,'DimTrifocus', 1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTrifocus.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,	 NULL),
								(7,6,'DimEntity',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimEntity.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(7,7,'DimYOA',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimYOA.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(7,8,'DimCCY',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimCCY.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL), 
								(7,9,'DimProduct',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimProduct.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(7,10,'DimLocation',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimLocation.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(7,11,'Dim Policy',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPolicy.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(7,28,'DimRateScenario',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimRateScenario.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(7,29,'DimReportingCurrency',1,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimReportingCurrency.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(7,40,'DimPolicySection',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPolicySection.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),

								--Level 9
								(7,12,'Tech Fact',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactTechnicalResult.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								--Level 10
								(7,15,'Earning',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactEarning.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								--Level 11
								(7,18,'SideCar',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactSideCar.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(7,30,'FXRate',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactFxRates.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								--Level 12
								(7,19,'THubToFDM Extraction',1,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''THubToFactFDMExternal.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID =null','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(7,25,'Cube Process',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''CubeBuild.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL)
					)

						AS Source(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.PK_Module = Source.PK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
					VALUES(Source.FK_Orchestration,  Source.PK_module,  Source.ModuleName,  Source.FK_ModuleType,  Source.ModuleRoutine,  Source.DestinationServer,  Source.DestinationDatabase,Source.FK_Schedule,Source.FK_Notification)
			WHEN	MATCHED
			THEN	UPDATE SET		FK_Orchestration	= source.FK_Orchestration, 
									PK_module 			= source.PK_module, 
									ModuleName 			= source.ModuleName, 
									FK_ModuleType 		= source.FK_ModuleType, 
									ModuleRoutine 		= source.ModuleRoutine, 
									DestinationServer	= source.DestinationServer, 
									DestinationDatabase	= source.DestinationDatabase, 
									FK_Schedule 		= source.FK_Schedule, 
									FK_Notification		= source.FK_Notification
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = 7
			THEN	DELETE;

			MERGE 
			INTO	etl.ModuleHierarchy AS Target
			USING	(
						VALUES	--L1
								(7,	NULL,	1,	1),
								(7,	NULL,	2,	1), 
								(7,	NULL,	13,	1),
								(7,	NULL,	16,	1),
								(7,	NULL,	20,	1),
								(7,	NULL,	21,	1),
								(7,	NULL,	26,	1),

								--L2
								(7,	1,	3,	2),
								(7,	2,	3,	2),
								(7,	13,	3,	2),
								(7,	16,	3,	2),
								(7,	20,	3,	2),
								(7,	21,	3,	2),
								(7,	26,	3,	2),

								--L3-7
								(7,	3,	14,	3),
								(7,	14,	17,	4),
								(7,	17,	22,	5),
								(7,	22,	23,	6),
								(7, 23, 27, 7),

								--L8
								(7,	27,	4,	8),
								(7,	27,	24,	8),

								--L9
								(7,	4,	5,	9),
								(7,	4,	6,	9),
								(7,	4,	7,	9),
								(7,	4,	8,	9),
								(7,	4,	9,	9),
								(7,	4,	10,	9),
								(7,	4,	11,	9),
								(7,	4,	28,	9),
								(7,	4,	29,	9),
								(7,	4,	40,	9),

								(7,	24,	5,	9),
								(7,	24,	6,	9),
								(7,	24,	7,	9),
								(7,	24,	8,	9),
								(7,	24,	9,	9),
								(7,	24,	10,	9),
								(7,	24,	11,	9),
								(7,	24,	28,	9),
								(7,	24,	29,	9),
								(7,	24,	40,	9),

								--L10
								(7,	5,	12,	10),
								(7,	6,	12,	10),
								(7,	7,	12,	10),
								(7,	8,	12,	10),
								(7,	9,	12,	10),
								(7,	10,	12,	10),
								(7,	11,	12,	10),
								(7,	28,	12,	10),
								(7,	29,	12,	10),
								(7,	40,	12,	10),

								--L11
								(7,	12,	15,	11 ),
								--L12
								(7,	15,	18,	12 ),
								(7, 15, 30, 12 ),
								--L13
								(7, 18, 19, 13 ),
								(7, 18, 25, 13 ),
								(7, 30, 19, 13 ),
								(7, 30, 25, 13 )
					) AS Source(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.FK_ChildModule = Source.FK_ChildModule
				AND Target.FK_ParentModule = Source.FK_ParentModule
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
					VALUES(Source.FK_Orchestration,Source.FK_ParentModule,Source.FK_ChildModule,Source.TreeLevel)
			WHEN	MATCHED
			THEN	UPDATE SET	FK_Orchestration = source.FK_Orchestration, 
								FK_ParentModule = source.FK_ParentModule, 
								FK_ChildModule = source.FK_ChildModule, 
								TreeLevel = source.TreeLevel
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = 7
			THEN	DELETE;


			MERGE	etl.ModuleActivity Target
			USING	(
						SELECT	m.FK_Orchestration,
								m.PK_Module,
								1
						FROM	etl.Module m
						WHERE	m.FK_Orchestration = 7
					) Source (FK_Orchestration, FK_Module, FK_ModuleStatus)
			ON		Source.FK_Orchestration = Target.FK_Orchestration
				AND	Source.FK_Module = Target.FK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT	(FK_Orchestration, FK_Module, FK_ModuleStatus)
					VALUES	(Source.FK_Orchestration, Source.FK_Module, Source.FK_ModuleStatus)
			WHEN	MATCHED
			THEN	UPDATE	SET	Target.FK_ModuleStatus = Source.FK_ModuleStatus
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = 7
			THEN	DELETE;


