﻿Delete from etl.ModuleHierarchy where FK_Orchestration=6
Delete from etl.ModuleActivity where FK_Orchestration=6
Delete From etl.Module where FK_Orchestration=6

			MERGE 
			INTO	etl.Orchestration AS Target
			USING	(VALUES(6, 'Base Load',0)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled)
			ON		(Target.PK_Orchestration = Source.PK_Orchestration)
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(PK_Orchestration,OrchestrationName,IsEnabled)
					VALUES(Source.PK_Orchestration,  Source.OrchestrationName,  Source.IsEnabled)
			WHEN	MATCHED
			THEN	UPDATE SET	Target.ORchestrationName = Source.OrchestrationName,
								Target.IsEnabled = Source.Isenabled;

			MERGE 
			INTO	etl.Module AS Target
			USING	(
						VALUES	--Level 1 
								(6,2,'EB Trifocus', 1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FDMTrifocusCode.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
					            (6,21,'MDS ToLanding', 1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_MDSToLandingExtract.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

								--level 2
								(6,19,'Eurobase BaseLoad',1,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''EurobaseBaseLoad.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								(6,13,'US Premium BaseLoad',1,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''USPremiumBaseLoad.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								(6,16,'PFT Forecast',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''PremiumForecastLanding.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								(6,30,'BICI BaseLoadLanding',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BICILandingBaseLoad.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								(6,31,'BIDAC BaseLoadLanding',1,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BIDACLandingBaseLoad.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								(6,32,'USBAIC BaseLoadLanding',1,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_USBAICLandingBaseLoad.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								(6,33,'USBESI Landing',1,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_PyramidToLandingExtract.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								(6,34,'Eurobase TacticalLoad',1,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''EurobaseTacticalLoad.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								--Level 3
								(6,3,'EB Landing BaseLoad', 1,	'EXEC [eb].[usp_LandingInboundWorkflow_BaseLoad] ','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								(6,80,'Dummy Load', 1,	'SELECT 1','$(InstanceName)', 'FinanceLanding', NULL, NULL),

								--Level 4
								(6,14,'US Landing', 1,			'EXEC [us].[usp_LandingInboundWorkflow]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								(6,17,'PFT Landing', 1,			'EXEC [pft].[usp_LandingToInboundToOutboundWorkflow]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								(6,40,'BICI LandToInbound', 1,	'EXEC [US].[usp_BICILandingToInboundWorkflow]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								(6,41,'BIDAC LandToInbound', 1,	'EXEC [BIDAC].[usp_LandingInboundWorkflow]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								(6,42,'USBAIC LandToInbound', 1,'EXEC [US].[usp_BAICLandingToInboundWorkflow]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								(6,43,'USBESI LandingToInboundToOutbound', 1,'EXEC [Pyramid].[usp_LandingToInboundToOutboundWorkflow_USBESI]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								(6,44,'EurobaseTactical LandToInbound', 1,'EXEC [Eb].[usp_LandingInboundWorkflow_EurobaseTacticalLoad]','$(InstanceName)', 'FinanceLanding', NULL, NULL),

								--Level 5
								(6,4,'DataContract',1,			'EXEC [Inbound].[usp_InboundOutboundWorkflow]'	,'$(InstanceName)', 'FinanceDataContract', NULL, NULL),
								(6,90,'DataContract',1,			'EXEC [Inbound].[usp_InboundOutboundWorkflow_GAAP]'	,'$(InstanceName)', 'FinanceDataContract', NULL, NULL),
								(6,91,'EurobaseDataContract',1,	 'EXEC [TL].[usp_InboundOutBoundWorkflow_TacticalLoads]'	,'$(InstanceName)', 'FinanceDataContract', NULL, NULL),

								--level 6
								(6,5,'DimTrifocus', 1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTrifocus.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,	 NULL),
								(6,6,'DimEntity',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimEntity.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(6,7,'DimYOA',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimYOA.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(6,8,'DimCCY',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimCCY.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL), 
								(6,9,'DimProduct',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimProduct.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(6,10,'DimLocation',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimLocation.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(6,81,'DimAccountdtsx',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimAccount.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL), 
								(6,82,'DimPatternName',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPatternName.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(6,83,'DimCatCode',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimCatCode.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(6,84,'DimMovementType',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimMovementType.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL), 
								(6,85,'DimClaimExposure',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimClaimExposure.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								
								--Level 7
								--(6,11,'Dim Policy',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPolicy.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(6,11,'Dummy Load',1,			'SELECT 1'	,'$(InstanceName)', 'FinanceDataContract', NULL, NULL),
								(6,27,'DimPolicySection',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPolicySection.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(6,70,'DimDataset',1,			'EXEC  [Dim].[MergeDatasetBR1]','$(InstanceName)', 'TechnicalHub', NULL, NULL),
								(6,71,'DimAccount',1,			'SELECT 1'	,'$(InstanceName)', 'TechnicalHub', NULL, NULL),
								(6,72,'DimTrackingStatus',1,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTrackingStatus.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(6,73,'DimRIPolicyType',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimRIPolicyType.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(6,74,'DimProgrammeCode',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimProgrammeCode.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(6,75,'DimTriangleGroup',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTriangleGroup.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(6,76,'DimReservingDataSet',1,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimReservingDataset.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(6,77,'DimRateScenario',1,	    'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimRateScenario.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(6,78,'DimReportingCurrency',1,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimReportingCurrency.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),

								--Level 8
								(6,12,'Tech Fact',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactTechnicalResult.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								--Level 9
								(6,15,'Earning',1,				'SELECT 1','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								--Level 10
								(6,18,'SideCar',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactSideCar.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								--Level 11
								(6,20,'THubToFDM Extraction',1, 'SELECT 1 /*EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''THubToFactFDMExternal.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT*/','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								--(6,26,'Dummy CUBE job',1,'SELECT 1','$(InstanceName)', 'SchedulingHub', NULL, NULL)
								--Level 12
								(6,100,'FXRate'	,1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactFxRates.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL)


						)
					
						AS Source(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.PK_Module = Source.PK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
					VALUES(Source.FK_Orchestration,  Source.PK_module,  Source.ModuleName,  Source.FK_ModuleType,  Source.ModuleRoutine,  Source.DestinationServer,  Source.DestinationDatabase,Source.FK_Schedule,Source.FK_Notification)
			WHEN	MATCHED
			THEN	UPDATE SET		FK_Orchestration	= source.FK_Orchestration, 
									PK_module 			= source.PK_module, 
									ModuleName 			= source.ModuleName, 
									FK_ModuleType 		= source.FK_ModuleType, 
									ModuleRoutine 		= source.ModuleRoutine, 
									DestinationServer	= source.DestinationServer, 
									DestinationDatabase	= source.DestinationDatabase, 
									FK_Schedule 		= source.FK_Schedule, 
									FK_Notification		= source.FK_Notification
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = 6
			THEN	DELETE;

			MERGE 
			INTO	etl.ModuleHierarchy AS Target
			USING	(
						VALUES	--L1 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
								(6,	NULL,	2,	1), 
								(6,	NULL,	21,	1),
					
								--L2 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
								(6,	2,	13,	2),
								(6,	2,	16,	2),
								(6,	2,	19,	2),
								(6,	2,	30,	2),
								(6,	2,	31,	2),
								(6,	2,	32,	2),
								(6,	2,	33,	2),
								(6,	2,	34,	2),

								(6,	21,	13,	2),
								(6,	21,	16,	2),
								(6,	21,	19,	2),
								(6,	21,	30,	2),
								(6,	21,	31,	2),
								(6,	21,	32,	2),
								(6,	21,	33,	2),
								(6,	21,	34,	2),

								--L3 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
								(6,	13,	3,	3),
								(6,	16,	3,	3),
								(6,	19,	3,	3),
								(6,	30,	3,	3),
								(6,	31,	3,	3),
								(6,	32,	3,	3),
								(6,	33,	3,	3),
								(6,	34,	3,	3),

								(6,	13,	80,	3),
								(6,	16,	80,	3),
								(6,	19,	80,	3),
								(6,	30,	80,	3),
								(6,	31,	80,	3),
								(6,	32,	80,	3),
								(6,	33,	80,	3),
								(6,	34,	80,	3),
								

								--L4 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
								(6,	3,	14,	4),
								(6,	3,	17,	4),
								(6,	3,	40,	4),
								(6,	3,	41,	4),
								(6,	3,	42,	4),
								(6,	3,	43,	4),
								(6,	3,	44,	4),

								(6,	80,	14,	4),
								(6,	80,	17,	4),
								(6,	80,	40,	4),
								(6,	80,	41,	4),
								(6,	80,	42,	4),
								(6,	80,	43,	4),
								(6,	80,	44,	4),
								--L5 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
								
							--	(6,	3,	4,	5),
								(6,	14,	4,	5),
								(6,	17,	4,	5),
								(6,	40,	4,	5),
								(6,	41,	4,	5),
								(6,	42,	4,	5),
								(6,	43,	4,	5),
								(6,	44,	4,	5),


								(6,	14,	90,	5),
								(6,	17,	90,	5),
								(6,	40,	90,	5),
								(6,	41,	90,	5),
								(6,	42,	90,	5),
								(6,	43,	90,	5),
								(6,	44,	90,	5),


								(6,	14,	91,	5),
								(6,	17,	91,	5),
								(6,	40,	91,	5),
								(6,	41,	91,	5),
								(6,	42,	91,	5),
								(6,	43,	91,	5),
								(6,	44,	91,	5),

								--L6 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
								(6,	4,	5,	6),
								(6,	4,	6,	6),
								(6,	4,	7,	6),
								(6,	4,	8,	6),
								(6,	4,	9,	6),
								(6,	4,	10,	6),
								(6,	4,	81,	6),
								(6,	4,	82,	6),
								(6,	4,	83,	6),
								(6,	4,	84,	6),
								(6,	4,	85,	6),

								(6,	90,	5,	6),
								(6,	90,	6,	6),
								(6,	90,	7,	6),
								(6,	90,	8,	6),
								(6,	90,	9,	6),
								(6,	90,	10,	6),
								(6,	90,	81,	6),
								(6,	90,	82,	6),
								(6,	90,	83,	6),
								(6,	90,	84,	6),
								(6,	90,	85,	6),


								--L7
								(6,	4,	11,	7),
								(6,	4,	27,	7),
								(6,	4,	70,	7),
								(6,	4,	71,	7),
								(6,	4,	72,	7),
								(6,	4,	73,	7),
								(6,	4,	74,	7),
								(6,	4,	75,	7),
								(6,	4,	76,	7),
								(6,	4,	77,	7),
								(6,	4,	78,	7),

								(6,	90,	11,	7),
								(6,	90,	27,	7),
								(6,	90,	70,	7),
								(6,	90,	71,	7),
								(6,	90,	72,	7),
								(6,	90,	73,	7),
								(6,	90,	74,	7),
								(6,	90,	75,	7),
								(6,	90,	76,	7),
								(6,	90,	77,	7),
								(6,	90,	78,	7),
								

								--L8 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
								(6,	5,	12,	8),
								(6,	6,	12,	8),
								(6,	7,	12,	8),
								(6,	8,	12,	8),
								(6,	9,	12,	8),
								(6,	10,	12,	8),
								(6,	11,	12,	8),
								(6,	27,	12,	8),
								(6,	70,	12,	8),

								--L9 (FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
								(6,	12,	15,	9),
								--L10
								(6,	15,	18,	10),
								--L11
								(6, 18, 20, 11),
								--(6, 18, 26, 10)
								--L12
								(6, 20, 100, 12)





					) AS Source(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.FK_ChildModule = Source.FK_ChildModule
				AND Target.FK_ParentModule = Source.FK_ParentModule
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
					VALUES(Source.FK_Orchestration,Source.FK_ParentModule,Source.FK_ChildModule,Source.TreeLevel)
			WHEN	MATCHED
			THEN	UPDATE SET	FK_Orchestration = source.FK_Orchestration, 
								FK_ParentModule = source.FK_ParentModule, 
								FK_ChildModule = source.FK_ChildModule, 
								TreeLevel = source.TreeLevel
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = 6
			THEN	DELETE;


			MERGE	etl.ModuleActivity Target
			USING	(
						SELECT	m.FK_Orchestration,
								m.PK_Module,
								1
						FROM	etl.Module m
						WHERE	m.FK_Orchestration = 6
					) Source (FK_Orchestration, FK_Module, FK_ModuleStatus)
			ON		Source.FK_Orchestration = Target.FK_Orchestration
				AND	Source.FK_Module = Target.FK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT	(FK_Orchestration, FK_Module, FK_ModuleStatus)
					VALUES	(Source.FK_Orchestration, Source.FK_Module, Source.FK_ModuleStatus)
			WHEN	MATCHED
			THEN	UPDATE	SET	Target.FK_ModuleStatus = Source.FK_ModuleStatus
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = 6
			THEN	DELETE;