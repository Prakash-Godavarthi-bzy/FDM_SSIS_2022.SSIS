﻿--:setvar InstanceName "UKDVDB149"

/*
	Change log. Please add comments to help us developers make sure we don't miss changes before we check in code.

	Author:			nithin.dumpeti@beazley.com
	Description:	Orchestration17 is ued to only for Dims and Fact

*/

declare @IFRS17_InstanceName_B34 nvarchar(129) = '$(InstanceName)'



--select @IFRS17_InstanceName_Pre

/*
	-- to delete everything and start again. The merge statement can fail when changes break referential entrigity, 
	-- so the data needs to be deleted and re-stated.
declare @IFRS17_Orchestration_Pre int = 17

delete etl.ModuleActivity
where FK_Orchestration = @IFRS17_Orchestration_B34

delete etl.ModuleHierarchy
where FK_Orchestration = @IFRS17_Orchestration_B34

delete etl.Module
where FK_Orchestration = @IFRS17_Orchestration_B34

delete etl.Orchestration
where PK_Orchestration = @IFRS17_Orchestration_B34

*/

-- static variables
declare @IFRS17_Orchestration_B34 int = 16
declare @IFRS17_Orchestration_IsEnabledB34 int = 1
declare @IFRS17_RunTimeExecutionPriorityOrderB34 int = 1

Delete from etl.ModuleHierarchy 
where FK_Orchestration=@IFRS17_Orchestration_B34

Delete from etl.ModuleActivity 
where FK_Orchestration=@IFRS17_Orchestration_B34

Delete From etl.Module 
where FK_Orchestration=@IFRS17_Orchestration_B34


  --orchestration select * from etl.Orchestration
			MERGE 
			INTO	etl.Orchestration AS Target
			USING	(VALUES(@IFRS17_Orchestration_B34, 'BR1Orchestration DimsFact',@IFRS17_Orchestration_IsEnabledB34)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled)
			ON		(Target.PK_Orchestration = Source.PK_Orchestration)
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(PK_Orchestration,OrchestrationName,IsEnabled)
					VALUES(Source.PK_Orchestration,  Source.OrchestrationName,  Source.IsEnabled)
			WHEN	MATCHED
			THEN	UPDATE SET	Target.ORchestrationName = Source.OrchestrationName,
								Target.IsEnabled = Source.Isenabled;

			-- code to uncomment when priority column can be released.
			--MERGE 
			--INTO	etl.Orchestration AS Target
			--USING	(VALUES(@IFRS17_Orchestration_Pre, 'IFRS17',@IFRS17_Orchestration_IsEnabledPre,@IFRS17_RunTimeExecutionPriorityOrder)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled,RunTimeExecutionPriorityOrder)
			--ON		(Target.PK_Orchestration = Source.PK_Orchestration)
			--WHEN	NOT MATCHED BY TARGET
			--THEN	INSERT(PK_Orchestration,OrchestrationName,IsEnabled,RunTimeExecutionPriorityOrder)
			--		VALUES(Source.PK_Orchestration,  Source.OrchestrationName,  Source.IsEnabled, Source.RunTimeExecutionPriorityOrder)
			--WHEN	MATCHED
			--THEN	UPDATE SET	Target.ORchestrationName = Source.OrchestrationName,
			--					Target.IsEnabled = Source.Isenabled,
			--					Target.RunTimeExecutionPriorityOrder = Source.RunTimeExecutionPriorityOrder;

--module select * from etl.Module 

declare @FK_ModuleType_SPB34 int = (select PK_ModuleType from [etl].[ModuleType] where ModuleType = 'SPROC')
declare @FK_ModuleType_SSISB34 int = (select PK_ModuleType from [etl].[ModuleType] where ModuleType = 'SSIS')

			MERGE --@IFRS17_Orchestration_Pre
			INTO	etl.Module AS Target
			USING	(
						VALUES	--Level 1 Dims 1*15=1-15	
								
								--Level 1 Dims
								(@IFRS17_Orchestration_B34,1,'DimTrifocus', @FK_ModuleType_SSISB34,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTrifocus.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_B34, 'SchedulingHub', null,	 NULL),
								(@IFRS17_Orchestration_B34,2,'DimEntity',@FK_ModuleType_SSISB34,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimEntity.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_B34,3,'DimYOA',@FK_ModuleType_SSISB34,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimYOA.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_B34,4,'DimCCY',@FK_ModuleType_SSISB34,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimCCY.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL), 
								(@IFRS17_Orchestration_B34,5,'DimProduct',@FK_ModuleType_SSISB34,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimProduct.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_B34,6,'DimLocation',@FK_ModuleType_SSISB34,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimLocation.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_B34,7,'Dummy Load',@FK_ModuleType_SSISB34,           'SELECT 1',@IFRS17_InstanceName_B34, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_B34,8,'DimAccount',@FK_ModuleType_SSISB34,			'SELECT 1',@IFRS17_InstanceName_B34, 'TechnicalHub', NULL, NULL),
								(@IFRS17_Orchestration_B34,9,'DimDataset',@FK_ModuleType_SSISB34,			'EXEC  [Dim].[MergeDatasetBR1]',@IFRS17_InstanceName_B34, 'TechnicalHub', NULL, NULL),
								(@IFRS17_Orchestration_B34,10,'DimPatternName',@FK_ModuleType_SSISB34,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPatternName.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_B34,11,'DimCatCode',@FK_ModuleType_SSISB34,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimCatCode.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_B34,12,'DimMovementType',@FK_ModuleType_SSISB34,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimMovementType.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_B34,13,'DimAccountDtsx', @FK_ModuleType_SSISB34,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimAccount.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_B34, 'SchedulingHub', null,	 NULL),
								(@IFRS17_Orchestration_B34,14,'DimClaimExposure', @FK_ModuleType_SSISB34,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimClaimExposure.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_B34, 'SchedulingHub', null,	 NULL),
								(@IFRS17_Orchestration_B34,15,'DimPolicySection', @FK_ModuleType_SSISB34,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPolicySection.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_B34, 'SchedulingHub', null,	 NULL),

								--Level 2 Dims
								(@IFRS17_Orchestration_B34,16,'DimTrackingStatus',@FK_ModuleType_SSISB34,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTrackingStatus.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_B34,17,'DimRIPolicyType',@FK_ModuleType_SSISB34,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimRIPolicyType.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_B34,18,'DimProgrammeCode',@FK_ModuleType_SSISB34,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimProgrammeCode.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_B34,19,'DimTriangleGroup',@FK_ModuleType_SSISB34,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTriangleGroup.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_B34,20,'DimReservingDataSet',@FK_ModuleType_SSISB34,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimReservingDataset.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_B34,21,'DimRateScenario',@FK_ModuleType_SSISB34,	    'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimRateScenario.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_B34,22,'DimReportingCurrency',@FK_ModuleType_SSISB34,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimReportingCurrency.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL),
														  
								--Level 3 Facts		  
								(@IFRS17_Orchestration_B34,23,'IFRS2017TechResult',@FK_ModuleType_SSISB34,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactTechnicalResult_IFRS2017.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_B34,24,'Fact Pattern',@FK_ModuleType_SSISB34,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactPattern.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_B34,25,'Fact Discountrates',@FK_ModuleType_SSISB34,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactDiscountRates.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_B34,26,'StandAlone Loads',@FK_ModuleType_SSISB34,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''StandaloneLoads.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL),
														  
								--Level 4				  
								(@IFRS17_Orchestration_B34,27,'Tech Fact',@FK_ModuleType_SSISB34,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactTechnicalResult.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL),

								--Level 5
								(@IFRS17_Orchestration_B34,28,'Earning',@FK_ModuleType_SSISB34,		'SELECT 1',@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL),

								--Level 6
								(@IFRS17_Orchestration_B34,29,'SideCar',@FK_ModuleType_SSISB34,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactSideCar.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_B34,30,'FXRate'	,@FK_ModuleType_SSISB34,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactFxRates.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_B34, 'SchedulingHub', NULL, NULL)



								
					)
						AS Source(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.PK_Module = Source.PK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
					VALUES(Source.FK_Orchestration,  Source.PK_module,  Source.ModuleName,  Source.FK_ModuleType,  Source.ModuleRoutine,  Source.DestinationServer,  Source.DestinationDatabase,Source.FK_Schedule,Source.FK_Notification)
			WHEN	MATCHED
			THEN	UPDATE SET		FK_Orchestration	= source.FK_Orchestration, 
									PK_module 			= source.PK_module, 
									ModuleName 			= source.ModuleName, 
									FK_ModuleType 		= source.FK_ModuleType, 
									ModuleRoutine 		= source.ModuleRoutine, 
									DestinationServer	= source.DestinationServer, 
									DestinationDatabase	= source.DestinationDatabase, 
									FK_Schedule 		= source.FK_Schedule, 
									FK_Notification		= source.FK_Notification
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_B34
			THEN	DELETE;




			--ModuleHierarchy select * from etl.ModuleHierarchy
			MERGE 
			INTO	etl.ModuleHierarchy AS Target
			USING	(
						VALUES	
								--L1 Dims
							
								(@IFRS17_Orchestration_B34,	NULL,	1,		1), 
								(@IFRS17_Orchestration_B34,	NULL,	2,		1),
								(@IFRS17_Orchestration_B34,	NULL,	3,		1),
								(@IFRS17_Orchestration_B34,	NULL,	4,		1), 
								(@IFRS17_Orchestration_B34,	NULL,	5,		1),
								(@IFRS17_Orchestration_B34,	NULL,	6,		1),
								(@IFRS17_Orchestration_B34,	NULL,	7,		1), 
								(@IFRS17_Orchestration_B34,	NULL,	8,		1),
								(@IFRS17_Orchestration_B34,	NULL,	9,		1),
								(@IFRS17_Orchestration_B34,	NULL,	10,		1), 
								(@IFRS17_Orchestration_B34,	NULL,	11,		1),
								(@IFRS17_Orchestration_B34,	NULL,	12,		1),
								(@IFRS17_Orchestration_B34,	NULL,	13,		1), 
								(@IFRS17_Orchestration_B34,	NULL,	14,		1),
								(@IFRS17_Orchestration_B34,	NULL,	15,		1),

								--L2
								(@IFRS17_Orchestration_B34,	1,	16,		2), 
								(@IFRS17_Orchestration_B34,	2,	16,		2),
								(@IFRS17_Orchestration_B34,	3,	16,		2),
								(@IFRS17_Orchestration_B34,	4,	16,		2), 
								(@IFRS17_Orchestration_B34,	5,	16,		2),
								(@IFRS17_Orchestration_B34,	6,	16,		2),
								(@IFRS17_Orchestration_B34,	7,	16,		2), 
								(@IFRS17_Orchestration_B34,	8,	16,		2),
								(@IFRS17_Orchestration_B34,	9,	16,		2),
								(@IFRS17_Orchestration_B34,	10, 16,		2), 
								(@IFRS17_Orchestration_B34,	11, 16,		2),
								(@IFRS17_Orchestration_B34,	12, 16,		2),
								(@IFRS17_Orchestration_B34,	13, 16,		2), 
								(@IFRS17_Orchestration_B34,	14, 16,		2),
								(@IFRS17_Orchestration_B34,	15, 16,		2),

								(@IFRS17_Orchestration_B34,	1,	17,		2), 
								(@IFRS17_Orchestration_B34,	2,	17,		2),
								(@IFRS17_Orchestration_B34,	3,	17,		2),
								(@IFRS17_Orchestration_B34,	4,	17,		2), 
								(@IFRS17_Orchestration_B34,	5,	17,		2),
								(@IFRS17_Orchestration_B34,	6,	17,		2),
								(@IFRS17_Orchestration_B34,	7,	17,		2), 
								(@IFRS17_Orchestration_B34,	8,	17,		2),
								(@IFRS17_Orchestration_B34,	9,	17,		2),
								(@IFRS17_Orchestration_B34,	10, 17,		2), 
								(@IFRS17_Orchestration_B34,	11, 17,		2),
								(@IFRS17_Orchestration_B34,	12, 17,		2),
								(@IFRS17_Orchestration_B34,	13, 17,		2), 
								(@IFRS17_Orchestration_B34,	14, 17,		2),
								(@IFRS17_Orchestration_B34,	15, 17,		2),

								(@IFRS17_Orchestration_B34,	1,	18,		2), 
								(@IFRS17_Orchestration_B34,	2,	18,		2),
								(@IFRS17_Orchestration_B34,	3,	18,		2),
								(@IFRS17_Orchestration_B34,	4,	18,		2), 
								(@IFRS17_Orchestration_B34,	5,	18,		2),
								(@IFRS17_Orchestration_B34,	6,	18,		2),
								(@IFRS17_Orchestration_B34,	7,	18,		2), 
								(@IFRS17_Orchestration_B34,	8,	18,		2),
								(@IFRS17_Orchestration_B34,	9,	18,		2),
								(@IFRS17_Orchestration_B34,	10, 18,		2), 
								(@IFRS17_Orchestration_B34,	11, 18,		2),
								(@IFRS17_Orchestration_B34,	12, 18,		2),
								(@IFRS17_Orchestration_B34,	13, 18,		2), 
								(@IFRS17_Orchestration_B34,	14, 18,		2),
								(@IFRS17_Orchestration_B34,	15, 18,		2),

								(@IFRS17_Orchestration_B34,	1,	19,		2), 
								(@IFRS17_Orchestration_B34,	2,	19,		2),
								(@IFRS17_Orchestration_B34,	3,	19,		2),
								(@IFRS17_Orchestration_B34,	4,	19,		2), 
								(@IFRS17_Orchestration_B34,	5,	19,		2),
								(@IFRS17_Orchestration_B34,	6,	19,		2),
								(@IFRS17_Orchestration_B34,	7,	19,		2), 
								(@IFRS17_Orchestration_B34,	8,	19,		2),
								(@IFRS17_Orchestration_B34,	9,	19,		2),
								(@IFRS17_Orchestration_B34,	10, 19,		2), 
								(@IFRS17_Orchestration_B34,	11, 19,		2),
								(@IFRS17_Orchestration_B34,	12, 19,		2),
								(@IFRS17_Orchestration_B34,	13, 19,		2), 
								(@IFRS17_Orchestration_B34,	14, 19,		2),
								(@IFRS17_Orchestration_B34,	15, 19,		2),

								(@IFRS17_Orchestration_B34,	1,	20,		2), 
								(@IFRS17_Orchestration_B34,	2,	20,		2),
								(@IFRS17_Orchestration_B34,	3,	20,		2),
								(@IFRS17_Orchestration_B34,	4,	20,		2), 
								(@IFRS17_Orchestration_B34,	5,	20,		2),
								(@IFRS17_Orchestration_B34,	6,	20,		2),
								(@IFRS17_Orchestration_B34,	7,	20,		2), 
								(@IFRS17_Orchestration_B34,	8,	20,		2),
								(@IFRS17_Orchestration_B34,	9,	20,		2),
								(@IFRS17_Orchestration_B34,	10, 20,		2), 
								(@IFRS17_Orchestration_B34,	11, 20,		2),
								(@IFRS17_Orchestration_B34,	12, 20,		2),
								(@IFRS17_Orchestration_B34,	13, 20,		2), 
								(@IFRS17_Orchestration_B34,	14, 20,		2),
								(@IFRS17_Orchestration_B34,	15, 20,		2),

								(@IFRS17_Orchestration_B34,	1,	21,		2), 
								(@IFRS17_Orchestration_B34,	2,	21,		2),
								(@IFRS17_Orchestration_B34,	3,	21,		2),
								(@IFRS17_Orchestration_B34,	4,	21,		2), 
								(@IFRS17_Orchestration_B34,	5,	21,		2),
								(@IFRS17_Orchestration_B34,	6,	21,		2),
								(@IFRS17_Orchestration_B34,	7,	21,		2), 
								(@IFRS17_Orchestration_B34,	8,	21,		2),
								(@IFRS17_Orchestration_B34,	9,	21,		2),
								(@IFRS17_Orchestration_B34,	10, 21,		2), 
								(@IFRS17_Orchestration_B34,	11, 21,		2),
								(@IFRS17_Orchestration_B34,	12, 21,		2),
								(@IFRS17_Orchestration_B34,	13, 21,		2), 
								(@IFRS17_Orchestration_B34,	14, 21,		2),
								(@IFRS17_Orchestration_B34,	15, 21,		2),

								(@IFRS17_Orchestration_B34,	1,	22,		2), 
								(@IFRS17_Orchestration_B34,	2,	22,		2),
								(@IFRS17_Orchestration_B34,	3,	22,		2),
								(@IFRS17_Orchestration_B34,	4,	22,		2), 
								(@IFRS17_Orchestration_B34,	5,	22,		2),
								(@IFRS17_Orchestration_B34,	6,	22,		2),
								(@IFRS17_Orchestration_B34,	7,	22,		2), 
								(@IFRS17_Orchestration_B34,	8,	22,		2),
								(@IFRS17_Orchestration_B34,	9,	22,		2),
								(@IFRS17_Orchestration_B34,	10, 22,		2), 
								(@IFRS17_Orchestration_B34,	11, 22,		2),
								(@IFRS17_Orchestration_B34,	12, 22,		2),
								(@IFRS17_Orchestration_B34,	13, 22,		2), 
								(@IFRS17_Orchestration_B34,	14, 22,		2),
								(@IFRS17_Orchestration_B34,	15, 22,		2),
								
								--L3

								(@IFRS17_Orchestration_B34,	16,	23,		3), 
								(@IFRS17_Orchestration_B34,	17,	23,		3),
								(@IFRS17_Orchestration_B34,	18,	23,		3),
								(@IFRS17_Orchestration_B34,	19,	23,		3), 
								(@IFRS17_Orchestration_B34,	20,	23,		3),
								(@IFRS17_Orchestration_B34,	21,	23,		3),
								(@IFRS17_Orchestration_B34,	22,	23,		3),

								(@IFRS17_Orchestration_B34,	16,	24,		3), 
								(@IFRS17_Orchestration_B34,	17,	24,		3),
								(@IFRS17_Orchestration_B34,	18,	24,		3),
								(@IFRS17_Orchestration_B34,	19,	24,		3), 
								(@IFRS17_Orchestration_B34,	20,	24,		3),
								(@IFRS17_Orchestration_B34,	21,	24,		3),
								(@IFRS17_Orchestration_B34,	22,	24,		3),

								(@IFRS17_Orchestration_B34,	16,	25,		3), 
								(@IFRS17_Orchestration_B34,	17,	25,		3),
								(@IFRS17_Orchestration_B34,	18,	25,		3),
								(@IFRS17_Orchestration_B34,	19,	25,		3), 
								(@IFRS17_Orchestration_B34,	20,	25,		3),
								(@IFRS17_Orchestration_B34,	21,	25,		3),
								(@IFRS17_Orchestration_B34,	22,	25,		3),

								(@IFRS17_Orchestration_B34,	16,	26,		3), 
								(@IFRS17_Orchestration_B34,	17,	26,		3),
								(@IFRS17_Orchestration_B34,	18,	26,		3),
								(@IFRS17_Orchestration_B34,	19,	26,		3), 
								(@IFRS17_Orchestration_B34,	20,	26,		3),
								(@IFRS17_Orchestration_B34,	21,	26,		3),
								(@IFRS17_Orchestration_B34,	22,	26,		3),


								--L4
								(@IFRS17_Orchestration_B34,	23,	27,		4), 
								(@IFRS17_Orchestration_B34,	24,	27,		4),
								(@IFRS17_Orchestration_B34,	25,	27,		4),
								(@IFRS17_Orchestration_B34,	26,	27,		4), 

								--L5
								(@IFRS17_Orchestration_B34,	27,	28,		5), 

								--L6
								(@IFRS17_Orchestration_B34,	28,	29,		6),
								(@IFRS17_Orchestration_B34,	28,	30,		6)


					) AS Source(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.FK_ChildModule = Source.FK_ChildModule
				AND Target.FK_ParentModule = Source.FK_ParentModule
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
					VALUES(Source.FK_Orchestration,Source.FK_ParentModule,Source.FK_ChildModule,Source.TreeLevel)
			WHEN	MATCHED
			THEN	UPDATE SET	FK_Orchestration = source.FK_Orchestration, 
								FK_ParentModule = source.FK_ParentModule, 
								FK_ChildModule = source.FK_ChildModule, 
								TreeLevel = source.TreeLevel
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_B34
			THEN	DELETE;






			--ModuleActivity select * from etl.ModuleActivity
			MERGE	etl.ModuleActivity Target
			USING	(
						SELECT	m.FK_Orchestration,
								m.PK_Module,
								1, -- Pending
								'Initialization from deployment' -- run description
						FROM	etl.Module m
						WHERE	m.FK_Orchestration = @IFRS17_Orchestration_B34
					) Source (FK_Orchestration, FK_Module, FK_ModuleStatus,RunDescription)
			ON		Source.FK_Orchestration = Target.FK_Orchestration
				AND	Source.FK_Module = Target.FK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT	(FK_Orchestration, FK_Module, FK_ModuleStatus, RunDescription)
					VALUES	(Source.FK_Orchestration, Source.FK_Module, Source.FK_ModuleStatus, Source.RunDescription)
			WHEN	MATCHED
			THEN	UPDATE	SET	Target.FK_ModuleStatus = Source.FK_ModuleStatus, Target.RunDescription = Source.RunDescription
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_B34
			THEN	DELETE;


