﻿

declare @IFRS17_InstanceName_NTL nvarchar(129) = '$(InstanceName)'


declare @IFRS17_Orchestration_NTL int = 14
declare @IFRS17_Orchestration_IsEnabledNTL int = 1
declare @IFRS17_RunTimeExecutionPriorityOrderNTL int = 1

Delete from etl.ModuleHierarchy where FK_Orchestration=14
Delete from etl.ModuleActivity where FK_Orchestration=14
Delete From etl.Module where FK_Orchestration=14


			MERGE 
			INTO	etl.Orchestration AS Target
			USING	(VALUES(@IFRS17_Orchestration_NTL, 'IFRS17_NTL',@IFRS17_Orchestration_IsEnabledNTL)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled)
			ON		(Target.PK_Orchestration = Source.PK_Orchestration)
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(PK_Orchestration,OrchestrationName,IsEnabled)
					VALUES(Source.PK_Orchestration,  Source.OrchestrationName,  Source.IsEnabled)
			WHEN	MATCHED
			THEN	UPDATE SET	Target.ORchestrationName = Source.OrchestrationName,
								Target.IsEnabled = Source.Isenabled;



declare @FK_ModuleType_SPNTL int = (select PK_ModuleType from [etl].[ModuleType] where ModuleType = 'SPROC')

			MERGE 
			INTO	etl.Module AS Target
			USING	(
						VALUES	--Level 1 1*15=1-15
								(@IFRS17_Orchestration_NTL,1,'EIOPA ToLanding',@FK_ModuleType_SPNTL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_EIOPAToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_NTL,2,'NatCatEarning ToLanding',@FK_ModuleType_SPNTL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_NatCatEarningToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_NTL,3,'Paid Rebates Landing',@FK_ModuleType_SPNTL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_PaidRebatesToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_NTL,4,'Ultimate Rebates Landing',@FK_ModuleType_SPNTL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_UltimateRebatesToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_NTL,5,'BeazleyRIMI to Landing',@FK_ModuleType_SPNTL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BeazleyMIReinsuranceToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_NTL,6,'LPSO ToLanding',@FK_ModuleType_SPNTL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_EurobaseToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_NTL,7,'MDS ToLanding',@FK_ModuleType_SPNTL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_MDSToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_NTL,8,'FDM ToLanding',@FK_ModuleType_SPNTL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_FDMToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),
								-- used for DS ObligatedPremium_MunichQQS proc [OP].[usp_LandingToInboundToOutbound_ObligatedPremium_MunichQQS] 
								(@IFRS17_Orchestration_NTL,9,'ADM ToLanding',  @FK_ModuleType_SPNTL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADMToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),
								
								(@IFRS17_Orchestration_NTL,10,'ADM DFM PaymentPatterns',@FK_ModuleType_SPNTL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADM_DFM_PaymentPattern_ToLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_NTL,11,'ADM Reserving Data PaymentPatterns',@FK_ModuleType_SPNTL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADM_ResDat_PaymentPattern_ToLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_NTL,12,'ADM S2 Technical Provision PaymentPatterns',@FK_ModuleType_SPNTL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_ADM_S2_TPOutput_PaymentPattern_ToLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_NTL,13,'CededRe to Landing',@FK_ModuleType_SPNTL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_CededReAccToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_NTL,14,'SyndicateSplit Landing',@FK_ModuleType_SPNTL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''SyndicateSplit.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_NTL,15,'BICC ToLanding',@FK_ModuleType_SPNTL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BICCToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),

								--Level 2

								(@IFRS17_Orchestration_NTL,16,'Ult Profit Commission Landing',@FK_ModuleType_SPNTL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_UltimateProfitCommissionToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_NTL,17,'AgressoAR Landing Landing',  @FK_ModuleType_SPNTL,'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_AgressoToLandingExtract.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_NTL,18,'EB Trifocus',@FK_ModuleType_SPNTL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FDMTrifocusCode.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),								
								(@IFRS17_Orchestration_NTL,19,'EurobaseEPIReInstatement Landing',@FK_ModuleType_SPNTL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_EurobaseEPIReinstatement.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),								
								(@IFRS17_Orchestration_NTL,20,'Dummy Load',@FK_ModuleType_SPNTL,'SELECT 1'	,@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),


								--Level 3  
								(@IFRS17_Orchestration_NTL,27,'Eurobase',@FK_ModuleType_SPNTL,'SELECT 1'	,@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_NTL,28,'US Premium',@FK_ModuleType_SPNTL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''USPremium.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_NTL,29,'PFT Forecast',@FK_ModuleType_SPNTL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''PremiumForecastLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_NTL,30,'BICI Landing',@FK_ModuleType_SPNTL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BICILanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_NTL,31,'BIDAC Landing',@FK_ModuleType_SPNTL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BIDACLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),
								(@IFRS17_Orchestration_NTL,32,'USBAIC Landing',@FK_ModuleType_SPNTL,'EXEC [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_USBAICLanding.dtsx'', @PackageLocation = ''FinanceLanding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL,'SchedulingHub',NULL,NULL),
								


								--Level 4 Land to inbound (EIOPA,NatCat,PaidRebates) 
								(@IFRS17_Orchestration_NTL,41,'MDS LandingToInbound', @FK_ModuleType_SPNTL,'EXEC [MDS].[usp_LandingToInbound]',@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),								

								--Level 5
								(@IFRS17_Orchestration_NTL,51,'EIOPA LandingToInbound', @FK_ModuleType_SPNTL,'EXEC [XLS].[usp_EIOPALandingToInbound_DiscountRates]',@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),

								--Level 6
								(@IFRS17_Orchestration_NTL,61,'NatCatEarning LandingToInbound', @FK_ModuleType_SPNTL,'EXEC [NCME].[usp_NatCatEarningLandingToInbound_Pattern]',@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),

								--Level	7
							    (@IFRS17_Orchestration_NTL,71,'AccountName Transaction InboundToOutbound',@FK_ModuleType_SPNTL,'EXEC [Inbound].[usp_InboundOutboundWorkflow_AccountNames]'	,@IFRS17_InstanceName_NTL, 'FinanceDataContract', NULL, NULL),																
								
								--Level 8
							    (@IFRS17_Orchestration_NTL,81,'ReInsurance_ContractAttributes LandingToInbound', @FK_ModuleType_SPNTL,'EXEC [Eurobase].[usp_LandingToInbound_TreatyReInsurance_ContractAttributes]',@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),
								
								--Level 9
								(@IFRS17_Orchestration_NTL,91,'ReInsurance_ContractAttributes InboundToOutbound', @FK_ModuleType_SPNTL,'EXEC [FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTreatyContractAttributes]',@IFRS17_InstanceName_NTL, 'FinanceDataContract', NULL, NULL),

								--Level 10
								(@IFRS17_Orchestration_NTL,101,'ReInsurance TrifocusAllocationsTreaty LandingToInbound', @FK_ModuleType_SPNTL,'EXEC [fdm].[usp_LandingToInbound_ReInsuranceTrifocusAllocationsTreaty]',@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),
								
								--Level 11
								(@IFRS17_Orchestration_NTL,111,'ReInsurance QuotaSharePercentage LandingToInbound', @FK_ModuleType_SPNTL,'EXEC [fdm].[usp_LandingToInbound_ReInsuranceQuotaSharePercentage]',@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),

								--Level 12
								(@IFRS17_Orchestration_NTL,121,'DataContract ReInsuranceQuotaSharePercentage InboundToOutbound', @FK_ModuleType_SPNTL,'EXEC [Inbound].[usp_InboundOutboundWorkflow_ReInsuranceQuotaSharePercentage]',@IFRS17_InstanceName_NTL, 'FinanceDataContract', NULL, NULL),
							
							    --Level 13
								(@IFRS17_Orchestration_NTL,131,'DataContract ReInsuranceTrifocusAllocationsTreaty InboundToOutbound', @FK_ModuleType_SPNTL,'EXEC [Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTrifocusAllocationsTreaty]',@IFRS17_InstanceName_NTL, 'FinanceDataContract', NULL, NULL),

								--Level 14
								(@IFRS17_Orchestration_NTL,141,'ADM Pattern LandingToInbound', @FK_ModuleType_SPNTL,'EXEC [ADM].[usp_LandingToInbound_Pattern]',@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),
								
								--Level 15
								(@IFRS17_Orchestration_NTL,151,'EurobaseEPIReInstatement LandingToInboundToOutbound', @FK_ModuleType_SPNTL,'EXEC Eurobase.usp_LandingToInboundToOutbound_EPIReinstatement',@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_NTL,152,'Dummy Load',@FK_ModuleType_SPNTL,'SELECT 1'	,@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),
								
								--Level 16
								(@IFRS17_Orchestration_NTL,161,'Paid Rebates LandingToInboundToOutbound', @FK_ModuleType_SPNTL,'EXEC [pdrebsrc].[usp_LandingToInboundToOutbound_PaidRebates]',@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_NTL,162,'Dummy Load',@FK_ModuleType_SPNTL,'SELECT 1'	,@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),

								--Level 17
								(@IFRS17_Orchestration_NTL,171,'Claims_BI_ODS LandingToInboundToOutbound', @FK_ModuleType_SPNTL,'EXEC [Claims_BI_ODS].[usp_LandingToInboundToOutbound]',@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),
						        
								--Level 18
								(@IFRS17_Orchestration_NTL,181,'LPSO LandingToInbound', @FK_ModuleType_SPNTL,'EXEC [Eurobase].[usp_LandingToInbound]',@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),
								
								--Level 19
								(@IFRS17_Orchestration_NTL,191,'LPSO LandingToInboundToOutbound Fac ReInsurance', @FK_ModuleType_SPNTL,'EXEC [Eurobase].[usp_LandingToInboundToOutbound_FacReInsurance]',@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),
								
								--Level 20
								(@IFRS17_Orchestration_NTL,201,'BI Policy Section references LandingToInbound', @FK_ModuleType_SPNTL,'EXEC [Claims_BI_ODS].[usp_LandingToInbound_PolicySectionReference]',@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),
								
								--Level 21 
								(@IFRS17_Orchestration_NTL,211,'DataContract DiscountRates InboundToOutbound',@FK_ModuleType_SPNTL, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_DiscountRates]'	,@IFRS17_InstanceName_NTL, 'FinanceDataContract', NULL, NULL),
								
								--Level 22
								(@IFRS17_Orchestration_NTL,221,'DataContract Pattern InboundToOutbound',@FK_ModuleType_SPNTL, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_Pattern]'	,@IFRS17_InstanceName_NTL, 'FinanceDataContract', NULL, NULL),
								
								--Level 23
								(@IFRS17_Orchestration_NTL,231,'DataContract PolicySectionReference InboundToOutbound',@FK_ModuleType_SPNTL, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_PolicySectionReferences]'	,@IFRS17_InstanceName_NTL, 'FinanceDataContract', NULL, NULL),
								
								--Level 24
								(@IFRS17_Orchestration_NTL,241,'DataContract Transaction InboundToOutbound',@FK_ModuleType_SPNTL,'EXEC [Inbound].[usp_InboundOutboundWorkflow] @DoNonIFRS17_Tests = 0'	,@IFRS17_InstanceName_NTL, 'FinanceDataContract', NULL, NULL),
								
								--Level 25

							--	(@IFRS17_Orchestration_NTL,251,'DataContract ClaimExtensions InboundToOutbound',@FK_ModuleType_SPNTL, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_ClaimExtensions]'	,@IFRS17_InstanceName_NTL, 'FinanceDataContract', NULL, NULL),

							(@IFRS17_Orchestration_NTL,251,'Dummy load',@FK_ModuleType_SPNTL, 'Select 1'	,@IFRS17_InstanceName_NTL, 'FinanceDataContract', NULL, NULL),
								

								--Level 26
								(@IFRS17_Orchestration_NTL,261,'DataContract ReInsuranceExtensions InboundToOutbound',@FK_ModuleType_SPNTL, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_ReInsuranceExtensions]'	,@IFRS17_InstanceName_NTL, 'FinanceDataContract', NULL, NULL),
								
								--Level 27 
								(@IFRS17_Orchestration_NTL,271,'DataContract ReInsurance Treaty Landing to InboundToOutbound',@FK_ModuleType_SPNTL, 'EXEC [Eurobase].[usp_LandingToInboundToOutbound_TreatyReInsurance]'	,@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),

							    --Level 28 
								(@IFRS17_Orchestration_NTL,281,'UltimateRebates LandingToInboundToOutbound',@FK_ModuleType_SPNTL,'EXEC [ultrebsrc].[usp_LandingToInboundToOutbound_UltimateRIRebate]'	,@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_NTL,282,'Dummy Load',@FK_ModuleType_SPNTL,'SELECT 1'	,@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),

								--Level 29
								(@IFRS17_Orchestration_NTL,291,'ADM LandingToInboundToOutbound', @FK_ModuleType_SPNTL,'EXEC [ADM].[usp_LandingToInboundToOutbound]',@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),
								
								--Level 30
								(@IFRS17_Orchestration_NTL,301,'CededReClaimsIncurred LandingToInboundToOutbound',@FK_ModuleType_SPNTL,'EXEC [CededRe].[usp_LandingToInboundToOutbound_CededReClaimsIncurred]'	,@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),								
								
								--Level 31
								(@IFRS17_Orchestration_NTL,311,'CededReClosedYOA LandingToInboundToOutbound',@FK_ModuleType_SPNTL,'EXEC [CededRe].[usp_LandingToInboundToOutbound_CededReClosedYOA]'	,@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),
								
								--Level 32
								(@IFRS17_Orchestration_NTL,321,'CededReORC LandingToInboundToOutbound',@FK_ModuleType_SPNTL,'EXEC [CededRe].[usp_LandingToInboundToOutbound_CededReORC]'	,@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),								
								
								--Level 33
								(@IFRS17_Orchestration_NTL,331,'Reinsurance overriding commission LandingToInboundToOutbound',@FK_ModuleType_SPNTL,'EXEC [FDM].[usp_LandingToInboundToOutbound_Reinsurance_Overriding_Commission]'	,@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),
								
								--Level 34
								(@IFRS17_Orchestration_NTL,341,'ReInsurance ObligatedPremium Transaction LandingToInboundToOutbound',@FK_ModuleType_SPNTL,'EXEC [fdm].[usp_LandingToInboundToOutbound_ObligatedPremium]'	,@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),								
								
								--Level 35
								(@IFRS17_Orchestration_NTL,351,'Ultimate Profit Commission LandingToInboundToOutbound',@FK_ModuleType_SPNTL,'EXEC [ultpc].[usp_LandingToInboundToOutbound_UltimateProfitCommission]'	,@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),								
								(@IFRS17_Orchestration_NTL,352,'Dummy Load',@FK_ModuleType_SPNTL,'SELECT 1'	,@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),

								
								--Level 36 								
								(@IFRS17_Orchestration_NTL,361,'Signed Profit Commission LandingToInboundToOutbound',@FK_ModuleType_SPNTL,'EXEC [ReinsuranceMI].[usp_LandingToInboundToOutbound_SignedProfitCommission]'	,@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),								
								
								
								
								--Level 37
								(@IFRS17_Orchestration_NTL,371,'AgressoARBIDAC LandingToInboundToOutbound',@FK_ModuleType_SPNTL,'EXEC [AgressoAR].[usp_LandingToInboundToOutbound_AgressoARBIDAC]'	,@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_NTL,372,'Dummy Load',@FK_ModuleType_SPNTL,'SELECT 1'	,@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),

								
								--Level 38
								(@IFRS17_Orchestration_NTL,381,'AgressoARUS LandingToInboundToOutbound',@FK_ModuleType_SPNTL,'EXEC [AgressoAR].[usp_LandingToInboundToOutbound_AgressoARUS]'	,@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),
							    (@IFRS17_Orchestration_NTL,382,'Dummy Load',@FK_ModuleType_SPNTL,'SELECT 1'	,@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),

								
								--Level 39
								(@IFRS17_Orchestration_NTL,391,'RISpecialArrangements Transaction LandingToInboundToOutbound',@FK_ModuleType_SPNTL,'EXEC [fdm].[usp_LandingToInboundToOutbound_RISpecialArrangements]'	,@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),								

								
								--Level 40
								(@IFRS17_Orchestration_NTL,401,'RI_ReInstatementPremiumEarned LandingToInboundToOutbound',@FK_ModuleType_SPNTL,'EXEC [fdm].[usp_LandingToInboundToOutbound_RI_Reinstatement_Premium_Earned]'	,@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),								

								
								--Level 41
								(@IFRS17_Orchestration_NTL,411,'Loading RI_Percentage data', @FK_ModuleType_SPNTL,'EXEC [fdm].[usp_LoadtoRI_Percentage]',@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),
                                
								--Level 42
								(@IFRS17_Orchestration_NTL,421,'RIPercentage LandingtoInbound',@FK_ModuleType_SPNTL,'EXEC [fdm].[usp_LandingToInbound_RI_Percentage]',@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),
                                
								--Level 43
								(@IFRS17_Orchestration_NTL,431,'DataContract RIPercentage InboundToOutbound',@FK_ModuleType_SPNTL, 'EXEC [Inbound].[usp_InboundOutboundWorkflow_RIPercentage] '	,@IFRS17_InstanceName_NTL, 'FinanceDataContract', NULL, NULL),

								--Level 44
								(@IFRS17_Orchestration_NTL,441,'US Landing',@FK_ModuleType_SPNTL,'EXEC [us].[usp_LandingInboundWorkflow]'	,@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),								

								--Level 45
								(@IFRS17_Orchestration_NTL,451,'BICI LandToInbound',@FK_ModuleType_SPNTL,'EXEC [US].[usp_BICILandingToInboundWorkflow]'	,@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),								

								--Level 46
								(@IFRS17_Orchestration_NTL,461,'BIDAC LandToInbound',@FK_ModuleType_SPNTL,'EXEC [BIDAC].[usp_LandingInboundWorkflow]'	,@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),								

								--Level 47
								(@IFRS17_Orchestration_NTL,471,'USBAIC LandToInbound',@FK_ModuleType_SPNTL,'EXEC [US].[usp_BAICLandingToInboundWorkflow]'	,@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),								

								--Level 48
								(@IFRS17_Orchestration_NTL,481,'DataContract',@FK_ModuleType_SPNTL,'EXEC [Inbound].[usp_InboundOutboundWorkflow_GAAP]'  ,@IFRS17_InstanceName_NTL, 'Financedatacontract', NULL, NULL),								

								--Level 49
								(@IFRS17_Orchestration_NTL,491,'PFT Landing',@FK_ModuleType_SPNTL,'EXEC [pft].[usp_LandingToInboundToOutboundWorkflow]'	,@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),								

								--Level 50
								(@IFRS17_Orchestration_NTL,501,'DataContract',@FK_ModuleType_SPNTL,'EXEC [Inbound].[usp_InboundOutboundWorkflow]'	,@IFRS17_InstanceName_NTL, 'Financedatacontract', NULL, NULL),								

								--Level 51
								(@IFRS17_Orchestration_NTL,511,'DimTrifocus', @FK_ModuleType_SPNTL,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTrifocus.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL, 'SchedulingHub', null,	 NULL),
								(@IFRS17_Orchestration_NTL,512,'DimEntity',@FK_ModuleType_SPNTL,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimEntity.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_NTL,513,'DimYOA',@FK_ModuleType_SPNTL,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimYOA.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_NTL,514,'DimCCY',@FK_ModuleType_SPNTL,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimCCY.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL), 
								(@IFRS17_Orchestration_NTL,515,'DimProduct',@FK_ModuleType_SPNTL,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimProduct.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_NTL,516,'DimLocation',@FK_ModuleType_SPNTL,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimLocation.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_NTL,517,'Dummy Load',@FK_ModuleType_SPNTL,			'SELECT 1'	,@IFRS17_InstanceName_NTL, 'FinanceLanding', NULL, NULL),
								(@IFRS17_Orchestration_NTL,518,'DimAccount',@FK_ModuleType_SPNTL,			'SELECT 1'	,@IFRS17_InstanceName_NTL, 'TechnicalHub', NULL, NULL),
								(@IFRS17_Orchestration_NTL,519,'DimDataset',@FK_ModuleType_SPNTL,			'EXEC  [Dim].[MergeDatasetBR1]',@IFRS17_InstanceName_NTL, 'TechnicalHub', NULL, NULL),
								(@IFRS17_Orchestration_NTL,520,'DimPatternName',@FK_ModuleType_SPNTL,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPatternName.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_NTL,521,'DimCatCode',@FK_ModuleType_SPNTL,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimCatCode.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_NTL,522,'DimMovementType',@FK_ModuleType_SPNTL,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimMovementType.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_NTL,523,'DimAccountDtsx', @FK_ModuleType_SPNTL,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimAccount.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL, 'SchedulingHub', null,	 NULL),
								(@IFRS17_Orchestration_NTL,524,'DimClaimExposure', @FK_ModuleType_SPNTL,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimClaimExposure.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL, 'SchedulingHub', null,	 NULL),
								(@IFRS17_Orchestration_NTL,525,'DimPolicySection', @FK_ModuleType_SPNTL,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPolicySection.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL, 'SchedulingHub', null,	 NULL),

								--Level 52
								(@IFRS17_Orchestration_NTL,526,'DimTrackingStatus',@FK_ModuleType_SPNTL,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTrackingStatus.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_NTL,527,'DimRIPolicyType',@FK_ModuleType_SPNTL,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimRIPolicyType.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_NTL,528,'DimProgrammeCode',@FK_ModuleType_SPNTL,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimProgrammeCode.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_NTL,529,'DimTriangleGroup',@FK_ModuleType_SPNTL,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTriangleGroup.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_NTL,530,'DimReservingDataSet',@FK_ModuleType_SPNTL,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimReservingDataset.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_NTL,531,'DimRateScenario',@FK_ModuleType_SPNTL,	    'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimRateScenario.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_NTL,532,'DimReportingCurrency',@FK_ModuleType_SPNTL,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimReportingCurrency.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),

								--Level 53
								(@IFRS17_Orchestration_NTL,536,'IFRS2017TechResult',@FK_ModuleType_SPNTL,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactTechnicalResult_IFRS2017.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_NTL,537,'Fact Pattern',@FK_ModuleType_SPNTL,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactPattern.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_NTL,538,'Fact Discountrates',@FK_ModuleType_SPNTL,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactDiscountRates.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_NTL,539,'StandAlone Loads',@FK_ModuleType_SPNTL,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''StandaloneLoads.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),

								--Level 54
								(@IFRS17_Orchestration_NTL,546,'Tech Fact',@FK_ModuleType_SPNTL,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactTechnicalResult.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),

								--Level 55
								(@IFRS17_Orchestration_NTL,556,'Earning',@FK_ModuleType_SPNTL,		   'SELECT 1',@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),

								--Level 56
								(@IFRS17_Orchestration_NTL,566,'SideCar',@FK_ModuleType_SPNTL,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactSideCar.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),
								(@IFRS17_Orchestration_NTL,567,'FXRate'	,@FK_ModuleType_SPNTL,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactFxRates.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL),

							  --Level57
							  (@IFRS17_Orchestration_NTL,576,'ViewToTableFullRefresh'	,@FK_ModuleType_SPNTL,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17TechnicalResult_FullRefresh.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT',@IFRS17_InstanceName_NTL, 'SchedulingHub', NULL, NULL)

								
					)
						AS Source(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.PK_Module = Source.PK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
					VALUES(Source.FK_Orchestration,  Source.PK_module,  Source.ModuleName,  Source.FK_ModuleType,  Source.ModuleRoutine,  Source.DestinationServer,  Source.DestinationDatabase,Source.FK_Schedule,Source.FK_Notification)
			WHEN	MATCHED
			THEN	UPDATE SET		FK_Orchestration	= source.FK_Orchestration, 
									PK_module 			= source.PK_module, 
									ModuleName 			= source.ModuleName, 
									FK_ModuleType 		= source.FK_ModuleType, 
									ModuleRoutine 		= source.ModuleRoutine, 
									DestinationServer	= source.DestinationServer, 
									DestinationDatabase	= source.DestinationDatabase, 
									FK_Schedule 		= source.FK_Schedule, 
									FK_Notification		= source.FK_Notification
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_NTL
			THEN	DELETE;




			--ModuleHierarchy select * from etl.ModuleHierarchy
			MERGE 
			INTO	etl.ModuleHierarchy AS Target
			USING	(
						VALUES	--L1

								(@IFRS17_Orchestration_NTL,	NULL,	1,	1), --
								(@IFRS17_Orchestration_NTL,	NULL,	2,	1), -- 
								(@IFRS17_Orchestration_NTL,	NULL,	3,	1), --
								(@IFRS17_Orchestration_NTL,	NULL,	4,	1), -- 
								(@IFRS17_Orchestration_NTL,	NULL,	5,	1), --
								(@IFRS17_Orchestration_NTL,	NULL,	6,	1), -- 
								(@IFRS17_Orchestration_NTL,	NULL,	7,	1), --
								(@IFRS17_Orchestration_NTL,	NULL,	8,	1), --
								(@IFRS17_Orchestration_NTL,	NULL,	9,	1), --
								(@IFRS17_Orchestration_NTL,	NULL,	10,	1), --
								(@IFRS17_Orchestration_NTL,	NULL,	11,	1), --
								(@IFRS17_Orchestration_NTL,	NULL,	12,	1), --
								(@IFRS17_Orchestration_NTL,	NULL,	13,	1), --
								(@IFRS17_Orchestration_NTL,	NULL,	14,	1), --
								(@IFRS17_Orchestration_NTL,	NULL,	15,	1), --

								--L2
								(@IFRS17_Orchestration_NTL,NULL,	16, 2), --
								(@IFRS17_Orchestration_NTL,NULL,	17, 2), -- 
								(@IFRS17_Orchestration_NTL,NULL,    18, 2), --
								(@IFRS17_Orchestration_NTL,NULL,    19, 2), --
								(@IFRS17_Orchestration_NTL,NULL,    20, 2), --


						

								--L3
								(@IFRS17_Orchestration_NTL,	1,	27, 3),
								(@IFRS17_Orchestration_NTL,	2,	27, 3),
								(@IFRS17_Orchestration_NTL,	3,	27, 3),
								(@IFRS17_Orchestration_NTL,	4,	27,	3),
								(@IFRS17_Orchestration_NTL,	5,	27, 3),
								(@IFRS17_Orchestration_NTL,	6,	27, 3),
								(@IFRS17_Orchestration_NTL,	7,	27, 3),
								(@IFRS17_Orchestration_NTL,	8,	27, 3),
								(@IFRS17_Orchestration_NTL,	9,	27, 3),
								(@IFRS17_Orchestration_NTL,	10,	27,	3),
								(@IFRS17_Orchestration_NTL,	11,	27, 3),
								(@IFRS17_Orchestration_NTL,	12,	27, 3),
								(@IFRS17_Orchestration_NTL,	13,	27, 3),
								(@IFRS17_Orchestration_NTL,	14,	27, 3),
								(@IFRS17_Orchestration_NTL,	15,	27, 3),
								(@IFRS17_Orchestration_NTL,	16,	27, 3),
								(@IFRS17_Orchestration_NTL,	17,	27, 3),
								(@IFRS17_Orchestration_NTL,	18,	27, 3),
								(@IFRS17_Orchestration_NTL,	19,	27, 3),
								(@IFRS17_Orchestration_NTL,	20,	27, 3),


								

								(@IFRS17_Orchestration_NTL,	1,	28, 3),
								(@IFRS17_Orchestration_NTL,	2,	28, 3),
								(@IFRS17_Orchestration_NTL,	3,	28, 3),
								(@IFRS17_Orchestration_NTL,	4,	28,	3),
								(@IFRS17_Orchestration_NTL,	5,	28, 3),
								(@IFRS17_Orchestration_NTL,	6,	28, 3),
								(@IFRS17_Orchestration_NTL,	7,	28, 3),
								(@IFRS17_Orchestration_NTL,	8,	28, 3),
								(@IFRS17_Orchestration_NTL,	9,	28, 3),
								(@IFRS17_Orchestration_NTL,	10,	28,	3),
								(@IFRS17_Orchestration_NTL,	11,	28, 3),
								(@IFRS17_Orchestration_NTL,	12,	28, 3),
								(@IFRS17_Orchestration_NTL,	13,	28, 3),
								(@IFRS17_Orchestration_NTL,	14,	28, 3),
								(@IFRS17_Orchestration_NTL,	15,	28, 3),
								(@IFRS17_Orchestration_NTL,	16,	28, 3),
								(@IFRS17_Orchestration_NTL,	17,	28, 3),
								(@IFRS17_Orchestration_NTL,	18,	28, 3),
								(@IFRS17_Orchestration_NTL,	19,	28, 3),
								(@IFRS17_Orchestration_NTL,	20,	28, 3),



								(@IFRS17_Orchestration_NTL,	1,	29, 3),
								(@IFRS17_Orchestration_NTL,	2,	29, 3),
								(@IFRS17_Orchestration_NTL,	3,	29, 3),
								(@IFRS17_Orchestration_NTL,	4,	29,	3),
								(@IFRS17_Orchestration_NTL,	5,	29, 3),
								(@IFRS17_Orchestration_NTL,	6,	29, 3),
								(@IFRS17_Orchestration_NTL,	7,	29, 3),
								(@IFRS17_Orchestration_NTL,	8,	29, 3),
								(@IFRS17_Orchestration_NTL,	9,	29, 3),
								(@IFRS17_Orchestration_NTL,	10,	29,	3),
								(@IFRS17_Orchestration_NTL,	11,	29, 3),
								(@IFRS17_Orchestration_NTL,	12,	29, 3),
								(@IFRS17_Orchestration_NTL,	13,	29, 3),
								(@IFRS17_Orchestration_NTL,	14,	29, 3),
								(@IFRS17_Orchestration_NTL,	15,	29, 3),
								(@IFRS17_Orchestration_NTL,	16,	29, 3),
								(@IFRS17_Orchestration_NTL,	17,	29, 3),
								(@IFRS17_Orchestration_NTL,	18,	29, 3),
								(@IFRS17_Orchestration_NTL,	19,	29, 3),
								(@IFRS17_Orchestration_NTL,	20,	29, 3),



								(@IFRS17_Orchestration_NTL,	1,	30, 3),
								(@IFRS17_Orchestration_NTL,	2,	30, 3),
								(@IFRS17_Orchestration_NTL,	3,	30, 3),
								(@IFRS17_Orchestration_NTL,	4,	30,	3),
								(@IFRS17_Orchestration_NTL,	5,	30, 3),
								(@IFRS17_Orchestration_NTL,	6,	30, 3),
								(@IFRS17_Orchestration_NTL,	7,	30, 3),
								(@IFRS17_Orchestration_NTL,	8,	30, 3),
								(@IFRS17_Orchestration_NTL,	9,	30, 3),
								(@IFRS17_Orchestration_NTL,	10,	30,	3),
								(@IFRS17_Orchestration_NTL,	11,	30, 3),
								(@IFRS17_Orchestration_NTL,	12,	30, 3),
								(@IFRS17_Orchestration_NTL,	13,	30, 3),
								(@IFRS17_Orchestration_NTL,	14,	30, 3),
								(@IFRS17_Orchestration_NTL,	15,	30, 3),
								(@IFRS17_Orchestration_NTL,	16,	30, 3),
								(@IFRS17_Orchestration_NTL,	17,	30, 3),
								(@IFRS17_Orchestration_NTL,	18,	30, 3),
								(@IFRS17_Orchestration_NTL,	19,	30, 3),
								(@IFRS17_Orchestration_NTL,	20,	30, 3),



								(@IFRS17_Orchestration_NTL,	1,	31, 3),
								(@IFRS17_Orchestration_NTL,	2,	31, 3),
								(@IFRS17_Orchestration_NTL,	3,	31, 3),
								(@IFRS17_Orchestration_NTL,	4,	31,	3),
								(@IFRS17_Orchestration_NTL,	5,	31, 3),
								(@IFRS17_Orchestration_NTL,	6,	31, 3),
								(@IFRS17_Orchestration_NTL,	7,	31, 3),
								(@IFRS17_Orchestration_NTL,	8,	31, 3),
								(@IFRS17_Orchestration_NTL,	9,	31, 3),
								(@IFRS17_Orchestration_NTL,	10,	31,	3),
								(@IFRS17_Orchestration_NTL,	11,	31, 3),
								(@IFRS17_Orchestration_NTL,	12,	31, 3),
								(@IFRS17_Orchestration_NTL,	13,	31, 3),
								(@IFRS17_Orchestration_NTL,	14,	31, 3),
								(@IFRS17_Orchestration_NTL,	15,	31, 3),
								(@IFRS17_Orchestration_NTL,	16,	31, 3),
								(@IFRS17_Orchestration_NTL,	17,	31, 3),
								(@IFRS17_Orchestration_NTL,	18,	31, 3),
								(@IFRS17_Orchestration_NTL,	19,	31, 3),
								(@IFRS17_Orchestration_NTL,	20,	31, 3),



								(@IFRS17_Orchestration_NTL,	1,	32, 3),
								(@IFRS17_Orchestration_NTL,	2,	32, 3),
								(@IFRS17_Orchestration_NTL,	3,	32, 3),
								(@IFRS17_Orchestration_NTL,	4,	32,	3),
								(@IFRS17_Orchestration_NTL,	5,	32, 3),
								(@IFRS17_Orchestration_NTL,	6,	32, 3),
								(@IFRS17_Orchestration_NTL,	7,	32, 3),
								(@IFRS17_Orchestration_NTL,	8,	32, 3),
								(@IFRS17_Orchestration_NTL,	9,	32, 3),
								(@IFRS17_Orchestration_NTL,	10,	32,	3),
								(@IFRS17_Orchestration_NTL,	11,	32, 3),
								(@IFRS17_Orchestration_NTL,	12,	32, 3),
								(@IFRS17_Orchestration_NTL,	13,	32, 3),
								(@IFRS17_Orchestration_NTL,	14,	32, 3),
								(@IFRS17_Orchestration_NTL,	15,	32, 3),
								(@IFRS17_Orchestration_NTL,	16,	32, 3),
								(@IFRS17_Orchestration_NTL,	17,	32, 3),
								(@IFRS17_Orchestration_NTL,	18,	32, 3),
								(@IFRS17_Orchestration_NTL,	19,	32, 3),
								(@IFRS17_Orchestration_NTL,	20,	32, 3),




								--L4
								
								(@IFRS17_Orchestration_NTL,	27,	41, 4),
								(@IFRS17_Orchestration_NTL,	28,	41, 4),
								(@IFRS17_Orchestration_NTL,	29,	41, 4),
								(@IFRS17_Orchestration_NTL,	30,	41, 4),
								(@IFRS17_Orchestration_NTL,	31,	41, 4),
								(@IFRS17_Orchestration_NTL,	32,	41, 4),
								

								
								--L5
								(@IFRS17_Orchestration_NTL,	41,	51, 5),

								
								--L6
								(@IFRS17_Orchestration_NTL,	51,	61, 6),

								--L7
								(@IFRS17_Orchestration_NTL,	61,	71, 7),
								
								--L8
								(@IFRS17_Orchestration_NTL,	71,	81, 8),
								
								--L9
								(@IFRS17_Orchestration_NTL,	81,	91, 9),
								
								--L10
								(@IFRS17_Orchestration_NTL,	91,	101, 10),
								
								--L11
								(@IFRS17_Orchestration_NTL,	101,111, 11), 
								
								--L12
								(@IFRS17_Orchestration_NTL,	111,121, 12),  
								
								--L13
								(@IFRS17_Orchestration_NTL,	121,131, 13),
								
								--L14
								(@IFRS17_Orchestration_NTL,131,141, 14),  
								
								--L15
								(@IFRS17_Orchestration_NTL,141,151,	15),
								(@IFRS17_Orchestration_NTL,141,152,	15),

								
								--L16
								(@IFRS17_Orchestration_NTL,151,161,	16),
								(@IFRS17_Orchestration_NTL,151,162,	16),

								(@IFRS17_Orchestration_NTL,152,161,	16),
								(@IFRS17_Orchestration_NTL,152,162,	16),
								
								--L17
								(@IFRS17_Orchestration_NTL,	161,171,17),
								(@IFRS17_Orchestration_NTL,	162,171,17),


								--L18
								(@IFRS17_Orchestration_NTL,	171,181,18),
								
								--L19
								(@IFRS17_Orchestration_NTL,	181,191,19),
							
								--L20
								(@IFRS17_Orchestration_NTL,	191,201,20),
							
								--L21
								(@IFRS17_Orchestration_NTL,201,211,21),
								
								--L22
								(@IFRS17_Orchestration_NTL,211,221,22),
								
								--L23
								(@IFRS17_Orchestration_NTL,221,231,23),

								--L24
								(@IFRS17_Orchestration_NTL,231,241,24),

								--L25
								(@IFRS17_Orchestration_NTL,241,251,25),

								--L26
								(@IFRS17_Orchestration_NTL,251,261,26),

								--L27
								(@IFRS17_Orchestration_NTL,261,271,27),

								--L28
								(@IFRS17_Orchestration_NTL,271,281,28),
								(@IFRS17_Orchestration_NTL,271,282,28),


								--L29
								(@IFRS17_Orchestration_NTL,281,291,29),
								(@IFRS17_Orchestration_NTL,282,291,29),


								--L30
								(@IFRS17_Orchestration_NTL,291,301,30),

								--L31
								(@IFRS17_Orchestration_NTL,301,311,	31),

								--L32
								(@IFRS17_Orchestration_NTL,311,321,	32),

								--L33
								(@IFRS17_Orchestration_NTL,	321,331,33),

								--L34
								(@IFRS17_Orchestration_NTL,331,341,34),

								--L35
								(@IFRS17_Orchestration_NTL,341,351,35),
								(@IFRS17_Orchestration_NTL,341,352,35),


								--L36
								(@IFRS17_Orchestration_NTL,351,361,36),
								(@IFRS17_Orchestration_NTL,352,361,36),


								--L37
								(@IFRS17_Orchestration_NTL,361,371,37),
								(@IFRS17_Orchestration_NTL,361,372,37),


								--L38
								(@IFRS17_Orchestration_NTL,371,381,38),
								(@IFRS17_Orchestration_NTL,371,382,38),

								(@IFRS17_Orchestration_NTL,372,381,38),
								(@IFRS17_Orchestration_NTL,372,382,38),


								--L39
								(@IFRS17_Orchestration_NTL,	381,391,39),
								(@IFRS17_Orchestration_NTL,	382,391,39),


								--L40
								(@IFRS17_Orchestration_NTL,391,401,40),

								--L41
								(@IFRS17_Orchestration_NTL,401,411,41),

								--L42
								(@IFRS17_Orchestration_NTL,411,421,42),

								--L43
								(@IFRS17_Orchestration_NTL,421,431,43),

								--L44
								(@IFRS17_Orchestration_NTL,431,441,44),

								--L45
								(@IFRS17_Orchestration_NTL,441,451,45),

								--L46
								(@IFRS17_Orchestration_NTL,451,461,46),

								--L47
								(@IFRS17_Orchestration_NTL,461,471,47),

								--L48
								(@IFRS17_Orchestration_NTL,471,481,48),

								--L49
								(@IFRS17_Orchestration_NTL,481,491,49),

								--L50
								(@IFRS17_Orchestration_NTL,491,501,50),

								


								--L51 --Dims
							
								(@IFRS17_Orchestration_NTL,	501,	511,		51), 
								(@IFRS17_Orchestration_NTL,	501,	512,		51),
								(@IFRS17_Orchestration_NTL,	501,	513,		51),
								(@IFRS17_Orchestration_NTL,	501,	514,		51), 
								(@IFRS17_Orchestration_NTL,	501,	515,		51),
								(@IFRS17_Orchestration_NTL,	501,	516,		51),
								(@IFRS17_Orchestration_NTL,	501,	517,		51), 
								(@IFRS17_Orchestration_NTL,	501,	518,		51),
								(@IFRS17_Orchestration_NTL,	501,	519,		51),
								(@IFRS17_Orchestration_NTL,	501,	520,		51), 
								(@IFRS17_Orchestration_NTL,	501,	521,		51),
								(@IFRS17_Orchestration_NTL,	501,	522,		51),
								(@IFRS17_Orchestration_NTL,	501,	523,		51), 
								(@IFRS17_Orchestration_NTL,	501,	524,		51),
								(@IFRS17_Orchestration_NTL,	501,	525,		51),

								--L52
								(@IFRS17_Orchestration_NTL,		511, 526,		52), 
								(@IFRS17_Orchestration_NTL,		512, 526,		52),
								(@IFRS17_Orchestration_NTL,		513, 526,		52),
								(@IFRS17_Orchestration_NTL,		514, 526,		52), 
								(@IFRS17_Orchestration_NTL,		515, 526,		52),
								(@IFRS17_Orchestration_NTL,		516, 526,		52),
								(@IFRS17_Orchestration_NTL,		517, 526,		52), 
								(@IFRS17_Orchestration_NTL,		518, 526,		52),
								(@IFRS17_Orchestration_NTL,		519, 526,		52),
								(@IFRS17_Orchestration_NTL,		520, 526,		52), 
								(@IFRS17_Orchestration_NTL,		521, 526,		52),
								(@IFRS17_Orchestration_NTL,		522, 526,		52),
								(@IFRS17_Orchestration_NTL,		523, 526,		52), 
								(@IFRS17_Orchestration_NTL,		524, 526,		52),
								(@IFRS17_Orchestration_NTL,		525, 526,		52),

								(@IFRS17_Orchestration_NTL,		511, 527,		52), 
								(@IFRS17_Orchestration_NTL,		512, 527,		52),
								(@IFRS17_Orchestration_NTL,		513, 527,		52),
								(@IFRS17_Orchestration_NTL,		514, 527,		52), 
								(@IFRS17_Orchestration_NTL,		515, 527,		52),
								(@IFRS17_Orchestration_NTL,		516, 527,		52),
								(@IFRS17_Orchestration_NTL,		517, 527,		52), 
								(@IFRS17_Orchestration_NTL,		518, 527,		52),
								(@IFRS17_Orchestration_NTL,		519, 527,		52),
								(@IFRS17_Orchestration_NTL,		520, 527,		52), 
								(@IFRS17_Orchestration_NTL,		521, 527,		52),
								(@IFRS17_Orchestration_NTL,		522, 527,		52),
								(@IFRS17_Orchestration_NTL,		523, 527,		52), 
								(@IFRS17_Orchestration_NTL,		524, 527,		52),
								(@IFRS17_Orchestration_NTL,		525, 527,		52),

								(@IFRS17_Orchestration_NTL,		511, 528,		52), 
								(@IFRS17_Orchestration_NTL,		512, 528,		52),
								(@IFRS17_Orchestration_NTL,		513, 528,		52),
								(@IFRS17_Orchestration_NTL,		514, 528,		52), 
								(@IFRS17_Orchestration_NTL,		515, 528,		52),
								(@IFRS17_Orchestration_NTL,		516, 528,		52),
								(@IFRS17_Orchestration_NTL,		517, 528,		52), 
								(@IFRS17_Orchestration_NTL,		518, 528,		52),
								(@IFRS17_Orchestration_NTL,		519, 528,		52),
								(@IFRS17_Orchestration_NTL,		520, 528,		52), 
								(@IFRS17_Orchestration_NTL,		521, 528,		52),
								(@IFRS17_Orchestration_NTL,		522, 528,		52),
								(@IFRS17_Orchestration_NTL,		523, 528,		52), 
								(@IFRS17_Orchestration_NTL,		524, 528,		52),
								(@IFRS17_Orchestration_NTL,		525, 528,		52),

								(@IFRS17_Orchestration_NTL,		511, 529,		52), 
								(@IFRS17_Orchestration_NTL,		512, 529,		52),
								(@IFRS17_Orchestration_NTL,		513, 529,		52),
								(@IFRS17_Orchestration_NTL,		514, 529,		52), 
								(@IFRS17_Orchestration_NTL,		515, 529,		52),
								(@IFRS17_Orchestration_NTL,		516, 529,		52),
								(@IFRS17_Orchestration_NTL,		517, 529,		52), 
								(@IFRS17_Orchestration_NTL,		518, 529,		52),
								(@IFRS17_Orchestration_NTL,		519, 529,		52),
								(@IFRS17_Orchestration_NTL,		520, 529,		52), 
								(@IFRS17_Orchestration_NTL,		521, 529,		52),
								(@IFRS17_Orchestration_NTL,		522, 529,		52),
								(@IFRS17_Orchestration_NTL,		523, 529,		52), 
								(@IFRS17_Orchestration_NTL,		524, 529,		52),
								(@IFRS17_Orchestration_NTL,		525, 529,		52),

								(@IFRS17_Orchestration_NTL,		511, 530,		52), 
								(@IFRS17_Orchestration_NTL,		512, 530,		52),
								(@IFRS17_Orchestration_NTL,		513, 530,		52),
								(@IFRS17_Orchestration_NTL,		514, 530,		52), 
								(@IFRS17_Orchestration_NTL,		515, 530,		52),
								(@IFRS17_Orchestration_NTL,		516, 530,		52),
								(@IFRS17_Orchestration_NTL,		517, 530,		52), 
								(@IFRS17_Orchestration_NTL,		518, 530,		52),
								(@IFRS17_Orchestration_NTL,		519, 530,		52),
								(@IFRS17_Orchestration_NTL,		520, 530,		52), 
								(@IFRS17_Orchestration_NTL,		521, 530,		52),
								(@IFRS17_Orchestration_NTL,		522, 530,		52),
								(@IFRS17_Orchestration_NTL,		523, 530,		52), 
								(@IFRS17_Orchestration_NTL,		524, 530,		52),
								(@IFRS17_Orchestration_NTL,		525, 530,		52),

								(@IFRS17_Orchestration_NTL,		511, 531,		52), 
								(@IFRS17_Orchestration_NTL,		512, 531,		52),
								(@IFRS17_Orchestration_NTL,		513, 531,		52),
								(@IFRS17_Orchestration_NTL,		514, 531,		52), 
								(@IFRS17_Orchestration_NTL,		515, 531,		52),
								(@IFRS17_Orchestration_NTL,		516, 531,		52),
								(@IFRS17_Orchestration_NTL,		517, 531,		52), 
								(@IFRS17_Orchestration_NTL,		518, 531,		52),
								(@IFRS17_Orchestration_NTL,		519, 531,		52),
								(@IFRS17_Orchestration_NTL,		520, 531,		52), 
								(@IFRS17_Orchestration_NTL,		521, 531,		52),
								(@IFRS17_Orchestration_NTL,		522, 531,		52),
								(@IFRS17_Orchestration_NTL,		523, 531,		52), 
								(@IFRS17_Orchestration_NTL,		524, 531,		52),
								(@IFRS17_Orchestration_NTL,		525, 531,		52),

								(@IFRS17_Orchestration_NTL,		511, 532,		52), 
								(@IFRS17_Orchestration_NTL,		512, 532,		52),
								(@IFRS17_Orchestration_NTL,		513, 532,		52),
								(@IFRS17_Orchestration_NTL,		514, 532,		52), 
								(@IFRS17_Orchestration_NTL,		515, 532,		52),
								(@IFRS17_Orchestration_NTL,		516, 532,		52),
								(@IFRS17_Orchestration_NTL,		517, 532,		52), 
								(@IFRS17_Orchestration_NTL,		518, 532,		52),
								(@IFRS17_Orchestration_NTL,		519, 532,		52),
								(@IFRS17_Orchestration_NTL,		520, 532,		52), 
								(@IFRS17_Orchestration_NTL,		521, 532,		52),
								(@IFRS17_Orchestration_NTL,		522, 532,		52),
								(@IFRS17_Orchestration_NTL,		523, 532,		52), 
								(@IFRS17_Orchestration_NTL,		524, 532,		52),
								(@IFRS17_Orchestration_NTL,		525, 532,		52),
								
								--L53

								(@IFRS17_Orchestration_NTL,	526,	536,		53), 
								(@IFRS17_Orchestration_NTL,	527,	536,		53),
								(@IFRS17_Orchestration_NTL,	528,	536,		53),
								(@IFRS17_Orchestration_NTL,	529,	536,		53), 
								(@IFRS17_Orchestration_NTL,	530,	536,		53),
								(@IFRS17_Orchestration_NTL,	531,	536,		53),
								(@IFRS17_Orchestration_NTL,	532,	536,		53),

								(@IFRS17_Orchestration_NTL,	526,	537,		53), 
								(@IFRS17_Orchestration_NTL,	527,	537,		53),
								(@IFRS17_Orchestration_NTL,	528,	537,		53),
								(@IFRS17_Orchestration_NTL,	529,	537,		53), 
								(@IFRS17_Orchestration_NTL,	530,	537,		53),
								(@IFRS17_Orchestration_NTL,	531,	537,		53),
								(@IFRS17_Orchestration_NTL,	532,	537,		53),
								
								(@IFRS17_Orchestration_NTL,	526,	538,		53), 
								(@IFRS17_Orchestration_NTL,	527,	538,		53),
								(@IFRS17_Orchestration_NTL,	528,	538,		53),
								(@IFRS17_Orchestration_NTL,	529,	538,		53), 
								(@IFRS17_Orchestration_NTL,	530,	538,		53),
								(@IFRS17_Orchestration_NTL,	531,	538,		53),
								(@IFRS17_Orchestration_NTL,	532,	538,		53),
								
								(@IFRS17_Orchestration_NTL,	526,	539,		53), 
								(@IFRS17_Orchestration_NTL,	527,	539,		53),
								(@IFRS17_Orchestration_NTL,	528,	539,		53),
								(@IFRS17_Orchestration_NTL,	529,	539,		53), 
								(@IFRS17_Orchestration_NTL,	530,	539,		53),
								(@IFRS17_Orchestration_NTL,	531,	539,		53),
								(@IFRS17_Orchestration_NTL,	532,	539,		53),



								--L54
								(@IFRS17_Orchestration_NTL,	536,	546,		54), 
								(@IFRS17_Orchestration_NTL,	537,	546,		54),
								(@IFRS17_Orchestration_NTL,	538,	546,		54),
								(@IFRS17_Orchestration_NTL,	539,	546,		54), 

								--L55
								(@IFRS17_Orchestration_NTL,	546,	556,		55), 

								--L56
								(@IFRS17_Orchestration_NTL,	556,	566,		56),
								(@IFRS17_Orchestration_NTL,	556,	567,		56),

								--L57
								(@IFRS17_Orchestration_NTL,	566,	576,		57),
								(@IFRS17_Orchestration_NTL,	567,	576,		57)


-- SSIS packages
--IFRS17_ADMToLandingExtract.dtsx -- > [ADM].[usp_LandingToInbound] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow
--								  -- > [ADM].[usp_LandingToInbound_Pattern] --> FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_Pattern			

--IFRS17_AgressoToLandingExtract.dtsx -- on hold

--IFRS17_BICCToLandingExtract.dtsx -- > [BICC].[usp_LandingToInbound] -- > assume FinanceDataContract.Inbound.usp_InboundOutboundWorkflow but unit test has changed or not there. Ciprian will update me.
--IFRS17_EIOPAToLandingExtract.dtsx -- > [XLS].[usp_EIOPALandingToInbound_DiscountRates] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_DiscountRates
--IFRS17_EurobaseToLandingExtract.dtsx -- > [Eurobase].[usp_LandingToInbound_EPI] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow
--										-- > [Eurobase].[usp_LandingToInbound] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow

-- needs to be added
--IFRS17_LossRatioToLandingExtract.dtsx -- > [XLS].[usp_LandingToInbound_LossRatio] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_LossRatio

--IFRS17_MDSToLandingExtract.dtsx -- > [MDS].[usp_LandingToInbound] -- > no outbound required

--check this!
--IFRS17_NatCatEarningToLandingExtract.dtsx -- > [XLS].[usp_NatCatEarningLandingToInbound_Pattern] -- > FinanceDataContract.Inbound.usp_InboundOutboundWorkflow_Pattern


					) AS Source(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.FK_ChildModule = Source.FK_ChildModule
				AND Target.FK_ParentModule = Source.FK_ParentModule
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
					VALUES(Source.FK_Orchestration,Source.FK_ParentModule,Source.FK_ChildModule,Source.TreeLevel)
			WHEN	MATCHED
			THEN	UPDATE SET	FK_Orchestration = source.FK_Orchestration, 
								FK_ParentModule = source.FK_ParentModule, 
								FK_ChildModule = source.FK_ChildModule, 
								TreeLevel = source.TreeLevel
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_NTL
			THEN	DELETE;






			--ModuleActivity select * from etl.ModuleActivity
			MERGE	etl.ModuleActivity Target
			USING	(
						SELECT	m.FK_Orchestration,
								m.PK_Module,
								1, -- Pending
								'Initialization from deployment' -- run description
						FROM	etl.Module m
						WHERE	m.FK_Orchestration = @IFRS17_Orchestration_NTL
					) Source (FK_Orchestration, FK_Module, FK_ModuleStatus,RunDescription)
			ON		Source.FK_Orchestration = Target.FK_Orchestration
				AND	Source.FK_Module = Target.FK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT	(FK_Orchestration, FK_Module, FK_ModuleStatus, RunDescription)
					VALUES	(Source.FK_Orchestration, Source.FK_Module, Source.FK_ModuleStatus, Source.RunDescription)
			WHEN	MATCHED
			THEN	UPDATE	SET	Target.FK_ModuleStatus = Source.FK_ModuleStatus, Target.RunDescription = Source.RunDescription
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = @IFRS17_Orchestration_NTL
			THEN	DELETE;


