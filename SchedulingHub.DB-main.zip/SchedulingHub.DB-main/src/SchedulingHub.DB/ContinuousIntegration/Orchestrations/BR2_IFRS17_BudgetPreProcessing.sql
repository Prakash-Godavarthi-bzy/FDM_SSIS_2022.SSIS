﻿/*MERGE
INTO etl.Orchestration AS Target
USING (VALUES(19, 'BR2_IFRS17_BudgetPreProcessing',0)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled)
ON (Target.PK_Orchestration = Source.PK_Orchestration)
WHEN NOT MATCHED BY TARGET
THEN INSERT(PK_Orchestration,OrchestrationName,IsEnabled)
VALUES(Source.PK_Orchestration, Source.OrchestrationName, Source.IsEnabled)
WHEN MATCHED
THEN UPDATE SET Target.ORchestrationName = Source.OrchestrationName,
Target.IsEnabled = Source.Isenabled;
*/