﻿Delete from etl.ModuleHierarchy where FK_Orchestration=5
Delete from etl.ModuleActivity where FK_Orchestration=5
Delete From etl.Module where FK_Orchestration=5
				MERGE 
			INTO	etl.Orchestration AS Target
			USING	(VALUES(5, 'Premium Result',0)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled)
			ON		(Target.PK_Orchestration = Source.PK_Orchestration)
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(PK_Orchestration,OrchestrationName,IsEnabled)
					VALUES(Source.PK_Orchestration,  Source.OrchestrationName,  Source.IsEnabled)
			WHEN	MATCHED
			THEN	UPDATE SET	Target.ORchestrationName = Source.OrchestrationName,
								Target.IsEnabled = Source.Isenabled;

			MERGE 
			INTO	etl.Module AS Target
			USING	(
						VALUES	--Level 1
								(5,1,'Eurobase',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''EurobaseEPI.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								(5,2,'EB Trifocus', 1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FDMTrifocusCode.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(5,13,'US Premium',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''USPremium.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								(5,16,'PFT Forecast',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''PremiumForecastLanding.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								(5,26,'Fake Data',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_FakeDataToLanding.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExcelImport=1, @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								(5,40,'BICI Landing',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BICILanding.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExcelImport=1, @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								(5,41,'BIDAC Landing',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_BIDACLanding.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExcelImport=1, @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								(5,42,'USBAIC Landing',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''IFRS17_USBAICLanding.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExcelImport=1, @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
								(5,43,'USSYND Landing',1,		'SELECT 1','$(InstanceName)', 'SchedulingHub', NULL, NULL),

								--Level 2
								(5,3,'EB Landing', 1,			'EXEC [eb].[USP_LandingInboundWorkflow]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								(5,70,'Dummy Job', 1,			'SELECT 1','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								--Level 3
								(5,14,'US Landing', 1,			'EXEC [us].[usp_LandingInboundWorkflow]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								(5,17,'PFT Landing', 1,			'EXEC [pft].[usp_LandingInboundWorkflow]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								(5,27,'Fake Data Landing', 1,	'EXEC [FA].[usp_LandingInboundFakeDataWorkflow]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								(5,50,'BICI LandToInbound', 1,	'EXEC [US].[usp_BICILandingToInboundWorkflow]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								(5,51,'BIDAC LandToInbound', 1,	'EXEC [BIDAC].[usp_LandingInboundWorkflow]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								(5,52,'USBAIC LandToInbound', 1,	'EXEC [US].[usp_BAICLandingToInboundWorkflow]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								(5,53,'USSYND LandToInbound', 1,	'SELECT 1','$(InstanceName)', 'FinanceLanding', NULL, NULL),
								--Level 4
								(5,4,'DataContract',1,			'EXEC [Inbound].[usp_InboundOutboundWorkflow]'	,'$(InstanceName)', 'FinanceDataContract', NULL, NULL),
								(5,90,'DataContract',1,			'EXEC [Inbound].[usp_InboundOutboundWorkflow_GAAP]'	,'$(InstanceName)', 'FinanceDataContract', NULL, NULL),
								--level 5
								(5,5,'DimTrifocus', 1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTrifocus.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,	 NULL),
								(5,6,'DimEntity',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimEntity.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(5,7,'DimYOA',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimYOA.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(5,8,'DimCCY',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimCCY.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL), 
								(5,9,'DimProduct',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimProduct.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(5,10,'DimLocation',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimLocation.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								--(5,11,'Dim Policy',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPolicy.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(5,11,'Dummy Load',1,			'SELECT 1'	,'$(InstanceName)', 'FinanceDataContract', NULL, NULL),
								(5,28,'DimRateScenario',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimRateScenario.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(5,29,'DimReportingCurrency',1,	'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimReportingCurrency.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(5,32,'DimPolicySection',1,		'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPolicySection.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'	,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(5,60,'DimDataset',1,			'EXEC  [Dim].[MergeDatasetBR1]','$(InstanceName)', 'TechnicalHub', NULL, NULL),

								--Level 6
								(5,12,'Tech Fact',1,			'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactTechnicalResult.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								--Level 7
								(5,15,'Earning',1,				'SELECT 1','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								--Level 8
								(5,18,'SideCar',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactSideCar.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								(5,30,'FXRate',1,				'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactFxRates.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								--Level 9
								(5,31,'Post Initial and Subsequment',1,			'SELECT 1 --EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''Post Fact Initial Subsequent.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
								--Level 10
								(5,25,'Cube Process',1,			'SELECT 1 --EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''CubeBuild.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL)
					)

						AS Source(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.PK_Module = Source.PK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
					VALUES(Source.FK_Orchestration,  Source.PK_module,  Source.ModuleName,  Source.FK_ModuleType,  Source.ModuleRoutine,  Source.DestinationServer,  Source.DestinationDatabase,Source.FK_Schedule,Source.FK_Notification)
			WHEN	MATCHED
			THEN	UPDATE SET		FK_Orchestration	= source.FK_Orchestration, 
									PK_module 			= source.PK_module, 
									ModuleName 			= source.ModuleName, 
									FK_ModuleType 		= source.FK_ModuleType, 
									ModuleRoutine 		= source.ModuleRoutine, 
									DestinationServer	= source.DestinationServer, 
									DestinationDatabase	= source.DestinationDatabase, 
									FK_Schedule 		= source.FK_Schedule, 
									FK_Notification		= source.FK_Notification
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = 5
			THEN	DELETE;

			MERGE 
			INTO	etl.ModuleHierarchy AS Target
			USING	(
						VALUES	--L1
								(5,	NULL,	1,	1),
								(5,	NULL,	2,	1), 
								(5,	NULL,	13,	1),
								(5,	NULL,	16,	1),
								(5,	NULL,	26,	1),
								(5,	NULL,	40,	1),
								(5,	NULL,	41,	1),
								(5,	NULL,	42,	1),
								(5,	NULL,	43,	1),

								--L2
								(5,	1,	3,	2),
								(5,	2,	3,	2),
								(5,	13,	3,	2),
								(5,	16,	3,	2),
								(5,	26,	3,	2),
								(5,	40,	3,	2),
								(5,	41,	3,	2),
								(5,	42,	3,	2),
								(5,	43,	3,	2),

								(5,	1,	70,	2),
								(5,	2,	70,	2),
								(5,	13,	70,	2),
								(5,	16,	70,	2),
								(5,	26,	70,	2),
								(5,	40,	70,	2),
								(5,	41,	70,	2),
								(5,	42,	70,	2),
								(5,	43,	70,	2),
								--L3
								(5,	3,	14,	3),
								(5,	3,	17,	3),
								(5,	3,	27,	3),
								(5,	3,	50,	3),
								(5,	3,	51,	3),
								(5,	3,	52,	3),
								(5,	3,	53,	3),

								(5,	70,	14,	3),
								(5,	70,	17,	3),
								(5,	70,	27,	3),
								(5,	70,	50,	3),
								(5,	70,	51,	3),
								(5,	70,	52,	3),
								(5,	70,	53,	3),
								
								--L4
								--(5,	3,	4,	4),
								(5,	14,	4,	4),
								(5,	17,	4,	4),
								(5,	27,	4,	4),
								(5,	50,	4,	4),
								(5,	51,	4,	4),
								(5,	52,	4,	4),
								(5,	53,	4,	4),

								(5,	14,	90,	4),
								(5,	17,	90,	4),
								(5,	27,	90,	4),
								(5,	50,	90,	4),
								(5,	51,	90,	4),
								(5,	52,	90,	4),
								(5,	53,	90,	4),
								
								--L5
								(5,	4,	5,	5),
								(5,	4,	6,	5),
								(5,	4,	7,	5),
								(5,	4,	8,	5),
								(5,	4,	9,	5),
								(5,	4,	10,	5),
								(5,	4,	11,	5),
								(5,	4,	28,	5),
								(5,	4,	29,	5),
								(5,	4,	32,	5),
								(5,	4,	60,	5),

								(5,	90,	5,	5),
								(5,	90,	6,	5),
								(5,	90,	7,	5),
								(5,	90,	8,	5),
								(5,	90,	9,	5),
								(5,	90,	10,	5),
								(5,	90,	11,	5),
								(5,	90,	28,	5),
								(5,	90,	29,	5),
								(5,	90,	32,	5),
								(5,	90,	60,	5),

								

								--L6
								(5,	5,	12,	6),
								(5,	6,	12,	6),
								(5,	7,	12,	6),
								(5,	8,	12,	6),
								(5,	9,	12,	6),
								(5,	10,	12,	6),
								(5,	11,	12,	6),
								(5,	28,	12,	6),
								(5,	29,	12,	6),
								(5,	32,	12,	6),
								(5,	60,	12,	6),

								--L7
								(5,	12,	15,	7),
								--L8
								(5,	15,	18,	8),
								(5, 15, 30, 8),
								--L9
								(5, 18, 31, 9),
								(5, 30, 31, 9),
								--L10
								(5, 31, 25, 10)


					) AS Source(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
			ON		Target.FK_Orchestration = Source.FK_Orchestration
				AND Target.FK_ChildModule = Source.FK_ChildModule
				AND Target.FK_ParentModule = Source.FK_ParentModule
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
					VALUES(Source.FK_Orchestration,Source.FK_ParentModule,Source.FK_ChildModule,Source.TreeLevel)
			WHEN	MATCHED
			THEN	UPDATE SET	FK_Orchestration = source.FK_Orchestration, 
								FK_ParentModule = source.FK_ParentModule, 
								FK_ChildModule = source.FK_ChildModule, 
								TreeLevel = source.TreeLevel
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = 5
			THEN	DELETE;


			MERGE	etl.ModuleActivity Target
			USING	(
						SELECT	m.FK_Orchestration,
								m.PK_Module,
								1
						FROM	etl.Module m
						WHERE	m.FK_Orchestration = 5
					) Source (FK_Orchestration, FK_Module, FK_ModuleStatus)
			ON		Source.FK_Orchestration = Target.FK_Orchestration
				AND	Source.FK_Module = Target.FK_Module
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT	(FK_Orchestration, FK_Module, FK_ModuleStatus)
					VALUES	(Source.FK_Orchestration, Source.FK_Module, Source.FK_ModuleStatus)
			WHEN	MATCHED
			THEN	UPDATE	SET	Target.FK_ModuleStatus = Source.FK_ModuleStatus
			WHEN	NOT MATCHED BY SOURCE AND target.fk_Orchestration = 5
			THEN	DELETE;


