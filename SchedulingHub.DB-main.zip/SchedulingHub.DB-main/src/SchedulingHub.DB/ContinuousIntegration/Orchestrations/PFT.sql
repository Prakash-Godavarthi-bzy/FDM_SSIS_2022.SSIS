﻿MERGE 
                     INTO   etl.Orchestration AS Target
                     USING  (VALUES(7, 'PFTLoad',1)) AS Source(PK_Orchestration, OrchestrationName,IsEnabled)
                     ON            (Target.PK_Orchestration = Source.PK_Orchestration)
                     WHEN   NOT MATCHED BY TARGET
                     THEN   INSERT(PK_Orchestration,OrchestrationName,IsEnabled)
                                  VALUES(Source.PK_Orchestration,  Source.OrchestrationName,  Source.IsEnabled)
                     WHEN   MATCHED
                     THEN   UPDATE SET    Target.ORchestrationName = Source.OrchestrationName,
                                                       Target.IsEnabled = Source.Isenabled;

                     MERGE 
                     INTO   etl.Module AS Target
                     USING  (
                                         VALUES --Level 1
                                                       (7,1,'PFT Forecast',1,                   'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''PremiumForecastLanding.dtsx'', @PackageLocation = ''FinanceLAnding'',@Projectname = ''FinanceLanding.SSIS'', @EnvironmentName = ''FinanceLandingEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)','SchedulingHub',NULL,NULL),
                                                       (7,2,'PFT Landing', 1,                   'EXEC [pft].[usp_LandingInboundWorkflow]','$(InstanceName)', 'FinanceLanding', NULL, NULL),
                                                       --Level 7
                                                       (7,3,'DataContract',1,                   'EXEC [Inbound].[usp_InboundOutboundWorkflow]' ,'$(InstanceName)', 'FinanceDataContract', NULL, NULL),
                                                       --level 8
                                                       (7,4,'DimTrifocus', 1,                   'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimTrifocus.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', null,     NULL),
                                                       (7,5,'DimEntity',1,                      'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimEntity.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
                                                       (7,6,'DimYOA',1,                         'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimYOA.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
                                                       (7,7,'DimCCY',1,                         'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimCCY.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL), 
                                                       (7,8,'DimProduct',1,              'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimProduct.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
                                                       (7,9,'DimLocation',1,                    'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimLocation.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
                                                       (7,10,'Dim Policy',1,                    'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''DimPolicy.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT'     ,'$(InstanceName)', 'SchedulingHub', NULL, NULL),
                                                       --Level 9
                                                       (7,11,'Tech Fact',1,              'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactTechnicalResult.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
                                                       --Level 10
                                                       (7,12,'Earning',1,                       'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactEarning.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL),
                                                       --Level 11
                                                       (7,13,'SideCar',1,                       'EXEC  [sch].[USP_ExecutePackage]  @Parameters =null,@PackageName = ''FactSideCar.dtsx'', @PackageLocation = ''TechnicalHub'',@Projectname = ''TechnicalHub.SSIS'', @EnvironmentName = ''TechnicalHubEnvironment'', @ExecutionID = @ModuleExecutionID OUTPUT','$(InstanceName)', 'SchedulingHub', NULL, NULL)
                                                       
                                  )

                                         AS Source(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
                     ON            Target.FK_Orchestration = Source.FK_Orchestration
                           AND Target.PK_Module = Source.PK_Module
                     WHEN   NOT MATCHED BY TARGET
                     THEN   INSERT(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase, FK_Schedule, FK_Notification)
                                  VALUES(Source.FK_Orchestration,  Source.PK_module,  Source.ModuleName,  Source.FK_ModuleType,  Source.ModuleRoutine,  Source.DestinationServer,  Source.DestinationDatabase,Source.FK_Schedule,Source.FK_Notification)
                     WHEN   MATCHED
                     THEN   UPDATE SET           FK_Orchestration     = source.FK_Orchestration, 
                                                              PK_module                  = source.PK_module, 
                                                              ModuleName                 = source.ModuleName, 
                                                              FK_ModuleType              = source.FK_ModuleType, 
                                                              ModuleRoutine              = source.ModuleRoutine, 
                                                              DestinationServer    = source.DestinationServer, 
                                                              DestinationDatabase  = source.DestinationDatabase, 
                                                              FK_Schedule          = source.FK_Schedule, 
                                                              FK_Notification            = source.FK_Notification
                     WHEN   NOT MATCHED BY SOURCE AND target.fk_Orchestration = 7
                     THEN   DELETE;
       
                     MERGE 
                     INTO   etl.ModuleHierarchy AS Target
                     USING  (
                                         VALUES --L1
                                                       (7,    NULL,  1,     1),
                                                       (7,    1,     2,     2), 
                                                       (7,    2,     3,     3),
                                                       (7,    3,     4,     4),
                                                       (7,    4,     5,     5),
                                                       (7,    5,     6,     6),

                                                       --L2
                                                       (7,    6,     7,     7),
                                                       (7,    7,     8,     8),
                                                       (7,    8,     9,     9),
                                                       (7,    9,     10,    10),
                                                       (7,    10,    11,11),
                                                       (7,    11,    12,    12),

                                                       --L3-6
                                                       (7,    12,    13,    13)
                                                       
                                  ) AS Source(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
                     ON            Target.FK_Orchestration = Source.FK_Orchestration
                           AND Target.FK_ChildModule = Source.FK_ChildModule
                           AND Target.FK_ParentModule = Source.FK_ParentModule
                     WHEN   NOT MATCHED BY TARGET
                     THEN   INSERT(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
                                  VALUES(Source.FK_Orchestration,Source.FK_ParentModule,Source.FK_ChildModule,Source.TreeLevel)
                     WHEN   MATCHED
                     THEN   UPDATE SET    FK_Orchestration = source.FK_Orchestration, 
                                                       FK_ParentModule = source.FK_ParentModule, 
                                                       FK_ChildModule = source.FK_ChildModule, 
                                                       TreeLevel = source.TreeLevel
                     WHEN   NOT MATCHED BY SOURCE AND target.fk_Orchestration = 7
                     THEN   DELETE;


                     MERGE  etl.ModuleActivity Target
                     USING  (
                                         SELECT m.FK_Orchestration,
                                                       m.PK_Module,
                                                       1
                                         FROM   etl.Module m
                                         WHERE  m.FK_Orchestration = 7
                                  ) Source (FK_Orchestration, FK_Module, FK_ModuleStatus)
                     ON            Source.FK_Orchestration = Target.FK_Orchestration
                           AND    Source.FK_Module = Target.FK_Module
                     WHEN   NOT MATCHED BY TARGET
                     THEN   INSERT (FK_Orchestration, FK_Module, FK_ModuleStatus)
                                  VALUES (Source.FK_Orchestration, Source.FK_Module, Source.FK_ModuleStatus)
                     WHEN   MATCHED
                     THEN   UPDATE SET    Target.FK_ModuleStatus = Source.FK_ModuleStatus
                     WHEN   NOT MATCHED BY SOURCE AND target.fk_Orchestration = 7
                     THEN   DELETE;