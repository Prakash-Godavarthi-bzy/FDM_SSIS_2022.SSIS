﻿/*
This will be executed during the pre-deployment phase.
Use it to apply scripts for all actions that cannot be easily and 
consistently done using just the database project.

Note that the pre-deployment scripts are just prepended to the
generated script.

!!!Make sure your scripts are idempotent(repeatable)!!!

Example invocation:
EXEC sp_execute_script @sql = 'UPDATE Table....', @author = 'Your Name'
*/

-- Mark Baekdal, 08/06/2020. I changed the script so it runs even if the database never had these tables which will be the case with a new database.

if exists (select 1 from sys.tables where [object_id]=object_id('etl.ModuleHierarchy'))
begin
	exec(
	'DELETE 
	FROM	etl.ModuleHierarchy
	WHERE	EXISTS 
	(		SELECT	*
			FROM	etl.ModuleHierarchy
			WHERE	FK_Orchestration = 5
			AND		FK_ChildModule = 19
	)'
	)
end		


if exists (select 1 from sys.tables where [object_id]=object_id('etl.ModuleActivity'))
begin
	exec(
	'DELETE 
	FROM	etl.ModuleActivity
	WHERE	EXISTS 
	(		SELECT	*
			FROM	etl.ModuleActivity 
			WHERE FK_Orchestration = 5
			AND		FK_Module = 19
	)'
	)
end
	
		

if exists (select 1 from sys.tables where [object_id]=object_id('etl.ModuleActivity'))
begin
	exec(
	'DELETE 
	FROM	etl.Module
	WHERE	EXISTS 
	(		SELECT	*
			FROM	etl.Module
			WHERE FK_Orchestration = 5
			AND		PK_module = 19
	)'
	)
end

if exists (select 1 from sys.tables where [object_id]=object_id('etl.ModuleHierarchy'))
begin
	exec(
	'DELETE 
	FROM	etl.ModuleHierarchy
	WHERE	FK_Orchestration = 1'
	)
end	


IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'Generate CSV')
		BEGIN
			EXEC msdb.dbo.sp_delete_job @job_name = 'Generate CSV', @delete_unused_schedule=1
		END

/*==========GAAP BaseLoad Orchestration Modification Start=============*/
IF exists (select 1 from sys.tables where [object_id]=object_id('etl.ModuleActivity'))
BEGIN
DELETE FROM SchedulingHub.etl.ModuleActivity
WHERE FK_Orchestration=6 AND FK_Module IN (21,22,23,24,25,26)
END

IF exists (select 1 from sys.tables where [object_id]=object_id('etl.ModuleHierarchy'))
BEGIN
DELETE FROM SchedulingHub.etl.ModuleHierarchy
WHERE FK_Orchestration=6
END

IF exists (select 1 from sys.tables where [object_id]=object_id('etl.Module'))
BEGIN
DELETE FROM SchedulingHub.etl.MODULE
WHERE FK_Orchestration=6 AND PK_module IN (21,22,23,24,25,26)
END

/*==========GAAP BaseLoad Orchestration Modification End=============*/

/*==========GAAP Normal Load Orchestration Modification Start=============*/
IF exists (select 1 from sys.tables where [object_id]=object_id('etl.ModuleActivity'))
BEGIN
DELETE FROM SchedulingHub.etl.ModuleActivity
WHERE FK_Orchestration=5 AND FK_Module IN (20,21,22,23,24)
END

IF exists (select 1 from sys.tables where [object_id]=object_id('etl.ModuleHierarchy'))
BEGIN
DELETE FROM SchedulingHub.etl.ModuleHierarchy
WHERE FK_Orchestration=5
END

IF exists (select 1 from sys.tables where [object_id]=object_id('etl.Module'))
BEGIN
DELETE FROM SchedulingHub.etl.MODULE
WHERE FK_Orchestration=5 AND PK_module IN (20,21,22,23,24)
END
/*==========GAAP Normal Load Orchestration Modification End=============*/

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'Calculation Tree')
BEGIN
    --RAISERROR('Delete Job', 0, 0) WITH NOWAIT
	EXEC msdb.dbo.sp_delete_job @job_name ='Calculation Tree', @delete_unused_schedule=1
END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'RunPowerAppsJob')
	BEGIN
		--RAISERROR('Delete Job', 0, 0) WITH NOWAIT
		EXEC msdb.dbo.sp_delete_job @job_name = 'RunPowerAppsJob', @delete_unused_schedule=1;
	END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'OpeningBalances')
	BEGIN
		--RAISERROR('Delete Job', 0, 0) WITH NOWAIT
		EXEC msdb.dbo.sp_delete_job @job_name = 'OpeningBalances', @delete_unused_schedule=1
	END

	-- Disable IFRS17OrchestrationRunner Job
IF EXISTS (SELECT * FROM msdb.dbo.sysjobs WHERE name = 'IFRS17 Orchestration Scheduler')
BEGIN
  EXEC msdb.dbo.sp_update_job @job_name='IFRS17 Orchestration Scheduler',@enabled = 0
END

IF EXISTS (SELECT * FROM msdb.dbo.sysjobs WHERE name = 'SchedulingHub_Sprint16')
BEGIN
  EXEC msdb.dbo.sp_update_job @job_name='SchedulingHub_Sprint16',@enabled = 0
END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'SchedulingHub_23Q1')
	BEGIN
		--RAISERROR('Delete Job', 0, 0) WITH NOWAIT
		EXEC msdb.dbo.sp_delete_job @job_name = 'SchedulingHub_23Q1', @delete_unused_schedule=1
	END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'SchedulingHub_23Q2')
	BEGIN
		--RAISERROR('Delete Job', 0, 0) WITH NOWAIT
		EXEC msdb.dbo.sp_delete_job @job_name = 'SchedulingHub_23Q2', @delete_unused_schedule=1
	END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'SchedulingHub_23Q3')
	BEGIN
		--RAISERROR('Delete Job', 0, 0) WITH NOWAIT
		EXEC msdb.dbo.sp_delete_job @job_name = 'SchedulingHub_23Q3', @delete_unused_schedule=1
	END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'SchedulingHub_Sprint13')
	BEGIN
		--RAISERROR('Delete Job', 0, 0) WITH NOWAIT
		EXEC msdb.dbo.sp_delete_job @job_name = 'SchedulingHub_Sprint13', @delete_unused_schedule=1
	END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'SchedulingHub_Sprint13_set2')
	BEGIN
		--RAISERROR('Delete Job', 0, 0) WITH NOWAIT
		EXEC msdb.dbo.sp_delete_job @job_name = 'SchedulingHub_Sprint13_set2', @delete_unused_schedule=1
	END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'SchedulingHub_Sprint14')
	BEGIN
		--RAISERROR('Delete Job', 0, 0) WITH NOWAIT
		EXEC msdb.dbo.sp_delete_job @job_name = 'SchedulingHub_Sprint14', @delete_unused_schedule=1
	END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'SchedulingHub_Sprint15')
	BEGIN
		--RAISERROR('Delete Job', 0, 0) WITH NOWAIT
		EXEC msdb.dbo.sp_delete_job @job_name = 'SchedulingHub_Sprint15', @delete_unused_schedule=1
	END

--/*=========Delete SchedulingHub_Sprint13 Job not used in anymore in UAT*/
--IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'SchedulingHub_Sprint13')
--	BEGIN
--		--RAISERROR('Delete Job', 0, 0) WITH NOWAIT
--		EXEC msdb.dbo.sp_delete_job @job_name = 'SchedulingHub_Sprint13', @delete_unused_schedule=1
--	END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'SchedulingHub_23Q4')
	BEGIN
		--RAISERROR('Delete Job', 0, 0) WITH NOWAIT
		EXEC msdb.dbo.sp_delete_job @job_name = 'SchedulingHub_23Q4', @delete_unused_schedule=1
	END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'SchedulingHub_BaseLoads')
	BEGIN
		--RAISERROR('Delete Job', 0, 0) WITH NOWAIT
		EXEC msdb.dbo.sp_delete_job @job_name = 'SchedulingHub_BaseLoads', @delete_unused_schedule=1
	END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'SchedulingHub_IncrementalLoads')
	BEGIN
		--RAISERROR('Delete Job', 0, 0) WITH NOWAIT
		EXEC msdb.dbo.sp_delete_job @job_name = 'SchedulingHub_IncrementalLoads', @delete_unused_schedule=1
	END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'SchedulingHub_Sprint16')
	BEGIN
		--RAISERROR('Delete Job', 0, 0) WITH NOWAIT
		EXEC msdb.dbo.sp_delete_job @job_name = 'SchedulingHub_Sprint16', @delete_unused_schedule=1
	END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'ViewToTableFullRefresh')
	BEGIN
		--RAISERROR('Delete Job', 0, 0) WITH NOWAIT
		EXEC msdb.dbo.sp_delete_job @job_name = 'ViewToTableFullRefresh', @delete_unused_schedule=1
	END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'BulkDumpFix')
	BEGIN
		--RAISERROR('Delete Job', 0, 0) WITH NOWAIT
		EXEC msdb.dbo.sp_delete_job @job_name = 'BulkDumpFix', @delete_unused_schedule=1
	END
--=================================================================================================
--Change Version	: 1.0 
--Sprint			: BR1 Q3 24 committed
--Author			: lakshman.akasapu@beazley.com
--Modify Date	    : 2024-08-13 
--Description		: Written a delete for the unnecessary Testingjob		 
--=================================================================================================
IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'TestingJob')
	BEGIN
		--RAISERROR('Delete Job', 0, 0) WITH NOWAIT
		EXEC msdb.dbo.sp_delete_job @job_name = 'TestingJob', @delete_unused_schedule=1
	END