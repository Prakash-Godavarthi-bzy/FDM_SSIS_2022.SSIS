﻿
--:setvar InstanceName "ukdvdb149"
--:setvar ProxyLogin "BFL\PXY_IFRS17_DEV"
--:setvar ProxySecret "***"
--:setvar SchedulingHubEnvironment "SchedulingHubEnvironment"
--:setvar SSISProxyName "PXY_IFRS17"
--:setvar DatabaseName "SchedulingHub"
--:setvar DefaultFilePrefix "SchedulingHub"
--:setvar DefaultDataPath "D:\Data\MSSQLSERVER\"
--:setvar DefaultLogPath "D:\Logs\MSSQLSERVER\"

/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
--		:SETVAR InstanceName "Localhost\SQL2016"
--		:SETVAR SchedulingHubEnvironment "SchedulingHubEnvironment"
--		:SETVAR SSISProxyName "PXY_PH"
	
	
		DECLARE @EnvironmentName NVARCHAR(20) = (select	 CAST(reference_id AS varchar) from	[SSISDB].[catalog].[environment_references]	where environment_name = '$(SchedulingHubEnvironment)')
		DECLARE @ssisCommand NVARCHAR(4000) = '/ISSERVER "\"\SSISDB\SchedulingHub\SchedulingHub.SSIS\BR1DataScheduler.dtsx\"" /SERVER "\"$(InstanceName)\"" /ENVREFERENCE ' + @EnvironmentName + ' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'
		
		
		--IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'IFRS17BR1Scheduler_OnDemand')
		--		BEGIN
		--			EXEC msdb.dbo.sp_delete_job @job_name = 'IFRS17BR1Scheduler_OnDemand', @delete_unused_schedule=1
		--		END

		IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'IFRS17Jobs')
		BEGIN
		EXEC  msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'IFRS17Jobs'
		END

		
		IF Not EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'IFRS17BR1Scheduler_OnDemand')
		BEGIN
		EXEC msdb.dbo.sp_add_job 
				@job_name=N'IFRS17BR1Scheduler_OnDemand', 
				@enabled=0, 
				@notify_level_eventlog=2, 
				@notify_level_email=0, 
				@notify_level_netsend=0, 
				@notify_level_page=0, 
				@delete_level=0, 
				@owner_login_name=N'BeazleyReader_RO'
		END

		IF EXISTS (SELECT 1 FROM msdb.dbo.sysjobsteps WHERE job_id = (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'IFRS17BR1Scheduler_OnDemand') AND step_name = 'Fetch schrun')
		BEGIN
		EXEC msdb.dbo.sp_update_jobstep 
				@job_name = 'IFRS17BR1Scheduler_OnDemand',
				@step_name = 'Fetch schrun',
				@step_id = 1,
				@command = N'IF EXISTS(SELECT 1 FROM SchedulingHub.sch.UserSchedule WHERE Status=''Pending'')
					            SELECT 1
					        ELSE
					            RAISERROR (''No data found!.'',16,1)',
				@database_name = 'SchedulingHub';
		END
		ELSE
		BEGIN
		EXEC msdb.dbo.sp_add_jobstep 
				@job_name = 'IFRS17BR1Scheduler_OnDemand',
				@step_name = 'Fetch schrun', 
				@step_id = 1, 
				@cmdexec_success_code = 0, 
				@on_success_action = 3, 
				@on_fail_action = 1, 
				@retry_attempts = 0, 
				@retry_interval = 0, 
				@os_run_priority = 0, 
				@subsystem = 'TSQL', 
				@command = N'IF EXISTS(SELECT 1 FROM SchedulingHub.sch.UserSchedule WHERE Status=''Pending'')
						        SELECT 1
						    ELSE
								RAISERROR (''No data found!.'',16,1)', 
				@database_name = 'SchedulingHub', 
				@flags = 0;
		END

-- Second Job Step:  add or update
IF EXISTS (SELECT 1 FROM msdb.dbo.sysjobsteps WHERE job_id = (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'IFRS17BR1Scheduler_OnDemand') AND step_name = 'Kickoff the package')
BEGIN
    EXEC msdb.dbo.sp_update_jobstep 
        @job_name = 'IFRS17BR1Scheduler_OnDemand',
        @step_name = 'Kickoff the package',
		@step_id = 2,
        @command = @ssisCommand,
        @database_name = 'master';
END
ELSE
BEGIN
EXEC msdb.dbo.sp_add_jobstep 
    @job_name = 'IFRS17BR1Scheduler_OnDemand',
    @step_name = 'Kickoff the package', 
    @step_id = 2, 
    @cmdexec_success_code = 0, 
    @on_success_action = 1, 
    @on_fail_action = 2, 
    @retry_attempts = 0, 
    @retry_interval = 0, 
    @os_run_priority = 0,
    @subsystem = 'SSIS', 
    @command = @ssisCommand,
    @database_name = 'master', 
    @flags = 0, 
    @proxy_name = 'PXY_IFRS17';
END

		EXEC msdb.dbo.sp_add_jobschedule 
				@job_name=N'IFRS17BR1Scheduler_OnDemand',
				@name=N'IFRS17BR1Scheduler_OnDemand', 
				@enabled=1, 
				@freq_type=4, 
				@freq_interval=1, 
				@freq_subday_type=4, 
				@freq_subday_interval=2, 
				@freq_relative_interval=0, 
				@freq_recurrence_factor=0, 
				@active_start_date=20220209, 
				@active_end_date=99991231, 
				@active_start_time=150, 
				@active_end_time=235959 

		IF Not EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'IFRS17BR1Scheduler_OnDemand')
		BEGIN
		EXEC msdb.dbo.sp_add_jobserver 
					@job_name=N'IFRS17BR1Scheduler_OnDemand',
					@server_name = N'(local)'
		END

		EXEC msdb.dbo.sp_update_job @job_name='IFRS17BR1Scheduler_OnDemand',@category_name = 'IFRS17Jobs'

