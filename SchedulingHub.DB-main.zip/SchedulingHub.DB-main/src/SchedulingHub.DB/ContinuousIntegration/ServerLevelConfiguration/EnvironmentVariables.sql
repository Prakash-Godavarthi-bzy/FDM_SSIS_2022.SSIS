﻿/*		
version	   Modified by							Date								Description
---------------------------------------------------------------------------------------------------------------------------------------
 1.0     Lakshman.Akasapu@Beazley.com		30/05/2024				created new Environment Reference Variables IFRS17_MailFrom and IFRS17_MailTo 
																	regarding the ticket :https://beazley.atlassian.net/jira/software/c/projects/I1B/boards/735?search=5553&selectedIssue=I1B-5553&sprints=5993

---------------------------------------------------------------------------------------------------------------------------------------
*/


					/* ======================================================================================================
														Declaration of Environment variables
					=======================================================================================================*/
					DECLARE @LocalInstance								NVARCHAR(2000) =	'$(InstanceName)'
					DECLARE @IDM_Instance                               NVARCHAR(2000) =    '$(InstanceName_IDM)'
					DECLARE @SMTP                                       NVARCHAR(2000) =    '$(SMTPServer)'
					DECLARE @PPPath                                     NVARCHAR(2000) =    '$(PPPath)'

					DECLARE @IFRS17_MailFrom							NVARCHAR(2000) = '$(Parameter_IFRS17_MailFrom)'
					DECLARE @IFRS17_MailTo								NVARCHAR(2000) = '$(Parameter_IFRS17_MailTo)'

					/* ======================================================================================================
														Deleting Environment Reference
					=======================================================================================================*/

					DECLARE @ReferenceID INT = 0
					WHILE EXISTS	(SELECT	* FROM	ssisdb.catalog.environment_references r WHERE	r.environment_name IN ('$(SchedulingHubEnvironment)') AND r.reference_id > @ReferenceID)
					BEGIN
						SELECT	@ReferenceID = MIN(reference_id)
						FROM	ssisdb.catalog.environment_references r
						WHERE	r.environment_name IN ('$(SchedulingHubEnvironment)')
							AND reference_id > @ReferenceID
	
						EXEC SSISDB.catalog.delete_environment_reference @ReferenceID
					END


					/* ======================================================================================================
														Deleting Environment 
					=======================================================================================================*/

					IF EXISTS (SELECT * FROM SSISDB.catalog.environments WHERE Name = '$(SchedulingHubEnvironment)')		

					EXEC [SSISDB].[catalog].[delete_environment] @folder_name = 'SchedulingHub', @Environment_Name = '$(SchedulingHubEnvironment)'

					--Clean off any parameters incorrectly set by solidops SSIS deployment
					DECLARE @ObjectName VARCHAR(255), @ParameterName VARCHAR(255), @ObjectType INT
					-- the old line is LIKE 'TechnicalHub.SSIS.%', it should be 'SchedulingHub.SSIS.%'. Caused an infinite loop.
					--WHILE EXISTS (SELECT * FROM	ssisdb.catalog.object_parameters op WHERE	op.referenced_variable_name LIKE 'TechnicalHub.SSIS.%')
					WHILE EXISTS (SELECT * FROM	ssisdb.catalog.object_parameters op WHERE	op.referenced_variable_name LIKE 'SchedulingHub.SSIS.%')
					BEGIN
						SELECT	TOP 1  
								@ObjectName = op.object_name,
								@ParameterName = op.parameter_name,
								@ObjectType = op.object_type
						FROM	ssisdb.catalog.object_parameters op 
						WHERE	op.referenced_variable_name LIKE 'SchedulingHub.SSIS.%'
	
						EXEC	SSISDB.catalog.clear_object_parameter_value @folder_name = N'SchedulingHub', @project_name = N'SchedulingHub.SSIS', @object_type = @ObjectType, @object_name = @ObjectName, @parameter_name = @ParameterName
					END

					/* ======================================================================================================
														Create Environment 
					=======================================================================================================*/

					EXEC [SSISDB].[catalog].[create_environment] @folder_name = 'SchedulingHub', @Environment_Name = '$(SchedulingHubEnvironment)'

					/* ======================================================================================================
														Create Environment Reference
					=======================================================================================================*/

					SET @ReferenceID = NULL

					EXEC [SSISDB].[catalog].[create_environment_reference] @folder_name = N'SchedulingHub', @project_name = N'SchedulingHub.SSIS', @environment_name = N'$(SchedulingHubEnvironment)', @Reference_type = 'R', @reference_id = @ReferenceID


					/* ======================================================================================================
														Create Environment Reference Variables
					=======================================================================================================*/

					EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'$(SchedulingHubEnvironment)',		@variable_name=N'OrchestramDB',		@sensitive=False, @folder_name=N'SchedulingHub', @value=@LocalInstance, @data_type=N'String'
					EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'$(SchedulingHubEnvironment)',		@variable_name=N'OrchestrationDB',	@sensitive=False, @folder_name=N'SchedulingHub', @value=@LocalInstance, @data_type=N'String'
					EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'$(SchedulingHubEnvironment)',		@variable_name=N'IFRS17DataMart',	@sensitive=False, @folder_name=N'SchedulingHub', @value=@IDM_Instance, @data_type=N'String'
					EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'$(SchedulingHubEnvironment)',		@variable_name=N'SMTPServer',	    @sensitive=False, @folder_name=N'SchedulingHub', @value=@SMTP, @data_type=N'String'
					EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'$(SchedulingHubEnvironment)',		@variable_name=N'PPPath',	    @sensitive=False, @folder_name=N'SchedulingHub', @value=@PPPath, @data_type=N'String'

					EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'$(SchedulingHubEnvironment)',		@variable_name=N'IFRS17_MailFrom',	    @sensitive=False, @folder_name=N'SchedulingHub', @value=@IFRS17_MailFrom, @data_type=N'String'
					EXEC [SSISDB].[catalog].[create_environment_variable] @environment_name=N'$(SchedulingHubEnvironment)',		@variable_name=N'IFRS17_MailTo',	    @sensitive=False, @folder_name=N'SchedulingHub', @value=@IFRS17_MailTo, @data_type=N'String'

					/* ======================================================================================================
														Set Parameter Values
					=======================================================================================================*/
					EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'OrchestramDB', @object_name=N'SchedulingHub.SSIS', @folder_name=N'SchedulingHub', @project_name=N'SchedulingHub.SSIS', @value_type=R, @parameter_value=N'OrchestramDB'
					EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'OrchestrationDB', @object_name=N'SchedulingHub.SSIS', @folder_name=N'SchedulingHub', @project_name=N'SchedulingHub.SSIS', @value_type=R, @parameter_value=N'OrchestrationDB'
					EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'IFRS17DataMart', @object_name=N'SchedulingHub.SSIS', @folder_name=N'SchedulingHub', @project_name=N'SchedulingHub.SSIS', @value_type=R, @parameter_value=N'IFRS17DataMart'
					EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'SMTPServer', @object_name=N'SchedulingHub.SSIS', @folder_name=N'SchedulingHub', @project_name=N'SchedulingHub.SSIS', @value_type=R, @parameter_value=N'SMTPServer'
					EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'PPPath', @object_name=N'SchedulingHub.SSIS', @folder_name=N'SchedulingHub', @project_name=N'SchedulingHub.SSIS', @value_type=R, @parameter_value=N'PPPath'

					EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'IFRS17_MailFrom', @object_name=N'SchedulingHub.SSIS', @folder_name=N'SchedulingHub', @project_name=N'SchedulingHub.SSIS', @value_type=R, @parameter_value=N'IFRS17_MailFrom'
					EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'IFRS17_MailTo', @object_name=N'SchedulingHub.SSIS', @folder_name=N'SchedulingHub', @project_name=N'SchedulingHub.SSIS', @value_type=R, @parameter_value=N'IFRS17_MailTo'

