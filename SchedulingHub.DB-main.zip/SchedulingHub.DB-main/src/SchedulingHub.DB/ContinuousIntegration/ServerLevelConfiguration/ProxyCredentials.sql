﻿

--:setvar InstanceName "ukdvdb149"
--:setvar ProxyLogin "BFL\PXY_FDM_DEV"
--:setvar ProxySecret "***"
--:setvar SchedulingHubEnvironment "SchedulingHubEnvironment"
--:setvar SSISProxyName "PXY_FDM"
--:setvar DatabaseName "SchedulingHub"
--:setvar DefaultFilePrefix "SchedulingHub"
--:setvar DefaultDataPath "D:\Data\MSSQLSERVER\"
--:setvar DefaultLogPath "D:\Logs\MSSQLSERVER\"

BEGIN TRY
	IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'SchedulingHub')
	BEGIN
		RAISERROR('Delete Job', 0, 0) WITH NOWAIT
		EXEC msdb.dbo.sp_delete_job @job_name = 'SchedulingHub', @delete_unused_schedule=1
	END

	IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'Calculation Tree')
	BEGIN
		RAISERROR('Delete Job', 0, 0) WITH NOWAIT
		EXEC msdb.dbo.sp_delete_job @job_name = 'Calculation Tree', @delete_unused_schedule=1;
	END

	IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'OpeningBalances')
	BEGIN
		RAISERROR('Delete Job', 0, 0) WITH NOWAIT
		EXEC msdb.dbo.sp_delete_job @job_name = 'OpeningBalances', @delete_unused_schedule=1
	END

	IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'RunPowerAppsJob')
	BEGIN
		RAISERROR('Delete Job', 0, 0) WITH NOWAIT
		EXEC msdb.dbo.sp_delete_job @job_name = 'RunPowerAppsJob', @delete_unused_schedule=1;
	END
	IF EXISTS (SELECT * FROM msdb.dbo.sysproxies s WHERE name = '$(SSISProxyName)')
		EXEC msdb.dbo.sp_delete_proxy @proxy_name = '$(SSISProxyName)'

	IF EXISTS (SELECT * FROM sys.sysusers s WHERE name = '$(ProxyLogin)')
	BEGIN
		EXECUTE sys.sp_dropuser @name_in_db = '$(ProxyLogin)'
	END
	--IF EXISTS (SELECT 1 FROM [sys].[credentials] WHERE [name] = '$(SSISProxyName)')
	--BEGIN
	--	RAISERROR('Dropping credential', 0, 0) WITH NOWAIT
	--	DROP CREDENTIAL [$(SSISProxyName)];
	--END

	IF EXISTS (SELECT * FROM SSISDB.sys.schemas s WHERE name = '$(ProxyLogin)')
		BEGIN
			DECLARE @SQL VARCHAR(MAX) = ''
			SELECT	@SQL = 'USE ssisdb;' + CHAR(10) +  'DROP SCHEMA [$(ProxyLogin)]' 
			PRINT	@SQL 
			EXEC(	@SQL)
		END
			PRINT '2'
		
		
	IF EXISTS (SELECT * FROM ssisdb.sys.sysusers s WHERE name = '$(ProxyLogin)')
	BEGIN
		DELETE	op
		FROM	SSISDB.[internal].[operation_permissions] op
		JOIN	ssisdb.sys.sysusers su ON su.sid = op.grantor_sid
		WHERE	su.name = '$(ProxyLogin)'

		-- we don't want to drop the user, if it exists as it will have other permissions that aren't within here (failed previously) which will cause the drop to fail. 
		-- These permission types are related to the individual packages. 
		-- IE: EXEC catalog.revoke_permission @object_type=4, @object_id=998, @principal_id=1, @permission_type=1
		--EXECUTE ssisdb.sys.sp_dropuser @name_in_db = '$(ProxyLogin)' -- :setvar ProxyLogin "BFL\PXY_FDM_DEV"
	END 
	--/*=======================================================================================================
	--Create	
	--=======================================================================================================*/
	
	IF NOT EXISTS (SELECT * FROM master.sys.syslogins WHERE name = '$(ProxyLogin)')
		CREATE LOGIN [$(ProxyLogin)] FROM WINDOWS WITH DEFAULT_DATABASE=[master]
		
	IF NOT EXISTS (select * from ssisdb.sys.database_principals where name='$(ProxyLogin)')
		EXECUTE ssisdb.sys.sp_adduser @loginame = '$(ProxyLogin)', @name_in_db = '$(ProxyLogin)', @grpname = 'db_owner' -- caused error - added conditional clause to make it repeatable.

	EXECUTE sys.sp_adduser @loginame = '$(ProxyLogin)', @name_in_db = '$(ProxyLogin)', @grpname = 'db_owner'
	EXECUTE ssisdb.sys.sp_addrolemember @rolename = 'ssis_admin', @membername = '$(ProxyLogin)'
	
	IF NOT EXISTS (SELECT 1 FROM [sys].[credentials] WHERE [name] = '$(SSISProxyName)')
	begin
		RAISERROR('Create Credential: $(SSISProxyName)', 0, 0) WITH NOWAIT
		CREATE CREDENTIAL [$(SSISProxyName)] WITH IDENTITY = '$(ProxyLogin)', SECRET = N'$(ProxySecret)'
	end

	IF EXISTS (SELECT name FROM msdb.dbo.sysproxies WHERE name = '$(SSISProxyName)')
	BEGIN
		RAISERROR('Dropping Proxy', 0, 0) WITH NOWAIT
		EXEC msdb.dbo.sp_delete_proxy @proxy_name = '$(SSISProxyName)';
	END

	RAISERROR('Create Proxy: $(SSISProxyName)', 0, 0) WITH NOWAIT
	EXEC msdb.dbo.sp_add_proxy @proxy_name = '$(SSISProxyName)', @credential_name = '$(SSISProxyName)', @enabled = 1;
	EXEC msdb.dbo.sp_grant_proxy_to_subsystem @proxy_name = '$(SSISProxyName)', @subsystem_id = 11;
	
	IF EXISTS ( SELECT	* FROM	dbo.syslogins s WHERE name = '$(ProxyLogin)' AND s.sysadmin <> 1)
		EXEC msdb.dbo.sp_grant_login_to_proxy @proxy_name='$(SSISProxyName)' ,@login_name='$(ProxyLogin)'

END TRY
BEGIN CATCH
	if @@trancount<>0 rollback; -- can have an open transaction here when an error occurs, so we need to rollback if exists
	THROW;
END CATCH

-- rollback
