﻿

--:setvar InstanceName "ukdvdb149"
--:setvar ProxyLogin "BFL\PXY_IFRS17_DEV"
--:setvar ProxySecret "***"
--:setvar SchedulingHubEnvironment "SchedulingHubEnvironment"
--:setvar SSISProxyName "PXY_IFRS17"
--:setvar DatabaseName "SchedulingHub"
--:setvar DefaultFilePrefix "SchedulingHub"
--:setvar DefaultDataPath "D:\Data\MSSQLSERVER\"
--:setvar DefaultLogPath "D:\Logs\MSSQLSERVER\"

/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
--		:SETVAR InstanceName "Localhost\SQL2016"
--		:SETVAR SchedulingHubEnvironment "SchedulingHubEnvironment"
--		:SETVAR SSISProxyName "PXY_PH"

		DECLARE @Env NVARCHAR(20) = (select	 CAST(reference_id AS varchar) from	SSISDB.internal.environment_references	where environment_name = '$(SchedulingHubEnvironment)')
		DECLARE @Command NVARCHAR(4000) = '/ISSERVER "\"\SSISDB\SchedulingHub\SchedulingHub.SSIS\Orchestrator.dtsx\"" /SERVER "\"$(InstanceName)\"" /ENVREFERENCE ' + @Env + ' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'

		--IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'SchedulingHub')
		--BEGIN
		--	EXEC msdb.dbo.sp_delete_job @job_name = 'SchedulingHub', @delete_unused_schedule=1
		--END

		IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'IFRS17Jobs')
		BEGIN
		EXEC  msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'IFRS17Jobs'
		END

		IF NOT EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'SchedulingHub')
		BEGIN
		EXEC msdb.dbo.sp_add_job 
			@Start_step_id = 1, 
			@job_name=N'SchedulingHub', 
			@enabled=0, 
			@notify_level_eventlog=0, 
			@notify_level_email=0, 
			@notify_level_netsend=0, 
			@notify_level_page=0, 
			@delete_level=0, 
			@owner_login_name=N'BFL\Beazley_Reader'
		END
		
		IF EXISTS (SELECT 1 FROM msdb.dbo.sysjobsteps WHERE job_id = (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'SchedulingHub') AND step_name = 'Call Orchestrator')
		BEGIN
		EXEC msdb.dbo.sp_update_jobstep 
				@job_name = N'SchedulingHub',
				@step_name = N'Call Orchestrator',
				@step_id = 1,
				@command =@Command,
				@database_name = N'master';
		END
		ELSE
		BEGIN
		EXEC msdb.dbo.sp_add_jobstep
			@job_name=N'SchedulingHub', 
			@step_name=N'Call Orchestrator', 
			@step_id=1, 
			@cmdexec_success_code=0, 
			@on_success_action=1, 
			@on_success_step_id=0, 
			@on_fail_action=2, 
			@on_fail_step_id=0, 
			@retry_attempts=0, 
			@retry_interval=0, 
			@os_run_priority=0, 
			@subsystem=N'SSIS', 
			@command=@Command, 
			@database_name=N'master', 
			@flags=0, 
			@proxy_name=N'PXY_IFRS17'
		END


		EXEC msdb.dbo.sp_add_jobschedule 
				@job_name = 'SchedulingHub', 
				@name=N'Daily@5am', 
				@enabled=1, 
				@freq_type=4, 
				@freq_interval=1, 
				@freq_subday_type=1, 
				@freq_subday_interval=10, 
				@freq_relative_interval=0, 
				@freq_recurrence_factor=0, 
				@active_start_date=20190417, 
				@active_end_date=99991231, 
				@active_start_time=50000, 
				@active_end_time=235959, 
				@schedule_uid=N'b0c7856a-35d2-4d8c-b42e-0ddef43f1101'
		
		IF Not EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = 'IFRS17BR1Scheduler_OnDemand')
		BEGIN
		EXEC msdb.dbo.sp_add_jobserver 
			@job_name=N'SchedulingHub',
			@server_name = N'(local)'
		END

	-- set the job to disabled as all environments except for production need to run manually.
	EXEC msdb.dbo.sp_update_job @job_name='SchedulingHub',@enabled = 0,@category_name = 'IFRS17Jobs'
