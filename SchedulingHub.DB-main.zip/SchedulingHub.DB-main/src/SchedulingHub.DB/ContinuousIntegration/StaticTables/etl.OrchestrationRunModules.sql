﻿MERGE INTO [etl].[OrchestrationRunModules] AS Target

USING (VALUES
             (1,1,15,'IFRS17_AgressoToLandingExtract',NULL,NULL,38,'usp_LandingToInboundToOutbound_AgressoARBIDAC',NULL,NULL)
			,(2,2,15,'IFRS17_AgressoToLandingExtract',NULL,NULL,39,'usp_LandingToInboundToOutbound_AgressoARUS',NULL,NULL)
			,(3,3,40,'IFRS17_BICILanding',50,'usp_BICILandingToInboundWorkflow',4,'usp_InboundOutboundWorkflow',NULL,NULL)
			,(4,4,10,'IFRS17_BICIRI_Claim',25,'usp_LandingInboundWorkflow_BICI_RI_Ultimate_Claim',31,'usp_InboundOutBoundWorkflow_TacticalLoads',NULL,NULL)
			,(5,5,7,'IFRS17_TDMBICIClaimsToLandingExtract',22,'usp_LandingInboundWorkflow_BICIClaims',31,'usp_InboundOutBoundWorkflow_TacticalLoads',NULL,NULL)
			,(6,6,5,'IFRS17_BICIRI_Incurred',20,'usp_LandingInboundWorkflow_BICI_RI_Incurred',31,'usp_InboundOutBoundWorkflow_TacticalLoads',NULL,NULL)
			,(7,7,8,'IFRS17_BICIRI_Paid',23,'usp_LandingInboundWorkflow_BICI_RI_Paid',31,'usp_InboundOutBoundWorkflow_TacticalLoads',NULL,NULL)
			,(8,8,2,'IFRS17_BICIRI_Ultimate',17,'usp_LandingInboundWorkflow_BICI_RI_Ultimate_Premium',31,'usp_InboundOutBoundWorkflow_TacticalLoads',NULL,NULL)
			,(9,9,41,'IFRS17_BIDACLanding',51,'BIDAC.usp_LandingInboundWorkflow',4,'usp_InboundOutboundWorkflow',NULL,NULL)
			,(10,10,1,'IFRS17_BusinessPlanLanding',16,'usp_LandingInboundWorkflow_BusinessPlan',31,'usp_InboundOutBoundWorkflow_TacticalLoads',NULL,NULL)
			,(11,11,6,'IFRS17_BusinessPlanLandingRI',21,'usp_LandingInboundWorkflow_BusinessPlanRI',31,'usp_InboundOutBoundWorkflow_TacticalLoads',NULL,NULL)
			,(12,12,11,'IFRS17_CededReAccToLandingExtract',NULL,NULL,32,'usp_LandingToInboundToOutbound_CededReClaimsIncurred',NULL,NULL)
			,(13,13,11,'IFRS17_CededReAccToLandingExtract',NULL,NULL,33,'usp_LandingToInboundToOutbound_CededReClosedYOA',NULL,NULL)
			,(14,14,11,'IFRS17_CededReAccToLandingExtract',NULL,NULL,34,'usp_LandingToInboundToOutbound_CededReORC',NULL,NULL)
			,(15,15,40,'IFRS17_BICCToLandingExtract',95,'usp_LandingToInbound',97,'usp_InboundOutboundWorkflow',210,'usp_InboundOutboundWorkflow_ClaimExtensions')
			,(16,16,65,'IFRS17_FDMToLandingExtract',NULL,NULL,36,'usp_LandingToInboundToOutbound_RI_Reinstatement_Premium_Earned',NULL,NULL)
			,(17,17,50,'IFRS17_EurobaseToLandingExtract',150,'sp_LandingToInbound_EPI',170,'usp_InboundOutboundWorkflow',NULL,NULL)
			,(18,18,2,'FDMTrifocusCode',3,'eb.USP_LandingInboundWorkflow',4,'usp_InboundOutboundWorkflow',NULL,NULL)
			,(19,18,1,'EurobaseEPI',3,'eb.USP_LandingInboundWorkflow',4,'usp_InboundOutboundWorkflow',NULL,NULL)
			,(20,19,13,'AgressoExpensesActual',28,'usp_LandingInboundWorkflow_AgressoExpensesActual',31,'usp_InboundOutBoundWorkflow_TacticalLoads',NULL,NULL)
			,(21,20,50,'IFRS17_EurobaseToLandingExtract',130,'Eurobase.usp_LandingToInbound',170,'usp_InboundOutboundWorkflow',NULL,NULL)
			,(22,21,14,'IFRS17_ObligatedPremium_Munich_QQS',29,'usp_LandingInboundWorkflow_ObligatedPremium_Munich_QQS',31,'usp_InboundOutBoundWorkflow_TacticalLoads',NULL,NULL)
			,(23,22,65,'IFRS17_FDMToLandingExtract',NULL,NULL,93,'usp_LandingToInboundToOutbound_ObligatedPremium',NULL,NULL)
			,(24,23,11,'IFRS17_SPAObligatedPremium',26,'usp_LandingInboundWorkflow_ObligatedPremium_SPA',31,'usp_InboundOutBoundWorkflow_TacticalLoads',NULL,NULL)
			,(25,24,16,'PremiumForecastLanding',17,'pft.usp_LandingInboundWorkflow',4,'usp_InboundOutboundWorkflow',NULL,NULL)
			,(26,25,65,'IFRS17_FDMToLandingExtract',NULL,NULL,51,'usp_LandingToInboundToOutbound_Reinsurance_Overriding_Commission',NULL,NULL)
			,(27,26,13,'IFRS17_PaidRebatesToLandingExtract',NULL,NULL,52,'usp_LandingToInboundToOutbound_PaidRebates',NULL,NULL)
			,(28,27,12,'IFRS17_UltimateRebatesToLandingExtract',NULL,NULL,35,'usp_LandingToInboundToOutbound_UltimateRIRebate',NULL,NULL)
			,(29,28,3,'IFRS17_ADMResDataAllocToLandingExtract',18,'usp_LandingInboundWorkflow_ResDataEventAlloc',31,'usp_InboundOutBoundWorkflow_TacticalLoads',NULL,NULL)
			,(30,29,15,'IFRS17_ADMResDataUltimateClaims',30,'usp_LandingInboundWorkflow_ResDataRIAttClaims',31,'usp_InboundOutBoundWorkflow_TacticalLoads',NULL,NULL)
			,(31,30,12,'ADMReinsuranceReservingData_LargeLosses',27,'usp_LandingInboundWorkflow_ReinsuranceReservingDataLargeLosses_ADM',31,'usp_InboundOutBoundWorkflow_TacticalLoads',NULL,NULL)
			,(32,31,10,'IFRS17_ADMToLandingExtract',NULL,NULL,90,'ADM.usp_LandingToInboundToOutbound',NULL,NULL)
			,(33,31,73,'IFRS17_ADM_DFM_PaymentPattern_ToLanding',NULL,NULL,90,'ADM.usp_LandingToInboundToOutbound',NULL,NULL)
			,(34,31,76,'IFRS17_ADM_ResDat_PaymentPattern_ToLanding',NULL,NULL,90,'ADM.usp_LandingToInboundToOutbound',NULL,NULL)
			,(35,31,78,'IFRS17_ADM_S2_TPOutput_PaymentPattern_ToLanding',NULL,NULL,90,'ADM.usp_LandingToInboundToOutbound',NULL,NULL)
			,(36,32,50,'IFRS17_EurobaseToLandingExtract',132,'usp_LandingToInbound_FacReInsurance',170,'usp_InboundOutboundWorkflow',NULL,NULL)
			,(37,33,50,'IFRS17_EurobaseToLandingExtract',NULL,NULL,217,'usp_LandingToInboundToOutbound_TreatyReInsurance',210,'usp_InboundOutboundWorkflow_ClaimExtensions')
			,(38,34,65,'IFRS17_FDMToLandingExtract',NULL,NULL,96,'usp_LandingToInboundToOutbound_RISpecialArrangements',NULL,NULL)
			,(39,35,4,'IFRS17_UltimateRIPsEventToLandingExtract',19,'usp_LandingInboundWorkflow_RIPsEventAlloc',31,'usp_InboundOutBoundWorkflow_TacticalLoads',NULL,NULL)
			,(40,36,79,'IFRS17_BeazleyMIReinsuranceToLandingExtract',NULL,NULL,31,'usp_LandingToInboundToOutbound_SignedProfitCommission',NULL,NULL)
			,(41,37,14,'IFRS17_UltimateProfitCommissionToLandingExtract',NULL,NULL,37,'usp_LandingToInboundToOutbound_UltimateProfitCommission',NULL,NULL)
			,(42,38,42,'IFRS17_USBAICLanding',52,'usp_BAICLandingToInboundWorkflow',4,'usp_InboundOutboundWorkflow',NULL,NULL)
			,(43,39,13,'USPremium',14,'us.usp_LandingInboundWorkflow',4,'usp_InboundOutboundWorkflow',NULL,NULL)
			,(44,40,20,'IFRS17_EIOPAToLandingExtract',100,'usp_EIOPALandingToInbound_DiscountRates',180,'usp_InboundOutboundWorkflow_DiscountRates',NULL,NULL)
			,(45,41,30,'IFRS17_NatCatEarningToLandingExtract',110,'usp_NatCatEarningLandingToInbound_Pattern',190,'usp_InboundOutboundWorkflow_Pattern',NULL,NULL)
			,(46,42,90,'IFRS17_ObligatedPremiumUnincepted',116,'usp_LandingInboundWorkflow_ObligatedPremium_Unincepted',31,'usp_InboundOutBoundWorkflow_TacticalLoads',NULL,NULL)
			,(47,43,9,'IFRS17_BICIRIEarnedToLandingExtract',24,'usp_LandingInboundWorkflow_EarnedPremium',31,'usp_InboundOutBoundWorkflow_TacticalLoads',NULL,NULL)
			,(48,44,10,'IFRS17_ADMToLandingExtract',140,'usp_LandingToInbound_Pattern',190,'usp_InboundOutboundWorkflow_Pattern',NULL,NULL)
			,(49,44,73,'IFRS17_ADM_DFM_PaymentPattern_ToLanding',140,'usp_LandingToInbound_Pattern',190,'usp_InboundOutboundWorkflow_Pattern',NULL,NULL)
			,(50,44,75,'IFRS17_ADM_ResDat_PaymentPattern_ToLanding',140,'usp_LandingToInbound_Pattern',190,'usp_InboundOutboundWorkflow_Pattern',NULL,NULL)
			,(51,44,78,'IFRS17_ADM_S2_TPOutput_PaymentPattern_ToLanding',140,'usp_LandingToInbound_Pattern',190,'usp_InboundOutboundWorkflow_Pattern',NULL,NULL)
			,(52,45,21,'MDS ToLanding',NULL,NULL,NULL,NULL,NULL,NULL)
			,(53,45,30,'IFRS17_BICILandingBaseLoad.dtsx',40,'usp_BICILandingToInboundWorkflow',4,'usp_InboundOutboundWorkflow',NULL,NULL)
			,(54,46,21,'MDS ToLanding',NULL,NULL,NULL,NULL,NULL,NULL)
			,(55,46,31,'IFRS17_BIDACLandingBaseLoad.dtsx',41,'BIDAC.usp_LandingInboundWorkflow',4,'usp_InboundOutboundWorkflow',NULL,NULL)
			,(56,47,21,'MDS ToLanding',NULL,NULL,NULL,NULL,NULL,NULL)
			,(57,47,32,'IFRS17_USBAICLandingBaseLoad.dtsx',42,'usp_BAICLandingToInboundWorkflow',4,'usp_InboundOutboundWorkflow',NULL,NULL)
			,(58,48,16,'PremiumForecastLanding.dtsx',17,'pft.usp_LandingInboundWorkflow',4,'usp_InboundOutboundWorkflow',NULL,NULL)
			,(59,49,2,'EB Trifocus',NULL,NULL,NULL,NULL,NULL,NULL)
			,(60,49,21,'MDS ToLanding',NULL,NULL,NULL,NULL,NULL,NULL)
			,(61,49,19,'EurobaseBaseLoad.dtsx',3,'eb.usp_LandingInboundWorkflow_BaseLoad',4,'usp_InboundOutboundWorkflow',NULL,NULL)
			,(62,50,21,'MDS ToLanding',NULL,NULL,NULL,NULL,NULL,NULL)
			,(63,50,13,'USPremiumBaseLoad.dtsx',14,'us.usp_LandingInboundWorkflow',4,'usp_InboundOutboundWorkflow',NULL,NULL)

       )AS Source ([PK_OrcModules], [fk_config], [fk_Landing], [PackageName], [fk_Inbound], [InboundProc], [fk_Outbound], [OutboundProc], [fk_Extensions], [ExtensionsProc])
			
ON (Target.[PK_OrcModules] = Source.[PK_OrcModules])

WHEN MATCHED 
		and [Target].[fk_config]         != Source.[fk_config]
		or  [Target].[fk_Landing]    != Source.[fk_Landing]
		or  [Target].[PackageName]  != Source.[PackageName]
		or  [Target].[fk_Inbound]  != Source.[fk_Inbound]
		or  [Target].[InboundProc]  != Source.[InboundProc]
		or  [Target].[fk_Outbound]  != Source.[fk_Outbound]
		or  [Target].[OutboundProc]  != Source.[OutboundProc]
		or  [Target].[fk_Extensions]  != Source.[fk_Extensions]
		or  [Target].[ExtensionsProc]  != Source.[ExtensionsProc]

THEN 
UPDATE SET [fk_config]         = Source.[fk_config]
		,[fk_Landing]    = Source.[fk_Landing]
		,[PackageName]  = Source.[PackageName]
		,[fk_Inbound]  = Source.[fk_Inbound]
		,[InboundProc]  = Source.[InboundProc]
		,[fk_Outbound]  = Source.[fk_Outbound]
		,[OutboundProc]  = Source.[OutboundProc]
		,[fk_Extensions]  = Source.[fk_Extensions]
		,[ExtensionsProc]  = Source.[ExtensionsProc]
WHEN NOT MATCHED BY TARGET THEN

INSERT ([PK_OrcModules], [fk_config], [fk_Landing], [PackageName], [fk_Inbound], [InboundProc], [fk_Outbound], [OutboundProc], [fk_Extensions], [ExtensionsProc])
VALUES (Source.[PK_OrcModules], Source.[fk_config], Source.[fk_Landing], Source.[PackageName], Source.[fk_Inbound], Source.[InboundProc], Source.[fk_Outbound],Source.[OutboundProc], source.[fk_Extensions], source.[ExtensionsProc])
		   
WHEN NOT MATCHED BY SOURCE THEN DELETE;
                                                                                                                                                                                                      
DECLARE @mergeError int                                                                                                                                                                                  
       ,@mergeCount int                                                                                                                                                                                       
SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT                                                                                                                                                   
IF @mergeError != 0                                                                                                                                                                                      
 BEGIN                                                                                                                                                                                                   
 PRINT 'ERROR OCCURRED IN MERGE FOR [etl].[OrchestratioRunModules]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); -- SQL should always return zero rows affected                           
 END                                                                                                                                                                                                     
ELSE                                                                                                                                                                                                     
 BEGIN                                                                                                                                                                                                   
 PRINT '[etl].[OrchestratioRunModules] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));                                                                                              
 END                                                                                                                                                                                                     


