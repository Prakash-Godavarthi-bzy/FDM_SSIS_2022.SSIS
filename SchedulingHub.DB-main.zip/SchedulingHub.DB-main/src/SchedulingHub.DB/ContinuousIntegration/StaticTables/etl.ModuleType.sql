﻿

			MERGE	[etl].[ModuleType] AS Target
			USING	(VALUES(1, N'SPROC'),(2, N'SSIS'),(3, N'Notification')) AS Source([PK_ModuleType], [ModuleType])
			ON		(Target.[PK_ModuleType] = Source.[PK_ModuleType])
			WHEN	MATCHED
			THEN	UPDATE SET [ModuleType] = Source.[ModuleType]
			WHEN	NOT MATCHED
			THEN	INSERT([PK_ModuleType], [ModuleType])
					VALUES(Source.[PK_ModuleType], Source.[ModuleType]);

