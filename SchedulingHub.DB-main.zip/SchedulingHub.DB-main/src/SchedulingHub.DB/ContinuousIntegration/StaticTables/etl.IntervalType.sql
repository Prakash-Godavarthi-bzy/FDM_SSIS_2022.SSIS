﻿
MERGE	[etl].[IntervalType] AS Target
USING	(	
			VALUES	(1,  N'Days', N'd'),
					(2,  N'Hours',  N'h'),
					(3,  N'Calendar', NULL),
					(4,  N'Minutes',  N'm')
		) AS Source ([PK_IntervalType], [IntervalType], [abbreviation])
ON		[Target].[PK_IntervalType] = Source.[PK_IntervalType]
WHEN	NOT MATCHED
THEN	INSERT	([PK_IntervalType], [IntervalType], [abbreviation])
		VALUES  (Source.[PK_IntervalType],  Source.[IntervalType],  Source.[abbreviation])
WHEN	MATCHED
THEN	UPDATE SET	[IntervalType] = source.[IntervalType], 
					[abbreviation] = source.[abbreviation];

