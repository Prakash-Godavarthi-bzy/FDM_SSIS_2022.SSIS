/*
	Change Version	: v1.2	 
	Sprint			: BR1 Q3 24 Committed
	Author		    : Shah Nawaz Ahmed    <shahnawaz.ahmed@beazley.com>
	Modify Date	    : 12/07/2024
	Description		: https://beazley.atlassian.net/browse/I1B-5622   
									Add a new DataSet PolicySectionReference and Renamed  ResDataRIAttClmAllocPhase1, 2 and IR_ViewToTable
*/
Declare @Ident_Max int
select @Ident_Max=max(PK_ConfigID)
from sch.DataSetConfig

dbcc checkident ('sch.DataSetConfig',reseed,@ident_max);

MERGE INTO	[sch].[DataSetConfig] AS Target

USING	( VALUES																							
			(1 ,'ADM-DFMs' ,15 ,'ADM' ),
			(2 ,'AgressoARBIDAC' ,15 ,'Agresso' ),
			(3 ,'AgressoARUS' ,15 ,'Agresso' ),
			(4 ,'BICI' ,15 ,'FDM' ),
			(5 ,'BICI RI Ultimate Claim' ,15 ,'CSV File' ),
			(6 ,'BICI TDM' ,15 ,'CSV File' ),
			(7 ,'BICI_Earned_Agresso' ,15 ,'Agresso' ),
			(8 ,'BICI_ORC_TACTICAL' ,15 ,'Agresso' ),
			(9 ,'BICI_RI_Incurred' ,15 ,'Agresso' ),
			(10 ,'BICI_RI_Paid' ,15 ,'Agresso' ),
			(11 ,'BICI_RI_Ultimate_Premium' ,15 ,'CSV File' ),
			(12 ,'BIDAC' ,15 ,'FDM' ),
			(13 ,'BusinessPlan' ,15 ,'CSV File' ),
			(14 ,'BusinessPlanRI' ,15 ,'CSV File' ),
			(15 ,'Ceded_Re_Claims_Incurred' ,15 ,'Ceded Access DB' ),
			(16 ,'Ceded_Re_Closed_YOA' ,15 ,'Ceded Access DB' ),
			(17 ,'Ceded_Re_ORC' ,15 ,'Ceded Access DB' ),
			(18 ,'Claims_BI_ODS' ,15 ,'Claims BICC' ),
			(19 ,'Earned_RIP_RISpend' ,15 ,'FDM' ),
			(20 ,'EPI Reinstatement Eurobase' ,15 ,'Eurobase' ),
			(21 ,'Eurobase' ,15 ,'CSV File' ),
			(22 ,'Expenses Actual' ,15 ,'Agresso' ),
			(23 ,'LPSO' ,15 ,'Eurobase' ),
			(24 ,'NatCatEarning' ,15 ,'Excel CatMargin' ),
			(25 ,'ObligatedPremium_MunichQQS' ,15 ,'ADM' ),
			(26 ,'ObligatedPremium_RISpend' ,15 ,'FDM' ),
			(27 ,'ObligatedPremium_SPA' ,15 ,'FDM' ),
			(28 ,'PFT' ,15 ,'FDM' ),
			(29 ,'Reinsurance_Overriding_Commission' ,15 ,'FDM' ),
			(30 ,'ReinsuranceRebates_Paid' ,15 ,'CSV File' ),
			(31 ,'ReinsuranceRebates_Ultimate' ,15 ,'CSV File' ),
			(32 ,'ResDataEventAlloc' ,15 ,'CSV File' ),
			(33 ,'ResDataRIAttClmAllocPhase1' ,15 ,'CSV File' ), 
			(34 ,'ResDataRIAttClmAllocPhase2' ,15 ,'CSV File' ), 
			(35 ,'ResDataRILargeLossAlloc' ,15 ,'CSV File' ),
			(36 ,'ReservingData' ,15 ,'ADM' ),
			(37 ,'ReservingDataPremiumAlloc' ,15 ,'ADM' ), 
			(38 ,'RI LPSO FAC' ,15 ,'Eurobase' ),
			(39 ,'RI LPSO TTY' ,15 ,'Eurobase' ),
			(40 ,'Load RIPercentage' ,15 ,'FDM' ),
			(41 ,'RIPsEventAlloc' ,15 ,'CSV File' ),
			(42 ,'Signed Profit Commission' ,15 ,'BeazleyReinsuranceMI' ),
			(43 ,'SPA_MUNQQS_ORC_TACTICAL' ,15 ,'CSV File' ),
			(44 ,'Ultimate Profit Commission' ,15 ,'CSV File' ),
			(45 ,'USBAIC' ,15 ,'FDM' ),
			(46 ,'USBESI' ,15 ,'FDM' ),
			(47 ,'USPremium' ,15 ,'FDM' ),
			(48 ,'TechnicalHub' ,16 ,'FDM' ),			
			(49 ,'IR_ViewToTable' ,17,'FDM' ),
			(50 ,'PolicySectionReference',15,'BeazleyIntelligenceODS_FULLY_PROCESSED')
			


	) AS Source(PK_ConfigID,Dataset,FK_Orchestration,SourceFrom)
			ON		(Target.PK_ConfigID=Source.PK_ConfigID)
			   
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(Dataset,FK_Orchestration,SourceFrom)
					VALUES(Source.Dataset,Source.FK_Orchestration,Source.SourceFrom)
			WHEN	MATCHED
			and [Target].[DataSet]         != Source.[DataSet]
			or [Target].[FK_Orchestration] !=Source.[FK_Orchestration]
			or [Target].[SourceFrom]       !=Source.[SourceFRom]
			THEN	UPDATE SET	Dataset = source.Dataset, 
								FK_Orchestration = source.FK_Orchestration, 
								SourceFrom = source.SourceFrom
		
		   
WHEN NOT MATCHED BY SOURCE THEN DELETE;
                                                                                                                                                                                                      
DECLARE @mergeErrorDSC int                                                                                                                                                                                  
       ,@mergeCountDSC int                                                                                                                                                                                       
SELECT @mergeErrorDSC = @@ERROR, @mergeCountDSC = @@ROWCOUNT                                                                                                                                                   
IF @mergeErrorDSC != 0                                                                                                                                                                                      
 BEGIN                                                                                                                                                                                                   
 PRINT 'ERROR OCCURRED IN MERGE FOR sch.DataSetConfig. Rows affected: ' + CAST(@mergeCountDSC AS VARCHAR(100)); -- SQL should always return zero rows affected                           
 END                                                                                                                                                                                                     
ELSE                                                                                                                                                                                                     
 BEGIN                                                                                                                                                                                                   
 PRINT 'sch.DataSetConfig rows affected by MERGE: ' + CAST(@mergeCountDSC AS VARCHAR(100));                                                                                              
 END                                                                                                                                                                                                     
  
