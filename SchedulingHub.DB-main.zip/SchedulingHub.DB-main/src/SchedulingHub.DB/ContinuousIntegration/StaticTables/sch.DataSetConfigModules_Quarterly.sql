﻿MERGE INTO [sch].[DataSetConfigModules_Quarterly] AS Target

USING (VALUES

			/********* DEPENDENCIES TABLES ON WD-15 ***********/
				(1,43,'Dependency Table','WD-15',13,15,'IFRS17_CededReAccToLandingExtract.dtsx','Landing',NULL),
				(2,43,'Dependency Table','WD-15',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing',NULL),
				(3,43,'Dependency Table','WD-15',7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing',NULL),
				(4,43,'Dependency Table','WD-15',8,15,'IFRS17_FDMToLandingExtract.dtsx','Landing',NULL),			
				(5,43,'Dependency Table','WD-15',9,15,'IFRS17_ADMToLandingExtract.dtsx','Landing',NULL),

			/********* DEPENDENCIES TABLES ON WD-10 ***********/
				(6,43,'Dependency Table','WD-10',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing',NULL),
				(7,43,'Dependency Table','WD-10',7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing',NULL),
				(8,43,'Dependency Table','WD-10',8,15,'IFRS17_FDMToLandingExtract.dtsx','Landing',NULL),			
				(9,43,'Dependency Table','WD-10',9,15,'IFRS17_ADMToLandingExtract.dtsx','Landing',NULL),

			/********* DEPENDENCIES TABLES ON WD1 ***********/
				(10,43,'Dependency Table','WD1',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing',NULL),
				(11,43,'Dependency Table','WD1',8,15,'IFRS17_FDMToLandingExtract.dtsx','Landing',NULL),

			/********* DEPENDENCIES TABLES ON WD2 ***********/
				(12,43,'Dependency Table','WD2',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing',NULL),
				(13,43,'Dependency Table','WD2',7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing',NULL),
				(14,43,'Dependency Table','WD2',8,15,'IFRS17_FDMToLandingExtract.dtsx','Landing',NULL),			
				(15,43,'Dependency Table','WD2',9,15,'IFRS17_ADMToLandingExtract.dtsx','Landing',NULL),
				(16,43,'Dependency Table','WD2',13,15,'IFRS17_CededReAccToLandingExtract.dtsx','Landing',NULL),
				(17,43,'Dependency Table','WD2',14,15,'SyndicateSplit.dtsx','Landing',NULL),

				(18,43,'Dependency Table','WD2',22,15,'IFRS17_AgressoToLandingExtract.dtsx','Landing','Agresso'),

			/********* DEPENDENCIES TABLES ON WD3 ***********/
				(19,43,'Dependency Table','WD3',7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing',NULL),

				--(1,1,'ADM-DFMs',9,15,'IFRS17_ADMToLandingExtract.dtsx','Landing',NULL),
				--(2,1,'ADM-DFMs',10,15,'IFRS17_ADM_DFM_PaymentPattern_ToLanding.dtsx','Landing',NULL),
				--(3,1,'ADM-DFMs',136,15,'[ADM].[usp_LandingToInbound_Pattern]','LandingToInbound',NULL),
				--(4,1,'ADM-DFMs',152,15,'[Inbound].[usp_InboundOutboundWorkflow_Pattern]','InboundToOutbound',NULL),
				--(5,2,'Claims_BI_ODS',7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing','claim'),
				(20,2,'Claims_BI_ODS','WD3',15,15,'IFRS17_BICCToLandingExtract.dtsx','Landing','claim'),
				(21,2,'Claims_BI_ODS','WD3',106,15,'[MDS].[usp_LandingToInbound]','LandingToInbound','claim'),
				(22,2,'Claims_BI_ODS','WD3',137,15,'[Claims_BI_ODS].[usp_LandingToInboundToOutbound]','LandingToInboundToOutbound','claim'),
				(23,2,'Claims_BI_ODS','WD3',154,15,'[Inbound].[usp_InboundOutboundWorkflow_ClaimExtensions]','Extensions','claim'),
				(24,2,'Claims_BI_ODS','WD3',167,15,'[Inbound].[usp_InboundOutboundWorkflow]','InboundToOutbound','claim'),
				--(5,3,'BICI RI Ultimate Claim',25,15,'IFRS17_BICIRI_Claim.dtsx','Landing','Reinsurance'),
				--(6,3,'BICI RI Ultimate Claim',61,15,'[BICIRI].[usp_LandingInboundWorkflow_BICI_RI_Ultimate_Claim]','LandingToInbound','Reinsurance'),
				--(7,3,'BICI RI Ultimate Claim',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
				--(8,4,'BICI_RI_Ultimate_Premium',18,15,'IFRS17_BICIRI_Ultimate.dtsx','Landing','Reinsurance'),
				--(9,4,'BICI_RI_Ultimate_Premium',65,15,'[BICIRI].[usp_LandingInboundWorkflow_BICI_RI_Ultimate_Premium]','LandingToInbound','Reinsurance'),
				--(10,4,'BICI_RI_Ultimate_Premium',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
				--(11,5,'BusinessPlan',17,15,'IFRS17_BusinessPlanLanding.dtsx','Landing','Reinsurance'),
				--(12,5,'BusinessPlan',62,15,'[BP].[usp_LandingInboundWorkflow_BusinessPlan]','LandingToInbound','Reinsurance'),
				--(13,5,'BusinessPlan',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
				--(20,6,'Ceded_Re_Claims_Incurred',13,15,'IFRS17_CededReAccToLandingExtract.dtsx','Landing','Reinsurance'),
				--(21,6,'Ceded_Re_Claims_Incurred',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
				(25,6,'Ceded_Re_Claims_Incurred','WD-15',109,15,'[Eurobase].[usp_LandingToInbound_TreatyReInsurance_ContractAttributes]','LandingToInbound','Reinsurance'),
				(26,6,'Ceded_Re_Claims_Incurred','WD-15',122,15,'[FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTreatyContractAttributes]','LandingToInbound','Reinsurance'),
				(27,6,'Ceded_Re_Claims_Incurred','WD-15',183,15,'[CededRe].[usp_LandingToInboundToOutbound_CededReClaimsIncurred]','LandingToInboundToOutbound','Reinsurance'),
				(28,7,'ReinsuranceRebates_Ultimate','WD-15',4,15,'IFRS17_UltimateRebatesToLandingExtract.dtsx','Landing','Reinsurance'),
				--(26,7,'ReinsuranceRebates_Ultimate',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
				--(27,7,'ReinsuranceRebates_Ultimate',7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing','Reinsurance'),
				--(28,7,'ReinsuranceRebates_Ultimate',8,15,'IFRS17_FDMToLandingExtract.dtsx','Landing','Reinsurance'),
				--(29,7,'ReinsuranceRebates_Ultimate',9,15,'IFRS17_ADMToLandingExtract.dtsx','Landing','Reinsurance'),
				(29,7,'ReinsuranceRebates_Ultimate','WD-15',181,15,'[ultrebsrc].[usp_LandingToInboundToOutbound_UltimateRIRebate]','LandingToInboundToOutbound','Reinsurance'),
				--(31,8,'AgressoARBIDAC',22,15,'SyndicateSplit.dtsx','Landing','Agresso'),
				--(17,8,'AgressoARBIDAC',14,15,'IFRS17_AgressoToLandingExtract.dtsx','Landing','Agresso'),
				(30,8,'AgressoARBIDAC','WD2',199,15,'EXEC [AgressoAR].[usp_LandingToInboundToOutbound_AgressoARBIDAC1]','LandingToInboundToOutbound','Agresso'),
				--(19,9,'AgressoARUS',22,15,'SyndicateSplit.dtsx','Landing','Agresso'),
				--(19,9,'AgressoARUS',14,15,'IFRS17_AgressoToLandingExtract.dtsx','Landing','Agresso'),
				(31,9,'AgressoARUS','WD2',200,15,'EXEC [AgressoAR].[usp_LandingToInboundToOutbound_AgressoARUS]','LandingToInboundToOutbound','Agresso'),
				--(2,10,'Eurobase',31,15,'EurobaseTacticalLoad.dtsx','Landing','Premium'),
				--(3,10,'Eurobase',78,15,'EXEC [Eb].[usp_LandingInboundWorkflow_EurobaseTacticalLoad]','LandingToInbound','Premium'),
				--(4,10,'Eurobase',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Premium'),
				--(40,11,'LPSO',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing',NULL),
				--(41,11,'LPSO',8,15,'IFRS17_FDMToLandingExtract.dtsx','Landing',NULL),
				(32,11,'LPSO','WD2',138,15,'EXEC [Eurobase].[usp_LandingToInbound]','LandingToInbound',NULL),
				(33,11,'LPSO','WD2',167,15,'EXEC [Inbound].[usp_InboundOutboundWorkflow]','InboundToOutbound',NULL),
				--(14,12,'NatCatEarning',2,15,'IFRS17_NatCatEarningToLandingExtract.dtsx','Landing',NULL),
				--(15,12,'NatCatEarning',108,15,'EXEC [NCME].[usp_NatCatEarningLandingToInbound_Pattern]','LandingToInbound',NULL),
				--(16,12,'NatCatEarning',152,15,'EXEC [Inbound].[usp_InboundOutboundWorkflow_Pattern]','InboundToOutbound',NULL),
				--(47,13,'RI LPSO FAC',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
				--(48,13,'RI LPSO FAC',7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing','Reinsurance'),
				(34,13,'RI LPSO FAC','WD2',139,15,'EXEC [Eurobase].[usp_LandingToInbound_FacReInsurance]','LandingToInbound','Reinsurance'),
				(35,13,'RI LPSO FAC','WD2',155,15,'EXEC [Inbound].[usp_InboundOutboundWorkflow_ReInsuranceExtensions]','Extensions','Reinsurance'),
				(36,13,'RI LPSO FAC','WD2',167,15,'EXEC [Inbound].[usp_InboundOutboundWorkflow]','InboundToOutbound','Reinsurance'),
				--(52,14,'RI LPSO TTY',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
				--(53,14,'RI LPSO TTY',7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing','Reinsurance'),
				--(54,14,'RI LPSO TTY',8,15,'IFRS17_FDMToLandingExtract.dtsx','Landing','Reinsurance'),
				--(55,14,'RI LPSO TTY',9,15,'IFRS17_ADMToLandingExtract.dtsx','Landing','Reinsurance'),
				--(56,14,'RI LPSO TTY',13,15,'IFRS17_CededReAccToLandingExtract.dtsx','Landing','Reinsurance'),
				(37,14,'RI LPSO TTY','WD2',166,15,'EXEC [Eurobase].[usp_LandingToInboundToOutbound_TreatyReInsurance]','LandingToInboundToOutbound','Reinsurance'),
				--(17,15,'BICI',34,15,'IFRS17_BICILanding.dtsx','Landing',NULL),
				--(59,15,'BICI',7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing',NULL),
				--(18,15,'BICI',212,15,'EXEC [US].[usp_BICILandingToInboundWorkflow]','LandingToInbound',NULL),
				--(19,15,'BICI',226,15,'EXEC [Inbound].[usp_InboundOutboundWorkflow_GAAP]','Landing',NULL),
				--(20,16,'BIDAC',35,15,'IFRS17_BIDACLanding.dtsx','Landing',NULL),
				--(63,16,'BIDAC',7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing',NULL),
				--(21,16,'BIDAC',213,15,'EXEC [BIDAC].[usp_LandingInboundWorkflow]','LandingToInbound',NULL),
				--(22,16,'BIDAC',226,15,'EXEC [Inbound].[usp_InboundOutboundWorkflow_GAAP]','InboundToOutbound',NULL),
				--(17,17,'BusinessPlanRI',21,15,'IFRS17_BusinessPlanLandingRI.dtsx','Landing','Reinsurance'),
				--(18,17,'BusinessPlanRI',68,15,'[BP].[usp_LandingInboundWorkflow_BusinessPlanRI]','LandingToInbound','Reinsurance'),
				--(19,17,'BusinessPlanRI',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
				--(11,18,'EPI Reinstatement Eurobase',21,15,'IFRS17_BusinessPlanLandingRI.dtsx','Landing','Reinsurance'),
				--(20,19,'Expenses Actual',24,15,'AgressoExpensesActual.dtsx','Landing','Reinsurance'),
				--(21,19,'Expenses Actual',64,15,'[Agresso].[usp_LandingInboundWorkflow_AgressoExpensesActual]','LandingToInbound','Reinsurance'),
				--(22,19,'Expenses Actual',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
				(38,20,'Signed Profit Commission','WD2',5,15,'IFRS17_BeazleyMIReinsuranceToLandingExtract.dtsx','Landing','Reinsurance'),
				--(74,20,'Signed Profit Commission',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
				(39,20,'Signed Profit Commission','WD2',198,15,'[ReinsuranceMI].[usp_LandingToInboundToOutbound_SignedProfitCommission]','LandingToInboundToOutbound','Reinsurance'),
				--(23,21,'USBAIC',36,15,'IFRS17_USBAICLanding.dtsx','Landing',NULL),
				--(77,21,'USBAIC',7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing',NULL),
				--(24,21,'USBAIC',214,15,'[US].[usp_BAICLandingToInboundWorkflow]','LandingToInbound',NULL),
				--(25,21,'USBAIC',226,15,'[Inbound].[usp_InboundOutboundWorkflow_GAAP]','InboundToOutbound',NULL),
				--(26,22,'USPremium',32,15,'USPremium.dtsx','Landing',NULL),
				--(81,22,'USPremium',7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing',NULL),
				--(27,22,'USPremium',211,15,'[us].[usp_LandingInboundWorkflow]','LandingToInbound',NULL),
				--(28,22,'USPremium',226,15,'[Inbound].[usp_InboundOutboundWorkflow_GAAP]','InboundToOutbound',NULL),
				--(23,23,'BICI TDM',23,15,'IFRS17_TDMBICIClaimsToLandingExtract.dtsx','Landing','Reinsurance'),
				--(24,23,'BICI TDM',63,15,'[TDM].[usp_LandingInboundWorkflow_BICIClaims]','LandingToInbound','Reinsurance'),
				--(25,23,'BICI TDM',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
				--(26,24,'BICI_Earned_Agresso',39,15,'IFRS17_BICIRIEarnedToLandingExtract.dtsx','Landing','Reinsurance'),
				--(27,24,'BICI_Earned_Agresso',69,15,'[BICIRI].[usp_LandingInboundWorkflow_EarnedPremium]','LandingToInbound','Reinsurance'),
				--(28,24,'BICI_Earned_Agresso',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
				--(29,25,'BICI_RI_Incurred',29,15,'IFRS17_BICIRI_Incurred.dtsx','Landing','Reinsurance'),
				--(30,25,'BICI_RI_Incurred',71,15,'[BICIRI].[usp_LandingInboundWorkflow_BICI_RI_Incurred]','LandingToInbound','Reinsurance'),
				--(31,25,'BICI_RI_Incurred',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
				--(32,26,'BICI_RI_Paid',41,15,'IFRS17_BICIRI_Paid.dtsx','Landing','Reinsurance'),
				--(33,26,'BICI_RI_Paid',71,15,'[BICIRI].[usp_LandingInboundWorkflow_BICI_RI_Paid]','LandingToInbound','Reinsurance'),
				--(34,26,'BICI_RI_Paid',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
				--(96,27,'Ceded_Re_Closed_YOA',13,15,'IFRS17_CededReAccToLandingExtract.dtsx','Landing','Reinsurance'),
				--(97,27,'Ceded_Re_Closed_YOA',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
				(40,27,'Ceded_Re_Closed_YOA','WD-15',109,15,'[Eurobase].[usp_LandingToInbound_TreatyReInsurance_ContractAttributes]','LandingToInbound','Reinsurance'),
				(41,27,'Ceded_Re_Closed_YOA','WD-15',122,15,'[FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTreatyContractAttributes]','LandingToInbound','Reinsurance'),
				(42,27,'Ceded_Re_Closed_YOA','WD-15',184,15,'[CededRe].[usp_LandingToInboundToOutbound_CededReClosedYOA]','LandingToInboundToOutbound','Reinsurance'),
				--(101,28,'Ceded_Re_ORC',13,15,'IFRS17_CededReAccToLandingExtract.dtsx','Landing','Reinsurance'),
				--(102,28,'Ceded_Re_ORC',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
				(43,28,'Ceded_Re_ORC','WD-15',109,15,'[Eurobase].[usp_LandingToInbound_TreatyReInsurance_ContractAttributes]','LandingToInbound','Reinsurance'),
				(44,28,'Ceded_Re_ORC','WD-15',122,15,'[FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTreatyContractAttributes]','LandingToInbound','Reinsurance'),
				(45,28,'Ceded_Re_ORC','WD-15',184,15,'EXEC [CededRe].[usp_LandingToInboundToOutbound_CededReOR','LandingToInboundToOutbound','Reinsurance'),
				--(106,29,'Earned_RIP_RISpend',8,15,'IFRS17_FDMToLandingExtract.dtsx','Landing','Reinsurance'),
				(46,29,'Earned_RIP_RISpend','WD-10',187,15,'[fdm].[usp_LandingToInboundToOutbound_RI_Reinstatement_Premium_Earned]','LandingToInboundToOutbound','Reinsurance'),
				--(35,30,'ObligatedPremium_Munich_QQS',28,15,'IFRS17_ObligatedPremium_Munich_QQS.dtsx','Landing','Reinsurance'),
				--(36,30,'ObligatedPremium_Munich_QQS',75,15,'[OP].[usp_LandingInboundWorkflow_ObligatedPremium_Munich_QQS]','LandingToInbound','Reinsurance'),
				--(37,30,'ObligatedPremium_Munich_QQS',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
				--(111,31,'ObligatedPremium_RISpend',8,15,'IFRS17_FDMToLandingExtract.dtsx','Landing','Reinsurance'),
				--(112,31,'ObligatedPremium_RISpend',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
				(47,31,'ObligatedPremium_RISpend','WD-10',196,15,'[fdm].[usp_LandingToInboundToOutbound_ObligatedPremium]','LandingToInboundToOutbound','Reinsurance'),
				--(38,32,'ObligatedPremium_SPA',42,15,'IFRS17_SPAObligatedPremium.dtsx','Landing','Reinsurance'),
				--(39,32,'ObligatedPremium_SPA',74,15,'[SPA].[usp_LandingInboundWorkflow_ObligatedPremium_SPA]','LandingToInbound','Reinsurance'),
				--(40,32,'ObligatedPremium_SPA',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
				(48,33,'PFT','WD-10',33,15,'PremiumForecastLanding.dtsx','Landing',NULL),
				(49,33,'PFT','WD-10',241,15,'[pft].[usp_LandingToInboundToOutboundWorkflow]','LandingToInbound',NULL),
				--(119,34,'Reinsurance_Overriding_Commission',8,15,'IFRS17_FDMToLandingExtract.dtsx','Landing','Reinsurance'),
				--(120,34,'Reinsurance_Overriding_Commission',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
				(50,34,'Reinsurance_Overriding_Commission','WD-10',186,15,'[FDM].[usp_LandingToInboundToOutbound_Reinsurance_Overriding_Commission]]','LandingToInboundToOutbound','Reinsurance'),
				(51,35,'ReinsuranceRebates_Paid','WD-15',3,15,'IFRS17_PaidRebatesToLandingExtract.dtsx','Landing','Reinsurance'),
				--(123,35,'ReinsuranceRebates_Paid',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
				--(124,35,'ReinsuranceRebates_Paid',7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing','Reinsurance'),
				--(125,35,'ReinsuranceRebates_Paid',8,15,'IFRS17_FDMToLandingExtract.dtsx','Landing','Reinsurance'),
				--(126,35,'ReinsuranceRebates_Paid',9,15,'IFRS17_ADMToLandingExtract.dtsx','Landing','Reinsurance'),
				(52,35,'ReinsuranceRebates_Paid','WD-15',202,15,'[pdrebsrc].[usp_LandingToInboundToOutbound_PaidRebates]','LandingToInboundToOutbound','Reinsurance'),
				--(41,36,'ResDataEventAlloc',19,15,'IFRS17_ADMResDataAllocToLandingExtract.dtsx','Landing','Reinsurance'),
				--(42,36,'ResDataEventAlloc',66,15,'[ADM].[usp_LandingInboundWorkflow_ResDataEventAlloc]','LandingToInbound','Reinsurance'),
				--(43,36,'ResDataEventAlloc',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
				--(44,37,'ResDataRIAttClmAlloc',38,15,'IFRS17_ADMResDataUltimateClaims.dtsx','Landing','Reinsurance'),
				--(45,37,'ResDataRIAttClmAlloc',70,15,'[ADM].[usp_LandingInboundWorkflow_ResDataRIAttClaims]','LandingToInbound','Reinsurance'),
				--(46,37,'ResDataRIAttClmAlloc',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
				--(47,38,'ResDataRILargeLossAlloc',40,15,'ADMReinsuranceReservingData_LargeLosses.dtsx','Landing','Reinsurance'),
				--(48,38,'ResDataRILargeLossAlloc',73,15,'[ADM].[usp_LandingInboundWorkflow_ReinsuranceReservingDataLargeLosses_ADM]','LandingToInbound','Reinsurance'),
				--(49,38,'ResDataRILargeLossAlloc',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
				--(137,39,'ReservingData',7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing','ReservingReinsurance'),
				--(138,39,'ReservingData',9,15,'IFRS17_ADMToLandingExtract.dtsx','Landing','ReservingReinsurance'),
				(53,39,'ReservingData','WD-10',182,15,'EXEC [ADM].[usp_LandingToInboundToOutbound]','LandingToInboundOutbound','ReservingReinsurance'),
				--(50,40,'ReservingDataPremiumAlloc',30,15,'IFRS17_ADMResDataPremiumAlloc.dtsx','Landing','Reinsurance'),
				--(51,40,'ReservingDataPremiumAlloc',76,15,'[ADM].[usp_LandingInboundWorkflow_ReservingDataPremiumAlloc]','LandingToInbound','Reinsurance'),
				--(52,40,'ReservingDataPremiumAlloc',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
				--(53,41,'RIPsEventAlloc',20,15,'IFRS17_UltimateRIPsEventToLandingExtract.dtsx','Landing','Reinsurance'),
				--(54,41,'RIPsEventAlloc',67,15,'EXEC [Ultrea].[usp_LandingInboundWorkflow_RIPsEventAlloc]','LandingToInbound','Reinsurance'),
				--(55,41,'RIPsEventAlloc',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance')
				--(146,42,'Ultimate Profit Commission',16,15,'IFRS17_UltimateProfitCommissionToLandingExtract.dtsx','Landing','Reinsurance'),
				--(147,42,'Ultimate Profit Commission',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
				--(148,42,'Ultimate Profit Commission',8,15,'IFRS17_FDMToLandingExtract.dtsx','Landing','Reinsurance'),
				(54,42,'Ultimate Profit Commission','WD1',197,15,'[ultpc].[usp_LandingToInboundToOutbound_UltimateProfitCommission]','LandingToInboundToOutbound','Reinsurance')

       )AS Source ([PK_ConfigModQID], [Fk_ConfigID], [Dataset], [WorkingDay], [Fk_Module], [Fk_Orchestration], [ModuleObjectName], [ModuleUsedFor], [Extension])
			
ON (Target.[PK_ConfigModQID] = Source.[PK_ConfigModQID])

WHEN MATCHED 
		and [Target].[Fk_ConfigID]         != Source.[Fk_ConfigID]
		or  [Target].[Dataset]    != Source.[Dataset]
		or  [Target].[WorkingDay]    != Source.[WorkingDay]
		or  [Target].[Module]  != Source.[Fk_Module]
		or  [Target].[Fk_Orchestration]  != Source.[Fk_Orchestration]
		or  [Target].[ModuleObjectName]  != Source.[ModuleObjectName]
		or  [Target].[ModuleUsedFor]  != Source.[ModuleUsedFor]
		or  [Target].[Extension]  != Source.[Extension]


THEN 
UPDATE SET [Fk_ConfigID]         = Source.[Fk_ConfigID]
		,[Dataset]    = Source.[Dataset]
		,[WorkingDay]    = Source.[WorkingDay]
		,[Module]  = Source.[Fk_Module]
		,[Fk_Orchestration]  = Source.[Fk_Orchestration]
		,[ModuleObjectName]  = Source.[ModuleObjectName]
		,[ModuleUsedFor]  = Source.[ModuleUsedFor]
		,[Extension]  = Source.[Extension]
WHEN NOT MATCHED BY TARGET THEN

INSERT ([PK_ConfigModQID], [Fk_ConfigID], [Dataset], [WorkingDay], [Module], [Fk_Orchestration], [ModuleObjectName], [ModuleUsedFor], [Extension])
VALUES (Source.[PK_ConfigModQID], Source.[Fk_ConfigID], Source.[Dataset], Source.[WorkingDay], Source.[Fk_Module], Source.[Fk_Orchestration], Source.[ModuleObjectName], Source.[ModuleUsedFor],Source.[Extension])
		   
WHEN NOT MATCHED BY SOURCE THEN DELETE;
                                                                                                                                                                                                      
DECLARE @mergeErrorDCMQ int                                                                                                                                                                                  
       ,@mergeCountDCMQ int                                                                                                                                                                                       
SELECT @mergeErrorDCMQ = @@ERROR, @mergeCountDCMQ = @@ROWCOUNT                                                                                                                                                   
IF @mergeErrorDCMQ != 0                                                                                                                                                                                      
 BEGIN                                                                                                                                                                                                   
 PRINT 'ERROR OCCURRED IN MERGE FOR [sch].[DataSetConfigModules_Quarterly]. Rows affected: ' + CAST(@mergeCountDCMQ AS VARCHAR(100)); -- SQL should always return zero rows affected                           
 END                                                                                                                                                                                                     
ELSE                                                                                                                                                                                                     
 BEGIN                                                                                                                                                                                                   
 PRINT '[sch].[DataSetConfigModules_Quarterly] rows affected by MERGE: ' + CAST(@mergeCountDCMQ AS VARCHAR(100));                                                                                              
 END                                                                                                                                                                                                     


