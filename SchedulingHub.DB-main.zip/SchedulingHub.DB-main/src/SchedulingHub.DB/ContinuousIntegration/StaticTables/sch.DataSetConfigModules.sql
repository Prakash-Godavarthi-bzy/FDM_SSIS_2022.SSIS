﻿/*
	Change Version	: v1.2	 
	Sprint			: BR1 Q3 24 Committed
	Author		    : Shah Nawaz Ahmed    <shahnawaz.ahmed@beazley.com>
	Modify Date	    : 12/07/2024
	Description		: https://beazley.atlassian.net/browse/I1B-5622   
									Added new modules for PolicySectionReference DS
*/
MERGE INTO [sch].[DataSetConfigModules] AS Target

USING (VALUES
			(1, 1, 'ADM-DFMs', 9, 15, 'IFRS17_ADMToLandingExtract.dtsx' ,'Landing', NULL),
			(2, 1, 'ADM-DFMs', 10, 15, 'IFRS17_ADM_DFM_PaymentPattern_ToLanding.dtsx', 'Landing', NULL),
			(3, 1, 'ADM-DFMs', 136, 15, '[ADM].[usp_LandingToInbound_Pattern]', 'LandingToInbound', NULL),
			(4, 1, 'ADM-DFMs', 152, 15, '[Inbound].[usp_InboundOutboundWorkflow_Pattern]', 'InboundToOutbound', NULL),

			(5, 2, 'AgressoARBIDAC', 22, 15, 'IFRS17_AgressoToLandingExtract.dtsx', 'Landing', NULL),
			(6, 2, 'AgressoARBIDAC', 199, 15, '[AgressoAR].[usp_LandingToInboundToOutbound_AgressoARBIDAC]', 'LandingToInboundToOutbound', 'Agresso'),

			(7, 3, 'AgressoARUS', 22, 15, 'IFRS17_AgressoToLandingExtract.dtsx', 'Landing', NULL),
			(8, 3, 'AgressoARUS', 200, 15, '[AgressoAR].[usp_LandingToInboundToOutbound_AgressoARUS]', 'LandingToInboundToOutbound', 'Agresso'),

			(9, 4, 'BICI' ,7 ,15 ,'IFRS17_MDSToLandingExtract.dtsx' ,'Landing', NULL),			
			(10, 4, 'BICI' ,34 ,15 ,'IFRS17_BICILanding.dtsx' ,'Landing' ,NULL),
			(11, 4, 'BICI' ,212 ,15 ,'[US].[usp_BICILandingToInboundWorkflow]' ,'LandingToInbound' ,NULL),
			(12, 4, 'BICI' ,226 ,15 ,'[Inbound].[usp_InboundOutboundWorkflow_GAAP]' ,'InboundToOutbound' ,NULL),
			
			(13, 5, 'BICI RI Ultimate Claim' ,25 ,15 ,'IFRS17_BICIRI_Claim.dtsx' ,'Landing' ,NULL),
			(14, 5, 'BICI RI Ultimate Claim' ,61 ,15 ,'[BICIRI].[usp_LandingInboundWorkflow_BICI_RI_Ultimate_Claim]' ,'LandingToInbound' ,'Reinsurance'),
			(15, 5, 'BICI RI Ultimate Claim' ,91 ,15 ,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]' ,'InboundToOutbound', NULL),
			
			(16, 6, 'BICI TDM' ,23 ,15 ,'IFRS17_TDMBICIClaimsToLandingExtract.dtsx' ,'Landing' ,NULL),
			(17, 6, 'BICI TDM' ,63 ,15 ,'[TDM].[usp_LandingInboundWorkflow_BICIClaims]' ,'LandingToInbound' ,'Reinsurance'),
			(18, 6, 'BICI TDM' ,91 ,15 ,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]' ,'InboundToOutbound', NULL),
			
			(19, 7, 'BICI_Earned_Agresso' ,6 ,15 ,'IFRS17_EurobaseToLandingExtract.dtsx' ,'Landing', NULL),	
			(20, 7, 'BICI_Earned_Agresso', 8, 15, 'IFRS17_FDMToLandingExtract.dtsx' ,'Landing', NULL),			
			(21, 7, 'BICI_Earned_Agresso' ,39 ,15 ,'IFRS17_BICIRI_EarnedPremium.dtsx','Landing' ,NULL),
			(22, 7, 'BICI_Earned_Agresso' ,69 ,15 ,'[Agresso].[usp_LandingToInboundToOutboundWorkflow_BICIRI_EarnedPremium]' ,'LandingToInboundToOutbound' ,'Reinsurance' ),
			
			(23, 8, 'BICI_Earned_Agresso' ,6 ,15 ,'IFRS17_EurobaseToLandingExtract.dtsx' ,'Landing', NULL),	
			(24, 8, 'BICI_Earned_Agresso', 8, 15, 'IFRS17_FDMToLandingExtract.dtsx' ,'Landing', NULL),			
			(25, 8, 'BICI_ORC_TACTICAL' ,28 ,15 ,'IFRS17_BICI_Orc_Tactical.dtsx', 'Landing', NULL),
			(26, 8, 'BICI_ORC_TACTICAL' ,80 ,15 ,'[Agresso].[usp_LandingToInboundToOutboundWorkflow_BICIRI_Orc_Tactical]' ,'LandingToInboundToOutbound' ,'Reinsurance' ),
			
			(27, 9, 'BICI_RI_Incurred' ,6 ,15 ,'IFRS17_EurobaseToLandingExtract.dtsx' ,'Landing', NULL),
			(28, 9, 'BICI_RI_Incurred' ,29 ,15 ,'IFRS17_BICIRI_Incurred.dtsx' ,'Landing', NULL),
			(29, 9, 'BICI_RI_Incurred' ,71 ,15 ,'[Agresso].[usp_LandingToInboundToOutboundWorkflow_BICIRI_Incurred]' ,'LandingToInboundToOutbound' ,'Reinsurance' ),

			(30, 10 ,'BICI_RI_Paid' ,6 ,15 ,'IFRS17_EurobaseToLandingExtract.dtsx' ,'Landing', NULL),
			(31, 10 ,'BICI_RI_Paid' ,41 ,15 ,'IFRS17_BICIRI_Paid.dtsx' ,'Landing', NULL),
			(32, 10 ,'BICI_RI_Paid' ,72 ,15 ,'[Agresso].[usp_LandingToInboundToOutboundWorkflow_BICIRI_Paid]' ,'LandingToInboundToOutbound' ,'Reinsurance' ),
			
			(33, 11 ,'BICI_RI_Ultimate_Premium' ,18 ,15 ,'IFRS17_BICIRI_Ultimate.dtsx' ,'Landing', NULL),
			(34, 11 ,'BICI_RI_Ultimate_Premium' ,65 ,15 ,'[BICIRI].[usp_LandingInboundWorkflow_BICI_RI_Ultimate_Premium]' ,'LandingToInbound' ,'Reinsurance' ),
			(35, 11 ,'BICI_RI_Ultimate_Premium' ,91 ,15 ,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]' ,'InboundToOutbound', NULL),
									
			(36, 12, 'BIDAC' ,6 ,15 ,'IFRS17_EurobaseToLandingExtract.dtsx' ,'Landing', NULL),
			(37, 12, 'BIDAC' ,7 ,15 ,'IFRS17_MDSToLandingExtract.dtsx' ,'Landing', NULL),			
			(38, 12 ,'BIDAC' ,35 ,15 ,'IFRS17_BIDACLanding.dtsx' ,'Landing' ,NULL ),
			(39, 12 ,'BIDAC' ,213 ,15 ,'[BIDAC].[usp_LandingInboundWorkflow]' ,'LandingToInbound' ,NULL ),
			(40, 12 ,'BIDAC' ,226 ,15 ,'[Inbound].[usp_InboundOutboundWorkflow_GAAP]' ,'InboundToOutbound' ,NULL ),
			
			(41, 13 ,'BusinessPlan' ,17 ,15 ,'IFRS17_BusinessPlanLanding.dtsx' ,'Landing', NULL),
			(42, 13 ,'BusinessPlan' ,62 ,15 ,'[BP].[usp_LandingInboundWorkflow_BusinessPlan]' ,'LandingToInbound' ,'Reinsurance' ),
			(43, 13 ,'BusinessPlan' ,91 ,15 ,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]' ,'InboundToOutbound', NULL),
			
			(44, 14 ,'BusinessPlanRI' ,21 ,15 ,'IFRS17_BusinessPlanLandingRI.dtsx' ,'Landing', NULL),
			(45, 14 ,'BusinessPlanRI' ,68 ,15 ,'[BP].[usp_LandingInboundWorkflow_BusinessPlanRI]' ,'LandingToInbound' ,'Reinsurance' ),
			(46, 14 ,'BusinessPlanRI' ,91 ,15 ,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]' ,'InboundToOutbound', NULL),
			
			(47, 15 ,'Ceded_Re_Claims_Incurred', 6, 15, 'IFRS17_EurobaseToLandingExtract.dtsx', 'Landing' ,NULL),
			(48, 15 ,'Ceded_Re_Claims_Incurred', 8, 15, 'IFRS17_FDMToLandingExtract.dtsx', 'Landing', NULL),			
			(49, 15 ,'Ceded_Re_Claims_Incurred' ,13 ,15 ,'IFRS17_CededReAccToLandingExtract.dtsx' ,'Landing', NULL),
			(50, 15 ,'Ceded_Re_Claims_Incurred' ,183 ,15 ,'[CededRe].[usp_LandingToInboundToOutbound_CededReClaimsIncurred]' ,'LandingToInboundToOutbound' ,'Reinsurance' ),
			
			(51, 16 ,'Ceded_Re_Closed_YOA', 6, 15, 'IFRS17_EurobaseToLandingExtract.dtsx', 'Landing' ,NULL),
			(52, 16 ,'Ceded_Re_Closed_YOA', 8, 15, 'IFRS17_FDMToLandingExtract.dtsx', 'Landing', NULL),			
			(53, 16 ,'Ceded_Re_Closed_YOA' ,13 ,15 ,'IFRS17_CededReAccToLandingExtract.dtsx' ,'Landing', NULL),
			(54, 16 ,'Ceded_Re_Closed_YOA' ,184 ,15 ,'[CededRe].[usp_LandingToInboundToOutbound_CededReClosedYOA]' ,'LandingToInboundToOutbound' ,'Reinsurance' ),
			
			(55, 17 ,'Ceded_Re_ORC', 6, 15, 'IFRS17_EurobaseToLandingExtract.dtsx', 'Landing' ,NULL),
			(56, 17 ,'Ceded_Re_ORC', 8, 15, 'IFRS17_FDMToLandingExtract.dtsx', 'Landing', NULL),				
			(57, 17 ,'Ceded_Re_ORC' ,13 ,15 ,'IFRS17_CededReAccToLandingExtract.dtsx' ,'Landing', NULL),
			(58, 17 ,'Ceded_Re_ORC' ,185 ,15 ,'[CededRe].[usp_LandingToInboundToOutbound_CededReORC]' ,'LandingToInboundToOutbound' ,'Reinsurance'),
			
			(59, 18 ,'Claims_BI_ODS' ,7 ,15 ,'IFRS17_MDSToLandingExtract.dtsx' ,'Landing', NULL),
			(60, 18 ,'Claims_BI_ODS' ,15 ,15 ,'IFRS17_BICCToLandingExtract.dtsx' ,'Landing', NULL),
			(61, 18 ,'Claims_BI_ODS' ,137 ,15 ,'[Claims_BI_ODS].[usp_LandingToInboundToOutbound]' ,'LandingToInboundToOutbound', 'claim' ),
			
			(62, 19, 'Earned_RIP_RISpend', 8, 15, 'IFRS17_FDMToLandingExtract.dtsx' ,'Landing', NULL),
			(63, 19, 'Earned_RIP_RISpend', 187, 15, '[fdm].[usp_LandingToInboundToOutbound_RI_Reinstatement_Premium_Earned]', 'LandingToInboundToOutbound', 'Reinsurance'),
			
			(64, 20, 'EPI Reinstatement Eurobase', 14, 15, 'SyndicateSplit.dtsx', 'Landing', NULL), 
			(65, 20, 'EPI Reinstatement Eurobase', 27, 15, 'IFRS17_EurobaseEPIReinstatement.dtsx', 'Landing', NULL),
			(66, 20, 'EPI Reinstatement Eurobase', 77, 15, '[Eurobase].[usp_LandingToInboundToOutbound_EPIReinstatement]', 'LandingToInboundToOutbound', 'Reinsurance'),
			
			(67, 21 ,'Eurobase' ,31 ,15 ,'EurobaseTacticalLoad.dtsx' ,'Landing', NULL),
			(68, 21 ,'Eurobase' ,78 ,15 ,'[Eb].[usp_LandingInboundWorkflow_EurobaseTacticalLoad]' ,'LandingToInbound' ,'Premium'),
			(69, 21 ,'Eurobase' ,91 ,15 ,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]' ,'InboundToOutbound',NULL),
			
			(70, 22 ,'Expenses Actual', 14, 15, 'SyndicateSplit.dtsx' ,'Landing', NULL), 			
			(71, 22, 'Expenses Actual', 24, 15, 'IFRS17_AExpensesActualLanding.dtsx', 'Landing', NULL),
			(72, 22, 'Expenses Actual', 64, 15, '[Agresso].[usp_LandingToInboundToOutboundWorkflow_AgressoExpensesActual]' ,'LandingToInboundToOutbound' ,'Reinsurance' ),
			
			(73, 23 ,'LPSO', 6, 15, 'IFRS17_EurobaseToLandingExtract.dtsx', 'Landing' ,NULL),
			(74, 23 ,'LPSO', 7, 15, 'IFRS17_MDSToLandingExtract.dtsx', 'Landing', NULL),
			(75, 23 ,'LPSO', 8, 15, 'IFRS17_FDMToLandingExtract.dtsx', 'Landing', NULL),
			(76, 23 ,'LPSO', 138, 15, '[Eurobase].[usp_LandingToInboundToOutbound_LPSO]' ,'LandingToInboundToOutbound', NULL),
			
			(77, 24 ,'NatCatEarning' ,2 ,15 ,'IFRS17_NatCatEarningToLandingExtract.dtsx' ,'Landing' ,NULL ),
			(78, 24 ,'NatCatEarning' ,108 ,15 ,'[NCME].[usp_NatCatEarningLandingToInbound_Pattern]' ,'LandingToInbound' ,NULL ),
			(79, 24 ,'NatCatEarning' ,152 ,15 ,'[Inbound].[usp_InboundOutboundWorkflow_Pattern]' ,'InboundToOutbound' ,NULL ),
			
			(80, 25 ,'ObligatedPremium_MunichQQS', 8, 15, 'IFRS17_FDMToLandingExtract.dtsx', 'Landing', NULL),			
			(81, 25 ,'ObligatedPremium_MunichQQS' ,9 ,15 ,'IFRS17_ADMToLandingExtract.dtsx' ,'Landing' , NULL),
			(82, 25 ,'ObligatedPremium_MunichQQS' ,75 ,15 ,' [OP].[usp_LandingToInboundToOutbound_ObligatedPremium_MunichQQS]' ,'LandingToInboundToOutbound' ,'Reinsurance' ),
			
			(83, 26 ,'ObligatedPremium_RISpend', 6, 15, 'IFRS17_EurobaseToLandingExtract.dtsx', 'Landing' ,NULL),			
			(84, 26 ,'ObligatedPremium_RISpend' ,8 ,15 ,'IFRS17_FDMToLandingExtract.dtsx' ,'Landing', NULL),
			(85, 26 ,'ObligatedPremium_RISpend' ,196 ,15 ,'[fdm].[usp_LandingToInboundToOutbound_ObligatedPremium]' ,'LandingToInboundToOutbound' ,'Reinsurance' ),
			
			(86, 27 ,'ObligatedPremium_SPA', 6, 15, 'IFRS17_EurobaseToLandingExtract.dtsx', 'Landing' ,NULL),
			(87, 27 ,'ObligatedPremium_SPA' ,8 ,15 ,'IFRS17_FDMToLandingExtract.dtsx' ,'Landing', NULL),
			(88, 27 ,'ObligatedPremium_SPA', 14, 15, 'SyndicateSplit.dtsx' ,'Landing', NULL), 						
			(89, 27 ,'ObligatedPremium_SPA' ,33 ,15 ,'PremiumForecastLanding.dtsx' ,'Landing', NULL),
			(90, 27 ,'ObligatedPremium_SPA' ,74 ,15 ,'[SPA].[usp_LandingToInboundToOutbound_ObligatedPremium_SPA] ' ,'LandingToInboundToOutbound' ,'Reinsurance' ),
			
			(91, 28 ,'PFT' ,33 ,15 ,'PremiumForecastLanding.dtsx' ,'Landing' ,NULL ),
			(92, 28 ,'PFT' ,241 ,15 ,'[pft].[usp_LandingToInboundToOutboundWorkflow]' ,'LandingToInboundToOutbound' ,NULL ),
			
			(93, 29 ,'Reinsurance_Overriding_Commission', 6, 15, 'IFRS17_EurobaseToLandingExtract.dtsx', 'Landing', NULL),			
			(94, 29 ,'Reinsurance_Overriding_Commission' ,8 ,15 ,'IFRS17_FDMToLandingExtract.dtsx' ,'Landing', NULL),
			(95, 29 ,'Reinsurance_Overriding_Commission' ,186 ,15 ,'[FDM].[usp_LandingToInboundToOutbound_Reinsurance_Overriding_Commission]]' ,'LandingToInboundToOutbound' ,'Reinsurance' ),
			
			(96, 30 ,'ReinsuranceRebates_Paid' ,3 ,15 ,'IFRS17_PaidRebatesToLandingExtract.dtsx' ,'Landing', NULL),
			(97, 30 ,'ReinsuranceRebates_Paid', 6, 15, 'IFRS17_EurobaseToLandingExtract.dtsx', 'Landing', NULL),			
			(98, 30 ,'ReinsuranceRebates_Paid' ,8 ,15 ,'IFRS17_FDMToLandingExtract.dtsx' ,'Landing', NULL),
			(99, 30 ,'ReinsuranceRebates_Paid' ,9 ,15 ,'IFRS17_ADMToLandingExtract.dtsx' ,'Landing', NULL),
			(100, 30 ,'ReinsuranceRebates_Paid' ,13 ,15 ,'IFRS17_CededReAccToLandingExtract.dtsx' ,'Landing', NULL),
			(101, 30 ,'ReinsuranceRebates_Paid' ,202 ,15 ,'[pdrebsrc].[usp_LandingToInboundToOutbound_PaidRebates]' ,'LandingToInboundToOutbound' ,'Reinsurance' ),
			
			(102, 31 ,'ReinsuranceRebates_Ultimate' ,4 ,15 ,'IFRS17_UltimateRebatesToLandingExtract.dtsx' ,'Landing', NULL),
			(103, 31 ,'ReinsuranceRebates_Ultimate', 6, 15, 'IFRS17_EurobaseToLandingExtract.dtsx', 'Landing', NULL),			
			(104, 31 ,'ReinsuranceRebates_Ultimate' ,8 ,15 ,'IFRS17_FDMToLandingExtract.dtsx' ,'Landing', NULL),
			(105, 31 ,'ReinsuranceRebates_Ultimate' ,9 ,15 ,'IFRS17_ADMToLandingExtract.dtsx' ,'Landing', NULL),
			(106, 31 ,'ReinsuranceRebates_Ultimate' ,13 ,15 ,'IFRS17_CededReAccToLandingExtract.dtsx' ,'Landing', NULL),
			(107, 31 ,'ReinsuranceRebates_Ultimate' ,181 ,15 ,'[ultrebsrc].[usp_LandingToInboundToOutbound_UltimateRIRebate]' ,'LandingToInboundToOutbound' ,'Reinsurance' ),
			
			(108, 32 ,'ResDataEventAlloc' ,19 ,15 ,'IFRS17_ADMResDataAllocToLandingExtract.dtsx' ,'Landing', NULL),
			(109, 32 ,'ResDataEventAlloc' ,66 ,15 ,'[ADM].[usp_LandingToInboundToOutbound_ResDataEventAlloc]' ,'LandingToInboundToOutbound' ,'Reinsurance' ),
					--(110, 32 ,'ResDataEventAlloc' ,91 ,15 ,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]' ,'InboundToOutbound', NULL),

			(110, 33 ,'ResDataRIAttClmAllocPase1' ,9 ,15 ,'IFRS17_ADMToLandingExtract.dtsx' ,'Landing', NULL),			
			(111, 33 ,'ResDataRIAttClmAllocPase1' ,37 ,15 ,'ADMResDataAttClmAllocPhase1.dtsx' ,'Landing', NULL),
			(112, 33 ,'ResDataRIAttClmAllocPase1' ,70 ,15 ,'[ADMRI].[ResDataAttClmAllocLandingPhase1]' ,'LandingProc', NULL),
			
			(113, 34 ,'ResDataRIAttClmAllocPase2' ,38 ,15 ,'ADMResDataAttClmAllocPhase2.dtsx' ,'Landing', NULL),
			(114, 34 ,'ResDataRIAttClmAllocPase2' ,82 ,15 ,'[ADMRI].[ResDataAttClmAllocLandingPhase2]' ,'Landingproc', NULL),
			(115, 34 ,'ResDataRIAttClmAllocPase2' ,168 ,15 ,'[ADM].[usp_LandingToInboundToOutbound_ResDataRIAttClmAlloc]' ,'LandingToInboundToOutbound' ,'Reinsurance' ),
			
			(116, 35 ,'ResDataRILargeLossAlloc' ,40 ,15 ,'ADMReinsuranceReservingData_LargeLosses.dtsx' ,'Landing', NULL),
			(117, 35 ,'ResDataRILargeLossAlloc' ,73 ,15 ,'[ADM].[usp_LandingToInboundToOutbound_ReinsuranceReservingDataLargeLosses_ADM]' ,'LandingToInboundToOutbound' ,'Reinsurance' ),
					--(119, 35 ,'ResDataRILargeLossAlloc' ,91 ,15 ,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]' ,'InboundToOutbound', NULL),
			
			(118, 36 ,'ReservingData' ,7 ,15 ,'IFRS17_MDSToLandingExtract.dtsx' ,'Landing' ,NULL),
			(119, 36 ,'ReservingData' ,9 ,15 ,'IFRS17_ADMToLandingExtract.dtsx' ,'Landing' ,NULL),
			(120, 36 ,'ReservingData' ,182 ,15 ,'[ADM].[usp_LandingToInboundToOutbound]' ,'LandingToInboundToOutbound' ,'ReservingReinsurance' ),
			
			(121, 37 ,'ReservingDataPremiumAlloc' ,6 ,15 ,'IFRS17_EurobaseToLandingExtract.dtsx' ,'Landing', NULL),
			(122, 37 ,'ReservingDataPremiumAlloc' ,8 ,15 ,'IFRS17_FDMToLandingExtract.dtsx' ,'Landing', NULL),
			(123, 37 ,'ReservingDataPremiumAlloc' ,9 ,15 ,'IFRS17_ADMToLandingExtract.dtsx' ,'Landing', NULL),
			(124, 37 ,'ReservingDataPremiumAlloc' ,13 ,15 ,'IFRS17_CededReAccToLandingExtract.dtsx' ,'Landing', NULL),
			(125, 37 ,'ReservingDataPremiumAlloc' ,14 ,15 ,'SyndicateSplit.dtsx' ,'Landing', NULL),
			(126, 37 ,'ReservingDataPremiumAlloc' ,7 ,15 ,'IFRS17_MDSToLandingExtract.dtsx' ,'Landing', NULL),
			(127, 37 ,'ReservingDataPremiumAlloc' ,76 ,15 ,'[ADM].[usp_LandingToInboundToOutbound_ReservingDataPremiumAlloc]' ,'LandingToInboundToOutbound' ,'Reinsurance' ),
			
			(128, 38, 'RI LPSO FAC', 7 ,15 ,'IFRS17_MDSToLandingExtract.dtsx', 'Landing', NULL),			
			(129, 38, 'RI LPSO FAC', 6 ,15 ,'IFRS17_EurobaseToLandingExtract.dtsx', 'Landing', NULL),
			(130, 38, 'RI LPSO FAC', 139 ,15, '[Eurobase].[usp_LandingToInboundToOutbound_FacReInsurance]', 'LandingToInboundToOutbound', 'Reinsurance'),

			(131, 39, 'RI LPSO TTY', 6, 15, 'IFRS17_EurobaseToLandingExtract.dtsx', 'Landing', NULL),
			(132, 39, 'RI LPSO TTY', 7, 15, 'IFRS17_MDSToLandingExtract.dtsx', 'Landing', NULL),			
			(133, 39, 'RI LPSO TTY', 8, 15, 'IFRS17_FDMToLandingExtract.dtsx', 'Landing', NULL),
			(134, 39, 'RI LPSO TTY', 9, 15, 'IFRS17_ADMToLandingExtract.dtsx', 'Landing', NULL),
			(135, 39, 'RI LPSO TTY', 13, 15, 'IFRS17_CededReAccToLandingExtract.dtsx', 'Landing' , NULL),
			(136, 39, 'RI LPSO TTY', 14, 15, 'SyndicateSplit.dtsx', 'Landing', NULL),
			(137, 39, 'RI LPSO TTY', 166, 15, '[Eurobase].[usp_LandingToInboundToOutbound_TreatyReInsurance]' ,'LandingToInboundToOutbound' ,'Reinsurance' ),
			
			(138, 40 ,'Load RIPercentage' ,8 ,15 ,'IFRS17_FDMToLandingExtract.dtsx' ,'Landing' ,NULL ),
			(139, 40 ,'Load RIPercentage' ,79 ,15 ,'[fdm].[usp_LoadtoRI_Percentage]' ,'Load RIPercentage' ,NULL ),
			(140, 40 ,'Load RIPercentage' ,112 ,15 ,'[fdm].[usp_LandingToInbound_RI_Percentage]' ,'LandingToInbound' ,NULL ),
			
			(141, 41 ,'RIPsEventAlloc' ,20 ,15 ,'IFRS17_UltimateRIPsEventToLandingExtract.dtsx' ,'Landing', NULL),
			(142, 41 ,'RIPsEventAlloc' ,67 ,15 ,'[Ultrea].[usp_LandingToInboundToOutbound_RIPsEventAlloc]' ,'LandingToInboundToOutbound' ,'Reinsurance' ),
					--(145, 41 ,'RIPsEventAlloc' ,91 ,15 ,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]' ,'InboundToOutbound', NULL),
			
			(143, 42 ,'Signed Profit Commission' ,5 ,15 ,'IFRS17_BeazleyMIReinsuranceToLandingExtract.dtsx' ,'Landing', NULL),
			(144, 42, 'Signed Profit Commission', 6, 15, 'IFRS17_EurobaseToLandingExtract.dtsx', 'Landing', NULL),
			(145, 42 ,'Signed Profit Commission' ,8 ,15 ,'IFRS17_FDMToLandingExtract.dtsx' ,'Landing', NULL),
			(146, 42, 'Signed Profit Commission', 9, 15, 'IFRS17_ADMToLandingExtract.dtsx', 'Landing', NULL),
			(147, 42 ,'Signed Profit Commission' ,13 ,15 ,'IFRS17_CededReAccToLandingExtract.dtsx' ,'Landing', NULL),
			(148, 42 ,'Signed Profit Commission' ,198 ,15 ,'[ReinsuranceMI].[usp_LandingToInboundToOutbound_SignedProfitCommission]' ,'LandingToInboundToOutbound' ,'Reinsurance' ),
			
			(149, 43, 'SPA_MUNQQS_ORC_TACTICAL', 6, 15, 'IFRS17_EurobaseToLandingExtract.dtsx', 'Landing', NULL),
			(150, 43, 'SPA_MUNQQS_ORC_TACTICAL', 7, 15, 'IFRS17_MDSToLandingExtract.dtsx', 'Landing', NULL),			
			(151, 43, 'SPA_MUNQQS_ORC_TACTICAL', 8, 15, 'IFRS17_FDMToLandingExtract.dtsx', 'Landing', NULL),
			(152, 43, 'SPA_MUNQQS_ORC_TACTICAL', 33, 15, 'PremiumForecastLanding.dtsx', 'Landing', NULL),			
			(153, 43 ,'SPA_MUNQQS_ORC_TACTICAL' ,42 ,15 ,'IFRS17_SPA_MUNQQS_ORC_Tactical.dtsx' ,'Landing', NULL),
			(154, 43 ,'SPA_MUNQQS_ORC_TACTICAL' ,81 ,15 ,'[SPA].[usp_LandingToInboundToOutbound_SPA_MUNQQS_ORC_TACTICAL]' ,'LandingToInboundToOutbound' ,'Reinsurance' ),
		
			(155, 44, 'Ultimate Profit Commission', 6, 15, 'IFRS17_EurobaseToLandingExtract.dtsx', 'Landing', NULL),			
			(156, 44, 'Ultimate Profit Commission', 14, 15, 'SyndicateSplit.dtsx', 'Landing', NULL),			
			(157, 44 ,'Ultimate Profit Commission' ,16 ,15 ,'IFRS17_UltimateProfitCommissionToLandingExtract.dtsx' ,'Landing', NULL),
			(158, 44 ,'Ultimate Profit Commission' ,197 ,15 ,'[ultpc].[usp_LandingToInboundToOutbound_UltimateProfitCommission]' ,'LandingToInboundToOutbound' ,'Reinsurance' ),
			
			(159, 45 ,'USBAIC' ,36 ,15 ,'IFRS17_USBAICLanding.dtsx' ,'Landing' ,NULL ),
			(160, 45 ,'USBAIC' ,214 ,15 ,'[US].[usp_BAICLandingToInboundWorkflow]' ,'LandingToInbound' ,NULL ),
			(161, 45 ,'USBAIC' ,226 ,15 ,'[Inbound].[usp_InboundOutboundWorkflow_GAAP]' ,'InboundToOutbound' ,NULL ),			
			
			(162, 46 ,'USBESI' ,7 ,15 ,'IFRS17_MDSToLandingExtract.dtsx' ,'Landing' ,NULL ),
			(163, 46 ,'USBESI' ,43 ,15 ,'IFRS17_PyramidToLandingExtract.dtsx' ,'Landing' ,NULL ),
			(164, 46 ,'USBESI' ,215 ,15 ,'[Pyramid].[usp_LandingToInboundToOutboundWorkflow_USBESI]' ,'LandingToInboundToOutbound' ,NULL )	,

			(165, 47 ,'USPremium' ,7 ,15 ,'IFRS17_MDSToLandingExtract.dtsx' ,'Landing' ,NULL ),			
			(166, 47 ,'USPremium' ,32 ,15 ,'USPremium.dtsx' ,'Landing' ,NULL ),
			(167, 47 ,'USPremium' ,211 ,15 ,'[us].[usp_LandingInboundWorkflow]' ,'LandingToInbound' ,NULL ),
			(168, 47 ,'USPremium' ,226 ,15 ,'[Inbound].[usp_InboundOutboundWorkflow_GAAP]' ,'InboundToOutbound' ,NULL ),
			
			(169, 19, 'Earned_RIP_RISpend', 30, 15, 'IFRS17_Earned_RIP_RISpendBESI.dtsx' ,'Landing', NULL),
			(170, 26 ,'ObligatedPremium_RISpend' ,45 ,15 ,'IFRS17_ObligatedPremiumRISpendBESI.dtsx' ,'Landing', NULL),
			(171, 29 ,'Reinsurance_Overriding_Commission' ,44 ,15 ,'IFRS17_RISpendBESI_ORCFileTolanding.dtsx' ,'Landing', NULL),
			(172, 44 ,'NCB Landing' ,46 ,15 ,'IFRS17_NoClaimBonusLanding.dtsx' ,'Landing', NULL),
			(173, 40 ,'Load RIPercentage' ,113 ,15 ,'[Inbound].[usp_InboundOutboundWorkflow_RIPercentage]' ,'InboundToOutbound' ,NULL ),
			(174, 50 ,'PolicySectionReference' ,15 ,15 ,'IFRS17_BICCToLandingExtract.dtsx' ,'Landing', NULL),
			(175, 50 ,'PolicySectionReference' ,140 ,15 ,'[Claims_BI_ODS].[usp_LandingToInbound_PolicySectionReference]' ,'LandingToInbound', NULL),
			(176, 50 ,'PolicySectionReference' ,153 ,15 ,'[Inbound].[usp_InboundOutboundWorkflow_PolicySectionReferences]' ,'LandingToInbound', NULL),
			(177, 39, 'RI LPSO TTY', 47, 15, 'IFRS17_FACPrgogrammes.dtsx' ,'Landing', NULL)

			  
       )AS Source ([PK_ConfigModID], [Fk_ConfigID], [Dataset], [Module], [Fk_Orchestration], [ModuleObjectName], [ModuleUsedFor], [Extension])
			
ON (Target.[PK_ConfigModID] = Source.[PK_ConfigModID])

WHEN MATCHED 
		and [Target].[Fk_ConfigID]         != Source.[Fk_ConfigID]
		or  [Target].[Dataset]    != Source.[Dataset]
		or  [Target].[Module]  != Source.[Module]
		or  [Target].[Fk_Orchestration]  != Source.[Fk_Orchestration]
		or  [Target].[ModuleObjectName]  != Source.[ModuleObjectName]
		or  [Target].[ModuleUsedFor]  != Source.[ModuleUsedFor]
		or  [Target].[Extension]  != Source.[Extension]


THEN 
UPDATE SET [Fk_ConfigID]         = Source.[Fk_ConfigID]
		,[Dataset]    = Source.[Dataset]
		,[Module]  = Source.[Module]
		,[Fk_Orchestration]  = Source.[Fk_Orchestration]
		,[ModuleObjectName]  = Source.[ModuleObjectName]
		,[ModuleUsedFor]  = Source.[ModuleUsedFor]
		,[Extension]  = Source.[Extension]
WHEN NOT MATCHED BY TARGET THEN

INSERT ([PK_ConfigModID], [Fk_ConfigID], [Dataset], [Module], [Fk_Orchestration], [ModuleObjectName], [ModuleUsedFor], [Extension])
VALUES (Source.[PK_ConfigModID], Source.[Fk_ConfigID], Source.[Dataset], Source.[Module], Source.[Fk_Orchestration], Source.[ModuleObjectName], Source.[ModuleUsedFor],Source.[Extension])
		   
WHEN NOT MATCHED BY SOURCE THEN DELETE;
                                                                                                                                                                                                      
DECLARE @mergeErrorDCM int                                                                                                                                                                                  
       ,@mergeCountDCM int                                                                                                                                                                                       
SELECT @mergeErrorDCM = @@ERROR, @mergeCountDCM = @@ROWCOUNT                                                                                                                                                   
IF @mergeErrorDCM != 0                                                                                                                                                                                      
 BEGIN                                                                                                                                                                                                   
 PRINT 'ERROR OCCURRED IN MERGE FOR [sch].[DataSetConfigModules]. Rows affected: ' + CAST(@mergeCountDCM AS VARCHAR(100)); -- SQL should always return zero rows affected                           
 END                                                                                                                                                                                                     
ELSE                                                                                                                                                                                                     
 BEGIN                                                                                                                                                                                                   
 PRINT '[sch].[DataSetConfigModules] rows affected by MERGE: ' + CAST(@mergeCountDCM AS VARCHAR(100));                                                                                              
 END                                                                                                                                                                                                     
