﻿
MERGE	[etl].[ModuleStatus] AS Target
USING	(VALUES  (1,N'Pending',1) ,(2,N'Running',0) ,(3,N'Failed',1) ,(4,N'Succeeded',0)) AS Source ([PK_ModuleStatus],[ModuleStatus],[ToRerun])ON (Target.[PK_ModuleStatus] = Source.[PK_ModuleStatus])
WHEN	MATCHED 
THEN	UPDATE SET	[ModuleStatus] = Source.[ModuleStatus], 
					[ToRerun] = Source.[ToRerun]
WHEN	NOT MATCHED 
THEN	INSERT([PK_ModuleStatus],[ModuleStatus],[ToRerun])
		VALUES(Source.[PK_ModuleStatus],Source.[ModuleStatus],Source.[ToRerun]);
	

