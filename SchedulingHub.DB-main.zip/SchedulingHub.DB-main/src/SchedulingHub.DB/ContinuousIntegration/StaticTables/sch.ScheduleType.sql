﻿/*
	Change Version	: v1.2	 
	Sprint			: BR1 Q3 24 Committed
	Author		    : Shah Nawaz Ahmed    <shahnawaz.ahmed@beazley.com>
	Modify Date	    : 12/07/2024
	Description		: https://beazley.atlassian.net/browse/I1B-5622   
									Renamed ViewToTable to IR_ViewToTable
*/

DECLARE @AuditUserEmail varchar(128) = 'IFRS17.Support@beazley.com'
MERGE INTO	[sch].[ScheduleType] AS Target

USING	( VALUES
						(1,'Full Refresh',NULL,0,1,'Day 1 refresh',NULL),
						(2,'Clean Refresh',NULL,0,1,'Clean all boxes and refresh for the selected datasets individually',NULL),
						(3,'Delta Refresh',NULL,0,1,'Perform Delta/Normal Load refresh for the selected Datasets on top of Currently available data (Incremental)',NULL),
						(4,'TechnicalHub',NULL,0,1,'Loads data from Box3-4',NULL),
						(5,'IR_ViewToTable',NULL,0,1,'Loads data from view to table incrementally',NULL),
						(6,'Daily Refresh','Daily',0,0,'Daily Refresh Automated  as per the Scheduled datetime',@AuditUserEmail),
						(7,'Weekly Refresh','Monday',0,0,'Weekly Refresh Automated  as per the Scheduled datetime',@AuditUserEmail),
					    (8,'Monthly Refresh','WD1',0,0,'Monthly Refresh Automated  as per the Scheduled datetime on working day 1',@AuditUserEmail),
						(9,'Monthly Refresh','WD2',0,0,'Monthly Refresh Automated  as per the Scheduled datetime  on working day 2',@AuditUserEmail),
						(10,'Quarterly Refresh','WD-15',0,0,'Quarterly Refresh Automated as per the Scheduled datetime  on working day -15',@AuditUserEmail),
						(11,'Quarterly Refresh','WD-10',0,0,'Quarterly Refresh Automated as per the Scheduled datetime  on working day -10',@AuditUserEmail),
						(12,'Quarterly Refresh','WD1',0,0,'Quarterly Refresh Automated as per the Scheduled datetime on working day 1',@AuditUserEmail),
						(13,'Quarterly Refresh','WD2',0,0,'Quarterly Refresh Automated as per the Scheduled datetime on working day 2',@AuditUserEmail),
						(14,'Quarterly Refresh','WD3',0,0,'Quarterly Refresh Automated as per the Scheduled datetime on working day 3',@AuditUserEmail)

					) AS Source(PK_SchID,SchRunType,WorkingDay,IsEnabled,IsUserInitiated,[Description],AuditUserEmail)
			ON		(Target.PK_SchID=Source.PK_SchID)
			   
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(PK_SchID,SchRunType,WorkingDay,IsEnabled,IsUserInitiated,[Description],AuditUserEmail)
					VALUES(Source.PK_SchID,Source.SchRunType,Source.WorkingDay,Source.IsEnabled,Source.IsUserInitiated,Source.[Description],Source.AuditUserEmail)
			WHEN	MATCHED
			and [Target].SchRunType         != Source.SchRunType
			or [Target].WorkingDay !=Source.WorkingDay
			or [Target].IsEnabled !=Source.IsEnabled
			or [Target].IsUserInitiated       !=Source.IsUserInitiated
			or [Target].[Description]       !=Source.[Description]
			or [Target].AuditUserEmail       !=Source.AuditUserEmail
			THEN	UPDATE SET	SchRunType = source.SchRunType,
								WorkingDay = source.WorkingDay,
								IsEnabled = source.IsEnabled, 
								IsUserInitiated = source.IsUserInitiated,
								[Description] = Source.[Description],
								[AuditUserEmail] = Source.AuditUserEmail
		
		   
WHEN NOT MATCHED BY SOURCE THEN DELETE;
                                                                                                                                                                                                      
DECLARE @mergeErrorST int                                                                                                                                                                                  
       ,@mergeCountST int                                                                                                                                                                                       
SELECT @mergeErrorST = @@ERROR, @mergeCountST = @@ROWCOUNT                                                                                                                                                   
IF @mergeErrorST != 0                                                                                                                                                                                      
 BEGIN                                                                                                                                                                                                   
 PRINT 'ERROR OCCURRED IN MERGE FOR sch.ScheduleType. Rows affected: ' + CAST(@mergeCountST AS VARCHAR(100)); -- SQL should always return zero rows affected                           
 END                                                                                                                                                                                                     
ELSE                                                                                                                                                                                                     
 BEGIN                                                                                                                                                                                                   
 PRINT 'sch.ScheduleType rows affected by MERGE: ' + CAST(@mergeCountST AS VARCHAR(100));                                                                                              
 END       