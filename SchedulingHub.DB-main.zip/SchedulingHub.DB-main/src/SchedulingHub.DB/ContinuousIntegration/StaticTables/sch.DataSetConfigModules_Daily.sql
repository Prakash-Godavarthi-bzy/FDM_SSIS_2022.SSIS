﻿MERGE INTO [sch].[DataSetConfigModules_Daily] AS Target

USING (VALUES
             (1,1,'ADM-DFMs','Daily',9,15,'IFRS17_ADMToLandingExtract.dtsx','Landing',NULL),
			 (2,1,'ADM-DFMs','Daily',10,15,'IFRS17_ADM_DFM_PaymentPattern_ToLanding.dtsx','Landing',NULL),
			 (3,1,'ADM-DFMs','Daily',136,15,'[ADM].[usp_LandingToInbound_Pattern]','LandingToInbound',NULL),
			 (4,1,'ADM-DFMs','Daily',152,15,'[Inbound].[usp_InboundOutboundWorkflow_Pattern]','InboundToOutbound',NULL),
			 --(5,2,'Claims_BI_ODS',NULL,7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing','claim'),
			 --(6,2,'Claims_BI_ODS',NULL,15,15,'IFRS17_BICCToLandingExtract.dtsx','Landing','claim'),
			 --(7,2,'Claims_BI_ODS',NULL,106,15,'[MDS].[usp_LandingToInbound]','LandingToInbound','claim'),
			 --(8,2,'Claims_BI_ODS',NULL,137,15,'[Claims_BI_ODS].[usp_LandingToInboundToOutbound]','LandingToInboundToOutbound','claim'),
			 --(9,2,'Claims_BI_ODS',NULL,154,15,'[Inbound].[usp_InboundOutboundWorkflow_ClaimExtensions]','Extensions','claim'),
			 --(10,2,'Claims_BI_ODS',NULL,167,15,'[Inbound].[usp_InboundOutboundWorkflow]','InboundToOutbound','claim'),
			 (5,3,'BICI RI Ultimate Claim','Daily',25,15,'IFRS17_BICIRI_Claim.dtsx','Landing','Reinsurance'),
			 (6,3,'BICI RI Ultimate Claim','Daily',61,15,'[BICIRI].[usp_LandingInboundWorkflow_BICI_RI_Ultimate_Claim]','LandingToInbound','Reinsurance'),
			 (7,3,'BICI RI Ultimate Claim','Daily',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
			 (8,4,'BICI_RI_Ultimate_Premium','Daily',18,15,'IFRS17_BICIRI_Ultimate.dtsx','Landing','Reinsurance'),
			 (9,4,'BICI_RI_Ultimate_Premium','Daily',65,15,'[BICIRI].[usp_LandingInboundWorkflow_BICI_RI_Ultimate_Premium]','LandingToInbound','Reinsurance'),
			 (10,4,'BICI_RI_Ultimate_Premium','Daily',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
			 (11,5,'BusinessPlan','Daily',17,15,'IFRS17_BusinessPlanLanding.dtsx','Landing','Reinsurance'),
			 (12,5,'BusinessPlan','Daily',62,15,'[BP].[usp_LandingInboundWorkflow_BusinessPlan]','LandingToInbound','Reinsurance'),
			 (13,5,'BusinessPlan','Daily',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
			 --(20,6,'Ceded_Re_Claims_Incurred',NULL,13,15,'IFRS17_CededReAccToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(21,6,'Ceded_Re_Claims_Incurred',NULL,6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(22,6,'Ceded_Re_Claims_Incurred',NULL,109,15,'[Eurobase].[usp_LandingToInbound_TreatyReInsurance_ContractAttributes]','LandingToInbound','Reinsurance'),
			 --(23,6,'Ceded_Re_Claims_Incurred',NULL,122,15,'[FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTreatyContractAttributes]','LandingToInbound','Reinsurance'),
			 --(24,6,'Ceded_Re_Claims_Incurred',NULL,183,15,'[CededRe].[usp_LandingToInboundToOutbound_CededReClaimsIncurred]','LandingToInboundToOutbound','Reinsurance'),
			 --(25,7,'ReinsuranceRebates_Ultimate',NULL,4,15,'IFRS17_UltimateRebatesToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(26,7,'ReinsuranceRebates_Ultimate',NULL,6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(27,7,'ReinsuranceRebates_Ultimate',NULL,7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(28,7,'ReinsuranceRebates_Ultimate',NULL,8,15,'IFRS17_FDMToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(29,7,'ReinsuranceRebates_Ultimate',NULL,9,15,'IFRS17_ADMToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(30,7,'ReinsuranceRebates_Ultimate',NULL,181,15,'[ultrebsrc].[usp_LandingToInboundToOutbound_UltimateRIRebate]','LandingToInboundToOutbound','Reinsurance'),
			 --(31,8,'AgressoARBIDAC',NULL,22,15,'SyndicateSplit.dtsx','Landing','Agresso'),
			 --(32,8,'AgressoARBIDAC',NULL,14,15,'IFRS17_AgressoToLandingExtract.dtsx','Landing','Agresso'),
			 --(33,8,'AgressoARBIDAC',NULL,199,15,'EXEC [AgressoAR].[usp_LandingToInboundToOutbound_AgressoARBIDAC1]','LandingToInboundToOutbound','Agresso'),
			 --(34,9,'AgressoARUS',NULL,22,15,'SyndicateSplit.dtsx','Landing','Agresso'),
			 --(35,9,'AgressoARUS',NULL,14,15,'IFRS17_AgressoToLandingExtract.dtsx','Landing','Agresso'),
			 --(36,9,'AgressoARUS',NULL,200,15,'EXEC [AgressoAR].[usp_LandingToInboundToOutbound_AgressoARUS]','LandingToInboundToOutbound','Agresso'),
			 --(37,10,'Eurobase',NULL,31,15,'EurobaseTacticalLoad.dtsx','Landing','Premium'),
			 --(38,10,'Eurobase',NULL,78,15,'EXEC [Eb].[usp_LandingInboundWorkflow_EurobaseTacticalLoad]','LandingToInbound','Premium'),
			 --(39,10,'Eurobase',NULL,91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Premium'),
			 --(40,11,'LPSO',NULL,6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing',NULL),
			 --(41,11,'LPSO',NULL,8,15,'IFRS17_FDMToLandingExtract.dtsx','Landing',NULL),
			 --(42,11,'LPSO',NULL,138,15,'EXEC [Eurobase].[usp_LandingToInbound]','LandingToInbound',NULL),
			 --(43,11,'LPSO',NULL,167,15,'EXEC [Inbound].[usp_InboundOutboundWorkflow]','InboundToOutbound',NULL),
			 (14,12,'NatCatEarning','Daily',2,15,'IFRS17_NatCatEarningToLandingExtract.dtsx','Landing',NULL),
			 (15,12,'NatCatEarning','Daily',108,15,'EXEC [NCME].[usp_NatCatEarningLandingToInbound_Pattern]','LandingToInbound',NULL),
			 (16,12,'NatCatEarning','Daily',152,15,'EXEC [Inbound].[usp_InboundOutboundWorkflow_Pattern]','InboundToOutbound',NULL),
			 --(47,13,'RI LPSO FAC',NULL,6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(48,13,'RI LPSO FAC',NULL,7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(49,13,'RI LPSO FAC',NULL,139,15,'EXEC [Eurobase].[usp_LandingToInbound_FacReInsurance]','LandingToInbound','Reinsurance'),
			 --(50,13,'RI LPSO FAC',NULL,155,15,'EXEC [Inbound].[usp_InboundOutboundWorkflow_ReInsuranceExtensions]','Extensions','Reinsurance'),
			 --(51,13,'RI LPSO FAC',NULL,167,15,'EXEC [Inbound].[usp_InboundOutboundWorkflow]','InboundToOutbound','Reinsurance'),
			 --(52,14,'RI LPSO TTY',NULL,6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(53,14,'RI LPSO TTY',NULL,7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(54,14,'RI LPSO TTY',NULL,8,15,'IFRS17_FDMToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(55,14,'RI LPSO TTY',NULL,9,15,'IFRS17_ADMToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(56,14,'RI LPSO TTY',NULL,13,15,'IFRS17_CededReAccToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(57,14,'RI LPSO TTY',NULL,166,15,'EXEC [Eurobase].[usp_LandingToInboundToOutbound_TreatyReInsurance]','LandingToInboundToOutbound','Reinsurance'),
			 --(58,15,'BICI',NULL,34,15,'IFRS17_BICILanding.dtsx','Landing',NULL),
			 --(59,15,'BICI',NULL,7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing',NULL),
			 --(60,15,'BICI',NULL,212,15,'EXEC [US].[usp_BICILandingToInboundWorkflow]','LandingToInbound',NULL),
			 --(61,15,'BICI',NULL,226,15,'EXEC [Inbound].[usp_InboundOutboundWorkflow_GAAP]','Landing',NULL),
			 --(62,16,'BIDAC',NULL,35,15,'IFRS17_BIDACLanding.dtsx','Landing',NULL),
			 --(63,16,'BIDAC',NULL,7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing',NULL),
			 --(64,16,'BIDAC',NULL,213,15,'EXEC [BIDAC].[usp_LandingInboundWorkflow]','LandingToInbound',NULL),
			 --(65,16,'BIDAC',NULL,226,15,'EXEC [Inbound].[usp_InboundOutboundWorkflow_GAAP]','InboundToOutbound',NULL),
			 (17,17,'BusinessPlanRI','Daily',21,15,'IFRS17_BusinessPlanLandingRI.dtsx','Landing','Reinsurance'),
			 (18,17,'BusinessPlanRI','Daily',68,15,'[BP].[usp_LandingInboundWorkflow_BusinessPlanRI]','LandingToInbound','Reinsurance'),
			 (19,17,'BusinessPlanRI','Daily',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
			 --(69,18,'EPI Reinstatement Eurobase',NULL,21,15,'IFRS17_BusinessPlanLandingRI.dtsx','Landing','Reinsurance'),
			 (20,19,'Expenses Actual','Daily',24,15,'AgressoExpensesActual.dtsx','Landing','Reinsurance'),
			 (21,19,'Expenses Actual','Daily',64,15,'[Agresso].[usp_LandingInboundWorkflow_AgressoExpensesActual]','LandingToInbound','Reinsurance'),
			 (22,19,'Expenses Actual','Daily',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
			 --(73,20,'Signed Profit Commission',NULL,5,15,'IFRS17_BeazleyMIReinsuranceToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(74,20,'Signed Profit Commission',NULL,6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(75,20,'Signed Profit Commission',NULL,198,15,'[ReinsuranceMI].[usp_LandingToInboundToOutbound_SignedProfitCommission]','LandingToInboundToOutbound','Reinsurance'),
			 --(76,21,'USBAIC',NULL,36,15,'IFRS17_USBAICLanding.dtsx','Landing',NULL),
			 --(77,21,'USBAIC',NULL,7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing',NULL),
			 --(78,21,'USBAIC',NULL,214,15,'[US].[usp_BAICLandingToInboundWorkflow]','LandingToInbound',NULL),
			 --(79,21,'USBAIC',NULL,226,15,'[Inbound].[usp_InboundOutboundWorkflow_GAAP]','InboundToOutbound',NULL),
			 --(80,22,'USPremium',NULL,32,15,'USPremium.dtsx','Landing',NULL),
			 --(81,22,'USPremium',NULL,7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing',NULL),
			 --(82,22,'USPremium',NULL,211,15,'[us].[usp_LandingInboundWorkflow]','LandingToInbound',NULL),
			 --(83,22,'USPremium',NULL,226,15,'[Inbound].[usp_InboundOutboundWorkflow_GAAP]','InboundToOutbound',NULL),
			 (23,23,'BICI TDM','Daily',23,15,'IFRS17_TDMBICIClaimsToLandingExtract.dtsx','Landing','Reinsurance'),
			 (24,23,'BICI TDM','Daily',63,15,'[TDM].[usp_LandingInboundWorkflow_BICIClaims]','LandingToInbound','Reinsurance'),
			 (25,23,'BICI TDM','Daily',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
			 (26,24,'BICI_Earned_Agresso','Daily',39,15,'IFRS17_BICIRIEarnedToLandingExtract.dtsx','Landing','Reinsurance'),
			 (27,24,'BICI_Earned_Agresso','Daily',69,15,'[BICIRI].[usp_LandingInboundWorkflow_EarnedPremium]','LandingToInbound','Reinsurance'),
			 (28,24,'BICI_Earned_Agresso','Daily',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
			 (29,25,'BICI_RI_Incurred','Daily',29,15,'IFRS17_BICIRI_Incurred.dtsx','Landing','Reinsurance'),
			 (30,25,'BICI_RI_Incurred','Daily',71,15,'[BICIRI].[usp_LandingInboundWorkflow_BICI_RI_Incurred]','LandingToInbound','Reinsurance'),
			 (31,25,'BICI_RI_Incurred','Daily',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
			 (32,26,'BICI_RI_Paid','Daily',41,15,'IFRS17_BICIRI_Paid.dtsx','Landing','Reinsurance'),
			 (33,26,'BICI_RI_Paid','Daily',71,15,'[BICIRI].[usp_LandingInboundWorkflow_BICI_RI_Paid]','LandingToInbound','Reinsurance'),
			 (34,26,'BICI_RI_Paid','Daily',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
			 --(96,27,'Ceded_Re_Closed_YOA',13,15,'IFRS17_CededReAccToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(97,27,'Ceded_Re_Closed_YOA',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(98,27,'Ceded_Re_Closed_YOA',109,15,'[Eurobase].[usp_LandingToInbound_TreatyReInsurance_ContractAttributes]','LandingToInbound','Reinsurance'),
			 --(99,27,'Ceded_Re_Closed_YOA',122,15,'[FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTreatyContractAttributes]','LandingToInbound','Reinsurance'),
			 --(100,27,'Ceded_Re_Closed_YOA',184,15,'[CededRe].[usp_LandingToInboundToOutbound_CededReClosedYOA]','LandingToInboundToOutbound','Reinsurance'),
			 --(101,28,'Ceded_Re_ORC',13,15,'IFRS17_CededReAccToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(102,28,'Ceded_Re_ORC',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(103,28,'Ceded_Re_ORC',109,15,'[Eurobase].[usp_LandingToInbound_TreatyReInsurance_ContractAttributes]','LandingToInbound','Reinsurance'),
			 --(104,28,'Ceded_Re_ORC',122,15,'[FinanceDataContract].[Inbound].[usp_InboundOutboundWorkflow_ReInsuranceTreatyContractAttributes]','LandingToInbound','Reinsurance'),
			 --(105,28,'Ceded_Re_ORC',184,15,'EXEC [CededRe].[usp_LandingToInboundToOutbound_CededReOR','LandingToInboundToOutbound','Reinsurance'),
			 --(106,29,'Earned_RIP_RISpend',8,15,'IFRS17_FDMToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(107,29,'Earned_RIP_RISpend',187,15,'[fdm].[usp_LandingToInboundToOutbound_RI_Reinstatement_Premium_Earned]','LandingToInboundToOutbound','Reinsurance'),
			 (35,30,'ObligatedPremium_Munich_QQS','Daily',28,15,'IFRS17_ObligatedPremium_Munich_QQS.dtsx','Landing','Reinsurance'),
			 (36,30,'ObligatedPremium_Munich_QQS','Daily',75,15,'[OP].[usp_LandingInboundWorkflow_ObligatedPremium_Munich_QQS]','LandingToInbound','Reinsurance'),
			 (37,30,'ObligatedPremium_Munich_QQS','Daily',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
			 --(111,31,'ObligatedPremium_RISpend',8,15,'IFRS17_FDMToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(112,31,'ObligatedPremium_RISpend',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(113,31,'ObligatedPremium_RISpend',196,15,'[fdm].[usp_LandingToInboundToOutbound_ObligatedPremium]','LandingToInboundToOutbound','Reinsurance'),
			 (38,32,'ObligatedPremium_SPA','Daily',42,15,'IFRS17_SPAObligatedPremium.dtsx','Landing','Reinsurance'),
			 (39,32,'ObligatedPremium_SPA','Daily',74,15,'[SPA].[usp_LandingInboundWorkflow_ObligatedPremium_SPA]','LandingToInbound','Reinsurance'),
			 (40,32,'ObligatedPremium_SPA','Daily',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
			 --(117,33,'PFT',33,15,'PremiumForecastLanding.dtsx','Landing',NULL),
			 --(118,33,'PFT',241,15,'[pft].[usp_LandingToInboundToOutboundWorkflow]','LandingToInbound',NULL),
			 --(119,34,'Reinsurance_Overriding_Commission',8,15,'IFRS17_FDMToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(120,34,'Reinsurance_Overriding_Commission',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(121,34,'Reinsurance_Overriding_Commission',186,15,'[FDM].[usp_LandingToInboundToOutbound_Reinsurance_Overriding_Commission]]','LandingToInboundToOutbound','Reinsurance'),
			 --(122,35,'ReinsuranceRebates_Paid',3,15,'IFRS17_PaidRebatesToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(123,35,'ReinsuranceRebates_Paid',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(124,35,'ReinsuranceRebates_Paid',7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(125,35,'ReinsuranceRebates_Paid',8,15,'IFRS17_FDMToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(126,35,'ReinsuranceRebates_Paid',9,15,'IFRS17_ADMToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(127,35,'ReinsuranceRebates_Paid',202,15,'[pdrebsrc].[usp_LandingToInboundToOutbound_PaidRebates]','LandingToInboundToOutbound','Reinsurance'),
			 (41,36,'ResDataEventAlloc','Daily',19,15,'IFRS17_ADMResDataAllocToLandingExtract.dtsx','Landing','Reinsurance'),
			 (42,36,'ResDataEventAlloc','Daily',66,15,'[ADM].[usp_LandingInboundWorkflow_ResDataEventAlloc]','LandingToInbound','Reinsurance'),
			 (43,36,'ResDataEventAlloc','Daily',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
			 (44,37,'ResDataRIAttClmAlloc','Daily',38,15,'IFRS17_ADMResDataUltimateClaims.dtsx','Landing','Reinsurance'),
			 (45,37,'ResDataRIAttClmAlloc','Daily',70,15,'[ADM].[usp_LandingInboundWorkflow_ResDataRIAttClaims]','LandingToInbound','Reinsurance'),
			 (46,37,'ResDataRIAttClmAlloc','Daily',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
			 (47,38,'ResDataRILargeLossAlloc','Daily',40,15,'ADMReinsuranceReservingData_LargeLosses.dtsx','Landing','Reinsurance'),
			 (48,38,'ResDataRILargeLossAlloc','Daily',73,15,'[ADM].[usp_LandingInboundWorkflow_ReinsuranceReservingDataLargeLosses_ADM]','LandingToInbound','Reinsurance'),
			 (49,38,'ResDataRILargeLossAlloc','Daily',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
			 --(137,39,'ReservingData',7,15,'IFRS17_MDSToLandingExtract.dtsx','Landing','ReservingReinsurance'),
			 --(138,39,'ReservingData',9,15,'IFRS17_ADMToLandingExtract.dtsx','Landing','ReservingReinsurance'),
			 --(139,39,'ReservingData',182,15,'EXEC [ADM].[usp_LandingToInboundToOutbound]','LandingToInboundOutbound','ReservingReinsurance'),
			 (50,40,'ReservingDataPremiumAlloc','Daily',30,15,'IFRS17_ADMResDataPremiumAlloc.dtsx','Landing','Reinsurance'),
			 (51,40,'ReservingDataPremiumAlloc','Daily',76,15,'[ADM].[usp_LandingInboundWorkflow_ReservingDataPremiumAlloc]','LandingToInbound','Reinsurance'),
			 (52,40,'ReservingDataPremiumAlloc','Daily',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance'),
			 (53,41,'RIPsEventAlloc','Daily',20,15,'IFRS17_UltimateRIPsEventToLandingExtract.dtsx','Landing','Reinsurance'),
			 (54,41,'RIPsEventAlloc','Daily',67,15,'EXEC [Ultrea].[usp_LandingInboundWorkflow_RIPsEventAlloc]','LandingToInbound','Reinsurance'),
			 (55,41,'RIPsEventAlloc','Daily',91,15,'[TL].[usp_InboundOutBoundWorkflow_TacticalLoads]','InboundToOutbound','Reinsurance')
			 --(146,42,'Ultimate Profit Commission',16,15,'IFRS17_UltimateProfitCommissionToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(147,42,'Ultimate Profit Commission',6,15,'IFRS17_EurobaseToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(148,42,'Ultimate Profit Commission',8,15,'IFRS17_FDMToLandingExtract.dtsx','Landing','Reinsurance'),
			 --(149,42,'Ultimate Profit Commission',197,15,'[ultpc].[usp_LandingToInboundToOutbound_UltimateProfitCommission]','LandingToInboundToOutbound','Reinsurance')


       )AS Source ([PK_ConfigModDID], [Fk_ConfigID], [Dataset], [WorkingDay], [Fk_Module], [Fk_Orchestration], [ModuleObjectName], [ModuleUsedFor], [Extension])
			
ON (Target.[PK_ConfigModDID] = Source.[PK_ConfigModDID])

WHEN MATCHED 
		and [Target].[Fk_ConfigID]         != Source.[Fk_ConfigID]
		or  [Target].[Dataset]    != Source.[Dataset]
		or  [Target].[WorkingDay]    != Source.[WorkingDay]
		or  [Target].[Module]  != Source.[Fk_Module]
		or  [Target].[Fk_Orchestration]  != Source.[Fk_Orchestration]
		or  [Target].[ModuleObjectName]  != Source.[ModuleObjectName]
		or  [Target].[ModuleUsedFor]  != Source.[ModuleUsedFor]
		or  [Target].[Extension]  != Source.[Extension]


THEN 
UPDATE SET [Fk_ConfigID]         = Source.[Fk_ConfigID]
		,[Dataset]    = Source.[Dataset]
		,[WorkingDay]    = Source.[WorkingDay]
		,[Module]  = Source.[Fk_Module]
		,[Fk_Orchestration]  = Source.[Fk_Orchestration]
		,[ModuleObjectName]  = Source.[ModuleObjectName]
		,[ModuleUsedFor]  = Source.[ModuleUsedFor]
		,[Extension]  = Source.[Extension]
WHEN NOT MATCHED BY TARGET THEN

INSERT ([PK_ConfigModDID], [Fk_ConfigID], [Dataset], [WorkingDay], [Module], [Fk_Orchestration], [ModuleObjectName], [ModuleUsedFor], [Extension])
VALUES (Source.[PK_ConfigModDID], Source.[Fk_ConfigID], Source.[Dataset], Source.[WorkingDay], Source.[Fk_Module], Source.[Fk_Orchestration], Source.[ModuleObjectName], Source.[ModuleUsedFor],Source.[Extension])
		   
WHEN NOT MATCHED BY SOURCE THEN DELETE;
                                                                                                                                                                                                      
DECLARE @mergeErrorDCMD int                                                                                                                                                                                  
       ,@mergeCountDCMD int                                                                                                                                                                                       
SELECT @mergeErrorDCMD = @@ERROR, @mergeCountDCMD = @@ROWCOUNT                                                                                                                                                   
IF @mergeErrorDCMD != 0                                                                                                                                                                                      
 BEGIN                                                                                                                                                                                                   
 PRINT 'ERROR OCCURRED IN MERGE FOR [sch].[DataSetConfigModules_Daily]. Rows affected: ' + CAST(@mergeCountDCMD AS VARCHAR(100)); -- SQL should always return zero rows affected                           
 END                                                                                                                                                                                                     
ELSE                                                                                                                                                                                                     
 BEGIN                                                                                                                                                                                                   
 PRINT '[sch].[DataSetConfigModules_Daily] rows affected by MERGE: ' + CAST(@mergeCountDCMD AS VARCHAR(100));                                                                                              
 END                                                                                                                                                                                                     


