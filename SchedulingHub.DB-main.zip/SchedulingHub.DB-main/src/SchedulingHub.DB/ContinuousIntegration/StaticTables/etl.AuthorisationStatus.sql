﻿
MERGE INTO [etl].[AuthorisationStatus] AS Target
USING(VALUES
(1,  N'Pending',  2),(2,  N'Authorised',  4),(3,  N'Revoked', 3)) AS Source([PK_AuthorisationStatus], [AuthorisationStatus], [DefaultModuleStatus])
ON    (Target.[PK_AuthorisationStatus] = Source.[PK_AuthorisationStatus])
    WHEN NOT MATCHED
    THEN
      INSERT([PK_AuthorisationStatus], 
             [AuthorisationStatus], 
             [DefaultModuleStatus])
      VALUES(Source.[PK_AuthorisationStatus],  Source.[AuthorisationStatus],  Source.[DefaultModuleStatus])
    WHEN MATCHED
    THEN UPDATE SET [AuthorisationStatus] = source.[AuthorisationStatus], 
					[DefaultModuleStatus] = source.[DefaultModuleStatus];

