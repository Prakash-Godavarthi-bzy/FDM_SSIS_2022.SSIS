﻿MERGE INTO [etl].[OrchestrationRunConfig] AS Target

USING (VALUES
                 (1,'AgressoARBIDAC',3,'Agresso')
				,(2,'AgressoARUS',3,'Agresso')
				,(3,'BICI',5,'FDM_DB')
				,(4,'BICI RI Ultimate Claim',9,'Excel')
				,(5,'BICI TDM',9,'Excel')
				,(6,'BICI_RI_Incurred',9,'Excel')
				,(7,'BICI_RI_Paid',9,'Excel')
				,(8,'BICI_RI_Ultimate_Premium',9,'Excel')
				,(9,'BIDAC',5,'FDM_DB')
				,(10,'BusinessPlan',9,'Excel')
				,(11,'BusinessPlanRI',9,'Excel')
				,(12,'Ceded_Re_Claims_Incurred',3,'Ceded Access DB')
				,(13,'Ceded_Re_Closed_YOA',3,'Ceded Access DB')
				,(14,'Ceded_Re_ORC',3,'Ceded Access DB')
				,(15,'Claims_BI_ODS',3,'BeazleyIntelligenceODS_FULLY_PROCESSED')
				,(16,'Earned_RIP_RISpend',3,'FDM')
				,(17,'EPI Reinstatement Eurobase',3,'Eurobase')
				,(18,'Eurobase',5,'EurobaseCentralDataStore')
				,(19,'Expenses Actual',9,'Excel')
				,(20,'LPSO',3,'Eurobase')
				,(21,'ObligatedPremium_Munich_QQS',9,'Excel')
				,(22,'ObligatedPremium_RISpend',3,'FDM')
				,(23,'ObligatedPremium_SPA',9,'Excel')
				,(24,'PFT',5,'FDM_DB')
				,(25,'Reinsurance_Overriding_Commission',3,'FDM')
				,(26,'ReinsuranceRebates_Paid',3,'Rebate_Paid Excel')
				,(27,'ReinsuranceRebates_Ultimate',3,'Rebate_Ultimate Excel')
				,(28,'ResDataEventAlloc',9,'Excel')
				,(29,'ResDataRIAttClmAlloc',9,'Excel')
				,(30,'ResDataRILargeLossAlloc',9,'Excel')
				,(31,'ReservingData',3,'ADM')
				,(32,'RI LPSO FAC',3,'Eurobase')
				,(33,'RI LPSO TTY',3,'Eurobase & CSV File')
				,(34,'RI_SpecialArrangements',3,'FDM')
				,(35,'RIPsEventAlloc',9,'Excel')
				,(36,'Signed Profit Commission',3,'BeazleyReinsuranceMI')
				,(37,'Ultimate Profit Commission',3,'UltimateProfitComission Excel')
				,(38,'USBAIC',5,'FDM_DB')
				,(39,'USPremium',5,'FDM_DB')
				,(40,'EIOPA',3,'EIOPA Excel')
				,(41,'NatCatEarning',3,'NatCatEarning Excel')
				,(42,'ObligatedPremium_Unincepted',9,'Excel')
				,(43,'BICI_Earned_Agresso',9,'Excel')
				,(44,'ADM-DFMS',3,'ADM')
				,(45,'BICI',6,'FDM_DB BaseLoad')
				,(46,'BIDAC',6,'FDM_DB BaseLoad')
				,(47,'USBAIC',6,'FDM_DB BaseLoad')
				,(48,'PFT',6,'FDM_DB BaseLoad')
				,(49,'Eurobase',6,'FDM_DB BaseLoad')
				,(50,'USPremium',6,'FDM_DB BaseLoad')

       )AS Source ([PK_Config], [Dataset], [fk_Orchestration], [Source DB])
			
ON (Target.[PK_Config] = Source.[PK_Config])

WHEN MATCHED 
		and [Target].[DataSet]         != Source.[DataSet]
		or  [Target].[fk_Orchestration]    != Source.[fk_Orchestration]
		or  [Target].[Source DB]  != Source.[Source DB]
THEN 
UPDATE SET  [DataSet]         = Source.[DataSet]
		   ,[fk_Orchestration]    = Source.[fk_Orchestration]
		   ,[Source DB]  = Source.[Source DB]
		   
WHEN NOT MATCHED BY TARGET THEN

INSERT ([PK_Config], [DataSet], [fk_Orchestration], [Source DB])
VALUES (Source.[PK_Config], Source.[DataSet], Source.[fk_Orchestration], Source.[Source DB])
		   
WHEN NOT MATCHED BY SOURCE THEN DELETE;
                                                                                                                                                                                                      
DECLARE @mergeErrorORC int                                                                                                                                                                                  
       ,@mergeCountORC int                                                                                                                                                                                       
SELECT @mergeErrorORC = @@ERROR, @mergeCountORC = @@ROWCOUNT                                                                                                                                                   
IF @mergeErrorORC != 0                                                                                                                                                                                      
 BEGIN                                                                                                                                                                                                   
 PRINT 'ERROR OCCURRED IN MERGE FOR [etl].[OrchestrationRunConfig]. Rows affected: ' + CAST(@mergeCountORC AS VARCHAR(100)); -- SQL should always return zero rows affected                           
 END                                                                                                                                                                                                     
ELSE                                                                                                                                                                                                     
 BEGIN                                                                                                                                                                                                   
 PRINT '[etl].[OrchestrationRunConfig] rows affected by MERGE: ' + CAST(@mergeCountORC AS VARCHAR(100));                                                                                              
 END                                                                                                                                                                                                     
  

