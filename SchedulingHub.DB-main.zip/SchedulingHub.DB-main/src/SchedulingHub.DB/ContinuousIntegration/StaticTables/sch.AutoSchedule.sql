﻿MERGE INTO	[sch].[AutoSchedule] AS Target

USING	( VALUES
						(1,4,1,'ADM-DFMs','Daily Refresh','Daily',1),
						(2,5,2,'Claims_BI_ODS','Weekly Refresh','Monday',1),
						(3,4,3,'BICI RI Ultimate Claim','Daily Refresh','Daily',1),
						(4,4,4,'BICI_RI_Ultimate_Premium','Daily Refresh','Daily',1),
					    (5,4,5,'BusinessPlan','Daily Refresh','Daily',1),
						(6,8,6,'Ceded_Re_Claims_Incurred','Quarterly Refresh','WD-15',1),
						(7,8,7,'ReinsuranceRebates_Ultimate','Quarterly Refresh','WD-15',1),
						(8,11,8,'AgressoARBIDAC','Quarterly Refresh','WD2',1),
						(9,11,9,'AgressoARUS','Quarterly Refresh','WD2',1),
						(10,6,10,'Eurobase','Monthly Refresh','WD1',1),
						(11,5,11,'LPSO','Weekly Refresh','Monday',1),
						(12,4,12,'NatCatEarning','Daily Refresh','Daily',1),
						(13,5,13,'RI LPSO FAC','Weekly Refresh','Monday',1),
						(14,5,14,'RI LPSO TTY','Weekly Refresh','Monday',1),
						(15,5,15,'BICI','Weekly Refresh','Monday',1),
						(16,5,16,'BIDAC','Weekly Refresh','Monday',1),
						(17,4,17,'BusinessPlanRI','Daily Refresh','Daily',1),
						(18,7,18,'EPI Reinstatement Eurobase','Monthly Refresh','WD2',1),
						(19,4,19,'Expenses Actual','Daily Refresh','Daily',1),
						(20,11,20,'Signed Profit Commission','Quarterly Refresh','WD2',1),
						(21,5,21,'USBAIC','Weekly Refresh','Monday',1),
						(22,5,22,'USPremium','Weekly Refresh','Monday',1),
						(23,4,23,'BICI TDM','Daily Refresh','Daily',1),
						(24,4,24,'BICI_Earned_Agresso','Daily Refresh','Daily',1),
						(25,4,25,'BICI_RI_Incurred','Daily Refresh','Daily',1),
						(26,4,26,'BICI_RI_Paid','Daily Refresh','Daily',1),
						(27,8,27,'Ceded_Re_Closed_YOA','Quarterly Refresh','WD-15',1),
						(28,8,28,'Ceded_Re_ORC','Quarterly Refresh','WD-15',1),
						(29,9,29,'Earned_RIP_RISpend','Quarterly Refresh','WD-10',1),
						(30,4,30,'ObligatedPremium_Munich_QQS','Daily Refresh','Daily',1),
						(31,9,31,'ObligatedPremium_RISpend','Quarterly Refresh','WD-10',1),
						(32,4,32,'ObligatedPremium_SPA','Daily Refresh','Daily',1),
						(33,9,33,'PFT','Quarterly Refresh','WD-10',1),
						(34,9,34,'Reinsurance_Overriding_Commission','Quarterly Refresh','WD-10',1),
						(35,8,35,'ReinsuranceRebates_Paid','Quarterly Refresh','WD-15',1),
						(36,4,36,'ResDataEventAlloc','Daily Refresh','Daily',1),
						(37,4,37,'ResDataRIAttClmAlloc','Daily Refresh','Daily',1),
						(38,4,38,'ResDataRILargeLossAlloc','Daily Refresh','Daily',1),
						(39,9,39,'ReservingData','Quarterly Refresh','WD-10',1),
						(40,4,40,'ReservingDataPremiumAlloc','Daily Refresh','Daily',1),
						(41,4,41,'RIPsEventAlloc','Daily Refresh','Daily',1),
						(42,10,42,'Ultimate Profit Commission','Quarterly Refresh','WD1',1),
						(43,6,21,'USBAIC','Monthly Refresh','WD1',1),
						(44,6,22,'USPremium','Monthly Refresh','WD1',1),
						(45,6,15,'BICI','Monthly Refresh','WD1',1),
						(46,6,16,'BIDAC','Monthly Refresh','WD1',1),
						(47,12,2,'Claims_BI_ODS','Quarterly Refresh','WD3',1),
						(48,11,11,'LPSO','Quarterly Refresh','WD2',1),
						(49,11,13,'RI LPSO FAC','Quarterly Refresh','WD2',1),
						(50,11,14,'RI LPSO TTY','Quarterly Refresh','WD2',1)--,
						--various dependency tables runs for quarterly refresh on WD1
						--(51,7,43,'IFRS17_EIOPAToLandingExtract.dtsx','Quarterly Refresh','WD1',1),
						--(52,7,43,'IFRS17_NatCatEarningToLandingExtract.dtsx','Quarterly Refresh','WD1',1),
						--(53,7,43,'IFRS17_PaidRebatesToLandingExtract.dtsx','Quarterly Refresh','WD1',1),
						--(54,7,43,'IFRS17_BeazleyMIReinsuranceToLandingExtract.dtsx ','Quarterly Refresh','WD1',1),
						--(55,7,43,'IFRS17_EurobaseToLandingExtract.dtsx','Quarterly Refresh','WD1',1),
						--(56,7,43,'IFRS17_MDSToLandingExtract.dtsx','Quarterly Refresh','WD1',1),
						--(57,7,43,'IFRS17_FDMToLandingExtract.dtsx','Quarterly Refresh','WD1',1),
						--(58,7,43,'IFRS17_ADMToLandingExtract.dtsx','Quarterly Refresh','WD1',1),
						--(59,7,43,'IFRS17_ADM_DFM_PaymentPattern_ToLanding.dtsx','Quarterly Refresh','WD1',1),
						--(60,7,43,'IFRS17_ADM_ResDat_PaymentPattern_ToLanding.dtsx','Quarterly Refresh','WD1',1),
						--(61,7,43,'IFRS17_ADM_S2_TPOutput_PaymentPattern_ToLanding.dtsx','Quarterly Refresh','WD1',1),
						--(62,7,43,'IFRS17_CededReAccToLandingExtract.dtsx','Quarterly Refresh','WD1',1),
						--(63,7,43,'SyndicateSplit.dtsx','Quarterly Refresh','WD1',1),
						--(64,7,43,'IFRS17_BICCToLandingExtract.dtsx','Quarterly Refresh','WD1',1),
						--(65,7,43,'IFRS17_UltimateProfitCommissionToLandingExtract.dtsx','Quarterly Refresh','WD1',1),
						--(66,7,43,'IFRS17_BusinessPlanLanding.dtsx','Quarterly Refresh','WD1',1),
						--(67,7,43,'IFRS17_BICIRI_Ultimate.dtsx','Quarterly Refresh','WD1',1),
						--(68,7,43,'IFRS17_ADMResDataAllocToLandingExtract.dtsx','Quarterly Refresh','WD1',1),
						--(69,7,43,'IFRS17_UltimateRIPsEventToLandingExtract.dtsx','Quarterly Refresh','WD1',1),
						--(70,7,43,'IFRS17_BusinessPlanLandingRI.dtsx','Quarterly Refresh','WD1',1),
						--(71,7,43,'IFRS17_AgressoToLandingExtract.dtsx','Quarterly Refresh','WD1',1),
						--(72,7,43,'IFRS17_TDMBICIClaimsToLandingExtract.dtsx','Quarterly Refresh','WD1',1),
						--(73,7,43,'AgressoExpensesActual.dtsx','Quarterly Refresh','WD1',1),
						--(74,7,43,'IFRS17_BICIRI_Claim.dtsx','Quarterly Refresh','WD1',1),
						--(75,7,43,'FDMTrifocusCode.dtsx','Quarterly Refresh','WD1',1),
						--(76,7,43,'IFRS17_EurobaseEPIReinstatement.dtsx','Quarterly Refresh','WD1',1),
						--(77,7,43,'IFRS17_ObligatedPremium_Munich_QQS.dtsx','Quarterly Refresh','WD1',1),
						--(78,7,43,'IFRS17_BICIRI_Incurred.dtsx','Quarterly Refresh','WD1',1),
						--(79,7,43,'IFRS17_ADMResDataPremiumAlloc.dtsx','Quarterly Refresh','WD1',1),
						--(80,7,43,'EurobaseTacticalLoad.dtsx','Quarterly Refresh','WD1',1),
						--(81,7,43,'USPremium.dtsx','Quarterly Refresh','WD1',1),
						--(82,7,43,'PremiumForecastLanding.dtsx','Quarterly Refresh','WD1',1),
						--(83,7,43,'IFRS17_BICILanding.dtsx','Quarterly Refresh','WD1',1),
						--(84,7,43,'IFRS17_BIDACLanding.dtsx','Quarterly Refresh','WD1',1),
						--(85,7,43,'IFRS17_USBAICLanding.dtsx','Quarterly Refresh','WD1',1),
						--(86,7,43,'IFRS17_ADMResDataUltimateClaims.dtsx','Quarterly Refresh','WD1',1),
						--(87,7,43,'IFRS17_BICIRIEarnedToLandingExtract.dtsx','Quarterly Refresh','WD1',1),
						--(88,7,43,'ADMReinsuranceReservingData_LargeLosses.dtsx','Quarterly Refresh','WD1',1),
						--(89,7,43,'IFRS17_BICIRI_Paid.dtsx','Quarterly Refresh','WD1',1),
						--(90,7,43,'IFRS17_SPAObligatedPremium.dtsx','Quarterly Refresh','WD1',1),
						--(91,7,43,'IFRS17_UltimateRebatesToLandingExtract.dtsx','Quarterly Refresh','WD1',1),
						----various dependency tables runs for quarterly refresh on WD-10
						--(92,7,43,'IFRS17_EIOPAToLandingExtract.dtsx','Quarterly Refresh','WD-10',1),
						--(93,7,43,'IFRS17_NatCatEarningToLandingExtract.dtsx','Quarterly Refresh','WD-10',1),
						--(94,7,43,'IFRS17_PaidRebatesToLandingExtract.dtsx','Quarterly Refresh','WD-10',1),
						--(95,7,43,'IFRS17_BeazleyMIReinsuranceToLandingExtract.dtsx ','Quarterly Refresh','WD-10',1),
						--(96,7,43,'IFRS17_EurobaseToLandingExtract.dtsx','Quarterly Refresh','WD-10',1),
						--(97,7,43,'IFRS17_MDSToLandingExtract.dtsx','Quarterly Refresh','WD-10',1),
						--(98,7,43,'IFRS17_FDMToLandingExtract.dtsx','Quarterly Refresh','WD-10',1),
						--(99,7,43,'IFRS17_ADMToLandingExtract.dtsx','Quarterly Refresh','WD-10',1),
						--(100,7,43,'IFRS17_ADM_DFM_PaymentPattern_ToLanding.dtsx','Quarterly Refresh','WD-10',1),
						--(101,7,43,'IFRS17_ADM_ResDat_PaymentPattern_ToLanding.dtsx','Quarterly Refresh','WD-10',1),
						--(102,7,43,'IFRS17_ADM_S2_TPOutput_PaymentPattern_ToLanding.dtsx','Quarterly Refresh','WD-10',1),
						--(103,7,43,'IFRS17_CededReAccToLandingExtract.dtsx','Quarterly Refresh','WD-10',1),
						--(104,7,43,'SyndicateSplit.dtsx','Quarterly Refresh','WD-10',1),
						--(105,7,43,'IFRS17_BICCToLandingExtract.dtsx','Quarterly Refresh','WD-10',1),
						--(106,7,43,'IFRS17_UltimateProfitCommissionToLandingExtract.dtsx','Quarterly Refresh','WD-10',1),
						--(107,7,43,'IFRS17_BusinessPlanLanding.dtsx','Quarterly Refresh','WD-10',1),
						--(108,7,43,'IFRS17_BICIRI_Ultimate.dtsx','Quarterly Refresh','WD-10',1),
						--(109,7,43,'IFRS17_ADMResDataAllocToLandingExtract.dtsx','Quarterly Refresh','WD-10',1),
						--(110,7,43,'IFRS17_UltimateRIPsEventToLandingExtract.dtsx','Quarterly Refresh','WD-10',1),
						--(111,7,43,'IFRS17_BusinessPlanLandingRI.dtsx','Quarterly Refresh','WD-10',1),
						--(112,7,43,'IFRS17_AgressoToLandingExtract.dtsx','Quarterly Refresh','WD-10',1),
						--(113,7,43,'IFRS17_TDMBICIClaimsToLandingExtract.dtsx','Quarterly Refresh','WD-10',1),
						--(114,7,43,'AgressoExpensesActual.dtsx','Quarterly Refresh','WD-10',1),
						--(115,7,43,'IFRS17_BICIRI_Claim.dtsx','Quarterly Refresh','WD-10',1),
						--(116,7,43,'FDMTrifocusCode.dtsx','Quarterly Refresh','WD-10',1),
						--(117,7,43,'IFRS17_EurobaseEPIReinstatement.dtsx','Quarterly Refresh','WD-10',1),
						--(118,7,43,'IFRS17_ObligatedPremium_Munich_QQS.dtsx','Quarterly Refresh','WD-10',1),
						--(119,7,43,'IFRS17_BICIRI_Incurred.dtsx','Quarterly Refresh','WD-10',1),
						--(120,7,43,'IFRS17_ADMResDataPremiumAlloc.dtsx','Quarterly Refresh','WD-10',1),
						--(121,7,43,'EurobaseTacticalLoad.dtsx','Quarterly Refresh','WD-10',1),
						--(122,7,43,'USPremium.dtsx','Quarterly Refresh','WD-10',1),
						--(123,7,43,'PremiumForecastLanding.dtsx','Quarterly Refresh','WD-10',1),
						--(124,7,43,'IFRS17_BICILanding.dtsx','Quarterly Refresh','WD-10',1),
						--(125,7,43,'IFRS17_BIDACLanding.dtsx','Quarterly Refresh','WD-10',1),
						--(126,7,43,'IFRS17_USBAICLanding.dtsx','Quarterly Refresh','WD-10',1),
						--(127,7,43,'IFRS17_ADMResDataUltimateClaims.dtsx','Quarterly Refresh','WD-10',1),
						--(128,7,43,'IFRS17_BICIRIEarnedToLandingExtract.dtsx','Quarterly Refresh','WD-10',1),
						--(129,7,43,'ADMReinsuranceReservingData_LargeLosses.dtsx','Quarterly Refresh','WD-10',1),
						--(130,7,43,'IFRS17_BICIRI_Paid.dtsx','Quarterly Refresh','WD-10',1),
						--(131,7,43,'IFRS17_SPAObligatedPremium.dtsx','Quarterly Refresh','WD-10',1),
						--(132,7,43,'IFRS17_UltimateRebatesToLandingExtract.dtsx','Quarterly Refresh','WD-10',1)

					) AS Source(PK_AutoSchID,FK_SchID,FK_ConfigID,Dataset,SchRunType,WorkingDay,IsEnabled)
			ON		(Target.PK_AutoSchID=Source.PK_AutoSchID)
			   
			WHEN	NOT MATCHED BY TARGET
			THEN	INSERT(PK_AutoSchID,FK_SchID,FK_ConfigID,Dataset,SchRunType,WorkingDay,IsEnabled)
					VALUES(Source.PK_AutoSchID,Source.FK_SchID,Source.FK_ConfigID,Source.Dataset,Source.SchRunType,Source.WorkingDay,Source.IsEnabled)
			WHEN	MATCHED
			and [Target].FK_SchID         != Source.FK_SchID
			or [Target].FK_ConfigID !=Source.FK_ConfigID
			or [Target].Dataset       !=Source.Dataset
			or [Target].SchRunType       !=Source.SchRunType
			or [Target].WorkingDay       !=Source.WorkingDay
			or [Target].IsEnabled       !=Source.IsEnabled
			THEN	UPDATE SET	FK_SchID = source.FK_SchID, 
								FK_ConfigID = source.FK_ConfigID, 
								Dataset = source.Dataset,
								SchRunType = source.SchRunType,
								WorkingDay = source.WorkingDay, 
								IsEnabled = source.IsEnabled
		
		   
WHEN NOT MATCHED BY SOURCE THEN DELETE;
                                                                                                                                                                                                      
DECLARE @mergeErrorAS int                                                                                                                                                                                  
       ,@mergeCountAS int                                                                                                                                                                                       
SELECT @mergeErrorAS = @@ERROR, @mergeCountAS = @@ROWCOUNT                                                                                                                                                   
IF @mergeErrorAS != 0                                                                                                                                                                                      
 BEGIN                                                                                                                                                                                                   
 PRINT 'ERROR OCCURRED IN MERGE FOR [sch].[AutoSchedule]. Rows affected: ' + CAST(@mergeCountAS AS VARCHAR(100)); -- SQL should always return zero rows affected                           
 END                                                                                                                                                                                                     
ELSE                                                                                                                                                                                                     
 BEGIN                                                                                                                                                                                                   
 PRINT '[sch].[AutoSchedule] rows affected by MERGE: ' + CAST(@mergeCountAS AS VARCHAR(100));                                                                                              
 END                                                                                                                                                                                                     
  

