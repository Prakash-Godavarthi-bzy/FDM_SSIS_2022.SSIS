﻿
MERGE INTO [etl].AccessLevel AS Target
USING	(
			VALUES(1, 'Admin'), (2, 'Reader'), (3, 'Approver')
		) AS Source(PK_AccessLevel, AccessLevel)
ON    (Target.PK_AccessLevel = Source.PK_AccessLevel)
WHEN	NOT MATCHED
THEN	INSERT(AccessLevel,PK_AccessLevel)
		VALUES(Source.AccessLevel,  Source.PK_AccessLevel)
WHEN	MATCHED
THEN	UPDATE SET AccessLevel = source.AccessLevel;


