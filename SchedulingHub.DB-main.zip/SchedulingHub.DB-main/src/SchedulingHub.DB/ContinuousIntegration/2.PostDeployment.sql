DECLARE @Trancount INT = @@Trancount
				--:r .\ServerLevelConfiguration\ProxyCredentials.sql


BEGIN TRY
	IF @Trancount = 0 BEGIN TRAN;
			--Server Level
			:r .\ServerLevelConfiguration\EnvironmentVariables.sql
			:r .\ServerLevelConfiguration\SchedulingHub.sql
			:r .\ServerLevelConfiguration\IFRS17OrchestrationRunner.sql
			:r .\ServerLevelConfiguration\IFRS17BR1Scheduler_OnDemand.sql
			--temporary use. 
			

			--Static data
			:r .\StaticTables\etl.AccessLevel.sql
			:r .\StaticTables\etl.AuthorisationStatus.sql
			:r .\StaticTables\etl.IntervalType.sql
			:r .\StaticTables\etl.ModuleStatus.sql
			:r .\StaticTables\etl.ModuleType.sql
			:r .\StaticTables\etl.OrchestrationRunConfig.sql
			:r .\StaticTables\etl.OrchestrationRunModules.sql

			--Orchestrations
			:r .\Orchestrations\TechnicalResult.sql
			:r .\Orchestrations\BaseLoad.sql
			:r .\Orchestrations\FDMPostings.sql
			:r .\Orchestrations\IFRS17.sql
			:r .\Orchestrations\BR1LoadtoTechHub.sql
			:r .\Orchestrations\SO1BR1Load.sql
			:r .\Orchestrations\CubeProcess.sql
			:r .\Orchestrations\AssumptionDatasetProcessing.sql
			:r .\Orchestrations\IFRS17_TL.sql
			:r .\Orchestrations\IFRS17_1.sql
			:r .\Orchestrations\IFRS17_preprocessing_aggregation.sql
			:r .\Orchestrations\IFRS17_RI.sql
			:r .\Orchestrations\IFRS17_IL.sql
			:r .\Orchestrations\IFRS17_NTL.sql
			:r .\Orchestrations\IFRS17_Scheduler.sql 
			:r .\Orchestrations\IFRS17_Scheduler_DimsFact.sql 
			--:r .\Orchestrations\BR2_IFRS17_ForecastPreProcessing.sql
			--:r .\Orchestrations\BR2_IFRS17_BudgetPreProcessing.sql
			:r .\Orchestrations\IFRS17_Scheduler_ViewToTable.sql
			

			--Static script
			:r .\StaticTables\sch.DataSetConfig.sql
			:r .\StaticTables\sch.DataSetConfigModules.sql
			:r .\StaticTables\sch.DataSetConfigModules_Daily.sql
			:r .\StaticTables\sch.DataSetConfigModules_Monthly.sql
			:r .\StaticTables\sch.DataSetConfigModules_Quarterly.sql
			:r .\StaticTables\sch.DataSetConfigModules_Weekly.sql
			:r .\StaticTables\sch.ScheduleType.sql
			:r .\StaticTables\sch.AutoSchedule.sql

		IF @Trancount = 0 COMMIT;
END TRY
BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
END CATCH