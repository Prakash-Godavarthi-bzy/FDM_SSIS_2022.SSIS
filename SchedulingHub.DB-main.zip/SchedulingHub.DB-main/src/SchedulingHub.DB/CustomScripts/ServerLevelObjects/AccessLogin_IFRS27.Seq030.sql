-- INCLUDE #{Login2_Pre_v4}

SET @user_name = 'PXY_IFRS17'

/*
Create an environment windows login

    The username will be the same in all environments         - accounttype_applicationname
        where accounttype is the type of application account, e.g. SVC or PXY
    The windows login will change across the environments     - domain\accounttype_applicationname_env
        env will be something like DEV, SYS, UAT, PKG, or PRD
        The login will be BFL\<user_name>_<environment> for all environments

Instructions:
=============
1. Set the @user_name

*/
-- INCLUDE #{Login2_Post_v4}
