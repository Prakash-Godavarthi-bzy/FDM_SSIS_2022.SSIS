﻿-- INCLUDE #{LinkedServer1_Pre_v4}

SET @LinkedServerName = N'SchedulingHubLinkedServer'
SET @RemoteUser = Null-- '#{pxy_fdm.ad.user}' -- For Windows / Kerberos set to null
SET @RemotePassword = Null-- '#{pxy_fdm.ad.user.password}' -- For Windows / Kerberos set to null
SET @DataSourceName = '#{financetechnicalhub.ssdb.instance}' -- remote server-instance name/CNAME
SET @CatalogName = N'SchedulingHub' -- remote database name
--SET @ProviderName nvarchar(128) = N'SQLNCLI'

-- INCLUDE #{LinkedServer1_Mid_v4}

/*

Use this for most LinkedServers (uses "Other" data sources)
With this type, the linked server destination instance name can change for each environment and you can set the remote database name

Instructions:
=============
1. Set the @LinkedServerName
2. Create an Octopus variable for the @RemoteUser
   If you are using Kerberos, set @RemoteUser to NULL
3. Create an Octopus variable for the @RemotePassword
   If you are using Kerberos, set @RemotePassword to NULL
4. Create an Octopus variable for the @DataSourceName (remote instance or CNAME)
5. Set the @CatalogName (remote database name)
6. If the default @ProviderName is not 'SQLNCLI', then uncomment and set the @ProviderName
7. Set any non-standard config below, e.g.

*/
-- EXEC master.dbo.sp_serveroption @server=@LinkedServerName, @optname=N'collation compatible', @optvalue=N'false'

-- INCLUDE #{LinkedServer_TEST}