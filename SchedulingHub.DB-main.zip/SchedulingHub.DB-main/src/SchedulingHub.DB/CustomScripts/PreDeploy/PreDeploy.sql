﻿--=================================================================================================
--Change Version	: 1.0 
--Sprint			: BR1 Q3 24 committed
--Author			: lakshman.akasapu@beazley.com
--Modify Date	    : 2024-08-06 
--Description		: https://beazley.atlassian.net/browse/I1B-5328
--					  Drop tables and procedures scripts has written here
--=================================================================================================

-- Alter DateAsInt column

IF EXISTS (
    SELECT *
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'Orchestrationrunner'
      AND COLUMN_NAME = 'DateAsInt'
	  AND TABLE_SCHEMA = 'sch'
      AND DATA_TYPE = 'int'  -- Replace 'int' with the actual data type
) 
BEGIN
	ALTER TABLE [sch].[Orchestrationrunner]
	ADD [NewDateAsInt]            CHAR(8)             DEFAULT (Convert(CHAR(8),GETDATE(),112))
END
GO

IF EXISTS (
    SELECT *
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'Orchestrationrunner'
      AND COLUMN_NAME = 'NewDateAsInt'
	  AND TABLE_SCHEMA = 'sch'
) 
BEGIN

DECLARE @SQL NVARCHAR(MAX) = 'UPDATE [sch].[Orchestrationrunner] SET [NewDateAsInt]  = [DateAsInt] '
EXEC sp_executesql @sql

	ALTER TABLE [sch].[Orchestrationrunner]
	DROP COLUMN [DateAsInt] 

	EXEC sp_rename '[sch].[Orchestrationrunner].NewDateAsInt', 'DateAsInt', 'COLUMN'
END

-- Create System version tables
IF OBJECT_ID('sch.Child_Orchestrationrunner', 'U') IS NOT NULL AND OBJECT_ID('sch.Orchestrationrunner', 'U') IS NOT NULL
BEGIN

	IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Child_Orchestrationrunner' AND COLUMN_NAME IN ('ValidFrom', 'ValidTo'))) AND 
	   (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Orchestrationrunner' AND COLUMN_NAME IN ('ValidFrom', 'ValidTo')))
	BEGIN

		DROP TABLE IF EXISTS #temp_Child_Orchestrationrunner
		SELECT		   [id]
		  ,[PKSCID]
		  ,[acc_from]
		  ,[acc_To]
		  ,[status]
		  ,[batchID]
		  ,[Psicle_Message]
		  ,[AuditTime]
		INTO	#temp_Child_Orchestrationrunner
		FROM	sch.Child_Orchestrationrunner

		DROP TABLE IF EXISTS #temp_Orchestrationrunner
		SELECT	[PKSCID]
		  ,[PK_Orchestration]
		  ,[UserName]
		  ,[UserEmail]
		  ,[FromAccountingPeriod]
		  ,[ToAccountingPeriod]
		  ,[Auditinserttime]
		  ,[AuditUserCreate]
		  ,[Status]
		  ,[ExecutionID]
		  ,[DateAsInt]
		INTO	#temp_Orchestrationrunner
		FROM	sch.Orchestrationrunner
		

		DELETE FROM sch.Child_Orchestrationrunner
		DBCC CHECKIDENT('sch.Child_Orchestrationrunner',RESEED,0)

		ALTER TABLE [sch].[Child_Orchestrationrunner]
		ADD 	[ValidFrom]               DATETIME2 (7) GENERATED ALWAYS AS ROW START NOT NULL,
		[ValidTo]                 DATETIME2 (7) GENERATED ALWAYS AS ROW END   NOT NULL,
		PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])

		DELETE FROM sch.Orchestrationrunner
		DBCC CHECKIDENT('sch.Orchestrationrunner',RESEED,0)

		ALTER TABLE [sch].[Orchestrationrunner]
		ADD 	[ValidFrom]               DATETIME2 (7) GENERATED ALWAYS AS ROW START NOT NULL,
		[ValidTo]                 DATETIME2 (7) GENERATED ALWAYS AS ROW END   NOT NULL,
		PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])

		--IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Orchestrationrunner' AND COLUMN_NAME IN ('Forecast_BudgetRunType')))
		--BEGIN
		--	ALTER TABLE [sch].[Orchestrationrunner]
		--	ADD	[Forecast_BudgetRunType] [varchar](20) NULL
		--END

		--IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Orchestrationrunner' AND COLUMN_NAME IN ('FileName')))
		--BEGIN
		--	ALTER TABLE [sch].[Orchestrationrunner]
		--	ADD	[FileName] [varchar](max) NULL
		--END

		-- Insert Parent Table (sch.Orchestrationrunner)
	INSERT INTO sch.Orchestrationrunner (
				  [PK_Orchestration]
				 ,[UserName]
				 ,[UserEmail]
				 ,[FromAccountingPeriod]
				 ,[ToAccountingPeriod]
				 ,[Auditinserttime]
				 ,[AuditUserCreate]
				 ,[Status]
				 ,[ExecutionID]
				 ,[DateAsInt]
				 )
		SELECT	  [PK_Orchestration]
				 ,[UserName]
				 ,[UserEmail]
				 ,[FromAccountingPeriod]
				 ,[ToAccountingPeriod]
				 ,[Auditinserttime]
				 ,[AuditUserCreate]
				 ,[Status]
				 ,[ExecutionID]
				 ,[DateAsInt]
		FROM	#temp_Orchestrationrunner

		-- Insert Child Table (sch.Child_Orchestrationrunner)
		INSERT	INTO sch.Child_Orchestrationrunner (
				[PKSCID]
		       ,[acc_from]
		       ,[acc_To]
		       ,[status]
		       ,[batchID]
		       ,[Psicle_Message]
		       ,[AuditTime]
			)
		SELECT	[PKSCID]
		       ,[acc_from]
		       ,[acc_To]
		       ,[status]
		       ,[batchID]
		       ,[Psicle_Message]
		       ,[AuditTime]
		FROM   #temp_Child_Orchestrationrunner
	END

	-- Drop the temp tables
	DROP TABLE IF EXISTS #temp_Child_Orchestrationrunner
	DROP TABLE IF EXISTS #temp_Orchestrationrunner
END


--Delete below statements once sprint17 (23q4 commited sprint) is crossed (no longer needed)

BEGIN
	IF EXISTS (
				SELECT DISTINCT 1 
				FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
				WHERE CONSTRAINT_CATALOG = 'SchedulingHub' and TABLE_SCHEMA = 'sch' and CONSTRAINT_NAME like 'FK_Orchestration_DSconfig%'
			)
	BEGIN
		ALTER TABLE sch.DataSetConfig					DROP CONSTRAINT FK_Orchestration_DSconfig
		ALTER TABLE sch.DataSetConfigModules			DROP CONSTRAINT FK_Orchestration_DSConfigMod
		ALTER TABLE sch.DataSetConfigModules_Daily		DROP CONSTRAINT FK_Orchestration_DSConfigModD
		ALTER TABLE sch.DataSetConfigModules_Monthly	DROP CONSTRAINT FK_Orchestration_DSConfigModM
		ALTER TABLE sch.DataSetConfigModules_Quarterly	DROP CONSTRAINT FK_Orchestration_DSConfigModQ
		ALTER TABLE sch.DataSetConfigModules_Weekly		DROP CONSTRAINT FK_Orchestration_DSConfigModW
	END
END



BEGIN
IF EXISTS (
			SELECT DISTINCT 1
			FROM sys.tables t
			JOIN sys.columns c ON c.[object_id] = t.[object_id]
			JOIN sys.foreign_keys fk ON fk.parent_object_id = t.[object_id]
			WHERE t.[name] IN (
					'DataSetConfig'
					,'DataSetConfigModules'
					,'DataSetConfigModules_Daily'
					,'DataSetConfigModules_Monthly'
					,'DataSetConfigModules_Quarterly'
					,'DataSetConfigModules_Weekly'
					,'ScheduleRunLog'
					,'UserSchedule'
					)
				AND c.[name] LIKE 'FK_Config%'
				AND fk.[name] LIKE 'FK_Config%'
			)
	BEGIN
		ALTER TABLE sch.DataSetConfigModules			DROP CONSTRAINT FK_ConfigID_DSConfigMod
		ALTER TABLE sch.DataSetConfigModules_Daily		DROP CONSTRAINT FK_ConfigID_DSConfigModD
		ALTER TABLE sch.DataSetConfigModules_Monthly	DROP CONSTRAINT FK_ConfigID_DSConfigModM
		ALTER TABLE sch.DataSetConfigModules_Quarterly	DROP CONSTRAINT FK_ConfigID_DSConfigModQ
		ALTER TABLE sch.DataSetConfigModules_Weekly		DROP CONSTRAINT FK_ConfigID_DSConfigModW
		ALTER TABLE sch.ScheduleRunLog					DROP CONSTRAINT FK_ConfigID_SchRunLog
		ALTER TABLE sch.UserSchedule					DROP CONSTRAINT FK_ConfigID_UserSchedule
	END
END


BEGIN
	IF EXISTS (
		SELECT DISTINCT 1
		FROM SchedulingHub.sch.UserSchedule
		WHERE Dataset = 'ViewToTable'
			AND FK_ConfigID = 51
		)
	BEGIN
		UPDATE SchedulingHub.sch.UserSchedule
		SET FK_ConfigID = 49
		WHERE Dataset = 'ViewToTable'
			AND FK_ConfigID = 51
	END
	
	IF EXISTS (
			SELECT DISTINCT 1
			FROM SchedulingHub.sch.ScheduleRunLog
			WHERE Dataset = 'ViewToTable'
				AND FK_ConfigID = 51
			)
	BEGIN
		UPDATE SchedulingHub.sch.ScheduleRunLog
		SET FK_ConfigID = 49
		WHERE Dataset = 'ViewToTable'
			AND FK_ConfigID = 51
	END
	
	IF EXISTS (
			SELECT DISTINCT 1
			FROM SchedulingHub.sch.UserSchedule
			WHERE Dataset = 'USPremium'
				AND FK_ConfigID = 46
			)	BEGIN
		UPDATE SchedulingHub.sch.UserSchedule
		SET FK_ConfigID = 47
		WHERE Dataset = 'USPremium'
			AND FK_ConfigID = 46
	END
	
	IF EXISTS (
			SELECT DISTINCT 1
			FROM SchedulingHub.sch.ScheduleRunLog
			WHERE Dataset = 'USPremium'
				AND FK_ConfigID = 46
			)
	BEGIN
		UPDATE SchedulingHub.sch.ScheduleRunLog
		SET FK_ConfigID = 47
		WHERE Dataset = 'USPremium'
			AND FK_ConfigID = 46
	END

END
-- Comment when sending it to UAT 
--IF NOT EXISTS (
--    SELECT *
--    FROM INFORMATION_SCHEMA.COLUMNS
--    WHERE TABLE_NAME = 'Orchestrationrunner'
--      AND COLUMN_NAME = 'Forecast_BudgetRunType' -- adding a new column by Forecast_BugetRunType for Orchestration build
--	  AND TABLE_SCHEMA = 'sch' 
--) 
--BEGIN
--	ALTER TABLE [sch].[Orchestrationrunner]
--	ADD Forecast_BudgetRunType varchar(20)
--END

--IF NOT EXISTS (
--    SELECT *
--    FROM INFORMATION_SCHEMA.COLUMNS
--    WHERE TABLE_NAME = 'Orchestrationrunner'
--      AND COLUMN_NAME = 'FileName' -- adding a new column by FileNames for Orchestration build
--	  AND TABLE_SCHEMA = 'sch' 
--) 
--BEGIN
--	ALTER TABLE [sch].[Orchestrationrunner]
--	ADD FileName varchar(355)
--END

	 -- Uncomment when sending it to UAT 
		IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Orchestrationrunner' AND COLUMN_NAME IN ('Forecast_BudgetRunType'))
		BEGIN

		ALTER TABLE [sch].[Orchestrationrunner]
		SET (SYSTEM_VERSIONING = OFF);

			ALTER TABLE [sch].[Orchestrationrunner]
			Drop column	[Forecast_BudgetRunType] 
		END

		IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Orchestrationrunner_History' AND COLUMN_NAME IN ('Forecast_BudgetRunType'))
		BEGIN
			ALTER TABLE sch.Orchestrationrunner_History
			Drop column	[Forecast_BudgetRunType] 

			ALTER TABLE [sch].[Orchestrationrunner]
			SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = sch.Orchestrationrunner_History));
		END

		IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Orchestrationrunner' AND COLUMN_NAME IN ('FileName'))
		BEGIN

		ALTER TABLE [sch].[Orchestrationrunner]
		SET (SYSTEM_VERSIONING = OFF);

			ALTER TABLE [sch].[Orchestrationrunner]
			Drop column	[FileName]
		END

		IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Orchestrationrunner_History' AND COLUMN_NAME IN ('FileName'))
		BEGIN
			ALTER TABLE sch.Orchestrationrunner_History
			Drop column	[FileName]

			ALTER TABLE [sch].[Orchestrationrunner]
			SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = sch.Orchestrationrunner_History));
		END


--===========================================================
--Stored Procedures
--===========================================================

IF (OBJECT_ID('[Logging].[usp_ActivityLogArchive]', 'P') IS NOT NULL)
BEGIN
  DROP PROCEDURE [Logging].[usp_ActivityLogArchive];
END;

--===========================================================
--Tables
--===========================================================

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES  WHERE TABLE_SCHEMA='etl' AND TABLE_NAME='OrchestrationSharepoint')
BEGIN
ALTER TABLE SchedulingHub.etl.OrchestrationSharepoint
SET (SYSTEM_VERSIONING = OFF);

DROP TABLE [etl].[OrchestrationSharepoint]
END

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES  WHERE TABLE_SCHEMA='etl' AND TABLE_NAME='OrchestrationSharepoint_History')
BEGIN
DROP TABLE [etl].[OrchestrationSharepoint_History]
END

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES  WHERE TABLE_SCHEMA='Utility' AND TABLE_NAME='Configuration')
BEGIN
DROP TABLE [Utility].[Configuration]
END

