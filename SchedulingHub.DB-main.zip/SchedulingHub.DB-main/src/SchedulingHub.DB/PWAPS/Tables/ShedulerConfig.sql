﻿CREATE TABLE [PWAPS].[ShedulerConfig] (
    [PKSCID]          INT            IDENTITY (1, 1) NOT NULL,
    [UserName]        VARCHAR (MAX)  NOT NULL,
    [UserEmail]       NVARCHAR (MAX) NOT NULL,
    [RunType]         VARCHAR (50)   NOT NULL,
    [Dataset]         VARCHAR (255)  NULL,
    [RunSubtype]      VARCHAR (50)   NOT NULL,
    [Comments]        NVARCHAR (255) NULL,
    [Auditinserttime] DATETIME       DEFAULT (getdate()) NULL,
    [activeFlag]      INT            DEFAULT ((1)) NULL,
    CONSTRAINT [PK1] PRIMARY KEY CLUSTERED ([PKSCID] ASC) WITH (FILLFACTOR = 90)
);

