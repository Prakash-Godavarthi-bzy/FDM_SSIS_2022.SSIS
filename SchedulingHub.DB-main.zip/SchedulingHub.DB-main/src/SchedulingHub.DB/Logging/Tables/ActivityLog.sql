﻿CREATE TABLE [Logging].[ActivityLog] (
    [PK_ActivityLog]          BIGINT          IDENTITY (1, 1) NOT NULL,
    [FK_ParentActivityLog]    BIGINT          NULL,
    [FK_ActivityLogTag]       BIGINT          NULL,
    [FK_ActivitySource]       SMALLINT        NOT NULL,
    [FK_ActivityType]         SMALLINT        NOT NULL,
    [FK_ActivityStatus]       SMALLINT        NOT NULL,
    [ActivityHost]            VARCHAR (100)   NOT NULL,
    [ActivityDatabase]        VARCHAR (100)   NULL,
    [ActivityJobId]           VARCHAR (50)    NULL,
    [ActivitySSISExecutionId] VARCHAR (50)    NULL,
    [ActivityName]            VARCHAR (100)   NOT NULL,
    [ActivityDateTime]        DATETIME2 (2)   NULL,
    [ActivityMessage]         NVARCHAR (4000) NULL,
    [ActivityErrorCode]       NVARCHAR (50)   NULL,
    [AuditCreateDateTime]     DATETIME2 (2)   CONSTRAINT [DF_ActivityLog_AuditCreateDateTime] DEFAULT (getutcdate()) NOT NULL,
    [AuditModifyDateTime]     DATETIME2 (2)   NULL,
    [AuditUserCreate]         VARCHAR (64)    CONSTRAINT [DF_ActivityLog_AuditUserCreate] DEFAULT (suser_sname()) NOT NULL,
    [AuditUserModify]         VARCHAR (64)    NULL,
    PRIMARY KEY CLUSTERED ([PK_ActivityLog] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_ActivityLog_ActivityLog] FOREIGN KEY ([FK_ParentActivityLog]) REFERENCES [Logging].[ActivityLog] ([PK_ActivityLog]),
    CONSTRAINT [FK_ActivityLog_ActivitySource] FOREIGN KEY ([FK_ActivitySource]) REFERENCES [Logging].[ActivitySource] ([PK_ActivitySource]),
    CONSTRAINT [FK_ActivityLog_ActivityStatus] FOREIGN KEY ([FK_ActivityStatus]) REFERENCES [Logging].[ActivityStatus] ([PK_ActivityStatus]),
    CONSTRAINT [FK_ActivityLog_ActivityType] FOREIGN KEY ([FK_ActivityType]) REFERENCES [Logging].[ActivityType] ([PK_ActivityType]),
    CONSTRAINT [FK_ActivityLogTag_ActivityLog] FOREIGN KEY ([FK_ActivityLogTag]) REFERENCES [Logging].[ActivityLog] ([PK_ActivityLog])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Audit column to track updates by user in the activity log records.', @level0type = N'SCHEMA', @level0name = N'Logging', @level1type = N'TABLE', @level1name = N'ActivityLog', @level2type = N'COLUMN', @level2name = N'AuditUserModify';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Audit column to record the users including service accounts that insert the records in the activity log.', @level0type = N'SCHEMA', @level0name = N'Logging', @level1type = N'TABLE', @level1name = N'ActivityLog', @level2type = N'COLUMN', @level2name = N'AuditUserCreate';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Audit column to track updates by date and time in the activity log records.', @level0type = N'SCHEMA', @level0name = N'Logging', @level1type = N'TABLE', @level1name = N'ActivityLog', @level2type = N'COLUMN', @level2name = N'AuditModifyDateTime';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Audit column to stamp date the records inserted in the activity log.', @level0type = N'SCHEMA', @level0name = N'Logging', @level1type = N'TABLE', @level1name = N'ActivityLog', @level2type = N'COLUMN', @level2name = N'AuditCreateDateTime';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'The system error code of the activity in case of a system failure.', @level0type = N'SCHEMA', @level0name = N'Logging', @level1type = N'TABLE', @level1name = N'ActivityLog', @level2type = N'COLUMN', @level2name = N'ActivityErrorCode';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Information related to the activity recorded i.e. the error message of the activity in case of a failure.', @level0type = N'SCHEMA', @level0name = N'Logging', @level1type = N'TABLE', @level1name = N'ActivityLog', @level2type = N'COLUMN', @level2name = N'ActivityMessage';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'The date and time of the activity recorded in the log. This is when the activity is generated in the activity originator (client)', @level0type = N'SCHEMA', @level0name = N'Logging', @level1type = N'TABLE', @level1name = N'ActivityLog', @level2type = N'COLUMN', @level2name = N'ActivityDateTime';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'The name of the activity recorded in the log.', @level0type = N'SCHEMA', @level0name = N'Logging', @level1type = N'TABLE', @level1name = N'ActivityLog', @level2type = N'COLUMN', @level2name = N'ActivityName';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Execution Id for the package that is executed on the Integration Services server that generates the activity recorded in the log.', @level0type = N'SCHEMA', @level0name = N'Logging', @level1type = N'TABLE', @level1name = N'ActivityLog', @level2type = N'COLUMN', @level2name = N'ActivitySSISExecutionId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Identifier for the job that is executed on the client server and generates the activity recorded in the log.', @level0type = N'SCHEMA', @level0name = N'Logging', @level1type = N'TABLE', @level1name = N'ActivityLog', @level2type = N'COLUMN', @level2name = N'ActivityJobId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'The name of the client database from where the activity recorded in the log is generated (if applicable).', @level0type = N'SCHEMA', @level0name = N'Logging', @level1type = N'TABLE', @level1name = N'ActivityLog', @level2type = N'COLUMN', @level2name = N'ActivityDatabase';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'The name of the host/client from where the activity recorded in the log is generated (if applicable).', @level0type = N'SCHEMA', @level0name = N'Logging', @level1type = N'TABLE', @level1name = N'ActivityLog', @level2type = N'COLUMN', @level2name = N'ActivityHost';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'The FK representing the status of the activity recorded in the log.', @level0type = N'SCHEMA', @level0name = N'Logging', @level1type = N'TABLE', @level1name = N'ActivityLog', @level2type = N'COLUMN', @level2name = N'FK_ActivityStatus';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'The FK representing the type of the activity recorded in the log.', @level0type = N'SCHEMA', @level0name = N'Logging', @level1type = N'TABLE', @level1name = N'ActivityLog', @level2type = N'COLUMN', @level2name = N'FK_ActivityType';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'The FK representing the name of the originator (data source or system) of the activity recorded in the log.', @level0type = N'SCHEMA', @level0name = N'Logging', @level1type = N'TABLE', @level1name = N'ActivityLog', @level2type = N'COLUMN', @level2name = N'FK_ActivitySource';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'The FK linking records within the same activity. For example, a SUCCEDED event is linked to its STARTED event via this field.', @level0type = N'SCHEMA', @level0name = N'Logging', @level1type = N'TABLE', @level1name = N'ActivityLog', @level2type = N'COLUMN', @level2name = N'FK_ActivityLogTag';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Used to hierarchically link activities in the log (parent/child).', @level0type = N'SCHEMA', @level0name = N'Logging', @level1type = N'TABLE', @level1name = N'ActivityLog', @level2type = N'COLUMN', @level2name = N'FK_ParentActivityLog';


GO
EXECUTE sp_addextendedproperty @name = N'Table definition', @value = N'Table used to log (store) mainly operational activity/events generated from multiple platforms/systems, for example the FDM or the IFRS17 systems.', @level0type = N'SCHEMA', @level0name = N'Logging', @level1type = N'TABLE', @level1name = N'ActivityLog';

