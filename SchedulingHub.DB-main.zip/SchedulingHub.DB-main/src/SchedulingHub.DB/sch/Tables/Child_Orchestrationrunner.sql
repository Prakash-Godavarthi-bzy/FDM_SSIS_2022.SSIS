﻿CREATE TABLE [sch].[Child_Orchestrationrunner] (
    [id]             INT            IDENTITY (1, 1) NOT NULL,
    [PKSCID]         INT            NOT NULL,
    [acc_from]       INT            NOT NULL,
    [acc_To]         INT            NOT NULL,
    [status]         VARCHAR (255)  DEFAULT ('pending') NOT NULL,
    [batchID]        INT            NULL,
    [Psicle_Message] NVARCHAR (MAX) NULL,
    [AuditTime]      DATETIME       DEFAULT (getdate()) NULL,
	[ValidFrom]               DATETIME2 (7) GENERATED ALWAYS AS ROW START NOT NULL,
    [ValidTo]                 DATETIME2 (7) GENERATED ALWAYS AS ROW END   NOT NULL,
    PRIMARY KEY CLUSTERED ([id] ASC) WITH (FILLFACTOR = 90),
	CONSTRAINT [FK_PKSCID] FOREIGN KEY ([PKSCID]) REFERENCES [sch].[Orchestrationrunner] ([PKSCID]),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[sch].[Child_Orchestrationrunner_History], DATA_CONSISTENCY_CHECK=ON));

GO