﻿CREATE TABLE [sch].[ScheduleRunLog](
	[PK_RunLogID] [int] IDENTITY(1,1) NOT NULL,
	[FK_SchID] [int] NOT NULL,
	[FK_ConfigID] [int] NOT NULL,
	[SchRunType] [varchar](255) NULL,
	[WorkingDay] [varchar](10) NULL,
	[Dataset] [varchar](255) NOT NULL,
	[StartTime] [datetime] NULL,
	[EndTime] [datetime] NULL,
	[Duration] [nvarchar](255) NULL,
	[Status] [varchar](25) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserRun] [varchar](255) NOT NULL,
	[AuditHost] [varchar](255) NOT NULL,
	[Description] [varchar](4000) NULL,
 CONSTRAINT [PK_RunLogID] PRIMARY KEY CLUSTERED 
(
	[PK_RunLogID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [sch].[ScheduleRunLog] ADD  CONSTRAINT [DF_AuditCreateDateTime_SchRunLog]  DEFAULT (getdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [sch].[ScheduleRunLog] ADD  CONSTRAINT [DF_Audithost_SchRunLog]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO

ALTER TABLE [sch].[ScheduleRunLog]  WITH CHECK ADD  CONSTRAINT [FK_SchID_SchRunLog] FOREIGN KEY([FK_SchID])
REFERENCES [sch].[ScheduleType] ([PK_SchID])
GO

ALTER TABLE [sch].[ScheduleRunLog] CHECK CONSTRAINT [FK_SchID_SchRunLog]
GO

ALTER TABLE [sch].[ScheduleRunLog]  WITH CHECK ADD  CONSTRAINT [FK_ConfigID_SchRunLog] FOREIGN KEY([FK_ConfigID])
REFERENCES [sch].[DataSetConfig] ([PK_ConfigID])
GO

ALTER TABLE [sch].[ScheduleRunLog] CHECK CONSTRAINT [FK_ConfigID_SchRunLog]
GO