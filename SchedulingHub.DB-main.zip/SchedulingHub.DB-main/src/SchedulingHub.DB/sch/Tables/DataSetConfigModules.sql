﻿CREATE TABLE [sch].[DataSetConfigModules](
	[PK_ConfigModID] [int] NOT NULL,
	[FK_ConfigID] [int] NOT NULL,
	[Dataset] [varchar](100) NOT NULL,
	[Module] [int] NOT NULL,
	[FK_Orchestration] [int] NOT NULL,
	[ModuleObjectName] [varchar](255) NULL,
	[ModuleUsedFor] [varchar](255) NULL,
	[Extension] [varchar](100) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [varchar](255) NOT NULL,
	[AuditHost] [varchar](255) NOT NULL,
	[ValidFrom] [datetime2](7) GENERATED ALWAYS AS ROW START NOT NULL,
	[ValidTo] [datetime2](7) GENERATED ALWAYS AS ROW END NOT NULL,
 CONSTRAINT [PK_ConfigModID] PRIMARY KEY CLUSTERED 
(
	[PK_ConfigModID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY],
	PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
) ON [PRIMARY] 
WITH
(
SYSTEM_VERSIONING = ON ( HISTORY_TABLE = [sch].[DataSetConfigModules_History] )
)
GO

ALTER TABLE [sch].[DataSetConfigModules] ADD  CONSTRAINT [DF_AuditCreateDateTime_DSConfigMod]  DEFAULT (getdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [sch].[DataSetConfigModules] ADD  CONSTRAINT [DF_AuditUserCreate_DSConfigMod]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [sch].[DataSetConfigModules] ADD  CONSTRAINT [DF_Audithost_DSConfigMod]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO

ALTER TABLE [sch].[DataSetConfigModules]  WITH CHECK ADD  CONSTRAINT [FK_ConfigID_DSConfigMod] FOREIGN KEY([FK_ConfigID])
REFERENCES [sch].[DataSetConfig] ([PK_ConfigID])
GO

ALTER TABLE [sch].[DataSetConfigModules] CHECK CONSTRAINT [FK_ConfigID_DSConfigMod]
GO

ALTER TABLE [sch].[DataSetConfigModules]  WITH CHECK ADD  CONSTRAINT [FK_Orchestration_DSConfigMod] FOREIGN KEY([FK_Orchestration])
REFERENCES [etl].[Orchestration] ([PK_Orchestration])
GO

ALTER TABLE [sch].[DataSetConfigModules] CHECK CONSTRAINT [FK_Orchestration_DSConfigMod]
GO