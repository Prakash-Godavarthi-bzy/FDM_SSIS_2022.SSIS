﻿CREATE TABLE [sch].[DataSetConfigModules_Monthly](
	[PK_ConfigModMID] [int] NOT NULL,
	[FK_ConfigID] [int] NOT NULL,
	[Dataset] [varchar](100) NOT NULL,
	[WorkingDay] [varchar](10) NULL,
	[Module] [int] NOT NULL,
	[FK_Orchestration] [int] NOT NULL,
	[ModuleObjectName] [varchar](255) NULL,
	[ModuleUsedFor] [varchar](255) NULL,
	[Extension] [varchar](100) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [varchar](255) NOT NULL,
	[AuditHost] [varchar](255) NOT NULL,
	[ValidFrom] [datetime2](7) GENERATED ALWAYS AS ROW START NOT NULL,
	[ValidTo] [datetime2](7) GENERATED ALWAYS AS ROW END NOT NULL,
 CONSTRAINT [PK_ConfigModMID] PRIMARY KEY CLUSTERED 
(
	[PK_ConfigModMID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY],
	PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
) ON [PRIMARY]

GO

ALTER TABLE [sch].[DataSetConfigModules_Monthly] ADD  CONSTRAINT [DF_AuditCreateDateTime_DSConfigModM]  DEFAULT (getdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [sch].[DataSetConfigModules_Monthly] ADD  CONSTRAINT [DF_AuditUserCreate_DSConfigModM]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [sch].[DataSetConfigModules_Monthly] ADD  CONSTRAINT [DF_Audithost_DSConfigModM]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO

ALTER TABLE [sch].[DataSetConfigModules_Monthly]  WITH CHECK ADD  CONSTRAINT [FK_ConfigID_DSConfigModM] FOREIGN KEY([FK_ConfigID])
REFERENCES [sch].[DataSetConfig] ([PK_ConfigID])
GO

ALTER TABLE [sch].[DataSetConfigModules_Monthly] CHECK CONSTRAINT [FK_ConfigID_DSConfigModM]
GO

ALTER TABLE [sch].[DataSetConfigModules_Monthly]  WITH CHECK ADD  CONSTRAINT [FK_Orchestration_DSConfigModM] FOREIGN KEY([FK_Orchestration])
REFERENCES [etl].[Orchestration] ([PK_Orchestration])
GO

ALTER TABLE [sch].[DataSetConfigModules_Monthly] CHECK CONSTRAINT [FK_Orchestration_DSConfigModM]
GO