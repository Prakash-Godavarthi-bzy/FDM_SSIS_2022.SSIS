﻿CREATE TABLE [sch].[Child_Orchestrationrunner_History] (
    [id]             INT            NOT NULL,
    [PKSCID]         INT            NOT NULL,
    [acc_from]       INT            NOT NULL,
    [acc_To]         INT            NOT NULL,
    [status]         VARCHAR (255)  DEFAULT ('pending') NOT NULL,
    [batchID]        INT            NULL,
    [Psicle_Message] NVARCHAR (MAX) NULL,
    [AuditTime]      DATETIME       DEFAULT (getdate()) NULL,
	ValidFrom	datetime2 (7) NOT NULL,
	ValidTo		datetime2 (7) NOT NULL
);

