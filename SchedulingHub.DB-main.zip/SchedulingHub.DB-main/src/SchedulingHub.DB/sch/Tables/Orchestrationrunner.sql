﻿CREATE TABLE [sch].[Orchestrationrunner] (
    [PKSCID]               INT            IDENTITY (1, 1) NOT NULL,
    [PK_Orchestration]     INT            NOT NULL,
    [UserName]             VARCHAR (MAX)  NOT NULL,
    [UserEmail]            NVARCHAR (MAX) NOT NULL,
    [FromAccountingPeriod] INT            NOT NULL,
    [ToAccountingPeriod]   INT            NOT NULL,
    [Auditinserttime]      DATETIME       DEFAULT (getdate()) NULL,
    [AuditUserCreate]      NVARCHAR (MAX) DEFAULT (suser_sname()) NULL,
    [Status]               VARCHAR (25)   NULL,
	[ExecutionID] INT NULL,
    [DateAsInt]            CHAR(8)             DEFAULT (Convert(CHAR(8),GETDATE(),112)),
	[ValidFrom]               DATETIME2 (7) GENERATED ALWAYS AS ROW START NOT NULL,
    [ValidTo]                 DATETIME2 (7) GENERATED ALWAYS AS ROW END   NOT NULL
	--[Forecast_BudgetRunType] [varchar](20) NULL,
	--[FileName] [varchar](355) NULL
    CONSTRAINT [PK1] PRIMARY KEY CLUSTERED ([PKSCID] ASC) WITH (FILLFACTOR = 90),
	CONSTRAINT [FK_Orchestration] FOREIGN KEY ([PK_Orchestration]) REFERENCES [etl].[Orchestration] ([PK_Orchestration]),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[sch].[Orchestrationrunner_History], DATA_CONSISTENCY_CHECK=ON));

GO
