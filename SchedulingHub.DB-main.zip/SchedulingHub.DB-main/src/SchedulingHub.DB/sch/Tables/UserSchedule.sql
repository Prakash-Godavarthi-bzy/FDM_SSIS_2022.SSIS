﻿CREATE TABLE [sch].[UserSchedule](
	[PK_UserSchID] [int] IDENTITY(1,1) NOT NULL,
	[FK_SchID] [int] NOT NULL,
	[FK_ConfigID] [int] NOT NULL,
	[Dataset] [varchar](255) NOT NULL,
	[AuditUserTriggered] [varchar](100) NOT NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditHost] [varchar](255) NOT NULL,
	[Description] [varchar](255) NULL,
	[Status] [varchar](10) NULL,
 CONSTRAINT [PK_UserSchID] PRIMARY KEY CLUSTERED 
(
	[PK_UserSchID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [sch].[UserSchedule] ADD  CONSTRAINT [DF_AuditCreateDateTime_UserSchedule]  DEFAULT (getdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [sch].[UserSchedule] ADD  CONSTRAINT [DF_Audithost_UserSchedule]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO

ALTER TABLE [sch].[UserSchedule]  WITH CHECK ADD  CONSTRAINT [FK_ConfigID_UserSchedule] FOREIGN KEY([FK_ConfigID])
REFERENCES [sch].[DataSetConfig] ([PK_ConfigID])
GO

ALTER TABLE [sch].[UserSchedule] CHECK CONSTRAINT [FK_ConfigID_UserSchedule]
GO

ALTER TABLE [sch].[UserSchedule]  WITH CHECK ADD  CONSTRAINT [FK_SchID_UserSchedule] FOREIGN KEY([FK_SchID])
REFERENCES [sch].[ScheduleType] ([PK_SchID])
GO

ALTER TABLE [sch].[UserSchedule] CHECK CONSTRAINT [FK_SchID_UserSchedule]
GO