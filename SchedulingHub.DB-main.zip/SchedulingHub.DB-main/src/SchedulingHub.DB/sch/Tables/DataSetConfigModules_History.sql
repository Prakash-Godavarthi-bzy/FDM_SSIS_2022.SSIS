﻿CREATE TABLE [sch].[DataSetConfigModules_History](
	[PK_ConfigModID] [int] NOT NULL,
	[FK_ConfigID] [int] NOT NULL,
	[Dataset] [varchar](100) NOT NULL,
	[Module] [int] NOT NULL,
	[FK_Orchestration] [int] NOT NULL,
	[ModuleObjectName] [varchar](255) NULL,
	[ModuleUsedFor] [varchar](255) NULL,
	[Extension] [varchar](100) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getdate()),
	[AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
	[AuditHost] [varchar](255) NOT NULL DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))),
	[ValidFrom] [datetime2](7) NOT NULL,
	[ValidTo] [datetime2](7) NOT NULL
	)