﻿CREATE TABLE [sch].[ScheduleType](
	[PK_SchID] [int]  NOT NULL,
	[SchRunType] [varchar](255) NULL,
	[WorkingDay] [varchar](10) NULL,
	[IsEnabled] [bit] NOT NULL,
	[IsUserInitiated] [bit] NOT NULL,
	[AuditUserTriggered] [varchar](100) NULL,
	[AuditUserEmail] [varchar](100) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditModifyDateTime] [datetime] NULL,
	[AuditHost] [varchar](255) NOT NULL,
	[Description] [varchar](255) NULL,
	[ValidFrom] [datetime2](7) GENERATED ALWAYS AS ROW START NOT NULL,
	[ValidTo] [datetime2](7) GENERATED ALWAYS AS ROW END NOT NULL,
 CONSTRAINT [PK_SchID] PRIMARY KEY CLUSTERED 
(
	[PK_SchID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY],
	PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
) ON [PRIMARY]
WITH
(
SYSTEM_VERSIONING = ON ( HISTORY_TABLE = [sch].[ScheduleType_History] )
)
GO

ALTER TABLE [sch].[ScheduleType] ADD  CONSTRAINT [DF_AuditCreateDateTime_ScheduleType]  DEFAULT (getdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [sch].[ScheduleType] ADD  CONSTRAINT [DF_AuditModifyDateTime_ScheduleType]  DEFAULT (getdate()) FOR [AuditModifyDateTime]
GO

ALTER TABLE [sch].[ScheduleType] ADD  CONSTRAINT [DF_Audithost_ScheduleType]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO