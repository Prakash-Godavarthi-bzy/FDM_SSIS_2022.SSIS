﻿CREATE TABLE [sch].[AutoSchedule](
	[PK_AutoSchID] [int] NOT NULL,
	[FK_SchID] [int] NOT NULL,
	[FK_ConfigID] [int] NOT NULL,
	[Dataset] [varchar](255) NOT NULL,
	[SchRunType] [varchar](255) NULL,
	[WorkingDay] [varchar](10) NULL,
	[IsEnabled] [int] NOT NULL,
	[AuditUserModified] [varchar](100) NOT NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditModifyDateTime] [datetime] NOT NULL,
	[AuditHost] [varchar](255) NOT NULL,
	[Description] [varchar](255) NULL,
	[ValidFrom] [datetime2](7) GENERATED ALWAYS AS ROW START NOT NULL,
	[ValidTo] [datetime2](7) GENERATED ALWAYS AS ROW END NOT NULL,
 CONSTRAINT [PK_AutoSchID] PRIMARY KEY CLUSTERED 
(
	[PK_AutoSchID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY],
	PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
) ON [PRIMARY]
WITH
(
SYSTEM_VERSIONING = ON ( HISTORY_TABLE = [sch].[AutoSchedule_History] )
)
GO

ALTER TABLE [sch].[AutoSchedule] ADD  CONSTRAINT [DF_AuditUserModified_AutoSchedule]  DEFAULT (suser_sname()) FOR [AuditUserModified]
GO

ALTER TABLE [sch].[AutoSchedule] ADD  CONSTRAINT [DF_AuditCreateDateTime_AutoSchedule]  DEFAULT (getdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [sch].[AutoSchedule] ADD  CONSTRAINT [DF_AuditModifyDateTime_AutoSchedule]  DEFAULT (getdate()) FOR [AuditModifyDateTime]
GO

ALTER TABLE [sch].[AutoSchedule] ADD  CONSTRAINT [DF_Audithost_AutoSchedule]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO

ALTER TABLE [sch].[AutoSchedule]  WITH CHECK ADD  CONSTRAINT [FK_ConfigID_AutoSchedule] FOREIGN KEY([FK_ConfigID])
REFERENCES [sch].[DataSetConfig] ([PK_ConfigID])
GO

ALTER TABLE [sch].[AutoSchedule] CHECK CONSTRAINT [FK_ConfigID_AutoSchedule]
GO

ALTER TABLE [sch].[AutoSchedule]  WITH CHECK ADD  CONSTRAINT [FK_SchID_AutoSchedule] FOREIGN KEY([FK_SchID])
REFERENCES [sch].[ScheduleType] ([PK_SchID])
GO

ALTER TABLE [sch].[AutoSchedule] CHECK CONSTRAINT [FK_SchID_AutoSchedule]
GO