﻿CREATE TABLE [sch].[DataSetConfig](
	[PK_ConfigID] [int] IDENTITY(1,1) NOT NULL,
	[Dataset] [varchar](100) NOT NULL,
	[FK_Orchestration] [int] NOT NULL,
	[SourceFrom] [varchar](100) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [varchar](255) NOT NULL,
	[AuditHost] [varchar](255) NOT NULL,
 CONSTRAINT [PK_Config] PRIMARY KEY CLUSTERED 
(
	[PK_ConfigID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [sch].[DataSetConfig] ADD  CONSTRAINT [DF_AuditCreateDateTime_DSconfig]  DEFAULT (getdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [sch].[DataSetConfig] ADD  CONSTRAINT [DF_AuditUserCreate_DSconfig]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [sch].[DataSetConfig] ADD  CONSTRAINT [DF_Audithost_DSconfig]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO

ALTER TABLE [sch].[DataSetConfig]  WITH CHECK ADD  CONSTRAINT [FK_Orchestration_DSconfig] FOREIGN KEY([FK_Orchestration])
REFERENCES [etl].[Orchestration] ([PK_Orchestration])
GO

ALTER TABLE [sch].[DataSetConfig] CHECK CONSTRAINT [FK_Orchestration_DSconfig]
GO
