﻿CREATE TABLE [sch].[ControlDataset_History](
	[PK_ParamID] [int] NOT NULL,
	[Dataset] [varchar](100) NOT NULL,
	[PassingDate] [date] NOT NULL,
	[AuditUserModify] [varchar](255) NOT NULL,
	[AuditModifyDateTime] [datetime] NOT NULL,
	[Description] [varchar](1000) NULL,
	[AuditHost] [varchar](255) NULL,
	[ValidFrom] [datetime2](7) NOT NULL,
	[ValidTo] [datetime2](7) NOT NULL
)
GO
