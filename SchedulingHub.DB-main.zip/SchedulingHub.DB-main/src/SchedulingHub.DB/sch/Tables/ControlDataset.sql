﻿CREATE TABLE [sch].[ControlDataset](
	[PK_ParamID] [int] IDENTITY(1,1) NOT NULL,
	[Dataset] [varchar](100) NOT NULL,
	[PassingDate] [date] NOT NULL,
	[AuditUserModify] [varchar](255) NOT NULL,
	[AuditModifyDateTime] [datetime] NOT NULL,
	[Description] [varchar](1000) NULL,
	[AuditHost] [varchar](255) NULL,
	[ValidFrom] [datetime2](7) GENERATED ALWAYS AS ROW START NOT NULL,
	[ValidTo] [datetime2](7) GENERATED ALWAYS AS ROW END NOT NULL,
 CONSTRAINT [PK_ParamID] PRIMARY KEY CLUSTERED 
(
	[PK_ParamID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY],
	PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
) ON [PRIMARY]
WITH
(
SYSTEM_VERSIONING = ON ( HISTORY_TABLE = [sch].[ControlDataset_History] )
)
GO

ALTER TABLE [sch].[ControlDataset] ADD  CONSTRAINT [DF_AuditUserModify_ControlDataset]  DEFAULT (suser_sname()) FOR [AuditUserModify]
GO

ALTER TABLE [sch].[ControlDataset] ADD  CONSTRAINT [DF_AuditModifyDateTime_ControlDataset]  DEFAULT (getdate()) FOR [AuditModifyDateTime]
GO

ALTER TABLE [sch].[ControlDataset] ADD  CONSTRAINT [DF_Audithost_ControlDataset]  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO