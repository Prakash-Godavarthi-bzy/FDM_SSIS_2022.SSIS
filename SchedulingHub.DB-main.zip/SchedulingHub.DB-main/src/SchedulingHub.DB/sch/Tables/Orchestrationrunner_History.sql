﻿CREATE TABLE [sch].[Orchestrationrunner_History] (
    [PKSCID]               INT            NOT NULL,
    [PK_Orchestration]     INT            NOT NULL,
    [UserName]             VARCHAR (MAX)  NOT NULL,
    [UserEmail]            NVARCHAR (MAX) NOT NULL,
    [FromAccountingPeriod] INT            NOT NULL,
    [ToAccountingPeriod]   INT            NOT NULL,
    [Auditinserttime]      DATETIME       DEFAULT (getdate()) NULL,
    [AuditUserCreate]      NVARCHAR (MAX) DEFAULT (suser_sname()) NULL,
    [Status]               VARCHAR (25)   NULL,
	[ExecutionID] INT NULL,
    [DateAsInt]            CHAR(8)             DEFAULT (Convert(CHAR(8),GETDATE(),112)),
	ValidFrom	datetime2 (7) NOT NULL ,
	ValidTo		datetime2 (7) NOT NULL
	--[Forecast_BudgetRunType] [varchar](20) NULL,
	--[FileName] [varchar](355) NULL
);
