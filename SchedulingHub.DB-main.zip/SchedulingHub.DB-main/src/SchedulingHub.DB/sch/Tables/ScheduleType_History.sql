﻿CREATE TABLE [sch].[ScheduleType_History](
	[PK_SchID] [int]  NOT NULL,
	[SchRunType] [varchar](255) NULL,
	[WorkingDay] [varchar](10) NULL,
	[IsEnabled] [bit] NOT NULL,
	[IsUserInitiated] [bit] NOT NULL,
	[AuditUserTriggered] [varchar](100) NULL,
	[AuditUserEmail] [varchar](100) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getdate()),
	[AuditModifyDateTime] [datetime] NULL DEFAULT (getdate()),
	[AuditHost] [varchar](255) NOT NULL DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))),
	[Description] [varchar](255) NULL,
	[ValidFrom] [datetime2](7) NOT NULL,
	[ValidTo] [datetime2](7) NOT NULL
	)