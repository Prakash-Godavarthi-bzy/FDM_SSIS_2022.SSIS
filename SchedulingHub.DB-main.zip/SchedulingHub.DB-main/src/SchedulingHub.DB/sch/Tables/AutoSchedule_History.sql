﻿CREATE TABLE [sch].[AutoSchedule_History](
	[PK_AutoSchID] [int] NOT NULL,
	[FK_SchID] [int] NOT NULL,
	[FK_ConfigID] [int] NOT NULL,
	[Dataset] [varchar](255) NOT NULL,
	[SchRunType] [varchar](255) NULL,
	[WorkingDay] [varchar](10) NULL,
	[IsEnabled] [int] NOT NULL,
	[AuditUserModified] [varchar](100) NOT NULL  DEFAULT (suser_sname()),
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getdate()),
	[AuditModifyDateTime] [datetime] NOT NULL DEFAULT (getdate()),
	[AuditHost] [varchar](255) NOT NULL DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))),
	[Description] [varchar](255) NULL,
	[ValidFrom] [datetime2](7)  NOT NULL,
	[ValidTo] [datetime2](7)  NOT NULL
	)