﻿CREATE VIEW SCH.[VW_GetMaxRunIDforSuccess]
AS
SELECT	 PKSCID,[Status],ToAccountingPeriod,FromAccountingPeriod
FROM		sch.Orchestrationrunner
WHERE		PKSCID IN(
			SELECT        MAX(PKSCID) AS MaxPKID
			FROM            sch.Orchestrationrunner
			where		 Status IN ('Successful')
)