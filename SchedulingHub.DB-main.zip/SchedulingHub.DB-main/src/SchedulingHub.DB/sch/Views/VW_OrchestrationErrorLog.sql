﻿
CREATE VIEW [sch].[VW_OrchestrationErrorLog]
as

SELECT DISTINCT orr.PKSCID,
ma.FK_Orchestration,
m.ModuleName,
ma.FK_Module,
CASE WHEN M.ModuleName LIKE '%Psicle%' then COALESCE(corr.Psicle_Message,MA.RunDescription) WHEN M.ModuleName NOT LIKE '%Psicle%' THEN MA.RunDescription ELSE NULL END ErrorMessage,
MA.ExecutionID,
MA.ActivityStart
FROM (
SELECT
[FK_Orchestration]
,[FK_Module]
,[FK_ModuleStatus]
,[RunDescription]
,[ActivityStart]
,[ActivityEnd]
,[ExecutionID]
,[ModuleExecutionID]
FROM [etl].[ModuleActivity]
UNION
SELECT
[FK_Orchestration]
,[FK_Module]
,[FK_ModuleStatus]
,[RunDescription]
,[ActivityStart]
,[ActivityEnd]
,[ExecutionID]
,[ModuleExecutionID]
FROM [etl].[ModuleActivity_History]
) ma
JOIN sch.Orchestrationrunner orr
on orr.PK_Orchestration = ma.FK_Orchestration and orr.ExecutionID = ma.ExecutionID
JOIN etl.Module m
ON ma.FK_Orchestration = m.FK_Orchestration and
ma.FK_Module = m.PK_module
JOIN sch.Child_Orchestrationrunner CORR
ON CORR.PKSCID = ORR.PKSCID
WHERE ma.FK_ModuleStatus IN (3) AND M.FK_Orchestration = 11 AND CORR.[status] NOT LIKE '%success%'
ORDER BY MA.ExecutionID
OFFSET 0 ROWS
