﻿
CREATE view [sch].[VW_OrchestrationRunner] As
select orr.PKSCID
	  ,orr.PK_Orchestration
	  ,orr.[UserName]
      ,orr.[UserEmail]
      ,orr.[FromAccountingPeriod]
      ,orr.[ToAccountingPeriod]
	  ,orr.Auditinserttime
	  ,orr.AuditUserCreate
	  ,orr.ExecutionID
	  ,orr.DateAsInt
      ,orr.[Status]
	  ,o.OrchestrationName 
	  ,case when orr.Status = 'Failed' then 'View Issues'
	        else '' 
	   end [Failure Reasons]
from sch.Orchestrationrunner as orr
inner join etl.Orchestration as o
on o.PK_Orchestration = orr.PK_Orchestration