﻿CREATE PROC [sch].[USP_Child_Orchestrationrunner]
AS
BEGIN
		DECLARE @FromAcc int,@ToAcc int,@ID int
		SELECT	@FromAcc= FromAccountingPeriod,@ToAcc=ToAccountingPeriod,@ID = PKSCID
		FROM	sch.Orchestrationrunner
		WHERE	PKSCID IN (SELECT MIN(PKSCID) FROM sch.Orchestrationrunner WHERE Status = 'Running')
	
		INSERT INTO [SchedulingHub].[sch].[Child_Orchestrationrunner]([PKSCID],[acc_from],[acc_To])
		SELECT	@ID,BK_AccountingPeriod,BK_AccountingPeriod
		FROM	TechnicalHub.dim.AccountingPeriod
		WHERE	BK_AccountingPeriod between @FromAcc and @ToAcc and right(BK_AccountingPeriod,2) not in (00,13)
END