﻿
CREATE PROCEDURE sch.USP_CreateOrchestrationActivity(@FK_Orchestration INT)
AS
BEGIN
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID)
	DECLARE @Logging log.utt_ActivityLog
	INSERT @Logging(ActivityStatus) SELECT 1

	BEGIN TRY
		IF @FK_Orchestration IS NULL
			RAISERROR('FK_Orchestration is a required field', 16, 0)

		INSERT	etl.OrchestrationActivity(FK_Orchestration)
		SELECT	@FK_Orchestration

		INSERT @Logging(ActivityStatus, ActivityMessage) SELECT 5, 'Orchestration Activity'

		SELECT	SCOPE_IDENTITY()
		
		INSERT @Logging(ActivityStatus) SELECT 2 
		--Generate logging for success
		EXEC log.usp_LogSchedulingHub  @Input = @Logging
	END TRY
	BEGIN CATCH
	--Generate logging for error (outside tran)
		INSERT @Logging(ActivityStatus, ActivityMessage) SELECT 4, ERROR_MESSAGE()
		EXEC log.usp_LogSchedulingHub  @Input = @Logging;
		THROW;
	END CATCH

END
GO
EXECUTE sp_addextendedproperty @name = N'Stored Procedure Parameters', @value = N'INput:

					@FK_Orchestration – INT – NOT NULL:
					This pram stores unique ID (PK_Orchestration value) of the activity recorded in the Orchestration table.', @level0type = N'SCHEMA', @level0name = N'sch', @level1type = N'PROCEDURE', @level1name = N'USP_CreateOrchestrationActivity';


GO
EXECUTE sp_addextendedproperty @name = N'Stored Procedure Definition', @value = N'The procedure can be used  to insert FK_Orchestration in etl.OrchestrationActivity table.', @level0type = N'SCHEMA', @level0name = N'sch', @level1type = N'PROCEDURE', @level1name = N'USP_CreateOrchestrationActivity';

