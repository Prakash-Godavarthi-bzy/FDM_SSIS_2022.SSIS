﻿
CREATE PROCEDURE sch.USP_CreateAuthorisation(@FK_ModuleActivity INT, @FK_AuthorisationStatus INT, @Submit INT)
AS
BEGIN
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID)
	DECLARE @Logging log.utt_ActivityLog
	INSERT @Logging(ActivityStatus) SELECT 1

	BEGIN TRY
		IF (@Submit<>0)
		BEGIN
			--Create the authorisation
			INSERT	etl.Authorisation(FK_ModuleActivity, FK_AuthorisationStatus)
			VALUES	(@FK_ModuleActivity, @FK_AuthorisationStatus)

			--Set the activity to the relevant status
			UPDATE	etl.ModuleActivity
			SET		FK_ModuleStatus = (SELECT DefaultModuleStatus FROM etl.AuthorisationStatus WHERE PK_AuthorisationStatus = @FK_AuthorisationStatus)
			WHERE	PK_ModuleActivity = @FK_ModuleActivity
		 INSERT @Logging(ActivityStatus, ActivityMessage) SELECT 5, 'Create Authorisation'
		END
		
		--Return the latest auth info for the given activity
		SELECT	a.FK_ModuleActivity,
				st.PK_AuthorisationStatus
		FROM	etl.Authorisation a
		JOIN	etl.AuthorisationStatus st on a.FK_AuthorisationStatus = st.PK_AuthorisationStatus
		JOIN	(
					SELECT	MAX(PK_Authorisation) AS PK_Authorisation,
							a.FK_ModuleActivity
					FROM	etl.Authorisation a
					WHERE	FK_ModuleActivity = @FK_ModuleActivity
					GROUP BY a.FK_ModuleActivity
				) ma ON ma.PK_Authorisation = a.PK_Authorisation

		INSERT @Logging(ActivityStatus, ActivityMessage) SELECT 5, 'Return Latest Authorisation Info'
		
		INSERT @Logging(ActivityStatus) SELECT 2 
		
		--Generate logging for success
		EXEC log.usp_LogSchedulingHub  @Input = @Logging 
	END TRY

	
	BEGIN CATCH
	--Generate logging for error 
		INSERT @Logging(ActivityStatus, ActivityMessage) SELECT 4, ERROR_MESSAGE()
		EXEC log.usp_LogSchedulingHub  @Input = @Logging;
		THROW;
	END CATCH
END
GO
EXECUTE sp_addextendedproperty @name = N'Stored Procedure Parameters', @value = N'INput:

					@FK_ModuleActivity – INT – NOT NULL:
					This pram stores unique ID (PK_ModuleActivity value) of the activity recorded in the ModuleActivity table.

					Input:

					@FK_AuthorisationStatus - INT - NULL:
					This pram stores unique ID (PK_AuthorisationStatus  value) of the status recorded in the AuthorisationStatus  table..

					@Submit – INT - NULL:
					 This pram  takes Integer value  if the value is not zero then create authorisation.', @level0type = N'SCHEMA', @level0name = N'sch', @level1type = N'PROCEDURE', @level1name = N'USP_CreateAuthorisation';


GO
EXECUTE sp_addextendedproperty @name = N'Stored Procedure Definition', @value = N'The procedure can be used to create Authoriasation for Module in etl.Authorisation table.

					       When a new Authorisation is created then it updates FK_ModuleStatus in ModuleActivity table.', @level0type = N'SCHEMA', @level0name = N'sch', @level1type = N'PROCEDURE', @level1name = N'USP_CreateAuthorisation';

