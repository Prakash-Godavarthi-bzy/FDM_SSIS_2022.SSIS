CREATE PROCEDURE [sch].[USP_CleanupScripts] @DataSet VARCHAR(50) = NULL
AS
BEGIN
	DECLARE @p_C_Dataset VARCHAR(50)

	--,@p_C_Extensions VARCHAR(50) --Uncomment these Incase you want to delete extensions in future
	SET @p_C_Dataset = @Dataset

	/* --Uncomment these Incase you want to delete extensions in future
	SELECT @p_C_Extensions=Extension 
	FROM sch.DataSetConfigModules
	Where Dataset=@p_C_Dataset
  */
	IF EXISTS (
			SELECT *
			FROM FinanceDataContract.Inbound.BatchQueue
			WHERE DataSet = @p_C_Dataset
			)
	BEGIN
		/* --UnComment these incase you need to delete the ActivityLog in future
		DELETE
		FROM Orchestram.log.ActivityLog
		WHERE ActivityJobId IN (
				SELECT CAST(PK_Batch AS VARCHAR(20))
				FROM FinanceDataContract.Inbound.BatchQueue
				WHERE DataSet = @p_C_Dataset --For all datasets
				)
		*/

		DELETE
		FROM FinanceLanding.dbo.Batch
		WHERE DataSet = @p_C_Dataset --For all Datasets
	END

	/*
 --UnComment the below code incase you want to delete extensions in future.
 
 IF(@p_C_Extensions='Premium')

 BEGIN

/*--------------------------------------*Premium_Extensions*----------------------*/
         DELETE ex
         from FinanceDataContract.Outbound.[Transaction] t
         INNER JOIN FinanceDataContract.Outbound.Premium_Extensions_Bridge rb on t.RowHash = rb.RowHash_Transaction
         INNER JOIN FinanceDataContract.Outbound.Premium_Extensions ex on rb.RowHash_Transaction_Premium_Extensions =
         ex.RowHash_Transaction_Premium_Extensions
         WHERE t.Dataset = @p_C_Dataset --For Eurobase , BIDAC datasets

-------------------------------------*Premium_Extensions_Bridge*---------------------------                   
         DELETE rb
         FROM FinanceDataContract.Outbound.[Transaction] t
         INNER JOIN FinanceDataContract.Outbound.Premium_Extensions_Bridge rb on t.RowHash = rb.RowHash_Transaction
         WHERE t.Dataset = @p_C_Dataset -- For Eurobase , BIDAC datasets

 END

 IF(@p_C_Extensions='Agresso')

 BEGIN

/*-----------------------------------*Transaction_AgressoAR_Extensions*-------------------------------*/
         DELETE aex
         FROM FinanceDataContract.Outbound.[Transaction] t
         INNER JOIN FinanceDataContract.Outbound.Transaction_AgressoAR_Extensions_Bridge rb on t.RowHash = rb.RowHash_Transaction
         INNER JOIN FinanceDataContract.Outbound.Transaction_AgressoAR_Extensions aex on rb.RowHash_Transaction_AgressoAR_Extensions =
         aex.RowHash_Transaction_AgressoAR_Extensions
         WHERE t.Dataset = @p_C_Dataset --For AgressoARBIDAC , AgressoARUS datasets

-------------------------------------Transaction_AgressoAR_Extensions_Bridge--------------------------------
         DELETE aexb
         FROM FinanceDataContract.Outbound.[Transaction] t
         INNER JOIN FinanceDataContract.Outbound.Transaction_AgressoAR_Extensions_Bridge aexb on t.RowHash = aexb.RowHash_Transaction
         WHERE t.Dataset = @p_C_Dataset --For AgressoARBIDAC , AgressoARUS datasets

 END

 IF(@p_C_Extensions='Claim')

 BEGIN

/*---------------------------------Transaction_Claim_Extensions-------------------------------------*/
         DELETE cex
         FROM FinanceDataContract.Outbound.[Transaction] t
         INNER JOIN FinanceDataContract.Outbound.Transaction_Claim_Extensions_Bridge rb on t.RowHash = rb.RowHash_Transaction
         INNER JOIN FinanceDataContract.Outbound.Transaction_Claim_Extensions cex on rb.RowHash_Transaction_Claim_Extensions =
         cex.RowHash_Transaction_Claim_Extensions
         WHERE t.Dataset = @p_C_Dataset --For Claims_BI_ODS dataset

------------------------------Transaction_Claim_Extensions_Bridge-----------------------------------
         DELETE cexb
         FROM FinanceDataContract.Outbound.[Transaction] t
         INNER JOIN FinanceDataContract.Outbound.Transaction_Claim_Extensions_Bridge cexb on t.RowHash = cexb.RowHash_Transaction
         WHERE t.Dataset = @p_C_Dataset --For Claims_BI_ODS dataset

 END

 IF(@p_C_Extensions='ReservingReinsurance')

 BEGIN
/*-------------------------Transaction_Reserving_ReInsurance_Extensions----------------------------------*/
          DELETE rrex
          FROM FinanceDataContract.Outbound.[Transaction] t
          INNER JOIN FinanceDataContract.Outbound.Transaction_Reserving_ReInsurance_Extensions_Bridge rb on t.RowHash = rb.RowHash_Transaction
          INNER JOIN FinanceDataContract.Outbound.Transaction_Reserving_ReInsurance_Extensions rrex on rb.RowHash_Transaction_Reserving_ReInsurance_Extensions =
          rrex.RowHash_Transaction_Reserving_ReInsurance_Extensions
          WHERE t.Dataset = @p_C_Dataset --For ResDataEventAlloc , ReservingData , RIPsEventAlloc Datasets

/*------------------------Transaction_Reserving_ReInsurance_Extensions_Bridge---------------------------------------*/                   
          DELETE rrexb
          FROM FinanceDataContract.Outbound.[Transaction] t
          INNER JOIN FinanceDataContract.Outbound.Transaction_Reserving_ReInsurance_Extensions_Bridge rrexb on t.RowHash = rrexb.RowHash_Transaction
          WHERE t.Dataset = @p_C_Dataset --For ResDataEventAlloc , ReservingData , RIPsEventAlloc Datasets

 END

 IF(@p_C_Extensions='Reinsurance')

 BEGIN
 /*-----------------------------Transaction_ReInsurance_Extensions-----------------------------------------*/
         DELETE rex
         from FinanceDataContract.Outbound.[Transaction] t
         INNER JOIN FinanceDataContract.Outbound.Transaction_ReInsurance_Extensions_Bridge rb on t.RowHash = rb.RowHash_Transaction
         INNER JOIN FinanceDataContract.Outbound.Transaction_ReInsurance_Extensions rex on rb.RowHash_Transaction_ReInsurance_Extensions =
         rex.RowHash_Transaction_ReInsurance_Extensions
         WHERE t.Dataset = @p_C_Dataset --For ReinsuranceRebates_Paid , Reinsurance_Overriding_Commission , BICI_RI_Ultimate_Premium , BICI_RI_Paid , ObligatedPremium_Munich_QQS , ResDataRILargeLossAlloc , BusinessPlanRI , Earned_RIP_RISpend
							--,Ceded_Re_ORC , BICI_Earned_Agresso , ObligatedPremium_SPA , Ceded_Re_Claims_Incurred , ReinsuranceRebates_Ultimate , BICI_RI_Incurred , Expenses Actual , Signed Profit Commission
							--,RI_SpecialArrangements , ObligatedPremium_RISpend , ResDataRIAttClmAlloc , RI LPSO FAC , ReservingDataPremiumAlloc , BICI RI Ultimate Claim , Ultimate Profit Commission , EPI Reinstatement Eurobase
							--,Ceded_Re_Closed_YOA , RI LPSO TTY datasets

--------------------------------Transaction_ReInsurance_Extensions_Bridge-------------------------------                 
         DELETE rexb
         from FinanceDataContract.Outbound.[Transaction] t
         INNER JOIN FinanceDataContract.Outbound.Transaction_ReInsurance_Extensions_Bridge rexb on t.RowHash = rexb.RowHash_Transaction
         WHERE t.Dataset = @DataSet --For ReinsuranceRebates_Paid , Reinsurance_Overriding_Commission , BICI_RI_Ultimate_Premium , BICI_RI_Paid , ObligatedPremium_Munich_QQS , ResDataRILargeLossAlloc , BusinessPlanRI , Earned_RIP_RISpend
							--,Ceded_Re_ORC , BICI_Earned_Agresso , ObligatedPremium_SPA , Ceded_Re_Claims_Incurred , ReinsuranceRebates_Ultimate , BICI_RI_Incurred , Expenses Actual , Signed Profit Commission
							--,RI_SpecialArrangements , ObligatedPremium_RISpend , ResDataRIAttClmAlloc , RI LPSO FAC , ReservingDataPremiumAlloc , BICI RI Ultimate Claim , Ultimate Profit Commission , EPI Reinstatement Eurobase
							--,Ceded_Re_Closed_YOA , RI LPSO TTY datasets

 END
 
 */
	-----------------------------------------------------------------FinanceDataContract Delete (BOX-3)  For all datasets except ADM-DFMs , NatCatEarning Datasets------------------------------------------------------------------------------
	IF (
			@p_c_Dataset NOT IN (
				'ADM-DFMs'
				,'NatCatEarning'
				)
			)
	BEGIN
		SET NOCOUNT ON;

		DECLARE @Box3 INT;

		SET @Box3 = 1;

		WHILE @Box3 > 0
		BEGIN
			DELETE TOP (500000) ot
			FROM FinanceDataContract.Outbound.[Transaction] ot
			WHERE DataSet = @p_C_Dataset

			SET @Box3 = @@ROWCOUNT;
		END
	END

	-------------------------------------------------------------------FinanceDataContract Delete (BOX-3)  For only  ADM-DFMs , NatCatEarning Datasets-----------------------------------------------------------
	IF (
			@p_c_Dataset IN (
				'ADM-DFMs'
				,'NatCatEarning'
				)
			)
	BEGIN
		DELETE
		FROM FinanceDataContract.Outbound.Pattern
		WHERE DataSet = @p_C_Dataset -- For only ADM-DFMs , NatCatEarning Datasets
	END

	-----------------------------------------------------------------------TechnicalHub Delete(Box-4) For all datasets except ADM-DFMs , NatCatEarning Datasets----------------------------------------------------
	IF (
			@p_c_Dataset NOT IN (
				'ADM-DFMs'
				,'NatCatEarning'
				)
			)
	BEGIN
		SET NOCOUNT ON;

		DECLARE @Box4 INT;

		SET @Box4 = 1;

		WHILE @Box4 > 0
		BEGIN
			DELETE TOP (500000) TR
			FROM TechnicalHub.fct.TechnicalResult TR
			JOIN TechnicalHub.dim.DataSet DS ON DS.PK_DataSet = TR.FK_DataSet
			WHERE DS.BK_DataSet = @p_C_Dataset

			SET @Box4 = @@ROWCOUNT;
		END
	END

	----------------------------------------------------------TechnicalHub Delete(Box-4)  For only  ADM-DFMs , NatCatEarning Datasets--------------------------------------
	IF (
			@p_c_Dataset IN (
				'ADM-DFMs'
				,'NatCatEarning'
				)
			)
	BEGIN
		DELETE P
		FROM TechnicalHub.fct.Pattern P
		JOIN TechnicalHub.dim.DataSet DS ON DS.PK_DataSet = P.FK_DataSet
		WHERE DS.BK_DataSet = @p_C_Dataset
	END

	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	IF EXISTS (
			SELECT *
			FROM FinanceDataContract.Inbound.BatchQueue
			WHERE DataSet = @p_C_Dataset
			)
	BEGIN
		DELETE
		FROM FinanceDataContract.Inbound.BatchQueue
		WHERE DataSet = @p_C_Dataset -- For all Datasets
	END
END
