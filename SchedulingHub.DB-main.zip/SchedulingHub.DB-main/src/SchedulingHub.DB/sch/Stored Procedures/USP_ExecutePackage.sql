﻿CREATE PROCEDURE	[sch].[USP_ExecutePackage] (@PackageName NVARCHAR(255), @PackageLocation NVARCHAR(255), @ProjectName NVARCHAR(255), @EnvironmentName VARCHAR(255) = NULL, @Parameters XML = NULL, @ExcelImport BIT = 0, @ExecutionID INT OUTPUT)
AS
BEGIN
		
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID)
	DECLARE @Logging log.utt_ActivityLog
	INSERT @Logging(ActivityStatus,ActivityMessage) SELECT 1,'USP_ExecutePackage Has Started'

	DECLARE @execution_id BIGINT
	DECLARE @ID INT = 0, @ParameterKey VARCHAR(255), @ParameterValue VARCHAR(MAX), @parameterType VARCHAR(255), @ParameterValueVariant SQL_VARIANT
	DECLARE @ErrorMessage VARCHAR(MAX), @SQL NVARCHAR(MAX) = ''
	DECLARE @Reference_ID INT = (SELECT reference_id FROM SSISDB.catalog.environment_references WHERE environment_name = @EnvironmentName)
	
	INSERT @Logging(ActivityStatus, ActivityMessage) SELECT 5, 'Parameter are created'

	IF @EnvironmentName IS NOT NULL AND @Reference_ID IS NULL 
	BEGIN
		RAISERROR('@Reference_ID is null!!!', 16, 0)
		
		INSERT @Logging(ActivityStatus, ActivityMessage) SELECT 4, ERROR_MESSAGE()
		EXEC log.usp_LogSchedulingHub  @Input = @Logging;

		RETURN
	END
	/*=======================================================================================================
	Deserialise parameters
	=======================================================================================================*/
	PRINT 'params'
	DECLARE @ParametersTable TABLE
	(
		[ID] [bigint] IDENTITY(1, 1),
		[ParameterKey] [varchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[ParameterType] [varchar](255) NULL,
		[ParameterValue] SQL_VARIANT NULL
	) 

	DECLARE @docHandle INT;
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @Parameters;  

	INSERT @Logging(ActivityStatus, ActivityMessage) SELECT 5, 'Deserialise parameters'

	-- Use OPENXML to provide rowset consisting of customer data. 
	INSERT	@ParametersTable 
	SELECT	*   
	FROM	OPENXML(@docHandle, N'/ROOT/Parameter')   
	WITH	(	ParameterKey varchar(255),
				ParameterType varchar(255),
				ParameterValue SQL_VARIANT)

	-- Remove the internal representation of the XML document.  
	EXEC	sp_xml_removedocument @docHandle;

	INSERT @Logging(ActivityStatus, ActivityMessage) SELECT 5, 'Remove the internal representation of the XML document'

	/*=======================================================================================================
	Execute SISS package
	=======================================================================================================*/
	EXEC	SSISDB.catalog.create_execution		@execution_id=@execution_id OUTPUT,
												@package_name=@PackageName,
												@folder_name=@PackageLocation,
												@project_name=@ProjectName,
												@use32bitruntime=@ExcelImport,
												@reference_id=@Reference_ID
	--Return ExecutionID to caller
	SET @ExecutionID = @execution_id
		
	INSERT @Logging(ActivityStatus, ActivityMessage) SELECT 5, 'Execute SSIS Package'
 
	--Assign values to package params
	WHILE EXISTS (
					SELECT	*
					FROM	(SELECT	DISTINCT parameter_name, object_name FROM	ssisdb.internal.object_parameters) op
					JOIN	@ParametersTable p ON p.ParameterKey = op.parameter_name
					WHERE	op.object_name = @PackageName
						AND p.ID > @ID
				)
	BEGIN
		SELECT	TOP 1
				@ID = p.ID,
				@ParameterKey = p.ParameterKey,
				@ParameterValue = CAST(p.ParameterValue AS VARCHAR(MAX)),
				@parameterType = p.ParameterType
		FROM	(SELECT	DISTINCT parameter_name, object_name FROM	ssisdb.internal.object_parameters) op
		JOIN	@ParametersTable p	ON	p.ParameterKey = op.parameter_name 
		WHERE	op.object_name = @PackageName
			AND p.ID > @ID
		ORDER BY ID
			
		INSERT @Logging(ActivityStatus, ActivityMessage) SELECT 5, 'Assign values to package Params'


		RAISERROR('%s:%s', 0, 0, @ParameterKey, @ParameterValue)

		--Re cast the parameter to it's base type then back to SQL variant (XML turns everything to a varchar)
		SET		@SQL = REPLACE(REPLACE('SET @ParameterValueVariant = CAST(CAST(''[@ParameterValue]'' AS [@parameterType]) AS SQL_VARIANT)', '[@parameterType]', @parameterType), '[@ParameterValue]', @ParameterValue)
		PRINT @SQL
		EXECUTE sp_executesql	@SQL, N'@ParameterValueVariant SQL_VARIANT OUTPUT', @ParameterValueVariant=@ParameterValueVariant OUTPUT;  
		
		EXEC SSISDB.catalog.set_execution_parameter_value		@execution_id = @execution_id, 
																@object_type=30,
																@parameter_name=@ParameterKey,
																@parameter_value=@ParameterValueVariant

		INSERT @Logging(ActivityStatus, ActivityMessage) SELECT 5, 'Re cast the Package Parameters'

	END

	--Kick off package and wait to complete
	EXEC	[SSISDB].[catalog].[start_execution] @execution_id
			
	INSERT @Logging(ActivityStatus, ActivityMessage) SELECT 5, 'Package execution has started and waiting to complete'

	WHILE EXISTS	(
						SELECT [Status] FROM [SSISDB].[catalog].[executions]
						WHERE execution_id = @execution_id
						AND [status] in (1,2,5)
					)
	WAITFOR DELAY '00:00:05'; 

	--Dig out any errors and chuck up the stack
	IF EXISTS (SELECT * FROM SSISDB.catalog.executions WHERE execution_id = @execution_id AND status IN (3, 4, 6, 8))
	BEGIN
		SELECT	@ErrorMessage = 
		CAST(	
				(
					SELECT	Message AS "@Message"
					FROM	SSISDB.internal.operation_messages
					WHERE	Message_type = 120
						AND operation_id = @execution_id
					FOR		XML PATH ('Messages')
				) AS VARCHAR(MAX)
			)	

		RAISERROR (@ErrorMessage, 16, 0)

		END

	
	RETURN @execution_id

	INSERT @Logging(ActivityStatus, ActivityMessage) SELECT 2, 'ExecutePackage Suceeded'
	EXEC log.usp_LogSchedulingHub  @Input = @Logging
END