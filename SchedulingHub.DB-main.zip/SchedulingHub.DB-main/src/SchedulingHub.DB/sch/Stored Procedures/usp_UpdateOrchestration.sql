﻿CREATE PROCEDURE [sch].[USP_UpdateOrchestration]
AS
BEGIN
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID)
	DECLARE @Logging log.utt_ActivityLog
	INSERT @Logging(ActivityStatus) SELECT 1
	DECLARE @SLOrchestrationName AS VARCHAR(255)
	DECLARE @OrchestrationToEnable AS VARCHAR(255)
	DECLARE @OrchestrationName AS VARCHAR(255)
	DECLARE @IsEnabled AS BIT
	DECLARE @FreezeFromDate as DATE
	
	 

	BEGIN TRY
		
		-- Mark Baekdal, 08/06/2020 - had conversation with <> and was told the freeze functionality wasn't required.
		-- For now freeze functionality isn't required, so i'm disabling all this code.

		declare @placeholder int=0 -- remove this and un-comment all the code until the end try to enable the code

		--SELECT 	@SLOrchestrationName=OrchestrationName,	@IsEnabled=IsEnabled,	@FreezeFromDate=FreezeFromDate, 	@OrchestrationToEnable = OrchestrationToEnable
		--FROM	etl.OrchestrationSharepoint

		---- for IFRS17, we can ignore the freeze functionality. For now.

		--SELECT	@OrchestrationName = OrchestrationName
		--FROM	ETL.Orchestration
		--WHERE	IsEnabled = 1
		--	and OrchestrationName != 'IFRS17'

		--IF @FreezeFromDate IS NULL OR @FreezeFromDate>getDate()
		--BEGIN
		--		UPDATE	ETL.Orchestration
		--		SET		IsEnabled  =0
		--		WHERE	OrchestrationName != 'IFRS17'

		--		UPDATE	ETL.Orchestration
		--		SET		IsEnabled  =1
		--		WHERE	OrchestrationName=@SLOrchestrationName 

		--END
		--ELSE IF @FreezeFromDate <=getDate()
		--BEGIN
		--		UPDATE	ETL.Orchestration
		--		SET		IsEnabled  =0
		--		WHERE	OrchestrationName != 'IFRS17'

		--		UPDATE	ETL.Orchestration
		--		SET		IsEnabled  =1
		--		WHERE	OrchestrationName=@OrchestrationToEnable
		--END


		--INSERT @Logging(ActivityStatus, ActivityMessage) SELECT 5, 'Updated active orchestration'
		
		--INSERT @Logging(ActivityStatus) SELECT 2 
		
		----Generate logging for success
		--EXEC log.usp_LogSchedulingHub  @Input = @Logging 
	END TRY
	
	BEGIN CATCH
	--Generate logging for error 
		INSERT @Logging(ActivityStatus, ActivityMessage) SELECT 4, ERROR_MESSAGE()
		EXEC log.usp_LogSchedulingHub  @Input = @Logging;
		THROW;
	END CATCH
END