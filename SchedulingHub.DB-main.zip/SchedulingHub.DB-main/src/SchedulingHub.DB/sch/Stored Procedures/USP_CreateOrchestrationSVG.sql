﻿CREATE PROC sch.[USP_CreateOrchestrationSVG]
 @Orchestration int
AS 

DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID)
DECLARE @Logging log.utt_ActivityLog

INSERT @Logging(ActivityStatus) SELECT 1
/**
	# =============================================
	Author:          <Author,,Syed Masoom>
	Create date:     <Created On 16/04/2018>
	Description:     <This code take Orchesteration number is input varialable genrate svg file as output for all modules and links between modules ,>
	Input variable   <Orchestration >
	Output            <Svg File Code for all modules and links beteen module>
	# =============================================
	**/

/* set orchestraction */

set @Orchestration=2;
------
IF OBJECT_ID('tempdb..#formt') IS NOT NULL
BEGIN
DROP TABLE #formt
END
IF OBJECT_ID('tempdb..#Temp') IS NOT NULL
BEGIN
DROP TABLE #Temp
END;
create table #formt (id  int, sv varchar(max));
/* select modules for given Orchestration */
with cte
as 
(
  select distinct 
  [FK_ChildModule] as module
  ,  [TreeLevel] as [Level] 
  from [LKScratchpad].[etl].[ModuleHierarchy]
  where [FK_Orchestration]=@Orchestration

  )
  /* calculates the points for boxes*/
  ,cte2 as
  (
  select [level],
  
    count(*) over(partition by [level]) [Cnt PB Level]
  , ROW_NUMBER()over(partition by [level] order by module asc )  [RWN PB level]
  ,module
   from cte) 
      select 	*,  (3000/([Cnt PB Level]+1)*[RWN PB level])-700 AS A
	  ,10+(([Level]-1)*400) AS B
	  ,((3000/([Cnt PB Level]+1)*[RWN PB level])-700)+250 AS C
	  ,10+(([Level]-1)*400)+200 D
	   INTO #Temp
  FROM cte2 ;
  /*identify parent modules for boxes*/
   WITH  CTE_P
  AS(
  SELECT DISTINCT  FK_ParentModule AS Pmodule,FK_ChildModule  ,A AS PA, B AS PB, C AS PC, D AS PD  FROM #Temp 
  INNER JOIN  [LKScratchpad].[etl].[ModuleHierarchy] H   ON H.[FK_ParentModule]  =#Temp.module AND FK_Orchestration=4
  )
  INSERT INTO #formt
 /* Formating the SVG file for output*/

 /* create links between modules*/
  SELECT  module+1.5,
CASE WHEN A<PA  and B-A<PA-A
Then 
--'LEFT' (

 '<polygon id="'+convert (varchar,module ) +'.1" title="line '+ convert (varchar,module ) +
  '.1" points="'+convert (varchar, (PC+PA)/2)+','+convert (varchar, (PD+PD)/2)+' '+convert (varchar, (PC+PA)/2+10)+','+convert (varchar, (PD+PD)/2)+' '+convert (varchar, (C+C)/2)+','+convert (varchar, (B+D)/2+10)+' '+convert (varchar, (C+C)/2)+','+convert (varchar, (B+D)/2)+'"/>' 

when A>PA and B-A>PA-A
then
--'Right'
 '<polygon id="'+convert (varchar,module ) +'.1" title="line '+ convert (varchar,module ) +
  '.1" points="'+convert (varchar, (PC+PA)/2)+','+convert (varchar, (PD+PD)/2)+' '+convert (varchar, (PC+PA)/2+10)+','+convert (varchar, (PD+PD)/2)+' '+convert (varchar,(A+A)/2)+','+convert (varchar, (B+D)/2+10)+' '+convert (varchar,(A+A)/2)+','+convert (varchar, (B+D)/2)+'"/>' 
else 
---'Below'
 '<polygon id="'+convert (varchar,module ) +'.1" title="line '+ convert (varchar,module ) +
  '.1" points="'+convert (varchar,(PC+PA)/2)+','+convert (varchar, (PD+PD)/2)+' '+convert (varchar, (PC+PA)/2+10)+','+convert (varchar, (PD+PD)/2)+' '+convert (varchar,(A+C)/2)+','+convert (varchar,(B+B)/2+10)+' '+convert (varchar,(A+C)/2)+','+convert (varchar,(B+B)/2)+'"/>' 
End as SVG

FROM CTE_P
INNER JOIN #Temp ON #Temp.module  = CTE_P.FK_ChildModule
/*genrate code for Modules diagram*/
union 
 SELECT 1, '<svg version="1.1" id="Map" class="gen-by-synoptic-designer" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1838 2513" fill="none" stroke="#00aaff" stroke-width="6" xml:space="preserve">200'
  UNION
  SELECT module+1, '<polygon id="'+convert (varchar,module ) +'" title="Step '+ convert (varchar,module ) +
  '" points="'+convert (varchar,A)+','+convert (varchar,B)+' '+convert (varchar,C)+','+convert (varchar,B)+' '+convert (varchar,C)+','+convert (varchar,D)+' '+convert (varchar,A)+','+convert (varchar,D)+'"/>' 

  FROM  #Temp 
 UNION 
 SELECT   2000,  '</svg>'
 select SV from #formt order by id

INSERT @Logging(ActivityStatus) SELECT 2 
		
		--Generate logging for success
		EXEC log.usp_LogSchedulingHub  @Input = @Logging