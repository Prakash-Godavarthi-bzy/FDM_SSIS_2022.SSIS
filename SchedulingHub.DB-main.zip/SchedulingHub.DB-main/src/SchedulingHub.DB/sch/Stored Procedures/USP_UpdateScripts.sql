﻿CREATE PROCEDURE [sch].[USP_UpdateScripts]  
@p_ConfigID int = NULL,
@p_Dataset  varchar(50)=NULL

AS

BEGIN

DECLARE 
@p_L_ConfigId int
,@p_L_Dataset  varchar(50)

SET @p_L_ConfigId=@p_ConfigID
SET @p_L_Dataset=@p_Dataset

if object_id('tempdb..#modules') is not null drop table #modules

SELECT  M.Module
Into    #modules
FROM    sch.DataSetConfig D
join    sch.DataSetConfigModules M on D.PK_ConfigID=M.FK_ConfigID
where   PK_ConfigID=@p_L_ConfigId 
        and D.Dataset=@p_L_Dataset

UPDATE etl.Orchestration
SET IsEnabled=0

UPDATE etl.Orchestration
SET IsEnabled=1
WHERE PK_Orchestration=15

UPDATE etl.ModuleActivity
SET FK_ModuleStatus=4
WHERE FK_Orchestration=15 AND FK_Module not in (select Module from #modules)

UPDATE etl.ModuleActivity
SET FK_ModuleStatus=1
WHERE FK_Orchestration=15 AND FK_Module in (Select Module from #modules) 


END
