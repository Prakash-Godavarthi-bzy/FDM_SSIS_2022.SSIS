﻿
/*====================================================================================================
Is:			etl.CreateModuleActivity
Does:		Sets what modules are set to run. Can take a manual dataset as input for override/initialisation 
			or applies default logic to decide if status needs to change after an orchestration has run
Parameters:	@Input etl.utt_CreateModuleActivity (Table)
			(
				FK_Orchestration INT NOT NULL,			Reference to module
				FK_Module INT NOT NULL,					Reference to module
				FK_ModuleStatus INT NOT NULL,			New status to apply
				NotificationPending BIT,				Set to re-send notifications if required
				RunDescription VARCHAR(255)	NOT NULL	Justification for running an override
			)
====================================================================================================*/
CREATE PROCEDURE [sch].[USP_CreateModuleActivity](@Input etl.utt_CreateModuleActivity READONLY)
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	DECLARE @p_ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID)
	DECLARE @Logging log.utt_ActivityLog

	INSERT @Logging(ActivityStatus) SELECT 1

	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Create a writeable version of the input table
			SELECT TOP 0 * INTO #Input FROM @Input i

			/*=======================================================================================================
			Prepare activities to update
			=======================================================================================================*/
			
			IF EXISTS(SELECT * FROM @Input)
			BEGIN
				INSERT	#Input(FK_Orchestration, FK_Module, FK_ModuleStatus, NotificationPending, RunDescription)
				SELECT	FK_Orchestration, 
						FK_Module, 
						FK_ModuleStatus, 
						NotificationPending, 
						RunDescription 
				FROM	@Input i

				INSERT @Logging(ActivityStatus, ActivityMessage) SELECT 5, 'Parameter Input'
			END
			ELSE BEGIN
				--Fully complete
				INSERT		#Input(FK_Orchestration, FK_Module, FK_ModuleStatus, NotificationPending, RunDescription)
				SELECT		ma.FK_Orchestration, 
							ma.FK_Module, 
							1, --Pending
							IIF(m.FK_ModuleType = 3, 1, 0),
							'Auto reset because orchestration had completed in full'
				FROM		etl.ModuleActivity ma
				JOIN		etl.Module m	ON m.FK_Orchestration = ma.FK_Orchestration 
											AND m.PK_module = ma.FK_Module
				LEFT JOIN	(
								SELECT	DISTINCT 
										ma.FK_Orchestration
								FROM	etl.ModuleActivity ma
								WHERE	ma.FK_ModuleStatus <> 4
							) nc ON nc.FK_Orchestration = ma.FK_Orchestration
				WHERE		nc.FK_Orchestration IS NULL

				INSERT @Logging(ActivityStatus, ActivityMessage) SELECT 5, 'Fully complete'


				--Default Resets
				INSERT		#Input(FK_Orchestration, FK_Module, FK_ModuleStatus, NotificationPending, RunDescription)
				SELECT		ma.FK_Orchestration, 
							ma.FK_Module, 
							1, --Pending
							IIF(m.FK_ModuleType = 3, 1, 0),
							'Default status override'
				FROM		etl.ModuleActivity ma
				JOIN		etl.Module m	ON	m.FK_Orchestration = ma.FK_Orchestration 
											AND m.PK_module = ma.FK_Module
				LEFT JOIN	#Input i		ON i.FK_Module = ma.FK_Module
											AND i.FK_Orchestration = ma.FK_Orchestration
				WHERE		ma.FK_ModuleStatus <> m.DefaultResetStatus --Will intentionally filter nulls as well
					AND		i.FK_Orchestration IS NULL
							
				INSERT @Logging(ActivityStatus, ActivityMessage) SELECT 5, 'Default Resets'
			END

			/*=======================================================================================================
			Validation
			=======================================================================================================*/
			IF EXISTS (SELECT * FROM #Input GROUP BY FK_Orchestration, FK_Module HAVING COUNT(*) > 1)
				RAISERROR('Duplicate modules have been submitted to the constructor, aborting', 16, 0)


			/*=======================================================================================================
			Update the target
			=======================================================================================================*/
			MERGE	etl.ModuleActivity a
			USING	#Input i	ON	i.FK_Orchestration = a.FK_Orchestration
								AND i.FK_Module = a.FK_Module
			WHEN	NOT MATCHED
			THEN	INSERT	(FK_Orchestration, FK_Module, FK_ModuleStatus, NotificationPending, RunDescription)
					VALUES	(i.FK_Orchestration, i.FK_Module, i.FK_ModuleStatus, i.NotificationPending, i.RunDescription)
			WHEN	MATCHED
			THEN	UPDATE 
					SET	a.FK_ModuleStatus = i.FK_ModuleStatus,
						a.RunDescription = i.RunDescription,
						a.NotificationPending = i.NotificationPending;
			
			INSERT @Logging(ActivityStatus, ActivityMessage) SELECT 5, 'Update the target'
		

		IF @Trancount = 0 COMMIT;

		INSERT @Logging(ActivityStatus) SELECT 2 
		
		--Generate logging for success
		EXEC log.usp_LogSchedulingHub  @Input = @Logging
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;

		--Generate logging for error (outside tran)
		INSERT @Logging(ActivityStatus, ActivityMessage) SELECT 4, ERROR_MESSAGE()
		EXEC log.usp_LogSchedulingHub  @Input = @Logging;

		THROW;
	END CATCH
END