﻿
CREATE  PROC  [test].[usp_ModulatorOnError]
AS

/*=======================================================================================================
To do
-Make PK_Orchestration an identity column
=======================================================================================================*/
SET NOCOUNT ON
BEGIN TRY
    DECLARE @GUID VARCHAR(55) = CAST(NEWID() AS VARCHAR(55))
	DECLARE @PK_Orchestration INT = (SELECT MAX(pk_orchestration) + 1 FROM etl.Orchestration o)
	DECLARE @OrchestrationName VARCHAR(255)='ModuleErrorLogingTest'
	DECLARE @TestDate DATETIME2(0) = GETUTCDATE()
	--SELECT @TestDate, @PK_Orchestration,@OrchestrationName
	--BEGIN TRAN
		/*=======================================================================================================
		Set up test configs
		=======================================================================================================*/
		--Create orchestration
		INSERT	etl.Orchestration(PK_Orchestration, OrchestrationName, FK_Schedule, FK_Parameter, IsEnabled)
		VALUES	(@PK_Orchestration, @OrchestrationName, NULL, NULL, 1);
		RAISERROR('etl.Orchestration: %i', 0, 0, @@rowcount) WITH NOWAIT;

		--Associate with 15 modules (that don't do very much)
		WITH	Tally AS (SELECT TOP(1) ROW_NUMBER() OVER (ORDER BY object_id) AS i FROM sys.objects o)
		INSERT	etl.Module(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase)
		SELECT	@PK_Orchestration, 
				t.i,
				'Step ' + CAST(t.i AS VARCHAR(20)), 
				1, 
				'RAISERROR(''unique reference to error: %s'', 16, 0, '''+ @GUID+''')',
				'UKDVDB162', 
				'SchedulingHub'
		FROM	Tally t;
		RAISERROR('etl.Module: %i', 0, 0, @@rowcount) WITH NOWAIT;

		--Create a hierarch of the modules. All at level one so set to run all 15 in paralell
		WITH	Tally AS (SELECT TOP(1) ROW_NUMBER() OVER (ORDER BY object_id) AS i FROM sys.objects o)
		INSERT	etl.ModuleHierarchy(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
		SELECT	@PK_Orchestration, NULL, t.i, 1 
		FROM	Tally t
		RAISERROR('etl.ModuleHierarchy: %i', 0, 0, @@rowcount) WITH NOWAIT;

		--Set the modules to status: pending
		INSERT	etl.ModuleActivity(FK_Orchestration, FK_Module, FK_ModuleStatus, NotificationPending)
		--OUTPUT	Inserted.*
		SELECT	DISTINCT 
				mh.FK_Orchestration,
				mh.FK_ChildModule,
				1 AS FK_moduleStatus, --Pending
				IIF(m.FK_ModuleType = 3, 1, 0) AS NotificationPending
		FROM	etl.ModuleHierarchy mh
		JOIN	etl.Module m	ON	m.PK_module = mh.FK_ChildModule
								AND m.FK_Orchestration = mh.FK_Orchestration
		WHERE	mh.FK_Orchestration = @PK_Orchestration
		RAISERROR('etl.ModuleActivity: %i', 0, 0, @@rowcount) WITH NOWAIT;

		/*=======================================================================================================
		Run the test
		=======================================================================================================*/
		--Kick off the job and wait for completion
		EXEC	test.usp_StartJob @JobName = 'SchedulingHub'; -- varchar(255)
		
		DECLARE @ModuleActivity VARCHAR(MAX)
		DECLARE @Now DATETIME2(0) = GETUTCDATE()
		SET		@ModuleActivity = REPLACE(CAST((	SELECT	FK_Module, 
															FK_ModuleStatus, 
															RunDescription, 
															ExecutionID 
													FROM	etl.ModuleActivity FOR SYSTEM_TIME FROM @TestDate TO @Now
													WHERE	FK_Orchestration = @PK_Orchestration 
													ORDER BY FK_Module, ActivityStart DESC
													FOR XML AUTO) AS VARCHAR(MAX)), '"/>', '"/>' + CHAR(13) + CHAR(10))
		
		PRINT CAST(@ModuleActivity AS NTEXT)
		--Check Error message in SSISDB--
		IF EXISTS(Select   *
		           From     SSISDB.internal.operation_messages m  
		           Where    m.message_type = 120   
                     and m.message like '%'+@GUID+'%'
					 and m.message_time>=DATEADD(minute, -7,  GETUTCDATE())
                     )






 SELECT 'Pass'
	

--GO
ELSE 
SELECT 'Test Fail: Unique error message not found in SSIDB '



/*=======================================================================================================
Clean up
--=======================================================================================================*/
DELETE	etl.ModuleActivity WHERE FK_Orchestration = @PK_Orchestration
--DELETE	etl.ModuleActivity_History WHERE FK_Orchestration = @PK_Orchestration
DELETE	etl.ModuleHierarchy WHERE FK_Orchestration = @PK_Orchestration
DELETE	etl.Module WHERE FK_Orchestration = @PK_Orchestration
DELETE	etl.Orchestration WHERE PK_Orchestration = @PK_Orchestration






END TRY

BEGIN CATCH

	--return failed status
	SELECT Fail = ERROR_MESSAGE();
END CATCH