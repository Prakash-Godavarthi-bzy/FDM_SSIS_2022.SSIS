﻿CREATE PROCEDURE test.usp_StartJob(@JobName VARCHAR(255))
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @xp_results TABLE 
	( 
		job_id                UNIQUEIDENTIFIER NOT NULL,
		last_run_date         INT              NOT NULL,
		last_run_time         INT              NOT NULL,
		next_run_date         INT              NOT NULL,
		next_run_time         INT              NOT NULL,
		next_run_schedule_id  INT              NOT NULL,
		requested_to_run      INT              NOT NULL, -- BOOL
		request_source        INT              NOT NULL,
		request_source_id     sysname          COLLATE DATABASE_DEFAULT NULL,
		running               INT              NOT NULL, -- BOOL
		current_step          INT              NOT NULL,
		current_retry_attempt INT              NOT NULL,
		job_state             INT              NOT NULL
	)

	DECLARE	@JobID UNIQUEIDENTIFIER = (SELECT s.job_id FROM msdb.dbo.sysjobs s WHERE s.name = @JobName)
	DECLARE @r AS INT
	DECLARE @start_job BIGINT = cast(convert(varchar, getdate(), 112) as bigint) * 1000000 + datepart(hour, getdate()) * 10000 + datepart(minute, getdate()) * 100 + datepart(second, getdate())
	DECLARE @StepID INT = 0
	DECLARE @StepName VARCHAR(255)
	DECLARE @StepDate VARCHAR(50)

	BEGIN TRY
		-- start the job
		RAISERROR ('Starting job: %s', 0, 0, @JobName) WITH NOWAIT
		EXEC	@r = msdb.dbo.sp_start_job @job_id = @JobID
		IF		@r<>0 RAISERROR (N'Could not start job', 16, 2)

		--Wait for the job to complete
		WHILE 1=1
		BEGIN
			WAITFOR DELAY '0:0:01';

			DELETE @xp_results
			INSERT @xp_results EXECUTE master.dbo.xp_sqlagent_enum_jobs 1, 'BFL\kirkl', @JobID

			IF	EXISTS (SELECT * FROM @xp_results xr WHERE xr.current_step <> @StepID)
			BEGIN
				SELECT	@StepID = xr.current_step FROM @xp_results xr

				SELECT	@StepName = s.step_name
				FROM	msdb.dbo.sysjobsteps s		
				WHERE	s.job_id = @JobID
					AND s.step_id = @StepID

				SET @StepDate = CONCAT(CONVERT(VARCHAR(50), GETDATE(), 112), ' ', CONVERT(VARCHAR(50), GETDATE(), 108))
				RAISERROR('%s: %s', 0, 0, @StepDate, @StepName) WITH NOWAIT

			END 

			IF EXISTS (SELECT * FROM @xp_results WHERE running = 0)
				BREAK
		END
		RAISERROR ('Job complete', 0, 0, @JobName) WITH NOWAIT

		-- did it finish ok ?
		DECLARE @ErrorMessage VARCHAR(8000) = ''
		IF NOT EXISTS	(SELECT	* FROM msdb.dbo.sysjobhistory WHERE	job_id=@JobID AND CAST(run_date AS BIGINT) * 1000000 + run_time >= @start_job AND run_status = 1)
		BEGIN	
			SELECT	@ErrorMessage += message + '; ' FROM msdb.dbo.sysjobhistory WHERE	job_id=@JobID AND CAST(run_date AS BIGINT) * 1000000 + run_time >= @start_job AND sql_severity = 16
			RAISERROR (N'%s Failed: %s', 16, 0, @JobName, @ErrorMessage)
		END
		ELSE
			RETURN 1
	END TRY
	BEGIN CATCH
		THROW;
	END CATCH
END
GO

