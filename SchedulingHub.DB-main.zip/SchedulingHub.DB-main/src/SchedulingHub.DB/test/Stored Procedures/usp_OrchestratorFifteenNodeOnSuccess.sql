﻿
/*=======================================================================================================
Is:		test.usp_OrchestratorFifteenNodeOnSuccess
Does:	Creates a 15 node orchestration, runs it and assesses the activity table for whether it ran 
		successfully. This is intended to be run in a SSDT unit test asserting on no rows (ie. No 
		news is good news)
=======================================================================================================*/
CREATE PROCEDURE test.usp_OrchestratorFifteenNodeOnSuccess
AS
BEGIN
	SET NOCOUNT ON
	BEGIN TRY
		DECLARE @PK_Orchestration INT = (SELECT MAX(pk_orchestration) + 1 FROM etl.Orchestration o)
		DECLARE @TestDate DATETIME2(0) = DATEADD(MINUTE, -1, GETUTCDATE())
		DECLARE @ExecutionID INT
		
		RAISERROR('PK_Orchestration: %i', 0, 0, @PK_Orchestration) WITH NOWAIT;
		/*=======================================================================================================
		Set up test configs
		=======================================================================================================*/
		--Create orchestration
		INSERT	etl.Orchestration(PK_Orchestration, OrchestrationName, FK_Schedule, FK_Parameter, IsEnabled)
		VALUES	(@PK_Orchestration, '15 node test', NULL, NULL, 1);
		RAISERROR('etl.Orchestration: %i', 0, 0, @@rowcount) WITH NOWAIT;

		--Associate with 15 modules (that don't do very much)
		WITH	Tally AS (SELECT TOP(15) ROW_NUMBER() OVER (ORDER BY object_id) AS i FROM sys.objects o)
		INSERT	etl.Module(FK_Orchestration, PK_module, ModuleName, FK_ModuleType, ModuleRoutine, DestinationServer, DestinationDatabase)
		SELECT	@PK_Orchestration, 
				t.i,
				'Step ' + CAST(t.i AS VARCHAR(20)), 
				1, 
				'SELECT ' + CAST(t.i AS VARCHAR(20)),
				@@SERVERNAME, 
				'SchedulingHub'
		FROM	Tally t;
		RAISERROR('etl.Module: %i', 0, 0, @@rowcount) WITH NOWAIT;
		
		--Create a hierarch of the modules. All at level one so set to run all 15 in paralell
		WITH	Tally AS (SELECT TOP(15) ROW_NUMBER() OVER (ORDER BY object_id) AS i FROM sys.objects o)
		INSERT	etl.ModuleHierarchy(FK_Orchestration, FK_ParentModule, FK_ChildModule, TreeLevel)
		SELECT	@PK_Orchestration, NULL, t.i, 1 
		FROM	Tally t
		RAISERROR('etl.ModuleHierarchy: %i', 0, 0, @@rowcount) WITH NOWAIT;

		--Set the modules to status: pending
		INSERT	etl.ModuleActivity(FK_Orchestration, FK_Module, FK_ModuleStatus, NotificationPending, ExecutionID)
		--OUTPUT	Inserted.*
		SELECT	DISTINCT 
				mh.FK_Orchestration,
				mh.FK_ChildModule,
				1 AS FK_moduleStatus, --Pending
				IIF(m.FK_ModuleType = 3, 1, 0) AS NotificationPending,
				-1
		FROM	etl.ModuleHierarchy mh
		JOIN	etl.Module m	ON	m.PK_module = mh.FK_ChildModule
								AND m.FK_Orchestration = mh.FK_Orchestration
		WHERE	mh.FK_Orchestration = @PK_Orchestration
		RAISERROR('etl.ModuleActivity: %i', 0, 0, @@rowcount) WITH NOWAIT;

		/*=======================================================================================================
		Run the test
		=======================================================================================================*/
		--Kick off the job and wait for completion
		EXEC	sch.usp_ExecutePackage	@PackageName = N'Orchestrator.dtsx', 
									@PackageLocation = N'Scheduling_Hub', 
									@ProjectName = N'SchedulingHubETL', 
									@Parameters = '<Root></Root>',
									@ExecutionID = @ExecutionID OUTPUT
		
		/*=======================================================================================================
		Run some checks and return info back to the test
		=======================================================================================================*/
		RAISERROR('ExecutionID: %i', 0, 0, @ExecutionID) WITH NOWAIT;

		DECLARE @ModuleActivity VARCHAR(MAX)
		DECLARE @Now DATETIME2(0) = GETUTCDATE()
		SET		@ModuleActivity = REPLACE(CAST((	SELECT	FK_Module, 
															FK_ModuleStatus, 
															RunDescription, 
															ExecutionID 
													FROM	etl.ModuleActivity FOR SYSTEM_TIME FROM @TestDate TO @Now
													WHERE	FK_Orchestration = @PK_Orchestration 
													ORDER BY FK_Module, ActivityStart DESC
													FOR XML AUTO) AS VARCHAR(MAX)), '"/>', '"/>' + CHAR(13) + CHAR(10))
		
		PRINT CAST(@ModuleActivity AS NTEXT)

		IF NOT EXISTS(SELECT * FROM etl.ModuleActivity  WHERE FK_Orchestration = @PK_Orchestration AND ExecutionID = @ExecutionID)
			RAISERROR('No activity found for this run', 16, 0);

		--Assert on expected activity. No rows = good
		WITH		Actual(StatusCount, StatusDescription, ExecutionID)
		AS			(
						SELECT		COUNT(*), 
									ms.ModuleStatus,
									ma.ExecutionID
						FROM		etl.ModuleActivity FOR SYSTEM_TIME ALL ma
						JOIN		etl.ModuleStatus ms ON ms.PK_ModuleStatus = ma.FK_ModuleStatus
						WHERE		ma.FK_Orchestration = @PK_Orchestration
							AND		ma.ExecutionID = @ExecutionID
						GROUP BY	ms.ModuleStatus, ma.ExecutionID
					)
		,			Expected(StatusCount, StatusDescription, ExecutionID)
		AS			(
						SELECT 15, 'Pending',	@ExecutionID UNION ALL
						SELECT 15, 'Succeeded',	@ExecutionID
					)
		SELECT	* 
		FROM	(
					SELECT 'Actual', * FROM Actual
					EXCEPT 
					SELECT 'Actual', * FROM Expected
					UNION	ALL
					SELECT 'Expected', * FROM Expected
					EXCEPT 
					SELECT 'Expected', * FROM Actual
				) diff (SourceDescription, StatusCount, StatusDescription, ExecutionID)

		--Clean up
		DELETE	etl.ModuleActivity WHERE FK_Orchestration = @PK_Orchestration
		DELETE	etl.ModuleHierarchy WHERE FK_Orchestration = @PK_Orchestration
		DELETE	etl.Module WHERE FK_Orchestration = @PK_Orchestration
		DELETE	etl.Orchestration WHERE PK_Orchestration = @PK_Orchestration
	END TRY
	BEGIN CATCH
		--Clean up
		DELETE	etl.ModuleActivity WHERE FK_Orchestration = @PK_Orchestration
		DELETE	etl.ModuleHierarchy WHERE FK_Orchestration = @PK_Orchestration
		DELETE	etl.Module WHERE FK_Orchestration = @PK_Orchestration
		DELETE	etl.Orchestration WHERE PK_Orchestration = @PK_Orchestration



		--return failed status
		SELECT Fail = ERROR_MESSAGE(), @PK_Orchestration, @ExecutionID;
		THROW;
	END CATCH
END