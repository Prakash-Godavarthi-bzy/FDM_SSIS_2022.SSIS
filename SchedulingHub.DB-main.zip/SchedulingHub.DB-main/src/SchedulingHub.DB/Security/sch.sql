﻿CREATE SCHEMA [sch]
    AUTHORIZATION [dbo];







