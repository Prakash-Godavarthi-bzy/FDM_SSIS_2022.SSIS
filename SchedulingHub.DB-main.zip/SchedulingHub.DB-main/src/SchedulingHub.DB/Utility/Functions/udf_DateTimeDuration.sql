﻿
CREATE FUNCTION Utility.udf_DateTimeDuration
(
     @p_StartDateTime         DATETIME2(2)
    ,@p_EndDateTime           DATETIME2(2)
)

RETURNS NVARCHAR(50)

WITH RETURNS NULL ON NULL INPUT

AS

BEGIN

	DECLARE @v_DateTimeIntervalStart 	DATETIME2(2)
	DECLARE @v_DateTimeIntervalEnd 		DATETIME2(2)

	--Change date format to yyyy-mmm-dd so there is not confusion between yyyy-mm-dd and yyyy-dd-mm
	SET @p_StartDateTime = (SELECT CONVERT(NVARCHAR(50),@p_StartDateTime,113)) 
	SET @p_EndDateTime   = (SELECT CONVERT(NVARCHAR(50),@p_EndDateTime  ,113))

	-- Reverse the dates if the start date is greater than the enddate
	SET @v_DateTimeIntervalStart = (SELECT CASE WHEN @p_StartDateTime <= @p_EndDateTime   THEN @p_StartDateTime ELSE @p_EndDateTime   END)
	SET @v_DateTimeIntervalEnd 	 = (SELECT CASE WHEN @p_EndDateTime   >= @p_StartDateTime THEN @p_EndDateTime   ELSE @p_StartDateTime END)

	RETURN 

	-- If the difference is greater than 99h return just +99 
		   CASE WHEN DATEDIFF(HOUR,@v_DateTimeIntervalStart,@v_DateTimeIntervalEnd)>99 THEN '+ 99h'
				ELSE
						 RIGHT('00' + CAST((DATEDIFF(SECOND,@v_DateTimeIntervalStart,@v_DateTimeIntervalEnd)) / 3600 AS NVARCHAR(255)),2) + ':' 
					   + RIGHT('00' + CAST((DATEDIFF(SECOND,@v_DateTimeIntervalStart,@v_DateTimeIntervalEnd)) % 3600 / 60 AS NVARCHAR(255)),2) + ':'  
					   + RIGHT('00' + CAST((DATEDIFF(SECOND,@v_DateTimeIntervalStart,@v_DateTimeIntervalEnd)) % 60 AS NVARCHAR(255)),2)
		   END
       
END
GO
EXECUTE sp_addextendedproperty @name = N'Function Parameters', @value = N'@p_StartDateTime DATETIME2(2)
					The start date and time that will be used to calculate the duration.

					@p_EndDateTime DATETIME2(2)
					The end date and time that will be used to calculate the duration.', @level0type = N'SCHEMA', @level0name = N'Utility', @level1type = N'FUNCTION', @level1name = N'udf_DateTimeDuration';


GO
EXECUTE sp_addextendedproperty @name = N'Function Definition', @value = N'This function calculates the duration between two datetime values and outputs the result in the format: hh:mm:ss
					To be used in the ActivityDuration column in the Archive.ActivityLog table.', @level0type = N'SCHEMA', @level0name = N'Utility', @level1type = N'FUNCTION', @level1name = N'udf_DateTimeDuration';


GO
EXECUTE sp_addextendedproperty @name = N'Function Call', @value = N'The function caller will just pass the two input parameters defined in the parameters column and get the hh:mm:ss duration back.
					Remarks:
					1.	Reverse the input dates if the start date time is greater than the end date time.
					2.	For activities with a duration bigger than 99h the function will return the string ‘+99’.
					3.	The function must be able to distinguish between yyyy-mm-dd and yyyy-dd-mm dates.', @level0type = N'SCHEMA', @level0name = N'Utility', @level1type = N'FUNCTION', @level1name = N'udf_DateTimeDuration';

