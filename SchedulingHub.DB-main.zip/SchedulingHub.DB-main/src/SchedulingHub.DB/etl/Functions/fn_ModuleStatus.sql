﻿CREATE FUNCTION etl.fn_ModuleStatus(@PK_Orchestration INT)
RETURNS TABLE 
AS
RETURN
(	
	SELECT	Step = cm.ModuleName,
			PK_ModuleStatus = ma.FK_ModuleStatus,
			PK_module = cm.PK_module,
			ma.ActivityStart,
			URL =	IIF(cm.FK_ModuleType = 3,
								'<iframe id="contact" src="http://ukdvdb151/ReportServer/Pages/ReportViewer.aspx?%2fFDMTest%2fAuthorise&rs:Command=Render?rs:Embed=true' 
								+ '&FK_ModuleActivity=' + CAST(ma.PK_ModuleActivity AS VARCHAR(20)) 
								+ '&FK_AuthorisationStatus=' + ISNULL(CAST(a.FK_AuthorisationStatus AS VARCHAR(20)), '1')
								+ '&Submit=0" allowtransparency="true" frameborder="0" scrolling="no" width="100%" height="100%"></iframe>'
							,'<H1>Select a step to approve</H1>'),
			SVGLocation = 	'https://raw.githubusercontent.com/LaurenceBKirk/Orchestrations/master/Orchestration' + CAST(@PK_Orchestration AS VARCHAR(20)) + '.svg'
							
	FROM		etl.Orchestration o
	JOIN		etl.Module cm			ON  cm.FK_Orchestration = o.PK_Orchestration
	JOIN		etl.ModuleActivity ma   ON  ma.FK_Orchestration = cm.FK_Orchestration
										AND ma.FK_Module = cm.PK_module
	LEFT JOIN	(
					SELECT	a.FK_AuthorisationStatus,
							a.FK_ModuleActivity
					FROM	etl.Authorisation a
					JOIN	(
								SELECT	MAX(PK_Authorisation) AS PK_Authorisation, 
										FK_ModuleActivity 
								FROM	etl.Authorisation
								GROUP BY FK_ModuleActivity
							) la	ON	a.PK_Authorisation = la.PK_Authorisation
				)  a ON a.FK_ModuleActivity = ma.PK_ModuleActivity
	WHERE		o.PK_Orchestration = @PK_Orchestration
	UNION
	SELECT	'Step 0', 0, 0, NULL, '<H1>Select a step to approve</H1>', ''
)
GO
EXECUTE sp_addextendedproperty @name = N'Function Parameters', @value = N'INput:

					@PK_Orchestration – INT – NOT NULL:
					This pram stores unique ID (PK_Orchestration value) of the Orchestration recorded in the Orchestration table.', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'FUNCTION', @level1name = N'fn_ModuleStatus';


GO
EXECUTE sp_addextendedproperty @name = N'Function Definition', @value = N'The Function takes one input variables and returns module name, module status and other relvent information can been seen above.', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'FUNCTION', @level1name = N'fn_ModuleStatus';

