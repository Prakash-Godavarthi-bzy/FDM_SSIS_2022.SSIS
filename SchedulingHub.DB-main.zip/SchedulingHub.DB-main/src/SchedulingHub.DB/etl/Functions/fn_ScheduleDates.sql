﻿
CREATE FUNCTION etl.fn_ScheduleDates(@PK_Schedule INT, @TestStart DATETIME = NULL, @TestCurrent DATETIME = NULL)
RETURNS TABLE 
AS
RETURN
(
	WITH		CombinedSchedule
	AS			(
					SELECT	s.PK_Schedule,
							s.Schedule,
							DATEADD(mi, DATEDIFF(mi, 0, ISNULL(@TestStart, s.StartDate)), 0) AS StartDate,
							DATEADD(mi, DATEDIFF(mi, 0, ISNULL(@TestCurrent, GETDATE())), 0) AS CurrentDate,
							s.Interval,
							s.FK_IntervalType
					FROM	etl.Schedule s
					WHERE	s.PK_Schedule = @PK_Schedule
				)

	SELECT		cs.PK_Schedule,
				cs.Schedule,
				--cs.StartDate,
				--cs.CurrentDate,
				--CS.Interval,
				DATEADD(mi, DATEDIFF(mi, 0, 
				CASE cs.FK_IntervalType
					WHEN 2 THEN DATEADD(MINUTE, ((DATEDIFF(MINUTE, cs.StartDate, cs.CurrentDate)) % (cs.interval*60)) * -1, cs.CurrentDate)
					WHEN 4 THEN DATEADD(SECOND, ((DATEDIFF(SECOND, cs.StartDate, cs.CurrentDate)) % (cs.interval*60)) * -1, cs.CurrentDate)
					WHEN 1 THEN DATEADD(MINUTE, ((DATEDIFF(MINUTE, cs.StartDate, cs.CurrentDate)) % (cs.interval*24*60)) * -1, cs.CurrentDate)
					WHEN 3 THEN cal.PreviousSchedule
				END), 0) AS PreviousSchedule,
				DATEADD(mi, DATEDIFF(mi, 0, 
				CASE cs.FK_IntervalType
					WHEN 2 THEN DATEADD(MINUTE, (cs.interval*60)-((DATEDIFF(MINUTE, cs.StartDate, cs.CurrentDate))%(cs.interval*60)), cs.CurrentDate)
					WHEN 4 THEN DATEADD(SECOND, (cs.interval*60)-((DATEDIFF(SECOND, cs.StartDate, cs.CurrentDate))%(cs.interval*60)), cs.CurrentDate)
					WHEN 1 THEN DATEADD(MINUTE, (cs.interval*24*60)-((DATEDIFF(MINUTE, cs.StartDate, cs.CurrentDate))%(cs.interval*24*60)), cs.CurrentDate)
					WHEN 3 THEN cal.NextSchedulde 
				END), 0) AS NextSchedule
	FROM		CombinedSchedule cs
	LEFT JOIN	(
					SELECT		sc.FK_Schedule,	
								MIN(IIF(cs.CurrentDate < TargetDate, TargetDate, NULL)) AS NextSchedulde,
								MAX(IIF(cs.CurrentDate > TargetDate, TargetDate, NULL)) AS PreviousSchedule
					FROM		etl.ScheduleCalendar sc
					JOIN		CombinedSchedule cs ON cs.PK_Schedule = sc.FK_Schedule
					GROUP BY	sc.FK_Schedule 
				) cal ON cal.FK_Schedule = cs.PK_Schedule
)