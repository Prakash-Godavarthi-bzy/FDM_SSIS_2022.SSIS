﻿

CREATE FUNCTION [etl].[fn_Parameters](@PK_Orchestration INT)
RETURNS VARCHAR(8000)
AS 
BEGIN
	DECLARE @Parameters VARCHAR(8000) =	CAST((
									SELECT	ParameterKey AS "@ParameterKey",
											ParameterType AS "@ParameterType",
											ParameterValue AS "@ParameterValue" 
									FROM	[etl].[Parameter] where [FK_Orchestration]=@PK_Orchestration
									FOR		XML PATH('Parameter'),ROOT('ROOT')
								) AS VARCHAR(8000))
	 
	RETURN @Parameters
END