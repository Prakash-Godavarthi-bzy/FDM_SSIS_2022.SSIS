﻿CREATE FUNCTION etl.fn_NotificationConfig(@PK_Orchestration INT, @PK_Module INT)
RETURNS @Return TABLE 
(
	Recipients VARCHAR(4000),
	Cc VARCHAR(4000),
	Bcc VARCHAR(4000),
	Subject VARCHAR(130),
	Body VARCHAR(8000)
)
AS
BEGIN
	--Build up address fields
	DECLARE @To VARCHAR(4000) = '', @cc VARCHAR(4000) = '', @Bcc VARCHAR(4000) = ''
	SELECT	@To =	@to + IIF(@to = '', '', ';') + IIF(nu.FK_RecipientType = 1, ru.EmailAddress, ''),
			@cc =	@cc + IIF(@cc = '', '', ';') + IIF(nu.FK_RecipientType = 2, ru.EmailAddress, ''),
			@Bcc =	@Bcc + IIF(@Bcc = '', '', ';') + IIF(nu.FK_RecipientType = 3, ru.EmailAddress, '')
	FROM	etl.Module m
	JOIN	etl.Notification n ON n.PK_Notification = m.FK_Notification
	JOIN	etl.NotificationUser nu ON nu.FK_Notification = n.PK_Notification
	JOIN	etl.ReportUser ru ON ru.PK_ReportUser = nu.FK_ReportUser
	WHERE	m.FK_Orchestration = @PK_Orchestration
		AND m.PK_module = @PK_Module

	--Assign email details for this module
	INSERT	@Return(Recipients, Cc, bcc, Subject, Body)
	SELECT	@To,
			@cc,
			@Bcc,
			n.Subject,
			n.Body
	FROM	etl.Module m
	JOIN	etl.Notification n ON n.PK_Notification = m.FK_Notification
	WHERE	m.FK_Orchestration = @PK_Orchestration
		AND m.PK_module = @PK_Module

	--Return empty strings if nothing to return (prevents having to handle nulls in SSIS)
	INSERT	@Return(Recipients, Cc, Bcc, Subject, Body)
	SELECT	'', '', '', '', '' 
	WHERE	NOT EXISTS (SELECT * FROM @Return)

	RETURN
END