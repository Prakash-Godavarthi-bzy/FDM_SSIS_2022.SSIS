﻿
/*=======================================================================================================
Is:		etl.fn_OrchestratorControl
Does:	
=======================================================================================================*/
CREATE FUNCTION etl.fn_OrchestratorControl(@PK_Orchestration INT)
RETURNS TABLE 
AS
RETURN
(
	SELECT	TreeLevel,
			ISNULL(p.[1], '') AS [1],
			ISNULL(p.[2], '') AS [2],
			ISNULL(p.[3], '') AS [3],
			ISNULL(p.[4], '') AS [4],
			ISNULL(p.[5], '') AS [5],
			ISNULL(p.[6], '') AS [6],
			ISNULL(p.[7], '') AS [7],
			ISNULL(p.[8], '') AS [8],
			ISNULL(p.[9], '') AS [9],
			ISNULL(p.[10], '') AS [10],
			ISNULL(p.[11], '') AS [11],
			ISNULL(p.[12], '') AS [12],
			ISNULL(p.[13], '') AS [13],
			ISNULL(p.[14], '') AS [14],
			ISNULL(p.[15], '') AS [15]
	FROM	(
				SELECT	ROW_NUMBER() OVER(PARTITION BY h.TreeLevel ORDER BY h.TreeLevel, h.PK_module) AS LevelPosition,
						TreeLevel,
						PK_module
				FROM	(
							SELECT		DISTINCT
										mh.TreeLevel,
										m.ModuleName,
										m.PK_module
							FROM		etl.Orchestration o
							JOIN		etl.ModuleHierarchy mh	ON o.PK_Orchestration = mh.FK_orchestration
							JOIN		etl.Module m			ON mh.FK_ChildModule = m.PK_module
																AND m.FK_Orchestration = mh.FK_Orchestration
							WHERE		o.PK_Orchestration = @PK_Orchestration
						) h
			) h
	PIVOT	(MIN(PK_module) FOR LevelPosition IN ([1], [2], [3], [4], [5], [6], [7], [8], [9], [10], [11], [12], [13], [14], [15])) p
	WHERE	COALESCE ([1], [2], [3], [4], [5], [6], [7], [8], [9], [10], [11], [12], [13], [14], [15]) IS NOT NULL
)