﻿
CREATE FUNCTION [etl].[fn_ModulatorConfig](@PK_Orchestration INT, @PK_Module INT)
RETURNS TABLE 
AS
RETURN
(
	--DECLARE @PK_Orchestration INT = 4, @PK_Module INT = 2
	WITH	Configs
	AS		(	
				SELECT		m.ModuleName,
							m.ModuleRoutine,
							m.FK_ModuleType,
							m.DestinationServer,
							m.DestinationDatabase,
							ma.PK_ModuleActivity,
							1 AS ControlBitmask,
							ma.NotificationPending,
							ms.PK_ModuleStatus,
							ms.ToRerun,
							mh.FK_ChildModule,
							mh.FK_ParentModule,
							ISNULL(pa.FK_ModuleStatus, 4) AS ParentStatus,
							ma.ActivityStart,
							sd.NextSchedule,
							sd.PreviousSchedule,
							IIF(ma.ActivityStart <= ISNULL(sd.PreviousSchedule, GETDATE()), 1, 0) AS ScheduledToRun
				FROM		etl.Module m
				JOIN		etl.ModuleHierarchy mh 	ON	m.PK_Module = mh.FK_ChildModule
													AND m.FK_Orchestration = mh.FK_Orchestration
				JOIN		etl.ModuleActivity ma	ON ma.FK_Module = mh.FK_ChildModule
													AND ma.FK_Orchestration = m.FK_Orchestration
				JOIN		etl.ModuleStatus ms		ON ms.PK_ModuleStatus = ma.FK_ModuleStatus
				OUTER APPLY	etl.fn_ScheduleDates(m.FK_Schedule, NULL, NULL) sd
				LEFT JOIN	etl.ModuleActivity pa	ON pa.FK_Module = mh.FK_ParentModule
													AND pa.FK_Orchestration = m.FK_Orchestration
				WHERE		m.FK_Orchestration = @PK_Orchestration
					--AND FK_ChildModule = 2
			)
	SELECT	TOP 1 *
	FROM	(
				SELECT	DISTINCT
						c.ModuleName,
						c.ModuleRoutine,
						c.FK_ModuleType,
						c.DestinationServer,
						c.DestinationDatabase,
						c.PK_ModuleActivity,
						1 AS ControlBitmask,
						(SELECT	count(*) FROM Configs c WHERE	c.FK_ChildModule = @PK_Module AND c.ParentStatus <> 4) AS UnsucceededParents,
						c.NotificationPending
				FROM	Configs c
				WHERE	1=1 
					AND NOT EXISTS	(SELECT	* FROM Configs c WHERE	c.FK_ChildModule = @PK_Module AND c.ParentStatus <> 4)
					AND c.ToRerun = 1
					AND c.ScheduledToRun = 1
					AND c.FK_ChildModule = @PK_Module
				UNION
				SELECT	'' AS ModuleName,
						'' AS ModuleRoutine,
						0 AS FK_ModuleType,
						'' AS DestinationServer,
						'' AS DestinationDatabase,
						0 AS PK_ModuleActivity,
						0 AS ControlBitmask,
						(SELECT	count(*) FROM Configs c WHERE	c.FK_ChildModule = @PK_Module AND c.ParentStatus <> 4) AS UnsucceededParents,
						0 AS NotificationPending
			) c
	ORDER BY FK_ModuleType DESC
)
GO
EXECUTE sp_addextendedproperty @name = N'Function Parameters', @value = N'INput:

					@PK_Orchestration – INT – NOT NULL:
					This pram stores unique ID (PK_Orchestration value) of the Orchestration recorded in the Orchestration table.

					Input:

					 @PK_Module -   INT - NOT NULL:
					This pram stores unique ID (PK_Module s  value) of the Module recorded in the Module   table.', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'FUNCTION', @level1name = N'fn_ModulatorConfig';


GO
EXECUTE sp_addextendedproperty @name = N'Function Definition', @value = N'The Function takes two variables and returns module name, module rutine and other relvent information can been seen above.', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'FUNCTION', @level1name = N'fn_ModulatorConfig';

