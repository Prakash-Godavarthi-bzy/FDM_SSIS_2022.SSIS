﻿CREATE TYPE [etl].[utt_CreateModuleActivity] AS TABLE (
    [FK_Orchestration]    INT           NOT NULL,
    [FK_Module]           INT           NOT NULL,
    [FK_ModuleStatus]     INT           NOT NULL,
    [NotificationPending] BIT           NULL,
    [RunDescription]      VARCHAR (255) NOT NULL);

