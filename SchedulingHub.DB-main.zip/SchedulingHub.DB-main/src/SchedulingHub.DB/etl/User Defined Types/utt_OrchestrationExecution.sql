﻿CREATE TYPE [etl].[utt_OrchestrationExecution] AS TABLE (
    [ExecutionSequence]       INT NOT NULL,
    [PK_Orchestration]        INT NOT NULL,
    [CurrentAccountingPeriod] INT NOT NULL);

