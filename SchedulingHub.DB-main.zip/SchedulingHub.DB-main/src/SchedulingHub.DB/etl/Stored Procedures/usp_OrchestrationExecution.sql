﻿/*====================================================================================================
Is:			usp_OrchestrationExecution 
Does:		Enables a specified orchestration then runs the scheduling hub
Parameters:	etl.utt_OrchestrationExecution
				ExecutionSequence - Order to run in
				PK_Orchestration - Orchestration to run
				CurrentAccountingPeriod -	for base load: data will be cut for this period
											for normal load: data will be loaded into this period
====================================================================================================*/
CREATE PROCEDURE etl.usp_OrchestrationExecution (@Configs etl.utt_OrchestrationExecution READONLY)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Logging log.utt_ActivityLog
	DECLARE @ActivityName VARCHAR(50) = OBJECT_NAME(@@PROCID)
	DECLARE @ExecutionSequence INT = 0
	DECLARE @PK_Orchestration INT
	DECLARE @CurrentAccountingPeriod INT
	BEGIN TRY
		INSERT @Logging(ActivityName, ActivityStatus, ActivityMessage) SELECT @ActivityName, 5, 'Start'

		--Save current orchestration settings			
		SELECT	o.PK_Orchestration
				,o.IsEnabled 
		INTO	#Orchestration
		FROM	etl.Orchestration o

		--Loop configs and execute orchestrations (if not alrready loaded)
		WHILE EXISTS (SELECT * FROM @Configs c WHERE c.ExecutionSequence > @ExecutionSequence)
		BEGIN
			SELECT	@ExecutionSequence = c.ExecutionSequence
					,@PK_Orchestration = c.PK_Orchestration
					,@CurrentAccountingPeriod = c.CurrentAccountingPeriod
			FROM	@Configs c
			JOIN	(
						SELECT MIN(c.ExecutionSequence) AS ExecutionSequence 
						FROM @Configs c 
						WHERE c.ExecutionSequence > @ExecutionSequence
					) nc ON nc.ExecutionSequence = c.ExecutionSequence

			IF NOT EXISTS (SELECT * FROM TechnicalHub.fct.TechnicalResult tr WHERE tr.FK_AccountingPeriod = @CurrentAccountingPeriod)
			BEGIN
				INSERT @Logging(ActivityName, ActivityStatus, ActivityMessage) 
				SELECT @ActivityName, 5, CONCAT('Running orchestration ', CAST(@PK_Orchestration AS VARCHAR(20)), ' For period ', CAST(@CurrentAccountingPeriod AS VARCHAR(20)))

				--Set the appropriate orchestration settings
				UPDATE	etl.ModuleActivity SET FK_ModuleStatus = 1, RunDescription = NULL  WHERE FK_Orchestration = @PK_Orchestration
				UPDATE	etl.Orchestration SET IsEnabled = IIF(PK_Orchestration = @PK_Orchestration, 1, 0) FROM etl.Orchestration 
				UPDATE	TechnicalHub.dim.process SET CurrentAccountingPeriod = @CurrentAccountingPeriod

				EXEC test.usp_StartJob @JobName = 'SchedulingHub'
					
			END
			ELSE	
				INSERT @Logging(ActivityName, ActivityStatus, ActivityMessage) 
				SELECT @ActivityName, 5, CONCAT('Data already loaded for ', CAST(@CurrentAccountingPeriod AS VARCHAR(20)))
		END

		--Re-apply saved orchestration settings
		UPDATE	o
		SET		o.IsEnabled = so.IsEnabled
		FROM	etl.Orchestration o
		JOIN	#Orchestration so ON so.PK_Orchestration = o.PK_Orchestration

		INSERT @Logging(ActivityName, ActivityStatus, ActivityMessage) SELECT @ActivityName, 5, 'End'
		EXEC log.usp_LogSchedulingHub @Input = @Logging
	END TRY
	BEGIN CATCH
		INSERT @Logging(ActivityName, ActivityStatus, ActivityMessage) SELECT @ActivityName, 4, ERROR_MESSAGE()
		EXEC log.usp_LogSchedulingHub @Input = @Logging;
		THROW;
	END CATCH
END
GO
