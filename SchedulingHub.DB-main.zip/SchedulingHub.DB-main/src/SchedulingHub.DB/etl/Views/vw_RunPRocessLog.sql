﻿CREATE View [etl].[vw_RunPRocessLog] AS 

SELECT ocf.Dataset,ocf.[Source DB],Ocf.fk_Orchestration,orm.fk_Landing,PackageName AS Inbound,fk_Inbound,INB_mod.ModuleName AS InboundModule,
fk_Outbound,out_mod.ModuleName AS OutboundModule,OutboundProc,
fk_Extensions,ext_mod.ModuleName AS ExtensionsModule,ExtensionsProc
FROM [etl].[OrchestrationRunConfig] as ocf
JOIN
etl.Orchestration as o
ON ocf.fk_Orchestration = o.PK_Orchestration
JOIN
ETL.OrchestrationRunModules as orm
ON ocf.PK_Config = orm.fk_config
LEFT JOIN
etl.Module as lan_mod
ON orm.fk_Landing = lan_mod.PK_module
and ocf.fk_Orchestration=lan_mod.FK_Orchestration
LEFT JOIN
etl.Module as INB_mod
ON orm.fk_Inbound = INB_mod.PK_module
and ocf.fk_Orchestration=INB_mod.FK_Orchestration
LEFT JOIN
etl.Module as out_mod
ON orm.fk_Outbound = out_mod.PK_module
and ocf.fk_Orchestration=out_mod.FK_Orchestration
LEFT JOIN
etl.Module as ext_mod
ON orm.fk_Extensions = ext_mod.PK_module
and ocf.fk_Orchestration=ext_mod.FK_Orchestration
GO
