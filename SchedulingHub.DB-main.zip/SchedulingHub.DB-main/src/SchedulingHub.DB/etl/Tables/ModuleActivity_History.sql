﻿CREATE TABLE [etl].[ModuleActivity_History] (
    [PK_ModuleActivity]        INT           NOT NULL,
    [FK_OrchestrationActivity] INT           NULL,
    [FK_Orchestration]         INT           NULL,
    [FK_Module]                INT           NULL,
    [FK_ModuleStatus]          INT           NULL,
    [RunDescription]           VARCHAR (4000) NULL,
    [ControlBitmask]           INT           NULL,
    [NotificationPending]      BIT           NULL,
    [ActivityStart]            DATETIME2 (1) NOT NULL,
    [ActivityEnd]              DATETIME2 (1) NOT NULL,
    [ExecutionID]              INT           NULL,
	[ModuleExecutionID]		   INT			NULL
);


GO
CREATE CLUSTERED INDEX [ix_ModuleActivity_History]
    ON [etl].[ModuleActivity_History]([ActivityEnd] ASC, [ActivityStart] ASC) WITH (DATA_COMPRESSION = PAGE);

