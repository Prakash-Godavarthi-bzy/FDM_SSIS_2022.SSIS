﻿CREATE TABLE [etl].[ModuleStatus] (
    [PK_ModuleStatus] INT           NOT NULL,
    [ModuleStatus]    VARCHAR (255) NULL,
    [ToRerun]         BIT           NULL,
    [ExecutionID]     INT           NULL,
    PRIMARY KEY CLUSTERED ([PK_ModuleStatus] ASC) WITH (FILLFACTOR = 90)
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Contains Boolean value for module status(0,1) for logicial use ', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleStatus', @level2type = N'COLUMN', @level2name = N'ToRerun';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'This stores status of Module for example Pending ,runing failed etc ', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleStatus', @level2type = N'COLUMN', @level2name = N'ModuleStatus';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary key of table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleStatus', @level2type = N'COLUMN', @level2name = N'PK_ModuleStatus';


GO
EXECUTE sp_addextendedproperty @name = N'Table definition', @value = N'Table is created for Module Status related data', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleStatus';

