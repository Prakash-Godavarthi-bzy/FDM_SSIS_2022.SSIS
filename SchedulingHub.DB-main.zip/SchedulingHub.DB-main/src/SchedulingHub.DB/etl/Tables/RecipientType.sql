﻿CREATE TABLE [etl].[RecipientType] (
    [PK_RecipientType] INT           NOT NULL,
    [RecipientType]    VARCHAR (255) NOT NULL,
    PRIMARY KEY CLUSTERED ([PK_RecipientType] ASC) WITH (FILLFACTOR = 90)
);

