﻿CREATE TABLE [etl].[Parameter] (
    [PK_Parameter]     INT           IDENTITY (1, 1) NOT NULL,
    [ParameterKey]     VARCHAR (255) NULL,
    [ParameterValue]   SQL_VARIANT   NULL,
    [ParameterType]    VARCHAR (255) NULL,
    [FK_Orchestration] INT           NULL,
    PRIMARY KEY CLUSTERED ([PK_Parameter] ASC),
    CONSTRAINT [FK_Parameter_Orchestration] FOREIGN KEY ([FK_Orchestration]) REFERENCES [etl].[Orchestration] ([PK_Orchestration])
);

