﻿CREATE TABLE [etl].[NotificationUser] (
    [FK_Notification]  INT NOT NULL,
    [FK_ReportUser]    INT NOT NULL,
    [FK_RecipientType] INT NULL,
    PRIMARY KEY CLUSTERED ([FK_Notification] ASC, [FK_ReportUser] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_NotificationUser_Notification] FOREIGN KEY ([FK_Notification]) REFERENCES [etl].[Notification] ([PK_Notification]),
    CONSTRAINT [FK_NotificationUser_RecipientType] FOREIGN KEY ([FK_RecipientType]) REFERENCES [etl].[RecipientType] ([PK_RecipientType]),
    CONSTRAINT [FK_NotificationUser_ReportUser] FOREIGN KEY ([FK_ReportUser]) REFERENCES [etl].[ReportUser] ([PK_ReportUser])
);

