﻿CREATE TABLE [etl].[ModuleHierarchy] (
    [PK_ModuleHierarchy] INT IDENTITY (1, 1) NOT NULL,
    [FK_Orchestration]   INT NULL,
    [FK_ParentModule]    INT NULL,
    [FK_ChildModule]     INT NULL,
    [TreeLevel]          INT NULL,
    PRIMARY KEY CLUSTERED ([PK_ModuleHierarchy] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_ModuleHierarchy_ChildModule] FOREIGN KEY ([FK_Orchestration], [FK_ChildModule]) REFERENCES [etl].[Module] ([FK_Orchestration], [PK_module]),
    CONSTRAINT [FK_ModuleHierarchy_Orchestration] FOREIGN KEY ([FK_Orchestration]) REFERENCES [etl].[Orchestration] ([PK_Orchestration]),
    CONSTRAINT [FK_ModuleHierarchy_ParentModule] FOREIGN KEY ([FK_Orchestration], [FK_ParentModule]) REFERENCES [etl].[Module] ([FK_Orchestration], [PK_module])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Foreign key of table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleHierarchy', @level2type = N'COLUMN', @level2name = N'FK_ChildModule';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Foreign key of table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleHierarchy', @level2type = N'COLUMN', @level2name = N'FK_ParentModule';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Foreign key of table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleHierarchy', @level2type = N'COLUMN', @level2name = N'FK_Orchestration';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary key of table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleHierarchy', @level2type = N'COLUMN', @level2name = N'PK_ModuleHierarchy';


GO
EXECUTE sp_addextendedproperty @name = N'Table definition', @value = N'Module Hierarchy and relationships between Modules are stared int this table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleHierarchy';

