﻿CREATE TABLE [etl].[OrchestrationActivity] (
    [PK_OrchestrationActivity] INT      IDENTITY (1, 1) NOT NULL,
    [FK_Orchestration]         INT      NULL,
    [ActivityStart]            DATETIME DEFAULT (getdate()) NULL,
    PRIMARY KEY CLUSTERED ([PK_OrchestrationActivity] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_OrchestrationActivity_Orchestration] FOREIGN KEY ([FK_Orchestration]) REFERENCES [etl].[Orchestration] ([PK_Orchestration])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Log Date of Orchestration Activity ', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'OrchestrationActivity', @level2type = N'COLUMN', @level2name = N'ActivityStart';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Foreign key of table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'OrchestrationActivity', @level2type = N'COLUMN', @level2name = N'FK_Orchestration';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary key of table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'OrchestrationActivity', @level2type = N'COLUMN', @level2name = N'PK_OrchestrationActivity';


GO
EXECUTE sp_addextendedproperty @name = N'Table definition', @value = N'This table created for Orchestration activity data', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'OrchestrationActivity';

