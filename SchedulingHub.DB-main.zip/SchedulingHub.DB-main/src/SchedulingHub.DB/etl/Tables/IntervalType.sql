﻿CREATE TABLE [etl].[IntervalType] (
    [PK_IntervalType] INT          NOT NULL,
    [IntervalType]    VARCHAR (50) NULL,
    [abbreviation]    VARCHAR (10) NULL,
    PRIMARY KEY CLUSTERED ([PK_IntervalType] ASC) WITH (FILLFACTOR = 90)
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TBC ', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'IntervalType', @level2type = N'COLUMN', @level2name = N'abbreviation';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TBC', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'IntervalType', @level2type = N'COLUMN', @level2name = N'IntervalType';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary key of table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'IntervalType', @level2type = N'COLUMN', @level2name = N'PK_IntervalType';


GO
EXECUTE sp_addextendedproperty @name = N'Table definition', @value = N'Table to stores data regarding intervals types', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'IntervalType';

