﻿CREATE TABLE [etl].[ControlGroup] (
    [FK_Orchestration] INT NOT NULL,
    [FK_module]        INT NOT NULL,
    [FK_ReportUser]    INT NOT NULL,
    [FK_AccessLevel]   INT NOT NULL,
    PRIMARY KEY CLUSTERED ([FK_Orchestration] ASC, [FK_module] ASC, [FK_ReportUser] ASC),
    CONSTRAINT [FK_ControlGroup_AccessLevel] FOREIGN KEY ([FK_AccessLevel]) REFERENCES [etl].[AccessLevel] ([PK_AccessLevel]),
    CONSTRAINT [FK_ControlGroup_Module] FOREIGN KEY ([FK_Orchestration], [FK_module]) REFERENCES [etl].[Module] ([FK_Orchestration], [PK_module])
);

