﻿CREATE TABLE [etl].[OrchestrationRunConfig](
	[PK_Config] [int] NOT NULL,
	[Dataset] [varchar](100) NOT NULL,
	[fk_Orchestration] [int] NOT NULL,
	[Source DB] [varchar](100) NOT NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [varchar](255) NOT NULL,
	[AuditHost] [varchar](255) NOT NULL,
 CONSTRAINT [PK_Config] PRIMARY KEY CLUSTERED 
(
	[PK_Config] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [etl].[OrchestrationRunConfig] ADD  CONSTRAINT [DF_config_AuditCreateDateTime]  DEFAULT (getdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [etl].[OrchestrationRunConfig] ADD  CONSTRAINT [DF_config_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [etl].[OrchestrationRunConfig] ADD  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO