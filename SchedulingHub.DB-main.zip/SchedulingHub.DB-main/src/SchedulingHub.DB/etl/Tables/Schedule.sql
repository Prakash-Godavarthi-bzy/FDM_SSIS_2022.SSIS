﻿CREATE TABLE [etl].[Schedule] (
    [PK_Schedule]     INT           IDENTITY (1, 1) NOT NULL,
    [Schedule]        VARCHAR (255) NULL,
    [StartDate]       SMALLDATETIME NULL,
    [FK_IntervalType] INT           NULL,
    [Interval]        INT           NULL,
    PRIMARY KEY CLUSTERED ([PK_Schedule] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_Schedule_IntervalType] FOREIGN KEY ([FK_IntervalType]) REFERENCES [etl].[IntervalType] ([PK_IntervalType])
);

