﻿CREATE TABLE [etl].[AuthorisationStatus] (
    [PK_AuthorisationStatus] INT           NOT NULL,
    [AuthorisationStatus]    VARCHAR (200) NULL,
    [DefaultModuleStatus]    INT           NULL,
    PRIMARY KEY CLUSTERED ([PK_AuthorisationStatus] ASC) WITH (FILLFACTOR = 90)
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Maps Authersation status to Module status', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'AuthorisationStatus', @level2type = N'COLUMN', @level2name = N'DefaultModuleStatus';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Contains Authorisation Status(Pending,Approvued etc)', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'AuthorisationStatus', @level2type = N'COLUMN', @level2name = N'AuthorisationStatus';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary key of table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'AuthorisationStatus', @level2type = N'COLUMN', @level2name = N'PK_AuthorisationStatus';


GO
EXECUTE sp_addextendedproperty @name = N'Table definition', @value = N'Table to store the different statuses available for  Authorisation', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'AuthorisationStatus';

