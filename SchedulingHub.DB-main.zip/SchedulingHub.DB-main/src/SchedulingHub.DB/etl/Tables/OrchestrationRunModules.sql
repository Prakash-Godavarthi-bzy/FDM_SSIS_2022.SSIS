﻿CREATE TABLE [etl].[OrchestrationRunModules](
	[PK_OrcModules] [int] NOT NULL,
	[fk_config] [int] NULL,
	[fk_Landing] [int] NULL,
	[PackageName] [varchar](255) NULL,
	[fk_Inbound] [int] NULL,
	[InboundProc] [varchar](255) NULL,
	[fk_Outbound] [int] NULL,
	[OutboundProc] [varchar](255) NULL,
	[fk_Extensions] [int] NULL,
	[ExtensionsProc] [varchar](255) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [varchar](255) NOT NULL,
	[AuditHost] [varchar](255) NOT NULL,
 CONSTRAINT [PK_OrcModules] PRIMARY KEY CLUSTERED 
(
	[PK_OrcModules] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [etl].[OrchestrationRunModules] ADD  CONSTRAINT [DF_Module_AuditCreateDateTime]  DEFAULT (getdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [etl].[OrchestrationRunModules] ADD  CONSTRAINT [DF_Module_AuditUserCreate]  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO

ALTER TABLE [etl].[OrchestrationRunModules] ADD  DEFAULT (CONVERT([nvarchar](255),serverproperty('MachineName'))) FOR [AuditHost]
GO

ALTER TABLE [etl].[OrchestrationRunModules] ADD  CONSTRAINT [FK_Config_Datasets] FOREIGN KEY([fk_config])
REFERENCES [etl].[OrchestrationRunConfig] ([PK_Config])
GO