﻿CREATE TABLE [etl].[Notification] (
    [PK_Notification] INT           IDENTITY (1, 1) NOT NULL,
    [Subject]         VARCHAR (130) NULL,
    [Body]            VARCHAR (MAX) NULL,
    PRIMARY KEY CLUSTERED ([PK_Notification] ASC) WITH (FILLFACTOR = 90)
);

