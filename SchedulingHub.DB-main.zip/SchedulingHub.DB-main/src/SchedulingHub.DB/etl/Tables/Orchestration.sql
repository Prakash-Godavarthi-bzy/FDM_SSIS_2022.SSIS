﻿CREATE TABLE [etl].[Orchestration] (
    [PK_Orchestration]  INT           NOT NULL,
    [OrchestrationName] VARCHAR (255) NULL,
    [FK_Schedule]       INT           NULL,
    [FK_Parameter]      INT           NULL,
    [IsEnabled]         BIT           DEFAULT ((0)) NULL,
    PRIMARY KEY CLUSTERED ([PK_Orchestration] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_Orchestration_Schedule] FOREIGN KEY ([FK_Schedule]) REFERENCES [etl].[Schedule] ([PK_Schedule])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N' This column contains Orchestration Name', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'Orchestration', @level2type = N'COLUMN', @level2name = N'OrchestrationName';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary key of table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'Orchestration', @level2type = N'COLUMN', @level2name = N'PK_Orchestration';


GO
EXECUTE sp_addextendedproperty @name = N'Table definition', @value = N'This table created for Orchestration data', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'Orchestration';

