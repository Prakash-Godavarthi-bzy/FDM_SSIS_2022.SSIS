﻿CREATE TABLE [etl].[ScheduleCalendar] (
    [PK_ScheduleCalendar] INT           IDENTITY (1, 1) NOT NULL,
    [FK_Schedule]         INT           NULL,
    [TargetDate]          SMALLDATETIME NULL,
    [TargetDescription]   VARCHAR (255) NULL,
    PRIMARY KEY CLUSTERED ([PK_ScheduleCalendar] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_ScheduleCalendar_Schedule] FOREIGN KEY ([FK_Schedule]) REFERENCES [etl].[Schedule] ([PK_Schedule])
);

