﻿CREATE TABLE [etl].[ModuleActivity] (
    [PK_ModuleActivity]        INT                                         IDENTITY (1, 1) NOT NULL,
    [FK_OrchestrationActivity] INT                                         NULL,
    [FK_Orchestration]         INT                                         NULL,
    [FK_Module]                INT                                         NULL,
    [FK_ModuleStatus]          INT                                         NULL,
    [RunDescription]           VARCHAR (4000)                               NULL,
    [ControlBitmask]           INT                                         NULL,
    [NotificationPending]      BIT                                         DEFAULT ((0)) NULL,
    [ActivityStart]            DATETIME2 (1) GENERATED ALWAYS AS ROW START NOT NULL,
    [ActivityEnd]              DATETIME2 (1) GENERATED ALWAYS AS ROW END   NOT NULL,
    [ExecutionID]              INT                                         NULL,
	[ModuleExecutionID]              INT                                   NULL,
    PRIMARY KEY CLUSTERED ([PK_ModuleActivity] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_ModuleActivity_Module] FOREIGN KEY ([FK_Orchestration], [FK_Module]) REFERENCES [etl].[Module] ([FK_Orchestration], [PK_module]),
    CONSTRAINT [FK_ModuleActivity_ModuleStatus] FOREIGN KEY ([FK_ModuleStatus]) REFERENCES [etl].[ModuleStatus] ([PK_ModuleStatus]),
    PERIOD FOR SYSTEM_TIME ([ActivityStart], [ActivityEnd])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[etl].[ModuleActivity_History]));


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Module Activity Date ', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleActivity', @level2type = N'COLUMN', @level2name = N'ActivityStart';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Boolean value Notification Pending ', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleActivity', @level2type = N'COLUMN', @level2name = N'NotificationPending';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'To be dropped', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleActivity', @level2type = N'COLUMN', @level2name = N'ControlBitmask';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N' Need to confirmed in future ', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleActivity', @level2type = N'COLUMN', @level2name = N'RunDescription';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Foreign key of table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleActivity', @level2type = N'COLUMN', @level2name = N'FK_ModuleStatus';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Foreign key of table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleActivity', @level2type = N'COLUMN', @level2name = N'FK_Module';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Foreign key of table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleActivity', @level2type = N'COLUMN', @level2name = N'FK_Orchestration';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Foreign key of table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleActivity', @level2type = N'COLUMN', @level2name = N'FK_OrchestrationActivity';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary key of table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleActivity', @level2type = N'COLUMN', @level2name = N'PK_ModuleActivity';


GO
EXECUTE sp_addextendedproperty @name = N'Table definition', @value = N'Table to stores data regarding Modules Activity', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleActivity';

