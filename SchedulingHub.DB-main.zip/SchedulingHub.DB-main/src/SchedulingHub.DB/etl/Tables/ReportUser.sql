﻿CREATE TABLE [etl].[ReportUser] (
    [PK_ReportUser] INT            IDENTITY (1, 1) NOT NULL,
    [Username]      VARCHAR (20)   NOT NULL,
    [FullName]      VARCHAR (255)  NULL,
    [EmailAddress]  VARCHAR (1000) NULL,
    PRIMARY KEY CLUSTERED ([PK_ReportUser] ASC) WITH (FILLFACTOR = 90)
);

