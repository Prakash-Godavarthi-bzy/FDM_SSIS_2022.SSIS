﻿CREATE TABLE [etl].[Authorisation] (
    [PK_Authorisation]       INT           IDENTITY (1, 1) NOT NULL,
    [FK_ModuleActivity]      INT           NULL,
    [AuthorisationDate]      DATETIME      DEFAULT (getdate()) NULL,
    [Authorisor]             VARCHAR (255) DEFAULT (original_login()) NULL,
    [FK_AuthorisationStatus] INT           NULL,
    CONSTRAINT [FK_Authorisation_AuthorisationStatus] FOREIGN KEY ([FK_AuthorisationStatus]) REFERENCES [etl].[AuthorisationStatus] ([PK_AuthorisationStatus]),
    CONSTRAINT [FK_Authorisation_ModuleActivity] FOREIGN KEY ([FK_ModuleActivity]) REFERENCES [etl].[ModuleActivity] ([PK_ModuleActivity])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N' Authorisation Date ', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'Authorisation', @level2type = N'COLUMN', @level2name = N'AuthorisationDate';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Foreign key of table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'Authorisation', @level2type = N'COLUMN', @level2name = N'FK_ModuleActivity';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary key of table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'Authorisation', @level2type = N'COLUMN', @level2name = N'PK_Authorisation';


GO
EXECUTE sp_addextendedproperty @name = N'Table definition', @value = N'Table to store the different statuses available for  Authorisation', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'Authorisation';

