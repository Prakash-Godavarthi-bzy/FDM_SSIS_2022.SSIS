﻿CREATE TABLE [etl].[ModuleType] (
    [PK_ModuleType] INT          NOT NULL,
    [ModuleType]    VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([PK_ModuleType] ASC) WITH (FILLFACTOR = 90)
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'This column stores type of Module for instance SSIS,SP OR Notification etc ', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleType', @level2type = N'COLUMN', @level2name = N'ModuleType';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary key of table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleType', @level2type = N'COLUMN', @level2name = N'PK_ModuleType';


GO
EXECUTE sp_addextendedproperty @name = N'Table definition', @value = N'This table contains types of Module', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'ModuleType';

