﻿CREATE TABLE [etl].[AccessLevel] (
    [PK_AccessLevel] INT          NOT NULL,
    [AccessLevel]    VARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([PK_AccessLevel] ASC) WITH (FILLFACTOR = 90)
);

