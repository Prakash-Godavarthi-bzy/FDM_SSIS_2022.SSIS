﻿CREATE TABLE [etl].[Module] (
    [FK_Orchestration]    INT            NOT NULL,
    [PK_module]           INT            NOT NULL,
    [ModuleName]          VARCHAR (255)  NULL,
    [FK_ModuleType]       INT            NULL,
    [FK_Schedule]         INT            NULL,
    [ModuleRoutine]       VARCHAR (2000)  NULL,
    [DestinationServer]   VARCHAR (2000) NULL,
    [DestinationDatabase] VARCHAR (255)  NULL,
    [FK_Notification]     INT            NULL,
    [DefaultResetStatus]  INT            NULL,
    PRIMARY KEY CLUSTERED ([FK_Orchestration] ASC, [PK_module] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_Module_ModuleStatus] FOREIGN KEY ([DefaultResetStatus]) REFERENCES [etl].[ModuleStatus] ([PK_ModuleStatus]),
    CONSTRAINT [FK_Module_ModuleType] FOREIGN KEY ([FK_ModuleType]) REFERENCES [etl].[ModuleType] ([PK_ModuleType]),
    CONSTRAINT [FK_Module_Notification] FOREIGN KEY ([FK_Notification]) REFERENCES [etl].[Notification] ([PK_Notification]),
    CONSTRAINT [FK_Module_Orchestration] FOREIGN KEY ([FK_Orchestration]) REFERENCES [etl].[Orchestration] ([PK_Orchestration]),
    CONSTRAINT [FK_Module_Schedule] FOREIGN KEY ([FK_Schedule]) REFERENCES [etl].[Schedule] ([PK_Schedule])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Destination Database', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'Module', @level2type = N'COLUMN', @level2name = N'DestinationDatabase';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Destination Server', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'Module', @level2type = N'COLUMN', @level2name = N'DestinationServer';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Routine of Module for instance USP', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'Module', @level2type = N'COLUMN', @level2name = N'ModuleRoutine';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Foreign key of table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'Module', @level2type = N'COLUMN', @level2name = N'FK_ModuleType';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Name of the Modle ', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'Module', @level2type = N'COLUMN', @level2name = N'ModuleName';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary key of table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'Module', @level2type = N'COLUMN', @level2name = N'PK_module';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Foreign key of table', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'Module', @level2type = N'COLUMN', @level2name = N'FK_Orchestration';


GO
EXECUTE sp_addextendedproperty @name = N'Table definition', @value = N'Table to stores data regarding Modules ', @level0type = N'SCHEMA', @level0name = N'etl', @level1type = N'TABLE', @level1name = N'Module';

