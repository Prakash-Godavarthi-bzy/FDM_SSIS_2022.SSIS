Param
	(
		[switch]
		$Install,
		[switch]
		$Update,
		[switch]
		$Build,
		[switch]
		$Test,
		[switch]
		$Pack,
		[switch]
		$Publish,
		[switch]
		$Release, #creates a new Octopus Deploy release for the Project
		[switch]
		$Vsix	
	) 

 
$SOURCE_NAME = "jfrog_nuget"
$AUTH_FILE_PATH = "jfrog_nuget.config"
$nuget_file_content = @"
<?xml version="1.0" encoding="utf-8"?>
<configuration>
	<packageSources>
	</packageSources>
</configuration>
"@
$nuget_deployments_server = $env:Artifactory_NuGetDeployments_URL
$nuget_server = $env:Artifactory_SaaS+"/artifactory/api/nuget/v2/nuget-local"
$nuget_deployments_api_key = $env:Artifactory_NuGet_API_Key
$nuget_api_key = $env:Artifactory_NuGet_API_Key

Function Register-Nuget-Server {
	Param(
		[string]
		$NugetPath = "C:\ProgramData\chocolatey\lib\NuGet.CommandLine\tools\NuGet.exe",
		[string]
		$source_name = $SOURCE_NAME,
		[string]
		$source_url = $nuget_server,
		[string]
		$nuget_username = $env:artifactorysaas_username,
		[string]
		$nuget_passwd = $env:artifactorysaas_reference_token,
		[string]
		$ConfigFilePath = $AUTH_FILE_PATH
	)

	$ScriptBlockContent = {
		& $NugetPath sources add -name $source_name -source $source_url -username $nuget_username -password $nuget_passwd -configfile $ConfigFilePath
	}
	if (!(Test-Path -Path $ConfigFilePath -PathType Leaf)) {
		New-Item -Path $ConfigFilePath -ItemType "file" -Force
		Set-Content -Path $ConfigFilePath -Value $nuget_file_content -Encoding UTF8
	}
	Write-Host "Register nuget server"
	Invoke-Command -ScriptBlock $ScriptBlockContent -ArgumentList $($NugetPath, $source_name, $source_url, $nuget_username, $nuget_passwd, $ConfigFilePath) -Verbose

}

Function Unregister-Nuget-Server {
	Param(
		[string]
		$NugetPath = "C:\ProgramData\chocolatey\lib\NuGet.CommandLine\tools\NuGet.exe",
		[string]
		$source_name = $SOURCE_NAME,
		[string]
		$ConfigFilePath = $AUTH_FILE_PATH
	)

	$ScriptBlockContent = {
		& $NugetPath sources remove -name $source_name -configfile $ConfigFilePath
	}
	Write-Host "Unregister nuget server"
	Invoke-Command -ScriptBlock $ScriptBlockContent -ArgumentList $($NugetPath, $source_name, $ConfigFilePath) -Verbose
}

Function NuGet-Install {
	Param(
		[string]
		$OutDir=".",
		[string]
		$NugetPath = "C:\ProgramData\chocolatey\lib\NuGet.CommandLine\tools\NuGet.exe",
		[string]$AUTH_FILE_PATH = $AUTH_FILE_PATH
	)

	$ScriptBlockContent = {
		& $NugetPath install -ExcludeVersion -OutputDir $OutDir -configfile $AUTH_FILE_PATH
	}

	Invoke-Command -ScriptBlock $ScriptBlockContent -ArgumentList $($NugetPath, $Source, $ApiKey, $Path, $AUTH_FILE_PATH) -Verbose
}

# Register the JFrog nuget server at the begining of installation on pack and install tasks
if ($Install -or $Pack) {
	Register-Nuget-Server

}

function Add-OctopusDeployRelease {
	[CmdletBinding()]
	Param(
		[Parameter(Mandatory=$true)]
        [string]
		$ProjectName, 
		[Parameter(Mandatory=$true)]
		[string]
		$Version, 
		[Parameter(Mandatory=$true)]
		[string]
		$Packageversion, 
		[Parameter(Mandatory=$true)]
		[string]
		$OctopusDeployServer,
		[Parameter(Mandatory=$true)]
		[string]
		$OctopusDeployAPIKey,
		[string]
		$OctoLocation = "C:\ProgramData\chocolatey\lib\OctopusTools\tools\octo.exe",
		[switch]
		$LocalBuild,
		[string]
		$OctopusChannel
	)

	Write-Host @"
			Options:
				ProjectName = $ProjectName
				Version = $Version
				PackageVersion = $Packageversion
				OctopusDeployServer = $OctopusDeployServer
				OctopusChannel = $OctopusChannel
"@

	# Check for octo.exe
	If (Test-Path $OctoLocation) {
		Write-Host "octo.exe found: $OctoLocation"
	} Else {
		Write-Warning "octo.exe not found at $OctoLocation"
		[Environment]::Exit(1)
	}
	
	Create-Release-Notes -Version $Version
		
	If ($LocalBuild) {
		Write-Warning "Local build - octopus release not created"
	} Else {

		$ScriptBlockContent = $null
		if($OctopusChannel) {
			$ScriptBlockContent = {
				& $OctoLocation create-release --project `"$ProjectName`" --version $Version --packageVersion $PackageVersion --server $OctopusDeployServer --apiKey $OctopusDeployAPIKey --releasenotesfile ".\release-notes.md" --channel $OctopusChannel
			}
		} else {
			$ScriptBlockContent = {
				& $OctoLocation create-release --project `"$ProjectName`" --version $Version --packageVersion $PackageVersion --server $OctopusDeployServer --apiKey $OctopusDeployAPIKey --releasenotesfile ".\release-notes.md"
			}
		}

		

		Invoke-Command -ScriptBlock $ScriptBlockContent -ArgumentList $($OctoLocation, $ProjectName, $Version, $PackageVersion, $OctopusDeployServer,  $OctopusDeployAPIKey) -Verbose | Tee-Object -Variable result
		
		If($result) {
			$message =  $result | Out-String

			If (-Not $message.Contains("created successfully!")) {
				Write-Error $message

				# stop build process
				[Environment]::Exit(1)
			}
		}
	}
}


#Install dependencies	
$modulePath = ".\BuildTools.DB"
If (-Not (Test-Path $modulePath)) {
	# TODO: find NuGet proper location
	NuGet-Install
}
	
# Import dependencies	
Import-Module "$modulePath\buildtoolsdb-helpers.ps1"

# print all variables
# Get-Childitem -Path Env:* | Sort-Object Name

# set env variables

$octopus_server = $env:Octopus_Server
$octopus_api_key = $env:Octopus_API_Key
$version = $env:BUILD_NUMBER
$projectName = $env:db_project_name
$buildAgent = $env:BUILD_AGENT
$branch = $env:Branch_Name
$ghe_token = $env:GITHUB_ENTERPRISE_TOKEN

$sonar_url = $env:Sonar_Url
$gitOrganization = $env:Git_Organization
$gitRepository = $env:Git_Repository
$gitEndpoint = $env:Git_Endpoint

# multiple channel config
$multipleChannels = $env:Multiple_Channels
$channels = $null
$prereleaseTag = $false

# set variables
$src = ""
If (Test-Path "src") {
	$src = "src\"
}

if($multipleChannels) {
	$channels = $multipleChannels -Split ";"
}

$buildOutputPath = "BuildOutput"
$packagePath = "$src$projectName\$projectName.nuspec"
$vsixPackagePath = "$src$projectName.vsix\$projectName.vsix.nuspec"
$outDir = "$buildOutputPath\$projectName\"
$vsixOutDir = "$buildOutputPath\$projectName.Installer\"
$config = "Release"
$localBuild = $false
$pullRequestNo = $null
$preview = $true


"nuget_deployments_server: $nuget_deployments_server"
"nuget_server: $nuget_server"
"nuget_deployments_api_key: $env:Nuget_Deployments_Api_Key"
"nuget_api_key: $env:NuGet_Api_Key"
"octopus_server: $env:Octopus_Server"
"octopus_api_key: $env:Octopus_API_Key"
"version: $env:BUILD_NUMBER"
"projectName: $env:db_project_name"
"buildAgent: $env:BUILD_AGENT"
"branch: $env:Branch_Name"
"ghe_token: $env:GITHUB_ENTERPRISE_TOKEN"
"sonar_url: $env:Sonar_Url"
"gitOrganization: $env:Git_Organization"
"gitRepository: $env:Git_Repository"
"gitEndpoint: $env:Git_Endpoint"
"buildOutputPathBuildOutput"
"packagePath: $src$projectName\: $projectName.nuspec"
"vsixPackagePath: $src$projectName.vsix\: $projectName.vsix.nuspec"
"outDir: $buildOutputPath\: $projectName\"
"vsixOutDir: $buildOutputPath\: $projectName.Installer\"
"configRelease"
"localBuild: $false"
"pullRequestNo: $null"
"preview: $true"

If (-Not $version) {
	$version = "1.0.0"
}
  
# init, build and validate, publish

If(-Not $buildAgent) {
	$localBuild = $true
}

If($branch) {
	If($branch.EndsWith("/merge")) {
		$pullRequestNo = $branch.Split('/')[0]
	} Else {
		$preview = $false
	}
}

# Install dependencies
If ($Install) {
	Choco-Project
}

	
# Build project
If ($Build) {
	# clean build output
	If(Test-Path $buildOutputPath) {
	  Remove-Item -Force -Recurse $buildOutputPath
	}

	# Build project
	Write-Host "##teamcity[blockOpened name='Build-Project' description=' $projectName']"
	Build-Project -ProjectName $projectName -LocalBuild:$localBuild
	Write-Host "##teamcity[blockClosed name='Build-Project']"

	#If($Test) {
		#$testProject = "$projectName.Tests"
		#Write-Host "##teamcity[blockOpened name='Build-Project' description='$testProject']"
		#Build-Project -ProjectName "$testProject" -LocalBuild:$localBuild
		#Write-Host "##teamcity[blockClosed name='Build-Project']"
	#}

	# Static Code Analysis
	Write-Host "##teamcity[blockOpened name='Static Code Analysis' description='sonar-project.properties']"
	$sonarOptions = @{
			Preview = $preview
			SonarUrl = $sonar_url
			Version = $version
			PullRequestNo = $pullRequestNo
			GitOrganization = $gitOrganization
			GitRepository = $gitRepository
			GitOauth = $ghe_token
			GitEnpoint = $gitEndpoint
		}
	Sonar-Project @sonarOptions
	Write-Host "##teamcity[blockClosed name='Static Code Analysis']"


	#unit tests here?


}

#If ($Test) {
	# Test project
	#Write-Host "##teamcity[blockOpened name='Test-Project' description='$projectName']"
	#Test-Project -ProjectName $projectName 
	#Write-Host "##teamcity[blockClosed name='Test-Project']"
#}

# Pack and publish package
If ($Pack) {
	Write-Host "##teamcity[blockOpened name='Pack-Project' description='Pack project']"
	Pack-Project-Saas -Path $packagePath -Version $version -ProjectName $projectName -OutDir $outDir -Configfile $AUTH_FILE_PATH
	Write-Host "##teamcity[blockClosed name='Pack-Project']"

	If($Vsix){
	Write-Host "##teamcity[blockOpened name='Pack-Project' description='Pack project']"
	Pack-Project-Saas -Path $vsixPackagePath -Version $version -ProjectName "$projectName.Installer" -OutDir $vsixOutDir -Configfile $AUTH_FILE_PATH
	Write-Host "##teamcity[blockClosed name='Pack-Project']"
	}
}

# Publish Nuget
If ($Publish) {
	Write-Host "##teamcity[blockOpened name='Publish-Project' description='Pack project']"
	Publish-Package -Path $outDir -Source $nuget_deployments_server"/"$projectName -ApiKey $nuget_deployments_api_key
	Write-Host "##teamcity[blockClosed name='Publish-Project']"

	If($Vsix){
	Write-Host "##teamcity[blockOpened name='Publish-Project' description='Pack project']"
	Publish-Package -Path $vsixOutDir -Source $nuget_server"/"$projectName -ApiKey $nuget_api_key
	Write-Host "##teamcity[blockClosed name='Publish-Project']"
	}
}

# Create Octopus Deploy new release
If ($Release) {
	If ($preview) {
		$result = Create-Release-Notes -Version $version
	# } Else {
	# 	# replace alpha if pre-release build
	# 	#$releaseNumber = $version.Replace("-alpha", "")
	# 	$packageVersion = $version.Split("-")[0]
	# 	Write-Host "##teamcity[blockOpened name='Octopus-Release' description='Release project']"

    #     if($version.Split("-")[1])
	#     {
	#         $packageVersion = $version
	#     }

	# 	$octopusOptions = @{
	# 		ProjectName = $projectName
	# 		Version = $version
	# 		PackageVersion = $packageVersion
	# 		OctopusDeployServer = $octopus_server
	# 		OctopusDeployAPIKey = $octopus_api_key
	# 	}
	# 	Create-Octopus-Release @octopusOptions
		
	# 	Write-Host "##teamcity[blockClosed name='Octopus-Release']"
	# }

	} Else {
		# replace alpha if pre-release build
		#$releaseNumber = $version.Replace("-alpha", "")
		
		$packageVersion = $version.Split("-")[0]
		Write-Host "##teamcity[blockOpened name='Octopus-Release' description='Release project']"

		if($version.Split("-")[1])
		{
			$packageVersion = $version
			$prereleaseTag = $true
		}

		$octopusOptions = @{
			ProjectName = $projectName
			Version = $version
			PackageVersion = $packageVersion
			OctopusDeployServer = $octopus_server
			OctopusDeployAPIKey = $octopus_api_key
			OctopusChannel = $null
		}

		#Create-Octopus-Release @octopusOptions
		# create default release
		Add-OctopusDeployRelease @octopusOptions

		if(($channels) -and (-not $prereleaseTag)) {
			Write-Host "Create release for multiple channels"
			foreach ($channel in $channels) {
				Write-Host "##teamcity[blockOpened name='Octopus-Release Channel $($channel)']"
				$octopusOptions.OctopusChannel = $channel
				$octopusOptions.Version = $version + "-" + $channel
				Add-OctopusDeployRelease @octopusOptions
				Write-Host "##teamcity[blockClosed name='Octopus-Release Channel $($channel)']"
			}
		}
		
		
		Write-Host "##teamcity[blockClosed name='Octopus-Release']"
	}
} 


# Unregister on completion

if ($Install -or $Pack) {

	Unregister-Nuget-Server -source_name $SOURCE_NAME -ConfigFilePath $AUTH_FILE_PATH

}
