﻿CREATE TABLE Util.Configuration (
     PK_Configuration      SMALLINT      IDENTITY (1, 1) NOT NULL
    ,Question              VARCHAR(50)   NOT NULL
    ,Answer                VARCHAR(50)   NOT NULL
    ,Description           VARCHAR(100)  NOT NULL
    ,AuditCreateDateTime   DATETIME2(2)  CONSTRAINT DF_Configuration_AuditCreateDateTime DEFAULT (GETUTCDATE())  NOT NULL
    ,AuditModifyDateTime   DATETIME2(2)  NULL
    ,AuditUserCreate       VARCHAR(64)   CONSTRAINT DF_Configuration_AuditUserCreate     DEFAULT (SUSER_SNAME()) NOT NULL
    ,AuditUserModify       VARCHAR(64)   NULL
    ,PRIMARY KEY CLUSTERED (PK_Configuration ASC) WITH (FILLFACTOR = 90)
);

GO

----------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Table and columns documentation
----------------------------------------------------------------------------------------------------------------------------------------------------------------

EXECUTE sp_addextendedproperty 
         @name           = N'Table definition'
        ,@value          = N'Table to store parameters/values that are used across the various logging framework SQL objects.'
        ,@level0type     = N'SCHEMA'
        ,@level0name     = N'Util'
        ,@level1type     = N'TABLE'
        ,@level1name     = N'Configuration';
GO

-- COLUMNS

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'The name of the configuration parameter.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Util'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Configuration'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'Question';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'The value of the configuration parameter.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Util'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Configuration'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'Answer';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'The description of the configuration parameter.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Util'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Configuration'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'Description';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to stamp date the records inserted in the table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Util'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Configuration'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditCreateDateTime';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to track updates by date and time in the date'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Util'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Configuration'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditModifyDateTime';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to record the users,including service accounts that insert the records in the table'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Util'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Configuration'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditUserCreate';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to track updates by user in the table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Util'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Configuration'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditUserModify';

