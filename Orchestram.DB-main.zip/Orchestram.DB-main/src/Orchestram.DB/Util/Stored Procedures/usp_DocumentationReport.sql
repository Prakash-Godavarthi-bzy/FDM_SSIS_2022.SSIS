﻿
-- =============================================
-- Author:		Ciprian Mandras
-- Create date: 2019.07.16
-- Description:	Used to log activities in the system
-- =============================================

CREATE PROCEDURE Util.usp_DocumentationReport 
	 @p_Catalog 				VARCHAR(100)		
	,@p_Level					VARCHAR(20)			
	,@p_SchemaName 				VARCHAR(20)			= NULL
	,@p_ObjectName 				VARCHAR(100)		= NULL
	,@p_ColumnName 				VARCHAR(100)		= NULL
	
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @v_ErrorMessage NVARCHAR(4000)	
	DECLARE @v_SQL          NVARCHAR(4000)	

	SELECT @v_SQL = 'SELECT * FROM ' + @p_Catalog + '.sys.fn_listextendedproperty (NULL,' 
						+ CASE WHEN @p_Level = 'Database'	
							THEN 'NULL,NULL,NULL,NULL,NULL,NULL)'
							ELSE 
								CASE 
									WHEN (@p_Level = 'Schema') AND (@p_SchemaName IS NULL)	THEN '''SCHEMA'',NULL,NULL,NULL,NULL,NULL)'
									WHEN (@p_Level = 'Schema')								THEN '''SCHEMA'',''' + @p_SchemaName + ''',NULL,NULL,NULL,NULL)'
									ELSE  
										CASE 
											WHEN (@p_Level <> 'Column') AND (@p_ObjectName IS NULL)	THEN '''SCHEMA'',''' + @p_SchemaName + ''',''' + @p_Level + ''',NULL,NULL,NULL)'
											WHEN (@p_Level <> 'Column')								THEN '''SCHEMA'',''' + @p_SchemaName + ''',''' + @p_Level + ''',''' + @p_ObjectName + ''',NULL,NULL)'
											WHEN (@p_Level = 'Column')  AND (@p_ColumnName IS NULL)	THEN '''SCHEMA'',''' + @p_SchemaName + ''',''TABLE'',''' + @p_ObjectName + ''',''COLUMN'',NULL)'
											WHEN (@p_Level = 'Column')								THEN '''SCHEMA'',''' + @p_SchemaName + ''',''TABLE'',''' + @p_ObjectName + ''',''COLUMN'',''' + @p_ColumnName + ''')'
										END
								END
						  END

	EXEC SP_EXECUTESQL @v_SQL 	
		
END
GO
EXECUTE sp_addextendedproperty @name = N'Stored Procedure Parameters', @value = N'Input:

					@p_Catalog – VARCHAR(100) - NOT NULL:
					Database/ Catalog name on which we will search.

					@p_Level – VARCHAR(20) - NOT NULL:
					Level on which the report will return results.

					@p_SchemaName – VARCHAR(20) - NULL:
					Schema name on which the report will return results.

					@p_ObjectName – VARCHAR(100) - NULL:
					Object name that the report will return as result.

					@p_ColumnName – VARCHAR(100) - NULL:
					Column name that the report will return as result.', @level0type = N'SCHEMA', @level0name = N'Util', @level1type = N'PROCEDURE', @level1name = N'usp_DocumentationReport';


GO
EXECUTE sp_addextendedproperty @name = N'Stored Procedure Definition', @value = N'The procedure can be called by developers to understand the usage of objects in a database.', @level0type = N'SCHEMA', @level0name = N'Util', @level1type = N'PROCEDURE', @level1name = N'usp_DocumentationReport';


GO
EXECUTE sp_addextendedproperty @name = N'Stored Procedure Call', @value = N'The procedure can be called by developers to understand the usage of objects in a database.', @level0type = N'SCHEMA', @level0name = N'Util', @level1type = N'PROCEDURE', @level1name = N'usp_DocumentationReport';

