﻿
CREATE PROCEDURE Util.usp_DocRep (
	 @pObjType				VARCHAR(50)	= NULL
	,@pDatabase				VARCHAR(50)	= NULL
	,@pName					VARCHAR(50)	= NULL
	,@pEPName				VARCHAR(50)	= NULL
	,@pEPValue				VARCHAR(50) = NULL
	)
AS

BEGIN

		DECLARE	  @ObjLevel					INT
				 ,@NrOrd					INT
				 ,@SQL_Run					NVARCHAR(MAX)

		DECLARE @Levels TABLE
				(
				  NrOrd						INT IDENTITY (1,1)
				 ,ObjLevel					INT
				 ,Level0Name				NVARCHAR(50)
				 ,Level1Name				NVARCHAR(50)
				 ,Level2Name				NVARCHAR(50)
				 ,Level3Name				NVARCHAR(50)
				 ,EPName					NVARCHAR(50)
				 ,EPValue					NVARCHAR(MAX)
				 ,IsCommitted				TINYINT
				 )

		INSERT INTO @Levels

		SELECT	 ObjLevel				= 0
				,Level0Name				= name
				,Level1Name				= NULL
				,Level2Name				= NULL
				,Level3Name				= NULL
				,EPName					= NULL
				,EPValue				= NULL
				,IsCommitted			= 0
		FROM sys.databases

		WHERE name NOT IN ('master','tempdb','model','msdb','ForRecovery','BZYDBA','SSISDB','Oliver')

		--SELECT *
		--FROM @Levels

		WHILE EXISTS (SELECT TOP 1 1 
						FROM @Levels
						WHERE IsCommitted = 0)
		BEGIN

			SELECT TOP 1 
				 @NrOrd = NrOrd
				,@ObjLevel = ObjLevel
			FROM @Levels
			WHERE IsCommitted = 0

			----------------------
			IF @ObjLevel = 0
				SELECT @SQL_Run = 'SELECT 1, ''' + Level0Name + ''', objname , NULL, NULL, CAST(name as NVARCHAR(50)), CAST(value as NVARCHAR(MAX)), 0 
									FROM ' + Level0Name + '.sys.fn_listextendedproperty (NULL,''SCHEMA'',NULL,NULL,NULL,NULL,NULL)'
					FROM @Levels
					WHERE NrOrd = @NrOrd
	

			IF @ObjLevel = 1
				SELECT @SQL_Run = 'SELECT 2, ''' + Level0Name + ''', ''' + Level1Name + ''', objname, NULL, CAST(name as NVARCHAR(50)), CAST(value as NVARCHAR(MAX)), 0 
									FROM ' + Level0Name + '.sys.fn_listextendedproperty (NULL,''SCHEMA'',''' + Level1Name + ''',''TABLE'',NULL,NULL,NULL)
									UNION
									SELECT -2, ''' + Level0Name + ''', ''' + Level1Name + ''', objname, NULL, CAST(name as NVARCHAR(50)), CAST(value as NVARCHAR(MAX)), 0 
									FROM ' + Level0Name + '.sys.fn_listextendedproperty (NULL,''SCHEMA'',''' + Level1Name + ''',''PROCEDURE'',NULL,NULL,NULL)'
				FROM @Levels
				WHERE NrOrd = @NrOrd


			IF @ObjLevel = 2
				SELECT @SQL_Run = 'SELECT 3, ''' + Level0Name + ''', ''' + Level1Name + ''', '''  + Level2Name + ''', objname, CAST(name as NVARCHAR(50)), CAST(value as NVARCHAR(MAX)), 1 
									FROM ' + Level0Name + '.sys.fn_listextendedproperty (NULL,''SCHEMA'',''' + Level1Name + ''',''TABLE'',''' + Level2Name + ''',''COLUMN'',NULL)'
				FROM @Levels
				WHERE NrOrd = @NrOrd


			INSERT INTO @Levels

			EXEC SP_EXECUTESQL @Statement = @SQL_Run

			----------------------

			UPDATE r
			SET IsCommitted = 1
			FROM @Levels r
			WHERE NrOrd = @NrOrd

		END

		SELECT DISTINCT 
				 ObjectType		= CASE	
									WHEN ObjLevel = 1	THEN 'Schema'
									WHEN ObjLevel = 2	THEN 'Table'
									WHEN ObjLevel = -2	THEN 'Procedure'
									WHEN ObjLevel = 3	THEN 'Column'
									ELSE '-'
								  END
				,ObjectName		= ISNULL(Level1Name,'') + ISNULL('.' + Level2Name,'') + ISNULL('.' + Level3Name,'')
				,ColumnName		= Level3Name
				,EPName			= EPName
				,EPValue		= EPValue
				,ObjLevel		= ABS(ObjLevel)
				,DatabaseName	= Level0Name

		FROM @Levels

		WHERE EPValue		IS NOT NULL
			AND ObjLevel	= CASE
								WHEN @pObjType IS NULL			THEN ObjLevel
								WHEN @pObjType = 'Schema'		THEN 1
								WHEN @pObjType = 'Table'		THEN 2
								WHEN @pObjType = 'Procedure'	THEN -2
								WHEN @pObjType = 'Column'		THEN 3
							  END	
			AND ISNULL(Level1Name,'') + ISNULL('.' + Level2Name,'') + ISNULL('.' + Level3Name,'') LIKE '%' + ISNULL(@pName,'') + '%'
			AND Level0Name	LIKE '%' + ISNULL(@pDatabase,Level0Name) + '%'
			AND EPName		LIKE '%' + ISNULL(@pEPName,EPName) + '%'
			AND EPValue		LIKE '%' + ISNULL(@pEPValue,EPValue) + '%'
		ORDER BY Level0Name, ABS(ObjLevel), 2
END