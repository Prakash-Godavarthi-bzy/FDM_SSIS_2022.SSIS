﻿EXECUTE sp_addextendedproperty @name = N'Version', @value = N'2.0.23';

