﻿CREATE SCHEMA [Lin]
    AUTHORIZATION [dbo];


GO

EXEC sys.sp_addextendedproperty 
	 @name			=N'Schema usage'
	,@value			=N'This schema will be used for lineage framework tables' 
	,@level0type	=N'SCHEMA'
	,@level0name	=N'Lin'
GO
