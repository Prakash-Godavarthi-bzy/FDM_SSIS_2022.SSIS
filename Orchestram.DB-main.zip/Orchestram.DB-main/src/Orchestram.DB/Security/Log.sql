﻿CREATE SCHEMA [Log]
    AUTHORIZATION [dbo];





GO

EXEC sys.sp_addextendedproperty 
	 @name			=N'Schema usage'
	,@value			=N'This schema will be used for audit purposes' 
	,@level0type	=N'SCHEMA'
	,@level0name	=N'Log'
GO