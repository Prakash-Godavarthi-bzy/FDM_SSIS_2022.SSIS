﻿CREATE SCHEMA [Util]
    AUTHORIZATION [dbo];



GO

EXEC sys.sp_addextendedproperty 
	 @name			=N'Schema usage'
	,@value			=N'This schema will be used for various tables' 
	,@level0type	=N'SCHEMA'
	,@level0name	=N'Util'
GO