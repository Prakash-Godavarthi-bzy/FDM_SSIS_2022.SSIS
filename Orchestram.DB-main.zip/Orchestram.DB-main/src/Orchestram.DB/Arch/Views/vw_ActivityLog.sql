﻿
CREATE VIEW Arch.vw_ActivityLog 
WITH SCHEMABINDING 
AS

SELECT PK_ActivityLogArchive
      ,PK_ActivityLog
      ,FK_ParentActivityLog
      ,ActivitySource
      ,ActivityType
      ,ActivityStatus
      ,ActivityHost
      ,ActivityDatabase
      ,ActivityJobId
      ,ActivitySSISExecutionId
      ,ActivityName
      ,ActivityStartDateTime
      ,ActivityEndDateTime
      ,ActivityDuration
      ,ActivityErrorCode
	  ,AffectedRows 
      ,AuditCreateDateTime
      ,AuditModifyDateTime
      ,AuditUserCreate
      ,AuditUserModify
	  
FROM Arch.ActivityLog 
GO

EXECUTE sp_addextendedproperty 
		 @name = N'View Definition'
		,@value = N'This view is just a simple SELECT from the Arch.ActivityLog table for all columns.
					•	Remarks: hint to be used in all table selects/joins.'
		,@level0type = N'SCHEMA'
		,@level0name = N'Arch'
		,@level1type = N'VIEW'
		,@level1name = N'vw_ActivityLog';

