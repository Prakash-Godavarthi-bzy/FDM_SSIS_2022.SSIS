﻿CREATE TABLE [dbo].[DeploymentHistory]
(
	ID int IDENTITY(1, 1) PRIMARY KEY,
	Release_Version_No VARCHAR(50) NOT NULL,
    DateofDeployment DATETIME NOT NULL,
    Component VARCHAR(250) NOT NULL,
    ServerName VARCHAR(50) NOT NULL,
	ReleaseNotes NVARCHAR(MAX) NOT NULL
)
