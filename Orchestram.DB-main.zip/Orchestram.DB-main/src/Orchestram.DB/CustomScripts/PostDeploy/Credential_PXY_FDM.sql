﻿--IF NOT EXISTS (SELECT * FROM master.sys.syslogins WHERE name = '#{FDMProxy}')
--	CREATE LOGIN [#{FDMProxy}] FROM WINDOWS WITH DEFAULT_DATABASE=[master]

--IF EXISTS (SELECT * FROM sys.sysusers s WHERE name = '#{FDMProxy}')
--	DROP USER [#{FDMProxy}]

--CREATE USER [#{FDMProxy}] FOR LOGIN [#{FDMProxy}] WITH DEFAULT_SCHEMA=[dbo]
--ALTER ROLE db_owner ADD MEMBER [#{FDMProxy}]