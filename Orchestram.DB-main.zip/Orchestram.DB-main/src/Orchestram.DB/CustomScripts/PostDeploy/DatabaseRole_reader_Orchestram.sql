USE Orchestram 													
GO

DECLARE @role_name SYSNAME = 'DatabaseRole_reader_Orchestram'        

IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE type_desc = 'DATABASE_ROLE' AND name = @role_name)
EXEC('CREATE ROLE ['+@role_name+']')

-- Add the grants here
EXEC('GRANT SELECT ON [Log].[vw_ActivityLog] TO ['+@role_name+']')
EXEC('GRANT SELECT ON [Arch].[vw_ActivityLog] TO ['+@role_name+']')
EXEC('GRANT EXECUTE ON [Util].[udf_DateTimeDuration] TO ['+@role_name+']')
EXEC('GRANT EXECUTE ON [Log].[usp_ActivityLogReport] TO ['+@role_name+']')
