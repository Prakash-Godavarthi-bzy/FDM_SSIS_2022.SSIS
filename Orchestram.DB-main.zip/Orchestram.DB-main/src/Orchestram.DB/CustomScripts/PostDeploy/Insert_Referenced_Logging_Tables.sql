--USE Orchestram

--DELETE FROM [Log].[ActivitySource]
--DBCC CHECKIDENT ('[Log].[ActivitySource]',RESEED,0)

--DELETE FROM [Log].[ActivityStatus]
--DBCC CHECKIDENT ('[Log].[ActivityStatus]',RESEED,0)

--DELETE FROM [Log].[ActivityType]
--DBCC CHECKIDENT ('[Log].[ActivityType]',RESEED,0)

--TRUNCATE TABLE [Utility].[Configuration]

	MERGE	[Log].[ActivitySource] tgt
	USING	(
				SELECT	1,'IFRS17'
				UNION SELECT 2,'DataContract'
				UNION SELECT 3,'FDM'
				UNION SELECT 4,'SchedulingHub'
				UNION SELECT 5,'LandingDB'
				UNION SELECT 6,'TechnicalHub'
			) src (PK_ActivitySource, ActivitySource) 
	ON src.PK_ActivitySource = tgt.PK_ActivitySource
	WHEN	MATCHED
	THEN	UPDATE SET tgt.ActivitySource = src.ActivitySource
	WHEN	NOT MATCHED BY TARGET
	THEN	INSERT (PK_ActivitySource, ActivitySource)
			VALUES (src.PK_ActivitySource, src.ActivitySource)
	WHEN	NOT MATCHED BY SOURCE
	THEN	DELETE;

	MERGE	[Log].ActivityStatus tgt
	USING	(
				SELECT	1,'STARTED'
				UNION SELECT 2,'SUCCEEDED'
				UNION SELECT 3,'STOPPED'
				UNION SELECT 4,'ERRORED'
				UNION SELECT 5,'INFORMATION'
			) src (PK_ActivityStatus, ActivityStatus)
	ON		src.PK_ActivityStatus = tgt.PK_ActivityStatus
	WHEN	MATCHED
	THEN	UPDATE SET tgt.ActivityStatus = src.ActivityStatus
	WHEN	NOT MATCHED BY TARGET
	THEN	INSERT (PK_ActivityStatus, ActivityStatus)
			VALUES (src.PK_ActivityStatus, src.ActivityStatus)
	WHEN	NOT MATCHED BY SOURCE
	THEN	DELETE;

IF NOT EXISTS (SELECT TOP 1 1 FROM [Log].[ActivityType] WHERE PK_ActivityType = 1)
	INSERT INTO [Log].[ActivityType]
		(PK_ActivityType,ActivityType)
	VALUES	
		(1,'Automated process')

IF NOT EXISTS (SELECT TOP 1 1 FROM [Log].[ActivityType] WHERE PK_ActivityType = 2)
	INSERT INTO [Log].[ActivityType]
		(PK_ActivityType,ActivityType)
	VALUES	
		(2,'Manual process')

IF NOT EXISTS (SELECT TOP 1 1 FROM [Log].[ActivityType] WHERE PK_ActivityType = 3)
	INSERT INTO [Log].[ActivityType]
		(PK_ActivityType,ActivityType)
	VALUES	
		(3,'Data Quality')

IF NOT EXISTS (SELECT TOP 1 1 FROM [Log].[ActivityType] WHERE PK_ActivityType = 4)
	INSERT INTO [Log].[ActivityType]
		(PK_ActivityType,ActivityType)
	VALUES	
		(4,'Reconciliation')

IF NOT EXISTS (SELECT TOP 1 1 FROM [Log].[ActivityType] WHERE PK_ActivityType = 5)
	INSERT INTO [Log].[ActivityType]
		(PK_ActivityType,ActivityType)
	VALUES	
		(5,'Info')

IF NOT EXISTS (SELECT TOP 1 1 FROM [Util].[Configuration] WHERE Question = 'ArchiveActivityLogCutOffDays')
	INSERT INTO [Util].[Configuration]
		(Question,Answer,Description)
	VALUES	
			('ArchiveActivityLogCutOffDays','7','Will control the cutoff date to select which data can be archived')

IF NOT EXISTS (SELECT TOP 1 1 FROM [Util].[Configuration] WHERE Question = 'EurobaseDefaultBrokeragePercentage')
	INSERT INTO [Util].[Configuration]
		(Question,Answer,Description)
	VALUES	
			('EurobaseDefaultBrokeragePercentage','20.00','The default value to be used for brokerage when LPSO data are pulled and information is missing')


IF NOT EXISTS (SELECT TOP 1 1 FROM [Util].[Configuration] WHERE Question = 'EurobaseFirstYearToLoad')
	INSERT INTO [Util].[Configuration]
		(Question,Answer,Description)
	VALUES	
			('EurobaseFirstYearToLoad','2004','The year from which we upload the data from LPSO in IFRS17')
