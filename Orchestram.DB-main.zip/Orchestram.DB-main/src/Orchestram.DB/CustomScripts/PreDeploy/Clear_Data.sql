-- COMMENT AFTER FIRST RUN

USE Orchestram

--DELETE FROM [Archive].[ActivityLog]
--DELETE FROM [Log].[ActivityLog]
