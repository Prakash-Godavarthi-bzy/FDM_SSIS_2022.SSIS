﻿CREATE TABLE Rec.[CheckpointQuery] (
     PK_CheckpointQuery       BIGINT          IDENTITY(1,1) NOT NULL 
	,FK_Metric                BIGINT          NOT NULL
	,FK_Checkpoint            BIGINT          NOT NULL
 	,QueryStatement           VARCHAR(2000)     NOT NULL
    ,AuditCreateDateTime      DATETIME2(2)    CONSTRAINT DF_CheckpointQuery_AuditCreateDateTime  DEFAULT (GETUTCDATE())  NOT NULL 
    ,AuditModifyDateTime      DATETIME2(2)    NULL 
    ,AuditUserCreate          VARCHAR(64)     CONSTRAINT DF_CheckpointQuery_AuditUserCreate      DEFAULT (SUSER_SNAME()) NOT NULL 
    ,AuditUserModify          VARCHAR(64)     NULL 
    ,PRIMARY KEY CLUSTERED (PK_CheckpointQuery ASC) WITH (FILLFACTOR = 90)
	,CONSTRAINT FK_CheckpointQuery_Metric       FOREIGN KEY (FK_Metric) REFERENCES Rec.[Metric] (PK_Metric)
	,CONSTRAINT FK_CheckpointQuery_Checkpoint   FOREIGN KEY (FK_Checkpoint) REFERENCES Rec.[Checkpoint] (PK_Checkpoint)
);

GO

----------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Table and columns documentation
----------------------------------------------------------------------------------------------------------------------------------------------------------------

EXECUTE sp_addextendedproperty 
         @name           = N'Table definition'
        ,@value          = N'Table to store the SQL queries that will run for each checkpoint combined with the metrics setup in the Metric and Checkpoint tables.
							 For Example:
								Query1 : for metric Policy Count in checkpoint Data Contract Inbound '
        ,@level0type     = N'SCHEMA'
        ,@level0name     = N'Rec'
        ,@level1type     = N'TABLE'
        ,@level1name     = N'CheckpointQuery';
GO

-- COLUMNS

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'The FK linking with the metric table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Rec'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'CheckpointQuery'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'FK_Metric';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'The FK linking with the checkpoint table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Rec'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'CheckpointQuery'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'FK_Checkpoint';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'The Query that should be run for the metric in that checkpoint.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Rec'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'CheckpointQuery'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'QueryStatement';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to stamp date the records inserted in the table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Rec'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'CheckpointQuery'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditCreateDateTime';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to track updates by date and time in the table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Rec'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'CheckpointQuery'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditModifyDateTime';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to record the users including service accounts that insert the records in the table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Rec'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'CheckpointQuery'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditUserCreate';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to track updates by user in the table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Rec'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'CheckpointQuery'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditUserModify';
