﻿CREATE TABLE Rec.[Metric] (
     PK_Metric                BIGINT          IDENTITY(1,1) NOT NULL 
    ,MetricName               VARCHAR(50)     NULL 
    ,AuditCreateDateTime      DATETIME2(2)    CONSTRAINT DF_Metric_AuditCreateDateTime  DEFAULT (GETUTCDATE())  NOT NULL 
    ,AuditModifyDateTime      DATETIME2(2)    NULL 
    ,AuditUserCreate          VARCHAR(64)     CONSTRAINT DF_Metric_AuditUserCreate      DEFAULT (SUSER_SNAME()) NOT NULL 
    ,AuditUserModify          VARCHAR(64)     NULL 
    ,PRIMARY KEY CLUSTERED (PK_Metric ASC) WITH (FILLFACTOR = 90)
);

GO

----------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Table and columns documentation
----------------------------------------------------------------------------------------------------------------------------------------------------------------

EXECUTE sp_addextendedproperty 
         @name           = N'Table definition'
        ,@value          = N'Table to store the different metrics that need to be reconciled. For example Policy Count, Sum of Gross Premium, Sum of Earned Premium.'
        ,@level0type     = N'SCHEMA'
        ,@level0name     = N'Rec'
        ,@level1type     = N'TABLE'
        ,@level1name     = N'Metric';
GO

-- COLUMNS

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Name of the rule, should help to identify where the rule is used.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Rec'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Metric'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'MetricName';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to stamp date the records inserted in the table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Rec'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Metric'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditCreateDateTime';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to track updates by date and time in the table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Rec'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Metric'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditModifyDateTime';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to record the users including service accounts that insert the records in the table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Rec'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Metric'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditUserCreate';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to track updates by user in the table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Rec'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Metric'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditUserModify';
