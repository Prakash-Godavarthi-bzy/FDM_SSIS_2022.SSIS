﻿CREATE TABLE Rec.[CheckpointQueryRule] (
     PK_CheckpointQueryRule   BIGINT          IDENTITY(1,1) NOT NULL 
	,FK_Rule                  BIGINT          NOT NULL
	,FK_CheckpointQuery       BIGINT          NOT NULL
    ,AuditCreateDateTime      DATETIME2(2)    CONSTRAINT DF_CheckpointQueryRule_AuditCreateDateTime  DEFAULT (GETUTCDATE())  NOT NULL 
    ,AuditModifyDateTime      DATETIME2(2)    NULL 
    ,AuditUserCreate          VARCHAR(64)     CONSTRAINT DF_CheckpointQueryRule_AuditUserCreate      DEFAULT (SUSER_SNAME()) NOT NULL 
    ,AuditUserModify          VARCHAR(64)     NULL 
    ,PRIMARY KEY CLUSTERED (PK_CheckpointQueryRule ASC) WITH (FILLFACTOR = 90)
	,CONSTRAINT FK_CheckpointQueryRule_Rule              FOREIGN KEY (FK_Rule)            REFERENCES Rec.[Rule] (PK_Rule)
	,CONSTRAINT FK_CheckpointQueryRule_CheckpointQuery   FOREIGN KEY (FK_CheckpointQuery) REFERENCES Rec.[CheckpointQuery] (PK_CheckpointQuery)
);

GO

----------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Table and columns documentation
----------------------------------------------------------------------------------------------------------------------------------------------------------------

EXECUTE sp_addextendedproperty 
         @name           = N'Table definition'
        ,@value          = N'Many to  many bridge table to link the checkpoint queries with the reconciliation rules.'
        ,@level0type     = N'SCHEMA'
        ,@level0name     = N'Rec'
        ,@level1type     = N'TABLE'
        ,@level1name     = N'CheckpointQueryRule';
GO

-- COLUMNS

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'The FK linking with the Rule table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Rec'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'CheckpointQueryRule'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'FK_Rule';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'The FK linking with the CheckpointQuery table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Rec'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'CheckpointQueryRule'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'FK_CheckpointQuery';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to stamp date the records inserted in the table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Rec'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'CheckpointQueryRule'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditCreateDateTime';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to track updates by date and time in the table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Rec'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'CheckpointQueryRule'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditModifyDateTime';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to record the users including service accounts that insert the records in the table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Rec'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'CheckpointQueryRule'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditUserCreate';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to track updates by user in the table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Rec'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'CheckpointQueryRule'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditUserModify';
