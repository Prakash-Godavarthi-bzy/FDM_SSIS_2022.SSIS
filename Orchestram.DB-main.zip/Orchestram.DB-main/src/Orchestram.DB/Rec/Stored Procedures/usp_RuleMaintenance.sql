﻿






CREATE PROCEDURE [Rec].[usp_RuleMaintenance] 
	  @p_RuleName 					   VARCHAR(50)   	= NULL
	 ,@p_RuleStatement 				   VARCHAR(2000)   	= NULL
	 ,@p_Tolerance                     DECIMAL(19,4)    = NULL
	 ,@p_PKRule                        BIGINT           = NULL
	 ,@p_PKCheckpointQuery             BIGINT           = NULL
	 ,@p_PKCheckpointQueryRule         BIGINT           = NULL
	 ,@p_OperationType                 VARCHAR(50)      = 'INSERT'  --possible values:INSERT,UPDATE,DELETE
	 ,@p_TargetObject                  VARCHAR(50)      =  'ALL'    --possible values:ALL,RULE,CHECKPOINTQUERYRULE

AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @v_ErrorMessage         NVARCHAR(4000)
	DECLARE @v_PKRule               BIGINT = NULL	
	DECLARE @CurrentDate	        DATETIME2         = GETUTCDATE()

	BEGIN TRAN

		BEGIN TRY


			IF (@p_PKRule IS NULL OR NOT EXISTS (SELECT 1 FROM Rec.[Rule] ru where ru.PK_Rule = @p_PKRule))

			    AND @p_OperationType IN ('UPDATE','DELETE') AND @p_TargetObject IN ('RULE','ALL')

			    PRINT 'Invalid PKRule value for this type of operation.'


			IF (@p_PKCheckpointQueryRule IS NULL OR NOT EXISTS (SELECT 1 FROM Rec.[CheckpointQueryRule] cp where cp.PK_CheckpointQueryRule = @p_PKCheckpointQueryRule))

			   AND @p_OperationType IN ('UPDATE','DELETE') AND @p_TargetObject IN ('CHECKPOINTQUERYRULE','ALL')

			   PRINT 'Invalid PKCheckpointQueryRule value for this type of operation.'


			IF @p_OperationType = 'INSERT'

              BEGIN

			    --Rule table
				IF @p_TargetObject IN ('ALL','RULE')

				  BEGIN

				       INSERT INTO Rec.[Rule] 
				              (
							   RuleName
							  ,RuleStatement
							  ,Tolerance
					          )

				       SELECT
				               @p_RuleName 
							  ,@p_RuleStatement
							  ,@p_Tolerance

                       SELECT  @v_PKRule = SCOPE_IDENTITY()

                  END

         
				--CheckpointQueryRule table
				IF @p_TargetObject IN ('ALL')

				  BEGIN

					   INSERT INTO Rec.CheckpointQueryRule
					          (
							   FK_Rule
							  ,FK_CheckpointQuery
							  )

					   SELECT
					           @v_PKRule
							  ,@p_PKCheckpointQuery
					          
				  END

				  IF @p_TargetObject IN ('CHECKPOINTQUERYRULE')

				  BEGIN

					   INSERT INTO Rec.CheckpointQueryRule
					          (
							   FK_Rule
							  ,FK_CheckpointQuery
							  )

					   SELECT
					           @p_PKRule
							  ,@p_PKCheckpointQuery
					          
				  END

              END

			  IF @p_OperationType = 'UPDATE'

			    BEGIN

				  --Rule table
				  IF @p_TargetObject IN ('ALL','RULE') 

				    BEGIN
					    
						UPDATE Rec.[Rule]

						SET     RuleName            = @p_RuleName
						       ,RuleStatement       = @p_RuleStatement
							   ,Tolerance           = @p_Tolerance
						       ,AuditModifyDateTime = @CurrentDate
							   ,AuditUserModify     = suser_sname()

						WHERE  PK_Rule              = @p_PKRule

					END

				  --CheckpointQueryRule table
				  IF @p_TargetObject IN ('ALL','CHECKPOINTQUERYRULE') 

				    BEGIN
					    
						UPDATE Rec.[CheckpointQueryRule] 

						SET     FK_Rule                 = @p_PKRule
						       ,FK_CheckpointQuery      = @p_PKCheckpointQuery
						       ,AuditModifyDateTime     = @CurrentDate
							   ,AuditUserModify         = suser_sname()

						WHERE  PK_CheckpointQueryRule   = @p_PKCheckpointQueryRule 

					END  


				END

              IF @p_OperationType = 'DELETE'

			    BEGIN

				  --CheckpointQueryRule table
				  IF @p_TargetObject IN ('CHECKPOINTQUERYRULE') 

				    BEGIN

					  IF (EXISTS (SELECT     1 

					               FROM       Rec.RuleResult rr 

								   INNER JOIN Rec.CheckpointQueryRule cqr ON  rr.FK_Rule = cqr.FK_Rule

					               WHERE      cqr.PK_CheckpointQueryRule = @p_PKCheckpointQueryRule
								  )
						  )
			              PRINT 'You cannot delete this CheckpointQueryRule because is being referenced in RuleResult.'
					   ELSE
					      DELETE FROM Rec.CheckpointQueryRule

					      WHERE       PK_CheckpointQueryRule = @p_PKCheckpointQueryRule

					END

                   
                  --Rule table
				  IF @p_TargetObject IN ('ALL','RULE') 

				    BEGIN

					   IF (EXISTS (SELECT     1 

					               FROM       Rec.RuleResult rr 

					               WHERE      rr.FK_Rule = @p_PKRule
								  )
						  )
			              PRINT 'You cannot delete this Rule because is being referenced in RuleResult.'
					   
					   DELETE FROM Rec.CheckpointQueryRule

					   WHERE       FK_Rule = @p_PKRule

					   DELETE FROM Rec.[Rule] 

					   WHERE       PK_Rule = @p_PKRule

					END
				END

		END TRY		   
			
		BEGIN CATCH
		
			-- CANCEL TRAN
			ROLLBACK
			
			-- LOG ERROR
			SELECT    @v_ErrorMessage = 'Reconciliation framework error: ' + ERROR_MESSAGE()
			RAISERROR(@v_ErrorMessage, 16, 1)
	
		END CATCH

	IF @@TRANCOUNT = 1
		COMMIT
		
END
GO
EXECUTE sp_addextendedproperty @name = N'Stored Procedure Call', @value = N'Definition: This stored procedure is used to add /delete/update reconciliation rules in the reconciliation framework tables: Rule, CheckpointQueryRule.
Remarks:
TRY/CATCH BLOCKS are required to handle errors in the stored procedure.
SQL Transactions (BEGIN TRAN/COMMIT) are required in this stored procedure.', @level0type = N'SCHEMA', @level0name = N'Rec', @level1type = N'PROCEDURE', @level1name = N'usp_RuleMaintenance';
GO
