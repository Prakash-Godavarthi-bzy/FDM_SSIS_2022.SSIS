﻿


CREATE PROCEDURE [Rec].[usp_CheckpointMaintenance] 
	  @p_MetricName 					VARCHAR(50)   	= NULL
	 ,@p_CheckpointName					VARCHAR(50)     = NULL
	 ,@p_QueryStatement					NVARCHAR(2000)  = NULL
	 ,@p_PKMetric                       BIGINT          = NULL
	 ,@p_PKCheckpoint                   BIGINT          = NULL
	 ,@p_PKCheckpointQuery              BIGINT          = NULL
	 ,@p_OperationType                  VARCHAR(50)     = 'INSERT'  --possible values:INSERT,UPDATE,DELETE
	 ,@p_TargetObject                   VARCHAR(50)     =  'ALL'    --possible values:ALL,METRIC,CHECKPOINT,CHECKPOINTQUERY

AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @v_ErrorMessage         NVARCHAR(4000)
	DECLARE @v_PKMetric             BIGINT = NULL	
	DECLARE @v_PKCheckpoint         BIGINT = NULL
	DECLARE @CurrentDate	        DATETIME2         = GETUTCDATE()

	BEGIN TRAN

		BEGIN TRY

		    --check that @p_QueryStatement is not null when @p_OperationType is INSERT or UPDATE and @p_TargetObject  is ALL or CHECKPOINTQUERY
			IF @p_QueryStatement IS NULL AND @p_OperationType IN ('INSERT','UPDATE') AND @p_TargetObject IN ('ALL','CHECKPOINTQUERY')

			    PRINT 'QueryStatement value cannot be NULL for this type of operation.'

            --check that @p_PKMetric is not null when @p_OperationType is UPDATE OR DELETE and @p_TargetObject  is ALL or METRIC
			IF (@p_PKMetric IS NULL OR NOT EXISTS (SELECT 1 FROM Rec.Metric mt WHERE mt.PK_Metric = @p_PKMetric))

			    AND @p_OperationType IN ('UPDATE','DELETE') AND @p_TargetObject IN ('METRIC','ALL')

			    PRINT 'Invalid PKMetric value for this type of operation.'

			--check that @p_PKCheckpoint is not null when @p_OperationType is UPDATE OR DELETE and @p_TargetObject  is ALL or CHECKPOINT
			IF (@p_PKCheckpoint IS NULL OR NOT EXISTS (SELECT 1 FROM Rec.[Checkpoint] cp WHERE cp.PK_Checkpoint = @p_PKCheckpoint))

			   AND @p_OperationType IN ('UPDATE','DELETE') AND @p_TargetObject IN ('CHECKPOINT','ALL')

			    PRINT 'Invalid PKCheckpoint value for this type of operation.'

			--check that @p_PKCheckpointQuery is not null when @p_OperationType is UPDATE OR DELETE and @p_TargetObject  is ALL or CHECKPOINTQUERY
			IF (@p_PKCheckpointQuery IS NULL OR NOT EXISTS (SELECT 1 FROM Rec.[CheckpointQuery] cp WHERE cp.PK_CheckpointQuery = @p_PKCheckpointQuery))

			   AND @p_OperationType IN ('UPDATE','DELETE') AND @p_TargetObject IN ('CHECKPOINTQUERY','ALL')

			    PRINT 'Invalid PKCheckpointQuery value for this type of operation.'
           
		    
         
			IF @p_OperationType = 'INSERT'

              BEGIN

			    --Metric table
				IF @p_TargetObject IN ('ALL','METRIC')

				  BEGIN

				       INSERT INTO Rec.Metric 
				              (
							   MetricName
					          )
				       SELECT
				               @p_MetricName

                       SELECT  @p_PKMetric = SCOPE_IDENTITY()

                  END

                --Checkpoint table
                IF @p_TargetObject IN ('ALL','CHECKPOINT')

			      BEGIN

				       INSERT INTO Rec.[Checkpoint]  
				              (
							   CheckpointName
					    	  )

				       SELECT 
				               @p_CheckpointName

                       SELECT  @p_PKCheckpoint = SCOPE_IDENTITY()

                  END
         
				--CheckpointQuery table
				IF @p_TargetObject IN ('ALL','CHECKPOINTQUERY')

				  BEGIN

					   INSERT INTO Rec.CheckpointQuery
					          (
							   FK_Metric
							  ,FK_Checkpoint
							  ,QueryStatement
							  )

					   SELECT
					           @p_PKMetric
							  ,@p_PKCheckpoint
							  ,@p_QueryStatement	
					          
				  END

              END

			  IF @p_OperationType = 'UPDATE'

			    BEGIN

				  --Metric table
				  IF @p_TargetObject IN ('ALL','METRIC') 

				    BEGIN
					    
						UPDATE Rec.Metric 

						SET     MetricName          = @p_MetricName
						       ,AuditModifyDateTime = @CurrentDate
							   ,AuditUserModify     = suser_sname()

						WHERE  PK_Metric            = @p_PKMetric

					END

				  --Checkpoint table
				  IF @p_TargetObject IN ('ALL','CHECKPOINT') 

				    BEGIN
					    
						UPDATE Rec.[Checkpoint] 

						SET     CheckpointName      = @p_CheckpointName
						       ,AuditModifyDateTime = @CurrentDate
							   ,AuditUserModify     = suser_sname()

						WHERE  PK_Checkpoint        = @p_PKCheckpoint

					END  

				  --CheckpointQuery table
				  IF @p_TargetObject IN ('ALL','CHECKPOINTQUERY') 

				    BEGIN
					    
						UPDATE Rec.CheckpointQuery

						SET     QueryStatement      = @p_QueryStatement
						       ,AuditModifyDateTime = @CurrentDate
							   ,AuditUserModify     = suser_sname()

						WHERE  PK_CheckpointQuery   = @p_PKCheckpointQuery

					END

				END

              IF @p_OperationType = 'DELETE'

			    BEGIN

				  --CheckpointQuery table
				  IF @p_TargetObject IN ('ALL','CHECKPOINTQUERY') 

				    BEGIN

					   IF (EXISTS (SELECT 1 

					               FROM   Rec.CheckpointQueryResult cqr 

					               WHERE  cqr.FK_CheckpointQuery = @p_PKCheckpointQuery
								  )
						  )
			              PRINT 'You cannot delete this checkpointquery because is being referenced in ChecpointQueryResult.'

					   DELETE FROM Rec.CheckpointQueryRule 

					   WHERE       FK_CheckpointQuery = @p_PKCheckpointQuery

					   DELETE FROM Rec.CheckpointQuery 

					   WHERE       PK_CheckpointQuery = @p_PKCheckpointQuery

					END
                    
                  --Checkpoint table
				  IF @p_TargetObject IN ('ALL','CHECKPOINT') 

				    BEGIN

					   IF (EXISTS (SELECT     1 

					               FROM       Rec.CheckpointQueryResult cqr 

								   INNER JOIN Rec.CheckpointQuery cq ON cqr.FK_CheckpointQuery = cq.PK_CheckpointQuery

					               WHERE      cq.FK_Checkpoint = @p_PKCheckpoint
								  )
						  )
			              PRINT 'You cannot delete this checkpoint because is being referenced in ChecpointQueryResult.'

				       DELETE FROM Rec.CheckpointQueryRule 

					   WHERE       FK_CheckpointQuery IN  
					                                      (SELECT   PK_CheckpointQuery
					                                       FROM     Rec.CheckpointQuery 
					                                       WHERE    FK_Checkpoint = @p_PKCheckpoint
					                                       )
					   DELETE FROM Rec.CheckpointQuery
					    
					   WHERE       FK_Checkpoint = @p_PKCheckpoint

					   DELETE FROM Rec.[Checkpoint] 

					   WHERE       PK_Checkpoint = @p_PKCheckpoint

					END
                    
                  --Metric table
				  IF @p_TargetObject IN ('ALL','METRIC') 

				    BEGIN

					   IF (EXISTS (SELECT     1 

					               FROM       Rec.CheckpointQueryResult cqr 

								   INNER JOIN Rec.CheckpointQuery cq ON cqr.FK_CheckpointQuery = cq.PK_CheckpointQuery

					               WHERE      cq.FK_Metric = @p_PKMetric
								  )
						  )
			              PRINT 'You cannot delete this metric because is being referenced in ChecpointQueryResult.'

					   DELETE FROM Rec.CheckpointQueryRule 

					   WHERE       FK_CheckpointQuery IN  (SELECT   PK_CheckpointQuery
					                                       FROM     Rec.CheckpointQuery 
					                                       WHERE    FK_Metric = @p_PKMetric
					                                       )
					   DELETE FROM Rec.CheckpointQuery 

					   WHERE       FK_Metric = @p_PKMetric

					   DELETE FROM Rec.[Metric] 

					   WHERE       PK_Metric = @p_PKMetric

					END
				END

		END TRY		   
			
		BEGIN CATCH
		
			-- CANCEL TRAN
			ROLLBACK
			
			-- LOG ERROR
			SELECT    @v_ErrorMessage = 'Reconciliation framework error: ' + ERROR_MESSAGE()
			RAISERROR(@v_ErrorMessage, 16, 1)
	
		END CATCH

	IF @@TRANCOUNT = 1
		COMMIT
		
END
GO
EXECUTE sp_addextendedproperty @name = N'Stored Procedure Call', @value = N'Definition: This stored procedure is used to add /delete/update metrics, checkpoints and queries in the reconciliation framework tables: Metric, Checkpoint, CheckpointQuery.
Remarks:
TRY/CATCH BLOCKS are required to handle errors in the stored procedure.
SQL Transactions (BEGIN TRAN/COMMIT) are required in this stored procedure..', @level0type = N'SCHEMA', @level0name = N'Rec', @level1type = N'PROCEDURE', @level1name = N'usp_CheckpointMaintenance';
GO


