﻿


CREATE PROCEDURE [Rec].[usp_ReconciliationProcess] 
	  @p_RuleName 					   VARCHAR(50)   	= NULL
	 ,@p_PKRule 				       BIGINT       	= NULL
	 ,@p_PKCheckpointQuery             BIGINT   	    = NULL
	 ,@p_MetricName                    VARCHAR(50)   	= NULL
	 ,@p_PKMetric                      BIGINT           = NULL
	 ,@p_BatchId                       BIGINT           = NULL
	 

AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @v_ErrorMessage         NVARCHAR(4000)
	DECLARE @v_Query		        VARCHAR(2000)
	DECLARE @v_TblCnt               INT               = NULL
	DECLARE @v_Cnt                  INT               = 1
	DECLARE @v_PKCheckpointQuery    BIGINT 
	DECLARE @v_CheckpointResult     VARCHAR(50)
	DECLARE @v_SQL                  NVARCHAR(4000)
	DECLARE @v_PKRule               BIGINT            = NULL
	DECLARE @v_RuleResult           DECIMAL(19,4)              
	DECLARE @v_Tolerance            DECIMAL(19,4) 
	DECLARE @v_CurrentDate	        DATETIME2         = GETUTCDATE()


	DROP TABLE IF EXISTS #ToCalculate

	CREATE TABLE #ToCalculate
	    (
		 PK_ToCalculate   	     INT		IDENTITY(1,1)
		,PK_Metric               BIGINT
		,MetricName              VARCHAR(50)
		,PK_Checkpoint           BIGINT
		,CheckpointName          VARCHAR(50)
		,PK_CheckpointQuery      BIGINT
		,QueryStatement		     VARCHAR(2000)
		,PK_Rule                 BIGINT
	    ,RuleName                VARCHAR(50)
	    ,RuleStatement           VARCHAR(4000)
	    ,Tolerance               DECIMAL(19,4)
		,QueryResult             DECIMAL(19,4)
		,QueryResultExist        BIT
		) 

    DROP TABLE IF EXISTS #RuleOperation
	
	CREATE TABLE #RuleOperation
	     ( PK_RuleOperation       INT		IDENTITY(1,1)
		  ,PK_Rule                BIGINT
		  ,RuleStatement          VARCHAR(4000)
		  ,Tolerance              DECIMAL(19,4)
		  )

	BEGIN TRY

		BEGIN TRAN

		    INSERT INTO  #ToCalculate
			             (
		                  PK_Metric
		                 ,MetricName
		                 ,PK_Checkpoint
		                 ,CheckpointName
		                 ,PK_CheckpointQuery
		                 ,QueryStatement
						 ,PK_Rule
	                     ,RuleName
	                     ,RuleStatement
	                     ,Tolerance
						 ,QueryResultExist 
						 )

		    SELECT DISTINCT
			              mt.PK_Metric
                         ,mt.MetricName
	                     ,c.PK_Checkpoint
	                     ,c.CheckpointName
                         ,cq.PK_CheckpointQuery
	                     ,cq.QueryStatement
						 ,r.PK_Rule
	                     ,r.RuleName
	                     ,r.RuleStatement
	                     ,r.Tolerance
						 ,(CASE WHEN EXISTS (SELECT 1 

                                             FROM    Rec.CheckpointQueryResult  cqrr

								             WHERE   cqrr.FK_CheckpointQuery = cq.PK_CheckpointQuery

								             AND     cqrr.BatchId            = @p_BatchId
											 ) 
							    THEN 1
								ELSE 0 END
						 )


            FROM          Rec.CheckpointQuery      cq                  

            LEFT JOIN     Rec.[Checkpoint]         c                    
			ON            c.PK_Checkpoint        = cq.FK_Checkpoint

            LEFT JOIN     Rec.Metric               mt                   
			ON            mt.PK_Metric           = cq.FK_Metric 

            LEFT JOIN     Rec.CheckpointQueryRule  cqr                  
			ON            cqr.FK_CheckpointQuery = cq.PK_CheckpointQuery      
			      
			LEFT JOIN     Rec.[Rule]               r                    
			ON             r.PK_Rule              = cqr.FK_Rule

			WHERE   cq.PK_CheckpointQuery = ISNULL(@p_PKCheckpointQuery,cq.PK_CheckpointQuery) 
			AND     mt.PK_Metric          = ISNULL(@p_PKMetric,mt.PK_Metric)  
			AND     mt.MetricName         = ISNULL(@p_MetricName,mt.MetricName)
			AND     r.RuleName            = ISNULL(@p_RuleName,r.RuleName)
			AND     r.PK_Rule             = ISNULL(@p_RuleName,r.PK_Rule)
	

			SELECT  @v_TblCnt = SCOPE_IDENTITY()
			

			IF @v_TblCnt IS NOT NULL 

			   BEGIN

			        WHILE (@v_Cnt <= @v_TblCnt)

					     BEGIN
						      SELECT  DISTINCT
							          @v_Query              = cqtr.QueryStatement
							         ,@v_PKCheckpointQuery  = cqtr.PK_CheckpointQuery

							  FROM   #ToCalculate  cqtr

							  WHERE  PK_ToCalculate = @v_Cnt


							  SET @v_SQL = N'SELECT @v_CheckpointResult = (' + @v_Query + ')'
							  
							  EXEC SP_EXECUTESQL @v_SQL,N'@v_Query  NVARCHAR(2000),@v_CheckpointResult VARCHAR(50) OUTPUT',@v_Query ,  @v_CheckpointResult OUTPUT


							  
							  INSERT INTO   Rec.CheckpointQueryResult
							                (FK_CheckpointQuery
											,BatchId
											,ResultDateTime
											,[Result]
											)
							  SELECT 
											 @v_PKCheckpointQuery
											,@p_BatchId 
											,@v_CurrentDate
											,@v_CheckpointResult
							  
							  UPDATE        #ToCalculate

							  SET           QueryResult        = cast(@v_CheckpointResult as decimal(19,4))

							  WHERE         PK_CheckpointQuery = @v_PKCheckpointQuery  
							  
							                

							  SET @v_Cnt = @v_Cnt + 1
						 END


	               INSERT INTO   #RuleOperation
						         (PK_Rule 
		                         ,RuleStatement 
								 ,Tolerance
								 )

				    SELECT        DISTINCT
				                  tc.PK_Rule
						         ,tc.RuleStatement
								 ,tc.Tolerance

				    FROM         #ToCalculate tc

					WHERE        tc.RuleStatement IS NOT NULL

					SELECT  @v_TblCnt = SCOPE_IDENTITY()
						
					SET @v_Cnt         = 1

					WHILE (@v_Cnt <= @v_TblCnt)

					   BEGIN

					       SELECT  @v_SQL       = ro.RuleStatement
						          ,@v_PKRule    = ro.PK_Rule 
								  ,@v_Tolerance = ro.Tolerance

						   FROM   #RuleOperation ro

						   WHERE ro.PK_RuleOperation = @v_Cnt

						   EXEC SP_EXECUTESQL @v_SQL,N'@v_PKRule BIGINT,@p_BatchId BIGINT,@v_Tolerance DECIMAL(19,4)',@v_PKRule, @p_BatchId, @v_Tolerance

						   SET @v_Cnt = @v_Cnt + 1

					   END
				END	   	

		END TRY		   
			
		BEGIN CATCH
		
			-- CANCEL TRAN
			ROLLBACK
			
			-- LOG ERROR
			SELECT    @v_ErrorMessage = 'Reconciliation framework error: ' + ERROR_MESSAGE()
			RAISERROR(@v_ErrorMessage, 16, 1)
	
		END CATCH

	IF @@TRANCOUNT = 1
		COMMIT
		
END
GO
EXECUTE sp_addextendedproperty @name = N'Stored Procedure Call', @value = N'Definition: This stored procedure is used to run the queries or rules (and record the results) that are part of the reconciliation framework. This is controlled with @parameters in the stored procedure for example the proc can run processes by rule id or name, query id or name, a group of reconciliation rules or queries... 
Remarks:
TRY/CATCH BLOCKS are required to handle errors in the stored procedure.
SQL Transactions (BEGIN TRAN/COMMIT) are required in this stored procedure.', @level0type = N'SCHEMA', @level0name = N'Rec', @level1type = N'PROCEDURE', @level1name = N'usp_ReconciliationProcess';
GO
