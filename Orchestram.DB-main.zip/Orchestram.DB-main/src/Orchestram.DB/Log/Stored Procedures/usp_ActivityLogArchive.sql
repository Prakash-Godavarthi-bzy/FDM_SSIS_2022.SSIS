﻿-- =============================================
-- Author:		Ciprian Mandras
-- Create date: 2019.03.28
-- Description:	Used to archive activity log and purge data from current log
-- =============================================
CREATE PROCEDURE Log.usp_ActivityLogArchive 
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @v_CommitFlag BIT = 1			/* Set to 0 for TEST and 1 to commit */

	DECLARE @v_ErrorMessage 			NVARCHAR(4000)
	DECLARE @v_ConfiguredParameter 		INT
	DECLARE @v_DateTimeIntervalEnd		DATETIME2(2)

	DECLARE @Trancount					INT = @@Trancount

	-- We define a twin table for  Arch.ActivityLog, to keep lines from Log.ActivityLog that are not archived yet
	
	DROP TABLE IF EXISTS #tmpActivityLog
	
	CREATE TABLE #tmpActivityLog(
		 PK_ActivityLogArchive     BIGINT           IDENTITY(1,1) NOT NULL
		,PK_ActivityLog            BIGINT           NOT NULL
		,FK_ParentActivityLog      BIGINT           NULL
		,ActivitySource            VARCHAR(50)      NOT NULL 
		,ActivityType              VARCHAR(50)      NOT NULL
		,ActivityStatus            VARCHAR(50)      NOT NULL
		,ActivityHost              VARCHAR(100)     NOT NULL
		,ActivityDatabase          VARCHAR(100)     NULL
		,ActivityJobId             VARCHAR(50)      NULL
		,ActivitySSISExecutionId   VARCHAR(50)      NULL
		,ActivityName              VARCHAR(100)     NOT NULL
		,ActivityStartDateTime     DATETIME2(2)     NULL
		,ActivityEndDateTime       DATETIME2(2)     NULL
		,ActivityDuration          VARCHAR(12)      NULL
		,ActivityErrorCode         NVARCHAR(50)     NULL
		,AffectedRows              INT              NULL
		,AuditCreateDateTime	   DATETIME2(2)     NOT NULL	
		,AuditUserCreate		   VARCHAR(64)      NOT NULL
		,RowOrder				   INT				NULL
		)

	-- DATA COMMIT ZONE 

	BEGIN TRY

		SELECT  @v_DateTimeIntervalEnd = GETDATE()

		SELECT 	@v_ConfiguredParameter = -1*CAST(Answer AS INT)
		FROM 	Util.Configuration
		WHERE	Question = 'ArchiveActivityLogCutOffDays'
		
		IF @Trancount = 0
				BEGIN TRAN 
			
		-- We insert all activities started before @p_AuditCreateDateTimeTo that are not yet in the archive
		
		INSERT INTO #tmpActivityLog
			   (
				 PK_ActivityLog            
				,FK_ParentActivityLog      
				,ActivitySource            
				,ActivityType              
				,ActivityStatus            
				,ActivityHost              
				,ActivityDatabase          
				,ActivityJobId             
				,ActivitySSISExecutionId   
				,ActivityName              
				,ActivityStartDateTime     
				,ActivityEndDateTime       
				,ActivityDuration          
				,ActivityErrorCode
				,AffectedRows
				,AuditCreateDateTime
				,AuditUserCreate
				,RowOrder
			    )
				   
		SELECT 
				 PK_ActivityLog         	=	LALStart.PK_ActivityLog																	-- PK from start, to keep the chain of activities
				,FK_ParentActivityLog		=	LALStart.FK_ParentActivityLog															-- PK of parent activity
				-- The next values are the same in both rows, except status that we want to have it from closing line
				,ActivitySource				=	LALStart.ActivitySource
				,ActivityType				=	LALStart.ActivityType
				,ActivityStatus				=	ISNULL(LAStop.ActivityStatus, LALStart.ActivityStatus)
				,ActivityHost				=	LALStart.ActivityHost
				,ActivityDatabase			=	LALStart.ActivityDatabase
				,ActivityJobId				=	LALStart.ActivityJobId
				,ActivitySSISExecutionId	=	LALStart.ActivitySSISExecutionId
				,ActivityName				=	LALStart.ActivityName
				-- Running information
				,ActivityStartDateTime		=	LALStart.ActivityDateTime
				,ActivityEndDateTime		=	LAStop.ActivityDateTime
				,ActivityDuration			=	Util.udf_DateTimeDuration(LALStart.ActivityDateTime,LAStop.ActivityDateTime)
				,ActivityErrorCode			=	LAStop.ActivityErrorCode
				,AffectedRows				=	LAStop.AffectedRows
				,AuditCreateDateTime		=	LALStart.AuditCreateDateTime
				,AuditUserCreate			=	LALStart.AuditUserCreate
				-- If I have more Ends, I want to take just the last one
				,RowOrder					=	ROW_NUMBER() OVER (PARTITION BY LAStop.FK_ActivityLogTag ORDER BY LAStop.ActivityDateTime DESC)
				
		FROM Log.vw_ActivityLog LALStart
		
		LEFT JOIN Log.vw_ActivityLog LAStop 
		ON LALStart.PK_ActivityLog = LAStop.FK_ActivityLogTag
		
		WHERE   LALStart.ActivityDateTime < DATEADD(DAY,@v_ConfiguredParameter,@v_DateTimeIntervalEnd)
			AND LALStart.ActivityStatus   = 'STARTED'
		
		-- We delete the ending rows that are not the last ones 
		
		DELETE FROM tmp
		
		FROM #tmpActivityLog tmp
		
		WHERE 	RowOrder > 1
			AND	ActivityEndDateTime IS NOT NULL
		
		-- Insert ...
		
		INSERT INTO Arch.ActivityLog
			   (
				 PK_ActivityLog
			    ,FK_ParentActivityLog
			    ,ActivitySource
			    ,ActivityType
			    ,ActivityStatus
			    ,ActivityHost
			    ,ActivityDatabase
			    ,ActivityJobId
			    ,ActivitySSISExecutionId
			    ,ActivityName
			    ,ActivityStartDateTime
			    ,ActivityEndDateTime
			    ,ActivityDuration
			    ,ActivityErrorCode
				,AffectedRows
				,AuditCreateDateTime
				,AuditUserCreate
			    )
				
		SELECT
				 tmp.PK_ActivityLog
			    ,tmp.FK_ParentActivityLog
			    ,tmp.ActivitySource
			    ,tmp.ActivityType
			    ,tmp.ActivityStatus
			    ,tmp.ActivityHost
			    ,tmp.ActivityDatabase
			    ,tmp.ActivityJobId
			    ,tmp.ActivitySSISExecutionId
			    ,tmp.ActivityName
			    ,tmp.ActivityStartDateTime
			    ,tmp.ActivityEndDateTime
			    ,tmp.ActivityDuration
			    ,tmp.ActivityErrorCode
				,tmp.AffectedRows
				,tmp.AuditCreateDateTime
				,tmp.AuditUserCreate
				
		FROM #tmpActivityLog tmp
		
		LEFT JOIN Arch.ActivityLog AAL 
		ON tmp.PK_ActivityLog = AAL.PK_ActivityLog
		
		WHERE AAL.PK_ActivityLog IS NULL															-- It is not in archive already

		-- ... and purge

		DELETE FROM LAL
		
		FROM Log.ActivityLog LAL
		
		INNER JOIN #tmpActivityLog tmp
		ON tmp.PK_ActivityLog = ISNULL(LAL.FK_ActivityLogTag, LAL.PK_ActivityLog)
		
		-- And now we finish with the desired option
		
		IF @v_CommitFlag = 1
		BEGIN
			IF @Trancount = 0
				COMMIT			-- Save the data
		END
		ELSE
		BEGIN
			-- We want to know the results in affected tables
			
			SELECT 
				 PK_ActivityLog
			    ,FK_ParentActivityLog
			    ,ActivitySource
			    ,ActivityType
			    ,ActivityStatus
			    ,ActivityHost
			    ,ActivityDatabase
			    ,ActivityJobId
			    ,ActivitySSISExecutionId
			    ,ActivityName
			    ,ActivityStartDateTime
			    ,ActivityEndDateTime
			    ,ActivityDuration
			    ,ActivityErrorCode 
				,AffectedRows
				,AuditCreateDateTime
				,AuditUserCreate
				,RowOrder
				
			FROM #tmpActivityLog

			DROP TABLE #tmpActivityLog
			
			IF @Trancount = 0
				ROLLBACK
		END	

	END TRY

	BEGIN CATCH
		
		-- Finally
		IF @Trancount = 0
			ROLLBACK
		
		-- LOG ERROR
		SELECT    @v_ErrorMessage = 'Logging framework error: ' + ERROR_MESSAGE()
		RAISERROR(@v_ErrorMessage, 16, 1)
		
	END CATCH
		
END

GO

EXECUTE sp_addextendedproperty 
		 @name = N'Stored Procedure Call'
		,@value = N'The procedure will be called on demand or scheduled via a SQL job.

					A parameter setup in the Util.Configuration table (ArchiveActivityLogCutOffDays) will control the cutoff date to select which data can 
					be archived. Once this data is archived, it will need to be deleted from the Log.ActivityLog table.

					Range of data to archive -> 
					WHERE AuditCreateDateTime <= GETDATE() - @p_ArchiveActivityLogCutOffDays

					•	Remarks:

					1.	TRY/CATCH BLOCKS are required to handle errors in the stored procedure.

					2.	SQL Transactions (BEGIN TRAN/COMMIT) are required for this stored procedure. 

					3.  SQL hint must be used in all the selects and joins in the stored procedure.
					'
		,@level0type = N'SCHEMA'
		,@level0name = N'Log'
		,@level1type = N'PROCEDURE'
		,@level1name = N'usp_ActivityLogArchive';

GO

EXECUTE sp_addextendedproperty 
		@name = N'Stored Procedure Definition'
		,@value = N'This stored procedure archives selected records from the Log.ActivityLog table into its archive version Arch.ActivityLog.

					 The goal of this stored procedure is to keep the ActivityLog table with a reasonable volume of data where performance is no'
		,@level0type = N'SCHEMA'
		,@level0name = N'Log'
		,@level1type = N'PROCEDURE'
		,@level1name = N'usp_ActivityLogArchive';

