﻿
-- =============================================
-- Author:		Ciprian Mandras
-- Create date: 2019.04.18
-- Description:	Used to insert new sources/systems in the Logging.ActivitySource table
-- =============================================

CREATE PROCEDURE [Log].usp_ActivitySourceMaintenance 
	  @p_SourceName 					NVARCHAR(50)	
	 ,@p_SourceId						INT
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @v_ErrorMessage NVARCHAR(4000)	

	BEGIN TRAN

		BEGIN TRY

			-- If it is already in the table, I want to return an informative message instead of duplicate the line

			IF EXISTS 
					(SELECT TOP 1 1 
					 
					 FROM Log.ActivitySource
					 
					 WHERE ActivitySource = @p_SourceName
					 )
			
				PRINT 'This activity source already exists.'

			ELSE

				INSERT INTO Log.ActivitySource
					   (
						 PK_ActivitySource
						,ActivitySource
					   )
				   
				SELECT 
						 @p_SourceId
						,@p_SourceName 
		   
		END TRY

		BEGIN CATCH
		
			-- CANCEL TRAN
			ROLLBACK
			
			-- LOG ERROR
			SELECT    @v_ErrorMessage = 'Logging framework error: ' + ERROR_MESSAGE()
			RAISERROR(@v_ErrorMessage, 16, 1)
	
		END CATCH

	IF @@TRANCOUNT = 1
		COMMIT
		
END

GO

EXECUTE sp_addextendedproperty 
		 @name = N'Stored Procedure Call'
		,@value = N'The procedure will be called by passing the source/system name as a parameter. This will just insert a new row into the Logging.ActivitySource table. 

					•	Remarks:

					1.	TRY/CATCH BLOCKS are required to handle errors in the stored procedure.

					2.	SQL Transactions (BEGIN TRAN/COMMIT) are required for this stored procedure.'
		,@level0type = N'SCHEMA'
		,@level0name = N'Log'
		,@level1type = N'PROCEDURE'
		,@level1name = N'usp_ActivitySourceMaintenance';

GO

EXECUTE sp_addextendedproperty 
		 @name = N'Stored Procedure Definition'
		,@value = N'This stored procedure inserts new sources/systems in the Log.ActivitySource table. This must be done before a new system can send activity records to the logging framework.'
		,@level0type = N'SCHEMA'
		,@level0name = N'Log'
		,@level1type = N'PROCEDURE'
		,@level1name = N'usp_ActivitySourceMaintenance';

GO

EXECUTE sp_addextendedproperty 
		 @name = N'Stored Procedure Parameters'
		,@value = N'Input:

					@_SourceName -  VARCHAR(50) - NOT NULL:
					The name of the new originator (data source or system) of the activity that is going to be recorded in the log.'
		,@level0type = N'SCHEMA'
		,@level0name = N'Log'
		,@level1type = N'PROCEDURE'
		,@level1name = N'usp_ActivitySourceMaintenance';

