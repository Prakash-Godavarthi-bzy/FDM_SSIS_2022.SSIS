﻿
-- =============================================
-- Author:		Ciprian Mandras
-- Create date: 2019.03.22
-- Description:	Used to log activities in the system
-- =============================================

CREATE PROCEDURE Log.usp_ActivityLogReport 
	 @p_ActivityDateTimeFrom 	DATETIME2(2)	=	'19000101'
	,@p_ActivityDateTimeTo 		DATETIME2(2)	=	'99991231'
AS
BEGIN

	SET NOCOUNT ON;

	-- DECLARATION SECTION 

	-- Variables used for date control (in case that the user request has parameters in reversed order)
	DECLARE @v_DateTimeIntervalStart	DATETIME2(2)
	DECLARE @v_DateTimeIntervalEnd		DATETIME2(2)
	DECLARE @v_ErrorMessage 			NVARCHAR(4000)
	
	-- We define a twin table for  Archive.ActivityLog, to keep lines from Logging.ActivityLog that are not archived yet

	DROP TABLE IF EXISTS #tmpActivityLog 
	
	CREATE TABLE #tmpActivityLog(
		 PK_ActivityLogArchive     BIGINT           IDENTITY (1,1) NOT NULL
		,PK_ActivityLog            BIGINT           NOT NULL
		,FK_ParentActivityLog      BIGINT           NULL
		,ActivitySource            VARCHAR(50)      NOT NULL
		,ActivityType              VARCHAR(50)      NOT NULL
		,ActivityStatus            VARCHAR(50)      NOT NULL
		,ActivityHost              VARCHAR(100)     NOT NULL
		,ActivityDatabase          VARCHAR(100)     NULL
		,ActivityJobId             VARCHAR(50)      NULL
		,ActivitySSISExecutionId   VARCHAR(50)      NULL
		,ActivityName              VARCHAR(100)     NOT NULL
		,ActivityStartDateTime     DATETIME2(2)     NULL
		,ActivityEndDateTime       DATETIME2(2)     NULL
		,ActivityDuration          VARCHAR(12)      NULL
		,ActivityErrorCode         NVARCHAR(50)     NULL
		,AffectedRows              INT              NULL
		)

	-- VALIDATION SECTION

	--Change date format to yyyy-mmm-dd so there is not confusion between yyyy-mm-dd and yyyy-dd-mm
	SET @v_DateTimeIntervalStart	= (SELECT CONVERT(NVARCHAR(50),@p_ActivityDateTimeFrom,113)) 
    SET @v_DateTimeIntervalEnd   	= (SELECT CONVERT(NVARCHAR(50),@p_ActivityDateTimeTo  ,113))

	-- Reverse the dates if the start date is greater than the end date
    SET @v_DateTimeIntervalStart 	= (SELECT CASE WHEN @p_ActivityDateTimeFrom <= @p_ActivityDateTimeTo   THEN @p_ActivityDateTimeFrom ELSE @p_ActivityDateTimeTo   END)
    SET @v_DateTimeIntervalEnd 		= (SELECT CASE WHEN @p_ActivityDateTimeTo   >= @p_ActivityDateTimeFrom THEN @p_ActivityDateTimeTo   ELSE @p_ActivityDateTimeFrom END)

	-- DATA COMMIT ZONE (Here we put data in our tables)

	BEGIN TRY
		
		-- First we take in the temporary table all activities started in this interval and we consolidate them into the archive structure
		
		INSERT INTO #tmpActivityLog
			   (
				 PK_ActivityLog            
				,FK_ParentActivityLog      
				,ActivitySource            
				,ActivityType              
				,ActivityStatus            
				,ActivityHost              
				,ActivityDatabase          
				,ActivityJobId             
				,ActivitySSISExecutionId   
				,ActivityName              
				,ActivityStartDateTime     
				,ActivityEndDateTime       
				,ActivityDuration          
				,ActivityErrorCode  
				,AffectedRows
			    )
				   
		SELECT 
				 PK_ActivityLog         	=	LALStart.PK_ActivityLog													-- PK from last status or PK of the first one if activity has no end date yet
				,FK_ParentActivityLog		=	LALStart.FK_ParentActivityLog													-- PK from start (parent id))
				-- The next values are the same in both rows
				,ActivitySource				=	LALStart.ActivitySource
				,ActivityType				=	LALStart.ActivityType
				,ActivityStatus				=	ISNULL(LALStop.ActivityStatus, LALStart.ActivityStatus)
				,ActivityHost				=	LALStart.ActivityHost
				,ActivityDatabase			=	LALStart.ActivityDatabase
				,ActivityJobId				=	LALStart.ActivityJobId
				,ActivitySSISExecutionId	=	LALStart.ActivitySSISExecutionId
				,ActivityName				=	LALStart.ActivityName
				-- Running information
				,ActivityStartDateTime		=	LALStart.ActivityDateTime
				,ActivityEndDateTime		=	LALStop.ActivityDateTime
				,ActivityDuration			=	Utility.udf_DateTimeDuration(LALStart.ActivityDateTime,LALStop.ActivityDateTime)
				,ActivityErrorCode			=	LALStop.ActivityErrorCode
				,AffectedRows				=	LALStop.AffectedRows

		FROM Log.vw_ActivityLog LALStart
		
		LEFT JOIN Log.vw_ActivityLog LALStop 
		ON LALStart.PK_ActivityLog = LALStop.FK_ActivityLogTag
			
		WHERE LALStart.ActivityDateTime BETWEEN @v_DateTimeIntervalStart AND @v_DateTimeIntervalEnd
			AND LALStart.ActivityStatus = 'STARTED'

		-- Results:

		SELECT PK_ActivityLog
			  ,FK_ParentActivityLog
			  ,ActivitySource
			  ,ActivityType
			  ,ActivityStatus
			  ,ActivityHost
			  ,ActivityDatabase
			  ,ActivityJobId
			  ,ActivitySSISExecutionId
			  ,ActivityName
			  ,ActivityStartDateTime
			  ,ActivityEndDateTime
			  ,ActivityDuration
			  ,ActivityErrorCode
			  ,AffectedRows
			  
		FROM Arch.vw_ActivityLog 
		
		WHERE ActivityStartDateTime BETWEEN @v_DateTimeIntervalStart AND @v_DateTimeIntervalEnd
		  
		UNION ALL
		  
		SELECT PK_ActivityLog
			  ,FK_ParentActivityLog
			  ,ActivitySource
			  ,ActivityType
			  ,ActivityStatus
			  ,ActivityHost
			  ,ActivityDatabase
			  ,ActivityJobId
			  ,ActivitySSISExecutionId
			  ,ActivityName
			  ,ActivityStartDateTime
			  ,ActivityEndDateTime
			  ,ActivityDuration
			  ,ActivityErrorCode
			  ,AffectedRows
			  
		FROM #tmpActivityLog	
		
		ORDER BY ActivityStartDateTime, ActivityEndDateTime	
		
		
		DROP TABLE #tmpActivityLog
		
	END TRY

	BEGIN CATCH
		
		-- LOG ERROR
		SELECT    @v_ErrorMessage = 'Logging framework error: ' + ERROR_MESSAGE()
		RAISERROR(@v_ErrorMessage, 16, 1)
		
	END CATCH
		
END

GO
EXECUTE sp_addextendedproperty 
		 @name = N'Stored Procedure Call'
		,@value = N'The procedure will be called on demand by the users. They will pass two date input parameters to the stored procedure:
						•	@p_ActivityDateTimeFrom 
						•	@p_ActivityDateTimeTo   

						The stored procedure will then select all the Log.vw_ActivityLog and Arch.vw_ActivityLog rows within the range of the above date parameters.

						Select records where:
						@p_ ActivityDateTimeFrom ≤ Logging.vw_ActivityLog. ActivityDateTime ≤ @p_ ActivityDateTimeTo

						UNION ALL

						@p_ ActivityDateTimeFrom ≤ Archive.vw_ActivityLog. ActivityStartDateTime ≤ @p_ ActivityDateTimeTo

						•	Remarks:

						1.	TRY/CATCH BLOCKS are required to handle errors in the stored procedure.

						2.	SQL Transactions (BEGIN TRAN/COMMIT) are not required for this stored procedure. 

						3.	SQL hint must be used in all the selects and joins in the stored procedure.
						'
		,@level0type = N'SCHEMA'
		,@level0name = N'Log'
		,@level1type = N'PROCEDURE'
		,@level1name = N'usp_ActivityLogReport';

GO

EXECUTE sp_addextendedproperty 
		 @name = N'Stored Procedure Definition'
		,@value = N'This stored procedure selects data from the Log.vw_ActivityLog and Arch.vw_ActivityLog views for reporting purposes and based on two input date parameters.'
		,@level0type = N'SCHEMA'
		,@level0name = N'Log'
		,@level1type = N'PROCEDURE'
		,@level1name = N'usp_ActivityLogReport';

GO

EXECUTE sp_addextendedproperty 
		 @name = N'Stored Procedure Parameters'
		,@value = N'Input:

					@p_ActivityDateTimeFrom - DATETIME2(2) – NOT NULL:
					The FROM period of the event date time of the records that need to be reported.

					@p_ActivityDateTimeTo - DATETIME2(2) – NOT NULL:
					The TO period of the event date time of the records that need to be reported.'
		,@level0type = N'SCHEMA'
		,@level0name = N'Log'
		,@level1type = N'PROCEDURE'
		,@level1name = N'usp_ActivityLogReport';

