﻿
-- =============================================
-- Author:		Ciprian Mandras
-- Create date: 2019.03.20
-- Description:	Used to log activities in the system
-- =============================================

CREATE PROCEDURE Log.usp_ActivityLog 
	 @p_ParentActivityLogId 		BIGINT			= NULL
	,@p_ActivityLogTag				BIGINT			= NULL
	,@p_ActivitySource 				SMALLINT
	,@p_ActivityType 				SMALLINT
	,@p_ActivityStatus 				SMALLINT 
	,@p_ActivityHost 				VARCHAR(100)
	,@p_ActivityDatabase 			VARCHAR(100)	= NULL
	,@p_ActivityJobId 				VARCHAR(50)		= NULL
	,@p_ActivitySSISExecutionId 	VARCHAR(50)		= NULL
	,@p_ActivityName 				VARCHAR(100)
	,@p_ActivityDateTime 			DATETIME2(2)
	,@p_ActivityMessage 			NVARCHAR(4000)	= NULL
	,@p_ActivityErrorCode 			NVARCHAR(50)	= NULL
	,@p_AffectedRows                INT             = 0
	,@p_ActivityLogId 				BIGINT OUTPUT
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @v_ErrorMessage NVARCHAR(4000)	

	BEGIN TRY

		INSERT INTO Log.ActivityLog
			   (
				FK_ParentActivityLog
			   ,FK_ActivityLogTag
			   ,FK_ActivitySource
			   ,FK_ActivityType
			   ,FK_ActivityStatus
			   ,ActivityHost
			   ,ActivityDatabase
			   ,ActivityJobId
			   ,ActivitySSISExecutionId
			   ,ActivityName
			   ,ActivityDateTime
			   ,ActivityMessage
			   ,ActivityErrorCode
			   ,AffectedRows
			   )
				   
		SELECT 
				 @p_ParentActivityLogId 
				,@p_ActivityLogTag
				,@p_ActivitySource 				
				,@p_ActivityType 				
				,@p_ActivityStatus 				
				,@p_ActivityHost 				
				,@p_ActivityDatabase 			
				,@p_ActivityJobId 				
				,@p_ActivitySSISExecutionId 	
				,@p_ActivityName 				
				,@p_ActivityDateTime 			
				,@p_ActivityMessage 			
				,@p_ActivityErrorCode 
				,@p_AffectedRows
		   
		 SELECT @p_ActivityLogId = SCOPE_IDENTITY()

	END TRY

	BEGIN CATCH
		
		-- LOG ERROR
		SELECT    @v_ErrorMessage = 'Logging framework error: ' + ERROR_MESSAGE()
		RAISERROR(@v_ErrorMessage, 16, 1)
	
	END CATCH
		
END

GO

EXECUTE sp_addextendedproperty 
		 @name = N'Stored Procedure Call'
		,@value = N'The procedure can be called from the external applications which will pass all the required parameters to insert just one
					 record per call in the activity log table Logging.ActivityLog.

					When a new activity is sent to the activity log the stored procedure will insert a single row in the Activity Log table, 
					generate a new ActivityLogId for the record and pass it back (SCOPE_IDENTITY) to the caller via an output parameter (@p_ActivityLogId). 

					To insert the data each column in the Logging.ActivityLog table has a linked input parameter (see list of input parameters).

					•	Remarks:

					1.	TRY/CATCH BLOCKS are required to handle errors in the stored procedure.

					2.	The insert operation will require all the ‘NOT NULL-able’ columns in the ActivityLog table to be populated.

					3.	The systems or callers will be responsible to maintain the linking of activities and reflect this in the activity log via the
					@p_ParentActivityLogId during the insert operations.

					4.	SQL Transactions (BEGIN TRAN/COMMIT) are not allowed in this stored procedure.'
		,@level0type = N'SCHEMA'
		,@level0name = N'Log'
		,@level1type = N'PROCEDURE'
		,@level1name = N'usp_ActivityLog';

GO

EXECUTE sp_addextendedproperty 
		 @name = N'Stored Procedure Definition'
		,@value = N'This stored procedure inserts records into the Logging.ActivityLog in the Logging Framework. Only inserts are allowed, no updates or deletes.'
		,@level0type = N'SCHEMA'
		,@level0name = N'Log'
		,@level1type = N'PROCEDURE'
		,@level1name = N'usp_ActivityLog';

GO

EXECUTE sp_addextendedproperty 
		 @name = N'Stored Procedure Parameters'
		,@value = N'Output:

					@p_ActivityLogId – BIGINT – NOT NULL:
					The generated unique ID (PK_ActivityLog value) of the activity recorded in the log table.

					Input:

					@p_ParentActivityLogId - BIGINT - NULL:
					Used to hierarchically link activities in the log (parent/child) using the PK_ActivityLog column values. NULL value for records with no parents.

					@p_ActivityLogTag – BIGINT - NULL:
					Used to link records within the same activity. For example, a SUCCEDED event is linked to its STARTED event via this field.

					@p_ActivitySource – SMALLINT - NOT NULL:
					The FK representing the name of the originator (data source or system) of the activity recorded in the log.

					@p_ActivityType – SMALLINT – NOT NULL:
					The FK representing the type of the activity recorded in the log.

					@p_ActivityStatus – SMALLINT – NOT NULL:
					The FK representing the status of the activity recorded in the log.

					@p_ActivityHost – VARCHAR(100) – NOT NULL:
					The name of the host from where the activity recorded in the log is generated.

					@p_ActivityDatabase – VARCHAR(100) – NULL:
					The name of the client database from where the activity recorded in the log is generated (if applicable).

					@p_ActivityJobId – VARCHAR(50) – NULL:
					Identifier of the job that is executed on the client server and generates the activity recorded in the log.

					@p_ActivitySSISExecutionId – VARCHAR(50) – NULL:
					Execution Id of the package that is executed on the Integration Services server that generates the activity recorded in the log.

					@p_ActivityName - VARCHAR(100) – NOT NULL:
					The name of the activity recorded in the log.

					@p_ActivityDateTime - DATETIME2(2) - NOT NULL:
					The date and time of the activity recorded in the log. This is when the activity is generated in the activity originator (client)

					@p_ActivityMessage - NVARCHAR(4000) – NULL:
					Information related to the activity recorded i.e. the error message of the activity in case of a failure.

					@p_ActivityErrorCode - NVARCHAR(50) - NULL:
					The system error code of the activity in case of a system failure.
					
					@p_AffectedRows - INT:
					The number of rows affected by the activity (if it is the case)'
		,@level0type = N'SCHEMA'
		,@level0name = N'Log'
		,@level1type = N'PROCEDURE'
		,@level1name = N'usp_ActivityLog';

