﻿
CREATE VIEW Log.vw_ActivityLog 
WITH SCHEMABINDING 
AS

SELECT LAL.PK_ActivityLog
	  ,LAL.FK_ParentActivityLog
	  ,LAL.FK_ActivityLogTag
	  ,LAL.FK_ActivitySource
	  ,LASrc.ActivitySource
	  ,LAL.FK_ActivityType
	  ,LAT.ActivityType
	  ,LAL.FK_ActivityStatus
	  ,LASts.ActivityStatus
	  ,LAL.ActivityHost 
	  ,LAL.ActivityDatabase
	  ,LAL.ActivityJobId
	  ,LAL.ActivitySSISExecutionId
	  ,LAL.ActivityName
	  ,LAL.ActivityDateTime
	  ,LAL.ActivityMessage
	  ,LAL.ActivityErrorCode
	  ,LAL.AffectedRows
	  ,LAL.AuditCreateDateTime
	  ,LAL.AuditModifyDateTime
	  ,LAL.AuditUserCreate
	  ,LAL.AuditUserModify

FROM Log.ActivityLog LAL 

INNER JOIN Log.ActivitySource LASrc 
ON LAL.FK_ActivitySource = LASrc.PK_ActivitySource

INNER JOIN Log.ActivityStatus LASts  
ON LAL.FK_ActivityStatus = LASts.PK_ActivityStatus

INNER JOIN Log.ActivityType LAT  
ON LAL.FK_ActivityType	 = LAT.PK_ActivityType

GO

EXECUTE sp_addextendedproperty 
		 @name = N'View Definition'
		,@value = N'This view is just a simple SELECT from the Logging.ActivityLog table for all columns and joined with the ActvitySource, ActivityType and ActivityStatus tables.
					•	Remarks: hint to be used in all table selects/joins.'
		,@level0type = N'SCHEMA'
		,@level0name = N'Log'
		,@level1type = N'VIEW'
		,@level1name = N'vw_ActivityLog';

