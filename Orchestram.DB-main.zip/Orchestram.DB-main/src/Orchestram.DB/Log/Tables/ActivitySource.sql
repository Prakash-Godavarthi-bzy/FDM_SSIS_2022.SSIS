﻿CREATE TABLE Log.ActivitySource (
     PK_ActivitySource       SMALLINT     NOT NULL
    ,ActivitySource          VARCHAR(50)  NOT NULL
    ,AuditCreateDateTime     DATETIME2(2) CONSTRAINT DF_ActivitySource_AuditCreateDateTime DEFAULT (GETUTCDATE())  NOT NULL
    ,AuditModifyDateTime     DATETIME2(2) NULL
    ,AuditUserCreate         VARCHAR(64)  CONSTRAINT DF_ActivitySource_AuditUserCreate     DEFAULT (SUSER_SNAME()) NOT NULL
    ,AuditUserModify         VARCHAR(64)  NULL
    ,PRIMARY KEY CLUSTERED (PK_ActivitySource ASC) WITH (FILLFACTOR = 90)
);

GO

----------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Table and columns documentation
----------------------------------------------------------------------------------------------------------------------------------------------------------------

EXECUTE sp_addextendedproperty 
         @name           = N'Table definition'
        ,@value          = N'Table to store the name of the systems that can insert data into the activity log. For example, FDM, IFRS17 or BI.'
        ,@level0type     = N'SCHEMA'
        ,@level0name     = N'Log'
        ,@level1type     = N'TABLE'
        ,@level1name     = N'ActivitySource';
GO

-- COLUMNS

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'The name of the originator (data source or system) of the activity recorded in the log.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Log'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'ActivitySource'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'ActivitySource';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to stamp date the records inserted in the activity table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Log'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'ActivitySource'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditCreateDateTime';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to track updates by date and time in the table records.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Log'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'ActivitySource'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditModifyDateTime';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to record the users,including service accounts that insert the records in the table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Log'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'ActivitySource'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditUserCreate';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to track updates by user in table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Log'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'ActivitySource'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditUserModify';
GO
