﻿CREATE TABLE [Lin].[Table] (
     PK_Table                 INT             IDENTITY(1,1) NOT NULL 
    ,DatabaseName             VARCHAR(50)     NOT NULL 
    ,TableName                VARCHAR(50)     NOT NULL
    ,SchemaName               VARCHAR(50)     NOT NULL
    ,SourceSystemField        VARCHAR(50)     NULL
    ,BusinessKeyField         VARCHAR(50)     NOT NULL
    ,RowHashField             VARCHAR(50)     NULL
    ,BusinessProcessField     VARCHAR(50)     NULL
    ,AuditDateField           VARCHAR(50)     NOT NULL
	,ValueField               VARCHAR(50)     NOT NULL
	,LineageLevel             INT             CONSTRAINT DF_Table_LineageLevel         DEFAULT (0)             NOT NULL
    ,AuditCreateDateTime      DATETIME2(2)    CONSTRAINT DF_Table_AuditCreateDateTime  DEFAULT (GETUTCDATE())  NOT NULL 
    ,AuditModifyDateTime      DATETIME2(2)    NULL 
    ,AuditUserCreate          VARCHAR(64)     CONSTRAINT DF_Tableg_AuditUserCreate     DEFAULT (SUSER_SNAME()) NOT NULL 
    ,AuditUserModify          VARCHAR(64)     NULL 
    ,PRIMARY KEY CLUSTERED (PK_Table ASC) WITH (FILLFACTOR = 90)
);

GO

----------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Table and columns documentation
----------------------------------------------------------------------------------------------------------------------------------------------------------------

EXECUTE sp_addextendedproperty 
         @name           = N'Table definition'
        ,@value          = N'Table used to store tables that will be scanned for Lineage Framework report.'
        ,@level0type     = N'SCHEMA'
        ,@level0name     = N'Lin'
        ,@level1type     = N'TABLE'
        ,@level1name     = N'Table';
GO

-- COLUMNS

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Database to which source table belong.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Lin'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Table'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'DatabaseName';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'The source table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Lin'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Table'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'TableName';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Schema to which source table belong. For FinanceLanding tables represents the SourceSystem too.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Lin'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Table'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'SchemaName';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'The field on which the SourceSystemName is. If it is null, the report will return the value from SchemaName field of this table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Lin'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Table'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'SourceSystemField';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'The field on which the BusinessKey is.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Lin'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Table'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'BusinessKeyField';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'The field on which the RowHash to be returned is.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Lin'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Table'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'RowHashField';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'The field on which the Business Process to be returned is.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Lin'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Table'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'BusinessProcessField';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'The field on which the audit date to be returned is.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Lin'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Table'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditDateField';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'The field on which the Value to be returned is.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Lin'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Table'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'ValueField';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Order used to report data'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Lin'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Table'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'LineageLevel';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to stamp date the records inserted in the table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Lin'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Table'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditCreateDateTime';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to track updates by date and time in the table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Lin'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Table'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditModifyDateTime';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to record the users including service accounts that insert the records in the table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Lin'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Table'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditUserCreate';
GO

EXECUTE sp_addextendedproperty 
         @name          = N'MS_Description'
        ,@value         = N'Audit column to track updates by user in the table.'
        ,@level0type    = N'SCHEMA'
        ,@level0name    = N'Lin'
        ,@level1type    = N'TABLE'
        ,@level1name    = N'Table'
        ,@level2type    = N'COLUMN'
        ,@level2name    = N'AuditUserModify';

