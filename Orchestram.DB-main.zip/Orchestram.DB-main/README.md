## Orchestram.DB <a href="http://teamcity.bfl.local/viewType.html?buildTypeId=PerforceMigration_SolidOpsDb_Master&guest=1" target="_blank">
<img src="http://teamcity.bfl.local/app/rest/builds/buildType:(id:PerforceMigration_SolidOpsDb_Master)/statusIcon"/>
</a> <a href="http://ukdvdv132:9211/sonar/dashboard/index/Orchestram.DB:master" target="_blank">
<img src="http://ukdvdv132:9211/sonar/api/badges/gate?key=Orchestram.DB:master"/>
</a> <a href="http://ukdvdv132:9211/sonar/dashboard/index/Orchestram.DB:master" target="_blank">
<img src="http://ukdvdv132:9211/sonar/api/badges/measure?key=Orchestram.DB:master&metric=code_smells"/>
</a>
   
 ### High level features
- SSDT with Visual Studio => DACPAC
  - Validate syntax errors at build (CI) => deployable DACPAC, existing in MS SQL Server since 2008 R2
  - DACPAC versioning (database versioning) via nuget or native feature
  - SQL Compare both ways:
    - Visual Studio project vs SQL Server Database
    - Database vs DACPAC
    - Visual Studio project vs DACPAC
  - SQL Code Smells and push results to SonarQube in order to have a web overview
  - No need for a deployment to a blank database in order to test the structure
  - Logins & Linked servers scripted in the project structure
  - Cross database reference – the ability to reference another SSDT/DACPAC database and validate model against it
  - Specific environment variables that can be sent via command line at deployment (ie. Linked servers, DB names on different environments)
  - Azure ready
   -… and more
- SSDT minor adjustments – Visual Studio project template
  - Static data ready
  - SQL Jobs ready
  - One time scripts ready
- TeamCity and OctopusDeploy ready
  - Chocolatey install dependencies
- SQL Unit testing via MS Test example
  - 1 x simple scenario
- Continuous Code Quality with SonarQube (open source platform) example
- There are no extra licensing costs for this solution
- Compatible with any ORM (Entity Framework, ActiveRecord, NHibernate etc.). Best suitable for Database first developments
- DBGhost can be added over the existing structure at any point if required – just add and configure the xml manifest. As a note, SSDT covers everything from DBGhost
