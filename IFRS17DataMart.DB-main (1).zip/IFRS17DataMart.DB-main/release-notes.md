Sprint0
- add QA OD channel
- add Default Values for tables Inbound.TechHub_AccPer_Control, Outbound.AccPer_AsAt_Control
- Added/Updated IDS tables for new OBs
- Added/Altered IDS Views for new OBs
- Altered the [fct].[usp_PopulateIDSOB] to included the newly created OBs
- I17-3256 and I17-3193 changes
Sprint1
- Altered the Assumption View as per the ticket no I17-3286
- DB Cleanup(tables,views,storedprocs) as per the story I17-3268
- Stored procedure updated by removing two accounts I17-1582(3356) and altered the [fct].[usp_PopulateIDS_EP_Weighted] stored procedure
- Updated the Programme column as "GROSS" Instead of "Gross" in the outbound views(I17-3359 and I17-3344)
- Altered the view (rpt.vw_bm_factAssumptions) for the ticket 17-3280
- Altered the view ([PWAPS].[vw_dv_updateRuleset]) for the ticket 17-3350
Sprint2
-Updated [fct].[usp_PopulateIDS_EP_Weighted] Stored Procedure and [fct].[usp_PopulateIDS_EP_Weighted] view for duplicates created by LTD Process(I17-3407)
-Updated PWAPS.ExceptionData view For Schedule time to be UK time (I17-3331)
-Updated [fct].[usp_PopulateIDSOB] procedure and added IDS.CSMReleaseBalancesOB table (I17-3457)
-Predeployment Code added for System generated Assumptions views.
Sprint3
-Updated Column lengths for CCY and TriFocusCode (I17-3496)
-Add Default value for outbound RunID table (I17-3500)
-Fixed the scientific exponential format in the rebates file (I17-3442)
-Added Column ReportingDateOpen (I17-3481)
-Sprint4
-Added IDS static tables for I17-3449
-Added outbound views-[Outbound].[vw_IDS_FX_Info],[Outbound].[vw_IDS_BalHeader],[Outbound].[vw_IDS_Cashflow_Discount],[Outbound].[vw_IDS_SpotToForward],[Outbound].[vw_ICE_RunInformation]
-Updated the [fct].[usp_PopulateIDSOB] stored procedure to avoid duplicates for OB tables.
-Added the Claims Basis column to the [stg].[fct_TechnicalResult] table
-Updated IDS.BalHeader table Data.
-Altered FXRate and Pattern table and added PredeploymentScript.
-New columns were added to the Dim.PolicySection and stg.Dim_PolicySection tables
-Update Cashflow&Discount and SpotToForward data (I17-3789)
-Fixed the bug ENIDs assumptions coming in with a Loss Type (I17-3787)
-Bug fix for duplicates values in [IDS].[AssumptionPercentages] table (I17-3663)
-Assumptions must not allow duplicate records (I17-2435)
-Filtering RI Percentage view (I17-3745)
-RI Flag Corrected In [IDS].[Aggr_Claims] (I17-2915)
-Added YTDQTD column to logtable PWAPS.IFRS17CalcUI_RunLog and view [Outbound].[vw_ICE_RunInformation] (I17-3536)
-Alter the column from reporting ccy to  reporting currency in the view [rpt].[vw_bm_factFXRate]
-PreDeployment Script changed because of deployment failure in NFT(I17-3878)
-Added policySection,policyMOPCode,PolicyCOB Codes from BR1 Sprint11 changes.
-Updated Assumption upload Procedures and function to include Entity column for IELR(Pure). 
-Added InceptionDate and Expirydate to technicalResult table.
-updated Premium Brokerage Procedure for I17-3900
-Sprint5
-Updated IDS.FCT_Adjustments table to inlcude DataSetID
-Update stactic data for IDS.BalHeader and IDS.Cashflow_Discount(I17-4051, I17-4049)
-Changes included(tables, sPs) in the database as per the story I17-2583
-updated Three procedures that populate SM I17-4122
-DataType changed for Value and Value2 from int to Numeric(38,12)(I17-4134)
-Dv.GetForeignKeys function changed(I17-4135)
-rpt.vw_bm_dimTrifocus view altered (I17-4174)
-Sprint6
-Altered the storedprocedures related to the AMA flows and added a new column to the stg_UploadedAssumptionErrors(I17-3295).
-Created the table and written the merge script for the story I17-4259.
-Sprint7
-Bug fix for AMA Error is displayed twice in stg_UploadedAssumptionErrors(I17-4379).
-Views are altered as per the story requirement I17-2811.
-ValidationRuleType3 procedure altered(I17-4381).
-updated [fct].[usp_PopulateIntermediaryDiscountRt] (I17-4402)
-Updates for static tables IDS.Cashflow_Discount,BalHeader,SpotToForward(I17-4418)
-Sprint7.A
-Static data update for IDS.Cashflow_Discount table(I17-4461).
-Added view for TopUPReference table(I17-4360).
-Created a view Outbound.vw_IDS_RIPercentage from fct.RI_Percentage(I17-4433).
-Typo corrected for the outbound View(I17-4360).
-Sprint7.B
- RI Earnings change to Outbound.vw_RIPercentage(I17-4661).
- Business Plan data to Supplement Missing PFT(17-4609).
-Sprint7.D
-Exportlog view updated as per the ticket I17-1364.


 Sprint15
   - IDM DB - added new columns to the log table to capture ICE approved details (I17-6747)
Sprint15.3  

-Update [Outbound].[vw_IDS_Cashflow_Discount](I17-7184)

-Update [Dim].[TopUPReference](I17-7204)

-Add "CM Earn" column to TF Mapping table and associated views(I17-6919)

  




