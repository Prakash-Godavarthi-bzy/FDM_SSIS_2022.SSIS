Create Table Dim.TopUPReference
(
PK_TopUpReference int identity(1,1) NOT NULL,
Entity Varchar(50) NOT NULL,
TopUp Char(2) NOT NULL,
AuditCreateDateTime [datetime2](7) NOT NULL Default(getdate()),
AuditUserCreate [nvarchar](510) NOT NULL Default(suser_name())
)




