﻿CREATE TABLE [Dim].[AccountCodeMapping_History] (
    [PK_AccCodeMapping]       INT            NOT NULL,
    [AssumptionDatasetNameID] INT            NOT NULL,
    [AccountCode]             VARCHAR (15)   NOT NULL,
    [Type]                    VARCHAR (30)   NULL,
    [Source]                  VARCHAR (50)   NULL,
    [FieldLabel]              VARCHAR (30)   NULL,
    [IsActive]                INT            NOT NULL,
	[ProcessFlow]             VARCHAR(10)  NULL,
    [CreatedDt]               DATETIME       NULL,
    [CreatedBy]               NVARCHAR (150) NULL,
    [UpdatedDt]               DATETIME       NULL,
    [UpdatedBy]               NVARCHAR (150) NULL,
    [ValidFrom]               DATETIME2 (7)  NOT NULL,
    [ValidTo]                 DATETIME2 (7)  NOT NULL
);


GO


CREATE CLUSTERED INDEX [ix_AccountCodeMapping_History]
    ON [Dim].[AccountCodeMapping_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

