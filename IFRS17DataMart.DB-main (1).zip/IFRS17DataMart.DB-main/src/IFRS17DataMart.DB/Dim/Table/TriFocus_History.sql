﻿CREATE TABLE [dim].[TriFocus_History] (
	[PK_TriFocus]    VARCHAR (25)  NOT NULL,
    [TriFocusName]   VARCHAR (50)  NULL,
    [TriFocusLevel1] VARCHAR (50)  NULL,
    [TriFocusLevel2] VARCHAR (100) NULL,
    [TriFocusLevel3] VARCHAR (100) NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    [ValidFrom]      DATETIME2 (7) NOT NULL,
    [ValidTo]        DATETIME2 (7) NOT NULL
);




GO
CREATE CLUSTERED INDEX [ix_TriFocus_History]
    ON [dim].[TriFocus_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

