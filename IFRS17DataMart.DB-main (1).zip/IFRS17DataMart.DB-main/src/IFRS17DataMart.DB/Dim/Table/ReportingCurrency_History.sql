﻿CREATE TABLE [Dim].[ReportingCurrency_History] (
    [PK_ReportingCurrencyCode] NVARCHAR (255) NOT NULL,
    [ReportingCurrencyName]    NVARCHAR (255) NULL,
    [ValidFrom]                DATETIME2 (7)  NOT NULL,
    [ValidTo]                  DATETIME2 (7)  NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_ReportingCurrency_History]
    ON [Dim].[ReportingCurrency_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

