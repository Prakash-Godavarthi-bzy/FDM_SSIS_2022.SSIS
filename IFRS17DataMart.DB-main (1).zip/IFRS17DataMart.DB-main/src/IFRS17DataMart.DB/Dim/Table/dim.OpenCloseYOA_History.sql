﻿CREATE TABLE [Dim].[OpenCloseYOA_History] (
    [Id]                  INT            NOT NULL,
    [FK_AccountingPeriod] VARCHAR (6)    NOT NULL,
    [Programme]           VARCHAR (100)  NOT NULL,
    [FK_Trifocus]         VARCHAR (25)   NOT NULL,
    [FK_YOA]              INT            NOT NULL,
    [Open_Cls_Flag]       VARCHAR (10)   NOT NULL,
    [AuditCreateDateTime] DATETIME2 (7)  NOT NULL,
    [AuditUserCreate]     NVARCHAR (510) NOT NULL,
    [ValidFrom]           DATETIME2 (7)  NOT NULL,
    [ValidTo]             DATETIME2 (7)  NOT NULL
);




GO
CREATE CLUSTERED INDEX [ix_OpenCloseYOA_History]
ON [dim].[OpenCloseYOA_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

