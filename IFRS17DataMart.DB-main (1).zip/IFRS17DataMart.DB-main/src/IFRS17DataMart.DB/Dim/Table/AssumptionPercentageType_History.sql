﻿CREATE TABLE [Dim].[AssumptionPercentageType_History]
(
	[Pk_AssumptionPercentageTypeId] [int] NOT NULL,
	[AssumptionPercentageType] [nvarchar](35) NULL,
	[CreatedDt] [datetime] NULL,
	[CreatedBy] [nvarchar](150) NULL,
	[UpdatedDt] [datetime] NULL,
	[UpdatedBy] [nvarchar](150) NULL,
	[ValidFrom] [datetime2](7) NOT NULL,
	[ValidTo] [datetime2](7) NOT NULL,
	[HelpLink] [nvarchar](255) NULL
) ON [PRIMARY]
GO