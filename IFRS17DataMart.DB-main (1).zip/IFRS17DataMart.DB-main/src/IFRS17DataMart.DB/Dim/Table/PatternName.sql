﻿CREATE TABLE [dim].[PatternName] (
	[PK_PatternName] VARCHAR (20)                                NOT NULL,
    --[SourceTable]    VARCHAR (200)                               NULL,
    [PatternName]   VARCHAR (200)                               NULL,
   -- [PatternRef]     VARCHAR (20)                                NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    [ValidFrom]      DATETIME2 (7) GENERATED ALWAYS AS ROW START NOT NULL,
    [ValidTo]        DATETIME2 (7) GENERATED ALWAYS AS ROW END   NOT NULL,
    CONSTRAINT [PK_PatternName] PRIMARY KEY CLUSTERED ([PK_PatternName] ASC),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[dim].[PatternName_History], DATA_CONSISTENCY_CHECK=ON));

