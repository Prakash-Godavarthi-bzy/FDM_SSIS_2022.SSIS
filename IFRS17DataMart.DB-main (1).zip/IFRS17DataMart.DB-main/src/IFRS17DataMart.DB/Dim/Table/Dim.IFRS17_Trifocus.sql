﻿CREATE TABLE [Dim].[IFRS17_Trifocus] (
    [Trifocus_Id]         INT                                         IDENTITY (1, 1) NOT NULL,
    [FK_AccountingPeriod] INT                                         NOT NULL,
    [BK_PolicyNumber]     VARCHAR (50)                                NOT NULL,
    [FK_YOA]              INT                                         NOT NULL,
    [IFRS17_Trifocus]     VARCHAR (25)                                NOT NULL,
    [AuditCreateDateTime] DATETIME2 (7)                               DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]     NVARCHAR (510)                              DEFAULT (suser_sname()) NOT NULL,
    [ValidFrom]           DATETIME2 (7) GENERATED ALWAYS AS ROW START NOT NULL,
    [ValidTo]             DATETIME2 (7) GENERATED ALWAYS AS ROW END   NOT NULL,
    CONSTRAINT [Trifocus_Id] PRIMARY KEY CLUSTERED ([Trifocus_Id] ASC) WITH (FILLFACTOR = 90),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[Dim].[IFRS17_Trifocus_History], DATA_CONSISTENCY_CHECK=ON));


GO
CREATE NONCLUSTERED INDEX [IX_IFRS17_Trifocus_AccountingPeriod] ON  [Dim].[IFRS17_Trifocus]
(
[FK_AccountingPeriod] ASC
)
GO
  