﻿CREATE TABLE [Dim].[Entity] (
    [PK_Entity]    VARCHAR (25)                                NOT NULL,
    [Entity]       VARCHAR (50)                                NULL,
    [EntityName]   VARCHAR (50)                                NULL,
    [Platform]     VARCHAR (10)                                NULL,
    [EntityLevel1] VARCHAR (50)                                NULL,
    [EntityLevel2] VARCHAR (50)                                NULL,
    [EntityLevel3] VARCHAR (50)                                NULL,
    [EntityLevel4] VARCHAR (50)                                NULL,
    [EntityLevel5] VARCHAR (50)                                NULL,
    [ValidFrom]    DATETIME2 (7) GENERATED ALWAYS AS ROW START NOT NULL,
    [ValidTo]      DATETIME2 (7) GENERATED ALWAYS AS ROW END   NOT NULL,
    CONSTRAINT [PK_Entity] PRIMARY KEY CLUSTERED ([PK_Entity] ASC) WITH (FILLFACTOR = 90),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[Dim].[Entity_History], DATA_CONSISTENCY_CHECK=ON));

