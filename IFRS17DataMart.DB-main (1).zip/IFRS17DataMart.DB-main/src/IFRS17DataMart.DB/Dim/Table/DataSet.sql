﻿CREATE TABLE [dim].[DataSet] (
	[PK_DataSet]   VARCHAR (255)     NOT NULL,
    [SourceSystem] VARCHAR (50)      NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    [ValidFrom]    DATETIME2 (7) GENERATED ALWAYS AS ROW START NOT NULL,
    [ValidTo]      DATETIME2 (7) GENERATED ALWAYS AS ROW END   NOT NULL,
    CONSTRAINT [PK_DataSet] PRIMARY KEY CLUSTERED ([PK_DataSet] ASC),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[dim].[DataSet_History], DATA_CONSISTENCY_CHECK=ON));





