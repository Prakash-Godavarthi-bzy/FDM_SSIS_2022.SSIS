﻿CREATE TABLE [Dim].[ReportingCurrency] (
    [PK_ReportingCurrencyCode] NVARCHAR (255)                              NOT NULL,
    [ReportingCurrencyName]    NVARCHAR (255)                              NULL,
    [ValidFrom]                DATETIME2 (7) GENERATED ALWAYS AS ROW START NOT NULL,
    [ValidTo]                  DATETIME2 (7) GENERATED ALWAYS AS ROW END   NOT NULL,
    CONSTRAINT [PK_ReportingCurrency] PRIMARY KEY CLUSTERED ([PK_ReportingCurrencyCode] ASC) WITH (FILLFACTOR = 90),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[Dim].[ReportingCurrency_History], DATA_CONSISTENCY_CHECK=ON));

