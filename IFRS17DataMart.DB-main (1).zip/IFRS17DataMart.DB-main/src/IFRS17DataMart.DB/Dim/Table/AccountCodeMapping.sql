﻿CREATE TABLE [Dim].[AccountCodeMapping] (
    [PK_AccCodeMapping]       INT                                         IDENTITY (1, 1) NOT NULL,
    [AssumptionDatasetNameID] INT                                         NOT NULL,
    [AccountCode]             VARCHAR (15)                                NOT NULL,
    [Type]                    VARCHAR (30)                                NULL,
    [Source]                  VARCHAR (50)                                NULL,
    [FieldLabel]              VARCHAR (30)                                NULL,
    [IsActive]                INT                                         NOT NULL,
	[ProcessFlow]             VARCHAR(10)  NULL,
    [CreatedDt]               DATETIME                                    NULL,
    [CreatedBy]               NVARCHAR (150)                              NULL,
    [UpdatedDt]               DATETIME                                    NULL,
    [UpdatedBy]               NVARCHAR (150)                              NULL,
    [ValidFrom]               DATETIME2 (7) GENERATED ALWAYS AS ROW START NOT NULL,
    [ValidTo]                 DATETIME2 (7) GENERATED ALWAYS AS ROW END   NOT NULL,
    CONSTRAINT [PK_AccCodeMapping] PRIMARY KEY CLUSTERED ([PK_AccCodeMapping] ASC) WITH (FILLFACTOR = 90),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[Dim].[AccountCodeMapping_History], DATA_CONSISTENCY_CHECK=ON));


GO
