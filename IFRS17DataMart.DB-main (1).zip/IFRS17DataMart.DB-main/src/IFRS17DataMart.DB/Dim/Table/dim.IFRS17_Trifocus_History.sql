﻿CREATE TABLE [Dim].[IFRS17_Trifocus_History] (
    [Trifocus_Id]         INT            NOT NULL,
    [FK_AccountingPeriod] INT            NOT NULL,
    [BK_PolicyNumber]     VARCHAR (50)   NOT NULL,
    [FK_YOA]              INT            NOT NULL,
    [IFRS17_Trifocus]     VARCHAR (25)   NOT NULL,
    [AuditCreateDateTime] DATETIME2 (7)  NOT NULL,
    [AuditUserCreate]     NVARCHAR (510) NOT NULL,
    [ValidFrom]           DATETIME2 (7)  NOT NULL,
    [ValidTo]             DATETIME2 (7)  NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_IFRS17_Trifocus_History]
    ON [dim].[IFRS17_Trifocus_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);