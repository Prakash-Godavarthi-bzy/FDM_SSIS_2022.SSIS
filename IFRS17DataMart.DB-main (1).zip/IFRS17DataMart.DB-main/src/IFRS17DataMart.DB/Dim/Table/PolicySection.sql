﻿CREATE TABLE [Dim].[PolicySection] (
    [PK_PolicySection]    VARCHAR (255)                               NOT NULL,
    [PolicyReference]     VARCHAR (50)                                NULL,
    [SectionReference]    VARCHAR (100)                               NULL,
    [InceptionDate]       DATETIME                                    NULL,
    [ExpiryDate]          DATETIME                                    NULL,
    [PolicyYOA]           INT                                         NULL,
    [PolicyType]          VARCHAR (50)                                NULL,
    [BindDate]            DATE                                        NULL,
    [TypeOfBusiness]      VARCHAR (10)                                NULL,
    [MaxEarningDate]      DATE                                        NULL,
    [IsUSPolicy]          BIT                                         DEFAULT ((0)) NULL,
	[PolicyClaimBasis]    VARCHAR (10)                                NULL,
    [PolicyMOPCode]		  VARCHAR (10)                                NULL,
    [PolicyCobCode]		  VARCHAR (10)                                NULL,			 
	[AuditSourceBatchID]  VARCHAR (255)                               NULL,
    [AuditCreateDateTime] DATETIME                                    DEFAULT (getutcdate()) NOT NULL,
    [AuditUserCreate]     VARCHAR (255)                               DEFAULT (suser_sname()) NOT NULL,
    [AuditHost]           VARCHAR (255)                               DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))) NULL,
    [ValidFrom]           DATETIME2 (7) GENERATED ALWAYS AS ROW START NOT NULL,
    [ValidTo]             DATETIME2 (7) GENERATED ALWAYS AS ROW END   NOT NULL,
    CONSTRAINT [PK_PolicySection] PRIMARY KEY CLUSTERED ([PK_PolicySection] ASC) WITH (FILLFACTOR = 90),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[Dim].[PolicySection_History], DATA_CONSISTENCY_CHECK=ON));



