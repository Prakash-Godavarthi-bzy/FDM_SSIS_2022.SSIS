﻿CREATE TABLE [Dim].[Account] (
    [PK_Account]          VARCHAR (50)                                NOT NULL,
    [AccountName]         VARCHAR (100)                               NULL,
    [Level1Group]         VARCHAR (100)                               NULL,
    [Level2Group]         VARCHAR (100)                               NULL,
    [Level3Group]         VARCHAR (100)                               NULL,
    [RIFlag]              VARCHAR (2)                                 NULL,
    [AuditSourceBatchID]  VARCHAR (255)                               NULL,
    [AuditCreateDateTime] DATETIME                                    DEFAULT (getutcdate()) NOT NULL,
    [AuditUserCreate]     VARCHAR (255)                               DEFAULT (suser_sname()) NOT NULL,
    [AuditHost]           VARCHAR (255)                               DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))) NULL,
    [ValidFrom]           DATETIME2 (7) GENERATED ALWAYS AS ROW START NOT NULL,
    [ValidTo]             DATETIME2 (7) GENERATED ALWAYS AS ROW END   NOT NULL,
    CONSTRAINT [PK_Account] PRIMARY KEY CLUSTERED ([PK_Account] ASC) WITH (FILLFACTOR = 90),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[Dim].[Account_History], DATA_CONSISTENCY_CHECK=ON));



