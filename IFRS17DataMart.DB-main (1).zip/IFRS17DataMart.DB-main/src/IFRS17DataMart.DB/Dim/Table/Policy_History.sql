﻿CREATE TABLE [Dim].[Policy_History] (
    [PK_Policy]        VARCHAR (118) NOT NULL,
    [BK_PolicyNumber]  VARCHAR (25)  NULL,
    [SectionReference] VARCHAR (25)  NULL,
    [InceptionDate]    DATETIME      NULL,
    [ExpiryDate]       DATETIME      NULL,
    [PolicyYOA]        INT           NULL,
    [PolicyType]       VARCHAR (50)  NULL,
    [PolicyPattern]    VARCHAR (10)  NULL,
    [BindDate]         DATE          NULL,
    [TypeOfBusiness]   VARCHAR (10)  NULL,
    [MaxEarningDate]   DATE          NULL,
    [ValidFrom]        DATETIME2 (7) NOT NULL,
    [ValidTo]          DATETIME2 (7) NOT NULL,
    [IsUSPolicy]       BIT           NULL
);


GO
CREATE CLUSTERED INDEX [ix_Policy_History]
    ON [Dim].[Policy_History]([ValidTo] ASC, [ValidFrom] ASC);

