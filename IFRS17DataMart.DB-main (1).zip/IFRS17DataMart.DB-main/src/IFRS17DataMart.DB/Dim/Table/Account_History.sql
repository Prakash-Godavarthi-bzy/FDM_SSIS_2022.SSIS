﻿CREATE TABLE [Dim].[Account_History] (
    [PK_Account]          VARCHAR (50)  NOT NULL,
    [AccountName]         VARCHAR (100) NULL,
    [Level1Group]         VARCHAR (100) NULL,
    [Level2Group]         VARCHAR (100) NULL,
    [Level3Group]         VARCHAR (100) NULL,
    [RIFlag]              VARCHAR (2)   NULL,
    [AuditSourceBatchID]  VARCHAR (255) NULL,
    [AuditCreateDateTime] DATETIME      DEFAULT (getutcdate()) NOT NULL,
    [AuditUserCreate]     VARCHAR (255) DEFAULT (suser_sname()) NOT NULL,
    [AuditHost]           VARCHAR (255) DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))) NULL,
    [ValidFrom]           DATETIME2 (7) NOT NULL,
    [ValidTo]             DATETIME2 (7) NOT NULL
);






GO
CREATE CLUSTERED INDEX [ix_Account_History]
    ON [dim].[Account_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

