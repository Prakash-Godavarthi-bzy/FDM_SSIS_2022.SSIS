﻿CREATE TABLE [Dim].[YOA]
(
	[PK_YOA]    VARCHAR(10)            NOT NULL, 
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    [ValidFrom] DATETIME2 GENERATED ALWAYS AS ROW START NOT NULL, 
    [ValidTo] DATETIME2 GENERATED ALWAYS AS ROW END NOT NULL, 
	PERIOD FOR SYSTEM_TIME (ValidFrom,ValidTo),
    CONSTRAINT [PK_YOA] PRIMARY KEY ([PK_YOA])
)WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = [Dim].[YOA_History])
);

