﻿CREATE TABLE [Dim].[ADMAsAtDate_History](
	[Id] [int] NOT NULL,
	[AsAt] [int] NULL,
	[SysStart] [datetime2](7) NOT NULL,
	[SysEnd] [datetime2](7) NOT NULL
) ON [PRIMARY]
GO
