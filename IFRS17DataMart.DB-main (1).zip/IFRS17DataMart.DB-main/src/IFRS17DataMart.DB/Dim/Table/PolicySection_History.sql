﻿CREATE TABLE [Dim].[PolicySection_History] (
    [PK_PolicySection]    VARCHAR (255) NOT NULL,
    [PolicyReference]     VARCHAR (50)  NULL,
    [SectionReference]    VARCHAR (100) NULL,
    [InceptionDate]       DATETIME      NULL,
    [ExpiryDate]          DATETIME      NULL,
    [PolicyYOA]           INT           NULL,
    [PolicyType]          VARCHAR (50)  NULL,
    [BindDate]            DATE          NULL,
    [TypeOfBusiness]      VARCHAR (10)  NULL,
    [MaxEarningDate]      DATE          NULL,
    [IsUSPolicy]          BIT           NULL,
	[PolicyClaimBasis]    VARCHAR (10)                                NULL,
    [PolicyMOPCode]		  VARCHAR (10)                                NULL,
    [PolicyCobCode]		  VARCHAR (10)                                NULL,	
    [AuditSourceBatchID]  VARCHAR (255) NULL,
    [AuditCreateDateTime] DATETIME      NOT NULL,
    [AuditUserCreate]     VARCHAR (255) NOT NULL,
    [AuditHost]           VARCHAR (255) NULL,
    [ValidFrom]           DATETIME2 (7) NOT NULL,
    [ValidTo]             DATETIME2 (7) NOT NULL
);




GO
CREATE CLUSTERED INDEX [ix_PolicySection_History]
    ON [Dim].[PolicySection_History]([ValidTo] ASC, [ValidFrom] ASC);

