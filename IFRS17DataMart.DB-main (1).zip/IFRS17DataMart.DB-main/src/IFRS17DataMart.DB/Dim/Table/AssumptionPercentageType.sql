﻿CREATE TABLE [Dim].[AssumptionPercentageType]
(
	[Pk_AssumptionPercentageTypeId] [int] IDENTITY(1,1) NOT NULL,
	[AssumptionPercentageType] [nvarchar](35) NULL,
	[CreatedDt] [datetime] NULL,
	[CreatedBy] [nvarchar](150)  NULL,
	[UpdatedDt] [datetime] NULL,
	[UpdatedBy] [nvarchar](150) ,
	[ValidFrom] [datetime2](7) GENERATED ALWAYS AS ROW START NOT NULL,
	[ValidTo] [datetime2](7) GENERATED ALWAYS AS ROW END NOT NULL,
	[HelpLink] [nvarchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[Pk_AssumptionPercentageTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY],
	PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
) ON [PRIMARY]
WITH
(
SYSTEM_VERSIONING = ON ( HISTORY_TABLE = [Dim].[AssumptionPercentageType_History] )
)
GO

ALTER TABLE [Dim].[AssumptionPercentageType] ADD  CONSTRAINT [DF_UpdatedDt]  DEFAULT (getdate()) FOR [UpdatedDt]
GO

ALTER TABLE [Dim].[AssumptionPercentageType] ADD  CONSTRAINT [DF_UpdatedBy]  DEFAULT (suser_name()) FOR [UpdatedBy]
GO