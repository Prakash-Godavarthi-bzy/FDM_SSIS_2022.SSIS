﻿CREATE TABLE [Dim].[TrifocusMapping] (
    [PK_TrifocusMapping]      INT                                         IDENTITY (1, 1) NOT NULL,
    [AssumptionDatasetNameID] INT                                         NOT NULL,
    [TriFocusCode]            VARCHAR (25)                                NOT NULL,
    [TriFocusName]            VARCHAR (60)                                NULL,
    [Division]                VARCHAR (60)                                NULL,
    [Focus Group]             VARCHAR (100)                               NULL,
    [IsActive]                INT                                         NOT NULL,
    [CreatedDt]               DATETIME                                    NULL,
    [CreatedBy]               NVARCHAR (150)                              NULL,
    [UpdatedDt]               DATETIME                                    NULL,
    [UpdatedBy]               NVARCHAR (150)                              NULL,
    [ValidFrom]               DATETIME2 (7) GENERATED ALWAYS AS ROW START NOT NULL,
    [ValidTo]                 DATETIME2 (7) GENERATED ALWAYS AS ROW END   NOT NULL,
    [CM Earn]                 VARCHAR (3)                                 NULL,
    CONSTRAINT [PK_TrifocusMapping] PRIMARY KEY CLUSTERED ([PK_TrifocusMapping] ASC) WITH (FILLFACTOR = 90),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[Dim].[TrifocusMapping_History], DATA_CONSISTENCY_CHECK=ON));


GO
