Create Table Dim.DataCheckAccount
(
ID int identity(1,1),
[PK_AccountCode] nvarchar(35) NULL,
[AccountName] nvarchar(36) NULL,
[AccountSource] varchar(24) Not null,
[AccountTableName]  varchar(39) Not null,
[AuditCreateDateTime] [datetime] default getdate() NULL,
[AuditUserCreate] [varchar](255) default suser_name() NULL
)