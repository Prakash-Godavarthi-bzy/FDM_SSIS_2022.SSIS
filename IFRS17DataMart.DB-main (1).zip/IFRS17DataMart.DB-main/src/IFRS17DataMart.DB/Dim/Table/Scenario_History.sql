﻿CREATE TABLE [Dim].[Scenario_History] (
    [PK_Scenario]         VARCHAR (10)  NOT NULL,
    [ScenarioName]        VARCHAR (50)  NULL,
    [AuditSourceBatchID]  VARCHAR (255) NULL,
    [AuditCreateDateTime] DATETIME      NOT NULL,
    [AuditUserCreate]     VARCHAR (255) NOT NULL,
    [AuditHost]           VARCHAR (255) NULL,
    [ValidFrom]           DATETIME2 (7) NOT NULL,
    [ValidTo]             DATETIME2 (7) NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_Scenario_History]
    ON [Dim].[Scenario_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

