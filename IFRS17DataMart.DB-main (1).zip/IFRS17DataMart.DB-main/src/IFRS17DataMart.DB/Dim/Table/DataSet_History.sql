﻿CREATE TABLE [dim].[DataSet_History] (
	[PK_DataSet]   VARCHAR (255) NOT NULL,
    [SourceSystem] VARCHAR (50)  NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    [ValidFrom]    DATETIME2 (7) NOT NULL,
    [ValidTo]      DATETIME2 (7) NOT NULL
);








GO
CREATE CLUSTERED INDEX [ix_DataSet_History]
    ON [dim].[DataSet_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

