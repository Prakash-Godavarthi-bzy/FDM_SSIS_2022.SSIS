CREATE TABLE [Dim].[AssumptionDatasets] (
    [Pk_AssumptionDatasetNameId]   INT                                         IDENTITY (1, 1) NOT NULL,
    [AssumptionDatasetName]        NVARCHAR (50)                               NULL,
    [AssumptionDatasetDescription] NVARCHAR (255)                              NULL,
    [AssumptionPercentageTypeId]   INT                                         NULL,
    [IsDatasetAlreadyUsed]         INT                                         NULL,
    [CreatedDt]                    DATETIME                                    NULL,
    [CreatedBy]                    NVARCHAR (150)                              NULL,
    [UpdatedDt]                    DATETIME                                    NULL,
    [UpdatedBy]                    NVARCHAR (150)                              NULL,
    [ValidFrom]                    DATETIME2 (7) GENERATED ALWAYS AS ROW START NOT NULL,
    [ValidTo]                      DATETIME2 (7) GENERATED ALWAYS AS ROW END   NOT NULL,
	[Reporting_Year]			   INT                                         NULL,
	[Reporting_Quarter]            NVARCHAR (10)                               NULL,
	[RI_Flag]                      NVARCHAR (10)                               NULL,
	[Version]                      INT                                         NULL,
    PRIMARY KEY CLUSTERED ([Pk_AssumptionDatasetNameId] ASC) WITH (FILLFACTOR = 90),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[Dim].[AssumptionDatasets_History], DATA_CONSISTENCY_CHECK=ON));


GO
CREATE NONCLUSTERED INDEX [bzyidx_AssumptionDatasets_1]
    ON [Dim].[AssumptionDatasets]([AssumptionDatasetName] ASC) WITH (FILLFACTOR = 90);

