CREATE TABLE [Dim].[DatasetAccountMapping](
	[PK_ID] [int] IDENTITY(1,1) NOT NULL,
	[DataSet] [varchar](255) NOT NULL,
	[Account] [varchar](50) NOT NULL,
	[AuditCreateDateTime] [datetime] DEFAULT (getutcdate()) NOT NULL,
	[AuditHost] [varchar](255) DEFAULT (suser_sname()) NULL
	
	)



