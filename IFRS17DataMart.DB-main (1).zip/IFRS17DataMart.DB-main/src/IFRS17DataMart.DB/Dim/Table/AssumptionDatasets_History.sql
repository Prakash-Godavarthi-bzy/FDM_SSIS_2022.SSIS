﻿CREATE TABLE [Dim].[AssumptionDatasets_History]
(
	[Pk_AssumptionDatasetNameId] [int] NOT NULL,
	[AssumptionDatasetName] [nvarchar](50) NULL,
	[AssumptionDatasetDescription] [nvarchar](255) NULL,
	[AssumptionPercentageTypeId] [int] NULL,
	[IsDatasetAlreadyUsed] [int] NULL,
	[CreatedDt] [datetime] NULL,
	[CreatedBy] [nvarchar](150) NULL,
	[UpdatedDt] [datetime] NULL,
	[UpdatedBy] [nvarchar](150) NULL,
	[ValidFrom] [datetime2](7) NOT NULL,
	[ValidTo] [datetime2](7) NOT NULL,
	[Reporting_Year] [int] NULL,
	[Reporting_Quarter] [nvarchar](10) NULL,
	[RI_Flag] [nvarchar](10) NULL,
	[Version] [int] NULL
) ON [PRIMARY]
