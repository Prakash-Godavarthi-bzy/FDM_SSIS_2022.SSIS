﻿CREATE TABLE [Dim].[Entity_History] (
    [PK_Entity]    VARCHAR (25)  NOT NULL,
    [Entity]       VARCHAR (50)  NULL,
    [EntityName]   VARCHAR (50)  NULL,
    [Platform]     VARCHAR (10)  NULL,
    [EntityLevel1] VARCHAR (50)  NULL,
    [EntityLevel2] VARCHAR (50)  NULL,
    [EntityLevel3] VARCHAR (50)  NULL,
    [EntityLevel4] VARCHAR (50)  NULL,
    [EntityLevel5] VARCHAR (50)  NULL,
    [ValidFrom]    DATETIME2 (7) NOT NULL,
    [ValidTo]      DATETIME2 (7) NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_Entity_History]
    ON [Dim].[Entity_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

