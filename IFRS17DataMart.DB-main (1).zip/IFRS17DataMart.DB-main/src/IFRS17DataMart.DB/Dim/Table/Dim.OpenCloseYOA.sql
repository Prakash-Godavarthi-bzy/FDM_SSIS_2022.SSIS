﻿CREATE TABLE [Dim].[OpenCloseYOA] (
    [Id]                  INT                                         IDENTITY (1, 1) NOT NULL,
    [FK_AccountingPeriod] VARCHAR (6)                                 NOT NULL,
    [Programme]           VARCHAR (100)                               NOT NULL,
    [FK_Trifocus]         VARCHAR (25)                                NOT NULL,
    [FK_YOA]              INT                                         NOT NULL,
    [Open_Cls_Flag]       VARCHAR (10)                                NOT NULL,
    [AuditCreateDateTime] DATETIME2 (7)                               DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]     NVARCHAR (510)                              DEFAULT (suser_sname()) NOT NULL,
    [ValidFrom]           DATETIME2 (7) GENERATED ALWAYS AS ROW START NOT NULL,
    [ValidTo]             DATETIME2 (7) GENERATED ALWAYS AS ROW END   NOT NULL,
    CONSTRAINT [Id] PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 90),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[Dim].[OpenCloseYOA_History], DATA_CONSISTENCY_CHECK=ON));




GO
CREATE NONCLUSTERED INDEX [IX_OpenCloseYOA_AccountingPeriod] ON [Dim].[OpenCloseYOA] 
(
[FK_AccountingPeriod] ASC
)
go


GO

  
