﻿CREATE TABLE [dim].[PatternName_History] (
	 [PK_PatternName] VARCHAR (20)  NOT NULL,
   -- [SourceTable]    VARCHAR (200) NULL,
    [PatternName]   VARCHAR (200) NULL,
   -- [PatternRef]     VARCHAR (20)  NULL,
    [AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    [ValidFrom]      DATETIME2 (7) NOT NULL,
    [ValidTo]        DATETIME2 (7) NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_PatternName_History]
    ON [dim].[PatternName_History]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

