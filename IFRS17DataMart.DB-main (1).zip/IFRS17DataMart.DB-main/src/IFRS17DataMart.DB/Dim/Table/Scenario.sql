﻿CREATE TABLE [Dim].[Scenario] (
    [PK_Scenario]         VARCHAR (10)                                NOT NULL,
    [ScenarioName]        VARCHAR (50)                                NULL,
    [AuditSourceBatchID]  VARCHAR (255)                               NULL,
    [AuditCreateDateTime] DATETIME                                    DEFAULT (getutcdate()) NOT NULL,
    [AuditUserCreate]     VARCHAR (255)                               DEFAULT (suser_sname()) NOT NULL,
    [AuditHost]           VARCHAR (255)                               DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))) NULL,
    [ValidFrom]           DATETIME2 (7) GENERATED ALWAYS AS ROW START NOT NULL,
    [ValidTo]             DATETIME2 (7) GENERATED ALWAYS AS ROW END   NOT NULL,
    CONSTRAINT [PK_Scenario] PRIMARY KEY CLUSTERED ([PK_Scenario] ASC) WITH (FILLFACTOR = 90),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[Dim].[Scenario_History], DATA_CONSISTENCY_CHECK=ON));

