﻿CREATE PROCEDURE [dim].[usp_MergeYOA]
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			INSERT		dim.YOA WITH (TABLOCK) ([PK_YOA])
			SELECT		stg.[PK_YOA]
			FROM		stg.dim_YOA stg	
			LEFT JOIN	Dim.YOA dim	ON	dim.[PK_YOA] = stg.[PK_YOA]
			WHERE		dim.[PK_YOA] IS NULL
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END