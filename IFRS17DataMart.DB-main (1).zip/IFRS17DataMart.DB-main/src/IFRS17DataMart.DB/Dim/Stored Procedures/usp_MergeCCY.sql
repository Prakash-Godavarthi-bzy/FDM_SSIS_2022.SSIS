﻿CREATE PROCEDURE [dim].[usp_MergeCCY]
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			UPDATE	dim
			SET		dim.CCYName = stg.CCYName
			FROM	stg.dim_CCY stg	
			JOIN	Dim.CCY dim	ON	dim.[PK_CCY] = stg.[PK_CCY]			WHERE	dim.CCYName <> stg.CCYName
				OR	CAST(IIF(dim.CCYName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.CCYName IS NULL, 0, 1) AS BIT) = 1 

			--Create new records
			INSERT		dim.CCY WITH (TABLOCK) ([PK_CCY], CCYName)
			SELECT		stg.[PK_CCY], 
						stg.CCYName
			FROM		stg.dim_CCY stg	
			LEFT JOIN	Dim.CCY dim	ON	dim.[PK_CCY] = stg.[PK_CCY]
			WHERE		dim.[PK_CCY] IS NULL
					OR	dim.CCYName <> stg.CCYName
					OR	CAST(IIF(dim.CCYName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.CCYName IS NULL, 0, 1) AS BIT) = 1 
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END