﻿CREATE PROCEDURE [dim].[usp_MergeScenario]
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			UPDATE	dim
			SET		dim.ScenarioName = stg.ScenarioName
			FROM	stg.dim_Scenario stg	
			JOIN	Dim.Scenario dim	ON	dim.[PK_Scenario] = stg.[PK_Scenario]			WHERE	dim.ScenarioName <> stg.ScenarioName
				OR	CAST(IIF(dim.ScenarioName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.ScenarioName IS NULL, 0, 1) AS BIT) = 1 

			--Create new records
			INSERT		Dim.Scenario WITH (TABLOCK) ([PK_Scenario], ScenarioName)
			SELECT		stg.[PK_Scenario], 
						stg.ScenarioName
			FROM		stg.dim_Scenario stg	
			LEFT JOIN	Dim.Scenario dim	ON	dim.[PK_Scenario] = stg.[PK_Scenario]
			WHERE		dim.[PK_Scenario] IS NULL
					OR	dim.ScenarioName <> stg.ScenarioName
					OR	CAST(IIF(dim.ScenarioName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.ScenarioName IS NULL, 0, 1) AS BIT) = 1 
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END