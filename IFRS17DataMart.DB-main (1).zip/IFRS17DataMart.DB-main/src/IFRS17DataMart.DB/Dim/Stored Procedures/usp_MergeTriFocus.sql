﻿CREATE PROCEDURE [dim].[usp_MergeTriFocus]
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			UPDATE	dim
			SET		dim.TriFocusName = stg.TriFocusName,
					dim.TriFocusLevel1 = stg.TriFocusLevel1,
					dim.TriFocusLevel2 = stg.TriFocusLevel2,
					dim.TriFocusLevel3 = stg.TriFocusLevel3
			FROM	stg.dim_TriFocus stg	
			JOIN	Dim.TriFocus dim	ON	dim.[PK_TriFocus] = stg.[PK_TriFocus]			WHERE	dim.TriFocusName <> stg.TriFocusName
				OR	dim.TriFocusLevel1 <> stg.TriFocusLevel1
				OR	dim.TriFocusLevel2 <> stg.TriFocusLevel2
				OR	dim.TriFocusLevel3 <> stg.TriFocusLevel3
				OR	CAST(IIF(dim.TriFocusName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.TriFocusName IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.TriFocusLevel1 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.TriFocusLevel1 IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.TriFocusLevel2 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.TriFocusLevel2 IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.TriFocusLevel3 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.TriFocusLevel3 IS NULL, 0, 1) AS BIT) = 1 

			--Create new records
			INSERT		dim.TriFocus WITH (TABLOCK) ([PK_TriFocus], TriFocusName, TriFocusLevel1, TriFocusLevel2, TriFocusLevel3)
			SELECT		stg.[PK_TriFocus], 
						stg.TriFocusName, 
						stg.TriFocusLevel1, 
						stg.TriFocusLevel2, 
						stg.TriFocusLevel3
			FROM		stg.dim_TriFocus stg	
			LEFT JOIN	Dim.TriFocus dim	ON	dim.[PK_TriFocus] = stg.[PK_TriFocus]
			WHERE		dim.[PK_TriFocus] IS NULL
					OR	dim.TriFocusName <> stg.TriFocusName
					OR	dim.TriFocusLevel1 <> stg.TriFocusLevel1
					OR	dim.TriFocusLevel2 <> stg.TriFocusLevel2
					OR	dim.TriFocusLevel3 <> stg.TriFocusLevel3
					OR	CAST(IIF(dim.TriFocusName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.TriFocusName IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.TriFocusLevel1 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.TriFocusLevel1 IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.TriFocusLevel2 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.TriFocusLevel2 IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.TriFocusLevel3 IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.TriFocusLevel3 IS NULL, 0, 1) AS BIT) = 1 
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END