﻿

/*====================================================================================================
Is:		dim.Mergedim.MergePolicySection
Does:	Updates SCD values with staged data
====================================================================================================*/
CREATE PROCEDURE [Dim].[usp_MergePolicySection]
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			UPDATE	dim
			SET		dim.[PK_PolicySection]	= stg.[PK_PolicySection],
					dim.[PolicyReference]	= stg.[PolicyReference],
					dim.[SectionReference]	= stg.[SectionReference],
					dim.[InceptionDate]		= stg.[InceptionDate],
					dim.[ExpiryDate]		= stg.[ExpiryDate],
					dim.PolicyYOA			= stg.PolicyYOA,
					dim.PolicyType			= stg.PolicyType,
					dim.BindDate			= stg.BindDate,
					dim.TypeOfBusiness		= stg.TypeOfBusiness,
					dim.MaxEarningDate		= stg.MaxEarningDate,
					dim.IsUSPolicy			= stg.IsUSPolicy,
					dim.PolicyClaimBasis	=stg.PolicyClaimBasis,
					dim.PolicyMOPCode		=stg.PolicyMOPCode,
					dim.PolicyCobCode		=stg.PolicyCobCode
			
			FROM	stg.dim_PolicySection stg	
			JOIN	Dim.PolicySection dim	
			ON	dim.PK_PolicySection		= stg.PK_PolicySection

			WHERE	dim.PolicyReference		<> stg.PolicyReference
				OR	dim.SectionReference	<> stg.SectionReference
				OR	dim.InceptionDate		<> stg.InceptionDate
				OR	dim.ExpiryDate			<> stg.ExpiryDate
				OR	dim.PolicyYOA			<> stg.PolicyYOA
				OR	dim.PolicyType			<> stg.PolicyType
				OR	dim.BindDate			<> stg.BindDate
				OR	dim.TypeOfBusiness		<> stg.TypeOfBusiness
				OR	dim.MaxEarningDate		<> stg.MaxEarningDate
				OR	dim.IsUSPolicy			<> stg.IsUSPolicy
				OR  dim.PolicyClaimBasis	<>stg.PolicyClaimBasis
				OR	dim.PolicyMOPCode		<>stg.PolicyMOPCode
				OR  dim.PolicyCobCode		<>stg.PolicyCobCode

				OR	CAST(IIF(dim.PolicyReference IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.PolicyReference IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.SectionReference IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.SectionReference IS NULL, 0, 1) AS BIT) = 1
				OR	CAST(IIF(dim.InceptionDate IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.InceptionDate IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.ExpiryDate IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.ExpiryDate IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.PolicyYOA IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.PolicyYOA IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.PolicyType IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.PolicyType IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.BindDate IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.BindDate IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.TypeOfBusiness IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.TypeOfBusiness IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.MaxEarningDate IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.MaxEarningDate IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.IsUSPolicy IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.IsUSPolicy IS NULL, 0, 1) AS BIT) = 1
				OR  CAST(IIF(dim.PolicyClaimBasis IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.PolicyClaimBasis IS NULL, 0, 1) AS BIT) = 1
				OR CAST(IIF(dim.PolicyMOPCode IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.PolicyMOPCode IS NULL, 0, 1) AS BIT) = 1
				OR CAST(IIF(dim.PolicyCobCode IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.PolicyCobCode IS NULL, 0, 1) AS BIT) = 1

			--Create new records
			INSERT		Dim.PolicySection WITH (TABLOCK) ([PK_PolicySection],[PolicyReference],[SectionReference],PolicyClaimBasis,PolicyMOPCode,PolicyCobCode, InceptionDate, ExpiryDate, PolicyYOA, PolicyType, BindDate, TypeOfBusiness, MaxEarningDate,IsUSPolicy)
			SELECT		 stg.[PK_PolicySection]
						,stg.[PolicyReference]
						,stg.[SectionReference]
						,stg.PolicyClaimBasis
						 ,stg.PolicyMOPCode
						 ,stg.PolicyCobCode
						,stg.[InceptionDate]
						,stg.[ExpiryDate]
						,stg.[PolicyYOA]
						,stg.[PolicyType]
						,stg.[BindDate]
						,stg.[TypeOfBusiness]
						,stg.[MaxEarningDate]
						,stg.[IsUSPolicy]
			FROM		stg.dim_PolicySection stg	
			LEFT JOIN	Dim.PolicySection dim	ON	dim.[PK_PolicySection] = stg.[PK_PolicySection]
			WHERE		dim.PK_PolicySection IS NULL


		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END