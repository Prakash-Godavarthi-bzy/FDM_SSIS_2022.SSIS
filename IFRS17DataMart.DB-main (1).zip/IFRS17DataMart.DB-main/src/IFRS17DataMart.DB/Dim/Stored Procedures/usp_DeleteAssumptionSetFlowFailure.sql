﻿CREATE PROCEDURE [Dim].[usp_DeleteAssumptionSetFlowFailure] @AssumptionDataSetID int
AS
BEGIN
	INSERT INTO PWAPS.stg_UploadedAssumptionErrors([AssumpDatasetId],[AssumpPercName],[ErrorMsg],FlowName)
    SELECT @AssumptionDataSetID,AssumptionPercentageType,'Flow has failed','ASM_DeleteAssumptionSet' 
	FROM dim.AssumptionPercentageType APT
    JOIN dim.AssumptionDatasets AD on APT.Pk_AssumptionPercentageTypeId=AD.AssumptionPercentageTypeId
    WHERE AD.Pk_AssumptionDatasetNameId = @AssumptionDataSetID;

END