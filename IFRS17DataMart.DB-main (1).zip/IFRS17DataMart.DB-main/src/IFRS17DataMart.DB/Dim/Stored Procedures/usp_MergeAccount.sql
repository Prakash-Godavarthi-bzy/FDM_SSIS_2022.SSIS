﻿CREATE PROCEDURE [Dim].[usp_MergeAccount]
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			
			UPDATE	Dim
			SET		Dim.AccountName = stg.AccountName,
					Dim.Level1Group = stg.Level1Group,
					Dim.Level2Group = stg.Level2Group,
					Dim.Level3Group = stg.Level3Group,
					Dim.RIFlag      = stg.RIFlag
			FROM	stg.dim_Account stg	
			JOIN	Dim.Account Dim	ON	Dim.PK_Account = stg.PK_Account
			WHERE	Dim.AccountName <> stg.AccountName
				OR	Dim.Level1Group <> stg.Level1Group
				OR	Dim.Level2Group <> stg.Level2Group
				OR	Dim.Level3Group <> stg.Level3Group
				OR  Dim.RIFlag <> stg.RIFlag
				OR	CAST(IIF(Dim.AccountName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.AccountName IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(Dim.Level1Group IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Level1Group IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(Dim.Level2Group IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Level2Group IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(Dim.Level3Group IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Level3Group IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(Dim.RIFlag IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.RIFlag IS NULL, 0, 1) AS BIT) = 1 

			--Create new records
			INSERT		Dim.Account WITH (TABLOCK) ([PK_Account], AccountName, Level1Group, Level2Group, Level3Group, RIFlag)
			SELECT		stg.[PK_Account], 
						stg.AccountName, 
						stg.Level1Group, 
						stg.Level2Group, 
						stg.Level3Group,
						stg.RIFlag
			FROM		stg.dim_Account stg	
			LEFT JOIN	Dim.Account Dim	ON	dim.PK_Account = stg.PK_Account
			WHERE	Dim.[PK_Account] IS NULL
				OR	Dim.AccountName <> stg.AccountName
				OR	Dim.Level1Group <> stg.Level1Group
				OR	Dim.Level2Group <> stg.Level2Group
				OR	Dim.Level3Group <> stg.Level3Group
				OR  Dim.RIFlag <> stg.RIFlag
				OR	CAST(IIF(Dim.AccountName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.AccountName IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(Dim.Level1Group IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Level1Group IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(Dim.Level2Group IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Level2Group IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(Dim.Level3Group IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Level3Group IS NULL, 0, 1) AS BIT) = 1 


		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END
GO