﻿CREATE PROCEDURE dim.usp_MergeDate
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			--Overwrite SCD 1 data columns.
			UPDATE	dim
			SET		dim.Date = stg.Date,
					dim.DateName = stg.DateName,
					dim.Year = stg.Year,
					dim.Month = stg.Month,
					dim.Day = stg.Day,
					dim.PERIOD = stg.PERIOD,
					dim.MonthName = stg.MonthName,
					dim.Quarter = stg.Quarter,
					dim.QuarterName = stg.QuarterName,
					dim.DaysInMonth = stg.DaysInMonth
			FROM	stg.dim_Date stg	
			JOIN	Dim.[Date] dim	ON	dim.[PK_Date] = stg.[PK_Date]			WHERE	dim.Date <> stg.Date
				OR	dim.DateName <> stg.DateName
				OR	dim.Year <> stg.Year
				OR	dim.Month <> stg.Month
				OR	dim.Day <> stg.Day
				OR	dim.PERIOD <> stg.PERIOD
				OR	dim.MonthName <> stg.MonthName
				OR	dim.Quarter <> stg.Quarter
				OR	dim.QuarterName <> stg.QuarterName
				OR	dim.DaysInMonth <> stg.DaysInMonth
				OR	CAST(IIF(dim.Date IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Date IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.DateName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.DateName IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.Year IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Year IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.Month IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Month IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.Day IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Day IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.PERIOD IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.PERIOD IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.MonthName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.MonthName IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.Quarter IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Quarter IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.QuarterName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.QuarterName IS NULL, 0, 1) AS BIT) = 1 
				OR	CAST(IIF(dim.DaysInMonth IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.DaysInMonth IS NULL, 0, 1) AS BIT) = 1 

			--Create new records
			INSERT		Dim.Date WITH (TABLOCK) ([PK_Date], Date, DateName, Year, Month, Day, PERIOD, MonthName, Quarter, QuarterName, DaysInMonth)
			SELECT		stg.[PK_Date], 
						stg.Date, 
						stg.DateName, 
						stg.Year, 
						stg.Month, 
						stg.Day, 
						stg.PERIOD, 
						stg.MonthName, 
						stg.Quarter, 
						stg.QuarterName, 
						stg.DaysInMonth
			FROM		stg.dim_Date stg	
			LEFT JOIN	Dim.Date dim	ON	dim.[PK_Date] = stg.[PK_Date]
			WHERE		dim.[PK_Date] IS NULL
					OR	dim.Date <> stg.Date
					OR	dim.DateName <> stg.DateName
					OR	dim.Year <> stg.Year
					OR	dim.Month <> stg.Month
					OR	dim.Day <> stg.Day
					OR	dim.PERIOD <> stg.PERIOD
					OR	dim.MonthName <> stg.MonthName
					OR	dim.Quarter <> stg.Quarter
					OR	dim.QuarterName <> stg.QuarterName
					OR	dim.DaysInMonth <> stg.DaysInMonth
					OR	CAST(IIF(dim.Date IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Date IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.DateName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.DateName IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.Year IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Year IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.Month IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Month IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.Day IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Day IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.PERIOD IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.PERIOD IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.MonthName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.MonthName IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.Quarter IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.Quarter IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.QuarterName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.QuarterName IS NULL, 0, 1) AS BIT) = 1 
					OR	CAST(IIF(dim.DaysInMonth IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.DaysInMonth IS NULL, 0, 1) AS BIT) = 1 
		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END