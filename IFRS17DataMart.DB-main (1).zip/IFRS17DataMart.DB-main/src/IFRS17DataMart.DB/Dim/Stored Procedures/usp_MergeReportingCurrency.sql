﻿CREATE PROCEDURE [dim].[usp_MergeReportingCurrency]
AS
BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;
			UPDATE	dim
			SET		 dim.ReportingCurrencyName = stg.ReportingCurrencyName
			FROM	stg.dim_ReportingCurrency stg	
			JOIN	Dim.ReportingCurrency dim	ON	dim.PK_ReportingCurrencyCode = stg.PK_ReportingCurrencyCode
			WHERE
				dim.ReportingCurrencyName <> stg.ReportingCurrencyName
				OR	CAST(IIF(dim.ReportingCurrencyName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.ReportingCurrencyName IS NULL, 0, 1) AS BIT) = 1 
			;				

			--Create new records
			INSERT INTO dim.ReportingCurrency WITH (TABLOCK) 
			(
				 PK_ReportingCurrencyCode
				,ReportingCurrencyName
			)
			SELECT		
				 stg.PK_ReportingCurrencyCode
				,stg.ReportingCurrencyName
			FROM		stg.dim_ReportingCurrency stg	
			LEFT JOIN	Dim.ReportingCurrency dim	ON dim.PK_ReportingCurrencyCode = stg.PK_ReportingCurrencyCode
			WHERE		dim.PK_ReportingCurrencyCode IS NULL
					OR	dim.ReportingCurrencyName <> stg.ReportingCurrencyName
					OR	CAST(IIF(dim.ReportingCurrencyName IS NULL, 0, 1) AS BIT) ^ CAST(IIF(stg.ReportingCurrencyName IS NULL, 0, 1) AS BIT) = 1 
			;

		IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH
END