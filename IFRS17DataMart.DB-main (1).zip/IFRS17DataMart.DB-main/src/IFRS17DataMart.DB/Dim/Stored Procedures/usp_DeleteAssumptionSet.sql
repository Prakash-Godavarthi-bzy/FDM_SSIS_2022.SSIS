﻿CREATE PROCEDURE [Dim].[usp_DeleteAssumptionSet] @AssumptionDataSetID int
AS
BEGIN

		IF EXISTS (SELECT 1 FROM fct.AssumptionData WHERE [Pk_AssumptionDatasetNameId] = @AssumptionDataSetID)
            BEGIN
            Delete From fct.AssumptionData Where Pk_AssumptionDatasetNameId =  @AssumptionDataSetID
            END

        IF EXISTS (SELECT 1 FROM Dim.AssumptionDatasets WHERE Pk_AssumptionDatasetNameId = @AssumptionDataSetID)
            BEGIN
            Delete From Dim.AssumptionDatasets Where Pk_AssumptionDatasetNameId =@AssumptionDataSetID
            END
        


END