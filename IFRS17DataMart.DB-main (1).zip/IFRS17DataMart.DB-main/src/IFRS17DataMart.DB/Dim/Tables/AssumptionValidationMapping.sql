﻿CREATE TABLE [Dim].[AssumptionValidationMapping] (
    [RowID]          INT           IDENTITY (1, 1) NOT NULL,
    [AssumptionName] VARCHAR (255) NULL,
    [ValidationType] VARCHAR (255) NULL
);

