﻿UPDATE PWAPS.IFRS17CalcUI_RunLog
	   SET ApprovalStatus='Approved',
	   ApprovedDateTime=GETDATE(),
	   ApproverComments=CONCAT ('Approved - ',SUSER_NAME(), ' ',FORMAT(getdate(), 'd', 'en-gb'),' Approved by actuaries'),
	   ApproverName=SUSER_NAME()  WHERE Pk_RequestId between 3 and 14 or 
	   Pk_RequestId in (16,30,52,53,54,63,64,88,96);