DECLARE @ReconcileDimIFRS17DataStage TABLE
(
[PK_ReconcileDataStageID] [int] NOT NULL,
[ReconciliationStageDescription] varchar(255) NULL
)


INSERT @ReconcileDimIFRS17DataStage([PK_ReconcileDataStageID],[ReconciliationStageDescription])
VALUES (1,'TDH_IDM'), (2,'IDM_PrePost_Psicle'),
(3,'PostPsicle_IDS'),(4,'IDS_ICEInput')



MERGE [IFRS17DataMart].[Control].[ReconcileDimIFRS17DataStage] AS TGT
USING @ReconcileDimIFRS17DataStage AS SRC
ON (
TGT.[PK_ReconcileDataStageID] = SRC.[PK_ReconcileDataStageID]
)

WHEN NOT MATCHED BY TARGET THEN

INSERT (PK_ReconcileDataStageID,ReconciliationStageDescription) VALUES (PK_ReconcileDataStageID,ReconciliationStageDescription);

--[Control].[ReconcileDimIFRS17DataStageTables]

DECLARE @ReconcileDimIFRS17DataStageTables TABLE
(
PK_ReconcileDimIFRS17DataStageTablesID int identity(1,1) NOT NULL,
FK_ReconcileDataStageID int NOT NULL,
SourceTableName Varchar(100) NULL,
TargetTableName Varchar(100) NULL
)
DECLARE @DataStageID1 INT,@DataStageID2 INT

SELECT @DataStageID1 = PK_ReconcileDataStageID FROM [Control].ReconcileDimIFRS17DataStage WHERE ReconciliationStageDescription = 'TDH_IDM'
SELECT @DataStageID2 = PK_ReconcileDataStageID FROM [Control].ReconcileDimIFRS17DataStage WHERE ReconciliationStageDescription = 'IDM_PrePost_Psicle'


INSERT @ReconcileDimIFRS17DataStageTables(FK_ReconcileDataStageID,SourceTableName,TargetTableName)
VALUES (@DataStageID1,'IFRS17.Trifocus',	'Dim.TriFocus')
,(@DataStageID1,'IFRS17.Scenario',	'Dim.Scenario')
,(@DataStageID1,'IFRS17.ReportingCurrency',	'Dim.ReportingCurrency')
,(@DataStageID1,'IFRS17.PolicySection',	'Dim.PolicySection')
,(@DataStageID1,'IFRS17.Entity',	'Dim.Entity')
,(@DataStageID1,'IFRS17.Dataset',	'Dim.DataSet')
,(@DataStageID1,'IFRS17.CCY',	'Dim.CCY')
,(@DataStageID1,'IFRS17.AccountingPeriod',	'Dim.AccountingPeriod')
,(@DataStageID1,'IFRS17.FCT_TechnicalResult',	'stg.fct_TechnicalResult')
,(@DataStageID1,'IFRS17.FCT_TechnicalResult',	'fct.PreProcessPremiumLTD')
,(@DataStageID1,'dbo.RIPercentage',	'fct.RIPercentage')
,(@DataStageID1,'fct.Pattern', 	'fct.Pattern')
,(@DataStageID1,'fct.FxRate',	'fct.FxRate')
,(@DataStageID1,'fct.DiscountRate',	'fct.DiscountRate')
,(@DataStageID1,'IFRS17.FCT_TechnicalResult',	'fct.Aggr_NonPremiumLTD')
,(@DataStageID2,'fct.PremiumLatestValueWithOpenCloseFlag',	'fct.Aggr_PremiumLTD')


MERGE [IFRS17DataMart].[Control].[ReconcileDimIFRS17DataStageTables] AS TGT
USING @ReconcileDimIFRS17DataStageTables AS SRC
ON (
TGT.PK_ReconcileDimIFRS17DataStageTablesID = SRC.PK_ReconcileDimIFRS17DataStageTablesID
)

WHEN NOT MATCHED BY TARGET THEN

INSERT (FK_ReconcileDataStageID,SourceTableName,TargetTableName) VALUES (FK_ReconcileDataStageID,SourceTableName,TargetTableName);
