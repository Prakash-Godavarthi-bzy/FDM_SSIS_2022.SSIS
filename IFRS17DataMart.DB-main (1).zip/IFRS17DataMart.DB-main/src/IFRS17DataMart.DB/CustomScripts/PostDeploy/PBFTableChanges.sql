﻿-----Sprint 17 PBF Development Changes-----
/*
IF EXISTS(SELECT DISTINCT 1 FROM PBF.ForecastBudgetRunHistory HAVING COUNT(*)=0)
BEGIN 
SET IDENTITY_INSERT PBF.ForecastBudgetRunHistory ON;

INSERT INTO PBF.ForecastBudgetRunHistory 
    (Pk_ForecastBudgetRunHistoryID, FK_PKSCID, VersionName, VersionNumber, UserEmail)
VALUES 
    (-1, 0, '999912 A V1', '1', 'IFRS17.Support@beazley.com');
 
SET IDENTITY_INSERT PBF.ForecastBudgetRunHistory OFF;
END


IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'ForecastBudgetDirectLoad' AND TABLE_SCHEMA='PBF' AND COLUMN_NAME = 'FK_ForecastBudgetRunHistoryID')
BEGIN
IF NOT EXISTS(SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='PBF' AND TABLE_NAME='ForecastBudgetDirectLoad' AND CONSTRAINT_NAME='FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID')
BEGIN
ALTER TABLE PBF.ForecastBudgetDirectLoad WITH NOCHECK ADD CONSTRAINT FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID FOREIGN KEY (FK_ForecastBudgetRunHistoryID) REFERENCES PBF.ForecastBudgetRunHistory(PK_ForecastBudgetRunHistoryID);
END;
END;
Go
*/

/*
IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'OpenCloseYOA' AND TABLE_SCHEMA='Dim' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
	DECLARE @BatchSize INT = 10000000;
	DECLARE @RowsAffected INT = 1;
 
	WHILE @RowsAffected > 0
	BEGIN
		UPDATE TOP (@BatchSize) [Dim].OpenCloseYOA
		SET FK_ForecastBudgetRunHistoryID = -1, VersionNumber = 1
		WHERE FK_ForecastBudgetRunHistoryID IS NULL
 
		SET @RowsAffected = @@ROWCOUNT
	END
END
GO

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'IFRS17_Trifocus' AND TABLE_SCHEMA='Dim' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
	DECLARE @BatchSize INT = 10000000;
	DECLARE @RowsAffected INT = 1;
 
	WHILE @RowsAffected > 0
	BEGIN
		UPDATE TOP (@BatchSize) [Dim].IFRS17_Trifocus
		SET FK_ForecastBudgetRunHistoryID = -1, VersionNumber = 1
		WHERE FK_ForecastBudgetRunHistoryID IS NULL
 
		SET @RowsAffected = @@ROWCOUNT
	END
END
GO

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'ActualWrittenPremiumByEarnQtr_Binders' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
	DECLARE @BatchSize INT = 10000000;
	DECLARE @RowsAffected INT = 1;
 
	WHILE @RowsAffected > 0
	BEGIN
		UPDATE TOP (@BatchSize) [fct].ActualWrittenPremiumByEarnQtr_Binders
		SET FK_ForecastBudgetRunHistoryID = -1, VersionNumber = 1
		WHERE FK_ForecastBudgetRunHistoryID IS NULL
 
		SET @RowsAffected = @@ROWCOUNT
	END
END
GO

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Aggr_PremiumLTD' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
	DECLARE @BatchSize INT = 10000000;
	DECLARE @RowsAffected INT = 1;
 
	WHILE @RowsAffected > 0
	BEGIN
		UPDATE TOP (@BatchSize) [fct].Aggr_PremiumLTD
		SET FK_ForecastBudgetRunHistoryID = -1,
			VersionNumber = 1
		WHERE FK_ForecastBudgetRunHistoryID IS NULL
 
		SET @RowsAffected = @@ROWCOUNT
	END
END
GO

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'EarnedPremiumByQtr_NonBinders' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
	DECLARE @BatchSize INT = 10000000;
	DECLARE @RowsAffected INT = 1;
 
	WHILE @RowsAffected > 0
	BEGIN
		UPDATE TOP (@BatchSize) [fct].EarnedPremiumByQtr_NonBinders
		SET FK_ForecastBudgetRunHistoryID = -1,
			VersionNumber = 1
		WHERE FK_ForecastBudgetRunHistoryID IS NULL
 
		SET @RowsAffected = @@ROWCOUNT
	END
END
GO

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'EarningsForGrossNonRadAndRadProg' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
	DECLARE @BatchSize INT = 10000000;
	DECLARE @RowsAffected INT = 1;
 
	WHILE @RowsAffected > 0
	BEGIN
		UPDATE TOP (@BatchSize) [fct].EarningsForGrossNonRadAndRadProg
		SET FK_ForecastBudgetRunHistoryID = -1,
			VersionNumber = 1
		WHERE FK_ForecastBudgetRunHistoryID IS NULL
 
		SET @RowsAffected = @@ROWCOUNT
	END
END
GO

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'ExpectedWrittenPremium_Binders' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
	DECLARE @BatchSize INT = 10000000;
	DECLARE @RowsAffected INT = 1;
 
	WHILE @RowsAffected > 0
	BEGIN
		UPDATE TOP (@BatchSize) [fct].ExpectedWrittenPremium_Binders
		SET FK_ForecastBudgetRunHistoryID = -1,
			VersionNumber = 1
		WHERE FK_ForecastBudgetRunHistoryID IS NULL
 
		SET @RowsAffected = @@ROWCOUNT
	END
END
GO

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'FSC_Actual' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
	DECLARE @BatchSize INT = 10000000;
	DECLARE @RowsAffected INT = 1;
 
	WHILE @RowsAffected > 0
	BEGIN
		UPDATE TOP (@BatchSize) [fct].FSC_Actual
		SET FK_ForecastBudgetRunHistoryID = -1,
			VersionNumber = 1
		WHERE FK_ForecastBudgetRunHistoryID IS NULL
 
		SET @RowsAffected = @@ROWCOUNT
	END
END
GO

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'FSC_EarnPrem_Prior' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
	DECLARE @BatchSize INT = 10000000;
	DECLARE @RowsAffected INT = 1;
 
	WHILE @RowsAffected > 0
	BEGIN
		UPDATE TOP (@BatchSize) [fct].FSC_EarnPrem_Prior
		SET FK_ForecastBudgetRunHistoryID = -1,
			VersionNumber = 1
		WHERE FK_ForecastBudgetRunHistoryID IS NULL
 
		SET @RowsAffected = @@ROWCOUNT
	END
END
GO

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'FSC_EPI' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
	DECLARE @BatchSize INT = 10000000;
	DECLARE @RowsAffected INT = 1;
 
	WHILE @RowsAffected > 0
	BEGIN
		UPDATE TOP (@BatchSize) [fct].FSC_EPI
		SET FK_ForecastBudgetRunHistoryID = -1,
			VersionNumber = 1
		WHERE FK_ForecastBudgetRunHistoryID IS NULL
 
		SET @RowsAffected = @@ROWCOUNT
	END
END
GO

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'FSC_Forecast' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
	DECLARE @BatchSize INT = 10000000;
	DECLARE @RowsAffected INT = 1;
 
	WHILE @RowsAffected > 0
	BEGIN
		UPDATE TOP (@BatchSize) [fct].FSC_Forecast
		SET FK_ForecastBudgetRunHistoryID = -1,
			VersionNumber = 1
		WHERE FK_ForecastBudgetRunHistoryID IS NULL
 
		SET @RowsAffected = @@ROWCOUNT
	END
END
GO

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'FSC_Per_QOI' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
	DECLARE @BatchSize INT = 10000000;
	DECLARE @RowsAffected INT = 1;
 
	WHILE @RowsAffected > 0
	BEGIN
		UPDATE TOP (@BatchSize) [fct].FSC_Per_QOI
		SET FK_ForecastBudgetRunHistoryID = -1,
			VersionNumber = 1
		WHERE FK_ForecastBudgetRunHistoryID IS NULL
 
		SET @RowsAffected = @@ROWCOUNT
	END
END
GO

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'FSC_Per_YOA' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
	DECLARE @BatchSize INT = 10000000;
	DECLARE @RowsAffected INT = 1;
 
	WHILE @RowsAffected > 0
	BEGIN
		UPDATE TOP (@BatchSize) [fct].FSC_Per_YOA
		SET FK_ForecastBudgetRunHistoryID = -1,
			VersionNumber = 1
		WHERE FK_ForecastBudgetRunHistoryID IS NULL
 
		SET @RowsAffected = @@ROWCOUNT
	END
END
GO
*/

/*
IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'OpenCloseYOA' AND TABLE_SCHEMA='Dim' AND COLUMN_NAME = 'FK_ForecastBudgetRunHistoryID')
BEGIN
IF NOT EXISTS(SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='Dim' AND TABLE_NAME='OpenCloseYOA' AND CONSTRAINT_NAME='FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_1')
BEGIN
ALTER TABLE Dim.OpenCloseYOA WITH NOCHECK ADD CONSTRAINT FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_1 FOREIGN KEY (FK_ForecastBudgetRunHistoryID) REFERENCES PBF.ForecastBudgetRunHistory(PK_ForecastBudgetRunHistoryID);
END;
END;
Go

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'IFRS17_Trifocus' AND TABLE_SCHEMA='Dim' AND COLUMN_NAME ='FK_ForecastBudgetRunHistoryID')
BEGIN
IF NOT EXISTS(SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='Dim' AND TABLE_NAME='IFRS17_Trifocus' AND CONSTRAINT_NAME='FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_2')
BEGIN
ALTER TABLE [Dim].IFRS17_Trifocus WITH NOCHECK ADD CONSTRAINT FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_2 FOREIGN KEY (FK_ForecastBudgetRunHistoryID) REFERENCES PBF.ForecastBudgetRunHistory(PK_ForecastBudgetRunHistoryID);
END;
END;
Go

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'ActualWrittenPremiumByEarnQtr_Binders' AND TABLE_SCHEMA='fct' AND COLUMN_NAME = 'FK_ForecastBudgetRunHistoryID')
BEGIN
IF NOT EXISTS(SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='fct' AND TABLE_NAME='ActualWrittenPremiumByEarnQtr_Binders' AND CONSTRAINT_NAME='FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_3')
BEGIN
ALTER TABLE [fct].ActualWrittenPremiumByEarnQtr_Binders WITH NOCHECK ADD CONSTRAINT FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_3 FOREIGN KEY (FK_ForecastBudgetRunHistoryID) REFERENCES PBF.ForecastBudgetRunHistory(PK_ForecastBudgetRunHistoryID);
END;
END;
Go

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Aggr_PremiumLTD' AND TABLE_SCHEMA='fct' AND COLUMN_NAME = 'FK_ForecastBudgetRunHistoryID')
BEGIN
IF NOT EXISTS(SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='fct' AND TABLE_NAME='Aggr_PremiumLTD' AND CONSTRAINT_NAME='FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_4')
BEGIN
ALTER TABLE [fct].Aggr_PremiumLTD WITH NOCHECK ADD CONSTRAINT FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_4 FOREIGN KEY (FK_ForecastBudgetRunHistoryID) REFERENCES PBF.ForecastBudgetRunHistory(PK_ForecastBudgetRunHistoryID);
END;
END;
Go

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'EarnedPremiumByQtr_NonBinders' AND TABLE_SCHEMA='fct' AND COLUMN_NAME = 'FK_ForecastBudgetRunHistoryID')
BEGIN
IF NOT EXISTS(SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='fct' AND TABLE_NAME='EarnedPremiumByQtr_NonBinders' AND CONSTRAINT_NAME='FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_5')
BEGIN
ALTER TABLE [fct].EarnedPremiumByQtr_NonBinders WITH NOCHECK ADD CONSTRAINT FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_5 FOREIGN KEY (FK_ForecastBudgetRunHistoryID) REFERENCES PBF.ForecastBudgetRunHistory(PK_ForecastBudgetRunHistoryID);
END;
END;
Go

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'EarningsForGrossNonRadAndRadProg' AND TABLE_SCHEMA='fct' AND COLUMN_NAME = 'FK_ForecastBudgetRunHistoryID')
BEGIN
IF NOT EXISTS(SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='fct' AND TABLE_NAME='EarningsForGrossNonRadAndRadProg' AND CONSTRAINT_NAME='FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_6')
BEGIN
ALTER TABLE [fct].EarningsForGrossNonRadAndRadProg WITH NOCHECK ADD CONSTRAINT FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_6 FOREIGN KEY (FK_ForecastBudgetRunHistoryID) REFERENCES PBF.ForecastBudgetRunHistory(PK_ForecastBudgetRunHistoryID);
END;
END;
Go

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'ExpectedWrittenPremium_Binders' AND TABLE_SCHEMA='fct' AND COLUMN_NAME = 'FK_ForecastBudgetRunHistoryID')
BEGIN
IF NOT EXISTS(SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='fct' AND TABLE_NAME='ExpectedWrittenPremium_Binders' AND CONSTRAINT_NAME='FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_7')
BEGIN
ALTER TABLE [fct].ExpectedWrittenPremium_Binders WITH NOCHECK ADD CONSTRAINT FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_7 FOREIGN KEY (FK_ForecastBudgetRunHistoryID) REFERENCES PBF.ForecastBudgetRunHistory(PK_ForecastBudgetRunHistoryID);
END;
END;
Go

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'FSC_Actual' AND TABLE_SCHEMA='fct' AND COLUMN_NAME = 'FK_ForecastBudgetRunHistoryID')
BEGIN
IF NOT EXISTS(SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='fct' AND TABLE_NAME='FSC_Actual' AND CONSTRAINT_NAME='FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_8')
BEGIN
ALTER TABLE [fct].[FSC_Actual] WITH NOCHECK ADD CONSTRAINT FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_8 FOREIGN KEY (FK_ForecastBudgetRunHistoryID) REFERENCES PBF.ForecastBudgetRunHistory(PK_ForecastBudgetRunHistoryID);
END;
END;
Go

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'FSC_EarnPrem_Prior' AND TABLE_SCHEMA='fct' AND COLUMN_NAME = 'FK_ForecastBudgetRunHistoryID')
BEGIN
IF NOT EXISTS(SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='fct' AND TABLE_NAME='FSC_EarnPrem_Prior' AND CONSTRAINT_NAME='FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_9')
BEGIN
ALTER TABLE [fct].FSC_EarnPrem_Prior WITH NOCHECK ADD CONSTRAINT FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_9 FOREIGN KEY (FK_ForecastBudgetRunHistoryID) REFERENCES PBF.ForecastBudgetRunHistory(PK_ForecastBudgetRunHistoryID);
END;
END;
Go

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'FSC_EPI' AND TABLE_SCHEMA='fct' AND COLUMN_NAME = 'FK_ForecastBudgetRunHistoryID')
BEGIN
IF NOT EXISTS(SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='fct' AND TABLE_NAME='FSC_EPI' AND CONSTRAINT_NAME='FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_10')
BEGIN
ALTER TABLE [fct].FSC_EPI WITH NOCHECK ADD CONSTRAINT FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_10 FOREIGN KEY (FK_ForecastBudgetRunHistoryID) REFERENCES PBF.ForecastBudgetRunHistory(PK_ForecastBudgetRunHistoryID);
END;
END;
Go

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'FSC_Forecast' AND TABLE_SCHEMA='fct' AND COLUMN_NAME = 'FK_ForecastBudgetRunHistoryID')
BEGIN
IF NOT EXISTS(SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='fct' AND TABLE_NAME='FSC_Forecast' AND CONSTRAINT_NAME='FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_11')
BEGIN
ALTER TABLE [fct].FSC_Forecast WITH NOCHECK ADD CONSTRAINT FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_11 FOREIGN KEY (FK_ForecastBudgetRunHistoryID) REFERENCES PBF.ForecastBudgetRunHistory(PK_ForecastBudgetRunHistoryID);
END;
END;
Go

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'FSC_Per_QOI' AND TABLE_SCHEMA='fct' AND COLUMN_NAME = 'FK_ForecastBudgetRunHistoryID')
BEGIN
IF NOT EXISTS(SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='fct' AND TABLE_NAME='FSC_Per_QOI' AND CONSTRAINT_NAME='FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_12')
BEGIN
ALTER TABLE [fct].FSC_Per_QOI WITH NOCHECK ADD CONSTRAINT FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_12 FOREIGN KEY (FK_ForecastBudgetRunHistoryID) REFERENCES PBF.ForecastBudgetRunHistory(PK_ForecastBudgetRunHistoryID);
END;
END;
Go

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'FSC_Per_YOA' AND TABLE_SCHEMA='fct' AND COLUMN_NAME = 'FK_ForecastBudgetRunHistoryID')
BEGIN
IF NOT EXISTS(SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='fct' AND TABLE_NAME='FSC_Per_YOA' AND CONSTRAINT_NAME='FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_13')
BEGIN
ALTER TABLE [fct].[FSC_Per_YOA] WITH NOCHECK ADD CONSTRAINT FK_ForecastBudgetRunHistory_PK_ForecastBudgetRunHistoryID_13 FOREIGN KEY (FK_ForecastBudgetRunHistoryID) REFERENCES PBF.ForecastBudgetRunHistory(PK_ForecastBudgetRunHistoryID);
END;
END;
Go
*/




