IF EXISTS (Select  1 from Sys.tables  where name='DataCheckAccount' And schema_id=SCHEMA_ID('dim'))
Begin
DECLARE @DataCheckAccount TABLE
(
ID int identity(1,1),
[PK_AccountCode] nvarchar(35) NULL,
[AccountName] nvarchar(36) NULL,
[AccountSource] varchar(24) Not null,
[AccountTableName]  varchar(39) Not null,
	[AuditCreateDateTime] [datetime] default getdate() NULL,
	[AuditUserCreate] [varchar](255) default suser_name() NULL
)

INSERT @DataCheckAccount
([PK_AccountCode],[AccountName],[AccountSource],[AccountTableName])
Values
('PREM_NONBINDER','Gross Premium Policy','Premium Brokerage','[rpt].[vw_bm_factPremiumBrokerage]'),
('PREM_TEAM','Gross Premium Ultimate Policy','Premium Brokerage','[rpt].[vw_bm_factPremiumBrokerage]'),
('PREM_BINDER','Gross Premium Binder Adjusted','Premium Brokerage','[rpt].[vw_bm_factPremiumBrokerage]'),
('PREM_BINDER_UNCAPPED','Gross Premium Binder Adjusted','Premium Brokerage','[rpt].[vw_bm_factPremiumBrokerage]'),
('BKG_NONBINDER','Brokerage Policy','Premium Brokerage','[rpt].[vw_bm_factPremiumBrokerage]'),
('BKG_BINDER','Brokerage Binder Adjusted','Premium Brokerage','[rpt].[vw_bm_factPremiumBrokerage]'),
('RIP_NONBINDER','Reinstatement Premium Policy','Premium Brokerage','[rpt].[vw_bm_factPremiumBrokerage]'),
('FSC_PREM','Gross Premium_Future Service','Premium Brokerage','[rpt].[vw_bm_factPremiumBrokerage]'),
('FSC_BKG','Brokerage_Future Service','Premium Brokerage','[rpt].[vw_bm_factPremiumBrokerage]'),
('FSC_RIP','Reinstatement Premium_Future Service','Premium Brokerage','[rpt].[vw_bm_factPremiumBrokerage]'),
('PREM_CASH','Gross Premium Cash','Cash','[rpt].[vw_bm_factCash]'),
('BKG_CASH','Brokerage Cash','Cash','[rpt].[vw_bm_factCash]'),
('PC_CASH','Profit Commission Cash','Cash','[rpt].[vw_bm_factCash]'),
('RIP_CASH','Reinstatement Premium Cash','Cash','[rpt].[vw_bm_factCash]'),
('ADMIN_CASH','Admin Expense (Premium related)','Cash','[rpt].[vw_bm_factCash]'),
('CHE_CASH','Claims Handling Expense','Cash','[rpt].[vw_bm_factCash]'),
('OAE_CASH','Other Acquisition Expense','Cash','[rpt].[vw_bm_factCash]'),
('PAID_ATT','Claims Paid','Paid & Incurred','[rpt].[vw_bm_factPaidIncurred]'),
('PAID_LL','Claims Paid    ','Paid & Incurred','[rpt].[vw_bm_factPaidIncurred]'),
('ULT_PURE_LL','Claims Ultimate','Actuarial Ultimates','[rpt].[vw_bm_factActuarialUltimates]'),
('ULT_TEAM_LL','Claims Ultimate','Actuarial Ultimates','[rpt].[vw_bm_factActuarialUltimates]'),
('Earning Pattern YOI','Earning Pattern YOI','Earnings Pattern YOI','[rpt].[vw_bm_factEarningPatternsYOI]'),
('Earning Pattern QOI','Earning Pattern QOI','Earning Pattern QOI','[rpt].[vw_bm_factEarningPatternsQOI]'),
('Nat Cat Earning Percentage','Nat Cat Earning Percentage','NatCatEarningPatterns','[rpt].[vw_bm_factNatCatEarningPatterns]')


MERGE [IFRS17DataMart].[Dim].DataCheckAccount AS TGT

USING @DataCheckAccount AS SRC

ON (
		TGT.ID = SRC.ID 
		AND TGT.[PK_AccountCode]=SRC.[PK_AccountCode]
	)

WHEN NOT MATCHED BY TARGET THEN

INSERT ([PK_AccountCode],[AccountName],[AccountSource],[AccountTableName])
VALUES ([PK_AccountCode],[AccountName],[AccountSource],[AccountTableName]);

END