﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

/*UPDATE IDS.[AssumptionPercentages]
SET LossType = 'A'
WHERE LossType = 'ADM'



UPDATE IDS.[AssumptionPercentages]
SET LossType = 'L'
WHERE LossType = 'LL*/

/*
UPDATE fct.AssumptionData
SET [Gross/RI Flag]='U'
WHERE Pk_AssumptionPercentageTypeId=54 and [Gross/RI Flag] IS NULL
*/
IF EXISTS(SELECT 1 FROM PWAPS.IFRS17CalcUI_RunLog WHERE [Run Type]='Regulatory')
BEGIN
UPDATE PWAPS.IFRS17CalcUI_RunLog SET [Run Type]='Actual' where [Run Type]='Regulatory';
END

IF NOT EXISTS(select distinct 1 from INFORMATION_SCHEMA.COLUMNS where COLUMN_NAME = 'YTDQTD' and TABLE_NAME='IFRS17CalcUI_RunLog')
BEGIN
ALTER TABLE PWAPS.IFRS17CalcUI_RunLog
Add YTDQTD char(3)
END

--I17-7740 Dynamic Assumption Name Generation - Update Version Column for Existing Rows

IF EXISTS (
    SELECT 1
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = 'Dim'
    AND TABLE_NAME = 'AssumptionDatasets'
    AND COLUMN_NAME IN ('Reporting_Year', 'Reporting_Quarter', 'RI_Flag', 'Version')
)
BEGIN

;WITH VersionCTE AS (
    SELECT 
        t1.Pk_AssumptionDatasetNameId,
        ROW_NUMBER() OVER(
            PARTITION BY 
                t1.AssumptionPercentageTypeId,
                t1.[RI_Flag],
                t1.[Reporting_Year],
                t1.[Reporting_Quarter]
            ORDER BY t1.Pk_AssumptionDatasetNameId
        ) AS Version
    FROM 
        Dim.AssumptionDatasets t1
)
UPDATE t
SET t.Version = v.Version
FROM Dim.AssumptionDatasets t
INNER JOIN VersionCTE v
    ON t.Pk_AssumptionDatasetNameId = v.Pk_AssumptionDatasetNameId;

END
