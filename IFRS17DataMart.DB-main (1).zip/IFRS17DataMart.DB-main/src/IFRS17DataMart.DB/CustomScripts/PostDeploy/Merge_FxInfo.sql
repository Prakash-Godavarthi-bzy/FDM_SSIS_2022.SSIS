﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
DECLARE @FX_Info TABLE
(
ID int Identity(1,1)  NOT NULL,
[Statement] Varchar(8) NULL,
Position	Varchar(8) NULL,
fx_rate_type	Varchar(8)NULL,
OpenCls	Varchar(8)NULL,
[AuditCreateDateTime] [datetime] default getdate() NULL,
[AuditUserCreate] [varchar](255) default suser_name() NULL
)

INSERT @FX_Info(Statement,Position,fx_rate_type,OpenCls)
VALUES
('LIC','New','FXA','Cls'),
('LIC','Paid','FXA','Cls'),
('LIC','NFNChgV','FXA','Cls'),
('LIC','NFNChgO','FXA','Cls'),
('LIC','Closing','FXS','Cls'),
('LIC','FinChg','FXA','Cls'),
('LIC','Unwind','FXA','Cls'),
('LIC','Open','FXS','Open'),
('LRC','New','FXA','Cls'),
('LRC','Paid','FXA','Cls'),
('LRC','NFNChgO','FXA','Cls'),
('LRC','Closing','FXS','Cls'),
('LRC','NFNChgV','FXA','Cls'),
('LRC','FinChg','FXA','Cls'),
('LRC','Unwind','FXA','Cls'),
('LRC','Open','FXS','Open'),
('LRC','Release','FXA','Cls'),
('CSM','Open','FXS','Open'),
('CSM','New','FXA','Cls'),
('CSM','Unwind','FXA','Cls'),
('CSM','NFNChgO','FXA','Cls'),
('CSM','NFNChgV','FXA','Cls'),
('CSM','FinChg','FXA','Cls'),
('CSM','Release','FXA','Cls'),
('CSM','Closing','FXS','Cls')




MERGE [IFRS17DataMart].[IDS].FX_Info AS TGT

USING @FX_Info AS SRC

ON (
		TGT.ID = SRC.ID
	)

WHEN NOT MATCHED BY TARGET THEN

INSERT (Statement,Position,fx_rate_type,OpenCls,[AuditCreateDateTime],[AuditUserCreate])
VALUES (Statement,Position,fx_rate_type,OpenCls,[AuditCreateDateTime],[AuditUserCreate])
;