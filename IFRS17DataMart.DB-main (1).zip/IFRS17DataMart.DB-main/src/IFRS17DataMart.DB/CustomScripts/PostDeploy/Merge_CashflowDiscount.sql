IF EXISTS ( SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'IDS' AND TABLE_NAME =  'Cashflow_Discount')
BEGIN
TRUNCATE TABLE [IDS].[Cashflow_Discount];
END

DECLARE @CashflowDiscount TABLE
(
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [Flag] [varchar](99) NULL,
    [Section] [varchar](99) NULL,
    [Parameter] [varchar](99) NULL,
    [Value] [varchar](7000) NULL,
    [AuditCreateDateTime] [datetime] default getdate() NULL,
    [AuditUserCreate] [varchar](255) default suser_name() NULL
)
INSERT INTO  @CashflowDiscount(Flag,Section,Parameter,[Value]) VALUES
('Static', '_Model', 'IncludeIncomingSections', 'TRUE')
,('Static', 'General', 'Type', 'Template')
,('Dynamic', 'Type1_', 'Formulae', 'YoA = [YOA]$Shift = (All.ReportingDate - All.ReportingDateOpen)*(-4)$SETPARAMETERS(RemoveZeros = "True")$DEFAULTOPTIONS(Function = "STRETCH", StretchValue = 1, AnchorPosition = 0, Interpolation = "LinearSpline", Periodicity = 1)$DEFAULTOPTIONS(Function = "DISC", ExponentFactor = 0.25, YieldCurveType = "Forward", CashflowShift = -0.5)$DEFAULTOPTIONS(Function = "SHIFT", HoldPositions = "FALSE", Direction = "Across", Interpolation = "NoInterpolation")$DEFAULTOPTIONS(Function = "RISKMETRICS", Direction="Across")$DEFAULTOPTIONS(Function = "CASHFLOW", Normalised = "TRUE", NormalisedFail = "ShortPatternAction", Periodicity = 4, ShortPatternAction = 1, PatternType = "Incremental", PatternShift = 0)$Open_Payment_Pattern_Inc = [TFC]_[RI FLAG]_S000000.[PAYPATT] |> STRETCH() |> INCREMENTAL()$Closed_Payment_Pattern_Inc = [TFC]_[RI FLAG]_[RunID].[PAYPATT] |> STRETCH() |> INCREMENTAL()$UND_Open = IU :> CASHFLOW(PatternName = "Open_Payment_Pattern_Inc", ValuationOrigin = All.ReportingDateOpen)$UND_Open_Pat = IU :> CASHFLOW(PatternName = "Closed_Payment_Pattern_Inc", ValuationOrigin = All.ReportingDateOpen)$UND_Closed = IU :> CASHFLOW(PatternName = "Closed_Payment_Pattern_Inc", ValuationOrigin = All.ReportingDate)$UND_Open_NEG = UND_Open :> SHIFT(ShiftValue = Shift) :> SELECT(Range = "1-(last)", Inverse = "True") :> RISKMETRICS()$UND_Open_Pat_NEG = UND_Open_Pat :> SHIFT(ShiftValue = Shift) :> SELECT(Range = "1-(last)", Inverse = "True") :> RISKMETRICS()$YC_LOCK_ClosedClosed = [CURRENCY]_[FOCUSGROUP]_[YOI].Gross_Closed_Closed_YC_Forward_Quarterly_Locked |> IFNULL(IfTrue = "[CURRENCY]_[FOCUSGROUP]_2018.Gross_Closed_Closed_YC_Forward_Quarterly_Locked", IfFalse = "[CURRENCY]_[FOCUSGROUP]_[YOI].Gross_Closed_Closed_YC_Forward_Quarterly_Locked")$YC_LOCK_OpenOpen = [CURRENCY]_[FOCUSGROUP]_[YOI].Gross_Open_Open_YC_Forward_Quarterly_Locked |> IFNULL(IfTrue = "[CURRENCY]_[FOCUSGROUP]_2018.Gross_Open_Open_YC_Forward_Quarterly_Locked", IfFalse = "[CURRENCY]_[FOCUSGROUP]_[YOI].Gross_Open_Open_YC_Forward_Quarterly_Locked")$YC_LOCK_OpenClosed = [CURRENCY]_[FOCUSGROUP]_[YOI].Gross_Open_Closed_YC_Forward_Quarterly_Locked |> IFNULL(IfTrue = "[CURRENCY]_[FOCUSGROUP]_2018.Gross_Open_Closed_YC_Forward_Quarterly_Locked", IfFalse = "[CURRENCY]_[FOCUSGROUP]_[YOI].Gross_Open_Closed_YC_Forward_Quarterly_Locked")$DIS_Open_Open_Open @ = UND_Open :> DISC(YieldCurve = "[CURRENCY].Gross_Open_Open_YC_Forward_Quarterly", ValuationOrigin = YoA) (Replace_Agg)$DIS_Open_Accreted = UND_Open :> SHIFT(ShiftValue = Shift) :> SELECT(Range = "1-(last)", Inverse = "True") :> DISC(YieldCurve = "[CURRENCY].Gross_Open_Open_YC_Forward_Quarterly", ValuationOrigin = YoA) (Replace_Agg)$DIS_Open_Cls_Open @ = UND_Open :> SHIFT(ShiftValue = Shift) :> SELECT(Range = "1-(last)") :> DISC(YieldCurve = "[CURRENCY].Gross_Open_Closed_YC_Forward_Quarterly", ValuationOrigin = YoA) (Replace_Agg) |> BODMAS( ApplyStructure = "DIS_Open_Accreted")$DIS_Open_Cls_Cls @ = UND_Open :> SHIFT(ShiftValue = Shift) :> SELECT(Range = "1-(last)") :> DISC(YieldCurve = "[CURRENCY].Gross_Closed_Closed_YC_Forward_Quarterly", ValuationOrigin = YoA) (Replace_Agg) |> BODMAS( ApplyStructure = "UND_Open_NEG")$DIS_Open_Cls_Cls_Pat @ = UND_Open_Pat :> SHIFT(ShiftValue = Shift) :> SELECT(Range = "1-(last)") :> DISC(YieldCurve = "[CURRENCY].Gross_Closed_Closed_YC_Forward_Quarterly", ValuationOrigin = YoA) (Replace_Agg) |> BODMAS( ApplyStructure = "UND_Open_Pat_NEG")$DIS_Cls_Cls_Cls @ = UND_Closed :> DISC(YieldCurve = "[CURRENCY].Gross_Closed_Closed_YC_Forward_Quarterly", ValuationOrigin = YoA) (Replace_Agg)$DISLOCK_Open_Open_Open @ = UND_Open :> DISC(YieldCurve = "YC_LOCK_OpenOpen", ValuationOrigin = YoA) (Replace_Agg)$DISLOCK_Open_Accreted = UND_Open :> SHIFT(ShiftValue = Shift) :> SELECT(Range = "1-(last)", Inverse = "True") :> DISC(YieldCurve = "YC_LOCK_OpenOpen", ValuationOrigin = YoA) (Replace_Agg)$DISLOCK_Open_Cls_Open @ = UND_Open :> SHIFT(ShiftValue = Shift) :> SELECT(Range = "1-(last)") :> DISC(YieldCurve = "YC_LOCK_OpenClosed", ValuationOrigin = YoA) (Replace_Agg) |> BODMAS( ApplyStructure = "DISLOCK_Open_Accreted")$DISLOCK_Open_Cls_Cls @ = UND_Open :> SHIFT(ShiftValue = Shift) :> SELECT(Range = "1-(last)") :> DISC(YieldCurve = "YC_LOCK_ClosedClosed", ValuationOrigin = YoA) (Replace_Agg) |> BODMAS( ApplyStructure = "UND_Open_NEG")$DISLOCK_Open_Cls_Cls_Pat @ = UND_Open_Pat :> SHIFT(ShiftValue = Shift) :> SELECT(Range = "1-(last)") :> DISC(YieldCurve = "YC_LOCK_ClosedClosed", ValuationOrigin = YoA) (Replace_Agg) |> BODMAS( ApplyStructure = "UND_Open_Pat_NEG")$DISLOCK_Cls_Cls_Cls @ = UND_Closed :> DISC(YieldCurve = "YC_LOCK_ClosedClosed", ValuationOrigin = YoA) (Replace_Agg)$UNDISC @ = UND_Closed :> RISKMETRICS()')
,('Dynamic', 'Type2_', 'Formulae', 'YoA = [YOA]$SETPARAMETERS(RemoveZeros = "True")$DEFAULTOPTIONS(Function = "STRETCH", StretchValue = 1, AnchorPosition = 0, Interpolation = "LinearSpline", Periodicity = 1)$DEFAULTOPTIONS(Function = "DISC", ExponentFactor = 0.25, YieldCurveType = "Forward", CashflowShift = -0.5)$DEFAULTOPTIONS(Function = "SHIFT", HoldPositions = "FALSE", Direction = "Across", Interpolation = "NoInterpolation")$DEFAULTOPTIONS(Function = "RISKMETRICS", Direction="Across")$Payment_Pattern_Inc = [TFC]_[RI FLAG]_[RunID].[PAYPATT] |> STRETCH() |> INCREMENTAL()$UND_Closed = IU :> CASHFLOW(PatternName = "Payment_Pattern_Inc", Normalised = "TRUE", NormalisedFail = "ShortPatternAction", Periodicity = 4, ShortPatternAction = 1, PatternType = "Incremental", PatternShift = 0, ValuationOrigin = All.ReportingDate)$YC_LOCK_ClosedClosed = [CURRENCY]_[FOCUSGROUP]_[YOI].Gross_Closed_Closed_YC_Forward_Quarterly_Locked |> IFNULL(IfTrue = "[CURRENCY]_[FOCUSGROUP]_2018.Gross_Closed_Closed_YC_Forward_Quarterly_Locked", IfFalse = "[CURRENCY]_[FOCUSGROUP]_[YOI].Gross_Closed_Closed_YC_Forward_Quarterly_Locked")$DIS_Cls_Cls_Cls @ = UND_Closed :> DISC(YieldCurve = "[CURRENCY].Gross_Closed_Closed_YC_Forward_Quarterly", ValuationOrigin = YoA) (Replace_Agg)$DISLOCK_Cls_Cls_Cls @ = UND_Closed :> DISC(YieldCurve = "YC_LOCK_ClosedClosed", ValuationOrigin = YoA) (Replace_Agg)$UNDISC @ = UND_Closed :> RISKMETRICS()')
,('Static', 'LEN(71)', 'Type', 'Default')
,('Static', 'LEN(71)', 'Template', 'General')
,('Static', 'LEN(71)', 'Tag', 'RunID = MID(1,7) | ENTITY = MID(9,5) | PROGRAMME = MID(15,3) | IFRS17 TFC = MID(19,4) | TFC = MID(24,5) | FOCUSGROUP = MID(30,5) | YOA = MID(36,4) | YOI = MID(41,4) | QTR = MID(46,7) | CURRENCY = MID(54,3) | INCEPTED = MID(58,1) | RI FLAG = MID(60,1) | PAYPATT = MID(62,3) | CASHTYPE = MID(66,2) | AGGREGATION = MID(69,1) | RP = MID(71,1)')
 
MERGE [IFRS17DataMart].[IDS].Cashflow_Discount AS TGT
 
 
USING @CashflowDiscount AS SRC
 
 
ON (
        TGT.ID = SRC.ID 
    )
 
 
WHEN NOT MATCHED BY TARGET THEN
INSERT (Flag,Section,Parameter,Value,[AuditCreateDateTime],[AuditUserCreate])
VALUES (Flag,Section,Parameter,Value,[AuditCreateDateTime],[AuditUserCreate])
;
