IF((Select count(*) from Dim.AccountingPeriod) = 0)
Insert into Dim.AccountingPeriod(PK_AccountingPeriod,AccountingPeriodName,AccountingYear,AccountingYearName,AccountingMonth,AccountingMonthName)
Values(201812,'201812',2018,'2018',12,'12')

IF((select count(*) from Outbound.AccPer_AsAt_Control)=0)
Insert into Outbound.AccPer_AsAt_Control(AccountingPeriod) values(201812)


IF((select count(*) from inbound.TechHub_AccPer_Control) = 0)
Insert into inbound.TechHub_AccPer_Control(From_AccountingPeriod,To_AccountingPeriod) values(201812,201812)

