﻿DECLARE @Account TABLE
(
[Pk_Account] [varchar](50) NOT NULL,
	[AuditCreateDateTime] [datetime] default getdate() NULL,
	[AuditUserCreate] [varchar](255) default suser_name() NULL
)

INSERT @Account([Pk_Account])
VALUES
('FSC_BKG'),
('FSC_PREM'),
('FSC_RIP'),
('P-BP-BU')

MERGE [IFRS17DataMart].[Dim].[Account] AS TGT

USING @Account AS SRC

ON (
		TGT.[PK_Account] = SRC.[Pk_Account] 
	)

WHEN NOT MATCHED BY TARGET THEN

INSERT ([PK_Account],[AuditCreateDateTime],[AuditUserCreate])
VALUES ([Pk_Account],[AuditCreateDateTime],[AuditUserCreate])
;

