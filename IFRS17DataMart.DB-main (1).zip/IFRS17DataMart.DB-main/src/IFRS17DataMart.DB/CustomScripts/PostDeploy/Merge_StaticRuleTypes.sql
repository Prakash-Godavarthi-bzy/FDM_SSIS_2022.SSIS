DECLARE @ValidationRuleType TABLE
(
[PK_ValidationRuleTypeID] [int] identity(1,1) NOT NULL,
[ValidationRuleType]	 varchar(150) Not NULL
)
INSERT @ValidationRuleType([ValidationRuleType])
VALUES ('Inspect Attribute'),('Inspect Value'),('Compare Values')
------------------------------------------------------------------


MERGE [IFRS17DataMart].[Dv].[ValidationRuleType] AS TGT

USING @ValidationRuleType AS SRC

ON (
		TGT.[ValidationRuleType]=SRC.[ValidationRuleType]
	)

WHEN NOT MATCHED BY TARGET THEN

INSERT ([ValidationRuleType]) VALUES ([ValidationRuleType]);
