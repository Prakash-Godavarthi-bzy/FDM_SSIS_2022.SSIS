﻿/*
This will be executed during the pre-deployment phase.
Use it to apply scripts for all actions that cannot be easily and 
consistently done using just the database project.

Note that the pre-deployment scripts are just prepended to the
generated script.

!!!Make sure your scripts are idempotent(repeatable)!!!

Example invocation:
EXEC sp_execute_script @sql = 'UPDATE Table....', @author = 'Your Name'
*/


IF EXISTS (SELECT DISTINCT 1 FROM [PWAPS].[IFRS17CalcUI_RunLog] HAVING COUNT(*) = 0)
BEGIN
INSERT INTO [PWAPS].[IFRS17CalcUI_RunLog] ([Reporting Period]  ,[Run Type]    ,[User Name]   ,[Run Description]   ,[Reporting Year]   
,[IR Scenario 07], [IR Reporting Period 07], [IR Scenario 08], [IR Reporting Period 08], [IR Scenario 09], [IR Reporting Period 09]
,[RI Scenario 07], [RI Reporting Period 07], [RI Scenario 08], [RI Reporting Period 08], [RI Scenario 09], [RI Reporting Period 09]
, [SM Scenario Actual], [SM Up to inception period Actual], [SM Reporting Period Actual], [RI SM Up to inception period Actual], [RI SM Reporting Period Actual]
,[Status]  ,[ScheduleRunType]   ,[ScheduleStatus]   ,[Email]    ,[AuditDateTime])
SELECT      201809    ,'Regulatory'     ,SYSTEM_USER     ,'OB Default Row'     ,2018     
,'Actual', 201809, 'Actual', 201809 , 'Actual', 201809
,'Actual', 201809, 'Actual', 201809 , 'Actual', 201809
,'Actual', 201809, 201809 , 201809, 201809
,'Completed'  ,'Now'     ,'Success'    ,'Test_Email@Beazley.Com'  ,GETDATE()
END

IF EXISTS (SELECT DISTINCT 1 FROM [PWAPS].[IFRS17CalcUI_RunLog] WHERE Pk_RequestId = 1 AND [IR Scenario 07]  IS NULL)
BEGIN
	UPDATE  [PWAPS].[IFRS17CalcUI_RunLog] 
	SET 
	[IR Scenario 07] = 'Actual'
	,[IR Reporting Period 07] = 201809
	,[IR Scenario 08] = 'Actual'
	,[IR Reporting Period 08] = 201809
	,[IR Scenario 09] = 'Actual'
	,[IR Reporting Period 09] = 201809
	,[RI Scenario 07]  = 'Actual'
	,[RI Reporting Period 07] = 201809
	,[RI Scenario 08]  = 'Actual'
	,[RI Reporting Period 08] = 201809
	,[RI Scenario 09] = 'Actual'
	,[RI Reporting Period 09] = 201809
	, [SM Scenario Actual] = 'Actual'
	,[SM Up to inception period Actual] = 201809
	, [SM Reporting Period Actual] = 201809
	, [RI SM Up to inception period Actual] = 201809
	, [RI SM Reporting Period Actual] = 201809
	WHERE Pk_RequestId = 1
END


IF EXISTS(SELECT DISTINCT 1 FROM OUTBOUND.IDS_RunID_Control HAVING COUNT(*)=0)
BEGIN
INSERT INTO OUTBOUND.IDS_RunID_Control(RunID) Values(1)
END


