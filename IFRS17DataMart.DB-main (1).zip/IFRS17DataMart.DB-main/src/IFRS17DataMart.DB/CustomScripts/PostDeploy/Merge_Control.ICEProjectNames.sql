DECLARE @ICEProjectNames TABLE
(
[ID] [int] identity(1,1) NOT NULL,
[IceProjectName] varchar(255) NULL
)



INSERT @ICEProjectNames(IceProjectName)
VALUES ('Project 1 ICE'), ('Project 2 ICE'),
('Project 3 ICE'),('Project 4 ICE')



MERGE [IFRS17DataMart].[Control].[ICEProjectNames] AS TGT
USING @ICEProjectNames AS SRC
ON (
TGT.[ID] = SRC.[ID]
AND TGT.[IceProjectName]=SRC.[IceProjectName]
)



WHEN NOT MATCHED BY TARGET THEN



INSERT ([IceProjectName]) VALUES ([IceProjectName]);