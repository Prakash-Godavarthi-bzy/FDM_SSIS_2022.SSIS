﻿IF EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='Fk_AssumptionDatasetNameId' and TABLE_NAME='Pattern' AND TABLE_SCHEMA='FCT')
	BEGIN
		DECLARE @Rowcount4 INT = 1
		WHILE @Rowcount4 > 0
			BEGIN
				UPDATE TOP (100000) FCT.Pattern
				SET Fk_AssumptionDatasetNameId=AD.Pk_AssumptionDatasetNameId
				from FCT.Pattern FP,Dim.AssumptionDatasets AD
					WHERE FP.TDH_DatasetName=AD.AssumptionDatasetName AND Fk_AssumptionDatasetNameId = -1 
				
				SET @Rowcount4 = @@ROWCOUNT
			END
	END

IF EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='Fk_AssumptionPercentageTypeId' and TABLE_NAME='Pattern' AND TABLE_SCHEMA='FCT')
	BEGIN
		DECLARE @Rowcount5 INT = 1
		WHILE @Rowcount5 > 0
			BEGIN
				UPDATE TOP (100000) FCT.Pattern
				SET Fk_AssumptionPercentageTypeId=AD.AssumptionPercentageTypeId
				from FCT.Pattern FP,Dim.AssumptionDatasets AD
					WHERE FP.TDH_DatasetName=AD.AssumptionDatasetName AND Fk_AssumptionPercentageTypeId = -1
				
				SET @Rowcount5 = @@ROWCOUNT
			END
	END

--GO

--ALTER TABLE FCT.PATTERN  ADD CONSTRAINT FK_AssumptionPercentageTypeId FOREIGN KEY(Fk_AssumptionPercentageTypeId)
--REFERENCES Dim.AssumptionPercentageType ([Pk_AssumptionPercentageTypeId])

--GO
--ALTER TABLE FCT.PATTERN ADD CONSTRAINT FK_AssumptionDatasetNameId FOREIGN KEY(Fk_AssumptionDatasetNameId)
--REFERENCES Dim.AssumptionDatasets ([Pk_AssumptionDatasetNameId])
