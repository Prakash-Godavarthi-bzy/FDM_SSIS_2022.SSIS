﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
MERGE [IFRS17DataMart].[PWAPS].[Appsettings] AS TGT
USING (
SELECT '@env' Environment,'PowerApp Environment' SettingName, 'Describes which enviroment PowerApp is connected to.' SettingDescription, '#{PowerAppEnvironment}' SettingValue
) AS SRC




ON ( TGT.SettingName = SRC.SettingName and TGT.Environment = SRC.Environment )
WHEN MATCHED AND
ISNULL(TGT.SettingValue,'') <> ISNULL(SRC.SettingValue,'') OR
ISNULL(TGT.SettingDescription,'') <> ISNULL(SRC.SettingDescription,'')
THEN
UPDATE SET TGT.SettingValue = SRC.SettingValue,
TGT.SettingDescription= SRC.SettingDescription
WHEN NOT MATCHED BY TARGET THEN
INSERT (Environment,SettingName,SettingDescription,SettingValue)
VALUES (src.Environment,src.SettingName,src.SettingDescription,src.SettingValue);