﻿DECLARE @Scenario TABLE
(
PK_Scenario [varchar](10) NOT NULL,
ScenarioName [varchar](50)  NULL,
	[AuditCreateDateTime] [datetime] default getdate() NULL,
	[AuditUserCreate] [varchar](255) default suser_name() NULL
)

INSERT @Scenario(PK_Scenario,ScenarioName)
VALUES
('N','None'),
('U','Ultimates')


MERGE [IFRS17DataMart].[Dim].Scenario AS TGT

USING @Scenario AS SRC

ON (
		TGT.PK_Scenario = SRC.PK_Scenario 
	)

WHEN NOT MATCHED BY TARGET THEN

INSERT (PK_Scenario,ScenarioName,[AuditCreateDateTime],[AuditUserCreate])
VALUES (PK_Scenario,ScenarioName,[AuditCreateDateTime],[AuditUserCreate])
;