
IF EXISTS(SELECT  1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'Dim' AND TABLE_NAME ='TopUPReference')
BEGIN
TRUNCATE TABLE [Dim].[TopUPReference]
END
 
DECLARE @TopUpReference TABLE
(
PK_TopUpReference int identity(1,1) NOT NULL,
Entity Varchar(50) NOT NULL,
TopUp Char(2) NOT NULL	
)
 
INSERT @TopUpReference(Entity,TopUp)
VALUES
('2623','Y'), 
('3622','Y'), 
('3623','Y'), 
('4321','Y'), 
('5623','Y'), 
('6050','Y'), 
('6107','Y'), 
('623','Y'), 
('8022','N'), 
('8033','N'), 
('No Entity','Y'), 
('USBAIC','N'),
('USBUSA','Y'), 
('USUKCONSOL','N'), 
('8044','N')
 
 
MERGE [IFRS17DataMart].[Dim].TopUPReference AS TGT
 
USING @TopUpReference AS SRC
 
ON (
		TGT.Entity = SRC.Entity
		AND TGT.TopUp = SRC.TopUp
	)
 
WHEN NOT MATCHED BY TARGET THEN
 
INSERT (Entity,TopUp)
VALUES (Entity,TopUp);