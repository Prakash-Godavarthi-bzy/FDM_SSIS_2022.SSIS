﻿DECLARE @JobName NVARCHAR(MAX) = 'Export DataSet,Populate IFRS17DataMart IDS,Upload Assumption to IDM'


DECLARE @JobSchedules TABLE (Active_Start_date datetime2, ScheduleID int)

SET NOCOUNT ON
--Get Active schedules with older create date than now, handles multiple schedules for job.
INSERT INTO @JobSchedules (Active_Start_date, ScheduleID)
SELECT msdb.dbo.agent_datetime(sch.active_start_date,0) as Active_start_date_dt, sjs.schedule_id
FROM msdb..sysjobs sj 
	INNER JOIN msdb..sysjobschedules sjs ON sj.job_id=sjs.job_id
	INNER JOIN msdb..sysschedules sch ON sjs.schedule_id=sch.schedule_id
WHERE  SJ.name IN (SELECT VALUE FROM string_split(@JobName,',')) AND sch.enabled=1
AND msdb.dbo.agent_datetime(sch.active_start_date,0) <= getdate()

DECLARE schedcursor CURSOR LOCAL FAST_FORWARD
FOR SELECT ScheduleID FROM @JobSchedules

DECLARE @scheduleid int
DECLARE @StartDate VARCHAR(8) =  CONVERT(VARCHAR,GETDATE(),112)
OPEN schedcursor

	FETCH NEXT FROM schedcursor INTO @scheduleid
	WHILE (@@fetch_status <> -1)
	BEGIN
		EXEC msdb..sp_update_schedule   @schedule_id=@scheduleid, @active_start_date =@StartDate
		PRINT 'Updated schedule: '+CONVERT(varchar(4), @scheduleid)+' to '+@Startdate
		FETCH NEXT FROM schedcursor INTO @scheduleid
	END

CLOSE schedcursor
DEALLOCATE schedcursor
GO
