/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

IF EXISTS ( SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'IDS' AND TABLE_NAME =  'SpotToForward')
BEGIN
TRUNCATE TABLE [IDS].[SpotToForward];
END
 
DECLARE @SpotToForward TABLE
(
ID int identity(1,1) NOT NULL,
Section Varchar(99) NULL,
Parameter Varchar(99) NULL,
Value Varchar(3000) NULL,
	[AuditCreateDateTime] [datetime] default getdate() NULL,
	[AuditUserCreate] [varchar](255) default suser_name() NULL
)
 
INSERT @SpotToForward(Section,Parameter,Value)
VALUES
('_Model', 'IncludeIncomingSections', 'TRUE')
, ('General', 'Type', 'Template')
, ('General', 'Formulae', 'DEFAULTOPTIONS(Function = "STRETCH", StretchValue = 4, AnchorPosition = 0, Interpolation = "StepInterpolation", Periodicity = 4)$YC_Quarterly_Forward  @ =  YC_Annual |> SPOTTOFORWARD() |> STRETCH()')
, ('ALL()', 'Type', 'Default')
, ('ALL()', 'Template', 'General')
 
 
MERGE [IFRS17DataMart].[IDS].SpotToForward AS TGT
 
USING @SpotToForward AS SRC
 
ON (
		TGT.ID = SRC.ID 
	)
 
WHEN NOT MATCHED BY TARGET THEN
 
INSERT (Section,Parameter,Value,[AuditCreateDateTime],[AuditUserCreate])
VALUES (Section,Parameter,Value,[AuditCreateDateTime],[AuditUserCreate])
;