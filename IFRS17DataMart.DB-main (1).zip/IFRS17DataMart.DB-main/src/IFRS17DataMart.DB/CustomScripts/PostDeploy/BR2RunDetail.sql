﻿--IF EXISTS (Select   Distinct 1 from Sys.tables  where name='CanonicalBR2RunDetails' And schema_id=SCHEMA_ID('rpt'))
--Begin
IF EXISTS (SELECT DISTINCT 1 FROM rpt.CanonicalBR2RunDetails HAVING COUNT(*) = 0)
BEGIN
Insert into rpt.CanonicalBR2RunDetails
(
		RunID,
		ReportingPeriod,
		UserName,
		RunStatus,
		[ICE Available],
		CanonicalStatus
)
Select  Pk_RequestId,
		[Reporting Period],
		[User Name],
		ScheduleStatus,
		CASE  When ICEStatus ='Success' Then 'Y'
					Else 'N'
					End As ICEStatus
				 ,
		'N'
		 From PWAPS.IFRS17CalcUI_RunLog 
		Where  ScheduleStatus='Success'
				AND ICEStatus='Success'
				AND [Not_Populated_Tables(ICE)]='All Tables Populated'
END
--END
