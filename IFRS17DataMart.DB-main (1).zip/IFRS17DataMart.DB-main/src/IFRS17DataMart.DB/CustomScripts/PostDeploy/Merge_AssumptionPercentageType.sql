﻿DECLARE @AssumptionPercentageType TABLE
(
[Pk_AssumptionPercentageTypeId] [int] IDENTITY(1,1) NOT NULL,
	[AssumptionPercentageType] [nvarchar](35) NULL,
	[CreatedDt] [datetime] NULL,
	[CreatedBy] [nvarchar](150) NULL,
	[UpdatedDt] [datetime] NULL,
	[UpdatedBy] [nvarchar](150) NULL,	
	[HelpLink] [nvarchar](255) NULL



)



INSERT @AssumptionPercentageType([AssumptionPercentageType],[HelpLink])
VALUES



('RI Admin','https://beazley.atlassian.net/wiki/spaces/TDH/pages/3199860846/Expenses+Spreadsheet'),
('Premium Lapse Risk','https://beazley.atlassian.net/wiki/spaces/TDH/pages/3199860880/Premium+Lapse+Risk+Spreadsheet'),
('LRC Risk Adjustment','https://beazley.atlassian.net/wiki/spaces/TDH/pages/3199860907/Risk+Adjustments+Spreadsheet'),
('LIC Risk Adjustment','https://beazley.atlassian.net/wiki/spaces/TDH/pages/3199860907/Risk+Adjustments+Spreadsheet'),
('LIC Risk Adjustment (Older Years)','https://beazley.atlassian.net/wiki/spaces/TDH/pages/3199860952/Risk+Adjustments+Older+Years+Spreadsheet'),
('Earning Pattern (Nat Cat)','https://beazley.atlassian.net/wiki/spaces/TDH/pages/3011837963/Earning+Patterns+Spreadsheet'),
('Reinsurance Credit Loss','https://beazley.atlassian.net/wiki/spaces/TDH/pages/2958622888/Assumptions+Without+Loss+Type+Spreadsheet'),
('Rebates','https://beazley.atlassian.net/wiki/spaces/TDH/pages/2958622888/Assumptions+Without+Loss+Type+Spreadsheet'),
('Adjustments','https://beazley.atlassian.net/wiki/spaces/TDH/pages/2993422714/Adjustments'),
('Mappings (Trifocus)','https://beazley.atlassian.net/wiki/spaces/TDH/pages/2958655753/Trifocus+Mapping'),
('Mappings (Account Code)','https://beazley.atlassian.net/wiki/spaces/TDH/pages/2957836638/Account+Code+Mapping'),
('ENIDs (Unearned)','https://beazley.atlassian.net/wiki/spaces/TDH/pages/2958622888/Assumptions+Without+Loss+Type+Spreadsheet'),
('Payment Pattern (Claims)','https://beazley.atlassian.net/wiki/spaces/TDH/pages/2958786933/Payment+Patterns+Spreadsheet'),
('FX Rate (Average)','https://beazley.atlassian.net/wiki/spaces/TDH/pages/2958491842/Exchange+Rates+Spreadsheet'),
('Payment Pattern (Premiums)','https://beazley.atlassian.net/wiki/spaces/TDH/pages/2958786933/Payment+Patterns+Spreadsheet'),
('FX Rate (Spot)','https://beazley.atlassian.net/wiki/spaces/TDH/pages/2958491842/Exchange+Rates+Spreadsheet'),
('Discount Rate','https://beazley.atlassian.net/wiki/spaces/TDH/pages/2950135848/Discount+Rates+Spreadsheet'),
('Ultimate Loss Ratios','https://beazley.atlassian.net/wiki/spaces/TDH/pages/2957803863/Ultimate+Loss+Ratios+Spreadsheet'),
('Reinstatement Premiums','https://beazley.atlassian.net/wiki/spaces/TDH/pages/2958622888/Assumptions+Without+Loss+Type+Spreadsheet'),
('Profit Commissions','https://beazley.atlassian.net/wiki/spaces/TDH/pages/2958622888/Assumptions+Without+Loss+Type+Spreadsheet'),
('Expenses (Other Acquisition)','https://beazley.atlassian.net/wiki/spaces/TDH/pages/3199860846/Expenses+Spreadsheet'),
--('IELR (Team)','https://beazley.atlassian.net/wiki/spaces/TDH/pages/2958262542/Assumptions+With+Loss+Type+Spreadsheet'),
('IELR (Pure)','https://beazley.atlassian.net/wiki/spaces/TDH/pages/2958262542/Assumptions+With+Loss+Type+Spreadsheet'),
('ENIDs (Earned)','https://beazley.atlassian.net/wiki/spaces/TDH/pages/2958622888/Assumptions+Without+Loss+Type+Spreadsheet'),
('Expenses (Claims Handling)','https://beazley.atlassian.net/wiki/spaces/TDH/pages/3199860846/Expenses+Spreadsheet'),
('Expenses (Admin Other)','https://beazley.atlassian.net/wiki/spaces/TDH/pages/3199860846/Expenses+Spreadsheet')


/*****************************************************************************
************ Please add any new records here. If we insert any record in between,
it will break the logic and duplicates may insert**************************
******************************************************************************/
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------





MERGE [IFRS17DataMart].[Dim].[AssumptionPercentageType] AS TGT



USING @AssumptionPercentageType AS SRC



ON (
TGT.[AssumptionPercentageType] = SRC.[AssumptionPercentageType] 


)



WHEN MATCHED AND



ISNULL(TGT.[AssumptionPercentageType],'') <> ISNULL(SRC.[AssumptionPercentageType],'') OR
ISNULL(TGT.[HelpLink],'') <> ISNULL(SRC.[HelpLink],'')

THEN



UPDATE SET TGT.[AssumptionPercentageType] = SRC.[AssumptionPercentageType],
--TGT.[CreatedDt] = SRC.[CreatedDt],
--TGT.[CreatedBy] = SRC.[CreatedBy],
--TGT.[UpdatedDt] = SRC.[UpdatedDt],
--TGT.[UpdatedBy] = SRC.[UpdatedBy]
TGT.[HelpLink]=   SRC.[HelpLink]



WHEN NOT MATCHED BY TARGET THEN



INSERT ([AssumptionPercentageType],[HelpLink])



VALUES ([AssumptionPercentageType],[HelpLink])
;