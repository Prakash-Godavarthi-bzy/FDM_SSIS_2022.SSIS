DROP TABLE IF EXISTS #LatestIDs
 
SELECT AccountingPeriod, FK_ReconcileDataStageID, max(PK_ReconcileIFRS17AccountingPeriodID) AS MAX_PK_ReconcileIFRS17AccountingPeriodID
INTO #LatestIDs
FROM Control.ReconcileIFRS17AccountingPeriod
GROUP BY AccountingPeriod, FK_ReconcileDataStageID
 
IF EXISTS ( SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'Control' AND TABLE_NAME =  'ReconcileIFRS17AccountingPeriodDetail' AND COLUMN_NAME = 'AccountingPeriodflag')
 
BEGIN
UPDATE T1
SET T1.AccountingPeriodflag =  CASE WHEN T2.MAX_PK_ReconcileIFRS17AccountingPeriodID IS NULL THEN 0 ELSE 1 END
FROM  Control.ReconcileIFRS17AccountingPeriod T1
LEFT JOIN #LatestIDs T2 ON T1.PK_ReconcileIFRS17AccountingPeriodID = T2.MAX_PK_ReconcileIFRS17AccountingPeriodID
WHERE T1.AccountingPeriodflag IS NULL
 
END
 
BEGIN
UPDATE T1
SET T1.AccountingPeriodflag =  CASE WHEN T2.MAX_PK_ReconcileIFRS17AccountingPeriodID IS NULL THEN 0 ELSE 1 END
FROM Control.ReconcileIFRS17AccountingPeriodDetail T1
LEFT JOIN #LatestIDs T2 ON T1.FK_ReconcileIFRS17AccountingPeriodID = T2.MAX_PK_ReconcileIFRS17AccountingPeriodID
WHERE T1.AccountingPeriodflag IS NULL
 
END