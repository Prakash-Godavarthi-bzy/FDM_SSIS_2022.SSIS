USE [MASTER]
GO

DECLARE @user_name SYSNAME

SET @user_name = 'SVC_Psicle'

IF @user_name = 'accounttype_applicationname'
BEGIN
    RAISERROR ('Login is using a template token value and must be modified.', 16, 1)
    RETURN
END

-- set @login_name (for non-production: development) [default]
DECLARE @login_name VARCHAR(max) = N'BFL\' + @user_name + N'_DEV'

-- set @login_name (for production) based upon the 'Environment Name' extended property on 'master' database
DECLARE @environment_name VARCHAR(3)
SET @environment_name = '#{DatabaseEnvironment}'
IF @environment_name like '#{Data%' SET @environment_name = 'DEV'

DECLARE @sub_env_name VARCHAR(8)
SELECT @sub_env_name = CAST(value AS VARCHAR) FROM master.sys.extended_properties WHERE name = 'Sub-Environment Name'

IF @sub_env_name IS NOT NULL
	SET @environment_name = @sub_env_name

IF (@environment_name IN ('PKG','PRD'))
    SET @login_name = N'BFL\' + @user_name + N'_PRD'
ELSE
    SET @login_name = N'BFL\' + @user_name + N'_' + @environment_name

-- validate and CREATE LOGIN ...
IF (EXISTS (SELECT 1 FROM [master].[sys].[server_principals] WHERE [name] = @login_name))
    RAISERROR ('Login ''%s'' already exists.', 10, 1, @login_name)
ELSE IF (@user_name = N'SVC_[APPLICATION]')
    RAISERROR ('Login ''%s'' using template token value and must be modified [user_name].', 16, 1, @login_name)
ELSE
BEGIN
    BEGIN TRY
		EXECUTE ('CREATE LOGIN [' + @login_name + '] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]')
        RAISERROR ('Login ''%s'' created.', 10, 1, @login_name)
    END TRY
    BEGIN CATCH
    DECLARE @err NVARCHAR(4000) = ERROR_MESSAGE()
        RAISERROR ('Login ''%s'' creation failed. %s', 16, 1, @login_name, @err)
    END CATCH
END
