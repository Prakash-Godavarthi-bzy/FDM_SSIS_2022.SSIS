﻿-- INCLUDE #{Proxy_Pre_v4}



SET @proxy_name = 'PXY_IFRS17DataMart'
--SET @credential_name = @proxy_name



-- INCLUDE #{Proxy_Mid_v4}
/*



Instructions:
=============
1. Set the @proxy_name
2. Optionally, set the @credential_name if it's different from the @proxy_name
3. Enable at least one subsystem by uncommenting it below



NOTE:
1. To use the Proxy for a TSql jobstep, edit the job step, go to the Advanced page, set in the "Run as user" field
2. Drop and re-create will fail if there is a job already using the proxy. Therefore some checks are required
and if there is a material conflict this script will throw an error.



*/
--SET @CmdExec = 1
--SET @Snapshot = 1
--SET @LogReader = 1
--SET @Distribution = 1
--SET @Merge = 1
--SET @QueueReader = 1
--SET @ANALYSISQUERY = 1
--SET @ANALYSISCOMMAND = 1
SET @SSIS = 1
--SET @PowerShell = 1



-- INCLUDE #{Proxy_Post_v4}
