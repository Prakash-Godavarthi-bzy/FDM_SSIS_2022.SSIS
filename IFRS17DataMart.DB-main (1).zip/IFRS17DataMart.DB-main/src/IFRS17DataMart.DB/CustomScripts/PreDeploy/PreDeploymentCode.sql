﻿

IF EXISTS ( SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'IDS' AND TABLE_NAME =  'OpenUoAOB' AND COLUMN_NAME = 'Tri focus')
BEGIN
ALTER TABLE [IFRS17DataMart].IDS.OpenUoAOB ALTER COLUMN [Tri focus] VARCHAR(50)  NULL;
END

-------Sprint4 Changes------


IF EXISTS ( SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'rpt' AND TABLE_NAME =  'vw_bm_factActuarialUltimates')
BEGIN
DROP View [rpt].[vw_bm_factActuarialUltimates] ;
END

IF EXISTS ( SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'rpt' AND TABLE_NAME =  'vw_bm_factADMUltimateLossRatios')
BEGIN
DROP View [rpt].[vw_bm_factADMUltimateLossRatios] ;
END

IF EXISTS ( SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'rpt' AND TABLE_NAME =  'vw_bm_factAssumptions')
BEGIN
DROP View [rpt].[vw_bm_factAssumptions];
END

IF EXISTS ( SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'rpt' AND TABLE_NAME =  'vw_bm_factCash')
BEGIN
DROP View [rpt].[vw_bm_factCash];
END

IF EXISTS ( SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'rpt' AND TABLE_NAME =  'vw_bm_factEarningPatternsQOI')
BEGIN
DROP View [rpt].[vw_bm_factEarningPatternsQOI];
END

IF EXISTS ( SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'rpt' AND TABLE_NAME =  'vw_bm_factEarningPatternsYOI')
BEGIN
DROP View [rpt].[vw_bm_factEarningPatternsYOI];
END


IF EXISTS ( SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'rpt' AND TABLE_NAME =  'vw_bm_factPaidIncurred')
BEGIN
DROP View [rpt].[vw_bm_factPaidIncurred];
END

IF EXISTS ( SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'rpt' AND TABLE_NAME =  'vw_bm_factPremiumBrokerage')
BEGIN
DROP View [rpt].[vw_bm_factPremiumBrokerage];
END



IF EXISTS ( SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'PWAPS' AND TABLE_NAME =  'VW_ExceptionData')
BEGIN
DROP View [PWAPS].[VW_ExceptionData];
END

IF EXISTS ( SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Outbound' AND TABLE_NAME =  'vw_TopUPRefrence')
BEGIN
DROP View [Outbound].[vw_TopUPRefrence];
END

IF EXISTS ( SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'PWAPS' AND TABLE_NAME =  'RunID_AssumptionDetails')
BEGIN
DROP View [PWAPS].[RunID_AssumptionDetails] ;
END


IF EXISTS(SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'Outbound') 
	BEGIN
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_ADMULRs
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_Aggr_ActurialUltimates
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_Aggr_Cash
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_Aggr_PaidAndIncurred
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_Aggr_PremiumBrokerage
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_AssumptionsOB
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_AssumptionPercentages
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_CSMReleaseBalancesOB
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_DiscountRate
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_EarningPatternsYOAYOI
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_EarningPatternsYOIQOI
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_EarningsOB
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_FXRate
		DROP VIEW IF EXISTS [Outbound].[vw_IDS_OpenUoAOB]
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_HistLockRatesOB
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_HistPremLockRatesOB
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_NatCat_EarningPatterns
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_PaymentPattern
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_PremiumAdjustments
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_PresStatementPatternsOB
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_PreStatementBalancesOB
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_Release_Calcs_FSC
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_RIPercentage
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_UndiscCSMWalkBalancesOB
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_UndiscLICWalkBalancesOB
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_UndiscLRCWalkBalancesOB
		DROP VIEW IF EXISTS OUTBOUND.vw_ICE_RunInformation
		DROP VIEW IF EXISTS OUTBOUND.vw_IDS_Cashflow_Discount
		DROP VIEW IF EXISTS Outbound.vw_IDS_BalHeader
	END



IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'IDS' and TABLE_NAME = 'UndiscCSMWalkBalancesOB' and COLUMN_NAME in ('Amount_disc'))
BEGIN
ALTER TABLE [IDS].[UndiscCSMWalkBalancesOB] ADD Amount_disc Numeric(38,12) DEFAULT 0  NOT NULL ;
END


IF NOT EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = 'IFRS17_Trifocus' AND TABLE_SCHEMA = 'Dim' AND COLUMN_NAME = 'FK_AccountingPeriod' AND DATA_TYPE = 'INT')
BEGIN
ALTER TABLE [Dim].[IFRS17_Trifocus] ADD [FK_AccountingPeriod] INT DEFAULT 9999 NOT NULL
END

IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'PWAPS' and TABLE_NAME = 'IFRS17CalcUI_RunLog' and COLUMN_NAME in ('Not_Populated_Tables(ICE)'))
BEGIN
ALTER TABLE PWAPS.IFRS17CalcUI_RunLog ADD  [Not_Populated_Tables(ICE)] VARCHAR(MAX) NULL
END




IF EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='TDH_DatasetName' and TABLE_NAME='Pattern' AND TABLE_SCHEMA='FCT')
	BEGIN		
		DECLARE @Rowcount INT = 1
		WHILE @Rowcount > 0
			BEGIN
				DELETE TOP (100000)
				FROM FCT.Pattern
				WHERE TDH_DatasetName IN(
					SELECT AssumptionDatasetName 
					FROM DIM.AssumptionDatasets
					WHERE AssumptionPercentageTypeId IS NULL)

				SET @Rowcount = @@ROWCOUNT
			END
	END

IF EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='AssumptionPercentageTypeId' and TABLE_NAME='AssumptionDatasets' AND TABLE_SCHEMA='DIM')
BEGIN
	DECLARE @Rowcount1 INT = 1
	WHILE @Rowcount1 > 0
	BEGIN
		DELETE TOP (100000)
		FROM DIM.AssumptionDatasets
		WHERE AssumptionPercentageTypeId IS NULL

		SET @Rowcount1 = @@ROWCOUNT
	END
END


IF EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='AssumptionDatasetNameId' and TABLE_NAME='FxRate' AND TABLE_SCHEMA='FCT')
	BEGIN		
		DECLARE @Rowcount2 INT = 1
		WHILE @Rowcount2 > 0
			BEGIN
				DELETE TOP (100000)
				FROM FCT.FxRate 
				WHERE AssumptionDatasetNameId is null or AssumptionPercentageTypeId is null

				SET @Rowcount2 = @@ROWCOUNT
			END
	END

IF EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='AssumptionPercentageTypeId' and TABLE_NAME='AssumptionData' AND TABLE_SCHEMA='FCT')
BEGIN
	DECLARE @Rowcount3 INT = 1
	WHILE @Rowcount3 > 0
	BEGIN
		DELETE TOP (100000)
		FROM fct.AssumptionData
		WHERE Pk_AssumptionDatasetNameId is null or Pk_AssumptionPercentageTypeId is null

		SET @Rowcount3 = @@ROWCOUNT
	END
END


IF Exists(SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.COLUMNS where TABLE_SCHEMA='fct' AND TABLE_NAME='AssumptionData')
BEGIN
	IF Exists(SELECT Distinct 1 FROM sys.indexes WHERE object_id = OBJECT_ID('fct.AssumptionData') AND name='bzyidx_AssumptionData_2')
		Begin
			Drop index [bzyidx_AssumptionData_2] On fct.AssumptionData
			ALTER TABLE fct.AssumptionData ALTER COLUMN Pk_AssumptionPercentageTypeId INT NOT NULL
		END
	ELSE
		BEGIN
			ALTER TABLE fct.AssumptionData ALTER COLUMN Pk_AssumptionPercentageTypeId INT NOT NULL
		END
END

IF Exists(SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.COLUMNS where TABLE_SCHEMA='fct' AND TABLE_NAME='AssumptionData')
BEGIN
	IF Exists(SELECT Distinct 1 FROM sys.indexes WHERE object_id = OBJECT_ID('fct.AssumptionData') AND name='PK_AssumptionData')
		Begin
			Drop index [PK_AssumptionData] On fct.AssumptionData
			ALTER TABLE fct.AssumptionData ALTER COLUMN Pk_AssumptionDatasetNameId INT NOT NULL
		END
	ELSE
		BEGIN
			ALTER TABLE fct.AssumptionData ALTER COLUMN Pk_AssumptionDatasetNameId INT NOT NULL
		END
END


IF EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='AssumptionPercentageTypeId' and TABLE_NAME='FxRate' AND TABLE_SCHEMA='fct')
	BEGIN
		ALTER TABLE fct.FxRate ALTER COLUMN AssumptionPercentageTypeId INT NOT NULL
	END

IF EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='AssumptionDatasetNameId' and TABLE_NAME='FxRate' AND TABLE_SCHEMA='fct')
	BEGIN
		ALTER TABLE fct.FxRate ALTER COLUMN AssumptionDatasetNameId INT NOT NULL
	END

IF EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='Fk_AssumptionPercentageTypeId' and TABLE_NAME='Pattern' AND TABLE_SCHEMA='FCT')
	select 1
else
	BEGIN
		ALTER TABLE FCT.PATTERN ADD Fk_AssumptionPercentageTypeId INT  DEFAULT(-1) NOT NULL
	END


IF EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='Fk_AssumptionDatasetNameId' and TABLE_NAME='Pattern' AND TABLE_SCHEMA='FCT')
	select 1
else
	BEGIN
		ALTER TABLE FCT.PATTERN ADD Fk_AssumptionDatasetNameId INT DEFAULT(-1) NOT NULL
	END
----	----------------------------------Index----------------------------------------------
----	--------------------------------------------------------------------------------------
IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='FSC_EarnPrem_Prior' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_FSC_EarnPrem_Prior_AccountingPeriod')
BEGIN
CREATE NONCLUSTERED INDEX [IX_FSC_EarnPrem_Prior_AccountingPeriod] ON [fct].[FSC_EarnPrem_Prior]
(
[Accounting_Period] ASC
) WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;


IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='OpenCloseYOA' And TABLE_SCHEMA='Dim')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_OpenCloseYOA_AccountingPeriod')
BEGIN
CREATE NONCLUSTERED INDEX [IX_OpenCloseYOA_AccountingPeriod] ON [Dim].[OpenCloseYOA] 
(
[FK_AccountingPeriod] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='OpenCloseYOA' And TABLE_SCHEMA='Dim')
BEGIN
	IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_OpenCloseYOA_YOATrifocusProgramme')
		BEGIN
		CREATE NONCLUSTERED INDEX [IX_OpenCloseYOA_YOATrifocusProgramme] ON [Dim].[OpenCloseYOA] 
		(
			[FK_AccountingPeriod] ASC,
			[FK_YOA] ASC,
			[FK_Trifocus] ASC,
			[Programme] ASC
		)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
		END;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='IFRS17_Trifocus' And TABLE_SCHEMA='Dim')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_IFRS17_Trifocus_AccountingPeriod')
BEGIN
CREATE NONCLUSTERED INDEX [IX_IFRS17_Trifocus_AccountingPeriod] ON  [Dim].[IFRS17_Trifocus]
(
[FK_AccountingPeriod] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;



IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='PreProcessPremiumLTD' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_PreProcessPremiumLTD_TrifocusYOAProgramme')
BEGIN
CREATE NONCLUSTERED INDEX [IX_PreProcessPremiumLTD_TrifocusYOAProgramme] ON [fct].[PreProcessPremiumLTD]
(
	[FK_AccountingPeriod] ASC,
	[FK_YOA] ASC,
	[FK_Trifocus] ASC,
	[Programme] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='PreProcessPremiumLTD' And TABLE_SCHEMA='fct')
BEGIN
IF EXISTS (select distinct 1 from sys.indexes where name = 'IX_PreProcessPremiumLTD_AccountingPeriod')
BEGIN
DROP INDEX [IX_PreProcessPremiumLTD_AccountingPeriod] ON [fct].[PreProcessPremiumLTD]
END;
END;


IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Aggr_PremiumLTD' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_Aggr_PremiumLTD_AccountingPeriod')
BEGIN
CREATE NONCLUSTERED INDEX [IX_Aggr_PremiumLTD_AccountingPeriod] ON [fct].[Aggr_PremiumLTD]
(
[AccountingPeriod] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;



IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Aggr_NonPremiumLTD' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_Aggr_NonPremiumLTD_AccountingPeriod')
BEGIN
CREATE NONCLUSTERED INDEX [IX_Aggr_NonPremiumLTD_AccountingPeriod] ON [fct].[Aggr_NonPremiumLTD]
(
[AccountingPeriod] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='FSC_Actual' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_FSC_Actual_AccountingPeriod')
BEGIN
CREATE NONCLUSTERED INDEX [IX_FSC_Actual_AccountingPeriod] ON [fct].[FSC_Actual]  
(
[FK_AccountingPeriod] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='FSC_EPI' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_FSC_EPI_AccountingPeriod')
BEGIN
CREATE NONCLUSTERED INDEX [IX_FSC_EPI_AccountingPeriod] ON [fct].[FSC_EPI]  
(
[FK_AccountingPeriod] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='FSC_Forecast' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_FSC_Forecast_AccountingPeriod')
BEGIN
CREATE NONCLUSTERED INDEX [IX_FSC_Forecast_AccountingPeriod] ON [fct].[FSC_Forecast]  
(
[FK_AccountingPeriod] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;


IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='FSC_Per_QOI' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_FSC_Per_QOI_AccountingPeriod')
BEGIN
CREATE NONCLUSTERED INDEX [IX_FSC_Per_QOI_AccountingPeriod] ON [fct].[FSC_Per_QOI]  
(
[FK_AccountingPeriod] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='FSC_Per_YOA' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_FSC_Per_YOA_AccountingPeriod')
BEGIN
CREATE NONCLUSTERED INDEX [IX_FSC_Per_YOA_AccountingPeriod] ON [fct].[FSC_Per_YOA]  
(
[FK_AccountingPeriod] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='EarnedPremiumByQtr_NonBinders' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_EarnedPremiumByQtr_NonBinders_AccountingPeriod')
BEGIN
CREATE NONCLUSTERED INDEX [IX_EarnedPremiumByQtr_NonBinders_AccountingPeriod] ON [fct].[EarnedPremiumByQtr_NonBinders]  
(
[FK_AccountingPeriod] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='ExpectedWrittenPremium_Binders' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_ExpectedWrittenPremium_Binders_AccountingPeriod')
BEGIN
CREATE NONCLUSTERED INDEX [IX_ExpectedWrittenPremium_Binders_AccountingPeriod] ON [fct].[ExpectedWrittenPremium_Binders]  
(
[FK_AccountingPeriod] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='ActualWrittenPremiumByEarnQtr_Binders' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_ActualWrittenPremiumByEarnQtr_Binders_AccountingPeriod')
BEGIN
CREATE NONCLUSTERED INDEX [IX_ActualWrittenPremiumByEarnQtr_Binders_AccountingPeriod] ON [fct].[ActualWrittenPremiumByEarnQtr_Binders]  
(
[FK_AccountingPeriod] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='PremiumLatestValueWithOpenCloseFlag' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_PremiumLatestValueWithOpenCloseFlag_AccountingPeriod')
BEGIN
CREATE NONCLUSTERED INDEX [IX_PremiumLatestValueWithOpenCloseFlag_AccountingPeriod] ON [fct].[PremiumLatestValueWithOpenCloseFlag]  
(
[FK_AccountingPeriod] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;


IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='EarningsForGrossNonRadAndRadProg' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_EarningsForGrossNonRadAndRadProg_AccountingPeriod')
BEGIN
CREATE NONCLUSTERED INDEX [IX_EarningsForGrossNonRadAndRadProg_AccountingPeriod] ON [fct].[EarningsForGrossNonRadAndRadProg]  
(
[FK_AccountingPeriod] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;


If Exists (Select distinct 1 from sys.indexes where name = 'IX_FSC_Per_YOA_adj_AccountingPeriod')
Begin
 Drop index IX_FSC_Per_YOA_adj_AccountingPeriod On [fct].[FSC_Per_YOA_adj]
End

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='FSC_Per_YOA_adj' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_FSC_Per_YOA_adj_AdjustmentID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_FSC_Per_YOA_adj_AdjustmentID] ON [fct].[FSC_Per_YOA_adj]  
(
[AdjustmentID] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;

If Exists (Select distinct 1 from sys.indexes where name = 'IX_FSC_Per_QOI_adj_AccountingPeriod')
Begin  
Drop index IX_FSC_Per_QOI_adj_AccountingPeriod On [fct].[FSC_Per_QOI_adj] 
End

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='FSC_Per_QOI_adj' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_FSC_Per_QOI_adj_AdjustmentID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_FSC_Per_QOI_adj_AdjustmentID] ON [fct].[FSC_Per_QOI_adj]  
(
[AdjustmentID] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;

----------------------------------------------------------PK_Constarints---------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------
IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='FSC_EarnPrem_Prior' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (SELECT distinct 1 FROM information_schema.table_constraints where TABLE_SCHEMA='fct' And TABLE_NAME='FSC_EarnPrem_Prior' And CONSTRAINT_NAME='PK_ID_FSC_EarnPrem_Prior')
BEGIN
ALTER TABLE [fct].[FSC_EarnPrem_Prior]  ADD CONSTRAINT PK_ID_FSC_EarnPrem_Prior PRIMARY KEY (Id);
END;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='FSC_Actual' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (SELECT distinct 1 FROM information_schema.table_constraints where TABLE_SCHEMA='fct' And TABLE_NAME='FSC_Actual' And CONSTRAINT_NAME='PK_ID_FSC_Actual')
BEGIN
ALTER TABLE [fct].[FSC_Actual]  ADD CONSTRAINT PK_ID_FSC_Actual PRIMARY KEY (Id);
END;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='FSC_EPI' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (SELECT distinct 1 FROM information_schema.table_constraints where TABLE_SCHEMA='fct' And TABLE_NAME='FSC_EPI' And CONSTRAINT_NAME='PK_ID_FSC_EPI')
BEGIN
ALTER TABLE [fct].[FSC_EPI]  ADD CONSTRAINT PK_ID_FSC_EPI PRIMARY KEY (Id);
END;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='FSC_Forecast' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (SELECT distinct 1 FROM information_schema.table_constraints where TABLE_SCHEMA='fct' And TABLE_NAME='FSC_Forecast' And CONSTRAINT_NAME='PK_ID_FSC_Forecast')
BEGIN
ALTER TABLE [fct].[FSC_Forecast]   ADD CONSTRAINT PK_ID_FSC_Forecast PRIMARY KEY (Id);
END;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='FSC_Per_QOI' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (SELECT distinct 1 FROM information_schema.table_constraints where TABLE_SCHEMA='fct' And TABLE_NAME='FSC_Per_QOI' And CONSTRAINT_NAME='PK_ID_FSC_Per_QOI')
BEGIN
ALTER TABLE [fct].[FSC_Per_QOI]   ADD CONSTRAINT PK_ID_FSC_Per_QOI PRIMARY KEY (Id);
END;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='FSC_Per_YOA' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (SELECT distinct 1 FROM information_schema.table_constraints where TABLE_SCHEMA='fct' And TABLE_NAME='FSC_Per_YOA' And CONSTRAINT_NAME='PK_ID_FSC_Per_YOA')
BEGIN
ALTER TABLE [fct].[FSC_Per_YOA]    ADD CONSTRAINT PK_ID_FSC_Per_YOA PRIMARY KEY (Id);
END;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='EarnedPremiumByQtr_NonBinders' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (SELECT distinct 1 FROM information_schema.table_constraints where TABLE_SCHEMA='fct' And TABLE_NAME='EarnedPremiumByQtr_NonBinders' And CONSTRAINT_NAME='PK_ID_EarnedPremiumByQtr_NonBinders')
BEGIN
ALTER TABLE [fct].[EarnedPremiumByQtr_NonBinders]    ADD CONSTRAINT PK_ID_EarnedPremiumByQtr_NonBinders PRIMARY KEY (Id);
END;
END;
IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='FSC_Per_QOI_adj' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (SELECT distinct 1 FROM information_schema.table_constraints where TABLE_SCHEMA='fct' And TABLE_NAME='FSC_Per_QOI_adj' And CONSTRAINT_NAME='PK_ID_FSC_Per_QOI_adj')
BEGIN
ALTER TABLE [fct].[FSC_Per_QOI_adj]   ADD CONSTRAINT PK_ID_FSC_Per_QOI_adj PRIMARY KEY (Id);
END;
END;
IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='ExpectedWrittenPremium_Binders' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (SELECT distinct 1 FROM information_schema.table_constraints where TABLE_SCHEMA='fct' And TABLE_NAME='ExpectedWrittenPremium_Binders' And CONSTRAINT_NAME='PK_ID_ExpectedWrittenPremium_Binders')
BEGIN
ALTER TABLE [fct].[ExpectedWrittenPremium_Binders]  ADD CONSTRAINT PK_ID_ExpectedWrittenPremium_Binders PRIMARY KEY (Id);
END;
END;


IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='ActualWrittenPremiumByEarnQtr_Binders' And TABLE_SCHEMA='fct')
BEGIN
IF NOT EXISTS (SELECT distinct 1 FROM information_schema.table_constraints where TABLE_SCHEMA='fct' And TABLE_NAME='ActualWrittenPremiumByEarnQtr_Binders' And CONSTRAINT_NAME='PK_ID_ActualWrittenPremiumByEarnQtr_Binders')
BEGIN
ALTER TABLE [fct].[ActualWrittenPremiumByEarnQtr_Binders]  ADD CONSTRAINT PK_ID_ActualWrittenPremiumByEarnQtr_Binders PRIMARY KEY (Id);
END;
END;





------------------------------------------DataChecks Index----------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------
IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='AssumptionPercentages' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_AssumptionPercentages_PK_RequestID_DatasetNameId_PercentageTypeID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_AssumptionPercentages_PK_RequestID_DatasetNameId_PercentageTypeID] ON [IDS].[AssumptionPercentages]
(
	[Pk_RequestId] ASC,
	[DatasetNameId] ASC,
	[PercentageTypeId] ASC,
	[PK_TriFocus_4] ASC,
	[Entity] ASC,
	[RIProgramme] ASC,
	[GeneralPercent_0] ASC
)
INCLUDE([PK_YOA_3],[LossType],[RIFlag],[Quarters],[Focus Group]) WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='AssumptionPercentages' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_AssumptionPercentages_DataSetName_PKRequestID_GeneralPercent')
BEGIN
CREATE NONCLUSTERED INDEX [IX_AssumptionPercentages_DataSetName_PKRequestID_GeneralPercent] ON [IDS].[AssumptionPercentages]
(
	[DatasetNameId] ASC,
	[Pk_RequestId] ASC,
	[GeneralPercent_0] ASC,
	[PK_TriFocus_4] ASC,
	[PK_YOA_3] ASC,
	[PercentageTypeId] ASC,
	[Entity] ASC
)
INCLUDE([LossType],[RIFlag],[Quarters]) WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;





IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='PaymentPattern' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_PaymentPattern_DevelopmentQuarter_DatasetNameID')
BEGIN
CREATE CLUSTERED INDEX [IX_PaymentPattern_DevelopmentQuarter_DatasetNameID] ON [IDS].[PaymentPattern]
(
	[DevelopmentQuarter] ASC,
	[DatasetNameId] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;


IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='PaymentPattern' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_PaymentPattern_DatasetNameID_PK_requestID_DevelopmentQuarter')
BEGIN
CREATE NONCLUSTERED INDEX [IX_PaymentPattern_DatasetNameID_PK_requestID_DevelopmentQuarter] ON [IDS].[PaymentPattern]
(
	[DatasetNameId] ASC,
	[Pk_RequestId] ASC,
	[DevelopmentQuarter] ASC,
	[PercentageTypeId] ASC,
	[PaymentPerc] ASC
)
INCLUDE([RIFlag]) WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;


IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='PaymentPattern' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_Pk_RequestID_DatasetNameID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_Pk_RequestID_DatasetNameID] ON [IDS].[PaymentPattern]
(
	[Pk_RequestId] ASC,
	[DatasetNameId] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;


IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Open_CloseYOA' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_Open_CloseYOA_Programme_RunID_YOA')
BEGIN
CREATE NONCLUSTERED INDEX [IX_Open_CloseYOA_Programme_RunID_YOA] ON [IDS].[Open_CloseYOA]
(
	[Programme] ASC,
	[RunId] ASC,
	[YOA] ASC
)
INCLUDE([TrifocusCode],[Open/Closed]) WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;


IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Open_CloseYOA' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_Open_CloseYOA_RunID_Trifocuscode_YOA')
BEGIN
CREATE NONCLUSTERED INDEX [IX_Open_CloseYOA_RunID_Trifocuscode_YOA] ON [IDS].[Open_CloseYOA]
(
	[RunId] ASC,
	[TrifocusCode] ASC,
	[YOA] ASC,
	[Open/Closed] ASC
)
INCLUDE([Programme]) WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Open_CloseYOA' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_Open_Close_YOA_YOA')
BEGIN
CREATE NONCLUSTERED INDEX [IX_Open_Close_YOA_YOA] ON [IDS].[Open_CloseYOA]
(
	[YOA] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;


IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='DiscountRate' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_DiscountRate_DatasetNameID')
BEGIN
CREATE CLUSTERED INDEX [IX_DiscountRate_DatasetNameID] ON [IDS].[DiscountRate]
(
	[DatasetNameId] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='FXRate' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_FXRate_DatasetNameID')
BEGIN
CREATE CLUSTERED INDEX [IX_FXRate_DatasetNameID] ON [IDS].[FXRate]
(
	[DatasetNameId] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Aggr_PremiumBrokerage' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_Aggr_PremiumBrokerage_RunID_ID_RI_Flag')
BEGIN
CREATE NONCLUSTERED INDEX [IX_Aggr_PremiumBrokerage_RunID_ID_RI_Flag] ON [IDS].[Aggr_PremiumBrokerage]
(
	[RunID] ASC,
	[Id] ASC,
	[RI_Flag] ASC,
	[Tri focus code] ASC,
	[Account] ASC,
	[Entity] ASC,
	[IFRS17 Trifocus] ASC,
	[Programme] ASC,
	[Premtype] ASC,
	[RecognitionType] ASC,
	[Amount] ASC
)
INCLUDE([YOA],[YOI],[CCY]) WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
End;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Aggr_CashExcludingClaims' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_Aggr_CashExcludingClaims_TriFocus_Code_RunID_Entity')
BEGIN
CREATE NONCLUSTERED INDEX [IX_Aggr_CashExcludingClaims_TriFocus_Code_RunID_Entity] ON [IDS].[Aggr_CashExcludingClaims]
(
	[Tri focus code] ASC,
	[RunID] ASC,
	[Entity] ASC,
	[IFRS17 TrifocusCode] ASC,
	[Account] ASC,
	[Programme] ASC,
	[RI_Flag] ASC,
	[YOA] ASC,
	[Amount] ASC
)
INCLUDE([Id],[YOI],[CCY]) WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;


IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='TrifocusMapping' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_TrifocusMapping_RunID_TrifocusCode_FocusGroup')
BEGIN
CREATE NONCLUSTERED INDEX [IX_TrifocusMapping_RunID_TrifocusCode_FocusGroup] ON [IDS].[TrifocusMapping]
(
	[RunID] ASC,
	[Trifocus Code] ASC,
	[Focus Group] ASC,
	[Division] ASC
	 
)
INCLUDE ([ID],[AuditCreateDateTime]) WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;


IF NOT  EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='CSM_Post_LCAdjustments'  AND TABLE_SCHEMA = 'IDS' and COLUMN_NAME in ('AuditCreateDateTime','AuditUserCreate'))
BEGIN
ALTER TABLE IDS.CSM_Post_LCAdjustments  ADD  [AuditCreateDateTime] DATETIME2(7) DEFAULT (getdate())  NOT NULL ;
ALTER TABLE IDS.CSM_Post_LCAdjustments  ADD  [AuditUserCreate]     NVARCHAR (510) DEFAULT (suser_sname())NOT NULL ;
END

IF NOT EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='RuleSet'  AND TABLE_SCHEMA = 'Dv'  AND  COLUMN_NAME='Ruleset' AND DATA_TYPE = 'VARCHAR'
AND CHARACTER_MAXIMUM_LENGTH = 50)
BEGIN
ALTER TABLE Dv.RuleSet ALTER COLUMN Ruleset VARCHAR (50) NULl;
ALTER TABLE Dv.ValidationRuleHeader ALTER COLUMN [Rule] VARCHAR (50) NULL;
END


IF NOT  EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='AssumptionOB'  AND TABLE_SCHEMA = 'IDS' and COLUMN_NAME in ('AuditCreateDateTime','AuditUserCreate'))
BEGIN
ALTER TABLE IDS.AssumptionOB  ADD  [AuditCreateDateTime] DATETIME2(7) DEFAULT (getdate())  NOT NULL ;
ALTER TABLE IDS.AssumptionOB  ADD  [AuditUserCreate]     NVARCHAR (510) DEFAULT (suser_sname())NOT NULL ;
END


IF NOT  EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='CSMReleaseBalancesOB'  AND TABLE_SCHEMA = 'IDS' and COLUMN_NAME in ('AuditCreateDateTime','AuditUserCreate'))
BEGIN
ALTER TABLE IDS.CSMReleaseBalancesOB  ADD  [AuditCreateDateTime] DATETIME2(7) DEFAULT (getdate())  NOT NULL ;
ALTER TABLE IDS.CSMReleaseBalancesOB  ADD  [AuditUserCreate]     NVARCHAR (510) DEFAULT (suser_sname())NOT NULL ;
END


IF NOT  EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='EarningsOB'  AND TABLE_SCHEMA = 'IDS' and COLUMN_NAME in ('AuditCreateDateTime','AuditUserCreate'))
BEGIN
ALTER TABLE IDS.EarningsOB  ADD  [AuditCreateDateTime] DATETIME2(7) DEFAULT (getdate())  NOT NULL ;
ALTER TABLE IDS.EarningsOB  ADD  [AuditUserCreate]     NVARCHAR (510) DEFAULT (suser_sname())NOT NULL ;
END


IF NOT  EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='HistLockRatesOB'  AND TABLE_SCHEMA = 'IDS' and COLUMN_NAME in ('AuditCreateDateTime','AuditUserCreate'))
BEGIN
ALTER TABLE IDS.HistLockRatesOB  ADD  [AuditCreateDateTime] DATETIME2(7) DEFAULT (getdate())  NOT NULL ;
ALTER TABLE IDS.HistLockRatesOB  ADD  [AuditUserCreate]     NVARCHAR (510) DEFAULT (suser_sname())NOT NULL ;
END




IF NOT  EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='HistPremLockRatesOB'  AND TABLE_SCHEMA = 'IDS' and COLUMN_NAME in ('AuditCreateDateTime','AuditUserCreate'))
BEGIN
ALTER TABLE IDS.HistPremLockRatesOB  ADD  [AuditCreateDateTime] DATETIME2(7) DEFAULT (getdate())  NOT NULL ;
ALTER TABLE IDS.HistPremLockRatesOB  ADD  [AuditUserCreate]     NVARCHAR (510) DEFAULT (suser_sname())NOT NULL ;
END


IF NOT  EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='OpenClosedOB'  AND TABLE_SCHEMA = 'IDS' and COLUMN_NAME in ('AuditCreateDateTime','AuditUserCreate'))
BEGIN
ALTER TABLE IDS.OpenClosedOB  ADD  [AuditCreateDateTime] DATETIME2(7) DEFAULT (getdate())  NOT NULL ;
ALTER TABLE IDS.OpenClosedOB  ADD  [AuditUserCreate]     NVARCHAR (510) DEFAULT (suser_sname())NOT NULL ;
END


IF NOT  EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='OpenUoAOB'  AND TABLE_SCHEMA = 'IDS' and COLUMN_NAME in ('AuditCreateDateTime','AuditUserCreate'))
BEGIN
ALTER TABLE IDS.OpenUoAOB  ADD  [AuditCreateDateTime] DATETIME2(7) DEFAULT (getdate())  NOT NULL ;
ALTER TABLE IDS.OpenUoAOB  ADD  [AuditUserCreate]     NVARCHAR (510) DEFAULT (suser_sname())NOT NULL ;
END


IF NOT  EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='PremiumAdjustments'  AND TABLE_SCHEMA = 'IDS' and COLUMN_NAME in ('AuditCreateDateTime','AuditUserCreate'))
BEGIN
ALTER TABLE IDS.PremiumAdjustments  ADD  [AuditCreateDateTime] DATETIME2(7) DEFAULT (getdate())  NOT NULL ;
ALTER TABLE IDS.PremiumAdjustments  ADD  [AuditUserCreate]     NVARCHAR (510) DEFAULT (suser_sname())NOT NULL ;
END



IF NOT  EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='PresStatementPatternsOB'  AND TABLE_SCHEMA = 'IDS' and COLUMN_NAME in ('AuditCreateDateTime','AuditUserCreate'))
BEGIN
ALTER TABLE IDS.PresStatementPatternsOB  ADD  [AuditCreateDateTime] DATETIME2(7) DEFAULT (getdate())  NOT NULL ;
ALTER TABLE IDS.PresStatementPatternsOB  ADD  [AuditUserCreate]     NVARCHAR (510) DEFAULT (suser_sname())NOT NULL ;
END


IF NOT  EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='PreStatementBalancesOB'  AND TABLE_SCHEMA = 'IDS' and COLUMN_NAME in ('AuditCreateDateTime','AuditUserCreate'))
BEGIN
ALTER TABLE IDS.PreStatementBalancesOB  ADD  [AuditCreateDateTime] DATETIME2(7) DEFAULT (getdate())  NOT NULL ;
ALTER TABLE IDS.PreStatementBalancesOB  ADD  [AuditUserCreate]     NVARCHAR (510) DEFAULT (suser_sname())NOT NULL ;
END


IF NOT  EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='Release_Calcs_FSC'  AND TABLE_SCHEMA = 'IDS' and COLUMN_NAME in ('AuditCreateDateTime','AuditUserCreate'))
BEGIN
ALTER TABLE IDS.Release_Calcs_FSC ADD  [AuditCreateDateTime] DATETIME2(7) DEFAULT (getdate())  NOT NULL ;
ALTER TABLE IDS.Release_Calcs_FSC ADD  [AuditUserCreate]     NVARCHAR (510) DEFAULT (suser_sname())NOT NULL ;
END


IF NOT  EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='UndiscCSMWalkBalancesOB'  AND TABLE_SCHEMA = 'IDS' and COLUMN_NAME in ('AuditCreateDateTime','AuditUserCreate'))
BEGIN
ALTER TABLE IDS.UndiscCSMWalkBalancesOB  ADD  [AuditCreateDateTime] DATETIME2(7) DEFAULT (getdate())  NOT NULL ;
ALTER TABLE IDS.UndiscCSMWalkBalancesOB  ADD  [AuditUserCreate]     NVARCHAR (510) DEFAULT (suser_sname())NOT NULL ;
END


IF NOT  EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='UndiscLICWalkBalancesOB'  AND TABLE_SCHEMA = 'IDS' and COLUMN_NAME in ('AuditCreateDateTime','AuditUserCreate'))
BEGIN
ALTER TABLE IDS.UndiscLICWalkBalancesOB  ADD  [AuditCreateDateTime] DATETIME2(7) DEFAULT (getdate())  NOT NULL ;
ALTER TABLE IDS.UndiscLICWalkBalancesOB  ADD  [AuditUserCreate]     NVARCHAR (510) DEFAULT (suser_sname())NOT NULL ;
END

IF NOT  EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='UndiscLRCWalkBalancesOB'  AND TABLE_SCHEMA = 'IDS' and COLUMN_NAME in ('AuditCreateDateTime','AuditUserCreate'))
BEGIN
ALTER TABLE IDS.UndiscLRCWalkBalancesOB  ADD  [AuditCreateDateTime] DATETIME2(7) DEFAULT (getdate())  NOT NULL ;
ALTER TABLE IDS.UndiscLRCWalkBalancesOB  ADD  [AuditUserCreate]     NVARCHAR (510) DEFAULT (suser_sname())NOT NULL ;
END

IF NOT  EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='fct_AggrData_NonPremium'  AND TABLE_SCHEMA = 'stg' and COLUMN_NAME ='Loss Type')
BEGIN
ALTER TABLE [stg].[fct_AggrData_NonPremium]  ADD  [Loss Type]   VARCHAR (1)    NULL ;
END

IF NOT  EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='fct_AggrData_NonPremium'  AND TABLE_SCHEMA = 'stg' and COLUMN_NAME ='Type')
BEGIN
ALTER TABLE [stg].[fct_AggrData_NonPremium]  ADD  [Type]   VARCHAR (1)    NULL ;
END

----------------------------------------OB table index -------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------
IF NOT EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='CSM_Post_LCAdjustments' And TABLE_SCHEMA='IDS' And COLUMN_NAME='ID')
BEGIN
ALTER TABLE [IDS].[CSM_Post_LCAdjustments]  ADD  ID int identity(1,1) Primary Key;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='CSM_Post_LCAdjustments' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_CSM_Post_LCAdjustments_RunID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_CSM_Post_LCAdjustments_RunID] ON   [IDS].[CSM_Post_LCAdjustments]
(
	[RunID],[Entity],[Tri focus code]
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]---0.22
END;
END;


IF NOT EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='PreStatementBalancesOB' And TABLE_SCHEMA='IDS' And COLUMN_NAME='ID')
BEGIN
ALTER TABLE [IDS].[PreStatementBalancesOB]  ADD ID int identity(1,1) Primary Key;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='PreStatementBalancesOB' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_PreStatementBalancesOB_RunID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_PreStatementBalancesOB_RunID] ON   [IDS].[PreStatementBalancesOB]
(
	[RunID],[Entity],[Tri focus code]
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
END;
END;


IF NOT EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='OpenClosedOB' And TABLE_SCHEMA='IDS' And COLUMN_NAME='ID')
BEGIN
ALTER TABLE [IDS].[OpenClosedOB]  ADD  ID int identity(1,1) Primary Key;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='OpenClosedOB' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_OpenClosedOB_RunID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_OpenClosedOB_RunID] ON   [IDS].[OpenClosedOB]
(
	[RunID],[Tri focus code]
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
END;
END;


IF NOT EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='AssumptionOB' And TABLE_SCHEMA='IDS' And COLUMN_NAME='ID')
BEGIN
ALTER TABLE [IDS].[AssumptionOB]  ADD ID int identity(1,1) Primary Key
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='AssumptionOB' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name ='IX_AssumptionOB_RunID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_AssumptionOB_RunID] ON   [IDS].[AssumptionOB]
(
	[RunID],[Entity],[Tri focus code]
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
END;
END;



IF NOT EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='HistLockRatesOB' And TABLE_SCHEMA='IDS' And COLUMN_NAME='ID')
BEGIN
ALTER TABLE [IDS].[HistLockRatesOB]  ADD  ID int identity(1,1) Primary Key;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='HistLockRatesOB' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name ='IX_HistLockRatesOB_RunID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_HistLockRatesOB_RunID] ON   [IDS].[HistLockRatesOB]
(
	[RunID]
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
END;
END;


IF NOT EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='CSMReleaseBalancesOB' And TABLE_SCHEMA='IDS' And COLUMN_NAME='ID')
BEGIN
ALTER TABLE [IDS].[CSMReleaseBalancesOB]  ADD  CONSTRAINT PK_ID_CSMReleaseBalancesOB  Primary Key (ID);
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='CSMReleaseBalancesOB' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name ='IX_CSMReleaseBalancesOB_RunID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_CSMReleaseBalancesOB_RunID] ON   [IDS].[CSMReleaseBalancesOB]
(
	[RunID],[Entity],[Tri focus code]
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
END;
END;


IF NOT  EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='HistPremLockRatesOB' And TABLE_SCHEMA='IDS' And COLUMN_NAME='ID')
BEGIN
ALTER TABLE [IDS].[HistPremLockRatesOB]  ADD  ID int identity(1,1) Primary Key;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='HistPremLockRatesOB' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name ='IX_HistPremLockRatesOB_RunID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_HistPremLockRatesOB_RunID] ON   [IDS].[HistPremLockRatesOB]
(
	[RunID]
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
END;
END;


IF NOT  EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='OpenUoAOB' And TABLE_SCHEMA='IDS' And COLUMN_NAME='ID')
BEGIN
ALTER TABLE [IDS].[OpenUoAOB]  ADD  ID int identity(1,1) Primary Key;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='OpenUoAOB' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name ='IX_OpenUoAOB_RunID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_OpenUoAOB_RunID] ON   [IDS].[OpenUoAOB]
(
	[RunID],[Entity],[Tri focus code]
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
END;
END;

IF NOT  EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='PresStatementPatternsOB' And TABLE_SCHEMA='IDS' ANd COLUMN_NAME='ID')
BEGIN
ALTER TABLE [IDS].[PresStatementPatternsOB]  ADD  ID int identity(1,1) Primary Key ;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='PresStatementPatternsOB' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name ='IX_PresStatementPatternsOB_RunID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_PresStatementPatternsOB_RunID] ON   [IDS].[PresStatementPatternsOB]
(
	[RunID],[Entity],[Tri focus code]
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
END;
END;


IF NOT EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='UndiscLICWalkBalancesOB' And TABLE_SCHEMA='IDS' ANd COLUMN_NAME='ID')
BEGIN
ALTER TABLE [IDS].[UndiscLICWalkBalancesOB]  ADD  ID int identity(1,1) Primary Key;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='UndiscLICWalkBalancesOB' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name ='IX_UndiscLICWalkBalancesOB_RunID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_UndiscLICWalkBalancesOB_RunID] ON   [IDS].[UndiscLICWalkBalancesOB]
(
	[RunID],[Entity],[Tri focus code]
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
END;
END;


IF NOT EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='UndiscCSMWalkBalancesOB' And TABLE_SCHEMA='IDS' ANd COLUMN_NAME='ID')
BEGIN
ALTER TABLE [IDS].[UndiscCSMWalkBalancesOB]  ADD  ID int identity(1,1) Primary Key;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='UndiscCSMWalkBalancesOB' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name ='IX_UndiscCSMWalkBalancesOB_RunID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_UndiscCSMWalkBalancesOB_RunID] ON   [IDS].[UndiscCSMWalkBalancesOB]
(
	[RunID],[Entity],[Tri focus code]
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
END;
END;



IF NOT EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='UndiscLRCWalkBalancesOB' And TABLE_SCHEMA='IDS' And COLUMN_NAME='ID')
BEGIN
ALTER TABLE [IDS].[UndiscLRCWalkBalancesOB]  ADD  ID int identity(1,1) Primary Key;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='UndiscLRCWalkBalancesOB' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name ='IX_UndiscLRCWalkBalancesOB_RunID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_UndiscLRCWalkBalancesOB_RunID] ON   [IDS].[UndiscLRCWalkBalancesOB]
(
	[RunID],[Entity],[Tri focus code]
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
END;
END;

IF NOT EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='EarningsOB' And TABLE_SCHEMA='IDS' And COLUMN_NAME='ID')
BEGIN
ALTER TABLE [IDS].[EarningsOB]  ADD ID int identity(1,1) Primary Key;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='EarningsOB' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name ='IX_EarningsOB_RunID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_EarningsOB_RunID] ON   [IDS].[EarningsOB]
(
	[RunID],[Entity],[Tri focus code]
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
END;
END;

IF NOT EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='PremiumAdjustments' And TABLE_SCHEMA='IDS' And COLUMN_NAME='ID')
BEGIN
ALTER TABLE [IDS].[PremiumAdjustments]  ADD  ID int identity(1,1) Primary Key;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='PremiumAdjustments' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name ='IX_PremiumAdjustments_RunID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_PremiumAdjustments_RunID] ON   [IDS].[PremiumAdjustments]
(
	[RunID],[Entity],[Tri focus code]
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
END;
END;


IF NOT EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Release_Calcs_FSC' And TABLE_SCHEMA='IDS' And COLUMN_NAME='ID')
BEGIN
ALTER TABLE [IDS].[Release_Calcs_FSC]  ADD ID int identity(1,1) Primary Key;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='Release_Calcs_FSC' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name ='IX_Release_Calcs_FSC_RunID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_Release_Calcs_FSC_RunID] ON   [IDS].[Release_Calcs_FSC]
(
	[RunID],[Entity],[Tri focus code]
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
END;
END;



IF NOT EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='CatEarningOB' And TABLE_SCHEMA='IDS' And COLUMN_NAME='ID')
BEGIN
ALTER TABLE [IDS].[CatEarningOB]  ADD ID int identity(1,1) Primary Key;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='CatEarningOB' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name ='IX_CatEarningOB_RunID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_CatEarningOB_RunID] ON   [IDS].[CatEarningOB]
(
	[RunID],[Tri focus code]
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
END;
END;

IF NOT EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='AttEarningOB' And TABLE_SCHEMA='IDS' And COLUMN_NAME='ID')
BEGIN
ALTER TABLE [IDS].[AttEarningOB]  ADD ID int identity(1,1) Primary Key;
END;

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='AttEarningOB' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name ='IX_AttEarningOB_RunID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_AttEarningOB_RunID] ON   [IDS].[AttEarningOB]
(
	[RunID],[Tri focus code]
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
END;
END;


IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='AssumptionOB' And TABLE_SCHEMA='IDS')
BEGIN
IF  EXISTS (select distinct 1 from sys.indexes where name ='bzyidx_IDS_AssumptionOB_1')
BEGIN
  Drop index [bzyidx_IDS_AssumptionOB_1] On [IDS].[AssumptionOB]
END;
END;

IF EXISTS(SELECT DISTINCT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'vw_Adjustments' AND TABLE_SCHEMA = 'PWAPS')
BEGIN
DROP VIEW [PWAPS].[vw_Adjustments]
END


IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'PWAPS' and TABLE_NAME = 'IFRS17CalcUI_RunLog' and COLUMN_NAME in ('AuditEndDateTime'))
BEGIN
ALTER TABLE PWAPS.IFRS17CalcUI_RunLog ADD  [AuditEndDateTime] DATETIME2 (7) DEFAULT (getdate()) NULL
END

IF NOT EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='InboundStatus' and TABLE_NAME='IFRS17CalcUI_RunLog' AND TABLE_SCHEMA='PWAPS')
	BEGIN
		ALTER TABLE PWAPS.IFRS17CalcUI_RunLog ADD  [InboundStatus] VARCHAR(50) NULL
	END

 

IF NOT EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='ICEInputExtractionStatus' and TABLE_NAME='IFRS17CalcUI_RunLog' AND TABLE_SCHEMA='PWAPS')
	BEGIN
		ALTER TABLE PWAPS.IFRS17CalcUI_RunLog ADD  ICEInputExtractionStatus VARCHAR(10) NULL
	END

 

IF NOT EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='ICEOutputExtractionStatus' and TABLE_NAME='IFRS17CalcUI_RunLog' AND TABLE_SCHEMA='PWAPS')
	BEGIN
		ALTER TABLE PWAPS.IFRS17CalcUI_RunLog ADD  ICEOutputExtractionStatus VARCHAR(10) NULL
	END

IF NOT EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='RunConfigDetailsFileName' and TABLE_NAME='IFRS17CalcUI_RunLog' AND TABLE_SCHEMA='PWAPS')
BEGIN
	ALTER TABLE PWAPS.IFRS17CalcUI_RunLog ADD  RunConfigDetailsFileName NVARCHAR(128) NULL
END

IF EXISTS (SELECT 1 FROM SYS.objects WHERE NAME ='Udf_fnGetOpeningBalancePeriods' AND SCHEMA_NAME([SCHEMA_ID]) = 'PWAPS')
BEGIN
	DROP FUNCTION PWAPS.Udf_fnGetOpeningBalancePeriods 
END 

IF EXISTS (SELECT 1 FROM SYS.objects WHERE NAME ='UDF_OBPeriodsLoopThrough' AND SCHEMA_NAME([SCHEMA_ID]) = 'rpt')
BEGIN
	DROP FUNCTION rpt.UDF_OBPeriodsLoopThrough
END 

-------------Sprint14------------------------------
IF  EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='TrifocusMappingId' and TABLE_NAME='IFRS17CalcUI_RunLog' AND TABLE_SCHEMA='PWAPS')
	BEGIN
	Alter table [PWAPS].[IFRS17CalcUI_RunLog] Alter column [TrifocusMappingId] Varchar(100) NULL
	END

IF NOT EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='AccountingPeriodflag' and TABLE_NAME='ReconcileIFRS17AccountingPeriod' AND TABLE_SCHEMA='Control')
BEGIN
	ALTER TABLE [Control].[ReconcileIFRS17AccountingPeriod] ADD  [AccountingPeriodflag]   INT     NULL
END

IF NOT EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='AccountingPeriodflag' and TABLE_NAME='ReconcileIFRS17AccountingPeriodDetail' AND TABLE_SCHEMA='Control')
BEGIN
	ALTER TABLE [Control].[ReconcileIFRS17AccountingPeriodDetail] ADD  [AccountingPeriodflag]   INT     NULL
END


IF  EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='TrifocusMappingId' and TABLE_NAME='IFRS17CalcUI_RunLog' AND TABLE_SCHEMA='PWAPS')
	BEGIN
Update t1
Set TrifocusMappingId= t2.AssumptionDatasetName 
from PWAPS.IFRS17CalcUI_RunLog t1 
inner join dim.AssumptionDatasets t2 on t1.TrifocusMappingId = t2.Pk_AssumptionDatasetNameId
where isnumeric(t1.TrifocusMappingId) =1
END


IF EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='DimensionName' and TABLE_NAME='ValidationRuleDetailsType03' AND TABLE_SCHEMA='DV')
BEGIN
Alter table Dv.ValidationRuleDetailsType03 Alter column [DimensionName] Varchar(500)
END


------------Sprint15---------------
IF NOT EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='ApprovalStatus' and TABLE_NAME='IFRS17CalcUI_RunLog' AND TABLE_SCHEMA='PWAPS')
BEGIN
	ALTER TABLE PWAPS.IFRS17CalcUI_RunLog ADD  ApprovalStatus   VARCHAR(10) NULL
END

IF NOT EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='ApproverName' and TABLE_NAME='IFRS17CalcUI_RunLog' AND TABLE_SCHEMA='PWAPS')
BEGIN
	ALTER TABLE PWAPS.IFRS17CalcUI_RunLog ADD  ApproverName   VARCHAR(255) NULL 
END

IF NOT EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='ApprovedDateTime' and TABLE_NAME='IFRS17CalcUI_RunLog' AND TABLE_SCHEMA='PWAPS')
BEGIN
	ALTER TABLE PWAPS.IFRS17CalcUI_RunLog ADD  ApprovedDateTime datetime2(7) NULL
END

IF NOT EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='ApproverComments' and TABLE_NAME='IFRS17CalcUI_RunLog' AND TABLE_SCHEMA='PWAPS')
BEGIN
	ALTER TABLE PWAPS.IFRS17CalcUI_RunLog ADD  ApproverComments   VARCHAR(255) NULL
END

IF EXISTS (SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='BR2RunDetails' AND TABLE_SCHEMA = 'rpt')
BEGIN
	DROP Table  [rpt].[BR2RunDetails]
END

IF EXISTS (Select COUNT(*) from INFORMATION_SCHEMA.TABLES where TABLE_NAME='fct_TechnicalResult_BusinessPlan' And TABLE_SCHEMA = 'stg' HAVING COUNT(*) >=1)
BEGIN
	DROP TABLE [stg].[fct_TechnicalResult_BusinessPlan]
END 

IF  EXISTS(SELECT distinct 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='ApproverComments' and TABLE_NAME='IFRS17CalcUI_RunLog' AND TABLE_SCHEMA='PWAPS' and CHARACTER_MAXIMUM_LENGTH=255)
	BEGIN
	Alter table [PWAPS].[IFRS17CalcUI_RunLog] Alter column [ApproverComments] Varchar(max) 
	END


-----------Sprint 17 PBF Development Changes-----------
/*
IF NOT EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='TechHub_AccPer_Control'  AND TABLE_SCHEMA = 'Inbound' and COLUMN_NAME in ('FK_PKSCID','PP_RunType'))
BEGIN
ALTER TABLE Inbound.TechHub_AccPer_Control  ADD  [FK_PKSCID] INT;
ALTER TABLE Inbound.TechHub_AccPer_Control  ADD  [PP_RunType] varchar(5) DEFAULT 'A';
END

IF NOT EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='AccPer_AsAt_Control'  AND TABLE_SCHEMA = 'Outbound' and COLUMN_NAME in ('FK_PKSCID','PP_RunType'))
BEGIN
ALTER TABLE Outbound.AccPer_AsAt_Control  ADD  [FK_PKSCID] INT;
ALTER TABLE Outbound.AccPer_AsAt_Control  ADD  [PP_RunType] varchar(5) DEFAULT 'A';
END

IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'OpenCloseYOA' AND TABLE_SCHEMA='Dim' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
ALTER TABLE Dim.OpenCloseYOA ADD FK_ForecastBudgetRunHistoryID INT NULL;
ALTER TABLE [Dim].[OpenCloseYOA] ADD [VersionNumber] INT NULL;
END

IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'IFRS17_Trifocus' AND TABLE_SCHEMA='Dim' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
ALTER TABLE [Dim].IFRS17_Trifocus ADD FK_ForecastBudgetRunHistoryID INT NULL;
ALTER TABLE [Dim].IFRS17_Trifocus ADD [VersionNumber] INT NULL;
END

IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'ActualWrittenPremiumByEarnQtr_Binders' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
ALTER TABLE [fct].ActualWrittenPremiumByEarnQtr_Binders ADD FK_ForecastBudgetRunHistoryID INT NULL;
ALTER TABLE [fct].ActualWrittenPremiumByEarnQtr_Binders ADD [VersionNumber] INT NULL;
END

IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Aggr_PremiumLTD' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
ALTER TABLE [fct].Aggr_PremiumLTD ADD FK_ForecastBudgetRunHistoryID INT NULL;
ALTER TABLE [fct].Aggr_PremiumLTD ADD [VersionNumber] INT NULL;
END

IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Aggr_PremiumLTD' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('OpenCloseFlag'))
BEGIN
ALTER TABLE [fct].Aggr_PremiumLTD ADD [OpenCloseFlag] CHAR(1) NULL ;
END

IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'EarnedPremiumByQtr_NonBinders' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
ALTER TABLE [fct].EarnedPremiumByQtr_NonBinders ADD FK_ForecastBudgetRunHistoryID INT NULL;
ALTER TABLE [fct].EarnedPremiumByQtr_NonBinders ADD [VersionNumber] INT;
END

IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'EarningsForGrossNonRadAndRadProg' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
ALTER TABLE [fct].EarningsForGrossNonRadAndRadProg ADD FK_ForecastBudgetRunHistoryID INT NULL;
ALTER TABLE [fct].EarningsForGrossNonRadAndRadProg ADD [VersionNumber] INT NULL;
END

IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'ExpectedWrittenPremium_Binders' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
ALTER TABLE [fct].ExpectedWrittenPremium_Binders ADD FK_ForecastBudgetRunHistoryID INT NULL;
ALTER TABLE [fct].ExpectedWrittenPremium_Binders ADD [VersionNumber] INT NULL;
END

IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'FSC_Actual' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
ALTER TABLE [fct].[FSC_Actual] ADD FK_ForecastBudgetRunHistoryID INT NULL;
ALTER TABLE [fct].[FSC_Actual] ADD [VersionNumber] INT NULL;
END

IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'FSC_EarnPrem_Prior' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
ALTER TABLE [fct].FSC_EarnPrem_Prior ADD FK_ForecastBudgetRunHistoryID INT NULL;
ALTER TABLE [fct].FSC_EarnPrem_Prior ADD [VersionNumber] INT NULL;
END

IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'FSC_EPI' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
ALTER TABLE [fct].FSC_EPI ADD FK_ForecastBudgetRunHistoryID INT  NULL;
ALTER TABLE [fct].FSC_EPI ADD [VersionNumber] INT NULL;
END

IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'FSC_Forecast' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
ALTER TABLE [fct].FSC_Forecast ADD FK_ForecastBudgetRunHistoryID INT  NULL;
ALTER TABLE [fct].FSC_Forecast ADD [VersionNumber] INT NULL;
END

IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'FSC_Per_QOI' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
ALTER TABLE [fct].FSC_Per_QOI ADD FK_ForecastBudgetRunHistoryID INT  NULL;
ALTER TABLE [fct].FSC_Per_QOI ADD [VersionNumber] INT NULL;
END

IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'FSC_Per_YOA' AND TABLE_SCHEMA='fct' AND COLUMN_NAME IN ('FK_ForecastBudgetRunHistoryID','VersionNumber'))
BEGIN
ALTER TABLE [fct].[FSC_Per_YOA] ADD FK_ForecastBudgetRunHistoryID INT  NULL;
ALTER TABLE [fct].[FSC_Per_YOA] ADD [VersionNumber] INT NULL;
END
*/

IF EXISTS(Select Distinct 1 from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='PreProcessPremiumLTD' And TABLE_SCHEMA='IDS')
BEGIN
IF NOT EXISTS (select distinct 1 from sys.indexes where name = 'IX_AssumptionPercentages_DataSetName_PKRequestID_GeneralPercent')
BEGIN
CREATE NONCLUSTERED INDEX [IX_AssumptionPercentages_DataSetName_PKRequestID_GeneralPercent] ON [IDS].[AssumptionPercentages]
(
	[DatasetNameId] ASC,
	[Pk_RequestId] ASC,
	[GeneralPercent_0] ASC,
	[PK_TriFocus_4] ASC,
	[PK_YOA_3] ASC,
	[PercentageTypeId] ASC,
	[Entity] ASC
)
INCLUDE([LossType],[RIFlag],[Quarters]) WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
END;
END;

/* Just included for Smooth Deployment to SYS
IF EXISTS (
    SELECT 1
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = 'Dim'
    AND TABLE_NAME = 'AssumptionDatasets'
    AND COLUMN_NAME='Reporting Year'
) 
BEGIN

ALTER TABLE Dim.AssumptionDatasets DROP COLUMN [Reporting Year]

END


IF EXISTS (
    SELECT 1
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = 'Dim'
    AND TABLE_NAME = 'AssumptionDatasets'
    AND COLUMN_NAME='Reporting Quarter'
) 
BEGIN

ALTER TABLE Dim.AssumptionDatasets DROP COLUMN [Reporting Quarter]

END


IF EXISTS (
    SELECT 1
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = 'Dim'
    AND TABLE_NAME = 'AssumptionDatasets'
    AND COLUMN_NAME='RI Flag'
) 
BEGIN

ALTER TABLE Dim.AssumptionDatasets DROP COLUMN [RI Flag]

END


IF EXISTS (
    SELECT 1
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = 'Dim'
    AND TABLE_NAME = 'AssumptionDatasets'
    AND COLUMN_NAME='Version'
) 
BEGIN

ALTER TABLE Dim.AssumptionDatasets DROP COLUMN [Version]

END

IF EXISTS (select 1 from sys.tables t inner join sys.schemas s
on t.schema_id=s.schema_id where t.name='AssumptionDatasets' and s.name='Dim' and t.temporal_type=0)
BEGIN

ALTER TABLE [Dim].[AssumptionDatasets]
    SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = [Dim].[AssumptionDatasets_History]));
  
END
*/



/*Added Column renaming script for table Dim.AssumptionDatasets as we are experiencing Ambiguous column issue */
IF EXISTS
(
SELECT 1 FROM sys.tables	T
JOIN	sys.schemas		S
ON		T.schema_id		=		S.schema_id
WHERE	T.name='AssumptionDatasets' 
AND		S.name='Dim'
AND		T.temporal_type=2
)

BEGIN
 
ALTER TABLE [Dim].[AssumptionDatasets]

    SET (SYSTEM_VERSIONING = OFF);
 
IF EXISTS (

    SELECT 1

    FROM INFORMATION_SCHEMA.COLUMNS

    WHERE TABLE_SCHEMA = 'Dim'

    AND TABLE_NAME = 'AssumptionDatasets'

    AND COLUMN_NAME='Reporting Year'

)

BEGIN

-- Rename the column in the AssumptionDatasets table

EXEC sp_rename 'Dim.AssumptionDatasets.[Reporting Year]', 'Reporting_Year', 'COLUMN';
 
-- Rename the column in the AssumptionDatasets_History table

EXEC sp_rename 'Dim.AssumptionDatasets_History.[Reporting Year]', 'Reporting_Year', 'COLUMN';
 
END
 
IF EXISTS (

    SELECT 1

    FROM INFORMATION_SCHEMA.COLUMNS

    WHERE TABLE_SCHEMA = 'Dim'

    AND TABLE_NAME = 'AssumptionDatasets'

    AND COLUMN_NAME='Reporting Quarter'

) 

BEGIN
 
EXEC sp_rename 'Dim.AssumptionDatasets.[Reporting Quarter]', 'Reporting_Quarter', 'COLUMN';
 
EXEC sp_rename 'Dim.AssumptionDatasets_History.[Reporting Quarter]', 'Reporting_Quarter', 'COLUMN';
 
END
 
IF EXISTS (

    SELECT 1

    FROM INFORMATION_SCHEMA.COLUMNS

    WHERE TABLE_SCHEMA = 'Dim'

    AND TABLE_NAME = 'AssumptionDatasets'

    AND COLUMN_NAME='RI Flag'

) 

BEGIN
 
-- Rename columns in the AssumptionDatasets table
 
EXEC sp_rename 'Dim.AssumptionDatasets.[RI Flag]', 'RI_Flag', 'COLUMN';
 
-- Rename columns in the AssumptionDatasets_History table
 
EXEC sp_rename 'Dim.AssumptionDatasets_History.[RI Flag]', 'RI_Flag', 'COLUMN';
 
 
END
 
ALTER TABLE [Dim].[AssumptionDatasets]

    SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = [Dim].[AssumptionDatasets_History]));
 
END

--I17-7740 Dynamic Assumption Name Generation

IF NOT EXISTS (
    SELECT 1
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = 'Dim'
    AND TABLE_NAME = 'AssumptionDatasets'
    AND COLUMN_NAME IN ('Reporting_Year', 'Reporting_Quarter', 'RI_Flag', 'Version')
)
BEGIN

    ALTER TABLE [Dim].[AssumptionDatasets]
    SET (SYSTEM_VERSIONING = OFF);

    ALTER TABLE [Dim].[AssumptionDatasets]
    ADD
        [Reporting_Year] INT NULL,
        [Reporting_Quarter] NVARCHAR(10) NULL,
        [RI_Flag] NVARCHAR(10) NULL,
        [Version] INT NULL;

    ALTER TABLE [Dim].[AssumptionDatasets_History]
    ADD
        [Reporting_Year] INT NULL,
        [Reporting_Quarter] NVARCHAR(10) NULL,
        [RI_Flag] NVARCHAR(10) NULL,
        [Version] INT NULL;
    

    ALTER TABLE [Dim].[AssumptionDatasets]
    SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = [Dim].[AssumptionDatasets_History]));

END

IF EXISTS (SELECT 1 from INFORMATION_SCHEMA.COLUMNS where TABLE_SCHEMA='Dim' AND 
TABLE_NAME='AssumptionDatasets' AND COLUMN_NAME='AssumptionDatasetName'  AND DATA_TYPE='NVARCHAR' AND CHARACTER_MAXIMUM_LENGTH=35)
BEGIN 

IF EXISTS (select 1 from sys.tables t inner join sys.schemas s
on t.schema_id=s.schema_id where t.name='AssumptionDatasets' and s.name='Dim' and t.temporal_type=2)
BEGIN

ALTER TABLE [Dim].[AssumptionDatasets]
    SET (SYSTEM_VERSIONING = OFF);
	
END

ALTER TABLE [Dim].[AssumptionDatasets]
ALTER COLUMN AssumptionDatasetName NVARCHAR(50)

ALTER TABLE [Dim].[AssumptionDatasets_History]
ALTER COLUMN AssumptionDatasetName NVARCHAR(50)

ALTER TABLE [Dim].[AssumptionDatasets]
SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = [Dim].[AssumptionDatasets_History]));
 
END
