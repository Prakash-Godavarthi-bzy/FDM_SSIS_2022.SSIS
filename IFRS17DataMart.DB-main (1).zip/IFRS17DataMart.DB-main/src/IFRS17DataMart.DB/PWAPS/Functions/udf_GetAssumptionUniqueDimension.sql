﻿--declare @AssumpDatasetID Int = 3099
--,@AssumpPercName  Varchar(255) = 'IELR (Pure)';


CREATE FUNCTION [PWAPS].[udf_GetAssumptionUniqueDimension] (@AssumpDatasetID Int,@AssumpPercName  Varchar(255))

RETURNS TABLE
AS
RETURN


WITH DUPS AS
(
SELECT 		CASE 
			WHEN @AssumpPercName IN ('Mappings (Account Code)' )      
				 THEN CASE WHEN (([Account] IS NOT NULL OR [Account] <> '' ) AND ([Type] IS NOT NULL OR [Type] <> '') AND ([Source] IS NOT NULL OR [Source] <> '') AND ([FieldLabel] IS NOT NULL OR [FieldLabel] <> '')	)
						   THEN   CONCAT_WS('-', [Account],[Type],[Source],[FieldLabel])
					  END
			WHEN @AssumpPercName IN ('FX Rate (Spot)'    ,'FX Rate (Average)')    
				 THEN CASE WHEN ((Currency IS NOT NULL OR Currency <> '' ) AND	(ReportingCurrency IS NOT NULL OR 	ReportingCurrency <> ''))					
						   THEN CONCAT_WS('-', Currency,	ReportingCurrency)
					  END
			WHEN @AssumpPercName IN ('Discount Rate' )   
				 THEN CASE WHEN ((Currency IS NOT NULL OR Currency <> '') AND (DevelopmentQuarter IS NOT NULL  OR  DevelopmentQuarter <> '' ))
						   THEN CONCAT_WS('-', Currency,DevelopmentQuarter)
					  END
			WHEN @AssumpPercName IN ('Payment Pattern (Claims)'       ,'Payment Pattern (Premiums)' )    
				 THEN CASE WHEN ((Trifocus IS NOT NULL OR Trifocus <> '') AND	(DevelopmentQuarter IS NOT NULL OR DevelopmentQuarter <> '') AND	(RIFlag IS NOT NULL OR RIFlag <> ''))
							THEN CONCAT_WS('-', Trifocus,	DevelopmentQuarter,	RIFlag)
					  END
			WHEN @AssumpPercName IN ('ENIDs (Earned)', 'ENIDs (Unearned)', 'Profit Commissions', 'Reinstatement Premiums'  ,'Reinsurance Credit Loss', 'Rebates'       )     
				 THEN CASE WHEN ((YOA IS NOT NULL OR YOA <> '' )AND	(Trifocus IS NOT NULL  OR Trifocus  <> '')AND (RIFlag IS NOT NULL OR RIFlag  <> ''  )AND (RIProgramme IS NOT NULL OR RIProgramme  <> '' ))
							THEN CONCAT_WS('-', YOA,	Trifocus,RIFlag,RIProgramme)
					 END
			WHEN @AssumpPercName IN ('IELR (Pure)')
				 THEN CASE WHEN ((YOA IS NOT NULL OR YOA <> '' ) AND	(Trifocus IS NOT NULL OR Trifocus  <> '') AND (LossType IS NOT NULL OR LossType  <> '') AND (RIFlag IS NOT NULL OR RIFlag  <> '' )  AND (RIProgramme IS NOT NULL OR RIProgramme  <> '' ) AND (Entity IS NOT NULL OR Entity  <> '' ))
						   THEN CONCAT_WS('-', YOA,	Trifocus,	LossType,	RIFlag,	RIProgramme,Entity)
					  END
			WHEN @AssumpPercName IN ('Mappings (Trifocus)' )
				 THEN CASE WHEN ((Trifocus IS NOT NULL OR Trifocus  <> '') AND ( TriFocusName IS NOT NULL OR TriFocusName  <> ''  ) AND (FocusGroup IS NOT NULL OR FocusGroup  <> '') AND (Division IS NOT NULL OR Division  <> ''))
						   THEN CONCAT_WS('-', TriFocus,	TriFocusName,	FocusGroup,	Division)
					  END
			WHEN @AssumpPercName IN ('Adjustments' )
				 THEN CASE WHEN ( (AdjustmentID IS NOT NULL OR AdjustmentID <> '' )AND (Trifocus IS NOT NULL OR Trifocus <> '' ) AND (YOA IS NOT NULL OR YOA <> '' ) AND (Entity IS NOT NULL OR Entity <> '' ) AND (Account IS NOT NULL OR Account <> '' )
								  AND (RIFlag IS NOT NULL OR RIFlag <> '') AND	(RIProgramme IS NOT NULL OR RIProgramme <> ''  ) AND	(Currency IS NOT NULL OR Currency <> '' ) AND ([Source] IS NOT NULL OR [Source] <> '' ) 
								  AND	(EarnedPercentage IS NOT NULL OR EarnedPercentage  <> '') AND	(InceptionDate IS NOT NULL OR InceptionDate <> '') AND	(Narrative IS NOT NULL OR Narrative <> ''))
						   THEN CONCAT_WS('-', AdjustmentID,Trifocus,	YOA,	Entity,	Account, RIFlag,	RIProgramme,	Currency,	[Source],	EarnedPercentage,	InceptionDate,	Narrative)
					  END
			WHEN @AssumpPercName IN ('Earning Pattern (Nat Cat)'          )
				 THEN CASE WHEN ((Trifocus  IS NOT NULL OR Trifocus <> '') AND (YOA IS NOT NULL OR YOA <> '') AND (DevelopmentQuarter IS NOT NULL OR  DevelopmentQuarter <> '' ))
						   THEN CONCAT_WS('-', Trifocus,	YOA,	DevelopmentQuarter)
					  END
			WHEN @AssumpPercName IN ('Expenses (Admin Other)' ,  'Expenses (Claims Handling)','Expenses (Other Acquisition)'  ,'RI Admin')
				 THEN CASE WHEN FocusGroup IS NOT NULL OR FocusGroup <> ''
						   THEN FocusGroup
					  END
			WHEN @AssumpPercName IN ('LIC Risk Adjustment (Older Years)')
				 THEN CASE WHEN (( RIFlag  IS NOT NULL OR RIFlag  <> '')	AND (FocusGroup  IS NOT NULL OR FocusGroup <> ''))
						   THEN CONCAT_WS('-', RIFlag,	FocusGroup)
					  END
			WHEN @AssumpPercName IN ('Premium Lapse Risk')
				 THEN CASE WHEN ((Trifocus IS NOT NULL OR Trifocus <> '')	AND (YOA IS NOT NULL OR YOA <> ''))
						   THEN CONCAT_WS('-', Trifocus,	YOA)
					   END
			WHEN @AssumpPercName IN ('LIC Risk Adjustment','LRC Risk Adjustment')
				 THEN CASE WHEN ((YOA IS NOT NULL OR  YOA <> '') AND (RIFlag IS NOT NULL OR RIFlag  <> '')	AND	(FocusGroup IS NOT NULL OR FocusGroup <> '') ) 
						   THEN CONCAT_WS('-', YOA,	RIFlag,	FocusGroup)
					  END
			WHEN @AssumpPercName IN ('Ultimate Loss Ratios')
				 THEN CASE WHEN ((Trifocus  IS NOT NULL OR Trifocus <> '') AND	(YOA IS NOT NULL OR YOA <> '' )AND	(Entity IS NOT NULL OR Entity <> '' ) AND (RIFlag IS NOT NULL OR RIFlag <> '' ) 
				                 AND	(RIProgramme IS NOT NULL OR RIProgramme <> '') AND (LossType IS NOT NULL OR LossType <> '' ))
						   THEN CONCAT_WS('-', Trifocus,	YOA,	Entity,	RIFlag,	RIProgramme,LossType)
					  END

			END as DupData
  FROM [PWAPS].[stg_UploadAssumptionData]
  WHERE [AssumpDatasetId] = @AssumpDatasetID
  AND [AssumpPercName] = @AssumpPercName
  GROUP BY 
			CASE 
			WHEN @AssumpPercName IN ('Mappings (Account Code)' )      
				 THEN CASE WHEN (([Account] IS NOT NULL OR [Account] <> '' ) AND ([Type] IS NOT NULL OR [Type] <> '') AND ([Source] IS NOT NULL OR [Source] <> '') AND ([FieldLabel] IS NOT NULL OR [FieldLabel] <> '')	)
						   THEN   CONCAT_WS('-', [Account],[Type],[Source],[FieldLabel])
					  END
			WHEN @AssumpPercName IN ('FX Rate (Spot)'    ,'FX Rate (Average)')    
				 THEN CASE WHEN ((Currency IS NOT NULL OR Currency <> '' ) AND	(ReportingCurrency IS NOT NULL OR 	ReportingCurrency <> ''))					
						   THEN CONCAT_WS('-', Currency,	ReportingCurrency)
					  END
			WHEN @AssumpPercName IN ('Discount Rate' )   
				 THEN CASE WHEN ((Currency IS NOT NULL OR Currency <> '') AND (DevelopmentQuarter IS NOT NULL  OR  DevelopmentQuarter <> '' ))
						   THEN CONCAT_WS('-', Currency,DevelopmentQuarter)
					  END
			WHEN @AssumpPercName IN ('Payment Pattern (Claims)'       ,'Payment Pattern (Premiums)' )    
				 THEN CASE WHEN ((Trifocus IS NOT NULL OR Trifocus <> '') AND	(DevelopmentQuarter IS NOT NULL OR DevelopmentQuarter <> '') AND	(RIFlag IS NOT NULL OR RIFlag <> ''))
							THEN CONCAT_WS('-', Trifocus,	DevelopmentQuarter,	RIFlag)
					  END
			WHEN @AssumpPercName IN ('ENIDs (Earned)', 'ENIDs (Unearned)', 'Profit Commissions', 'Reinstatement Premiums'  ,'Reinsurance Credit Loss', 'Rebates'       )     
				 THEN CASE WHEN ((YOA IS NOT NULL OR YOA <> '' )AND	(Trifocus IS NOT NULL  OR Trifocus  <> '')AND (RIFlag IS NOT NULL OR RIFlag  <> ''  )AND (RIProgramme IS NOT NULL OR RIProgramme  <> '' ))
							THEN CONCAT_WS('-', YOA,	Trifocus,RIFlag,RIProgramme)
					 END
			WHEN @AssumpPercName IN ('IELR (Pure)')
				 THEN CASE WHEN ((YOA IS NOT NULL OR YOA <> '' ) AND	(Trifocus IS NOT NULL OR Trifocus  <> '') AND (LossType IS NOT NULL OR LossType  <> '') AND (RIFlag IS NOT NULL OR RIFlag  <> '' ) AND (RIProgramme IS NOT NULL OR RIProgramme  <> '' ) AND (Entity IS NOT NULL OR Entity  <> '' ))
						   THEN CONCAT_WS('-', YOA,	Trifocus,	LossType,	RIFlag,	RIProgramme,Entity)
					  END
			WHEN @AssumpPercName IN ('Mappings (Trifocus)' )
				 THEN CASE WHEN ((Trifocus IS NOT NULL OR Trifocus  <> '') AND ( TriFocusName IS NOT NULL OR TriFocusName  <> ''  ) AND (FocusGroup IS NOT NULL OR FocusGroup  <> '') AND (Division IS NOT NULL OR Division  <> ''))
						   THEN CONCAT_WS('-', TriFocus,	TriFocusName,	FocusGroup,	Division)
					  END
			WHEN @AssumpPercName IN ('Adjustments' )
				 THEN CASE WHEN ( (AdjustmentID IS NOT NULL OR AdjustmentID <> '' )AND (Trifocus IS NOT NULL OR Trifocus <> '' ) AND (YOA IS NOT NULL OR YOA <> '' ) AND (Entity IS NOT NULL OR Entity <> '' ) AND (Account IS NOT NULL OR Account <> '' )
								  AND (RIFlag IS NOT NULL OR RIFlag <> '') AND	(RIProgramme IS NOT NULL OR RIProgramme <> ''  ) AND	(Currency IS NOT NULL OR Currency <> '' ) AND ([Source] IS NOT NULL OR [Source] <> '' ) 
								  AND	(EarnedPercentage IS NOT NULL OR EarnedPercentage  <> '') AND	(InceptionDate IS NOT NULL OR InceptionDate <> '') AND	(Narrative IS NOT NULL OR Narrative <> ''))
						   THEN CONCAT_WS('-', AdjustmentID,Trifocus,	YOA,	Entity,	Account, RIFlag,	RIProgramme,	Currency,	[Source],	EarnedPercentage,	InceptionDate,	Narrative)
					  END
			WHEN @AssumpPercName IN ('Earning Pattern (Nat Cat)'          )
				 THEN CASE WHEN ((Trifocus  IS NOT NULL OR Trifocus <> '') AND (YOA IS NOT NULL OR YOA <> '') AND (DevelopmentQuarter IS NOT NULL OR  DevelopmentQuarter <> '' ))
						   THEN CONCAT_WS('-', Trifocus,	YOA,	DevelopmentQuarter)
					  END
			WHEN @AssumpPercName IN ('Expenses (Admin Other)' ,  'Expenses (Claims Handling)','Expenses (Other Acquisition)'  ,'RI Admin')
				 THEN CASE WHEN FocusGroup IS NOT NULL OR FocusGroup <> ''
						   THEN FocusGroup
					  END
			WHEN @AssumpPercName IN ('LIC Risk Adjustment (Older Years)')
				 THEN CASE WHEN (( RIFlag  IS NOT NULL OR RIFlag  <> '')	AND (FocusGroup  IS NOT NULL OR FocusGroup <> ''))
						   THEN CONCAT_WS('-', RIFlag,	FocusGroup)
					  END
			WHEN @AssumpPercName IN ('Premium Lapse Risk')
				 THEN CASE WHEN ((Trifocus IS NOT NULL OR Trifocus <> '')	AND (YOA IS NOT NULL OR YOA <> ''))
						   THEN CONCAT_WS('-', Trifocus,	YOA)
					   END
			WHEN @AssumpPercName IN ('LIC Risk Adjustment','LRC Risk Adjustment')
				 THEN CASE WHEN ((YOA IS NOT NULL OR  YOA <> '') AND (RIFlag IS NOT NULL OR RIFlag  <> '')	AND	(FocusGroup IS NOT NULL OR FocusGroup <> '') ) 
						   THEN CONCAT_WS('-', YOA,	RIFlag,	FocusGroup)
					  END
			WHEN @AssumpPercName IN ('Ultimate Loss Ratios')
				 THEN CASE WHEN ((Trifocus  IS NOT NULL OR Trifocus <> '') AND	(YOA IS NOT NULL OR YOA <> '' )AND	(Entity IS NOT NULL OR Entity <> '' ) AND (RIFlag IS NOT NULL OR RIFlag <> '' ) 
				                 AND	(RIProgramme IS NOT NULL OR RIProgramme <> '') AND (LossType IS NOT NULL OR LossType <> '' ))
						   THEN CONCAT_WS('-', Trifocus,	YOA,	Entity,	RIFlag,	RIProgramme,LossType)
					  END
			END
  HAVING COUNT(*) > 1
  )


  SELECT T1.RowID, 
			T2.DupData
  FROM [PWAPS].[stg_UploadAssumptionData] T1
  INNER JOIN DUPS T2 ON   
			CASE 
			WHEN @AssumpPercName IN ('Mappings (Account Code)' )      
				 THEN CASE WHEN (([Account] IS NOT NULL OR [Account] <> '' ) AND ([Type] IS NOT NULL OR [Type] <> '') AND ([Source] IS NOT NULL OR [Source] <> '') AND ([FieldLabel] IS NOT NULL OR [FieldLabel] <> '')	)
						   THEN   CONCAT_WS('-', [Account],[Type],[Source],[FieldLabel])
					  END
			WHEN @AssumpPercName IN ('FX Rate (Spot)'    ,'FX Rate (Average)')    
				 THEN CASE WHEN ((Currency IS NOT NULL OR Currency <> '' ) AND	(ReportingCurrency IS NOT NULL OR 	ReportingCurrency <> ''))					
						   THEN CONCAT_WS('-', Currency,	ReportingCurrency)
					  END
			WHEN @AssumpPercName IN ('Discount Rate' )   
				 THEN CASE WHEN ((Currency IS NOT NULL OR Currency <> '') AND (DevelopmentQuarter IS NOT NULL  OR  DevelopmentQuarter <> '' ))
						   THEN CONCAT_WS('-', Currency,DevelopmentQuarter)
					  END
			WHEN @AssumpPercName IN ('Payment Pattern (Claims)'       ,'Payment Pattern (Premiums)' )    
				 THEN CASE WHEN ((Trifocus IS NOT NULL OR Trifocus <> '') AND	(DevelopmentQuarter IS NOT NULL OR DevelopmentQuarter <> '') AND	(RIFlag IS NOT NULL OR RIFlag <> ''))
							THEN CONCAT_WS('-', Trifocus,	DevelopmentQuarter,	RIFlag)
					  END
			WHEN @AssumpPercName IN ('ENIDs (Earned)', 'ENIDs (Unearned)', 'Profit Commissions', 'Reinstatement Premiums'  ,'Reinsurance Credit Loss', 'Rebates'       )     
				 THEN CASE WHEN ((YOA IS NOT NULL OR YOA <> '' )AND	(Trifocus IS NOT NULL  OR Trifocus  <> '')AND (RIFlag IS NOT NULL OR RIFlag  <> ''  )AND (RIProgramme IS NOT NULL OR RIProgramme  <> '' ))
							THEN CONCAT_WS('-', YOA,	Trifocus,RIFlag,RIProgramme)
					 END
			WHEN @AssumpPercName IN ('IELR (Pure)')
				 THEN CASE WHEN ((YOA IS NOT NULL OR YOA <> '' ) AND	(Trifocus IS NOT NULL OR Trifocus  <> '') AND (LossType IS NOT NULL OR LossType  <> '') AND (RIFlag IS NOT NULL OR RIFlag  <> '' ) AND (RIProgramme IS NOT NULL OR RIProgramme  <> '' ) AND (Entity IS NOT NULL OR Entity  <> '' ))
						   THEN CONCAT_WS('-', YOA,	Trifocus,	LossType,	RIFlag,	RIProgramme,Entity)
					  END
			WHEN @AssumpPercName IN ('Mappings (Trifocus)' )
				 THEN CASE WHEN ((Trifocus IS NOT NULL OR Trifocus  <> '') AND ( TriFocusName IS NOT NULL OR TriFocusName  <> ''  ) AND (FocusGroup IS NOT NULL OR FocusGroup  <> '') AND (Division IS NOT NULL OR Division  <> ''))
						   THEN CONCAT_WS('-', TriFocus,	TriFocusName,	FocusGroup,	Division)
					  END
			WHEN @AssumpPercName IN ('Adjustments' )
				 THEN CASE WHEN ( (AdjustmentID IS NOT NULL OR AdjustmentID <> '' )AND (Trifocus IS NOT NULL OR Trifocus <> '' ) AND (YOA IS NOT NULL OR YOA <> '' ) AND (Entity IS NOT NULL OR Entity <> '' ) AND (Account IS NOT NULL OR Account <> '' )
								  AND (RIFlag IS NOT NULL OR RIFlag <> '') AND	(RIProgramme IS NOT NULL OR RIProgramme <> ''  ) AND	(Currency IS NOT NULL OR Currency <> '' ) AND ([Source] IS NOT NULL OR [Source] <> '' ) 
								  AND	(EarnedPercentage IS NOT NULL OR EarnedPercentage  <> '') AND	(InceptionDate IS NOT NULL OR InceptionDate <> '') AND	(Narrative IS NOT NULL OR Narrative <> ''))
						   THEN CONCAT_WS('-', AdjustmentID,Trifocus,	YOA,	Entity,	Account, RIFlag,	RIProgramme,	Currency,	[Source],	EarnedPercentage,	InceptionDate,	Narrative)
					  END
			WHEN @AssumpPercName IN ('Earning Pattern (Nat Cat)'          )
				 THEN CASE WHEN ((Trifocus  IS NOT NULL OR Trifocus <> '') AND (YOA IS NOT NULL OR YOA <> '') AND (DevelopmentQuarter IS NOT NULL OR  DevelopmentQuarter <> '' ))
						   THEN CONCAT_WS('-', Trifocus,	YOA,	DevelopmentQuarter)
					  END
			WHEN @AssumpPercName IN ('Expenses (Admin Other)' ,  'Expenses (Claims Handling)','Expenses (Other Acquisition)'  ,'RI Admin')
				 THEN CASE WHEN FocusGroup IS NOT NULL OR FocusGroup <> ''
						   THEN FocusGroup
					  END
			WHEN @AssumpPercName IN ('LIC Risk Adjustment (Older Years)')
				 THEN CASE WHEN (( RIFlag  IS NOT NULL OR RIFlag  <> '')	AND (FocusGroup  IS NOT NULL OR FocusGroup <> ''))
						   THEN CONCAT_WS('-', RIFlag,	FocusGroup)
					  END
			WHEN @AssumpPercName IN ('Premium Lapse Risk')
				 THEN CASE WHEN ((Trifocus IS NOT NULL OR Trifocus <> '')	AND (YOA IS NOT NULL OR YOA <> ''))
						   THEN CONCAT_WS('-', Trifocus,	YOA)
					   END
			WHEN @AssumpPercName IN ('LIC Risk Adjustment','LRC Risk Adjustment')
				 THEN CASE WHEN ((YOA IS NOT NULL OR  YOA <> '') AND (RIFlag IS NOT NULL OR RIFlag  <> '')	AND	(FocusGroup IS NOT NULL OR FocusGroup <> '') ) 
						   THEN CONCAT_WS('-', YOA,	RIFlag,	FocusGroup)
					  END
			WHEN @AssumpPercName IN ('Ultimate Loss Ratios')
				 THEN CASE WHEN ((Trifocus  IS NOT NULL OR Trifocus <> '') AND	(YOA IS NOT NULL OR YOA <> '' )AND	(Entity IS NOT NULL OR Entity <> '' ) AND (RIFlag IS NOT NULL OR RIFlag <> '' ) 
				                 AND	(RIProgramme IS NOT NULL OR RIProgramme <> '') AND (LossType IS NOT NULL OR LossType <> '' ))
						   THEN CONCAT_WS('-', Trifocus,	YOA,	Entity,	RIFlag,	RIProgramme,LossType)
					  END

			END = T2.DupData
  WHERE [AssumpDatasetId] = @AssumpDatasetID
  AND [AssumpPercName] = @AssumpPercName