﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [PWAPS].[CheckAssumptionUploadStatus] 
(
	-- Add the parameters for the function here 
	--DECLARE
	@AssumptionID int 
	, @AssumptionType varchar(35) 
)
RETURNS VARCHAR(10)
AS
BEGIN
	-- Declare the return variable here
	Declare @Result varchar(10)
	-- Add the T-SQL statements to compute the return value here
	IF EXISTS (SELECT DISTINCT 1 FROM PWAPS.stg_UploadedAssumptionErrors WHERE AssumpDatasetId = @AssumptionID AND AssumpPercName = @AssumptionType)
		SET @Result = 'FAILURE'

	ELSE
		BEGIN
			IF EXISTS (SELECT DISTINCT 1  
						FROM fct.AssumptionData   T1
						INNER JOIN Dim.AssumptionPercentageType T2 ON T1.Pk_AssumptionPercentageTypeId = T2.Pk_AssumptionPercentageTypeId
						WHERE T1.Pk_AssumptionDatasetNameId = @AssumptionID AND T2.AssumptionPercentageType = @AssumptionType)
					
					SET @Result = 'SUCCESS'
					
			ELSE
				IF EXISTS (SELECT DISTINCT 1 
						   FROM Dim.TrifocusMapping T1
						   WHERE IsActive = 1 
						   AND T1.AssumptionDatasetNameID = @AssumptionID)

							SET @Result = 'SUCCESS'
							

				 ELSE 		
						IF EXISTS (SELECT DISTINCT 1 
									FROM Dim.AccountCodeMapping T1
									WHERE IsActive = 1 
									AND T1.AssumptionDatasetNameID = @AssumptionID )

									SET @Result = 'SUCCESS'
																		

						ELSE
								SET @Result = 'FAILURE'
		END

	-- Return the result of the function
	RETURN 	 @Result 

END