﻿CREATE TABLE [PWAPS].[ExportLogs]
(
	[Pk_RequestID] [int] IDENTITY(1,1) NOT NULL,
	[Pk_AssumptionDataSetNameId] [int] NULL,
	[AssumptionPrecentType] [varchar](50) NULL,
	[RunFlag] [bit] NULL,
	[UserName] [varchar](20) NOT NULL,
	[Email] [varchar](255) NOT NULL,
	[AssumptionName] [varchar](100) NULL,
	[UpdateFlag] [int] NULL,
	[AuditDateTime] [datetime2](7) NULL,
	[FileName] [varchar](300) NULL,
PRIMARY KEY CLUSTERED 
(
	[Pk_RequestID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [PWAPS].[ExportLogs] ADD  DEFAULT (getdate()) FOR [AuditDateTime]
GO