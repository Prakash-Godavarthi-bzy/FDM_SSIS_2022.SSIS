﻿CREATE TABLE [PWAPS].[stg_UploadAssumptionData] (
    [RowID]              INT           NULL,
    [AssumpDatasetId]    INT           NULL,
    [AssumpPercName]     VARCHAR (255) NULL,
    [Entity]             VARCHAR (MAX) NULL,
    [Trifocus]           VARCHAR (MAX) NULL,
    [TriFocusName]       VARCHAR (MAX) NULL,
    [FocusGroup]         VARCHAR (MAX) NULL,
    [Division]           VARCHAR (MAX) NULL,
    [Account]            VARCHAR (MAX) NULL,
    [Type]               VARCHAR (MAX) NULL,
    [FieldLabel]         VARCHAR (MAX) NULL,
    [YOA]                VARCHAR (MAX) NULL,
    [Currency]           VARCHAR (MAX) NULL,
    [ReportingCurrency]  VARCHAR (MAX) NULL,
    [RIFlag]             VARCHAR (MAX) NULL,
    [RIProgramme]        VARCHAR (MAX) NULL,
    [LossType]           VARCHAR (MAX) NULL,
    [AdjustmentID]       VARCHAR (MAX) NULL,
    [Source]             VARCHAR (MAX) NULL,
    [EarnedPercentage]   VARCHAR (MAX) NULL,
    [InceptionDate]      VARCHAR (MAX) NULL,
    [Narrative]          VARCHAR (MAX) NULL,
    [DevelopmentQuarter] VARCHAR (MAX) NULL,
    [Value]              VARCHAR (MAX) NULL,
    [HasError]           BIT           NULL,
    [ProcessFlow]        VARCHAR (10)  NULL,
    [CMEarn]             VARCHAR (3)   NULL
);







