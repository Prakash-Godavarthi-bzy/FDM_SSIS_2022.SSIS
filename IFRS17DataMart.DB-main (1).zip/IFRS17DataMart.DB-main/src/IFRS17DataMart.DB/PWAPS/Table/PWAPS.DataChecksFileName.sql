Create Table PWAPS.DataChecksFileName
(
ID int primary key identity(1,1),
PK_RequestID int,
DataChecks_FileName Varchar(500)
)


