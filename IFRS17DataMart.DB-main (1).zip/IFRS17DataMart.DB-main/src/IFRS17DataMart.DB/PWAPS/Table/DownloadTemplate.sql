﻿CREATE TABLE [PWAPS].[DownloadTemplate]
(
	[Pk_RequestID] [int] IDENTITY(1,1) NOT NULL,
	[AssumptionPrecentType] [varchar](50) NULL,
	[UserName] [varchar](20) NOT NULL,
	[RunFlag] [bit] NULL,
	[Email] [varchar](255) NOT NULL,
	[AssumptionDatasetID] [varchar](100) NULL,
	[UpdateFlag] [int] NULL,
	[LossType] [nvarchar](510) NULL,
	[FileName] [varchar](300) NULL,
	[SourceFilename] [varchar] (300) null,
	[WorksheetName] [varchar](100) NULL,
	[AuditDateTime] [datetime2](7) NULL,
	[IsSystemGenerated] [int] NULL,
	[ULRFXRateSpot] [varchar](35) NULL,
	[ULRAsAt] [int] NULL,
	[ULRType] [varchar](4) NULL,
PRIMARY KEY CLUSTERED 
(
	[Pk_RequestID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [PWAPS].[DownloadTemplate] ADD  DEFAULT ((0)) FOR [RunFlag]
GO

ALTER TABLE [PWAPS].[DownloadTemplate] ADD  DEFAULT ((0)) FOR [UpdateFlag]
GO

ALTER TABLE [PWAPS].[DownloadTemplate] ADD  DEFAULT (getdate()) FOR [AuditDateTime]
GO

ALTER TABLE [PWAPS].[DownloadTemplate] ADD  DEFAULT ((0)) FOR [IsSystemGenerated]
GO
