﻿CREATE TABLE [PWAPS].[Log_AssumptionUploadFailures] (
    [ErrorID]        INT           IDENTITY (1, 1) NOT NULL,
    [AssumptionID]   INT           NULL,
    [AssumptionType] VARCHAR (255) NULL,
    [ErrorSource]    VARCHAR (255) NULL,
    [ErrorLine]      INT           NULL,
    [ErrorMSg]       VARCHAR (MAX) NULL,
    [ErrorDateTime]  DATETIME      NULL
);

