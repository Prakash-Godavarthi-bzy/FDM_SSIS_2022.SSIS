﻿CREATE TABLE [PWAPS].[stg_UploadedAssumptionErrors] (
    [RowID]           INT           NULL,
    [AssumpDatasetId] INT           NULL,
    [AssumpPercName]  VARCHAR (255) NULL,
    [ColumnData]      VARCHAR (MAX) NULL,
    [ErrorMsg]        VARCHAR (MAX) NULL,
    [HasError]        BIT           NULL,
	FlowName          VARCHAR (255) NULL
);

