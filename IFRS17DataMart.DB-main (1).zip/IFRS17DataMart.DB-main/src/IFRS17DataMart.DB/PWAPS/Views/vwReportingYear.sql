﻿CREATE VIEW [PWAPS].[vwReportingYear]
	AS 
select distinct [Year] PK_Year,[Year]  
from Dim.Date 
where [Year] between Year(Getdate())-5 and Year(Getdate())+8
