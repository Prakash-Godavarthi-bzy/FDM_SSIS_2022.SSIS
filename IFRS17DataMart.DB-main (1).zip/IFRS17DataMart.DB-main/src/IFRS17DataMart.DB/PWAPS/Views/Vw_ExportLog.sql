﻿CREATE VIEW [PWAPS].[Vw_ExportLog]
	AS 
SELECT 
	e.Pk_RequestID,
	e.Pk_AssumptionDataSetNameId,
	d.AssumptionDatasetName,
	p.AssumptionPercentageType,
	e.[FileName],
	e.UserName,
	e.Email,
	e.UpdateFlag,
	d.AssumptionPercentageTypeId,
    d.CreatedDt, 
    d.CreatedBy,
    d.UpdatedDt,
    d.UpdatedBy
from [PWAPS].[ExportLogs] e
inner join Dim.AssumptionDatasets d on e.AssumptionName=d.AssumptionDatasetName
inner join Dim.AssumptionPercentageType P on e.AssumptionPrecentType=p.Pk_AssumptionPercentageTypeId
GO
