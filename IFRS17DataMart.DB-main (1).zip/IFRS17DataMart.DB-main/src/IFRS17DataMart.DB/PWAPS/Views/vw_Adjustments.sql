﻿CREATE  view [PWAPS].[vw_Adjustments]
as
select f.[WB_TYPE]
      ,f.[Pk_AssumptionDatasetNameId]
      ,f.[Pk_AssumptionPercentageTypeId]
      ,f.[PK_LossType]
      ,f.[YOA]
      ,f.[TriFocus]
      ,f.[CCY]
      ,f.[FX_ReportingCurrencyCode_4]
      ,f.[DR_DevelopmentYear]
      ,f.[PP_DevelopmentQuarter]
      ,f.[Value]
      ,f.[Entity]
      ,f.[Gross/RI Flag]
      ,f.[Account]
      ,f.[Source]
      ,f.[EarnedPercentage]
      ,f.[InceptionDate]
      ,f.[Narrative]
      ,f.[AdjustmentID]
      ,f.[Programme]
      ,f.[Focus Group]
FROM	fct.AssumptionData F
INNER	JOIN Dim.AssumptionDatasets ASD
ON		F.Pk_AssumptionDatasetNameId = ASD.Pk_AssumptionDatasetNameId
INNER	JOIN Dim.AssumptionPercentageType AST
ON		F.Pk_AssumptionPercentageTypeId =AST.Pk_AssumptionPercentageTypeId
WHERE	AST.AssumptionPercentageType = 'Adjustments'