﻿
CREATE view [PWAPS].[vw_dv_ValidationResults_Outputs]
as
SELECT [FK_RunId]
	  ,Rs.[Rule]
	  ,RT.ValidationRuleType
      ,ISNULL([Value],0) As Value
      ,IsNULL([Value2],0) As Value2
      ,ISNULL([FK_AccountCode],'N/A') As FK_AccountCode
	  ,ISNULL(DA.AccountName,'N/A') As AccountName
      ,ISNULL(Cast([FK_CCY] as varchar(10)),'N/A') As CCY
      ,ISNULL([FK_DevelopmentQuarter],0) As FK_DevelopmentQuarter
      ,ISNULL([FK_DevelopmentYear] ,0) AS FK_DevelopmentYear
      ,ISNULL([FK_Division],'N/A') As FK_Division
      ,COALESCE(CONVERT(VARCHAR(255), FK_EarningPeriod), 'N/A') AS FK_EarningPeriod
      ,ISNULL([FK_Entity],'N/A') AS FK_Entity
      ,ISNULL([FK_EventDate],'N/A') As FK_EventDate
      ,ISNULL([FK_FocusGroup],'N/A') As FK_FocusGroup
      ,ISNULL(Cast([FK_IFRS17TriFocusCode] as varchar(25)) ,'N/A') As FK_IFRS17TriFocusCode
      ,ISNULL([FK_LossType],'N/A') AS FK_LossType
      ,ISNULL([FK_OpenCloseYOA],'N/A') AS FK_OpenCloseYOA
      ,ISNULL([FK_PremiumType],'N/A') As FK_PremiumType
      ,ISNULL([FK_Programme],'N/A') As FK_Programme
	  ,COALESCE(CONVERT(VARCHAR(255), FK_Quarter), 'N/A') As FK_Quarter
      ,ISNULL([FK_RecognitionType],'N/A') AS FK_RecognitionType
      ,ISNULL([FK_ReportingCCY],'N/A') As FK_ReportingCCY
      ,ISNULL([FK_RIFlag],'NA') AS FK_RIFlag
      ,ISNULL([FK_Trifocus],'N/A') As FK_Trifocus
      ,ISNULL([FK_UltimatesSource],'N') As FK_UltimatesSource
	  ,COALESCE(CONVERT(VARCHAR(25),FK_YOA),'N/A') As FK_YOA
      --,ISNULL([FK_YOA],'N/A') As FK_YOA
     ,COALESCE(CONVERT(VARCHAR(25),FK_YOI),'N/A') As YOI
	 ,COALESCE(CONVERT(VARCHAR(25),QOI),'N/A') As QOI
	 -- ,ISNULL(QOI,'N/A') As QOI
	  ,ISNULL(FK_source,'N/A') As Source
  FROM [Dv].[ValidationResults] VR left join  Dv.ValidationRuleHeader Rs
  On VR.FK_ValidationRuleID=Rs.PK_ValidationRuleID
	left join Dv.ValidationRuleType RT On Rs.FK_ValidationRuleTypeID=RT.PK_ValidationRuleTypeID
     left Join [rpt].[vw_bm_dimAccount] DA On VR.FK_AccountCode=DA.PK_AccountCode
	 left  join Dim.AssumptionDatasets DS On VR.FK_AssumptionDataSetNameID=DS.Pk_AssumptionDatasetNameId
	 left join  [rpt].[vw_bm_dimInceptionPeriod] IR On IR.QOI=VR.FK_YOI