﻿CREATE VIEW  PWAPS.vw_FailureAssumptions 
AS
SELECT  T.Pk_RequestID
       ,[RowID]
      ,[AssumpDatasetId]
      ,[AssumpPercName]
      ,[ColumnData]
      ,[ErrorMsg]
      ,[HasError], 
	  T.AssumptionDatasetName
	 
FROM [PWAPS].VW_DownloadTemplate T
INNER JOIN [PWAPS].[stg_UploadedAssumptionErrors] T1 ON T.Pk_AssumptionDatasetNameId=T1.AssumpDatasetId
