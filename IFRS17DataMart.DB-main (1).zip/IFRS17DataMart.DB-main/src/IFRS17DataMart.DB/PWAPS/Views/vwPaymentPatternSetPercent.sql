
CREATE VIEW [PWAPS].[vwPaymentPatternSetPercent]
	AS 
SELECT *
FROM 
	(
	SELECT 
	AD.AssumptionDatasetName
	,AD.AssumptionDatasetDescription
	,AD.IsDatasetAlreadyUsed
	,APT.AssumptionPercentageType
	--,APST.LossTypeDescription as SubType
	,ASP.TriFocus AS PK_TriFocus_1
	,ASP.PP_DevelopmentQuarter AS PK_DevelopmentQuarter_5
	,ASP.[Gross/RI Flag]
	,cast(ASP.DevelopmentPercentage_0 as decimal(38,10)) as DevelopmentPercentage_0
	,ad.Pk_AssumptionDatasetNameId
	,APT.Pk_AssumptionPercentageTypeId
	,apt.AssumptionPercentageType as SubType
	 FROM
	(
		 SELECT Pk_AssumptionDatasetNameId, Pk_AssumptionPercentageTypeId, PK_LossType, TriFocus, PP_DevelopmentQuarter, [Gross/RI Flag], [Value] as DevelopmentPercentage_0 FROM fct.AssumptionData WHERE WB_TYPE = 'PP'  
		 UNION 
		(SELECT DS.Pk_AssumptionDatasetNameId  as Pk_AssumptionDatasetNameId
				,DS.AssumptionPercentageTypeId
				,CASE LEFT(FK_PatternName, 1) WHEN 'C' THEN 'PPC' ELSE 'PPP' END AS PK_LossType
				,fp.FK_Trifocus
				,fp.DevelopmentQuarter
				,'' AS [Gross/RIFlag]
				,fp.DevelopmentPercentageCumulative as DevelopmentPercentage_0
		FROM fct.Pattern fp

		INNER JOIN Dim.AssumptionDatasets DS  ON fp.TDH_DatasetName = DS.AssumptionDatasetName)
	 ) ASP 
	Inner Join Dim.AssumptionDatasets  AD  ON ASP.Pk_AssumptionDatasetNameId =AD.Pk_AssumptionDatasetNameId
	Inner Join Dim.AssumptionPercentageType  APT   ON ASP.Pk_AssumptionPercentageTypeId = APT.Pk_AssumptionPercentageTypeId 
	--Inner Join dim.AssumptionPercentageSubType  APST ON ASP.PK_LossType_4 =APST.LossType
	--where	ad.Pk_AssumptionDatasetNameId = 989
) AS A
PIVOT
(
SUM(DevelopmentPercentage_0) FOR  SubType in ([Payment Pattern (Claims)],[Payment Pattern (Premiums)])) as B
