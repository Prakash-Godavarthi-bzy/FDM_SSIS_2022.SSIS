﻿ CREATE View [PWAPS].[vw_dv_updateRuleset]
 AS
 Select RSM.FK_RuleSetID,
RSM.FK_ValidationRuleID,
RSM.Pk_RuleMap,
VR.PK_ValidationRuleID,
VR.FK_ValidationRuleTypeID,
VR.[Rule],
Case when Cast(VR.[Hidden] as nvarchar)=0 then 'No'
when Cast(VR.[Hidden] as nvarchar)=1 then 'Yes'
Else Cast(VR.[Hidden] as nvarchar)
End HiddenRule ,
VR.UpdateDateTime,
VR.UpdatedBy,
VRT.ValidationRuleType,
RD.AccountName,
RD.CompareAccountname,
RD.DimensionName,
RD.Factor,
RD.[Value],
RD.value2,
RD.[No.Of models],
RD.[No.Of rules],
RD.Operator
From
Dv.RuleSetRuleMapping RSM
Inner join Dv.[ValidationRuleHeader] VR on RSM.FK_ValidationRuleID=VR.PK_ValidationRuleID
Inner join Dv.ValidationRuleType VRT on VR.FK_ValidationRuleTypeID=VRT.PK_ValidationRuleTypeID
Left join [PWAPS].[vw_dv_ruleDetail] RD On RSM.FK_ValidationRuleID=RD.PK_ValidationRuleID