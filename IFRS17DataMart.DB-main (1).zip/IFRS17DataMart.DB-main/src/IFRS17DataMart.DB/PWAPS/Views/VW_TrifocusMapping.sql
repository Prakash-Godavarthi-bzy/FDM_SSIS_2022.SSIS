﻿
CREATE View [PWAPS].[VW_TrifocusMapping]
As
Select 
		  A.AssumptionDatasetName,
		M.TriFocusCode,
		M.TriFocusName,
		M.[Focus Group],
		M.Division,
		M.[CM Earn],
		M.CreatedDt
From Dim.AssumptionDatasets A inner join Dim.AssumptionPercentageType P
On A.AssumptionPercentageTypeId=P.Pk_AssumptionPercentageTypeId
inner join Dim.TrifocusMapping M on A.Pk_AssumptionDatasetNameId=M.AssumptionDatasetNameID
Where P.AssumptionPercentageType='Mappings (Trifocus)'
Order by  A.CreatedDt desc
OFFSet 0 Rows