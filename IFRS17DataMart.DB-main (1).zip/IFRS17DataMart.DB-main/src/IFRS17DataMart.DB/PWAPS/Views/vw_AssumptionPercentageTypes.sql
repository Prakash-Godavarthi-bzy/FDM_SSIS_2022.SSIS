
/*====================================================================================
Author			:	Manohar Bardha
Create date		:	1 June 2021
Description		:	This used for populating calc UI Applications dropdowns

Change Author	:	Hemomsu Lakkaraju
Chnage Date		:	19 June 2024
Description		:	Archiving data greater than 3 Years
Ticket No		:	https://beazley.atlassian.net/browse/I17-7538

=====================================================================================*/

CREATE VIEW [PWAPS].[vw_AssumptionPercentageTypes]
	AS 
SELECT
	Ap.AssumptionPercentageType
,	AD.AssumptionDatasetName
,	Ap.Pk_AssumptionPercentageTypeId
,	Ad.CreatedDt
,	iif(Ap.AssumptionPercentageType =	'ENIDs (Earned)',AD.AssumptionDatasetName,'0') AS [ENIDs] 
,	iif(Ap.AssumptionPercentageType	=	'IELR (Pure)',AD.AssumptionDatasetName,'0') AS [IELR Pure]
--,	iif(Ap.AssumptionPercentageType	=	'IELR (Team)',AD.AssumptionDatasetName,'0') AS [IELR Team]
,	iif(Ap.AssumptionPercentageType	=	'Admin Exp (CR)',AD.AssumptionDatasetName,'0') AS [Admin Exp Claims Related]
,	iif(Ap.AssumptionPercentageType	=	'Expenses (Admin Other)',AD.AssumptionDatasetName,'0') AS [Admin Exp Other]
,	iif(Ap.AssumptionPercentageType	=	'Admin Exp (PR)',AD.AssumptionDatasetName,'0') AS [Admin Exp Premium Related]
,	iif(Ap.AssumptionPercentageType	=	'Expenses (Claims Handling)',AD.AssumptionDatasetName,'0') AS [Claims Handling Exp]
,	iif(Ap.AssumptionPercentageType	=	'Expenses (Other Acquisition)',AD.AssumptionDatasetName,'0') AS [Other Acq]
,	iif(Ap.AssumptionPercentageType	=	'Profit Commissions',AD.AssumptionDatasetName,'0') AS [Profit Commission]
,	iif(Ap.AssumptionPercentageType	=	'Reinstatement Premiums',AD.AssumptionDatasetName,'0') AS [Reinstatement Premium Percent]
,	iif(Ap.AssumptionPercentageType	=	'Ultimate Loss Ratios',AD.AssumptionDatasetName,'0') AS [ADM]
,	iif(Ap.AssumptionPercentageType	=	'Discount Rate',AD.AssumptionDatasetName,'0') AS [Discount Rates]
,	iif(Ap.AssumptionPercentageType	=	'FX Rate (Average)',AD.AssumptionDatasetName,'0') AS [Fx Rates Avg]
,	iif(Ap.AssumptionPercentageType	=	'FX Rate (Spot)',AD.AssumptionDatasetName,'0') AS [Fx Rate spot]
,	iif(Ap.AssumptionPercentageType	=	'Payment Pattern (Premiums)',AD.AssumptionDatasetName,'0') AS [Payment Pattern]
,	iif(Ap.AssumptionPercentageType	=	'Payment Pattern (Claims)',AD.AssumptionDatasetName,'0') AS [Payment Pattern Claims]
,	iif(Ap.AssumptionPercentageType	=	'ENIDS (Unearned)',AD.AssumptionDatasetName,'0') AS [ENIDs Unearned]
,	iif(Ap.AssumptionPercentageType	=	'Adjustments',AD.AssumptionDatasetName,'0') AS [Adjustments]
,	iif(Ap.AssumptionPercentageType	=	'Rebates',AD.AssumptionDatasetName,'0') AS [Rebates]
,	iif(Ap.AssumptionPercentageType	=	'Reinsurance Credit Loss',AD.AssumptionDatasetName,'0') AS  [RICL]
,	iif(Ap.AssumptionPercentageType	=	'Earning Pattern (Nat Cat)',AD.AssumptionDatasetName,'0') AS  [Earning Pattern (Nat Cat)]
,   iif(Ap.AssumptionPercentageType	=	'RI Admin',AD.AssumptionDatasetName,'0') AS  [RI Admin]
,   iif(Ap.AssumptionPercentageType	=	'Premium Lapse Risk',AD.AssumptionDatasetName,'0') AS  [Premium Lapse Risk]
,   iif(Ap.AssumptionPercentageType	=	'LRC Risk Adjustment',AD.AssumptionDatasetName,'0') AS  [LRC Risk Adjustment]
,   iif(Ap.AssumptionPercentageType	=	'LIC Risk Adjustment',AD.AssumptionDatasetName,'0') AS  [LIC Risk Adjustment]
,   iif(Ap.AssumptionPercentageType	=	'LIC Risk Adjustment (Older Years)',AD.AssumptionDatasetName,'0') AS  [LIC Risk Adjustment (Older Years)]
,   iif(Ap.AssumptionPercentageType	=	'Mappings (Trifocus)',AD.AssumptionDatasetName,'0') AS  [TriFocusMapping]


FROM (
SELECT	A.*
FROM	DIM.AssumptionDatasets A 
JOIN	DIM.AssumptionPercentageType PT 
ON A.AssumptionPercentageTypeId = PT.Pk_AssumptionPercentageTypeId 
WHERE	PT.AssumptionPercentageType IN ('Payment Pattern (Claims)','Payment Pattern (Premiums)')
AND		(	CHARINDEX(RIGHT(YEAR(GETDATE()),2),A.AssumptionDatasetName,1) <> 0 		OR
			CHARINDEX(RIGHT(YEAR(GETDATE())-1,2),A.AssumptionDatasetName,1) <> 0 	OR
			CHARINDEX(RIGHT(YEAR(GETDATE())-2,2),A.AssumptionDatasetName,1) <> 0
		)
UNION
SELECT	A.*
FROM	DIM.AssumptionDatasets A 
JOIN	DIM.AssumptionPercentageType PT 
ON A.AssumptionPercentageTypeId = PT.Pk_AssumptionPercentageTypeId 
WHERE	PT.AssumptionPercentageType NOT IN ('Payment Pattern (Claims)','Payment Pattern (Premiums)')
AND		(	CHARINDEX(CONVERT(CHAR(4),YEAR(GETDATE())),A.AssumptionDatasetName,1) <> 0 		OR
			CHARINDEX(CONVERT(CHAR(4),YEAR(GETDATE()) - 1),A.AssumptionDatasetName,1) <> 0 	OR
			CHARINDEX(CONVERT(CHAR(4),YEAR(GETDATE()) - 2),A.AssumptionDatasetName,1) <> 0
		)
) AD 
INNER JOIN 
(  SELECT DISTINCT a.AssumptionDatasetNameId
   FROM
    (
       SELECT DISTINCT Pk_AssumptionDatasetNameId AS AssumptionDatasetNameId FROM fct.AssumptionData
       UNION ALL
       (SELECT DISTINCT AssumptionDatasetNameId
	    FROM Dim.AssumptionDatasets DS
		INNER JOIN fct.FxRate DF  ON DF.AssumptionDatasetNameId =DS.Pk_AssumptionDatasetNameId)
	   UNION ALL
		(SELECT distinct  DS.Pk_AssumptionDatasetNameId 
		FROM Dim.AssumptionDatasets DS
		INNER JOIN fct.DiscountRate DR  ON DR.AssumptionDatasetName =DS.AssumptionDatasetName)
	   UNION ALL
		(SELECT distinct  DS.Pk_AssumptionDatasetNameId 
		FROM Dim.AssumptionDatasets DS
		INNER JOIN fct.Pattern FP ON FP.TDH_DatasetName =  DS.AssumptionDatasetName)
	   UNION ALL
	   (
	   SELECT distinct  DS.Pk_AssumptionDatasetNameId 
		FROM Dim.AssumptionDatasets DS
		INNER JOIN Dim.TrifocusMapping DT ON Dt.AssumptionDatasetNameID =  DS.Pk_AssumptionDatasetNameId
	   )
    )A
) AWC ON AWC.AssumptionDatasetNameId = AD.Pk_AssumptionDatasetNameId 
INNER JOIN Dim.AssumptionPercentageType AP on AD.AssumptionPercentageTypeId=AP.Pk_AssumptionPercentageTypeId
GROUP BY Ap.Pk_AssumptionPercentageTypeId,AP.AssumptionPercentageType,AD.AssumptionDatasetName,AD.CreatedDt
GO
