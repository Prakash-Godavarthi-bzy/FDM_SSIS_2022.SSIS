/*====================================================================================
Author			:	Pooja Khandual
Create date		:	1 June 2021
Description		:	This allows users to view data related to imported assumptions

Change Author	:	Hemomsu Lakkaraju
Chnage Date		:	19 June 2024
Description		:	Archiving data greater than 3 Years
Ticket No		:	https://beazley.atlassian.net/browse/I17-7538

=====================================================================================*/

CREATE VIEW [PWAPS].[VW_AssumptionDataSet]
	AS 
Select [Pk_AssumptionDatasetNameId]
, [AssumptionDatasetName]
, [AssumptionDatasetDescription]
, [AssumptionPercentageTypeId]
, [CreatedDt]
, [CreatedBy]
, [UpdatedDt]
, [UpdatedBy]
, [ValidFrom]
, [ValidTo]
, IsDatasetAlreadyUsed
, Convert(varchar(10),CreatedDt,103) as CreatedDtText
From Dim.AssumptionDatasets ad
WHERE	(	CHARINDEX(CONVERT(CHAR(4),YEAR(GETDATE())),AD.AssumptionDatasetName,1) <> 0 		OR
			CHARINDEX(CONVERT(CHAR(4),YEAR(GETDATE()) - 1),AD.AssumptionDatasetName,1) <> 0 	OR
			CHARINDEX(CONVERT(CHAR(4),YEAR(GETDATE()) - 2),AD.AssumptionDatasetName,1) <> 0
		)
GO
