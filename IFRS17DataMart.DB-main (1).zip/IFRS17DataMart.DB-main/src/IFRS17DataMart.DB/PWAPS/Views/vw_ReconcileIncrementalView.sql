﻿
CREATE VIEW  PWAPS.vw_ReconcileIncrementalView AS
	SELECT SourceType, A.AccountingPeriod, A.Entity, CONVERT(NUMERIC(38,2), A.Amount) AS Amount
	FROM
	(
		(Select 'Premium' as SourceType,FK_AccountingPeriod As AccountingPeriod,FK_Entity As Entity,Sum(Value) As Amount
		from Fct.PreProcessPremiumLTD 
		Group by FK_Entity,FK_AccountingPeriod )
		Union
		(Select 'NonPremium'as SourceType,AccountingPeriod,Entity,Sum(Value) As Amount
		from Fct.Aggr_NonPremiumLTD 
		Group by Entity,AccountingPeriod)
	) A