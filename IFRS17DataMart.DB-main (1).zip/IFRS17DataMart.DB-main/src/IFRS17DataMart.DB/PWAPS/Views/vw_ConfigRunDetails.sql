﻿--USE [IFRS17DataMart]
--GO

--/****** Object:  View [PWAPS].[vw_ConfigRunDetails]    Script Date: 01/02/2024 19:09:59 ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO


CREATE VIEW [PWAPS].[vw_ConfigRunDetails]
AS

SELECT RunID,[Configuration],[Value] 
FROM
(
SELECT
       CAST(Pk_RequestId	AS VARCHAR(255))			AS RunID    
      ,CAST([Reporting Period]	AS VARCHAR(255))	AS Reporting_Period
      ,CAST([Pattern Scenario]	AS VARCHAR(255))	AS PatternScenario
      ,CAST([Run Type]			AS VARCHAR(255))	AS RunType
      ,CAST([Input Config]		   AS VARCHAR(255))	AS InputConfig
      ,CAST([Opening Balances Id]	AS VARCHAR(255)) AS OpeningBalancesId
      ,CAST([OB Reporting Period]	AS VARCHAR(255)) AS OBReportingPeriod
      ,CAST([User Name]				AS VARCHAR(255)) AS UserName
      ,CAST([Run Description]		AS VARCHAR(255)) AS RunDescription
      ,CAST([Reporting Year] AS VARCHAR(255))			AS ReportingYear
      ,CAST([Use Type] AS VARCHAR(255))	 AS UseType
      ,CAST([IR Scenario 01] AS VARCHAR(255))		 AS IRScenario01
      ,CAST([IR Reporting Period 01] AS VARCHAR(255))		 AS IRReportingPeriod01
      ,CAST([IR Scenario 02] AS VARCHAR(255))		 AS IRScenario02
      ,CAST([IR Reporting Period 02] AS VARCHAR(255))		 AS IRReportingPeriod02
      ,CAST([IR Scenario 03] AS VARCHAR(255))		 AS IRScenario03
      ,CAST([IR Reporting Period 03] AS VARCHAR(255))		 AS IRReportingPeriod03
      ,CAST([IR Scenario 04] AS VARCHAR(255))		 AS IRScenario04
      ,CAST([IR Reporting Period 04] AS VARCHAR(255))		 AS IRReportingPeriod04
      ,CAST([IR Scenario 05] AS VARCHAR(255))		 AS IRScenario05
      ,CAST([IR Reporting Period 05] AS VARCHAR(255))		 AS IRReportingPeriod05
      ,CAST([IR Scenario 06] AS VARCHAR(255))		 AS IRScenario06
      ,CAST([IR Reporting Period 06] AS VARCHAR(255))		 AS IRReportingPeriod06
      ,CAST([IR Scenario 07] AS VARCHAR(255))		 AS IRScenario07
      ,CAST([IR Reporting Period 07] AS VARCHAR(255))		 AS IRReportingPeriod07
      ,CAST([IR Scenario 08] AS VARCHAR(255))		 AS IRScenario08
      ,CAST([IR Reporting Period 08] AS VARCHAR(255))		 AS IRReportingPeriod08
      ,CAST([IR Scenario 09] AS VARCHAR(255))		 AS IRScenario09
      ,CAST([IR Reporting Period 09] AS VARCHAR(255))		 AS IRReportingPeriod09
      ,CAST([IR Scenario 10] AS VARCHAR(255))		 AS IRScenario10
      ,CAST([IR Reporting Period 10] AS VARCHAR(255))		 AS IRReportingPeriod10
      ,CAST([IR Scenario 11] AS VARCHAR(255))		 AS IRScenario11
      ,CAST([IR Reporting Period 11] AS VARCHAR(255))		 AS IRReportingPeriod11
      ,CAST([IR Scenario 12] AS VARCHAR(255))		 AS IRScenario12
      ,CAST([IR Reporting Period 12] AS VARCHAR(255))		 AS IRReportingPeriod12
      ,CAST([RI Scenario 01] AS VARCHAR(255))		 AS RIScenario01
      ,CAST([RI Reporting Period 01] AS VARCHAR(255))		 AS RIReportingPeriod01
      ,CAST([RI Scenario 02] AS VARCHAR(255))		 AS RIScenario02
      ,CAST([RI Reporting Period 02] AS VARCHAR(255))		 AS RIReportingPeriod02
      ,CAST([RI Scenario 03] AS VARCHAR(255))		 AS RIScenario03
      ,CAST([RI Reporting Period 03] AS VARCHAR(255))		 AS RIReportingPeriod03
      ,CAST([RI Scenario 04] AS VARCHAR(255))		 AS RIScenario04
      ,CAST([RI Reporting Period 04] AS VARCHAR(255))		 AS RIReportingPeriod04
      ,CAST([RI Scenario 05] AS VARCHAR(255))		 AS RIScenario05
      ,CAST([RI Reporting Period 05] AS VARCHAR(255))		 AS RIReportingPeriod05
      ,CAST([RI Scenario 06] AS VARCHAR(255))		 AS RIScenario06
      ,CAST([RI Reporting Period 06] AS VARCHAR(255))		 AS RIReportingPeriod06
      ,CAST([RI Scenario 07] AS VARCHAR(255))		 AS RIScenario07
      ,CAST([RI Reporting Period 07] AS VARCHAR(255))		 AS RIReportingPeriod07
      ,CAST([RI Scenario 08] AS VARCHAR(255))		 AS RIScenario08
      ,CAST([RI Reporting Period 08] AS VARCHAR(255))		 AS RIReportingPeriod08
      ,CAST([RI Scenario 09] AS VARCHAR(255))		 AS RIScenario09
      ,CAST([RI Reporting Period 09] AS VARCHAR(255))		 AS RIReportingPeriod09
      ,CAST([RI Scenario 10] AS VARCHAR(255))		 AS RIScenario10
      ,CAST([RI Reporting Period 10] AS VARCHAR(255))		 AS RIReportingPeriod10
      ,CAST([RI Scenario 11] AS VARCHAR(255))		 AS RIScenario11
      ,CAST([RI Reporting Period 11] AS VARCHAR(255))		 AS RIReportingPeriod11
      ,CAST([RI Scenario 12] AS VARCHAR(255))		 AS RIScenario12
      ,CAST([RI Reporting Period 12] AS VARCHAR(255))		 AS RIReportingPeriod12
      ,CAST([SM Scenario Actual] AS VARCHAR(255))		 AS SMScenarioActual
      ,CAST([SM Up to inception period Actual] AS VARCHAR(255))		 AS SMUptoinceptionperiodActual
      ,CAST([SM Reporting Period Actual] AS VARCHAR(255))		 AS SMReportingPeriodActual
      ,CAST([RI SM Up to inception period Actual] AS VARCHAR(255))		 AS RISMUptoinceptionperiodActual
      ,CAST([RI SM Reporting Period Actual] AS VARCHAR(255))		 AS RISMReportingPeriodActual
      ,CAST([SM Scenario Forecast]	 AS VARCHAR(255))	 AS SMScenarioForecast
      ,CAST([SM Up to inception period Forecast] AS VARCHAR(255))	 AS SMUptoinceptionperiodForecast
      ,CAST([SM Reporting Period Forecast]	 AS VARCHAR(255))	 AS SMReportingPeriodForecast
      ,CAST([RI SM Up to inception period Forecast]	 AS VARCHAR(255))	 AS RISMUptoinceptionperiodForecast
      ,CAST([RI SM Reporting Period Forecast]	 AS VARCHAR(255))	 AS RISMReportingPeriodForecast
      ,CAST([SM Scenario Business Plan]	 AS VARCHAR(255))	 AS SMScenarioBusinessPlan
      ,CAST([SM Up to inception period Business Plan]	 AS VARCHAR(255))	 AS SMUptoinceptionperiodBusinessPlan
      ,CAST([SM Reporting Period Business Plan]	 AS VARCHAR(255))	 AS SMReportingPeriodBusinessPlan
      ,CAST([RI SM Up to inception period Business Plan]	 AS VARCHAR(255))	 AS RISMUptoinceptionperiodBusinessPlan
      ,CAST([RI SM Reporting Period Business Plan]	 AS VARCHAR(255))	 AS RISMReportingPeriodBusinessPlan
      ,CAST([Topup Gross >3y Source]	 AS VARCHAR(255))	 AS [TopupGross>3ySource]
      ,CAST([Topup Gross >3y Asat]	 AS VARCHAR(255))	 AS [TopupGross>3yAsat]
      ,CAST([Topup Gross >18m<3y Source]	 AS VARCHAR(255))	 AS [TopupGross>18m<3ySource]
      ,CAST([Topup Gross >18m<3y Asat]	 AS VARCHAR(255))	 AS [TopupGross>18m<3yAsat]
      ,CAST([ADM]	 AS VARCHAR(255))	 AS ADM
      ,CAST([Payment Pattern Claims]	 AS VARCHAR(255))	 AS PaymentPatternClaims
      ,CAST([Earning Pattern (Nat Cat)]		 AS VARCHAR(255)) AS [EarningPattern(NatCat)]
      ,CAST([Pure ULR SM]		 AS VARCHAR(255)) AS PureULRSM
      ,CAST([Pure IELR Q1]		 AS VARCHAR(255)) AS PureIELRQ1
      ,CAST([Pure IELR Q2]		 AS VARCHAR(255)) AS PureIELRQ2
      ,CAST([Pure IELR Q3]		 AS VARCHAR(255)) AS PureIELRQ3
      ,CAST([Pure IELR Q4]		 AS VARCHAR(255)) AS PureIELRQ4
      ,CAST([Pure IELR Q5]		 AS VARCHAR(255)) AS PureIELRQ5
      ,CAST([Pure IELR SM]		 AS VARCHAR(255)) AS PureIELRSM
      ,CAST([ENIDs Q1]	 AS VARCHAR(255)) AS ENIDsQ1
      ,CAST([ENIDs Q2]	 AS VARCHAR(255)) AS ENIDsQ2
      ,CAST([ENIDs Q3]	 AS VARCHAR(255)) AS ENIDsQ3
      ,CAST([ENIDs Q4]	 AS VARCHAR(255)) AS ENIDsQ4
      ,CAST([ENIDs Q5]	 AS VARCHAR(255)) AS ENIDsQ5
      ,CAST([ENIDs SM]	 AS VARCHAR(255)) AS ENIDsSM
	  ,CAST([Discount Rate Q1] AS VARCHAR(255)) AS DiscountRateQ1
	  ,CAST([Discount Rate Q2] AS VARCHAR(255))	AS DiscountRateQ2
	  ,CAST([Discount Rate Q3] AS VARCHAR(255))	AS DiscountRateQ3
	  ,CAST([Discount Rate Q4] AS VARCHAR(255))	AS DiscountRateQ4
	  ,CAST([Discount Rate Q5] AS VARCHAR(255))	AS DiscountRateQ5
	  ,CAST([Discount Rate SM] AS VARCHAR(255))	AS DiscountRateSM
      ,CAST([ENIDs UnEarned Q1]	 AS VARCHAR(255))	 AS ENIDsUnEarnedQ1
      ,CAST([ENIDs UnEarned Q2]	 AS VARCHAR(255))	 AS ENIDsUnEarnedQ2
      ,CAST([ENIDs UnEarned Q3]	 AS VARCHAR(255))	 AS ENIDsUnEarnedQ3
      ,CAST([ENIDs UnEarned Q4]	 AS VARCHAR(255))	 AS ENIDsUnEarnedQ4
      ,CAST([ENIDs UnEarned Q5]	 AS VARCHAR(255))	 AS ENIDsUnEarnedQ5
      ,CAST([ENIDs UnEarned SM]	 AS VARCHAR(255))	 AS ENIDsUnEarnedSM
      ,CAST([Pattern Scenario(Re)]	 AS VARCHAR(255))	 AS [PatternScenario(Re)]
      ,CAST([Payment Pattern Claims(Re)]	 AS VARCHAR(255))	 AS [PaymentPatternClaims(Re)]
      ,CAST([Pure ULR(Re) SM]		 AS VARCHAR(255)) AS [PureULR(Re)SM]
      ,CAST([Pure IELR(Re) Q1]		 AS VARCHAR(255)) AS [PureIELR(Re)Q1]
      ,CAST([Pure IELR(Re) Q2]		 AS VARCHAR(255)) AS [PureIELR(Re)Q2]
      ,CAST([Pure IELR(Re) Q3]		 AS VARCHAR(255)) AS [PureIELR(Re)Q3]
      ,CAST([Pure IELR(Re) Q4]		 AS VARCHAR(255)) AS [PureIELR(Re)Q4]
      ,CAST([Pure IELR(Re) Q5]		 AS VARCHAR(255)) AS [PureIELR(Re)Q5]
      ,CAST([Pure IELR(Re) SM]		 AS VARCHAR(255)) AS [PureIELR(Re)SM]
       ,CAST([RICL Q1] 	 AS VARCHAR(255)) AS RICLQ1
      ,CAST([RICL Q2]		 AS VARCHAR(255)) AS RICLQ2
      ,CAST([RICL Q3]		 AS VARCHAR(255)) AS RICLQ3
      ,CAST([RICL Q4]		 AS VARCHAR(255)) AS RICLQ4
      ,CAST([RICL Q5]		 AS VARCHAR(255)) AS RICLQ5
      ,CAST([RICL SM]		 AS VARCHAR(255)) AS RICLSM
      ,CAST([ENIDs Earned(Re) Q1]		 AS VARCHAR(255)) AS [ENIDsEarned(Re)Q1]
      ,CAST([ENIDs Earned(Re) Q2]		 AS VARCHAR(255)) AS [ENIDsEarned(Re)Q2]
      ,CAST([ENIDs Earned(Re) Q3]		 AS VARCHAR(255)) AS [ENIDsEarned(Re)Q3]
      ,CAST([ENIDs Earned(Re) Q4]		 AS VARCHAR(255)) AS [ENIDsEarned(Re)Q4]
      ,CAST([ENIDs Earned(Re) Q5]		 AS VARCHAR(255)) AS [ENIDsEarned(Re)Q5]
      ,CAST([ENIDs Earned(Re) SM]		 AS VARCHAR(255)) AS [ENIDsEarned(Re)SM]
      ,CAST([ENIDs Unearned(Re) Q1]		 AS VARCHAR(255)) AS [ENIDsUnearned(Re)Q1]
      ,CAST([ENIDs Unearned(Re) Q2]		 AS VARCHAR(255)) AS [ENIDsUnearned(Re)Q2]
      ,CAST([ENIDs Unearned(Re) Q3]		 AS VARCHAR(255)) AS [ENIDsUnearned(Re)Q3]
      ,CAST([ENIDs Unearned(Re) Q4]		 AS VARCHAR(255)) AS [ENIDsUnearned(Re)Q4]
      ,CAST([ENIDs Unearned(Re) Q5]		 AS VARCHAR(255)) AS [ENIDsUnearned(Re)Q5]
      ,CAST([ENIDs Unearned(Re) SM]		 AS VARCHAR(255)) AS [ENIDsUnearned(Re)SM]
       ,CAST([Other Acquisition Expenses Q1]	 AS VARCHAR(255))	 AS [OtherAcquisitionExpensesQ1]
      ,CAST([Other Acquisition Expenses Q2]		 AS VARCHAR(255)) AS [OtherAcquisitionExpensesQ2]
      ,CAST([Other Acquisition Expenses Q3]		 AS VARCHAR(255)) AS [OtherAcquisitionExpensesQ3]
      ,CAST([Other Acquisition Expenses Q4]		 AS VARCHAR(255)) AS [OtherAcquisitionExpensesQ4]
      ,CAST([Other Acquisition Expenses Q5]		 AS VARCHAR(255)) AS [OtherAcquisitionExpensesQ5]
      ,CAST([Other Acquisition Expenses SM]		 AS VARCHAR(255)) AS [OtherAcquisitionExpensesSM]
      ,CAST([Admin Expense Q1 (other)]		 AS VARCHAR(255)) AS [AdminExpenseQ1(other)]
      ,CAST([Admin Expense Q2 (other)]		 AS VARCHAR(255)) AS [AdminExpenseQ2(other)]
      ,CAST([Admin Expense Q3 (other)]		 AS VARCHAR(255)) AS [AdminExpenseQ3(other)]
      ,CAST([Admin Expense Q4 (other)]		 AS VARCHAR(255)) AS [AdminExpenseQ4(other)]
      ,CAST([Admin Expense Q5 (other)]		 AS VARCHAR(255)) AS [AdminExpenseQ5(other)]
      ,CAST([Admin Expense SM (other)]		 AS VARCHAR(255)) AS [AdminExpenseSM(other)]
      ,CAST([Profit Commission Q1]		 AS VARCHAR(255)) AS ProfitCommissionQ1
      ,CAST([Profit Commission Q2]		 AS VARCHAR(255)) AS ProfitCommissionQ2
      ,CAST([Profit Commission Q3]		 AS VARCHAR(255)) AS ProfitCommissionQ3
      ,CAST([Profit Commission Q4]		 AS VARCHAR(255)) AS ProfitCommissionQ4
      ,CAST([Profit Commission Q5]		 AS VARCHAR(255)) AS ProfitCommissionQ5
      ,CAST([Profit Commission SM]		 AS VARCHAR(255)) AS ProfitCommissionSM
       ,CAST([Claims Handling Expenses Q1]		 AS VARCHAR(255)) AS ClaimsHandlingExpensesQ1
      ,CAST([Claims Handling Expenses Q2]		 AS VARCHAR(255)) AS ClaimsHandlingExpensesQ2
      ,CAST([Claims Handling Expenses Q3]		 AS VARCHAR(255)) AS ClaimsHandlingExpensesQ3
      ,CAST([Claims Handling Expenses Q4]		 AS VARCHAR(255)) AS ClaimsHandlingExpensesQ4
      ,CAST([Claims Handling Expenses Q5]		 AS VARCHAR(255)) AS ClaimsHandlingExpensesQ5
      ,CAST([Claims Handling Expenses SM]		 AS VARCHAR(255)) AS ClaimsHandlingExpensesSM
      ,CAST([Reinstatement Premium Q1]		 AS VARCHAR(255)) AS ReinstatementPremiumQ1
      ,CAST([Reinstatement Premium Q2]		 AS VARCHAR(255)) AS ReinstatementPremiumQ2
      ,CAST([Reinstatement Premium Q3]		 AS VARCHAR(255)) AS ReinstatementPremiumQ3
      ,CAST([Reinstatement Premium Q4]		 AS VARCHAR(255)) AS ReinstatementPremiumQ4
      ,CAST([Reinstatement Premium Q5]		 AS VARCHAR(255)) AS ReinstatementPremiumQ5
      ,CAST([Reinstatement Premium SM]		 AS VARCHAR(255)) AS ReinstatementPremiumSM
      , CAST([Premium Lapse Risk Q1]		 AS VARCHAR(255)) AS PremiumLapseRiskQ1
      ,CAST([Premium Lapse Risk Q2]	 AS VARCHAR(255))	 AS PremiumLapseRiskQ2
      ,CAST([Premium Lapse Risk Q3]	 AS VARCHAR(255))	 AS PremiumLapseRiskQ3
      ,CAST([Premium Lapse Risk Q4]	 AS VARCHAR(255))	 AS PremiumLapseRiskQ4
      ,CAST([Premium Lapse Risk Q5]	 AS VARCHAR(255))	 AS PremiumLapseRiskQ5
      ,CAST([Premium Lapse Risk SM]	 AS VARCHAR(255))	 AS PremiumLapseRiskSM
      ,CAST([RI Admin Q1]		 AS VARCHAR(255)) AS RIAdminQ1
      ,CAST([RI Admin Q2]		 AS VARCHAR(255)) AS RIAdminQ2
      ,CAST([RI Admin Q3]		 AS VARCHAR(255)) AS RIAdminQ3
      ,CAST([RI Admin Q4]		 AS VARCHAR(255)) AS RIAdminQ4
      ,CAST([RI Admin Q5]		 AS VARCHAR(255)) AS RIAdminQ5
      ,CAST([RI Admin SM]		 AS VARCHAR(255)) AS RIAdminSM
      , CAST([Profit Commission(Re) Q1]		 AS VARCHAR(255)) AS [ProfitCommission(Re)Q1]
      ,CAST([Profit Commission(Re) Q2]		 AS VARCHAR(255)) AS [ProfitCommission(Re)Q2]
      ,CAST([Profit Commission(Re) Q3]		 AS VARCHAR(255)) AS [ProfitCommission(Re)Q3]
      ,CAST([Profit Commission(Re) Q4]		 AS VARCHAR(255)) AS [ProfitCommission(Re)Q4]
      ,CAST([Profit Commission(Re) Q5]		 AS VARCHAR(255)) AS [ProfitCommission(Re)Q5]
      ,CAST([Profit Commission(Re) SM]		 AS VARCHAR(255)) AS [ProfitCommission(Re)SM]
      ,CAST([Reinstatement Premium(Re) Q1]	 AS VARCHAR(255))	 AS [ReinstatementPremium(Re)Q1]
      ,CAST([Reinstatement Premium(Re) Q2]	 AS VARCHAR(255))	 AS [ReinstatementPremium(Re)Q2]
      ,CAST([Reinstatement Premium(Re) Q3]	 AS VARCHAR(255))	 AS [ReinstatementPremium(Re)Q3]
      ,CAST([Reinstatement Premium(Re) Q4]	 AS VARCHAR(255))	 AS [ReinstatementPremium(Re)Q4]
      ,CAST([Reinstatement Premium(Re) Q5]	 AS VARCHAR(255))	 AS [ReinstatementPremium(Re)Q5]
      ,CAST([Reinstatement Premium(Re) SM]	 AS VARCHAR(255))	 AS [ReinstatementPremium(Re)SM]
      ,CAST([Rebates Q1]	 AS VARCHAR(255))	 AS RebatesQ1
      ,CAST([Rebates Q2]	 AS VARCHAR(255))	 AS RebatesQ2
      ,CAST([Rebates Q3]	 AS VARCHAR(255))	 AS RebatesQ3
      ,CAST([Rebates Q4]	 AS VARCHAR(255))	 AS RebatesQ4
      ,CAST([Rebates Q5]	 AS VARCHAR(255))	 AS RebatesQ5
      ,CAST([Rebates SM]	 AS VARCHAR(255))	 AS RebatesSM
      ,CAST([FX Rate Name (Avg)] 	 AS VARCHAR(255))	 AS [FXRateName(Avg)]
      ,CAST([FX Rate Name (Spot)]	 AS VARCHAR(255))	 AS [FXRateName(Spot)]
      ,CAST(Adjustments 	 AS VARCHAR(255)) AS Adjustments
	  ,CAST([BBNI]    AS VARCHAR(255)) AS [BBNI]
      ,CAST([LRC Risk Adjustment Q1] AS VARCHAR(255))	 AS LRCRiskAdjustmentQ1
      ,CAST([LRC Risk Adjustment Q2] AS VARCHAR(255))	 AS LRCRiskAdjustmentQ2
      ,CAST([LRC Risk Adjustment Q3] AS VARCHAR(255))	 AS LRCRiskAdjustmentQ3
      ,CAST([LRC Risk Adjustment Q4] AS VARCHAR(255))	 AS LRCRiskAdjustmentQ4
      ,CAST([LRC Risk Adjustment Q5] AS VARCHAR(255))	 AS LRCRiskAdjustmentQ5
      ,CAST([LRC Risk Adjustment SM] AS VARCHAR(255))	 AS LRCRiskAdjustmentSM
      ,CAST([LIC Risk Adjustment Q1] AS VARCHAR(255))	 AS LICRiskAdjustmentQ1
      ,CAST([LIC Risk Adjustment Q2] AS VARCHAR(255))	 AS LICRiskAdjustmentQ2
      ,CAST([LIC Risk Adjustment Q3] AS VARCHAR(255))	 AS LICRiskAdjustmentQ3
      ,CAST([LIC Risk Adjustment Q4] AS VARCHAR(255))	 AS LICRiskAdjustmentQ4
      ,CAST([LIC Risk Adjustment Q5] AS VARCHAR(255))	 AS LICRiskAdjustmentQ5
      ,CAST([LIC Risk Adjustment SM] AS VARCHAR(255))	 AS LICRiskAdjustmentSM
      ,CAST([LIC Risk Adjustment (Older Years) Q1] AS VARCHAR(255))   AS [LICRiskAdjustment(OlderYears)Q1]
      ,CAST([LIC Risk Adjustment (Older Years) Q2] AS VARCHAR(255)) AS [LICRiskAdjustment(OlderYears)Q2]
      ,CAST([LIC Risk Adjustment (Older Years) Q3] AS VARCHAR(255)) AS [LICRiskAdjustment(OlderYears)Q3]
      ,CAST([LIC Risk Adjustment (Older Years) Q4] AS VARCHAR(255)) AS [LICRiskAdjustment(OlderYears)Q4]
      ,CAST([LIC Risk Adjustment (Older Years) Q5] AS VARCHAR(255)) AS [LICRiskAdjustment(OlderYears)Q5]
      ,CAST([LIC Risk Adjustment (Older Years) SM] AS VARCHAR(255)) AS [LICRiskAdjustment(OlderYears)SM]
      ,CAST([ScheduleStatus]  AS VARCHAR(255))	AS [ScheduleStatus]
      ,CAST([ICEStatus]	  AS VARCHAR(255)) AS [ICEStatus]
      ,CAST([FK_RuleSetID]	  AS VARCHAR(255)) AS [FK_RuleSetID]
      ,CAST(YTDQTD	 AS VARCHAR(255)) AS YTDQTD
	  ,CAST(TrifocusMappingId AS VARCHAR(255) ) AS TrifocusMappingId
FROM PWAPS.IFRS17CalcUI_RunLog
) P
UNPIVOT
(value FOR Configuration IN (
      
Reporting_Period
,PatternScenario
,RunType
,InputConfig
, OpeningBalancesId
, OBReportingPeriod
,UserName
,RunDescription
,ReportingYear
,UseType
,IRScenario01
,IRReportingPeriod01
,IRScenario02
,IRReportingPeriod02
,IRScenario03
,IRReportingPeriod03
,IRScenario04
,IRReportingPeriod04
,IRScenario05
,IRReportingPeriod05
,IRScenario06
,IRReportingPeriod06
,IRScenario07
,IRReportingPeriod07
,IRScenario08
,IRReportingPeriod08
,IRScenario09
,IRReportingPeriod09
,IRScenario10
,IRReportingPeriod10
,IRScenario11
,IRReportingPeriod11
,IRScenario12
,IRReportingPeriod12
,RIScenario01
,RIReportingPeriod01
,RIScenario02
,RIReportingPeriod02
,RIScenario03
,RIReportingPeriod03
,RIScenario04
,RIReportingPeriod04
,RIScenario05
,RIReportingPeriod05
,RIScenario06
,RIReportingPeriod06
,RIScenario07
,RIReportingPeriod07
,RIScenario08
,RIReportingPeriod08
,RIScenario09
,RIReportingPeriod09
,RIScenario10
,RIReportingPeriod10
,RIScenario11
,RIReportingPeriod11
,RIScenario12
,RIReportingPeriod12
,SMScenarioActual
,SMUptoinceptionperiodActual
,SMReportingPeriodActual
,RISMUptoinceptionperiodActual
,RISMReportingPeriodActual
,SMScenarioForecast
,SMUptoinceptionperiodForecast
,SMReportingPeriodForecast
,RISMUptoinceptionperiodForecast
,RISMReportingPeriodForecast
,SMScenarioBusinessPlan
,SMUptoinceptionperiodBusinessPlan
,SMReportingPeriodBusinessPlan
,RISMUptoinceptionperiodBusinessPlan
,RISMReportingPeriodBusinessPlan
,[TopupGross>3ySource]
,[TopupGross>3yAsat]
,[TopupGross>18m<3ySource]
,[TopupGross>18m<3yAsat]
,ADM
,PaymentPatternClaims
,[EarningPattern(NatCat)]
,PureULRSM
,PureIELRQ1
,PureIELRQ2
,PureIELRQ3
,PureIELRQ4
,PureIELRQ5
,PureIELRSM
,ENIDsQ1
,ENIDsQ2
,ENIDsQ3
,ENIDsQ4
,ENIDsQ5
,ENIDsSM
,DiscountRateQ1
,DiscountRateQ2
,DiscountRateQ3
,DiscountRateQ4
,DiscountRateQ5
,DiscountRateSM
,ENIDsUnEarnedQ1
,ENIDsUnEarnedQ2
,ENIDsUnEarnedQ3
,ENIDsUnEarnedQ4
,ENIDsUnEarnedQ5
,ENIDsUnEarnedSM
,[PatternScenario(Re)]
,[PaymentPatternClaims(Re)]
,[PureULR(Re)SM]
,[PureIELR(Re)Q1]
,[PureIELR(Re)Q2]
,[PureIELR(Re)Q3]
,[PureIELR(Re)Q4]
,[PureIELR(Re)Q5]
,[PureIELR(Re)SM]
,RICLQ1
,RICLQ2
,RICLQ3
,RICLQ4
,RICLQ5
,RICLSM
,[ENIDsEarned(Re)Q1]
,[ENIDsEarned(Re)Q2]
,[ENIDsEarned(Re)Q3]
,[ENIDsEarned(Re)Q4]
,[ENIDsEarned(Re)Q5]
,[ENIDsEarned(Re)SM]
,[ENIDsUnearned(Re)Q1]
,[ENIDsUnearned(Re)Q2]
,[ENIDsUnearned(Re)Q3]
,[ENIDsUnearned(Re)Q4]
,[ENIDsUnearned(Re)Q5]
,[ENIDsUnearned(Re)SM]
,[OtherAcquisitionExpensesQ1]
,[OtherAcquisitionExpensesQ2]
,[OtherAcquisitionExpensesQ3]
,[OtherAcquisitionExpensesQ4]
,[OtherAcquisitionExpensesQ5]
,[OtherAcquisitionExpensesSM]
,[AdminExpenseQ1(other)]
,[AdminExpenseQ2(other)]
,[AdminExpenseQ3(other)]
,[AdminExpenseQ4(other)]
,[AdminExpenseQ5(other)]
,[AdminExpenseSM(other)]
,ProfitCommissionQ1
,ProfitCommissionQ2
,ProfitCommissionQ3
,ProfitCommissionQ4
,ProfitCommissionQ5
,ProfitCommissionSM
,ClaimsHandlingExpensesQ1
,ClaimsHandlingExpensesQ2
,ClaimsHandlingExpensesQ3
,ClaimsHandlingExpensesQ4
,ClaimsHandlingExpensesQ5
,ClaimsHandlingExpensesSM
,ReinstatementPremiumQ1
,ReinstatementPremiumQ2
,ReinstatementPremiumQ3
,ReinstatementPremiumQ4
,ReinstatementPremiumQ5
,ReinstatementPremiumSM
,PremiumLapseRiskQ1
,PremiumLapseRiskQ2
,PremiumLapseRiskQ3
,PremiumLapseRiskQ4
,PremiumLapseRiskQ5
,PremiumLapseRiskSM
,RIAdminQ1
,RIAdminQ2
,RIAdminQ3
,RIAdminQ4
,RIAdminQ5
,RIAdminSM
,[ProfitCommission(Re)Q1]
,[ProfitCommission(Re)Q2]
,[ProfitCommission(Re)Q3]
,[ProfitCommission(Re)Q4]
,[ProfitCommission(Re)Q5]
,[ProfitCommission(Re)SM]
,[ReinstatementPremium(Re)Q1]
,[ReinstatementPremium(Re)Q2]
,[ReinstatementPremium(Re)Q3]
,[ReinstatementPremium(Re)Q4]
,[ReinstatementPremium(Re)Q5]
,[ReinstatementPremium(Re)SM]
,RebatesQ1
,RebatesQ2
,RebatesQ3
,RebatesQ4
,RebatesQ5
,RebatesSM
,[FXRateName(Avg)]
,[FXRateName(Spot)]
,Adjustments
,BBNI
,LRCRiskAdjustmentQ1
,LRCRiskAdjustmentQ2
,LRCRiskAdjustmentQ3
,LRCRiskAdjustmentQ4
,LRCRiskAdjustmentQ5
,LRCRiskAdjustmentSM
,LICRiskAdjustmentQ1
,LICRiskAdjustmentQ2
,LICRiskAdjustmentQ3
,LICRiskAdjustmentQ4
,LICRiskAdjustmentQ5
,LICRiskAdjustmentSM
,[LICRiskAdjustment(OlderYears)Q1]
,[LICRiskAdjustment(OlderYears)Q2]
,[LICRiskAdjustment(OlderYears)Q3]
,[LICRiskAdjustment(OlderYears)Q4]
,[LICRiskAdjustment(OlderYears)Q5]
,[LICRiskAdjustment(OlderYears)SM]
      ,[ScheduleStatus]	
      ,[ICEStatus]	
      ,[FK_RuleSetID]	
      , YTDQTD
	  ,TrifocusMappingId
))AS T
GO


