﻿


CREATE  view [PWAPS].[vw_dv_ruleDetail]
As
select  ---RSM.FK_RuleSetID,
		vr.PK_ValidationRuleID,
        vr.[rule],
		vrt.validationruletype,
		an.AccountName,
		an.Operator,an.Value,
		an.CompareAccountname,
		an.Factor,
		an.DimensionName,
		an.value2,
		vr.[hidden],
		vr.updatedby,
		vr.[updatedatetime],
		Isnull(M.mv,0) [No.Of models],
		Count(RSM.FK_RuleSetID) as [No.Of rules]
from dv.[ValidationRuleHeader] vr inner join dv.validationruletype vrt on vrt.pk_validationruletypeid=vr.fk_validationruletypeid
Left join (select FK_ValidationRuleID,count(FK_ValidationRuleID) as mv from dv.RuleSetRuleMapping RSM
inner join PWAPS.IFRS17CalcUI_RunLog RL on RSM.FK_RuleSetID=RL.FK_RuleSetID
group by FK_ValidationRuleID--,RL.FK_RuleSetID
) M on M.FK_ValidationRuleID=vr.PK_ValidationRuleID
inner join
(select vrt1.AccountName,
					vrt1.FK_ValidationRuleID,
					vrt1.DimensionName,
					vrt1.Operator,
					vrt1.Value,
					null as CompareAccountName
					,null as Factor,
					null as Value2
from dv.validationruletype01 vrt1
union all
select vrt2.AccountName,
		vrt2.FK_ValidationRuleID,
		null as DimensionName ,
		vrt2.Operator,
		Cast(vrt2.Value as nvarchar),
		null as CompareAccountName,
		null as Factor,cast(vrt2.Value2 as nvarchar(100))
from dv.ValidationRuleType02 vrt2
union all
select vrt3.AccountName,
		vrt3.FK_ValidationRuleID,
		T.DimensionName ,
		vrt3.Operator,
		null as Value,
		vrt3.CompareAccountName,
		vrt3.Factor,null as Value2
from dv.ValidationRuleType03 vrt3 left join Dv.ValidationRuleDetailsType03 T on vrt3.FK_ValidationRuleID=T.FK_ValidationRuleID) an 
on vr.pk_validationRuleID=an.FK_ValidationRuleID
left  join Dv.RuleSetRuleMapping RSM on an.FK_ValidationRuleID=RSM.FK_ValidationRuleID
Group by 
		vr.PK_ValidationRuleID,
        vr.[rule],
		vrt.validationruletype,
		an.AccountName,
		an.Operator,
		an.Value,
		an.CompareAccountname,
		an.Factor,
		an.DimensionName,
		an.value2,
		vr.[hidden],
		vr.updatedby,
		vr.[updatedatetime],
		M.mv

GO


