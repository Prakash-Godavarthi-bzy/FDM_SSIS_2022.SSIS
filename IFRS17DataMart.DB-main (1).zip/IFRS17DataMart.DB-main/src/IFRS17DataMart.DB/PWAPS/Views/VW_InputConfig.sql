﻿CREATE VIEW [PWAPS].[VW_InputConfig]
	AS 
 SELECT Pk_RequestId as RunId
		,concat([Run Type],' , ',[Run Description]) as ConfigDate
		,cast(Pk_RequestId as varchar) as RunId1 
 FROM PWAPS.IFRS17CalcUI_RunLog
