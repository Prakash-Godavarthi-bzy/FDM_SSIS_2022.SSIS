﻿CREATE VIEW [PWAPS].[vwFxRateSetPercent]
	AS 
SELECT *
FROM 
	(
	SELECT 
	AD.AssumptionDatasetName
	,AD.AssumptionDatasetDescription
	,AD.IsDatasetAlreadyUsed
	,APT.AssumptionPercentageType
	,cast(ASP.CCY AS varchar(10)) AS PK_CCY_5
	,ASP.ReportingCurrencyCode AS PK_ReportingCurrencyCode_4
	,ASP.FXRate AS FXRate_0
	,AD.Pk_AssumptionDatasetNameId
	,APT.Pk_AssumptionPercentageTypeId
	,apt.AssumptionPercentageType  as SubType
	FROM 
	(SELECT AssumptionDatasetNameId, AssumptionPercentageTypeId, FxType, CCY, ReportingCurrencyCode, FXRate FROM fct.[FxRate]
	 UNION
	 SELECT Pk_AssumptionDatasetNameId, Pk_AssumptionPercentageTypeId, PK_LossType, CCY, FX_ReportingCurrencyCode_4, [Value] FROM fct.AssumptionData WHERE WB_TYPE = 'FX'  
	 ) ASP 
	INNER JOIN Dim.AssumptionDatasets  AD ON ASP.AssumptionDatasetNameId =AD.Pk_AssumptionDatasetNameId
	INNER JOIN Dim.AssumptionPercentageType  APT ON ASP.AssumptionPercentageTypeId =APT.Pk_AssumptionPercentageTypeId 

	) AS A
PIVOT
(
SUM(FXRate_0) FOR SubType in ([FX Rate (Average)],[FX Rate (Spot)])) as B
GO


