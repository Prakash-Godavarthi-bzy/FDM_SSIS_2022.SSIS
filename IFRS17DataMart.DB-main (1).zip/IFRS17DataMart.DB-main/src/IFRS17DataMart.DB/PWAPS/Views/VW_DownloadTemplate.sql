﻿CREATE VIEW [PWAPS].[VW_DownloadTemplate]
	AS 
WITH MAXID AS
(
SELECT AssumptionDatasetID, MAX(Pk_RequestID) MaxID
FROM PWAPS.DownloadTemplate
GROUP BY AssumptionDatasetID 
)


SELECT	da.AssumptionDatasetName,
		da.AssumptionDatasetDescription,
		da.Pk_AssumptionDatasetNameId,
		dt.AssumptionPrecentType,
		dt.[FileName],
		dt.[SourceFilename],
		dt.UserName,
		dt.Pk_RequestID,
		case when DT.UpdateFlag = 0 then 'Success'
		when dt.UpdateFlag = 1 then 'Pending'
		when DT.UpdateFlag = 2 then 'Running'
		else  'Failed'
		end UpdateFlag,
		case when dt.UpdateFlag = 3 then 'Recreate Assumption' 
		else '' end [RecreateAssumption],
		dt.AuditDateTime,
		case when dt.UpdateFlag = 3 then 'View Issues'
		else '' end [Failure Reasons]
FROM	MAXID M
JOIN    PWAPS.DownloadTemplate DT ON M.MaxID = DT.Pk_RequestID AND M.AssumptionDatasetID = DT.AssumptionDatasetID
JOIN	Dim.AssumptionDatasets DA ON		convert(int,DT.AssumptionDatasetID) = DA.Pk_AssumptionDatasetNameId
