﻿CREATE VIEW [PWAPS].[VW_OBRunId]
	AS  
SELECT Pk_RequestId as RunId
	 ,[Run Description] as ConfigDate
	 ,cast(Pk_RequestId as varchar) as OBId1 
FROM PWAPS.IFRS17CalcUI_RunLog
