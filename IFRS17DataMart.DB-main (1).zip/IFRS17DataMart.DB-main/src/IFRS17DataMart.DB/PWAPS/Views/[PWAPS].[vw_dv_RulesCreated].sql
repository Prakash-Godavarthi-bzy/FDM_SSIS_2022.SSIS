
Create View [PWAPS].[vw_dv_RulesCreated]
As
select T.Pk_ValidationRuleID,T.[Rule],R.ValidationRuleType from dv.ValidationRuleType R inner join dv.[ValidationRuleHeader] T on R.PK_ValidationRuleTypeID=T.FK_ValidationRuleTypeID
