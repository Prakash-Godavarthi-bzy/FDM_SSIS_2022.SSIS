﻿

CREATE VIEW [PWAPS].[vwAssumptionSetPercent] as

SELECT *
FROM 
(
	SELECT
	 AD.AssumptionDatasetName
	,AD.AssumptionDatasetDescription
	,AD.IsDatasetAlreadyUsed
	,APT.AssumptionPercentageType
	,ASP.PK_TriFocus_4 as Trifocus
	,ASP.PK_YOA_3
	,ASP.GeneralPercent_0
	,AD.Pk_AssumptionDatasetNameId
	,APT.Pk_AssumptionPercentageTypeId
	,asp.Entity
	,ASP.[Gross/RI Flag]
	,ASP.PK_LossType_5
	,CASE	WHEN (APT.AssumptionPercentageType =  'IELR (Pure)') --OR (APT.AssumptionPercentageType =  'IELR (Team)')
	        THEN CASE WHEN (ASP.PK_LossType_5 = 'A' OR ASP.PK_LossType_5 = 'Att' OR ASP.PK_LossType_5 = 'C' OR ASP.PK_LossType_5 = 'Cat') 
					 THEN  'IELR Perc'
					 --WHEN (ASP.PK_LossType_5 = 'C' OR ASP.PK_LossType_5 = 'Cat')
					 --THEN 'IELR Cat'
				END
			ELSE APT.AssumptionPercentageType
	END as SubType
	,ASP.Programme As RIProgramme 
	,ASP.[Dev Qtr]
	,ASP.[Percentage]
	,ASP.[Focus Group]
	FROM 
	(
	 SELECT Pk_AssumptionDatasetNameId as Pk_AssumptionDatasetNameId_1 , Pk_AssumptionPercentageTypeId as Pk_AssumptionPercentageTypeId_2,Entity,[Gross/RI Flag], YOA PK_YOA_3, Trifocus PK_TriFocus_4, PK_LossType as PK_LossType_5, [VALUE] GeneralPercent_0,Programme,PP_DevelopmentQuarter as [Dev Qtr]
		,EarnedPercentage as [Percentage],[Focus Group]  FROM fct.AssumptionData WHERE WB_TYPE in ('AD','EP')
	 )ASP 
	INNER JOIN Dim.AssumptionDatasets  AD ON ASP.Pk_AssumptionDatasetNameId_1 =AD.Pk_AssumptionDatasetNameId
	INNER JOIN Dim.AssumptionPercentageType  APT ON ASP.Pk_AssumptionPercentageTypeId_2 =APT.Pk_AssumptionPercentageTypeId
	--where AD.Pk_AssumptionDatasetNameId=2112

	) AS A
PIVOT
(
SUM(GeneralPercent_0) FOR SubType in ([Ultimate Loss Ratios],[Admin Exp (CR)],[Expenses (Admin Other)],[Expenses (Claims Handling)],[ENIDs (Earned)],
[ENIDs (Unearned)],[IELR Perc],[Expenses (Other Acquisition)],[Profit Commissions],[Reinstatement Premiums],[Reinsurance Credit Loss],[Rebates],
[Earning Pattern (Nat Cat)],[RI Admin],[Premium Lapse Risk],[LRC Risk Adjustment],[LIC Risk Adjustment],[LIC Risk Adjustment (Older Years)])) AS B
GO
