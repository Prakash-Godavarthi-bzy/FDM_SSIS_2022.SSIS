﻿CREATE VIEW [PWAPS].[vwDiscountRateSetPercent]
	AS
SELECT
AD.AssumptionDatasetName
,AD.AssumptionDatasetDescription
,AD.IsDatasetAlreadyUsed
,APT.AssumptionPercentageType
,'Discount Rate' as SubType,
CAST(ASP.CCY AS varchar(10)) AS PK_CCY_5,
ASP.DR_DevelopmentYear AS DevelopmentYear_4, 
ASP.[Value]  AS DiscountRtPerc_0,
AD.Pk_AssumptionDatasetNameId,
APT.Pk_AssumptionPercentageTypeId
FROM
(
 SELECT Pk_AssumptionDatasetNameId
		, Pk_AssumptionPercentageTypeId
		, PK_LossType
		, CCY
		, DR_DevelopmentYear
		,[Value] 
		FROM fct.AssumptionData WHERE WB_TYPE = 'DR' 
 UNION 
 SELECT DS.Pk_AssumptionDatasetNameId
		,DS.AssumptionPercentageTypeId
		, 'DR' as PK_LossType
		,DR.SettlementCCY
		,DR.DevelopmentYear
		,DR.CumulativeDevelopmentPercentage 
		FROM fct.DiscountRate DR
		Inner Join Dim.AssumptionDatasets DS ON DR.AssumptionDatasetName =DS.AssumptionDatasetName
   ) ASP 
Inner Join Dim.AssumptionDatasets  AD ON ASP.Pk_AssumptionDatasetNameId =AD.Pk_AssumptionDatasetNameId
Inner Join Dim.AssumptionPercentageType  APT ON ASP.Pk_AssumptionPercentageTypeId =APT.Pk_AssumptionPercentageTypeId
