﻿



CREATE VIEW [PWAPS].[vw_RecDataTable]
AS
SELECT B.Type,Account, YoA, AccountingPeriod, SUM([SumOfBox4_Value]) AS [SumOfBox4_Value], SUM([SumOfBox5_1_Value]) AS [SumOfBox5_1_Value], SUM([SumOfBox5_2_Value]) AS [SumOfBox5_2_Value]
,ROUND(Sum([SumOfBox5_1_Value])-Sum([SumOfBox4_Value]), 2) as [SumOfBox5_1_vs_Box4]
,ROUND(Sum([SumOfBox5_2_Value])-Sum([SumOfBox4_Value]), 2) as [SumOfBox5_2_vs_Box4]
,ROUND(Sum([SumOfBox5_2_Value])-Sum([SumOfBox5_1_Value]), 2) as [SumOfBox5_2_vs_Box5_1]
,CASE  B.Type
		WHEN  'Premium' THEN 'A'
		WHEN 'Cash' THEN 'B'
		WHEN 'Incurred' THEN 'C'
		WHEN 'Ultimates' THEN 'D'
		ELSE 'E'
 END OrderAccounts
	

FROM
(
	SELECT  Account, YoA , T1.AccountingPeriod, Sum(SourceTotalValue) as  [SumOfBox4_Value] ,Sum(TargetTotalValue) as  [SumOfBox5_1_Value], 0 AS [SumOfBox5_2_Value]
	FROM [Control].[ReconcileIFRS17AccountingPeriodDetail] T
	INNER JOIN [Control].[ReconcileIFRS17AccountingPeriod] T1
	ON T1.PK_ReconcileIFRS17AccountingPeriodID=T.FK_ReconcileIFRS17AccountingPeriodID
	INNER JOIN [Control].ReconcileDimIFRS17DataStage T2 ON T.FK_ReconcileDataStageID = T2.PK_ReconcileDataStageID
	WHERE T2.ReconciliationStageDescription = 'TDH_IDM'
	And T.AccountingPeriodflag=1
	AND T.FK_ReconcileDimIFRS17DataStageTablesID IN (SELECT PK_ReconcileDimIFRS17DataStageTablesID FROM Control.ReconcileDimIFRS17DataStageTables WHERE TargetTableName IN ('fct.PreProcessPremiumLTD'))
	GROUP BY Account, YoA,T1.AccountingPeriod
	UNION ALL
	SELECT  Account, YoA , T1.AccountingPeriod, Sum(SourceTotalValue) as  [SumOfBox4_Value] ,0 as  [SumOfBox5_1_Value], Sum(TargetTotalValue) AS [SumOfBox5_2_Value]
	FROM [Control].[ReconcileIFRS17AccountingPeriodDetail] T
	INNER JOIN [Control].[ReconcileIFRS17AccountingPeriod] T1
	ON T1.PK_ReconcileIFRS17AccountingPeriodID=T.FK_ReconcileIFRS17AccountingPeriodID
	INNER JOIN [Control].ReconcileDimIFRS17DataStage T2 ON T.FK_ReconcileDataStageID = T2.PK_ReconcileDataStageID
	LEFT JOIN Dim.AccountCodeMapping B ON T.Account = B.AccountCode  AND B.IsActive = 1
	WHERE T2.ReconciliationStageDescription = 'TDH_IDM'
	And T.AccountingPeriodflag=1
	AND T.FK_ReconcileDimIFRS17DataStageTablesID IN (SELECT PK_ReconcileDimIFRS17DataStageTablesID FROM Control.ReconcileDimIFRS17DataStageTables WHERE TargetTableName IN ('fct.Aggr_NonPremiumLTD'))
	GROUP BY Account, YoA,T1.AccountingPeriod
	UNION ALL
	SELECT  Account, YoA , T1.AccountingPeriod, 0 as  [SumOfBox4_Value] ,0 as  [SumOfBox5_1_Value], SUM(TargetTotalValue) [SumOfBox5_2_Value]
	FROM [Control].[ReconcileIFRS17AccountingPeriodDetail] T
	INNER JOIN [Control].[ReconcileIFRS17AccountingPeriod] T1
	ON T1.PK_ReconcileIFRS17AccountingPeriodID=T.FK_ReconcileIFRS17AccountingPeriodID
	INNER JOIN [Control].ReconcileDimIFRS17DataStage T2 ON T.FK_ReconcileDataStageID = T2.PK_ReconcileDataStageID
	WHERE T2.ReconciliationStageDescription = 'IDM_PrePost_Psicle' 
	And T.AccountingPeriodflag=1
	GROUP BY Account, YoA,T1.AccountingPeriod
)A

LEFT JOIN Dim.AccountCodeMapping B ON A.Account = B.AccountCode  AND B.IsActive = 1
GROUP BY  B.Type,Account, YoA, AccountingPeriod