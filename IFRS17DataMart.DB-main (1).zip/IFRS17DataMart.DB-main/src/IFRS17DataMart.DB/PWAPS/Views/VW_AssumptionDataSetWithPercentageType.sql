
/*====================================================================================
Author			:	Hemomsu Lakkaraju
Create date		:	1 June 2021
Description		:	This allows users to view data related to imported assumptions

Change Author	:	Hemomsu Lakkaraju
Chnage Date		:	19 June 2024
Description		:	Archiving data greater than 3 Years
Ticket No		:	https://beazley.atlassian.net/browse/I17-7538

=====================================================================================*/




CREATE VIEW [PWAPS].[VW_AssumptionDataSetWithPercentageType]
	AS 
SELECT	 [Pk_AssumptionDatasetNameId]
		,[AssumptionDatasetName]
		,[AssumptionDatasetDescription]
		,[AssumptionPercentageTypeId]
		,AssumptionPercentageType
		,[CreatedDt]
		,[CreatedBy]
		,[UpdatedDt]
		,[UpdatedBy]
		,[ValidFrom]
		,[ValidTo]
		,IsDatasetAlreadyUsed
		, CreatedDtText
FROM	(
			Select 
			  T1.[Pk_AssumptionDatasetNameId]
			, T1.[AssumptionDatasetName]
			, T1.[AssumptionDatasetDescription]
			, T1.[AssumptionPercentageTypeId]
			, T2.AssumptionPercentageType
			, T1.[CreatedDt]
			, T1.[CreatedBy]
			, T1.[UpdatedDt]
			, T1.[UpdatedBy]
			, T1.[ValidFrom]
			, T1.[ValidTo]
			, T1.IsDatasetAlreadyUsed
			, Convert(varchar(10),T1.CreatedDt,103) as CreatedDtText
			From Dim.AssumptionDatasets T1
			INNER JOIN Dim.AssumptionPercentageType T2 ON T1.AssumptionPercentageTypeId = T2.Pk_AssumptionPercentageTypeId
			INNER JOIN (SELECT DISTINCT Pk_AssumptionDatasetNameId FROM fct.AssumptionData)T4 ON T1.Pk_AssumptionDatasetNameId = T4.Pk_AssumptionDatasetNameId

			UNION 

			Select 
			  T3.[Pk_AssumptionDatasetNameId]
			,T3.[AssumptionDatasetName]
			, T3.[AssumptionDatasetDescription]
			, T3.[AssumptionPercentageTypeId]
			, T5.AssumptionPercentageType
			, T3.[CreatedDt]
			, T3.[CreatedBy]
			, T3.[UpdatedDt]
			, T3.[UpdatedBy]
			, T3.[ValidFrom]
			, T3.[ValidTo]
			, T3.IsDatasetAlreadyUsed
			, Convert(varchar(10),T3.CreatedDt,103) as CreatedDtText
			From Dim.AssumptionDatasets T3
			INNER JOIN Dim.AssumptionPercentageType T5 ON T3.AssumptionPercentageTypeId = T5.Pk_AssumptionPercentageTypeId
			INNER JOIN (SELECT DISTINCT AssumptionDatasetNameID FROM dim.AccountCodeMapping) T6 on T6.AssumptionDatasetNameID= T3.Pk_AssumptionDatasetNameId

			UNION 

			Select 
			  T3.[Pk_AssumptionDatasetNameId]
			,T3.[AssumptionDatasetName]
			, T3.[AssumptionDatasetDescription]
			, T3.[AssumptionPercentageTypeId]
			, T5.AssumptionPercentageType
			, T3.[CreatedDt]
			, T3.[CreatedBy]
			, T3.[UpdatedDt]
			, T3.[UpdatedBy]
			, T3.[ValidFrom]
			, T3.[ValidTo]
			, T3.IsDatasetAlreadyUsed
			, Convert(varchar(10),T3.CreatedDt,103) as CreatedDtText
			From Dim.AssumptionDatasets T3
			INNER JOIN Dim.AssumptionPercentageType T5 ON T3.AssumptionPercentageTypeId = T5.Pk_AssumptionPercentageTypeId
			INNER JOIN (SELECT DISTINCT AssumptionDatasetNameID FROM dim.TrifocusMapping) T7 on T7.AssumptionDatasetNameID= T3.Pk_AssumptionDatasetNameId
)AD
WHERE	(	CHARINDEX(CONVERT(CHAR(4),YEAR(GETDATE())),AD.AssumptionDatasetName,1) <> 0 		OR
			CHARINDEX(CONVERT(CHAR(4),YEAR(GETDATE()) - 1),AD.AssumptionDatasetName,1) <> 0 	OR
			CHARINDEX(CONVERT(CHAR(4),YEAR(GETDATE()) - 2),AD.AssumptionDatasetName,1) <> 0
		)
GO


