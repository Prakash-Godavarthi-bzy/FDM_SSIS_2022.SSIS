﻿





CREATE VIEW [PWAPS].[VW_ExceptionData]
AS 
SELECT	Pk_RequestId
      ,[Reporting Period] AS ReportingPeriod
	  ,[ApprovalStatus]
	 ,ApproverComments
       ,CASE WHEN ScheduleRunType='Later' THEN ScheduleDate 
	    ELSE  AuditDateTime END RunDate
       ,ScheduleStatus
       ,DataCheckScheduleStatus
	   ,[User Name]
	   ,ICEStatus
	   ,InboundStatus
	   ,[Not_Populated_tables(ICE)],
	   ICEInputExtractionStatus, 
	   ICEOutputExtractionStatus,
	   ApproverName,
	   CASE 
	        WHEN DataCheckScheduleStatus = 'Email Sent' THEN 'Download Exception Data'
		    WHEN DataCheckScheduleStatus='Email Failed' THEN 'Download Exception Data'
			ELSE '' END [View Data]
			,FK_RuleSetID
			,RuleSet
			,RunConfigDetailsFileName
FROM	PWAPS.IFRS17CalcUI_RunLog Rl LEFT JOIN Dv.RuleSet RS On Rl.FK_RuleSetID=Rs.PK_RuleSetID
