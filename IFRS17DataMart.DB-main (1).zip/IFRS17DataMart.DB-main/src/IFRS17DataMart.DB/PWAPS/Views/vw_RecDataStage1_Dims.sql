﻿


CREATE VIEW [PWAPS].[vw_RecDataStage1_Dims] AS
(
	SELECT  T3.SourceTableName, T3.TargetTableName , T1.AccountingPeriod, Sum(SourceTotalValue) as  [CountOfBox4_Value] ,Sum(TargetTotalValue) as  [CountOfBox5_1_Value]
	,ROUND(Sum(SourceTotalValue)-Sum(TargetTotalValue), 2) as  [DiffOfBox4_vs_Box5_1]  
	FROM [Control].[ReconcileIFRS17AccountingPeriodDetail] T
	INNER JOIN [Control].[ReconcileIFRS17AccountingPeriod] T1
	ON T1.PK_ReconcileIFRS17AccountingPeriodID=T.FK_ReconcileIFRS17AccountingPeriodID
	INNER JOIN [Control].ReconcileDimIFRS17DataStage T2 ON T.FK_ReconcileDataStageID = T2.PK_ReconcileDataStageID
	LEFT JOIN [Control].ReconcileDimIFRS17DataStageTables T3 ON T.FK_ReconcileDimIFRS17DataStageTablesID = T3.PK_ReconcileDimIFRS17DataStageTablesID
	WHERE T2.ReconciliationStageDescription = 'TDH_IDM'
	AND T.Account IS  NULL
	GROUP BY T3.SourceTableName, T3.TargetTableName,T1.AccountingPeriod
)