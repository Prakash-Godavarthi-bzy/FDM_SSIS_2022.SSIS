﻿


 CREATE  View [PWAPS].[vw_dv_Ruleset_count]
  As
  Select Distinct(count(rsm.FK_RuleSetID)) as [no.of.rules],isnull(b.count,0) as [no of models],rsm.FK_RuleSetID,RuleSet,Rs.[Hidden],Rs.UpdatedBy,Rs.UpdateDateTime 
  from  Dv.RuleSetRuleMapping Rsm inner join Dv.RuleSet Rs on RSM.FK_RuleSetID=Rs.PK_RuleSetID
  left join (select distinct fk_rulesetid,count(fk_rulesetid) as count from PWAPS.IFRS17CalcUI_RunLog group by FK_RuleSetId) b on Rsm.FK_RuleSetID=b.FK_RuleSetID
  Group by Rs.RuleSet,Rs.[Hidden],Rs.UpdatedBy,Rs.UpdateDateTime,rsm.FK_RuleSetID,b.count
  order by RSM.FK_RuleSetID offset 0 rows
GO


