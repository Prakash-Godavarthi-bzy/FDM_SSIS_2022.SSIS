﻿CREATE View [PWAPS].[vwAdjustments] as
SELECT *FROM 
	(
	SELECT 
	AD.AssumptionDatasetName
	,AD.AssumptionDatasetDescription
	,AD.IsDatasetAlreadyUsed
	--,ASP.checko
	,ASP.Pk_AssumptionDatasetNameId_1
	,ASP.Pk_AssumptionPercentageTypeId_2
	,APT.AssumptionPercentageType
	,ASP.TriFocus
	,ASP.Programme
	,ASP.YOA
	,ASP.CCY
	,ASP.Entity
	,ASP.[Gross/RI Flag]
	,ASP.Account
	,ASP.Source
	,ASP.AdjustmentID
	,ASP.EarnedPercentage
	,ASP.Amounts
	,ASP.Amount
	,ASP.InceptionDate
	,ASP.Narrative
	,CASE	
	 WHEN APT.AssumptionPercentageType ='Adjustments' THEN 'Adjustments'
	END as SubType
		FROM 
	(/*SELECT Pk_AssumptionDatasetNameId_1, Pk_AssumptionPercentageTypeId_2, PK_YOA_3, PK_TriFocus_4, PK_LossType_5, GeneralPercent_0 FROM dbo.WB_AssumptionSetPercent
	 UNION */ 
	 SELECT Pk_AssumptionDatasetNameId as Pk_AssumptionDatasetNameId_1 , Pk_AssumptionPercentageTypeId as Pk_AssumptionPercentageTypeId_2,Entity,[Gross/RI Flag], YOA,Account,Source,EarnedPercentage, InceptionDate,Narrative,Trifocus,Value as Amount,AdjustmentID,Programme,CCY, PK_LossType as PK_LossType_5, [VALUE] Amounts
	 FROM [fct].[AssumptionData] WHERE WB_TYPE = 'AD'  
	 )ASP 
	INNER JOIN Dim.AssumptionDatasets  AD ON ASP.Pk_AssumptionDatasetNameId_1 =AD.Pk_AssumptionDatasetNameId
	INNER JOIN Dim.AssumptionPercentageType  APT ON ASP.Pk_AssumptionPercentageTypeId_2 =APT.Pk_AssumptionPercentageTypeId 
	--where AssumptionDatasetName = '2019 Q3 IELR Pure v1'
	--INNER JOIN dim.AssumptionPercentageSubType  APST ON ASP.PK_LossType_5 =APST.LossType
	) AS A
PIVOT
(
SUM(Amounts) FOR SubType in (
[Adjustments])) AS B
where AssumptionPercentageType='Adjustments'