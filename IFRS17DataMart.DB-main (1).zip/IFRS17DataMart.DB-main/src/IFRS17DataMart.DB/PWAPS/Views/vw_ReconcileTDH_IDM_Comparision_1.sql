﻿CREATE VIEW PWAPS.vw_ReconcileTDH_IDM_Comparision
AS

SELECT Entity, Account, YOA, DataSet,AccountingPeriod, TDH, IDM, Diff
FROM
(	/* Non Prem Data Comparision*/
	SELECT Entity, Account, YoA AS YOA, DataSet,T2.AccountingPeriod, SUM(CAST(SourceTotalValue AS numeric(38,2))) as TDH, SUM(CAST(TargetTotalValue AS NUMERIC(38,2))) as IDM, 
	SUM(CAST(SourceTotalValue AS numeric(38,2)))-SUM(CAST(TargetTotalValue AS NUMERIC(38,2))) Diff
	FROM Control.ReconcileIFRS17AccountingPeriodDetail T1
	LEFT JOIN Control.ReconcileIFRS17AccountingPeriod T2 ON T1.FK_ReconcileIFRS17AccountingPeriodID = T2.PK_ReconcileIFRS17AccountingPeriodID
	LEFT JOIN Control.ReconcileDimIFRS17DataStageTables T3 ON T1.FK_ReconcileDimIFRS17DataStageTablesID = T3.PK_ReconcileDimIFRS17DataStageTablesID
	LEFT JOIN Control.ReconcileDimIFRS17DataStage T4 ON T1.FK_ReconcileDataStageID = T4.PK_ReconcileDataStageID
	WHERE  T4.ReconciliationStageDescription  = 'TDH_IDM'
	AND T3.SourceTableName = 'IFRS17.FCT_TechnicalResult'
	AND T3.TargetTableName = 'fct.Aggr_NonPremiumLTD'
	GROUP BY Entity, Account, YoA, DataSet, T2.AccountingPeriod

	UNION ALL
	/* Prem Data Comparision */
	SELECT Entity, Account, YoA AS YOA, DataSet,AccountingPeriod , SUM(TDH) AS TDH, SUM(IDM) AS IDM, SUM(TDH)-SUM(IDM) Diff
	FROM
		(

			SELECT Entity, Account, YoA AS YOA, DataSet,T2.AccountingPeriod, SUM(CAST(SourceTotalValue AS numeric(38,2))) as TDH, 0 as IDM
			FROM Control.ReconcileIFRS17AccountingPeriodDetail T1
			LEFT JOIN Control.ReconcileIFRS17AccountingPeriod T2 ON T1.FK_ReconcileIFRS17AccountingPeriodID = T2.PK_ReconcileIFRS17AccountingPeriodID
			LEFT JOIN Control.ReconcileDimIFRS17DataStageTables T3 ON T1.FK_ReconcileDimIFRS17DataStageTablesID = T3.PK_ReconcileDimIFRS17DataStageTablesID
			LEFT JOIN Control.ReconcileDimIFRS17DataStage T4 ON T1.FK_ReconcileDataStageID = T4.PK_ReconcileDataStageID
			WHERE  T4.ReconciliationStageDescription  = 'TDH_IDM'
			AND T3.SourceTableName = 'IFRS17.FCT_TechnicalResult'
			AND T3.TargetTableName = 'fct.PreProcessPremiumLTD'
			And T1.AccountingPeriodflag=1
			GROUP BY Entity, Account, YoA, DataSet, T2.AccountingPeriod

			UNION ALL

			SELECT Entity, Account, YoA AS YOA, DataSet,T2.AccountingPeriod, 0 as TDH, SUM(CAST(TargetTotalValue AS NUMERIC(38,2))) as IDM
			FROM Control.ReconcileIFRS17AccountingPeriodDetail T1
			LEFT JOIN Control.ReconcileIFRS17AccountingPeriod T2 ON T1.FK_ReconcileIFRS17AccountingPeriodID = T2.PK_ReconcileIFRS17AccountingPeriodID
			LEFT JOIN Control.ReconcileDimIFRS17DataStageTables T3 ON T1.FK_ReconcileDimIFRS17DataStageTablesID = T3.PK_ReconcileDimIFRS17DataStageTablesID
			LEFT JOIN Control.ReconcileDimIFRS17DataStage T4 ON T1.FK_ReconcileDataStageID = T4.PK_ReconcileDataStageID
			WHERE  T4.ReconciliationStageDescription  = 'IDM_PrePost_Psicle'
			AND T3.TargetTableName = 'fct.Aggr_PremiumLTD'
			And T1.AccountingPeriodflag=1
			GROUP BY Entity, Account, YoA, DataSet, T2.AccountingPeriod
		)A
		GROUP BY Entity, Account, YoA, DataSet, AccountingPeriod
)B