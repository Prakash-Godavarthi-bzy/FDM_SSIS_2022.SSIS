﻿CREATE VIEW PWAPS.vw_DistinctApprovedRunIdCheck
AS
WITH Distinct_ApprovedRunIds AS
(
SELECT  [Reporting Period], SUM(CASE WHEN ApprovalStatus = 'Approved' THEN 1 ELSE 0 END) CheckApprovalStatus
FROM PWAPS.IFRS17CalcUI_RunLog
GROUP BY  [Reporting Period]
)
 
SELECT T1.Pk_RequestId, [Reporting Period], 'Unapproved' AS ApprovalStatus
FROM PWAPS.IFRS17CalcUI_RunLog T1
WHERE [Reporting Period] IN (SELECT [Reporting Period] FROM Distinct_ApprovedRunIds WHERE CheckApprovalStatus = 0)