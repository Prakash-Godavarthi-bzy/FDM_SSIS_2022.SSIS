﻿  Create view PWAPS.vw_dv_dimensions
  as
  Select Distinct A.Account,A.AccountTableName,D.DimensionTableName,Ad.Dimension from [rpt].[vw_bm_metadata_Account] A
  inner join [rpt].[vw_bm_metadata_AccountDimensionMapping] D
  on A.AccountTableName=D.AccountTableName
  Inner join[rpt].vw_bm_metadata_Dimension AD on D.DimensionTableName=AD.DimensionTableName
   where Ad.Dimension not in ('Account')