﻿Create  view  [PWAPS].[vw_AccountingPeriodRange]

as

select Distinct AccountingPeriodName from  PWAPS.vw_AccountingPeriod
where AccountingPeriodName >= (select AccountingPeriod from [fct].[VW_Aggr_PremiumLTD] ) and 
AccountingPeriodName <= (select  FORMAT (getdate(), 'yyyyMM'))