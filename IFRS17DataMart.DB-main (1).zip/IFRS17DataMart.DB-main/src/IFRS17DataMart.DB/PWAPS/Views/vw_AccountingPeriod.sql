﻿CREATE VIEW [PWAPS].[vw_AccountingPeriod]
As
(SELECT  *
FROM Dim.AccountingPeriod
WHERE AccountingPeriodName > 201600 and 
AccountingPeriodName < Concat(YEAR(CURRENT_TIMESTAMP)+1,13) and
AccountingMonth not in (0,13)
)
GO
