﻿ Create View PWAPS.IncrementalView
 As
 (
 Select FK_AccountingPeriod As AccoutingPeriod,FK_Account As Account,Sum(Value) As Amount
 from Fct.PreProcessPremiumLTD Group by FK_Account,FK_AccountingPeriod 
 Union
 (Select AccountingPeriod,Account,Sum(Value) As Amount
 from Fct.Aggr_NonPremiumLTD Group by Account,AccountingPeriod)
 )