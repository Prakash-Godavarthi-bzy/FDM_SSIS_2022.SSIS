﻿--CREATE VIEW [PWAPS].[VW_ADMAsAtDate]
--AS
--SELECT Distinct AsAt as [Pk_AsAt],	AsAt
--FROM (
--		SELECT	Distinct fk_AccountingPeriod AsAt,FK_Account
--		FROM	fct.TechnicalResult
--		WHERE	FK_DataSet = 'ReservingData'
--		AND		FK_Account LIKE '_P-P-PR'
--		UNION
--		SELECT	Distinct fk_AccountingPeriod AsAt ,FK_Account
--		FROM	fct.TechnicalResult
--		WHERE	fk_dataSet = 'ReservingData'
--		AND FK_Account LIKE '%-P-%'
--		AND FK_Account NOT LIKE '%IC'
--		AND FK_Account NOT LIKE '%PR'

--	) AsAttb	

--GO


CREATE VIEW [PWAPS].[VW_ADMAsAtDate]
AS
SELECT Distinct AccountingPeriod as [Pk_AsAt], CAST(AccountingPeriod AS varchar(6)) AS [AsAt]
FROM fct.Aggr_PremiumLTD
WHERE Account in ('GP-T-PR','RP-T-PR')
Order by Pk_AsAt desc
OffSet  0 rows
GO

