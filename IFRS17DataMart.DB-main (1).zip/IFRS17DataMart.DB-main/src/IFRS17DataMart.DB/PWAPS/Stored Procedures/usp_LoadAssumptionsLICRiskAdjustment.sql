﻿ 
CREATE PROCEDURE [PWAPS].[usp_LoadAssumptionsLICRiskAdjustment]
     @tblassumptionLICRiskAdjustment stg_assumptionLICRiskAdjustment READONLY
AS
BEGIN
      SET NOCOUNT ON;

      INSERT into PWAPS.stg_UploadAssumptionData([RowID],[AssumpDatasetId],[AssumpPercName],RIFlag,FocusGroup,Value)
	  select c2.[RowID],c2.[AssumpDatasetId],c2.[AssumpPercName],c2.[RI Flag],c2.[Focus Group],c2.Percentage
	  from  @tblassumptionLICRiskAdjustment c2
END