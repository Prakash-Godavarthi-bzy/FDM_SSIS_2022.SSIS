﻿
CREATE PROCEDURE [PWAPS].[usp_LoadAssumptionsAccountCode]
     @tblassumptionAccountCodes stg_assumptionAccountCode READONLY
AS
BEGIN
      SET NOCOUNT ON;

      INSERT into PWAPS.stg_UploadAssumptionData([RowID],[AssumpDatasetId],[AssumpPercName],Account,[Type],Source,FieldLabel)
	  select c2.[RowID],c2.[AssumpDatasetId],c2.[AssumpPercName],c2.AccountCode,c2.[Type],c2.Source,c2.FieldLabel
	  from  @tblassumptionAccountCodes c2
END