﻿CREATE PROCEDURE [PWAPS].[usp_AssumptionFinalInsert] (@AssumpDatasetID Int,@AssumpPercName  Varchar(255))

AS

BEGIN

DECLARE @ERROR INT


SELECT @ERROR = COUNT(*) FROM PWAPS.stg_UploadedAssumptionErrors where AssumpDatasetId = @AssumpDatasetID and AssumpPercName = @AssumpPercName


IF @ERROR = 0
	BEGIN
		IF(@AssumpPercName = 'Mappings (Trifocus)')
			BEGIN
				--IF((SELECT COUNT(*) RECORD_EXISTS FROM Dim.TrifocusMapping WHERE AssumptionDatasetNameID = @AssumpDatasetID) = 0)
				--BEGIN
				--UPDATE Dim.TrifocusMapping
				--SET IsActive = 0
				--WHERE IsActive = 1

				BEGIN TRY
					INSERT INTO Dim.TrifocusMapping(AssumptionDatasetNameID,TriFocusCode,TriFocusName, [Focus Group], Division,[CM Earn],IsActive,CreatedDt,CreatedBy)
					SELECT T1.AssumpDatasetId, T1.Trifocus, T1.TriFocusName, T1.FocusGroup, T1.Division,Isnull(T1.CMEarn,''), 1, GETDATE(), SYSTEM_USER
					FROM PWAPS.stg_UploadAssumptionData T1
					INNER JOIN Dim.AssumptionPercentageType T2 ON T1.AssumpPercName = T2.AssumptionPercentageType
					WHERE T1.AssumpDatasetId = @AssumpDatasetID
					AND T2.AssumptionPercentageType = @AssumpPercName

				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Insert Into TrifocusMapping Failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH
				---END
			END
		ELSE IF (@AssumpPercName = 'Mappings (Account Code)')
			BEGIN
				IF((SELECT COUNT(*) RECORD_EXISTS FROM Dim.AccountCodeMapping WHERE AssumptionDatasetNameID = @AssumpDatasetID) = 0)
				BEGIN
				UPDATE Dim.AccountCodeMapping
				SET IsActive = 0
				WHERE IsActive = 1

				BEGIN TRY
					INSERT INTO Dim.AccountCodeMapping(AssumptionDatasetNameID,AccountCode,[Type], [Source], FieldLabel, IsActive,[ProcessFlow],CreatedDt,CreatedBy)
					SELECT T1.AssumpDatasetId, T1.Account, T1.[Type], T1.[Source], T1.FieldLabel, 1,UPPER([ProcessFlow]), GETDATE(), SYSTEM_USER
					FROM PWAPS.stg_UploadAssumptionData T1
					INNER JOIN Dim.AssumptionPercentageType T2 ON T1.AssumpPercName = T2.AssumptionPercentageType
					WHERE T1.AssumpDatasetId = @AssumpDatasetID
					AND T2.AssumptionPercentageType = @AssumpPercName
				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Insert Into AccountCodeMapping Failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH
				END
			END	
		ELSE
			BEGIN
				IF((SELECT COUNT(*) RECORD_EXISTS FROM fct.AssumptionData WHERE Pk_AssumptionDatasetNameId = @AssumpDatasetID) = 0)
				BEGIN TRY
					INSERT INTO fct.AssumptionData
					(WB_TYPE	,Pk_AssumptionDatasetNameId,Pk_AssumptionPercentageTypeId,Entity,	TriFocus,Account,YOA ,CCY	,FX_ReportingCurrencyCode_4	,[Gross/RI Flag]	
					,Programme,PK_LossType ,AdjustmentID		,Source	,EarnedPercentage	,InceptionDate,[Focus Group]	,Narrative	,PP_DevelopmentQuarter, DR_DevelopmentYear	,[Value])	
					SELECT 
					--'AD', 
					CASE when T1.AssumpPercName IN ('FX Rate (Average)','FX Rate (Spot)') Then 'FX'
						 when T1.AssumpPercName IN ('Payment Pattern (Claims)' ,'Payment Pattern (Premiums)' ) Then 'PP'
						 when T1.AssumpPercName='Discount Rate' Then 'DR'
						 when T1.AssumpPercName='Earning Pattern (Nat Cat)' Then 'EP'  
						 else 'AD' end as WB_TYPE ,
					T1.AssumpDatasetId, T2.Pk_AssumptionPercentageTypeId,	Entity,	Trifocus,Account,YOA ,Currency	,ReportingCurrency	,RIFlag	
					,RIProgramme,LossType ,AdjustmentID		,Source	,TRY_CONVERT(decimal(19,10),[EarnedPercentage])	,TRY_CONVERT(DATETIME,InceptionDate,103),FocusGroup	,Narrative	,
					CASE when T1.AssumpPercName in ('Payment Pattern (Claims)' ,'Payment Pattern (Premiums)','Earning Pattern (Nat Cat)') Then  TRY_CONVERT(INT,DevelopmentQuarter) else null end,	
					CASE when T1.AssumpPercName ='Discount Rate' Then  TRY_CONVERT(INT,DevelopmentQuarter) else null end,
					--TRY_CONVERT(float,[Value]),
					CASE WHEN [Value] LIKE '%E%' 
							THEN CAST(CAST([Value] AS FLOAT)  AS DECIMAL(38,12)) 
							ELSE TRY_CONVERT(DECIMAL(38,12),[Value])
					END
					FROM PWAPS.stg_UploadAssumptionData T1
					INNER JOIN Dim.AssumptionPercentageType T2 ON T1.AssumpPercName = T2.AssumptionPercentageType
					WHERE T1.AssumpDatasetId = @AssumpDatasetID
					AND T2.AssumptionPercentageType = @AssumpPercName
				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Insert Into AssumptionData Failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH
			END
	END

END