﻿-- =============================================
-- Author:		Hemomsu Lakkaraju
-- Create date: 10th May 2021
-- Description:	This woud update the Updateflag in export template for ready to download
-- =============================================
CREATE PROCEDURE [PWAPS].[USP_ExportLogs]
	-- Add the parameters for the stored procedure here
	@FileName Varchar(500)
AS

BEGIN
	BEGIN TRY
	
		Update PWAPS.ExportLogs
		set		UpdateFlag = 5
		where	[FileName] = @FileName
	
	  
	END TRY

	BEGIN CATCH
	        INSERT INTO PWAPS.stg_UploadedAssumptionErrors([AssumpDatasetId],[AssumpPercName],[ErrorMsg],FlowName)
	        SELECT ep.Pk_AssumptionDataSetNameId,apt.AssumptionPercentageType,'Flow has failed','ASM_FilesystemtoSharepoint'
	        FROM PWAPS.ExportLogs ep join Dim.AssumptionPercentageType apt on ep.AssumptionPrecentType = apt.Pk_AssumptionPercentageTypeId
	        WHERE ep.FileName = @FileName
	
	       UPDATE PWAPS.ExportLogs
	        SET  UpdateFlag = 3
	        WHERE [FileName] = @FileName


	END CATCH
END