﻿ 
CREATE PROCEDURE [PWAPS].[usp_LoadAssumptionsWithLossType]
    @tblassumptiondataWithLossType stg_assumptionWithLossType READONLY
AS
BEGIN
      SET NOCOUNT ON;


      INSERT into PWAPS.stg_UploadAssumptionData([RowID],[AssumpDatasetId],[AssumpPercName],[Trifocus],[YOA],[LossType],RIFlag,[RIProgramme],[Value]
	  ) select c2.[RowID],c2.[AssumpDatasetId],c2.[AssumpPercName],c2.[Trifocus],c2.[YOA],c2.LossType,c2.[RIFlag],c2.[RIProgramme],c2.[Percentage] from 
	  @tblassumptiondataWithLossType c2
END