CREATE PROCEDURE [PWAPS].[usp_LoadAssumptionsWithOutLossType]
@tblsassumptiondataWOLT stg_assumptionWithOutLossType READONLY
AS
BEGIN
SET NOCOUNT ON;




INSERT into PWAPS.stg_UploadAssumptionData([RowID],[AssumpDatasetId],[AssumpPercName],[Trifocus],[YOA],[RIFlag],[RIProgramme],[Value]
) select c2.[RowID],c2.[AssumpDatasetId],c2.[AssumpPercName],c2.[Trifocus],c2.[YOA],c2.[RI Flag],c2.[RIProgramme],c2.[Percentage] from
@tblsassumptiondataWOLT c2
END