﻿CREATE PROCEDURE [PWAPS].[usp_LoadAssumptionsExpenses]
     @tblassumptionExp stg_assumptionExpenses READONLY
AS
BEGIN
      SET NOCOUNT ON;

      INSERT into PWAPS.stg_UploadAssumptionData([RowID],[AssumpDatasetId],[AssumpPercName],FocusGroup,Value)
	  select c2.[RowID],c2.[AssumpDatasetId],c2.[AssumpPercName],c2.[Focus Group],c2.Percentage
	  from  @tblassumptionExp c2
END