﻿CREATE PROCEDURE [PWAPS].[usp_LoadAssumptionsFx]
        @tblassumptionFx stg_assumptionFx READONLY
AS
BEGIN
      SET NOCOUNT ON;


      INSERT into PWAPS.stg_UploadAssumptionData([RowID],[AssumpDatasetId],[AssumpPercName],[Currency],[ReportingCurrency],[Value]
	  ) select c2.[RowID],c2.[AssumpDatasetId],c2.[AssumpPercName],c2.[Original Currency],c2.[ReportingCurrency],c2.[Percentage] from 
	  @tblassumptionFx c2
END