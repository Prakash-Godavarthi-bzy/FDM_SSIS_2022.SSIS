﻿ 
CREATE PROCEDURE [PWAPS].[usp_LoadAssumptionsPaymentPattern]
  @tblassumptionPP stg_assumptionPaymentPattern READONLY
AS
BEGIN
      SET NOCOUNT ON;



      INSERT into PWAPS.stg_UploadAssumptionData([RowID],[AssumpDatasetId],[AssumpPercName],[Trifocus],[DevelopmentQuarter],[RIFlag],[Value]
	  ) select c2.[RowID],c2.[AssumpDatasetId],c2.[AssumpPercName],c2.Trifocus,c2.[DevelopmentQuarter],c2.[RI Flag],c2.[Percentage] from 
	  @tblassumptionPP c2
END