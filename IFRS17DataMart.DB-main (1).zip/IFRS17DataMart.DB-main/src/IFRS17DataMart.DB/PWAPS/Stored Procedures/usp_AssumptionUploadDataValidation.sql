﻿--EXECUTE PWAPS.usp_AssumptionUploadDataValidation 2920, 'Adjustments'

--DECLARE
--@AssumpDatasetID Int = 7868
--,@AssumpPercName  Varchar(255) = 'Earning Pattern (Nat Cat)          '


CREATE PROCEDURE [PWAPS].[usp_AssumptionUploadDataValidation] (@AssumpDatasetID Int,@AssumpPercName  Varchar(255))

AS

BEGIN 
	DROP TABLE IF EXISTS #UploadAssumptionData
	CREATE TABLE #UploadAssumptionData
	(
	RowID								INT ,
	ColumnData							VARCHAR(Max),
	ErrorMsg							VARCHAR(Max),
	HasError							BIT
	)

	DROP TABLE IF EXISTS #DataToCheck
	SELECT *
	INTO #DataToCheck
	FROM PWAPS.stg_UploadAssumptionData
	WHERE AssumpDatasetId = @AssumpDatasetID
	AND AssumpPercName = @AssumpPercName


	BEGIN

	-----Unique Dimensionality
		IF EXISTS (SELECT DISTINCT 1  FROM [PWAPS].[udf_GetAssumptionUniqueDimension](@AssumpDatasetID,@AssumpPercName))
			BEGIN
					INSERT INTO #UploadAssumptionData(RowID , ColumnData , HasError, ErrorMsg)
					SELECT T1.RowID , T1.DupData , 1, 'Duplicate Dimension'
					FROM [PWAPS].[udf_GetAssumptionUniqueDimension](@AssumpDatasetID,@AssumpPercName) T1	
			END

	-----VALIDATE TRIFOCUS
		IF @AssumpPercName IN ('Adjustments','ENIDs (Earned)','Rebates','Reinsurance Credit Loss','Profit Commissions','Reinstatement Premiums','ENIDs (Unearned)','Ultimate Loss Ratios',
								'Payment Pattern (Claims)' ,'Payment Pattern (Premiums)' ,'IELR (Pure)' ,'Earning Pattern (Nat Cat)','Premium Lapse Risk')
		
			BEGIN TRY
			
				INSERT INTO #UploadAssumptionData(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID , CASE WHEN T1.Trifocus IS NULL OR  T1.Trifocus = '' THEN 'Blank' ELSE T1.Trifocus END , 1,CASE WHEN LEN(T1.Trifocus)>25 THEN 'Invalid Trifocus Code Length'																														
																																 ELSE 'Invalid Trifocus Code'
																															 END
				FROM #DataToCheck T1
				LEFT JOIN Dim.TriFocus T2 ON T1.Trifocus = T2.PK_TriFocus
				WHERE 
				1 = 1
				AND (PK_TriFocus IS NULL OR ISNULL(T1.Trifocus,'') = '' OR T1.Trifocus = '' OR LEN(T1.Trifocus)>25 )
			END TRY
			BEGIN CATCH

				EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Generic-Invalid Trifocus Code insert failed', ERROR_LINE, ERROR_MESSAGE 

			END CATCH

	----VALIDATE YOA 		
		IF @AssumpPercName IN ('Adjustments','ENIDs (Earned)','Rebates','Reinsurance Credit Loss','Profit Commissions','Reinstatement Premiums','ENIDs (Unearned)','Ultimate Loss Ratios',
								'IELR (Pure)','Earning Pattern (Nat Cat)','Premium Lapse Risk' ,'LRC Risk Adjustment' ,'LIC Risk Adjustment')
								
			BEGIN TRY
				INSERT INTO #UploadAssumptionData(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID , CASE WHEN T1.YOA  IS NULL OR  T1.YOA  = '' THEN 'Blank' ELSE T1.YOA  END, 1, 'Invalid YOA'
				FROM #DataToCheck T1
				LEFT JOIN Dim.YOA T2 ON T1.YOA = T2.PK_YOA
				WHERE 
				1 = 1
				AND (PK_YOA IS NULL OR ISNULL(T1.YOA,'') = '' OR T1.YOA = '')
			END TRY
			BEGIN CATCH

				EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Generic-Invalid YOA insert failed', ERROR_LINE, ERROR_MESSAGE 

			END CATCH

	----VALIDATE ENTITY		
		IF @AssumpPercName IN ('Adjustments','Ultimate Loss Ratios','IELR (Pure)')
		   IF @AssumpPercName = 'IELR (Pure)'
			BEGIN TRY
				INSERT INTO #UploadAssumptionData(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID , CASE WHEN T1.Entity  IS NULL OR  T1.Entity  = '' THEN 'Blank' ELSE T1.Entity  END  , 1 , 'Invalid Entity Code'
				FROM #DataToCheck T1
				WHERE 
				1 = 1
				AND CASE WHEN T1.Entity IS NULL OR T1.ENTITY = '' THEN  'Blank' ELSE T1.Entity END NOT IN ( 'Blank','8022')
			END TRY
			BEGIN CATCH

				EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Generic-Invalid Entity Code insert failed', ERROR_LINE, ERROR_MESSAGE 

			END CATCH
			
		  ELSE
			BEGIN TRY
				INSERT INTO #UploadAssumptionData(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID , CASE WHEN T1.Entity  IS NULL OR  T1.Entity  = '' THEN 'Blank' ELSE T1.Entity  END  , 1 , 'Invalid Entity Code'
				FROM #DataToCheck T1
				LEFT JOIN Dim.Entity T2 ON T1.Entity = T2.PK_Entity
				WHERE 
				1 = 1
				AND (T2.PK_Entity IS NULL OR ISNULL(T1.Entity,'') = '' OR T1.Entity = '')
			END TRY
			BEGIN CATCH

				EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Generic-Invalid Entity Code insert failed', ERROR_LINE, ERROR_MESSAGE 

			END CATCH

	----VALIDATE CURRENCY	
		IF @AssumpPercName IN ('Adjustments','Discount Rate','FX Rate (Spot)','FX Rate (Average)')

			 BEGIN TRY
				INSERT INTO #UploadAssumptionData(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID ,CASE WHEN T1.Currency  IS NULL OR  T1.Currency  = '' THEN 'Blank' ELSE T1.Currency  END   , 1 , 'Invalid Currency Code'
				FROM #DataToCheck T1
				LEFT JOIN Dim.CCY T2 ON T1.Currency = T2.PK_CCY
				WHERE 
				1 = 1
				AND (T2.PK_CCY IS NULL OR ISNULL(T1.Currency,'') = '' OR T1.Currency = '')
			END TRY
			BEGIN CATCH

				EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Generic-Invalid Currency Code insert failed', ERROR_LINE, ERROR_MESSAGE 

			END CATCH

		

-------VALIDATE RI FLAG	
			IF @AssumpPercName IN ('Adjustments','Ultimate Loss Ratios','Payment Pattern (Claims)' ,'Payment Pattern (Premiums)','IELR (Pure)','LRC Risk Adjustment' ,'LIC Risk Adjustment',
								'LIC Risk Adjustment (Older Years)','Profit Commissions','Reinstatement Premiums','ENIDs (Earned)','ENIDs (Unearned)')

				 BEGIN TRY
					INSERT INTO #UploadAssumptionData(RowID , ColumnData , HasError, ErrorMsg)
					SELECT T1.RowID ,CASE WHEN T1.RIFlag IS NULL OR  T1.RIFlag  = '' THEN 'Blank' ELSE T1.RIFlag  END  , 1, 'Invalid RI Flag'
					FROM #DataToCheck T1
					WHERE 
					1 = 1
					AND RIFlag IS NULL OR RIFlag = '' OR RIFlag NOT IN ('G', 'R')
  			    END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Generic-Invalid RI Flag insert failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH

			ELSE IF @AssumpPercName  IN ('Rebates','Reinsurance Credit Loss')
				BEGIN TRY
					INSERT INTO #UploadAssumptionData(RowID , ColumnData , HasError, ErrorMsg)
					SELECT T1.RowID ,CASE WHEN T1.RIFlag  IS NULL OR  T1.RIFlag  = '' THEN 'Blank' ELSE T1.RIFlag  END  , 1, 'Invalid RI Flag'
					FROM #DataToCheck T1
					WHERE 
					1 = 1
					AND RIFlag IS NULL OR RIFlag = '' OR RIFlag <> 'R' 
				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Generic-Invalid RI Flag insert failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH


-------VALIDATE PROGRAMME
		IF @AssumpPercName IN ('Adjustments','Ultimate Loss Ratios','Rebates','Reinsurance Credit Loss','Profit Commissions','Reinstatement Premiums','ENIDs (Earned)','ENIDs (Unearned)','IELR (Pure)')
				BEGIN TRY

				INSERT INTO #UploadAssumptionData(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID ,CASE WHEN T1.[RIProgramme] IS NULL OR  T1.[RIProgramme]  = '' THEN 'Blank' ELSE T1.[RIProgramme]   END , 1, 'Invalid RI Programme Name Length'
				FROM #DataToCheck T1
				WHERE 
				1 = 1
				AND ([RIProgramme] is null OR RIProgramme = '' OR LEN(RIProgramme) > 100 )
				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Generic-Invalid RI Programme Name Length insert failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH

		IF @AssumpPercName IN ('Adjustments','Ultimate Loss Ratios','Rebates','Reinsurance Credit Loss','Profit Commissions','Reinstatement Premiums','ENIDs (Earned)','ENIDs (Unearned)','IELR (Pure)')
				BEGIN TRY

				INSERT INTO #UploadAssumptionData(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID , T1.[RIProgramme]  , 1, 'Invalid RI Programme Name'
				FROM #DataToCheck T1
				WHERE 
				1 = 1
				AND ( (CASE WHEN RIFlag IS NOT NULL OR RIFlag  <> ''
							THEN CASE WHEN RIFlag = 'G' AND  RIProgramme <>  'Gross' THEN 'F' 
									WHEN RIFlag = 'R' AND  RIProgramme =  'Gross' THEN 'F'
									ELSE 'P' 
								END
						END  = 'F'))
				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Generic-Invalid RI Programme Name insert failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH

-------VALIDATE LossType
		IF @AssumpPercName IN ('Ultimate Loss Ratios','IELR (Pure)')

			BEGIN TRY
				INSERT INTO #UploadAssumptionData(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID , CASE WHEN T1.LossType  IS NULL OR  T1.LossType  = '' THEN 'Blank' ELSE T1.LossType  END  , 1, 'Invalid Loss Type'
				FROM #DataToCheck T1
				WHERE 
				1 = 1
				AND LossType NOT IN ('A','C', 'L') OR LossType IS NULL OR LossType = ''
			END TRY
			BEGIN CATCH

				EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Generic-Invalid Loss Type insert failed', ERROR_LINE, ERROR_MESSAGE 

			END CATCH


--------FOCUSGROUP LENGTH VALIDATION
		IF @AssumpPercName IN ('Mappings (Trifocus)','LRC Risk Adjustment' ,'LIC Risk Adjustment','LIC Risk Adjustment (Older Years)','Expenses (Other Acquisition)', 'Expenses (Admin Other)', 'Expenses (Claims Handling)' ,'RI Admin'  )
			BEGIN TRY
				INSERT INTO #UploadAssumptionData(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID ,CASE WHEN T1.FocusGroup  IS NULL OR  T1.FocusGroup = '' THEN 'Blank' ELSE T1.FocusGroup  END   , 1, 'Invalid FocusGroup Length'
				FROM #DataToCheck T1
				WHERE 
				1 = 1
				AND(FocusGroup = '' OR FocusGroup IS NULL OR LEN(FocusGroup) > 100 )
			END TRY
			BEGIN CATCH

				EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Generic-Invalid FocusGroup Length insert failed', ERROR_LINE, ERROR_MESSAGE 

			END CATCH


------ VALIDATE Percentage */

		IF @AssumpPercName IN ('ENIDs (Earned)','Rebates','Reinsurance Credit Loss','Profit Commissions','Reinstatement Premiums','ENIDs (Unearned)','Payment Pattern (Claims)' ,'Payment Pattern (Premiums)',
								'IELR (Pure)','FX Rate (Spot)','FX Rate (Average)','Earning Pattern (Nat Cat)' ,'Premium Lapse Risk','LRC Risk Adjustment' ,'LIC Risk Adjustment','LIC Risk Adjustment (Older Years)',
								'Expenses (Other Acquisition)', 'Expenses (Admin Other)', 'Expenses (Claims Handling)' ,'RI Admin','Ultimate Loss Ratios','Discount Rate')
			BEGIN TRY
				INSERT INTO #UploadAssumptionData(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID ,CASE WHEN T1.[Value]  IS NULL OR  T1.[Value]  = '' THEN 'Blank' ELSE T1.[Value]  END  , 1, 'Invalid Percentage'
				FROM #DataToCheck T1
				WHERE 
				1 = 1
				--AND FLOOR(EarnedPercentage) = CEILING(EarnedPercentage)
				
				AND ([Value] = '' OR [Value] IS NULL OR [Value] LIKE '[A-Z]%' OR
					ISNUMERIC(
							CASE WHEN [Value] LIKE '%E%' 
							THEN CAST(CAST([Value] AS FLOAT)  AS DECIMAL(38,12)) 
							ELSE TRY_CONVERT(DECIMAL(38,12),[Value])
							END ) = 0
					)

			
			END TRY
			BEGIN CATCH
				EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Generic-Invalid percentage insert failed', ERROR_LINE, ERROR_MESSAGE 
			END CATCH			

		END


------FINAL RESULT
				IF EXISTS (SELECT 1 FROM #UploadAssumptionData WHERE HasError = 1)
					BEGIN TRY
					  INSERT INTO PWAPS.stg_UploadedAssumptionErrors
							(RowID,AssumpDatasetId  ,AssumpPercName,	ColumnData	,HasError,ErrorMsg)	
					  SELECT RowID, @AssumpDatasetID ,@AssumpPercName,	ColumnData	,HasError,ErrorMsg	
					  FROM #UploadAssumptionData
					END TRY
					BEGIN CATCH

						EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Generic-Insert into stg_UploadedAssumptionErrors', ERROR_LINE, ERROR_MESSAGE 

					END CATCH
									   					 				  				  				 			   									   			 		  		  		 	   			   	  					
DROP TABLE IF EXISTS #UploadAssumptionData
DROP TABLE IF EXISTS #DataToCheck		
END