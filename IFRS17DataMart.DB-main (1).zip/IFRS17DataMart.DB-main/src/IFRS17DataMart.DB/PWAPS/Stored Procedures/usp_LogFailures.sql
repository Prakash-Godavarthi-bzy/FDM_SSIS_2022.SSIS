﻿CREATE PROCEDURE [PWAPS].[usp_LogFailures]
( 
@AssumpDatasetID   INT,
@AssumpPercName VARCHAR(MAX),
@ErrorSource	VARCHAR(MAX),
@ErrorLine      INT,
@ErrorMSg	    VARCHAR(MAX)
)
AS
BEGIN
	INSERT INTO PWAPS.Log_AssumptionUploadFailures	(AssumptionID  ,	AssumptionType,	ErrorSource	,ErrorLine  ,	ErrorMSg, ErrorDateTime)
	VALUES(@AssumpDatasetID  ,		   @AssumpPercName,		   @ErrorSource	,	@ErrorLine,	   @ErrorMSg, GETDATE())	   

END