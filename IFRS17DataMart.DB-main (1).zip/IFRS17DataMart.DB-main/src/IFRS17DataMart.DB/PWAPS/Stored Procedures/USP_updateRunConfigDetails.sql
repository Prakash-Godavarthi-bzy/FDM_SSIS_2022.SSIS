﻿
CREATE PROC [PWAPS].[USP_updateRunConfigDetails] (@RequestID INT,@RunConfigDetailsName NVARCHAR(128))
AS
BEGIN
UPDATE  PWAPS.IFRS17CalcUI_RunLog
SET		RunConfigDetailsFileName = @RunConfigDetailsName
WHERE	Pk_RequestId = @RequestID
END