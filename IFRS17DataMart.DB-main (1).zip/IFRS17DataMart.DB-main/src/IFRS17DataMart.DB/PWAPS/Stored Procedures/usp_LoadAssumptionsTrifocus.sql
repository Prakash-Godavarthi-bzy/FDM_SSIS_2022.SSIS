﻿ 
CREATE PROCEDURE [PWAPS].[usp_LoadAssumptionsTrifocus]
     @tblassumptionTrifocus stg_assumptionTrifocus READONLY
AS
BEGIN
      SET NOCOUNT ON;

      INSERT into PWAPS.stg_UploadAssumptionData([RowID],[AssumpDatasetId],[AssumpPercName],Trifocus,TriFocusName,FocusGroup,Division)
	  select c2.[RowID],c2.[AssumpDatasetId],c2.[AssumpPercName],c2.TriFocusCode,c2.TriFocusName,c2.[Focus Group],c2.Division
	  from  @tblassumptionTrifocus c2
END