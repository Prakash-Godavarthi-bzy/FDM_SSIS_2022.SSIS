﻿
--DECLARE
--@AssumpDatasetID Int = 7868
--,@AssumpPercName  Varchar(255) = 'Earning Pattern (Nat Cat)          '
CREATE PROCEDURE [PWAPS].[usp_AssumptionSpecificValidation] (@AssumpDatasetID Int,@AssumpPercName  Varchar(255))

AS

BEGIN

	DROP TABLE IF exists #UploadAssumptionSpecificErrors
	CREATE TABLE #UploadAssumptionSpecificErrors
	(
	RowID								int ,
	ColumnData							varchar(MAX),
	ErrorMsg							varchar(MAX),
	HasError							BIT
	)

	DROP TABLE IF EXISTS #DataToCheck
	SELECT *
	INTO #DataToCheck
	FROM PWAPS.stg_UploadAssumptionData
	WHERE AssumpDatasetId = @AssumpDatasetID
	AND @AssumpPercName = @AssumpPercName


------ADJUSTMENT SPECIFIC CHECKS
		IF @AssumpPercName IN ('Adjustments')

			BEGIN
				BEGIN TRY
				/*  Duplicate Adjustment ID check */
					INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
					SELECT T1.RowID , T1.AdjustmentID , 1, 'Duplicate Adjustment ID'
					FROM #DataToCheck T1
					WHERE 
					1 = 1
					AND AdjustmentID IN (SELECT DISTINCT AdjustmentID
										 FROM #DataToCheck
										 GROUP BY  AdjustmentID
										 HAVING COUNT(*) > 1)
				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Duplicate Adjustment ID insert failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH

				BEGIN TRY
				/*  Empty Adjustment ID check */
					INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
					SELECT T1.RowID , CASE WHEN T1.AdjustmentID  IS NULL OR  T1.AdjustmentID  = '' THEN 'Blank' ELSE T1.AdjustmentID  END , 1, 'Invalid Adjustment ID'
					FROM #DataToCheck T1
					WHERE 
					1 = 1
					AND AdjustmentID = '' OR AdjustmentID IS NULL
				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Duplicate Adjustment ID insert failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH


				----VALIDATE ACCOUNT	
			   BEGIN TRY
					INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
					SELECT T1.RowID , CASE WHEN T1.Account  IS NULL OR  T1.Account = '' THEN 'Blank' ELSE T1.Account  END, 1 , 'Invalid Account Code'
					FROM #DataToCheck T1
					LEFT JOIN Dim.Account T2 ON T1.Account = T2.PK_Account
					WHERE 
					1 = 1
					AND T2.PK_Account IS NULL OR T1.ACCOUNT IS NULL OR T1.ACCOUNT = ''
				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Invalid Account Code insert failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH


				BEGIN TRY
				/*  Invalid Inception Date check */
					INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
					SELECT T1.RowID , CASE WHEN T1.InceptionDate  IS NULL OR  T1.InceptionDate = '' THEN 'Blank' ELSE T1.InceptionDate  END  , 1, 'Invalid Inception Date'
					FROM #DataToCheck T1
					WHERE 
					1 = 1
					AND ((CASE WHEN ISNULL(InceptionDate, '') <> '' THEN CASE ISDATE(TRY_CONVERT(DATETIME,InceptionDate,103)) WHEN 1 THEN 1 ELSE 0 END ELSE 0 END = 0) 
						 OR InceptionDate = '' OR InceptionDate IS NULL
						)

				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Invalid Inception Date insert failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH

				BEGIN TRY
				/*  Invalid Earned Percentage check */
				INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID , CASE WHEN T1.[EarnedPercentage] IS NULL OR  T1.[EarnedPercentage] = '' THEN 'Blank' ELSE T1.[EarnedPercentage]  END  , 1, 'Invalid Earned Percentage'
				FROM #DataToCheck T1
				WHERE 
				1 = 1
				--AND FLOOR(EarnedPercentage) = CEILING(EarnedPercentage)
				AND (CASE WHEN ISNULL([EarnedPercentage], '') <> '' AND ISNUMERIC(TRY_CONVERT(FLOAT,[EarnedPercentage])) = 1
						 THEN TRY_CONVERT(FLOAT,[EarnedPercentage])
						 ELSE -1 
					 END NOT BETWEEN 0 AND 1
					 OR [EarnedPercentage] = ''
					 OR [EarnedPercentage] IS NULL)

				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Invalid Earned Percentage insert failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH

				BEGIN TRY
				/*  Invalid Value */
				INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID , CASE WHEN T1.[Value] IS NULL OR  T1.[Value] = '' THEN 'Blank' ELSE T1.[Value]  END  , 1, 'Invalid Amount'--,TRY_CONVERT(decimal(19,9),[Value])	
				FROM #DataToCheck T1
				WHERE 
				1 = 1
				AND  ISNUMERIC(TRY_CONVERT(decimal(19,9),T1.[Value]))  = 0
				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Invalid Amount insert failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH

				BEGIN TRY
				-------VALIDATE SCENARIO
				INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID , T1.[Source] , 1, 'Invalid Data Source'
				FROM #DataToCheck T1
				WHERE 
				1 = 1
				AND [Source] NOT IN ('A', 'F', 'B', 'U')
				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Invalid Data Source insert failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH


				BEGIN TRY	
				/*  Invalid Narrative */
				INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID , T1.Narrative , 1, 'Invalid Narrative Length'
				FROM #DataToCheck T1
				WHERE 
				1 = 1
				AND LEN(Narrative) > 255
				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Invalid Narrative Length insert failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH
			END


----FX RATE SPECIFIC CHECKS
		IF @AssumpPercName IN ('FX Rate (Spot)','FX Rate (Average)')
		BEGIN
				----VALIDATE REPORTING CURRENCY	
			BEGIN TRY
				INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID , CASE WHEN T1.ReportingCurrency IS NULL OR  T1.ReportingCurrency = '' THEN 'Blank' ELSE T1.ReportingCurrency  END  , 1 , 'Invalid Reporting Currency'
				FROM #DataToCheck T1
				LEFT JOIN Dim.ReportingCurrency T2 ON T1.ReportingCurrency = T2.PK_ReportingCurrencyCode
				WHERE 
				1 = 1
				AND (T2.PK_ReportingCurrencyCode IS NULL OR  T1.ReportingCurrency = '' OR ISNULL( T1.ReportingCurrency,'') = '')
			END TRY
			BEGIN CATCH

				EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Invalid Reporting Currency insert failed', ERROR_LINE, ERROR_MESSAGE 

			END CATCH	

		----VALIDATE FX Rate is correct where Currency and Reporting currency are same
			BEGIN TRY
				INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID , T1.[Value] , 1 , 'Invalid FX Rate'
				FROM #DataToCheck T1
				WHERE 
				1 = 1
				AND CASE WHEN T1.Currency = T1.ReportingCurrency AND TRY_CONVERT(FLOAT,[Value]) <> 1 THEN 0 ELSE 1 END = 0
			END TRY
			BEGIN CATCH

				EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Invalid FX Rate insert failed', ERROR_LINE, ERROR_MESSAGE 

			END CATCH	


		END

			/* Check Development quarter is in range AND is an Integer*/	
		IF @AssumpPercName IN ('Discount Rate','Payment Pattern (Claims)' ,'Payment Pattern (Premiums)','Earning Pattern (Nat Cat)' )
		BEGIN
				BEGIN TRY
					INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
					SELECT T1.RowID , CASE WHEN T1.DevelopmentQuarter IS NULL OR T1.DevelopmentQuarter = '' THEN 'Blank' ELSE T1.DevelopmentQuarter END , 1, 'Invalid Development Quarter Value'
					FROM #DataToCheck T1
					WHERE 
					1 = 1
					AND (TRY_CONVERT(INT,DevelopmentQuarter) NOT BETWEEN 1 AND 200)
				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Invalid Development Quarter Value insert failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH

				BEGIN TRY
					INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
					SELECT T1.RowID , CASE WHEN T1.DevelopmentQuarter IS NULL OR T1.DevelopmentQuarter = '' THEN 'Blank' ELSE T1.DevelopmentQuarter END , 1, 'Invalid Development Quarter Format'
					FROM #DataToCheck T1
					WHERE 
					1 = 1
					AND (CASE WHEN ISNUMERIC(DevelopmentQuarter + '.e0') = 0 THEN 0 ELSE 1 END = 0)
						
				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Invalid Development Quarter Format insert failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH
		END
		
----------Earning Pattern Nat Cat Checks percentage total = 1 check
		IF @AssumpPercName IN ('Earning Pattern (Nat Cat)' )
		BEGIN
			BEGIN TRY
			    /*Earning Pattern Nat Cat percentage total = 1 check*/
				INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID , (T1.Trifocus + '-' + T1.YOA + '-' + T1.[Value]) , 1, 'Pattern Total Not Equal to 1 for Dimension'
				FROM #DataToCheck T1
				INNER JOIN (
							SELECT  Trifocus, YOA
							FROM (SELECT Trifocus, YOA,
										CASE WHEN [Value] LIKE '%E%' 
											 THEN CAST(CAST([Value] AS FLOAT)  AS DECIMAL(38,12)) 
											 ELSE TRY_CONVERT(DECIMAL(38,12),[Value])
										END  [Value]
								   FROM #DataToCheck
								 )A
                            GROUP BY Trifocus, YOA
							HAVING ROUND(SUM([VALUE]),1) <> 1
						 ) T2 ON T1.Trifocus = T2.Trifocus AND T1.YOA = T2.YOA 
 				WHERE 
				1 = 1
				ORDER BY RowID

			END TRY
			BEGIN CATCH

				EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Pattern Total Not Equal to 1 for Dimension insert failed', ERROR_LINE, ERROR_MESSAGE 

			END CATCH
			
			BEGIN TRY
			    /*Earning Pattern Nat Cat yoa-trifocus-devquarter to be unique*/
				INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID , (T1.Trifocus + '-' + T1.YOA + '-' + T1.[DevelopmentQuarter]) , 1, 'Duplicate Development Quarter for Dimension'
				FROM #DataToCheck T1
				INNER JOIN (SELECT Trifocus, YOA ,DevelopmentQuarter
							FROM #DataToCheck T1
							WHERE 
							1 = 1
							GROUP BY Trifocus, YOA,DevelopmentQuarter
							HAVING COUNT(*) > 1) T2 ON T1.Trifocus = T2.Trifocus AND T1.YOA = T2.YOA AND T1.DevelopmentQuarter = T2.DevelopmentQuarter
				 WHERE 
				 1 = 1
			END TRY
			BEGIN CATCH

				EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Duplicate Development Quarter for Dimension insert failed', ERROR_LINE, ERROR_MESSAGE 

			END CATCH
		END		

		
------ACCOUNT CODE SPECIFIC CHECKS

		/* ACCOUNT TYPE NOT SPECIFIED*/
		IF @AssumpPercName IN ('Mappings (Account Code)' )
		BEGIN

			----VALIDATE ACCOUNT TYPE
			  
				BEGIN TRY
				INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID , CASE WHEN T1.[Type]  IS NULL OR  T1.[Type]  = '' THEN 'Blank' ELSE T1.[Type]   END , 1, 'Invalid Account Type'
				FROM #DataToCheck T1
				WHERE 
				1 = 1
				AND [Type]  NOT IN ('Premium','Cash','Incurred','Ultimates') 
				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Invalid Account Type insert failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH


		/* ACCOUNT SOURCE NOT SPECIFIED*/
				BEGIN TRY
				INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID ,  CASE WHEN T1.[Source] IS NULL OR  T1.[Source]  = '' THEN 'Blank' ELSE T1.[Source]  END   , 1, 'Invalid Account Source Length'
				FROM #DataToCheck T1
				WHERE 
				1 = 1
				AND( [Source] is null OR [Source] = '' OR LEN([Source]) > 100)
				--[Source]  NOT IN ('Eurobase/PFT','LPSO','ADM','CC')
				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Invalid Account Source Length insert failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH

		/* ACCOUNT FIELD LABEL OUT OF LENGTH*/
				BEGIN TRY
				INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID , CASE WHEN T1.FieldLabel IS NULL OR  T1.FieldLabel  = '' THEN 'Blank' ELSE T1.FieldLabel  END   , 1, 'Invalid Field Label Length'
				FROM #DataToCheck T1
				WHERE 
				1 = 1
				AND (FieldLabel is null OR FieldLabel = '' OR LEN(FieldLabel) > 30)
				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Invalid Field Label Length insert failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH


				BEGIN TRY
				INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID , CASE WHEN T1.Account IS NULL OR  T1.Account  = '' THEN 'Blank' ELSE T1.Account  END  , 1 , 'Invalid Account Code Length'
				FROM #DataToCheck T1
				WHERE 
				1 = 1
				AND (T1.Account is null OR T1.Account = '' OR LEN(T1.Account) > 15)
				END TRY

				BEGIN CATCH

				EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Invalid Account Code Length insert failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH


				--Validating ProcessFlow



               BEGIN TRY
                INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
                SELECT T1.RowID , CASE WHEN T1.[ProcessFlow]  IS NULL OR  T1.[ProcessFlow]  = '' THEN 'Blank' ELSE T1.[ProcessFlow]   END , 1, 'Invalid ProcessFlow'
                FROM #DataToCheck T1
                WHERE
                1 = 1
                AND (T1.ProcessFlow is null OR T1.ProcessFlow = '' OR T1.ProcessFlow  NOT IN ('PP','NR'))
                END TRY
                BEGIN CATCH



                   EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Invalid ProcessFlow insert failed', ERROR_LINE, ERROR_MESSAGE



               END CATCH

		END
		
--------Trifocus Mapping Validation

		IF @AssumpPercName IN ('Mappings (Trifocus)' )
		BEGIN
				BEGIN TRY
				INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID , CASE WHEN T1.Trifocus IS NULL OR  T1.Trifocus  = '' THEN 'Blank' ELSE T1.Trifocus  END  , 1, 'Invalid Trifocus Code Length'
				FROM #DataToCheck T1
				WHERE 
				1 = 1
				AND (T1.Trifocus is null OR T1.Trifocus = '' OR LEN(Trifocus) > 25)
				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Invalid Trifocus Code Length insert failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH

				BEGIN TRY
				INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID , CASE WHEN  T1.TriFocusName IS NULL OR   T1.TriFocusName  = '' THEN 'Blank' ELSE  T1.TriFocusName END  , 1, 'Invalid Trifocus Name Length'
				FROM #DataToCheck T1
				WHERE 
				1 = 1
				AND ( T1.TriFocusName is null OR T1.TriFocusName = '' OR LEN(TriFocusName) > 60)
				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Invalid Trifocus Name Length insert failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH


				BEGIN TRY
				INSERT INTO #UploadAssumptionSpecificErrors(RowID , ColumnData , HasError, ErrorMsg)
				SELECT T1.RowID , CASE WHEN T1.Division  IS NULL OR T1.Division  = '' THEN 'Blank' ELSE  T1.Division  END  , 1, 'Invalid Division Length'
				FROM #DataToCheck T1
				WHERE 
				1 = 1
				AND (T1.Division is null OR T1.Division = '' OR LEN(Division) > 60)
				END TRY
				BEGIN CATCH
					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Invalid Division Length insert failed', ERROR_LINE, ERROR_MESSAGE 
				END CATCH
			END






-------FINAL ERROR INSERTS --------
		BEGIN
				IF EXISTS (SELECT 1 FROM #UploadAssumptionSpecificErrors WHERE HasError = 1)
				BEGIN TRY
					  INSERT INTO PWAPS.stg_UploadedAssumptionErrors
							(RowID,AssumpDatasetId  ,AssumpPercName,	ColumnData	,HasError,ErrorMsg)	
					  SELECT RowID, @AssumpDatasetID ,@AssumpPercName,	ColumnData	,HasError,ErrorMsg	
					  FROM #UploadAssumptionSpecificErrors
				END TRY
				BEGIN CATCH

					EXECUTE PWAPS.usp_LogFailures  @AssumpDatasetID, @AssumpPercName, 'Specific-Insert into stg_UploadedAssumptionErrors failed', ERROR_LINE, ERROR_MESSAGE 

				END CATCH
		END


DROP TABLE IF EXISTS #UploadAssumptionSpecificErrors
DROP TABLE IF EXISTS #DataToCheck
END