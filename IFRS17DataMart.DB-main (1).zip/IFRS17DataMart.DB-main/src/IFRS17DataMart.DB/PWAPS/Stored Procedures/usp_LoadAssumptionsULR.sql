﻿ 
CREATE PROCEDURE [PWAPS].[usp_LoadAssumptionsULR]
 @tblassumptionULR stg_assumptionULR READONLY
AS
BEGIN
      SET NOCOUNT ON;

      INSERT into PWAPS.stg_UploadAssumptionData([RowID],[AssumpDatasetId],[AssumpPercName],YOA,Trifocus,LossType,Entity,RIFlag,RIProgramme,[Value]
	  ) select c2.[RowID],c2.[AssumpDatasetId],c2.[AssumpPercName],c2.YOA,c2.Trifocus,c2.LossType,c2.Entity,c2.[RI Flag],c2.RIProgramme,c2.[Percentage] from 
	  @tblassumptionULR c2
END