﻿ 
CREATE PROCEDURE [PWAPS].[usp_LoadAssumptionsPremLapRisk]
     @tblassumptionPremLapRisk stg_assumptionPremLapRisk READONLY
AS
BEGIN
      SET NOCOUNT ON;

      INSERT into PWAPS.stg_UploadAssumptionData([RowID],[AssumpDatasetId],[AssumpPercName],YOA,Trifocus,Value)
	  select c2.[RowID],c2.[AssumpDatasetId],c2.[AssumpPercName],c2.YOA,c2.Trifocus,c2.Percentage
	  from  @tblassumptionPremLapRisk c2
END