﻿

CREATE PROCEDURE [PWAPS].[usp_LoadAssumptionsAdjustments]
  @tblassumptionAdj stg_assumptionAdjustments READONLY
AS
BEGIN
      SET NOCOUNT ON;

      INSERT into PWAPS.stg_UploadAssumptionData([RowID],[AssumpDatasetId],[AssumpPercName],AdjustmentID,Trifocus,YOA,Entity,
	  Account,RIFlag,RIProgramme,Currency,Source,Value,EarnedPercentage,InceptionDate,Narrative)
	  select c2.[RowID],c2.[AssumpDatasetId],c2.[AssumpPercName],c2.AdjustmentID,c2.Trifocus,c2.YOA,c2.Entity,c2.Account
	  ,c2.[Gross/ RIFlag],c2.Programme,c2.Currency,c2.Source,c2.Amount,c2.EarnedPercentage,c2.InceptionDate,c2.Narrative
	  from  @tblassumptionAdj c2
END