﻿ 
CREATE PROCEDURE [PWAPS].[usp_LoadAssumptionsRiskAdjustment]
       @tblassumptionRiskAdjustment stg_assumptionRiskAdjustment READONLY
AS
BEGIN
      SET NOCOUNT ON;

      INSERT into PWAPS.stg_UploadAssumptionData([RowID],[AssumpDatasetId],[AssumpPercName],YOA,RIFlag,FocusGroup,Value)
	  select c2.[RowID],c2.[AssumpDatasetId],c2.[AssumpPercName],c2.YOA,c2.[RI Flag],c2.[Focus Group],c2.Percentage
	  from  @tblassumptionRiskAdjustment c2
END