﻿CREATE TABLE [PWAPS].[AppSettings] (
    [SettingID]          INT           IDENTITY (1, 1) NOT NULL,
    [Environment]        VARCHAR (255) NULL,
    [SettingName]        VARCHAR (255) NULL,
    [SettingDescription] VARCHAR (255) NULL,
    [SettingValue]       VARCHAR (255) NULL,
    CONSTRAINT [PK_SettingID] PRIMARY KEY CLUSTERED ([SettingID] ASC) WITH (FILLFACTOR = 90)
);

