﻿
CREATE  PROCEDURE [dbo].[usp_LogIFRS17DataMart]	


													@v_ActivityMessage         NVARCHAR(4000), 
													@v_ActivityStatus          SMALLINT,
													@v_ActivityName            VARCHAR(50)    = NULL,
													@v_ActivitySSISExecutionId VARCHAR(50)    = NULL,
													@v_ActivityErrorCode	 NVARCHAR(50)	= NULL,
													@v_ActivityJobId			varchar(50)= NULL,
													@v_ActivityUserEmail	Varchar(150)=NULL,
													@V_RequestID				INT=NULL
			
													
													

AS

    BEGIN

/*
		=========================================================================================================
						Insert into Log table
		=========================================================================================================
*/

        INSERT INTO [Control].[ActivityLog]
					(
					 FK_ActivityStatus, 
					 ActivityHost, 
					 ActivityDatabase,  
					 ActivitySSISExecutionId, 
					 ActivityName, 
					 ActivityDateTime, 
					 ActivityMessage,
					ActivityErrorCode,
					ActivityJobId,
					UserName,
					PK_RequestID
					)
            SELECT	                
                      @v_ActivityStatus,
                      @@SERVERNAME, 
                      'IFRS17DataMart', 
                      @v_ActivitySSISExecutionId, 
                      ISNULL(@v_ActivityName,' SSIS Package Failed.'),
                      GETDATE(), 
                      @v_ActivityMessage,
					  @v_ActivityErrorCode,
					  @v_ActivityJobId,
					  @v_ActivityUserEmail,
					  @V_RequestID
    END;
