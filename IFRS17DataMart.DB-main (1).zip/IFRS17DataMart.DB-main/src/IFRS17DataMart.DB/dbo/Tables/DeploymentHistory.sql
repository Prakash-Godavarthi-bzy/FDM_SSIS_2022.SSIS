﻿CREATE TABLE [dbo].[DeploymentHistory] (
    [ID]                 INT            IDENTITY (1, 1) NOT NULL,
    [Release_Version_No] VARCHAR (50)   NOT NULL,
    [DateofDeployment]   DATETIME       NOT NULL,
    [Component]          VARCHAR (250)  NOT NULL,
    [ServerName]         VARCHAR (50)   NOT NULL,
    [ReleaseNotes]       NVARCHAR (MAX) NOT NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);

