﻿CREATE TABLE [dbo].[WB_AssumptionSetPercent] (
    [GeneralPercent_0]                FLOAT (53)     NULL,
    [Pk_AssumptionDatasetNameId_1]    INT            NULL,
    [Pk_AssumptionPercentageTypeId_2] INT            NULL,
    [PK_YOA_3]                        NVARCHAR (10)  NULL,
    [PK_TriFocus_4]                   NVARCHAR (25)  NULL,
    [PK_LossType_5]                   NVARCHAR (255) NULL,
	[Focus Group]                     VARCHAR(100)   NULL,
    [MS_AUDIT_TIME_6]                 DATETIME       NULL,
    [MS_AUDIT_USER_7]                 NVARCHAR (255) NULL
);

