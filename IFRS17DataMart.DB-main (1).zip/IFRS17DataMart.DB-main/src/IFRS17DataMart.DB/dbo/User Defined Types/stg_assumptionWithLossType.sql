﻿CREATE TYPE [dbo].[stg_assumptionWithLossType] AS TABLE (
    [RowID]           INT           NULL,
    [AssumpDatasetId] INT           NULL,
    [AssumpPercName]  VARCHAR (255) NULL,
    [Trifocus]        VARCHAR (255) NULL,
    [YOA]             VARCHAR (255) NULL,
    [LossType]        VARCHAR (255) NULL,
    [RIFlag]          VARCHAR (255) NULL,
    [RIProgramme]     VARCHAR (255) NULL,
    [Percentage]      VARCHAR (255) NULL);

