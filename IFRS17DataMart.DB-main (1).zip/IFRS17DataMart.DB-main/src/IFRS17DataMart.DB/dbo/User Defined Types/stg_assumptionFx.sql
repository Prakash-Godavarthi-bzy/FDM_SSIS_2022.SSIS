﻿CREATE TYPE [dbo].[stg_assumptionFx] AS TABLE (
    [RowID]             INT           NULL,
    [AssumpDatasetId]   INT           NULL,
    [AssumpPercName]    VARCHAR (255) NULL,
    [Original Currency] VARCHAR (255) NULL,
    [ReportingCurrency] VARCHAR (255) NULL,
    [Percentage]        VARCHAR (255) NULL);

