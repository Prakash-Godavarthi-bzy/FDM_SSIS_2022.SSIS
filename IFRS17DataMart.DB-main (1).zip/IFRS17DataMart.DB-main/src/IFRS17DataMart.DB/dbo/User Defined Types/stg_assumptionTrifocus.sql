﻿CREATE TYPE [dbo].[stg_assumptionTrifocus] AS TABLE (
    [RowID]           INT           NULL,
    [AssumpDatasetId] INT           NULL,
    [AssumpPercName]  VARCHAR (255) NULL,
    [TrifocusCode]    VARCHAR (255) NULL,
    [TriFocusName]    VARCHAR (255) NULL,
    [Focus Group]     VARCHAR (255) NULL,
    [Division]        VARCHAR (255) NULL);

