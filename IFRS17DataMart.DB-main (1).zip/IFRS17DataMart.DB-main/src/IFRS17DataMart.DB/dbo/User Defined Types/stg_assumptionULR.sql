﻿CREATE TYPE [dbo].[stg_assumptionULR] AS TABLE (
    [RowID]           INT           NULL,
    [AssumpDatasetId] INT           NULL,
    [AssumpPercName]  VARCHAR (255) NULL,
    [YOA]             VARCHAR (255) NULL,
    [Trifocus]        VARCHAR (255) NULL,
    [LossType]        VARCHAR (255) NULL,
    [Entity]          VARCHAR (255) NULL,
    [RI Flag]         VARCHAR (255) NULL,
    [RIProgramme]     VARCHAR (255) NULL,
    [Percentage]      VARCHAR (255) NULL);

