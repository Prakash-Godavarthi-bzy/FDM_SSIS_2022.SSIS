﻿CREATE TYPE [dbo].[stg_assumptionPaymentPattern] AS TABLE (
    [RowID]              INT           NULL,
    [AssumpDatasetId]    INT           NULL,
    [AssumpPercName]     VARCHAR (255) NULL,
    [Trifocus]           VARCHAR (255) NULL,
    [DevelopmentQuarter] VARCHAR (255) NULL,
    [RI Flag]            VARCHAR (255) NULL,
    [Percentage]         VARCHAR (255) NULL);

