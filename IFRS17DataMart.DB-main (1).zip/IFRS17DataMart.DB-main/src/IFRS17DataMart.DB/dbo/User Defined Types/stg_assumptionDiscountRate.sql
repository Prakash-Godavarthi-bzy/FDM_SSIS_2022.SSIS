﻿CREATE TYPE [dbo].[stg_assumptionDiscountRate] AS TABLE (
    [RowID]              INT           NULL,
    [AssumpDatasetId]    INT           NULL,
    [AssumpPercName]     VARCHAR (255) NULL,
    [Original Currency]  VARCHAR (255) NULL,
    [DevelopmentQuarter] VARCHAR (255) NULL,
    [Percentage]         VARCHAR (255) NULL);

