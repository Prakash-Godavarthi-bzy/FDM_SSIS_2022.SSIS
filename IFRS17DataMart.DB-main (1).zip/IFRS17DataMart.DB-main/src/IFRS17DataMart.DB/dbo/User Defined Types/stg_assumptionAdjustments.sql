﻿CREATE TYPE [dbo].[stg_assumptionAdjustments] AS TABLE (
    [RowID]            INT           NULL,
    [AssumpDatasetId]  INT           NULL,
    [AssumpPercName]   VARCHAR (255) NULL,
    [AdjustmentID]     VARCHAR (255) NULL,
    [Trifocus]         VARCHAR (255) NULL,
    [YOA]              VARCHAR (255) NULL,
    [Entity]           VARCHAR (255) NULL,
    [Account]          VARCHAR (255) NULL,
    [Gross/ RIFlag]    VARCHAR (255) NULL,
    [Programme]        VARCHAR (255) NULL,
    [Currency]         VARCHAR (255) NULL,
    [Source]           VARCHAR (255) NULL,
    [Amount]           VARCHAR (255) NULL,
    [EarnedPercentage] VARCHAR (255) NULL,
    [InceptionDate]    VARCHAR (255) NULL,
    [Narrative]        VARCHAR (255) NULL);

