﻿CREATE TYPE [dbo].[stg_assumptionLICRiskAdjustment] AS TABLE (
    [RowID]           INT           NULL,
    [AssumpDatasetId] INT           NULL,
    [AssumpPercName]  VARCHAR (255) NULL,
    [RI Flag]         VARCHAR (255) NULL,
    [Focus Group]     VARCHAR (255) NULL,
    [Percentage]      VARCHAR (255) NULL);

