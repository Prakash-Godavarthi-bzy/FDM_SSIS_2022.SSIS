﻿CREATE TYPE [dbo].[stg_assumptionPremLapRisk] AS TABLE (
    [RowID]           INT           NULL,
    [AssumpDatasetId] INT           NULL,
    [AssumpPercName]  VARCHAR (255) NULL,
    [YOA]             VARCHAR (255) NULL,
    [Trifocus]        VARCHAR (255) NULL,
    [Percentage]      VARCHAR (255) NULL);

