﻿CREATE TYPE [dbo].[stg_assumptionAccountCode] AS TABLE (
    [RowID]           INT           NULL,
    [AssumpDatasetId] INT           NULL,
    [AssumpPercName]  VARCHAR (255) NULL,
    [AccountCode]     VARCHAR (255) NULL,
    [Type]            VARCHAR (255) NULL,
    [Source]          VARCHAR (255) NULL,
    [FieldLabel]      VARCHAR (255) NULL);

