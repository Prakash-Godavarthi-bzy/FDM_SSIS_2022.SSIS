﻿
CREATE FUNCTION [Inbound].[udf_GetAggrPremiumData] (@Dataset VARCHAR(255),	@AccPer INT)

RETURNS TABLE
AS
RETURN
	SELECT  
		  T1.FK_Entity
		, T1.FK_Trifocus
		, T2.IFRS17_Trifocus
		, T1.[RI Flag]
		, T1.Programme
		, T1.CCYSettlement
		, T1.Fk_dataset
		, T1.FK_scenario
		, T1.FK_Account
		, T1.FK_YOA
		, T1.FK_inceptionyear
		, T1.InceptionPeriod
		, T1.FK_AccountingPeriod
		, SUM([Value]) AS [Value]
	FROM fct.PreProcessPremiumLTD T1
	LEFT JOIN [Dim].[IFRS17_Trifocus] T2 ON T1.BK_PolicyNumber = T2.BK_PolicyNumber AND T1.FK_YOA = T2.FK_YOA
	WHERE 1=1
	AND T1.Fk_dataset = @Dataset
	AND T1.FK_AccountingPeriod <= @AccPer
	GROUP BY T1.FK_Entity
		, T1.FK_Trifocus
		, T2.IFRS17_Trifocus
		, T1.[RI Flag]
		, T1.Programme
		, T1.CCYSettlement
		, T1.Fk_dataset
		, T1.FK_scenario
		, T1.FK_Account
		, T1.FK_YOA
		, T1.FK_inceptionyear
		, T1.InceptionPeriod
		, T1.FK_AccountingPeriod


