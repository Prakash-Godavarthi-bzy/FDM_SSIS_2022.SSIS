﻿CREATE VIEW [dbo].[MaxReleaseVersion] AS

 WITH MaxSprintNumbers AS (
    SELECT
        Component,
        MAX(CAST(SUBSTRING(ReleaseNotes, PATINDEX('%[0-9]%', ReleaseNotes), LEN(ReleaseNotes)) AS FLOAT)) AS MaxSprintNumber
    FROM
        [dbo].[DeploymentHistory]
    WHERE
        Component NOT IN ('IFRS17-PPAutomation', 'IFRS17-ICEAutomation')
    GROUP BY
        Component
)

SELECT
	COALESCE(MAX(CASE WHEN TableName IN ('Table1', 'Table2', 'Table3', 'Table4', 'Table5') THEN CONCAT(ReleaseNotes,   CHAR(13),' on ', FORMAT(DateofDeployment, 'dd-MMM-yyyy hh:mm:ss')) END), 'NA') AS BR1,
    COALESCE(MAX(CASE WHEN TableName IN ('Table6', 'Table7') THEN CONCAT(ReleaseNotes, ' on ', FORMAT(DateofDeployment, 'dd-MMM-yyyy hh:mm:ss')) END), 'NA') AS BR2,
    COALESCE(MAX(CASE WHEN TableName IN ('Table8') THEN CONCAT(ReleaseNotes, ' on ', FORMAT(DateofDeployment, 'dd-MMM-yyyy hh:mm:ss')) END), 'NA') AS ICE,
    COALESCE(MAX(CASE WHEN TableName IN ('Table9') THEN CONCAT(ReleaseNotes, ' on ', FORMAT(DateofDeployment, 'dd-MMM-yyyy hh:mm:ss')) END), 'NA') AS PP
FROM (
    SELECT 'Table1' AS TableName, Release_Version_No AS Release_Version_No, DateofDeployment AS DateofDeployment, ReleaseNotes AS ReleaseNotes FROM [$(Technicalhub)].[SchedulingHub].[dbo].[DeploymentHistory]
    WHERE ReleaseNotes = ( SELECT CONCAT('Sprint ', MAX(CAST(SUBSTRING(ReleaseNotes, PATINDEX('%[0-9]%', ReleaseNotes), LEN(ReleaseNotes)) AS FLOAT)))
    FROM [$(Technicalhub)].[SchedulingHub].[dbo].[DeploymentHistory])
    UNION
    SELECT 'Table2' AS TableName, Release_Version_No , DateofDeployment AS DateofDeployment , ReleaseNotes AS ReleaseNotes FROM [$(Technicalhub)].[Technicalhub].[dbo].[DeploymentHistory]
	WHERE ReleaseNotes = ( SELECT CONCAT('Sprint ', MAX(CAST(SUBSTRING(ReleaseNotes, PATINDEX('%[0-9]%', ReleaseNotes), LEN(ReleaseNotes)) AS FLOAT)))
    FROM [$(Technicalhub)].[TechnicalHub].[dbo].[DeploymentHistory])
    UNION												  
    SELECT 'Table3' AS TableName, Release_Version_No ,DateofDeployment AS DateofDeployment , ReleaseNotes AS ReleaseNotes  FROM [$(Technicalhub)].[FinanceDataContract].[dbo].[DeploymentHistory]
	WHERE ReleaseNotes = ( SELECT CONCAT('Sprint ', MAX(CAST(SUBSTRING(ReleaseNotes, PATINDEX('%[0-9]%', ReleaseNotes), LEN(ReleaseNotes)) AS FLOAT)))
    FROM [$(Technicalhub)].[FinanceDataContract].[dbo].[DeploymentHistory])
    UNION												 
    SELECT 'Table4' AS TableName, Release_Version_No , DateofDeployment  AS DateofDeployment  , ReleaseNotes AS ReleaseNotes FROM [$(Technicalhub)].[FinanceLanding].[dbo].[DeploymentHistory]
	WHERE ReleaseNotes = ( SELECT CONCAT('Sprint ', MAX(CAST(SUBSTRING(ReleaseNotes, PATINDEX('%[0-9]%', ReleaseNotes), LEN(ReleaseNotes)) AS FLOAT)))
    FROM [$(Technicalhub)].[FinanceLanding].[dbo].[DeploymentHistory])
    UNION												  
    SELECT 'Table5' AS TableName, Release_Version_No , DateofDeployment AS DateofDeployment , ReleaseNotes AS ReleaseNotes  FROM [$(Technicalhub)].[Orchestram].[dbo].[DeploymentHistory]
	WHERE ReleaseNotes = ( SELECT CONCAT('Sprint ', MAX(CAST(SUBSTRING(ReleaseNotes, PATINDEX('%[0-9]%', ReleaseNotes), LEN(ReleaseNotes)) AS FLOAT)))
    FROM   [$(Technicalhub)].[Orchestram].[dbo].[DeploymentHistory])
    UNION												 
    SELECT 'Table6' AS TableName, dh.Release_Version_No, dh.DateofDeployment, dh.ReleaseNotes FROM
    [dbo].[DeploymentHistory] dh
    JOIN MaxSprintNumbers ms
        ON dh.Component = ms.Component
        AND dh.ReleaseNotes = CONCAT('Sprint ', ms.MaxSprintNumber)	
    UNION
    SELECT 'Table7' AS TableName, Release_Version_No , DateofDeployment AS DateofDeployment , ReleaseNotes AS ReleaseNotes   FROM IFRS17PsicleData.[dbo].[DeploymentHistory]
	WHERE ReleaseNotes = (SELECT CONCAT('Sprint ', MAX(CAST(SUBSTRING(ReleaseNotes, PATINDEX('%[0-9]%', ReleaseNotes), LEN(ReleaseNotes)) AS FLOAT)))
	FROM [IFRS17PsicleData].[dbo].[DeploymentHistory])
	UNION
	SELECT 'Table8' AS TableName, Release_Version_No , DateofDeployment AS DateofDeployment  , ReleaseNotes AS ReleaseNotes  FROM [dbo].[DeploymentHistory] 
	Where Component IN ('IFRS17-ICEAutomation')
	UNION
	SELECT 'Table9' AS TableName, Release_Version_No , DateofDeployment AS DateofDeployment  , ReleaseNotes AS ReleaseNotes  FROM [dbo].[DeploymentHistory] 
	Where Component IN ('IFRS17-PPAutomation')
) AS MaxVersions;