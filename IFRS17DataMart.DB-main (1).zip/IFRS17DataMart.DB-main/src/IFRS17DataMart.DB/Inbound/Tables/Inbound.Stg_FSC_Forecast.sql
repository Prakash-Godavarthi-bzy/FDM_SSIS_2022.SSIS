﻿CREATE TABLE [Inbound].[Stg_FSC_Forecast](
	[PK_FSC_Forecast_ID] [int] IDENTITY(1,1) NOT NULL,
	[FK_AccountingPeriod] FLOAT NULL,
	[earn_qtr_prd] FLOAT NULL,
	[FK_Entity] [varchar](255) NULL,
	[FK_Trifocus] [varchar](255) NULL,
	[FK_YOA] FLOAT NULL,
	[FK_InceptionYear] FLOAT NULL,
	[QOI] datetime NULL,
	[CCYSettlement] [varchar](255) NULL,
	[FSC] FLOAT NULL,
	[IFRS17_Trifocus] [varchar](255) NULL,
	[Programme] [varchar](255) NULL,
	[RI Flag] [varchar](255) NULL,
	[FK_Account] [varchar](255) NULL,
	[FK_Scenario] [varchar](255) NULL,
	[AuditUser] [varchar](255) NOT NULL,
	[AuditCreateDatetime] [datetime2](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[PK_FSC_Forecast_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Inbound].[Stg_FSC_Forecast] ADD  DEFAULT (suser_sname()) FOR [AuditUser]
GO

ALTER TABLE [Inbound].[Stg_FSC_Forecast] ADD  DEFAULT (getdate()) FOR [AuditCreateDatetime]
GO