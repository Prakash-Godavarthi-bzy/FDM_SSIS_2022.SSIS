﻿CREATE TABLE [Inbound].[stg_FSC_EarnPrem_Prior]
(
 Id INT IDENTITY(1,1) not null
,FK_AccountingPeriod FLOAT null
,Earn_qtr_prd FLOAT null
,FK_Entity VARCHAR(255)  null
,Programme VARCHAR(255) null
,RI_Flag VARCHAR(255) null
,FK_Trifocus VARCHAR(255)  null
,FK_YOA FLOAT  null
,FK_Account VARCHAR(255)   null
,CCYOriginal VARCHAR(255)  null
,CCYSettlement VARCHAR(255)  null
,BK_PolicyNumber VARCHAR(255) null
,InceptionDate DATETIME
,ExpiryDate DATETIME
,[Value] FLOAT null
,Unearned_Perc FLOAT null
,[AuditCreateDateTime] [datetime2](7) not null DEFAULT GETDATE()
,[AuditUserCreate] [nvarchar](510) not null DEFAULT SUSER_SNAME()
)