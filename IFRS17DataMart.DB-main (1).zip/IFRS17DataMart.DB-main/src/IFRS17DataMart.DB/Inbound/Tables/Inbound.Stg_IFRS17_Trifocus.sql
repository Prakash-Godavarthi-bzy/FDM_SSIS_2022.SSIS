﻿CREATE TABLE [Inbound].[Stg_IFRS17_Trifocus](
	[PK_IFRS17_Trifocus_ID] [int] IDENTITY(1,1) NOT NULL,
	[BK_PolicyNumber] [varchar](255) NULL,
	[FK_YOA] FLOAT NULL,
	[IFRS17_Trifocus] [varchar](255) NULL,
	[AuditUser] [varchar](255) NOT NULL,
	[AuditCreateDatetime] [datetime2](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[PK_IFRS17_Trifocus_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Inbound].[Stg_IFRS17_Trifocus] ADD  DEFAULT (suser_sname()) FOR [AuditUser]
GO

ALTER TABLE [Inbound].[Stg_IFRS17_Trifocus] ADD  DEFAULT (getdate()) FOR [AuditCreateDatetime]
GO