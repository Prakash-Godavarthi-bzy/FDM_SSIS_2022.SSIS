﻿CREATE TABLE [Inbound].[Stg_FSC_Actual](
	[PK_FSC_Actual_ID] [int] IDENTITY(1,1) NOT NULL,
	[FK_AccountingPeriod] FLOAT NULL,
	[Earn_Qtr_After_Acct_Prd] FLOAT NULL,
	[FK_Entity] [varchar](255) NULL,
	[FK_Trifocus] [varchar](255) NULL,
	[FK_YOA] FLOAT NULL,
	[FK_InceptionYear] FLOAT NULL,
	[QOI] datetime NULL,
	[CCYSettlement] [varchar](255) NULL,
	[Pr_Qtr_End_Acct_Prd_Tot_Chg] [float] NULL,
	[Pr_Qtr_End_1_Acct_Prd_Tot_Chg] [float] NULL,
	[Pr_Ytd_End_Acct_Prd_Tot_Chg] [float] NULL,
	[Pr_Ytd_End_1_Acct_Prd_Tot_Chg] [float] NULL,
	[Pr_Qtr_End_Acct_Prd_FSC] FLOAT NULL,
	[Pr_Qtr_End_1_Acct_Prd_FSC] FLOAT NULL,
	[Pr_Ytd_End_Acct_Prd_Tot_FSC] FLOAT NULL,
	[Pr_Ytd_End_1_Acct_Prd_Tot_FSC] FLOAT NULL,
	[IFRS17_Trifocus] [varchar](255) NULL,
	[Programme] [varchar](255) NULL,
	[RI Flag] [varchar](255) NULL,
	[FK_Account] [varchar](255) NULL,
	[FK_Scenario] [varchar](255) NULL,
	[AuditUser] [varchar](255) NOT NULL,
	[AuditCreateDatetime] [datetime2](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[PK_FSC_Actual_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Inbound].[Stg_FSC_Actual] ADD  DEFAULT (suser_sname()) FOR [AuditUser]
GO

ALTER TABLE [Inbound].[Stg_FSC_Actual] ADD  DEFAULT (getdate()) FOR [AuditCreateDatetime]
GO