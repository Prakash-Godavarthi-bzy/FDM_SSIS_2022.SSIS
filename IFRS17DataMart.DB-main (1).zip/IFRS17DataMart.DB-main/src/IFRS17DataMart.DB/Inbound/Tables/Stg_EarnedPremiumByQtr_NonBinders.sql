﻿CREATE TABLE [Inbound].[Stg_EarnedPremiumByQtr_NonBinders] (
    [PK_EarnedPremiumByQtr_NonBinders_ID] INT           IDENTITY (1, 1) NOT NULL,
    [FK_Entity]                           VARCHAR (255) NULL,
    [FK_YOA]                              FLOAT (53)    NULL,
    [CCYSettlement]                       VARCHAR (255) NULL,
    [BK_PolicyNumber]                     VARCHAR (255) NULL,
    [InceptionDate]                       DATETIME      NULL,
    [ExpiryDate]                          DATETIME      NULL,
    [FK_Trifocus]                         VARCHAR (255) NULL,
    [Value]                               FLOAT (53)    NULL,
    [FK_Scenario]                         VARCHAR (255) NULL,
    [FK_Account]                          VARCHAR (255) NULL,
    [FK_AccountingPeriod]                 FLOAT (53)    NULL,
    [CCYOriginal]                         VARCHAR (255) NULL,
    [PolicyType]                          VARCHAR (255) NULL,
    [FK_InceptionYear]                    FLOAT (53)    NULL,
    [Earn_qtr]                            DATETIME      NULL,
    [Earned_days]                         FLOAT (53)    NULL,
    [Earned_prem]                         FLOAT (53)    NULL,
    [QOI]                                 DATETIME      NULL,
    [IFRS17_Trifocus]                     VARCHAR (255) NULL,
    [Programme]                           VARCHAR (255) NULL,
    [RI_FLAG]                             VARCHAR (255) NULL,
    [Claims Basis]                        VARCHAR (255) NULL,
    [Pol_InceptionDate]                   DATETIME      NULL,
    [Pol_ExpiryDate]                      DATETIME      NULL,
    [AuditUser]                           VARCHAR (255) DEFAULT (suser_sname()) NOT NULL,
    [AuditCreateDatetime]                 DATETIME2 (7) DEFAULT (getdate()) NOT NULL
);



