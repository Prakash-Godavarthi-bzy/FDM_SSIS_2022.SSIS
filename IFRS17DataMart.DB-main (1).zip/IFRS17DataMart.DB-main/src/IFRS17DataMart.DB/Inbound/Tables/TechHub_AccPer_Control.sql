﻿CREATE TABLE [Inbound].[TechHub_AccPer_Control] (
    [Id]                    INT IDENTITY (1, 1) NOT NULL,
    [From_AccountingPeriod] INT NULL,
    [To_AccountingPeriod]   INT NULL,
    [AsAt]                  INT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 90)
);


GO


