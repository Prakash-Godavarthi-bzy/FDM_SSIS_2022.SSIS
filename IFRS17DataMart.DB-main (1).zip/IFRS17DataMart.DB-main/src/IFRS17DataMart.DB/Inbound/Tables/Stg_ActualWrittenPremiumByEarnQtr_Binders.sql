﻿CREATE TABLE [Inbound].[Stg_ActualWrittenPremiumByEarnQtr_Binders] (
    [PK_ActualWrittenPremiumByEarnQtr_Binders_ID] INT           IDENTITY (1, 1) NOT NULL,
    [FK_Entity]                                   VARCHAR (255) NULL,
    [FK_YOA]                                      FLOAT (53)    NULL,
    [CCYSettlement]                               VARCHAR (255) NULL,
    [BK_PolicyNumber]                             VARCHAR (255) NULL,
    [FK_DataSet]                                  VARCHAR (255) NULL,
    [FK_Trifocus]                                 VARCHAR (255) NULL,
    [FK_Scenario]                                 VARCHAR (255) NULL,
    [FK_Account]                                  VARCHAR (255) NULL,
    [FK_AccountingPeriod]                         FLOAT (53)    NULL,
    [CCYOriginal]                                 VARCHAR (255) NULL,
    [PolicyType]                                  VARCHAR (255) NULL,
    [Pol_InceptionDate]                           DATETIME      NULL,
    [Pol_ExpiryDate]                              DATETIME      NULL,
    [Inc_qtr]                                     DATETIME      NULL,
    [IFRS17_Trifocus]                             VARCHAR (255) NULL,
    [Programme]                                   VARCHAR (255) NULL,
    [RI_FLAG]                                     VARCHAR (255) NULL,
    [Earn_qtr]                                    DATETIME      NULL,
    [Adj_Tot_Earn_days_v3]                        FLOAT (53)    NULL,
    [earned_prem]                                 FLOAT (53)    NULL,
    [FK_InceptionYear]                            FLOAT (53)    NULL,
    [Value]                                       FLOAT (53)    NULL,
    [AuditUser]                                   VARCHAR (255) DEFAULT (suser_sname()) NOT NULL,
    [AuditCreateDatetime]                         DATETIME2 (7) DEFAULT (getdate()) NOT NULL
);



