﻿

CREATE PROCEDURE [Inbound].[usp_Merge_StgExpectedWrittenPremium_Binders]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO IFRS17DataMart.[fct].[ExpectedWrittenPremium_Binders]
			  (
			   [FK_Entity]
			  ,[FK_YOA]
			  ,[CCYSettlement]
			  ,[BK_PolicyNumber]
			  ,[InceptionDate]
			  ,[ExpiryDate]
			  ,[FK_DataSet]
			  ,[FK_Trifocus]
			  ,[Value]
			  ,[FK_Scenario]
			  ,[FK_Account]
			  ,[FK_AccountingPeriod]
			  ,[CCYOriginal]
			  ,[PolicyType]
			  ,[FK_InceptionYear]
			  ,[Pol_len_days]
			  ,[Bind_adj_writ_prem]
			  ,[IFRS17_Trifocus]
			  ,[Programme]
			  ,[RI_FLAG]
			  ,[Claims Basis]
			  ,[RI Type]
			  ,[Pol_len_qtrs]
			  )
		SELECT 
			   [FK_Entity]
			  ,[FK_YOA]
			  ,[CCYSettlement]
			  ,[BK_PolicyNumber]
			  ,[InceptionDate]
			  ,[ExpiryDate]
			  ,[FK_DataSet]
			  ,[FK_Trifocus]
			  ,[Value]
			  ,[FK_Scenario]
			  ,[FK_Account]
			  ,[FK_AccountingPeriod]
			  ,[CCYOriginal]
			  ,[PolicyType]
			  ,[FK_InceptionYear]
			  ,[Pol_len_days]
			  ,[Bind_adj_writ_prem]
			  ,[IFRS17_Trifocus]
			  ,[Programme]
			  ,[RI_FLAG]
			  ,[Claims Basis]
			  ,[RI Type]
			  ,[Pol_len_qtrs]
		FROM Inbound.Stg_ExpectedWrittenPremium_Binders T1
		WHERE T1.FK_AccountingPeriod NOT IN (SELECT DISTINCT FK_AccountingPeriod FROM [fct].[ExpectedWrittenPremium_Binders])
		AND T1.FK_AccountingPeriod IS NOT NULL
	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END