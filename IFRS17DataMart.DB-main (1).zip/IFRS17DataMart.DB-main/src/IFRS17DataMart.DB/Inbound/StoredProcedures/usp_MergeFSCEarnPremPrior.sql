﻿CREATE PROCEDURE [Inbound].[usp_MergeFSCEarnPremPrior]
	
AS
	BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		BEGIN
		INSERT INTO [fct].[FSC_EarnPrem_Prior]
			(  [Accounting_Period]
			  ,[Earn_qtr_prd]
			  ,[FK_Entity]
			  ,[Programme]
			  ,[RI_Flag]
			  ,[FK_Trifocus]
			  ,[FK_YOA]
			  ,[Account]
			  ,[CCYOriginal]
			  ,[CCYSettlement]
			  ,[BK_PolicyNumber]
			  ,[InceptionDate]
			  ,[ExpiryDate]
			  ,[Value]
			  ,[Unearned_Perc])
		  SELECT 
			   CONVERT(INT, T1.[FK_AccountingPeriod])
			  ,CONVERT(INT, T1.[Earn_qtr_prd])
			  ,T1.[FK_Entity]
			  ,T1.[Programme]
			  ,T1.[RI_Flag]
			  ,T1.[FK_Trifocus]
			  ,CONVERT(INT, T1.[FK_YOA])
			  ,T1.[FK_Account]
			  ,T1.[CCYOriginal]
			  ,T1.[CCYSettlement]
			  ,T1.[BK_PolicyNumber]
			  ,T1.[InceptionDate]
			  ,T1.[ExpiryDate]
			  ,TRY_CAST(T1.[Value]  AS numeric(38,10))
			  ,TRY_CAST(T1.[Unearned_Perc]  AS numeric(38,10))
		  FROM [Inbound].[stg_FSC_EarnPrem_Prior] T1
		  ----LEFT JOIN [fct].[FSC_EarnPrem_Prior] T2 ON T1.Accounting_Period = T2.Accounting_Period
		  WHERE T1.[FK_AccountingPeriod] NOT IN (SELECT DISTINCT Accounting_Period FROM [fct].[FSC_EarnPrem_Prior])
		  AND T1.FK_AccountingPeriod IS NOT NULL
		END



	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END