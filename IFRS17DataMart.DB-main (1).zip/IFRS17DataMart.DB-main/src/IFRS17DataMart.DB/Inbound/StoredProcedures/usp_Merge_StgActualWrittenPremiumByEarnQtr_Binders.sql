﻿

CREATE PROCEDURE [Inbound].[usp_Merge_StgActualWrittenPremiumByEarnQtr_Binders]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO [fct].[ActualWrittenPremiumByEarnQtr_Binders]
			  (
			   [FK_Entity]
			  ,[FK_YOA]
			  ,[CCYSettlement]
			  ,[BK_PolicyNumber]
			  ,[FK_DataSet]
			  ,[FK_Trifocus]
			  ,[FK_Scenario]
			  ,[FK_Account]
			  ,[FK_AccountingPeriod]
			  ,[CCYOriginal]
			  ,[PolicyType]
			  ,[Pol_InceptionDate]
			  ,[Pol_ExpiryDate]
			  ,[Inc_qtr]
			  ,[IFRS17_Trifocus]
			  ,[Programme]
			  ,[RI_FLAG]
			  ,[Earn_qtr]
			  ,[Adj_Tot_Earn_days_v3]
			  ,[earned_prem]
			  ,[FK_InceptionYear]
			  ,[Value]
			  )
		SELECT 
			   [FK_Entity]
			  ,[FK_YOA]
			  ,[CCYSettlement]
			  ,[BK_PolicyNumber]
			  ,[FK_DataSet]
			  ,[FK_Trifocus]
			  ,[FK_Scenario]
			  ,[FK_Account]
			  ,[FK_AccountingPeriod]
			  ,[CCYOriginal]
			  ,[PolicyType]
			  ,[Pol_InceptionDate]
			  ,[Pol_ExpiryDate]
			  ,[Inc_qtr]
			  ,[IFRS17_Trifocus]
			  ,[Programme]
			  ,[RI_FLAG]
			  ,[Earn_qtr]
			  ,[Adj_Tot_Earn_days_v3]
			  ,[earned_prem]
			  ,[FK_InceptionYear]
			  ,[Value]
		FROM Inbound.Stg_ActualWrittenPremiumByEarnQtr_Binders T1
		WHERE T1.FK_AccountingPeriod NOT IN (SELECT DISTINCT FK_AccountingPeriod FROM [fct].[ActualWrittenPremiumByEarnQtr_Binders])
		AND T1.FK_AccountingPeriod IS NOT NULL
	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END