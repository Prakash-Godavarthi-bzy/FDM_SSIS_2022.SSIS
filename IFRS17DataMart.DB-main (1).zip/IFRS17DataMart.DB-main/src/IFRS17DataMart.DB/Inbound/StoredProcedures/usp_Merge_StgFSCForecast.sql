﻿

CREATE PROCEDURE [Inbound].[usp_Merge_StgFSCForecast]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO IFRS17DataMart.[fct].[FSC_Forecast]
			  (
			   [FK_AccountingPeriod]
			  ,[Earn_qtr_prd]
			  ,[FK_Entity]
			  ,[Programme]
			  ,[RI Flag]
			  ,[FK_Trifocus]
			  ,[IFRS17_Trifocus]
			  ,[FK_YOA]
			  ,[FK_InceptionYear]
			  ,[QOI]
			  ,[FK_Account]
			  ,[FK_Scenario]
			  ,[CCYSettlement]
			  ,[FSC]
			  )
		SELECT 
			   CONVERT(INT, T1.[FK_AccountingPeriod])
			  ,CONVERT(INT, T1.[earn_qtr_prd])
			  ,T1.[FK_Entity]
			  ,T1.[Programme]
			  ,T1.[RI Flag]
			  ,T1.[FK_Trifocus]
			  ,T1.[IFRS17_Trifocus]
			  ,CONVERT(INT, T1.[FK_YOA])
			  ,CONVERT(INT, T1.[FK_InceptionYear])
			  ,TRY_CAST(T1.[QOI] AS date)
			  ,T1.[FK_Account]
			  ,T1.[FK_Scenario]
			  ,T1.[CCYSettlement]
			  ,TRY_CAST(T1.[FSC] AS numeric(38,10))
		FROM [Inbound].[Stg_FSC_Forecast] T1
		----LEFT JOIN  [fct].FSC_Forecast T2 ON T1.FK_AccountingPeriod = T2.FK_AccountingPeriod
		WHERE T1.FK_AccountingPeriod NOT IN (SELECT DISTINCT FK_AccountingPeriod FROM [fct].FSC_Forecast)
		AND T1.FK_AccountingPeriod IS NOT NULL
	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END