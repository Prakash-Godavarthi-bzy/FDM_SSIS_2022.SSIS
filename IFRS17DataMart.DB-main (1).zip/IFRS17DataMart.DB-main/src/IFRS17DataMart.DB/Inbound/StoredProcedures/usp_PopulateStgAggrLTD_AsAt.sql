﻿	
CREATE PROCEDURE [Inbound].[usp_PopulateStgAggrLTD_AsAt] (@Dataset VARCHAR(255),	@AccPer INT)

AS
BEGIN

IF @Dataset IN ('ReservingData', 'Earned_RIP_RISpend')
	BEGIN
		DROP TABLE IF EXISTS #ReservingData

		SELECT 
		   T1.FK_Account 
		 , T1.FK_Entity
		 , T1.FK_Trifocus
		 , T1.IFRS17_Trifocus
		 , T1.[RI Flag]
		 , T1.Programme
		 , T1.FK_YOA
		 , T1.CCYSettlement 
		 , T1.Fk_dataset
		 , T1.FK_scenario
		 , T1.FK_inceptionyear
		 , T1.InceptionPeriod
		 , T1.FK_AccountingPeriod
		 , T1.[Value]
		 ,ROW_NUMBER() 
		  OVER (PARTITION BY 
					T1.FK_Account, T1.FK_Entity, T1.FK_Trifocus,T1.IFRS17_Trifocus , T1.[RI Flag] , T1.Programme,T1.FK_YOA, T1.CCYSettlement, 
					T1.Fk_dataset, T1.FK_scenario, T1.FK_inceptionyear, T1.InceptionPeriod ORDER BY T1.FK_AccountingPeriod DESC
			    ) RowOrder
		INTO #ReservingData
		FROM  Inbound.udf_GetAggrPremiumData (@Dataset, @AccPer) T1
		WHERE 1 = 1
		--AND T1.FK_AccountingPeriod <= @AccPer
		--AND T1.FK_Account IN ('RP-G-P', 'RP-G-B')

		BEGIN
		INSERT INTO stg.fct_AggrData(FK_Account, FK_Entity, FK_Trifocus, [IFRS17 Trifocus],[RI Flag], [RI Prog] , FK_YOA, CCYSettlement, Fk_dataset, FK_scenario, FK_inceptionyear,InceptionPeriod,FK_AccountingPeriod, [VALUE])
		SELECT FK_Account   ,FK_Entity   ,FK_Trifocus,IFRS17_Trifocus,[RI Flag],Programme   ,FK_YOA	   ,CCYSettlement    ,Fk_dataset   ,FK_scenario	   ,FK_inceptionyear   ,InceptionPeriod   ,@AccPer	   ,[Value]
		FROM #ReservingData
		WHERE RowOrder = 1
		END


	END
ELSE
	BEGIN
		DROP TABLE IF EXISTS #EverythingElse

		SELECT 
		   T1.FK_Account 
		 , T1.FK_Entity
		 , T1.FK_Trifocus
		 , T1.IFRS17_Trifocus
		 , T1.[RI Flag]
		 , T1.Programme
		 , T1.FK_YOA
		 , T1.CCYSettlement 
		 , T1.Fk_dataset
		 , T1.FK_scenario
		 , T1.FK_inceptionyear
		 , T1.InceptionPeriod
		 , T1.FK_AccountingPeriod
		 , T1.[Value]
		 ,ROW_NUMBER() 
		  OVER (PARTITION BY 
					T1.FK_Account, T1.FK_Entity, T1.FK_Trifocus,T1.IFRS17_Trifocus , T1.[RI Flag] , T1.Programme,T1.FK_YOA, T1.CCYSettlement, 
					T1.Fk_dataset, T1.FK_scenario, T1.FK_inceptionyear, T1.InceptionPeriod ORDER BY T1.FK_AccountingPeriod DESC
			    ) RowOrder
		INTO #EverythingElse
		FROM  Inbound.udf_GetAggrPremiumData (@Dataset, @AccPer) T1   
		INNER JOIN (SELECT DISTINCT A.FK_YOA, A.FK_Trifocus, A.Programme
					FROM Dim.OpenCloseYOA A
					INNER JOIN (SELECT FK_Trifocus, FK_YOA,Programme , MAX(FK_AccountingPeriod) MAX_AC
								FROM Dim.OpenCloseYOA
								WHERE 
								1 = 1
								GROUP BY FK_Trifocus, FK_YOA, Programme
								) B ON A.FK_Trifocus = B.FK_Trifocus 
									AND A.FK_YOA = B.FK_YOA 
									AND A.Programme = B.Programme
									AND A.FK_AccountingPeriod = B.MAX_AC
					WHERE A.Open_Cls_Flag = 'Closed'
				  ) T2 ON T1.FK_YOA = T2.FK_YOA AND T1.FK_Trifocus = T2.FK_Trifocus AND T1.Programme = T2.Programme
		WHERE 1 = 1
		AND T1.Fk_dataset = @Dataset
		AND T1.FK_AccountingPeriod <= @AccPer
		--AND T1.FK_Account IN ('P-GP-P', 'P-GP-B', 'P-AC-P', 'P-AC-B')

		
		BEGIN
		INSERT INTO stg.fct_AggrData(FK_Account, FK_Entity, FK_Trifocus, [IFRS17 Trifocus], [RI Flag], [RI Prog], FK_YOA, CCYSettlement, Fk_dataset, FK_scenario, FK_inceptionyear,InceptionPeriod,FK_AccountingPeriod, [VALUE])
		SELECT FK_Account   ,FK_Entity   ,FK_Trifocus, IFRS17_Trifocus, [RI Flag], Programme   ,FK_YOA	   ,CCYSettlement    ,Fk_dataset   ,FK_scenario	   ,FK_inceptionyear   ,InceptionPeriod   ,@AccPer	   ,[Value]
		FROM #EverythingElse
		WHERE RowOrder = 1
		END




		
	END

END




