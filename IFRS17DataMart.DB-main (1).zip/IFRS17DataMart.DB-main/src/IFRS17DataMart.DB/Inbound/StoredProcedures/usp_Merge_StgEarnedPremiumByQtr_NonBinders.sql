﻿

CREATE PROCEDURE [Inbound].[usp_Merge_StgEarnedPremiumByQtr_NonBinders]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO IFRS17DataMart.[fct].[EarnedPremiumByQtr_NonBinders]
			  (
			   [FK_Entity]
			  ,[FK_YOA]
			  ,[CCYSettlement]
			  ,[BK_PolicyNumber]
			  ,[InceptionDate]
			  ,[ExpiryDate]
			  ,[FK_Trifocus]
			  ,[Value]
			  ,[FK_Scenario]
			  ,[FK_Account]
			  ,[FK_AccountingPeriod]
			  ,[CCYOriginal]
			  ,[PolicyType]
			  ,[FK_InceptionYear]
			  ,[Earn_qtr]
			  ,[Earned_days]
			  ,[Earned_prem]
			  ,[QOI]
			  ,[IFRS17_Trifocus]
			  ,[Programme]
			  ,[RI_FLAG]
			  ,[Claims Basis]
			  ,[Pol_InceptionDate]
			  ,[Pol_ExpiryDate]
			  )
		SELECT 
			   [FK_Entity]
			  ,[FK_YOA]
			  ,[CCYSettlement]
			  ,[BK_PolicyNumber]
			  ,[InceptionDate]
			  ,[ExpiryDate]
			  ,[FK_Trifocus]
			  ,[Value]
			  ,[FK_Scenario]
			  ,[FK_Account]
			  ,[FK_AccountingPeriod]
			  ,[CCYOriginal]
			  ,[PolicyType]
			  ,[FK_InceptionYear]
			  ,[Earn_qtr]
			  ,[Earned_days]
			  ,[Earned_prem]
			  ,[QOI]
			  ,[IFRS17_Trifocus]
			  ,[Programme]
			  ,[RI_FLAG]
			  ,[Claims Basis]
			  ,[Pol_InceptionDate]
			  ,[Pol_ExpiryDate]
		FROM Inbound.Stg_EarnedPremiumByQtr_NonBinders T1
		WHERE T1.FK_AccountingPeriod NOT IN (SELECT DISTINCT FK_AccountingPeriod FROM [fct].[EarnedPremiumByQtr_NonBinders])
		AND T1.FK_AccountingPeriod IS NOT NULL
	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END