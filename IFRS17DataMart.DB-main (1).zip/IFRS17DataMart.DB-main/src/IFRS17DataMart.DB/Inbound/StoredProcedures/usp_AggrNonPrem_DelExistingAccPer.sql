﻿CREATE PROCEDURE [Inbound].[usp_AggrNonPrem_DelExistingAccPer] @Dataset Varchar(255), @AccPer int, @Account Varchar(50)
AS
BEGIN

SELECT 1

WHILE @@ROWCOUNT > 0
	BEGIN
		
		DELETE TOP (10000) 
		FROM [fct].[Aggr_NonPremiumLTD]
		WHERE Dataset = @Dataset
		AND AccountingPeriod = @AccPer
		AND Account = @Account

	END


END



