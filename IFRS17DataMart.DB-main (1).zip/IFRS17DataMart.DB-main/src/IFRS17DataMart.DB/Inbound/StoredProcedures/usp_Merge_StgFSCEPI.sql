﻿

CREATE PROCEDURE [Inbound].[usp_Merge_StgFSCEPI]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO IFRS17DataMart.[fct].[FSC_EPI]
			  (
			   [FK_Entity]
			  ,[FK_YOA]
			  ,[CCYOriginal]
			  ,[BK_PolicyNumber]
			  ,[InceptionDate]
			  ,[ExpiryDate]
			  ,[FK_Trifocus]
			  ,[FK_Account]
			  ,[FK_AccountingPeriod]
			  ,[CCYSettlement]
			  ,[Programme]
			  ,[RI_Flag]
			  ,[Value]
			  )
		SELECT 
			   T1.[FK_Entity]
			  ,CONVERT(INT, T1.[FK_YOA])
			  ,T1.[CCYOriginal]
			  ,T1.[BK_PolicyNumber]
			  ,TRY_CAST(T1.[InceptionDate] AS date)
			  ,TRY_CAST(T1.[ExpiryDate] AS date)
			  ,T1.[FK_Trifocus]
			  ,T1.[FK_Account]
			  ,CONVERT(INT,T1.[FK_AccountingPeriod])
			  ,T1.[CCYSettlement]
			  ,T1.[Programme]
			  ,T1.[RI_Flag]
			  ,TRY_CAST(T1.[Value] AS numeric(38,10))
		FROM [Inbound].[Stg_FSC_EPI] T1
		--LEFT JOIN  [fct].FSC_EPI T2 ON T1.FK_AccountingPeriod = T2.FK_AccountingPeriod
		WHERE T1.FK_AccountingPeriod NOT IN (SELECT DISTINCT FK_AccountingPeriod FROM [fct].FSC_EPI)
		AND T1.FK_AccountingPeriod IS NOT NULL
	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END