﻿

CREATE PROCEDURE [Inbound].[usp_Merge_StgAggregatePremiumLTD]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO IFRS17DataMart.[fct].Aggr_PremiumLTD
			  ([Entity]
			  ,[Trifocus]
			  ,[IFRS17 Trifocus]
			  ,[RI Prog]
			  ,[RI Flag]
			  ,[CCYSettlement]
			  ,[Dataset]
			  ,[Scenario]
			  ,[Account]
			  ,[AccountingPeriod]
			  ,[YOA]
			  ,[YOI]
			  ,[MOI]
			  ,[Value]
			  )
		SELECT 
			   T1.[FK_Entity]
			  ,T1.[FK_Trifocus]
			  ,T1.[IFRS17_Trifocus]
			  ,T1.[Programme]
			  ,T1.[RI_FLAG]
			  ,T1.[CCYSettlement]
			  ,T1.[FK_DataSet]
			  ,T1.[FK_Scenario]
			  ,T1.[FK_Account]
			  ,CONVERT(INT, T1.[FK_AccountingPeriod]) AS [FK_AccountingPeriod]
			  ,CONVERT(VARCHAR(10),T1.[FK_YOA]) AS [FK_YOA]
			  ,CONVERT(INT,T1.[FK_InceptionYear])
			  ,CONVERT(INT,CONCAT(CAST(YEAR(T1.[Inc_mth]) AS varchar(4))  ,RIGHT(CONCAT('00',CAST(MONTH(T1.[Inc_mth]) AS varchar(2))),2))) MOI
			  ,CONVERT(FLOAT,T1.[Value])[Value]
		FROM [Inbound].[Stg_Aggregate_PremiumLTD] T1
		----LEFT JOIN [fct].Aggr_PremiumLTD T2 ON T1.FK_AccountingPeriod = T2.AccountingPeriod
		WHERE T1.FK_AccountingPeriod NOT IN (SELECT DISTINCT AccountingPeriod FROM [fct].Aggr_PremiumLTD)
		AND T1.FK_AccountingPeriod IS NOT NULL

	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END