﻿CREATE PROCEDURE [Inbound].[AggrNonPrem_DelExistingAccPer] @Dataset Varchar(255), @AccPer int
AS
BEGIN

SELECT 1

WHILE @@ROWCOUNT > 0
	BEGIN
		
		DELETE TOP (10000) 
		FROM [fct].[Aggr_NonPremiumLTD]
		WHERE Dataset = @Dataset
		AND AccountingPeriod = @AccPer

	END


END