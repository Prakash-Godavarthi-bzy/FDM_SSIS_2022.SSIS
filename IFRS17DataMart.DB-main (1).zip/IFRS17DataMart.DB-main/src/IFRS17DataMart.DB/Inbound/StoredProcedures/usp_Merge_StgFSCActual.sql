﻿

CREATE PROCEDURE [Inbound].[usp_Merge_StgFSCActual]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO IFRS17DataMart.[fct].[FSC_Actual]
			  (
			   [FK_AccountingPeriod]
			  ,[Earn_Qtr_After_Acct_Prd]
			  ,[FK_Entity]
			  ,[FK_Trifocus]
			  ,[FK_YOA]
			  ,[FK_InceptionYear]
			  ,[QOI]
			  ,[CCYSettlement]
			  ,[Pr_Qtr_End_Acct_Prd_Tot_Chg]
			  ,[Pr_Qtr_End-1_Acct_Prd_Tot_Chg]
			  ,[Pr_Ytd_End_Acct_Prd_Tot_Chg]
			  ,[Pr_Ytd_End-1_Acct_Prd_Tot_Chg]
			  ,[Pr_Qtr_End_Acct_Prd_FSC]
			  ,[Pr_Qtr_End-1_Acct_Prd_FSC]
			  ,[Pr_Ytd_End_Acct_Prd_Tot_FSC]
			  ,[Pr_Ytd_End-1_Acct_Prd_Tot_FSC]
			  ,[IFRS17_Trifocus]
			  ,[Programme]
			  ,[RI Flag]
			  ,[FK_Account]
			  ,[FK_Scenario]
			  )
		SELECT 
			   CONVERT(INT, T1.[FK_AccountingPeriod]) 
			  ,CONVERT(INT, T1.[Earn_Qtr_After_Acct_Prd])
			  ,T1.[FK_Entity]
			  ,T1.[FK_Trifocus]
			  ,CONVERT(INT, T1.[FK_YOA])
			  ,CONVERT(INT, T1.[FK_InceptionYear])
			  ,T1.[QOI]
			  ,T1.[CCYSettlement]
			  ,T1.[Pr_Qtr_End_Acct_Prd_Tot_Chg]
			  ,T1.[Pr_Qtr_End_1_Acct_Prd_Tot_Chg]
			  ,T1.[Pr_Ytd_End_Acct_Prd_Tot_Chg]
			  ,T1.[Pr_Ytd_End_1_Acct_Prd_Tot_Chg]
			  ,T1.[Pr_Qtr_End_Acct_Prd_FSC]
			  ,T1.[Pr_Qtr_End_1_Acct_Prd_FSC]
			  ,T1.[Pr_Ytd_End_Acct_Prd_Tot_FSC]
			  ,T1.[Pr_Ytd_End_1_Acct_Prd_Tot_FSC]
			  ,T1.[IFRS17_Trifocus]
			  ,T1.[Programme]
			  ,T1.[RI Flag]
			  ,T1.[FK_Account]
			  ,T1.[FK_Scenario]
		FROM [Inbound].[Stg_FSC_Actual] T1
		----LEFT JOIN  [fct].FSC_Actual T2 ON T1.FK_AccountingPeriod = T2.FK_AccountingPeriod
		WHERE T1.FK_AccountingPeriod NOT IN (SELECT DISTINCT FK_AccountingPeriod FROM [fct].FSC_Actual)
		AND T1.FK_AccountingPeriod IS NOT NULL
	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END