﻿CREATE PROCEDURE [Inbound].[usp_AggrPrem_DelExistingAccPer] @Dataset Varchar(255), @AccPer int
AS
BEGIN

SELECT 1

WHILE @@ROWCOUNT > 0
	BEGIN
		
		DELETE TOP (20000) 
		FROM [fct].[Aggr_PremiumLTD]
		WHERE Dataset = @Dataset
		AND AccountingPeriod = @AccPer

	END


END



