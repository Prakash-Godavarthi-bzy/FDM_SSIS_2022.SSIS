﻿

CREATE PROCEDURE [Inbound].[usp_Merge_StgOpenCloseYOA]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO IFRS17DataMart.[Dim].[OpenCloseYOA]
			  (
			   FK_AccountingPeriod
			  ,[FK_YOA]
			  ,FK_Trifocus
			  ,Open_Cls_Flag
			  ,Programme
			  )
		SELECT 
			   CONVERT(INT, T1.FK_AccountingPeriod)
			  ,CONVERT(INT, T1.[FK_YOA])
			  ,T1.FK_Trifocus
			  ,T1.Open_Close_flag
			  ,T1.Programme
		FROM [Inbound].[Stg_OpenClosedYOA] T1
		----LEFT JOIN [Dim].[OpenCloseYOA] T2 ON T1.FK_AccountingPeriod = T2.FK_AccountingPeriod
		WHERE T1.FK_AccountingPeriod NOT IN (SELECT DISTINCT FK_AccountingPeriod FROM [Dim].[OpenCloseYOA])
		AND T1.FK_AccountingPeriod IS NOT NULL
	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END
