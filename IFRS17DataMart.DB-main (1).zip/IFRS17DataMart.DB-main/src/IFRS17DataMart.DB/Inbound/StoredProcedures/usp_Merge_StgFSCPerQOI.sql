﻿

CREATE PROCEDURE [Inbound].[usp_Merge_StgFSCPerQOI]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO IFRS17DataMart.[fct].[FSC_Per_QOI]
			  (
				 [FK_AccountingPeriod]
				,[Earning Category]
				,[FK_Scenario]
				,[Programme]
				,[FK_Trifocus]
				,[FK_InceptionYear]
				,[QOI]
				,[CCYSett]
				,[Earn_qtr]
				,[Pattern]
			  )
		SELECT 
			   CONVERT(INT, T1.[FK_AccountingPeriod])
			  ,T1.[Earning_Category]
			  ,T1.[FK_Scenario]
			  ,T1.[Programme]
			  ,T1.[FK_Trifocus]
			  ,CONVERT(INT, T1.[FK_InceptionYear])
			  ,T1.[QOI]
			  ,T1.[CCYSettlement]
			  ,T1.[Earn_qtr]
			  ,TRY_CAST(T1.[Pattern] AS numeric(38,10))
		FROM [Inbound].[Stg_FSC_Per_QOI] T1
		----LEFT JOIN  [fct].[FSC_Per_QOI] T2 ON T1.FK_AccountingPeriod = T2.FK_AccountingPeriod
		WHERE T1.FK_AccountingPeriod NOT IN (SELECT DISTINCT FK_AccountingPeriod FROM [fct].FSC_Per_QOI)
		AND T1.FK_AccountingPeriod IS NOT NULL
	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END