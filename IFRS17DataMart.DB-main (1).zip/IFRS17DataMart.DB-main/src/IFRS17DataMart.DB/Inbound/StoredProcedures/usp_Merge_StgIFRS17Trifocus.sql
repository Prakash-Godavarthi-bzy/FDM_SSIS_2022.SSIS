﻿

CREATE PROCEDURE [Inbound].[usp_Merge_StgIFRS17Trifocus]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO IFRS17DataMart.[Dim].[IFRS17_Trifocus]
			  (
			   [BK_PolicyNumber]
			  ,[FK_YOA]
			  ,[IFRS17_Trifocus]
			  ,[FK_AccountingPeriod]
			  )
		SELECT 
			   T1.[BK_PolicyNumber]
			  ,CONVERT(INT, T1.[FK_YOA])
			  ,T1.IFRS17_Trifocus
			  ,(SELECT AccountingPeriod FROM Outbound.AccPer_AsAt_Control)
		FROM (SELECT * FROM [Inbound].[Stg_IFRS17_Trifocus] WHERE BK_PolicyNumber IS NOT NULL AND FK_YOA IS NOT NULL AND IFRS17_Trifocus IS NOT NULL)T1
		LEFT JOIN IFRS17DataMart.[Dim].[IFRS17_Trifocus] T2 ON T1.BK_PolicyNumber = T2.BK_PolicyNumber 
															AND T1.FK_YOA = T2.FK_YOA
		WHERE T2.BK_PolicyNumber IS NULL
		AND T2.[FK_YOA] IS NULL

	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END