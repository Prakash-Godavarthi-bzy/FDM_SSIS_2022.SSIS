﻿

CREATE PROCEDURE [Inbound].[usp_Merge_StgEarningsForGrossNonRadAndRadProg]
AS

BEGIN
	DECLARE @Trancount INT = @@Trancount
	BEGIN TRY
		IF @Trancount = 0 BEGIN TRAN;

		INSERT INTO IFRS17DataMart.[fct].[EarningsForGrossNonRadAndRadProg]
			  (
			   [FK_AccountingPeriod]
				,[FK_Entity]
				,[FK_YOA]
				,[CCYSettlement]
				,[BK_PolicyNumber]
				,[InceptionDate]
				,[ExpiryDate]
				,[FK_Trifocus]
				,[FK_Scenario]
				,[FK_Account]
				,[CCYOriginal]
				,[PolicyType]
				,[Earn_qtr]
				,[QOI]
				,[IFRS17_Trifocus]
				,[Programme]
				,[RI_FLAG]
				,[Claims_Basis]
				,[Pol_InceptionDate]
				,[Pol_ExpiryDate]
				,[FK_InceptionYear]
				,[Earned_prem]
				,[Value]
			  )
		SELECT 
			CONVERT(INT,FK_AccountingPeriod)
			,CONVERT(VARCHAR(25), FK_Entity	)
			,CONVERT(INT,FK_YOA)
			,CONVERT(VARCHAR(10), CCYSettlement	)
			,CONVERT(VARCHAR(50), BK_PolicyNumber)
			,TRY_CAST(InceptionDate AS date)
			,TRY_CAST(ExpiryDate AS date)
			,CONVERT(VARCHAR(25), FK_Trifocus)
			,CONVERT(VARCHAR(10), FK_Scenario)
			,CONVERT(VARCHAR(25), FK_Account)
			,CONVERT(VARCHAR(10), CCYOriginal)
			,CONVERT(VARCHAR(50), PolicyType)
			,TRY_CAST(Earn_qtr AS date)	
			,TRY_CAST(QOI	 AS date)
			,CONVERT(VARCHAR(25), IFRS17_Trifocus)
			,CONVERT(VARCHAR(100), Programme)
			,CONVERT(VARCHAR(2), RI_FLAG)
			,CONVERT(VARCHAR(50), Claims_Basis)	
			,TRY_CAST(Pol_InceptionDate AS date)
			,TRY_CAST(Pol_ExpiryDate AS date)
			,CONVERT(INT,FK_InceptionYear)
			,TRY_CAST(Earned_prem	 AS numeric(38,12))
			,TRY_CAST([Value] AS numeric(38,12))
		FROM [Inbound].[Stg_EarningsForGrossNonRadAndRadProg] T1
		WHERE T1.FK_AccountingPeriod NOT IN (SELECT DISTINCT FK_AccountingPeriod FROM fct.EarningsForGrossNonRadAndRadProg)
		AND T1.FK_AccountingPeriod IS NOT NULL
	IF @Trancount = 0 COMMIT;
	END TRY
	BEGIN CATCH
		IF @Trancount = 0 ROLLBACK;
		THROW;
	END CATCH

END