CREATE PROCEDURE [fct].[usp_IDSAccCodeMapping] @RequestId INT
AS
BEGIN

IF NOT EXISTS(
select runid from
[IDS].[AccountCodeMapping]
where runid=@RequestId
)

BEGIN

--Truncate table [IFRS17DataMart].[IDS].[AccountCodeMapping]
--Set @RunId=(select isnull(Max(RunId),0) from [IFRS17DataMart].[IDS].[AccountCodeMapping])
INSERT INTO [IDS].[AccountCodeMapping]
([RunID],
[Account Code] ,
[Type],
[Source],
[Field Label])
SELECT
s.Pk_RequestId,
a.AccountCode,
a.[Type],
a.[Source],
a.[FieldLabel]
FROM
[Dim].[AccountCodeMapping] a 
INNER JOIN PWAPS.IFRS17CalcUI_RunLog s ON a.AssumptionDatasetNameID=s.AccountCodeMappingId 
WHERE a.IsActive='1'
AND s.Pk_RequestId=@RequestId
END
END