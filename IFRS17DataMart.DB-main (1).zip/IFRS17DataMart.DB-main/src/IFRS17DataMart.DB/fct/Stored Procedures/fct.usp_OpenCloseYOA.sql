CREATE PROCEDURE [fct].[usp_OpenCloseYOA](@RequestId int)
AS
BEGIN
	IF NOT EXISTS(
				SELECT RunId 
				FROM [IDS].[Open_CloseYOA]
				WHERE RunId=@RequestId
				)
	BEGIN 
		INSERT into [IDS].[Open_CloseYOA]
		([RunId],
		[Programme],
		[TrifocusCode],
		[YOA],
		[Open/Closed],
		[AuditCreateDateTime],
		[AuditUserCreate],
		[ValidFrom],
		[ValidTo]
		)
		SELECT @Requestid AS Pk_RequestId
		  ,Y.[Programme]
		  ,Y.[FK_Trifocus]
		  ,Y.[FK_YOA]
		  ,Y.[Open_Cls_Flag]
		  ,Y.[AuditCreateDateTime]
		  ,Y.[AuditUserCreate]
		  ,Y.[ValidFrom]
		  ,Y.[ValidTo]
		   FROM 
		   (SELECT  A.FK_YOA, A.FK_Trifocus, A.Programme ,Open_Cls_Flag,AuditCreateDateTime,AuditUserCreate,ValidFrom, ValidTo
			FROM DIM.OpenCloseYOA A
			INNER JOIN (SELECT FK_Trifocus, FK_YOA,Programme , MAX(FK_AccountingPeriod) MAX_AC
						FROM DIM.OpenCloseYOA
						WHERE 
						1 = 1
						AND  CONVERT(DATE,FK_AccountingPeriod+'01') >= 
								(SELECT DATEADD(QUARTER, DATEDIFF(QUARTER, 0, CONVERT(DATE,[SM Reporting Period Actual]+'01')) , 0) FROM PWAPS.IFRS17CalcUI_RunLog  WHERE Pk_RequestId = @Requestid)
						GROUP BY FK_Trifocus, FK_YOA, Programme
						) B ON A.FK_Trifocus = B.FK_Trifocus 
							AND A.FK_YOA = B.FK_YOA 
							AND A.Programme = B.Programme
							AND A.FK_AccountingPeriod = B.MAX_AC) Y     
	END
END