﻿CREATE Procedure [fct].[usp_IDSNatCatEarningPattern]  @RequestId INT
AS
--declare @RequestId INT = 3673

BEGIN
IF NOT EXISTS(
SELECT Runid 
FROM [IDS].[NatCat_EarningPatterns]
WHERE Runid = @RequestId
)
BEGIN
INSERT INTO [IDS].[NatCat_EarningPatterns]
           (
		   [RunID]
           ,[Pat_Type]
           ,[Loss_Type]
           ,[Tri Focus Code]
           ,[YOA]
           ,[Qtr]
           ,[Perc]
           ---,[AuditCreateDateTime]
           ---,[AuditUserCreate]
		   )
Select 
	     S.[Pk_RequestId],
		'E' AS Pat_type,
         'C' AS Loss_type,
		  A.[TriFocus],
          A.[YOA],
		 CAST(DATEADD(DD,-1,DATEADD(QQ,DATEDIFF(QQ,0,DATEADD(Q,PP_DevelopmentQuarter,CONVERT(DATE,CONCAT(YOA,'01','01')))),0)) AS DATE) AS Qt,
		A.[Value]
       --- GETDATE() AS AuditCreateDateTime,
        ---SUSER_SNAME() AS AuditUserCreate
  FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog S
INNER JOIN [IFRS17DataMart].dim.AssumptionDatasets D ON S.[Earning Pattern (Nat Cat)] = D.AssumptionDatasetName
INNER JOIN [IFRS17DataMart].[fct].[AssumptionData] A ON D.Pk_AssumptionDatasetNameId = A.Pk_AssumptionDatasetNameId
WHERE S.Pk_RequestId = @RequestId
END
END

