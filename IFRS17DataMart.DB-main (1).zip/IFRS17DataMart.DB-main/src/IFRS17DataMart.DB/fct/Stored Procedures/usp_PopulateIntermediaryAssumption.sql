﻿
--DECLARE @RequestId INT = 3943

CREATE PROCEDURE [fct].[usp_PopulateIntermediaryAssumption] @RequestId INT
AS
BEGIN

	SET NOCOUNT ON; 

	BEGIN

		DROP TABLE IF EXISTS #ColumnStructure
		SELECT T1.Pk_RequestId, T2.Pk_AssumptionDatasetNameId, T1.ColumnName, T2.AssumptionPercentageTypeId, T1.ColumnType
		INTO #ColumnStructure
		FROM [IDS].[udf_GetGrossRIColumns] (@RequestId) T1
		INNER JOIN [IFRS17DataMart].dim.AssumptionDatasets T2 ON T1.DatasetName = T2.AssumptionDatasetName
		LEFT JOIN IDS.AssumptionPercentages T3 ON T1.Pk_RequestId = T3.Pk_RequestId
		WHERE T3.Pk_RequestId IS NULL


		--SELECT * FROM #ColumnStructure where AssumptionPercentageTypeId in (9,55)

		DROP TABLE IF EXISTS #Gross
		SELECT  
				  T1.Pk_RequestId
				, T4.YOA
				, T4.TriFocus
				, T2.Pk_AssumptionDatasetNameId AS DatasetNameId
				, T3.Pk_AssumptionPercentageTypeId AS PercentageTypeId
				--, CASE TRIM(T3.AssumptionPercentageType)
				--      WHEN 'ENIDs (Earned)'  Then 'E'
				--      WHEN 'ENIDs (Unearned)' THEN 'U' 
				--      ELSE T4.PK_LossType 
				--END PK_LossType
				,T4.PK_LossType  as PK_LossType
				,T4.Entity
				,T4.[Gross/RI Flag]
				,T4.Programme As RIProgramme
				,T4.[Focus Group]
				, CASE WHEN CHARINDEX('Q', T1.ColumnName COLLATE  latin1_general_cs_as) = 0 
					   THEN 'SM' 
					   ELSE SUBSTRING(T1.ColumnName, CHARINDEX('Q', T1.ColumnName COLLATE  latin1_general_cs_as), 2) 
				   END Quarters
				, T4.[Value] GeneralPercent
				
		INTO #Gross
		FROM #ColumnStructure T1
		INNER JOIN [IFRS17DataMart].dim.AssumptionDatasets T2 ON T1.Pk_AssumptionDatasetNameId  = T2.Pk_AssumptionDatasetNameId
		INNER JOIN [IFRS17DataMart].dim.AssumptionPercentageType T3 ON T1.AssumptionPercentageTypeId = T3.Pk_AssumptionPercentageTypeId
		INNER JOIN [IFRS17DataMart].FCT.AssumptionData T4 ON T2.AssumptionPercentageTypeId = T4.Pk_AssumptionPercentageTypeId AND T2.Pk_AssumptionDatasetNameId = T4.Pk_AssumptionDatasetNameId
		WHERE 
		1 = 1
		AND T4.WB_TYPE = 'AD'
		AND CASE WHEN TRIM(T3.AssumptionPercentageType) IN ('Premium Lapse Risk','Expenses (Claims Handling)','Expenses (Admin Other)','Expenses (Other Acquisition)')
				 THEN 'G'
				 ELSE T4.[Gross/RI Flag] 
			END  = 'G'
		AND T1.ColumnType = 'GR'

		DROP TABLE IF EXISTS #ReInsurance
		SELECT  
				  T1.Pk_RequestId
				, T4.YOA
				, T4.TriFocus
				, T2.Pk_AssumptionDatasetNameId AS DatasetNameId
				, T3.Pk_AssumptionPercentageTypeId AS PercentageTypeId
				--, CASE TRIM(T3.AssumptionPercentageType)
				--      WHEN 'ENIDs (Earned)'  Then 'E'
				--      WHEN 'ENIDs (Unearned)' THEN 'U' 
				--      ELSE T4.PK_LossType 
				--END PK_LossType
				,T4.PK_LossType  as PK_LossType
				,T4.Entity
				,T4.[Gross/RI Flag]
				,T4.Programme As RIProgramme
				,T4.[Focus Group]
				, CASE WHEN CHARINDEX('Q', T1.ColumnName COLLATE  latin1_general_cs_as) = 0 
					   THEN 'SM' 
					   ELSE SUBSTRING(T1.ColumnName, CHARINDEX('Q', T1.ColumnName COLLATE  latin1_general_cs_as), 2) 
				   END Quarters
				, T4.[Value] GeneralPercent
				
		INTO #ReInsurance
		FROM #ColumnStructure T1
		INNER JOIN [IFRS17DataMart].dim.AssumptionDatasets T2 ON T1.Pk_AssumptionDatasetNameId  = T2.Pk_AssumptionDatasetNameId
		INNER JOIN [IFRS17DataMart].dim.AssumptionPercentageType T3 ON T1.AssumptionPercentageTypeId = T3.Pk_AssumptionPercentageTypeId
		INNER JOIN [IFRS17DataMart].FCT.AssumptionData T4 ON T2.AssumptionPercentageTypeId = T4.Pk_AssumptionPercentageTypeId AND T2.Pk_AssumptionDatasetNameId = T4.Pk_AssumptionDatasetNameId 
		WHERE 
		1 = 1
		AND T4.WB_TYPE = 'AD'
		AND CASE WHEN TRIM(T3.AssumptionPercentageType) IN ('RI Admin')
				 THEN 'R'
				 ELSE T4.[Gross/RI Flag] 
			END  = 'R'
		AND T1.ColumnType = 'RI'


		DROP TABLE IF EXISTS #Global
		SELECT  
				  T1.Pk_RequestId
				, T4.YOA
				, T4.TriFocus
				, T2.Pk_AssumptionDatasetNameId AS DatasetNameId
				, T3.Pk_AssumptionPercentageTypeId AS PercentageTypeId
				--, CASE TRIM(T3.AssumptionPercentageType)
				--      WHEN 'ENIDs (Earned)'  Then 'E'
				--      WHEN 'ENIDs (Unearned)' THEN 'U' 
				--      ELSE T4.PK_LossType 
				--END PK_LossType
				,T4.PK_LossType  as PK_LossType
				,T4.Entity
				,T4.[Gross/RI Flag]
				,T4.Programme As RIProgramme
				,T4.[Focus Group]
				, CASE WHEN CHARINDEX('Q', T1.ColumnName COLLATE  latin1_general_cs_as) = 0 
					   THEN 'SM' 
					   ELSE SUBSTRING(T1.ColumnName, CHARINDEX('Q', T1.ColumnName COLLATE  latin1_general_cs_as), 2) 
				   END Quarters
				, T4.[Value] GeneralPercent
				
		INTO #Global
		FROM #ColumnStructure T1
		INNER JOIN [IFRS17DataMart].dim.AssumptionDatasets T2 ON T1.Pk_AssumptionDatasetNameId  = T2.Pk_AssumptionDatasetNameId
		INNER JOIN [IFRS17DataMart].dim.AssumptionPercentageType T3 ON T1.AssumptionPercentageTypeId = T3.Pk_AssumptionPercentageTypeId
		INNER JOIN [IFRS17DataMart].FCT.AssumptionData T4 ON T2.AssumptionPercentageTypeId = T4.Pk_AssumptionPercentageTypeId AND T2.Pk_AssumptionDatasetNameId = T4.Pk_AssumptionDatasetNameId 
		WHERE 
		1 = 1
		AND T4.WB_TYPE = 'AD'
		AND T1.ColumnType = 'GL'	

	--SELECT * FROM #Gross WHERE DatasetNameId = 1895 AND PercentageTypeId = 6 AND Quarters = 'Q2'

	--SELECT * FROM #ReInsurance WHERE DatasetNameId = 1895 AND PercentageTypeId = 6 AND Quarters = 'Q2'

		------INSERT ------------------------


		INSERT INTO [IDS].[AssumptionPercentages]([Pk_RequestId],[PK_YOA_3],[PK_TriFocus_4],[DatasetNameId], PercentageTypeId, LossType,Entity,RIFlag,RIProgramme,[Focus Group],Quarters,GeneralPercent_0 )
		(
		SELECT  Pk_RequestId, YOA, TriFocus, DatasetNameId, PercentageTypeId, PK_LossType, Entity,CASE WHEN [Gross/RI Flag]='G' THEN 'I' WHEN [Gross/RI Flag]='R' THEN 'O' ELSE [Gross/RI Flag] END AS [Gross/RI Flag], RIProgramme, [Focus Group], Quarters, GeneralPercent
		FROM
			(
			SELECT  Pk_RequestId, YOA, TriFocus, DatasetNameId, PercentageTypeId, PK_LossType, Entity, [Gross/RI Flag], RIProgramme, [Focus Group], Quarters, GeneralPercent FROM #Gross 
			UNION ALL
			SELECT  Pk_RequestId, YOA, TriFocus, DatasetNameId, PercentageTypeId, PK_LossType, Entity, [Gross/RI Flag], RIProgramme, [Focus Group], Quarters, GeneralPercent FROM #ReInsurance  
			UNION ALL
			SELECT  Pk_RequestId, YOA, TriFocus, DatasetNameId, PercentageTypeId, PK_LossType, Entity, [Gross/RI Flag], RIProgramme, [Focus Group], Quarters, GeneralPercent FROM #Global 

			)A
	
		)

    END

DROP TABLE IF EXISTS #ColumnStructure
DROP TABLE IF EXISTS #Gross	
DROP TABLE IF EXISTS #ReInsurance
DROP TABLE IF EXISTS #Global
END
