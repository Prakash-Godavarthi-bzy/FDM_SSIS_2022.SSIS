﻿CREATE PROCEDURE [fct].[usp_Populate_ADJ_IDSCashBalances] @RequestId INT
As

BEGIN


IF NOT EXISTS(select [RunID] from [IDS].[Aggr_CashExcludingClaims] where runid = @RequestId AND Adjust_Flag = 'A') 

BEGIN
IF EXISTS(SELECT Adjustments FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog WHERE Pk_RequestId = @RequestId)

	BEGIN
		INSERT INTO [IDS].[Aggr_CashExcludingClaims]
		(RunID,Entity,[Tri focus code],Account,Programme,RI_Flag,YOA,CCY,Amount,Adjust_Flag,AuditCreateDateTime,AuditUserCreate)

		SELECT 
			Pk_RequestId
			  ,[Entity]
			  ,[Trifocus]
			  ,[Account]
			  ,Programme
			  --,[Gross/RI Flag]
			  ,CASE WHEN [Gross/RI Flag]='G' THEN 'I' WHEN [Gross/RI Flag]='R' THEN 'O' ELSE [Gross/RI Flag] END AS [Gross/RI Flag]
			  ,YOA AS YOA
			  ,CCY AS CCY
			  ,SUM([Value]) AS Amount
			  ,'A' as Adjust_Flag
			  ,GETDATE() AS AuditCreateDateTime
			  ,SUSER_SNAME() AS AuditUserCreate
	 
			  FROM [IFRS17DataMart].Dim.AssumptionDatasets A
		--FROM TechnicalHub.Fct.All_WB_Committed T
		INNER JOIN [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog T1 ON T1.Adjustments=A.AssumptionDatasetName
		INNER JOIN [IFRS17DataMart].Fct.AssumptionData W ON A.Pk_AssumptionDatasetNameId=W.Pk_AssumptionDatasetNameId
		INNER JOIN IFRS17DataMart.Dim.AccountCodeMapping T2 ON W.Account=T2.AccountCode
		WHERE t1.Pk_RequestId = @RequestId--2940
		  AND T2.IsActive=1
		  AND T2.Type in ('Cash')
		  --AND T2.AccountCode IN ('PC-LS-OT','PC-OS-OT','PC-SD-OT','BC-LS-OT','BC-OS-OT','BC-SD-OT','PC-LS-PC','PC-SD-PC')


		  GROUP BY 
			   T1.Pk_RequestId
			  ,[Entity]
			  ,[Trifocus]
			  ,[Account]
			  ,Programme
			  ,[Gross/RI Flag]
			  ,YOA
			  ,CCY
		END
	END

END
GO

