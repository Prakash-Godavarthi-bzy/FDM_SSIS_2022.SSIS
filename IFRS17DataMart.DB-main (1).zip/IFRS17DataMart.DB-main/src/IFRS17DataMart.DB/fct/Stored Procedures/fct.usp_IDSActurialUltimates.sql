CREATE  PROCEDURE  fct.usp_IDSActurialUltimates @RequestId INT
AS
BEGIN


IF NOT EXISTS(
select RunID from
[IDS].[Aggr_ActurialUltimates]
where runid=@RequestId
)

	BEGIN
		INSERT INTO [IDS].[Aggr_ActurialUltimates]
		(RunID,Entity,[Tri focus code],[Account],[Type],[Programme],[RI_Flag],[Loss_Type],[YOA],[YOI],CCY,Amount,EventDate,AuditCreateDateTime,AuditUserCreate)

		SELECT
			T1.Pk_RequestId
			,Entity
			,Trifocus
			, Account
			,T.[Type]
			,[RI Prog]
			,[RI Flag]
			,[Loss Type]
			,YOA
			,YOI
			,CCYSettlement as CCY
			,SUM([Value]) as Amount
			,EventDate
			,GETDATE() as AuditCreateDateTime
			,SUSER_SNAME() as AuditUserCreate
		FROM [fct].[Aggr_NonPremiumLTD] T
		INNER JOIN PWAPS.IFRS17CalcUI_RunLog T1 ON T.AccountingPeriod= CAST(T1.[ADM] AS INT)
		INNER JOIN Dim.AccountCodeMapping T2 ON T.Account=T2.AccountCode
		WHERE Pk_RequestId=@RequestId
		AND T2.IsActive=1
		AND T2.[Type] IN ('Ultimates')
		--AND T2.AccountCode  IN ('GC-P-AC', 'GC-P-CM', 'GC-P-LL', 'GC-T-AC','GC-T-CM', 'GC-T-LL')
		GROUP BY
			T1.Pk_RequestId
			,[Entity]
			,[Trifocus]
			,[Account]
			,T.[Type]
			,[RI Prog]
			,[RI Flag]
			,[Loss Type]
			,YOA
			,YOI
			,CCYSettlement
			,EventDate
	END
END
GO

