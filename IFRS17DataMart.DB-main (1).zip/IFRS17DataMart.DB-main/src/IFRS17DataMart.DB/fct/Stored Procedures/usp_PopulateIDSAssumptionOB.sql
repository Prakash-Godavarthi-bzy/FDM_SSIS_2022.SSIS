﻿CREATE  Procedure  [fct].[usp_PopulateIDSAssumptionOB] (@RunId Int)
AS
BEGIN
IF NOT EXISTS(SELECT 1 FROM IFRS17DataMart.IDS.AssumptionOB WHERE RunID = @RunId)
	BEGIN
	INSERT INTO IFRS17DataMart.IDS.AssumptionOB(
			 RunID           
			,Entity          
			,[Tri Focus Code]
			,Programme       
			,RI_Flag         
			,Assumption      
			,Loss_Type                 
			,YOA             
			,Qtr             
			,Perc            

			)
	SELECT 					
			    T2.Pk_RequestId		
			   ,T1.Entity 			
			   ,T1.[Tri Focus Code]
			   ,T1.Programme 		
			   ,T1.RI_Flag 		
			   ,T1.Assumption 		
			   ,T1.Loss_Type 			
			   ,T1.YOA 			
			   ,T1.Qtr 			
			   ,T1.Perc 			

			  
		FROM [IFRS17PsicleData].Results.AssumptionOB T1
	INNER JOIN IFRS17DataMart.PWAPS.IFRS17CalcUI_RunLog T2 ON T1.RunID = T2.[Opening Balances Id]
	WHERE T2.Pk_RequestId = @RunId
	END

END