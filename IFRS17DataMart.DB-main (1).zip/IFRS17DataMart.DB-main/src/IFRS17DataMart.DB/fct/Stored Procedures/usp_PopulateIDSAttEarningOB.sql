﻿CREATE  Procedure  [fct].[usp_PopulateIDSAttEarningOB] (@RunId Int)
AS
BEGIN
IF NOT EXISTS(SELECT 1 FROM IFRS17DataMart.IDS.[AttEarningOB] WHERE RunID = @RunId)
	BEGIN
	INSERT INTO IFRS17DataMart.IDS.[AttEarningOB](
			  [RunID]							
			 ,[Pat_Type]					
			 ,[Tri focus code]			
			 ,[Programme]			
			 ,[YOI]						
			 ,[QOI]							
			 ,[CCY]						
			 ,[Qtr]						
			 ,[Perc]	
			 )
	SELECT 					
			     T2.Pk_RequestId					
				,T1.[Pat_Type]				
				,T1.[Tri focus code]		
				,T1.[Programme]				
				,T1.[YOI]					
				,T1.[QOI]					
				,T1.[CCY]					
				,T1.[Qtr]					
				,T1.[Perc]					
		FROM [IFRS17PsicleData].[Results].[AttEarningOB] T1
	INNER JOIN IFRS17DataMart.PWAPS.IFRS17CalcUI_RunLog T2 ON T1.RunID = T2.[Opening Balances Id]
	WHERE T2.Pk_RequestId = @RunId
	END
END