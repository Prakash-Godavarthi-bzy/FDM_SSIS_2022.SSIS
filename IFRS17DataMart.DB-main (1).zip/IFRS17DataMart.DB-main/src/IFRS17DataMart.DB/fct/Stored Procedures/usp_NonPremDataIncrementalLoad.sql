﻿
CREATE PROCEDURE [fct].[usp_NonPremDataIncrementalLoad] (@AccPer int,@AccountDataset VARCHAR(MAX))
AS

--DECLARE @AccPer int = 202402
--,@AccountDataset VARCHAR(MAX) = 'BC-LS-OT:LPSO,BC-OS-OT:LPSO,BC-SD-OT:AgressoARBIDAC,BC-SD-OT:AgressoARUS,BC-SD-OT:LPSO,CC-LS-ATT-FAC:RI LPSO FAC,CC-LS-LL-FAC:RI LPSO FAC,CC-LS-UN-FAC:BICI_RI_Paid,CC-LS-UN-TTY:BICI_RI_Paid,CC-LS-UN-TTY:RI LPSO TTY,CC-OS-ATT-FAC:RI LPSO FAC,CC-OS-UN-TTY:RI LPSO TTY,CC-SD-ATT-FAC:RI LPSO FAC,CC-SD-LL-FAC:RI LPSO FAC,CC-SD-UN-TTY:RI LPSO TTY,C-DI-ATT:Claims_BI_ODS,C-DI-LL:Claims_BI_ODS,C-DP-ATT:Claims_BI_ODS,C-DP-LL:Claims_BI_ODS,C-FI-ATT:Claims_BI_ODS,C-FI-LL:Claims_BI_ODS,C-FP-ATT:Claims_BI_ODS,C-FP-LL:Claims_BI_ODS,C-II-ATT:BICI TDM,C-II-ATT:Claims_BI_ODS,C-II-LL:Claims_BI_ODS,C-IP-ATT:BICI TDM,C-IP-ATT:Claims_BI_ODS,C-IP-LL:Claims_BI_ODS,EX-AC-O:Expenses Actual,EX-AD-P:Expenses Actual,EX-CH-O:Expenses Actual,EX-RB-RC-R:ReinsuranceRebates_Paid,EX-RB-RP-R:ReinsuranceRebates_Ultimate,EX-RI-P:Expenses Actual,GC-P-AC:ReservingData,GC-P-CM:ReservingData,GC-P-LL:ResDataEventAlloc,GC-T-AC:ReservingData,GC-T-CM:ReservingData,GC-T-LL:ReservingData,PC-LS-OT:LPSO,PC-LS-PC:LPSO,PC-LS-PC-FAC:Signed Profit Commission,PC-LS-PC-TTY:Signed Profit Commission,PC-LS-RP-FAC:RI LPSO FAC,PC-LS-RP-TTY:RI LPSO TTY,PC-LS-RT:LPSO,PC-LS-RT-FAC:RI LPSO FAC,PC-LS-RT-TTY:RI LPSO TTY,PC-OS-OT:LPSO,PC-OS-PC:LPSO,PC-OS-RP-FAC:RI LPSO FAC,PC-OS-RP-TTY:RI LPSO TTY,PC-OS-RT:LPSO,PC-OS-RT-FAC:RI LPSO FAC,PC-OS-RT-TTY:RI LPSO TTY,PC-SD-OT:AgressoARBIDAC,PC-SD-OT:AgressoARUS,PC-SD-OT:LPSO,PC-SD-PC:LPSO,PC-SD-RP-FAC:RI LPSO FAC,PC-SD-RP-TTY:RI LPSO TTY,PC-SD-RT:LPSO,PC-SD-RT-FAC:RI LPSO FAC,PC-SD-RT-TTY:RI LPSO TTY,RC-P-AC:ResDataRIAttClmAlloc,RC-P-CM:ReservingData,RC-P-LL:ResDataRILargeLossAlloc,RC-T-LL:ReservingData'


;WITH SelectedDatasetAccount AS
(
SELECT SelectedList ,substring(SelectedList, (charindex(':',SelectedList)+1),len(SelectedList)) Dataset,
substring(SelectedList, 1,(charindex(':',SelectedList) - 1)) Account
FROM (SELECT RTRIM(LTRIM(value)) SelectedList
		FROM STRING_SPLIT(@AccountDataset, ',')
	)A
)

SELECT
     T2.PolicyReference as BK_PolicyNumber
    , T1.FK_Entity
    , T1.FK_Trifocus
    , CAST(T5.RIFlag AS Varchar(2)) RIFlag
    , CASE RIFlag	WHEN   'I' THEN 'GROSS'	ELSE t1.FK_ProgrammeCode    END AS [RI PROG]
    , T1.FK_CCYSettlement
    , T1.Fk_dataset
    , T1.FK_scenario
    , CAST(T1.FK_Account AS VARCHAR(15)) AS FK_Account
    , TRY_CONVERT(INT,T1.FK_YOA ) AS FK_YOA
    , T1.FK_inceptionyear
    , T1.InceptionPeriod
	, CASE WHEN T1.Fk_dataset='ResDataEventAlloc' 
		   THEN CASE WHEN ISDATE(RIGHT(T1.BusinessKey, (CHARINDEX('|',REVERSE(BusinessKey),0))-1)) = 1
					 THEN RIGHT(T1.BusinessKey, (CHARINDEX('|',REVERSE(BusinessKey),0))-1)
					 ELSE NULL
					 END
		   ELSE NULL 
	  END AS EventDate 
	, CASE  WHEN FK_Account LIKE '%-CM' THEN 'C' 
		WHEN (FK_Account LIKE '%-AC' OR FK_Account LIKE '%-ATT') THEN 'A'
		WHEN FK_Account LIKE '%-LL' THEN 'L'
		ELSE ''
	END [Loss Type]
	, CASE
		WHEN FK_Account LIKE '%-P-%' THEN 'P'
		WHEN FK_Account LIKE '%-T-%' THEN 'T'
		ELSE ''
	 END [Type]
    , CAST(SUM([Value]) AS Float) AS [Value]
FROM stg.fct_TechnicalResult T1
INNER JOIN Dim.[PolicySection] T2 ON T1.FK_PolicySection = T2.PK_PolicySection
INNER JOIN SelectedDatasetAccount T3 ON T1.FK_Account = T3.Account AND T1.Fk_dataset = T3.dataset
LEFT JOIN DIM.Account T5 ON T1.FK_Account = T5.PK_Account
INNER JOIN Dim.AccountCodeMapping T6 ON  T1.FK_Account = T6.AccountCode
WHERE 1=1 
AND T6.IsActive = 1
AND T6.[Type] <> 'PREMIUM'
AND FK_AccountingPeriod = @AccPer
GROUP BY 
   T2.PolicyReference 
    , T1.FK_Entity
    , T1.FK_Trifocus
	, T5.RIFlag
	, CASE RIFlag	WHEN   'I' THEN 'GROSS'	ELSE t1.FK_ProgrammeCode    END
    , T1.FK_CCYSettlement
    , T1.Fk_dataset
    , T1.FK_scenario
    , CAST(T1.FK_Account AS VARCHAR(15))
    , TRY_CONVERT(INT,T1.FK_YOA )
    , T1.FK_inceptionyear
    , T1.InceptionPeriod
	,CASE WHEN T1.Fk_dataset='ResDataEventAlloc' 
		   THEN CASE WHEN ISDATE(RIGHT(T1.BusinessKey, (CHARINDEX('|',REVERSE(BusinessKey),0))-1)) = 1
					 THEN RIGHT(T1.BusinessKey, (CHARINDEX('|',REVERSE(BusinessKey),0))-1)
					 ELSE NULL
					 END
		   ELSE NULL 
	  END
	, CASE  WHEN FK_Account LIKE '%-CM' THEN 'C' 
			WHEN (FK_Account LIKE '%-AC' OR FK_Account LIKE '%-ATT') THEN 'A'
			WHEN FK_Account LIKE '%-LL' THEN 'L'
			ELSE ''
		END 
	, CASE
		WHEN FK_Account LIKE '%-P-%' THEN 'P'
		WHEN FK_Account LIKE '%-T-%' THEN 'T'
		ELSE ''
	 END