﻿--USE [IFRS17DataMart]
--GO

--/****** Object:  StoredProcedure [fct].[usp_IDSTrifocusMapping]    Script Date: 20/03/2024 15:30:03 ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO

CREATE PROCEDURE [fct].[usp_IDSTrifocusMapping] @RequestId INT  
AS
BEGIN


IF NOT EXISTS(
select runid from
[IDS].[TrifocusMapping]
where runid=@RequestId
)

BEGIN
--Truncate table [IFRS17DataMart].[IDS].[TrifocusMapping] 
----Set @RunId=(select isnull(Max(RunId),0) from [IFRS17DataMart].[IDS].[TrifocusMapping])
INSERT INTO [IDS].[TrifocusMapping]
([RunID],
[Trifocus Code] ,
[Trifocus Name],
[Focus Group],
[Division],
[CM Earn]
)
SELECT
s.Pk_RequestId,
a.TrifocusCode,
a.[TrifocusName],
a.[Focus Group],
a.[Division],
a.[CM Earn]
FROM
[Dim].TrifocusMapping a  inner join Dim.AssumptionDatasets D on a.AssumptionDatasetNameID=D.Pk_AssumptionDatasetNameId
INNER JOIN PWAPS.IFRS17CalcUI_RunLog s ON D.AssumptionDatasetName=s.TrifocusMappingId 
---WHERE a.IsActive='1' 
AND s.Pk_RequestId=@RequestId
END
END