﻿


CREATE PROCEDURE  [fct].[usp_PopulateIDSPremiumBrokerageSM_Binder] @RequestId INT
AS


BEGIN
--DECLARE @RequestId INT = 4059
		DROP TABLE IF EXISTS #DataOrder
		SELECT T2.Pk_RequestId, T3.[Reporting Year], T3.[Reporting Period], T3.[OB Reporting Period],	T2.Scenario	,T2.UptoPeriod,	T2.AsAtPeriod, T2.SortOrder,LAG(T2.UptoPeriod,1) OVER(ORDER BY T2.SortOrder) Previous_UpToPeriod
		INTO #DataOrder
		FROM
		(
			SELECT Pk_RequestId, Scenario,	UptoPeriod,	AsAtPeriod, ROW_NUMBER() OVER(PARTITION BY Pk_RequestId ORDER BY UptoPeriod) SortOrder
			FROM
				(
				SELECT Pk_RequestId,[SM Scenario Actual] AS Scenario, [SM Up to inception period Actual] AS UptoPeriod, [SM Reporting Period Actual] AS AsAtPeriod FROM PWAPS.IFRS17CalcUI_RunLog
				UNION
				SELECT Pk_RequestId,[SM Scenario Forecast] AS Scenario, [SM Up to inception period Forecast] AS UptoPeriod, [SM Reporting Period Forecast] AS AsAtPeriod FROM PWAPS.IFRS17CalcUI_RunLog
				UNION
				SELECT Pk_RequestId,[SM Scenario Business Plan] AS Scenario, [SM Up to inception period Business Plan] AS UptoPeriod, [SM Reporting Period Business Plan] AS AsAtPeriod FROM PWAPS.IFRS17CalcUI_RunLog
				)T1
			WHERE UptoPeriod IS NOT NULL
		)T2
		INNER JOIN PWAPS.IFRS17CalcUI_RunLog  T3 ON T2.Pk_RequestId = T3.Pk_RequestId 
		WHERE 1 = 1
		AND T2.Pk_RequestId = @RequestId

----SELECT * FROM #DataOrder

	--- bring the sort order in right shape and fill the missing inception periods

		DROP TABLE IF EXISTS #RunConfig
		SELECT 
				Pk_RequestId
			  ,[Reporting Year] 
			  ,[Reporting Period] 
			  ,[OB Reporting Period]
			  , SortOrder
			  ,	CASE WHEN SortOrder = 1
					 THEN CASE WHEN SortOrder_IP <= UptoPeriod THEN SortOrder_IP ELSE NULL End
					 ELSE CASE WHEN SortOrder = 2 
							   THEN CASE WHEN SortOrder_IP > Previous_UpToPeriod AND SortOrder_IP <= UptoPeriod THEN SortOrder_IP ELSE NULL End
							   ELSE CASE WHEN SortOrder = 3 
										 THEN CASE WHEN SortOrder_IP > Previous_UpToPeriod AND SortOrder_IP <= UptoPeriod THEN SortOrder_IP ELSE NULL End
									END
						  END
				END  MOI
			 , 	CASE WHEN SortOrder = 1
					 THEN CASE WHEN SortOrder_IP <= UptoPeriod THEN T1.Scenario ELSE NULL End
					 ELSE CASE WHEN SortOrder = 2 
							   THEN CASE WHEN SortOrder_IP > Previous_UpToPeriod AND SortOrder_IP <= UptoPeriod THEN T1.Scenario ELSE NULL End
							   ELSE CASE WHEN SortOrder = 3 
										 THEN CASE WHEN SortOrder_IP > Previous_UpToPeriod AND SortOrder_IP <= UptoPeriod THEN T1.Scenario ELSE NULL End
									END
						  END
				END Scenario
			 , 	CASE WHEN SortOrder = 1
					 THEN CASE WHEN SortOrder_IP <= UptoPeriod THEN T1.AsAtPeriod ELSE NULL End
					 ELSE CASE WHEN SortOrder = 2 
							   THEN CASE WHEN SortOrder_IP > Previous_UpToPeriod AND SortOrder_IP <= UptoPeriod THEN T1.AsAtPeriod ELSE NULL End
							   ELSE CASE WHEN SortOrder = 3 
										 THEN CASE WHEN SortOrder_IP > Previous_UpToPeriod AND SortOrder_IP <= UptoPeriod THEN T1.AsAtPeriod ELSE NULL End
									END
						  END
				END SM_AsAtPeriod
		INTO #RunConfig
		FROM #DataOrder T1
		CROSS APPLY
			(	
			SELECT AccountingPeriodName, AccountingYearName FROM Dim.AccountingPeriod WHERE AccountingMonth NOT IN (0,13)
			)A 			( SortOrder_IP, AccountingYearName)
		WHERE A.AccountingYearName IN ( T1.[Reporting Year], (T1.[Reporting Year] - 1))
  
  ----SELECT  * FROM #RunConfig

	--- Get only the months till which user selected the inception periods in the UI
		DROP TABLE IF EXISTS #RunConfigReArranged
		SELECT Pk_RequestId
				, [Reporting Year]
				, [Reporting Period] 
				, [OB Reporting Period]
				, SortOrder
				--, [Reporting Year] + MOI AS [Inception Period]
				, CASE Scenario 
						WHEN 'Actual' THEN 'A' 
						WHEN 'Forecast' THEN 'F'
						WHEN 'Budget' THEN 'B'
				  END Scenario
				, SM_AsAtPeriod 
				,MIN( MOI ) MIN_IP
				,MAX( MOI ) MAX_IP
				,CASE WHEN T2.MAX_SORT IS NOT NULL THEN Scenario END MAX_SCENARIO
		INTO #RunConfigReArranged
		FROM #RunConfig T1
		LEFT JOIN ( SELECT MAX(SortOrder) MAX_SORT
					FROM #RunConfig
					WHERE Scenario IN ('Forecast', 'Budget' )
					) T2 ON T1.SortOrder = T2.MAX_SORT
		WHERE MOI IS NOT NULL
		GROUP BY Pk_RequestId
				, [Reporting Year]
				, [Reporting Period] 
				, [OB Reporting Period]
				, SortOrder
				, CASE Scenario 
						WHEN 'Actual' THEN 'A' 
						WHEN 'Forecast' THEN 'F'
						WHEN 'Budget' THEN 'B'
				  END
				, SM_AsAtPeriod 
				,CASE WHEN T2.MAX_SORT IS NOT NULL THEN Scenario END


----SELECT * FROM #RunConfigReArranged



---Dataset get all actuals AsAt the Accounting Period selected for actuals transactional balances (P-BA-B for Syndicate business)

		BEGIN

			DROP TABLE IF EXISTS #DS1_Actuals
			SELECT  T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus] ,T1.Account,'transactional' AS PremType, T1.[RI Prog] AS Programme, T1.[RI Flag]as RI_Flag	,T1.YOA,	T1.YOI,	MOI	,
					DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)) QOI_End_Date,'SM' AS RecognitionType,	T1.CCYSettlement, NULL as Adjust_Flag,
					CASE WHEN T1.Account = 'P-BA-B' AND T1.MOI > T2.[Reporting Period] 
						THEN 0 
						ELSE T1.[Value] 
					END AS [Value]

			INTO #DS1_Actuals
			FROM IFRS17DataMart.fct.Aggr_PremiumLTD T1
			INNER JOIN  #RunConfigReArranged	T2 ON T1.AccountingPeriod = CASE WHEN T2.[SM_AsAtPeriod] IS NULL THEN T2.[OB Reporting Period] ELSE T2.[SM_AsAtPeriod] END
												   AND T1.Scenario		= T2.Scenario
												   AND T2.Scenario = 'A'
												  -- AND T1.MOI <= T2.MAX_IP ----Not needed as we need actuals for all inception period available for upto the reporting year = yoa
												   AND T1.MOI <= T2.MAX_IP ---- put it back as part of CR 2801 
												   AND YOA <= [Reporting Year]
			INNER JOIN (SELECT [AccountCode], [Type] FROM IFRS17DataMart.Dim.AccountCodeMapping WHERE IsActive = 1 AND [Type] = 'Premium' ) T3 ON T1.Account = T3.AccountCode
			WHERE 1 = 1
			AND T1.Account IN ('P-BP-B', 'P-BA-B')
		END


	----SELECT * FROM #DS1_Actuals WHERE Account = 'P-BP-B' AND YOA = 2018 and Trifocus = 'TRI00015' and Entity = '2623' and [IFRS17 Trifocus] = 'TRI00015' and CCYSettlement = 'usd' order by MOI

	
-----Dataset get all forecast AsAt the Accounting Period selected for actuals transactional balances (P-BA-B for Syndicate business)
		BEGIN

			DROP TABLE IF EXISTS #DS2_Forecast
			SELECT T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus] ,T1.Account,'transactional' AS PremType, T1.[RI Prog] AS Programme, T1.[RI Flag]as RI_Flag,T1.YOA,	T1.YOI,	MOI	,
					DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)) QOI_End_Date,'SM' AS RecognitionType,	T1.CCYSettlement, NULL as Adjust_Flag, 
					CASE WHEN T1.Account = 'P-BA-B' AND T1.MOI > T2.[Reporting Period] 
						 THEN 0 
						 ELSE CASE WHEN T2.MAX_SCENARIO IS NULL AND T1.MOI > MAX_IP 
								   THEN 0
								   ELSE T1.[Value] 
							  END
					END AS [Value]
			INTO #DS2_Forecast
			FROM IFRS17DataMart.fct.Aggr_PremiumLTD T1
			INNER JOIN  #RunConfigReArranged	T2 ON T1.AccountingPeriod = T2.[SM_AsAtPeriod] 
												AND T1.Scenario		  = T2.Scenario
												AND T1.MOI >= T2.MIN_IP 
												AND YOA <= [Reporting Year]
												AND T2.Scenario = 'F'
			INNER JOIN (SELECT [AccountCode], [Type] FROM IFRS17DataMart.Dim.AccountCodeMapping WHERE IsActive = 1 AND [Type] = 'Premium' ) T3 ON T1.Account = T3.AccountCode
			WHERE 1 = 1
			AND T1.Account IN ('P-BP-B', 'P-BA-B')
			
		END

	----SELECT * FROM #DS2_Forecast WHERE Account = 'P-BP-B' AND YOA = 2018 and Trifocus = 'TRI00015' and Entity = '2623' and [IFRS17 Trifocus] = 'TRI00015' and CCYSettlement = 'usd' order by MOI


---Dataset get all Business Plan AsAt the Accounting Period selected for actuals transactional balances (P-BA-B for Syndicate business)

		BEGIN

			DROP TABLE IF EXISTS #DS3_BusinessPlan
			SELECT T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus] ,T1.Account,'transactional' AS PremType, T1.[RI Prog] AS Programme, T1.[RI Flag]as RI_Flag	,T1.YOA,	T1.YOI,	MOI	,
					DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)) QOI_End_Date,'SM' AS RecognitionType,	T1.CCYSettlement, NULL as Adjust_Flag, 
					CASE WHEN T1.Account = 'P-BA-B' AND T1.MOI > T2.[Reporting Period] 
						 THEN 0 
						 ELSE CASE WHEN T2.MAX_SCENARIO IS NULL AND T1.MOI > MAX_IP 
								   THEN 0
								   ELSE T1.[Value] 
							  END
					END AS [Value]
			INTO #DS3_BusinessPlan
			FROM IFRS17DataMart.fct.Aggr_PremiumLTD T1
			INNER JOIN  #RunConfigReArranged	T2 ON T1.AccountingPeriod = T2.[SM_AsAtPeriod] 
												AND T1.Scenario		  = T2.Scenario
												AND T1.MOI >= T2.MIN_IP 
												AND YOA <= [Reporting Year]
												AND T2.Scenario = 'B'
			INNER JOIN (SELECT [AccountCode], [Type] FROM IFRS17DataMart.Dim.AccountCodeMapping WHERE IsActive = 1 AND [Type] = 'Premium' ) T3 ON T1.Account = T3.AccountCode
			WHERE 1 = 1
			AND T1.Account IN ('P-BP-B', 'P-BA-B')
			
		END



DECLARE @RepPeriodQuaterEnd date
SELECT DISTINCT @RepPeriodQuaterEnd = DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST([Reporting Period] AS varchar), '01')))+1 ,0)) FROM #RunConfigReArranged
----SELECT  @RepPeriodQuaterEnd


-----FINAL UNION 
------ FINAL INSERT INTO [IDS].[Aggr_PremiumBrokerage]
	BEGIN
	INSERT INTO IFRS17DataMart.[IDS].[Aggr_PremiumBrokerage]
		  (RunID,	Entity,	[Tri focus code],	[IFRS17 Trifocus],	Account,	PremType,	Programme,	RI_Flag,	YOA,	YOI,	QOI_End_Date,	RecognitionType, CCY, Adjust_Flag,	[Amount],AuditCreateDateTime, AuditUserCreate)
	SELECT Pk_RequestId
			, Entity
			, Trifocus
			, [IFRS17 Trifocus] 
			, CASE WHEN Account = 'P-BP-B' AND QOI_End_Date > @RepPeriodQuaterEnd THEN 'P-BP-BU' ELSE Account END AS Account
			, PremType
			, Programme
			--, RI_Flag	
			,CASE WHEN [RI_Flag]='G' THEN 'I' WHEN [RI_Flag]='R' THEN 'O' ELSE [RI_Flag] END AS RI_Flag
			, YOA
			, YOI
			, QOI_End_Date
			, RecognitionType
			, CCYSettlement
			, Adjust_Flag
			, SUM([Value]) 
			, GETDATE()
			, SYSTEM_USER
   
	FROM
	(
		SELECT Pk_RequestId, Entity,	Trifocus,[IFRS17 Trifocus] ,Account, PremType, Programme,RI_Flag	,YOA,	YOI,	MOI	, QOI_End_Date,RecognitionType,	CCYSettlement, Adjust_Flag, [Value] FROM #DS1_Actuals --WHERE [Value] > 0 PK bug 3098.. 
		UNION ALL
		SELECT Pk_RequestId, Entity,	Trifocus,[IFRS17 Trifocus] ,Account, PremType, Programme,RI_Flag	,YOA,	YOI,	MOI	, QOI_End_Date,RecognitionType,	CCYSettlement, Adjust_Flag, [Value] FROM #DS2_Forecast --WHERE [Value] > 0 PK bug 3098..
		UNION ALL
		SELECT Pk_RequestId, Entity,	Trifocus,[IFRS17 Trifocus] ,Account, PremType, Programme,RI_Flag	,YOA,	YOI,	MOI	, QOI_End_Date,RecognitionType,	CCYSettlement, Adjust_Flag, [Value] FROM #DS3_BusinessPlan --WHERE [Value] > 0 PK bug 3098..
	)A
	GROUP BY Pk_RequestId
			, Entity
			, Trifocus
			, [IFRS17 Trifocus] 
			, CASE WHEN Account = 'P-BP-B' AND QOI_End_Date > @RepPeriodQuaterEnd THEN 'P-BP-BU' ELSE Account END 
			, PremType
			, Programme
			, RI_Flag	
			, YOA
			, YOI
			, QOI_End_Date
			, RecognitionType
			, CCYSettlement
			, Adjust_Flag
	END

	DROP TABLE IF EXISTS #DataOrder
	DROP TABLE IF EXISTS #RunConfig
	DROP TABLE IF EXISTS #RunConfigReArranged
	DROP TABLE IF EXISTS #DS1_Actuals
	DROP TABLE IF EXISTS #DS2_Forecast
	DROP TABLE IF EXISTS #DS3_BusinessPlan



END
GO


