﻿
CREATE Procedure [fct].[usp_Load_AsumptionDatsets](@yearMonth Varchar(30),@YearMn Varchar(20))
AS

--eXeC fct.usp_Load_AsumptionDatsets 'Feb 2021','202102'
-- =============================================
-- Author:		Krishna
-- Create date: 25-01-2021
-- Description:	This stored proc inserts data into assumption datasets table
-- =============================================



Begin

Declare @yearandmonthAv varchar(30)
Declare @yearandmonthSp varchar(30)
Declare @rnd varchar(10)
select @rnd=  CAst(CAST(RAND(CHECKSUM(NEWID()))*100 as int) as varchar)
Declare @AsFxRtAv int
Declare @AsFxrtSp int




Select @AsFxRtAv = Pk_AssumptionPercentageTypeId from Dim.AssumptionPercentageType
where AssumptionPercentageType='FX Rate (Average)'  


Select @AsFxrtSp = Pk_AssumptionPercentageTypeId from Dim.AssumptionPercentageType
where AssumptionPercentageType='FX Rate (Spot)' 

select @yearandmonthAv='SYS'+' '+@rnd+' '+@yearMonth+'AGRAvg'
--Set @yearandmonthAv='SYS'+' '+@yearMonth+'AGRAvg'
--Set @yearandmonthSp='SYS'+' '+@yearMonth+'AGRSpot'

select @yearandmonthSp='SYS'+' '+@rnd+' '+@yearMonth+'AGRSpot'


INSERT INTO [Dim].[AssumptionDatasets]
		([AssumptionDatasetName],[AssumptionDatasetDescription],[AssumptionPercentageTypeId],[IsDatasetAlreadyUsed]
      ,[CreatedDt]
      ,[CreatedBy]
      ,[UpdatedDt]
      ,[UpdatedBy]
    --  ,[ValidFrom]
   --   ,[ValidTo]
	  )
		SELECT 
		 @yearandmonthAv
		 , @yearandmonthAv
	      ,  @AsFxRtAv --46
				
			,NULL
			,GETDATE()
			,SUSER_SNAME()
			,GETDATE()
			,SUSER_SNAME()
			





INSERT INTO [Dim].[AssumptionDatasets]
		([AssumptionDatasetName],[AssumptionDatasetDescription],[AssumptionPercentageTypeId],[IsDatasetAlreadyUsed]
      ,[CreatedDt]
      ,[CreatedBy]
      ,[UpdatedDt]
      ,[UpdatedBy]
    --  ,[ValidFrom]
   --   ,[ValidTo]
	  )
		SELECT 
		 @yearandmonthSp
		 , @yearandmonthSp
	      ,  @AsFxrtSp--43
				
			,NULL
			,GETDATE()
			,SUSER_SNAME()
			,GETDATE()
			,SUSER_SNAME()
			

	


	

Declare @AssDtIDAv int
Declare @AssPTyIDAv int


Declare @AssDtIDSp int
Declare @AssPTyIDSp int



IF EXISTS(SELECT distinct fk_TransactionCurrency
		from stg.fct_FXRate
		where fk_AccountingPeriod=@YearMn
		and fk_TransactionCurrency not in (Select distinct PK_CCY from dim.CCY)
		)
	BEGIN


	DROP TABLE IF EXISTS #CCY
			
		SELECT distinct fk_TransactionCurrency into #CCY
		from stg.fct_FXRate
		where fk_AccountingPeriod=@YearMn
		and fk_TransactionCurrency not in (Select distinct PK_CCY from dim.CCY)

		INSERT INTO DIM.CCY(PK_CCY,CCYNAME)  (SELECT fk_TransactionCurrency,fk_TransactionCurrency From #CCY)

END


Select @AssDtIDAv= Pk_AssumptionDataSetNameID,@AssPTyIDAv= AssumptionPercentageTypeId From  dim.AssumptionDatasets Where
AssumptionDataSetName=@yearandmonthAv


Select @AssDtIDSp= Pk_AssumptionDataSetNameID,@AssPTyIDSp= AssumptionPercentageTypeId From  dim.AssumptionDatasets Where
AssumptionDataSetName=@yearandmonthSp

INSERT INTO fct.FxRate
		([FXRate],[AssumptionDatasetNameId],[AssumptionPercentageTypeId],[FxType]
      ,[ReportingCurrencyCode]
      ,[CCY]
      ,[MS_AUDIT_TIME]
      ,[MS_AUDIT_USER]
    --  ,[ValidFrom]
   --   ,[ValidTo]
	  )
SELECT Sum(FXrate),@AssDtIDAv,@AssPTyIDAv,Case when FxRateName ='Average' Then 'FXA' When FXRateName='Spot' Then 'FXS' else NULL end as LOSS_TYPE,fK_ReportingCurrencyCode,fk_TransactionCurrency
		
		,GETDATE()
		,SUSER_SNAME()
		from stg.fct_FXRate
		where fk_AccountingPeriod=@YearMn and FXRateName='Average'
		group by fk_Batch,FXRateName,fk_ReportingCurrencyCode,fk_TransactionCurrency




INSERT INTO fct.FxRate
		([FXRate],[AssumptionDatasetNameId],[AssumptionPercentageTypeId],[FxType]
      ,[ReportingCurrencyCode]
      ,[CCY]
      ,[MS_AUDIT_TIME]
      ,[MS_AUDIT_USER]
    --  ,[ValidFrom]
   --   ,[ValidTo]
	  )
SELECT Sum(FXrate),@AssDtIDSp,@AssPTyIDSp,Case when FxRateName ='Average' Then 'FXA' When FXRateName='Spot' Then 'FXS' else NULL end as LOSS_TYPE,fK_ReportingCurrencyCode,fk_TransactionCurrency
		
		,GETDATE()
		,SUSER_SNAME()
		from stg.fct_FXRate
		where fk_AccountingPeriod=@YearMn and FXRateName='Spot'
		group by fk_Batch,FXRateName,fk_ReportingCurrencyCode,fk_TransactionCurrency
		

	





End
GO


