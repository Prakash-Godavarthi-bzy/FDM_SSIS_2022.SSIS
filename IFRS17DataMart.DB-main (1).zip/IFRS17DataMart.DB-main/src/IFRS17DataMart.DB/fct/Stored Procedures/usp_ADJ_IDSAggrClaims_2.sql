﻿CREATE PROCEDURE [fct].[usp_ADJ_IDSAggrClaims] @RequestId INT
AS
BEGIN

IF NOT EXISTS(
select distinct [RunID] from
[IDS].[Aggr_Claims]
where runid=@RequestId
AND Adjust_Flag = 'A'
)

BEGIN


INSERT INTO [IDS].[Aggr_Claims]([RunID],[Entity],[Tri focus code],[Account],[Programme],[RI_Flag],[Loss_Type],[YOA],[YOI],[CCY],[Amount],Adjust_Flag,[AuditCreateDateTime]
,[AuditUserCreate])
SELECT 
     T1.Pk_RequestId
	  ,Entity
      ,Trifocus
      , Account
	  , Programme
	  ,CASE WHEN [Gross/RI Flag]='G' THEN 'I' WHEN [Gross/RI Flag]='R' THEN 'O' ELSE [Gross/RI Flag] END AS [Gross/RI Flag]
	   ,CASE WHEN PATINDEX('%ATT%', Account) > 0 THEN 'A'  
			WHEN PATINDEX('%LL%', Account) > 0 THEN 'L'
			WHEN PATINDEX('%CM%', Account) > 0 THEN 'C' 
			ELSE '' 
		END [Loss Type]
	  ,YOA AS YOA
	  ,YOA AS YOI
      ,CCY AS CCY
      ,SUM([Value]) AS Amount
	     ,'A' as Adjust_Flag
      ,GETDATE() AS AuditCreateDateTime
      ,SUSER_SNAME() AS AuditUserCreate
	
FROM Dim.AssumptionDatasets A
INNER JOIN PWAPS.IFRS17CalcUI_RunLog T1 ON T1.Adjustments=A.AssumptionDatasetName
INNER JOIN fct.AssumptionData W ON A.Pk_AssumptionDatasetNameId=W.Pk_AssumptionDatasetNameId
INNER JOIN Dim.AccountCodeMapping T2 ON W.Account=T2.AccountCode
WHERE T1.Pk_RequestId = @RequestId
AND T2.IsActive=1
AND T2.[Type] IN ('Incurred')
GROUP BY 
       T1.Pk_RequestId
      ,[Entity]
      ,[Trifocus]
      ,[Account]
	  ,AccountCode
	  ,Programme
      ,[Gross/RI Flag]
	  ,YOA
      ,CCY
END
END