﻿CREATE  Procedure  [fct].[usp_PopulateIDSCatEarningOB] (@RunId Int)
AS
BEGIN
IF NOT EXISTS(SELECT 1 FROM IFRS17DataMart.IDS.[CatEarningOB] WHERE RunID = @RunId)
	BEGIN
	INSERT INTO IFRS17DataMart.IDS.[CatEarningOB](
			  [RunID]					
			 ,[Tri focus code]		
			 ,[YOA]					
			 ,[Open/Closed Derivation]
			 ,[CCY]					
			 ,[QOI_End_Date]			
			 ,[Qtr]					
			 ,[YOI]					
			 ,[Account]				
			 ,[Amount_Cum]			
			)
	SELECT 					
			    T2.Pk_RequestId					
				,T1.[Tri focus code]		
				,T1.[YOA]					
				,T1.[Open/Closed Derivation]
				,T1.[CCY]					
				,T1.[QOI_End_Date]			
				,T1.[Qtr]					
				,T1.[YOI]					
				,T1.[Account]				
				,T1.[Amount_Cum]			

		FROM [IFRS17PsicleData].[Results].[CatEarningOB] T1
	INNER JOIN IFRS17DataMart.PWAPS.IFRS17CalcUI_RunLog T2 ON T1.RunID = T2.[Opening Balances Id]
	WHERE T2.Pk_RequestId = @RunId
	END

END