﻿



CREATE PROCEDURE [fct].[usp_PopulateIDSPremiumBrokerage] @RequestId INT
AS
BEGIN

SET NOCOUNT ON; 


	BEGIN
--DECLARE @RequestId INT	= 4452
		DROP TABLE IF EXISTS #RunDataGross;
		SELECT [Pk_RequestId]
				,[Reporting Year]
				,[Reporting Period] 
				,CAST([Reporting Year] + RIGHT(('00' + A.InceptionPeriod),2) AS INT) InceptionPeriod
				,A.InceptionQuarter
				,CASE A.IPSource 
						WHEN  'Actual' THEN 'A'
						WHEN  'Forecast' THEN 'F'
						WHEN  'Budget' THEN 'B'
						ELSE NULL			  
					END IPSource
				, A.IPAsAtPeriod
				, CASE WHEN T1.Adjustments IS NOT NULL 
							AND 
							(
								CONCAT(	LEFT(CAST(CAST(DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(CAST([Reporting Year] + RIGHT(('00' + A.InceptionPeriod),2) AS INT) AS varchar), '01')))+1 ,0)) AS DATE)  AS varchar), 4),
									   SUBSTRING(CAST(CAST(DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(CAST([Reporting Year] + RIGHT(('00' + A.InceptionPeriod),2) AS INT) AS varchar), '01')))+1 ,0)) AS DATE)  AS varchar),6,2))
							  = CONCAT(LEFT(CAST(CAST(DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST([Reporting Period] AS varchar), '01')))+1 ,0)) AS DATE)  AS varchar), 4),
									   SUBSTRING( CAST(CAST(DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST([Reporting Period] AS varchar), '01')))+1 ,0))AS DATE)  AS varchar),6,2))
							 )
							THEN CAST([Reporting Year] + RIGHT(('00' + A.InceptionPeriod),2) AS INT)
						ELSE NULL
					END Adj_IP
		INTO #RunDataGross
		FROM PWAPS.IFRS17CalcUI_RunLog T1
		CROSS APPLY
		(	
			VALUES	
			('1', '1', [IR Scenario 01], [IR Reporting Period 01]),
			('2', '1', [IR Scenario 02], [IR Reporting Period 02]),
			('3', '1', [IR Scenario 03], [IR Reporting Period 03]),
			('4', '2', [IR Scenario 04], [IR Reporting Period 04]),
			('5', '2', [IR Scenario 05], [IR Reporting Period 05]),
			('6', '2', [IR Scenario 06], [IR Reporting Period 06]),
			('7', '3', [IR Scenario 07], [IR Reporting Period 07]),
			('8', '3', [IR Scenario 08], [IR Reporting Period 08]),
			('9', '3', [IR Scenario 09], [IR Reporting Period 09]),
			('10','4', [IR Scenario 10], [IR Reporting Period 10]),
			('11','4', [IR Scenario 11], [IR Reporting Period 11]),
			('12','4', [IR Scenario 12], [IR Reporting Period 12])
		)A ( InceptionPeriod, InceptionQuarter,IPSource, IPAsAtPeriod)
		WHERE 1 = 1
		AND [Pk_RequestId] = @RequestId


		DROP TABLE IF EXISTS #RunDataRI;
		SELECT [Pk_RequestId]
				,[Reporting Year]
				,[Reporting Period] 
				,CAST([Reporting Year] + RIGHT(('00' + A.InceptionPeriod),2) AS INT) InceptionPeriod
				,A.InceptionQuarter
				,CASE A.IPSource 
						WHEN  'Actual' THEN 'A'
						WHEN  'Forecast' THEN 'F'
						WHEN  'Budget' THEN 'B'
						ELSE NULL			  
					END IPSource
				, A.IPAsAtPeriod
				, CASE WHEN T1.Adjustments IS NOT NULL 
							AND 
							(
								CONCAT(	LEFT(CAST(CAST(DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(CAST([Reporting Year] + RIGHT(('00' + A.InceptionPeriod),2) AS INT) AS varchar), '01')))+1 ,0)) AS DATE)  AS varchar), 4),
									   SUBSTRING(CAST(CAST(DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(CAST([Reporting Year] + RIGHT(('00' + A.InceptionPeriod),2) AS INT) AS varchar), '01')))+1 ,0)) AS DATE)  AS varchar),6,2))
							  = CONCAT(LEFT(CAST(CAST(DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST([Reporting Period] AS varchar), '01')))+1 ,0)) AS DATE)  AS varchar), 4),
									   SUBSTRING( CAST(CAST(DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST([Reporting Period] AS varchar), '01')))+1 ,0))AS DATE)  AS varchar),6,2))
							 )
							THEN CAST([Reporting Year] + RIGHT(('00' + A.InceptionPeriod),2) AS INT)
						ELSE NULL
					END Adj_IP
		INTO #RunDataRI
		FROM PWAPS.IFRS17CalcUI_RunLog T1
		CROSS APPLY
		(	
			VALUES	
			('1', '1', [RI Scenario 01], [RI Reporting Period 01]),
			('2', '1', [RI Scenario 02], [RI Reporting Period 02]),
			('3', '1', [RI Scenario 03], [RI Reporting Period 03]),
			('4', '2', [RI Scenario 04], [RI Reporting Period 04]),
			('5', '2', [RI Scenario 05], [RI Reporting Period 05]),
			('6', '2', [RI Scenario 06], [RI Reporting Period 06]),
			('7', '3', [RI Scenario 07], [RI Reporting Period 07]),
			('8', '3', [RI Scenario 08], [RI Reporting Period 08]),
			('9', '3', [RI Scenario 09], [RI Reporting Period 09]),
			('10','4', [RI Scenario 10], [RI Reporting Period 10]),
			('11','4', [RI Scenario 11], [RI Reporting Period 11]),
			('12','4', [RI Scenario 12], [RI Reporting Period 12])
		)A ( InceptionPeriod, InceptionQuarter,IPSource, IPAsAtPeriod)
		WHERE 1 = 1
		AND [Pk_RequestId] = @RequestId


--SELECT * FROM #RunDataGross
--SELECT * FROM #RunDataRI

-----Get Max AsAt Period for PFT and Actual/Forecast  AsAt for BBNI binder from SM. CR 1807/1808 --PK 12102021
			DROP TABLE IF EXISTS #MaxSMAsAtPeriodForGross
			SELECT	 T1.Pk_RequestId
					,T1.[Reporting Year]
					,T1.[Reporting Period]
					,(SELECT MAX(SM_AsAt)
					  FROM (VALUES(T1.[SM Reporting Period Actual]),(T1.[SM Reporting Period Forecast]),(T1.[SM Reporting Period Business Plan])) AS All_SMAsAt(SM_AsAt))  AS MaxSM_AsAt
					,CASE T2.Scenario 
						  WHEN 'Actual' THEN 'A'
						  WHEN 'Forecast' THEN 'F'
						  WHEN 'Budget' THEN 'B'
					 END AS Scenario
					,T2.AsAtPeriod
			INTO #MaxSMAsAtPeriodForGross
			FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog T1
			LEFT JOIN 		
				(
					SELECT Pk_RequestId,[SM Scenario Actual] AS Scenario, [SM Reporting Period Actual] AS AsAtPeriod FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog
					UNION
					SELECT Pk_RequestId
						  ,[SM Scenario Forecast] AS Scenario
						  ,CASE WHEN ([SM Reporting Period Forecast] IS NULL AND [SM Reporting Period Business Plan] IS NULL AND [SM Reporting Period Actual] IS NOT NULL)
								THEN [SM Reporting Period Actual]
								ELSE COALESCE([SM Reporting Period Forecast] ,[SM Reporting Period Business Plan])
						   END AS AsAtPeriod 
					FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog
     			)T2 ON T1.Pk_RequestId = T2.Pk_RequestId
			WHERE T1.Pk_RequestId = (SELECT DISTINCT Pk_RequestId FROM #RunDataGross)



			DROP TABLE IF EXISTS #MaxSMAsAtPeriodForRI
			SELECT	 T1.Pk_RequestId
					,T1.[Reporting Year]
					,T1.[Reporting Period]
					,(SELECT MAX(SM_AsAt)
					  FROM (VALUES(T1.[RI SM Reporting Period Actual]),(T1.[RI SM Reporting Period Forecast]),(T1.[RI SM Reporting Period Business Plan])) AS All_SMAsAt(SM_AsAt))  AS MaxSM_AsAt
					,CASE T2.Scenario 
						  WHEN 'Actual' THEN 'A'
						  WHEN 'Forecast' THEN 'F'
						  WHEN 'Budget' THEN 'B'
					 END AS Scenario
					,T2.AsAtPeriod
			INTO #MaxSMAsAtPeriodForRI
			FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog T1
			LEFT JOIN 		
				(
					SELECT Pk_RequestId,[SM Scenario Actual] AS Scenario, [RI SM Reporting Period Actual] AS AsAtPeriod FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog
					UNION
					SELECT Pk_RequestId
						  ,[SM Scenario Forecast] AS Scenario
						  ,CASE WHEN ([RI SM Reporting Period Forecast] IS NULL AND [RI SM Reporting Period Business Plan] IS NULL AND [RI SM Reporting Period Actual] IS NOT NULL)
								THEN [RI SM Reporting Period Actual]
								ELSE COALESCE([RI SM Reporting Period Forecast] ,[RI SM Reporting Period Business Plan])
						   END AS AsAtPeriod 
					FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog
     			)T2 ON T1.Pk_RequestId = T2.Pk_RequestId
			WHERE T1.Pk_RequestId = (SELECT DISTINCT Pk_RequestId FROM #RunDataRI)


	--select * from #MaxSMAsAtPeriodForGross
	--select * from #MaxSMAsAtPeriodForRI



-----Prepare premium data to include adjustments, if selected any in the model run.
	DROP TABLE IF EXISTS #PremiumWithAdjustment
	SELECT [Entity], [Trifocus], [IFRS17 Trifocus], [RI Prog], [RI Flag], [CCYSettlement], [Dataset], [Scenario], [Account], [AccountingPeriod], [YOA], [YOI], [MOI], Adjust_Flag, [Value]
	INTO #PremiumWithAdjustment
	FROM
		(
		SELECT T1.[Entity] ,T1.[Trifocus] ,T1.[IFRS17 Trifocus]  ,T1.[RI Prog]  ,T1.[RI Flag]  ,T1.[CCYSettlement]  ,T1.[Dataset]  ,T1.[Scenario]  ,T1.[Account]  ,T1.[AccountingPeriod]  ,T1.[YOA]  ,T1.[YOI]  ,[MOI]  ,[Value], NULL AS Adjust_Flag
		FROM [fct].[Aggr_PremiumLTD] T1

		UNION ALL

		SELECT	 T3.Entity	,T3.TriFocus	,T3.TriFocus AS [IFRS17 Trifocus] ,T3.Programme AS [RI Prog] ,T3.[Gross/RI Flag] AS [RI Flag]	,T3.CCY	 AS [CCYSettlement],CASE WHEN T3.Source = 'U' THEN 'ReservingData' ELSE 'Adjustment' END AS Dataset
				,CASE WHEN T3.Source = 'U' THEN 'F' ELSE T3.Source END AS Scenario		,T3.Account	,NULL AS 	[AccountingPeriod],T3.YOA		,YEAR(T3.InceptionDate) AS YOI		,CONCAT(CAST(YEAR(T3.InceptionDate) AS VARCHAR), RIGHT(('0'+ CAST(MONTH(T3.InceptionDate) AS VARCHAR)),2)) AS MOI	,T3.[Value], 'A' AS Adjust_Flag
				--			,DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CONCAT(CAST(YEAR(T3.InceptionDate) AS VARCHAR), RIGHT(('0'+ CAST(MONTH(T3.InceptionDate) AS VARCHAR)),2)), '01')))+1 ,0)) QOI_End_Date
		FROM PWAPS.IFRS17CalcUI_RunLog T1
		INNER JOIN dim.AssumptionDatasets T2 ON T1.Adjustments = T2.AssumptionDatasetName
		LEFT JOIN fct.AssumptionData T3 ON T2.Pk_AssumptionDatasetNameId = T3.Pk_AssumptionDatasetNameId
		WHERE 1 = 1
		AND T1.Pk_RequestId = @RequestId
		)A

			

------INSERT Dataset 1 Incepted Transactional balances----- -------------------
--IDS DATA for ('P-GP-P','P-BP-B') Dataset 1 populate into temp table #IDSOutput
    DROP TABLE IF EXISTS #Dataset1;

	SELECT D1.Pk_RequestId , D1.Entity, D1.Trifocus, D1.[IFRS17 Trifocus], D1.Account, D1.PremType, D1.RI_Flag, D1.Programme, D1.YOA, D1.YOI, D1.QOI_End_Date , D1.RecognitionType , D1.CCYSettlement , D1.Adjust_Flag ,D1.[Value]
	INTO #Dataset1
	FROM
	(
		(
		SELECT    T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus] ,T1.Account,'transactional' AS PremType, 
					[RI Prog] AS Programme, [RI Flag] as RI_Flag
		,T1.YOA,	T1.YOI,		
					DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)) QOI_End_Date,'I' AS RecognitionType,	T1.CCYSettlement, T1.Adjust_Flag, SUM(T1.[Value]) [Value]

		FROM #PremiumWithAdjustment T1
		INNER JOIN #RunDataGross T2 ON  T1.AccountingPeriod  = T2.IPAsAtPeriod
							   AND T1.MOI = T2.InceptionPeriod
							   AND T1.YOI = T2.[Reporting Year]
							   AND T1.Scenario = T2.IPSource
		INNER JOIN IFRS17DataMart.Dim.AccountCodeMapping T3 ON T1.Account = T3.AccountCode
		WHERE 1 = 1
		AND T3.IsActive = 1 
		AND T3.[Type] = 'Premium' 
		AND T3.AccountCode in ('P-GP-P','P-AC-P','P-BP-B','P-BA-B','GPE-RP-P','RP-ULT-G')
		GROUP BY T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus], T1.Account, T1.[RI Prog], T1.[RI Flag],	T1.YOA,	T1.YOI,	T1.CCYSettlement, T1.Adjust_Flag,	
					DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0))
		)
		UNION ALL
		(
		SELECT    T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus] ,T1.Account,'transactional' AS PremType, 
					[RI Prog] AS Programme, [RI Flag] as RI_Flag
		,T1.YOA,	T1.YOI,		
					DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)) QOI_End_Date,'I' AS RecognitionType,	T1.CCYSettlement, T1.Adjust_Flag, SUM(T1.[Value]) [Value]
		FROM #PremiumWithAdjustment T1
		INNER JOIN #RunDataRI T2 ON  T1.AccountingPeriod  = T2.IPAsAtPeriod
							   AND T1.MOI = T2.InceptionPeriod
							   AND T1.YOI = T2.[Reporting Year]
							   AND T1.Scenario = T2.IPSource
		INNER JOIN IFRS17DataMart.Dim.AccountCodeMapping T3 ON T1.Account = T3.AccountCode
		WHERE 1 = 1
		AND T3.IsActive = 1 
		AND T3.[Type] = 'Premium' 
		AND (T3.AccountCode in ('P-RP-P-FAC','P-RP-P-TTY','PC-LS-OR-FAC','PC-LS-OR-TTY','P-OR-P-FAC','P-OR-P-TTY') OR (T3.AccountCode = 'RP-T-PR' AND T1.Dataset = 'ReservingDataPremiumAlloc'))
		GROUP BY T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus], T1.Account, T1.[RI Prog], T1.[RI Flag],	T1.YOA,	T1.YOI,	T1.CCYSettlement, T1.Adjust_Flag,	
					DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0))		
		)
	)D1

	----SELECT * FROM #Dataset1 WHERE Entity = '2623'AND YOI = 2019 AND YOA = 2019 AND Trifocus = '10'AND CCYSettlement = 'USD' AND Account in ('P-GP-P')--,'P-AC-P','P-BP-B','P-BA-B','GPE-RP-P')



------ IR Incepted Transactional balances 'Adjustment' data where quater end of inception periods selected = reporting period
    DROP TABLE IF EXISTS #Dataset1a;
	SELECT Pk_RequestId , Entity, Trifocus, [IFRS17 Trifocus], Account, PremType, RI_Flag, Programme, YOA, YOI, QOI_End_Date , RecognitionType , CCYSettlement , Adjust_Flag , [Value]
	INTO #Dataset1a
	FROM
	(
		(
			SELECT    T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus] ,T1.Account,'transactional' AS PremType,
						[RI Prog] AS Programme, [RI Flag] as RI_Flag	,T1.YOA,	T1.YOI,		
						DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)) QOI_End_Date,'I' AS RecognitionType,	T1.CCYSettlement, T1.Adjust_Flag, SUM(T1.[Value]) [Value]
			FROM #PremiumWithAdjustment T1
			INNER JOIN #RunDataGross  T2 ON  T1.MOI	=  T2.Adj_IP
								   AND T1.YOI = T2.[Reporting Year]
								   AND T1.Scenario = T2.IPSource
								   AND Adj_IP IS NOT NULL
			INNER JOIN IFRS17DataMart.Dim.AccountCodeMapping T3 ON T1.Account = T3.AccountCode
			WHERE 1 = 1
			AND T3.IsActive = 1 
			AND T3.[Type] = 'Premium' 
			AND T3.AccountCode in ('P-GP-P','P-AC-P','P-BP-B','P-BA-B','GPE-RP-P','RP-ULT-G')
			AND T1.Adjust_Flag = 'A'
			GROUP BY T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus], T1.Account, T1.[RI Prog], T1.[RI Flag],	T1.YOA,	T1.YOI,	T1.CCYSettlement, T1.Adjust_Flag,	
						DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0))
		)
		UNION ALL
		(
			SELECT    T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus] ,T1.Account,'transactional' AS PremType,
						[RI Prog] AS Programme, [RI Flag] as RI_Flag	,T1.YOA,	T1.YOI,		
						DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)) QOI_End_Date,'I' AS RecognitionType,	T1.CCYSettlement, T1.Adjust_Flag, SUM(T1.[Value]) [Value]
			FROM #PremiumWithAdjustment T1
			INNER JOIN #RunDataRI  T2 ON  T1.MOI	=  T2.Adj_IP
								   AND T1.YOI = T2.[Reporting Year]
								   AND T1.Scenario = T2.IPSource
								   AND Adj_IP IS NOT NULL
			INNER JOIN IFRS17DataMart.Dim.AccountCodeMapping T3 ON T1.Account = T3.AccountCode
			WHERE 1 = 1
			AND T3.IsActive = 1 
			AND T3.[Type] = 'Premium' 
			AND T3.AccountCode in ('P-RP-P-FAC','P-RP-P-TTY','PC-LS-OR-FAC','PC-LS-OR-TTY','P-OR-P-FAC','P-OR-P-TTY')
			AND T1.Adjust_Flag = 'A'
			GROUP BY T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus], T1.Account, T1.[RI Prog], T1.[RI Flag],	T1.YOA,	T1.YOI,	T1.CCYSettlement, T1.Adjust_Flag,	
						DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0))
		)
	)D1a


----IDS DATA Forward Binder Transactional and Forecast Balances for ('P-BA-B','P-BP-B') Dataset 2 

    DROP TABLE IF EXISTS #Dataset2;  ------commented below and added new code as per CR 1807/1808 PK 12102021

	SELECT Pk_RequestId,	Entity,	Trifocus,[IFRS17 Trifocus], Account, PremType, Programme, RI_Flag, YOA, YOI,QOI_End_Date, RecognitionType, CCYSettlement, Adjust_Flag, [Value]
	INTO #Dataset2
	FROM
	(
        /* PK 270924- I17-7903- commented below section as for BBNI only Actuals are needed for yoa <= reporting year. there is no current yr/prior yr differentiation
		--CURRENT YOA
		SELECT T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus], T1.Account
					, CASE WHEN T1.Scenario = 'A' THEN 'transactional' ELSE 'forecast' END AS PremType, 
				[RI Prog] AS Programme, [RI Flag] as RI_Flag	,T1.YOA,	T1.YOI,	T1.MOI
					,DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)) QOI_End_Date,'I' AS RecognitionType,	T1.CCYSettlement, T1.Adjust_Flag, T1.[Value]
		FROM #MaxSMAsAtPeriodForGross T2 
		INNER JOIN #PremiumWithAdjustment T1 ON   T1.YOA = T2.[Reporting Year]
										  AND  T1.MOI = CASE WHEN RIGHT(T2.[Reporting Period],2) >= 12 THEN CONCAT((LEFT(T2.[Reporting Period],4) + 1),'01') ELSE (T2.[Reporting Period] + 1) END
										  AND  T1.AccountingPeriod = T2.[AsAtPeriod] 
										  AND  T1.Scenario = T2.Scenario
		INNER JOIN (SELECT [AccountCode], [Type] FROM IFRS17DataMart.Dim.AccountCodeMapping WHERE IsActive = 1 AND [Type] = 'Premium' AND [AccountCode] IN ('P-BA-B','P-BP-B')) T3 ON T1.Account = T3.AccountCode

		UNION ALL
		--PRIOR YOAs
		*/
		SELECT T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus], T1.Account 
			   , CASE WHEN T1.Scenario = 'A' THEN 'transactional' ELSE 'Forecast' END AS PremType, 
				[RI Prog] AS Programme, [RI Flag] as RI_Flag   ,T1.YOA,	T1.YOI,	T1.MOI
			   , DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)) QOI_End_Date,'I' AS RecognitionType,	T1.CCYSettlement, T1.Adjust_Flag, T1.[Value]
		FROM #MaxSMAsAtPeriodForGross T2 
		INNER JOIN #PremiumWithAdjustment T1 ON   T1.YOA < T2.[Reporting Year]
										  AND  T1.MOI = CASE WHEN RIGHT(T2.[Reporting Period],2) >= 12 THEN CONCAT((LEFT(T2.[Reporting Period],4) + 1),'01') ELSE (T2.[Reporting Period] + 1) END
										  AND  T1.Scenario = T2.Scenario
										  AND  T1.AccountingPeriod = T2.[AsAtPeriod] 
										  AND T1.Scenario = 'A'
		INNER JOIN (SELECT [AccountCode], [Type] 	FROM IFRS17DataMart.Dim.AccountCodeMapping 	WHERE IsActive = 1 	AND [Type] = 'Premium' 	AND [AccountCode] IN ('P-BA-B','P-BP-B')) T3 ON T1.Account = T3.AccountCode	
	)A	

	--SELECT * FROM #Dataset2

----IDS DATA for accounts (P-GP-P,P-AC-P,P-BP-B,P-BA-B,P-RP-P-FAC,P-RP-P-TTY) Dataset3 PFT Quarterly Financial Forecast balances 
------ As per CR 1807 11/10/2021 This query now takes care of all inception periods for the YOA which matches with reporting year. 
    DROP TABLE IF EXISTS #Dataset3;	

	SELECT Pk_RequestId , Entity, Trifocus, [IFRS17 Trifocus], Account, PremType, RI_Flag, Programme, YOA, YOI, QOI_End_Date , RecognitionType , CCYSettlement , Adjust_Flag , [Value]
	INTO #Dataset3
	FROM
	(
		(
		SELECT T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,	T1.[IFRS17 Trifocus], T1.Account, CASE WHEN T1.Scenario = 'A' THEN 'transactional' ELSE 'forecast' END AS PremType, 
					[RI Prog] AS Programme, [RI Flag] as RI_Flag	,T1.YOA,	T1.YOI,
					DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)) QOI_End_Date,'I' AS RecognitionType,	T1.CCYSettlement, T1.Adjust_Flag, SUM(T1.[Value]) [Value]
		FROM #PremiumWithAdjustment T1 
		INNER JOIN (SELECT DISTINCT Pk_RequestId, [Reporting Year], DATEPART(QUARTER,CONVERT(DATE, CONCAT(CAST([Reporting Period] AS varchar), '01'))) ReportingQuarter	, MaxSM_AsAt  
					FROM #MaxSMAsAtPeriodForGross) T2  ON  T1.YOA = T2.[Reporting Year]
											   AND CASE WHEN T1.Adjust_Flag = 'A' THEN T2.MaxSM_AsAt  ELSE  T1.AccountingPeriod END  = T2.MaxSM_AsAt
								 ------AND T1.MOI = T2.InceptionPeriod
								 ------AND T2.IPSource IS NOT NULL
		INNER JOIN (SELECT [AccountCode], [Type] FROM IFRS17DataMart.Dim.AccountCodeMapping WHERE IsActive = 1 AND [Type] = 'Premium'  )  T3 ON T1.Account = T3.AccountCode	
		WHERE 1 = 1
		----AND T1.AccountingPeriod = CONCAT(YEAR(DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0))), RIGHT(CONCAT('00',MONTH(DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)))),2))
		AND T1.Scenario = 'F'
		AND T1.Dataset  in ('PFT')-----------------Chaged as per I17-4896---(PK(160523) - reverted changes of 4896 )
		AND T3.AccountCode in ('P-GP-P','P-AC-P','P-BP-B','P-BA-B','GPE-RP-P','RP-ULT-G')
		GROUP BY T2.Pk_RequestId,	T1.Entity,	T1.Trifocus, T1.[IFRS17 Trifocus],T1.Account, T1.[RI Prog], T1.[RI Flag], CASE WHEN T1.Scenario = 'A' THEN 'transactional' ELSE 'forecast' END 
				,T1.YOA,	T1.YOI, DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)), T1.CCYSettlement, T1.Adjust_Flag
		)
		UNION ALL
		(
		SELECT T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,	T1.[IFRS17 Trifocus], T1.Account, CASE WHEN T1.Scenario = 'A' THEN 'transactional' ELSE 'forecast' END AS PremType, 
					[RI Prog] AS Programme, [RI Flag] as RI_Flag	,T1.YOA,	T1.YOI,
					DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)) QOI_End_Date,'I' AS RecognitionType,	T1.CCYSettlement, T1.Adjust_Flag, SUM(T1.[Value]) [Value]
		FROM #PremiumWithAdjustment T1 
		INNER JOIN (SELECT DISTINCT Pk_RequestId, [Reporting Year], DATEPART(QUARTER,CONVERT(DATE, CONCAT(CAST([Reporting Period] AS varchar), '01'))) ReportingQuarter	, MaxSM_AsAt  
					FROM #MaxSMAsAtPeriodForGross) T2  ON  T1.YOA = CASE WHEN T2.ReportingQuarter = 1 THEN  T2.[Reporting Year] ELSE (T2.[Reporting Year]+1) END
											   AND CASE WHEN T1.Adjust_Flag = 'A' THEN T2.MaxSM_AsAt  ELSE  T1.AccountingPeriod END  = T2.MaxSM_AsAt
		INNER JOIN (SELECT [AccountCode], [Type] FROM IFRS17DataMart.Dim.AccountCodeMapping WHERE IsActive = 1 AND [Type] = 'Premium'  )  T3 ON T1.Account = T3.AccountCode	
		INNER JOIN (SELECT Qtr, Scenario
					 FROM (VALUES
								(1 , 'B'),
								(4 , 'B')
							)AS TAB(Qtr, Scenario)) T4 ON T2.ReportingQuarter = T4.Qtr 
		WHERE 1 = 1
		AND T1.Scenario = T4.Scenario
		AND T3.AccountCode in ('P-GP-P','P-AC-P','P-BP-B','P-BA-B','GPE-RP-P','RP-ULT-G')
		GROUP BY T2.Pk_RequestId,	T1.Entity,	T1.Trifocus, T1.[IFRS17 Trifocus],T1.Account, T1.[RI Prog], T1.[RI Flag], CASE WHEN T1.Scenario = 'A' THEN 'transactional' ELSE 'forecast' END 
				,T1.YOA,	T1.YOI, DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)), T1.CCYSettlement, T1.Adjust_Flag
		)

		UNION ALL
		(
		SELECT T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,	T1.[IFRS17 Trifocus], T1.Account, CASE WHEN T1.Scenario = 'A' THEN 'transactional' ELSE 'forecast' END AS PremType, 
					[RI Prog] AS Programme, [RI Flag] as RI_Flag	,T1.YOA,	T1.YOI,
					DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)) QOI_End_Date,'I' AS RecognitionType,	T1.CCYSettlement, T1.Adjust_Flag, SUM(T1.[Value]) [Value]
		FROM #PremiumWithAdjustment T1 
		INNER JOIN (SELECT DISTINCT Pk_RequestId, [Reporting Year] , MaxSM_AsAt  
					FROM #MaxSMAsAtPeriodForRI) T2  ON  T1.YOA = T2.[Reporting Year]
											   AND CASE WHEN T1.Adjust_Flag = 'A' THEN T2.MaxSM_AsAt  ELSE  T1.AccountingPeriod END  = T2.MaxSM_AsAt
								 ----AND T1.MOI = T2.InceptionPeriod
								 ----AND T2.IPSource IS NOT NULL
		INNER JOIN (SELECT [AccountCode], [Type] FROM IFRS17DataMart.Dim.AccountCodeMapping WHERE IsActive = 1 AND [Type] = 'Premium'  )  T3 ON T1.Account = T3.AccountCode	
		WHERE 1 = 1
		----AND T1.AccountingPeriod = CONCAT(YEAR(DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0))), RIGHT(CONCAT('00',MONTH(DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)))),2))
		AND T1.Scenario = 'F'
		AND ((T3.AccountCode in ('P-RP-P-FAC','P-RP-P-TTY','PC-LS-OR-FAC','PC-LS-OR-TTY','P-OR-P-FAC','P-OR-P-TTY') AND T1.Dataset in ('PFT')) OR (T3.AccountCode = 'RP-T-PR' AND T1.Dataset = 'ReservingDataPremiumAlloc'))
		GROUP BY T2.Pk_RequestId,	T1.Entity,	T1.Trifocus, T1.[IFRS17 Trifocus],T1.Account, T1.[RI Prog], T1.[RI Flag], CASE WHEN T1.Scenario = 'A' THEN 'transactional' ELSE 'forecast' END 
				,T1.YOA,	T1.YOI, DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)), T1.CCYSettlement, T1.Adjust_Flag
		)
	)D3
	-----------------Chaged as per I17-4896
	--SELECT * FROM #Dataset3

-----Dataset 4 FUTURE INCEPTING PFT --- 11/10/2021 PK this is not needed as itis taken care in the above query for Dataset3 as per CR 1807
-- --   DROP TABLE IF EXISTS #Dataset4;	

-- --   SELECT T2.Pk_RequestId,    T1.Entity,    T1.Trifocus,    T1.[IFRS17 Trifocus], T1.Account, CASE WHEN T1.Scenario = 'A' THEN 'transactional' ELSE 'forecast' END AS PremType, 'GROSS' AS Programme, 'I' as RI_Flag    ,T1.YOA,    T1.YOI,
-- --       DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)) QOI_End_Date,'I' AS RecognitionType,    T1.CCYSettlement, T1.Adjust_Flag, SUM(T1.[Value]) [Value]
-- --   INTO #Dataset4
-- --   FROM #PremiumWithAdjustment T1
-- --   INNER JOIN  (SELECT [Pk_RequestId], [Reporting Year],[Reporting Period],MAX(InceptionPeriod) InceptionPeriod
-- --                FROM #RunData
-- --                where IPSource is not null
-- --                GROUP BY [Pk_RequestId], [Reporting Year],[Reporting Period]
                
-- --                )T2  ON  T1.YOA = T2.[Reporting Year]
-- --                   AND T1.AccountingPeriod  = T2.[Reporting Period]
-- --                   AND T1.MOI > T2.InceptionPeriod
-- --   INNER JOIN (SELECT [AccountCode], [Type] FROM IFRS17DataMart.Dim.AccountCodeMapping WHERE IsActive = 1 AND [Type] = 'Premium'  )  T3 ON T1.Account = T3.AccountCode   
-- --   WHERE 1 = 1
-- --   AND T1.Scenario = 'F'
-- --   AND T1.Dataset = 'PFT'
--	--AND T3.AccountCode in ('P-GP-P','P-AC-P','P-BP-B','P-BA-B','P-RP-P-FAC','P-RP-P-TTY')
-- --   GROUP BY T2.Pk_RequestId,    T1.Entity,    T1.Trifocus, T1.[IFRS17 Trifocus],T1.Account, CASE WHEN T1.Scenario = 'A' THEN 'transactional' ELSE 'forecast' END
-- --           ,T1.YOA,    T1.YOI, DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)), T1.CCYSettlement, T1.Adjust_Flag


-- FINAL INSERT INTO [IDS].[Aggr_PremiumBrokerage]


		INSERT INTO IFRS17DataMart.[IDS].[Aggr_PremiumBrokerage]
			  (RunID,	Entity,	[Tri focus code],	[IFRS17 Trifocus],	Account,	PremType,	Programme,	RI_Flag,	YOA,	YOI,	QOI_End_Date,	RecognitionType, CCY, Adjust_Flag,	[Amount], AuditUserCreate,	AuditCreateDateTime)
		SELECT Pk_RequestId,	Entity,	Trifocus,	[IFRS17 Trifocus], Account, PremType, Programme,CASE WHEN [RI_Flag]='G' THEN 'I' WHEN [RI_Flag]='R' THEN 'O' ELSE [RI_Flag] END AS RI_Flag, YOA, YOI,QOI_End_Date, RecognitionType, CCYSettlement, Adjust_Flag, [Value], SYSTEM_USER, GETDATE()
		FROM
		(
		SELECT Pk_RequestId,	Entity,	Trifocus,	[IFRS17 Trifocus], Account, PremType, Programme, RI_Flag, YOA, YOI,QOI_End_Date, RecognitionType, CCYSettlement, Adjust_Flag, [Value]	FROM #Dataset1
		UNION ALL
		SELECT Pk_RequestId,	Entity,	Trifocus,	[IFRS17 Trifocus], Account, PremType, Programme, RI_Flag, YOA, YOI,QOI_End_Date, RecognitionType, CCYSettlement, Adjust_Flag, [Value]	FROM #Dataset1a
		UNION ALL
		SELECT Pk_RequestId,	Entity,	Trifocus,	[IFRS17 Trifocus], Account, PremType, Programme, RI_Flag, YOA, YOI,QOI_End_Date, RecognitionType, CCYSettlement, Adjust_Flag, [Value]	FROM #Dataset2
		UNION ALL
		SELECT Pk_RequestId,	Entity,	Trifocus,	[IFRS17 Trifocus], Account, PremType, Programme, RI_Flag, YOA, YOI,QOI_End_Date, RecognitionType, CCYSettlement, Adjust_Flag, [Value]	FROM #Dataset3
		----UNION All 
		----SELECT Pk_RequestId,	Entity,	Trifocus,	[IFRS17 Trifocus], Account, PremType, Programme, RI_Flag, YOA, YOI,QOI_End_Date, RecognitionType, CCYSettlement, Adjust_Flag, [Value]	FROM #Dataset4
		)A

    END



	DROP TABLE IF EXISTS #RunDataGross;
	DROP TABLE IF EXISTS #RunDataRI;
	DROP TABLE IF EXISTS #MaxSMAsAtPeriodForGross;
	DROP TABLE IF EXISTS #MaxSMAsAtPeriodForRI;
	DROP TABLE IF EXISTS #PremiumWithAdjustment
    DROP TABLE IF EXISTS #Dataset1;
	DROP TABLE IF EXISTS #Dataset1a;
    DROP TABLE IF EXISTS #Dataset2;
    DROP TABLE IF EXISTS #Dataset3;
	----DROP TABLE IF EXISTS #Dataset4;
	

END