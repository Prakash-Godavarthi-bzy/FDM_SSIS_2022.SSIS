﻿
CREATE PROCEDURE [fct].[usp_PopulateIDSPremiumBrokerageSM_Policies] @RequestId INT
AS
BEGIN

SET NOCOUNT ON;

	BEGIN

--DECLARE @RequestId INT = 5

 	--- Identify the order of the scenario ,inception period and AsAt period selected
		DROP TABLE IF EXISTS #DataOrder
		SELECT T2.Pk_RequestId, T3.[Reporting Year], T3.[Reporting Period], T3.[Topup Gross >18m<3y Asat], T3.[Topup Gross >18m<3y Source], T3.[Topup Gross >3y Asat], T3.[Topup Gross >3y Source],	T2.Scenario
		,	T2.UptoPeriod,	T2.AsAtPeriod, T2.SortOrder,LAG(T2.UptoPeriod,1) OVER(ORDER BY T2.SortOrder) Previous_UpToPeriod
		INTO #DataOrder
		FROM
		(
			SELECT Pk_RequestId, Scenario,	UptoPeriod,	AsAtPeriod, ROW_NUMBER() OVER(PARTITION BY Pk_RequestId ORDER BY UptoPeriod) SortOrder
			FROM
				(
				SELECT Pk_RequestId,[SM Scenario Actual] AS Scenario, [SM Up to inception period Actual] AS UptoPeriod, [SM Reporting Period Actual] AS AsAtPeriod FROM PWAPS.IFRS17CalcUI_RunLog
				UNION
				SELECT Pk_RequestId,[SM Scenario Forecast] AS Scenario, [SM Up to inception period Forecast] AS UptoPeriod, [SM Reporting Period Forecast] AS AsAtPeriod FROM PWAPS.IFRS17CalcUI_RunLog
				UNION
				SELECT Pk_RequestId,[SM Scenario Business Plan] AS Scenario, [SM Up to inception period Business Plan] AS UptoPeriod, [SM Reporting Period Business Plan] AS AsAtPeriod FROM PWAPS.IFRS17CalcUI_RunLog
				)T1
			WHERE UptoPeriod IS NOT NULL
		)T2
		INNER JOIN PWAPS.IFRS17CalcUI_RunLog  T3 ON T2.Pk_RequestId = T3.Pk_RequestId 
		WHERE 1 = 1
		AND T2.Pk_RequestId = @RequestId


		--SELECT * FROM #DataOrder


	--- bring the sort order in right shape and fill the missing inception periods
	
		DROP TABLE IF EXISTS #RunConfig
		SELECT 
				Pk_RequestId
			  , [Reporting Year] 
			  , [Reporting Period] 
			  , [Topup Gross >18m<3y Asat]
			  , [Topup Gross >18m<3y Source]
			  , [Topup Gross >3y Asat]
			  , [Topup Gross >3y Source]
			  , SortOrder
			  ,	CASE WHEN SortOrder = 1
					 THEN CASE WHEN SortOrder_IP <= UptoPeriod THEN SortOrder_IP ELSE NULL End
					 ELSE CASE WHEN SortOrder = 2 
							   THEN CASE WHEN SortOrder_IP > Previous_UpToPeriod AND SortOrder_IP <= UptoPeriod THEN SortOrder_IP ELSE NULL End
							   ELSE CASE WHEN SortOrder = 3 
										 THEN CASE WHEN SortOrder_IP > Previous_UpToPeriod AND SortOrder_IP <= UptoPeriod THEN SortOrder_IP ELSE NULL End
									END
						  END
				END  MOI
			 , 	CASE WHEN SortOrder = 1
					 THEN CASE WHEN SortOrder_IP <= UptoPeriod THEN T1.Scenario ELSE NULL End
					 ELSE CASE WHEN SortOrder = 2 
							   THEN CASE WHEN SortOrder_IP > Previous_UpToPeriod AND SortOrder_IP <= UptoPeriod THEN T1.Scenario ELSE NULL End
							   ELSE CASE WHEN SortOrder = 3 
										 THEN CASE WHEN SortOrder_IP > Previous_UpToPeriod AND SortOrder_IP <= UptoPeriod THEN T1.Scenario ELSE NULL End
									END
						  END
				END Scenario
			 , 	CASE WHEN SortOrder = 1
					 THEN CASE WHEN SortOrder_IP <= UptoPeriod THEN T1.AsAtPeriod ELSE NULL End
					 ELSE CASE WHEN SortOrder = 2 
							   THEN CASE WHEN SortOrder_IP > Previous_UpToPeriod AND SortOrder_IP <= UptoPeriod THEN T1.AsAtPeriod ELSE NULL End
							   ELSE CASE WHEN SortOrder = 3 
										 THEN CASE WHEN SortOrder_IP > Previous_UpToPeriod AND SortOrder_IP <= UptoPeriod THEN T1.AsAtPeriod ELSE NULL End
									END
						  END
				END SM_AsAtPeriod
		INTO #RunConfig
		FROM #DataOrder T1
		CROSS APPLY
			(	
			SELECT AccountingPeriodName, AccountingYearName FROM DIM.AccountingPeriod WHERE AccountingMonth NOT IN (0,13)
			)A 			( SortOrder_IP, AccountingYearName)
		WHERE A.AccountingYearName IN ( T1.[Reporting Year], (T1.[Reporting Year] - 1))


--SELECT * FROM #RunConfig ORDER BY SortOrder, MOI

	--- Get only the months till which user selected the inception periods in the UI
		DROP TABLE IF EXISTS #RunConfigReArranged
		SELECT    Pk_RequestId
				, [Reporting Year]
				, [Reporting Period] 
				, T3.PK_Scenario AS [>18m<3y Source]	
				, [Topup Gross >18m<3y Asat] AS [>18m<3y AsAt]
				, T4.PK_Scenario AS [>3y Source]
				, [Topup Gross >3y Asat] AS [>3y AsAt]
				, SortOrder
				, MOI AS [Inception Period]
				, T2.PK_Scenario AS Scenario
				, SM_AsAtPeriod 
		INTO #RunConfigReArranged
		FROM #RunConfig t1
		LEFT JOIN DIM.Scenario T2 ON T1.Scenario = T2.ScenarioName
		LEFT JOIN DIM.Scenario T3 ON T1.[Topup Gross >18m<3y Source] = T3.ScenarioName
		LEFT JOIN DIM.Scenario T4 ON T1.[Topup Gross >3y Source] = T4.ScenarioName
		WHERE MOI IS NOT NULL

--SELECT * FROM #RunConfigReArranged

-----Get Max AsAt Period from SM. This will be used to get PFT data
-----COMMENTED BELOW AS PER CR 2933
 /*
	DROP TABLE IF EXISTS #MaxSMAsAtPeriod
	SELECT a.Pk_RequestId
			,a.[Reporting Year]
			,(SELECT MAX(SM_AsAt)
			  FROM (VALUES(a.[SM Reporting Period Actual]),(a.[SM Reporting Period Forecast]),(a.[SM Reporting Period Business Plan])) AS All_SMAsAt(SM_AsAt))  AS MaxSM_AsAt
	INTO #MaxSMAsAtPeriod
	FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog a
	WHERE Pk_RequestId = @RequestId
*/


	--select * from #RunConfigReArranged
-----Prepare premium data to include adjustments, if selected any in the model run.
	DROP TABLE IF EXISTS #PremiumWithAdjustment
	SELECT [Entity], [Trifocus], [IFRS17 Trifocus], [RI Prog], [RI Flag], [CCYSettlement], [Dataset], [Scenario], [Account], [AccountingPeriod], [YOA], [YOI], [MOI], Adjust_Flag, [Value]
	INTO #PremiumWithAdjustment
	FROM
		(
		SELECT T1.[Entity] ,T1.[Trifocus] ,T1.[IFRS17 Trifocus]  ,T1.[RI Prog]  ,T1.[RI Flag]  ,T1.[CCYSettlement]  ,T1.[Dataset]  ,T1.[Scenario]  ,T1.[Account]  ,T1.[AccountingPeriod]  ,T1.[YOA]  ,T1.[YOI]  ,[MOI]  ,[Value], NULL AS Adjust_Flag
		FROM [fct].[Aggr_PremiumLTD] T1

		UNION ALL

		SELECT	 T3.Entity	,T3.TriFocus	,T3.TriFocus AS [IFRS17 Trifocus] ,T3.Programme AS [RI Prog] ,T3.[Gross/RI Flag] AS [RI Flag]	,T3.CCY	 AS [CCYSettlement],CASE WHEN T3.Source = 'U'  THEN CASE When  T3.Account='GP-T-PR' Then 'ReservingData' When T3.Account='RP-T-PR' Then 'ReservingDataPremiumAlloc'  ELSE 'Adjsutment' END ELSE 'Adjustment' END AS Dataset
				,CASE WHEN T3.Source = 'U' THEN 'F' ELSE T3.Source END AS Scenario		,T3.Account	,NULL AS 	[AccountingPeriod],T3.YOA		,YEAR(T3.InceptionDate) AS YOI		,CONCAT(CAST(YEAR(T3.InceptionDate) AS VARCHAR), RIGHT(('0'+ CAST(MONTH(T3.InceptionDate) AS VARCHAR)),2)) AS MOI	,T3.[Value], 'A' AS Adjust_Flag
				--			,DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CONCAT(CAST(YEAR(T3.InceptionDate) AS VARCHAR), RIGHT(('0'+ CAST(MONTH(T3.InceptionDate) AS VARCHAR)),2)), '01')))+1 ,0)) QOI_End_Date
		FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog T1
		INNER JOIN [IFRS17DataMart].dim.AssumptionDatasets T2 ON T1.Adjustments = T2.AssumptionDatasetName
		LEFT JOIN [IFRS17DataMart].fct.AssumptionData T3 ON T2.Pk_AssumptionDatasetNameId = T3.Pk_AssumptionDatasetNameId
		WHERE 1 = 1
		AND T1.Pk_RequestId = @RequestId
		)A


---Dataset 1 Incepted Transactional balances (from P-GP-P,P-BP-B,P-AC-P, P-BA-B,,RP-G-P for Syndicate business)
----------YOI = ReportingYear 
	DROP TABLE IF EXISTS #DS1_CurrYOI
	SELECT T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus] ,T1.Account,'transactional' AS PremType, T1.[RI Prog] AS Programme, T1.[RI Flag]as RI_Flag	,T1.YOA,	T1.YOI,	--MOI	,
			FORMAT(DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)), 'dd/MM/yyyy') QOI_End_Date,'SM' AS RecognitionType,	T1.CCYSettlement,T1.Adjust_Flag, SUM(T1.[Value]) [Value]
	INTO #DS1_CurrYOI
	FROM #PremiumWithAdjustment T1
	INNER JOIN #RunConfigReArranged T2 ON  CASE WHEN T1.Adjust_Flag = 'A' THEN T2.[SM_AsAtPeriod]  ELSE  T1.AccountingPeriod END  = T2.[SM_AsAtPeriod] 
									  AND T1.YOI = T2.[Reporting Year]
									  AND T1.MOI = T2.[Inception Period]
									  AND T1.Scenario = T2.Scenario
	INNER JOIN (SELECT [AccountCode], [Type] FROM Dim.AccountCodeMapping WHERE IsActive = 1 AND [Type] = 'Premium' ) T3 ON T1.Account = T3.AccountCode
	WHERE 1 = 1
	AND T1.Account IN ('P-GP-P','P-AC-P','GPE-RP-P')
	GROUP BY T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus], T1.Account, T1.[RI Prog], T1.[RI Flag],	T1.YOA,	T1.YOI,	T1.CCYSettlement,	
				FORMAT(DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)), 'dd/MM/yyyy'),T1.Adjust_Flag

	--SELECT * FROM #DS1_CurrYOI WHERE Trifocus = '10' AND Entity = '2623' AND CCYSettlement = 'USD' ORDER BY Account, YOA, CCYSettlement, QOI_End_Date


---------YOI = ReportingYear - 1
	DROP TABLE IF EXISTS #DS1_PreYOI_NB
	SELECT T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus] ,T1.Account,'transactional' AS PremType, T1.[RI Prog] AS Programme, T1.[RI Flag]as RI_Flag	,T1.YOA,	T1.YOI,		
		   FORMAT(DATEADD(DD, -1, DATEADD(MM, DATEDIFF(MM, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)), 'dd/MM/yyyy') AS QOI_End_Date,'SM' AS RecognitionType,	T1.CCYSettlement,T1.Adjust_Flag, SUM(T1.[Value]) [Value]
	INTO #DS1_PreYOI_NB
	FROM #PremiumWithAdjustment T1
	INNER JOIN( SELECT DISTINCT
					  Pk_RequestId
					, [Reporting Year]
					, [Reporting Period]
					, Scenario
					, SM_AsAtPeriod
					,MAX([Inception Period]) [Inception Period]
				FROM #RunConfigReArranged
				GROUP BY Pk_RequestId, [Reporting Year], [Reporting Period], Scenario,SM_AsAtPeriod
				)T2 ON  CASE WHEN T1.Adjust_Flag = 'A' THEN T2.[SM_AsAtPeriod]  ELSE  T1.AccountingPeriod END  = T2.SM_AsAtPeriod
					AND T1.YOI = (T2.[Reporting Year] - 1)
					AND T1.MOI <=  T2.[Inception Period]
					AND T1.Scenario = T2.Scenario
					AND T2.Scenario = 'A'
	INNER JOIN (SELECT [AccountCode], [Type] FROM Dim.AccountCodeMapping WHERE IsActive = 1 AND [Type] = 'Premium' ) T3 ON T1.Account = T3.AccountCode
	WHERE 1 = 1
	AND T1.Account IN ('P-GP-P','P-AC-P','GPE-RP-P')
	GROUP BY T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus], T1.Account,T1.[RI Prog] ,T1.[RI Flag],	T1.YOA,	T1.YOI,	
	FORMAT(DATEADD(DD, -1, DATEADD(MM, DATEDIFF(MM, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)), 'dd/MM/yyyy') ,	T1.CCYSettlement,T1.Adjust_Flag

	--SELECT * FROM #DS1_PreYOI_NB WHERE Trifocus = '10' AND Entity = '2623'  AND CCYSettlement = 'USD' ORDER BY Account, YOA, CCYSettlement, QOI_End_Date

--------YOI < ReportingYear - 1
	DROP TABLE IF EXISTS #DS1_PrePreYOI
	SELECT T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus] ,T1.Account,'transactional' AS PremType, T1.[RI Prog] AS Programme, T1.[RI Flag]as RI_Flag	,T1.YOA,	T1.YOI		
		   ,FORMAT(DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS VARCHAR), '01')))+1 ,0)), 'dd/MM/yyyy')  AS QOI_End_Date,'SM' AS RecognitionType,	T1.CCYSettlement, T1.Adjust_Flag, SUM(T1.[Value]) [Value]
	INTO #DS1_PrePreYOI
	FROM #PremiumWithAdjustment T1
	INNER JOIN( SELECT DISTINCT
					  Pk_RequestId
					, [Reporting Year]
					, [Reporting Period]
					, Scenario
					, SM_AsAtPeriod
					,MAX([Inception Period]) [Inception Period]
				FROM #RunConfigReArranged
				GROUP BY Pk_RequestId, [Reporting Year], [Reporting Period], Scenario,SM_AsAtPeriod
				)T2 ON  CASE WHEN T1.Adjust_Flag = 'A' THEN T2.[SM_AsAtPeriod]  ELSE  T1.AccountingPeriod END  = T2.SM_AsAtPeriod
					AND T1.YOI < (T2.[Reporting Year] - 1)
					AND T1.MOI <=  T2.[Inception Period]
					AND T1.Scenario = T2.Scenario
					AND T2.Scenario = 'A'
	INNER JOIN (SELECT [AccountCode], [Type] FROM Dim.AccountCodeMapping WHERE IsActive = 1 AND [Type] = 'Premium' ) T3 ON T1.Account = T3.AccountCode
	WHERE 1 = 1
	AND T1.Account IN ('P-GP-P','P-AC-P','GPE-RP-P')
	GROUP BY T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus], T1.Account,T1.[RI Prog], T1.[RI Flag],	T1.YOA,	T1.YOI,	
	FORMAT(DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)), 'dd/MM/yyyy'),	T1.CCYSettlement, T1.Adjust_Flag

	--SELECT * FROM #DS1_PrePreYOI WHERE Trifocus = '10' AND Entity = '2623'  AND CCYSettlement = 'USD' ORDER BY Account, YOA, CCYSettlement, QOI_End_Date

------Dataset 2 - Full Year Financial Forecast balances - Open Years (from P-GP-P,P-BP-B, RP-G-P for Syndicate business)
DECLARE @ReportingPeriod INT
SELECT DISTINCT  @ReportingPeriod = [Reporting Period] FROM #RunConfigReArranged

	DROP TABLE IF EXISTS #DS2_PFT
	SELECT T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus] ,T1.Account,'forecast_topup' AS PremType, T1.[RI Prog] AS Programme, T1.[RI Flag]as RI_Flag	,T1.YOA
			--, 9999 AS YOI		,'31/12/' + CAST(T1.YOA AS VARCHAR) AS QOI_End_Date
		   ,YEAR(CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01'))) AS YOI
		   ,FORMAT(DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)), 'dd/MM/yyyy') AS QOI_End_Date
		   ,'SM' AS RecognitionType,	T1.CCYSettlement, T1.Adjust_Flag, SUM(T1.[Value]) [Value]
	INTO #DS2_PFT
	FROM #PremiumWithAdjustment T1
	INNER JOIN( SELECT DISTINCT
					  Pk_RequestId
					, [Reporting Year]
					, [Reporting Period]
					, [>18m<3y Asat]
					, [>18m<3y Source] 
				FROM #RunConfigReArranged
				)T2 ON  CASE WHEN T1.Adjust_Flag = 'A' THEN [>18m<3y Asat]  ELSE  T1.AccountingPeriod END  = [>18m<3y Asat]
				AND T1.Scenario = CASE WHEN T2.[>18m<3y Source] = 'U' THEN 'F' ELSE T2.[>18m<3y Source] END
	LEFT JOIN (SELECT DISTINCT A.FK_YOA, A.FK_Trifocus, A.Programme, A.Open_Cls_Flag
					FROM DIM.OpenCloseYOA A
					INNER JOIN (SELECT FK_Trifocus, FK_YOA,Programme , MAX(FK_AccountingPeriod) MAX_AC
								FROM DIM.OpenCloseYOA
								WHERE 
								1 = 1
								AND FK_AccountingPeriod <= @ReportingPeriod
								GROUP BY FK_Trifocus, FK_YOA, Programme
								) B ON A.FK_Trifocus = B.FK_Trifocus 
									AND A.FK_YOA = B.FK_YOA 
									AND A.Programme = B.Programme
									AND A.FK_AccountingPeriod = B.MAX_AC
				)T4 ON T1.Trifocus = T4.FK_Trifocus AND T1.YOA = T4.FK_YOA AND T1.[RI Prog] = T4.Programme
	WHERE 1 = 1
	--AND T1.Scenario = 'F' --COMMENTED THE TWO ROWS FR CR 2933
	AND T1.Dataset = 'PFT'
	AND T4.Open_Cls_Flag = 'Open'
	AND T1.Account IN (SELECT AccountCode FROM [IDS].[udf_GetAccountList] (T2.[>18m<3y Source]) )
	GROUP BY T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus], T1.Account,T1.[RI Prog], T1.[RI Flag],T1.YOA,	YEAR(CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01'))),
	FORMAT(DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)), 'dd/MM/yyyy') ,	T1.CCYSettlement, T1.Adjust_Flag

	--SELECT * FROM #DS2_PFT WHERE Trifocus = '10' AND Entity = '2623'  AND CCYSettlement = 'USD' ORDER BY Account, YOA, CCYSettlement, QOI_End_Date


------Dataset 3 -  Ultimate Forecast balances (from GP-T-PR for Syndicate business)
---------------updated Dataset to 'Reservingdata_TOPUP' instead of 'Reservingdata' as per I!7-4896 

	DROP TABLE IF EXISTS #DS3_Reservingdata
	SELECT T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus] ,T1.Account,'forecast_ult_topup' AS PremType,  T1.[RI Prog] AS Programme, T1.[RI Flag]as RI_Flag	,T1.YOA,	
		  CASE WHEN T1.YOI = 1980 THEN 9999 ELSE T1.YOI END YOI	,
		  --,('31/12/' + CAST(T1.YOA AS VARCHAR)) AS QOI_End_Date
		  FORMAT(DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)), 'dd/MM/yyyy') AS QOI_End_Date
		  ,'SM' AS RecognitionType,	T1.CCYSettlement, T1.Adjust_Flag, SUM(T1.[Value]) [Value]
	INTO #DS3_Reservingdata
	FROM #PremiumWithAdjustment T1
	INNER JOIN( SELECT DISTINCT
					  Pk_RequestId
					, [Reporting Year]
					, [Reporting Period]
					, [>3y AsAt]
					, [>3y Source] 
				FROM #RunConfigReArranged
				)T2 ON  CASE WHEN T1.Adjust_Flag = 'A' THEN [>3y AsAt]  ELSE  T1.AccountingPeriod END  = [>3y AsAt]
				AND T1.Scenario = CASE WHEN T2.[>3y Source] = 'U' THEN 'F' ELSE T2.[>3y Source] END
	WHERE 1 = 1
	--AND T1.Scenario = 'F' --COMMENTED THE TWO ROWS FR CR 2933
	AND ((T1.Dataset = 'Reservingdata' AND Account = 'GP-T-PR') OR (T1.Dataset = 'ReservingDataPremiumAlloc' AND Account = 'RP-T-PR') OR Account = 'RP-ULT-G') --Added this for datafix 3932 and then for 4191, accounts are needed specifically from two datasets otherwise it will double count.
	--AND T1.Account IN (SELECT AccountCode FROM [IDS].[udf_GetAccountList] (T2.[>3y Source]) ) --Commented this for datafix 3932, need to uncomment once RP-T-PR data comes correctly.
	GROUP BY T2.Pk_RequestId,	T1.Entity,	T1.Trifocus,T1.[IFRS17 Trifocus], T1.Account, T1.[RI Prog], T1.[RI Flag],	T1.YOA, CASE WHEN T1.YOI = 1980 THEN 9999 ELSE T1.YOI END,
	FORMAT(DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)), 'dd/MM/yyyy'), T1.CCYSettlement, T1.Adjust_Flag

	--SELECT * FROM #DS3_Reservingdata WHERE Trifocus = '10' AND Entity = '2623'  AND CCYSettlement = 'USD' ORDER BY Account, YOA, CCYSettlement, QOI_End_Date


------ FINAL INSERT INTO [IDS].[Aggr_PremiumBrokerage]
	INSERT INTO [IDS].[Aggr_PremiumBrokerage]
		  (RunID,	Entity,	[Tri focus code],	[IFRS17 Trifocus],	Account,	PremType,	Programme,	RI_Flag,	YOA,	YOI,	QOI_End_Date,	RecognitionType, CCY, Adjust_Flag,	[Amount],AuditCreateDateTime, AuditUserCreate)

	SELECT Pk_RequestId,	Entity,	Trifocus,	[IFRS17 Trifocus], Account, PremType, Programme,CASE WHEN [RI_Flag]='G' THEN 'I' WHEN [RI_Flag]='R' THEN 'O' ELSE [RI_Flag] END AS RI_Flag , YOA, YOI,QOI_End_Date, RecognitionType, CCYSettlement, Adjust_Flag, [Value], GETDATE(), SYSTEM_USER
	FROM
	(
	SELECT Pk_RequestId,	Entity,	Trifocus,	[IFRS17 Trifocus], Account, PremType, Programme, RI_Flag, YOA, YOI,CONVERT(DATE,QOI_End_Date,103) AS QOI_End_Date , RecognitionType, CCYSettlement, Adjust_Flag ,[Value]	FROM #DS1_CurrYOI
	UNION ALL
	SELECT Pk_RequestId,	Entity,	Trifocus,	[IFRS17 Trifocus], Account, PremType, Programme, RI_Flag, YOA, YOI,CONVERT(DATE,QOI_End_Date,103) AS QOI_End_Date , RecognitionType, CCYSettlement, Adjust_Flag, [Value]	FROM #DS1_PreYOI_NB
	UNION ALL
	SELECT Pk_RequestId,	Entity,	Trifocus,	[IFRS17 Trifocus], Account, PremType, Programme, RI_Flag, YOA, YOI,CONVERT(DATE,QOI_End_Date,103) AS QOI_End_Date , RecognitionType, CCYSettlement, Adjust_Flag, [Value]	FROM #DS1_PrePreYOI
	UNION ALL
	SELECT Pk_RequestId,	Entity,	Trifocus,	[IFRS17 Trifocus], Account, PremType, Programme, RI_Flag, YOA, YOI,CONVERT(DATE,QOI_End_Date,103) AS QOI_End_Date , RecognitionType, CCYSettlement, Adjust_Flag, [Value]	FROM #DS2_PFT
	UNION ALL
	SELECT Pk_RequestId,	Entity,	Trifocus,	[IFRS17 Trifocus], Account, PremType, Programme, RI_Flag, YOA, YOI,CONVERT(DATE,QOI_End_Date,103) AS QOI_End_Date , RecognitionType, CCYSettlement, Adjust_Flag, [Value]	FROM #DS3_Reservingdata
	)A

    END
	DROP TABLE IF EXISTS #RunConfig;
	DROP TABLE IF EXISTS #RunConfigReArranged;
	DROP TABLE IF EXISTS #PremiumWithAdjustment
    DROP TABLE IF EXISTS #DS1_CurrYOI;
    DROP TABLE IF EXISTS #DS1_PreYOI_NB;
    DROP TABLE IF EXISTS #DS1_PrePreYOI;
    DROP TABLE IF EXISTS #DS2_PFT;
    DROP TABLE IF EXISTS #DS3_Reservingdata;	


END
