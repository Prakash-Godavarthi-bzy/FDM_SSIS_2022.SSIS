﻿
--declare  @RequestId INT = 103
CREATE PROCEDURE [fct].[usp_PopulateIDS_All_AggrPremiumBrokerage] @RequestId INT
AS
BEGIN

DECLARE @RunIDExistsTarget INT
, @RunIDExistsSource INT
, @ErrorMessage NVARCHAR(4000)
, @ErrorLine INT

	DROP TABLE IF EXISTS #DistinctRunIdTarget
	SELECT DISTINCT RUNID
	INTO #DistinctRunIdTarget
	FROM IDS.Aggr_PremiumBrokerage T1



	SET @RunIDExistsTarget = ISNULL((SELECT T1.RunID
						   FROM #DistinctRunIdTarget  T1
						   WHERE RunID = @RequestId), 0)
	SET @RunIDExistsSource = CASE WHEN  (SELECT Pk_RequestId 
										FROM PWAPS.IFRS17CalcUI_RunLog T1
										WHERE Pk_RequestId = @RequestId) IS NULL 
								  THEN 0 
								  ELSE 1
							END

	--SELECT @RunIDExistsTarget, @RunIDExistsSource

	BEGIN
	IF  @RunIDExistsTarget = 0 AND @RunIDExistsSource = 1
	BEGIN

		BEGIN
		/*Call procedure for IR*/
			BEGIN TRY
			EXECUTE [fct].[usp_PopulateIDSPremiumBrokerage] @RequestId
			END TRY

			BEGIN CATCH

			 SET   @ErrorMessage = ERROR_MESSAGE() 
			 SET   @ErrorLine = ERROR_LINE()

			EXECUTE PWAPS.usp_LogFailures  1, 'IR', 'usp_PopulateIDSPremiumBrokerage', @ErrorLine, @ErrorMessage

			END CATCH
		END

		BEGIN
		/*Call procedure for SM policy RI*/
			BEGIN TRY
			EXECUTE [fct].[usp_PopulateIDSPremiumBrokerageSM_Policies_RI] @RequestId
			END TRY
		
			BEGIN CATCH
			 SET   @ErrorMessage = ERROR_MESSAGE() 
			 SET   @ErrorLine = ERROR_LINE()
			EXECUTE PWAPS.usp_LogFailures  2, 'SM', 'usp_PopulateIDSPremiumBrokerageSM_Policies_RI',  @ErrorLine, @ErrorMessage
			END CATCH
		END
		

		BEGIN
		/*Call procedure for SM Policies*/
			BEGIN TRY
			EXECUTE [fct].[usp_PopulateIDSPremiumBrokerageSM_Policies] @RequestId
			END TRY
		
			BEGIN CATCH
			 SET   @ErrorMessage = ERROR_MESSAGE() 
			 SET   @ErrorLine = ERROR_LINE()
			EXECUTE PWAPS.usp_LogFailures  3, 'SM', 'usp_PopulateIDSPremiumBrokerageSM_Policies',  @ErrorLine, @ErrorMessage
			END CATCH
		END
		
		BEGIN
		/*Call procedure for SM binder*/
			BEGIN TRY
			EXECUTE [fct].[usp_PopulateIDSPremiumBrokerageSM_Binder] @RequestId
			END TRY

			BEGIN CATCH
			 SET   @ErrorMessage = ERROR_MESSAGE() 
			 SET   @ErrorLine = ERROR_LINE()
			EXECUTE PWAPS.usp_LogFailures  4, 'SM', 'usp_PopulateIDSPremiumBrokerageSM_Binder',  @ErrorLine, @ErrorMessage
			END CATCH

		END

		BEGIN
		/*Call procedure for SM FSC RI*/
			BEGIN TRY
			EXECUTE [fct].[usp_PopulateIDSPremiumBrokerageFSC_RI] @RequestId
			END TRY

			BEGIN CATCH
			 SET   @ErrorMessage = ERROR_MESSAGE()
			 SET   @ErrorLine = ERROR_LINE()
			EXECUTE PWAPS.usp_LogFailures  5, 'SM', 'usp_PopulateIDSPremiumBrokerageFSC_RI',  @ErrorLine, @ErrorMessage
			END CATCH

		END

		BEGIN
		/*Call procedure for SM FSC*/
			BEGIN TRY
			EXECUTE [fct].[usp_PopulateIDSPremiumBrokerageFSC] @RequestId
			END TRY
		
			BEGIN CATCH
			 SET   @ErrorMessage = ERROR_MESSAGE()
			 SET   @ErrorLine = ERROR_LINE()
			EXECUTE PWAPS.usp_LogFailures  6, 'SM', 'usp_PopulateIDSPremiumBrokerageFSC',  @ErrorLine, @ErrorMessage 
			END CATCH
		END
	END
	END

END