﻿CREATE  Procedure  [fct].[usp_PopulateIDSHistPremLockRatesOB] (@RunId Int)
AS
BEGIN
IF NOT EXISTS(SELECT 1 FROM IFRS17DataMart.IDS.HistPremLockRatesOB WHERE RunID = @RunId)
	BEGIN
	INSERT INTO IFRS17DataMart.IDS.HistPremLockRatesOB(
			 RunID       
			,QOI_End_Date
			,Programme   
			,FocusGroup  
			,CCY         
			,[Amount]    
			
			)
	SELECT 					
			   T2.Pk_RequestId		
			   ,T1.QOI_End_Date
			   ,T1.Programme 	
			   ,T1.FocusGroup 	
			   ,T1.CCY 		
			   ,T1.[Amount] 	
			   
		FROM [IFRS17PsicleData].[Results].[HistPremLockRatesOB] T1
	INNER JOIN IFRS17DataMart.PWAPS.IFRS17CalcUI_RunLog T2 ON T1.RunID = T2.[Opening Balances Id]
	WHERE T2.Pk_RequestId = @RunId
	END

END