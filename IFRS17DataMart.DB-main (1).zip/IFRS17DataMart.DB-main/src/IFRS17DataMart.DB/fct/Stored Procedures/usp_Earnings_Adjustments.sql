CREATE PROCEDURE [fct].[usp_Earnings_Adjustments] (@RequestId int)
AS
BEGIN

DECLARE @Adjust_Selected CHAR(1)


SELECT @Adjust_Selected = CASE WHEN Adjustments IS NULL THEN 'N' ELSE 'Y' END FROM [PWAPS].[IFRS17CalcUI_RunLog] WHERE Pk_RequestId = @RequestId
--SELECT @Adjust_Selected

IF @Adjust_Selected = 'Y'

	BEGIN 

		DROP TABLE IF EXISTS #STEP1
		SELECT	 
			T3.Entity	
			,T3.TriFocus	
			,T3.TriFocus AS [IFRS17 Trifocus] 
			,T3.Programme AS [RI Prog] 
			,T3.[Gross/RI Flag] AS [RI Flag]	
			,T3.CCY	 AS [CCYSettlement]
			,CASE WHEN T3.Source = 'U' THEN 'Reserving Data' ELSE 'Adjustment' END AS Dataset
			,T3.Source AS Scenario		
			,T3.Account
			,T3.AdjustmentID
			,T4.[FieldLabel]
			,T3.YOA		
			,YEAR(T3.InceptionDate) AS YOI		
			--,CONCAT(CAST(YEAR(T3.InceptionDate) AS VARCHAR), RIGHT(('0'+ CAST(MONTH(T3.InceptionDate) AS VARCHAR)),2)) AS MOI	
			,T3.[Value]
			,T3.EarnedPercentage
			,CASE WHEN T3.InceptionDate IS NOT NULL THEN DATEDIFF(DAY,T3.InceptionDate,DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, cast(concat(T1.[Reporting Period],'01') as date))+1 ,0))) + 1 END AS Earned_Duration
			,CASE WHEN T3.InceptionDate IS NOT NULL THEN CASE WHEN T3.EarnedPercentage <> 0 THEN ((DATEDIFF(DAY,T3.InceptionDate,DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, cast(concat(T1.[Reporting Period],'01') as date))+1 ,0))) + 1)/T3.EarnedPercentage) ELSE 0 END END Implied_Policy_Duration
			,CASE WHEN T3.InceptionDate IS NOT NULL THEN DATEADD(DAY,CASE WHEN T3.EarnedPercentage <> 0 THEN ((DATEDIFF(DAY,T3.InceptionDate,DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, cast(concat(T1.[Reporting Period],'01') as date))+1 ,0))) + 1)/T3.EarnedPercentage) ELSE 0 END,T3.InceptionDate) END Implied_Expiry_Date
			, 'A' AS Adjust_Flag
			,T3.InceptionDate
			,DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CONCAT(CAST(YEAR(T3.InceptionDate) AS VARCHAR), RIGHT(('0'+ CAST(MONTH(T3.InceptionDate) AS VARCHAR)),2)), '01')))+1 ,0)) QOI_End_Date
		INTO #STEP1
		FROM [PWAPS].[IFRS17CalcUI_RunLog] T1
		INNER JOIN dim.AssumptionDatasets T2 ON T1.Adjustments = T2.AssumptionDatasetName
		LEFT JOIN fct.AssumptionData T3 ON T2.Pk_AssumptionDatasetNameId = T3.Pk_AssumptionDatasetNameId
		LEFT JOIN [Dim].[AccountCodeMapping] T4 ON T3.Account = T4.[AccountCode] 
		WHERE 1 = 1
		AND T1.Pk_RequestId = @RequestId
		AND T4.ISACTIVE = 1 
		AND T4.[TYPE] = 'Premium'
		AND T4.AccountCode IN ('P-GP-P','P-BP-B')
		AND T3.[Source] = 'A'
		----Select * from #STEP1 where AdjustmentID=145502

		DROP TABLE IF EXISTS #STEP2
		SELECT  DISTINCT 
			  @RequestId AS RunID
			, AdjustmentID
			, DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, T2.[Date])+1 ,0)) Earn_qtr
			,Adjust_Flag as Earning_Category
			,[RI Prog] as Programme
			,TriFocus
			,Scenario
			,YOI
			,YOA
			,QOI_End_Date
			,CCYSettlement
			, CASE WHEN Implied_Policy_Duration <> 0
				   THEN (CASE WHEN Implied_Expiry_Date >= DATEADD(QQ, DATEDIFF(QQ, 0,T2.[Date]), 0)
							  THEN CASE WHEN InceptionDate BETWEEN DATEADD(QQ, DATEDIFF(QQ, 0,T2.[Date]), 0) AND DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, T2.[Date])+1 ,0))
										THEN DATEDIFF(DD,InceptionDate, DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, T2.[Date])+1 ,0)) ) + 1
										ELSE CASE WHEN DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, T2.[Date])+1 ,0)) <= Implied_Expiry_Date
												  THEN DATEDIFF(DD, DATEADD(QQ, DATEDIFF(QQ, 0,T2.[Date]), 0), DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, T2.[Date])+1 ,0))) + 1
												  ELSE DATEDIFF(DD, DATEADD(QQ, DATEDIFF(QQ, 0,T2.[Date]), 0), Implied_Expiry_Date) 
											 END
									 END
						  END 
						  /
						  Implied_Policy_Duration
						  )
					ELSE 0
				END AdjEarnedPerc
		INTO #STEP2
		FROM #STEP1 T1
		LEFT JOIN [IFRS17DataMart].dim.[Date] T2 ON T2.[Date] >= InceptionDate AND T2.[Date] <= Implied_Expiry_Date


	----SELECT * FROM #STEP2 WHERE AdjustmentID =145502


			/** Inserting data into FSC_Per_QOI_adj table With cummulative value **/
			IF NOT EXISTS(
			SELECT [RunID] FROM
			[fct].[FSC_Per_QOI_adj]
			WHERE [RunID]=@RequestId
			) AND @Adjust_Selected = 'Y'
				BEGIN

				INSERT INTO [fct].[FSC_Per_QOI_adj]([RunID],[AdjustmentID],[Earn_qtr],[Earning Category],[Programme],[FK_Trifocus],[FK_Scenario],[FK_InceptionYear],[QOI],[CCYSett],[Pattern])
				SELECT RunID, AdjustmentID, Earn_qtr, Earning_Category, Programme, TriFocus, Scenario, YOI, QOI_End_Date ,CCYSettlement
					, CASE WHEN SUM(AdjEarnedPerc)	OVER(PARTITION BY RunID, AdjustmentID, Earning_Category, Programme, TriFocus, Scenario, YOI, QOI_End_Date, CCYSettlement) <> 0
						  THEN (SUM(AdjEarnedPerc)	OVER(PARTITION BY RunID, AdjustmentID, Earning_Category, Programme, TriFocus, Scenario, YOI, QOI_End_Date, CCYSettlement	ORDER BY Earn_qtr) -----this gives each quarter percentage
								/
								SUM(AdjEarnedPerc)	OVER(PARTITION BY RunID, AdjustmentID, Earning_Category, Programme, TriFocus, Scenario, YOI, QOI_End_Date, CCYSettlement) 
								)
						  ELSE 0
					 END 
				FROM #STEP2
				----WHERE AdjustmentID = 145502
				END

			/** Inserting data into FSC_Per_YOA_adj table With cummulative value **/
			IF NOT EXISTS(
			SELECT [RunID] FROM
			[fct].[FSC_Per_YOA_adj]
			WHERE [RunID]=@RequestId
			) AND @Adjust_Selected = 'Y'
				BEGIN

				INSERT INTO [fct].[FSC_Per_YOA_adj]([RunID] ,[AdjustmentID],[Earn_qtr],[Earning Category],[Programme],[FK_Trifocus],[FK_Scenario],[FK_InceptionYear],[FK_YOA],[CCYSettlement],[Pattern])
				SELECT RunID, AdjustmentID, Earn_qtr, Earning_Category, Programme, TriFocus, Scenario, YOI, YOA,CCYSettlement
					, CASE WHEN SUM(AdjEarnedPerc)	OVER(PARTITION BY RunID, AdjustmentID, Earning_Category, Programme, TriFocus, Scenario, YOI, YOA,  CCYSettlement) <> 0
						  THEN (SUM(AdjEarnedPerc)	OVER(PARTITION BY RunID, AdjustmentID, Earning_Category, Programme, TriFocus, Scenario, YOI, YOA,  CCYSettlement	ORDER BY Earn_qtr) -----this gives each quarter percentage
								/
								SUM(AdjEarnedPerc)	OVER(PARTITION BY RunID, AdjustmentID, Earning_Category, Programme, TriFocus, Scenario, YOI, YOA,  CCYSettlement) 
								)
						  ELSE 0
					 END 
				FROM #STEP2
				----WHERE AdjustmentID = 145502
				END
	END

	DROP TABLE IF EXISTS #STEP1
	DROP TABLE IF EXISTS #STEP2

END