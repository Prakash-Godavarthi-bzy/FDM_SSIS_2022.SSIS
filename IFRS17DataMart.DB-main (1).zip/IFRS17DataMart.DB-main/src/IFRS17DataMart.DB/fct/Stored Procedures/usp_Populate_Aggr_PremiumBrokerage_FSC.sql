﻿  
Create PROCEDURE [fct].[usp_Populate_Aggr_PremiumBrokerage_FSC] @RequestId INT
As
BEGIN


IF NOT EXISTS(
select runid from
[IDS].[Aggr_PremiumBrokerage]
where runid=@RequestId
)
BEGIN


  INSERT INTO [IDS].[Aggr_PremiumBrokerage]
  ([RunID],Entity,[Tri focus code],[IFRS17 Trifocus],[Account],[Premtype],[Programme],[RI_Flag],[YOA],[YOI],[QOI_End_Date],
  [RecognitionType],[CCY],[Adjust_Flag],[Amount],[AuditCreateDateTime],[AuditUserCreate])
 (
  SELECT 
  T1.Pk_RequestId
  ,T3.Entity   
    ,T3.TriFocus   
    ,T3.TriFocus AS [IFRS17 Trifocus]
	,'FSC'+Substring(FieldLabel,CHARINDEX('_',FieldLabel,0),len(FieldLabel)) AS Account
	,[Type] as [Premtype]
    ,T3.Programme AS [RI Prog]
    ,T3.[Gross/RI Flag] AS [RI Flag]  
	,T3.YOA AS YOA 
	,YEAR(T3.InceptionDate) AS YOI 
	 ,DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CONCAT(CAST(YEAR(T3.InceptionDate) AS VARCHAR), RIGHT(('0'+ CAST(MONTH(T3.InceptionDate) AS VARCHAR)),2)), '01')))+1 ,0)) QOI_End_Date
	 ,'SM' as RecognizationType
    ,T3.CCY AS [CCY]
	,'A' as Adjust_Flag
	,T3.[Value] * (1- T3.EarnedPercentage) as Amount
	,GETDATE() as AuditCreateDateTime
	,SUSER_NAME() as AuditUserCreate
    FROM [TechnicalHub].[stg].[MappingTotransformationLog] T1
    INNER JOIN TechnicalHub.dim.AssumptionDatasets T2 ON T1.Adjustments = T2.AssumptionDatasetName
    LEFT JOIN TechnicalHub.fct.All_WB_Committed T3 ON T2.Pk_AssumptionDatasetNameId = T3.Pk_AssumptionDatasetNameId
    LEFT JOIN IFRS17DATAMART.[Dim].[AccountCodeMapping] T4 ON T3.Account = T4.[AccountCode] AND T4.ISACTIVE = 1 AND [TYPE] = 'Premium'
    WHERE 1 = 1
    AND T1.Pk_RequestId =@RequestId--3111--@RequestId-- 3114--3111

	)

	END

	END