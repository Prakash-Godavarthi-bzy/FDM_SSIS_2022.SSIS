﻿
CREATE  Procedure  [fct].[usp_PopulateIDSUndiscCSMWalkBalancesOB] (@RunId Int)
AS
BEGIN

IF NOT EXISTS (SELECT DISTINCT 1 FROM [IFRS17DataMart].IDS.UndiscCSMWalkBalancesOB WHERE RunID = @RunId)
BEGIN
DROP TABLE IF EXISTS #DistinctOpenClosedOBCSM
SELECT  DISTINCT T2.RunID,T2.[Tri focus code], T2.YOA ,T2.Programme, T1.[Open/Closed Derivation]
INTO #DistinctOpenClosedOBCSM
FROM [IFRS17PsicleData].[Results].OpenClosedOB T1
INNER JOIN (SELECT DISTINCT RunID,[Tri focus code], YOA ,Programme
		    FROM [IFRS17PsicleData].[Results].UndiscCSMWalkBalancesOB 
			)T2 ON  T2.[Tri focus code]=T1.[Tri focus code] AND T1.YOA=T2.YOA  AND T1.Programme = T2.Programme AND T1.RunID = T2.RunID		
WHERE T1.RunID = @RunId

	BEGIN
		Insert into [IFRS17DataMart].IDS.UndiscCSMWalkBalancesOB(
		 RunID					
		,Entity					
		,[Tri focus code]		
		,[IFRS17 Tri focus code] 
		,Programme				
		,RI_Flag					
		,YOA						
		,YOI						
		,QOI_End_Date			
		,CCY						
		,InceptedStatus			
		,[Open/Closed]			
		,Statement				
		,Position				
		,Balance					
		,Amount						
		,Amount_disc
		)
		select 
			 T3.Pk_RequestId				
			,T1.Entity 					
			,T1.[Tri focus code] 		
			,T1.[IFRS17 Tri focus code]	
			,T1.Programme 				
			,T1.RI_Flag 				
			,T1.YOA 					
			,T1.YOI 					
			,T1.QOI_End_Date 			
			,T1.CCY 					
			,T1.InceptedStatus 
			,(SELECT [Open/Closed Derivation] 
				FROM #DistinctOpenClosedOBCSM T2
				WHERE T2.[Tri focus code]=T1.[Tri focus code] 
				AND T1.YOA=T2.YOA  
				AND T1.Programme = T2.Programme 
				AND T1.RunID = T2.RunID
				) [Open/Closed Derivation]
			,T1.Statement 				
			,T1.Position 				
			,T1.Balance 				
			,T1.Amount 					
			,T1.Amount_disc
		FROM [IFRS17PsicleData].Results.UndiscCSMWalkBalancesOB T1
		INNER JOIN [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog T3 ON T1.RunID = T3.[Opening Balances Id]
		where T3.Pk_RequestId = @RunId

		END
	DROP TABLE IF EXISTS #DistinctOpenClosedOBCSM
END
END