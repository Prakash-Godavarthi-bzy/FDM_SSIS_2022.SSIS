﻿CREATE  Procedure  [fct].[usp_PopulateIDSPreStatementBalancesOB] (@RunId Int)
AS

BEGIN

IF NOT EXISTS(SELECT 1 FROM IFRS17DataMart.IDS.PreStatementBalancesOB WHERE RunID = @RunId)
	BEGIN
	INSERT INTO IFRS17DataMart.IDS.PreStatementBalancesOB(
			 RunID                   
			,Entity                  
			,[Tri focus code]        
			,[IFRS17 Tri focus code] 
			,Account                 
			,Programme               
			,RI_Flag                 
			,YOA                     
			,YOI                     
			,QOI_End_Date            
			,RecognitionType         
			 ,CCY                     
			 ,[Incepted Status]       
			 ,[Open / Closed]         
			 ,Amount 
			)
	SELECT 
			    T2.Pk_RequestId 					
			   ,T1.Entity 					
			   ,T1.[Tri focus code] 		
			   ,T1.[IFRS17 Tri focus code] 
			   ,T1.Account 				
			   ,T1.Programme 				
			   --,T1.RI_Flag 
			    ,CASE WHEN T1.[RI_Flag]='G' THEN 'I' WHEN T1.[RI_Flag]='R' THEN 'O' ELSE T1.[RI_Flag] END AS RI_Flag
			   ,T1.YOA 					
			   ,T1.YOI 					
			   ,T1.QOI_End_Date 			
			   ,T1.RecognitionType 		
			   ,T1.CCY 					
			    ,T1.[Incepted Status] 		
				,T1.[Open / Closed] 		
				, T1.Amount 					
	FROM [IFRS17PsicleData]. Results.PreStatementBalancesOB T1
	INNER JOIN IFRS17DataMart.PWAPS.IFRS17CalcUI_RunLog T2 ON T1.RunID = T2.[Opening Balances Id]
	WHERE T2.Pk_RequestId = @RunId
	END
END