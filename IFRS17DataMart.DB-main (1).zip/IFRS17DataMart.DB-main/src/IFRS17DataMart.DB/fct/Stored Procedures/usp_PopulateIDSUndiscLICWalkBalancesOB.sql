﻿
CREATE  Procedure  [fct].[usp_PopulateIDSUndiscLICWalkBalancesOB] (@RunId Int)
AS
BEGIN
IF NOT EXISTS(SELECT DISTINCT 1 FROM [IFRS17DataMart].[IDS].[UndiscLICWalkBalancesOB] WHERE RunID = @RunId)
BEGIN
DROP TABLE IF EXISTS #DistinctOpenClosedOBLIC
SELECT  DISTINCT T2.RunID,T2.[Tri focus code], T2.YOA ,T2.Programme, T1.[Open/Closed Derivation]
INTO #DistinctOpenClosedOBLIC
FROM [IFRS17PsicleData].[Results].OpenClosedOB T1
INNER JOIN (SELECT DISTINCT RunID,[Tri focus code], YOA ,Programme
		    FROM [IFRS17PsicleData].[Results].[UndiscLICWalkBalancesOB] 
			)T2 ON  T2.[Tri focus code]=T1.[Tri focus code] AND T1.YOA=T2.YOA  AND T1.Programme = T2.Programme AND T1.RunID = T2.RunID
WHERE T1.RunID = @RunId

			
	BEGIN
	Insert into [IFRS17DataMart].[IDS].[UndiscLICWalkBalancesOB](
		 RunID                   
		,Entity                  
		,[Tri focus code]        
		,[IFRS17 Tri focus code] 
		,Account                 
		,Programme               
		,RI_Flag                 
		,YOA                     
		,YOI                     
		,QOI_End_Date            
		,CCY                     
		,InceptedStatus          
		,[Open/Closed]           
		,Statement               
		,Position                
		,Balance					
		,Amount					
		)
		select 
			 T3.Pk_RequestId 					
			,T1.Entity 					
			,T1.[Tri focus code] 		
			,T1.[IFRS17 Tri focus code] 
			,T1.Account 				
			,T1.Programme 				
			--,T1.RI_Flag 		
			 ,CASE WHEN T1.[RI_Flag]='G' THEN 'I' WHEN T1.[RI_Flag]='R' THEN 'O' ELSE T1.[RI_Flag] END AS RI_Flag
			,T1.YOA 					
			,T1.YOI 					
			,T1.QOI_End_Date 			
			,T1.CCY 					
			,T1.InceptedStatus 			
			,(SELECT [Open/Closed Derivation] 
				FROM #DistinctOpenClosedOBLIC T2
				WHERE T2.[Tri focus code]=T1.[Tri focus code] 
				AND T1.YOA=T2.YOA  
				AND T1.Programme = T2.Programme 
				AND T1.RunID = T2.RunID
				) [Open/Closed Derivation]
			,T1.Statement 	
			,T1.Position 	
			,T1.Balance 	
			,T1.Amount 		

		 from [IFRS17PsicleData].[Results].[UndiscLICWalkBalancesOB] T1
	    INNER JOIN [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog T3 ON T1.RunID = T3.[Opening Balances Id]
		where T3.Pk_RequestId = @RunId

		END
	DROP TABLE IF EXISTS #DistinctOpenClosedOBLIC
END
END