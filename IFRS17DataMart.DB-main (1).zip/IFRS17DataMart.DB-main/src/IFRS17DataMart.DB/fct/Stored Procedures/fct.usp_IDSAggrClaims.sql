﻿CREATE PROCEDURE [fct].[usp_IDSAggrClaims] @RequestId INT
AS
BEGIN

IF NOT EXISTS(
SELECT DISTINCT RunID 
FROM [IDS].[Aggr_Claims]
WHERE runid=@RequestId
AND Adjust_Flag	IS NULL
)

BEGIN
INSERT INTO [IDS].[Aggr_Claims]([RunID],[Entity],[Tri focus code],[Account],[Programme],[RI_Flag],[Loss_Type],[YOA],[YOI],[CCY],[Amount],[AuditCreateDateTime]
,[AuditUserCreate])
SELECT 
      T1.Pk_RequestId
	  ,Entity
      ,Trifocus
      , Account
	  ,[RI Prog]
	  --,'GROSS'
	  ,[RI Flag]
	  ,[Loss Type]
	  ,YOA
      ,ISNULL(YOI, '') AS YOI
      ,CCYSettlement AS CCY
      ,SUM([Value]) AS Amount
      ,GETDATE() AS AuditCreateDateTime
      ,SUSER_SNAME() AS AuditUserCreate
	  
FROM [fct].[Aggr_NonPremiumLTD] T
INNER JOIN PWAPS.IFRS17CalcUI_RunLog T1 ON T.AccountingPeriod=T1.[SM Reporting Period Actual]
INNER JOIN Dim.AccountCodeMapping T2 ON T.Account=T2.AccountCode
WHERE Pk_RequestId = @RequestId 
AND T.MOI <= CAST(T1.[SM Up to inception period Actual] AS INT)
AND T2.IsActive=1
AND T2.[Type] IN ('Incurred')
--AND T2.AccountCode IN ('C-FP-ATT','C-FI-ATT','C-FP-LL', 'C-II-ATT','C-IP-ATT', 'C-IP-LL', 
--'C-II-LL', 'C-FI-LL','C-DI-ATT', 'C-DI-LL',' C-DP-ATT','C-DP-LL')
GROUP BY 
       T1.Pk_RequestId
      ,[Entity]
      ,[Trifocus]
      ,[Account]
      ,[RI Prog]
	  ,[RI Flag]
	  ,[Loss Type]
	  ,YOA
      ,ISNULL(YOI, '')
      ,CCYSettlement
END
END
