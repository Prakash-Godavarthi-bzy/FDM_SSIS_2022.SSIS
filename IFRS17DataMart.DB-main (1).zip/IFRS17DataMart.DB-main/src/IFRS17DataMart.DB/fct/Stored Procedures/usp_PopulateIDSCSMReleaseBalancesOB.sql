﻿CREATE  Procedure  [fct].[usp_PopulateIDSCSMReleaseBalancesOB] (@RunId Int)
AS
BEGIN
IF NOT EXISTS(SELECT 1 FROM IFRS17DataMart.IDS.CSMReleaseBalancesOB WHERE RunID = @RunId)
	BEGIN
	INSERT INTO IFRS17DataMart.IDS.CSMReleaseBalancesOB(
			 [RunID]
      ,[Entity]
      ,[Tri focus code]
      ,[IFRS17 Tri Focus Code]
      ,[Account]
      ,[Programme]
      ,[RI_Flag]
      ,[YoI]
      ,[RecognitionType]
      ,[CCY]
      ,[Open_Closed]
      ,[Quarter]
      ,[Value]		
			
			)
	SELECT 					
			   T2.Pk_RequestId,		
      T1.[Entity]
      ,T1.[Tri focus code]
      ,T1.[IFRS17 Tri Focus Code]
      ,T1.[Account]
      ,T1.[Programme]
      ,T1.[RI_Flag]
      ,T1.[YoI]
      ,T1.[RecognitionType]
      ,T1.[CCY]
      ,T1.[Open_Closed]
      ,T1.[Quarter]
      ,T1.[Value]			
			   
		FROM [IFRS17PsicleData].Results.CSMReleaseBalancesOB T1
	INNER JOIN IFRS17DataMart.PWAPS.IFRS17CalcUI_RunLog T2 ON T1.RunID = T2.[Opening Balances Id]
	WHERE T2.Pk_RequestId = @RunId
	END

END