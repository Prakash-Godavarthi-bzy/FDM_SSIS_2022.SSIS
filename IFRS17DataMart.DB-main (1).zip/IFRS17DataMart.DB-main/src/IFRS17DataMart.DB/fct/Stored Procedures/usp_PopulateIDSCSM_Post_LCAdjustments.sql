﻿CREATE  Procedure  [fct].[usp_PopulateIDSCSM_Post_LCAdjustments] (@RunId Int)
AS
BEGIN
IF NOT EXISTS(SELECT 1 FROM IFRS17DataMart.[IDS].[CSM_Post_LCAdjustments] WHERE RunID = @RunId)
    BEGIN
    INSERT INTO IFRS17DataMart.[IDS].[CSM_Post_LCAdjustments](
             [RunID]
            ,[Entity]
            ,[FocusGroup]
            ,[Tri focus Code]
            ,[IFRS17 Tri focus code]
            ,[Programme]
            ,[RI_Flag]
            ,[YOA]
            ,[YOI]
            ,[QOI_End_Date]
            ,[CCY]
            ,[Incepted Status]
            ,[Statement]
            ,[Balance]
            ,[Position]
            ,[Amount]
            ,[Amount_disc]
            ,[Conv_Amount]
           ,[Conv_Amount_disc]
            ,[UOA]
            ,[CSM_LC]
            ,[Portfolio]        
             )
    SELECT                     
             T2.Pk_RequestId
             ,T1.[Entity]
             ,T1.[FocusGroup]
             ,T1.[Tri Focus Code]
             ,T1.[IFRS17 Tri Focus Code]
             ,T1.[Programme]
             ,T1.[RI_Flag]
             ,T1.[YOA]
             ,T1.[YOI]
             ,T1.[QOI_End_Date]
             ,T1.[CCY]
             ,T1.[Incepted Status]
             ,T1.[Statement]
             ,T1.[Balance]
             ,T1.[Position]
             ,T1.[Amount]
             ,T1.[Amount_disc]
             ,T1.[Conv_Amount]
             ,T1.[Conv_Amount_disc]
             ,T1.[UOA]
             ,T1.[CSM_LC]
             ,T1.[Portfolio]   
        FROM [IFRS17PsicleData].[Reporting].[CSM_Post_LCAdjustments] T1
    INNER JOIN IFRS17DataMart.PWAPS.IFRS17CalcUI_RunLog T2 ON T1.RunID = T2.[Opening Balances Id]
    WHERE T2.Pk_RequestId = @RunId
    END
END