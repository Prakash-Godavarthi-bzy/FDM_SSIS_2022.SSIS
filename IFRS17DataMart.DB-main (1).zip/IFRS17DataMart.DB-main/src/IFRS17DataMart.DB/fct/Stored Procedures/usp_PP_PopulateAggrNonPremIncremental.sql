﻿CREATE PROCEDURE [fct].[usp_PP_PopulateAggrNonPremIncremental](@AccPer INT)
AS
BEGIN
--DECLARE @AccPer INT = 202402

;WITH NewData AS 
(
SELECT FK_Account AS Account, FK_Entity AS Entity, FK_Trifocus AS Trifocus, [IFRS17 Trifocus], FK_YOA AS YOA, CCYSettlement, Fk_dataset AS Dataset, FK_scenario AS Scenario, FK_inceptionyear AS YOI
,Inceptionperiod As MOI
, CAST(CASE WHEN EventDate <> '1900-01-01 00:00:00.000'  THEN EventDate ELSE NULL END AS DATE)  AS EventDate
, [RI Flag]
, CASE [RI Flag]	WHEN   'I' THEN 'GROSS'	ELSE [RI Prog]    END 	[RI Prog]
 , [Loss Type]
 , [Type]
 , sum(value) [value]
FROM STG.fct_AggrData_NonPremium
GROUP BY FK_Account, FK_Entity, FK_Trifocus, [IFRS17 Trifocus], FK_YOA, CCYSettlement, Fk_dataset, FK_scenario, FK_inceptionyear, Inceptionperiod
, CAST(CASE WHEN EventDate <> '1900-01-01 00:00:00.000'  THEN EventDate ELSE NULL END AS DATE)  
, [RI Flag]
, CASE [RI Flag]	WHEN   'I' THEN 'GROSS'	ELSE [RI Prog]    END 
 , [Loss Type]
 , [Type]
)

--INSERT INTO FCT.Aggr_NonPremiumLTD(AccountingPeriod,Account ,Entity	,CCYSettlement ,Dataset ,Trifocus	,YOI   ,MOI	   ,YOA	   ,[RI Flag]  ,[RI Prog]		,[IFRS17 Trifocus]  ,Scenario   ,[Loss Type]   ,[Type]	   ,EventDate, [Value])
SELECT @AccPer AS AccountingPeriod,Account ,Entity	,CCYSettlement ,Dataset ,Trifocus	,YOI   ,MOI	   ,YOA	   ,[RI Flag]  ,[RI Prog]		,[IFRS17 Trifocus]  ,Scenario   ,[Loss Type]   ,[Type]	   ,EventDate, SUM([Value]) [Value]
FROM
(
SELECT Account ,Entity	,CCYSettlement ,Dataset ,Trifocus	,YOI   ,MOI	   ,YOA	   ,[RI Flag]  ,[RI Prog]		,[IFRS17 Trifocus]  ,Scenario   ,[Loss Type]   ,[Type]	   ,EventDate, [Value]				
FROM NewData 
)a
GROUP BY Account ,Entity	,CCYSettlement ,Dataset ,Trifocus	,
YOI   ,MOI	   ,YOA	   ,[RI Flag]  ,[RI Prog]		,[IFRS17 Trifocus]  ,Scenario   ,[Loss Type]   ,[Type]	   ,EventDate
OPTION (MAXDOP 1)
END