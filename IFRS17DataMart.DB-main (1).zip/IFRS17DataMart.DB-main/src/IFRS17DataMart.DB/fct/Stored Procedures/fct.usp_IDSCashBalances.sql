﻿

CREATE PROCEDURE [fct].[usp_IDSCashBalances] @RequestId INT
As
BEGIN

IF NOT EXISTS(
select runid from
[IDS].[Aggr_CashExcludingClaims]
where runid=@RequestId
AND Adjust_Flag	IS NULL
)

BEGIN




INSERT INTO [IDS].[Aggr_CashExcludingClaims]
(RunID,Entity,[Tri focus code],[IFRS17 TrifocusCode],Account,Programme,RI_Flag,YOA,YOI,CCY,Amount,AuditCreateDateTime,AuditUserCreate)

SELECT 
	   T2.Pk_RequestId
      ,[Entity]
      ,[Trifocus]
	  ,[IFRS17 Trifocus]
	  ,[Account]
	  ,[RI Prog] as [Programme]
	  --,[RI Flag] as [RI Flag]
	  ,CASE WHEN [RI Flag]='G' THEN 'I' WHEN [RI Flag]='R' THEN 'O' ELSE [RI Flag] END AS [RI Flag]
	  ,[YOA]
	  ,[YOI]
      ,[CCYSettlement] as CCY
      ,SUM([Value]) as Amount
	  ,getdate() as [AuditCreateDateTime]
	  ,suser_sname() as [AuditUserCreate]
  FROM [fct].[Aggr_NonPremiumLTD] T1
	 INNER JOIN PWAPS.IFRS17CalcUI_RunLog T2 ON T1.AccountingPeriod = T2.[SM Reporting Period Actual]
	 INNER JOIN dim.AccountCodeMapping DH ON T1.Account=DH.AccountCode
  WHERE T2.Pk_RequestId = @RequestId
  AND T1.MOI <= CAST(T2.[SM Up to inception period Actual] AS int)
  AND DH.IsActive=1
  AND DH.Type in ('Cash')
 -- AND DH.AccountCode IN ('PC-LS-OT','PC-OS-OT','PC-SD-OT','BC-LS-OT','BC-OS-OT','BC-SD-OT','PC-LS-PC','PC-SD-PC')

  GROUP BY 
       T2.Pk_RequestId	
      ,[Entity]
      ,[Trifocus]
      ,[IFRS17 Trifocus]
      ,[RI Prog]
      ,[RI Flag]
      ,[CCYSettlement]
      ,[Account]
      ,[YOA]
	  ,YOI

END
END
GO


