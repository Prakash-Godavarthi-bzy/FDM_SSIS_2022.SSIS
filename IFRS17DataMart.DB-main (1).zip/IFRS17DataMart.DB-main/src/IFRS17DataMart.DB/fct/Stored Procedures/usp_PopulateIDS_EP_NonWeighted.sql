﻿CREATE PROCEDURE [fct].[usp_PopulateIDS_EP_NonWeighted] @RequestId INT ,@RIFlag CHAR(1)
AS

BEGIN

--DECLARE @RequestID INT = 4085
--DECLARE @RIFlag CHAR(1) = 'O'

DECLARE @RunID_Exists CHAR(1)
DECLARE @Source CHAR(1)
DECLARE @Adjustment_Exists CHAR(1)


	DROP TABLE IF EXISTS #Scenario
	SELECT  DISTINCT 
			T3.Pk_RequestId
		,	T3.[Reporting Period]
		,   CASE WHEN T3.Adjustments IS NULL THEN 'N' ELSE 'Y'END Adjustment_Exists
		,   T1.RI_Flag
		,	CASE Scenario
				WHEN 'Actual' THEN 'A'
				WHEN 'Forecast' THEN 'F'
				WHEN 'Budget' THEN 'B'
			END as Scenario
		,	AsAtPeriod
		,   ISNULL(CAST(T2.RunID AS char), 'N') RunID_Exists 
		--,'N' RunID_Exists
	INTO #Scenario
	FROM
		(
				SELECT Pk_RequestId, 'I' AS RI_Flag,[SM Scenario Actual] AS Scenario, [SM Up to inception period Actual] AS UptoPeriod, [SM Reporting Period Actual] AS AsAtPeriod							FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog
				UNION
				SELECT Pk_RequestId, 'I' AS RI_Flag,[SM Scenario Forecast] AS Scenario, [SM Up to inception period Forecast] AS UptoPeriod, [SM Reporting Period Forecast] AS AsAtPeriod					FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog
				UNION
				SELECT Pk_RequestId, 'I' AS RI_Flag,[SM Scenario Business Plan] AS Scenario, [SM Up to inception period Business Plan] AS UptoPeriod, [SM Reporting Period Business Plan] AS AsAtPeriod		FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog
				UNION
				SELECT Pk_RequestId, 'O' AS RI_Flag,[SM Scenario Actual] AS Scenario, [RI SM Up to inception period Actual] AS UptoPeriodR, [RI SM Reporting Period Actual] AS AsAtPeriod					FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog
				UNION
				SELECT Pk_RequestId, 'O' AS RI_Flag,[SM Scenario Forecast] AS Scenario, [RI SM Up to inception period Forecast] AS UptoPeriod, [RI SM Reporting Period Forecast] AS AsAtPeriod				FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog
				UNION
				SELECT Pk_RequestId, 'O' AS RI_Flag,[SM Scenario Business Plan] AS Scenario, [RI SM Up to inception period Business Plan] AS UptoPeriod, [RI SM Reporting Period Business Plan] AS AsAtPeriod   FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog
		)T1
	INNER JOIN [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog  T3 ON T1.Pk_RequestId = T3.Pk_RequestId 
	LEFT JOIN IDS.EarningPatterns T2 ON T1.Pk_RequestId = T2.RunID AND T1.RI_Flag = T2.RI_Flag
	WHERE 1 = 1
	AND T1.UptoPeriod IS NOT NULL
	AND T3.Pk_RequestId = @RequestId
	AND T1.RI_Flag = @RIFlag
	AND	T2.RunID IS NULL

	------SELECT * FROM #Scenario

-------Assign RunID_Exists value to variable so that if its 'N' then below process will run else not And Check single or multiple source.
		SELECT @RunID_Exists =  RunID_Exists --, @Adjustment_Exists = Adjustment_Exists, @Source = COUNT(Scenario) 
		FROM #Scenario  group by RunID_Exists--, Adjustment_Exists
		--SELECT @RunID_Exists , @Adjustment_Exists , @Source


-------Populate EP based on Gross SM selection USING RIFlag
		IF  @RunID_Exists = 'N' --AND @Source = 1 AND @Adjustment_Exists = 'N' 
			BEGIN
		
				BEGIN
				----Insert YOI-YOA  Pattern
				INSERT INTO [IDS].[EarningPatterns]([RunID]      ,[Pat_Type]      ,[Tri Focus Code]      ,[Programme]      ,[RI_Flag]      ,[YOA]      ,[YOI]      ,[QOI]      ,[CCY]      ,[Qtr]      ,[Perc])
				SELECT
					   T1.Pk_RequestId 
					  ,'E' AS Pat_Type
					  ,T2.[FK_Trifocus]
					  ,T2.[Programme]
					  --,'N' AS [RI_Flag]
					  ,CASE WHEN T2.Programme = 'GROSS' 
							THEN 'I'  
							WHEN T2.Programme NOT IN ('GROSS', 'UNKNOWN') 
							THEN 'O'
							ELSE NULL 
						END AS [RI_Flag]
					  ,T2.[FK_YOA]
					  ,T2.[FK_InceptionYear] AS YOI
					  ,NULL AS QOI
					  ,T2.[CCYSettlement]
					  ,T2.[Earn_qtr] AS Qtr
					  ,T2.[Pattern] AS [Perc]
					  --,T2.[Earn_qtr]
				FROM #Scenario  T1
				INNER JOIN [fct].[FSC_Per_YOA] T2 ON T1.[AsAtPeriod]	= T2.FK_AccountingPeriod
													AND T1.Scenario		= T2.FK_Scenario
													AND T1.RI_Flag = CASE WHEN T2.Programme IS NOT NULL
																			THEN CASE WHEN T2.Programme =  'GROSS' THEN 'I' 
																						ELSE 'O'
																					END
																		END	
				WHERE T1.RI_Flag = @RIFlag
				END
		
				BEGIN
				----Insert YOI-QOI  Pattern
				INSERT INTO [IDS].[EarningPatterns]([RunID]      ,[Pat_Type]      ,[Tri Focus Code]      ,[Programme]      ,[RI_Flag]      ,[YOA]      ,[YOI]      ,[QOI]      ,[CCY]      ,[Qtr]      ,[Perc])
				SELECT
					   T1.Pk_RequestId 
					  ,'E' AS Pat_Type
					  ,T2.[FK_Trifocus]
					  ,T2.[Programme]
					 -- ,'N' AS [RI_Flag]
					  ,CASE WHEN T2.Programme = 'GROSS' 
							THEN 'I'  
							WHEN T2.Programme NOT IN ('GROSS', 'UNKNOWN') 
							THEN 'O'
							ELSE NULL 
						END AS [RI_Flag] 
					  ,NULL AS [YOA]
					  ,T2.[FK_InceptionYear] AS YOI
					  ,T2.QOI 
					  ,T2.[CCYSett]
					  ,T2.[Earn_qtr] AS Qtr
					  ,T2.[Pattern] AS [Perc]
					  --,T2.[Earn_qtr]
				FROM #Scenario  T1
				INNER JOIN [fct].[FSC_Per_QOI] T2 ON T1.[AsAtPeriod]	= T2.FK_AccountingPeriod
													AND T1.Scenario		= T2.FK_Scenario
													AND T1.RI_Flag = CASE WHEN T2.Programme IS NOT NULL
																			THEN CASE WHEN T2.Programme =  'GROSS' THEN 'I' 
																						ELSE 'O'
																					END
																		END	
				WHERE T1.RI_Flag = @RIFlag
				END

			END

DROP TABLE IF EXISTS #Scenario
END