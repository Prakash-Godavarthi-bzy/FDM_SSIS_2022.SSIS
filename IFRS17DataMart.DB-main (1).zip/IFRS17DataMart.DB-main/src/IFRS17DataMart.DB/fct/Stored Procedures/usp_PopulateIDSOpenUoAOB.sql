﻿CREATE  Procedure  [fct].[usp_PopulateIDSOpenUoAOB] (@RunId Int)
AS
BEGIN
IF NOT EXISTS(SELECT 1 FROM [IFRS17DataMart].IDS.OpenUoAOB WHERE RunID = @RunId)
	BEGIN
	INSERT INTO [IFRS17DataMart].IDS.OpenUoAOB(
			 RunID            
			,TFYOI            
			,Entity           
			,FocusGroup       
			,UOA              
			,YOI              
			,Programme        
			,[Tri focus code] 
			,[Tri focus]      
			,TFUOA            
			,Onerosity        
			,[CSM_LC]         

			
			)
	SELECT 					
			    T2.Pk_RequestId		
			   ,T1.TFYOI 			
			   ,T1.Entity 			
			   ,T1.FocusGroup 		
			   ,T1.UOA 			
			   ,T1.YOI 			
			   ,T1.Programme 		
			   ,T1.[Tri focus code]
			   ,T1.[Tri focus] 	
			   ,T1.TFUOA 			
			   ,T1.Onerosity 		
			   ,T1.[CSM_LC] 		
		
		FROM [IFRS17PsicleData].Results.OpenUoAOB T1
	INNER JOIN [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog T2 ON T1.RunID = T2.[Opening Balances Id]
	WHERE T2.Pk_RequestId = @RunId
	END

END