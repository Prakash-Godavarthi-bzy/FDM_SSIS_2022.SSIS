﻿

CREATE PROCEDURE [fct].[usp_PopulateIDS_EP_Weighted]  @RequestId INT ,@RIFlag CHAR(1)
AS

BEGIN

--DECLARE @RequestId INT = 56
--DECLARE @RIFlag CHAR(1) = 'I'

DECLARE @RunID_Exists CHAR(1)
DECLARE @Source CHAR(1)
DECLARE @Adjustment_Exists CHAR(1)


		DROP TABLE IF EXISTS #DataOrderEP
		SELECT T2.Pk_RequestId, T3.[Reporting Year], T3.[Reporting Period], T3.[OB Reporting Period],	T2.Scenario,T2.RI_Flag	,T2.UptoPeriod,	T2.AsAtPeriod, T2.SortOrder,LAG(T2.UptoPeriod,1) OVER(ORDER BY T2.SortOrder) Previous_UpToPeriod , T3.Adjustments 
		, ISNULL(CAST(T4.RunID AS char), 'N') RunID_Exists 
		--, 'N'  RunID_Exists
		INTO #DataOrderEP
		FROM
		(
			SELECT Pk_RequestId, Scenario,	UptoPeriod,RI_Flag,	AsAtPeriod, CASE WHEN UptoPeriod IS NULL THEN NULL ELSE ROW_NUMBER() OVER(PARTITION BY Pk_RequestId,RI_Flag ORDER BY UptoPeriod ) END SortOrder
			FROM
				(
				SELECT Pk_RequestId, 'I' AS RI_Flag,[SM Scenario Actual] AS Scenario, [SM Up to inception period Actual] AS UptoPeriod, [SM Reporting Period Actual] AS AsAtPeriod							FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog
				UNION
				SELECT Pk_RequestId, 'I' AS RI_Flag,[SM Scenario Forecast] AS Scenario, [SM Up to inception period Forecast] AS UptoPeriod, [SM Reporting Period Forecast] AS AsAtPeriod					FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog
				UNION
				SELECT Pk_RequestId, 'I' AS RI_Flag,[SM Scenario Business Plan] AS Scenario, [SM Up to inception period Business Plan] AS UptoPeriod, [SM Reporting Period Business Plan] AS AsAtPeriod		FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog
				UNION
				SELECT Pk_RequestId, 'O' AS RI_Flag,[SM Scenario Actual] AS Scenario, [RI SM Up to inception period Actual] AS UptoPeriodR, [RI SM Reporting Period Actual] AS AsAtPeriod					FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog
				UNION
				SELECT Pk_RequestId, 'O' AS RI_Flag,[SM Scenario Forecast] AS Scenario, [RI SM Up to inception period Forecast] AS UptoPeriod, [RI SM Reporting Period Forecast] AS AsAtPeriod				FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog
				UNION
				SELECT Pk_RequestId, 'O' AS RI_Flag,[SM Scenario Business Plan] AS Scenario, [RI SM Up to inception period Business Plan] AS UptoPeriod, [RI SM Reporting Period Business Plan] AS AsAtPeriod   FROM [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog

				)T1
			WHERE UptoPeriod IS NOT NULL 
			
		)T2
		INNER JOIN [IFRS17DataMart].PWAPS.IFRS17CalcUI_RunLog  T3 ON T2.Pk_RequestId = T3.Pk_RequestId 
		LEFT JOIN IFRS17DataMart.IDS.EarningPatterns T4 ON T2.Pk_RequestId = T4.RunID AND T2.RI_Flag = T4.RI_Flag
		WHERE 1 = 1
		AND T2.Pk_RequestId = @RequestId
		AND T2.RI_Flag = @RIFlag
		AND T4.RunID IS NULL

-------Assign RunID_Exists value to variable so that if its 'N' then below process will run else not.
		SELECT DISTINCT @RunID_Exists =  RunID_Exists  
		FROM #DataOrderEP 


IF @RunID_Exists = 'N' 
------/*If Run ID does not exist in target table then proceed.
	  /*Bring the sort order in right shape and fill the missing inception periods */
	BEGIN
		DROP TABLE IF EXISTS #RunConfigEP
		SELECT 
				Pk_RequestId
			  ,[Reporting Year] 
			  ,[Reporting Period] 
			  ,[OB Reporting Period]
			  ,[Adjustments] 
			  ,RI_Flag
			  , SortOrder
			  ,	CASE WHEN SortOrder = 1
						THEN CASE WHEN SortOrder_IP <= UptoPeriod  THEN SortOrder_IP ELSE NULL End
						ELSE CASE WHEN SortOrder = 2 
								THEN CASE WHEN SortOrder_IP > Previous_UpToPeriod AND SortOrder_IP <= UptoPeriod THEN SortOrder_IP ELSE NULL End
								ELSE CASE WHEN SortOrder = 3 
											THEN CASE WHEN SortOrder_IP > Previous_UpToPeriod AND SortOrder_IP <= UptoPeriod THEN SortOrder_IP ELSE NULL End
									END
							END
				END	MOI
			 ,CASE WHEN SortOrder = 1
					THEN CASE WHEN SortOrder_IP <= UptoPeriod THEN T1.Scenario ELSE NULL End
					ELSE CASE WHEN SortOrder = 2 
							THEN CASE WHEN SortOrder_IP > Previous_UpToPeriod AND SortOrder_IP <= UptoPeriod THEN T1.Scenario ELSE NULL End
							ELSE CASE WHEN SortOrder = 3 
										THEN CASE WHEN SortOrder_IP > Previous_UpToPeriod AND SortOrder_IP <= UptoPeriod THEN T1.Scenario ELSE NULL End
								END
						END
			  END  Scenario
			 ,CASE WHEN SortOrder = 1
					THEN CASE WHEN SortOrder_IP <= UptoPeriod THEN T1.AsAtPeriod ELSE NULL End
					ELSE CASE WHEN SortOrder = 2 
							THEN CASE WHEN SortOrder_IP > Previous_UpToPeriod AND SortOrder_IP <= UptoPeriod THEN T1.AsAtPeriod ELSE NULL End
							ELSE CASE WHEN SortOrder = 3 
										THEN CASE WHEN SortOrder_IP > Previous_UpToPeriod AND SortOrder_IP <= UptoPeriod THEN T1.AsAtPeriod ELSE NULL End
								END
						END
			END	 SM_AsAtPeriod
		INTO #RunConfigEP
		FROM #DataOrderEP T1
		CROSS APPLY
			(	
			SELECT AccountingPeriodName, AccountingYearName FROM DIM.AccountingPeriod WHERE AccountingMonth NOT IN (0,13)
			)A 			( SortOrder_IP, AccountingYearName)
		WHERE A.AccountingYearName IN ( T1.[Reporting Year], (T1.[Reporting Year] - 1))
  
  

  
	--- Get only the months till which user selected the inception periods in the UI
		DROP TABLE IF EXISTS #RunConfigReArrangedEP
		SELECT Pk_RequestId
				, [Reporting Year]
				, [Reporting Period] 
				, [OB Reporting Period]
				, [Adjustments] 
				, T1.RI_Flag
				, SortOrder
				, CASE Scenario 
						WHEN 'Actual' THEN 'A' 
						WHEN 'Forecast' THEN 'F'
						WHEN 'Budget' THEN 'B'
				  END Scenario
				, SM_AsAtPeriod 
				,MIN(MOI ) MIN_IP
				,MAX(MOI ) MAX_IP
				,CASE WHEN T2.MAX_SORT IS NOT NULL THEN Scenario END MAX_SCENARIO
		INTO #RunConfigReArrangedEP
		FROM #RunConfigEP T1
		LEFT JOIN ( SELECT RI_Flag,MAX(SortOrder) MAX_SORT
					FROM #RunConfigEP
					WHERE Scenario IN ('Forecast', 'Budget' )
					GROUP BY RI_Flag
					) T2 ON T1.SortOrder = T2.MAX_SORT AND T1.RI_Flag = T2.RI_Flag
		WHERE MOI IS NOT NULL
		GROUP BY Pk_RequestId
				, [Reporting Year]
				, [Reporting Period] 
				, [OB Reporting Period]
				, [Adjustments] 
				, T1.RI_Flag
				, SortOrder
				, CASE Scenario 
						WHEN 'Actual' THEN 'A' 
						WHEN 'Forecast' THEN 'F'
						WHEN 'Budget' THEN 'B'
				  END
				, SM_AsAtPeriod 
				,CASE WHEN T2.MAX_SORT IS NOT NULL THEN Scenario END


----Prepare the premiums first so that in the next step correct conditions as per config can be applied.
	DROP TABLE IF EXISTS #PreparePremium
	SELECT A.AccountingPeriod, A.Trifocus, A.[RI Prog], A.[RI Flag], A.YOA, A.YOI, A.MOI ,A.CCYSettlement, A.Scenario, A.[VALUE]
	INTO #PreparePremium
	FROM
	(
	--GET GROSS DATA
   	SELECT AccountingPeriod,Trifocus, YOA, YOI, CCYSettlement	, Scenario	, ISNULL([RI Flag], CASE WHEN [RI Prog] = 'GROSS' THEN 'I' ELSE 'O' END) [RI Flag], [RI Prog], MOI, [VALUE]
	FROM IFRS17DataMart.fct.Aggr_PremiumLTD 	
	WHERE 1 = 1
	AND Account IN ('P-GP-P','P-BP-B')
	AND [RI Flag] = @RIFlag

	UNION ALL
	---GET RI  8022 ENTITY DATA
   	 SELECT AccountingPeriod,Trifocus, YOA, YOI, CCYSettlement	, Scenario	, ISNULL([RI Flag], CASE WHEN [RI Prog] = 'GROSS' THEN 'I' ELSE 'O' END) [RI Flag], [RI Prog], MOI,  [VALUE]
	FROM IFRS17DataMart.fct.Aggr_PremiumLTD 	
	WHERE 1 = 1
	AND Account IN ('P-RP-P-FAC','P-RP-P-TTY')
	AND Entity = '8022'
	AND [RI Flag] = @RIFlag

	UNION ALL
	---GET RI NON  8022 ENTITY DATA
   	 SELECT AccountingPeriod,Trifocus, YOA, YOI, CCYSettlement	, CASE WHEN Account = 'RP-T-PR' THEN 'A' ELSE Scenario END Scenario	, ISNULL([RI Flag], CASE WHEN [RI Prog] = 'GROSS' THEN 'I' ELSE 'O' END) [RI Flag], [RI Prog], MOI, 
	 SUM( CASE WHEN Account IN ('P-RP-P-FAC','P-RP-P-TTY') 
			   THEN CASE WHEN  YOA > (CONVERT(INT, LEFT(AccountingPeriod, 4)) - 3) 		THEN [Value] 		ELSE 0			END
			   ELSE CASE WHEN  YOA <= (CONVERT(INT, LEFT(AccountingPeriod, 4)) - 3)		THEN [Value] 		ELSE 0			END
			END) AS [VALUE]
	FROM IFRS17DataMart.fct.Aggr_PremiumLTD 	
	WHERE 1 = 1
	AND Account IN ('P-RP-P-FAC','P-RP-P-TTY','RP-T-PR')
	AND [RI Flag] = @RIFlag
	AND Entity <> '8022'
	GROUP BY AccountingPeriod, Trifocus, YOA, YOI, CCYSettlement ,CASE WHEN Account = 'RP-T-PR' THEN 'A' ELSE Scenario END,	ISNULL([RI Flag], CASE WHEN [RI Prog] = 'GROSS' THEN 'I' ELSE 'O' END), [RI Prog], MOI	
	)A


------GET THE PREMIUM AMOUNT FOR ALL SCENARIOS AS PER THE CONFIG
    DROP TABLE IF EXISTS #Premium
	SELECT	 T1.Trifocus ,T1.YOA 	,T1.YOI	,DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)) AS QOI_END_DATE	,T1.CCYSettlement 	,T1.Scenario ,T1.[RI Prog],T1.[RI Flag] 
			,SUM(
				CASE WHEN T1.Scenario = 'A' 
					  THEN CASE WHEN T1.MOI <= T2.[Reporting Period]   --31-03-23 COMMENTED THIS CHANGE TO REMOVE DUPLICATES
								THEN T1.Value
								ELSE 0
							END
					  ELSE CASE WHEN T1.Scenario = 'F' 
								THEN CASE WHEN T1.MOI >= T2.MIN_IP AND T1.MOI <= T2.MAX_IP
										  THEN T1.[Value]
										  ELSE 0
									 END
								ELSE CASE WHEN T1.MOI >= T2.MIN_IP AND T1.MOI <= T2.MAX_IP
										  THEN T1.[Value]
										  ELSE 0
									 END
								END
				 END )[VALUE]
    INTO #Premium
	FROM #PreparePremium T1
	INNER JOIN #RunConfigReArrangedEP T2 ON T1.AccountingPeriod  = T2.SM_AsAtPeriod
										 AND T1.Scenario = T2.Scenario 
										 AND T1.[RI Flag] = T2.RI_Flag
										 AND T1.MOI <= T2.[Reporting Period]
	WHERE 1 = 1
	GROUP BY T1.Trifocus ,T1.YOA ,T1.YOI,DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(T1.MOI AS varchar), '01')))+1 ,0)) ,T1.CCYSettlement ,T1.Scenario ,T1.[RI Prog] ,T1.[RI Flag] 



--------GET Earning Pattren AND PREMIUM FROM YOI - YOA AND AGGR_PREMIUM TABLE
	    DROP TABLE IF EXISTS #EP_PremiumYOA
		SELECT
			   Pk_RequestId  ,'E' AS Pat_Type  ,T1.[FK_Trifocus]  ,Programme as [Programme]  ,T3.[RI Flag] AS [RI_Flag]  ,[FK_YOA]	  ,[FK_InceptionYear] AS YOI  ,T1.[CCYSettlement]  ,[Earn_qtr]  ,T1.Scenario
			  ,[Earn_qtr] AS Qtr	  ,T1.[Pattern] AS [Perc]  ,ISNULL(T3.[VALUE],0) AS [VALUE]
		INTO #EP_PremiumYOA
		FROM 
		(	
			SELECT Pk_RequestId, [FK_Trifocus]  ,Programme,FK_YOA,  [FK_InceptionYear]  ,[CCYSettlement]  ,[Earn_qtr],Scenario,RI_Flag,Pattern
			FROM
			(	--Below section is to get all patterns for scenario actual
				SELECT Pk_RequestId, [FK_Trifocus]  ,Programme,FK_YOA,  [FK_InceptionYear]  ,[CCYSettlement]  ,[Earn_qtr],Scenario, CASE WHEN T2.Programme =  'GROSS' THEN 'I' 	  ELSE 'O'	 END RI_Flag,Pattern
				FROM #RunConfigReArrangedEP  T1
				INNER JOIN IFRS17DataMart.[fct].[FSC_Per_YOA] T2 ON T1.[SM_AsAtPeriod]	= T2.FK_AccountingPeriod
															AND T1.Scenario		= T2.FK_Scenario
															AND T1.RI_Flag = CASE WHEN T2.Programme IS NOT NULL
																					THEN CASE WHEN T2.Programme =  'GROSS' THEN 'I' 
																							  ELSE 'O'
																						 END
																			 END
															AND T2.FK_InceptionYear <= CAST(LEFT(T1.MAX_IP,4) AS INT)
				WHERE T1.Scenario	= 'A'

				UNION ALL
				--Below section is to get all patterns except scenario actual
				SELECT Pk_RequestId, [FK_Trifocus]  ,Programme,FK_YOA,  [FK_InceptionYear]  ,[CCYSettlement]  ,[Earn_qtr],Scenario, CASE WHEN T2.Programme =  'GROSS' THEN 'I' 	  ELSE 'O'	 END RI_Flag,Pattern
				FROM #RunConfigReArrangedEP  T1
				INNER JOIN IFRS17DataMart.[fct].[FSC_Per_YOA] T2 ON T1.[SM_AsAtPeriod]	= T2.FK_AccountingPeriod
															AND T1.Scenario		= T2.FK_Scenario
															AND T1.RI_Flag = CASE WHEN T2.Programme IS NOT NULL
																					THEN CASE WHEN T2.Programme =  'GROSS' THEN 'I' 
																							  ELSE 'O'
																						 END
																			 END
															
				WHERE T1.Scenario	<> 'A'
				AND T2.FK_InceptionYear IN (CAST(LEFT(T1.MAX_IP,4) AS INT))
			)A
		) T1
		LEFT JOIN  (
					SELECT Trifocus, YOA, Scenario, YOI  ,CCYSettlement,[RI Prog],[RI Flag] , SUM(VALUE) AS [Value]
				    FROM #Premium 
					GROUP BY Trifocus, YOA, Scenario, YOI , CCYSettlement ,[RI Prog] ,[RI Flag] 
					)		T3 ON  T1.Scenario = T3.Scenario
						    AND T1.FK_Trifocus = T3.Trifocus
							AND T1.FK_YOA = T3.YOA 
							AND T1.FK_InceptionYear = T3.YOI
							AND T1.CCYSettlement = T3.CCYSettlement
							AND T1.Programme = T3.[RI Prog]
							AND T1.RI_Flag = T3.[RI Flag]



---------GET EP AND PREMIUM FROM YOI - QOI AND AGGR_PREMIUM TABLE
		DROP TABLE IF EXISTS #EP_PremiumQOI
		SELECT
			   T1.Pk_RequestId   ,'E' AS Pat_Type  ,[FK_Trifocus]  ,Programme as [Programme]  ,T3.[RI Flag] AS [RI_Flag]  ,QOI  ,[FK_InceptionYear] AS YOI  ,[CCYSett]	  ,T1.Scenario
			  ,[Earn_qtr] AS Qtr	  ,[Pattern] AS [Perc]	  ,ISNULL(T3.[VALUE],0) AS [VALUE]
		INTO #EP_PremiumQOI
				FROM 
		(	
			SELECT Pk_RequestId, [FK_Trifocus]  ,Programme,QOI,  [FK_InceptionYear]  ,CCYSett  ,[Earn_qtr],Scenario,RI_Flag,Pattern
			FROM
			(	--Below section is to get patterns for scenario actual
				SELECT Pk_RequestId, [FK_Trifocus]  ,Programme,QOI,  [FK_InceptionYear]  ,CCYSett ,[Earn_qtr],Scenario, CASE WHEN T2.Programme =  'GROSS' THEN 'I' 	  ELSE 'O'	 END RI_Flag,Pattern
				FROM #RunConfigReArrangedEP  T1
				INNER JOIN IFRS17DataMart.[fct].[FSC_Per_QOI] T2 ON T1.[SM_AsAtPeriod]	= T2.FK_AccountingPeriod
															AND T1.Scenario		= T2.FK_Scenario
															AND T1.RI_Flag = CASE WHEN T2.Programme IS NOT NULL
																					THEN CASE WHEN T2.Programme =  'GROSS' THEN 'I' 
																							  ELSE 'O'
																						 END
																			 END
															AND T2.FK_InceptionYear <= CAST(LEFT(T1.MAX_IP,4) AS INT)
				WHERE T1.Scenario	= 'A'

				UNION ALL
				--Below section is to get all patterns except scenario actual
				SELECT Pk_RequestId, [FK_Trifocus]  ,Programme,QOI,  [FK_InceptionYear]  ,CCYSett  ,[Earn_qtr],Scenario, CASE WHEN T2.Programme =  'GROSS' THEN 'I' 	  ELSE 'O'	 END RI_Flag,Pattern
				FROM #RunConfigReArrangedEP  T1
				INNER JOIN IFRS17DataMart.[fct].[FSC_Per_QOI] T2 ON T1.[SM_AsAtPeriod]	= T2.FK_AccountingPeriod
															AND T1.Scenario		= T2.FK_Scenario
															AND T1.RI_Flag = CASE WHEN T2.Programme IS NOT NULL
																					THEN CASE WHEN T2.Programme =  'GROSS' THEN 'I' 
																							  ELSE 'O'
																						 END
																			 END
															
				WHERE T1.Scenario	<> 'A'
				AND T2.FK_InceptionYear IN (CAST(LEFT(T1.MAX_IP,4) AS INT))
			)A
		) T1
		LEFT JOIN  (
					SELECT Trifocus, QOI_END_DATE, Scenario, YOI , CCYSettlement,[RI Prog],[RI Flag] , SUM(VALUE) AS [Value]
				    FROM #Premium 
					GROUP BY Trifocus, QOI_END_DATE, Scenario, YOI , CCYSettlement ,[RI Prog],[RI Flag]
					)		T3 ON  T1.Scenario = T3.Scenario
						       AND T1.FK_Trifocus = T3.Trifocus
							   AND T1.QOI = T3.QOI_END_DATE 
							   AND T1.FK_InceptionYear = T3.YOI
							   AND T1.CCYSett = T3.CCYSettlement
							   AND T1.Programme = T3.[RI Prog]
							   AND T1.RI_Flag = T3.[RI Flag]	




--------GET ADJUSTMENT PREMIUM DATA 
		DROP TABLE IF EXISTS #AdjPremium
		SELECT T1.Pk_RequestId 	, T3.AdjustmentID	, T3.Entity	, T3.TriFocus, T3.CCY	 AS [CCYSettlement], T3.Source AS Scenario, T3.Account, T3.YOA, YEAR(T3.InceptionDate) AS YOI, T3.InceptionDate, T3.Programme AS Programme
			, CASE T3.[Gross/RI Flag]  WHEN  'G' THEN 'I' WHEN 'R' THEN 'O' ELSE NULL END AS [RI Flag]
			, DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CONCAT(CAST(YEAR(T3.InceptionDate) AS VARCHAR), RIGHT(('0'+ CAST(MONTH(T3.InceptionDate) AS VARCHAR)),2)), '01')))+1 ,0)) QOI_End_Date
			, T3.[Value]
		INTO #AdjPremium
		FROM (SELECT DISTINCT Pk_RequestId,RI_Flag,Adjustments,[Reporting Period] FROM #RunConfigReArrangedEP) T1
		INNER JOIN [IFRS17DataMart].dim.AssumptionDatasets T2 ON T1.Adjustments = T2.AssumptionDatasetName
		LEFT JOIN [IFRS17DataMart].fct.AssumptionData T3 ON T2.Pk_AssumptionDatasetNameId = T3.Pk_AssumptionDatasetNameId 
		LEFT JOIN IFRS17DATAMART.[Dim].[AccountCodeMapping] T4 ON T3.Account = T4.[AccountCode] 
		WHERE 1 = 1
		AND T4.ISACTIVE = 1 
		AND T4.[TYPE] = 'Premium'
		AND T4.AccountCode IN ('P-GP-P','P-BP-B','P-RP-P-FAC','P-RP-P-TTY')
		AND T3.[SOURCE] = 'A'
		AND T1.RI_Flag = CASE  T3.[Gross/RI Flag] WHEN 'G' THEN 'I' WHEN 'R' THEN 'O' ELSE NULL END
		AND T3.InceptionDate <=  CONVERT(DATE,CONCAT(T1.[Reporting Period], '01'))


---------/* Adjustments */
---------GET Earning Premium from FSC_Per_YOA_adj AND PREMIUM FROM ADJ_PREMIUM TABLE
		DROP TABLE IF EXISTS #Adj_EP_PremiumYOA		
		SELECT T1.[RunID]  ,T1.[AdjustmentID]  ,T1.[Earn_qtr]  ,'E' AS Pat_Type, T1.Programme AS [Programme],T2.[RI Flag]   ,T1.[FK_Trifocus]  ,T1.[FK_Scenario]  
				,T1.[FK_InceptionYear] AS YOI   ,T1.[FK_YOA]  ,T1.[CCYSettlement]  	,T1.[Earn_qtr] AS Qtr	,SUM(T1.[Pattern]) AS Adj_EP   ,SUM(T2.[Value]) Adj_Prem	  
		INTO #Adj_EP_PremiumYOA
		FROM [IFRS17DataMart].[fct].[FSC_Per_YOA_adj] T1
		INNER JOIN #AdjPremium T2 ON  T1.RunID = T2.Pk_RequestId
								 AND T1.AdjustmentID = T2.AdjustmentID
								 AND T1.FK_Trifocus = T2.TriFocus 
								 AND T1.FK_Scenario = T2.Scenario 
								 AND T1.FK_YOA = T2.YOA 
								 AND T1.FK_InceptionYear = T2.YOI 
								 AND T1.CCYSettlement = T2.CCYSettlement
								 AND T1.Programme = T2.Programme
								 
		GROUP BY T1.[RunID]      ,T1.[AdjustmentID]      ,T1.[Earn_qtr],T1.Programme  ,T2.[RI Flag]      ,T1.[FK_Trifocus]      ,T1.[FK_Scenario]      ,T1.[FK_InceptionYear]   ,T1.[FK_YOA]     ,T1.[CCYSettlement]    


---------GET Earning Premium from FSC_Per_QOI_adj AND PREMIUM FROM ADJ_PREMIUM TABLE
		DROP TABLE IF EXISTS #Adj_EP_PremiumQOI
		SELECT T1.[RunID]  ,T1.[AdjustmentID]  ,T1.[Earn_qtr]  ,'E'  AS Pat_Type, T1.Programme AS [Programme],T2.[RI Flag] AS [RI_Flag]   ,T1.[FK_Trifocus]  ,T1.[FK_Scenario]  ,T1.[FK_InceptionYear] AS YOI ,T1.QOI  ,T1.[CCYSett]  
			  ,T1.[Earn_qtr] AS Qtr,	SUM(T1.[Pattern]) AS Adj_EP  	,SUM(T2.[Value]) Adj_Prem	  
		INTO #Adj_EP_PremiumQOI
		FROM [IFRS17DataMart].[fct].[FSC_Per_QOI_adj] T1
		INNER JOIN #AdjPremium T2 ON  T1.RunID = T2.Pk_RequestId
								 AND T1.AdjustmentID = T2.AdjustmentID
								 AND T1.FK_Trifocus = T2.TriFocus 
								 AND T1.FK_Scenario = T2.Scenario 
								 AND T1.QOI = T2.QOI_End_Date
								 AND T1.FK_InceptionYear = T2.YOI 
								 AND T1.CCYSett = T2.CCYSettlement
								 AND T1.Programme = T2.Programme
		GROUP BY T1.[RunID]      ,T1.[AdjustmentID]      ,T1.[Earn_qtr] ,T1.Programme ,T2.[RI Flag]   ,T1.[FK_Trifocus]      ,T1.[FK_Scenario]      ,T1.[FK_InceptionYear]      ,T1.QOI      ,T1.[CCYSett]   



--------CALCULATE WEIGHTED EARNING PATTERN FOR YOI - YOA
	    BEGIN
			INSERT INTO IFRS17DataMart.IDS.EarningPatterns(RunID ,Pat_Type, [Tri Focus Code] , Programme , RI_Flag , YOA , YOI, QOI , CCY, Qtr, Perc)
			SELECT Pk_RequestId,Pat_Type, FK_Trifocus, Programme, CASE WHEN RI_Flag IS NULL THEN CASE WHEN Programme = 'GROSS' THEN 'I' ELSE 'O' END ELSE RI_Flag END AS RI_Flag , FK_YOA, YOI, NULL AS QOI, CCYSettlement, Qtr, SUM(EarningPattern)  AS Weighted_EP
			FROM 
				(
					SELECT Pk_RequestId, Pat_Type, FK_Trifocus, Programme, RI_Flag, FK_YOA, YOI, CCYSettlement, Qtr
						,CASE WHEN SUM(Prem) OVER(PARTITION BY Pk_RequestId, Pat_Type, FK_Trifocus, Programme, RI_Flag, FK_YOA, YOI, CCYSettlement, Qtr)  <> 0
								THEN
									CONVERT(DECIMAL(38,10),
											(
												SUM(EPtimesPrem) OVER(PARTITION BY Pk_RequestId, Pat_Type, [SOURCE], FK_Trifocus, Programme, RI_Flag, FK_YOA, YOI, CCYSettlement, Qtr)
												/	
												SUM(Prem) OVER(PARTITION BY Pk_RequestId, Pat_Type, FK_Trifocus, Programme, RI_Flag, FK_YOA, YOI, CCYSettlement, Qtr) 
											)
										) 
								ELSE 0
							END AS EarningPattern
					FROM
					(
						SELECT Pk_RequestId,	Pat_Type,	Scenario AS [Source],	FK_Trifocus, Programme, RI_Flag, FK_YOA, YOI, CCYSettlement, Qtr, Perc AS EP, [VALUE]  AS Prem , (Perc * [VALUE]) AS EPtimesPrem FROM #EP_PremiumYOA 
						UNION ALL
						SELECT RunID	   ,	Pat_Type,	AdjustmentID		,	FK_Trifocus, Programme, [RI Flag], FK_YOA, YOI, CCYSettlement, Qtr, Adj_EP	, Adj_Prem		  , (Adj_EP *  Adj_Prem)			FROM #Adj_EP_PremiumYOA 
					)A
				)B

			GROUP BY Pk_RequestId, Pat_Type, FK_Trifocus, Programme, RI_Flag, FK_YOA, YOI, CCYSettlement, Qtr

		END


		-------CALCULATE WEIGHTED EARNING PATTERN FOR YOI - QOI
		BEGIN
		INSERT INTO IFRS17DataMart.IDS.EarningPatterns(RunID ,Pat_Type, [Tri Focus Code] , Programme , RI_Flag , YOA , YOI, QOI , CCY, Qtr, Perc)
		SELECT Pk_RequestId, Pat_Type	, FK_Trifocus	, Programme	, CASE WHEN RI_Flag IS NULL THEN CASE WHEN Programme = 'GROSS' THEN 'I' ELSE 'O' END ELSE RI_Flag END AS RI_Flag , NULL AS YOA	, YOI	,  QOI	, CCYSett	, Qtr, SUM(EarningPattern)  AS Weighted_EP
		FROM 
			(	
				SELECT Pk_RequestId, Pat_Type, FK_Trifocus, Programme, RI_Flag, YOI, QOI, CCYSett, Qtr
						,CASE WHEN SUM(Prem) OVER(PARTITION BY Pk_RequestId, Pat_Type, FK_Trifocus, Programme, RI_Flag, QOI, YOI, CCYSett, Qtr)  <> 0
							  THEN
									CONVERT(DECIMAL(38,10),
											(
												SUM(EPtimesPrem) OVER(PARTITION BY Pk_RequestId, Pat_Type, [SOURCE], FK_Trifocus, Programme, RI_Flag, QOI, YOI, CCYSett, Qtr)
												/	
												SUM(Prem) OVER(PARTITION BY Pk_RequestId, Pat_Type, FK_Trifocus, Programme, RI_Flag, QOI, YOI, CCYSett, Qtr) 
											)
										) 
							  ELSE 0
						 END AS EarningPattern
				FROM
				(
					SELECT Pk_RequestId,	Pat_Type,	Scenario AS [Source],	FK_Trifocus, Programme, RI_Flag, QOI, YOI, CCYSett, Qtr, Perc AS EP, [VALUE]  AS Prem , (Perc * [VALUE]) AS EPtimesPrem FROM #EP_PremiumQOI
					UNION ALL
					SELECT RunID	   ,	Pat_Type,	AdjustmentID		,	FK_Trifocus, Programme, RI_Flag, QOI, YOI, CCYSett, Qtr, Adj_EP	, Adj_Prem		  , (Adj_EP *  Adj_Prem)			FROM #Adj_EP_PremiumQOI 
				)A
			)B
		
		GROUP BY Pk_RequestId, Pat_Type, FK_Trifocus, Programme, RI_Flag, QOI, YOI, CCYSett, Qtr
		END
  END

  DROP TABLE IF EXISTS #DataOrderEP;
  DROP TABLE IF EXISTS #RunConfigEP
  DROP TABLE IF EXISTS #RunConfigReArrangedEP
  DROP TABLE IF EXISTS #PreparePremium
  DROP TABLE IF EXISTS #Premium
  DROP TABLE IF EXISTS #EP_PremiumQOI
  DROP TABLE IF EXISTS #EP_PremiumYOA
  DROP TABLE IF EXISTS #AdjPremium
  DROP TABLE IF EXISTS #Adj_EP_PremiumQOI
  DROP TABLE IF EXISTS #Adj_EP_PremiumYOA
END