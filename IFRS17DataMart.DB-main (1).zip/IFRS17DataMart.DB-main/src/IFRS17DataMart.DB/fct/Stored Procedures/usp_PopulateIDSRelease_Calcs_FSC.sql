﻿CREATE  Procedure  [fct].[usp_PopulateIDSRelease_Calcs_FSC] (@RunId Int)
AS
BEGIN
IF NOT EXISTS(SELECT 1 FROM IFRS17DataMart.IDS.[Release_Calcs_FSC] WHERE RunID = @RunId)
	BEGIN
	INSERT INTO IFRS17DataMart.IDS.[Release_Calcs_FSC](
			  [RunID]
			 ,[Entity]
			 ,[Tri focus code]
			 ,[IFRS17 TrifocusCode]
			 ,[Account]
			 ,[Programme]
			 ,[RI_Flag]
			 ,[YOA]
			 ,[YOI]
			 ,[QOI_End_Date]
			 ,[RecognitionType]
			 ,[CCY]
			 ,[Incepted Status]
			 ,[Open / Closed]
			 ,[Closing balances of release remaining Att]
			 ,[Closing balances of release remaining Cat]

			)
	SELECT 					
			    T2.Pk_RequestId			
				,T1.[Entity]
				,T1.[Tri focus code]
				,T1.[IFRS17 TrifocusCode]
				,T1.[Account]
				,T1.[Programme]
				,T1.[RI_Flag]
				,T1.[YOA]
				,T1.[YOI]
				,T1.[QOI_End_Date]
				,T1.[RecognitionType]
				,T1.[CCY]
				,T1.[Incepted Status]
				,T1.[Open / Closed]
				,T1.[Closing balances of release remaining Att]
				,T1.[Closing balances of release remaining Cat]
				

		FROM [IFRS17PsicleData].[Results].[Release_Calcs_FSC] T1
	INNER JOIN IFRS17DataMart.PWAPS.IFRS17CalcUI_RunLog T2 ON T1.RunID = T2.[Opening Balances Id]
	WHERE T2.Pk_RequestId = @RunId
	END

END