﻿


CREATE PROCEDURE [fct].[usp_PopulateIntermediaryDiscountRt] @RequestId INT
AS

BEGIN

SET NOCOUNT ON;
		BEGIN

--DECLARE @RequestId INT = 4111
--,@ScheduleRunType Varchar(10) = 'NOW'

		DROP TABLE IF EXISTS #UNPIVOT_DATA
		SELECT [Pk_RequestId], [Reporting Year], [Reporting Period], DatasetName, ColumnName
		INTO #UNPIVOT_DATA
		FROM [PWAPS].[IFRS17CalcUI_RunLog]
		UNPIVOT (
			DatasetName FOR ColumnName IN (
			   [Discount Rate Q1]
			  ,[Discount Rate Q2]
			  ,[Discount Rate Q3]
			  ,[Discount Rate Q4]
			  ,[Discount Rate Q5]
			  ,[Discount Rate SM]
			)
		) unpvt
		WHERE 
		[Pk_RequestId] =@RequestId 


		--SELECT * FROM #UNPIVOT_DATA

		DROP TABLE IF EXISTS #TABLE_1
		SELECT T1.Pk_RequestId, T2.Pk_AssumptionDatasetNameId, T1.ColumnName,T2.AssumptionPercentageTypeId, T1.[Reporting Year], T1.[Reporting Period]
		INTO #TABLE_1
		FROM #UNPIVOT_DATA T1
		INNER JOIN [IFRS17DataMart].dim.AssumptionDatasets T2 ON T1.DatasetName = T2.AssumptionDatasetName
		LEFT JOIN IDS.DiscountRate T3 ON T1.Pk_RequestId = T3.Pk_RequestId
		WHERE T3.Pk_RequestId IS NULL
	
		--SELECT * FROM #TABLE_1

		----------INSERT DiscountRt DATA
		BEGIN
			BEGIN

				INSERT INTO [IDS].[DiscountRate]([Pk_RequestId], [DatasetNameId],[PercentageTypeId],[LossType],[Currency],[DevelopmentYear],[Quarters],[DiscountRt],[OBFlag ])
				SELECT  DISTINCT
						  T1.Pk_RequestId
						, T2.Pk_AssumptionDatasetNameId AS DatasetNameId
						, T3.Pk_AssumptionPercentageTypeId AS PercentageTypeId
						, NULL
						, T4.CCY AS Currency
						, T4.DR_DevelopmentYear DevelopmentYear
						, CONVERT(DATE,
									CASE WHEN CHARINDEX('Q', T1.ColumnName COLLATE  latin1_general_cs_as) = 0 
										THEN DATEADD(DD, -1,DATEADD(QQ,DATEDIFF(QQ,0,DATEFROMPARTS(([Reporting Year]),1,1)) ,0)) 
										ELSE DATEADD(DD, -1, DATEADD(QQ, CASE WHEN RIGHT(T1.ColumnName,1) = 'M' THEN 0 ELSE RIGHT(T1.ColumnName,1) END , DATEFROMPARTS([Reporting Year],1,1))) 
									END 
									)AS Quarters
						, CAST(T4.[Value] AS DECIMAL(19,10)) DiscountRt
						,1
				FROM #TABLE_1 T1
				INNER JOIN [IFRS17DataMart].dim.AssumptionDatasets T2 ON T1.Pk_AssumptionDatasetNameId  = T2.Pk_AssumptionDatasetNameId
				INNER JOIN [IFRS17DataMart].dim.AssumptionPercentageType T3 ON T1.AssumptionPercentageTypeId = T3.Pk_AssumptionPercentageTypeId
				INNER JOIN ( SELECT Pk_AssumptionDatasetNameId
									,Pk_AssumptionPercentageTypeId
									,PK_LossType
									,CCY
									,DR_DevelopmentYear
									,[Value]
							FROM [IFRS17DataMart].FCT.AssumptionData
							WHERE WB_TYPE = 'DR'
							UNION ALL
							(SELECT DS.Pk_AssumptionDatasetNameId,DS.AssumptionPercentageTypeId, 'DR' as PK_LossType,DR.SettlementCCY,DR.DevelopmentYear,DR.CumulativeDevelopmentPercentage from [IFRS17DataMart].fct.DiscountRate DR
							Inner Join [IFRS17DataMart].dim.AssumptionDatasets DS ON DR.AssumptionDatasetName =DS.AssumptionDatasetName)) 
							T4 ON T2.Pk_AssumptionDatasetNameId = T4.Pk_AssumptionDatasetNameId AND T2.AssumptionPercentageTypeId = T4.Pk_AssumptionPercentageTypeId
				WHERE 
				1 = 1

				END

			END

	END
DROP TABLE IF EXISTS #UNPIVOT_DATA
DROP TABLE IF EXISTS #TABLE_1	

END