﻿

CREATE PROCEDURE [fct].[usp_PopulateIntermediaryFXRate] @RequestId INT
AS
BEGIN

	SET NOCOUNT ON;
		BEGIN

	--declare @RequestId int = 106,
	--@ScheduleRunType varchar(10) = 'now'

		DROP TABLE IF EXISTS #UNPIVOT_DATA
		SELECT [Pk_RequestId],[Opening Balances Id], DatasetName, ColumnName
		INTO #UNPIVOT_DATA
		FROM [PWAPS].[IFRS17CalcUI_RunLog]
		UNPIVOT (
			DatasetName FOR ColumnName IN (
			   [FX Rate Name (Avg)]
			  ,[FX Rate Name (Spot)]
			)
		) unpvt
		WHERE 
		[Pk_RequestId]=@RequestId 


		DROP TABLE IF EXISTS #TABLE_1
		SELECT T1.Pk_RequestId, T1.[Opening Balances Id], T2.Pk_AssumptionDatasetNameId, T1.ColumnName,T2.AssumptionPercentageTypeId
		INTO #TABLE_1
		FROM #UNPIVOT_DATA T1
		INNER JOIN [IFRS17DataMart].dim.AssumptionDatasets T2 ON T1.DatasetName = T2.AssumptionDatasetName
		LEFT JOIN IDS.FXRate T3 ON T1.Pk_RequestId = T3.Pk_RequestId
		WHERE T3.Pk_RequestId IS NULL

		--SELECT * FROM #TABLE_1

		DROP TABLE IF EXISTS #CurrentQuarterFxRate
		SELECT T1.Pk_RequestId, T1.ColumnName, T1.Pk_AssumptionDatasetNameId, T1.AssumptionPercentageTypeId, T2.ReportingCurrencyCode, T2.CCY, T2.[Value] AS FxRate
		INTO #CurrentQuarterFxRate
		FROM #TABLE_1 T1
		INNER JOIN 
		(
		SELECT Pk_AssumptionDatasetNameId
			,Pk_AssumptionPercentageTypeId
			,FX_ReportingCurrencyCode_4  AS ReportingCurrencyCode
			,CCY
			,[Value]
		FROM [IFRS17DataMart].FCT.AssumptionData
		WHERE WB_TYPE = 'FX'
		UNION All
		SELECT fp.AssumptionDatasetNameId
				,fp.AssumptionPercentageTypeId
				,fp.ReportingCurrencyCode
				,fp.CCY
				,fp.FXRate
		FROM [IFRS17DataMart].[fct].[FxRate] fp
		) T2 ON T1.Pk_AssumptionDatasetNameId = T2.Pk_AssumptionDatasetNameId AND T1.AssumptionPercentageTypeId = T2.Pk_AssumptionPercentageTypeId

		----------INSERT FX DATA
		BEGIN
			INSERT INTO [IDS].[FXRate]([Pk_RequestId],[DatasetNameId],[PercentageTypeId],[LossType],[ReportingCurrency],[TransactionCurrency],[FXRate_0],[OBFlag ])
			SELECT A.Pk_RequestId, A.DatasetNameId, A.PercentageTypeId, A.LossType, A.ReportingCurrency, A.TransactionCurrency, A.FXRate, A.OBFlag
			FROM
			(
			SELECT 
					  T1.Pk_RequestId
					, T1.Pk_AssumptionDatasetNameId AS DatasetNameId
					, T1.AssumptionPercentageTypeId AS PercentageTypeId
					, CASE T1.ColumnName WHEN 'FX Rate Name (Spot)' THEN 'FXS'  WHEN 'FX Rate Name (Avg)' THEN 'FXA' ELSE null END AS [LossType]
					, T1.ReportingCurrencyCode AS ReportingCurrency
					, T1.CCY as TransactionCurrency
					, CAST(T1.FxRate AS DECIMAL(19,10)) FXRate
					, 1 AS OBFlag
			FROM #CurrentQuarterFxRate T1

			UNION ALL
			/*PRIOR QUARTER FX RATE*/
			SELECT 
				  T1.Pk_RequestId
				 ,NULL
				 ,NULL
				 ,T2.FXRatetype 
				 ,T2.RepCCY
				 ,T2.CCY
				 ,CAST(T2.FXRate AS DECIMAL(19,10)) FXRate
				 ,0 AS OBFlag
				FROM [IFRS17PsicleData].[Results].[FXOB]  T2 
				INNER JOIN  (SELECT DISTINCT Pk_RequestId, [Opening Balances Id] FROM #TABLE_1) T1 ON T2.RunID = T1.[Opening Balances Id]

			) A

		END

	END
DROP TABLE IF EXISTS #UNPIVOT_DATA
DROP TABLE IF EXISTS #TABLE_1	
DROP TABLE IF EXISTS #CurrentQuarterFxRate
END