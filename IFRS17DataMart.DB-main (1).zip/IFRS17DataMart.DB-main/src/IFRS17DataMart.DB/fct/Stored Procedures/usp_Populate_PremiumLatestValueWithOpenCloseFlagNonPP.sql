﻿CREATE PROCEDURE [fct].[usp_Populate_PremiumLatestValueWithOpenCloseFlagNonPP]
AS


;WITH
MaxClaimsBasisAndMOP AS
(
	SELECT BK_PolicyNumber,CASE MAX(CASE WHEN T1.Claim_Basis = 'Unknown'
							THEN '-1'
							ELSE Claim_Basis
					END) WHEN '-1'
			 THEN 'Unknown'
			 ELSE MAX(CASE WHEN T1.Claim_Basis = 'Unknown'
							THEN '-1'
							ELSE Claim_Basis
					END)
		END Claim_Basis 
		,CASE MAX(CASE  WHEN T1.MOPCode IN  ('Unknown','NULL','NOMOP')  THEN '-1'
						ELSE MOPCode
					END) 
				WHEN '-1' THEN 'Unknown'
			    ELSE MAX(CASE  WHEN T1.MOPCode IN  ('Unknown','NULL','NOMOP')  THEN '-1'
						ELSE MOPCode
					END)
		END MOPCode 
		FROM FCT.PreProcessPremiumLTD T1 
		GROUP BY BK_PolicyNumber
),
AllData AS
(	
SELECT T1.FK_Account, T1.FK_Basis, T1.FK_Entity, T1.BK_PolicyNumber, T1.InceptionDate, T1.ExpiryDate, T1.FK_Process, T1.FK_Trifocus, T1.FK_YOA
      , T1.CCYOriginal, T1.CCYSettlement, T1.Fk_dataset, T1.FK_scenario, T1.FK_inceptionyear,T1.InceptionPeriod, T1.PolicyType, T1.[TypeOfBusiness],T1.Claim_Basis,T1.RI_Policy_Type,T1.[RI Flag]
      ,CASE WHEN T1.[RI Flag] ='I' Then 'GROSS' Else T1.Programme end Programme,T1.FK_AccountingPeriod, MOPCode, ISNULL(Open_Cls_Flag, 'Open') as Open_Cls_Flag
	  , SUM(T1.[Value]) [Value]
FROM FCT.PreProcessPremiumLTD T1
INNER JOIN Outbound.AccPer_AsAt_Control  T3 ON T1.FK_AccountingPeriod <= T3.AccountingPeriod
INNER JOIN DIM.AccountCodeMapping T4 ON T1.FK_Account = T4.AccountCode AND T4.ProcessFlow <> 'PP' AND IsActive = 1
LEFT JOIN (SELECT A.FK_YOA, A.FK_Trifocus, A.Programme, Open_Cls_Flag
			FROM DIM.OpenCloseYOA A
			INNER JOIN (SELECT FK_Trifocus, FK_YOA,Programme , MAX(FK_AccountingPeriod) MAX_AC
						FROM DIM.OpenCloseYOA A
						INNER JOIN Outbound.AccPer_AsAt_Control  B ON A.FK_AccountingPeriod < B.AccountingPeriod
						WHERE 
						1 = 1
						GROUP BY FK_Trifocus, FK_YOA, Programme
						) B ON A.FK_Trifocus = B.FK_Trifocus 
							AND A.FK_YOA = B.FK_YOA 
							AND A.Programme = B.Programme
							AND A.FK_AccountingPeriod = B.MAX_AC) T5 ON T1.FK_Trifocus = T5.FK_Trifocus
																	AND T1.FK_YOA = T5.FK_YOA
																	AND T1.Programme = T5.Programme
WHERE 1 = 1
--AND T1.FK_Account IN ('P-GP-P', 'P-GP-B', 'P-AC-P', 'P-AC-B', 'GPE-RP-P', 'P-RP-P-FAC', 'P-RP-P-TTY')
AND T1.FK_scenario IN ('A','F','B')
GROUP BY T1.FK_Account, T1.FK_Basis, T1.FK_Entity, T1.BK_PolicyNumber, T1.InceptionDate, T1.ExpiryDate, T1.FK_Process, T1.FK_Trifocus, T1.FK_YOA
      , T1.CCYOriginal, T1.CCYSettlement, T1.Fk_dataset, T1.FK_scenario, T1.FK_inceptionyear,T1.InceptionPeriod, T1.PolicyType, T1.[TypeOfBusiness],T1.Claim_Basis,T1.RI_Policy_Type,T1.[RI Flag]
      ,CASE WHEN T1.[RI Flag] ='I' Then 'GROSS' Else T1.Programme end ,T1.FK_AccountingPeriod,MOPCode,ISNULL(Open_Cls_Flag, 'Open')
)

, RowNumberedData AS
(
    SELECT T1.FK_Account 
     , T1.FK_Basis
     , T1.FK_Entity
     , T1.BK_PolicyNumber
     , T1.InceptionDate
     , T1.ExpiryDate
     , T1.FK_Process
     , T1.FK_Trifocus
     , T1.FK_YOA
     , T1.CCYOriginal
     , T1.CCYSettlement 
     , T1.Fk_dataset
     , T1.FK_scenario
     , T1.FK_inceptionyear
     , T1.InceptionPeriod
     , T1.PolicyType
     , T1.TypeOfBusiness
     , T1.Claim_Basis as [Claims Basis]
	 , T1.MOPCode
     , T1.RI_Policy_Type as [RI Type]
     , T1.Programme
     , T1.[RI Flag]
	 , Open_Cls_Flag
     , T1.FK_AccountingPeriod
     , T1.[Value]
     ,ROW_NUMBER() 
      OVER (PARTITION BY 
       T1.FK_Account, T1.FK_Basis, T1.FK_Entity, T1.BK_PolicyNumber, T1.InceptionDate, T1.ExpiryDate, T1.FK_Process, T1.FK_Trifocus, T1.FK_YOA  , T1.CCYOriginal, T1.CCYSettlement, 
	   T1.Fk_dataset, T1.FK_scenario, T1.FK_inceptionyear,T1.InceptionPeriod, T1.PolicyType, T1.[TypeOfBusiness],T1.Claim_Basis,T1.MOPCode	   ,T1.RI_Policy_Type , T1.Programme ,T1.[RI Flag], Open_Cls_Flag
      ORDER BY T1.FK_AccountingPeriod DESC
         ) RowOrder
FROM  AllData T1   
WHERE 1 = 1
)
,RowOne AS
(
			SELECT     [FK_Account] ,[FK_Basis],[FK_Entity] ,T1.[BK_PolicyNumber],[InceptionDate],[ExpiryDate],[FK_Process],[FK_Trifocus],[FK_YOA], [CCYOriginal],[CCYSettlement],
			[Fk_dataset],[FK_scenario],[FK_inceptionyear],InceptionPeriod ,	[PolicyType] ,T5.[Claim_Basis] as [Claims Basis],T5.MOPCode ,[TypeOfBusiness],Open_Cls_Flag
			,[RI Type] ,Programme,[RI Flag],RowOrder,MAX([FK_AccountingPeriod]) FK_AccountingPeriod,SUM([Value]) AS [Value]
			FROM RowNumberedData T1
			LEFT JOIN MaxClaimsBasisAndMOP T5 ON T1.BK_PolicyNumber = T5.BK_PolicyNumber
			WHERE 
			1 = 1
			AND RowOrder =  1 
			AND [Fk_dataset] NOT IN ('BusinessPlan','BusinessPlanRI','ObligatedPremium_RISpend')
			GROUP BY [FK_Account] ,[FK_Basis],[FK_Entity] ,T1.[BK_PolicyNumber],[InceptionDate],[ExpiryDate],[FK_Process],[FK_Trifocus],[FK_YOA], [CCYOriginal],[CCYSettlement],
			[Fk_dataset],[FK_scenario],[FK_inceptionyear],InceptionPeriod ,	[PolicyType] ,T5.[Claim_Basis],T5.MOPCode ,[TypeOfBusiness],Open_Cls_Flag
			,[RI Type] ,Programme,[RI Flag],RowOrder

			UNION All

			SELECT      [FK_Account] ,[FK_Basis],[FK_Entity] ,[BK_PolicyNumber],MAX([InceptionDate]) AS [InceptionDate],MAX([ExpiryDate]) AS [ExpiryDate],[FK_Process],[FK_Trifocus],[FK_YOA], [CCYOriginal],[CCYSettlement],
				[Fk_dataset],[FK_scenario],[FK_inceptionyear],InceptionPeriod ,	[PolicyType] , [Claims Basis], MOPCode ,[TypeOfBusiness],Open_Cls_Flag
				,[RI Type] ,Programme,[RI Flag],1 AS RowOrder,MAX([FK_AccountingPeriod]) FK_AccountingPeriod,SUM([Value]) AS [Value]
			FROM
			(
				SELECT     [FK_Account] ,[FK_Basis],[FK_Entity] ,T1.[BK_PolicyNumber],[InceptionDate],[ExpiryDate],[FK_Process],[FK_Trifocus],[FK_YOA], [CCYOriginal],[CCYSettlement],
					[Fk_dataset],[FK_scenario],[FK_inceptionyear],InceptionPeriod ,	[PolicyType] ,T5.[Claim_Basis] as [Claims Basis],T5.MOPCode ,[TypeOfBusiness],Open_Cls_Flag
					,[RI Type] ,Programme,[RI Flag],RowOrder,MAX([FK_AccountingPeriod]) FK_AccountingPeriod,SUM([Value]) AS [Value]
				FROM RowNumberedData T1
				LEFT JOIN MaxClaimsBasisAndMOP T5 ON T1.BK_PolicyNumber = T5.BK_PolicyNumber
				WHERE 
				1 = 1
				AND RowOrder =  1 
				AND [Fk_dataset] IN ('BusinessPlan','BusinessPlanRI','ObligatedPremium_RISpend')
				GROUP BY [FK_Account] ,[FK_Basis],[FK_Entity] ,T1.[BK_PolicyNumber],[InceptionDate],[ExpiryDate],[FK_Process],[FK_Trifocus],[FK_YOA], [CCYOriginal],[CCYSettlement],
				[Fk_dataset],[FK_scenario],[FK_inceptionyear],InceptionPeriod ,	[PolicyType] ,T5.[Claim_Basis],T5.MOPCode ,[TypeOfBusiness],Open_Cls_Flag
				,[RI Type] ,Programme,[RI Flag],RowOrder
			)A
			GROUP BY       [FK_Account] ,[FK_Basis],[FK_Entity] ,[BK_PolicyNumber],[InceptionDate],[ExpiryDate],[FK_Process],[FK_Trifocus],[FK_YOA], [CCYOriginal],[CCYSettlement],
				[Fk_dataset],[FK_scenario],[FK_inceptionyear],InceptionPeriod ,	[PolicyType] , [Claims Basis], MOPCode ,[TypeOfBusiness],Open_Cls_Flag
				,[RI Type] ,Programme,[RI Flag]
)


INSERT INTO [fct].[PremiumLatestValueWithOpenCloseFlagNonPP]
           ([FK_Account]
           ,[FK_Process]
           ,[FK_Basis]
           ,[BK_PolicyNumber]
           ,[PolicyType]
           ,[TypeOfBusiness]
           ,[InceptionDate]
           ,[ExpiryDate]
           ,[FK_Entity]
           ,[FK_Trifocus]
           ,[FK_YOA]
           ,[CCYOriginal]
           ,[CCYSettlement]
           ,[Fk_dataset]
           ,[FK_scenario]
           ,[FK_inceptionyear]
           ,[InceptionPeriod]
           ,[Programme]
           ,[RI Flag]
           ,[Claim_Basis]
           ,[RI_Policy_Type]
           ,[MOPCode]
           ,[Open_Cls_Flag]
           ,[FK_AccountingPeriod]
           ,[Value]		
		   ,[AuditCreateDateTime]
           ,[AuditUserCreate]
		   )

SELECT 
     lc.[FK_Account] AS [FK_Account],
     lc.[FK_Process] AS [FK_Process],
     lc.[FK_Basis]    AS [FK_Basis],
     lc.[BK_PolicyNumber] AS [BK_PolicyNumber],
     lc.[PolicyType] AS [PolicyType],
	 lc.TypeOfBusiness,
     lc.[InceptionDate] AS [InceptionDate],
     lc.[ExpiryDate] AS [ExpiryDate],
     lc.[FK_Entity] AS [FK_Entity],
     lc.[FK_Trifocus] AS [FK_Trifocus],
     lc.[FK_YOA] AS [FK_YOA],
     lc.[CCYOriginal] AS [CCYOriginal],
     lc.[CCYSettlement] AS [CCYSettlement],
     lc.[Fk_dataset] AS [Fk_dataset],
     lc.[FK_scenario] AS [FK_scenario],
     lc.[FK_inceptionyear] AS [FK_inceptionyear],
     lc.InceptionPeriod AS InceptionPeriod,
     Lc.Programme AS Programme,
     lc.[RI Flag] AS [RI_FLAG],
     lc.[Claims Basis] AS [Claims Basis],
     lc.[RI Type] AS [RI Type],
	 lc.MOPCode,
	 lc.Open_Cls_Flag AS [Open_Cls_Flag],
	 AsAt.AccountingPeriod AS [FK_AccountingPeriod],
	 SUM(lc.[Value]) AS [Value] ,
	 getdate(),
	 SYSTEM_USER
FROM RowOne lc
CROSS APPLY (SELECT AccountingPeriod FROM Outbound.AccPer_AsAt_Control) AsAt
WHERE 
1 = 1
GROUP BY [FK_Account], [FK_Basis],[BK_PolicyNumber],[FK_Entity],[InceptionDate],[ExpiryDate],[FK_Process],[FK_Trifocus],[FK_YOA], [CCYOriginal],[CCYSettlement],
	[Fk_dataset],[FK_scenario],[FK_inceptionyear],lc.[PolicyType],TypeOfBusiness,AsAt.AccountingPeriod,InceptionPeriod, Programme,[RI Flag],[Claims Basis],[RI Type],MOPCode,Open_Cls_Flag