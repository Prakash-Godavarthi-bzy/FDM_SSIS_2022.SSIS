﻿--USE [IFRS17DataMart]
--GO
--/****** Object:  StoredProcedure [fct].[usp_PopulateIntermediaryPaymentPattern]    Script Date: 13/12/2021 22:03:33 ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
-- =============================================
-- Author:		Pooja Khandual
-- Create date: 21 Dec 2020
-- Description:	This stored proc is called to populate the Intermedialy table with the Run ID data from the table stg.MappingTotransformationLog
-- =============================================

--DELETE FROM fct.IntermediaryAssumptionPaymentPattern WHERE [Pk_RequestId] = 1241
-- TRUNCATE TABLE fct.IntermediaryPaymentPattern
--SELECT COUNT(*) FROM  fct.IntermediaryPaymentPattern
--DROP PROCEDURE fct.usp_PopulateIntermediaryPaymentPattern
-- EXECUTE [fct].[usp_PopulateIntermediaryPaymentPattern] 



CREATE PROCEDURE [fct].[usp_PopulateIntermediaryPaymentPattern] @RequestId INT
AS
BEGIN

	SET NOCOUNT ON;

BEGIN
--DECLARE @RequestId  Int = 3730
DECLARE @GrPremCopied CHAR(1)
DECLARE @GrClaimsCopied CHAR(1)


		DROP TABLE IF EXISTS #ColumnStructure
		SELECT T1.Pk_RequestId,t1.DatasetName ,T2.PK_AssumptionDatasetNameId, T1.ColumnName, T2.AssumptionPercentageTypeId, T3.AssumptionPercentageType, T1.ColumnType
		INTO #ColumnStructure
		FROM [IDS].[udf_GetGrossRIColumns] (@RequestId) T1
		INNER JOIN [IFRS17DataMart].dim.AssumptionDatasets T2 ON T1.DatasetName = T2.AssumptionDatasetName
		LEFT JOIN DIM.AssumptionPercentageType T3 ON T2.AssumptionPercentageTypeId = T3.Pk_AssumptionPercentageTypeId
		LEFT JOIN IDS.PaymentPattern T4 ON T1.Pk_RequestId = T4.Pk_RequestId
		WHERE 
		1 = 1
		AND T4.Pk_RequestId IS NULL
		AND T1.AssumptionType = 'PP'

		
		DROP TABLE IF EXISTS #SystemGeneratedData
		SELECT  Pk_RequestId
				,CS.ColumnName
				,CS.Pk_AssumptionDatasetNameId
				,CS.AssumptionPercentageTypeId
				,CASE LEFT(FK_PatternName, 1) WHEN 'C' THEN 'PPC' ELSE 'PPP' END AS PK_LossType
				,fp.FK_Trifocus
				,fp.DevelopmentQuarter
				,'G' As RIFlag
				,fp.DevelopmentPercentageCumulative 
		INTO #SystemGeneratedData
		FROM [IFRS17DataMart].fct.Pattern fp
		INNER JOIN #ColumnStructure CS ON CS.DatasetName = FP.TDH_DatasetName


		DROP TABLE IF EXISTS #UserGenerated
		SELECT  Pk_RequestId
				,CS.ColumnName
				,CS.Pk_AssumptionDatasetNameId
				,CS.AssumptionPercentageTypeId
				,Case CS.AssumptionPercentageType when 'Payment Pattern (Premiums)' Then 'PPP' When  'Payment Pattern (Claims)' Then 'PPC' end PK_LossType
				,TriFocus
				,PP_DevelopmentQuarter
				,[Gross/RI Flag]
				,[Value]
		INTO #UserGenerated
		FROM [IFRS17DataMart].FCT.AssumptionData AD
		INNER JOIN #ColumnStructure CS ON CS.Pk_AssumptionDatasetNameId = AD.Pk_AssumptionDatasetNameId 
									   AND AD.Pk_AssumptionPercentageTypeId = CS.AssumptionPercentageTypeId
		WHERE WB_TYPE = 'PP'


		DROP TABLE IF EXISTS #TotalData
		SELECT Pk_RequestId,ColumnName,Pk_AssumptionDatasetNameId	,AssumptionPercentageTypeId		,PK_LossType ,TriFocus, PP_DevelopmentQuarter	,[Gross/RI Flag]	,[Value]
		INTO #TotalData
		FROM
		(
			SELECT Pk_RequestId,ColumnName,Pk_AssumptionDatasetNameId	,AssumptionPercentageTypeId		,PK_LossType ,TriFocus, PP_DevelopmentQuarter	,[Gross/RI Flag]	,[Value]	FROM #UserGenerated 
			UNION ALL
			SELECT Pk_RequestId,ColumnName,Pk_AssumptionDatasetNameId  ,AssumptionPercentageTypeId,PK_LossType   ,FK_Trifocus   ,DevelopmentQuarter   ,RIFlag   ,DevelopmentPercentageCumulative FROM #SystemGeneratedData
		)A


	SELECT @GrPremCopied = CASE WHEN ([Pattern Scenario] = [Pattern Scenario(Re)]) THEN 'Y' ELSE 'N' END,	
		   @GrClaimsCopied = CASE WHEN ([Payment Pattern Claims] = [Payment Pattern Claims(Re)]) THEN 'Y' ELSE 'N' END	
	FROM PWAPS.IFRS17CalcUI_RunLog WHERE Pk_RequestId = @RequestId

	--SELECT* FROM #ColumnStructure
	--SELECT * FROM #UserGenerated
	--SELECT * FROM #SystemGeneratedData
	--SELECT @GrPremCopied,@GrClaimsCopied

	IF @GrPremCopied = 'Y'
			BEGIN
			
				IF EXISTS( SELECT  DISTINCT 1	FROM  #TotalData G	WHERE ColumnName = 'Pattern Scenario'	AND G.[Gross/RI Flag] = 'R')
					BEGIN
						INSERT INTO [IDS].[PaymentPattern]([Pk_RequestId],[DatasetNameId],[PercentageTypeId],[LossType],[Trifocus],[DevelopmentQuarter],[RIFlag],[PaymentPerc],[OBFlag ])
						SELECT    G.Pk_RequestId
								, G.Pk_AssumptionDatasetNameId AS DatasetNameId
								, G.AssumptionPercentageTypeId AS PercentageTypeId
								, G.PK_LossType AS LossType
								, G.TriFocus AS Trifocus
								, G.PP_DevelopmentQuarter DevelopmentQuarter
								, G.[Gross/RI Flag]
								, CAST(G.[Value] AS DECIMAL(38,10)) PaymentPerc
								,1 AS [OBFlag]
						FROM  #TotalData G
						WHERE ColumnName = 'Pattern Scenario'
					
					END
				ELSE
					BEGIN
						INSERT INTO [IDS].[PaymentPattern]([Pk_RequestId],[DatasetNameId],[PercentageTypeId],[LossType],[Trifocus],[DevelopmentQuarter],[RIFlag],[PaymentPerc],[OBFlag ])
						SELECT    A.Pk_RequestId
								, A.Pk_AssumptionDatasetNameId AS DatasetNameId
								, A.AssumptionPercentageTypeId AS PercentageTypeId
								, A.PK_LossType AS LossType
								, A.TriFocus AS Trifocus
								, A.PP_DevelopmentQuarter DevelopmentQuarter
								--, [Gross/RI Flag]
								,CASE WHEN [Gross/RI Flag]='G' THEN 'I' WHEN [Gross/RI Flag]='R' THEN 'O' ELSE [Gross/RI Flag] END AS [Gross/RI Flag]
								, CAST(A.[Value] AS DECIMAL(38,10)) PaymentPerc
								,1 AS [OBFlag]
						FROM ( ---GROSS
							   SELECT Pk_RequestId,ColumnName,Pk_AssumptionDatasetNameId	,AssumptionPercentageTypeId		,PK_LossType ,TriFocus, PP_DevelopmentQuarter	,[Gross/RI Flag]	,[Value]	FROM #TotalData
							   UNION ALL 
							   ---AS RI
							   SELECT Pk_RequestId,ColumnName,Pk_AssumptionDatasetNameId	,AssumptionPercentageTypeId		,PK_LossType ,TriFocus, PP_DevelopmentQuarter	,'R' AS [Gross/RI Flag]	,[Value]	FROM #TotalData 
							 )A
						WHERE ColumnName = 'Pattern Scenario'
					END
			END
	ELSE
		 BEGIN
					INSERT INTO [IDS].[PaymentPattern]([Pk_RequestId],[DatasetNameId],[PercentageTypeId],[LossType],[Trifocus],[DevelopmentQuarter],[RIFlag],[PaymentPerc],[OBFlag ])
					SELECT A.Pk_RequestId, A.DatasetNameId, A.PercentageTypeId, A.LossType, A.Trifocus, A.DevelopmentQuarter,CASE WHEN A.[Gross/RI Flag]='G' THEN 'I' WHEN A.[Gross/RI Flag]='R' THEN 'O' ELSE A.[Gross/RI Flag] END AS [Gross/RI Flag], A.PaymentPerc, 1 AS OBFlag
					FROM
					(
						-----GROSS DATA
						SELECT  
								  G.Pk_RequestId
								, ColumnName
								, G.Pk_AssumptionDatasetNameId AS DatasetNameId
								, G.AssumptionPercentageTypeId AS PercentageTypeId
								, G.PK_LossType AS LossType
								, G.TriFocus AS Trifocus
								, G.PP_DevelopmentQuarter DevelopmentQuarter
								, G.[Gross/RI Flag]
								, CAST(G.[Value] AS DECIMAL(38,10)) PaymentPerc
						FROM  #TotalData G
						WHERE G.ColumnName IN ('Pattern Scenario')
						AND [Gross/RI Flag] = 'G'

						UNION ALL
						-----RI DATA
						SELECT Pk_RequestId,ColumnName,Pk_AssumptionDatasetNameId	,AssumptionPercentageTypeId		,PK_LossType ,TriFocus, PP_DevelopmentQuarter	,[Gross/RI Flag]	,[Value]	FROM #UserGenerated WHERE [Gross/RI Flag] = 'R' AND ColumnName IN ('Pattern Scenario(Re)')
					)A
				

		 END


	----Populate Claims Payment pattern

	IF @GrClaimsCopied = 'Y'
			BEGIN
			
				IF EXISTS(SELECT  DISTINCT 1	FROM  #TotalData G	WHERE ColumnName =  'Payment Pattern Claims' AND G.[Gross/RI Flag] = 'R')
					BEGIN
						INSERT INTO [IDS].[PaymentPattern]([Pk_RequestId],[DatasetNameId],[PercentageTypeId],[LossType],[Trifocus],[DevelopmentQuarter],[RIFlag],[PaymentPerc],[OBFlag ])
						SELECT    G.Pk_RequestId
								, G.Pk_AssumptionDatasetNameId AS DatasetNameId
								, G.AssumptionPercentageTypeId AS PercentageTypeId
								, G.PK_LossType AS LossType
								, G.TriFocus AS Trifocus
								, G.PP_DevelopmentQuarter DevelopmentQuarter
								--, G.[Gross/RI Flag]
								,CASE WHEN G.[Gross/RI Flag]='G' THEN 'I' WHEN G.[Gross/RI Flag]='R' THEN 'O' ELSE G.[Gross/RI Flag] END AS [Gross/RI Flag]
								, CAST(G.[Value] AS DECIMAL(38,10)) PaymentPerc
								,1 AS [OBFlag]
						FROM  #TotalData G
						WHERE ColumnName = 'Payment Pattern Claims'
					
					END
				ELSE
					BEGIN
						INSERT INTO [IDS].[PaymentPattern]([Pk_RequestId],[DatasetNameId],[PercentageTypeId],[LossType],[Trifocus],[DevelopmentQuarter],[RIFlag],[PaymentPerc],[OBFlag ])
						SELECT    A.Pk_RequestId
								, A.Pk_AssumptionDatasetNameId AS DatasetNameId
								, A.AssumptionPercentageTypeId AS PercentageTypeId
								, A.PK_LossType AS LossType
								, A.TriFocus AS Trifocus
								, A.PP_DevelopmentQuarter DevelopmentQuarter
								--, [Gross/RI Flag]
								,CASE WHEN [Gross/RI Flag]='G' THEN 'I' WHEN [Gross/RI Flag]='R' THEN 'O' ELSE [Gross/RI Flag] END AS [Gross/RI Flag]
								, CAST(A.[Value] AS DECIMAL(38,10)) PaymentPerc
								,1 AS [OBFlag]
						FROM ( ---GROSS
							   SELECT Pk_RequestId,ColumnName,Pk_AssumptionDatasetNameId	,AssumptionPercentageTypeId		,PK_LossType ,TriFocus, PP_DevelopmentQuarter	,[Gross/RI Flag]	,[Value]	FROM #TotalData
						   
							   UNION ALL 
							   ---AS RI
							  SELECT Pk_RequestId,ColumnName,Pk_AssumptionDatasetNameId	,AssumptionPercentageTypeId		,PK_LossType ,TriFocus, PP_DevelopmentQuarter	,'R' AS [Gross/RI Flag]	,[Value]	FROM #TotalData 
							 )A
						WHERE ColumnName = 'Payment Pattern Claims'
					END
			END
	ELSE
		 BEGIN
					INSERT INTO [IDS].[PaymentPattern]([Pk_RequestId],[DatasetNameId],[PercentageTypeId],[LossType],[Trifocus],[DevelopmentQuarter],[RIFlag],[PaymentPerc],[OBFlag ])
					SELECT A.Pk_RequestId, A.DatasetNameId, A.PercentageTypeId, A.LossType, A.Trifocus, A.DevelopmentQuarter, CASE WHEN A.[Gross/RI Flag]='G' THEN 'I' WHEN A.[Gross/RI Flag]='R' THEN 'O' ELSE A.[Gross/RI Flag] END AS [Gross/RI Flag], A.PaymentPerc, 1 AS [OBFlag]
					FROM
					(
						-----GROSS DATA
						SELECT  DISTINCT
								  G.Pk_RequestId
								, ColumnName
								, G.Pk_AssumptionDatasetNameId AS DatasetNameId
								, G.AssumptionPercentageTypeId AS PercentageTypeId
								, G.PK_LossType AS LossType
								, G.TriFocus AS Trifocus
								, G.PP_DevelopmentQuarter DevelopmentQuarter
								, G.[Gross/RI Flag]
								, CAST(G.[Value] AS DECIMAL(38,10)) PaymentPerc

						FROM  #TotalData G
						WHERE G.ColumnName IN ('Payment Pattern Claims')
						AND [Gross/RI Flag] = 'G'
						UNION ALL
						-----RI DATA
						SELECT Pk_RequestId,ColumnName,Pk_AssumptionDatasetNameId	,AssumptionPercentageTypeId		,PK_LossType ,TriFocus, PP_DevelopmentQuarter	,[Gross/RI Flag]	,[Value]	FROM #UserGenerated WHERE [Gross/RI Flag] = 'R' AND ColumnName IN ('Payment Pattern Claims(Re)')
					)A
				

		 END

		

END

	DROP TABLE IF EXISTS #ColumnStructure
	DROP TABLE IF EXISTS #SystemGeneratedData
	DROP TABLE IF EXISTS #UserGenerated
	DROP TABLE IF EXISTS #TotalData

END