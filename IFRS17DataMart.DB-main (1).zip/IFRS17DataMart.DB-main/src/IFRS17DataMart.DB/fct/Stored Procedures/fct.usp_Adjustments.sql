﻿CREATE PROCEDURE fct.usp_Adjustments @RequestId int
As
BEGIN

IF NOT EXISTS(
select runid from
[IDS].[fct_Adjustment]
where runid=@RequestId
)

BEGIN

--Truncate  table [IFRS17DataMart].[IDS].[fct_Adjustment]
Insert into [IDS].[fct_Adjustment]( 
       [RunID]
      ,[Adjustment ID]
      ,DatasetNameId
      --,[AdjustmentName]
      ,[Account]
      ,[Gross_RI Flag]
      ,[Currency]
      ,[Entity]
      ,[Trifocus]
      ,[Programme]
      ,[YOA]
      ,[Source]
      ,[Amount]
      ,[Earned %]
      ,[Inception Date]
      ,[Narrative]
      ,[AuditCreateDateTime]
      ,[AuditUserCreate]
	)
SELECT S.[Pk_RequestId],
        A.AdjustmentID,
        D.Pk_AssumptionDatasetNameId,
        --S.[Adjustments],
        A.[Account],
        --A.[Gross/RI Flag],
		CASE WHEN A.[Gross/RI Flag]='G' THEN 'I' WHEN A.[Gross/RI Flag]='R' THEN 'O' ELSE A.[Gross/RI Flag] END AS [Gross/RI Flag],
        A.[CCY],
        A.[Entity],
        A.[Trifocus],
        A.[Programme],
        Convert(Int,A.[YOA]),
        A.[Source],
        A.[Value],
        A.[EarnedPercentage],
        A.[InceptionDate],
        A.[Narrative],
        GETDATE() AS AuditCreateDateTime,
        SUSER_SNAME() AS AuditUserCreate
FROM PWAPS.IFRS17CalcUI_RunLog S
INNER JOIN dim.AssumptionDatasets D ON S.Adjustments = D.AssumptionDatasetName
INNER JOIN [fct].[AssumptionData] A ON D.Pk_AssumptionDatasetNameId = A.Pk_AssumptionDatasetNameId
WHERE S.Pk_RequestId = @RequestId

END
END