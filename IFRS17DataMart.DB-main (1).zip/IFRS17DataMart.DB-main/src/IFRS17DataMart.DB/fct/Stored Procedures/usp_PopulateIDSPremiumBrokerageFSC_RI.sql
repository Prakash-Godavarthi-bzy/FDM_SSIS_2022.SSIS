﻿
-----YTD F - 3044
-----YTD A - 3050
-----QTD F - 3046
-----QTD A - 3049

--DECLARE @RequestId INT = 34
----DECLARE @UseCase CHAR(5)

CREATE PROCEDURE [fct].[usp_PopulateIDSPremiumBrokerageFSC_RI] @RequestId INT

AS

BEGIN
	DECLARE @UseCase CHAR(5)

	DROP TABLE IF EXISTS #DataOrder
	SELECT 
		T2.Pk_RequestId
	,	T2.[Reporting Year]
	,	T2.[Reporting Period]
	,	T2.[Opening Balances Id]
	,	T2.[OB Reporting Period]
	,	T5.IPSource [OB Last IP Source]
	,	T5.IPAsAtPeriod [OB Last IP AsAt]
	,	CASE WHEN T2.[Reporting Period] > T2.[OB Reporting Period] 
				THEN CASE WHEN RIGHT(T2.[OB Reporting Period],2) ='12' 
							THEN CASE WHEN T5.IPSource = 'A' 
										THEN 'YTD-A'
										ELSE 'YTD-F'
								END
						WHEN RIGHT(T2.[OB Reporting Period],2) < '12' 
							THEN CASE WHEN T5.IPSource = 'A' 
									THEN 'QTD-A'
									ELSE 'QTD-F'
									END
					END
		END RunType
	,	CASE T2.Scenario 
			WHEN  'Actual' THEN 'A'
			WHEN  'Forecast' THEN 'F'
			WHEN  'Budget' THEN 'B'
			ELSE NULL			  
		END Scenario
	,	T2.UptoPeriod
	,	T2.AsAtPeriod
	,	T2.SortOrder
	,	LAG(T2.UptoPeriod,1) OVER(ORDER BY T2.SortOrder) Previous_UpToPeriod
	INTO #DataOrder
	FROM
		(
			SELECT Pk_RequestId,[Reporting Year],[Reporting Period],[Opening Balances Id],[OB Reporting Period], Scenario,	UptoPeriod,	AsAtPeriod, ROW_NUMBER() OVER(PARTITION BY Pk_RequestId ORDER BY UptoPeriod) SortOrder
			FROM
				(
				SELECT Pk_RequestId,[Reporting Year],[Reporting Period],[Opening Balances Id],[OB Reporting Period],[SM Scenario Actual] AS Scenario, [RI SM Up to inception period Actual] AS UptoPeriod, [RI SM Reporting Period Actual] AS AsAtPeriod FROM PWAPS.IFRS17CalcUI_RunLog
				UNION
				SELECT Pk_RequestId,[Reporting Year],[Reporting Period],[Opening Balances Id],[OB Reporting Period],[SM Scenario Forecast] AS Scenario, [RI SM Up to inception period Forecast] AS UptoPeriod, [RI SM Reporting Period Forecast] AS AsAtPeriod FROM PWAPS.IFRS17CalcUI_RunLog
				UNION
				SELECT Pk_RequestId,[Reporting Year],[Reporting Period],[Opening Balances Id],[OB Reporting Period],[SM Scenario Business Plan] AS Scenario, [RI SM Up to inception period Business Plan] AS UptoPeriod, [RI SM Reporting Period Business Plan] AS AsAtPeriod FROM PWAPS.IFRS17CalcUI_RunLog
				)T1
			WHERE UptoPeriod IS NOT NULL
		)T2
	LEFT JOIN 
		(
			SELECT	 DISTINCT
				T1.[Pk_RequestId]
				,T1.[Reporting Year]
				,T1.[Reporting Period] 
				,CAST(T1.[Reporting Year] + RIGHT(('00' + A.InceptionPeriod),2) AS INT) InceptionPeriod
				,A.InceptionQuarter
				,CASE A.IPSource 
						WHEN  'Actual' THEN 'A'
						WHEN  'Forecast' THEN 'F'
						WHEN  'Budget' THEN 'B'
						ELSE NULL			  
					END IPSource
				, A.IPAsAtPeriod
			FROM PWAPS.IFRS17CalcUI_RunLog T1
			CROSS APPLY
			(	
				VALUES	
				('1', '1', [RI Scenario 01], [RI Reporting Period 01]),
				('2', '1', [RI Scenario 02], [RI Reporting Period 02]),
				('3', '1', [RI Scenario 03], [RI Reporting Period 03]),
				('4', '2', [RI Scenario 04], [RI Reporting Period 04]),
				('5', '2', [RI Scenario 05], [RI Reporting Period 05]),
				('6', '2', [RI Scenario 06], [RI Reporting Period 06]),
				('7', '3', [RI Scenario 07], [RI Reporting Period 07]),
				('8', '3', [RI Scenario 08], [RI Reporting Period 08]),
				('9', '3', [RI Scenario 09], [RI Reporting Period 09]),
				('10','4', [RI Scenario 10], [RI Reporting Period 10]),
				('11','4', [RI Scenario 11], [RI Reporting Period 11]),
				('12','4', [RI Scenario 12], [RI Reporting Period 12])
			)A ( InceptionPeriod, InceptionQuarter,IPSource, IPAsAtPeriod)) T5 ON T2.[Opening Balances Id] = T5.[Pk_RequestId] AND T2.[OB Reporting Period] = T5.InceptionPeriod
	WHERE 1 = 1
	AND T2.Pk_RequestId = @RequestId

			--SELECT *	FROM #DataOrder T1


	----FIND THE USE CASE AND ASSIGN TO VARIABLE
	SELECT DISTINCT  @UseCase = RunType	FROM #DataOrder T1
		--SELECT @UseCase


	----IF ACTUALS ARE AVAAILBLE FOR ALL USE CASES THEN
	IF EXISTS (SELECT 1 FROM #DataOrder WHERE Scenario = 'A' )
		BEGIN
			---- GET DATA
			IF @UseCase IN ('QTD-A','QTD-F','YTD-A','YTD-F')
				BEGIN
					INSERT INTO [IDS].[Aggr_PremiumBrokerage]([RunID]      ,[Entity]      ,[Tri focus code]      ,[IFRS17 Trifocus]      ,[Account]      ,[Premtype]      ,[Programme]      ,[RI_Flag]      ,[YOA]      ,[YOI]     
					,[QOI_End_Date]      ,[RecognitionType]      ,[CCY]      ,[Amount], AuditUserCreate,	AuditCreateDateTime)
					SELECT A.RunID
						,A.Entity
						,A.[Tri Focus Code]
						,A.[IFRS17 Tri Focus Code]
						,A.[Account]
						,A.Prem_Type
						,A.[Programme]
						,CASE WHEN A.[RI_Flag]='G' THEN 'I' WHEN A.[RI_Flag]='R' THEN 'O' ELSE A.[RI_Flag] END AS RI_Flag
						,A.YoA
						,A.YoI
						,A.QOI_END_DATE
						,'SM' AS [RecognitionType]
						,A.CCY
						,CASE WHEN  @UseCase IN ('YTD-F','QTD-F')
								THEN (ISNULL(SUM(A.ActualVal),0) - ISNULL(SUM(A.FscVal),0)) 
								ELSE SUM(A.ActualVal)
							END AS AMOUNT
						, SYSTEM_USER
						, GETDATE()
					FROM
						(
						--GET ACTUALS VALUE
							(
							SELECT 
									T2.Pk_RequestId AS RunID
									,T1.[FK_Entity] AS Entity
									,T1.[FK_Trifocus] AS [Tri Focus Code]
									,T1.[IFRS17_Trifocus] AS [IFRS17 Tri Focus Code]
									,T1.[FK_Account]
									, T3.EnrichAccCode AS [Account]
									,'transactional' AS Prem_Type
									,T1.[Programme]
									--,'N' AS RI_Flag
									,[RI Flag] AS RI_Flag
									,T1.[FK_YOA] AS YoA
									,T1.[FK_InceptionYear] AS YoI
									,T1.[QOI] AS QOI_END_DATE
									,T1.[CCYSettlement]  AS CCY
									,CASE WHEN @UseCase IN ('QTD-A','QTD-F')     --CR I17-5389  PK(08-07-2023)
										THEN CASE WHEN @UseCase = 'QTD-A'
													THEN CASE WHEN T3.EnrichAccCode = 'FSC_ORC'
															  THEN CASE WHEN T1.FK_YOA <= (T2.[Reporting Year]-3)
																        THEN CASE WHEN FK_Account IN ('PC-LS-OR-TTY','PC-LS-OR-FAC')
																				  THEN T1.Pr_Qtr_End_Acct_Prd_FSC
																				  ELSE 0
																			 END
																		ELSE CASE WHEN FK_Account IN ('P-OR-P-FAC','P-OR-P-TTY')
																				  THEN T1.Pr_Qtr_End_Acct_Prd_FSC
																				  ELSE 0
																			 END
																		END
																ELSE	T1.Pr_Qtr_End_Acct_Prd_FSC
															END
													ELSE CASE WHEN T3.EnrichAccCode = 'FSC_ORC'
															  THEN CASE WHEN T1.FK_YOA <= (T2.[Reporting Year]-3)
																        THEN CASE WHEN FK_Account IN ('PC-LS-OR-TTY','PC-LS-OR-FAC')
																				  THEN T1.[Pr_Qtr_End-1_Acct_Prd_FSC]
																				  ELSE 0
																			 END
																		ELSE CASE WHEN FK_Account IN ('P-OR-P-FAC','P-OR-P-TTY')
																				  THEN T1.[Pr_Qtr_End-1_Acct_Prd_FSC]
																				  ELSE 0
																			 END
																		END
																ELSE	T1.[Pr_Qtr_End-1_Acct_Prd_FSC]
															END
												END
										ELSE CASE WHEN @UseCase = 'YTD-A'
													THEN CASE WHEN T3.EnrichAccCode = 'FSC_ORC'
															  THEN CASE WHEN T1.FK_YOA <= (T2.[Reporting Year]-3)
																        THEN CASE WHEN FK_Account IN ('PC-LS-OR-TTY','PC-LS-OR-FAC')
																				  THEN T1.[Pr_Ytd_End_Acct_Prd_Tot_FSC]
																				  ELSE 0
																			 END
																		ELSE CASE WHEN FK_Account IN ('P-OR-P-FAC','P-OR-P-TTY')
																				  THEN T1.[Pr_Ytd_End_Acct_Prd_Tot_FSC]
																				  ELSE 0
																			 END
																		END
															   ELSE	T1.[Pr_Ytd_End_Acct_Prd_Tot_FSC]
															END
													ELSE CASE WHEN T3.EnrichAccCode = 'FSC_ORC'
															  THEN CASE WHEN T1.FK_YOA <= (T2.[Reporting Year]-3)
																        THEN CASE WHEN FK_Account IN ('PC-LS-OR-TTY','PC-LS-OR-FAC')
																				  THEN T1.[Pr_Ytd_End-1_Acct_Prd_Tot_FSC] 
																				  ELSE 0
																			 END
																		ELSE CASE WHEN FK_Account IN ('P-OR-P-FAC','P-OR-P-TTY')
																				  THEN T1.[Pr_Ytd_End-1_Acct_Prd_Tot_FSC] 
																				  ELSE 0
																			 END
																		END
															   ELSE	T1.[Pr_Ytd_End-1_Acct_Prd_Tot_FSC] 
															END
												END
									END [ActualVal]
									,NULL AS [FscVal]
							FROM IFRS17DataMart.fct.FSC_Actual T1
							INNER JOIN (SELECT Pk_RequestId , [Reporting Period] ,AsAtPeriod, [OB Reporting Period],[Reporting Year]
										FROM #DataOrder
										WHERE Scenario = 'A') T2 ON T2.AsAtPeriod				= T1.FK_AccountingPeriod   
																AND T2.[Reporting Period]		= T1.Earn_Qtr_After_Acct_Prd 
							INNER JOIN (SELECT AccountCode ,FieldLabel, 'FSC_' + SUBSTRING(FieldLabel, 1,  (CHARINDEX('_', FieldLabel) - 1)) EnrichAccCode
										FROM Dim.AccountCodeMapping 
										WHERE AccountCode IN ( 'P-RP-P-FAC', 'P-RP-P-TTY','PC-LS-OR-FAC','PC-LS-OR-TTY','P-OR-P-FAC','P-OR-P-TTY') 
										AND IsActive = 1 )T3 ON T1.FK_Account = T3.AccountCode 
							WHERE 1 = 1
							AND CASE WHEN @UseCase IN ('QTD-A','QTD-F')
										THEN CASE WHEN @UseCase = 'QTD-A'
													THEN CASE WHEN T3.EnrichAccCode = 'FSC_ORC'
															  THEN CASE WHEN T1.FK_YOA <= (T2.[Reporting Year]-3)
																        THEN CASE WHEN FK_Account IN ('PC-LS-OR-TTY','PC-LS-OR-FAC')
																				  THEN T1.Pr_Qtr_End_Acct_Prd_FSC
																				  ELSE 0
																			 END
																		ELSE CASE WHEN FK_Account IN ('P-OR-P-FAC','P-OR-P-TTY')
																				  THEN T1.Pr_Qtr_End_Acct_Prd_FSC
																				  ELSE 0
																			 END
																		END
																ELSE	T1.Pr_Qtr_End_Acct_Prd_FSC
															END
													ELSE CASE WHEN T3.EnrichAccCode = 'FSC_ORC'
															  THEN CASE WHEN T1.FK_YOA <= (T2.[Reporting Year]-3)
																        THEN CASE WHEN FK_Account IN ('PC-LS-OR-TTY','PC-LS-OR-FAC')
																				  THEN T1.[Pr_Qtr_End-1_Acct_Prd_FSC]
																				  ELSE 0
																			 END
																		ELSE CASE WHEN FK_Account IN ('P-OR-P-FAC','P-OR-P-TTY')
																				  THEN T1.[Pr_Qtr_End-1_Acct_Prd_FSC]
																				  ELSE 0
																			 END
																		END
																ELSE	T1.[Pr_Qtr_End-1_Acct_Prd_FSC]
															END
												END
										ELSE CASE WHEN @UseCase = 'YTD-A'
													THEN CASE WHEN T3.EnrichAccCode = 'FSC_ORC'
															  THEN CASE WHEN T1.FK_YOA <= (T2.[Reporting Year]-3)
																        THEN CASE WHEN FK_Account IN ('PC-LS-OR-TTY','PC-LS-OR-FAC')
																				  THEN T1.[Pr_Ytd_End_Acct_Prd_Tot_FSC]
																				  ELSE 0
																			 END
																		ELSE CASE WHEN FK_Account IN ('P-OR-P-FAC','P-OR-P-TTY')
																				  THEN T1.[Pr_Ytd_End_Acct_Prd_Tot_FSC]
																				  ELSE 0
																			 END
																		END
															   ELSE	T1.[Pr_Ytd_End_Acct_Prd_Tot_FSC]
															END
													ELSE CASE WHEN T3.EnrichAccCode = 'FSC_ORC'
															  THEN CASE WHEN T1.FK_YOA <= (T2.[Reporting Year]-3)
																        THEN CASE WHEN FK_Account IN ('PC-LS-OR-TTY','PC-LS-OR-FAC')
																				  THEN T1.[Pr_Ytd_End-1_Acct_Prd_Tot_FSC] 
																				  ELSE 0
																			 END
																		ELSE CASE WHEN FK_Account IN ('P-OR-P-FAC','P-OR-P-TTY')
																				  THEN T1.[Pr_Ytd_End-1_Acct_Prd_Tot_FSC] 
																				  ELSE 0
																			 END
																		END
															   ELSE	T1.[Pr_Ytd_End-1_Acct_Prd_Tot_FSC] 
															END
												END
									END <> 0

								)
								UNION ALL
						---GET FORECAST VALUE
							(
							SELECT 
									T2.Pk_RequestId AS RunID
									,T1.[FK_Entity] AS Entity
									,T1.[FK_Trifocus] AS [Tri Focus Code]
									,T1.[IFRS17_Trifocus] AS [IFRS17 Tri Focus Code]
									,T1.[FK_Account]
									, T3.EnrichAccCode AS [Account]
									,'transactional' AS Prem_Type
									,T1.[Programme]
									,[RI Flag] AS RI_Flag
									,T1.[FK_YOA] AS YoA
									,T1.[FK_InceptionYear] AS YoI
									,T1.[QOI] AS QOI_END_DATE
									,T1.[CCYSettlement]  AS CCY
									,NULL AS [ActualVal]
									,T1.FSC AS [FscVal]
							FROM fct.FSC_Forecast T1
							INNER JOIN (SELECT Pk_RequestId , [Reporting Period] ,AsAtPeriod, [OB Reporting Period]
										FROM #DataOrder
										WHERE Scenario = 'A') T2 ON T2.[OB Reporting Period]	= T1.FK_AccountingPeriod   
																AND T2.[Reporting Period]		= T1.Earn_qtr_prd 
							INNER JOIN (SELECT AccountCode ,FieldLabel, 'FSC_' + SUBSTRING(FieldLabel, 1,  (CHARINDEX('_', FieldLabel) - 1)) EnrichAccCode
										FROM Dim.AccountCodeMapping 
										WHERE AccountCode IN ( 'P-RP-P-FAC', 'P-RP-P-TTY','PC-LS-OR-FAC','PC-LS-OR-TTY','P-OR-P-FAC','P-OR-P-TTY') 
										AND IsActive = 1 )T3 ON T1.FK_Account = T3.AccountCode 
							WHERE 1 = 1
							AND T1.FSC <> 0

								)
					)A
					GROUP BY A.RunID
						,A.Entity
						,A.[Tri Focus Code]
						,A.[IFRS17 Tri Focus Code]
						,A.[Account]
						,A.Prem_Type
						,A.[Programme]
						,A.RI_Flag
						,A.YoA
						,A.YoI
						,A.QOI_END_DATE
						,A.CCY
					HAVING CASE WHEN  @UseCase IN ('YTD-F','QTD-F')
								THEN (ISNULL(SUM(A.ActualVal),0) - ISNULL(SUM(A.FscVal),0)) 
								ELSE SUM(A.ActualVal)
							END IS NOT NULL
                END 
		
		END
	ELSE  -----IF ACTUAL IS MISSING THEN GET THE ACTUALS BY LOOKING THE OB REPORTING PERIOD
		IF @UseCase = 'YTD-A'
		BEGIN
					INSERT INTO [IDS].[Aggr_PremiumBrokerage]([RunID]      ,[Entity]      ,[Tri focus code]      ,[IFRS17 Trifocus]      ,[Account]      ,[Premtype]      ,[Programme]      ,[RI_Flag]      ,[YOA]      ,[YOI]     
					,[QOI_End_Date]      ,[RecognitionType]      ,[CCY]      ,[Amount], AuditUserCreate,	AuditCreateDateTime)
					SELECT A.RunID
						,A.Entity
						,A.[Tri Focus Code]
						,A.[IFRS17 Tri Focus Code]
						,A.[Account]
						,A.Prem_Type
						,A.[Programme]
						,CASE WHEN A.[RI_Flag]='G' THEN 'I' WHEN A.[RI_Flag]='R' THEN 'O' ELSE A.[RI_Flag] END AS RI_Flag
						,A.YoA
						,A.YoI
						,A.QOI_END_DATE
						,'SM' AS [RecognitionType]
						,A.CCY
						, SUM(A.ActualVal) AS AMOUNT
						, SYSTEM_USER
						, GETDATE()
					FROM
						--GET ACTUALS VALUE
							(
							SELECT 
									T2.Pk_RequestId AS RunID
									,T1.[FK_Entity] AS Entity
									,T1.[FK_Trifocus] AS [Tri Focus Code]
									,T1.[IFRS17_Trifocus] AS [IFRS17 Tri Focus Code]
									,T1.[FK_Account]
									, T3.EnrichAccCode AS [Account]
									,'transactional' AS Prem_Type
									,T1.[Programme]
									,[RI Flag] AS RI_Flag
									,T1.[FK_YOA] AS YoA
									,T1.[FK_InceptionYear] AS YoI
									,T1.[QOI] AS QOI_END_DATE
									,T1.[CCYSettlement]  AS CCY
									,CASE WHEN @UseCase IN ('QTD-A','QTD-F')
										THEN CASE WHEN @UseCase = 'QTD-A'
													THEN CASE WHEN T3.EnrichAccCode = 'FSC_ORC'
															  THEN CASE WHEN T1.FK_YOA <= (T2.[Reporting Year]-3)
																        THEN CASE WHEN FK_Account IN ('PC-LS-OR-TTY','PC-LS-OR-FAC')
																				  THEN T1.Pr_Qtr_End_Acct_Prd_FSC
																				  ELSE 0
																			 END
																		ELSE CASE WHEN FK_Account IN ('P-OR-P-FAC','P-OR-P-TTY')
																				  THEN T1.Pr_Qtr_End_Acct_Prd_FSC
																				  ELSE 0
																			 END
																		END
																ELSE	T1.Pr_Qtr_End_Acct_Prd_FSC
															END
													ELSE CASE WHEN T3.EnrichAccCode = 'FSC_ORC'
															  THEN CASE WHEN T1.FK_YOA <= (T2.[Reporting Year]-3)
																        THEN CASE WHEN FK_Account IN ('PC-LS-OR-TTY','PC-LS-OR-FAC')
																				  THEN T1.[Pr_Qtr_End-1_Acct_Prd_FSC]
																				  ELSE 0
																			 END
																		ELSE CASE WHEN FK_Account IN ('P-OR-P-FAC','P-OR-P-TTY')
																				  THEN T1.[Pr_Qtr_End-1_Acct_Prd_FSC]
																				  ELSE 0
																			 END
																		END
																ELSE	T1.[Pr_Qtr_End-1_Acct_Prd_FSC]
															END
												END
										ELSE CASE WHEN @UseCase = 'YTD-A'
													THEN CASE WHEN T3.EnrichAccCode = 'FSC_ORC'
															  THEN CASE WHEN T1.FK_YOA <= (T2.[Reporting Year]-3)
																        THEN CASE WHEN FK_Account IN ('PC-LS-OR-TTY','PC-LS-OR-FAC')
																				  THEN T1.[Pr_Ytd_End_Acct_Prd_Tot_FSC]
																				  ELSE 0
																			 END
																		ELSE CASE WHEN FK_Account IN ('P-OR-P-FAC','P-OR-P-TTY')
																				  THEN T1.[Pr_Ytd_End_Acct_Prd_Tot_FSC]
																				  ELSE 0
																			 END
																		END
															   ELSE	T1.[Pr_Ytd_End_Acct_Prd_Tot_FSC]
															END
													ELSE CASE WHEN T3.EnrichAccCode = 'FSC_ORC'
															  THEN CASE WHEN T1.FK_YOA <= (T2.[Reporting Year]-3)
																        THEN CASE WHEN FK_Account IN ('PC-LS-OR-TTY','PC-LS-OR-FAC')
																				  THEN T1.[Pr_Ytd_End-1_Acct_Prd_Tot_FSC] 
																				  ELSE 0
																			 END
																		ELSE CASE WHEN FK_Account IN ('P-OR-P-FAC','P-OR-P-TTY')
																				  THEN T1.[Pr_Ytd_End-1_Acct_Prd_Tot_FSC] 
																				  ELSE 0
																			 END
																		END
															   ELSE	T1.[Pr_Ytd_End-1_Acct_Prd_Tot_FSC] 
															END
												END
									END [ActualVal]
									,NULL AS [FscVal]
							FROM fct.FSC_Actual T1
							INNER JOIN (SELECT DISTINCT Pk_RequestId , [Reporting Period] , [OB Reporting Period],[Reporting Year]
										FROM #DataOrder
										) T2 ON T2.[OB Reporting Period]	= T1.FK_AccountingPeriod   
											AND T2.[Reporting Period]		= T1.Earn_Qtr_After_Acct_Prd 
							INNER JOIN (SELECT AccountCode ,FieldLabel, 'FSC_' + SUBSTRING(FieldLabel, 1,  (CHARINDEX('_', FieldLabel) - 1)) EnrichAccCode
										FROM Dim.AccountCodeMapping 
										WHERE AccountCode IN ('P-RP-P-FAC', 'P-RP-P-TTY','PC-LS-OR-FAC','PC-LS-OR-TTY','P-OR-P-FAC','P-OR-P-TTY') 
										AND IsActive = 1 )T3 ON T1.FK_Account = T3.AccountCode 
							WHERE 1 = 1
							AND CASE WHEN @UseCase IN ('QTD-A','QTD-F')
										THEN CASE WHEN @UseCase = 'QTD-A'
													THEN CASE WHEN T3.EnrichAccCode = 'FSC_ORC'
															  THEN CASE WHEN T1.FK_YOA <= (T2.[Reporting Year]-3)
																        THEN CASE WHEN FK_Account IN ('PC-LS-OR-TTY','PC-LS-OR-FAC')
																				  THEN T1.Pr_Qtr_End_Acct_Prd_FSC
																				  ELSE 0
																			 END
																		ELSE CASE WHEN FK_Account IN ('P-OR-P-FAC','P-OR-P-TTY')
																				  THEN T1.Pr_Qtr_End_Acct_Prd_FSC
																				  ELSE 0
																			 END
																		END
																ELSE	T1.Pr_Qtr_End_Acct_Prd_FSC
															END
													ELSE CASE WHEN T3.EnrichAccCode = 'FSC_ORC'
															  THEN CASE WHEN T1.FK_YOA <= (T2.[Reporting Year]-3)
																        THEN CASE WHEN FK_Account IN ('PC-LS-OR-TTY','PC-LS-OR-FAC')
																				  THEN T1.[Pr_Qtr_End-1_Acct_Prd_FSC]
																				  ELSE 0
																			 END
																		ELSE CASE WHEN FK_Account IN ('P-OR-P-FAC','P-OR-P-TTY')
																				  THEN T1.[Pr_Qtr_End-1_Acct_Prd_FSC]
																				  ELSE 0
																			 END
																		END
																ELSE	T1.[Pr_Qtr_End-1_Acct_Prd_FSC]
															END
												END
										ELSE CASE WHEN @UseCase = 'YTD-A'
													THEN CASE WHEN T3.EnrichAccCode = 'FSC_ORC'
															  THEN CASE WHEN T1.FK_YOA <= (T2.[Reporting Year]-3)
																        THEN CASE WHEN FK_Account IN ('PC-LS-OR-TTY','PC-LS-OR-FAC')
																				  THEN T1.[Pr_Ytd_End_Acct_Prd_Tot_FSC]
																				  ELSE 0
																			 END
																		ELSE CASE WHEN FK_Account IN ('P-OR-P-FAC','P-OR-P-TTY')
																				  THEN T1.[Pr_Ytd_End_Acct_Prd_Tot_FSC]
																				  ELSE 0
																			 END
																		END
															   ELSE	T1.[Pr_Ytd_End_Acct_Prd_Tot_FSC]
															END
													ELSE CASE WHEN T3.EnrichAccCode = 'FSC_ORC'
															  THEN CASE WHEN T1.FK_YOA <= (T2.[Reporting Year]-3)
																        THEN CASE WHEN FK_Account IN ('PC-LS-OR-TTY','PC-LS-OR-FAC')
																				  THEN T1.[Pr_Ytd_End-1_Acct_Prd_Tot_FSC] 
																				  ELSE 0
																			 END
																		ELSE CASE WHEN FK_Account IN ('P-OR-P-FAC','P-OR-P-TTY')
																				  THEN T1.[Pr_Ytd_End-1_Acct_Prd_Tot_FSC] 
																				  ELSE 0
																			 END
																		END
															   ELSE	T1.[Pr_Ytd_End-1_Acct_Prd_Tot_FSC] 
															END
												END
									END <> 0

								)A
					GROUP BY A.RunID
						,A.Entity
						,A.[Tri Focus Code]
						,A.[IFRS17 Tri Focus Code]
						,A.[Account]
						,A.Prem_Type
						,A.[Programme]
						,A.RI_Flag
						,A.YoA
						,A.YoI
						,A.QOI_END_DATE
						,A.CCY
					HAVING SUM(A.ActualVal) IS NOT NULL

		END

END