﻿CREATE TABLE [fct].[EarningsForGrossNonRadAndRadProg] (
    [Id]                  BIGINT           IDENTITY (1, 1) NOT NULL,
    [FK_AccountingPeriod] INT              NULL,
    [FK_Entity]           VARCHAR (25)     NULL,
    [FK_YOA]              INT              NULL,
    [CCYSettlement]       VARCHAR (10)     NULL,
    [BK_PolicyNumber]     VARCHAR (50)     NULL,
    [InceptionDate]       DATE             NULL,
    [ExpiryDate]          DATE             NULL,
    [FK_Trifocus]         VARCHAR (25)     NULL,
    [FK_Scenario]         VARCHAR (10)     NULL,
    [FK_Account]          VARCHAR (25)     NULL,
    [CCYOriginal]         VARCHAR (10)     NULL,
    [PolicyType]          VARCHAR (50)     NULL,
    [Earn_qtr]            DATE             NULL,
    [QOI]                 DATE             NULL,
    [IFRS17_Trifocus]     VARCHAR (25)     NULL,
    [Programme]           VARCHAR (100)    NULL,
    [RI_FLAG]             VARCHAR (2)      NULL,
    [Claims_Basis]        VARCHAR (50)     NULL,
    [Pol_InceptionDate]   DATE             NULL,
    [Pol_ExpiryDate]      DATE             NULL,
    [FK_InceptionYear]    INT              NULL,
    [Earned_prem]         NUMERIC (38, 12) NULL,
    [Value]               NUMERIC (38, 12) NULL,
    [AuditUser]           VARCHAR (255)    DEFAULT (suser_sname()) NOT NULL,
    [AuditCreateDatetime] DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 90)
);


GO
CREATE NONCLUSTERED INDEX [IX_EarningsForGrossNonRadAndRadProg_AccountingPeriod] ON [fct].[EarningsForGrossNonRadAndRadProg]  
(
[FK_AccountingPeriod] ASC
)

GO
