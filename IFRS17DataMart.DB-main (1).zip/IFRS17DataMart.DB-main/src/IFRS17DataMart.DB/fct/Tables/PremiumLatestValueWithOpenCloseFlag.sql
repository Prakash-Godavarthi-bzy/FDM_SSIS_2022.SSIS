﻿CREATE TABLE [fct].[PremiumLatestValueWithOpenCloseFlag] (
    [Id]                  BIGINT           IDENTITY (1, 1) NOT NULL,
    [FK_Account]          VARCHAR (15)     NOT NULL,
    [FK_Process]          VARCHAR (10)     NOT NULL,
    [FK_Basis]            VARCHAR (10)     NOT NULL,
    [BK_PolicyNumber]     VARCHAR (50)     NULL,
    [PolicyType]          VARCHAR (50)     NULL,
    [TypeOfBusiness]      VARCHAR (10)     NULL,
    [InceptionDate]       DATETIME         NULL,
    [ExpiryDate]          DATETIME         NULL,
    [FK_Entity]           VARCHAR (25)     NOT NULL,
    [FK_Trifocus]         VARCHAR (25)     NOT NULL,
    [FK_YOA]              VARCHAR (10)     NOT NULL,
    [CCYOriginal]         VARCHAR (10)     NOT NULL,
    [CCYSettlement]       VARCHAR (10)     NOT NULL,
    [Fk_dataset]          VARCHAR (255)    NULL,
    [FK_scenario]         VARCHAR (10)     NOT NULL,
    [FK_inceptionyear]    INT              NULL,
    [InceptionPeriod]     INT              NULL,
    [Value]               NUMERIC (38, 10) NULL,
    [FK_AccountingPeriod] INT              NOT NULL,
    [AuditCreateDateTime] DATETIME2 (7)    NOT NULL,
    [AuditUserCreate]     NVARCHAR (510)   NOT NULL,
    [RI Flag]             VARCHAR (2)      NULL,
    [Programme]           VARCHAR (100)    NULL,
    [Claim_Basis]         VARCHAR (50)     NULL,
    [RI_Policy_Type]      VARCHAR (50)     NULL,
    [MOPCode]             VARCHAR (10)     NULL,
    [Open_Cls_Flag]       VARCHAR (10)     NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 90)
);


GO
  ALTER TABLE FCT.PremiumLatestValueWithOpenCloseFlag    ADD CONSTRAINT FK_Entity_PLVWOCF FOREIGN KEY(FK_Entity)
REFERENCES  DIM.Entity (PK_Entity)
 
 GO
 ALTER TABLE FCT.PremiumLatestValueWithOpenCloseFlag    ADD CONSTRAINT FK_Trifocus_PLVWOCF FOREIGN KEY(FK_Trifocus)
REFERENCES  DIM.TriFocus (PK_TriFocus)

GO
ALTER TABLE FCT.PremiumLatestValueWithOpenCloseFlag    ADD CONSTRAINT FK_CCYSettlement_PLVWOCF FOREIGN KEY(CCYSettlement)
REFERENCES  DIM.CCY (PK_CCY)

GO
 ALTER TABLE FCT.PremiumLatestValueWithOpenCloseFlag    ADD CONSTRAINT FK_AccountingPeriod_PLVWOCF FOREIGN KEY(FK_AccountingPeriod)
REFERENCES  DIM.AccountingPeriod (PK_AccountingPeriod)
 
 GO
 ALTER TABLE FCT.PremiumLatestValueWithOpenCloseFlag    ADD CONSTRAINT FK_scenario_PLVWOCF FOREIGN KEY(FK_scenario)
REFERENCES  DIM.Scenario (PK_Scenario)

GO
ALTER TABLE FCT.PremiumLatestValueWithOpenCloseFlag    ADD CONSTRAINT FK_YOA_PLVWOCF FOREIGN KEY(FK_YOA)
REFERENCES  DIM.YOA (PK_YOA)
Go
CREATE NONCLUSTERED INDEX [IX_PremiumLatestValueWithOpenCloseFlag_AccountingPeriod] ON [fct].[PremiumLatestValueWithOpenCloseFlag]  
(
[FK_AccountingPeriod] ASC
)