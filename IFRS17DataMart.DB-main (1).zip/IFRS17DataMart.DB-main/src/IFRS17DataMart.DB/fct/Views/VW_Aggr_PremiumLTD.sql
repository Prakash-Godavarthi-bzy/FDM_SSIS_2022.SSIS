﻿

CREATE VIEW [fct].[VW_Aggr_PremiumLTD] 
AS
SELECT FORMAT(
			DateAdd(month 
					, 1
					, (CONCAT
						(CONCAT
							(CONCAT
								((SELECT ISNULL(max(LEFT(AccountingPeriod,4)),2018) FROM fct.Aggr_PremiumLTD),'-') 
								,(SELECT ISNULL(max(RIGHT(AccountingPeriod,2)),11) 
									FROM fct.Aggr_PremiumLTD 
									WHERE LEFT(AccountingPeriod,4) = (SELECT ISNULL(max(LEFT(AccountingPeriod,4)),2018) FROM fct.Aggr_PremiumLTD)  
								  )
							) 
							, '- 01'
						)
					   )
					)
			,'yyyyMM') as AccountingPeriod