﻿CREATE TABLE [fct].[FSC_EarnPrem_Prior] (
    [Id]                  INT              IDENTITY (1, 1) NOT NULL,
    [Accounting_Period]   INT              NOT NULL,
    [Earn_qtr_prd]        INT              NULL,
    [FK_Entity]           VARCHAR (25)     NOT NULL,
    [Programme]           VARCHAR (100)    NULL,
    [RI_Flag]             VARCHAR (2)      NULL,
    [FK_Trifocus]         VARCHAR (25)     NOT NULL,
    [FK_YOA]              INT              NOT NULL,
    [Account]             VARCHAR (25)     NOT NULL,
    [CCYOriginal]         VARCHAR (10)     NOT NULL,
    [CCYSettlement]       VARCHAR (10)     NOT NULL,
    [BK_PolicyNumber]     VARCHAR (100)    NULL,
    [InceptionDate]       DATE             NULL,
    [ExpiryDate]          DATE             NULL,
    [Value]               NUMERIC (38, 10) NULL,
    [Unearned_Perc]       NUMERIC (38, 10) NULL,
    [AuditCreateDateTime] DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]     NVARCHAR (510)   DEFAULT (suser_sname()) NOT NULL,
    CONSTRAINT [PK_ID_FSC_EarnPrem_Prior] PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 90)
);


Go

GO

CREATE NONCLUSTERED INDEX [IX_FSC_EarnPrem_Prior_AccountingPeriod] ON [fct].[FSC_EarnPrem_Prior]
(
[Accounting_Period] ASC
)

GO
