﻿CREATE TABLE [fct].[RIPercentage] (
    [AccountingPeriod]  VARCHAR (25)    NULL,
    [TrifocusCode]      NVARCHAR (50)   NULL,
    [TrifocusName]      NVARCHAR (255)  NULL,
    [Entity]            VARCHAR (50)    NULL,
    [YOA]               INT             NULL,
    [YOI]               INT             NULL,
    [RIProgramme]       VARCHAR (255)   NULL,
    [RIType]            VARCHAR (50)    NULL,
    [SettlementCCY]     VARCHAR (25)    NULL,
    [RIPolicyNumber]    VARCHAR (255)   NULL,
    [InceptionDate]     DATETIME        NULL,
    [ExpiryDate]        DATETIME        NULL,
    [ClaimsBasis]       VARCHAR (10)    NULL,
    [RIPremium]         NUMERIC (19, 6) NULL,
    [GrossNetUltimates] NUMERIC (19, 6) NULL,
    [RI%]               NUMERIC (19, 6) NULL,
    [Businesskey]       VARCHAR (500)   NOT NULL
);

