﻿CREATE TABLE [fct].[ActualWrittenPremiumByEarnQtr_Binders] (
    [Id]                   INT              IDENTITY (1, 1) NOT NULL,
    [FK_Entity]            VARCHAR (25)     NOT NULL,
    [FK_YOA]               INT              NOT NULL,
    [CCYSettlement]        VARCHAR (10)     NOT NULL,
    [BK_PolicyNumber]      VARCHAR (50)     NULL,
    [FK_DataSet]           VARCHAR (255)    NULL,
    [FK_Trifocus]          VARCHAR (25)     NOT NULL,
    [FK_Scenario]          VARCHAR (10)     NOT NULL,
    [FK_Account]           VARCHAR (25)     NOT NULL,
    [FK_AccountingPeriod]  INT              NOT NULL,
    [CCYOriginal]          VARCHAR (10)     NOT NULL,
    [PolicyType]           VARCHAR (50)     NULL,
    [Pol_InceptionDate]    DATETIME         NULL,
    [Pol_ExpiryDate]       DATETIME         NULL,
    [Inc_qtr]              DATETIME         NULL,
    [IFRS17_Trifocus]      VARCHAR (25)     NULL,
    [Programme]            VARCHAR (100)    NULL,
    [RI_FLAG]              VARCHAR (2)      NULL,
    [Earn_qtr]             DATETIME         NULL,
    [Adj_Tot_Earn_days_v3] NUMERIC (38, 12) NULL,
    [earned_prem]          NUMERIC (38, 12) NULL,
    [FK_InceptionYear]     INT              NULL,
    [Value]                NUMERIC (38, 12) NULL,
    [AuditUser]            VARCHAR (255)    DEFAULT (suser_sname()) NOT NULL,
    [AuditCreateDatetime]  DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_ID_ActualWrittenPremiumByEarnQtr_Binders] PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 90)
);


GO
CREATE NONCLUSTERED INDEX [IX_ActualWrittenPremiumByEarnQtr_Binders_AccountingPeriod] ON [fct].[ActualWrittenPremiumByEarnQtr_Binders]  
(
[FK_AccountingPeriod] ASC
)
GO


GO


