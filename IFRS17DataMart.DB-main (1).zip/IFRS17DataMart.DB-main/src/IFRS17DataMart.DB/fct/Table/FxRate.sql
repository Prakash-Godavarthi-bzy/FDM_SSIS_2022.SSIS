﻿CREATE TABLE [fct].[FxRate]
(
	[Id] INT Identity(1,1) PRIMARY KEY,
	[FXRate] Numeric(38,12) NULL,
	[AssumptionDatasetNameId] [int] NOT NULL,
	[AssumptionPercentageTypeId] [int] NOT NULL,
	[FxType] nvarchar(255) NULL,
	[ReportingCurrencyCode] [nvarchar](255) NULL,
	[CCY] [nvarchar](10) NULL,
	[MS_AUDIT_TIME] [datetime] NULL,
	[MS_AUDIT_USER] [nvarchar](255) NULL
) ON [PRIMARY]
GO


ALTER TABLE FCT.FxRate  ADD CONSTRAINT FK_AssumptionDatasetNameId_FxAss FOREIGN KEY([AssumptionDatasetNameId])
REFERENCES Dim.AssumptionDatasets ([Pk_AssumptionDatasetNameId])

GO
ALTER TABLE FCT.FxRate  ADD CONSTRAINT FK_AssumptionPercentageTypeId_FxAss FOREIGN KEY([AssumptionPercentageTypeId])
REFERENCES Dim.AssumptionPercentageType ([Pk_AssumptionPercentageTypeId])

