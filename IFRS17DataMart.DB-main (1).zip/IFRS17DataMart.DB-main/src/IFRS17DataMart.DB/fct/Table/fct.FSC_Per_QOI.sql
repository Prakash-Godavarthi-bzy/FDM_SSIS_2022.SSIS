﻿CREATE TABLE [fct].[FSC_Per_QOI] (
    [Id]                  INT              IDENTITY (1, 1) NOT NULL,
    [FK_AccountingPeriod] INT              NOT NULL,
    [Earn_qtr]            DATE             NULL,
    [Earning Category]    CHAR (1)         NOT NULL,
    [Programme]           VARCHAR (100)    NULL,
    [FK_Trifocus]         VARCHAR (25)     NOT NULL,
    [FK_Scenario]         CHAR (1)         NOT NULL,
    [FK_InceptionYear]    INT              NULL,
    [QOI]                 DATE             NULL,
    [CCYSett]             VARCHAR (10)     NOT NULL,
    [Pattern]             NUMERIC (38, 10) NULL,
    [AuditCreateDateTime] DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]     NVARCHAR (510)   DEFAULT (suser_sname()) NOT NULL,
    CONSTRAINT [PK_ID_FSC_Per_QOI] PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 90)
);


Go
CREATE NONCLUSTERED INDEX [IX_FSC_Per_QOI_AccountingPeriod] ON [fct].[FSC_Per_QOI]  
(
[FK_AccountingPeriod] ASC
)
Go


Go
