﻿CREATE TABLE [fct].[TechnicalResult_ADM] (
    [FK_Batch]            INT              NULL,
    [FK_DataSet]          VARCHAR (255)    NULL,
    [FK_Scenario]         VARCHAR (10)     NOT NULL,
    [FK_Account]          VARCHAR (13)     NULL,
    [FK_AccountingPeriod] INT              NOT NULL,
    [FK_Basis]            VARCHAR (10)     NOT NULL,
    [FK_Entity]           VARCHAR (25)     NOT NULL,
    [FK_Process]          VARCHAR (10)     NOT NULL,
    [FK_Trifocus]         VARCHAR (25)     NOT NULL,
    [FK_YOA]              VARCHAR (10)     NOT NULL,
    [CCYOriginal]         VARCHAR (10)      NOT NULL,
    [CCYSettlement]       VARCHAR (10)      NOT NULL,
    [FK_inceptionyear]    INT              NULL,
    [InceptionPeriod]     INT              NULL,
    [DeltaType]           VARCHAR (50)     NULL,
    [FK_Policy]           VARCHAR (118)    NOT NULL,
    [VALUE]               NUMERIC (38, 10) NOT NULL,
    [AuditCreateDateTime] DATETIME2 (7)    DEFAULT (getutcdate()) NOT NULL,
    [AuditUserCreate]     NVARCHAR (510)   DEFAULT (suser_sname()) NOT NULL
);

 
