﻿CREATE TABLE [fct].[FSC_EPI] (
    [Id]                  INT              IDENTITY (1, 1) NOT NULL,
    [FK_AccountingPeriod] INT              NOT NULL,
    [FK_Entity]           VARCHAR (25)     NOT NULL,
    [Programme]           VARCHAR (100)    NULL,
    [RI_Flag]             VARCHAR (2)      NULL,
    [FK_Trifocus]         VARCHAR (25)     NOT NULL,
    [FK_YOA]              INT              NOT NULL,
    [FK_Account]          VARCHAR (25)     NOT NULL,
    [CCYOriginal]         VARCHAR (10)     NOT NULL,
    [CCYSettlement]       VARCHAR (10)     NOT NULL,
    [BK_PolicyNumber]     VARCHAR (50)     NULL,
    [InceptionDate]       DATE             NULL,
    [ExpiryDate]          DATE             NULL,
    [Value]               NUMERIC (38, 10) NULL,
    [AuditCreateDateTime] DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]     NVARCHAR (510)   DEFAULT (suser_sname()) NOT NULL,
    CONSTRAINT [PK_ID_FSC_EPI] PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 90)
);


Go
CREATE NONCLUSTERED INDEX [IX_FSC_EPI_AccountingPeriod] ON [fct].[FSC_EPI]  
(
[FK_AccountingPeriod] ASC
)
Go


GO


