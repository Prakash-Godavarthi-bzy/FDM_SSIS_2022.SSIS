﻿CREATE TABLE [fct].[Pattern] (
    [PK_Pattern]                      BIGINT           IDENTITY (1, 1) NOT NULL,
    [FK_Batch]                        INT              NOT NULL,
    [FK_DataSet]                      VARCHAR (255)    NULL,
    [FK_PatternName]                  VARCHAR (20)     NULL,
    [Fk_AssumptionPercentageTypeId]   INT              DEFAULT ((-1)) NOT NULL,
    [Fk_AssumptionDatasetNameId]      INT              DEFAULT ((-1)) NOT NULL,
    [FK_Trifocus]                     VARCHAR (25)     NOT NULL,
    [FK_YOA]                          VARCHAR (10)     NOT NULL,
    [FK_InceptionYear]                INT              NOT NULL,
    [CCYSettlement]                   VARCHAR (10)     NOT NULL,
    [FK_AccountingPeriod]             INT              NOT NULL,
    [DevelopmentQuarter]              INT              NOT NULL,
    [PatternScenario]                 VARCHAR (10)     NOT NULL,
    [PatternScenarioVersion]          INT              NOT NULL,
    [DevelopmentPercentageIncrement]  NUMERIC (38, 10) NOT NULL,
    [DevelopmentPercentageCumulative] NUMERIC (38, 10) NULL,
    [TDH_DatasetName]                 VARCHAR (35)     NULL,
    [AuditCreateDateTime]             DATETIME2 (7)    DEFAULT (getutcdate()) NOT NULL,
    [AuditGenerateDateTime]           DATETIME2 (7)    NOT NULL,
    [AuditUserCreate]                 VARCHAR (510)    NOT NULL,
    CONSTRAINT [PK_Pattern] PRIMARY KEY CLUSTERED ([PK_Pattern] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_AssumptionDatasetNameId] FOREIGN KEY ([Fk_AssumptionDatasetNameId]) REFERENCES [Dim].[AssumptionDatasets] ([Pk_AssumptionDatasetNameId]),
    CONSTRAINT [FK_AssumptionPercentageTypeId] FOREIGN KEY ([Fk_AssumptionPercentageTypeId]) REFERENCES [Dim].[AssumptionPercentageType] ([Pk_AssumptionPercentageTypeId])
);

GO
CREATE NONCLUSTERED INDEX [bzyidx_Pattern_1]
    ON [fct].[Pattern]([TDH_DatasetName] ASC)
    INCLUDE([FK_PatternName], [FK_Trifocus], [DevelopmentQuarter], [DevelopmentPercentageCumulative]) WITH (FILLFACTOR = 90);



