CREATE TABLE [fct].[FSC_Per_YOA_adj](
	[Id] INT IDENTITY(1,1) NOT NULL,
	[RunID] INT NULL,
	[AdjustmentID] VARCHAR(30) NULL,
	[Earn_qtr] DATE NULL,
	[Earning Category] CHAR(1) NOT NULL,
	[Programme] VARCHAR(100) NOT NULL,
	[FK_Trifocus] VARCHAR(25) NOT NULL,
	[FK_Scenario] CHAR(1) NOT NULL,
	[FK_InceptionYear] INT NULL,
	[FK_YOA] INT NOT NULL,
	[CCYSettlement] VARCHAR(10) NOT NULL,
	[Pattern] NUMERIC(38, 10) NULL,
	[AuditCreateDateTime] DATETIME2(7) NOT NULL DEFAULT GETDATE(),
	[AuditUserCreate] NVARCHAR(510) NOT NULL DEFAULT SUSER_SNAME()
) 
------GO Sprint2024Q1
------ALTER TABLE [fct].[FSC_Per_YOA_adj] ADD CONSTRAINT PK_ID_FSC_Per_YOA_adj PRIMARY KEY (Id);

Go
CREATE NONCLUSTERED INDEX [IX_FSC_Per_YOA_adj_AdjustmentID] ON [fct].[FSC_Per_YOA_adj]  
(
[AdjustmentID] ASC
)

