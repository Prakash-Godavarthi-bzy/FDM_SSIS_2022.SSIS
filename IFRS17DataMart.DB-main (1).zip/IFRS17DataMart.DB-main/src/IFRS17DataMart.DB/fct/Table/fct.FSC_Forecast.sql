﻿CREATE TABLE [fct].[FSC_Forecast] (
    [Id]                  INT              IDENTITY (1, 1) NOT NULL,
    [FK_AccountingPeriod] INT              NOT NULL,
    [Earn_qtr_prd]        INT              NULL,
    [FK_Entity]           VARCHAR (25)     NOT NULL,
    [Programme]           VARCHAR (100)    NULL,
    [RI Flag]             VARCHAR (2)      NULL,
    [FK_Trifocus]         VARCHAR (25)     NOT NULL,
    [IFRS17_Trifocus]     VARCHAR (25)     NOT NULL,
    [FK_YOA]              INT              NOT NULL,
    [FK_InceptionYear]    INT              NULL,
    [QOI]                 DATE             NULL,
    [FK_Account]          VARCHAR (25)     NOT NULL,
    [FK_Scenario]         CHAR (1)         NOT NULL,
    [CCYSettlement]       VARCHAR (10)     NOT NULL,
    [FSC]                 NUMERIC (38, 10) DEFAULT ((0)) NULL,
    [AuditCreateDateTime] DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]     NVARCHAR (510)   DEFAULT (suser_sname()) NOT NULL,
    CONSTRAINT [PK_ID_FSC_Forecast] PRIMARY KEY NONCLUSTERED ([Id] ASC) WITH (FILLFACTOR = 90)
);



GO
CREATE UNIQUE CLUSTERED INDEX [PK_fct_FSC_Forecast]
    ON [fct].[FSC_Forecast]([Id] ASC) WITH (FILLFACTOR = 90);
	Go
	CREATE NONCLUSTERED INDEX [IX_FSC_Forecast_AccountingPeriod] ON [fct].[FSC_Forecast]  
(
[FK_AccountingPeriod] ASC
)
Go


GO

