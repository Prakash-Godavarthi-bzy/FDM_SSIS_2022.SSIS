﻿CREATE TABLE [fct].[Aggr_PremiumLTD] (
    [Id]                  INT              IDENTITY (1, 1) NOT NULL,
    [Entity]              VARCHAR (25)     NOT NULL,
    [Trifocus]            VARCHAR (25)     NOT NULL,
    [IFRS17 Trifocus]     VARCHAR (25)     NULL,
    [RI Prog]             VARCHAR (100)    NULL,
    [RI Flag]             VARCHAR (2)      NULL,
    [CCYSettlement]       VARCHAR (10)     NOT NULL,
    [Dataset]             VARCHAR (255)    NULL,
    [Scenario]            VARCHAR (10)     NOT NULL,
    [Account]             VARCHAR (15)     NOT NULL,
    [AccountingPeriod]    INT              NOT NULL,
    [YOA]                 VARCHAR (10)     NOT NULL,
    [YOI]                 INT              NULL,
    [MOI]                 INT              NULL,
    [Value]               NUMERIC (38, 10) NULL,
    [AuditCreateDateTime] DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]     NVARCHAR (510)   DEFAULT (suser_sname()) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_AccountingPeriod] FOREIGN KEY ([AccountingPeriod]) REFERENCES [Dim].[AccountingPeriod] ([PK_AccountingPeriod]),
    CONSTRAINT [FK_CCYSettlement] FOREIGN KEY ([CCYSettlement]) REFERENCES [Dim].[CCY] ([PK_CCY]),
    CONSTRAINT [FK_Entity] FOREIGN KEY ([Entity]) REFERENCES [Dim].[Entity] ([PK_Entity]),
    CONSTRAINT [FK_Scenario] FOREIGN KEY ([Scenario]) REFERENCES [Dim].[Scenario] ([PK_Scenario]),
    CONSTRAINT [FK_Trifocus] FOREIGN KEY ([Trifocus]) REFERENCES [Dim].[TriFocus] ([PK_TriFocus]),
    CONSTRAINT [FK_YOA] FOREIGN KEY ([YOA]) REFERENCES [Dim].[YOA] ([PK_YOA])
);



 
GO
 
 
 GO
 

GO


GO
 

 GO
 

GO


GO 
   


GO
CREATE NONCLUSTERED INDEX [bzyidx_Aggr_PremiumLTD_3]
    ON [fct].[Aggr_PremiumLTD]([Account] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [bzyidx_Aggr_PremiumLTD_2]
    ON [fct].[Aggr_PremiumLTD]([Trifocus] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [bzyidx_Aggr_PremiumLTD_1]
    ON [fct].[Aggr_PremiumLTD]([Scenario] ASC) WITH (FILLFACTOR = 90);
	Go
	CREATE NONCLUSTERED INDEX [IX_Aggr_PremiumLTD_AccountingPeriod] ON [fct].[Aggr_PremiumLTD]
(
[AccountingPeriod] ASC
)
