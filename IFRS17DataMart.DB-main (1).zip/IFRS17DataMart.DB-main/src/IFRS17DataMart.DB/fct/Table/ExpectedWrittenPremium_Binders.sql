﻿CREATE TABLE [fct].[ExpectedWrittenPremium_Binders] (
    [Id]                  INT              IDENTITY (1, 1) NOT NULL,
    [FK_Entity]           VARCHAR (25)     NOT NULL,
    [FK_YOA]              INT              NOT NULL,
    [CCYSettlement]       VARCHAR (10)     NOT NULL,
    [BK_PolicyNumber]     VARCHAR (50)     NULL,
    [InceptionDate]       DATETIME         NULL,
    [ExpiryDate]          DATETIME         NULL,
    [FK_DataSet]          VARCHAR (255)    NULL,
    [FK_Trifocus]         VARCHAR (25)     NOT NULL,
    [Value]               NUMERIC (38, 12) NULL,
    [FK_Scenario]         VARCHAR (10)     NOT NULL,
    [FK_Account]          VARCHAR (25)     NOT NULL,
    [FK_AccountingPeriod] INT              NOT NULL,
    [CCYOriginal]         VARCHAR (10)     NOT NULL,
    [PolicyType]          VARCHAR (50)     NULL,
    [FK_InceptionYear]    INT              NULL,
    [Pol_len_days]        INT              NULL,
    [Bind_adj_writ_prem]  NUMERIC (38, 12) NULL,
    [IFRS17_Trifocus]     VARCHAR (25)     NULL,
    [Programme]           VARCHAR (100)    NULL,
    [RI_FLAG]             VARCHAR (2)      NULL,
    [Claims Basis]        VARCHAR (50)     NULL,
    [RI Type]             VARCHAR (50)     NULL,
    [Pol_len_qtrs]        INT              NULL,
    [AuditUser]           VARCHAR (255)    DEFAULT (suser_sname()) NOT NULL,
    [AuditCreateDatetime] DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_ID_ExpectedWrittenPremium_Binders] PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 90)
);


GO
CREATE NONCLUSTERED INDEX [IX_ExpectedWrittenPremium_Binders_AccountingPeriod] ON [fct].[ExpectedWrittenPremium_Binders]  
(
[FK_AccountingPeriod] ASC
)
GO


GO

