﻿CREATE TABLE [fct].[AssumptionData] (
    [WB_TYPE]                       NVARCHAR (5)     NULL,
    [Pk_AssumptionDatasetNameId]    INT        NOT   NULL,
    [Pk_AssumptionPercentageTypeId] INT        NOT   NULL,
    [PK_LossType]                   NVARCHAR (255)   NULL,
    [YOA]                           NVARCHAR (10)    NULL,
    [TriFocus]                      NVARCHAR (25)    NULL,
    [CCY]                           VARCHAR (10)     NULL,
    [FX_ReportingCurrencyCode_4]    NVARCHAR (255)   NULL,
    [DR_DevelopmentYear]            INT              NULL,
    [PP_DevelopmentQuarter]         INT              NULL,
    [Value]                         NUMERIC (38, 12) NULL,
    [Entity]                        VARCHAR (35)     NULL,
    [Gross/RI Flag]                 VARCHAR (2)      NULL,
    [Account]                       VARCHAR (50)     NULL,
    [Source]                        CHAR (1)         NULL,
    [EarnedPercentage]              DECIMAL (19, 10) NULL,
    [InceptionDate]                 DATETIME         NULL,
    [Narrative]                     VARCHAR (255)    NULL,
    [AdjustmentID]                  VARCHAR (30)     NULL,
    [Programme]                     VARCHAR (100)    NULL,
    [Focus Group]                   VARCHAR (100)    NULL
);





GO
CREATE NONCLUSTERED INDEX [bzyidx_AssumptionData_1]
    ON [fct].[AssumptionData]([WB_TYPE] ASC) WITH (FILLFACTOR = 90);




GO
CREATE CLUSTERED INDEX [PK_AssumptionData]
    ON [fct].[AssumptionData]([Pk_AssumptionDatasetNameId] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [bzyidx_AssumptionData_2]
    ON [fct].[AssumptionData]([Pk_AssumptionPercentageTypeId] ASC) WITH (FILLFACTOR = 90);

GO
ALTER TABLE fct.AssumptionData  ADD CONSTRAINT FK_AssumptionPercentageTypeId_AssD  FOREIGN KEY([Pk_AssumptionPercentageTypeId])
REFERENCES Dim.AssumptionPercentageType ([Pk_AssumptionPercentageTypeId])

GO
ALTER TABLE fct.AssumptionData   ADD CONSTRAINT FK_AssumptionDatasetNameId_AssD  FOREIGN KEY([Pk_AssumptionDatasetNameId])
REFERENCES Dim.AssumptionDatasets ([Pk_AssumptionDatasetNameId])