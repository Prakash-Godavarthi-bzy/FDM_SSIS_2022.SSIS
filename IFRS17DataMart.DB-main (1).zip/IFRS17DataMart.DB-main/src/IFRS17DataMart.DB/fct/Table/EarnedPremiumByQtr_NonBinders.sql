﻿CREATE TABLE [fct].[EarnedPremiumByQtr_NonBinders] (
    [Id]                  INT              IDENTITY (1, 1) NOT NULL,
    [FK_Entity]           VARCHAR (25)     NOT NULL,
    [FK_YOA]              INT              NOT NULL,
    [CCYSettlement]       VARCHAR (10)     NOT NULL,
    [BK_PolicyNumber]     VARCHAR (50)     NULL,
    [InceptionDate]       DATETIME         NULL,
    [ExpiryDate]          DATETIME         NULL,
    [FK_Trifocus]         VARCHAR (25)     NOT NULL,
    [Value]               NUMERIC (38, 12) NULL,
    [FK_Scenario]         VARCHAR (10)     NOT NULL,
    [FK_Account]          VARCHAR (25)     NOT NULL,
    [FK_AccountingPeriod] INT              NOT NULL,
    [CCYOriginal]         VARCHAR (10)     NOT NULL,
    [PolicyType]          VARCHAR (50)     NULL,
    [FK_InceptionYear]    INT              NULL,
    [Earn_qtr]            DATETIME         NULL,
    [Earned_days]         INT              NULL,
    [Earned_prem]         NUMERIC (38, 12) NULL,
    [QOI]                 DATETIME         NULL,
    [IFRS17_Trifocus]     VARCHAR (25)     NULL,
    [Programme]           VARCHAR (100)    NULL,
    [RI_FLAG]             VARCHAR (2)      NULL,
    [Claims Basis]        VARCHAR (50)     NULL,
    [Pol_InceptionDate]   DATETIME         NULL,
    [Pol_ExpiryDate]      DATETIME         NULL,
    [AuditUser]           VARCHAR (255)    DEFAULT (suser_sname()) NOT NULL,
    [AuditCreateDatetime] DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_ID_EarnedPremiumByQtr_NonBinders] PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 90)
);


Go
CREATE NONCLUSTERED INDEX [IX_EarnedPremiumByQtr_NonBinders_AccountingPeriod] ON [fct].[EarnedPremiumByQtr_NonBinders]  
(
[FK_AccountingPeriod] ASC
)
Go


GO



