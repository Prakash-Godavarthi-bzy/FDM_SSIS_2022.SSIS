CREATE TABLE [fct].[PreProcessPremiumLTD] (
    [Id]                  BIGINT           IDENTITY (1, 1) NOT NULL,
    [FK_Account]          VARCHAR (15)     NOT NULL,
    [FK_Process]          VARCHAR (10)     NOT NULL,
    [FK_Basis]            VARCHAR (10)     NOT NULL,
    [BK_PolicyNumber]     VARCHAR (50)     NULL,
    [PolicyType]          VARCHAR (50)     NULL,
    [TypeOfBusiness]      VARCHAR (10)     NULL,
    [InceptionDate]       DATETIME         NULL,
    [ExpiryDate]          DATETIME         NULL,
    [FK_Entity]           VARCHAR (25)     NOT NULL,
    [FK_Trifocus]         VARCHAR (25)     NOT NULL,
    [FK_YOA]              VARCHAR (10)     NOT NULL,
    [CCYOriginal]         VARCHAR (10)      NOT NULL,
    [CCYSettlement]       VARCHAR (10)      NOT NULL,
    [Fk_dataset]          VARCHAR (255)    NULL,
    [FK_scenario]         VARCHAR (10)     NOT NULL,
    [FK_inceptionyear]    INT              NULL,
    [InceptionPeriod]     INT              NULL,
    [Value]               NUMERIC (38, 10) NULL,
    [FK_AccountingPeriod] INT              NOT NULL,
    [AuditCreateDateTime] DATETIME2 (7)    NOT NULL,
    [AuditUserCreate]     NVARCHAR (510)   NOT NULL,
    [RI Flag]             VARCHAR (2)      NULL,
    [Programme]           VARCHAR (100)    NULL,
    [Claim_Basis]         VARCHAR (50)     NULL,
    [RI_Policy_Type]      VARCHAR (50)     NULL,
    [MOPCode] varchar(10),
    PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 90)
);

GO
  ALTER TABLE FCT.PreProcessPremiumLTD  ADD CONSTRAINT FK_Entity_PPP FOREIGN KEY(FK_Entity)
REFERENCES  DIM.Entity (PK_Entity)
 
 GO
 ALTER TABLE FCT.PreProcessPremiumLTD    ADD CONSTRAINT FK_Trifocus_PPP FOREIGN KEY(FK_Trifocus)
REFERENCES  DIM.TriFocus (PK_TriFocus)

GO
ALTER TABLE FCT.PreProcessPremiumLTD    ADD CONSTRAINT CCYSettlement_PPP FOREIGN KEY(CCYSettlement)
REFERENCES  DIM.CCY (PK_CCY)

GO
 ALTER TABLE FCT.PreProcessPremiumLTD    ADD CONSTRAINT FK_AccountingPeriod_PPP FOREIGN KEY(FK_AccountingPeriod)
REFERENCES  DIM.AccountingPeriod (PK_AccountingPeriod)
 
 GO
 ALTER TABLE FCT.PreProcessPremiumLTD    ADD CONSTRAINT FK_scenario_PPP FOREIGN KEY(FK_scenario)
REFERENCES  DIM.Scenario (PK_Scenario)

GO
ALTER TABLE FCT.PreProcessPremiumLTD    ADD CONSTRAINT FK_YOA_PPP FOREIGN KEY(FK_YOA)
REFERENCES  DIM.YOA (PK_YOA)



GO
CREATE NONCLUSTERED INDEX [bzyidx_PreProcessPremiumLTD_4]
    ON [fct].[PreProcessPremiumLTD]([FK_Process] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [bzyidx_PreProcessPremiumLTD_3]
    ON [fct].[PreProcessPremiumLTD]([FK_AccountingPeriod] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [bzyidx_PreProcessPremiumLTD_2]
    ON [fct].[PreProcessPremiumLTD]([Fk_dataset] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [bzyidx_PreProcessPremiumLTD_1]
    ON [fct].[PreProcessPremiumLTD]([FK_Account] ASC) WITH (FILLFACTOR = 90);

	GO
	CREATE NONCLUSTERED INDEX [IX_PreProcessPremiumLTD_AccountingPeriod] ON [fct].[PreProcessPremiumLTD]
(
[FK_AccountingPeriod] ASC
)
GO

CREATE NONCLUSTERED INDEX [IX_PreProcessPremiumLTD_TrifocusYOAProgramme] ON [fct].[PreProcessPremiumLTD]
(
    [FK_AccountingPeriod] ASC,
	[FK_YOA] ASC,
	[FK_Trifocus] ASC,
	[Programme] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
GO