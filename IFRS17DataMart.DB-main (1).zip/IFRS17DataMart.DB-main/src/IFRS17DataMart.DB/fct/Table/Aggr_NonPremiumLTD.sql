﻿CREATE TABLE [fct].[Aggr_NonPremiumLTD] (
    [Id]                  INT              IDENTITY (1, 1) NOT NULL,
    [Entity]              VARCHAR (25)     NOT NULL,
    [Trifocus]            VARCHAR (25)     NOT NULL,
    [IFRS17 Trifocus]     VARCHAR (25)     NULL,
    [RI Prog]             VARCHAR (100)    NULL,
    [RI Flag]             VARCHAR (2)      NULL,
    [Loss Type]           VARCHAR (1)      NULL,
    [Type]                VARCHAR (1)      NULL,
    [CCYSettlement]       VARCHAR (10)      NOT NULL,
    [Dataset]             VARCHAR (255)    NULL,
    [Scenario]            VARCHAR (10)     NOT NULL,
    [Account]             VARCHAR (15)     NOT NULL,
    [AccountingPeriod]    INT              NOT NULL,
    [YOA]                 VARCHAR (10)     NOT NULL,
    [YOI]                 INT              NULL,
    [MOI]                 INT              NULL,
    [Value]               NUMERIC (38, 10) NULL,
    [EventDate]           DATETIME         NULL,
    [AuditCreateDateTime] DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]     NVARCHAR (510)   DEFAULT (suser_sname()) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 90)
);


GO
ALTER TABLE FCT.Aggr_NonPremiumLTD   ADD CONSTRAINT FK_Entity_AggrNE FOREIGN KEY(Entity)
REFERENCES  DIM.Entity (PK_Entity)
 
 GO
ALTER TABLE FCT.Aggr_NonPremiumLTD  ADD CONSTRAINT FK_Trifocus_AggrNT FOREIGN KEY(Trifocus)
REFERENCES  DIM.TriFocus (PK_TriFocus)

GO
ALTER TABLE FCT.Aggr_NonPremiumLTD  ADD CONSTRAINT FK_CCYSettlement_AggrNC FOREIGN KEY(CCYSettlement)
REFERENCES  DIM.CCY (PK_CCY)


GO
 ALTER TABLE FCT.Aggr_NonPremiumLTD   ADD CONSTRAINT FK_AccountingPeriod_AggrNA FOREIGN KEY(AccountingPeriod)
REFERENCES  DIM.AccountingPeriod (PK_AccountingPeriod)
 
 GO
 ALTER TABLE FCT.Aggr_NonPremiumLTD  ADD CONSTRAINT FK_Scenario_AggrNS FOREIGN KEY(Scenario)
REFERENCES  DIM.Scenario (PK_Scenario)

GO
ALTER TABLE FCT.Aggr_NonPremiumLTD ADD  CONSTRAINT FK_YOA_AggrNY FOREIGN KEY(YOA)
REFERENCES  DIM.YOA (PK_YOA)


GO
CREATE NONCLUSTERED INDEX [bzyidx_Aggr_NonPremiumLTD_1]
    ON [fct].[Aggr_NonPremiumLTD]([Dataset] ASC, [Account] ASC) WITH (FILLFACTOR = 90);

	Go
	CREATE NONCLUSTERED INDEX [IX_Aggr_NonPremiumLTD_AccountingPeriod] ON [fct].[Aggr_NonPremiumLTD]
(
[AccountingPeriod] ASC
)