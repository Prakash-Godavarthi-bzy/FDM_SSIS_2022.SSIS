﻿CREATE FUNCTION [fct].[udf_GetADMAccountsMaxAccPer] ( @AccPer INT)

RETURNS TABLE
AS
RETURN

WITH TAB AS
(
SELECT ROW_NUMBER() OVER (ORDER BY Account,Dataset,AccountingPeriod ) ROW_NUM, Account,Dataset,AccountingPeriod, ROUND(SUM(Value),2) SUM_VAL, DENSE_RANK() OVER(ORDER BY Account,Dataset) RANK_PARTITION
FROM fct.Aggr_NonPremiumLTD
WHERE 1 =1
AND CONVERT(DATE,CONVERT(VARCHAR(6),AccountingPeriod) +'01') > DATEADD(YEAR, -1, CONVERT(DATE,CONVERT(VARCHAR(6),@AccPer)+'01')) 
AND	(
		 Account IN ('RP-T-PR','RP-P-PR','GP-T-PR','GP-P-PR','GC-T-AC','GC-P-CM','GC-T-CM'
						,'RC-T-CM','RC-P-CM','RC-T-LL','GC-T-LL','RC-T-AC','GC-P-AC')
	OR	(Account='GC-P-LL' and dataset = 'ResDataEventAlloc') 
	OR	(Account = 'RC-P-AC' AND dataset = 'ResDataRIAttClmAlloc') 
	OR	(Account = 'RC-P-LL' AND dataset = 'ResDataRILargeLossAlloc')  )
GROUP BY Account,Dataset,AccountingPeriod
),
TAB2 AS
(
SELECT ROW_NUM,Account,Dataset, AccountingPeriod,SUM_VAL,RANK_PARTITION, SUM_VAL - LAG(SUM_VAL,1 , 0) OVER(PARTITION BY RANK_PARTITION ORDER BY ROW_NUM) Result
FROM TAB A
)

SELECT DISTINCT A.Account, Dataset, AccountingPeriod, SUM_VAL AS [LTD_Amount]
FROM TAB2 A
INNER JOIN ( SELECT RANK_PARTITION, MAX(ROW_NUM) MAX_ROW_NUM
		    FROM TAB2
			WHERE Result <> 0
			GROUP BY RANK_PARTITION
			)B ON A.ROW_NUM = B.MAX_ROW_NUM