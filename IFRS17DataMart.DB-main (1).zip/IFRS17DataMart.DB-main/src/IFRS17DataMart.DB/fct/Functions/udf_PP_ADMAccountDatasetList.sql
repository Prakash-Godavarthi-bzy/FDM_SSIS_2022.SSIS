﻿


CREATE FUNCTION [fct].[udf_PP_ADMAccountDatasetList] ( @AccPer INT)

RETURNS TABLE
AS
RETURN

WITH ACCDATASET AS
(
SELECT FK_Account,Fk_dataset, MaxTargetAP
FROM
(

	SELECT FK_Account, Fk_dataset,MAX(FK_AccountingPeriod)  MaxTargetAP
	FROM fct.PreProcessPremiumLTD 
	WHERE FK_AccountingPeriod <= @AccPer
	GROUP BY FK_Account, Fk_dataset
	UNION ALL
	SELECT Account, Dataset, AccountingPeriod FROM [fct].[udf_GetADMAccountsMaxAccPer] (@AccPer)
)A
WHERE 1 = 1
AND	 FK_Account IN ('RP-T-PR','RP-P-PR','GP-T-PR','GP-P-PR','GC-T-AC','GC-P-CM','GC-T-CM'
					,'RC-T-CM','RC-P-CM','RC-T-LL','GC-T-LL','RC-T-AC','GC-P-AC','GC-P-LL','RC-P-AC' ,'RC-P-LL')
)


	SELECT Account, DataSet 
	,ISNULL(T3.MaxTargetAP
			, CONVERT(INT,CONCAT( YEAR(DATEADD(MONTH, -1, CONVERT(DATE,CONVERT(VARCHAR(6),@AccPer)+'01')))
						, RIGHT(CONCAT('00',MONTH(DATEADD(MONTH, -1, CONVERT(DATE,CONVERT(VARCHAR(6),@AccPer)+'01')))),2)))) MaxTargetAP
	, (SELECT AccountingPeriod FROM Outbound.AccPer_AsAt_Control) CurrentAsAt
	FROM Dim.DatasetAccountMapping T2 
	INNER JOIN Dim.AccountCodeMapping  T1  ON T1.AccountCode = T2.Account
	LEFT JOIN ACCDATASET T3 ON T2.Account = T3.FK_Account AND T2.DataSet = T3.Fk_dataset
	WHERE 
	IsActive = 1
	AND	(	 Account IN ('RP-T-PR','RP-P-PR','GP-T-PR','GP-P-PR','GC-T-AC','GC-P-CM','GC-T-CM'
							,'RC-T-CM','RC-P-CM','RC-T-LL','GC-T-LL','RC-T-AC','GC-P-AC')
		OR	(Account='GC-P-LL' and dataset = 'ResDataEventAlloc') 
		OR	(Account = 'RC-P-AC' AND dataset = 'ResDataRIAttClmAlloc') 
		OR	(Account = 'RC-P-LL' AND dataset = 'ResDataRILargeLossAlloc')  )