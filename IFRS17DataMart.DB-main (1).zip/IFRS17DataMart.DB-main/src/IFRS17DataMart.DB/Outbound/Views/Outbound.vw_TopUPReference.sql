CREATE VIEW [Outbound].[vw_TopUPReference]
AS
 SELECT 
      [Entity]
      ,[TopUp]
  FROM [Dim].[TopUPReference]