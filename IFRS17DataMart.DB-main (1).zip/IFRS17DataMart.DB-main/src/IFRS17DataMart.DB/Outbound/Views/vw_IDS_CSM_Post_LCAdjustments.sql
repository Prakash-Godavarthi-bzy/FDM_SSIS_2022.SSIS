﻿

CREATE VIEW Outbound.vw_IDS_CSM_Post_LCAdjustments
AS
SELECT	C.[RunID],
		[Entity],
		[FocusGroup],
		[Tri focus Code],
		[IFRS17 Tri focus code],
		[Programme],
		[RI_Flag],
		[YOA],
		[YOI],
		[QOI_End_Date],
		[CCY],
		[Incepted Status],
		[Statement],
		[Balance],
		[Position],
		[Amount],
		[Amount_disc],
		[Conv_Amount],
		[Conv_Amount_disc],
		[UOA],
		[CSM_LC],
		[Portfolio]
FROM  [IDS].[CSM_Post_LCAdjustments] CPLC
INNER JOIN Outbound.IDS_RunID_Control C on CPLC.RunID =C.RunID