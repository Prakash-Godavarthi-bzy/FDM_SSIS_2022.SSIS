﻿CREATE VIEW [Outbound].[vw_PreProcessLTD_AsAt]

AS

WITH
MaxClaimsBasisAndMOP AS
(
	SELECT BK_PolicyNumber,CASE MAX(CASE WHEN T1.Claim_Basis = 'Unknown'
							THEN '-1'
							ELSE Claim_Basis
					END) WHEN '-1'
			 THEN 'Unknown'
			 ELSE MAX(CASE WHEN T1.Claim_Basis = 'Unknown'
							THEN '-1'
							ELSE Claim_Basis
					END)
		END Claim_Basis 
		,CASE MAX(CASE  WHEN T1.MOPCode IN  ('Unknown','NULL','NOMOP')  THEN '-1'
						ELSE MOPCode
					END) 
				WHEN '-1' THEN 'Unknown'
			    ELSE MAX(CASE  WHEN T1.MOPCode IN  ('Unknown','NULL','NOMOP')  THEN '-1'
						ELSE MOPCode
					END)
		END MOPCode 
		FROM FCT.PreProcessPremiumLTD T1 
		GROUP BY BK_PolicyNumber
),

OpenData As
(
SELECT T1.FK_Account, T1.FK_Basis, T1.FK_Entity, T1.BK_PolicyNumber, T1.InceptionDate, T1.ExpiryDate, T1.FK_Process, T1.FK_Trifocus, T1.FK_YOA
      , T1.CCYOriginal, T1.CCYSettlement, T1.Fk_dataset, T1.FK_scenario, T1.FK_inceptionyear,T1.InceptionPeriod, T1.PolicyType, T1.[TypeOfBusiness]
	  , T1.Claim_Basis
	  ,T1.RI_Policy_Type,T1.[RI Flag]
      ,CASE WHEN T1.[RI Flag] ='I' Then 'GROSS' Else T1.Programme end Programme,T1.FK_AccountingPeriod, T1.MOPCode
	  , SUM(T1.[Value]) [Value]

FROM FCT.PreProcessPremiumLTD T1
INNER JOIN Outbound.AccPer_AsAt_Control  T3 ON T1.FK_AccountingPeriod <= T3.AccountingPeriod
INNER JOIN DIM.AccountCodeMapping T4 ON T1.FK_Account = T4.AccountCode AND T4.ProcessFlow = 'PP' AND IsActive = 1
WHERE 1 = 1
AND T1.FK_scenario IN ('A','F','B')
AND NOT EXISTS	(SELECT A.FK_YOA, A.FK_Trifocus, A.Programme --,Open_Cls_Flag
					FROM DIM.OpenCloseYOA A
					INNER JOIN (SELECT FK_Trifocus, FK_YOA,Programme , MAX(FK_AccountingPeriod) MAX_AC
								FROM DIM.OpenCloseYOA
								WHERE 
								1 = 1
								AND FK_AccountingPeriod < T3.AccountingPeriod
								GROUP BY FK_Trifocus, FK_YOA, Programme
								) B ON A.FK_Trifocus = B.FK_Trifocus 
									AND A.FK_YOA = B.FK_YOA 
									AND A.Programme = B.Programme
									AND A.FK_AccountingPeriod = B.MAX_AC
					WHERE A.Open_Cls_Flag = 'Closed'
					AND T1.FK_Trifocus = A.FK_Trifocus
					AND T1.FK_YOA = A.FK_YOA
					AND T1.Programme = A.Programme)
GROUP BY T1.FK_Account, T1.FK_Basis, T1.FK_Entity, T1.BK_PolicyNumber, T1.InceptionDate, T1.ExpiryDate, T1.FK_Process, T1.FK_Trifocus, T1.FK_YOA
      , T1.CCYOriginal, T1.CCYSettlement, T1.Fk_dataset, T1.FK_scenario, T1.FK_inceptionyear,T1.InceptionPeriod, T1.PolicyType, T1.[TypeOfBusiness], T1.Claim_Basis
	  ,T1.RI_Policy_Type,T1.[RI Flag], CASE WHEN T1.[RI Flag] ='I' Then 'GROSS' Else T1.Programme end ,T1.FK_AccountingPeriod,T1.MOPCode
),
Premium AS
(
    SELECT T1.FK_Account 
     , T1.FK_Basis
     , T1.FK_Entity
     , T1.BK_PolicyNumber
     , T1.InceptionDate
     , T1.ExpiryDate
     , T1.FK_Process
     , T1.FK_Trifocus
     , T1.FK_YOA
     , T1.CCYOriginal
     , T1.CCYSettlement 
     , T1.Fk_dataset
     , T1.FK_scenario
     , T1.FK_inceptionyear
     , T1.InceptionPeriod
     , T1.PolicyType
     , T1.TypeOfBusiness
     , T1.Claim_Basis as [Claims Basis]
	 , T1.MOPCode
     , T1.RI_Policy_Type as [RI Type]
     , T1.Programme
     , T1.[RI Flag]
     , T1.FK_AccountingPeriod
     , T1.[Value]
     ,ROW_NUMBER() 
      OVER (PARTITION BY 
       T1.FK_Account, T1.FK_Basis, T1.FK_Entity, T1.BK_PolicyNumber, T1.InceptionDate, T1.ExpiryDate, T1.FK_Process, T1.FK_Trifocus, T1.FK_YOA  , T1.CCYOriginal, T1.CCYSettlement, 
	   T1.Fk_dataset, T1.FK_scenario, T1.FK_inceptionyear,T1.InceptionPeriod, T1.PolicyType, T1.[TypeOfBusiness],T1.Claim_Basis,T1.MOPCode	   
	   ,T1.RI_Policy_Type , T1.Programme ,T1.[RI Flag]
      ORDER BY T1.FK_AccountingPeriod DESC
         ) RowOrder
    FROM  OpenData  T1

)

, SelectedData AS
(
    (SELECT     [FK_Account] ,[FK_Basis],[FK_Entity] ,T1.[BK_PolicyNumber],[InceptionDate],[ExpiryDate],[FK_Process],[FK_Trifocus],[FK_YOA], [CCYOriginal],[CCYSettlement],
	[Fk_dataset],[FK_scenario],[FK_inceptionyear],InceptionPeriod ,	[PolicyType] ,T5.[Claim_Basis],T5.MOPCode 
	,[RI Type] ,Programme,[RI Flag],RowOrder,MAX([FK_AccountingPeriod]) FK_AccountingPeriod,SUM([Value]) AS [Value]
	FROM Premium T1
	LEFT JOIN MaxClaimsBasisAndMOP T5 ON T1.BK_PolicyNumber = T5.BK_PolicyNumber
    WHERE 
    1 = 1
    AND RowOrder =  1 
	AND [Fk_dataset] NOT IN ('BusinessPlan','BusinessPlanRI','ObligatedPremium_RISpend')
	GROUP BY [FK_Account] ,[FK_Basis],[FK_Entity] ,T1.[BK_PolicyNumber],[InceptionDate],[ExpiryDate],[FK_Process],[FK_Trifocus],[FK_YOA], [CCYOriginal],[CCYSettlement],
	[Fk_dataset],[FK_scenario],[FK_inceptionyear],InceptionPeriod ,	[PolicyType] ,T5.[Claim_Basis],T5.MOPCode 
	,[RI Type] ,Programme,[RI Flag],RowOrder)

	UNION ALL
	(
	SELECT [FK_Account] ,[FK_Basis],[FK_Entity] ,[BK_PolicyNumber],MAX([InceptionDate]) AS [InceptionDate],MAX([ExpiryDate]) AS [ExpiryDate],[FK_Process],[FK_Trifocus],[FK_YOA], [CCYOriginal],[CCYSettlement],
		[Fk_dataset],[FK_scenario],[FK_inceptionyear],InceptionPeriod ,	[PolicyType] ,[Claim_Basis],MOPCode 
		,[RI Type] ,Programme,[RI Flag],1 AS RowOrder, MAX(FK_AccountingPeriod)AS FK_AccountingPeriod,SUM([Value]) AS [Value]
	FROM
		(
			SELECT     [FK_Account] ,[FK_Basis],[FK_Entity] ,T1.[BK_PolicyNumber],[InceptionDate],[ExpiryDate],[FK_Process],[FK_Trifocus],[FK_YOA], [CCYOriginal],[CCYSettlement],
			[Fk_dataset],[FK_scenario],[FK_inceptionyear],InceptionPeriod ,	[PolicyType] ,T5.[Claim_Basis],T5.MOPCode 
			,[RI Type] ,Programme,[RI Flag],RowOrder,MAX([FK_AccountingPeriod]) FK_AccountingPeriod,SUM([Value]) AS [Value]
			FROM Premium T1
			LEFT JOIN MaxClaimsBasisAndMOP T5 ON T1.BK_PolicyNumber = T5.BK_PolicyNumber
			WHERE 
			1 = 1
			AND RowOrder =  1 
			AND [Fk_dataset] IN ('BusinessPlan','BusinessPlanRI','ObligatedPremium_RISpend')
			GROUP BY [FK_Account] ,[FK_Basis],[FK_Entity] ,T1.[BK_PolicyNumber],[InceptionDate],[ExpiryDate],[FK_Process],[FK_Trifocus],[FK_YOA], [CCYOriginal],[CCYSettlement],
			[Fk_dataset],[FK_scenario],[FK_inceptionyear],InceptionPeriod ,	[PolicyType] ,T5.[Claim_Basis],T5.MOPCode 
			,[RI Type] ,Programme,[RI Flag],RowOrder
		)A
	GROUP BY [FK_Account] ,[FK_Basis],[FK_Entity] ,[BK_PolicyNumber],[FK_Process],[FK_Trifocus],[FK_YOA], [CCYOriginal],[CCYSettlement],
			[Fk_dataset],[FK_scenario],[FK_inceptionyear],InceptionPeriod ,	[PolicyType] ,[Claim_Basis],MOPCode 
			,[RI Type] ,Programme,[RI Flag]
	)

)


SELECT 
     CONVERT(VARCHAR(255), lc.[FK_Account]) AS [FK_Account],
     CONVERT(VARCHAR(255), lc.[FK_Basis])    AS [FK_Basis],
     CONVERT(VARCHAR(255), lc.[BK_PolicyNumber]) AS [BK_PolicyNumber],
     CONVERT(VARCHAR(255), lc.[FK_Entity]) AS [FK_Entity],
     CONVERT(DATETIME, lc.[InceptionDate]) AS [InceptionDate],
     CONVERT(DATETIME, lc.[ExpiryDate]) AS [ExpiryDate],
     CONVERT(VARCHAR(255),lc.[FK_Process]) AS [FK_Process],
     CONVERT(VARCHAR(255),lc.[FK_Trifocus]) AS [FK_Trifocus],
     CONVERT(VARCHAR(255),lc.[FK_YOA]) AS [FK_YOA],
     CONVERT(VARCHAR(255),lc.[CCYOriginal]) AS [CCYOriginal],
     CONVERT(VARCHAR(255),lc.[CCYSettlement]) AS [CCYSettlement],
     CONVERT(VARCHAR(255),lc.[Fk_dataset]) AS [Fk_dataset],
     CONVERT(VARCHAR(255),lc.[FK_scenario]) AS [FK_scenario],
     CONVERT(FLOAT,lc.[FK_inceptionyear]) AS [FK_inceptionyear],
     CONVERT(VARCHAR(255),lc.[PolicyType]) AS [PolicyType],
     CONVERT(FLOAT,SUM(lc.[Value])) AS [Value] ,
     CONVERT(FLOAT,AsAt.AccountingPeriod) AS [FK_AccountingPeriod],
     CONVERT(VARCHAR(255),lc.InceptionPeriod) AS InceptionPeriod,
     CONVERT(VARCHAR(255), lc.Programme) AS Programme,
     CONVERT(VARCHAR(255), lc.[RI Flag]) AS [RI_FLAG],
     CONVERT(VARCHAR(255), lc.Claim_Basis) AS [Claims Basis],
     CONVERT(VARCHAR(255), lc.[RI Type]) AS [RI Type]
FROM SelectedData lc
CROSS APPLY (SELECT AccountingPeriod FROM Outbound.AccPer_AsAt_Control) AsAt
WHERE 
1 = 1
GROUP BY [FK_Account], [FK_Basis],LC.[BK_PolicyNumber],[FK_Entity],[InceptionDate],[ExpiryDate],[FK_Process],[FK_Trifocus],[FK_YOA], [CCYOriginal],[CCYSettlement],
	[Fk_dataset],[FK_scenario],[FK_inceptionyear],lc.[PolicyType],AsAt.AccountingPeriod,InceptionPeriod, Programme,[RI Flag],Claim_Basis,[RI Type]