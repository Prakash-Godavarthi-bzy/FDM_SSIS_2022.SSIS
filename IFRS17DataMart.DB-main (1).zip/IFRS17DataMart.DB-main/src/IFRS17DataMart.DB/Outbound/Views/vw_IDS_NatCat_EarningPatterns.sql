 CREATE VIEW [Outbound].[vw_IDS_NatCat_EarningPatterns]
AS
SELECT C.RunID,
		'E' AS Pat_type,
		'C' AS Loss_type,
		[Tri Focus Code] AS [Tri Focus],
		[YOA] AS YoA,
		convert(varchar, Qtr, 111) AS Qtr,
		cast(Perc as float) as Perc
		FROM IDS.NatCat_EarningPatterns NC
		INNER JOIN Outbound.IDS_RunID_Control C on NC.RunID =C.RunID