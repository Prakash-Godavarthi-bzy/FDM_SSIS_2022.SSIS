﻿



CREATE VIEW [Outbound].[vw_IDS_PaymentPattern]
AS


SELECT
	A.RunID
	,A.AssumptionDatasetName
	,A.AssumptionPercentageType
	,A.Loss_Type
	,A.[Tri Focus Code]
	,A.Qtr
	,A.Perc
	,A.YOA
	,A.RI_Flag
	,A.Programme
	,A.Pat_type
	,A.OBFlag

FROM
(
	SELECT Pk_RequestId as RunID
	,cast(D.AssumptionDatasetName as char(35)) as AssumptionDatasetName
	,cast(APT.AssumptionPercentageType as char(35)) as AssumptionPercentageType
	,Case when LossType='PPP' Then 'P' 
		  When LossType='PPC' Then 'A'
	 end as Loss_Type 
	,cast(Trifocus as varchar(25)) as [Tri Focus Code]
	,DevelopmentQuarter as Qtr
	,cast(PaymentPerc as float) as Perc
	,cast('9999' as int) as YOA
	,cast(RIFlag as Varchar(2))as RI_Flag
	,cast('GROSS' as varchar(100)) as Programme
	,'P' as Pat_type
	,ISNULL([OBFlag ],1) AS [OBFlag]
	FROM [IDS].[PaymentPattern] P
	INNER JOIN Outbound.IDS_RunID_Control C on p.Pk_RequestId =C.RunID
	LEFT JOIN Dim.AssumptionDatasets D on P.DatasetNameId = D.Pk_AssumptionDatasetNameId
	LEFT JOIN dim.AssumptionPercentageType APT on P.PercentageTypeID = APT.Pk_AssumptionPercentageTypeId

	UNION ALL

	SELECT T1.RunID 
	,ISNULL(cast(D.AssumptionDatasetName as char(35)),'NA') as AssumptionDatasetName
	,cast(APT.AssumptionPercentageType as char(35)) as AssumptionPercentageType
	,Case when LossType='PPP' Then 'P' 
		  When LossType='PPC' Then 'A'
	 end as Loss_Type 
	,cast(Trifocus as varchar(25)) as [Tri Focus Code]
	,DevelopmentQuarter as Qtr
	,cast(PaymentPerc as float) as Perc
	,cast('9999' as int) as YOA
	,cast(RIFlag as Varchar(2))as RI_Flag
	,cast('GROSS' as varchar(100)) as Programme
	,'P' as Pat_type
	,0 AS [OBFlag]
	FROM Outbound.IDS_RunID_Control T1
	INNER JOIN PWAPS.IFRS17CalcUI_RunLog T2 ON T1.RunID = T2.Pk_RequestId
	LEFT JOIN (	SELECT [Pk_RequestId]      ,[DatasetNameId]      ,[PercentageTypeId]      ,[LossType]      ,[Trifocus]      ,[DevelopmentQuarter]      ,[RIFlag]      ,[PaymentPerc]      ,[OBFlag ]
				FROM IDS.PaymentPattern
				UNION ALL
				SELECT 1, 0 , 13, 'PPP','NOTRIFOC', 1, 'I',0,0) T3 ON T2.[Opening Balances Id] = T3.Pk_RequestId
	LEFT JOIN Dim.AssumptionDatasets D on T3.DatasetNameId = D.Pk_AssumptionDatasetNameId
	LEFT JOIN dim.AssumptionPercentageType APT on T3.PercentageTypeID = APT.Pk_AssumptionPercentageTypeId
)A
Go

