﻿
CREATE VIEW [Outbound].[vw_IDS_UndiscCSMWalkBalancesOB]
AS
SELECT C.RunID					
      ,Entity					
      ,[Tri focus code]		
      ,[IFRS17 Tri focus code] 
      ,Programme				
      ,RI_Flag					
      ,YOA						
      ,YOI						
      ,QOI_End_Date			
      ,LTRIM(RTRIM(CCY)) AS CCY						
      ,InceptedStatus			
      ,[Open/Closed]			
      ,[Statement]				
      ,Position				
      ,Balance					
      ,CAST(Amount AS float) AS Amount	
	  ,CAST(Amount_disc AS float) AS Amount_disc
  FROM [IDS].[UndiscCSMWalkBalancesOB] U
  INNER JOIN Outbound.IDS_RunID_Control C on U.RunID =C.RunID