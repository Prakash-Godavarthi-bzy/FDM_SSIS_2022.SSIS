﻿CREATE VIEW [Outbound].[vw_FSC_EarnPrem_Prior]
	AS 
	SELECT	 CAST([Accounting_Period] AS FLOAT)			AS [FK_AccountingPeriod]
			,CAST([Earn_qtr_prd]	  AS FLOAT)			AS [Earn_qtr_prd]     
			,CAST([FK_Entity]		  AS VARCHAR(255))	AS [FK_Entity]
			,CAST([Programme]		  AS VARCHAR(255))	AS [Programme]    
			,CAST([RI_Flag]			  AS VARCHAR(255))	AS [RI_Flag]   
			,CAST([FK_Trifocus]		  AS VARCHAR(255))	AS [FK_Trifocus]     
			,CAST([FK_YOA]			  AS FLOAT)			AS [FK_YOA]
			,CAST([Account]			  AS VARCHAR(255))	AS [FK_Account]
			,CAST([CCYOriginal]		  AS VARCHAR(255))	AS [CCYOriginal]   
			,CAST([CCYSettlement]	  AS VARCHAR(255))	AS [CCYSettlement]    
			,CAST([BK_PolicyNumber]	  AS VARCHAR(255))	AS [BK_PolicyNumber]  
			,CAST([InceptionDate]	  AS DATETIME)		AS [InceptionDate]
			,CAST([ExpiryDate]		  AS DATETIME)		AS [ExpiryDate]
			,CAST([Value]			  AS FLOAT)			AS [Value]
			,CAST([Unearned_Perc]	  AS FLOAT)			AS [Unearned_Perc]
	FROM
		(
		SELECT [Accounting_Period]      ,[Earn_qtr_prd]      ,[FK_Entity]      ,[Programme]      ,[RI_Flag]      ,[FK_Trifocus]      ,[FK_YOA]      ,[Account]      
			  ,[CCYOriginal]      ,[CCYSettlement]      ,[BK_PolicyNumber]      ,[InceptionDate]      ,[ExpiryDate]      ,[Value]      ,[Unearned_Perc]
		FROM        fct.FSC_EarnPrem_Prior
		UNION ALL
		SELECT 201905 AS [Accounting_Period]      ,202103 AS [Earn_qtr_prd]      ,'2623' AS [FK_Entity]      ,'GROSS' AS [Programme]      ,'I' AS [RI_Flag]      ,'703' AS [FK_Trifocus]      ,2016 AS [FK_YOA]      ,'P-GP-P' AS [Account]      
				,'USD' AS [CCYOriginal]      ,'USD' AS [CCYSettlement]   ,'TEST1' AS [BK_PolicyNumber]     ,'2016-05-26' AS [InceptionDate]      ,'2026-05-26' AS [ExpiryDate]      ,85151.26 AS [Value]      ,0.515192992 AS [Unearned_Perc]

		)A
	WHERE (Accounting_Period > CONVERT(INT,CAST((SELECT LEFT(AccountingPeriod,4) FROM Outbound.AccPer_AsAt_Control)-1 AS char(4))+'10')
			AND Accounting_Period <= (SELECT AccountingPeriod FROM Outbound.AccPer_AsAt_Control))