﻿

CREATE VIEW  [Outbound].[vw_IDS_PreStatementBalancesOB]
AS
SELECT C.RunID                    
      ,Entity                   
      ,[Tri focus code]         
      ,[IFRS17 Tri focus code]  
      ,Account                  
      ,CASE WHEN Programme='Gross' THEN UPPER(Programme) ELSE Programme END Programme            
      ,RI_Flag                  
      ,YOA                      
      ,YOI                      
      ,QOI_End_Date             
      ,RecognitionType          
      ,LTRIM(RTRIM(CCY)) AS CCY                      
      ,[Incepted Status]          
      ,[Open / Closed]            
      ,cast(Amount as float) as Amount
  FROM [IDS].[PreStatementBalancesOB] P
  INNER JOIN Outbound.IDS_RunID_Control C on P.RunID =C.RunID