﻿

CREATE VIEW [Outbound].[vw_IDS_RIPercentage]
AS
SELECT R.[AccountingPeriod]
      ,[TrifocusCode]
      ,[TrifocusName]
      ,[Entity]
      ,[YOA]
      ,[YOI]
      ,[RIProgramme]
      ,[RIType]
      ,[SettlementCCY]
      ,[RIPolicyNumber]
      ,[InceptionDate]
      ,[ExpiryDate]
      ,[ClaimsBasis]
      ,CAST([RIPremium] AS float) AS [RIPremium]
      ,CAST([GrossNetUltimates] AS float) AS [GrossNetUltimates]
      ,CAST([RI%] AS float) AS [RI%]
      ,[Businesskey]
FROM [fct].[RIPercentage] R 
INNER JOIN [Outbound].[vw_ICE_RunInformation] A On R.AccountingPeriod=A.[Reporting Period]