﻿
CREATE VIEW  [Outbound].[vw_IDS_Release_Calcs_FSC]
AS
SELECT C.RunID                     				
      ,Entity					
      ,[Tri focus code]		
      ,[IFRS17 TrifocusCode] 
      ,Account					
      ,Programme				
      ,RI_Flag					
      ,YOA						
      ,YOI						
      ,[QOI_End_Date]			
      ,RecognitionType			
      ,LTRIM(RTRIM(CCY)) AS CCY						
      ,[Incepted Status]		
      ,[Open / Closed]	
	  ,cast([Closing balances of release remaining Att] as float) as [Closing balances of release remaining Att]
	  ,cast([Closing balances of release remaining Cat] as float) as [Closing balances of release remaining Cat]
  FROM IDS.[Release_Calcs_FSC] P
  INNER JOIN Outbound.IDS_RunID_Control C on P.RunID =C.RunID

GO