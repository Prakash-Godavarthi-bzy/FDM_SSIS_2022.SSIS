﻿




CREATE VIEW [Outbound].[vw_IDS_AssumptionPercentages]
AS

SELECT
	Pk_RequestId as RunID
	--,Entity /* I17-5125 PK 06062023 Commented this and added below code for enity for assumption type IELR pure */
    ,CASE WHEN AT.AssumptionPercentageType = 'IELR (Pure)'
        THEN  CASE WHEN [Entity] = '8022' THEN '8022' ELSE '' END
        ELSE [Entity]
    END [Entity]
	,CASE WHEN AT.AssumptionPercentageType IN
			('Expenses (Admin Other)'
			,'Expenses (Claims Handling)'
			,'Expenses (Other Acquisition)'
			,'LIC Risk Adjustment'
			,'LIC Risk Adjustment (Older Years)'
			,'LRC Risk Adjustment'
			,'RI Admin')
		THEN [Focus Group]
		ELSE cast (PK_TriFocus_4 AS VARCHAR(10))
	  END AS [Tri Focus Code]
--,CAST(PK_YOA_3 AS VARCHAR(10)) AS YOA
	,CASE WHEN PK_YOA_3 IS NULL 
		  THEN '9999' 
		  ELSE CASE WHEN Quarters = 'Q5' THEN CAST((CAST(PK_YOA_3 AS INT) + 1) AS VARCHAR(10)) ELSE CAST(PK_YOA_3 AS VARCHAR(10)) END
	  END  AS YOA
	,Case when at.AssumptionPercentageType in ('LRC Risk Adjustment','LIC Risk Adjustment')
		  then	Case when RIFlag='G' then 'GROSS' Else Null End
		  Else RIProgramme
	 End Programme
	,CASE WHEN RIFlag='G' THEN 'I' WHEN RIFlag= 'R' THEN 'O' WHEN RIFlag is NULL THEN 'U' ELSE RIFlag END as RI_Flag
	,cast(Case AT.AssumptionPercentageType
			When 'Expenses (Admin Other)' Then 'ADE_PREM_EXP'
			When 'Ultimate Loss Ratios' Then 'n/a'
			When 'IELR (Pure)' Then 'PURE_IELR'
			When 'ENIDs (Earned)' Then 'ENID'
			When 'ENIDs (Unearned)' Then 'ENID'
			When 'Expenses (Claims Handling)' Then 'CHE_EXP'
			When 'Expenses (Other Acquisition)' Then 'OAE_EXP'
			When 'Reinstatement Premiums' Then 'RIPS_EXP'
			When 'Reinsurance Credit Loss' Then 'RI CL'
			When 'Profit Commissions' Then 'PC_EXP'
			When 'Rebates' Then 'REBATES'
			When 'RI Admin' Then 'RI_EXP'
			When 'Premium Lapse Risk' Then 'PREM_LAPSE_RSK'
			When 'LRC Risk Adjustment' Then 'LRC_RSK_ADJ'
			When 'LIC Risk Adjustment' Then 'LIC_RSK_ADJ'
			When 'LIC Risk Adjustment (Older Years)' Then 'LICOLD_RSK_ADJ'
			Else 'Unknown'
	 end as varchar(20))as Assumption
	,cast(
		Case LossType
			When 'Att' Then 'A'
			When 'Cat' Then 'C'
			Else LossType
		End as varchar(10)) as Loss_Type
	,CASE WHEN Quarters = 'Q5' THEN 'Q1' ELSE Quarters END as Qtr
	,Cast(GeneralPercent_0 as Float) as Perc

from [IDS].[AssumptionPercentages] A
INNER JOIN Dim.AssumptionPercentageType AT on A.PercentageTypeId=AT.Pk_AssumptionPercentageTypeId
INNER JOIN Outbound.IDS_RunID_Control C on A.Pk_RequestId =C.RunID
Where AT.AssumptionPercentageType <> 'Ultimate Loss Ratios'
GO


