﻿


CREATE VIEW [Outbound].[vw_IDS_Aggr_PremiumBrokeragewithopenclosed]
AS

SELECT 
t1.RunID
,t1.Entity
,t1.[Tri focus code]
,t1.[IFRS17 Trifocus] as [IFRS17 Tri Focus Code]
,t1.Account
,t1.Premtype as Prem_type
,CASE WHEN t1.Programme IS NULL OR t1.Programme = '' THEN  'Unknown' ELSE t1.Programme END AS Programme
,t1.RI_Flag 
,t1.YOA
,t1.YOI
,t1.QOI_End_Date
,t1.RecognitionType
,LTRIM(RTRIM (t1.CCY)) as CCY
,t2.[Open/Closed Derivation]
,CAST(t1.Amount as float) as Amount
FROM [IDS].[Aggr_PremiumBrokerage]   as t1
LEFT JOIN [IFRS17PsicleData].[Results].[openClosedOB] t2 on t1.RunID = t2.RunId and 
t2.YOA = t1.YOA and 
t2.[Tri Focus Code] = t1.[Tri focus code] and 
t2.Programme = t1.Programme
INNER JOIN Outbound.IDS_RunID_Control C
on t1.RunID =C.RunID