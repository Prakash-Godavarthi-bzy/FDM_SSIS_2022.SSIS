﻿


CREATE VIEW  [Outbound].[vw_IDS_AttEarningOB]
AS
SELECT AE.[RunId]
      ,[Pat_Type]
      ,[Tri focus code]
      ,[Programme]
      ,[YOI]
      ,[QOI]
      ,[CCY]
      ,[Qtr]
      ,[Perc]    
  FROM [IDS].[AttEarningOB] AE
    INNER JOIN Outbound.IDS_RunID_Control C on AE.RunID =C.RunID