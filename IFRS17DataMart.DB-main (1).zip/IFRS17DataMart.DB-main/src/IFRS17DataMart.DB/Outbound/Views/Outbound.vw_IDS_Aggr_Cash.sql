﻿





CREATE VIEW [Outbound].[vw_IDS_Aggr_Cash]
AS

SELECT A. RunID
,Entity
,[Tri focus code]
,[IFRS17 TrifocusCode]
,Account
--,[dbo].[CamelCase](Programme) AS Programme
,CASE WHEN Programme='Gross' THEN UPPER(Programme) ELSE Programme END Programme
,CASE  WHEN cast(RI_Flag as varchar(2) ) = 'G' THEN 'I' WHEN cast(RI_Flag as varchar(2) ) = 'R' THEN 'O' WHEN cast(RI_Flag as varchar(2) ) IS NULL THEN 'U' ELSE cast(RI_Flag as varchar(2) ) END RI_Flag
,YOA
,LTRIM(RTRIM(CCY)) as CCY
,sum(cast(Amount as float)) as Amount
from [IDS].[Aggr_CashExcludingClaims]A 
INNER JOIN Outbound.IDS_RunID_Control C on A.RunID =C.RunID
group by A.RunID,Entity,[Tri focus code],[IFRS17 TrifocusCode],Account,Programme,cast(RI_Flag as varchar(2) ),YOA,CCY

Go

