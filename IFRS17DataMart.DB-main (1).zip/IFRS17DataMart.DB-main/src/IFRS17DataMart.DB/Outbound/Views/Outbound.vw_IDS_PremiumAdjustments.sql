﻿
CREATE VIEW  [Outbound].[vw_IDS_PremiumAdjustments]
AS
SELECT C.RunID                     				
      ,Entity					
      ,[Tri focus code]		
      ,[IFRS17 TrifocusCode] 
      ,Account					
      ,Programme				
      ,RI_Flag					
      ,YOA						
      ,YOI						
      ,[QOI_End_Date]			
      ,RecognitionType			
      ,LTRIM(RTRIM(CCY)) AS CCY						
      ,[Incepted Status]		
      ,[Open / Closed]	
	  ,cast(Amount as float) as Amount
  FROM [IDS].PremiumAdjustments P
  INNER JOIN Outbound.IDS_RunID_Control C on P.RunID =C.RunID
GO