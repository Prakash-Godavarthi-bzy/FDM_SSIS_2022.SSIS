﻿
CREATE View  [Outbound].[vw_IDS_CSMReleaseBalancesOB]
As
SELECT 
       CR.[RunID]
      ,[Entity]
      ,[Tri focus code]
      ,[IFRS17 Tri Focus Code]
      ,[Account]
      ,[Programme]
      ,[RI_Flag]
      ,[YoI]
      ,[RecognitionType]
      ,LTRIM(RTRIM(CCY)) as [CCY]
      ,[Open_Closed]
      ,[Quarter]
      ,cast([Value] as float) as [Value]
  FROM [IDS].[CSMReleaseBalancesOB] CR
    INNER JOIN Outbound.IDS_RunID_Control C on CR.RunID =C.RunID