﻿
--USE [IFRS17DataMart]
--GO

--/****** Object:  View [Outbound].[vw_IDS_Aggr_PaidAndIncurred]    Script Date: 05/05/2022 13:00:55 ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO




CREATE View [Outbound].[vw_IDS_Aggr_PaidAndIncurred]
AS


select  A.RunID,Entity,[Tri focus code],Account,Programme,cast(RI_Flag as varchar(2) ) RI_Flag,Loss_Type,YOA,YOI,LTRIM(RTRIM(CCY)) as CCY,cast(Amount as float) as Amount



from [IDS].[Aggr_Claims]A 
INNER JOIN Outbound.IDS_RunID_Control C
on A.RunID =C.RunID

Go

