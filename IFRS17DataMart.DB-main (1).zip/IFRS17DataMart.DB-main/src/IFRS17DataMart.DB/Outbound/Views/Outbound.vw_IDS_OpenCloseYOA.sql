


Create View Outbound.vw_IDS_OpenCloseYOA
AS


select p.RunId,cast(Programme as varchar(100)) as Programme,TrifocusCode as [Tri Focus Code],YOA,[Open/Closed]
from [IDS].[Open_CloseYOA]p
INNER JOIN Outbound.IDS_RunID_Control C
on p.RunID =C.RunID
Go

