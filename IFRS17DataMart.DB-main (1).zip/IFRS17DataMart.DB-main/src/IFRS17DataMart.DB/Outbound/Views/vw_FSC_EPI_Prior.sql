﻿CREATE VIEW [Outbound].[vw_FSC_EPI_Prior]
AS 
		SELECT  
			  CAST(FK_AccountingPeriod	AS FLOAT)			AS FK_AccountingPeriod
			, CAST(FK_Entity			AS VARCHAR(255))	AS FK_Entity
			, CAST(Programme			AS VARCHAR(255))	AS Programme
			, CAST(RI_Flag				AS VARCHAR(255))	AS RI_Flag
			, CAST(FK_Trifocus			AS VARCHAR(255))	AS FK_Trifocus
			, CAST(FK_YOA				AS FLOAT)			AS FK_YOA
			, CAST(FK_Account			AS VARCHAR(255))	AS FK_Account
			, CAST(CCYOriginal			AS VARCHAR(255))	AS CCYOriginal
			, CAST(CCYSettlement		AS VARCHAR(255))	AS CCYSettlement
			, CAST(BK_PolicyNumber		AS VARCHAR(255))	AS BK_PolicyNumber
			, CAST(InceptionDate		AS DATETIME)		AS [InceptionDate]
			, CAST(ExpiryDate			AS DATETIME)		AS [ExpiryDate]
			, CAST([Value]				AS FLOAT)			AS [Value]
		FROM
			(
				SELECT    FK_AccountingPeriod	, FK_Entity 			, Programme 			, RI_Flag			, FK_Trifocus			, FK_YOA			, FK_Account			, CCYOriginal
						, CCYSettlement			, BK_PolicyNumber		, InceptionDate			, ExpiryDate		, [Value]
				FROM        fct.FSC_EPI
				UNION ALL 
				SELECT 	201903 AS FK_AccountingPeriod	, '2623' AS FK_Entity 	,'GROSS' AS Programme 	, 'I' AS RI_Flag	,'718' AS FK_Trifocus	, 2018 AS FK_YOA	,'P-BP-B' AS FK_Account	 ,'EUR' AS  CCYOriginal
						, 'EUR' AS CCYSettlement	,'B7323K18PNTZ_3062018_test' AS BK_PolicyNumber		, '2018-01-01' AS InceptionDate		, '2018-12-31' AS ExpiryDate	,100 AS [Value]

			)A
		WHERE (FK_AccountingPeriod > CONVERT(INT,CAST((SELECT LEFT(AccountingPeriod,4) FROM Outbound.AccPer_AsAt_Control)-1 AS char(4))+'10')
		AND FK_AccountingPeriod <= (SELECT AccountingPeriod FROM Outbound.AccPer_AsAt_Control))