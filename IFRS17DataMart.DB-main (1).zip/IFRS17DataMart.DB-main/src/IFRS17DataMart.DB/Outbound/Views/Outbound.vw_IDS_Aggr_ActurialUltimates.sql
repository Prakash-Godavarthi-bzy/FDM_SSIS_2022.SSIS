﻿





CREATE View [Outbound].[vw_IDS_Aggr_ActurialUltimates]
AS

select A.RunID,Entity,[Tri focus code],Account,[Type],Programme,cast(RI_Flag as varchar(2) ) RI_Flag,Loss_Type,EventDate as [Event Date] ,YOA,LTRIM(RTRIM(CCY)) as CCY,sum(cast(Amount as float)) as Amount


from [IDS].[Aggr_ActurialUltimates]A 
INNER JOIN Outbound.IDS_RunID_Control C ON A.RunID =C.RunID
group by A.RunID,Entity,[Tri focus code],Account,[Type],Programme,cast(RI_Flag as varchar(2) ),Loss_Type,EventDate ,YOA,CCY

Go

