﻿
CREATE VIEW [Outbound].[vw_IDS_PresStatementPatternsOB]
AS
SELECT C.RunID                  
      ,Entity                 
      ,[Tri focus code]       
      ,[IFRS17 Tri focus code]
      ,Account                
      ,Programme              
      ,RI_Flag                
      ,YOI                    
      ,LTRIM(RTRIM(CCY)) AS CCY                    
      ,Qtr                    
      ,cast(Perc as float) as Perc                   
  FROM [IDS].[PresStatementPatternsOB] PS
  INNER JOIN Outbound.IDS_RunID_Control C on PS.RunID =C.RunID