﻿CREATE VIEW [Outbound].[vw_IDS_Cashflow_Discount]
AS
SELECT [ID], [Flag], [Section], [Parameter], [Value] FROM IDS.Cashflow_Discount