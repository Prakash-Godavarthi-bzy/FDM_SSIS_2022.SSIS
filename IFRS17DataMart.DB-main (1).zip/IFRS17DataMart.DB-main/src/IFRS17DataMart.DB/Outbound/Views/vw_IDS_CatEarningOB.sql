﻿


CREATE VIEW [Outbound].[vw_IDS_CatEarningOB]
AS
SELECT CE.RunID                  
       ,[Tri focus code]
      ,[YOA]
      ,[Open/Closed Derivation]
      ,[CCY]
      ,[QOI_End_Date]
      ,[Qtr]
      ,[YOI]
      ,[Account]
      ,[Amount_Cum]
  FROM [IDS].[CatEarningOB] CE
  INNER JOIN Outbound.IDS_RunID_Control C on CE.RunID =C.RunID