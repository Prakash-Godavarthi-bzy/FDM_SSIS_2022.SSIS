﻿



CREATE VIEW [Outbound].[vw_IDS_FXRate]
AS
SELECT Pk_RequestId as RunID
,cast(D.AssumptionDatasetName as char(35)) as AssumptionDatasetName
,cast(AT.AssumptionPercentageType as char(35)) as AssumptionPercentageType
,LossType as FXRateType
,ISNULL([OBFlag ],1) AS [OBFlag]
,LTRIM(RTRIM(cast(ReportingCurrency as varchar(10)))) as RepCCY
,LTRIM(RTRIM(cast(TransactionCurrency as varchar(10)))) as CCY
,cast(FXRate_0 as float) as FXRate
FROM [IDS].[FXRate] P
LEFT JOIN Dim.AssumptionDatasets D on P.DatasetNameId=D.Pk_AssumptionDatasetNameId
LEFT JOIN dim.AssumptionPercentageType AT on P.PercentageTypeID=AT.Pk_AssumptionPercentageTypeId
INNER JOIN Outbound.IDS_RunID_Control C on p.Pk_RequestId =C.RunID


Go

