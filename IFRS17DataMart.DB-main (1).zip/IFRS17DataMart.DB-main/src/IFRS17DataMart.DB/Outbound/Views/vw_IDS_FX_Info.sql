﻿CREATE VIEW [Outbound].[vw_IDS_FX_Info]
AS
SELECT [ID], [Statement], [Position], [fx_rate_type], [OpenCls] FROM IDS.FX_Info