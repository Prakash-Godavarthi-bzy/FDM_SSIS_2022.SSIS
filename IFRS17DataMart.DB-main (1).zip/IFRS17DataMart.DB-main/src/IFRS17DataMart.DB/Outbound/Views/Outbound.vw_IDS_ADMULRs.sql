﻿CREATE View [Outbound].[vw_IDS_ADMULRs]
AS

select Pk_RequestId as RunID
,Entity
, cast(PK_TriFocus_4 as varchar(25)) as [Tri Focus Code]
,Case When cast(Quarters as char(1))='AD' Then 'T' ELSE 'P' end as [Type]
,[RIProgramme] as Programme
--,CASE RIFlag  WHEN  'G' THEN 'I' WHEN 'R' THEN 'O' ELSE RIFlag END as RI_Flag
,CASE WHEN RIFlag='G' THEN 'I' WHEN RIFlag= 'R' THEN 'O' WHEN RIFlag is NULL THEN 'U' ELSE RIFlag END as RI_Flag
,cast(LossType as varchar(10)) as Loss_Type
,cast(PK_YOA_3 as int) as YOA
,cast(GeneralPercent_0 as float) as Perc
from [IDS].[AssumptionPercentages] A
INNER JOIN Dim.AssumptionPercentageType AT on A.PercentageTypeId=AT.Pk_AssumptionPercentageTypeId
INNER JOIN Outbound.IDS_RunID_Control C
on A.Pk_RequestId =C.RunID
Where AT.AssumptionPercentageType='Ultimate Loss Ratios'

Go

