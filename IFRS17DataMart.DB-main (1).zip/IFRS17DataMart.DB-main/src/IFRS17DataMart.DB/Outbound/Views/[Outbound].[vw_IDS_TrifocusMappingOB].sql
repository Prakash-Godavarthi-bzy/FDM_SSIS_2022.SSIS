



CREATE VIEW [Outbound].[vw_IDS_TrifocusMappingOB] 

AS

SELECT T1.RunID,T3.[Trifocus Code], T3.[Trifocus Name], T3.Division, T3.[Focus Group]
FROM Outbound.IDS_RunID_Control T1
INNER JOIN PWAPS.IFRS17CalcUI_RunLog T2 ON T1.RunID = T2.Pk_RequestId
INNER JOIN IDS.TrifocusMapping T3 ON T2.[Opening Balances Id] = T3.RunID



