﻿CREATE VIEW [Outbound].[vw_IDS_BalHeader]
AS
SELECT [ID], [DataSet], [Discountable], [Position], [Short_Balance], [Balance], [Statement], [Gross_RI], [Short_Name], [Long_Name], [Signage], [trans_type], [PmtPat_type], [Aggregation], [DiscRunning_total_or_Position_or_Both], [Open_Open], [Open_Cls], [Open_OLock], [Cls_Open], [Cls_OLock], [Cls_Cls], [Cls_CLock], [Disc_Bal_For_Disc_Calcs], [Disc_Bal_For_Disc_Walk], [ObjectName], [StatementOrder], [PositionOrder], [BalanceOrder]
FROM IDS.BalHeader