﻿
CREATE VIEW  [Outbound].[vw_IDS_HistPremLockRatesOB]
AS
SELECT 
       HP.RunID        
      ,QOI_End_Date 
      ,Programme    
      ,FocusGroup   
      ,LTRIM(RTRIM(CCY)) AS CCY          
      ,cast([Amount] as float) as  [Amount]    
  FROM [IDS].[HistPremLockRatesOB] HP
	  INNER JOIN Outbound.IDS_RunID_Control C on HP.RunID =C.RunID