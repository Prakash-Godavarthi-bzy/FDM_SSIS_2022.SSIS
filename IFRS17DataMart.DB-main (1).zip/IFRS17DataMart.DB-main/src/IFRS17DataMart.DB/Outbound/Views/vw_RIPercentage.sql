﻿
/****** Script for SelectTopNRows command from SSMS  ******/


CREATE VIEW [Outbound].[vw_RIPercentage]
AS
SELECT 
 [AsAt] AS [AccountingPeriod]
	  ,[TrifocusCode]
      ,[TrifocusName]
      ,[Entity]
      ,[YOA]
      ,[YOI]
      ,[RIProgramme]
      ,[RIType]
      ,[SettlementCCY]
      ,[RIPolicyNumber]
      ,[InceptionDate]
      ,[ExpiryDate]
      ,[ClaimsBasis]
      ,[RIPremium]
      ,[GrossNetUltimates]
      ,[RI%]
      ,[Businesskey]

FROM 
(
SELECT 
	   R.[AccountingPeriod]
      ,R.[TrifocusCode]
      ,R.[TrifocusName]
      ,R.[Entity]
      ,R.[YOA]
      ,R.[YOI]
      ,R.[RIProgramme]
	  ,R.[RIType]
      ,R.[SettlementCCY]
      ,R.[RIPolicyNumber]
      ,R.[InceptionDate]
      ,R.[ExpiryDate]
      ,R.[ClaimsBasis]
      ,R.[RIPremium]
      ,R.[GrossNetUltimates]
      ,R.[RI%]
	  ,R.[Businesskey]
	  ,CONCAT(DATEPART(YEAR, DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(A.AccountingPeriod AS varchar), '01')))+1 ,0)))
			,RIGHT(CONCAT('00',DATEPART(MONTH, DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(A.AccountingPeriod AS varchar), '01')))+1 ,0)))),2)
			) AsAt
	  ,ROW_NUMBER() OVER(PARTITION BY [TrifocusCode]      ,[TrifocusName]      ,[Entity]      ,[YOA]      ,[YOI]      ,[RIProgramme],[RIType]
      ,[SettlementCCY]      ,[RIPolicyNumber]      ,[InceptionDate]      ,[ExpiryDate]      ,[ClaimsBasis] ORDER BY R.[AccountingPeriod] DESC) RowOrder
FROM [fct].[RIPercentage] R
INNER JOIN [Outbound].[AccPer_AsAt_Control] A On R.AccountingPeriod <=
											    CONCAT(DATEPART(YEAR, DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(A.AccountingPeriod AS varchar), '01')))+1 ,0)))
													   ,RIGHT(CONCAT('00',DATEPART(MONTH, DATEADD(DD, -1, DATEADD(QQ, DATEDIFF(QQ, 0, CONVERT(DATE, CONCAT(CAST(A.AccountingPeriod AS varchar), '01')))+1 ,0)))),2)
												       )
)C
WHERE C.RowOrder = 1