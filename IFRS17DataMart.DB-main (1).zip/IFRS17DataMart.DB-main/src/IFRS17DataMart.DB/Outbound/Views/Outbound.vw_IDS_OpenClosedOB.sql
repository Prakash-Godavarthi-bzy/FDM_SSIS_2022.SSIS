﻿CREATE VIEW  Outbound.vw_IDS_OpenClosedOB
AS
SELECT C.[RunID]                           
      ,Programme               
      ,[Tri focus code]        
      ,YOA                     
      ,[Open/Closed Derivation]
  FROM [IDS].[OpenClosedOB] OC
  INNER JOIN Outbound.IDS_RunID_Control C on OC.RunID =C.RunID