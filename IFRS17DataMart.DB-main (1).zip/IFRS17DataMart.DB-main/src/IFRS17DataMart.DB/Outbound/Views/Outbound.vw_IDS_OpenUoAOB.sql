CREATE VIEW  Outbound.vw_IDS_OpenUoAOB
AS
SELECT C.RunID            
      ,TFYOI            
      ,Entity           
      ,FocusGroup       
      ,UOA              
      ,YOI              
      ,Programme        
      ,[Tri focus code] 
      ,[Tri focus]      
      ,TFUOA            
      ,Onerosity        
      ,[CSM_LC]         
  FROM [IDS].[OpenUoAOB] OU
  INNER JOIN Outbound.IDS_RunID_Control C on OU.RunID =C.RunID