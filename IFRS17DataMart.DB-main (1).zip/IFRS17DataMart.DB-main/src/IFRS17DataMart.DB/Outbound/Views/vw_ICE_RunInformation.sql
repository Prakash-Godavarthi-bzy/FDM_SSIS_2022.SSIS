﻿CREATE VIEW [Outbound].[vw_ICE_RunInformation]
as
select Pk_RequestId as [Run ID]
,Cast ([Reporting Period] as int) as [Reporting Period]
,Cast(EOMONTh(cast(left([Reporting Period],4)+'-'+right([Reporting Period],2)+'-01' as datetime))as datetime) as [Reporting Date]
,Cast('USD' as Varchar(3)) as [Reporting Currency]
,cast([BBNI] as float) as [BBNI %]
,Cast(EOMONTh(cast(left([OB Reporting Period],4)+'-'+right([OB Reporting Period],2)+'-01' as datetime))as datetime) as [OB Reporting Date],
cr.YTDQTD
from PWAPS.IFRS17CalcUI_RunLog cr 
inner join  Outbound.IDS_RunID_Control rc on cr.Pk_RequestId=rc.RunID