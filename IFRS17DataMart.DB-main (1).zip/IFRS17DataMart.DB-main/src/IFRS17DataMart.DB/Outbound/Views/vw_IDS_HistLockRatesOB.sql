﻿
CREATE VIEW  [Outbound].[vw_IDS_HistLockRatesOB]
AS
SELECT HL.[RunId]
      ,YOI
      ,[Programme]
      ,[FocusGroup]
      ,LTRIM(RTRIM([CCY])) AS CCY
      ,[Qtr]
      ,cast([Rate] as float) as [Rate]
  FROM [IDS].[HistLockRatesOB] HL
    INNER JOIN Outbound.IDS_RunID_Control C on HL.RunID =C.RunID