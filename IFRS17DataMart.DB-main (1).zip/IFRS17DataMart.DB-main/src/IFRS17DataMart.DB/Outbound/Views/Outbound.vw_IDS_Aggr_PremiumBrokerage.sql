﻿





CREATE VIEW [Outbound].[vw_IDS_Aggr_PremiumBrokerage]
AS


select 
A.RunID
,Entity
,[Tri focus code]
,[IFRS17 Trifocus] as [IFRS17 Tri Focus Code]
,Account
,Premtype as Prem_type
,CASE WHEN Programme IS NULL OR Programme = '' THEN  'Unknown' ELSE Programme END AS Programme
,RI_Flag 
,YOA
,YOI
,QOI_End_Date
,RecognitionType
,LTRIM(RTRIM(CCY)) as CCY
,cast(Amount as float) as Amount

from [IDS].[Aggr_PremiumBrokerage] A 
INNER JOIN Outbound.IDS_RunID_Control C
on A.RunID =C.RunID
Go

