﻿



CREATE View [Outbound].[vw_IDS_TrifocusMapping]
AS

select A.RunId,[Trifocus Code] as [Tri Focus Code],[Trifocus Name] as [Tri Focus Name],[Focus Group],Division,[CM Earn]
from  [IDS].[TrifocusMapping]A 
INNER JOIN Outbound.IDS_RunID_Control C
on A.RunID =C.RunID
 

Go

