﻿CREATE VIEW [Outbound].[vw_IDS_SpotToForward]
AS
SELECT [ID], [Section], [Parameter], [Value] FROM IDS.SpotToForward