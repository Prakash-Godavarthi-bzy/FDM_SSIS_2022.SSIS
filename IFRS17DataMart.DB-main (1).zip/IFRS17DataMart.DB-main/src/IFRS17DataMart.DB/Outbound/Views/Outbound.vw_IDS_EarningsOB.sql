﻿
CREATE VIEW  [Outbound].[vw_IDS_EarningsOB]
AS
SELECT C.RunID                     				
      ,Entity					
      ,[Tri focus code]		
      ,[IFRS17 TrifocusCode]  
      ,Account					
      ,Programme				
      ,RI_Flag					
      ,YOA						
      ,YOI						
      ,[QOI_End_Date]			
      ,RecognitionType			
      ,LTRIM(RTRIM(CCY)) AS CCY						
      ,[Incepted Status]		
      ,[Open / Closed]	
	  ,cast(Value as float) as Value
  FROM [IDS].EarningsOB P
  INNER JOIN Outbound.IDS_RunID_Control C on P.RunID =C.RunID