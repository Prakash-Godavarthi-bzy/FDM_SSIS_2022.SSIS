﻿





CREATE View [Outbound].[vw_IDS_AccountCodeMapping]
AS

select A.RunId,[Account Code] as [TDH Account Code],[Type],Source,[Field Label]
from [IDS].[AccountCodeMapping] A 
INNER JOIN Outbound.IDS_RunID_Control C
on A.RunID =C.RunID

GO
