﻿CREATE VIEW Outbound.vw_OpenCloseYOA
AS

SELECT CAST([FK_AccountingPeriod]	AS FLOAT)			AS [FK_AccountingPeriod]
      ,CAST([Programme]				AS VARCHAR(255))	AS [Programme]
      ,CAST([FK_Trifocus]			AS VARCHAR(255))	AS [FK_Trifocus]
      ,CAST([FK_YOA]				AS FLOAT)			AS [FK_YOA]
      ,CAST([Open_Cls_Flag]			AS VARCHAR(255))	AS [Open_Cls_Flag]
FROM 
		(
		 SELECT  201905	AS [FK_AccountingPeriod], 'GROSS' AS [Programme],	'T10' AS [FK_Trifocus], 	2004 AS [FK_YOA], 	'C' AS [Open_Cls_Flag]
		 UNION ALL
		 SELECT [FK_AccountingPeriod]      ,[Programme]      ,[FK_Trifocus]      ,[FK_YOA]      ,[Open_Cls_Flag] FROM [Dim].[OpenCloseYOA]
		)A
