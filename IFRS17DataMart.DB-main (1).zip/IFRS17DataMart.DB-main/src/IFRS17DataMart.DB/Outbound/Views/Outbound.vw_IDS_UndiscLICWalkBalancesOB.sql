﻿


CREATE VIEW  [Outbound].[vw_IDS_UndiscLICWalkBalancesOB]
AS
SELECT C.RunID                  
      ,Entity                 
      ,[Tri focus code]       
      ,[IFRS17 Tri focus code]
      ,Account                
      ,CASE WHEN Programme='Gross' THEN UPPER(Programme) ELSE Programme END Programme              
      ,RI_Flag                
      ,YOA                    
      ,YOI                    
      ,QOI_End_Date           
      ,LTRIM(RTRIM(CCY)) AS CCY                    
      ,InceptedStatus         
      ,[Open/Closed]          
      ,Statement              
      ,Position               
      ,Balance					
      ,CAST(Amount AS float) AS Amount				
  FROM [IDS].[UndiscLICWalkBalancesOB] UL
  INNER JOIN Outbound.IDS_RunID_Control C on UL.RunID =C.RunID