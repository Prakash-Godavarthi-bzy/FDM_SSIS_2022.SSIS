﻿CREATE VIEW [Outbound].[vw_IFRS17_Trifocus]
	AS 
SELECT CAST([BK_PolicyNumber]	AS VARCHAR(255))	AS [BK_PolicyNumber]
      ,CAST([FK_YOA]			AS FLOAT)			AS FK_YOA		
      ,CAST([IFRS17_Trifocus]	AS VARCHAR(255))	AS [IFRS17_Trifocus]
FROM 
	(
		SELECT  'TEST'	AS [BK_PolicyNumber], 2018 AS [FK_YOA]	, 'T10' AS [IFRS17_Trifocus]
		UNION ALL
		SELECT [BK_PolicyNumber]      ,[FK_YOA]      ,[IFRS17_Trifocus] FROM [Dim].[IFRS17_Trifocus]
	)A
