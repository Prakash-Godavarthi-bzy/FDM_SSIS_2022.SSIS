﻿






CREATE View [Outbound].[vw_IDS_EarningPatternsYOAYOI]
AS

select p.RunID,Pat_Type,[Tri Focus Code],CAST(Programme AS varchar(100)) Programme,YOA,YOI,LTRIM(RTRIM(cast(CCY as varchar(10)))) as CCY,Qtr,cast(Perc as float) as Perc
from  [IDS].[EarningPatterns] p 
INNER JOIN Outbound.IDS_RunID_Control C
on p.RunID =C.RunID
 where QOI is NULL