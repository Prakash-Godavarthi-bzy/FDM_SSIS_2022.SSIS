﻿CREATE VIEW Outbound.vw_IDS_AssumptionsOB
AS
SELECT C.[RunID]
      ,CASE WHEN [Assumption] = 'PURE_IELR' 
            THEN  CASE WHEN [Entity] = '8022' THEN '8022' ELSE '' END
            ELSE [Entity]
        END [Entity]
	  ----,[Entity]/* I17-5125 PK 06062023 Commented this and added below code for enity for assumption type IELR pure*/
      ,[Tri Focus Code]
      ,[Programme]
      ,[RI_Flag]
      ,[Assumption]
      ,[Loss_type]
      ,[YoA]
      ,[Qtr]
      ,cast([Perc] as float) as [Perc]
  FROM [IDS].[AssumptionOB] A
  INNER JOIN Outbound.IDS_RunID_Control C on A.RunID =C.RunID