﻿CREATE TABLE [Outbound].[AccPer_AsAt_Control] (
    [Id]               INT IDENTITY (1, 1) NOT NULL,
    [AccountingPeriod] INT NULL,
    [AsAt]             INT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 90)
);


