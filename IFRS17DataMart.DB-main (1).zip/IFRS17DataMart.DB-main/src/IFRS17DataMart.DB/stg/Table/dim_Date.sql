﻿CREATE TABLE [stg].[dim_Date]
(
	[ID]		  BIGINT NOT NULL IDENTITY(1,1),
    [PK_Date]     INT          NOT NULL,
    [Date]        DATE         NULL,
    [DateName]    VARCHAR (50) NULL,
    [Year]        INT          NULL,
    [Month]       INT          NULL,
    [Day]         INT          NULL,
    [PERIOD]      INT          NULL,
    [MonthName]   VARCHAR (50) NULL,
    [Quarter]     INT          NULL,
    [QuarterName] VARCHAR (50) NULL,
    [DaysInMonth] INT          NULL,
	[AuditSourceBatchID] [varchar](255)  NULL,
	[AuditCreateDateTime] [datetime] NOT NULL DEFAULT (getutcdate()),
    [AuditUserCreate] [varchar](255) NOT NULL DEFAULT (suser_sname()),
    [AuditHost] [varchar](255) NULL DEFAULT (CONVERT([varchar](255),serverproperty('MachineName'))),
    CONSTRAINT [ID] PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)

)
