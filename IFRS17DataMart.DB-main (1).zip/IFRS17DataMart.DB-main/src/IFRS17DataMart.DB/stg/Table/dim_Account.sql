﻿CREATE TABLE [stg].[dim_Account](
	[PK_Account] [varchar](50) NOT NULL,
	[AccountName] [varchar](100) NULL,
	[Level1Group] [varchar](100) NULL,
	[Level2Group] [varchar](100) NULL,
	[Level3Group] [varchar](100) NULL,
	[RIFlag] [varchar](2) NULL,
	[AuditCreateDateTime] [datetime] NOT NULL,
	[AuditUserCreate] [varchar](255) NOT NULL,
	[AuditHost] [varchar](255) NULL, 
 CONSTRAINT [PK_Account] PRIMARY KEY CLUSTERED 
(
	[PK_Account] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO


