﻿CREATE TABLE [stg].[dim_Entity]
(
	PK_Entity varchar(25) not null
	,Entity varchar(50) null
	,EntityName varchar(50)    null
	,[Platform] varchar(10)		null
	,EntityLevel1 varchar(50)	null
	,EntityLevel2 varchar(50)	null
	,EntityLevel3 varchar(50)	null
	,EntityLevel4 varchar(50)	null
	,EntityLevel5 varchar(50)	null
)
