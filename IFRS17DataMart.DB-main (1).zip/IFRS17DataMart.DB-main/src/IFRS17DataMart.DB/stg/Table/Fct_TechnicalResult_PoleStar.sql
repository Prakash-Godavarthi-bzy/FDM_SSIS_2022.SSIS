﻿CREATE TABLE [stg].[Fct_TechnicalResult_PoleStar](
	[AccountingPeriod] [varchar](50) NULL,
	[Trifocus] [varchar](50) NULL,
	[YOA] [varchar](50) NULL,
	[Entity] [varchar](50) NULL,
	[Account] [varchar](50) NULL,
	[GrossRIFlag] [varchar](50) NULL,
	[Programme] [varchar](50) NULL,
	[Currency] [varchar](50) NULL,
	[Source] [varchar](50) NULL,
	[RI Ref] [varchar](50) NULL,
	[Amount] [varchar](50) NULL,
	[EarnedPercentage] [varchar](50) NULL,
	[InceptionDate] [varchar](50) NULL,
	[ExpiryDate] [varchar](50) NULL
) ON [PRIMARY]