﻿CREATE TABLE [stg].[dim_AccountingPeriod] (
	[PK_AccountingPeriod]  INT         NOT NULL,
    [AccountingPeriodName] VARCHAR (6) NULL,
    [AccountingYear]       INT         NULL,
    [AccountingYearName]   VARCHAR (4) NULL,
    [AccountingMonth]      INT         NULL,
    [AccountingMonthName]  VARCHAR (2) NULL
);

