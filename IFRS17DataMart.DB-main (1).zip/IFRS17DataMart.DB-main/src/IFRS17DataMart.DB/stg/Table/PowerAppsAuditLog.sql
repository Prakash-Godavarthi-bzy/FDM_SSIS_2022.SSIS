﻿CREATE TABLE [stg].[PowerAppsAuditLog] (
    [RunId]       INT           IDENTITY (1, 1) NOT NULL,
    [UserName]    VARCHAR (100) NOT NULL,
    [Email]       VARCHAR (100) NULL,
    [RunDateTime] DATETIME      NULL
);

