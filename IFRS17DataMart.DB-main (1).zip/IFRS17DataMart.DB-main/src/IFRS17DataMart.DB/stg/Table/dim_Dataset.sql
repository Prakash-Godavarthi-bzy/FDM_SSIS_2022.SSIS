﻿CREATE TABLE [stg].[dim_Dataset]
(
    PK_DataSet varchar(255) not null,
    SourceSystem varchar(50),
    GrossRI varchar(50)
)
