﻿CREATE TABLE [stg].[dim_ReportingCurrency]
(
[PK_ReportingCurrencyCode] nvarchar(255) not null
,[ReportingCurrencyName] nvarchar(255) 
)
