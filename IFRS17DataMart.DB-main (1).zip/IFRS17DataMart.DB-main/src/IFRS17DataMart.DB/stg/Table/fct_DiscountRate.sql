﻿CREATE TABLE [stg].[fct_DiscountRate] (
    [PK_DiscountRates]                BIGINT          IDENTITY (1, 1) NOT NULL,
    [FK_Batch]                        INT             NOT NULL,
    [AsAtDate]                        DATE            NOT NULL,
    [DiscountRateName]                VARCHAR (255)   NOT NULL,
    [DiscountRateKey]                 VARCHAR (50)    NOT NULL,
    [DataSet]                         VARCHAR (50)    NOT NULL,
    [SettlementCCY]                   VARCHAR (10)     NOT NULL,
    [CumulativeDevelopmentPercentage] NUMERIC (19, 6) NOT NULL,
    [DevelopmentYear]                 INT             NOT NULL,
    [AssumptionDatasetName]           VARCHAR (35)    NOT NULL,
    [AuditCreateDateTime]             DATETIME2 (7)   NOT NULL,
    [AuditGenerateDateTime]           DATETIME2 (7)   NOT NULL,
    [AuditUserCreate]                 VARCHAR (510)   NOT NULL
);
Go
ALTER TABLE [stg].[fct_DiscountRate] ADD  CONSTRAINT [DF_UpdatedDt]  DEFAULT (getdate()) FOR [AuditGenerateDateTime]
GO
ALTER TABLE [stg].[fct_DiscountRate] ADD  CONSTRAINT [DF_UpdatedBy]  DEFAULT (suser_name()) FOR [AuditUserCreate]
Go
 ALTER TABLE [stg].[fct_DiscountRate] ADD  CONSTRAINT [DF_Updatedcr]  DEFAULT (getdate()) FOR [AuditCreateDateTime]

