﻿CREATE TABLE [stg].[dim_CCY]
(
  PK_CCY varchar(10) not null
  ,CCYName varchar(50) null
)
