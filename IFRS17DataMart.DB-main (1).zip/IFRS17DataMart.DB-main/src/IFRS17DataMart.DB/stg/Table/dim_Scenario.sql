﻿CREATE TABLE [stg].[dim_Scenario]
(
 [PK_Scenario] varchar(10) not null
,[ScenarioName] varchar(50)
)
