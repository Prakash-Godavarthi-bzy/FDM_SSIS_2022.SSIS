﻿CREATE TABLE [stg].[fct_AggrData] (
    [RowOrder]            INT              NULL,
    [FK_Account]          VARCHAR (15)     NOT NULL,
    [FK_Entity]           VARCHAR (25)     NOT NULL,
    [FK_Trifocus]         VARCHAR (25)     NOT NULL,
    [IFRS17 Trifocus]     VARCHAR (25)     NULL,
    [RI Flag]             VARCHAR (2)      NULL,
    [RI Prog]             VARCHAR (100)    NULL,
    [FK_YOA]              VARCHAR (10)     NOT NULL,
    [CCYSettlement]       VARCHAR (10)      NOT NULL,
    [Fk_dataset]          VARCHAR (255)    NULL,
    [FK_scenario]         VARCHAR (10)     NOT NULL,
    [FK_inceptionyear]    INT              NULL,
    [Inceptionperiod]     INT              NULL,
    [Value]               NUMERIC (38, 10) NULL,
    [FK_AccountingPeriod] INT              NOT NULL
);


GO
