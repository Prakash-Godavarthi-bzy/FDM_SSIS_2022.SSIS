﻿CREATE TABLE [stg].[dim_Trifocus]
(
	[PK_TriFocus] varchar(25) not null
	,[TriFocusName] varchar(50)
	,[TriFocusLevel1] varchar(50)
	,[TriFocusLevel2] varchar(100)
	,[TriFocusLevel3] varchar(100)
)
