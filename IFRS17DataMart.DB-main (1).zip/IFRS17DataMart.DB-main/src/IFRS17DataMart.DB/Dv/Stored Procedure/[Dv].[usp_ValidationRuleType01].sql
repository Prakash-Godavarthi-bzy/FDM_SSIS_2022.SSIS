﻿
CREATE Procedure [Dv].[usp_ValidationRuleType01] @RunId int,@RuleSetID int
As
Begin
--DECLARE @RunID AS INT
--DECLARE @RuleSetID AS INT



--SET @RunID = 4086
--SET @RuleSetID = 2



DECLARE @intCurrentRule AS INT
DECLARE @intMaxRule AS INT


		SET @intCurrentRule = 0
		SELECT @intMaxRule = MAX(VR.[PK_ValidationRuleID])
		FROM [Dv].[RuleSet] RS
		INNER JOIN [Dv].[RuleSetRuleMapping] RSM ON RSM.[FK_RuleSetID] = RS.[PK_RuleSetID]
		INNER JOIN [Dv].[ValidationRuleHeader] VR ON RSM.[FK_ValidationRuleID] = VR.[PK_ValidationRuleID]
		WHERE [FK_ValidationRuleTypeID] = 1 AND RS.[PK_RuleSetID] = @RuleSetID

--PRINT @intMaxRule

		WHILE @intCurrentRule < @intMaxRule
		BEGIN
		-- For Each Rule
		-- Pick Current Rule
		SELECT @intCurrentRule = MIN(VR.[PK_ValidationRuleID])
		FROM [Dv].[RuleSet] RS
		INNER JOIN [Dv].[RuleSetRuleMapping] RSM ON RSM.[FK_RuleSetID] = RS.[PK_RuleSetID]
		INNER JOIN [Dv].[ValidationRuleHeader] VR ON RSM.[FK_ValidationRuleID] = VR.[PK_ValidationRuleID]
		WHERE [FK_ValidationRuleTypeID] = 1 AND RS.[PK_RuleSetID] = @RuleSetID AND [PK_ValidationRuleID] > @intCurrentRule



--PRINT 'Current RuleID : ' + CAST( @intCurrentRule AS VARCHAR)




-- DECLARE Variables
		Declare @strAccount VarChar(200),@strDimension VarChar(200),@strOperator nvarchar(10),@strValue nvarchar(200), @strAccountTableType VARCHAR(250),@StrInsert NVARCHAR(4000)
		,@Pk_Column Varchar(100),@FK_Column varchar(100),@DimensionTableName varChar(250),@AccountTableName VarChar(250),@KeyAttributeName VarChar(100)
		,@strSelect nvarchar(4000),@strwhere nvarchar(4000),@strFinal nvarchar(4000),@strInnerJoin nvarchar(4000)
-- Get Current Rule Details
		SELECT
		@strAccount= T1.AccountName
		, @strDimension=T1.DimensionName
		,@strOperator= T1.Operator
		,@strValue= T1.Value
		FROM [dv].[ValidationRuleType01] T1 WHERE [FK_ValidationRuleID] = @intCurrentRule

--PRINT 'Extracted Rule details as Account = ' + @strAccount + ', Dimension = ' + @strDimension + ', Operator = ' + @strOperator + ', Value = ' + CAST(@strValue AS NVARCHAR)

-- Get Account Table Type
		IF EXISTS (SELECT * FROM [rpt].[vw_bm_metadata_AccountNameDimensionKeyMapping] WHERE [FKColumn] ='FK_RunID' and [Account] = @strAccount)
		SET @strAccountTableType = 'Direct'
		ELSE If EXISTS(SELECT * FROM [rpt].[vw_bm_metadata_AccountNameDimensionKeyMapping] WHERE [FKColumn] ='FK_AssumptionDatasetNameId' and [Account] = @strAccount)
		SET @strAccountTableType = 'Bridge'



--PRINT 'Extracted Account Table Type as : ' + @strAccountTableType




-- Comment
		Select @Pk_Column=PKColumn,@FK_Column=FKColumn,@DimensionTableName=DimensionTableName,@AccountTableName=AccountTableName,@KeyAttributeName=KeyAttributeName
		from [rpt].[vw_bm_metadata_AccountNameDimensionKeyMapping]
		where Account=@strAccount and Dimension=@strDimension

--print 'Pk_Column = '+@Pk_Column+', FK_Column = '+@FK_Column+', DimensionTableName = '+@DimensionTableName+', AccountTableName = '+@AccountTableName+', KeyAttributeName = '+@KeyAttributeName



--Insert Statement

		SET @StrInsert = 'INSERT INTO [dv].[ValidationResults] (FK_RunID, FK_ValidationRuleID,Value '
		SELECT @StrInsert = @StrInsert + ',' + FKColumn FROM ( SELECT DISTINCT [FKColumn] FROM [rpt].[vw_bm_metadata_AccountNameDimensionKeyMapping] WHERE Account = @strAccount AND FKColumn <> 'FK_RunID') A
		SET @StrInsert = @StrInsert + ')'



--print @StrInsert





--Select Statement
		IF @strAccountTableType='Direct'
		begin
		set @strSelect=' SELECT A.FK_RunID,'+cast(@intcurrentrule as varchar)+',A.Value'
		SELECT @strSelect = @strSelect + ', A.' + FKColumn FROM ( SELECT DISTINCT [FKColumn] FROM [rpt].[vw_bm_metadata_AccountNameDimensionKeyMapping] WHERE Account = @strAccount AND FKColumn <> 'FK_RunID') A
		set @strSelect=@strSelect+' FROM '+@AccountTableName+' A INNER JOIN [rpt].[vw_bm_dimAccount] Ac On A.FK_AccountCode=Ac.PK_AccountCode And Ac.AccountName = '''+@strAccount+''''
		end
		ELSE --IF @AccountTableType='Bridge'
		begin
		set @strSelect=' SELECT B.FK_RunID,'+cast(@intcurrentrule as varchar)+',A.Value'
		SELECT @strSelect = @strSelect + ', A.' + FKColumn FROM ( SELECT DISTINCT [FKColumn] FROM [rpt].[vw_bm_metadata_AccountNameDimensionKeyMapping] WHERE Account = @strAccount AND FKColumn <> 'FK_RunID') A
		set @strSelect=@strSelect+' FROM '+@AccountTableName+' A INNER JOIN [rpt].[vw_bm_dimAccount] Ac On A.FK_AccountCode=Ac.PK_AccountCode And Ac.AccountName = '''+@strAccount+''' INNER JOIN [rpt].[vw_bm_bridgeAssumptions] B on A.FK_AssumptionDatasetNameID = B.FK_AssumptionDatasetNameID'
		END

--print 'Select statemetn : ' + @strSelect

--Join Condition
		set @strInnerJoin=' LEFT JOIN '+@DimensionTableName+' D'
		set @strInnerJoin=@strInnerJoin+' ON A.'+@FK_Column+' = D.'+@Pk_Column



--print @strInnerJoin

--Where Clause
		IF @strOperator='EXISTS'
			select @strwhere=' Where D.['+@KeyAttributeName+'] IS NULL'
		ELSE IF @strOperator in ('<>','=','IN','NOT IN')
		begin
			set @strwhere=' Where NOT( D.[' + @KeyAttributeName+'] '+ @strOperator + ' ('
			select @strwhere=@strwhere+''''+ trim(value)+''',' from string_split(@strValue,',')
			set @strwhere=left(@strwhere,len(@strwhere)-2)+'''))'
		end
		--ELSE IF @strOperator in ('IN','NOT IN')
		--set @strwhere='Where D.'+@KeyAttributeName +@strOperator +''''+ Cast(@strValue as nvarchar)+''''

--print @strwhere
--Append
		IF @strAccountTableType='Direct'
		set @strwhere=@strwhere+' And A.FK_RunID= '+cast(@RunID as VARCHAR)
		ELSE IF @strAccountTableType='Bridge'
		set @strwhere=@strwhere+' AND B.Fk_RunID= '+cast(@RunID as VARCHAR)
--print @strwhere
		set @strFinal=@StrInsert+@strSelect+@strInnerJoin+@strwhere
		---print @strFinal
		exec sp_executesql @strFinal
	END
END

---Exec [dv].[usp_ValidationRuleType01] 3264,94