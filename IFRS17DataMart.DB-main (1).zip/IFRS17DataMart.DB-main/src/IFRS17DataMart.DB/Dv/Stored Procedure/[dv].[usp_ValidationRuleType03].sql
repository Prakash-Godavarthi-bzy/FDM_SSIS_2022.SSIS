﻿


CREATE Procedure [Dv].[usp_ValidationRuleType03] @RunId int,@RuleSetID int
As
Begin


--DECLARE @RunID AS INT
--DECLARE @RuleSetID AS INT

--SET @RunID = 4274
--SET @RuleSetID = 127

DECLARE @intCurrentRule AS INT
DECLARE @intMaxRule AS INT





SET @intCurrentRule =0
SELECT @intMaxRule = MAX(VR.[PK_ValidationRuleID])
FROM [Dv].[RuleSet] RS
INNER JOIN [Dv].[RuleSetRuleMapping] RSM ON RSM.[FK_RuleSetID] = RS.[PK_RuleSetID]
INNER JOIN [Dv].[ValidationRuleHeader] VR ON RSM.[FK_ValidationRuleID] = VR.[PK_ValidationRuleID]
WHERE [FK_ValidationRuleTypeID] = 3 AND RS.[PK_RuleSetID] = @RuleSetID



--PRINT @intMaxRule



WHILE @intCurrentRule < @intMaxRule
BEGIN
	 --For Each Rule
	 --Pick Current Rule
		SELECT @intCurrentRule = MIN(VR.[PK_ValidationRuleID])
		FROM [Dv].[RuleSet] RS
		INNER JOIN [Dv].[RuleSetRuleMapping] RSM ON RSM.[FK_RuleSetID] = RS.[PK_RuleSetID]
		INNER JOIN [Dv].[ValidationRuleHeader] VR ON RSM.[FK_ValidationRuleID] = VR.[PK_ValidationRuleID]
		WHERE [FK_ValidationRuleTypeID] = 3 AND RS.[PK_RuleSetID] = @RuleSetID AND [PK_ValidationRuleID] > @intCurrentRule

	--PRINT 'Current RuleID : ' + CAST( @intCurrentRule AS VARCHAR)


	-- DECLARE Variables
		Declare @strAccount VarChar(200),@strCompareAccount VarChar(200),@strOperator nvarchar(10),@decFactor numeric(38,10), @strAccountTableType VARCHAR(250),@strCompareAccountTableType VARCHAR(250)
		--,@Pk_Column Varchar(100),@FK_Column varchar(100)
		,@CompareAccountTableName varChar(250),@AccountTableName VarChar(250)--,@KeyAttributeName VarChar(100)
		,@StrInsert NVARCHAR(4000),@MasterSelect nvarchar(4000),@strSelectAccount nvarchar(4000),@strSelectCompareAccount nvarchar(4000),@strInnerJoin nvarchar(4000),@StrWhere nvarchar(4000),@strFinal nvarchar(4000)


	-- Get Current Rule Details
		SELECT
		@strAccount= T1.AccountName
		,@strCompareAccount=T1.CompareAccountName
		,@strOperator= T1.Operator
		,@decFactor= T1.Factor
		FROM [dv].[ValidationRuleType03] T1 WHERE [FK_ValidationRuleID] = @intCurrentRule


	--PRINT 'Extracted Rule details as Account = ' + @strAccount + ', Dimension = ' + @strDimension + ', Operator = ' + @strOperator + ', Value = ' + CAST(@strValue AS NVARCHAR)


	--Get Account Table Type


		IF EXISTS (SELECT * FROM [rpt].[vw_bm_metadata_AccountNameDimensionKeyMapping] WHERE [FKColumn] ='FK_RunID' and [Account] = @strAccount)
			SET @strAccountTableType = 'Direct'
		ELSE  If EXISTS(SELECT * FROM [rpt].[vw_bm_metadata_AccountNameDimensionKeyMapping] WHERE [FKColumn] ='FK_AssumptionDatasetNameId' and [Account] = @strAccount)
			SET @strAccountTableType = 'Bridge'

	--Get CompareAccountTableType

		IF EXISTS (SELECT * FROM [rpt].[vw_bm_metadata_AccountNameDimensionKeyMapping] WHERE [FKColumn] ='FK_RunID' and [Account] = @strCompareAccount)
			SET @strCompareAccountTableType = 'Direct'
		ELSE  If EXISTS(SELECT * FROM [rpt].[vw_bm_metadata_AccountNameDimensionKeyMapping] WHERE [FKColumn] ='FK_AssumptionDatasetNameId' and [Account] = @strCompareAccount)
			SET @strCompareAccountTableType = 'Bridge'

	--Get AccountTableName

		select @AccountTableName=AccountTableName from [rpt].[vw_bm_metadata_Account] where Account=@strAccount

	--Get CompareAccountTableName

		select @CompareAccountTableName=AccountTableName from [rpt].[vw_bm_metadata_Account] where Account=@strCompareAccount

	--Insert Statement

		SET @StrInsert = 'INSERT INTO [dv].[ValidationResults] (FK_RunID, FK_ValidationRuleID,Value,Value2'
		SELECT @StrInsert = @StrInsert + ',' + FKCOLUMN FROM DV.GetForeignKeys(@intCurrentRule,@strAccount,@strCompareAccount)
		SET @StrInsert = @StrInsert + ')'

	--Master Select Statement

		set @MasterSelect=' SELECT G.FK_RunID, '+ cast(@intCurrentRule as varchar) + ' AS FK_ValidationRuleID,G.Value,DR.Value2'
		select @MasterSelect=@MasterSelect+ ',G.' + FKCOLUMN FROM DV.GetForeignKeys(@intCurrentRule,@strAccount,@strCompareAccount)
		set @MasterSelect=@MasterSelect+ ' FROM '
		--Print @MasterSelect 

	--Select Statement for Account

		IF @strAccountTableType='Direct'
		 begin
			SET @strSelectAccount='(SELECT SUM(B.Value) AS Value,FK_RunID'
			select @strSelectAccount=@strSelectAccount+', B.'+FKCOLUMN FROM DV.GetForeignKeys(@intCurrentRule,@strAccount,@strCompareAccount)
			SET @strSelectAccount = @strSelectAccount + ' FROM ' + @AccountTableName + ' B  
							Inner Join [rpt].[vw_bm_dimAccount] DA On DA.Pk_AccountCode=B.Fk_AccountCode  
							WHERE B.FK_RunID = '+CAST(@RunID AS varchar)+ ' And DA.AccountName='''+@StrAccount +''' GROUP BY FK_RunID,'
			select @strSelectAccount=@strSelectAccount+'B.'+FKCOLUMN+',' FROM DV.GetForeignKeys(@intCurrentRule,@strAccount,@strCompareAccount)
			SET @strSelectAccount = LEFT(@strSelectAccount,LEN(@strSelectAccount)-1) + ') G LEFT JOIN '
		 end

		ELSE IF @strAccountTableType='Bridge'
		 begin
			SET @strSelectAccount='(SELECT SUM(B.Value) AS Value,FK_RunID'
			select @strSelectAccount=@strSelectAccount+', B.'+FKCOLUMN FROM DV.GetForeignKeys(@intCurrentRule,@strAccount,@strCompareAccount)
			SET @strSelectAccount = @strSelectAccount + ' FROM ' + @AccountTableName + '  B INNER JOIN [rpt].[vw_bm_bridgeAssumptions] BR ON B.[FK_AssumptionDataSetNameID] = BR.[FK_AssumptionDataSetNameID] 
						Inner join [rpt].[vw_bm_dimAccount] DA On DA.Pk_AccountCode=B.Fk_AccountCode
			WHERE   BR.[FK_RunID] = '+CAST(@RunID AS varchar)+ ' And DA.AccountName='''+@StrAccount +''' GROUP BY FK_RunID,'
			select @strSelectAccount=@strSelectAccount+'B.'+FKCOLUMN+',' FROM DV.GetForeignKeys(@intCurrentRule,@strAccount,@strCompareAccount)
			SET @strSelectAccount = LEFT(@strSelectAccount,LEN(@strSelectAccount)-1) + ') G LEFT JOIN '
		 end
		--- Print @strSelectAccount
	 --Select statement for Compare account

		IF @strcompareAccountTableType='Direct'
		begin
			SET @strSelectCompareAccount='(SELECT SUM(C.Value) * '+cast(@decfactor as varchar)+' AS Value2,FK_RunID '
			select @strSelectCompareAccount=@strSelectCompareAccount+', C.'+FKCOLUMN FROM DV.GetForeignKeys(@intCurrentRule,@strAccount,@strCompareAccount)
			SET @strSelectCompareAccount = @strSelectCompareAccount + ' FROM ' + @CompareAccountTableName + ' C Inner Join [rpt].[vw_bm_dimAccount] DA On DA.Pk_AccountCode=C.Fk_AccountCode  
					WHERE C.FK_RunID = '+CAST(@RunID AS varchar)+ ' And DA.AccountName='''+@strCompareAccount +''' GROUP BY FK_RunID,'
			select @strSelectCompareAccount=@strSelectCompareAccount+'C.'+FKCOLUMN+',' FROM DV.GetForeignKeys(@intCurrentRule,@strAccount,@strCompareAccount)
			SET @strSelectCompareAccount = LEFT(@strSelectCompareAccount,LEN(@strSelectCompareAccount)-1) + ') DR'
		 end

		 ELSE IF @strCompareAccountTableType='Bridge'
		 begin
			SET @strSelectCompareAccount='(SELECT SUM(C.Value) *'+ CAST(@decFactor as Nvarchar)+' As Value2,FK_RunID'
			select @strSelectCompareAccount=@strSelectCompareAccount+', C.'+FKCOLUMN FROM DV.GetForeignKeys(@intCurrentRule,@strAccount,@strCompareAccount)
			SET @strSelectCompareAccount = @strSelectCompareAccount + ' FROM ' + @CompareAccountTableName + '  C INNER JOIN [rpt].[vw_bm_bridgeAssumptions] BR ON C.[FK_AssumptionDataSetNameID] = BR.[FK_AssumptionDataSetNameID] 
			       Inner join [rpt].[vw_bm_dimAccount] DA On DA.Pk_AccountCode=C.Fk_AccountCode
			WHERE   BR.[FK_RunID] = '+CAST(@RunID AS varchar)+ ' And DA.AccountName= '''+@strCompareAccount +''' GROUP BY FK_RunID,'
			select @strSelectCompareAccount=@strSelectCompareAccount+'C.'+FKCOLUMN+',' FROM DV.GetForeignKeys(@intCurrentRule,@strAccount,@strCompareAccount)
				SET @strSelectCompareAccount = LEFT(@strSelectCompareAccount,LEN(@strSelectCompareAccount)-1) + ') DR'
		 end
  ---Print @strCompareAccount
	 --- Join Script

		set @strInnerJoin=' ON G.FK_RunID=DR.FK_RunID AND '
		select @strInnerJoin=@strInnerJoin+ 'G.'+ FKCOLUMN +' = DR.'+FKCOLUMN+ ' AND 'FROM DV.GetForeignKeys(@intCurrentRule,@strAccount,@strCompareAccount)
		SET @strInnerJoin = LEFT(@strInnerJoin,LEN(@strInnerJoin)-4)

		---Print @strInnerJoin

	--WHERE CLAUSE

		IF @strOperator IN ('<','>','<=','>=','=')
			SET @StrWhere=' WHERE NOT( G.Value '+@strOperator+' ISNULL(DR.Value2,0) ) '
		ELSE IF @strOperator = 'EXISTS'
			SET @StrWhere=' WHERE DR.Value2 IS NULL'

	--Concatenate Insert,MasterSelect,SelectAccount,selectCompareAccount,Join,WhereClause

		set @strFinal=@StrInsert+@MasterSelect+@strSelectAccount+@strSelectCompareAccount+@strInnerJoin+@strwhere

--print @strFinal
exec sp_executesql @strFinal


END

END