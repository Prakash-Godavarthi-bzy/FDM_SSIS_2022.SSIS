CREATE FUNCTION Dv.GetForeignKeys(@intCurrentRule int,@strAccount NVARCHAR(4000),@strCompareAccount NVARCHAR(4000))
RETURNS TABLE
AS
RETURN
SELECT distinct AC.[FKColumn] FROM [rpt].[vw_bm_metadata_AccountNameDimensionKeyMapping] AC
INNER JOIN [rpt].[vw_bm_metadata_AccountNameDimensionKeyMapping] CAC ON AC.[FKColumn] = CAC.[FKColumn]
INNER JOIN Dv.[ValidationRuleDetailsType03] R ON CHARINDEX(AC.[Dimension],IsNull(R.[DimensionName],0),1) = 0
WHERE AC.[Account] = @strAccount AND CAC.[Account] = @strCompareAccount
AND AC.[FKColumn] NOT IN ('FK_RunID','FK_AccountCode','FK_AssumptionDatasetNameId') and FK_ValidationRuleID=@intCurrentRule