Create  PROCEDURE [dv].[usp_ValidateRun] @RunID INT, @DeleteExisting BIT = 0
As
BEGIN
		IF @DeleteExisting = 0 AND EXISTS (SELECT * FROM [Dv].[ValidationResults] WHERE [FK_RunID] = @RunID)
				BEGIN
					  RAISERROR ( 'Error, unable to progress as data check results exists for the current run id',1,1)
						RETURN
				  END
       
		IF @DeleteExisting = 1 AND EXISTS (SELECT * FROM [Dv].[ValidationResults] WHERE [FK_RunID] = @RunID)
              -- Delete existing data for the current RunID
              DELETE FROM [Dv].[ValidationResults] where [FK_RunID] = @RunID
			  ---end
		Declare @FK_RuleSet int ,@Rule1Count int,@Rule2Count int,@Rule3Count int
						Set @FK_RuleSet= (Select 1 As Fk_RuleSetID From PWAPS.IFRS17CalcUI_RunLog where Pk_RequestId=@RunID)
						Set @Rule1Count=(Select Count( FK_ValidationRuleTypeID) from Dv.RuleSetRuleMapping RSM inner join  Dv.RuleSet Rs on RSM.FK_RuleSetID=RS.PK_RuleSetID 
											inner join Dv.ValidationRuleHeader VR On RSM.FK_ValidationRuleID=VR.PK_ValidationRuleID
											where PK_RuleSetID=28 and FK_ValidationRuleTypeID=1)
			
						Set @Rule2Count=(Select Count( FK_ValidationRuleTypeID) from Dv.RuleSetRuleMapping RSM inner join  Dv.RuleSet Rs on RSM.FK_RuleSetID=RS.PK_RuleSetID 
											inner join Dv.ValidationRuleHeader VR On RSM.FK_ValidationRuleID=VR.PK_ValidationRuleID
											where PK_RuleSetID=28 and FK_ValidationRuleTypeID=2)
						Set @Rule3Count=(Select Count( FK_ValidationRuleTypeID) from Dv.RuleSetRuleMapping RSM inner join  Dv.RuleSet Rs on RSM.FK_RuleSetID=RS.PK_RuleSetID 
											inner join Dv.ValidationRuleHeader VR On RSM.FK_ValidationRuleID=VR.PK_ValidationRuleID
											where PK_RuleSetID=28 and FK_ValidationRuleTypeID=3)

					If(@Rule1Count>0)
							Execute  [dv].[usp_ValidationRuleType01]@RunID,@FK_RuleSet
					If(@Rule2Count>0)	
							Execute [dv].[usp_ValidationRuleType02]@RunID,@FK_RuleSet
					If(@Rule3Count>0)
							Execute [dv].[usp_ValidationRuleType03]@RunID,@FK_RuleSet

END

--Exec [dv].[usp_ValidateRun]
