
Create Procedure [dv].[usp_ValidationRuleType02] @RunID int,@RuleSetID int
As
Begin
		DECLARE @intCurrentRule AS INT
		DECLARE @intMaxRule AS INT
		SET @intCurrentRule = 0
		SELECT @intMaxRule = MAX(VR.[PK_ValidationRuleID])
		FROM [Dv].[RuleSet] RS
		INNER JOIN [Dv].[RuleSetRuleMapping] RSM ON RSM.[FK_RuleSetID] = RS.[PK_RuleSetID]
		INNER JOIN [Dv].[ValidationRuleHeader] VR ON RSM.[FK_ValidationRuleID] = VR.[PK_ValidationRuleID]
		WHERE [FK_ValidationRuleTypeID] = 2 AND RS.[PK_RuleSetID] = @RuleSetID



--PRINT @intMaxRule
		WHILE @intCurrentRule < @intMaxRule
		BEGIN
		-- For Each Rule
		-- Pick Current Rule
		SELECT @intCurrentRule = MIN(VR.[PK_ValidationRuleID])
		FROM [Dv].[RuleSet] RS
		INNER JOIN [Dv].[RuleSetRuleMapping] RSM ON RSM.[FK_RuleSetID] = RS.[PK_RuleSetID]
		INNER JOIN [Dv].[ValidationRuleHeader] VR ON RSM.[FK_ValidationRuleID] = VR.[PK_ValidationRuleID]
		WHERE [FK_ValidationRuleTypeID] = 2 AND RS.[PK_RuleSetID] = @RuleSetID AND [PK_ValidationRuleID] > @intCurrentRule

		----PRINT 'Current RuleID : ' + CAST( @intCurrentRule AS VARCHAR)

-- DECLARE Variables
		Declare @strAccount VarChar(200),@strOperator nvarchar(10),@strRuleValue1 numeric(38,10),@strRuleValue2 numeric(38,10), @strAccountTableType VARCHAR(250),@StrInsert NVARCHAR(4000)
		,@AccountTableName VarChar(250),@KeyAttributeName VarChar(100)
		,@strSelect nvarchar(4000),@strwhere nvarchar(4000),@strFinal nvarchar(4000),@strInnerJoin nvarchar(4000)




-- Get Current Rule Details
		SELECT
		@strAccount= T1.AccountName
		,@strOperator= T1.Operator
		,@strRuleValue1= T1.Value
		,@strRuleValue2= T1.Value2
		FROM [dv].[ValidationRuleType02] T1 WHERE [FK_ValidationRuleID] = @intCurrentRule
		---PRINT 'Extracted Rule details as Account = ' + @strAccount + ', Operator = ' + @strOperator + ', Value1 = ' + CAST(@strRuleValue1 AS NVARCHAR) + 'Value2 = '+cast(@strrulevalue2 as nvarchar)

-- Get Account Table Type

		IF EXISTS (SELECT * FROM [rpt].[vw_bm_metadata_AccountNameDimensionKeyMapping] WHERE [FKColumn] ='FK_RunID')-- and [Account] = @strAccount)
		SET @strAccountTableType = 'Direct'
		ELSE  If EXISTS(SELECT * FROM [rpt].[vw_bm_metadata_AccountNameDimensionKeyMapping] WHERE [FKColumn] ='FK_AssumptionDataSetNameId')
		SET @strAccountTableType = 'Bridge'

		---PRINT 'Extracted Account Table Type as : ' + @strAccountTableType


-- Comment
		select @AccountTableName=AccountTableName--,@KeyAttributeName=keya
		from rpt.vw_bm_metadata_Account where Account=@strAccount

		----print 'AccountTableName = '+@AccountTableName

--Insert Statement
		

		SET @StrInsert = 'INSERT INTO [dv].[ValidationResults] (FK_RunID, FK_ValidationRuleID,Value '
		SELECT @StrInsert = @StrInsert + ',' + FKColumn FROM ( SELECT DISTINCT [FKColumn] FROM [rpt].[vw_bm_metadata_AccountNameDimensionKeyMapping] WHERE Account = @strAccount AND FKColumn <> 'FK_RunID') A
		SET @StrInsert = @StrInsert + ')'
	---	Print @strInsert

--Select Statement

		IF @strAccountTableType='Direct'
		begin
		set @strSelect='SELECT A.FK_RunID,'+cast(@intcurrentrule as varchar)+',A.Value'
		SELECT @strSelect = @strSelect + ', A.' + FKColumn FROM ( SELECT DISTINCT [FKColumn] FROM [rpt].[vw_bm_metadata_AccountNameDimensionKeyMapping] WHERE Account =@strAccount  AND FKColumn <> 'FK_RunID') A
		set @strSelect=@strSelect+' FROM '+@AccountTableName+' A '
		end
		ELSE --IF @AccountTableType='Bridge'
		begin
		set @strSelect='SELECT B.FK_RunID'+cast(@intcurrentrule as varchar)+',A.Value'
		SELECT @strSelect = @strSelect + ', A.' + FKColumn FROM ( SELECT DISTINCT [FKColumn] FROM [rpt].[vw_bm_metadata_AccountNameDimensionKeyMapping] WHERE Account = @strAccount  AND FKColumn <> 'FK_RunID') A
		set @strSelect=@strSelect+' FROM '+@AccountTableName+' A INNER JOIN [rpt].[vw_bm_bridgeAssumptions] B on A.FK_AssumptionDataSetNameID=B.FK_AssumptionDataSetNameID'
		END
		---print 'Select statemetn : ' + @strSelect
--Where Clause
		 IF @strOperator in ('<','>','<=','>=','=')
		set @strwhere=' Where A.Value '+ @strOperator +' '+cast(@strRuleValue1 as nvarchar)
		ELSE IF @strOperator in ('BETWEEN','NOT BETWEEN')
		set @strwhere='Where A.Value ' +@strOperator + @strRuleValue1 + ' And '+ @strRuleValue2

		---print @strwhere

--Append
		IF @strAccountTableType='Direct'
		set @strwhere=@strwhere+' And A.FK_RunID= '+cast(@RunID as VARCHAR)
		ELSE IF @strAccountTableType='Bridge'
		set @strwhere=@strwhere+' AND B.Fk_RunID= '+cast(@RunID as VARCHAR)

	---	print @strwhere

		set @strFinal=@StrInsert+@strSelect+@strwhere
		---print @strFinal
		exec sp_executesql @strFinal


END

END



--Exec [dv].[usp_ValidationRuleType02] 3624,95