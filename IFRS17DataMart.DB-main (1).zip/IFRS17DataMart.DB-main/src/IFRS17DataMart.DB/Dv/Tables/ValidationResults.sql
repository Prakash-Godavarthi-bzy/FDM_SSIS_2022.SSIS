﻿CREATE TABLE [Dv].[ValidationResults] (
    [FK_RunId]                   INT            NULL,
    [FK_ValidationRuleID]        INT            NULL,
    [Value]                      Numeric(38,12)            NULL,
    [Value2]                     Numeric(38,12)            NULL,
    [FK_AccountCode]             NVARCHAR (35)  NULL,
    [FK_AssumptionDataSetNameID] INT            NULL,
    [FK_CCY]                     NVARCHAR (10)   NULL,
    [FK_DevelopmentQuarter]      INT            NULL,
    [FK_DevelopmentYear]         INT            NULL,
    [FK_Division]                VARCHAR (60)   NULL,
    [FK_EarningPeriod]           DATE           NULL,
    [FK_Entity]                  VARCHAR (20)   NULL,
    [FK_EventDate]               VARCHAR (11)   NULL,
    [FK_FocusGroup]              VARCHAR (100)  NULL,
    [FK_IFRS17TriFocusCode]      VARCHAR (25)   NULL,
    [FK_LossType]                NVARCHAR (10)  NULL,
    [FK_OpenCloseYOA]            VARCHAR (10)   NULL,
    [FK_PremiumType]             VARCHAR (25)   NULL,
    [FK_Programme]               VARCHAR (100)  NULL,
    [FK_Quarter]                 DATE           NULL,
    [FK_RecognitionType]         CHAR (2)       NULL,
    [FK_ReportingCCY]            NVARCHAR (255) NULL,
    [FK_RIFlag]                  VARCHAR (2)    NULL,
    [FK_Trifocus]                NVARCHAR (25)  NULL,
    [FK_UltimatesSource]         CHAR (1)       NULL,
    [FK_YOA]                     INT            NULL,
    [FK_YOI]                     NVARCHAR (25)            NULL,
    [FK_source]                     varchar(5)              NULL,
    FOREIGN KEY ([FK_RunId]) REFERENCES [PWAPS].[IFRS17CalcUI_RunLog] ([Pk_RequestId]),
    FOREIGN KEY ([FK_RunId]) REFERENCES [PWAPS].[IFRS17CalcUI_RunLog] ([Pk_RequestId]),
    FOREIGN KEY ([FK_RunId]) REFERENCES [PWAPS].[IFRS17CalcUI_RunLog] ([Pk_RequestId]),
    FOREIGN KEY ([FK_RunId]) REFERENCES [PWAPS].[IFRS17CalcUI_RunLog] ([Pk_RequestId]),
    FOREIGN KEY ([FK_ValidationRuleID]) REFERENCES [Dv].[ValidationRuleHeader] ([PK_ValidationRuleID]),
    FOREIGN KEY ([FK_ValidationRuleID]) REFERENCES [Dv].[ValidationRuleHeader] ([PK_ValidationRuleID]),
    FOREIGN KEY ([FK_ValidationRuleID]) REFERENCES [Dv].[ValidationRuleHeader] ([PK_ValidationRuleID]),
    FOREIGN KEY ([FK_ValidationRuleID]) REFERENCES [Dv].[ValidationRuleHeader] ([PK_ValidationRuleID])
);

 
GO


