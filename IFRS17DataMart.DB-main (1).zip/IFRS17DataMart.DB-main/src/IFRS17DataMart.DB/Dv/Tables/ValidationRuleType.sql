﻿CREATE TABLE [Dv].[ValidationRuleType] (
    [PK_ValidationRuleTypeID] INT   Identity(1,1)   NOT NULL,
    [ValidationRuleType]      VARCHAR (200) Not NULL,
    PRIMARY KEY CLUSTERED ([PK_ValidationRuleTypeID] ASC) WITH (FILLFACTOR = 90)
);

