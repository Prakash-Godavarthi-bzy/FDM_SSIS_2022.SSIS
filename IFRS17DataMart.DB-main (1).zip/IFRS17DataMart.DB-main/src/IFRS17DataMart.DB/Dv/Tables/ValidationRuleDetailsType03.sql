﻿CREATE TABLE [Dv].[ValidationRuleDetailsType03] (
    [FK_ValidationRuleID] INT           NULL,
    [DimensionName]       VARCHAR (500) NULL,
    [Pk_RuleDetail]       INT           IDENTITY (1, 1) NOT NULL,
    PRIMARY KEY CLUSTERED ([Pk_RuleDetail] ASC) WITH (FILLFACTOR = 90),
    FOREIGN KEY ([FK_ValidationRuleID]) REFERENCES [Dv].[ValidationRuleHeader] ([PK_ValidationRuleID])
);



