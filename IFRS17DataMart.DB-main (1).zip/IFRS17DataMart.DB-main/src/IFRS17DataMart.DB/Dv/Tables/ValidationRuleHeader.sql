﻿CREATE TABLE [Dv].[ValidationRuleHeader] (
    [PK_ValidationRuleID]     INT           IDENTITY (1, 1) NOT NULL,
    [FK_ValidationRuleTypeID] INT           NULL,
    [Rule]                    VARCHAR (50) NULL,
    [Hidden]                  INT           NULL,
    [UpdatedBy]               VARCHAR (255) NULL,
    [UpdateDateTime]          DATETIME2 (7) NULL,
    PRIMARY KEY CLUSTERED ([PK_ValidationRuleID] ASC) WITH (FILLFACTOR = 90),
    FOREIGN KEY ([FK_ValidationRuleTypeID]) REFERENCES [Dv].[ValidationRuleType] ([PK_ValidationRuleTypeID])
);



