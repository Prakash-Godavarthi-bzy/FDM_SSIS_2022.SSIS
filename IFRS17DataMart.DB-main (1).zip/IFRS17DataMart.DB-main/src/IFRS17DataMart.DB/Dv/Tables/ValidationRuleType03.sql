﻿CREATE TABLE [Dv].[ValidationRuleType03] (
    [Pk_Rule3]            INT              IDENTITY (1, 1) NOT NULL,
    [FK_ValidationRuleID] INT              NULL,
    [AccountName]         VARCHAR (100)    NULL,
    [CompareAccountName]  VARCHAR (100)    NULL,
    [Operator]            NVARCHAR (20)    NULL,
    [Factor]              NUMERIC (38, 10) NULL,
    PRIMARY KEY CLUSTERED ([Pk_Rule3] ASC) WITH (FILLFACTOR = 90),
    FOREIGN KEY ([FK_ValidationRuleID]) REFERENCES [Dv].[ValidationRuleHeader] ([PK_ValidationRuleID])
);





