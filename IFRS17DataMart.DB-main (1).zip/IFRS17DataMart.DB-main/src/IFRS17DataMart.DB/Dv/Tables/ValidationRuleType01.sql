﻿CREATE TABLE [Dv].[ValidationRuleType01] (
    [Pk_Rule1]            INT            IDENTITY (1, 1) NOT NULL,
    [FK_ValidationRuleID] INT            NULL,
    [AccountName]         VARCHAR (100)  NULL,
    [DimensionName]       VARCHAR (100)  NULL,
    [Operator]            NVARCHAR (20)  NULL,
    [Value]               NVARCHAR (100) NULL,
    PRIMARY KEY CLUSTERED ([Pk_Rule1] ASC) WITH (FILLFACTOR = 90),
    FOREIGN KEY ([FK_ValidationRuleID]) REFERENCES [Dv].[ValidationRuleHeader] ([PK_ValidationRuleID])
);







