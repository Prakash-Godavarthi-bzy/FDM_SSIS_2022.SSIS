﻿CREATE TABLE [Dv].[RuleSet] (
    [PK_RuleSetID]   INT           IDENTITY (1, 1) NOT NULL,
    [RuleSet]        VARCHAR (50) NULL,
    [Hidden]         INT           NULL,
    [UpdatedBy]      VARCHAR (100) NULL,
    [UpdateDateTime] DATETIME      NULL,
    PRIMARY KEY CLUSTERED ([PK_RuleSetID] ASC) WITH (FILLFACTOR = 90)
);

