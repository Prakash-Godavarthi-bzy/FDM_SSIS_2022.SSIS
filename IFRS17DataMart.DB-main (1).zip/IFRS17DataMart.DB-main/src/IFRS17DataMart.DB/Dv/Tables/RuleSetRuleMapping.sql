﻿CREATE TABLE [Dv].[RuleSetRuleMapping] (
    [FK_RuleSetID]        INT NULL,
    [FK_ValidationRuleID] INT NULL,
    [Pk_RuleMap]          INT IDENTITY (1, 1) NOT NULL,
    PRIMARY KEY CLUSTERED ([Pk_RuleMap] ASC) WITH (FILLFACTOR = 90),
    FOREIGN KEY ([FK_RuleSetID]) REFERENCES [Dv].[RuleSet] ([PK_RuleSetID]),
    FOREIGN KEY ([FK_ValidationRuleID]) REFERENCES [Dv].[ValidationRuleHeader] ([PK_ValidationRuleID])
);



