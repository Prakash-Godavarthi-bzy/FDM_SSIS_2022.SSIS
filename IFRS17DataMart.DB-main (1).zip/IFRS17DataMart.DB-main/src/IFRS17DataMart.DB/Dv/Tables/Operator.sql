﻿CREATE TABLE [Dv].[Operator] (
    [PK_Operator] INT           IDENTITY (1, 1) NOT NULL,
    [Operator]    NVARCHAR (20) NULL,
    PRIMARY KEY CLUSTERED ([PK_Operator] ASC) WITH (FILLFACTOR = 90)
);

