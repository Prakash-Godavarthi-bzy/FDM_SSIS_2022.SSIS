﻿	CREATE TABLE [Control].[ActivityLog] (
    [PK_ActivityLog]          BIGINT          IDENTITY (1, 1) NOT NULL,
    [FK_ActivityStatus]       SMALLINT        NOT NULL,
    [ActivityHost]            VARCHAR (100)   NOT NULL,
    [ActivityDatabase]        VARCHAR (100)   NULL,
    [ActivityJobId]           VARCHAR (50)    NULL,
    [ActivitySSISExecutionId] VARCHAR (50)    NULL,
    [ActivityName]            VARCHAR (100)   NOT NULL,
    [ActivityDateTime]        DATETIME2 (2)   NULL,
    [ActivityMessage]         NVARCHAR (4000) NULL,
    [ActivityErrorCode]       NVARCHAR (50)   NULL,
    [AuditCreateDateTime]     DATETIME2 (2)   DEFAULT (getdate()) NOT NULL,
    [AuditModifyDateTime]     DATETIME2 (2)   DEFAULT (getdate()) NULL,
    [AuditUserCreate]         VARCHAR (64)    DEFAULT (suser_name()) NOT NULL,
    [AuditUserModify]         VARCHAR (64)    DEFAULT (suser_name()) NULL,
    [UserName]                VARCHAR (100)   NULL,
    [PK_RequestID]            INT             NULL
);








