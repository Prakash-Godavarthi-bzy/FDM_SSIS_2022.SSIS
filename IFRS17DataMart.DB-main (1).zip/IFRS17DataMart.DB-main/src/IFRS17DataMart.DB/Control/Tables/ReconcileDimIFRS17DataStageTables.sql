﻿CREATE TABLE [Control].[ReconcileDimIFRS17DataStageTables] (
    [PK_ReconcileDimIFRS17DataStageTablesID] INT     IDENTITY(1,1)     NOT NULL,
    [FK_ReconcileDataStageID]                INT           NOT NULL,
    [SourceTableName]                        VARCHAR (100) NULL,
    [TargetTableName]                        VARCHAR (100) NULL,
    [AuditCreateDateTime]   DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditCreateUser]       NVARCHAR (510)   DEFAULT (suser_sname()) NOT NULL,
 
    PRIMARY KEY CLUSTERED ([PK_ReconcileDimIFRS17DataStageTablesID] ASC) WITH (FILLFACTOR = 90)
);

