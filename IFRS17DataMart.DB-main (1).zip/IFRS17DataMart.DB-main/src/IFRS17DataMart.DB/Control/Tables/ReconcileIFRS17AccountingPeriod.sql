﻿CREATE TABLE [Control].[ReconcileIFRS17AccountingPeriod] (
    [PK_ReconcileIFRS17AccountingPeriodID] INT            IDENTITY (1, 1) NOT NULL,
    [FK_ParentOrchestrationID]             INT            NOT NULL,
    [FK_ChildOrchestrationID]              INT            NOT NULL,
    [AccountingPeriod]                     INT            NOT NULL,
    [FK_ReconcileDataStageID]              INT            NOT NULL,
    [ReconciliationStatus]                 VARCHAR (100)  NULL,
    [AuditCreateDateTime]                  DATETIME2 (7)  DEFAULT (getdate()) NOT NULL,
    [AuditCreateUser]                      NVARCHAR (510) DEFAULT (suser_sname()) NOT NULL,
    [AccountingPeriodflag]                 INT            NULL,
    PRIMARY KEY CLUSTERED ([PK_ReconcileIFRS17AccountingPeriodID] ASC) WITH (FILLFACTOR = 90)
);



