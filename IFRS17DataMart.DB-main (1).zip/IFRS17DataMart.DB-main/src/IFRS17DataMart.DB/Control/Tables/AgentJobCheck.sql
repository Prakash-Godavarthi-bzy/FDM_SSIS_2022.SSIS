﻿CREATE TABLE [Control].[AgentJobCheck] (
    [Id]        INT           IDENTITY (1, 1) NOT NULL,
    [JobName]   VARCHAR (255) NULL,
    [JobStatus] VARCHAR (255) NULL
);

