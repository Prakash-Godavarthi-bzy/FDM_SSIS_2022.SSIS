﻿CREATE TABLE [Control].[ReconcileIFRS17AccountingPeriodDetail] (
    [PK_ReconcileIFRS17AccountingPeriodDetailID] INT              IDENTITY (1, 1) NOT NULL,
    [FK_ReconcileIFRS17AccountingPeriodID]       INT              NOT NULL,
    [FK_ReconcileDataStageID]                    INT              NOT NULL,
    [FK_ReconcileDimIFRS17DataStageTablesID]     INT              NOT NULL,
    [Entity]                                     VARCHAR (255)    NULL,
    [RI Flag]                                    VARCHAR (255)    NULL,
    [CCY Settlement]                             VARCHAR (255)    NULL,
    [Scenario]                                   VARCHAR (255)    NULL,
    [Account]                                    VARCHAR (255)    NULL,
    [YoA]                                        VARCHAR (255)    NULL,
    [DataSet]                                    VARCHAR (255)    NULL,
    [SourceTotalValue]                           NUMERIC (38, 12) NULL,
    [TargetTotalValue]                           NUMERIC (38, 12) NULL,
    [AuditCreateDateTime]                        DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditCreateUser]                            NVARCHAR (510)   DEFAULT (suser_sname()) NOT NULL,
    [AccountingPeriodflag]                       INT              NULL,
    PRIMARY KEY CLUSTERED ([PK_ReconcileIFRS17AccountingPeriodDetailID] ASC) WITH (FILLFACTOR = 90)
);



