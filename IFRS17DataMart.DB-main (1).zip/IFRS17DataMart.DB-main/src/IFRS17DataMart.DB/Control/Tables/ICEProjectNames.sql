﻿CREATE TABLE [Control].[ICEProjectNames] (
    [id]             INT           IDENTITY (1, 1) NOT NULL,
    [IceProjectName] VARCHAR (255) NULL
);

