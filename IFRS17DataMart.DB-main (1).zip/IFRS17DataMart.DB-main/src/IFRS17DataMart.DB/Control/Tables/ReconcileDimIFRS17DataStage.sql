﻿CREATE TABLE [Control].[ReconcileDimIFRS17DataStage] (
    [PK_ReconcileDataStageID]        INT           NOT NULL,
    [ReconciliationStageDescription] VARCHAR (100) NULL,
    [AuditCreateDateTime]   DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditCreateUser]       NVARCHAR (510)   DEFAULT (suser_sname()) NOT NULL,
 
    PRIMARY KEY CLUSTERED ([PK_ReconcileDataStageID] ASC) WITH (FILLFACTOR = 90)
);

