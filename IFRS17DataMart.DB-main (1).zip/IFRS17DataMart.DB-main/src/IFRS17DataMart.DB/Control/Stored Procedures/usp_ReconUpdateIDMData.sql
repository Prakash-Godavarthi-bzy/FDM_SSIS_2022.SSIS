﻿

CREATE PROCEDURE [Control].usp_ReconUpdateIDMData(@AccPer INT,@AccPerID INT, @DataStageID INT, @DataStageTableID INT)
AS
BEGIN

DECLARE @DatastageTableName varchar(100);

SELECT @DatastageTableName = TargetTableName FROM Control.ReconcileDimIFRS17DataStageTables WHERE PK_ReconcileDimIFRS17DataStageTablesID = @DataStageTableID AND FK_ReconcileDataStageID = @DataStageID

IF @DatastageTableName = 'fct.PreProcessPremiumLTD' 
	BEGIN

	DROP TABLE IF EXISTS #TargetPremReconDataLTD
	SELECT FK_AccountingPeriod, FK_Entity, FK_Account, [RI Flag], Fk_dataset, FK_scenario, FK_YOA, CCYSettlement, ReconValue
	INTO #TargetPremReconDataLTD
	FROM
		(
		SELECT FK_AccountingPeriod, FK_Entity, FK_Account, [RI Flag], Fk_dataset, FK_scenario, FK_YOA, CCYSettlement, SUM([Value]) ReconValue
		FROM FCT.PremiumLatestValueWithOpenCloseFlag
		WHERE FK_AccountingPeriod = @AccPer
		GROUP BY  FK_AccountingPeriod, FK_Entity, FK_Account, [RI Flag], Fk_dataset, FK_scenario, FK_YOA, CCYSettlement
		UNION ALL
		SELECT FK_AccountingPeriod,FK_Entity, FK_Account, [RI Flag], Fk_dataset, FK_scenario, FK_YOA, CCYSettlement, SUM([Value]) ReconValue
		FROM FCT.PremiumLatestValueWithOpenCloseFlagNonPP
		WHERE FK_AccountingPeriod = @AccPer
		GROUP BY  FK_AccountingPeriod, FK_Entity, FK_Account, [RI Flag], Fk_dataset, FK_scenario, FK_YOA, CCYSettlement
		)A

	UPDATE T1
	SET T1.TargetTotalValue = T2.ReconValue
	FROM [CONTROL].ReconcileIFRS17AccountingPeriodDetail T1
	LEFT JOIN #TargetPremReconDataLTD T2 ON T1.Account = T2.FK_Account
									AND T1.Entity = T2.FK_Entity
									AND T1.DataSet = T2.Fk_dataset
									AND T1.[CCY Settlement] = T2.CCYSettlement
									AND T1.[RI Flag] = T2.[RI Flag]
									AND T1.Scenario = T2.FK_scenario
									AND T1.YoA = T2.FK_YOA
	WHERE T1.FK_ReconcileIFRS17AccountingPeriodID = @AccPerID 
	AND T1.FK_ReconcileDataStageID = @DataStageID
	AND T1.FK_ReconcileDimIFRS17DataStageTablesID = @DataStageTableID
	END

ELSE IF @DatastageTableName = 'fct.Aggr_NonPremiumLTD'
	BEGIN
	DROP TABLE IF EXISTS #TargetNonPremReconDataLTD
	SELECT AccountingPeriod, Entity, Account, [RI Flag], Dataset, Scenario, YOA, CCYSettlement, SUM([Value]) ReconValue
	INTO #TargetNonPremReconDataLTD
	FROM FCT.Aggr_NonPremiumLTD
	WHERE AccountingPeriod = @AccPer
	GROUP BY  AccountingPeriod, Entity, Account, [RI Flag], Dataset, Scenario, YOA, CCYSettlement


	UPDATE T1
	SET T1.TargetTotalValue = T2.ReconValue
	FROM [CONTROL].ReconcileIFRS17AccountingPeriodDetail T1
	LEFT JOIN #TargetNonPremReconDataLTD T2 ON T1.Account = T2.Account
									AND T1.Entity = T2.Entity
									AND T1.DataSet = T2.dataset
									AND T1.[CCY Settlement] = T2.CCYSettlement
									AND T1.[RI Flag] = T2.[RI Flag]
									AND T1.Scenario = T2.scenario
									AND T1.YoA = T2.YOA
	WHERE T1.FK_ReconcileIFRS17AccountingPeriodID = @AccPerID 
	AND T1.FK_ReconcileDataStageID = @DataStageID
	AND T1.FK_ReconcileDimIFRS17DataStageTablesID = @DataStageTableID
	END

ELSE 
	BEGIN
	DROP TABLE IF EXISTS #TargetPremReconDataDelta
	SELECT FK_AccountingPeriod, FK_Entity, FK_Account, Fk_dataset, FK_scenario, FK_YOA, CCYSettlement, ReconValue
	INTO #TargetPremReconDataDelta
	FROM
		(
		SELECT FK_AccountingPeriod, FK_Entity, FK_Account, Fk_dataset, FK_scenario, FK_YOA, FK_CCYSettlement AS CCYSettlement, SUM([Value]) ReconValue
		FROM stg.fct_TechnicalResult T1
		WHERE FK_AccountingPeriod = @AccPer
		GROUP BY  FK_AccountingPeriod, FK_Entity, FK_Account, Fk_dataset, FK_scenario, FK_YOA, FK_CCYSettlement
		)A

	UPDATE T1
	SET T1.TargetTotalValue = T2.ReconValue
	FROM [CONTROL].ReconcileIFRS17AccountingPeriodDetail T1
	LEFT JOIN #TargetPremReconDataDelta T2 ON T1.Account = T2.FK_Account
									AND T1.Entity = T2.FK_Entity
									AND T1.DataSet = T2.FK_dataset
									AND T1.[CCY Settlement] = T2.CCYSettlement
									AND T1.Scenario = T2.FK_scenario
									AND T1.YoA = T2.FK_YOA
	WHERE T1.FK_ReconcileIFRS17AccountingPeriodID = @AccPerID 
	AND T1.FK_ReconcileDataStageID = @DataStageID
	AND T1.FK_ReconcileDimIFRS17DataStageTablesID = @DataStageTableID
	END

END