﻿-- =============================================
-- Author:		<Sainath Murali Pendyala>
-- Create date: <19/01/2024>
-- Description:	<User defined table valued function which takes Run ID as an input and return dataset id's for future period assumptions>
-- =============================================
CREATE FUNCTION [rpt].[udf_AssumptionsFuturePeriodDatasets]
(
	@RunID	INT
)
RETURNS
@FuturePeriodAssumptions		TABLE
(
	[NextReportingPeriod]		VARCHAR(6)	,
	[AssumptionPrecentType]		VARCHAR(50)	,
	[AssumptionDatasetID]		VARCHAR(100)
)
BEGIN

		DECLARE	@NextQtr  VARCHAR(6)

		SELECT	@NextQtr = CAST
								(
									IIF	
										(	
											CAST([Reporting Period]	AS	INT)%100 >	9,
											CAST([Reporting Period]		AS		INT)	+	91,
											CAST([Reporting Period]		AS		INT)	+	3
										)
									AS VARCHAR(6)
								)
		FROM	[rpt].[vw_bm_dimRun]
		WHERE	[PK_RunID]		IN		(@RunID)

		INSERT	INTO	@FuturePeriodAssumptions

				SELECT  CASE	
							WHEN SUBSTRING(REPLACE([SourceFilename],' ',''),5,2)	=	'Q1'
									THEN	LEFT(REPLACE([SourceFilename],' ',''),4)	+	'03'
							WHEN SUBSTRING(REPLACE([SourceFilename],' ',''),5,2)	=	'Q2'
									THEN	LEFT(REPLACE([SourceFilename],' ',''),4)	+	'06'
							WHEN SUBSTRING(REPLACE([SourceFilename],' ',''),5,2)	=	'Q3'
									THEN	LEFT(REPLACE([SourceFilename],' ',''),4)	+	'09'
							WHEN SUBSTRING(REPLACE([SourceFilename],' ',''),5,2)	=	'Q4'
									THEN	LEFT(REPLACE([SourceFilename],' ',''),4)	+	'12'	
						END		AS		[NextReportingPeriod],
						[AssumptionPrecentType],
						MAX([AssumptionDatasetID])	AS		[AssumptionDatasetID]
				FROM	[PWAPS].[DownloadTemplate]
				WHERE	REPLACE([SourceFilename],' ','')	LIKE	'20%'
				AND		SUBSTRING(REPLACE([SourceFilename],' ',''),5,2)	IN	('Q1','Q2','Q3','Q4')
				AND		CASE
							WHEN SUBSTRING(REPLACE([SourceFilename],' ',''),5,2)	=	'Q1'
									THEN	LEFT(REPLACE([SourceFilename],' ',''),4)	+	'03'
							WHEN SUBSTRING(REPLACE([SourceFilename],' ',''),5,2)	=	'Q2'
									THEN	LEFT(REPLACE([SourceFilename],' ',''),4)	+	'06'
							WHEN SUBSTRING(REPLACE([SourceFilename],' ',''),5,2)	=	'Q3'
									THEN	LEFT(REPLACE([SourceFilename],' ',''),4)	+	'09'
							WHEN SUBSTRING(REPLACE([SourceFilename],' ',''),5,2)	=	'Q4'
									THEN	LEFT(REPLACE([SourceFilename],' ',''),4)	+	'12'
						END		IN		(@NextQtr)
				GROUP BY
						CASE
							WHEN SUBSTRING(REPLACE([SourceFilename],' ',''),5,2)	=	'Q1'
									THEN	LEFT(REPLACE([SourceFilename],' ',''),4)	+	'03'
							WHEN SUBSTRING(REPLACE([SourceFilename],' ',''),5,2)	=	'Q2'
									THEN	LEFT(REPLACE([SourceFilename],' ',''),4)	+	'06'
							WHEN SUBSTRING(REPLACE([SourceFilename],' ',''),5,2)	=	'Q3'
									THEN	LEFT(REPLACE([SourceFilename],' ',''),4)	+	'09'
							WHEN SUBSTRING(REPLACE([SourceFilename],' ',''),5,2)	=	'Q4'
									THEN	LEFT(REPLACE([SourceFilename],' ',''),4)	+	'12'
						END,
						[AssumptionPrecentType]
	
RETURN 
END