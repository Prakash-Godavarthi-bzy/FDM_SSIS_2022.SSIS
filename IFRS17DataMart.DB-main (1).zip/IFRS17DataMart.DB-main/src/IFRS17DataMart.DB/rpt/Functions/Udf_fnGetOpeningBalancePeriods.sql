﻿
-- =============================================
-- Author:		< Sainath Murali Pendyala >
-- Create date: < 19/01/2024 >
-- Description:	< User defined table valued function which takes Run ID as an input and returns related Opening Balance ID's and their information >
-- =============================================

CREATE function [rpt].[Udf_fnGetOpeningBalancePeriods]
(
	@Runid		INT
)

RETURNS TABLE

AS

RETURN
		WITH CTE AS
					(
						SELECT		[Pk_RequestId],
									[Reporting Period]			AS		[ReportingPeriod],
									[Opening Balances Id]		AS		[OpeningBalanceID],
									[OB Reporting Period]		AS		[OpeningBalancePeriod]
						FROM		[PWAPS].[IFRS17CalcUI_RunLog]
						WHERE		[Pk_RequestId]					=				@Runid

						UNION ALL

						SELECT		F1.[Pk_RequestId],
									F1.[Reporting Period]		AS		[ReportingPeriod],
									F1.[Opening Balances Id]	AS		[OpeningBalanceID],
									F1.[OB Reporting Period]	AS		[OpeningBalancePeriod]
						FROM		[CTE] F
						JOIN		[PWAPS].[IFRS17CalcUI_RunLog] F1
						ON			[F].[OpeningBalanceID]			=				[F1].[Pk_RequestId]
					)

		SELECT		[Pk_RequestId],
					[ReportingPeriod],
					[OpeningBalanceID],
					[OpeningBalancePeriod]
		FROM		[CTE]