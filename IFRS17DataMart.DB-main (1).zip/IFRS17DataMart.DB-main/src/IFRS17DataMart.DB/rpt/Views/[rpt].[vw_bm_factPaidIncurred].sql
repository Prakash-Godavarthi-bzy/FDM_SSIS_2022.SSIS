﻿


CREATE View [rpt].[vw_bm_factPaidIncurred] As
	Select distinct A.RunID as FK_RunID,
		A.Entity AS FK_Entity,
		cast(A.[Tri focus code] as varchar(25)) as FK_Trifocus,
		T.[Focus Group] AS FK_FocusGroup,
		T.Division AS FK_Division ,
		A.Account,
		Ac.[Field Label] AS FK_AccountCode,
		A.Programme AS FK_Programme,
		A.RI_Flag as FK_RIFlag,
		OC.YOA AS FK_YOA,
		Case when Oc.[Open/Closed]='Open' then 'O'
		When OC.[Open/Closed]='Closed' then 'C'
		Else Oc.[Open/Closed]
				End FK_OpenCloseYOA,
		cast(A.YOI as varchar(15)) AS FK_YOI,
		cast(A.CCY as varchar(10)) AS FK_CCY,
		A.Loss_Type AS [FK_LossType],
		A.Amount as [Value]
From [IDS].[Aggr_Claims] A Inner join  IDS.TrifocusMapping T
 on A.RunID=T.RunID and A.[Tri focus code]=T.[Trifocus Code]
 Inner join IDS.Open_CloseYOA OC on A.RunId=OC.RunID and OC.YOA=A.YOA and OC.TrifocusCode=A.[Tri focus code] and OC.Programme=A.Programme
 Inner join IDS.AccountCodeMapping AC on A.RunID=Ac.RunID and AC.[Account Code]=A.Account

