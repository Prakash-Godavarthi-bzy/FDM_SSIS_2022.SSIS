﻿

CREATE VIEW  [rpt].[vw_bm_factCash]
AS
SELECT distinct T.[RunID] as FK_RunID 
      ,[Entity] as FK_Entity
      ,cast([Tri focus code] as varchar(25)) as FK_Trifocus 
	  ,T1.[Focus Group] as FK_FocusGroup
	  ,T1.Division as FK_Division
	  ,cast([IFRS17 TrifocusCode] as varchar(25)) as FK_IFRS17TriFocusCode
      ,[Account]
	  ,T2.[Field Label] as FK_AccountCode
      ,T.[Programme] as FK_Programme
      ,[RI_Flag] as FK_RIFlag
      ,T.[YOA] as FK_YOA
	  ,CASE TRIM(T3.[Open/Closed])
				      WHEN 'Open'  Then 'O'
				      WHEN 'Closed' THEN 'C' 
				      ELSE T3.[Open/Closed] 
				END FK_OpenCloseYOA
      ,Cast(YOI as varchar(15)) as FK_YOI
      ,cast([CCY]  as varchar(10)) as FK_CCY
      ,[Amount] as [Value]
      
FROM [IDS].[Aggr_CashExcludingClaims] T
Inner join IDS.TrifocusMapping T1 on T1.[Trifocus Code]=T.[Tri focus code] and T1.RunID=T.RunID 
Inner join IDS.AccountCodeMapping T2 on T2.[Account Code]=T.Account and T2.RunID=T.RunID 
Inner join IDS.Open_CloseYOA T3 on T3.YOA=T.YOA  and T3.RunID=T.RunID And T3.Programme=T.Programme And T3.TrifocusCode=T.[Tri focus code]