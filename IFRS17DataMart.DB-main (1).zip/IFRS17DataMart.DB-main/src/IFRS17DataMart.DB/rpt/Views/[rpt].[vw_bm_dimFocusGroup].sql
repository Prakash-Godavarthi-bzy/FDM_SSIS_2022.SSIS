CREATE VIEW [rpt].[vw_bm_dimFocusGroup]
as
Select Distinct [Focus Group] As Pk_FocusGroup,[Focus Group] from IDS.TrifocusMapping
GO