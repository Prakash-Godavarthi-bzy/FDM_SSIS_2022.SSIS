﻿


CREATE view [rpt].[vw_bm_factNatCatEarningPatterns] as
SELECT distinct ep.RunID as FK_RunID,
	   ep.[Tri Focus Code] as FK_Trifocus,
	   tm.[Focus Group] as FK_FocusGroup
	   ,tm.Division as FK_Division,
	   'Nat Cat Earning Percentage' as FK_AccountCode,
	   ep.YOA as FK_YOA,
	   case when oc.[Open/Closed]='Open' then 'O' 
			when oc.[Open/Closed]='Closed' then 'C' 
			else oc.[Open/Closed] 
			end as FK_OpenCloseYOA,
		ep.Qtr as FK_EarningPeriod,
		ep.Perc as Value
FROM IDS.NatCat_EarningPatterns ep 
INNER JOIN IDS.TrifocusMapping tm on ep.RunID = tm.RunID and ep.[Tri Focus Code] = tm.[Trifocus Code]
INNER JOIN IDS.Open_CloseYOA oc on ep.RunID = oc.RunId and OC.YOA = ep.YOA And oc.Programme = 'Gross'


