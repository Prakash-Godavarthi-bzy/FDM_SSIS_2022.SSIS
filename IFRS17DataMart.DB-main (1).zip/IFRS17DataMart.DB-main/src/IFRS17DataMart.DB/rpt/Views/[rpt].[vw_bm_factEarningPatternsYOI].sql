﻿


CREATE View [rpt].[vw_bm_factEarningPatternsYOI]
AS
Select distinct EP.RunID as FK_RunID,
		EP.[Tri Focus Code] as FK_Trifocus,
		T.[Focus Group] as FK_FocusGroup,
		T.Division as FK_Division,
		'Earning Pattern YOI' As FK_AccountCode,
		EP.Programme as FK_Programme,
		Case When Ep.RI_Flag='G' then 'I'
			 When EP.RI_Flag='R' Then 'O'
			 Else EP.RI_Flag
			 End FK_RIFlag,
			 OC.YOA AS FK_YOA,
			 Case when Oc.[Open/Closed]='Open' then 'O' 
		  When OC.[Open/Closed]='Closed' then 'C'
		  Else Oc.[Open/Closed]
		  End FK_OpenCloseYOA,
		 cast(EP.YOI as varchar(15))as FK_YOI,
	   cast(EP.CCY as varchar(10)) as FK_CCY ,
		  EP.Qtr as FK_EarningPeriod,
		  EP.Perc as value
From  IDS.EarningPatterns EP  Inner join  IDS.TrifocusMapping T
 on EP.RunID=T.RunID and EP.[Tri Focus Code]=T.[Trifocus Code]
  Inner join IDS.Open_CloseYOA OC on EP.RunId=OC.RunID and OC.YOA=EP.YOA and OC.TrifocusCode=EP.[Tri focus code] and OC.Programme=EP.Programme
  