﻿



CREATE View [rpt].[vw_bm_factAssumptions]  
As
SELECT
Distinct [AP].[DatasetNameId] AS [FK_AssumptionDataSetNameID]
,Ap.Entity As FK_Entity,
ISNULL(T.[Trifocus Code],ISNULL(AP.[PK_TriFocus_4], 'NA')) AS FK_Trifocus,
ISNULL(T.[Focus Group],ISNULL(AP.[Focus Group],'NA')) AS FK_FocusGroup,
ISNULL(T.Division,ISNULL(FG.[Division],'NA')) as FK_Division,
APT.AssumptionPercentageType AS FK_AccountCode,
AP.RIProgramme As FK_Programme,
CASE WHEN Ap.RIFlag='G' then 'I'
WHEN AP.RIFlag='R' then 'O'
WHEN AP.[RIFlag] IS NULL THEN 'NA'
ELSE AP.RIFlag
End FK_RIFlag,
ISNULL(AP.PK_YOA_3,9999) AS FK_YOA,
CASE WHEN OC.[Open/Closed]='Open' then 'O'
When OC.[Open/Closed]='Closed' then 'C'
WHEN Oc.[Open/Closed] IS NULL THEN 'NA'
End FK_OpenCloseYOA,
CASE WHEN AP.LossType='LL' THEN 'L'
WHEN AP.[LossType] IS NULL THEN 'NA'
ELSE Ap.LossType
END FK_LossType,
CASE WHEN Ap.Quarters='AD' THEN 'T'
ELSE 'P'
End FK_UltimatesSource,
AP.GeneralPercent_0 As [Value]
FROM [IDS].[AssumptionPercentages] AP
INNER JOIN [Dim].[AssumptionPercentageType] APT
ON [APT].[Pk_AssumptionPercentageTypeId] = [AP].[PercentageTypeId]
LEFT JOIN IDS.TrifocusMapping T
ON AP.Pk_RequestId=T.RunID And Ap.PK_TriFocus_4=T.[Trifocus Code]
LEFT JOIN
(SELECT DISTINCT [Focus Group],[Division],[RunID] FROM IDS.TrifocusMapping) FG
ON AP.Pk_RequestId = FG.[RunID] AND AP.[Focus Group] = FG.[Focus Group]
LEFT JOIN IDS.Open_CloseYOA OC
ON AP.Pk_RequestId=OC.RunID AND Ap.PK_YOA_3=OC.YOA AND Ap.RIProgramme=Oc.Programme AND OC.TrifocusCode=Ap.PK_TriFocus_4
INNER JOIN
( SELECT [AP].[DatasetNameId] AS [AssumptionSetID]
, MAX([AP].[Pk_RequestID]) AS [RunID]
FROM [IDS].[AssumptionPercentages] AP
--INNER JOIN [Dim].[AssumptionPercentageType] APT
--ON [APT].[Pk_AssumptionPercentageTypeId] = [AP].[PercentageTypeId]
--WHERE [APT].[AssumptionPercentageType] <> 'Ultimate Loss Ratios'
GROUP BY [AP].[DatasetNameId]
) Lat
ON Lat.AssumptionSetID=Ap.DatasetNameId and Lat.RunID=Ap.Pk_RequestId
WHERE APT.AssumptionPercentageType <> 'Ultimate Loss Ratios'