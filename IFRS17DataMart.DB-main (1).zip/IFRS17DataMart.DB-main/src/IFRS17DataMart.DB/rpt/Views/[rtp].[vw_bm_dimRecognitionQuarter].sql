
CREATE VIEW [rpt].[vw_bm_dimRecognitionQuarter] AS
With QTR AS 
(
 select DISTINCT Quarters FROM [IDS].AssumptionPercentages
),
QTR1 as
(
SELECT  case Quarters
 when 'SM' then 'SM'
 else 'Q'+cast(ROW_NUMBER () OVER (ORDER BY Quarters) as varchar(20)) end  AS Q,Quarters FROM QTR
)
Select Q as PK_RecognitionQuarter, case Quarters
                                     when 'SM' then 'Subsequent Measure'
									 else Quarters end as RecognitionQuarter From QTR1 GO