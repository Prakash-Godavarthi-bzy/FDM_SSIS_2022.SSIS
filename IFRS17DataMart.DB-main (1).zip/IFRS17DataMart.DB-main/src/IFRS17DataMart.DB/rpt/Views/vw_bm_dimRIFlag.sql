﻿


CREATE View [rpt].[vw_bm_dimRIFlag] as
Select 'I' as RIFlagCode,'Inwards' as RIFlag
UNION
Select 'O' as RIFlagCode,'Outwards' as RIFlag
UNION
Select 'N' as RIFlagCode,'Net' as RIFlag
UNION
Select 'U' as RIFlagCode,'Unknown ' as RIFlag
GO