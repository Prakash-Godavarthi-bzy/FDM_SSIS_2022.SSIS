﻿
CREATE view [rpt].[vw_bm_dimTrifocus] 
as
select [Trifocus Code] as Pk_Trifocus,[Trifocus Code] as Trifocus,[Trifocus Name]  from 
(select [Trifocus Code]
,[Trifocus Name]
,ROW_NUMBER() over(partition by [trifocus code] order by T.AuditCreateDateTime DESC)  as RN
from IDS.TrifocusMapping T inner join PWAPS.IFRS17CalcUI_RunLog L
on T.RunID=L.Pk_RequestId
) a
where rn=1