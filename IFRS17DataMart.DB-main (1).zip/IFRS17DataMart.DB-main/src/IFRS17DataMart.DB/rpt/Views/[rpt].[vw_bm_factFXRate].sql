﻿


CREATE View [rpt].[vw_bm_factFXRate] As
SELECT distinct
[FX].[DatasetNameId] AS [FK_AssumptionDataSetNameID],
T.AssumptionPercentageType As [FK_AccountCode],
FX.ReportingCurrency As FK_ReportingCurrencyCode ,
cast(FX.TransactionCurrency as varchar(10)) As [FK_CCY],
FX.FXRate_0 As [Value]
FROM
[IDS].[FXRate] FX inner join Dim.AssumptionPercentageType T on Fx.PercentageTypeId=T.Pk_AssumptionPercentageTypeId
Inner join 
(SELECT [FX].[DatasetNameId] AS [AssumptionSetID]
, MAX([FX].[Pk_RequestID]) AS [RunID]
FROM
[IDS].[FXRate] FX
GROUP BY [FX].[DatasetNameId]) lat on lat.AssumptionSetID=FX.DatasetNameId and lat.RunID=FX.Pk_RequestId
--GO