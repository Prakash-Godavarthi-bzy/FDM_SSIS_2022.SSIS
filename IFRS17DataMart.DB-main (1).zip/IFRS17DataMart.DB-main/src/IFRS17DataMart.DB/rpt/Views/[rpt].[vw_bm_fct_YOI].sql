

create view [rpt].[vw_bm_fct_YOI]
as
select DISTINCT YOI from [IDS].[Aggr_PremiumBrokerage] where YOI is not null
union
select DISTINCT YOI from [IDS].[Aggr_ActurialUltimates] where YOI is not null
union
select DISTINCT YOI from [IDS].[Aggr_CashExcludingClaims] where YOI is not null
union
--select DISTINCT YOI from [fct].[EarningPattern] where YOI is not null
--UNION
Select Distinct YOI from IDS.Aggr_Claims where YOI is not null and YOI<>0
GO


