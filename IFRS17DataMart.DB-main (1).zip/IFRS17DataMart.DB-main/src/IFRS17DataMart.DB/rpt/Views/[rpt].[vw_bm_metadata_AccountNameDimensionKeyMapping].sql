Create view [rpt].[vw_bm_metadata_AccountNameDimensionKeyMapping]
As
SELECT  A.[Account],
		AD.[PKColumn], 
		REPLACE(AD.[PKColumn],'PK_','FK_') AS [FKColumn],
		AD.[DimensionTableName], AD.[KeyAttributeName], 
		AD.[Dimension],
		A.[AccountTableName]
	FROM 
	[rpt].[vw_bm_metadata_Account] A
	INNER JOIN [rpt].[vw_bm_metadata_AccountDimensionMapping] ADM
	ON A.[AccountTableName] = ADM.[AccountTableName]
	INNER JOIN [rpt].[vw_bm_metadata_Dimension] AD
	ON AD.[DimensionTableName] = ADM.[DimensionTableName]