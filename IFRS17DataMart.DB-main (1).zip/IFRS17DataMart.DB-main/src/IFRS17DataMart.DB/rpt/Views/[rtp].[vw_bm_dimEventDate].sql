﻿CREATE view [rpt].[vw_bm_dimEventDate]
As
SELECT  TOP (DATEDIFF(DAY,(Select Min(Eventdate) From IDS.Aggr_ActurialUltimates) , (Select Max(Eventdate) From IDS.Aggr_ActurialUltimates) + 1))
        EventDate = DATEADD(DAY, ROW_NUMBER() OVER(ORDER BY a.object_id) - 1,(Select Min(Eventdate) From IDS.Aggr_ActurialUltimates))
FROM    sys.all_objects a
        CROSS JOIN sys.all_objects b;