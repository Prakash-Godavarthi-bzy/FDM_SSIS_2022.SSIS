

CREATE VIEW [rpt].[vw_bm_dimEntity]
AS
Select Distinct Pk_Entity,Entity,EntityName,EntityLevel1,EntityLevel2,EntityLevel3,EntityLevel4,EntityLevel5
from Dim.Entity
UNION
SELECT EH.[PK_Entity]
, EH.[Entity]
, EH.[EntityName]
, EH.[EntityLevel1]
, EH.[EntityLevel2]
, EH.[EntityLevel3]
, EH.[EntityLevel4]
, EH.[EntityLevel5]
FROM [Dim].[Entity_History] EH
INNER JOIN
( SELECT [PK_Entity],MAX([ValidTo]) AS [ValidTo] FROM [Dim].[Entity_History] GROUP BY [PK_Entity]) LATEST
ON LATEST.[PK_Entity] = EH.[PK_Entity] AND LATEST.[ValidTo] = EH.[ValidTo]
LEFT JOIN [Dim].[Entity] E ON E.[PK_Entity] = EH.[PK_Entity]
WHERE E.[PK_Entity] IS NULL