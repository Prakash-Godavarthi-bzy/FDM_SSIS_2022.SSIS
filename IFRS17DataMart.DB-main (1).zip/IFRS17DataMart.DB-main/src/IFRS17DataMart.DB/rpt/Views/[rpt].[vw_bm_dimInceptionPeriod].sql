CREATE VIEW [rpt].[vw_bm_dimInceptionPeriod]
AS

With chk as
(
Select distinct YOI from IDS.Aggr_CashExcludingClaims where YOI is not null And YOI<>9999
union
Select YOI from IDS.Aggr_ActurialUltimates where YOI is not null and YOI<>9999
UNION
Select distinct YOI from IDs.Aggr_PremiumBrokerage where YOI is not null and YOI<>9999
union
Select Distinct YOI from IDS.Aggr_Claims Where YOI Is not null and YOI<>9999 and YOI<>0
UNION
Select Distinct YOI from IDS.EarningPatterns Where YOI is not null And YOI<>9999
UNION
Select Distinct (cast(year(QOI) as int)) From IDS.EarningPatterns Where QOI is not null and Cast(year(QOI) as int)<>9999

),dev as(
SELECT
DATEADD(dd, -1, DATEADD(mm, quarter * 3, year_date)) EndDate
--quarter QuarterNo
FROM
(
SELECT Concat(YOI,'01','01') year_date from chk
) s CROSS JOIN
(
SELECT 1 quarter UNION ALL
SELECT 2 UNION ALL
SELECT 3 UNION ALL
SELECT 4
) q

)
select convert(varchar, EndDate, 106) as PK_YOI,year(EndDate) as YOI,convert(varchar, EndDate, 106) as QOI from dev
GO



