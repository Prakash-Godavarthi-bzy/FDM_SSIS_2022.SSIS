﻿

CREATE VIew [rpt].[vw_bm_dimAccount]
As 
Select 'PREM_NONBINDER'  As PK_AccountCode,'Gross Premium Policy' As AccountName,'Premium Brokerage' As  AccountSource,'[rpt].[vw_bm_factPremiumBrokerage]' As AccountTableName
UNION ALL
Select 'PREM_TEAM' As PK_AccountCode,'Gross Premium Ultimate Policy' As AccountName,'Premium Brokerage'As AccountSource,'[rpt].[vw_bm_factPremiumBrokerage]' As AccountTableName
UNION ALL
Select 'PREM_BINDER' As PK_Accountcode,'Gross Premium Binder Adjusted' As AccountName,'Premium Brokerage' As AccountSource,'[rpt].[vw_bm_factPremiumBrokerage]' As AccountTableName
UNION ALL
Select 'PREM_BINDER_UNCAPPED' As PK_AccountCode,'Gross Premium Binder Adjusted' As AccountName,'Premium Brokerage' As AccountSource,'[rpt].[vw_bm_factPremiumBrokerage]' As AccountTableName
UNION ALL
Select 'BKG_NONBINDER' As PK_AccountCode,'Brokerage Policy' As AccountName,'Premium Brokerage' As AccountSource,'[rpt].[vw_bm_factPremiumBrokerage]' As AccountTableName
UNION ALL
Select 'BKG_BINDER' As PK_AccountCode,'Brokerage Binder Adjusted' As AccountName,'Premium Brokerage' As AccountSource,'[rpt].[vw_bm_factPremiumBrokerage]' As AccountTableName
UNION ALL
Select 'RIP_NONBINDER'As PK_AccountCode,'Reinstatement Premium Policy' As AccountName,'Premium Brokerage' As AccountSource,'[rpt].[vw_bm_factPremiumBrokerage]' As AccountTableName
UNION ALL
Select 'FSC_PREM' As PK_AccountCode,'Gross Premium_Future Service' As AccountName,'Premium Brokerage' As AccountSource,'[rpt].[vw_bm_factPremiumBrokerage]' As AccountTableName
UNION ALL
Select 'FSC_BKG' As Pk_AccountCode,'Brokerage_Future Service' As AccountName,'Premium Brokerage' As AccountSource,'[rpt].[vw_bm_factPremiumBrokerage]' As AccountTableName
UNION ALL
Select 'FSC_RIP' As PK_AccountCode,'Reinstatement Premium_Future Service' As AccountName,'Premium Brokerage' AS AccountSource,'[rpt].[vw_bm_factPremiumBrokerage]' As AccountTableName
UNION ALL
Select 'PREM_CASH' As PK_AccountCode,'Gross Premium Cash' As AccountName,'Cash' As AccountSource,'[rpt].[vw_bm_factCash]' As AccountTableName
UNION ALL
Select 'BKG_CASH' AS PK_AccountCode,'Brokerage Cash' As AccountName,'Cash' As AccountSource,'[rpt].[vw_bm_factCash]' As AccountTableName
UNION ALL
Select 'PC_CASH' As PK_AccountCode,'Profit Commission Cash' As AccountName,'Cash' As AccountSource,'[rpt].[vw_bm_factCash]' As AccountTableName
UNION ALL
Select 'RIP_CASH' As PK_AccountCode,'Reinstatement Premium Cash' AS AccountName,'Cash' AS  AccountSource,'[rpt].[vw_bm_factCash]' As AccountTableName
UNION ALL
Select 'ADMIN_CASH' As PK_AccountCode,'Admin Expense (Premium related)' AS AccountNAme,'Cash' As AccountSource,'[rpt].[vw_bm_factCash]' As AccountTableName
UNION ALL
Select 'CHE_CASH' As PK_AccountCode,'Claims Handling Expense' As AccountNAme,'Cash'As AccountSource,'[rpt].[vw_bm_factCash]' As AccountTableName
UNION ALL
Select 'OAE_CASH' As PK_accountCode,'Other Acquisition Expense' As AccountName,'Cash' As AccountSource,'[rpt].[vw_bm_factCash]' As AccountTableName
UNION ALL
Select 'PAID_ATT' As PK_AccountCode,'Claims Paid' As AccountName,'Paid & Incurred' As AccountSource,'[rpt].[vw_bm_factPaidIncurred]' As AccountTableName
UNION ALL
Select 'PAID_LL' As PK_AccountCode,'Claims Paid' As AccountName,'Paid & Incurred' As Accountsource,'[rpt].[vw_bm_factPaidIncurred]' As AccountTableName
UNION ALL
Select 'ULT_PURE_LL' As PK_AccountCode,'Claims Ultimate' As AccountName,'Actuarial Ultimates' As AccountSource,'[rpt].[vw_bm_factActuarialUltimates]' As AccountTableName
UNION ALL
Select 'ULT_TEAM_LL' As PK_AccountCode,'Claims Ultimate' As AccountName,'Actuarial Ultimates' As AccountSource,'[rpt].[vw_bm_factActuarialUltimates]' As AccountTableName
UNION ALL
Select 'Earning Pattern YOI' As Pk_AccountCode,'Earning Pattern YOI' As AccountName,'Earnings Pattern YOI' As AccountSource,'[rpt].[vw_bm_factEarningPatternsYOI]' As AccountTableName
UNION ALL 
Select 'Earning Pattern QOI' As PK_AccountCode,'Earning Pattern QOI' As AccountName,'Earning Pattern QOI' As AccountSource,'[rpt].[vw_bm_factEarningPatternsQOI]' As AccountTableName
UNION ALL 
Select 'Nat Cat Earning Percentage' As Pk_AccountCode,'Nat Cat Earning Percentage' As AccountName,'NatCatEarningPatterns' As AccountSource,'[rpt].[vw_bm_factNatCatEarningPatterns]' As AccountTableName
UNION ALL
SELECT
AssumptionPercentageType AS [PK_AccountCode]
, AssumptionPercentageType AS [AccountName]
, CASE
WHEN [AssumptionPercentageType] IN ('Ultimate Loss Ratios') THEN 'ADM Ultimate Loss Ratios'
WHEN [AssumptionPercentageType] IN ('Discount Rate' )THEN 'Discount Rate'
WHEN [AssumptionPercentageType] IN ('FX Rate (Spot)','FX Rate (Average)') THEN 'FX Rate'
WHEN [AssumptionPercentageType] IN ('Payment Pattern (Premiums)','Payment Pattern (Claims)') THEN 'Payment Pattern'
WHEN [AssumptionPercentageType] IN ('Adjustments') then 'Adjustments'
ELSE 'Assumptions'
END AS 'AccountSource',
Case
WHEN [AssumptionPercentageType] IN ('Ultimate Loss Ratios') THEN '[rpt].[vw_bm_factADMUltimateLossRatios]'
WHEN [AssumptionPercentageType] IN ('Discount Rate' )THEN '[rpt].[vw_bm_factDiscountRates]'
WHEN [AssumptionPercentageType] IN ('FX Rate (Spot)','FX Rate (Average)') THEN '[rpt].[vw_bm_factFXRate]'
When  [AssumptionPercentageType] IN ('Payment Pattern (Premiums)','Payment Pattern (Claims)') THEN '[rpt].[vw_bm_factPaymentPattern]'
When [AssumptionPercentageType] IN ('Adjustments') THEN '[rpt].[vw_bm_factAdjustments]'
Else '[rpt].[vw_bm_factAssumptions]'
END As 'AccountTableName'
FROM [Dim].[AssumptionPercentageType]
GO


