Create view [rpt].[vw_bm_dimReportingCurrency] as 
select Distinct PK_ReportingCurrencyCode,ReportingCurrencyName 
from Dim.ReportingCurrency
UNION 
select PK_ReportingCurrencyCode,ReportingCurrencyName 
from [Dim].[ReportingCurrency_History]