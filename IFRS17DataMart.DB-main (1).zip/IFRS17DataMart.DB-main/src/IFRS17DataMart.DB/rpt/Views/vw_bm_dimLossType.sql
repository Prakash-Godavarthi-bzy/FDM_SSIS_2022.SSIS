﻿CREATE VIEW [rpt].[vw_bm_dimLossType]
AS
SELECT 'A' as PK_LossType, 'Attritional' as LossType
UNION
SELECT 'C' as PK_LossType, 'Cat Margin' as LossType 
UNION
SELECT 'L' as PK_LossType, 'Large Loss' as LossType