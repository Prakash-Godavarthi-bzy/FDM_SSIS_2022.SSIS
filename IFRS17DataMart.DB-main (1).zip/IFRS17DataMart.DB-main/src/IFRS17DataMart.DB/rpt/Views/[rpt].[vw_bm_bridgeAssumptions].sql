CREATE VIEW [rpt].[vw_bm_bridgeAssumptions] AS
with Cte AS(
SELECT Pk_RequestId,DatasetNameId FROM IDS.AssumptionPercentages
UNION
SELECT  Pk_RequestId,DatasetNameId FROM IDS.DiscountRate 
UNION
SELECT Pk_RequestId,DatasetNameId FROM IDS.FXRate 
UNION
Select Pk_RequestId,DatasetNameId from IDs.PaymentPattern
), dev AS
(
SELECT Pk_RequestId AS FK_RunID,DatasetNameId AS FK_AssumptionDataSetNameID FROM Cte C 
)
SELECT DISTINCT FK_RunID,FK_AssumptionDataSetNameID FROM dev
GO