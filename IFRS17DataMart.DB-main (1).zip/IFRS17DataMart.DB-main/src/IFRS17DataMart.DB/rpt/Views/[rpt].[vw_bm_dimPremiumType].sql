Create view [rpt].[vw_bm_dimPremiumType] 
As
(
SELECT 
      Distinct [Premtype] As PK_PremiumType, Premtype As PremiumType  
  FROM [IDS].[Aggr_PremiumBrokerage]
  )
GO


