﻿CREATE view  [rpt].[vw_bm_dimSource] 
As 
Select  Distinct Source As PK_Source,Source from IDS.fct_Adjustment
UNION
Select 'B' As Source,'B' As Source
UNION
Select 'U' AS Source,'U' AS Source