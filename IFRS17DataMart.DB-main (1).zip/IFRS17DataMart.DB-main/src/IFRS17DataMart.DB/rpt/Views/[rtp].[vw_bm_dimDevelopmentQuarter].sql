
CREATE VIEW [rpt].[vw_bm_dimDevelopmentQuarter] As
With DevYear AS 
(
Select ROW_NUMBER () OVER (ORDER BY DevelopmentQuarter) AS Number from [IDS].[PaymentPattern]
--where Number<=(Select max(DevelopmentQuarter) from Ids.PaymentPattern)
),
DevYear1 as
(
Select Distinct P.DevelopmentQuarter,C.Number as PK_DevelopmentQuarter    from  DevYear C left join [IDS].[PaymentPattern] P
On C.Number=P.DevelopmentQuarter  where   C.Number <=(select Max(DevelopmentQuarter) from [IDS].[PaymentPattern]) order by  P.DevelopmentQuarter Asc offset 0 rows
)
Select  PK_DevelopmentQuarter,'Q ' + cast(DevelopmentQuarter as varchar(25)) as DevelopmentQuarter From DevYear1
GO
