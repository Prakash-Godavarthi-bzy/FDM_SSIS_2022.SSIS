CREATE VIEW [rpt].[vw_bm_factAdjustments]
As
Select FA.DatasetNameId As FK_AssumptionDataSetNameID
      ,[Adjustment ID]
      ,'Adjustemnets' as FK_AccountCode
      ,[Account]
      ,[Gross_RI Flag] As [FK_RIFlag]
      ,[Currency] As FK_CCY
      ,[Entity] As FK_Entity
      ,[Trifocus] As FK_Trifocus
      ,[Programme] As [FK_Programme]
      ,[YOA] As [FK_YOA]
      ,[Source] As FK_Source
      ,[Amount] As Value
      ,[Earned %] as  Value2
      ,[Inception Date]
      ,[Narrative] from IDS.fct_Adjustment  FA
      Inner join (SELECT [DR].[DatasetNameId] AS [AssumptionSetID], MAX([DR].RunID) AS [RunID] FROM[IDS].[fct_Adjustment] DR
        GROUP BY [DR].[DatasetNameId]) lat on lat.AssumptionSetID=FA.DatasetNameId And lat.RunID=FA.RunID
      Union All
      Select  FA1.DatasetNameId  AS FK_AssumptionDataSetNameID
            ,[Adjustment ID]
       ,'Adjustemnets' as FK_AccountCode
      ,[Account]
      ,[Gross_RI Flag] as [FK_RIFlag]
      ,[Currency] As FK_CCY
      ,[Entity] As FK_Entity
      ,[Trifocus] As FK_Trifocus
      ,[Programme] As FK_Programme
      ,[YOA]As FK_YOA
      ,[Source] As FK_Source
      ,Amount As Value
      ,[Earned %] As Value2
      ,[Inception Date]
      ,[Narrative] from IDS.fct_Adjustment FA1
       Inner join (SELECT [DR1].[DatasetNameId] AS [AssumptionSetID],
                            MAX([DR1].RunID) AS [RunID]
                            FROM [IDS].[fct_Adjustment] DR1
                                GROUP BY [DR1].[DatasetNameId]) lat on lat.AssumptionSetID=FA1.DatasetNameId And lat.RunID=FA1.RunID