Create View  [rpt].[vw_bm_dimAssumptionDataset] as
(
Select 
	   Pk_AssumptionDatasetNameId,
	   AssumptionDatasetName,
	   AssumptionDatasetDescription
from Dim.AssumptionDatasets 
)