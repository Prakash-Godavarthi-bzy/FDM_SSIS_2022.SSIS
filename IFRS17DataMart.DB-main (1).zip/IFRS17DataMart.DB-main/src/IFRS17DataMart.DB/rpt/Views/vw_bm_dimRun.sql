﻿
CREATE View   [rpt].[vw_bm_dimRun]  as 
Select pk_RequestId as PK_RunID,
		[Run Type],
		[Reporting Period],
		[Run Description],
		[FK_RuleSetID]
from 
[PWAPS].[IFRS17CalcUI_RunLog]