﻿

CREATE VIEW [rpt].[vw_bm_factPremiumBrokerage] As
SELECT distinct
A.RunID as FK_RunID ,
A.Entity as FK_Entity,
cast(A.[Tri focus code] as varchar(25)) as FK_Trifocus,
T.[Focus Group] as FK_FocusGroup,
T.Division as FK_Division,
cast(A.[IFRS17 Trifocus] as varchar(25)) as FK_IFRS17TriFocusCode,
A.Account,
Ac.[Field Label] as FK_AccountCode,
A.Programme as FK_Programme,
A.Premtype as FK_PremiumType,
A.RI_Flag as FK_RIFlag,
OC.YOA as FK_YOA,
OC.[Open/Closed] as FK_OpenCloseYOA,
cast(A.YOI as varchar(15))as FK_YOI,
A.RecognitionType as FK_RecognitionType,
cast(A.CCY as varchar(10))  as FK_CCY,
A.Amount as [Value]
From [IDS].[Aggr_PremiumBrokerage] A Inner join IDS.TrifocusMapping T
on A.RunID=T.RunID and A.[Tri focus code]=T.[Trifocus Code]
Inner join IDS.Open_CloseYOA OC on A.RunId=OC.RunID and OC.YOA=A.YOA and OC.TrifocusCode=A.[Tri focus code] and OC.Programme=A.Programme
Inner join IDS.AccountCodeMapping AC on A.RunID=Ac.RunID and AC.[Account Code]=A.Account