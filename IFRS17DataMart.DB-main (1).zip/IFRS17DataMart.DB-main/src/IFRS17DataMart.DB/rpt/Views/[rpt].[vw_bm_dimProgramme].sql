CREATE View  [rpt].[vw_bm_dimProgramme] as
Select Distinct Programme as Pk_Programme,Programme from IDS.Aggr_PremiumBrokerage where Programme is not null
UNION 
Select Distinct Programme as Pk_Programme,Programme From IDS.Aggr_ActurialUltimates  where Programme is not null
UNION 
Select Distinct Programme as Pk_Programme,Programme  From IDS.Aggr_Claims  where Programme is not null
UNION 
Select Distinct Programme as Pk_Programme,Programme  From IDS.Aggr_CashExcludingClaims  where Programme is not null
UNION 
Select Distinct RIProgramme as Pk_Programme,RIProgramme as Programme  From IDS.AssumptionPercentages  where RIProgramme is not null
--UNION 
--Select Distinct RiFlag as Pk_Programme, RIFlag AsProgramme  from IDS.PaymentPattern  where RIFlag is not null
UNION
Select Distinct Programme as Pk_Programme,Programme  From IDS.EarningPatterns  where Programme is not null
GO


