CREATE VIEW [rpt].[vw_bm_dimDivision]
as
SELECT  DISTINCT Division AS PK_Division,Division FROM [IDS].[TrifocusMapping] 
