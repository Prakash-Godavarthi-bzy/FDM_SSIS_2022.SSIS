﻿


CREATE VIEW [rpt].[vw_bm_factPaymentPattern] As
SELECT distinct [PP].[DatasetNameId] AS [FK_AssumptionDataSetNameID]
,T.AssumptionPercentageType As [FK_AccountCode],
Case when PP.RIFlag='G' then 'I'
     When pp.RIFlag='R' then 'O' 
	 Else PP.RIFlag
	 End [FK_RIFlag],

	 PP.DevelopmentQuarter As [FK_DevelopmentQuarter],
	 PP.PaymentPerc As [Value]
FROM
[IDS].[PaymentPattern] PP inner join Dim.AssumptionPercentageType T on PP.PercentageTypeId=T.Pk_AssumptionPercentageTypeId
Inner join
(SELECT [PP].[DatasetNameId] AS [AssumptionSetID]
, MAX([PP].[Pk_RequestID]) AS [RunID]
FROM
[IDS].[PaymentPattern] PP
GROUP BY [PP].[DatasetNameId])lat on lat.AssumptionSetID=pp.DatasetNameId and lat.RunID=pp.Pk_RequestId