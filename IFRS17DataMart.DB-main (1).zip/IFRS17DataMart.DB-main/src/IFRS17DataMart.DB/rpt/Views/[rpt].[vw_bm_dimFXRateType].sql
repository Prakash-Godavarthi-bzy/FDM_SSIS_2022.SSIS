

 Create VIEW [rpt].[vw_bm_dimFXRateType]
  AS 
  SELECT 'FXA' As Pk_FXRateType,'Average Rate' As FXRateType
  UNION
  Select 'FXS' As Pk_FXRateType,'Spot Rate' As FXRateType


