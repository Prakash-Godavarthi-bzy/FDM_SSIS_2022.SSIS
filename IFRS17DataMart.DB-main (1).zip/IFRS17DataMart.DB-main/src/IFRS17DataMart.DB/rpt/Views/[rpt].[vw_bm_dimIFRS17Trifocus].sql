﻿


CREATE VIEW [rpt].[vw_bm_dimIFRS17Trifocus]
AS
Select  Distinct IFRS17_Trifocus as PK_IFRS17TrifocusCode,
		IFRS17_Trifocus as IFRS17Trifcous
	From Dim.IFRS17_Trifocus
Union
SELECT Distinct TH.IFRS17_Trifocus as PK_IFRS17TrifocusCode,
	   TH.IFRS17_Trifocus as IFRS17Trifcous from Dim.IFRS17_Trifocus_History TH
	INNER JOIN
	( SELECT IFRS17_Trifocus,
			 MAX([ValidTo]) AS [ValidTo] 
			 FROM [Dim].IFRS17_Trifocus_History 
			 GROUP BY IFRS17_Trifocus) LATEST
			ON LATEST.IFRS17_Trifocus = TH.IFRS17_Trifocus 
			AND LATEST.[ValidTo] = TH.[ValidTo]
