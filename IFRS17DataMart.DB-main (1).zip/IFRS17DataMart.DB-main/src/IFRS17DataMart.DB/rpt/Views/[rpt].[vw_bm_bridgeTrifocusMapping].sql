

CREATE VIEW [rpt].[vw_bm_bridgeTrifocusMapping] 
AS
Select Distinct T.[Trifocus Code],T.[Trifocus Name] 
from IDS.TrifocusMapping T inner join PWAPS.IFRS17CalcUI_RunLog R
on T.RunID=R.Pk_RequestId
GO


