﻿Create View [rpt].[vw_bm_dimRecognitionType] As 
Select 'I' As Pk_RecognitionType,'Initial Recognition'  As RecognitionType 
UNION
Select 'SM' As Pk_RecognitionType,'Subsequent Measure'  As RecognitionType