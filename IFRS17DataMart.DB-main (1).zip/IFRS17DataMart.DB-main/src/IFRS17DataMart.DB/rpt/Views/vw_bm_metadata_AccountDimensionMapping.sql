﻿



  CREATE View 
  [rpt].[vw_bm_metadata_AccountDimensionMapping]
  As
 select   Concat(('[rpt].['+T.TABLE_NAME),']') As AccountTableName ,
			Case when C.COLUMN_NAME like '%RUNID' or C.COLUMN_NAME like  '%_RUNID' then '[rpt].[vw_bm_dimRun]'
				 when C.COLUMN_NAME like '%AssumptionDataSet%' then '[rpt].[vw_bm_dimAssumptionDataset]'
				 When C.COLUMN_NAME like '%Entity%' then '[rpt].[vw_bm_dimEntity]'
				 When C.COLUMN_NAME like '%IFRS17%Trifocus%' then '[rpt].[vw_bm_dimIFRS17Trifocus]'
				 When C.COLUMN_NAME like '%Trifocus%' then '[rpt].[vw_bm_dimTrifocus]'
				 When C.COLUMN_NAME like '%FocusGroup%' then '[rpt].[vw_bm_dimFocusGroup]'
				 When C.COLUMN_NAME like '%Division%' then '[rpt].[vw_bm_dimDivision]'
				 When C.COLUMN_NAME like '%Account%' then '[rpt].[vw_bm_dimAccount]'
				 when C.COLLATION_NAME like '%PremiumType%' Or C.COLUMN_NAME like '%_PremiumType%' then '[rpt].[vw_bm_dimPremiumType]'
				 when C.COLUMN_NAME like '%Programme%' then '[rpt].[vw_bm_dimProgramme]'
				 When C.COLUMN_NAME like '%RIFlag%' Or   C.COLUMN_NAME like '%RI_Flag%' then '[rpt].[vw_bm_dimRIFlag]'
				 When C.COLUMN_NAME ='FK_YOA' then '[rpt].[vw_bm_dimYOA]'
				 When C.COLLATION_NAME like '%OpenClose%' then '[rpt].[vw_bm_dimOpenCloseYOA]'
				 When C.COLUMN_NAME like '%YOI%' Or C.COLUMN_NAME like 'FK_YOI'  then '[rpt].[vw_bm_dimInceptionPeriod]'
				 When C.COLUMN_NAME like '%RecognitionType%' then '[rpt].[vw_bm_dimRecognitionType]'
				 when C.COLUMN_NAME like '%ReportingCCY%'   then '[rpt].[vw_bm_dimReportingCurrency]'
				 when C.COLUMN_NAME like '%CCY%'   then '[rpt].[vw_bm_dimCurrency]'
				 --When C.COLUMN_NAME like '%ReportingCurrency%' then '[rpt].[vw_bm_dimReportingCurrency]'
				 When C.COLUMN_NAME like '%LossType%' then '[rpt].[vw_bm_dimLossType]'
				 When C.COLUMN_NAME like '%EventDate%' then '[rpt].[vw_bm_dimEventDate]'
				 when C.COLUMN_NAME like '%UltimateSource%' then '[rpt].[vw_bm_dimUltimatesSource]'
				 When C.COLUMN_NAME like '%DevelopmentYear%' then '[rpt].[vw_bm_dimDevelopmentYear]'
				 When C.COLUMN_NAME like 'RecognitionQuarter' then '[rpt].[vw_bm_dimRecognitionQuarter]'
				 When C.COLUMN_NAME like '%DevelopmentQuarter%' then '[rpt].[vw_bm_dimDevelopmentQuarter]'
				 When C.COLUMN_NAME like '%Quarter%' then '[rpt].[vw_bm_dimQuarter]'
				 When C.COLUMN_NAME like 'FK_Source%' then '[rpt].[vw_bm_dimSource]'
				 when C.COLUMN_NAME like '%value' then T.TABLE_NAME
				 When C.COLUMN_NAME = 'FK_AssumptionDataSetID' Or C.COLUMN_NAME='FK_AssumptionSetID' then '[rpt].[vw_bm_bridgeAssumptions]'
				 When C.COLUMN_NAME = 'FK_OpenCloseYOA' then '[rpt].[vw_bm_dimOpenCloseYOA]'
				 Else C.COLUMN_NAME
				 End DimensionTableName
  from INFORMATION_SCHEMA.TABLES T
  inner join INFORMATION_SCHEMA.COLUMNS C on C.TABLE_NAME=T.TABLE_NAME
  where T.TABLE_SCHEMA='rpt' and T.TABLE_NAME   like 'vw_bm_fact%' and C.COLUMN_NAME<>'Value' And  C.COLUMN_NAME LIKE 'FK_%'
