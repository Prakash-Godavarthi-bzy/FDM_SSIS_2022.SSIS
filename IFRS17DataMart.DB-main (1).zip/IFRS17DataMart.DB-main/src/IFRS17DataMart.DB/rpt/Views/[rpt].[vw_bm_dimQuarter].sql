 CREATE VIEW [rpt].[vw_bm_dimQuarter] AS 
 With DevYear AS
(
select Qtr from IDS.EarningPatterns where (month(Qtr) in (3,12) And day(Qtr) not in (30)) --order by Qtr asc
union
select Qtr from IDS.EarningPatterns where (month(Qtr) in (06,09))
UNION
select Quarters from [IDS].[DiscountRate]



),
DevYear1 as
(
select convert(varchar(10), cast(Qtr as datetime), 105) PK_Quarter,
'Q'+cast((case month(qtr) when 3 then 1
when 6 then 2
when 9 then 3
when 12 then 4 end) as varchar(4))+'-' + cast(year(Qtr) as varchar(4)) Quarter , year(Qtr) Year from DevYear
)
select distinct PK_Quarter,Quarter,Year from DevYear1
GO