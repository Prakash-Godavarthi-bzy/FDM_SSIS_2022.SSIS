﻿

CREATE view [rpt].[vw_bm_factDiscountRates] as
SELECT distinct [DR].[DatasetNameId] AS FK_AssumptionDataSetNameID,
T.AssumptionPercentageType AS FK_AccountCode,
CAST(DR.Currency as varchar(10)) AS FK_CCY ,
DR.DevelopmentYear AS FK_DevelopmentYear,
DR.Quarters AS FK_Quarter,
DR.DiscountRt As Value
FROM
[IDS].[DiscountRate] DR inner join Dim.AssumptionPercentageType T on DR.PercentageTypeId=T.Pk_AssumptionPercentageTypeId
inner join (SELECT [DR].[DatasetNameId] AS [AssumptionSetID], MAX([DR].[Pk_RequestID]) AS [RunID] FROM[IDS].[DiscountRate] DR
GROUP BY [DR].[DatasetNameId]) lat on lat.AssumptionSetID=DR.DatasetNameId and lat.RunID=Dr.Pk_RequestId
GO