﻿

CREATE VIEW [rpt].[vw_bm_factADMUltimateLossRatios] 
AS
SELECT	distinct [AP].[DatasetNameId] AS FK_AssumptionDataSetNameID,
			Ap.Entity As  FK_Entity,
			AP.[PK_TriFocus_4] as FK_Trifocus,
			TM.[Focus Group] as FK_FocusGroup,
			TM.Division as FK_Division,
			'Ultimate Loss Ratios' as FK_AccountCode,
			 case [RIFlag] when 'G' then 'I'
						  when 'R' then 'O'
						 else [RIFlag]
						 end as FK_RIFlag,
			[PK_YOA_3] as FK_YOA,
			CASE OC.[Open/Closed] when 'Open' then 'O'
                        when 'Closed' then 'C'
						 end as FK_OpenCloseYOA,
			case LossType  when 'LL' then 'L'
                   else LossType 
				   end as FK_LossType,
			case AP.Quarters when 'AD' then 'T'
                  else 'P'
				  end as FK_UltimatesSource,
			AP.GeneralPercent_0 as Value
FROM
[IDS].[AssumptionPercentages] AP INNER JOIN [Dim].[AssumptionPercentageType] APT ON [APT].[Pk_AssumptionPercentageTypeId] = [AP].[PercentageTypeId]
INNER JOIN [IDS].[TrifocusMapping] TM ON AP.Pk_RequestId= TM.RunID And AP.PK_TriFocus_4=TM.[Trifocus Code]
INNER JOIN [IDS].[Open_CloseYOA] OC ON AP.Pk_RequestId = OC.RunId And AP.PK_YOA_3=OC.YOA And Oc.TrifocusCode=Ap.PK_TriFocus_4 And Oc.Programme='Gross'
INNER JOIN (SELECT [AP].[DatasetNameId] AS [AssumptionSetID]
					, MAX([AP].[Pk_RequestID]) AS [RunID]
				FROM   [IDS].[AssumptionPercentages] AP
				GROUP BY [AP].[DatasetNameId]) lat on lat.AssumptionSetID=Ap.DatasetNameId and lat.RunID=Ap.Pk_RequestId
WHERE [APT].[AssumptionPercentageType] = 'Ultimate Loss Ratios'

