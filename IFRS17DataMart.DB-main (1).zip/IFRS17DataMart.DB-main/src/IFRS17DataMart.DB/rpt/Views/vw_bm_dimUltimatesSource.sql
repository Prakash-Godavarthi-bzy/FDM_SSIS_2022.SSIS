﻿CREATE VIEW  [rpt].[vw_bm_dimUltimatesSource]
AS
SELECT 'P' as PK_UltimatesSource, 'Pure' as UltimateType
UNION
SELECT 'T' as UltimatesSource, 'Team' as UltimateType