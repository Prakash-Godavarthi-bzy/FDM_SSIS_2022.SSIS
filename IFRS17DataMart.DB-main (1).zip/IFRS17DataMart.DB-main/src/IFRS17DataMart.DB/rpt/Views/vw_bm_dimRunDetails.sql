﻿Create View   [rpt].[vw_bm_dimRunDetails]  as  
  SELECT FK_RunID,[Configuration],[value]
FROM
(
SELECT pk_RequestId AS FK_RunID, [Opening Balances Id],cast ([OB Reporting Period] as int ) As [OB Reporting Period]  FROM [PWAPS].[IFRS17CalcUI_RunLog]
) P
UNPIVOT
([value] FOR [Configuration] IN ([Opening Balances Id], [OB Reporting Period])
) AS T