 CREATE VIEW [rpt].[vw_bm_dimOpenCloseYOA]
  AS 
 SELECT 'O' as PK_OpenCloseYOA,'Open' as OpenCloseYOA
union
SELECT 'C' as PK_OpenCloseYOA,'Closed' as OpenCloseYOA