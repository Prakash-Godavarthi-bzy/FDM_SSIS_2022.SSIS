﻿

CREATE VIEW  [rpt].[vw_bm_factActuarialUltimates]
AS
SELECT  distinct T.RunID as FK_RunID, 
		Entity as FK_Entity, 
		cast([Tri focus code] as varchar(25)) as FK_Trifocus,
		T1.[Focus Group] as FK_FocusGroup, 
		T1.Division as FK_Division
		,Account,
		T2.[Field Label] as FK_AccountCode,
		T.Programme as FK_Programme,
		RI_Flag as FK_RIFlag,
		T.YOA as FK_YOA
		, CASE TRIM(T3.[Open/Closed])
				      WHEN 'Open'  Then 'O'
				      WHEN 'Closed' THEN 'C' 
				      ELSE T3.[Open/Closed] 
				END FK_OpenCloseYOA

		,Cast(YOI as varchar(15))as FK_YOI, 
		cast(CCY as varchar(10)) as FK_CCY,
		Loss_Type as FK_LossType, 
		isnull('01-Jan-1900',0) as FK_EventDate
		,T.[Type] as FK_UltimatesSource, 
		Amount as [Value]
FROM [IDS].[Aggr_ActurialUltimates] T
Inner join IDS.TrifocusMapping T1 on T1.[Trifocus Code]=T.[Tri focus code] and T1.RunID=T.RunID 
Inner join IDS.AccountCodeMapping T2 on T2.[Account Code]=T.Account and T2.RunID=T.RunID
Inner  join IDS.Open_CloseYOA T3 on T3.YOA=T.YOA  and T3.RunID=T.RunID And T3.Programme=T.Programme And T3.TrifocusCode=T.[Tri focus code]


