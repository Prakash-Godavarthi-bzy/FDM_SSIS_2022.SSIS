CREATE VIEW [rpt].[vw_bm_dimDevelopmentYear] As
With DevYear AS 
(
Select ROW_NUMBER () OVER (ORDER BY DevelopmentYear) AS Number from fct.DiscountRate
--where Number<=(Select max(DevelopmentQuarter) from Ids.PaymentPattern)
),
DevYear1 as
(
Select Distinct P.DevelopmentYear,C.Number as PK_DevelopmentYear    from  DevYear C left join fct.DiscountRate P
On C.Number=P.DevelopmentYear  where   C.Number <=(select Max(DevelopmentYear) from fct.DiscountRate) order by  P.DevelopmentYear Asc offset 0 rows
)
Select PK_DevelopmentYear, 'Year '+ CAST(DevelopmentYear as varchar(25)) as DevelopmentYear From DevYear1
GO

