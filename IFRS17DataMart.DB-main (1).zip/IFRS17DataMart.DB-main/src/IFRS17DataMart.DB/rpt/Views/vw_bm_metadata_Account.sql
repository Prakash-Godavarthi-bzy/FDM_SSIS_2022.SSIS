﻿
CREATE view [rpt].[vw_bm_metadata_Account]
 As
			 Select Distinct  AccountName As Account,
				AccountTableName
  From rpt.vw_bm_dimAccount