﻿CREATE View [rpt].[vw_bm_dimCurrency] As
(
Select Distinct [PK_CCY],[CCYName] As Currency
FROM [Dim].[CCY] where PK_CCY<>'' And CCYName<>''
)

