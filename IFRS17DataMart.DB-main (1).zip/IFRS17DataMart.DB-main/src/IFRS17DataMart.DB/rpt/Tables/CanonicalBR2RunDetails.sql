﻿CREATE TABLE [rpt].[CanonicalBR2RunDetails] (
    [ID]                  INT            IDENTITY (1, 1) NOT NULL,
    [RunID]               INT            NOT NULL,
    [ReportingPeriod]     INT            NOT NULL,
    [UserName]            VARCHAR (150)  NOT NULL,
    [RunStatus]           VARCHAR (15)   NOT NULL,
    [ICE Available]       VARCHAR (1)    NOT NULL,
    [CanonicalStatus]     VARCHAR (1)    NOT NULL,
    [AuditCreateDateTime] DATETIME2 (7)  DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]     NVARCHAR (510) DEFAULT (suser_name()) NOT NULL
);

