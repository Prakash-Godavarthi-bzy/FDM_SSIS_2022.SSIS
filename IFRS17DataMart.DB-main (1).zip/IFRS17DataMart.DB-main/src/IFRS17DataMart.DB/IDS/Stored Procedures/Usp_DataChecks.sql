﻿--USE [IFRS17DataMart]
--GO
--/****** Object:  StoredProcedure [IDS].[Usp_DataChecks]    Script Date: 09/02/2022 15:39:50 ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
--declare  @RunID INT = 3554, @DeleteExisting BIT = 0
CREATE PROCEDURE [IDS].[Usp_DataChecks] @RunID INT, @DeleteExisting BIT = 0
As
BEGIN

IF EXISTS (SELECT DISTINCT 1 FROM [IDS].[DataChecks] where [RunId] = @RunID)
	    BEGIN
	   -- Delete existing data for the current RunID
              DELETE FROM [IDS].[DataChecks] where [RunId] = @RunID
		END
		--Declare @RunID int=3554

DROP TABLE IF EXISTS #DistinctGrossList
	SELECT DISTINCT
		  RunID
		,  YOA
		, [Tri focus code]
		,Account
		,CONCAT(YOA,[Tri focus code]) TrifocusYOA
		,Sum(Amount) [VALUE]
	INTO #DistinctGrossList
	FROM [IDS].[Aggr_PremiumBrokerage]
	WHERE Account in ('P-GP-B','P-GP-P','P-AC-B','P-AC-P','P-BA-B','P-BP-B')
	AND RunID = @RunID 
	GROUP BY RunID 
	,YOA
	,[Tri focus code]
	,Account





DROP TABLE IF EXISTS #DistinctAssumptionList
	SELECT DISTINCT
		Pk_RequestId 
		,PercentageTypeId
		,PK_YOA_3
		,PK_TriFocus_4
		,RIFlag
		,ltrim(rtrim(Ap.AssumptionPercentageType)) As AssumptionPercentageType
		,CONCAT(PK_YOA_3 , PK_TriFocus_4) TrifocusYOA2
		,SUM(GeneralPercent_0) [VALUE]
	INTO #DistinctAssumptionList
	FROM [IDS].[Vw_AssumptionPercentages] VA
	LEFT JOIN Dim.AssumptionPercentageType Ap on VA.PercentageTypeId = Ap.Pk_AssumptionPercentageTypeId
	WHERE Pk_RequestId =  @RunID 
		And (ltrim(rtrim(Ap.AssumptionPercentageType)) in ('Ultimate Loss Ratios' ,'ENIDs (Unearned)','Profit Commissions'))
	GROUP BY Pk_RequestId 
	,PercentageTypeId
	,PK_YOA_3
	,PK_TriFocus_4
	,RIFlag
	,ltrim(rtrim(Ap.AssumptionPercentageType))



--RULE 1
--- DISTINCT ULR YOA-TRI LIST FROM ASSUMPTION IS THERE IN ABOVE TABLE OR VICE VERSA
Insert into IDS.Datachecks (RuleId ,RuleDescription,RunId,Trifocus ,YOA ,Account ,Amount )
	SELECT DISTINCT
        1 as RuleID
		,'Pure Ultimate Loss Ratios exist for all combinations (Trifocus-YOA) of Gross Premium' As RuleDescription
		,T1.RunID
		,T1.[Tri focus code]
		,T1.YOA
		,Null As Account
		,T1.[VALUE] As Amount

	FROM (Select RunId,YOA,[Tri focus code],TrifocusYOA,Sum([VALUE]) as [VALUE] From #DistinctGrossList Group by RunId,YOA,[Tri focus code],TrifocusYOA) T1
	LEFT JOIN (SELECT DISTINCT Pk_RequestId, PercentageTypeId , TrifocusYOA2 
			   FROM  #DistinctAssumptionList A
			   WHERE A.AssumptionPercentageType LIKE 'Ultimate Loss Ratios' And A.RIFlag='G' ) T2 ON T1.RunID = T2.Pk_RequestId AND T1.TrifocusYOA = T2.TrifocusYOA2
	WHERE 
	1 = 1
	AND T2.TrifocusYOA2 is null



---RULE 2
--DISTINCT ULR YOA-TRI-YOI  LIST FROM ASSUMPTION IS THERE IN ABOVE TABLE OR VICE VERSA
Insert into IDS.Datachecks (RuleId ,RuleDescription,RunId,Trifocus ,YOA,Account ,Amount )
	SELECT DISTINCT
		2 As RuleID
		,'Calculated (Trifocus-YOA)  Earning Pattern data exists for all combinations (Trifocus-YOA) of open year Gross Premium' As RuleDescription
		,T1.RunID
		,T1.[Tri focus code]
		,T1.YOA
		,Null As Account
		,T1.VALUE as Amount
	FROM(Select RunId,YOA,[Tri focus code],TrifocusYOA,Sum([VALUE]) as [VALUE] 
		 From #DistinctGrossList t1
		 Left join Dim.OpenCloseYOA t2 on t1.[Tri focus code] = t2.FK_Trifocus and t1.YOA = t2.FK_YOA
		 Where t2.Open_Cls_Flag = 'Open'
		 Group by RunId,YOA,[Tri focus code],TrifocusYOA) T1
	LEFT JOIN (SELECT DISTINCT Ep.RunID ,CONCAT(YOA , [Tri Focus Code]) TrifocusYOA2 
			   FROM  IDS.NatCat_EarningPatterns EP)  T2 ON T1.RunID = T2.RunID AND T1.TrifocusYOA = T2.TrifocusYOA2
	WHERE 
	1 = 1
	AND  T2.TrifocusYOA2 IS NULl




--RULE 3
---DISTINCT ULR YOA-TRI LIST FROM ASSUMPTION IS THERE IN ABOVE TABLE OR VICE VERSA
Insert into IDS.Datachecks (RuleId ,RuleDescription,RunId,Trifocus ,YOA,Account ,Amount )
SELECT DISTINCT
		3 As RuleID
		,'Unearned ENID %s exist for all combinations (Trifocus-YOA) of open year Gross Premium' AS RuleDescription
		,T1.RunID
		,T1.[Tri focus code]
		,T1.YOA
		,Null As Account 
		,T1.[VALUE] AS amount
	FROM (Select RunId,YOA,[Tri focus code],TrifocusYOA,Sum([VALUE]) as [VALUE] 		 
		  From #DistinctGrossList t1
		  Left join Dim.OpenCloseYOA t2 on t1.[Tri focus code] = t2.FK_Trifocus and t1.YOA = t2.FK_YOA
		  Where t2.Open_Cls_Flag = 'Open' 
		  Group by RunId,YOA,[Tri focus code],TrifocusYOA ) T1
	LEFT JOIN(SELECT DISTINCT Pk_RequestId, PercentageTypeId , TrifocusYOA2 
			   FROM  #DistinctAssumptionList A
			   WHERE A.AssumptionPercentageType LIKE  'ENIDs (Unearned)'  
						And A.RIFlag='G' )T2 ON T1.RunID = T2.Pk_RequestId AND T1.TrifocusYOA = T2.TrifocusYOA2
	WHERE 
	1 = 1 
	AND T2.TrifocusYOA2 IS NULL



--RULE 4
--DISTINCT aCCOUNT THAT WERE MISSED TYPE FROM ACCOUNT CODE MAPPING TABLE
Insert into IDS.Datachecks (RuleId ,RuleDescription,RunId,Trifocus ,YOA,Account  )
	SELECT DISTINCT 
			4 As RuleID
			,'Account Code Mapping is populated with Type for all account codes' As RuleDescription
			,T1.RUNID
			,Null AS [Tri focus code]
			,Null As YOA
			,T1.[Account Code]
	FROM IDS.AccountCodeMapping T1  
	WHERE 
	1 = 1
	AND T1.RunID = @RunID
	AND T1.[Type] IS NULL


---RULE 5
---DISTINCT % THAT ARE IN NOT IN 5-10 % RANGE FROM aSSUMPTION TABLE WHEN COMPARED WITH GROSS PREMIUM TABLE
Insert into IDS.Datachecks (RuleId ,RuleDescription,RunId,Trifocus ,YOA,Account ,Amount )
	SELECT DISTINCT
		5 As RuleID
		,'Profit Commission %s are reasonable within the range of 5-10%  for specific YOAs - last three' As RuleDescription
		,T1.Pk_RequestId As RunID
		,T1.Trifoucscode As [Tri focus code]
		,T1.PK_YOA_3 As YOA
		,Null As Account
		,T1.perc  As Amount
	FROM (SELECT DISTINCT T1.Pk_RequestId, T1.PK_YOA_3,T1.PK_TriFocus_4 as Trifoucscode,(T1.GeneralPercent_0 * 100) As  perc
		  FROM IDS.AssumptionPercentages T1
		  INNER JOIN Dim.AssumptionPercentageType T2 ON T1.PercentageTypeId = T2.Pk_AssumptionPercentageTypeId
		  LEFT JOIN PWAPS.IFRS17CalcUI_RunLog T3 ON T1.Pk_RequestId=T3.Pk_RequestId
		  WHERE 
		  1 = 1
		  AND T1.Pk_RequestId = @RunID
		  AND ltrim(rtrim(T2.AssumptionPercentageType)) like 'Profit Commissions' 
		  AND (T1.GeneralPercent_0 * 100) NOT BETWEEN 5 AND 10
		  AND T1.PK_YOA_3 BETWEEN (convert(int,SUBSTRING(T3.[Reporting Period],1,4)) - 2) AND convert(int,SUBSTRING(T3.[Reporting Period],1,4))
		  )T1


	
DROP TABLE IF EXISTS #DistinctGrossList
DROP TABLE IF EXISTS #DistinctAssumptionList

END
GO


