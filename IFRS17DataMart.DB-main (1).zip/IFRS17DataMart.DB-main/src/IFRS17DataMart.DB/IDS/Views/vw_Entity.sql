﻿
CREATE VIEW [IDS].[vw_Entity] AS
SELECT DISTINCT Entity FROM IDS.vw_balances