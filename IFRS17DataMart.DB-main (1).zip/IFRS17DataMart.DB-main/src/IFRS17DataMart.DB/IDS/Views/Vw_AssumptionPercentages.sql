﻿Create View IDS.Vw_AssumptionPercentages
as
SELECT [Pk_RequestId]
      ,[PK_YOA_3]
      ,[PK_TriFocus_4]
      ,[DatasetNameId]
      ,[PercentageTypeId]
	  ,D.AssumptionPercentageType
      ,[LossType]
      ,[RIFlag]
      ,[RIProgramme]
      ,[Quarters]
      ,[GeneralPercent_0]
      ,[Focus Group]
      ,[AuditCreateDateTime]
      ,[AuditUserCreate]
  FROM [IDS].[AssumptionPercentages] p inner join Dim.AssumptionPercentageType D 
  on P.PercentageTypeId=D.Pk_AssumptionPercentageTypeId