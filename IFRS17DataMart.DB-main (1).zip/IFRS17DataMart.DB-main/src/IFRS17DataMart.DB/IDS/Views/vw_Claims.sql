﻿CREATE VIEW [IDS].[vw_Claims]
AS
SELECT  AC.Type,AC.Source,AC.[Field Label],AU.* FROM IDS.Aggr_Claims AU 
INNER JOIN IDS.AccountCodeMapping AC
ON AC.RunID = AU.RunID AND AC.[Account Code] = AU.Account
GO
