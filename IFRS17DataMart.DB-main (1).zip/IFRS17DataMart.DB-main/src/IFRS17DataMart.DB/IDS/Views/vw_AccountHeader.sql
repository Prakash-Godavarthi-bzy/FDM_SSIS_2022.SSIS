﻿
CREATE VIEW [IDS].[vw_AccountHeader] AS
SELECT DISTINCT [Account] FROM IDS.vw_balances
GO
