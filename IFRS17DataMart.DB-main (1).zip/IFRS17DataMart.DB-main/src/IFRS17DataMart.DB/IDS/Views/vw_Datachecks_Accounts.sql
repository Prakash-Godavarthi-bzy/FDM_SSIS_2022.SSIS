﻿


CREATE VIEW [IDS].[vw_Datachecks_Accounts] AS
SELECT  

   AU.[CCY]
,  AU.[Entity]
,  AU.[RunID]
,  AU.[Tri focus code]
,  AU.[YOA]
,  'Paid Claims' AS [Account]
,  SUM([Amount]) AS [Amount]
FROM IDS.Aggr_Claims AU 
INNER JOIN IDS.AccountCodeMapping AC
ON AC.RunID = AU.RunID  
AND AC.[Account Code] = AU.Account
WHERE AC.[Field Label] IN ('PAID_ATT', 'PAID_LL')
GROUP BY 
AU.[CCY]
,  AU.[Entity]
,  AU.[RunID]
,  AU.[Tri focus code]
,  AU.[YOA]
UNION ALL
SELECT  

   AU.[CCY]
,  AU.[Entity]
,  AU.[RunID]
,  AU.[Tri focus code]
,  AU.[YOA]
,  'Claims Ultimate' AS [Account]
,  SUM([Amount]) AS [Amount]
FROM IDS.Aggr_ActurialUltimates AU 
INNER JOIN IDS.AccountCodeMapping AC
ON AC.RunID = AU.RunID  
AND AC.[Account Code] = AU.Account
WHERE AC.[Field Label] IN ('ULT_PURE_LL' , 'ULT_TEAM_LL')
GROUP BY 
AU.[CCY]
,  AU.[Entity]
,  AU.[RunID]
,  AU.[Tri focus code]
,  AU.[YOA]
UNION ALL

SELECT  

   AU.[CCY]
,  AU.[Entity]
,  AU.[RunID]
,  AU.[Tri focus code]
,  AU.[YOA]
,  CASE WHEN [Field Label] IN ('PREM_CASH') THEN 'Gross Premium Cash'
 WHEN [Field Label] IN ('BKG_CASH') THEN 'Brokerage Cash'
WHEN [Field Label] IN ('PC_CASH') THEN 'Profit Commission Cash' 
WHEN [Field Label] IN ('RIP_CASH') THEN 'Reinstatement Premium Cash'
WHEN [Field Label] IN ('ADMIN_CASH') THEN 'Admin Expense (premium related)'
WHEN [Field Label] IN ('CHE_CASH') THEN 'Claims Handling Expense'
WHEN [Field Label] IN ('OAE_CASH') THEN 'Other Acquisition Expense'
END

	AS [Account]
,  SUM([Amount]) AS [Amount]
FROM IDS.Aggr_CashExcludingClaims AU 
INNER JOIN IDS.AccountCodeMapping AC
ON AC.RunID = AU.RunID  
AND AC.[Account Code] = AU.Account
WHERE AC.[Field Label] IN ('PREM_CASH'
,'BKG_CASH'
,'PC_CASH'
,'RIP_CASH'
,'ADMIN_CASH'
,'CHE_CASH'
,'OAE_CASH'
)
GROUP BY 
AU.[CCY]
,  AU.[Entity]
,  AU.[RunID]
,  AU.[Tri focus code]
,  AU.[YOA]
,CASE WHEN [Field Label] IN ('PREM_CASH') THEN 'Gross Premium Cash'
 WHEN [Field Label] IN ('BKG_CASH') THEN 'Brokerage Cash'
WHEN [Field Label] IN ('PC_CASH') THEN 'Profit Commission Cash' 
WHEN [Field Label] IN ('RIP_CASH') THEN 'Reinstatement Premium Cash'
WHEN [Field Label] IN ('ADMIN_CASH') THEN 'Admin Expense (premium related)'
WHEN [Field Label] IN ('CHE_CASH') THEN 'Claims Handling Expense'
WHEN [Field Label] IN ('OAE_CASH') THEN 'Other Acquisition Expense'
END

UNION ALL

SELECT  

   AU.[CCY]
,  AU.[Entity]
,  AU.[RunID]
,  AU.[Tri focus code]
,  AU.[YOA]
,  CASE WHEN [Field Label] IN ('PREM_NONBINDER') THEN 'Gross Premium Policy'
WHEN [Field Label] IN ('PREM_TEAM') THEN 'Gross Premium Ultimate Policy'
WHEN [Field Label] IN ('PREM_BINDER', 'PREM_BINDER_UNCAPPED') THEN 'Gross Premium Binder Adjusted'
WHEN [Field Label] IN ('BKG_NONBINDER') THEN 'Brokerage Policy' 
WHEN [Field Label] IN ('BKG_BINDER') THEN 'Brokerage Binder Adjusted'
WHEN [Field Label] IN ('RIP_NONBINDER') THEN 'Reinstatement Premium Policy'
WHEN [Field Label] IN ('FSC_PREM') THEN 'Gross Premium_Future Service'
WHEN [Field Label] IN ('FSC_BKG') THEN 'Brokerage_Future Service'
WHEN [Field Label] IN ('FSC_RIP') THEN 'Reinstatement Premium_Future Service'
END

	AS [Account]
,  SUM([Amount]) AS [Amount]
FROM IDS.Aggr_PremiumBrokerage AU 
INNER JOIN IDS.AccountCodeMapping AC
ON AC.RunID = AU.RunID  
AND AC.[Account Code] = AU.Account
WHERE  AC.[Field Label] IN ('PREM_NONBINDER'
,'PREM_TEAM'
,'PREM_BINDER', 'PREM_BINDER_UNCAPPED'
,'BKG_NONBINDER'
,'BKG_BINDER'
,'RIP_NONBINDER'
,'FSC_PREM'
,'FSC_BKG'
,'FSC_RIP'
)
GROUP BY 
AU.[CCY]
,  AU.[Entity]
,  AU.[RunID]
,  AU.[Tri focus code]
,  AU.[YOA]
,  CASE WHEN [Field Label] IN ('PREM_NONBINDER') THEN 'Gross Premium Policy'
WHEN [Field Label] IN ('PREM_TEAM') THEN 'Gross Premium Ultimate Policy'
WHEN [Field Label] IN ('PREM_BINDER', 'PREM_BINDER_UNCAPPED') THEN 'Gross Premium Binder Adjusted'
WHEN [Field Label] IN ('BKG_NONBINDER') THEN 'Brokerage Policy' 
WHEN [Field Label] IN ('BKG_BINDER') THEN 'Brokerage Binder Adjusted'
WHEN [Field Label] IN ('RIP_NONBINDER') THEN 'Reinstatement Premium Policy'
WHEN [Field Label] IN ('FSC_PREM') THEN 'Gross Premium_Future Service'
WHEN [Field Label] IN ('FSC_BKG') THEN 'Brokerage_Future Service'
WHEN [Field Label] IN ('FSC_RIP') THEN 'Reinstatement Premium_Future Service'
END