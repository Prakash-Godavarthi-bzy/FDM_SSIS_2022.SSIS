﻿CREATE TABLE [IDS].[AttEarningOB] (
    [ID]                  INT              IDENTITY (1, 1) NOT NULL,
    [RunID]               INT              NOT NULL,
    [Pat_Type]            CHAR (1)         NOT NULL,
    [Tri focus code]      VARCHAR (25)     NOT NULL,
    [Programme]           VARCHAR (100)    NULL,
    [YOI]                 INT              NULL,
    [QOI]                 DATETIME         NULL,
    [CCY]                 VARCHAR (10)     NOT NULL,
    [Qtr]                 DATETIME         NULL,
    [Perc]                NUMERIC (38, 12) NOT NULL,
    [AuditCreateDateTime] DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]     NVARCHAR (510)   DEFAULT (suser_sname()) NOT NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);




GO
CREATE NONCLUSTERED INDEX [IX_AttEarningOB_RunID]
    ON [IDS].[AttEarningOB]([RunID] ASC, [Tri focus code] ASC) WITH (FILLFACTOR = 90);

