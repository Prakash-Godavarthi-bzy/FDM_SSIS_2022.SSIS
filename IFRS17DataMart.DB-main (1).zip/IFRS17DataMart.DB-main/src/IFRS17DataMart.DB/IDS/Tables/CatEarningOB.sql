﻿CREATE TABLE [IDS].[CatEarningOB] (
    [ID]                     INT              IDENTITY (1, 1) NOT NULL,
    [RunID]                  INT              NOT NULL,
    [Tri focus code]         VARCHAR (25)     NOT NULL,
    [YOA]                    INT              NOT NULL,
    [Open/Closed Derivation] VARCHAR (10)     NULL,
    [CCY]                    VARCHAR (10)     NOT NULL,
    [QOI_End_Date]           DATE             NULL,
    [Qtr]                    DATETIME         NULL,
    [YOI]                    INT              NULL,
    [Account]                VARCHAR (255)    NULL,
    [Amount_Cum]             NUMERIC (38, 12) NOT NULL,
    [AuditCreateDateTime]    DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]        NVARCHAR (510)   DEFAULT (suser_sname()) NOT NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);




GO
CREATE NONCLUSTERED INDEX [IX_CatEarningOB_RunID]
    ON [IDS].[CatEarningOB]([RunID] ASC, [Tri focus code] ASC) WITH (FILLFACTOR = 90);

