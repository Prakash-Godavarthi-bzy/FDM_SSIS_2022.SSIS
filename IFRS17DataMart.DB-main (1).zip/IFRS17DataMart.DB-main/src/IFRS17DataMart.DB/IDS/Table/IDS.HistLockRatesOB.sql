﻿CREATE TABLE [IDS].[HistLockRatesOB] (
    [ID]                  INT              IDENTITY (1, 1) NOT NULL,
    [RunID]               INT              NOT NULL,
    [YOI]                 INT              NULL,
    [Programme]           VARCHAR (100)    NULL,
    [FocusGroup]          VARCHAR (100)    NULL,
    [CCY]                 VARCHAR (10)     NOT NULL,
    [Qtr]                 INT              NULL,
    [Rate]                NUMERIC (38, 12) NOT NULL,
    [AuditCreateDateTime] DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]     NVARCHAR (510)   DEFAULT (suser_sname()) NOT NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);


GO
CREATE NONCLUSTERED INDEX [IX_HistLockRatesOB_RunID]
    ON [IDS].[HistLockRatesOB]([RunID] ASC) WITH (FILLFACTOR = 90);

