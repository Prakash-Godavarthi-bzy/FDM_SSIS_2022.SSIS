CREATE TABLE [IDS].[NatCat_EarningPatterns]
(
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[RunID] [int] NOT NULL,
	[Pat_Type] [char](1) NOT NULL,
	[Loss_Type] [char](1) NOT NULL,
	[Tri Focus Code] [varchar](25) NOT NULL,
	[YOA] [int] NULL,
	[Qtr] DATE NULL,
	[Perc] [decimal](38, 10) NOT NULL,
	[AuditCreateDateTime] [datetime2](7) NULL,
	[AuditUserCreate] [nvarchar](510) NULL,
	PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [IDS].[NatCat_EarningPatterns] ADD  DEFAULT (getdate()) FOR [AuditCreateDateTime]
GO

ALTER TABLE [IDS].[NatCat_EarningPatterns] ADD  DEFAULT (suser_sname()) FOR [AuditUserCreate]
GO



