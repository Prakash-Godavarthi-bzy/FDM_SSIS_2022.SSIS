﻿CREATE TABLE [IDS].[AssumptionPercentages] (
    [Pk_RequestId]        INT            NOT NULL,
    [PK_YOA_3]            NVARCHAR (10)  NULL,
    [PK_TriFocus_4]       NVARCHAR (25)  NULL,
    [DatasetNameId]       INT            NOT NULL,
    [PercentageTypeId]    INT            NOT NULL,
    [LossType]            NVARCHAR (10)  NULL,
    [RIFlag]              VARCHAR (2)    NULL,
    [RIProgramme]         VARCHAR (100)  NULL,
    [Quarters]            NVARCHAR (2)   NULL,
    [GeneralPercent_0]    NUMERIC (38, 12) NULL,
    [Focus Group]         VARCHAR (100)  NULL,
    [AuditCreateDateTime] DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditUserCreate]     NVARCHAR (510) DEFAULT (suser_sname()) NULL,
    [Entity]              VARCHAR (35)   NULL
);
GO

CREATE NONCLUSTERED INDEX [bzyidx_AssumptionPercentages_1]
    ON [IDS].[AssumptionPercentages]([Pk_RequestId] ASC) WITH (FILLFACTOR = 90);
GO

CREATE NONCLUSTERED INDEX [bzyidx_AssumptionPercentages_2]
    ON [IDS].[AssumptionPercentages]([DatasetNameId] ASC) WITH (FILLFACTOR = 90);
GO

CREATE NONCLUSTERED INDEX [bzyidx_AssumptionPercentages_3]
    ON [IDS].[AssumptionPercentages]([PercentageTypeId] ASC) WITH (FILLFACTOR = 90);
GO

CREATE NONCLUSTERED INDEX [bzyidx_AssumptionPercentages_4]
    ON [IDS].[AssumptionPercentages]([PK_TriFocus_4] ASC) WITH (FILLFACTOR = 90);
GO

CREATE NONCLUSTERED INDEX [bzyidx_AssumptionPercentages_Pk_RequestId_PK_TriFocus_4_RIProgramme]
    ON [IDS].[AssumptionPercentages]([DatasetNameId] ASC, [Pk_RequestId] ASC, [PercentageTypeId] ASC, [PK_TriFocus_4] ASC, [RIProgramme] ASC)
    INCLUDE([PK_YOA_3], [LossType], [RIFlag], [Quarters], [GeneralPercent_0], [Entity]) WITH (FILLFACTOR = 90);
GO

CREATE NONCLUSTERED INDEX [IX_AssumptionPercentages_DataSetName_PKRequestID_GeneralPercent]
    ON [IDS].[AssumptionPercentages]([DatasetNameId] ASC, [Pk_RequestId] ASC, [GeneralPercent_0] ASC, [PK_TriFocus_4] ASC, [PK_YOA_3] ASC, [PercentageTypeId] ASC, [Entity] ASC)
    INCLUDE([LossType], [RIFlag], [Quarters])
    ON [PRIMARY];
GO

CREATE NONCLUSTERED INDEX [IX_AssumptionPercentages_PK_RequestID_DatasetNameId_PercentageTypeID]
    ON [IDS].[AssumptionPercentages]([Pk_RequestId] ASC, [DatasetNameId] ASC, [PercentageTypeId] ASC, [PK_TriFocus_4] ASC, [Entity] ASC, [RIProgramme] ASC, [GeneralPercent_0] ASC)
    INCLUDE([PK_YOA_3], [LossType], [RIFlag], [Quarters], [Focus Group])
    ON [PRIMARY];
GO