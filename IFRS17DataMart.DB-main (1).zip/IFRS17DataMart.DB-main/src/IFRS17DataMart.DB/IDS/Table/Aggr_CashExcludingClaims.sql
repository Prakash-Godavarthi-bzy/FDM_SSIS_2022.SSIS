﻿CREATE TABLE [IDS].[Aggr_CashExcludingClaims] (
    [Id]                  BIGINT           IDENTITY (1, 1) NOT NULL,
    [RunID]               INT              NULL,
    [Entity]              VARCHAR (20)     NOT NULL,
    [Tri focus code]      VARCHAR (25)     NOT NULL,
    [IFRS17 TrifocusCode] VARCHAR (25)     NULL,
    [Account]             VARCHAR (15)     NOT NULL,
    [Programme]           VARCHAR (100)    NULL,
    [RI_Flag]             VARCHAR (2)      NULL,
    [YOA]                 INT              NOT NULL,
    [YOI]                 INT              NULL,
    [CCY]                 VARCHAR (10)         NOT NULL,
    [Amount]              NUMERIC (38, 10) NULL,
    [Adjust_Flag]         CHAR (1)         NULL,
    [AuditCreateDateTime] DATETIME2 (7)    NOT NULL,
    [AuditUserCreate]     NVARCHAR (510)   NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 90)
);
Go

CREATE NONCLUSTERED INDEX [bzyidx_Aggr_CashExcludingClaims_1]
    ON [IDS].[Aggr_CashExcludingClaims]([RunID] ASC)
    INCLUDE([Adjust_Flag]) WITH (FILLFACTOR = 90);
GO

GO
CREATE NONCLUSTERED INDEX [IX_Aggr_CashExcludingClaims_TriFocus_Code_RunID_Entity]
    ON [IDS].[Aggr_CashExcludingClaims]([Tri focus code] ASC, [RunID] ASC, [Entity] ASC, [IFRS17 TrifocusCode] ASC, [Account] ASC, [Programme] ASC, [RI_Flag] ASC, [YOA] ASC, [Amount] ASC)
    INCLUDE([Id], [YOI], [CCY])
    ON [PRIMARY];
GO



