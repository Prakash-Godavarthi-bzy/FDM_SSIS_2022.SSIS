﻿CREATE TABLE [IDS].[TrifocusMapping] (
    [Id]                  BIGINT         IDENTITY (1, 1) NOT NULL,
    [RunID]               INT            NOT NULL,
    [Trifocus Code]       VARCHAR (25)   NOT NULL,
    [Trifocus Name]       VARCHAR (60)   NULL,
    [Focus Group]         VARCHAR (100)  NULL,
    [Division]            VARCHAR (60)   NULL,
    [AuditCreateDateTime] DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditUserCreate]     NVARCHAR (510) DEFAULT (suser_sname()) NULL,
    [CM Earn]             VARCHAR (3)    NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 90)
);


GO
CREATE NONCLUSTERED INDEX [IX_TrifocusMapping_RunID_TrifocusCode_FocusGroup]
    ON [IDS].[TrifocusMapping]([RunID] ASC, [Trifocus Code] ASC, [Focus Group] ASC, [Division] ASC)
    INCLUDE([Id], [AuditCreateDateTime])
    ON [PRIMARY];
GO



