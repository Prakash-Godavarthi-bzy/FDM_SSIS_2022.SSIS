CREATE TABLE [IDS].[AssumptionOB] (
    [ID]                  INT              IDENTITY (1, 1) NOT NULL,
    [RunID]               INT              NOT NULL,
    [Entity]              VARCHAR (20)     NOT NULL,
    [Tri Focus Code]      VARCHAR (25)     NOT NULL,
    [Programme]           VARCHAR (100)    NULL,
    [RI_Flag]             VARCHAR (2)      NULL,
    [Assumption]          VARCHAR (15)     NOT NULL,
    [Loss_type]           VARCHAR (2)      NOT NULL,
    [YoA]                 INT              NULL,
    [Qtr]                 VARCHAR (2)      NOT NULL,
    [Perc]                NUMERIC (38, 12) NOT NULL,
    [AuditCreateDateTime] DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]     NVARCHAR (510)   DEFAULT (suser_sname()) NOT NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);







GO
CREATE NONCLUSTERED INDEX [IX_AssumptionOB_RunID]
    ON [IDS].[AssumptionOB]([RunID] ASC, [Entity] ASC, [Tri Focus Code] ASC) WITH (FILLFACTOR = 90);

