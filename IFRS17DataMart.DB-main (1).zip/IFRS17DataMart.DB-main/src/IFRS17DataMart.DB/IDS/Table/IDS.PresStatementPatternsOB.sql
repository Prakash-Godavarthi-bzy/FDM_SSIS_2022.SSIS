﻿CREATE TABLE [IDS].[PresStatementPatternsOB] (
    [ID]                    INT              IDENTITY (1, 1) NOT NULL,
    [RunID]                 INT              NOT NULL,
    [Entity]                VARCHAR (20)     NOT NULL,
    [Tri focus code]        VARCHAR (25)     NOT NULL,
    [IFRS17 Tri focus code] VARCHAR (25)     NULL,
    [Account]               VARCHAR (15)     NOT NULL,
    [Programme]             VARCHAR (100)    NULL,
    [RI_Flag]               VARCHAR (2)      NULL,
    [YOI]                   INT              NOT NULL,
    [CCY]                   VARCHAR (10)     NOT NULL,
    [Qtr]                   DATE             NULL,
    [Perc]                  NUMERIC (38, 12) NOT NULL,
    [AuditCreateDateTime]   DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]       NVARCHAR (510)   DEFAULT (suser_sname()) NOT NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);


GO
CREATE NONCLUSTERED INDEX [IX_PresStatementPatternsOB_RunID]
    ON [IDS].[PresStatementPatternsOB]([RunID] ASC, [Entity] ASC, [Tri focus code] ASC) WITH (FILLFACTOR = 90);

