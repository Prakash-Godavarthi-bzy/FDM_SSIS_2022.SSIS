﻿CREATE TABLE [IDS].[Aggr_Claims] (
    [Id]                  BIGINT           IDENTITY (1, 1) NOT NULL,
    [RunID]               INT              NULL,
    [Entity]              VARCHAR (20)     NOT NULL,
    [Tri focus code]      VARCHAR (25)     NOT NULL,
    [Account]             VARCHAR (15)     NOT NULL,
    [Programme]           VARCHAR (100)    NULL,
    [RI_Flag]             VARCHAR (2)      NULL,
    [Loss_Type]           CHAR (1)         NOT NULL,
    [YOA]                 INT              NOT NULL,
    [YOI]                 INT              NOT NULL,
    [CCY]                 VARCHAR (10)         NOT NULL,
    [Adjust_Flag]         CHAR (1)         NULL,
    [Amount]              NUMERIC (38, 10) NULL,
    [AuditCreateDateTime] DATETIME2 (7)    NOT NULL,
    [AuditUserCreate]     NVARCHAR (510)   NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 90)
);








GO
CREATE NONCLUSTERED INDEX [bzyidx_Aggr_Claims_1]
    ON [IDS].[Aggr_Claims]([RunID] ASC)
    INCLUDE([Adjust_Flag]) WITH (FILLFACTOR = 90);




GO
CREATE NONCLUSTERED INDEX [bzyidx_Aggr_Claims_2]
    ON [IDS].[Aggr_Claims]([YOI] ASC) WITH (FILLFACTOR = 90);

