﻿CREATE TABLE [IDS].[PremiumAdjustments] (
    [ID]                  INT              IDENTITY (1, 1) NOT NULL,
    [RunID]               INT              NOT NULL,
    [Entity]              VARCHAR (20)     NOT NULL,
    [Tri focus code]      VARCHAR (25)     NOT NULL,
    [IFRS17 TrifocusCode] VARCHAR (25)     NULL,
    [Account]             VARCHAR (15)     NOT NULL,
    [Programme]           VARCHAR (100)    NULL,
    [RI_Flag]             VARCHAR (2)      NULL,
    [YOA]                 INT              NOT NULL,
    [YOI]                 INT              NULL,
    [QOI_End_Date]        DATE             NULL,
    [RecognitionType]     CHAR (2)         NOT NULL,
    [CCY]                 VARCHAR (10)     NOT NULL,
    [Incepted Status]     CHAR (1)         NULL,
    [Open / Closed]       VARCHAR (10)     NULL,
    [Amount]              NUMERIC (38, 10) NULL,
    [AuditCreateDateTime] DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]     NVARCHAR (510)   DEFAULT (suser_sname()) NOT NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);


GO
CREATE NONCLUSTERED INDEX [IX_PremiumAdjustments_RunID]
    ON [IDS].[PremiumAdjustments]([RunID] ASC, [Entity] ASC, [Tri focus code] ASC) WITH (FILLFACTOR = 90);

