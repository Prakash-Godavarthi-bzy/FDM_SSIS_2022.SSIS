﻿CREATE TABLE [IDS].[Cashflow_Discount] (
    [ID]                  INT            IDENTITY (1, 1) NOT NULL,
    [Flag]                VARCHAR (99)   NULL,
    [Section]             VARCHAR (99)   NULL,
    [Parameter]           VARCHAR (99)   NULL,
    [Value]               VARCHAR (7000) NULL,
    [AuditCreateDateTime] DATETIME       DEFAULT (getdate()) NULL,
    [AuditUserCreate]     VARCHAR (255)  DEFAULT (suser_name()) NULL
);

