﻿CREATE TABLE [IDS].[EarningPatterns] (
    [ID]                  INT              IDENTITY (1, 1) NOT NULL,
    [RunID]               INT              NOT NULL,
    [Pat_Type]            CHAR (1)         NOT NULL,
    [Tri Focus Code]      VARCHAR (25)     NOT NULL,
    [Programme]           VARCHAR (100)    NULL,
    [RI_Flag]             VARCHAR (2)      NULL,
    [YOA]                 INT              NULL,
    [YOI]                 INT              NOT NULL,
    [QOI]                 DATE             NULL,
    [CCY]                 VARCHAR (10)      NOT NULL,
    [Qtr]                 DATE             NULL,
    [Perc]                DECIMAL (38, 10) NOT NULL,
    [AuditCreateDateTime] DATETIME2 (7)    DEFAULT (getdate()) NULL,
    [AuditUserCreate]     NVARCHAR (510)   DEFAULT (suser_sname()) NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);




GO
CREATE NONCLUSTERED INDEX [bzyidx_EarningPatterns_3]
    ON [IDS].[EarningPatterns]([YOI] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [bzyidx_EarningPatterns_2]
    ON [IDS].[EarningPatterns]([QOI] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [bzyidx_EarningPatterns_1]
    ON [IDS].[EarningPatterns]([RunID] ASC) WITH (FILLFACTOR = 90);

