﻿CREATE TABLE [IDS].[PaymentPattern] (
    [Pk_RequestId]        INT              NOT NULL,
    [DatasetNameId]       INT              NULL,
    [PercentageTypeId]    INT              NULL,
    [LossType]            VARCHAR (3)      NULL,
    [Trifocus]            VARCHAR (25)     NULL,
    [DevelopmentQuarter]  INT              NULL,
    [RIFlag]              VARCHAR (2)      NULL,
    [PaymentPerc]         DECIMAL (19, 10) NULL,
    [OBFlag ]             INT              NULL,
    [AuditCreateDateTime] DATETIME2 (7)    DEFAULT (getdate()) NULL,
    [AuditUserCreate]     NVARCHAR (510)   DEFAULT (suser_sname()) NULL
);
GO

CREATE NONCLUSTERED INDEX [bzyidx_PaymentPattern_1]
    ON [IDS].[PaymentPattern]([Pk_RequestId] ASC) WITH (FILLFACTOR = 90);
GO

CREATE NONCLUSTERED INDEX [IX_PaymentPattern_DatasetNameID_PK_requestID_DevelopmentQuarter]
    ON [IDS].[PaymentPattern]([DatasetNameId] ASC, [Pk_RequestId] ASC, [DevelopmentQuarter] ASC, [PercentageTypeId] ASC, [PaymentPerc] ASC)
    INCLUDE([RIFlag])
    ON [PRIMARY];
GO

CREATE CLUSTERED INDEX [IX_PaymentPattern_DevelopmentQuarter_DatasetNameID]
    ON [IDS].[PaymentPattern]([DevelopmentQuarter] ASC, [DatasetNameId] ASC)
    ON [PRIMARY];
GO

CREATE NONCLUSTERED INDEX [IX_Pk_RequestID_DatasetNameID]
    ON [IDS].[PaymentPattern]([Pk_RequestId] ASC, [DatasetNameId] ASC)
    ON [PRIMARY];
GO