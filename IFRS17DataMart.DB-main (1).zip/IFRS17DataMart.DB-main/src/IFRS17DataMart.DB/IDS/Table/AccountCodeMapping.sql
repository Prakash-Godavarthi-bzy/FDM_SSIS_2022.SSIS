﻿CREATE TABLE [IDS].[AccountCodeMapping] (
    [Id]                  BIGINT         IDENTITY (1, 1) NOT NULL,
    [RunID]               INT            NULL,
    [Account Code]        VARCHAR (15)   NOT NULL,
    [Type]                VARCHAR (30)   NULL,
    [Source]              VARCHAR (50)   NULL,
    [Field Label]         VARCHAR (30)   NULL,
    [AuditCreateDateTime] DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditUserCreate]     NVARCHAR (510) DEFAULT (suser_sname()) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 90)
);


GO




