﻿CREATE TABLE [IDS].[CSM_Post_LCAdjustments] (
    [ID]                    INT              IDENTITY (1, 1) NOT NULL,
    [RunID]                 INT              NOT NULL,
    [Entity]                VARCHAR (20)     NOT NULL,
    [FocusGroup]            VARCHAR (100)    NULL,
    [Tri focus Code]        VARCHAR (25)     NOT NULL,
    [IFRS17 Tri focus code] VARCHAR (25)     NULL,
    [Programme]             VARCHAR (100)    NULL,
    [RI_Flag]               VARCHAR (2)      NULL,
    [YOA]                   INT              NOT NULL,
    [YOI]                   INT              NULL,
    [QOI_End_Date]          DATE             NULL,
    [CCY]                   VARCHAR (10)     NOT NULL,
    [Incepted Status]       CHAR (1)         NULL,
    [Statement]             VARCHAR (50)     NOT NULL,
    [Balance]               VARCHAR (50)     NOT NULL,
    [Position]              VARCHAR (50)     NOT NULL,
    [Amount]                NUMERIC (38, 12) NULL,
    [Amount_disc]           NUMERIC (38, 12) NULL,
    [Conv_Amount]           NUMERIC (38, 12) NULL,
    [Conv_Amount_disc]      NUMERIC (38, 12) NULL,
    [UOA]                   VARCHAR (100)    NULL,
    [CSM_LC]                VARCHAR (10)     NULL,
    [Portfolio]             VARCHAR (100)    NULL,
    [AuditCreateDateTime]   DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]       NVARCHAR (510)   DEFAULT (suser_sname()) NOT NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);




GO
CREATE NONCLUSTERED INDEX [IX_CSM_Post_LCAdjustments_RunID]
    ON [IDS].[CSM_Post_LCAdjustments]([RunID] ASC, [Entity] ASC, [Tri focus Code] ASC) WITH (FILLFACTOR = 90);

