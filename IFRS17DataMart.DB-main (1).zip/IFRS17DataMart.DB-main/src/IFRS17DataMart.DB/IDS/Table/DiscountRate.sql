﻿CREATE TABLE [IDS].[DiscountRate] (
    [Pk_RequestId]        INT              NOT NULL,
    [DatasetNameId]       INT              NULL,
    [PercentageTypeId]    INT              NULL,
    [LossType]            INT              NULL,
    [Currency]            NVARCHAR (10)     NULL,
    [DevelopmentYear]     INT              NULL,
    [Quarters]            DATE             NULL,
    [DiscountRt]          DECIMAL (19, 10) NULL,
    [OBFlag ]             INT              NULL,
    [AuditCreateDateTime] DATETIME2 (7)    DEFAULT (getdate()) NULL,
    [AuditUserCreate]     NVARCHAR (510)   DEFAULT (suser_sname()) NULL
);
GO

CREATE NONCLUSTERED INDEX [bzyidx_DiscountRate_1]
    ON [IDS].[DiscountRate]([Pk_RequestId] ASC) WITH (FILLFACTOR = 90);
GO

CREATE CLUSTERED INDEX [IX_DiscountRate_DatasetNameID]
    ON [IDS].[DiscountRate]([DatasetNameId] ASC)
    ON [PRIMARY];
GO

