﻿CREATE TABLE [IDS].[HistPremLockRatesOB] (
    [ID]                  INT              IDENTITY (1, 1) NOT NULL,
    [RunID]               INT              NOT NULL,
    [QOI_End_Date]        DATE             NULL,
    [Programme]           VARCHAR (100)    NULL,
    [FocusGroup]          VARCHAR (100)    NULL,
    [CCY]                 VARCHAR (10)     NOT NULL,
    [Amount]              NUMERIC (38, 12) NOT NULL,
    [AuditCreateDateTime] DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]     NVARCHAR (510)   DEFAULT (suser_sname()) NOT NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);



GO
CREATE NONCLUSTERED INDEX [IX_HistPremLockRatesOB_RunID]
    ON [IDS].[HistPremLockRatesOB]([RunID] ASC) WITH (FILLFACTOR = 90);

