﻿CREATE TABLE [IDS].[Open_CloseYOA] (
    [Id]                  INT            IDENTITY (1, 1) NOT NULL,
    [RunId]               INT            NOT NULL,
    [Programme]           VARCHAR (100)  NOT NULL,
    [TrifocusCode]        VARCHAR (25)   NOT NULL,
    [YOA]                 INT            NOT NULL,
    [Open/Closed]         VARCHAR (10)   NOT NULL,
    [AuditCreateDateTime] DATETIME2 (7)  NOT NULL,
    [AuditUserCreate]     NVARCHAR (510) NOT NULL,
    [ValidFrom]           DATETIME2 (7)  NOT NULL,
    [ValidTo]             DATETIME2 (7)  NOT NULL
);
GO

CREATE NONCLUSTERED INDEX [bzindx_logicalKey]
    ON [IDS].[Open_CloseYOA]([RunId] ASC) WITH (FILLFACTOR = 90);
GO

CREATE NONCLUSTERED INDEX [bzyidx_Open_CloseYOA_1]
    ON [IDS].[Open_CloseYOA]([RunId] ASC) WITH (FILLFACTOR = 90);
GO

CREATE NONCLUSTERED INDEX [IX_Open_Close_YOA_YOA]
    ON [IDS].[Open_CloseYOA]([YOA] ASC)
    ON [PRIMARY];
GO

CREATE NONCLUSTERED INDEX [IX_Open_CloseYOA_Programme_RunID_YOA]
    ON [IDS].[Open_CloseYOA]([Programme] ASC, [RunId] ASC, [YOA] ASC)
    INCLUDE([TrifocusCode], [Open/Closed])
    ON [PRIMARY];
GO

CREATE NONCLUSTERED INDEX [IX_Open_CloseYOA_RunID_Trifocuscode_YOA]
    ON [IDS].[Open_CloseYOA]([RunId] ASC, [TrifocusCode] ASC, [YOA] ASC, [Open/Closed] ASC)
    INCLUDE([Programme])
    ON [PRIMARY];
GO