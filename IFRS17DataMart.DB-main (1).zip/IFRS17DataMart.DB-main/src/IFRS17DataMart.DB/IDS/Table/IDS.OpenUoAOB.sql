﻿CREATE TABLE [IDS].[OpenUoAOB] (
    [ID]                  INT            IDENTITY (1, 1) NOT NULL,
    [RunID]               INT            NOT NULL,
    [TFYOI]               VARCHAR (100)  NULL,
    [Entity]              VARCHAR (20)   NOT NULL,
    [FocusGroup]          VARCHAR (100)  NULL,
    [UOA]                 VARCHAR (100)  NULL,
    [YOI]                 INT            NULL,
    [Programme]           VARCHAR (100)  NULL,
    [Tri focus code]      VARCHAR (25)   NOT NULL,
    [Tri focus]           VARCHAR (50)   NULL,
    [TFUOA]               VARCHAR (200)  NULL,
    [Onerosity]           CHAR (2)       NULL,
    [CSM_LC]              VARCHAR (10)   NULL,
    [AuditCreateDateTime] DATETIME2 (7)  DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]     NVARCHAR (510) DEFAULT (suser_sname()) NOT NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);


GO
CREATE NONCLUSTERED INDEX [IX_OpenUoAOB_RunID]
    ON [IDS].[OpenUoAOB]([RunID] ASC, [Entity] ASC, [Tri focus code] ASC) WITH (FILLFACTOR = 90);

