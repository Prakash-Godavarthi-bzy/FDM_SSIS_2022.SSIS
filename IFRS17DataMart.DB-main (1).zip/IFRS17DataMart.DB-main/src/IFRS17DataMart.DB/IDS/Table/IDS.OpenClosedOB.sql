﻿CREATE TABLE [IDS].[OpenClosedOB] (
    [ID]                     INT            IDENTITY (1, 1) NOT NULL,
    [RunID]                  INT            NOT NULL,
    [Programme]              VARCHAR (100)  NULL,
    [Tri focus code]         VARCHAR (25)   NOT NULL,
    [YOA]                    INT            NOT NULL,
    [Open/Closed Derivation] VARCHAR (10)   NULL,
    [AuditCreateDateTime]    DATETIME2 (7)  DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]        NVARCHAR (510) DEFAULT (suser_sname()) NOT NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);




GO
CREATE NONCLUSTERED INDEX [IX_OpenClosedOB_RunID]
    ON [IDS].[OpenClosedOB]([RunID] ASC, [Tri focus code] ASC) WITH (FILLFACTOR = 90);

