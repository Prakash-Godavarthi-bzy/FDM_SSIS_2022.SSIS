﻿CREATE TABLE [IDS].[SpotToForward] (
    [ID]                  INT            IDENTITY (1, 1) NOT NULL,
    [Section]             VARCHAR (99)   NULL,
    [Parameter]           VARCHAR (99)   NULL,
    [Value]               VARCHAR (3000) NULL,
    [AuditCreateDateTime] DATETIME       DEFAULT (getdate()) NULL,
    [AuditUserCreate]     VARCHAR (255)  DEFAULT (suser_name()) NULL
);

