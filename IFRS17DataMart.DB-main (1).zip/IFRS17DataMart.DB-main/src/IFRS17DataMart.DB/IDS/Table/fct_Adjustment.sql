﻿CREATE TABLE [IDS].[fct_Adjustment] (
    [Id]                  BIGINT           IDENTITY (1, 1) NOT NULL,
    [RunID]               INT              NULL,
	[DatasetNameId]       INT              NULL,
    [Adjustment ID]       VARCHAR (30)     NULL,
    [Account]             VARCHAR (100)    NULL,
    [Gross_RI Flag]       VARCHAR (2)      NULL,
    [Currency]            VARCHAR (10)     NULL,
    [Entity]              VARCHAR (50)     NULL,
    [Trifocus]            VARCHAR (25)     NULL,
    [Programme]           VARCHAR (100)    NULL,
    [YOA]                 INT              NULL,
    [Source]              CHAR (1)         NULL,
    [Amount]              NUMERIC (38, 10) NULL,
    [Earned %]            DECIMAL (19, 10) NULL,
    [Inception Date]      DATETIME         NULL,
    [Narrative]           VARCHAR (255)    NULL,
    [AuditCreateDateTime] DATETIME2 (7)    NOT NULL,
    [AuditUserCreate]     NVARCHAR (510)   NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 90)
);




GO
CREATE NONCLUSTERED INDEX [bzyidx_fct_Adjustment_1]
    ON [IDS].[fct_Adjustment]([RunID] ASC) WITH (FILLFACTOR = 90);

