﻿CREATE TABLE [IDS].[UndiscLRCWalkBalancesOB] (
    [ID]                    INT              IDENTITY (1, 1) NOT NULL,
    [RunID]                 INT              NOT NULL,
    [Entity]                VARCHAR (20)     NOT NULL,
    [Tri focus code]        VARCHAR (25)     NOT NULL,
    [IFRS17 Tri focus code] VARCHAR (25)     NULL,
    [Account]               VARCHAR (15)     NOT NULL,
    [Programme]             VARCHAR (100)    NULL,
    [RI_Flag]               VARCHAR (2)      NULL,
    [YOA]                   INT              NOT NULL,
    [YOI]                   INT              NULL,
    [QOI_End_Date]          DATE             NULL,
    [CCY]                   VARCHAR (10)     NOT NULL,
    [InceptedStatus]        CHAR (1)         NULL,
    [Open/Closed]           CHAR (10)        NULL,
    [Statement]             VARCHAR (50)     NOT NULL,
    [Position]              VARCHAR (50)     NOT NULL,
    [Balance]               VARCHAR (50)     NOT NULL,
    [Amount]                NUMERIC (38, 12) NOT NULL,
    [AuditCreateDateTime]   DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditUserCreate]       NVARCHAR (510)   DEFAULT (suser_sname()) NOT NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC) WITH (FILLFACTOR = 90)
);


GO
CREATE NONCLUSTERED INDEX [IX_UndiscLRCWalkBalancesOB_RunID]
    ON [IDS].[UndiscLRCWalkBalancesOB]([RunID] ASC, [Entity] ASC, [Tri focus code] ASC) WITH (FILLFACTOR = 90);

