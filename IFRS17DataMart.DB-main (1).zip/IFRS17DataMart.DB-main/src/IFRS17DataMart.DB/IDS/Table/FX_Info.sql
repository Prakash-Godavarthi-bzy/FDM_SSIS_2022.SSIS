﻿CREATE TABLE [IDS].[FX_Info] (
    [ID]                  INT           IDENTITY (1, 1) NOT NULL,
    [Statement]           VARCHAR (8)   NULL,
    [Position]            VARCHAR (8)   NULL,
    [fx_rate_type]        VARCHAR (8)   NULL,
    [OpenCls]             VARCHAR (8)   NULL,
    [AuditCreateDateTime] DATETIME      DEFAULT (getdate()) NULL,
    [AuditUserCreate]     VARCHAR (255) DEFAULT (suser_name()) NULL
);

