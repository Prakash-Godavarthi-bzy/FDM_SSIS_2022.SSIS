﻿CREATE TABLE [IDS].[Aggr_PremiumBrokerage] (
    [Id]                  BIGINT           IDENTITY (1, 1) NOT NULL,
    [RunID]               INT              NULL,
    [Entity]              VARCHAR (20)     NOT NULL,
    [Tri focus code]      VARCHAR (25)     NOT NULL,
    [IFRS17 Trifocus]     VARCHAR (25)     NULL,
    [Account]             VARCHAR (15)     NOT NULL,
    [Premtype]            VARCHAR (25)     NOT NULL,
    [Programme]           VARCHAR (100)    NULL,
    [RI_Flag]             VARCHAR (2)      NULL,
    [YOA]                 INT              NOT NULL,
    [YOI]                 INT              NULL,
    [QOI_End_Date]        DATE             NULL,
    [RecognitionType]     CHAR (2)         NULL,
    [CCY]                 VARCHAR (10)         NOT NULL,
    [Adjust_Flag]         CHAR (1)         NULL,
    [Amount]              NUMERIC (38, 10) NULL,
    [AuditCreateDateTime] DATETIME2 (7)    NOT NULL,
    [AuditUserCreate]     NVARCHAR (510)   NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 90)
);
GO

CREATE NONCLUSTERED INDEX [bzyidx_Aggr_PremiumBrokerage_1]
    ON [IDS].[Aggr_PremiumBrokerage]([RunID] ASC)
    INCLUDE([RI_Flag]) WITH (FILLFACTOR = 90);
GO

CREATE NONCLUSTERED INDEX [bzyidx_Aggr_PremiumBrokerage_2]
    ON [IDS].[Aggr_PremiumBrokerage]([YOI] ASC) WITH (FILLFACTOR = 90);
GO

CREATE NONCLUSTERED INDEX [bzyidx_Aggr_PremiumBrokerage_3]
    ON [IDS].[Aggr_PremiumBrokerage]([Premtype] ASC) WITH (FILLFACTOR = 90);
GO

CREATE NONCLUSTERED INDEX [bzyidx_Aggr_PremiumBrokerage_4]
    ON [IDS].[Aggr_PremiumBrokerage]([RI_Flag] ASC) WITH (FILLFACTOR = 90);
GO

CREATE NONCLUSTERED INDEX [bzyidx_Aggr_PremiumBrokerage_5]
    ON [IDS].[Aggr_PremiumBrokerage]([Account] ASC) WITH (FILLFACTOR = 90);
GO

CREATE NONCLUSTERED INDEX [IX_Aggr_PremiumBrokerage_RunID_ID_RI_Flag]
    ON [IDS].[Aggr_PremiumBrokerage]([RunID] ASC, [Id] ASC, [RI_Flag] ASC, [Tri focus code] ASC, [Account] ASC, [Entity] ASC, [IFRS17 Trifocus] ASC, [Programme] ASC, [Premtype] ASC, [RecognitionType] ASC, [Amount] ASC)
    INCLUDE([YOA], [YOI], [CCY])
    ON [PRIMARY];
GO

