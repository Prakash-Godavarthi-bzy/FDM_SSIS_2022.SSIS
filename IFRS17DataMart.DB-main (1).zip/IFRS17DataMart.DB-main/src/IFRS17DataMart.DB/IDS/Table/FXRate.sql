﻿CREATE TABLE [IDS].[FXRate] (
    [Pk_RequestId]        INT              NOT NULL,
    [DatasetNameId]       INT              NULL,
    [PercentageTypeId]    INT              NULL,
    [LossType]            VARCHAR (3)      NULL,
    [ReportingCurrency]   NVARCHAR (255)   NULL,
    [TransactionCurrency] VARCHAR (10)     NULL,
    [FXRate_0]            DECIMAL (19, 10) NULL,
    [OBFlag ]             INT              NULL,
    [AuditCreateDateTime] DATETIME2 (7)    DEFAULT (getdate()) NULL,
    [AuditUserCreate]     NVARCHAR (510)   DEFAULT (suser_sname()) NULL
);
GO

CREATE NONCLUSTERED INDEX [bzyidx_FXRate_1]
    ON [IDS].[FXRate]([Pk_RequestId] ASC) WITH (FILLFACTOR = 90);
GO

CREATE CLUSTERED INDEX [IX_FXRate_DatasetNameID]
    ON [IDS].[FXRate]([DatasetNameId] ASC)
    ON [PRIMARY];
GO


