﻿
--declare @RequestId INT = 3700;


CREATE FUNCTION [IDS].[udf_GetGrossRIColumns] ( @RequestId INT)

RETURNS TABLE
AS
RETURN


WITH ColumnList AS
(
		SELECT [Pk_RequestId]  , DatasetName, ColumnName
		FROM [PWAPS].[IFRS17CalcUI_RunLog]
		UNPIVOT (
			DatasetName FOR ColumnName IN (

			   [Pure IELR Q1]
			  ,[Pure IELR Q2]
			  ,[Pure IELR Q3]
			  ,[Pure IELR Q4]
			  ,[Pure IELR Q5]
			  ,[Pure IELR SM]

			  ,[ENIDs Q1]
			  ,[ENIDs Q2]
			  ,[ENIDs Q3]
			  ,[ENIDs Q4]
			  ,[ENIDs Q5]
			  ,[ENIDs SM]

			  ,[Admin Expense Q1 (Claims Related)]
			  ,[Admin Expense Q2 (Claims Related)]
			  ,[Admin Expense Q3 (Claims Related)]
			  ,[Admin Expense Q4 (Claims Related)]
			  ,[Admin Expense Q5 (Claims Related)]
			  ,[Admin Expense SM (Claims Related)]

			  ,[Admin Expense Q1 (other)]
			  ,[Admin Expense Q2 (other)]
			  ,[Admin Expense Q3 (other)]
			  ,[Admin Expense Q4 (other)]
			  ,[Admin Expense Q5 (other)]
			  ,[Admin Expense SM (other)]

			  ,[Admin Expense Q1 (Premium Related)]
			  ,[Admin Expense Q2 (Premium Related)]
			  ,[Admin Expense Q3 (Premium Related)]
			  ,[Admin Expense Q4 (Premium Related)]
			  ,[Admin Expense Q5 (Premium Related)]
			  ,[Admin Expense SM (Premium Related)]

			  ,[Claims Handling Expenses Q1]
			  ,[Claims Handling Expenses Q2]
			  ,[Claims Handling Expenses Q3]
			  ,[Claims Handling Expenses Q4]
			  ,[Claims Handling Expenses Q5]
			  ,[Claims Handling Expenses SM]

			  ,[Other Acquisition Expenses Q1] 
			  ,[Other Acquisition Expenses Q2]
			  ,[Other Acquisition Expenses Q3]
			  ,[Other Acquisition Expenses Q4]
			  ,[Other Acquisition Expenses Q5]
			  ,[Other Acquisition Expenses SM]

			  ,[Profit Commission Q1]
			  ,[Profit Commission Q2]
			  ,[Profit Commission Q3]
			  ,[Profit Commission Q4]
			  ,[Profit Commission Q5]
			  ,[Profit Commission SM]

			  ,[Reinstatement Premium Q1]
			  ,[Reinstatement Premium Q2]
			  ,[Reinstatement Premium Q3]
			  ,[Reinstatement Premium Q4]
			  ,[Reinstatement Premium Q5]
			  ,[Reinstatement Premium SM]

			  ,[Pure ULR SM]
			  ,[Pure ULR(Re) SM]

			  ,[ENIDs UnEarned Q1]
			  ,[ENIDs UnEarned Q2]
			  ,[ENIDs UnEarned Q3]
			  ,[ENIDs UnEarned Q4]
			  ,[ENIDs UnEarned Q5]
			  ,[ENIDs UnEarned SM]

			  ,[Rebates Q1]
			  ,[Rebates Q2]
			  ,[Rebates Q3]
			  ,[Rebates Q4]
			  ,[Rebates Q5]
			  ,[Rebates SM]

			  ,[RICL Q1]
			  ,[RICL Q2]
	          ,[RICL Q3]
	          ,[RICL Q4]
	          ,[RICL Q5]
	          ,[RICL SM]

			  ,[Pure IELR(Re) Q1] 						
			  ,[Pure IELR(Re) Q2] 						
			  ,[Pure IELR(Re) Q3] 						
			  ,[Pure IELR(Re) Q4] 						
			  ,[Pure IELR(Re) Q5] 						
			  ,[Pure IELR(Re) SM] 						
			  
			  ,[ENIDs Earned(Re) Q1] 					
			  ,[ENIDs Earned(Re) Q2] 					
			  ,[ENIDs Earned(Re) Q3] 					
			  ,[ENIDs Earned(Re) Q4] 					
			  ,[ENIDs Earned(Re) Q5] 					
			  ,[ENIDs Earned(Re) SM] 					

			  ,[ENIDs Unearned(Re) Q1] 					
			  ,[ENIDs Unearned(Re) Q2] 					
			  ,[ENIDs Unearned(Re) Q3] 					
			  ,[ENIDs Unearned(Re) Q4] 					
			  ,[ENIDs Unearned(Re) Q5] 					
			  ,[ENIDs Unearned(Re) SM]
			  
			  ,[Profit Commission(Re) Q1] 				
			  ,[Profit Commission(Re) Q2] 				
			  ,[Profit Commission(Re) Q3] 				
			  ,[Profit Commission(Re) Q4] 				
			  ,[Profit Commission(Re) Q5] 				
			  ,[Profit Commission(Re) SM] 				
			  
			  ,[Reinstatement Premium(Re) Q1] 			
			  ,[Reinstatement Premium(Re) Q2] 			
			  ,[Reinstatement Premium(Re) Q3] 			
			  ,[Reinstatement Premium(Re) Q4] 			
			  ,[Reinstatement Premium(Re) Q5] 			
			  ,[Reinstatement Premium(Re) SM] 			
			  
			  --,[Other Acquisition Expenses(Re) Q1] 	
			  --,[Other Acquisition Expenses(Re) Q2] 	
			  --,[Other Acquisition Expenses(Re) Q3] 	
			  --,[Other Acquisition Expenses(Re) Q4] 	
			  --,[Other Acquisition Expenses(Re) Q5] 	
			  --,[Other Acquisition Expenses(Re) SM] 

			  ,[RI Admin Q1]
	          ,[RI Admin Q2]
	          ,[RI Admin Q3]
	          ,[RI Admin Q4]
	          ,[RI Admin Q5] 
	          ,[RI Admin SM] 

	          ,[Premium Lapse Risk Q1] 
	          ,[Premium Lapse Risk Q2]
	          ,[Premium Lapse Risk Q3]
	          ,[Premium Lapse Risk Q4]
	          ,[Premium Lapse Risk Q5]
	          ,[Premium Lapse Risk SM]

	          ,[LRC Risk Adjustment Q1]
	          ,[LRC Risk Adjustment Q2]
	          ,[LRC Risk Adjustment Q3]
	          ,[LRC Risk Adjustment Q4] 
	          ,[LRC Risk Adjustment Q5] 
	          ,[LRC Risk Adjustment SM] 

	          ,[LIC Risk Adjustment Q1]
	          ,[LIC Risk Adjustment Q2] 
	          ,[LIC Risk Adjustment Q3] 
	          ,[LIC Risk Adjustment Q4] 
	          ,[LIC Risk Adjustment Q5]
	          ,[LIC Risk Adjustment SM] 

	           ,[LIC Risk Adjustment (Older Years) Q1] 
	           ,[LIC Risk Adjustment (Older Years) Q2] 
	           ,[LIC Risk Adjustment (Older Years) Q3] 
	           ,[LIC Risk Adjustment (Older Years) Q4] 
	           ,[LIC Risk Adjustment (Older Years) Q5] 
	           ,[LIC Risk Adjustment (Older Years) SM] 

			   ,[Payment Pattern Claims]
			   ,[Payment Pattern Claims(Re)]
			   ,[Pattern Scenario]
			   ,[Pattern Scenario(Re)]
			   
			)
		) unpvt
		WHERE Pk_RequestId = @RequestId
)


SELECT Pk_RequestId
	, DatasetName 
	, ColumnName
	, CASE WHEN ColumnName LIKE ('%(Re)%') OR ColumnName like 'RI%' OR ColumnName like 'Rebates%'
		   THEN CASE WHEN  ColumnName LIKE ('%Pattern%') AND DatasetName LIKE 'SYS%' 
					 THEN 'GR'
					 ELSE  'RI' 
				END
		   ELSE CASE WHEN ColumnName LIKE '%LIC%' OR ColumnName LIKE '%LRC%'
					 THEN 'GL'
					 ELSE 'GR' 
				END
	  END ColumnType
	, CASE WHEN ColumnName LIKE ('%Pattern%')  THEN 'PP' ELSE 'AD' END AS AssumptionType
FROM ColumnList