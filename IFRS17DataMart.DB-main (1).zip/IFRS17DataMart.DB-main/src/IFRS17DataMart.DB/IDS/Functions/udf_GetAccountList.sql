﻿
----declare @Scenario char(1) = 'U';


CREATE FUNCTION [IDS].[udf_GetAccountList] ( @Scenario char(1))

RETURNS TABLE
AS
RETURN
SELECT AccountCode
from (VALUES
		('U' , 'GP-T-PR'), 
	    ('U' , 'RP-T-PR'),
		('A' , 'P-GP-P'),
		('F' , 'P-GP-P'),
		('B' , 'P-GP-P'),
		('BP' , 'P-GP-P'),
		('A' , 'P-AC-P'),
		('F' , 'P-AC-P'),
		('B' , 'P-AC-P'),
		('BP' , 'P-AC-P'),
		('A' , 'GPE-RP-P'),
		('F' , 'GPE-RP-P'),
		('B' , 'GPE-RP-P'),
		('BP' , 'GPE-RP-P'),
		('A' , 'P-BP-B'),
		('F' , 'P-BP-B'),
		('B' , 'P-BP-B'),
		('BP' , 'P-BP-B'),
		('A' , 'P-BA-B'),
		('F' , 'P-BA-B'),
		('B' , 'P-BA-B'),
		('BP' , 'P-BA-B'),
		('N' , 'NA')
	)AS TAB(Scenario, AccountCode)
WHERE Scenario = @Scenario